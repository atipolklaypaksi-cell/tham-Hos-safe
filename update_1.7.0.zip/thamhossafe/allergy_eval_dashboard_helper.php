<?php
/**
 * Dashboard การประเมินแพ้ยา — สรุปราย (HN+วันที่) ตามเภสัช และมูลค่าที่ตั้งไว้
 */

function aed_fee_defaults() {
    return [
        'existing_history' => ['label' => 'บัตรเดิม/ประวัติจาก รพ.อื่น', 'baht' => 10, 'sort' => 1],
        'allergy_no_follow' => ['label' => 'แพ้ยา ไม่ต้องติดตามเคส', 'baht' => 20, 'sort' => 2],
        'not_allergy' => ['label' => 'ไม่แพ้ยา', 'baht' => 20, 'sort' => 3],
        'adr_type_a' => ['label' => 'ADRs type A', 'baht' => 20, 'sort' => 4],
        'followup' => ['label' => 'ติดตามเคส (แพ้ยาหรือไม่)', 'baht' => 30, 'sort' => 5],
        'monitor' => ['label' => 'เฝ้าระวัง', 'baht' => 30, 'sort' => 6],
        'unclosed' => ['label' => 'ปิดเคสไม่ได้', 'baht' => 0, 'sort' => 7],
    ];
}

function aed_config_key() {
    return 'af_eval_fee_json';
}

function aed_load_fees($con) {
    $defaults = aed_fee_defaults();
    $key = mysqli_real_escape_string($con, aed_config_key());
    $q = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='$key' LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    $raw = trim((string)($row['config_value'] ?? ''));
    $saved = $raw !== '' ? json_decode($raw, true) : null;
    if (!is_array($saved)) {
        return $defaults;
    }
    foreach ($defaults as $code => $meta) {
        if (isset($saved[$code]) && is_array($saved[$code]) && isset($saved[$code]['baht'])) {
            $defaults[$code]['baht'] = max(0, (float)$saved[$code]['baht']);
        } elseif (isset($saved[$code]) && is_numeric($saved[$code])) {
            $defaults[$code]['baht'] = max(0, (float)$saved[$code]);
        }
    }
    return $defaults;
}

function aed_save_fees($con, array $incoming) {
    $defaults = aed_fee_defaults();
    $out = [];
    foreach ($defaults as $code => $meta) {
        $baht = $meta['baht'];
        if (isset($incoming[$code]) && is_array($incoming[$code]) && isset($incoming[$code]['baht'])) {
            $baht = $incoming[$code]['baht'];
        } elseif (isset($incoming[$code])) {
            $baht = $incoming[$code];
        }
        $out[$code] = [
            'label' => $meta['label'],
            'baht' => max(0, (float)$baht),
            'sort' => $meta['sort'],
        ];
    }
    $json = json_encode($out, JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return ['ok' => false, 'error' => 'แปลงค่าตั้งไม่สำเร็จ'];
    }
    $key = mysqli_real_escape_string($con, aed_config_key());
    $val = mysqli_real_escape_string($con, $json);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$key' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $ok = mysqli_query($con, "UPDATE sys_config SET config_value='$val' WHERE config_name='$key'");
    } else {
        $ok = mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$key', '$val')");
    }
    if (!$ok) {
        return ['ok' => false, 'error' => mysqli_error($con) ?: 'บันทึกไม่สำเร็จ'];
    }
    return ['ok' => true, 'fees' => $out];
}

function aed_hn_key($hn) {
    $hn = preg_replace('/\s+/', '', (string)$hn);
    if ($hn !== '' && ctype_digit($hn)) {
        return ltrim($hn, '0') ?: '0';
    }
    return strtolower($hn);
}

function aed_name_key($name) {
    $n = trim(preg_replace('/\s+/u', ' ', (string)$name));
    $n = preg_replace('/^(นาย|นางสาว|นาง|น\.ส\.|นส\.|ดร\.|ภก\.|ภญ\.|ภก|ภญ)\s*/u', '', $n);
    if (function_exists('mb_strtolower')) {
        return mb_strtolower($n, 'UTF-8');
    }
    return strtolower($n);
}

function aed_display_name($name, $fallback = 'ไม่ระบุผู้ประเมิน') {
    $n = trim(preg_replace('/\s+/u', ' ', (string)$name));
    return $n !== '' ? $n : $fallback;
}

function aed_classify_followup(array $row) {
    $sum = trim((string)($row['summary_result'] ?? ''));
    $fu = (int)($row['followup_count'] ?? 0);
    $stage = trim((string)($row['workflow_stage'] ?? ''));
    if ($sum === 'existing_history') {
        return 'existing_history';
    }
    if ($fu > 0 || $stage === 'following') {
        return 'followup';
    }
    if ($sum === 'monitor') {
        return 'monitor';
    }
    if ($sum === 'allergy') {
        return 'allergy_no_follow';
    }
    if ($sum === 'not_allergy') {
        return 'not_allergy';
    }
    if ($sum === 'adr_type_a') {
        return 'adr_type_a';
    }
    if ($sum === 'unclosed') {
        return 'unclosed';
    }
    return '';
}

function aed_classify_hosxp(array $row) {
    $blob = trim(implode(' ', [
        (string)($row['source_name'] ?? ''),
        (string)($row['allergy_type_name'] ?? ''),
        (string)($row['alert_type_name'] ?? ''),
        (string)($row['note'] ?? ''),
    ]));
    $low = function_exists('mb_strtolower') ? mb_strtolower($blob, 'UTF-8') : strtolower($blob);
    if (strpos($low, 'บัตรเดิม') !== false || strpos($low, 'รพ.อื่น') !== false
        || strpos($low, 'รพ อื่น') !== false || strpos($low, 'โรงพยาบาลอื่น') !== false) {
        return 'existing_history';
    }
    if (strpos($low, 'เฝ้า') !== false) {
        return 'monitor';
    }
    return 'allergy_no_follow';
}

function aed_pharmacist_of_followup(array $row) {
    foreach (['owner_name', 'closed_by_name', 'ack_by_name'] as $k) {
        $n = trim((string)($row[$k] ?? ''));
        if ($n !== '') {
            return $n;
        }
    }
    return '';
}

function aed_load_followup_rows($con, $start, $end) {
    require_once __DIR__ . '/allergy_followup_helper.php';
    af_ensure_tables($con);
    $start_esc = mysqli_real_escape_string($con, $start);
    $end_esc = mysqli_real_escape_string($con, $end);
    $sql = "SELECT id, case_date, hn, ptname, summary_result, owner_name, closed_by_name, ack_by_name,
                   followup_count, workflow_stage, ward, assessment_detail, ward_detail
            FROM allergy_followup_cases
            WHERE case_date >= '$start_esc' AND case_date <= '$end_esc'
            ORDER BY case_date DESC, id DESC";
    $q = mysqli_query($con, $sql);
    $out = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $out[] = $r;
        }
    }
    return $out;
}

function aed_load_hosxp_rows($con, $start, $end) {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    require_once __DIR__ . '/allergy_history_helper.php';
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 60) : null;
    if (!$hos) {
        return ['ok' => false, 'error' => 'เชื่อมต่อ HOSxP ไม่ได้', 'rows' => []];
    }
    $res = ah_fetch_rows($hos, [
        'start_date' => $start,
        'end_date' => $end,
        'limit' => 12000,
    ]);
    @mysqli_close($hos);
    if (empty($res['ok'])) {
        return ['ok' => false, 'error' => $res['error'] ?? 'ดึงประวัติแพ้ยาไม่สำเร็จ', 'rows' => []];
    }
    return ['ok' => true, 'error' => '', 'rows' => $res['rows']];
}

function aed_build_dashboard($con, $start, $end) {
    $fees = aed_load_fees($con);
    $follow = aed_load_followup_rows($con, $start, $end);
    $hx = aed_load_hosxp_rows($con, $start, $end);
    $hx_rows = $hx['rows'] ?? [];
    $hx_error = empty($hx['ok']) ? (string)($hx['error'] ?? '') : '';

    $groups = [];

    foreach ($follow as $r) {
        $type = aed_classify_followup($r);
        if ($type === '') {
            continue;
        }
        $hn = aed_hn_key($r['hn'] ?? '');
        $date = substr((string)($r['case_date'] ?? ''), 0, 10);
        if ($hn === '' || $date === '') {
            continue;
        }
        $key = $hn . '|' . $date;
        if (!isset($groups[$key])) {
            $groups[$key] = aed_empty_group($hn, $date);
        }
        $g = &$groups[$key];
        $g['has_followup'] = true;
        $g['ptname'] = $g['ptname'] !== '' ? $g['ptname'] : trim((string)($r['ptname'] ?? ''));
        $g['ward'] = $g['ward'] !== '' ? $g['ward'] : trim((string)($r['ward'] ?? ''));
        $g['followup_ids'][] = (int)$r['id'];
        $pharm = aed_pharmacist_of_followup($r);
        if ($pharm !== '' && $g['pharmacist'] === '') {
            $g['pharmacist'] = $pharm;
        }
        aed_offer_type($g, $type, $fees);
        $g['drugs'][] = trim((string)($r['ward_detail'] ?? ''));
        unset($g);
    }

    $incomplete_rows = 0;
    foreach ($hx_rows as $r) {
        $hn = aed_hn_key($r['hn'] ?? ($r['hn_display'] ?? ''));
        $date = substr((string)($r['report_date'] ?? ''), 0, 10);
        if ($hn === '' || $date === '') {
            continue;
        }
        $key = $hn . '|' . $date;
        $complete = !empty($r['is_complete']);
        if (!isset($groups[$key])) {
            $groups[$key] = aed_empty_group($hn, $date);
        }
        $g = &$groups[$key];
        $g['has_hosxp'] = true;
        $g['ptname'] = $g['ptname'] !== '' ? $g['ptname'] : trim((string)($r['fullname'] ?? ''));
        $g['hn_display'] = $g['hn_display'] !== '' ? $g['hn_display'] : (string)($r['hn_display'] ?? $hn);
        $agent = trim((string)($r['agent'] ?? ''));
        if ($agent !== '') {
            $g['drugs'][] = $agent;
        }
        if (!$complete) {
            $incomplete_rows++;
            $g['incomplete_drugs']++;
            foreach ((array)($r['missing_fields'] ?? []) as $mf) {
                $g['missing'][$mf] = true;
            }
            $pharm = trim((string)($r['evaluator_name'] ?? ''));
            if ($pharm !== '' && $g['pharmacist'] === '') {
                $g['pharmacist'] = $pharm;
            }
        } else {
            $g['complete_drugs']++;
            $pharm = trim((string)($r['evaluator_name'] ?? ''));
            if ($pharm !== '' && $g['pharmacist'] === '') {
                $g['pharmacist'] = $pharm;
            }
            if (!$g['has_followup']) {
                aed_offer_type($g, aed_classify_hosxp($r), $fees);
            }
        }
        unset($g);
    }

    $billable = [];
    $incomplete_persons = [];
    $dup_removed = 0;
    foreach ($groups as $g) {
        if ($g['has_followup'] && $g['has_hosxp']) {
            $dup_removed++;
        }
        $g['drug_count'] = count(array_unique(array_filter(array_map('trim', $g['drugs']))));
        $g['drugs'] = array_values(array_unique(array_filter(array_map('trim', $g['drugs']))));
        $g['missing_fields'] = array_keys($g['missing']);
        $g['pharmacist'] = aed_display_name($g['pharmacist']);
        $g['pharmacist_key'] = aed_name_key($g['pharmacist']);
        $g['hn_display'] = $g['hn_display'] !== '' ? $g['hn_display'] : $g['hn'];

        $can_bill = $g['fee_type'] !== '';
        if ($g['has_hosxp'] && (int)$g['incomplete_drugs'] > 0) {
            $incomplete_persons[] = $g;
        }
        if (!$can_bill) {
            continue;
        }
        $g['baht'] = (float)($fees[$g['fee_type']]['baht'] ?? 0);
        $g['fee_label'] = (string)($fees[$g['fee_type']]['label'] ?? $g['fee_type']);
        $billable[] = $g;
    }

    $by_pharm = [];
    foreach ($billable as $g) {
        $pk = $g['pharmacist_key'] !== '' ? $g['pharmacist_key'] : '_unknown';
        if (!isset($by_pharm[$pk])) {
            $by_pharm[$pk] = aed_empty_pharm($g['pharmacist'], $pk, $fees);
        }
        $by_pharm[$pk]['cases']++;
        $by_pharm[$pk]['baht'] += $g['baht'];
        if (isset($by_pharm[$pk]['by_type'][$g['fee_type']])) {
            $by_pharm[$pk]['by_type'][$g['fee_type']]['count']++;
            $by_pharm[$pk]['by_type'][$g['fee_type']]['baht'] += $g['baht'];
        }
    }
    foreach ($incomplete_persons as $g) {
        $pk = $g['pharmacist_key'] !== '' ? $g['pharmacist_key'] : '_unknown';
        if (!isset($by_pharm[$pk])) {
            $by_pharm[$pk] = aed_empty_pharm($g['pharmacist'], $pk, $fees);
        }
        $by_pharm[$pk]['incomplete']++;
    }
    $pharm_list = array_values($by_pharm);
    usort($pharm_list, function ($a, $b) {
        if ($b['baht'] == $a['baht']) {
            if ($b['incomplete'] == $a['incomplete']) {
                return $b['cases'] <=> $a['cases'];
            }
            return $b['incomplete'] <=> $a['incomplete'];
        }
        return $b['baht'] <=> $a['baht'];
    });

    $type_totals = aed_zero_type_counts($fees);
    $total_baht = 0;
    foreach ($billable as $g) {
        $total_baht += $g['baht'];
        if (isset($type_totals[$g['fee_type']])) {
            $type_totals[$g['fee_type']]['count']++;
            $type_totals[$g['fee_type']]['baht'] += $g['baht'];
        }
    }

    usort($incomplete_persons, function ($a, $b) {
        return strcmp($b['date'], $a['date']);
    });

    return [
        'fees' => $fees,
        'hosxp_error' => $hx_error,
        'summary' => [
            'persons' => count($billable),
            'baht' => $total_baht,
            'pharmacists' => count($pharm_list),
            'followup_source' => count(array_filter($billable, function ($g) { return !empty($g['has_followup']); })),
            'hosxp_source' => count(array_filter($billable, function ($g) { return empty($g['has_followup']) && !empty($g['has_hosxp']); })),
            'duplicates_removed' => $dup_removed,
            'incomplete_persons' => count($incomplete_persons),
            'incomplete_rows' => $incomplete_rows,
            'by_type' => $type_totals,
        ],
        'pharmacists' => $pharm_list,
        'cases' => array_map('aed_public_case', $billable),
        'incomplete' => array_map('aed_public_incomplete', $incomplete_persons),
    ];
}

function aed_empty_group($hn, $date) {
    return [
        'hn' => $hn,
        'hn_display' => $hn,
        'date' => $date,
        'ptname' => '',
        'ward' => '',
        'pharmacist' => '',
        'has_followup' => false,
        'has_hosxp' => false,
        'followup_ids' => [],
        'drugs' => [],
        'complete_drugs' => 0,
        'incomplete_drugs' => 0,
        'missing' => [],
        'fee_type' => '',
        'fee_baht_rank' => -1,
    ];
}

function aed_offer_type(array &$g, $type, array $fees) {
    if ($type === '' || !isset($fees[$type])) {
        return;
    }
    $baht = (float)$fees[$type]['baht'];
    if ($g['fee_type'] === '' || $baht > $g['fee_baht_rank']) {
        $g['fee_type'] = $type;
        $g['fee_baht_rank'] = $baht;
    }
}

function aed_empty_pharm($name, $key, array $fees) {
    return [
        'pharmacist' => $name,
        'pharmacist_key' => $key,
        'cases' => 0,
        'baht' => 0,
        'incomplete' => 0,
        'by_type' => aed_zero_type_counts($fees),
    ];
}

function aed_zero_type_counts(array $fees) {
    $out = [];
    foreach ($fees as $code => $meta) {
        $out[$code] = [
            'code' => $code,
            'label' => $meta['label'],
            'baht_each' => (float)$meta['baht'],
            'count' => 0,
            'baht' => 0,
        ];
    }
    return $out;
}

function aed_public_case(array $g) {
    return [
        'hn' => $g['hn_display'],
        'date' => $g['date'],
        'ptname' => $g['ptname'],
        'ward' => $g['ward'],
        'pharmacist' => $g['pharmacist'],
        'pharmacist_key' => $g['pharmacist_key'],
        'fee_type' => $g['fee_type'],
        'fee_label' => $g['fee_label'],
        'baht' => $g['baht'],
        'drug_count' => $g['drug_count'],
        'drugs' => array_slice($g['drugs'], 0, 8),
        'source' => !empty($g['has_followup']) ? (!empty($g['has_hosxp']) ? 'both' : 'followup') : 'hosxp',
        'followup_id' => !empty($g['followup_ids'][0]) ? (int)$g['followup_ids'][0] : 0,
    ];
}

function aed_public_incomplete(array $g) {
    return [
        'hn' => $g['hn_display'],
        'date' => $g['date'],
        'ptname' => $g['ptname'],
        'pharmacist' => $g['pharmacist'],
        'pharmacist_key' => $g['pharmacist_key'] ?? '',
        'incomplete_drugs' => (int)$g['incomplete_drugs'],
        'missing_fields' => $g['missing_fields'],
    ];
}
