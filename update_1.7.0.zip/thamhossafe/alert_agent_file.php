<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
require_once __DIR__ . '/alert_agent_helper.php';

$name = isset($_GET['file']) ? (string)$_GET['file'] : '';
if ($name === '' && !empty($_GET['latest'])) {
    $latest = tham_alert_agent_latest_file();
    $name = $latest['name'] ?? '';
}
$found = tham_alert_agent_find_file($name);
if (!$found) {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html lang="th"><head><meta charset="UTF-8"><title>ไม่พบไฟล์</title></head><body style="font-family:Tahoma,sans-serif;padding:40px;text-align:center;">';
    echo '<h3>ไม่พบไฟล์ติดตั้ง</h3><p><a href="alert_agent.php">กลับหน้าดาวน์โหลด</a></p></body></html>';
    exit;
}

if (!defined('THAM_SKIP_UNIT_GATE')) {
    define('THAM_SKIP_UNIT_GATE', true);
}
tham_alert_agent_stream_file($found);
exit;
