<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
$default_end = date('Y-m-d');
$default_start = date('Y-m-d', strtotime('-29 days'));
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>AMR Dashboard — เฝ้าระวังเชื้อดื้อยา</title>
    <script>
        (function () {
            var t = localStorage.getItem('amr-dashboard-theme') || 'light';
            document.documentElement.setAttribute('data-amr-theme', t === 'dark' ? 'dark' : 'light');
        })();
    </script>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        :root {
            --amr-ink: #12261c;
            --amr-muted: #5f7468;
            --amr-line: #d7e4dc;
            --amr-card: #ffffff;
            --amr-soft: #eef6f1;
            --amr-page: #e8f1ec;
            --amr-filter-bg: rgba(255,255,255,.88);
            --amr-live-bg: #ffffff;
            --amr-th: #f6faf8;
            --amr-td: #eef3f0;
            --amr-row-hover: #f5fbf8;
            --amr-split-bg: #e6eeea;
            --amr-chip-bg: #ffffff;
            --amr-drop-bg: #ffffff;
            --amr-input-bg: #eef6f1;
            --amr-ward-bg: #f3fbf6;
            --amr-ward-border: #d7efe4;
            --amr-ward-color: #146c4a;
            --amr-heat-empty: #edf3f0;
            --amr-teal: #0f766e;
            --amr-teal-2: #14b8a6;
            --amr-rose: #e11d48;
            --amr-amber: #d97706;
            --amr-ok: #059669;
            --amr-glow-a: rgba(20, 184, 166, .16);
            --amr-glow-b: rgba(225, 29, 72, .08);
        }
        html[data-amr-theme="dark"] {
            --amr-ink: #e8eef0;
            --amr-muted: #9aa7ae;
            --amr-line: #2c3538;
            --amr-card: #171c1f;
            --amr-soft: #12171a;
            --amr-page: #0f1315;
            --amr-filter-bg: rgba(23, 28, 31, .92);
            --amr-live-bg: #171c1f;
            --amr-th: #1e2529;
            --amr-td: #242c30;
            --amr-row-hover: #222a2e;
            --amr-split-bg: #2a3337;
            --amr-chip-bg: #1e2529;
            --amr-drop-bg: #1a2024;
            --amr-input-bg: #12171a;
            --amr-ward-bg: #163028;
            --amr-ward-border: #1f4d3b;
            --amr-ward-color: #7dcea0;
            --amr-heat-empty: #222a2e;
            --amr-glow-a: rgba(20, 184, 166, .10);
            --amr-glow-b: rgba(225, 29, 72, .08);
            color-scheme: dark;
        }
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: var(--amr-page); color: var(--amr-ink); }
        #content.amr-content {
            background:
                radial-gradient(1200px 420px at 100% -10%, var(--amr-glow-a), transparent 55%),
                radial-gradient(900px 380px at -10% 0%, var(--amr-glow-b), transparent 50%),
                var(--amr-page);
            min-height: 100vh;
        }
        .amr-hero {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 18px;
        }
        .amr-kicker {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: .75rem;
            font-weight: 700;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: var(--amr-teal);
            background: rgba(20, 184, 166, .12);
            border: 1px solid rgba(15, 118, 110, .15);
            border-radius: 999px;
            padding: 4px 10px;
            margin-bottom: 8px;
        }
        .amr-title { font-size: 1.55rem; font-weight: 800; color: var(--amr-ink); letter-spacing: -.02em; }
        .amr-sub { color: var(--amr-muted); font-size: .92rem; margin: 0; }
        .amr-live {
            display: flex;
            align-items: center;
            gap: 8px;
            background: var(--amr-live-bg);
            border: 1px solid var(--amr-line);
            border-radius: 999px;
            padding: 8px 14px;
            font-size: .82rem;
            color: var(--amr-muted);
            box-shadow: 0 8px 24px rgba(18, 38, 28, .05);
        }
        .amr-live .dot {
            width: 8px; height: 8px; border-radius: 50%;
            background: var(--amr-ok);
            box-shadow: 0 0 0 4px rgba(5, 150, 105, .16);
        }
        .amr-live.is-error .dot { background: var(--amr-rose); box-shadow: 0 0 0 4px rgba(225, 29, 72, .16); }
        .amr-live.is-loading .dot { background: var(--amr-amber); animation: amrPulse 1s ease infinite; }
        @keyframes amrPulse { 50% { opacity: .35; transform: scale(.85); } }

        .amr-filterbar {
            position: sticky;
            top: 12px;
            z-index: 20;
            background: var(--amr-filter-bg);
            backdrop-filter: blur(16px);
            border: 1px solid var(--amr-line);
            border-radius: 18px;
            padding: 14px;
            margin-bottom: 18px;
            box-shadow: 0 18px 40px rgba(18, 38, 28, .06);
        }
        .amr-var-label { font-size: .72rem; color: var(--amr-muted); font-weight: 700; margin-bottom: 4px; }
        .amr-var-btn, .amr-filterbar .form-select, .amr-filterbar .form-control {
            background: var(--amr-input-bg);
            border: 1px solid transparent;
            color: var(--amr-ink);
            font-size: .84rem;
            border-radius: 12px;
            min-height: 38px;
        }
        .amr-var-btn { min-width: 148px; text-align: left; }
        .amr-var-btn:hover, .amr-var-btn:focus, .amr-filterbar .form-control:focus, .amr-filterbar .form-select:focus {
            background: var(--amr-card);
            border-color: #99d5c4;
            box-shadow: 0 0 0 4px rgba(20, 184, 166, .12);
            color: var(--amr-ink);
        }
        .amr-drop {
            background: var(--amr-drop-bg);
            border: 1px solid var(--amr-line);
            border-radius: 14px;
            max-height: 300px;
            overflow: auto;
            min-width: 250px;
            font-size: .84rem;
            box-shadow: 0 16px 40px rgba(18, 38, 28, .12);
            color: var(--amr-ink);
        }
        .amr-drop .form-check-label { color: var(--amr-ink); }
        .amr-chip {
            border: 1px solid var(--amr-line);
            background: var(--amr-chip-bg);
            color: var(--amr-muted);
            border-radius: 999px;
            font-size: .78rem;
            font-weight: 600;
            padding: 7px 12px;
        }
        .amr-chip:hover { border-color: #99d5c4; color: var(--amr-teal); }
        .amr-chip.active { background: var(--amr-ink); color: var(--amr-page); border-color: var(--amr-ink); }
        .btn-amr {
            background: linear-gradient(180deg, #1a9a86, #0f766e);
            border: 0;
            color: #fff;
            font-weight: 700;
            border-radius: 12px;
            padding: 8px 16px;
            box-shadow: 0 8px 18px rgba(15, 118, 110, .25);
        }
        .btn-amr:hover { color: #fff; filter: brightness(1.06); }
        .btn-amr:disabled { opacity: .65; }

        .amr-kpi {
            background: var(--amr-card);
            border: 1px solid var(--amr-line);
            border-radius: 20px;
            padding: 18px 18px 16px;
            height: 100%;
            box-shadow: 0 10px 28px rgba(18, 38, 28, .04);
            overflow: hidden;
            position: relative;
        }
        .amr-kpi::after {
            content: "";
            position: absolute;
            right: -20px; top: -24px;
            width: 92px; height: 92px;
            border-radius: 50%;
            background: var(--kpi-glow, rgba(15, 118, 110, .08));
        }
        .amr-kpi .label { font-size: .78rem; font-weight: 700; color: var(--amr-muted); }
        .amr-kpi .value { font-size: 2rem; font-weight: 800; line-height: 1.15; letter-spacing: -.03em; }
        .amr-kpi .hint { font-size: .78rem; color: var(--amr-muted); }
        .amr-kpi .icon {
            width: 38px; height: 38px; border-radius: 12px;
            display: grid; place-items: center; font-size: .95rem; margin-bottom: 10px;
        }
        .amr-split { height: 7px; background: var(--amr-split-bg); border-radius: 99px; overflow: hidden; display: flex; margin-top: 10px; }
        .amr-split span { display: block; height: 100%; }
        .amr-split .ni { background: var(--amr-rose); }
        .amr-split .ci { background: var(--amr-teal-2); }

        .amr-panel {
            background: var(--amr-card);
            border: 1px solid var(--amr-line);
            border-radius: 20px;
            height: 100%;
            box-shadow: 0 10px 28px rgba(18, 38, 28, .04);
            overflow: hidden;
        }
        .amr-panel-head {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 10px;
            padding: 16px 18px 0;
            flex-wrap: wrap;
        }
        .amr-panel-title { font-size: .95rem; font-weight: 800; color: var(--amr-ink); margin: 0; }
        .amr-panel-desc { font-size: .76rem; color: var(--amr-muted); margin: 2px 0 0; }
        .amr-detail-tools {
            display: flex; flex-wrap: wrap; gap: 6px; align-items: center; justify-content: flex-end;
        }
        .amr-detail-tools .form-control { width: min(240px, 100%); }
        .amr-export-btn {
            border: 1px solid #c5d5cc; background: #fff; color: var(--amr-ink);
            border-radius: 8px; padding: 5px 10px; font-size: .78rem; font-weight: 700;
            cursor: pointer; white-space: nowrap;
        }
        .amr-export-btn:hover { border-color: #99d5c4; color: var(--amr-teal); }
        .amr-export-btn.excel { border-color: #a5d6a7; color: #1b5e20; background: #f1f8f2; }
        .amr-export-btn.excel:hover { background: #e8f5e9; }
        .amr-export-btn.pdf { border-color: #ef9a9a; color: #b71c1c; background: #fff5f5; }
        .amr-export-btn.pdf:hover { background: #ffebee; }
        .amr-gauge-wrap { position: relative; height: 168px; }
        .amr-gauge-value {
            position: absolute; left: 0; right: 0; bottom: 18px;
            text-align: center; font-size: 2.1rem; font-weight: 800; pointer-events: none;
        }
        .amr-chart { position: relative; height: 280px; padding: 8px 10px 14px; }
        .amr-chart-lg { height: 320px; }
        .amr-chart-sm { height: 210px; }
        .amr-scroll { max-height: 300px; overflow: auto; }
        .amr-table { font-size: .82rem; color: var(--amr-ink); margin: 0; }
        .amr-table thead th {
            background: var(--amr-th); color: var(--amr-muted); border-color: var(--amr-line);
            font-weight: 700; white-space: nowrap; font-size: .75rem;
        }
        .amr-table thead th.amr-sort {
            cursor: pointer; user-select: none;
        }
        .amr-table thead th.amr-sort:hover { color: var(--amr-ink); background: var(--amr-row-hover); }
        .amr-table thead th .sort-ico { opacity: .35; font-size: .65rem; margin-left: 4px; }
        .amr-table thead th.is-sorted .sort-ico { opacity: 1; color: var(--amr-teal); }
        .amr-table td { border-color: var(--amr-td); vertical-align: middle; }
        .amr-table tbody tr:hover { background: var(--amr-row-hover); }
        .amr-ward-chip {
            display: flex; justify-content: space-between; align-items: center; gap: 8px;
            background: var(--amr-ward-bg); border: 1px solid var(--amr-ward-border); color: var(--amr-ward-color);
            border-radius: 12px; padding: 8px 10px; font-size: .8rem; font-weight: 700;
        }
        .amr-ward-list { display: grid; gap: 8px; padding: 14px 16px 16px; }
        .amr-heat { border-collapse: separate; border-spacing: 3px; font-size: .68rem; }
        .amr-heat th { color: var(--amr-muted); font-weight: 600; white-space: nowrap; }
        .amr-heat .row-lab {
            color: var(--amr-ink); text-align: right; padding-right: 8px;
            max-width: 210px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 600;
        }
        .amr-heat .cell {
            width: 20px; height: 20px; border-radius: 6px; background: var(--amr-heat-empty);
            text-align: center; font-size: .65rem; line-height: 20px; font-weight: 700;
        }
        .badge-ni, .badge-ci, .badge-res {
            border-radius: 999px; font-weight: 700; font-size: .72rem; padding: .35em .65em;
        }
        .badge-ni { background: #ffe4ea; color: #be123c; }
        .badge-ci { background: #d7f6ef; color: #0f766e; }
        .badge-res { background: #fff4e0; color: #b45309; }
        .badge-sens { background: #e8f0ec; color: #4b6358; }
        .amr-empty { color: var(--amr-muted); text-align: center; padding: 2.4rem .8rem; font-size: .9rem; }
        .amr-legend { display: flex; flex-wrap: wrap; gap: 8px 12px; padding: 0 16px 14px; font-size: .75rem; color: var(--amr-muted); }
        .amr-legend i { display: inline-block; width: 9px; height: 9px; border-radius: 50%; margin-right: 5px; }
        html[data-amr-theme="dark"] .badge-ni { background: #3f1d27; color: #fb7185; }
        html[data-amr-theme="dark"] .badge-ci { background: #134e4a; color: #5eead4; }
        html[data-amr-theme="dark"] .badge-res { background: #3f2e14; color: #fbbf24; }
        html[data-amr-theme="dark"] .amr-kpi .icon { filter: saturate(1.1); }
        .amr-theme-toggle {
            display: inline-flex; background: var(--amr-soft); border: 1px solid var(--amr-line);
            border-radius: 999px; padding: 3px; gap: 2px;
        }
        .amr-theme-toggle button {
            border: 0; background: transparent; color: var(--amr-muted);
            border-radius: 999px; font-size: .78rem; font-weight: 700;
            padding: 6px 12px;
        }
        .amr-theme-toggle button.active {
            background: var(--amr-card); color: var(--amr-ink);
            box-shadow: 0 4px 12px rgba(0,0,0,.12);
        }
        #detailSearch {
            background: var(--amr-input-bg); border: 1px solid transparent; border-radius: 12px; color: var(--amr-ink);
            min-width: min(100%, 280px);
        }
        #detailSearch:focus { background: var(--amr-card); border-color: #99d5c4; box-shadow: 0 0 0 4px rgba(20, 184, 166, .12); color: var(--amr-ink); }
        .amr-rank { font-size: .8rem; }
        .amr-rank .bar { height: 5px; background: var(--amr-split-bg); border-radius: 99px; overflow: hidden; margin-top: 4px; }
        .amr-rank .bar > span { display: block; height: 100%; border-radius: 99px; }
        .flatpickr-input { background: var(--amr-input-bg) !important; color: var(--amr-ink) !important; border-color: transparent !important; }
        .amr-drop .form-control { background: var(--amr-input-bg); color: var(--amr-ink); border-color: var(--amr-line); }
        .amr-skel { background: linear-gradient(90deg, #eef4f1 25%, #f7fbf9 37%, #eef4f1 63%); background-size: 400% 100%; animation: amrShimmer 1.1s ease infinite; border-radius: 12px; }
        @keyframes amrShimmer { 0% { background-position: 100% 0; } 100% { background-position: 0 0; } }
        .is-loading .amr-panel, .is-loading .amr-kpi { opacity: .72; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content amr-content">
        <div class="container-fluid py-4">
            <div class="amr-hero">
                <div>
                    <div class="amr-kicker"><i class="fas fa-virus"></i> Infection Control · AMR</div>
                    <h1 class="amr-title mb-1">เฝ้าระวังเชื้อดื้อยา</h1>
                    <p class="amr-sub" id="amrSub">ภาพรวมผู้ป่วย IPD ที่พบเชื้อดื้อยา แยก NI/CI ตามหอผู้ป่วย ชนิดเชื้อ และ specimen</p>
                </div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <div class="amr-theme-toggle" role="group" aria-label="โหมดสี">
                        <button type="button" id="themeLight" onclick="setAmrTheme('light')"><i class="fas fa-sun me-1"></i>ขาว</button>
                        <button type="button" id="themeDark" onclick="setAmrTheme('dark')"><i class="fas fa-moon me-1"></i>มืด</button>
                    </div>
                    <?php if (!function_exists('tham_menu_can') || tham_menu_can('amr.settings')): ?>
                    <a href="amr_settings.php" class="btn btn-sm" style="background:var(--amr-chip-bg);color:var(--amr-ink);border:1px solid var(--amr-line);border-radius:999px;font-weight:700;">
                        <i class="fas fa-cog me-1"></i>ตั้งค่า
                    </a>
                    <?php endif; ?>
                    <div class="amr-live is-loading" id="amrStatusWrap">
                        <span class="dot"></span>
                        <span id="amrStatus">กำลังเตรียมตัวกรอง...</span>
                    </div>
                </div>
            </div>

            <div class="amr-filterbar">
                <div class="row g-2 align-items-end">
                    <div class="col-auto">
                        <div class="amr-var-label">ชนิดเชื้อ</div>
                        <div class="dropdown">
                            <button class="btn amr-var-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" id="btnMicro">ทั้งหมด</button>
                            <div class="dropdown-menu amr-drop p-2" id="dropMicro"></div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="amr-var-label">หอผู้ป่วย</div>
                        <div class="dropdown">
                            <button class="btn amr-var-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" id="btnWard">ทั้งหมด</button>
                            <div class="dropdown-menu amr-drop p-2" id="dropWard"></div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="amr-var-label">ชนิดติดเชื้อ</div>
                        <div class="dropdown">
                            <button class="btn amr-var-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" id="btnType">ทั้งหมด</button>
                            <div class="dropdown-menu amr-drop p-2" id="dropType"></div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="amr-var-label">Specimen</div>
                        <div class="dropdown">
                            <button class="btn amr-var-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" id="btnSpec">ทั้งหมด</button>
                            <div class="dropdown-menu amr-drop p-2" id="dropSpec"></div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="amr-var-label">ผลดื้อยา</div>
                        <div class="dropdown">
                            <button class="btn amr-var-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" id="btnResult">ทั้งหมด</button>
                            <div class="dropdown-menu amr-drop p-2" id="dropResult"></div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="amr-var-label">ผลเพาะเชื้อ</div>
                        <div class="d-flex gap-1 flex-wrap">
                            <button type="button" class="amr-chip active" data-scope="resistant" onclick="setCultureScope('resistant', this)">เชื้อดื้อยา</button>
                            <button type="button" class="amr-chip" data-scope="all" onclick="setCultureScope('all', this)" title="พบเชื้อทั้งหมด ทั้งดื้อยาและไม่ดื้อยา (ไม่รวม No growth)">ทั้งหมด</button>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="amr-var-label">อ้างอิงหอ</div>
                        <select id="wardMode" class="form-select form-select-sm" style="min-width:148px;">
                            <option value="snapshot">วันที่สั่ง Lab</option>
                            <option value="now">Ward ปัจจุบัน</option>
                        </select>
                    </div>
                    <div class="col-auto">
                        <div class="amr-var-label">ตั้งแต่</div>
                        <input type="text" id="filterStart" class="form-control form-control-sm" style="width:128px;" value="<?php echo htmlspecialchars($default_start); ?>">
                    </div>
                    <div class="col-auto">
                        <div class="amr-var-label">ถึง</div>
                        <input type="text" id="filterEnd" class="form-control form-control-sm" style="width:128px;" value="<?php echo htmlspecialchars($default_end); ?>">
                    </div>
                    <div class="col-auto d-flex gap-1 flex-wrap">
                        <button type="button" class="amr-chip" data-range="7" onclick="setQuickRange(7, this)">7 วัน</button>
                        <button type="button" class="amr-chip active" data-range="30" onclick="setQuickRange(30, this)">30 วัน</button>
                        <button type="button" class="amr-chip" data-range="90" onclick="setQuickRange(90, this)">90 วัน</button>
                    </div>
                    <div class="col-auto ms-lg-auto">
                        <button type="button" class="btn btn-amr" id="btnLoad" onclick="loadAmrDashboard()">
                            <i class="fas fa-sync-alt me-1"></i> โหลดข้อมูล
                        </button>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-md-6 col-xl-3">
                    <div class="amr-kpi" style="--kpi-glow: rgba(15,118,110,.12);">
                        <div class="icon" style="background:#d7f6ef;color:#0f766e;"><i class="fas fa-user-injured"></i></div>
                        <div class="label" id="kpiMainLabel">จำนวนที่พบเชื้อดื้อยา</div>
                        <div class="value" id="gaugeValue">–</div>
                        <div class="hint">lab ไม่ซ้ำ · ผู้ป่วย <strong id="statPatients">0</strong> คน</div>
                        <div class="hint mt-1" id="grafanaCompareHint">เทียบ Grafana: –</div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="amr-kpi" style="--kpi-glow: rgba(225,29,72,.10);">
                        <div class="icon" style="background:#ffe4ea;color:#e11d48;"><i class="fas fa-hospital"></i></div>
                        <div class="label">Hospital-acquired (NI)</div>
                        <div class="value" style="color:#e11d48;" id="statNi">0</div>
                        <div class="hint">สั่ง lab หลัง admit เกิน 2 วัน</div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="amr-kpi" style="--kpi-glow: rgba(5,150,105,.10);">
                        <div class="icon" style="background:#e7f8ee;color:#059669;"><i class="fas fa-notes-medical"></i></div>
                        <div class="label">Community-acquired (CI)</div>
                        <div class="value" style="color:#0f766e;" id="statCi">0</div>
                        <div class="hint">พบภายใน 2 วันแรกหลัง admit</div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="amr-kpi">
                        <div class="icon" style="background:#fff4e0;color:#d97706;"><i class="fas fa-vial"></i></div>
                        <div class="label">รายการ Lab</div>
                        <div class="value" id="statLab">0</div>
                        <div class="amr-split" id="niCiSplit"><span class="ni" style="width:0"></span><span class="ci" style="width:0"></span></div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-xl-3">
                    <div class="amr-panel">
                        <div class="amr-panel-head">
                            <div>
                                <h2 class="amr-panel-title">สัดส่วนผู้ป่วย</h2>
                                <p class="amr-panel-desc">เทียบกับกรอบเตือนของช่วงนี้</p>
                            </div>
                        </div>
                        <div class="amr-gauge-wrap">
                            <canvas id="chartGauge"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-xl-5">
                    <div class="amr-panel">
                        <div class="amr-panel-head">
                            <div>
                                <h2 class="amr-panel-title">อัตรา NI / 1,000 วันนอน</h2>
                                <p class="amr-panel-desc">แยกตามหอผู้ป่วย — สูงไปต่ำ</p>
                            </div>
                        </div>
                        <div class="amr-chart" id="niRateChartWrap"><canvas id="chartNiRate"></canvas></div>
                    </div>
                </div>
                <div class="col-xl-4">
                    <div class="amr-panel">
                        <div class="amr-panel-head">
                            <div>
                                <h2 class="amr-panel-title">หอที่ยังไม่พบ NI</h2>
                                <p class="amr-panel-desc">มีวันนอนในช่วงนี้ แต่ยังไม่มี NI</p>
                            </div>
                            <span class="badge-ci" id="zeroNiCount">0 หอ</span>
                        </div>
                        <div class="amr-scroll amr-ward-list" id="zeroNiBody">
                            <div class="amr-empty">รอโหลดข้อมูล</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12">
                    <div class="amr-panel">
                        <div class="amr-panel-head">
                            <div>
                                <h2 class="amr-panel-title">แนวโน้มรายวัน</h2>
                                <p class="amr-panel-desc" id="trendDesc">จำนวน lab เชื้อดื้อยารวมทุกชนิด</p>
                            </div>
                        </div>
                        <div class="amr-chart amr-chart-lg"><canvas id="chartByDate"></canvas></div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-12">
                    <div class="amr-panel">
                        <div class="amr-panel-head">
                            <div>
                                <h2 class="amr-panel-title">พบเชื้อแยกตามวัน</h2>
                                <p class="amr-panel-desc">แต่ละจุดคือชนิดเชื้อในวันนั้น</p>
                            </div>
                        </div>
                        <div class="amr-chart amr-chart-lg" id="scatterWrap"><canvas id="chartScatter"></canvas></div>
                        <div class="amr-legend" id="scatterLegend"></div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-lg-4">
                    <div class="amr-panel">
                        <div class="amr-panel-head">
                            <div>
                                <h2 class="amr-panel-title">แยกตามหอผู้ป่วย</h2>
                                <p class="amr-panel-desc">จำนวนรายการ lab สูงสุด 15 หอ</p>
                            </div>
                        </div>
                        <div class="amr-chart"><canvas id="chartByWard"></canvas></div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="amr-panel">
                        <div class="amr-panel-head">
                            <div>
                                <h2 class="amr-panel-title">แผนที่ความหนาแน่น</h2>
                                <p class="amr-panel-desc">หอผู้ป่วย × ชนิดเชื้อ · วันล่าสุดอยู่ซ้าย</p>
                            </div>
                        </div>
                        <div class="amr-scroll p-3" id="heatWrap">
                            <div class="amr-empty">รอโหลดข้อมูล</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="amr-panel">
                        <div class="amr-panel-head">
                            <div>
                                <h2 class="amr-panel-title">ชนิดเชื้อ</h2>
                                <p class="amr-panel-desc">สัดส่วนรายการ lab</p>
                            </div>
                        </div>
                        <div class="amr-chart amr-chart-sm"><canvas id="chartPie"></canvas></div>
                        <div class="amr-scroll px-3 pb-3" style="max-height:190px;" id="microRankBody"></div>
                    </div>
                </div>
            </div>

            <div class="amr-panel mb-2">
                <div class="amr-panel-head pb-2">
                    <div>
                        <h2 class="amr-panel-title">รายชื่อผู้ป่วย <span class="fw-normal" id="detailCount" style="font-size:.82rem;color:var(--amr-muted);"></span></h2>
                        <p class="amr-panel-desc">ค้นหาจาก HN, ชื่อ, เชื้อ, หอผู้ป่วย — ส่งออกตามรายการที่กรอง/ค้นหาอยู่</p>
                    </div>
                    <div class="amr-detail-tools">
                        <input type="search" id="detailSearch" class="form-control form-control-sm" placeholder="ค้นหา HN / ชื่อ / เชื้อ / หอ...">
                        <button type="button" class="amr-export-btn excel" id="btnExportExcel" title="ส่งออกรายชื่อเป็น Excel">
                            <i class="fas fa-file-excel me-1"></i>Excel
                        </button>
                        <button type="button" class="amr-export-btn pdf" id="btnExportPdf" title="พิมพ์ / บันทึกเป็น PDF">
                            <i class="fas fa-file-pdf me-1"></i>PDF
                        </button>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table amr-table">
                        <thead>
                            <tr>
                                <th class="amr-sort is-sorted" data-sort="order_date">วันที่สั่ง<span class="sort-ico">▼</span></th>
                                <th class="amr-sort" data-sort="reportdatetime">วันที่รายงาน+เวลา<span class="sort-ico">▲</span></th>
                                <th class="amr-sort" data-sort="hn">HN<span class="sort-ico">▲</span></th>
                                <th class="amr-sort" data-sort="an">AN<span class="sort-ico">▲</span></th>
                                <th class="amr-sort" data-sort="ptname">ชื่อ-สกุล<span class="sort-ico">▲</span></th>
                                <th class="amr-sort" data-sort="ward">หอผู้ป่วย<span class="sort-ico">▲</span></th>
                                <th class="amr-sort" data-sort="bedno">เตียง<span class="sort-ico">▲</span></th>
                                <th class="amr-sort" data-sort="Typeinfect">ชนิด<span class="sort-ico">▲</span></th>
                                <th class="amr-sort" data-sort="microtype">เชื้อ<span class="sort-ico">▲</span></th>
                                <th class="amr-sort" data-sort="result">ผลดื้อยา<span class="sort-ico">▲</span></th>
                                <th class="amr-sort" data-sort="Specimen">Specimen<span class="sort-ico">▲</span></th>
                                <th class="amr-sort" data-sort="DCstatus">สถานะจำหน่าย<span class="sort-ico">▲</span></th>
                                <th>Sen ATB</th>
                            </tr>
                        </thead>
                        <tbody id="detailBody">
                            <tr><td colspan="13" class="amr-empty">รอโหลดข้อมูล</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-between align-items-center px-3 py-2" id="detailPager" style="display:none !important;"></div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/flatpickr.min.js"></script>
<script src="js/chart.min.js"></script>
<script src="https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"></script>
<script>
const AMR_API = 'fetch_amr_api.php';
Chart.defaults.font.family = "'Sarabun', Tahoma, sans-serif";
Chart.defaults.font.size = 11;
Chart.defaults.plugins.legend.labels.boxWidth = 10;
Chart.defaults.plugins.legend.labels.boxHeight = 10;

let fpStart = null, fpEnd = null;
let charts = {};
let lastRows = [];
let lastDashboardData = null;
let detailSortKey = 'order_date';
let detailSortDir = 'desc';
let cultureScope = 'resistant';
let amrDataSource = '';
let detailPage = 1;
const DETAIL_PAGE_SIZE = 400;

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function selectedOf(name) {
    return Array.from(document.querySelectorAll('input[name="' + name + '"]:checked')).map(el => el.value);
}

function setBtnLabel(btnId, values) {
    const btn = document.getElementById(btnId);
    if (!values.length) btn.textContent = 'ทั้งหมด';
    else if (values.length === 1) btn.textContent = values[0];
    else btn.textContent = values.length + ' รายการ';
}

function renderCheckList(boxId, name, items, selected) {
    const box = document.getElementById(boxId);
    const sel = new Set(selected || []);
    let html = '<div class="mb-1"><input type="search" class="form-control form-control-sm amr-filter-search" placeholder="ค้นหา..."></div>';
    html += '<div class="form-check"><input class="form-check-input amr-all" type="checkbox" id="' + name + 'All" ' + (sel.size === 0 ? 'checked' : '') + '>';
    html += '<label class="form-check-label" for="' + name + 'All">ทั้งหมด</label></div><hr class="my-1">';
    items.forEach((it, i) => {
        const value = typeof it === 'string' ? it : it.ward;
        const label = typeof it === 'string' ? it : (it.name + ' (' + it.ward + ')');
        const id = name + '_' + i;
        html += '<div class="form-check amr-opt" data-label="' + esc(label.toLowerCase()) + '">';
        html += '<input class="form-check-input amr-item" type="checkbox" name="' + name + '" value="' + esc(value) + '" id="' + id + '"' + (sel.has(value) ? ' checked' : '') + '>';
        html += '<label class="form-check-label" for="' + id + '">' + esc(label) + '</label></div>';
    });
    box.innerHTML = html;
    const allCb = box.querySelector('.amr-all');
    const itemCbs = () => box.querySelectorAll('.amr-item');
    allCb.addEventListener('change', () => {
        if (allCb.checked) itemCbs().forEach(cb => { cb.checked = false; });
        syncFilterLabels();
    });
    itemCbs().forEach(cb => {
        cb.addEventListener('change', () => {
            allCb.checked = Array.from(itemCbs()).every(x => !x.checked);
            syncFilterLabels();
        });
    });
    const search = box.querySelector('.amr-filter-search');
    search.addEventListener('input', () => {
        const q = search.value.trim().toLowerCase();
        box.querySelectorAll('.amr-opt').forEach(row => {
            row.style.display = (!q || row.getAttribute('data-label').indexOf(q) !== -1) ? '' : 'none';
        });
    });
}

function syncFilterLabels() {
    setBtnLabel('btnWard', selectedOf('ward'));
    setBtnLabel('btnMicro', selectedOf('micro'));
    setBtnLabel('btnType', selectedOf('typeinfect'));
    setBtnLabel('btnSpec', selectedOf('specimen'));
    setBtnLabel('btnResult', selectedOf('result'));
}

function qs(obj) {
    return Object.keys(obj).filter(k => obj[k] !== '' && obj[k] != null)
        .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(obj[k])).join('&');
}

async function fetchJson(url, options) {
    const r = await fetch(url, Object.assign({ credentials: 'same-origin' }, options || {}));
    const text = await r.text();
    try { return JSON.parse(text); } catch (e) {
        throw new Error(/504|Gateway Time-out/i.test(text) ? 'หมดเวลาเชื่อมต่อ HOSxP (504)' : 'ตอบกลับไม่ใช่ JSON');
    }
}

function fmtDate(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + day;
}

function amrDateChunks(start, end, size) {
    size = Math.max(1, size || 3);
    const chunks = [];
    let from = new Date(start + 'T00:00:00');
    const to = new Date(end + 'T00:00:00');
    if (isNaN(from) || isNaN(to) || from > to) return chunks;
    while (from <= to) {
        const cs = fmtDate(from);
        const ce = new Date(from);
        ce.setDate(ce.getDate() + size - 1);
        if (ce > to) ce.setTime(to.getTime());
        chunks.push({ start: cs, end: fmtDate(ce) });
        from = new Date(ce);
        from.setDate(from.getDate() + 1);
    }
    return chunks;
}

async function mapPool(items, limit, fn) {
    const out = new Array(items.length);
    let i = 0;
    async function worker() {
        while (i < items.length) {
            const idx = i++;
            out[idx] = await fn(items[idx], idx);
        }
    }
    const n = Math.max(1, Math.min(limit, items.length));
    await Promise.all(Array.from({ length: n }, worker));
    return out;
}

let amrLoadSeq = 0;

function isDarkTheme() {
    return document.documentElement.getAttribute('data-amr-theme') === 'dark';
}

function chartTheme() {
    if (isDarkTheme()) {
        return { tick: '#9aa7ae', axis: '#e8eef0', grid: '#2c3538', track: '#222a2e', pieBorder: '#171c1f' };
    }
    return { tick: '#5f7468', axis: '#12261c', grid: '#eef4f1', track: '#e8f1ec', pieBorder: '#ffffff' };
}

function applyChartDefaults() {
    const t = chartTheme();
    Chart.defaults.color = t.tick;
    Chart.defaults.borderColor = t.grid;
}

function syncThemeButtons() {
    const dark = isDarkTheme();
    document.getElementById('themeLight').classList.toggle('active', !dark);
    document.getElementById('themeDark').classList.toggle('active', dark);
}

function setAmrTheme(theme) {
    const next = theme === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-amr-theme', next);
    localStorage.setItem('amr-dashboard-theme', next);
    syncThemeButtons();
    applyChartDefaults();
    if (lastDashboardData) {
        paintDashboard(lastDashboardData, false);
    }
}

function destroyChart(key) {
    if (charts[key]) {
        charts[key].destroy();
        charts[key] = null;
    }
}

function chartTooltip() {
    return {
        backgroundColor: '#12261c',
        borderWidth: 0,
        titleColor: '#fff',
        bodyColor: '#d7e4dc',
        padding: 10,
        cornerRadius: 10
    };
}

function renderGauge(value, max) {
    destroyChart('gauge');
    const v = Number(value) || 0;
    const m = Math.max(Number(max) || 50, v, 1);
    const ratio = v / m;
    const color = ratio < 0.4 ? '#14b8a6' : (ratio < 0.75 ? '#d97706' : '#e11d48');
    const track = chartTheme().track;
    charts.gauge = new Chart(document.getElementById('chartGauge'), {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [v, Math.max(0, m - v)],
                backgroundColor: [color, track],
                borderWidth: 0,
                circumference: 210,
                rotation: 255,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '78%',
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        }
    });
}

function renderNiRate(rows) {
    destroyChart('ni');
    const wrap = document.getElementById('niRateChartWrap');
    if (!rows.length) {
        wrap.innerHTML = '<div class="amr-empty">ไม่พบ NI ในช่วงนี้</div>';
        return;
    }
    wrap.innerHTML = '<canvas id="chartNiRate"></canvas>';
    const labels = rows.map(r => r.ward);
    const data = rows.map(r => r.rate == null ? 0 : r.rate);
    const th = chartTheme();
    charts.ni = new Chart(document.getElementById('chartNiRate'), {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: 'NI/1000 วันนอน',
                data,
                backgroundColor: (ctx) => {
                    const t = ctx.parsed && ctx.parsed.x != null ? ctx.parsed.x : 0;
                    return t >= 10 ? '#e11d48' : (t >= 5 ? '#f43f5e' : '#fb7185');
                },
                borderWidth: 0,
                borderRadius: 8,
                barPercentage: 0.72
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: chartTooltip() },
            scales: {
                x: { grid: { color: th.grid }, ticks: { color: th.tick }, border: { display: false } },
                y: { grid: { display: false }, ticks: { color: th.axis, font: { size: 11, weight: '600' } }, border: { display: false } }
            }
        }
    });
}

function renderZeroNi(rows) {
    const body = document.getElementById('zeroNiBody');
    document.getElementById('zeroNiCount').textContent = (rows.length || 0) + ' หอ';
    if (!rows.length) {
        body.innerHTML = '<div class="amr-empty">ไม่มีหอที่ปลอด NI (หรือไม่มีวันนอน)</div>';
        return;
    }
    body.innerHTML = rows.map(r =>
        '<div class="amr-ward-chip"><span>' + esc(r.ward) + '</span><span>' + (r.bed_days || 0) + ' วันนอน</span></div>'
    ).join('');
}

function renderByDate(series) {
    destroyChart('date');
    const canvas = document.getElementById('chartByDate');
    const ctx = canvas.getContext('2d');
    const th = chartTheme();
    const grad = ctx.createLinearGradient(0, 0, 0, 280);
    grad.addColorStop(0, 'rgba(225, 29, 72, .22)');
    grad.addColorStop(1, 'rgba(225, 29, 72, 0)');
    charts.date = new Chart(canvas, {
        type: 'line',
        data: {
            labels: series.map(s => s.date.slice(5)),
            datasets: [{
                label: 'จำนวน lab',
                data: series.map(s => s.count),
                borderColor: '#e11d48',
                backgroundColor: grad,
                fill: true,
                tension: 0.35,
                borderWidth: 2.5,
                pointRadius: 3,
                pointHoverRadius: 6,
                pointBackgroundColor: isDarkTheme() ? '#171c1f' : '#fff',
                pointBorderColor: '#e11d48',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: chartTooltip() },
            scales: {
                x: { grid: { display: false }, ticks: { color: th.tick, maxRotation: 0 }, border: { display: false } },
                y: { beginAtZero: true, grid: { color: th.grid }, ticks: { color: th.tick, precision: 0 }, border: { display: false } }
            }
        }
    });
}

function renderScatter(scatter, dates) {
    destroyChart('scatter');
    const wrap = document.getElementById('scatterWrap');
    if (!dates.length || !(scatter || []).length) {
        wrap.innerHTML = '<div class="amr-empty">ไม่พบจุดข้อมูลเชื้อตามวันที่</div><canvas id="chartScatter" class="d-none"></canvas>';
        document.getElementById('scatterLegend').innerHTML = '';
        return;
    }
    if (!document.getElementById('chartScatter') || document.getElementById('chartScatter').classList.contains('d-none')) {
        wrap.innerHTML = '<canvas id="chartScatter"></canvas>';
    }
    const dateIndex = {};
    dates.forEach((d, i) => { dateIndex[d] = i; });
    const th = chartTheme();
    const datasets = (scatter || []).map(s => ({
        label: s.label,
        data: (s.points || []).map(p => ({ x: dateIndex[p.x], y: p.y })),
        backgroundColor: s.color,
        borderColor: th.pieBorder,
        borderWidth: 1.5,
        pointRadius: 6,
        pointHoverRadius: 8
    }));
    document.getElementById('scatterLegend').innerHTML = (scatter || []).map(s =>
        '<span><i style="background:' + esc(s.color) + '"></i>' + esc(s.label) + '</span>'
    ).join('');
    charts.scatter = new Chart(document.getElementById('chartScatter'), {
        type: 'scatter',
        data: { datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: Object.assign(chartTooltip(), {
                    callbacks: {
                        label(ctx) {
                            const d = dates[ctx.parsed.x] || '';
                            return ctx.dataset.label + ' · ' + d + ' = ' + ctx.parsed.y;
                        }
                    }
                })
            },
            scales: {
                x: {
                    type: 'linear',
                    min: -0.5,
                    max: Math.max(dates.length - 0.5, 0.5),
                    ticks: {
                        color: th.tick,
                        callback(v) {
                            const i = Math.round(v);
                            return dates[i] ? dates[i].slice(5) : '';
                        }
                    },
                    grid: { color: th.grid },
                    border: { display: false }
                },
                y: { beginAtZero: true, ticks: { color: th.tick, precision: 0 }, grid: { color: th.grid }, border: { display: false } }
            }
        }
    });
}

function renderByWard(rows) {
    destroyChart('ward');
    const th = chartTheme();
    const top = (rows || []).slice(0, 15);
    charts.ward = new Chart(document.getElementById('chartByWard'), {
        type: 'bar',
        data: {
            labels: top.map(r => r.label),
            datasets: [{
                data: top.map(r => r.count),
                backgroundColor: '#0f766e',
                borderWidth: 0,
                borderRadius: 8
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: chartTooltip() },
            scales: {
                x: { beginAtZero: true, grid: { color: th.grid }, ticks: { color: th.tick, precision: 0 }, border: { display: false } },
                y: { grid: { display: false }, ticks: { color: th.axis, font: { size: 11, weight: '600' } }, border: { display: false } }
            }
        }
    });
}

function heatColor(v, max) {
    if (!v) return getComputedStyle(document.documentElement).getPropertyValue('--amr-heat-empty').trim() || '#edf3f0';
    const t = v / Math.max(max, 1);
    if (t < 0.34) return '#99f6e4';
    if (t < 0.67) return '#fbbf24';
    return '#fb7185';
}

function renderHeat(heat) {
    const wrap = document.getElementById('heatWrap');
    const dates = ((heat && heat.dates) || []).slice().reverse();
    const rows = (heat && heat.rows) || [];
    if (!rows.length) {
        wrap.innerHTML = '<div class="amr-empty">ไม่มีข้อมูล heatmap</div>';
        return;
    }
    let max = 1;
    rows.forEach(r => r.cells.forEach(c => { if (c > max) max = c; }));
    let html = '<table class="amr-heat"><thead><tr><th></th>';
    dates.forEach(d => { html += '<th>' + esc(d.slice(5)) + '</th>'; });
    html += '</tr></thead><tbody>';
    rows.forEach(r => {
        html += '<tr><td class="row-lab" title="' + esc(r.label) + '">' + esc(r.label) + '</td>';
        (r.cells || []).slice().reverse().forEach(c => {
            const bg = heatColor(c, max);
            const color = (!c || bg === '#99f6e4' || bg === '#fbbf24') ? '#12261c' : '#fff';
            html += '<td><div class="cell" style="background:' + bg + ';color:' + color + '">' + (c || '') + '</div></td>';
        });
        html += '</tr>';
    });
    html += '</tbody></table>';
    wrap.innerHTML = html;
}

function renderPie(rows) {
    destroyChart('pie');
    const top = (rows || []).slice(0, 8);
    const total = (rows || []).reduce((s, r) => s + r.count, 0) || 1;
    charts.pie = new Chart(document.getElementById('chartPie'), {
        type: 'doughnut',
        data: {
            labels: top.map(r => r.label),
            datasets: [{
                data: top.map(r => r.count),
                backgroundColor: top.map(r => r.color),
                borderWidth: 3,
                borderColor: chartTheme().pieBorder,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '62%',
            plugins: { legend: { display: false }, tooltip: chartTooltip() }
        }
    });
    document.getElementById('microRankBody').innerHTML = (rows || []).map(r => {
        const pct = Math.round((r.count / total) * 100);
        return '<div class="amr-rank mb-2">'
            + '<div class="d-flex justify-content-between"><span>' + esc(r.label) + '</span><strong>' + r.count + '</strong></div>'
            + '<div class="bar"><span style="width:' + pct + '%;background:' + esc(r.color) + '"></span></div>'
            + '</div>';
    }).join('');
}

function renderDetails(rows) {
    lastRows = rows || [];
    detailPage = 1;
    applyDetailFilter();
}

function fmtAmrTime(raw) {
    const s = String(raw == null ? '' : raw).trim();
    if (!s) return '';
    const digits = s.replace(/\D/g, '');
    if (digits.length >= 4) {
        return digits.slice(0, 2) + ':' + digits.slice(2, 4);
    }
    const m = s.match(/(\d{1,2}:\d{2})/);
    return m ? m[1] : '';
}

function fmtAmrDateTime(datePart, timePart, combined) {
    let d = String(datePart || '').slice(0, 10);
    if (d === '0000-00-00') d = '';
    let t = fmtAmrTime(timePart || '');
    const c = String(combined || '').trim();
    if (c) {
        const m = c.match(/(\d{4}-\d{2}-\d{2})(?:[ T]+(\S+))?/);
        if (m && m[1] !== '0000-00-00') {
            if (!d) d = m[1];
            if (!t) t = fmtAmrTime(m[2] || '');
        } else if (!t) {
            t = fmtAmrTime(c);
        }
    }
    if (!d && !t) return '—';
    if (!t) return esc(d);
    return esc(d) + '<div class="small text-muted">' + esc(t) + '</div>';
}

function sortValue(row, key) {
    if (key === 'order_date') return String(row.ordertime || row.order_date || '').slice(0, 19);
    if (key === 'reportdatetime') return String(row.reportdatetime || row.report_date || '').slice(0, 19);
    const v = row[key];
    return (v == null ? '' : String(v));
}

function sortDetailRows(rows) {
    const key = detailSortKey;
    const dir = detailSortDir === 'asc' ? 1 : -1;
    return rows.slice().sort((a, b) => {
        const va = sortValue(a, key);
        const vb = sortValue(b, key);
        if (key === 'order_date' || key === 'reportdatetime') {
            if (va === vb) return dir * String(a.hn || '').localeCompare(String(b.hn || ''));
            return dir * va.localeCompare(vb);
        }
        return dir * va.localeCompare(vb, 'th', { numeric: true, sensitivity: 'base' });
    });
}

function syncSortHeaders() {
    document.querySelectorAll('.amr-table thead th.amr-sort').forEach(th => {
        const on = th.getAttribute('data-sort') === detailSortKey;
        th.classList.toggle('is-sorted', on);
        const ico = th.querySelector('.sort-ico');
        if (ico) ico.textContent = on ? (detailSortDir === 'desc' ? '▼' : '▲') : '▲';
    });
}

function setDetailSort(key) {
    if (detailSortKey === key) {
        detailSortDir = detailSortDir === 'desc' ? 'asc' : 'desc';
    } else {
        detailSortKey = key;
        detailSortDir = (key === 'order_date' || key === 'reportdatetime') ? 'desc' : 'asc';
    }
    syncSortHeaders();
    applyDetailFilter();
}

function getFilteredDetailRows() {
    const q = (document.getElementById('detailSearch').value || '').trim().toLowerCase();
    let rows = lastRows.filter(r => {
        if (!q) return true;
        return [r.hn, r.an, r.ptname, r.ward, r.microtype, r.result, r.Specimen, r.Typeinfect, r.bedno, r.DCstatus]
            .join(' ').toLowerCase().indexOf(q) !== -1;
    });
    return sortDetailRows(rows);
}

function fmtAmrDateTimePlain(datePart, timePart, combined) {
    let d = String(datePart || '').slice(0, 10);
    if (d === '0000-00-00') d = '';
    let t = fmtAmrTime(timePart || '');
    const c = String(combined || '').trim();
    if (c) {
        const m = c.match(/(\d{4}-\d{2}-\d{2})(?:[ T]+(\S+))?/);
        if (m && m[1] !== '0000-00-00') {
            if (!d) d = m[1];
            if (!t) t = fmtAmrTime(m[2] || '');
        } else if (!t) {
            t = fmtAmrTime(c);
        }
    }
    if (!d && !t) return '';
    return t ? (d + ' ' + t) : d;
}

function resultLabelForExport(r) {
    if (r.result) return String(r.result);
    if (cultureScope === 'all') {
        return /no\s*growth/i.test(String(r.microtype || '')) ? 'No growth' : 'ไม่ดื้อยา';
    }
    return '';
}

function exportDetailFilename(ext) {
    const start = (document.getElementById('filterStart').value || '').replace(/[\\/:*?"<>|]/g, '_');
    const end = (document.getElementById('filterEnd').value || '').replace(/[\\/:*?"<>|]/g, '_');
    const scope = cultureScope === 'all' ? 'all' : 'resistant';
    return 'amr_patients_' + scope + '_' + start + '_' + end + '.' + ext;
}

function exportDetailExcel() {
    const rows = getFilteredDetailRows();
    if (!rows.length) {
        alert('ไม่มีข้อมูลสำหรับส่งออก — โหลดข้อมูลหรือปรับตัวกรองก่อน');
        return;
    }
    if (typeof XLSX === 'undefined') {
        alert('ไม่สามารถโหลดไลบรารี Excel ได้');
        return;
    }
    const headers = [
        'ลำดับ', 'วันที่สั่ง', 'วันที่รายงาน', 'HN', 'AN', 'ชื่อ-สกุล',
        'หอผู้ป่วย', 'เตียง', 'ชนิด', 'เชื้อ', 'ผลดื้อยา', 'Specimen', 'สถานะจำหน่าย'
    ];
    const data = rows.map((r, i) => [
        i + 1,
        fmtAmrDateTimePlain(r.order_date, r.order_time, r.ordertime),
        fmtAmrDateTimePlain(r.report_date, r.report_time, r.reportdatetime),
        r.hn || '',
        r.an || '',
        r.ptname || '',
        r.ward || '',
        r.bedno || '',
        r.Typeinfect || '',
        r.microtype || '',
        resultLabelForExport(r),
        r.Specimen || '',
        r.DCstatus || ''
    ]);
    const ws = XLSX.utils.aoa_to_sheet([headers].concat(data));
    ws['!cols'] = [
        { wch: 6 }, { wch: 18 }, { wch: 18 }, { wch: 12 }, { wch: 12 }, { wch: 28 },
        { wch: 22 }, { wch: 10 }, { wch: 8 }, { wch: 18 }, { wch: 14 }, { wch: 14 }, { wch: 14 }
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'รายชื่อผู้ป่วย');
    XLSX.writeFile(wb, exportDetailFilename('xlsx'));
}

function exportDetailPdf() {
    const rows = getFilteredDetailRows();
    if (!rows.length) {
        alert('ไม่มีข้อมูลสำหรับส่งออก — โหลดข้อมูลหรือปรับตัวกรองก่อน');
        return;
    }
    const start = document.getElementById('filterStart').value || '-';
    const end = document.getElementById('filterEnd').value || '-';
    const scopeTxt = cultureScope === 'all' ? 'ผลเพาะเชื้อทั้งหมด' : 'เฉพาะเชื้อดื้อยา';
    const now = new Date();
    const printed = now.getFullYear() + '-'
        + String(now.getMonth() + 1).padStart(2, '0') + '-'
        + String(now.getDate()).padStart(2, '0') + ' '
        + String(now.getHours()).padStart(2, '0') + ':'
        + String(now.getMinutes()).padStart(2, '0');
    const bodyHtml = rows.map((r, i) => '<tr>'
        + '<td>' + (i + 1) + '</td>'
        + '<td>' + esc(fmtAmrDateTimePlain(r.order_date, r.order_time, r.ordertime)) + '</td>'
        + '<td>' + esc(fmtAmrDateTimePlain(r.report_date, r.report_time, r.reportdatetime)) + '</td>'
        + '<td>' + esc(r.hn) + '</td>'
        + '<td>' + esc(r.an) + '</td>'
        + '<td>' + esc(r.ptname) + '</td>'
        + '<td>' + esc(r.ward) + '</td>'
        + '<td>' + esc(r.bedno) + '</td>'
        + '<td>' + esc(r.Typeinfect) + '</td>'
        + '<td>' + esc(r.microtype) + '</td>'
        + '<td>' + esc(resultLabelForExport(r)) + '</td>'
        + '<td>' + esc(r.Specimen) + '</td>'
        + '<td>' + esc(r.DCstatus) + '</td>'
        + '</tr>').join('');
    const html = '<!DOCTYPE html><html lang="th"><head><meta charset="UTF-8">'
        + '<title>' + esc(exportDetailFilename('pdf')) + '</title>'
        + '<style>'
        + 'body{font-family:"Sarabun",Tahoma,sans-serif;font-size:11px;color:#12261c;margin:16px;}'
        + '.toolbar{margin-bottom:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;}'
        + '.toolbar button{padding:6px 12px;font-weight:700;border:0;border-radius:6px;cursor:pointer;}'
        + '.toolbar .go{background:#0d9488;color:#fff;}'
        + '.toolbar .close{background:#64748b;color:#fff;}'
        + '.toolbar .hint{color:#64748b;font-size:12px;}'
        + 'h1{font-size:16px;margin:0 0 4px;}'
        + '.meta{color:#5a7380;margin-bottom:10px;}'
        + 'table{width:100%;border-collapse:collapse;}'
        + 'th,td{border:1px solid #cbd5d1;padding:4px 5px;vertical-align:top;}'
        + 'th{background:#e8f2ed;font-weight:800;text-align:left;white-space:nowrap;}'
        + '@page{size:A4 landscape;margin:10mm;}'
        + '@media print{.toolbar{display:none!important;} body{margin:0;}}'
        + '</style></head><body>'
        + '<div class="toolbar">'
        + '<button type="button" class="go" onclick="window.print()">พิมพ์ / บันทึก PDF</button>'
        + '<button type="button" class="close" onclick="window.close()">ปิด</button>'
        + '<span class="hint">เลือกปลายทางเป็น PDF · กระดาษ A4 แนวนอน</span>'
        + '</div>'
        + '<h1>AMR Dashboard — รายชื่อผู้ป่วย</h1>'
        + '<div class="meta">ช่วง ' + esc(start) + ' ถึง ' + esc(end)
        + ' · ' + esc(scopeTxt) + ' · ' + rows.length + ' รายการ · พิมพ์เมื่อ ' + esc(printed) + '</div>'
        + '<table><thead><tr>'
        + '<th>#</th><th>วันที่สั่ง</th><th>วันที่รายงาน</th><th>HN</th><th>AN</th><th>ชื่อ-สกุล</th>'
        + '<th>หอผู้ป่วย</th><th>เตียง</th><th>ชนิด</th><th>เชื้อ</th><th>ผลดื้อยา</th><th>Specimen</th><th>สถานะจำหน่าย</th>'
        + '</tr></thead><tbody>' + bodyHtml + '</tbody></table>'
        + '<script>window.onload=function(){setTimeout(function(){window.print();},250);};<\/script>'
        + '</body></html>';
    const w = window.open('', '_blank');
    if (!w) {
        alert('ไม่สามารถเปิดหน้าต่างพิมพ์ได้ — อนุญาต pop-up แล้วลองอีกครั้ง');
        return;
    }
    w.document.open();
    w.document.write(html);
    w.document.close();
}

function applyDetailFilter() {
    const rows = getFilteredDetailRows();
    const body = document.getElementById('detailBody');
    const countEl = document.getElementById('detailCount');
    const pager = document.getElementById('detailPager');
    if (countEl) countEl.textContent = rows.length ? ('· ' + rows.length + ' รายการ') : '';
    if (!rows.length) {
        body.innerHTML = '<tr><td colspan="13" class="amr-empty">ไม่พบรายการ</td></tr>';
        if (pager) pager.style.setProperty('display', 'none', 'important');
        return;
    }
    const pages = Math.max(1, Math.ceil(rows.length / DETAIL_PAGE_SIZE));
    if (detailPage > pages) detailPage = pages;
    if (detailPage < 1) detailPage = 1;
    const start = (detailPage - 1) * DETAIL_PAGE_SIZE;
    const view = rows.slice(start, start + DETAIL_PAGE_SIZE);
    if (pager) {
        if (pages > 1) {
            pager.style.removeProperty('display');
            pager.innerHTML = '<span class="small text-muted">แสดง ' + (start + 1) + '–' + (start + view.length) + ' จาก ' + rows.length + '</span>'
                + '<div class="d-flex gap-1">'
                + '<button type="button" class="amr-chip" onclick="setDetailPage(' + (detailPage - 1) + ')"' + (detailPage <= 1 ? ' disabled' : '') + '>ก่อนหน้า</button>'
                + '<button type="button" class="amr-chip" onclick="setDetailPage(' + (detailPage + 1) + ')"' + (detailPage >= pages ? ' disabled' : '') + '>ถัดไป</button>'
                + '</div>';
        } else {
            pager.style.setProperty('display', 'none', 'important');
        }
    }
    body.innerHTML = view.map(r => {
        const badge = r.Typeinfect === 'NI'
            ? '<span class="badge badge-ni">NI</span>'
            : '<span class="badge badge-ci">CI</span>';
        const micro = String(r.microtype || '');
        const isNg = /no\s*growth/i.test(micro);
        let res = '';
        if (r.result) {
            res = '<span class="badge badge-res">' + esc(r.result) + '</span>';
        } else if (cultureScope === 'all') {
            res = isNg
                ? '<span class="badge badge-sens">No growth</span>'
                : '<span class="badge badge-sens">ไม่ดื้อยา</span>';
        }
        const order = encodeURIComponent(r.lab_order_number || '');
        const hn = encodeURIComponent(r.hn || '');
        const sensHref = 'amr_sensitivity.php?order=' + order + (hn ? ('&hn=' + hn) : '');
        return '<tr>'
            + '<td class="text-nowrap">' + fmtAmrDateTime(r.order_date, r.order_time, r.ordertime) + '</td>'
            + '<td class="text-nowrap">' + fmtAmrDateTime(r.report_date, r.report_time, r.reportdatetime) + '</td>'
            + '<td class="fw-bold"><a href="' + sensHref + '">' + esc(r.hn) + '</a></td>'
            + '<td>' + esc(r.an) + '</td>'
            + '<td>' + esc(r.ptname) + '</td>'
            + '<td>' + esc(r.ward) + '</td>'
            + '<td>' + esc(r.bedno) + '</td>'
            + '<td>' + badge + '</td>'
            + '<td class="fw-semibold">' + esc(r.microtype) + '</td>'
            + '<td>' + res + '</td>'
            + '<td>' + esc(r.Specimen) + '</td>'
            + '<td>' + esc(r.DCstatus) + '</td>'
            + '<td><a class="btn btn-sm btn-outline-success py-0 px-2 text-nowrap" href="' + sensHref + '">Sen ATB</a></td>'
            + '</tr>';
    }).join('');
}

function setDetailPage(p) {
    detailPage = p;
    applyDetailFilter();
}

function currentQuery() {
    return {
        action: 'dashboard',
        start_date: document.getElementById('filterStart').value,
        end_date: document.getElementById('filterEnd').value,
        wards: selectedOf('ward').join(','),
        microtypes: selectedOf('micro').join(','),
        typeinfect: selectedOf('typeinfect').join(','),
        specimens: selectedOf('specimen').join(','),
        results: selectedOf('result').join(','),
        ward_mode: document.getElementById('wardMode').value,
        culture_scope: cultureScope
    };
}

function setStatus(msg, isError) {
    const wrap = document.getElementById('amrStatusWrap');
    wrap.classList.toggle('is-error', !!isError);
    document.getElementById('amrStatus').textContent = msg;
}

function setQuickRange(days, btn) {
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - (days - 1));
    const fmt = d => d.toISOString().slice(0, 10);
    if (fpStart) fpStart.setDate(fmt(start), false);
    else document.getElementById('filterStart').value = fmt(start);
    if (fpEnd) fpEnd.setDate(fmt(end), false);
    else document.getElementById('filterEnd').value = fmt(end);
    document.querySelectorAll('.amr-chip[data-range]').forEach(el => el.classList.remove('active'));
    if (btn) btn.classList.add('active');
}

function setCultureScope(scope, btn) {
    cultureScope = scope === 'all' ? 'all' : 'resistant';
    document.querySelectorAll('.amr-chip[data-scope]').forEach(el => el.classList.toggle('active', el.getAttribute('data-scope') === cultureScope));
    if (btn) btn.classList.add('active');
    loadAmrDashboard();
}

async function loadFilters() {
    const data = await fetchJson(AMR_API + '?action=filters');
    if (data.status !== 'success') throw new Error(data.message || 'โหลดตัวกรองไม่สำเร็จ');
    amrDataSource = data.source || '';
    renderCheckList('dropWard', 'ward', data.wards || [], []);
    renderCheckList('dropType', 'typeinfect', data.typeinfect || ['NI', 'CI'], []);
    renderCheckList('dropResult', 'result', data.results || [], []);
    renderCheckList('dropMicro', 'micro', [], []);
    renderCheckList('dropSpec', 'specimen', [], []);
    syncFilterLabels();
}

function mergeFilterOptions(data) {
    const f = data.filters || {};
    const keep = (name) => selectedOf(name);
    renderCheckList('dropMicro', 'micro', f.microtypes || [], keep('micro'));
    renderCheckList('dropSpec', 'specimen', f.specimens || [], keep('specimen'));
    if (f.results && f.results.length) {
        renderCheckList('dropResult', 'result', f.results, keep('result'));
    }
    syncFilterLabels();
}

async function loadAmrDashboard() {
    const btn = document.getElementById('btnLoad');
    const seq = ++amrLoadSeq;
    btn.disabled = true;
    document.body.classList.add('is-loading');
    document.getElementById('amrStatusWrap').classList.add('is-loading');
    const q = currentQuery();
    try {
        if (amrDataSource === 'mlab') {
            const scopeLabel = cultureScope === 'all' ? 'ผลเพาะเชื้อทั้งหมด' : 'เชื้อดื้อยา';
            setStatus('กำลังโหลด ' + scopeLabel + ' จาก mLAB...');
            const data = await fetchJson(AMR_API + '?' + qs(Object.assign({}, q, { action: 'dashboard' })));
            if (seq !== amrLoadSeq) return;
            if (data.status !== 'success') throw new Error(data.message || 'โหลดข้อมูลไม่สำเร็จ');
            lastDashboardData = data;
            paintDashboard(data, true);
            mergeFilterOptions(data);
            return;
        }
        const chunks = amrDateChunks(q.start_date, q.end_date, 3);
        const total = chunks.length;
        let done = 0;
        let found = 0;
        setStatus('กำลังประมวลผลขนาน ' + total + ' ช่วง (ช่วงละ 3 วัน)...');
        const chunkQuery = (chunk) => Object.assign({}, q, {
            action: 'chunk',
            start_date: chunk.start,
            end_date: chunk.end
        });
        const bedP = fetchJson(AMR_API + '?' + qs(Object.assign({}, q, { action: 'bed_days' })));
        const chunkResults = await mapPool(chunks, 3, async (chunk) => {
            const data = await fetchJson(AMR_API + '?' + qs(chunkQuery(chunk)));
            if (seq !== amrLoadSeq) return { rows: [] };
            if (data.status !== 'success') {
                throw new Error((data.message || 'ช่วง ' + chunk.start + ' ไม่สำเร็จ'));
            }
            done += 1;
            found += (data.row_count || (data.rows || []).length || 0);
            setStatus('ดึงแล้ว ' + done + '/' + total + ' ช่วง · พบ ' + found + ' lab · ' + chunk.start + ' ถึง ' + chunk.end);
            return data;
        });
        if (seq !== amrLoadSeq) return;
        const rows = [];
        chunkResults.forEach(part => {
            (part.rows || []).forEach(r => rows.push(r));
        });
        setStatus('รวมผล ' + rows.length + ' lab และคำนวณ Dashboard...');
        const bedRes = await bedP;
        if (seq !== amrLoadSeq) return;
        if (bedRes.status !== 'success') {
            throw new Error(bedRes.message || 'คำนวณ bed-days ไม่สำเร็จ');
        }
        const assembled = await fetchJson(AMR_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'assemble',
                start_date: q.start_date,
                end_date: q.end_date,
                culture_scope: q.culture_scope,
                rows: rows,
                bed_days: bedRes.bed_days || {}
            })
        });
        if (seq !== amrLoadSeq) return;
        if (assembled.status !== 'success') throw new Error(assembled.message || 'รวมผลไม่สำเร็จ');
        lastDashboardData = assembled;
        paintDashboard(assembled, true);
        mergeFilterOptions(assembled);
    } catch (e) {
        if (seq !== amrLoadSeq) return;
        setStatus(e.message || String(e), true);
    } finally {
        if (seq === amrLoadSeq) {
            btn.disabled = false;
            document.body.classList.remove('is-loading');
            document.getElementById('amrStatusWrap').classList.remove('is-loading');
        }
    }
}

function paintDashboard(data, updateStatus) {
    const meta = data.meta || {};
    const ni = meta.ni_count || 0;
    const ci = meta.ci_count || 0;
    const lab = meta.row_count || 0;
    const scope = meta.culture_scope || cultureScope || 'resistant';
    cultureScope = scope === 'all' ? 'all' : 'resistant';
    document.querySelectorAll('.amr-chip[data-scope]').forEach(el => {
        el.classList.toggle('active', el.getAttribute('data-scope') === cultureScope);
    });
    const resistant = meta.resistant_count != null ? meta.resistant_count : lab;
    const kpiLabel = document.getElementById('kpiMainLabel');
    const trendDesc = document.getElementById('trendDesc');
    const sub = document.getElementById('amrSub');
    if (kpiLabel) kpiLabel.textContent = cultureScope === 'all' ? 'จำนวนผลเพาะเชื้อ' : 'จำนวนที่พบเชื้อดื้อยา';
    if (trendDesc) trendDesc.textContent = cultureScope === 'all'
        ? 'จำนวนผลเพาะที่พบเชื้อ (ดื้อยาและไม่ดื้อยา)'
        : 'จำนวน lab เชื้อดื้อยารวมทุกชนิด';
    if (sub) {
        sub.textContent = cultureScope === 'all'
            ? 'ภาพรวมผลเพาะเชื้อที่พบเชื้อ ทั้งดื้อยาและไม่ดื้อยา (ไม่รวม No growth)'
            : 'ภาพรวมผู้ป่วย IPD ที่พบเชื้อดื้อยา แยก NI/CI ตามหอผู้ป่วย ชนิดเชื้อ และ specimen';
    }
    document.getElementById('statNi').textContent = ni;
    document.getElementById('statCi').textContent = ci;
    document.getElementById('statLab').textContent = lab;
    document.getElementById('gaugeValue').textContent = (data.gauge && data.gauge.value) || lab || 0;
    const uniqueHn = (data.gauge && data.gauge.patient_count != null)
        ? data.gauge.patient_count
        : (meta.patient_count || 0);
    const elPatients = document.getElementById('statPatients');
    if (elPatients) elPatients.textContent = uniqueHn;
    const gJoin = meta.grafana_join_count || 0;
    const extra = meta.snapshot_dup_extra || Math.max(0, gJoin - lab);
    const hint = document.getElementById('grafanaCompareHint');
    if (hint) {
        if (cultureScope === 'all') {
            hint.textContent = 'เชื้อดื้อยา ' + resistant + ' จาก ' + lab + ' lab';
        } else if (gJoin && gJoin !== lab) {
            hint.textContent = 'Grafana นับ ' + gJoin + ' เพราะ snapshot ซ้ำ +' + extra + ' แถว';
        } else {
            hint.textContent = gJoin ? ('เทียบ Grafana: ' + gJoin) : '';
        }
    }
    const splitNi = lab ? Math.round((ni / lab) * 100) : 0;
    document.querySelector('#niCiSplit .ni').style.width = splitNi + '%';
    document.querySelector('#niCiSplit .ci').style.width = (lab ? 100 - splitNi : 0) + '%';
    applyChartDefaults();
    renderGauge((data.gauge && data.gauge.value) || 0, (data.gauge && data.gauge.max) || 50);
    renderNiRate(data.ni_rate || []);
    renderZeroNi(data.zero_ni_wards || []);
    renderByDate(data.by_date || []);
    renderScatter(data.scatter || [], (data.heatmap && data.heatmap.dates) || (data.by_date || []).map(x => x.date));
    renderByWard(data.by_ward || []);
    renderHeat(data.heatmap || { dates: [], rows: [] });
    renderPie(data.by_micro || []);
    renderDetails(data.rows || []);
    if (updateStatus !== false) {
        const srcLabel = (meta.data_source_label || (meta.data_source === 'mlab' ? 'mLAB (ตาราง THAM Hos-Safe)' : 'HOSxP'));
        const ms = meta.elapsed_ms ? (' · ' + meta.elapsed_ms + ' ms') : '';
        const scopeTxt = cultureScope === 'all' ? 'ทั้งหมด' : 'เชื้อดื้อยา';
        setStatus('อัปเดตแล้ว · ' + srcLabel + ' · ' + scopeTxt + ' · ' + lab + ' lab · ผู้ป่วยไม่ซ้ำ ' + uniqueHn + ' คน' + ms);
    }
}

document.getElementById('detailSearch').addEventListener('input', applyDetailFilter);
document.getElementById('btnExportExcel').addEventListener('click', exportDetailExcel);
document.getElementById('btnExportPdf').addEventListener('click', exportDetailPdf);
document.querySelectorAll('.amr-table thead th.amr-sort').forEach(th => {
    th.addEventListener('click', () => setDetailSort(th.getAttribute('data-sort')));
});
syncThemeButtons();
applyChartDefaults();
syncSortHeaders();

if (typeof flatpickr !== 'undefined') {
    fpStart = flatpickr('#filterStart', { dateFormat: 'Y-m-d' });
    fpEnd = flatpickr('#filterEnd', { dateFormat: 'Y-m-d' });
}

loadFilters()
    .then(loadAmrDashboard)
    .catch(e => setStatus(e.message || String(e), true));
</script>
</body>
</html>
