<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
register_shutdown_function(function () {
    $e = error_get_last();
    if (!$e || !in_array((int)$e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        return;
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
    $msg = trim((string)($e['message'] ?? 'Internal error'));
    if (function_exists('mb_substr')) {
        $msg = mb_substr($msg, 0, 240, 'UTF-8');
    } else {
        $msg = substr($msg, 0, 240);
    }
    echo json_encode([
        'status' => 'error',
        'message' => 'โมดูลคัดกรองล้มเหลว: ' . $msg,
    ], JSON_UNESCAPED_UNICODE | (defined('JSON_INVALID_UTF8_SUBSTITUTE') ? JSON_INVALID_UTF8_SUBSTITUTE : 0));
});
session_start();

include('connect.php');
include('smart_pharma_helper.php');
include('smart_pharma_telegram_helper.php');
include('smart_pharma_webhook_helper.php');
include('smart_pharma_notifications_helper.php');
include('smart_pharma_alert_log_helper.php');
mysqli_set_charset($con, 'utf8');
set_time_limit(600);
ini_set('memory_limit', '512M');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

$sp_sess_user_id = (int)($_SESSION['user_id'] ?? 0);
$sp_sess_full_name = (string)($_SESSION['full_name'] ?? '');
session_write_close();

sp_ensure_tables($con);

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? ''));
if ($action === '') {
    $ctype = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? ''));
    if (strpos($ctype, 'application/json') !== false) {
        $peek = json_decode((string)file_get_contents('php://input'), true);
        if (is_array($peek) && !empty($peek['action'])) {
            $action = trim((string)$peek['action']);
        }
    }
}
if ($action === '') {
    $action = 'list';
}

if ($action === 'modules') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $q = mysqli_query($con, "SELECT * FROM smart_pharma_modules ORDER BY sort_order ASC");
    $mods = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $mods[] = $r;
        }
    }
    echo json_encode(['status' => 'success', 'modules' => $mods], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_modules' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!empty($raw['modules']) && is_array($raw['modules'])) {
        sp_save_module_settings($con, $raw['modules']);
    }
    echo json_encode(['status' => 'success', 'message' => 'บันทึกการตั้งค่าโมดูลเรียบร้อย'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_intervention' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true);
    if (empty($raw['hn']) || empty($raw['module_key'])) {
        echo json_encode(['status' => 'error', 'message' => 'ข้อมูลไม่ครบ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $result = sp_save_intervention(
        $con,
        $raw,
        $sp_sess_user_id,
        $sp_sess_full_name
    );
    echo json_encode([
        'status' => !empty($result['ok']) ? 'success' : 'error',
        'saved' => !empty($result['ok']),
        'id' => (int)($result['id'] ?? 0),
        'message' => $result['message'] ?? 'บันทึกไม่สำเร็จ',
        'hard_pending' => !empty($result['hard_pending']),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'update_intervention' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $id = (int)($raw['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบรายการ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $result = sp_update_intervention(
        $con,
        $id,
        $raw,
        $sp_sess_user_id,
        $sp_sess_full_name
    );
    echo json_encode([
        'status' => !empty($result['ok']) ? 'success' : 'error',
        'saved' => !empty($result['ok']),
        'message' => $result['message'] ?? 'แก้ไขไม่สำเร็จ',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'mute_alert_hn' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    if (trim((string)($raw['confirm'] ?? '')) !== 'confirm') {
        echo json_encode(['status' => 'error', 'message' => 'พิมพ์คำว่า confirm ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $result = sp_alert_mute_add(
        $con,
        'hn',
        $raw['hn'] ?? '',
        $raw['patient_type'] ?? '',
        $raw['vn'] ?? '',
        $raw['an'] ?? '',
        $sp_sess_user_id,
        $sp_sess_full_name
    );
    echo json_encode([
        'status' => !empty($result['ok']) ? 'success' : 'error',
        'muted' => !empty($result['ok']),
        'message' => $result['message'] ?? 'ปิดการแจ้งเตือนไม่สำเร็จ',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'delete_intervention' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    if (trim((string)($raw['confirm'] ?? '')) !== 'delete') {
        echo json_encode(['status' => 'error', 'message' => 'พิมพ์คำว่า delete ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $result = sp_delete_intervention($con, (int)($raw['id'] ?? 0));
    echo json_encode([
        'status' => !empty($result['ok']) ? 'success' : 'error',
        'deleted' => !empty($result['ok']),
        'message' => $result['message'] ?? 'ลบไม่สำเร็จ',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'alert_logs') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $filters = [
        'start_date' => $_GET['start_date'] ?? date('Y-m-d', strtotime('-7 days')),
        'end_date' => $_GET['end_date'] ?? date('Y-m-d'),
        'status' => $_GET['status'] ?? '',
        'resolved_by' => $_GET['resolved_by'] ?? '',
        'patient_type' => $_GET['patient_type'] ?? '',
        'module_key' => $_GET['module_key'] ?? '',
        'module_keys' => $_GET['module_keys'] ?? '',
        'limit' => (int)($_GET['limit'] ?? 300),
    ];
    $rows = sp_alert_log_list($con, $filters);
    echo json_encode(['status' => 'success', 'logs' => $rows, 'count' => count($rows)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'telegram_sent_logs') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $filters = [
        'start_date' => $_GET['start_date'] ?? date('Y-m-d', strtotime('-7 days')),
        'end_date' => $_GET['end_date'] ?? date('Y-m-d'),
        'patient_type' => $_GET['patient_type'] ?? '',
        'alert_level' => $_GET['alert_level'] ?? '',
        'hn' => $_GET['hn'] ?? '',
        'module_key' => $_GET['module_key'] ?? '',
        'module_keys' => $_GET['module_keys'] ?? '',
        'limit' => (int)($_GET['limit'] ?? 300),
    ];
    $rows = sp_telegram_sent_list($con, $filters);
    echo json_encode(['status' => 'success', 'rows' => $rows, 'count' => count($rows)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'list_backup') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    require_once __DIR__ . '/smart_pharma_backup_helper.php';
    $patient_type = ($_GET['patient_type'] ?? $_POST['patient_type'] ?? 'OPD') === 'IPD' ? 'IPD' : 'OPD';
    $screen_date = trim((string)($_GET['screen_date'] ?? $_POST['screen_date'] ?? date('Y-m-d')));
    $time_window = trim((string)($_GET['time_window'] ?? $_POST['time_window'] ?? ''));
    $time_from = trim((string)($_GET['time_from'] ?? $_POST['time_from'] ?? ''));
    $time_to = trim((string)($_GET['time_to'] ?? $_POST['time_to'] ?? ''));
    $t0 = microtime(true);
    $data = sp_backup_screen_from_logs($con, $patient_type, $screen_date, $time_window, $time_from, $time_to);
    $data['meta']['elapsed_ms'] = (int)round((microtime(true) - $t0) * 1000);
    echo json_encode([
        'status' => 'success',
        'patients' => $data['patients'],
        'modules' => $data['modules'],
        'meta' => $data['meta'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'alert_log_detail') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $id = (int)($_GET['id'] ?? 0);
    $q = mysqli_query($con, "SELECT l.*, m.label_th AS module_label FROM smart_pharma_alert_logs l
        LEFT JOIN smart_pharma_modules m ON m.module_key = l.module_key WHERE l.id=$id LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบรายการ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $row['status_label'] = sp_alert_log_status_label($row);
    $row['interventions'] = sp_alert_log_interventions($con, $id);
    echo json_encode(['status' => 'success', 'log' => $row], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'interventions') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $start = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
    $end = $_GET['end_date'] ?? date('Y-m-d');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start)) {
        $start = date('Y-m-d', strtotime('-30 days'));
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
        $end = date('Y-m-d');
    }
    $rows = sp_list_interventions($con, $start, $end);
    echo json_encode(['status' => 'success', 'interventions' => $rows, 'count' => count($rows)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'telegram_chats') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'chats' => sp_telegram_list_chats($con)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'telegram_rules') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'rules' => sp_telegram_list_rules($con)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'telegram_save_config' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    sp_telegram_save_config(
        $con,
        !empty($raw['enabled']),
        array_key_exists('cron_secret', $raw) ? ($raw['cron_secret'] ?? '') : null,
        array_key_exists('base_url', $raw) ? ($raw['base_url'] ?? '') : null
    );
    echo json_encode(['status' => 'success', 'message' => 'บันทึกการตั้งค่าเรียบร้อย'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'telegram_save_chat' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $ok = sp_telegram_save_chat($con, $raw);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'message' => $ok ? 'บันทึกกลุ่มเรียบร้อย' : 'บันทึกไม่สำเร็จ — ตรวจชื่อกลุ่ม, Bot Token (API) และ Chat ID',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'telegram_delete_chat' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $ok = sp_telegram_delete_chat($con, (int)($raw['id'] ?? 0));
    echo json_encode(['status' => $ok ? 'success' : 'error', 'message' => $ok ? 'ลบกลุ่มแล้ว' : 'ลบไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'telegram_save_rule' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $ok = sp_telegram_save_rule($con, $raw);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'message' => $ok ? 'บันทึกกฎเรียบร้อย' : 'บันทึกไม่สำเร็จ — เลือก Hard หรือ Soft อย่างน้อยหนึ่งอย่าง',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'telegram_delete_rule' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $ok = sp_telegram_delete_rule($con, (int)($raw['id'] ?? 0));
    echo json_encode(['status' => $ok ? 'success' : 'error', 'message' => $ok ? 'ลบกฎแล้ว' : 'ลบไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'webhook_endpoints') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'endpoints' => sp_webhook_list_endpoints($con)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'webhook_rules') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'rules' => sp_webhook_list_rules($con)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'webhook_save_config' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    sp_webhook_save_config(
        $con,
        !empty($raw['enabled']),
        array_key_exists('base_url', $raw) ? ($raw['base_url'] ?? '') : null
    );
    echo json_encode(['status' => 'success', 'message' => 'บันทึกการตั้งค่าเรียบร้อย'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'webhook_save_endpoint' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $ok = sp_webhook_save_endpoint($con, $raw);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'message' => $ok ? 'บันทึก Endpoint เรียบร้อย' : 'บันทึกไม่สำเร็จ — ตรวจชื่อ URL (http/https หรือ Tuya) และ Access ID:Secret ถ้าเป็น Tuya Cloud',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'webhook_delete_endpoint' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $ok = sp_webhook_delete_endpoint($con, (int)($raw['id'] ?? 0));
    echo json_encode(['status' => $ok ? 'success' : 'error', 'message' => $ok ? 'ลบ Endpoint แล้ว' : 'ลบไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'webhook_save_rule' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $ok = sp_webhook_save_rule($con, $raw);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'message' => $ok ? 'บันทึกกฎเรียบร้อย' : 'บันทึกไม่สำเร็จ — เลือก Hard หรือ Soft อย่างน้อยหนึ่งอย่าง',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'webhook_delete_rule' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $ok = sp_webhook_delete_rule($con, (int)($raw['id'] ?? 0));
    echo json_encode(['status' => $ok ? 'success' : 'error', 'message' => $ok ? 'ลบกฎแล้ว' : 'ลบไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'webhook_test' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $endpoint_id = (int)($raw['endpoint_id'] ?? 0);
    $endpoints = sp_webhook_list_endpoints($con);
    $endpoint_row = null;
    foreach ($endpoints as $e) {
        if ((int)$e['id'] === $endpoint_id) {
            $endpoint_row = $e;
            break;
        }
    }
    if (!$endpoint_row || trim((string)($endpoint_row['webhook_url'] ?? '')) === '') {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบ Endpoint'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $mode = (($raw['mode'] ?? '') === 'sample') ? 'sample' : 'simple';
    $res = sp_webhook_send_test($con, $endpoint_row, $mode);
    $msg = $res['error'] ?? 'ส่งไม่สำเร็จ';
    if (!empty($res['ok'])) {
        if ($mode === 'sample') {
            $n = (int)($res['sent'] ?? 1);
            $t = (int)($res['total'] ?? $n);
            $msg = 'ส่งตัวอย่าง Alert จริง ' . $n . ' รายการแล้ว — payload มี alert_log_id และลิงก์ Intervention Log';
            if ($n < $t) {
                $msg .= ' (ส่งได้ ' . $n . '/' . $t . ')';
            }
        } else {
            $msg = 'ส่ง Ping ทดสอบแล้ว — ตรวจที่ปลายทาง Webhook';
        }
    }
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $msg,
        'sent' => (int)($res['sent'] ?? 0),
        'total' => (int)($res['total'] ?? 0),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'notification_config') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'config' => sp_notifications_get_config($con)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'notification_save_config' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    sp_notifications_save_config($con, $raw);
    echo json_encode(['status' => 'success', 'message' => 'บันทึกการตั้งค่าเรียบร้อย'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'notification_unified_rules') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'rules' => sp_notifications_list_unified_rules($con)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'notification_save_unified_rule' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $result = sp_notifications_save_unified_rule($con, $raw);
    if (is_array($result) && !empty($result['conflicts'])) {
        echo json_encode([
            'status' => 'confirm',
            'message' => 'มีกฎเดิมที่ชนกัน — บันทึกจะแทนที่การตั้งค่าเดิม',
            'conflicts' => $result['conflicts'],
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $ok = (bool)$result;
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'message' => $ok ? 'บันทึกกฎเรียบร้อย' : 'บันทึกไม่สำเร็จ — เลือกปลายทาง, โมดูล, OPD/IPD และ Hard/Soft ให้ครบ',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'screen_hn') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = ($_SERVER['REQUEST_METHOD'] === 'POST')
        ? (json_decode(file_get_contents('php://input'), true) ?: [])
        : $_GET;
    $patient_type = ($raw['patient_type'] ?? 'OPD') === 'IPD' ? 'IPD' : 'OPD';
    $screen_date = trim((string)($raw['screen_date'] ?? $raw['vstdate'] ?? date('Y-m-d')));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $screen_date)) {
        $screen_date = date('Y-m-d');
    }
    $hn = trim((string)($raw['hn'] ?? ''));
    $vn = trim((string)($raw['vn'] ?? ''));
    $an = trim((string)($raw['an'] ?? ''));
    $notify = !isset($raw['notify']) || $raw['notify'] === true || $raw['notify'] === '1' || $raw['notify'] === 1;
    $module_keys = $raw['module_keys'] ?? null;
    if (is_string($module_keys)) {
        $module_keys = preg_split('/[\s,;]+/', $module_keys, -1, PREG_SPLIT_NO_EMPTY);
    }

    $hos = hosxp_connect($con);
    if (!$hos) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $result = sp_run_screening_hn($con, $hos, $patient_type, $screen_date, $hn, $vn, $an, [
        'notify' => $notify,
        'module_keys' => is_array($module_keys) ? $module_keys : null,
    ]);
    mysqli_close($hos);
    echo json_encode([
        'status' => !empty($result['ok']) ? 'success' : 'error',
        'message' => $result['message'] ?? '',
    ] + $result, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'screen_api_config') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'success',
        'api_key_set' => sp_screen_api_get_key($con) !== '',
        'api_url' => (isset($_SERVER['HTTP_HOST']) ? (((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''))) : '') . '/fetch_smart_pharma_screen_hn_api.php',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'screen_api_save_key' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    sp_screen_api_save_key($con, $raw['api_key'] ?? '');
    echo json_encode(['status' => 'success', 'message' => 'บันทึก API Key แล้ว'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'notification_delete_unified_rule' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $ok = sp_notifications_delete_unified_rule($con, $raw);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'message' => $ok ? 'ลบกฎแล้ว' : 'ไม่พบกฎที่ต้องการลบ',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'telegram_test' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    $raw = json_decode(file_get_contents('php://input'), true) ?: [];
    $chat_row_id = (int)($raw['chat_row_id'] ?? 0);
    $chats = sp_telegram_list_chats($con);
    $chat_row = null;
    foreach ($chats as $c) {
        if ((int)$c['id'] === $chat_row_id) {
            $chat_row = $c;
            break;
        }
    }
    if (!$chat_row || trim((string)($chat_row['chat_id'] ?? '')) === '') {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบกลุ่ม'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $mode = (($raw['mode'] ?? '') === 'sample') ? 'sample' : 'simple';
    $res = sp_telegram_send_test($con, $chat_row['chat_id'], $chat_row, $mode);
    $msg = $res['error'] ?? 'ส่งไม่สำเร็จ';
    if (!empty($res['ok'])) {
        if ($mode === 'sample') {
            $n = (int)($res['sent'] ?? 1);
            $t = (int)($res['total'] ?? $n);
            $msg = 'ส่งตัวอย่าง Alert จริง ' . $n . ' รายการแล้ว — แต่ละรายการมีลิงก์เปิด Intervention Log ของผู้ป่วยนั้น';
            if ($n < $t) {
                $msg .= ' (ส่งได้ ' . $n . '/' . $t . ')';
            }
        } else {
            $msg = 'ส่งข้อความทดสอบแล้ว — ตรวจใน Telegram';
        }
    }
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $msg,
        'sent' => (int)($res['sent'] ?? 0),
        'total' => (int)($res['total'] ?? 0),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action !== 'list' && $action !== 'list_bootstrap' && $action !== 'list_module') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unknown action'], JSON_UNESCAPED_UNICODE);
    exit;
}

// action=list | list_bootstrap | list_module
$is_bootstrap = ($action === 'list_bootstrap');
$module_key_filter = trim((string)($_GET['module_key'] ?? $_POST['module_key'] ?? ''));
$is_one_module = ($action === 'list_module' || ($action === 'list' && $module_key_filter !== ''));
if ($action === 'list_module' && $module_key_filter === '') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ module_key'], JSON_UNESCAPED_UNICODE);
    exit;
}

$patient_type = ($_GET['patient_type'] ?? $_POST['patient_type'] ?? 'OPD') === 'IPD' ? 'IPD' : 'OPD';
$screen_date = trim((string)($_GET['screen_date'] ?? $_POST['screen_date'] ?? date('Y-m-d')));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $screen_date)) {
    $screen_date = date('Y-m-d');
}
$time_window = sp_normalize_time_window($_GET['time_window'] ?? $_POST['time_window'] ?? '', $screen_date);
$time_from = trim((string)($_GET['time_from'] ?? $_POST['time_from'] ?? ''));
$time_to = trim((string)($_GET['time_to'] ?? $_POST['time_to'] ?? ''));
if ($time_window === 'custom' && sp_normalize_custom_time_range($time_from, $time_to) === null) {
    $time_window = sp_is_screen_date_today($screen_date) ? '30m' : 'full';
    $time_from = '';
    $time_to = '';
}

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}

$all_modules = sp_get_modules($con, $patient_type);
if (empty($all_modules)) {
    mysqli_close($hos);
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'success',
        'patients' => [],
        'modules' => [],
        'meta' => ['message' => 'ยังไม่ได้เปิดโมดูลคัดกรอง — ไปที่แท็บตั้งค่า'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$modules = $is_one_module && !$is_bootstrap
    ? sp_filter_modules_by_key($all_modules, $module_key_filter)
    : $all_modules;
if ($is_one_module && !$is_bootstrap && empty($modules)) {
    mysqli_close($hos);
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'success',
        'patients' => [],
        'modules' => [],
        'module_key' => $module_key_filter,
        'meta' => ['message' => 'ไม่พบโมดูลที่ระบุ หรือโมดูลถูกปิด'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$t0 = microtime(true);
$timings = [];
try {
list($patients_with_drugs, $patients_cached) = sp_load_cached_patients($hos, $patient_type, $screen_date);
$timings['fetch_ms'] = $patients_cached ? 0 : (int)round((microtime(true) - $t0) * 1000);
$timings['fetch_cached'] = $patients_cached;

$patients_to_screen = sp_patients_for_time_window($patients_with_drugs, $screen_date, $time_window, $time_from, $time_to);
$window_cache_suffix = $time_window === 'custom'
    ? ('custom_' . preg_replace('/[^0-9]/', '', $time_from . $time_to))
    : $time_window;
// ดักรายการใหม่/เปลี่ยน — ถ้า fingerprint เปลี่ยนจะไม่ใช้แคชผลคัดกรองเก่า
$patients_fp = sp_patients_fingerprint($patients_to_screen);
$window_cache_suffix .= '_fp' . $patients_fp;

$module_cols_all = array_map(function ($m) {
    return [
        'key' => $m['module_key'],
        'label' => $m['label_th'],
        'icon' => $m['icon'],
        'color' => $m['color'],
    ];
}, $all_modules);

if ($is_bootstrap) {
    session_write_close();
    $pending_rows = [];
    foreach ($patients_to_screen as $pat) {
        $pending_rows[] = sp_build_pending_patient_row($pat, $patient_type, $screen_date, $all_modules);
    }
    $elapsed = (int)round((microtime(true) - $t0) * 1000);
    $timings['total_ms'] = $elapsed;
    mysqli_close($hos);
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'success',
        'patients' => $pending_rows,
        'modules' => $module_cols_all,
        'meta' => [
            'patient_type' => $patient_type,
            'screen_date' => $screen_date,
            'count' => count($pending_rows),
            'total_patients' => count($patients_with_drugs),
            'time_window' => $time_window,
            'time_window_label' => sp_time_window_label($time_window, $time_from, $time_to),
            'time_from' => $time_from,
            'time_to' => $time_to,
            'is_today' => sp_is_screen_date_today($screen_date),
            'alert_count' => 0,
            'elapsed_ms' => $elapsed,
            'timings' => $timings,
            'phase' => 'bootstrap',
        ],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$cache_ttl = sp_cache_ttl($screen_date, $time_window);

if ($is_one_module) {
    // ปลด session lock ก่อนคัดกรองโมดูล — ให้หลายโมดูลรันคู่ขนานได้
    session_write_close();
}

$has_di_module = false;
foreach ($modules as $mod) {
    if (($mod['module_key'] ?? '') === 'di') {
        $has_di_module = true;
        break;
    }
}

$di_batch = null;
if ($has_di_module) {
    $cache_di_key = 'di_' . $screen_date . '_' . $patient_type . '_' . $window_cache_suffix;
    if (!$is_one_module) {
        $di_batch = sp_cache_get($cache_di_key, $cache_ttl);
    }
    if ($di_batch === null) {
        $t_di = microtime(true);
        $hn_filter = sp_extract_hn_list($patients_to_screen);
        $di_batch = sp_batch_screen_di_for_date($con, $hos, $screen_date, $hn_filter);
        if (!$is_one_module) {
            sp_cache_set($cache_di_key, $di_batch);
        }
        $timings['di_ms'] = (int)round((microtime(true) - $t_di) * 1000);
    } else {
        $timings['di_ms'] = 0;
        $timings['di_cached'] = true;
    }
}

$cache_ctx_key = 'ctx_' . $screen_date . '_' . $patient_type . '_' . $window_cache_suffix;
if ($is_one_module && $module_key_filter !== '') {
    $cache_ctx_key .= '_' . $module_key_filter;
}
$screen_ctx = $is_one_module ? null : sp_cache_get($cache_ctx_key, $cache_ttl);
if ($screen_ctx === null) {
    $t_ctx = microtime(true);
    $screen_ctx = sp_build_screen_cache($con, $hos, $patients_to_screen, $screen_date, $modules);
    if (!$is_one_module) {
        sp_cache_set($cache_ctx_key, $screen_ctx);
    }
    $timings['screen_cache_ms'] = (int)round((microtime(true) - $t_ctx) * 1000);
} else {
    $timings['screen_cache_ms'] = 0;
    $timings['screen_cache_cached'] = true;
}

if (!$is_one_module) {
    session_write_close();
}

$all_screened = [];
$t_screen = microtime(true);
foreach ($patients_to_screen as $pat) {
    $screen = sp_screen_patient($con, $hos, $pat, $modules, $di_batch, $screen_date, $screen_ctx);
    $all_screened[] = sp_build_screened_patient_row($pat, $screen, $patient_type, $screen_date, $modules);
}
$all_screened = sp_apply_alert_mutes($con, $patient_type, $all_screened);

$t_log = microtime(true);
$alert_log_stats = sp_alert_log_sync(
    $con,
    $patient_type,
    $screen_date,
    $all_screened,
    $time_window === 'full',
    $is_one_module ? $module_key_filter : ''
);
$timings['alert_log_ms'] = (int)round((microtime(true) - $t_log) * 1000);

$all_screened = sp_apply_intervention_display($con, $patient_type, $screen_date, $all_screened);
$out = sp_filter_screened_rows_by_time($all_screened, $screen_date, $time_window, $time_from, $time_to);

usort($out, function ($a, $b) {
    $a_alert = ($a['overall'] ?? '') === 'alert' ? 0 : 1;
    $b_alert = ($b['overall'] ?? '') === 'alert' ? 0 : 1;
    if ($a_alert !== $b_alert) {
        return $a_alert <=> $b_alert;
    }
    $a_level = ($a['overall_level'] ?? '') === 'hard' ? 0 : 1;
    $b_level = ($b['overall_level'] ?? '') === 'hard' ? 0 : 1;
    if ($a_alert === 0 && $a_level !== $b_level) {
        return $a_level <=> $b_level;
    }
    $a_dt = sp_patient_order_timestamp([
        'rxdate' => $a['rxdate'] ?? '', 'rxtime' => $a['rxtime'] ?? '',
        'vstdate' => $a['vstdate'] ?? '', 'vsttime' => $a['vsttime'] ?? '',
    ]) ?: 0;
    $b_dt = sp_patient_order_timestamp([
        'rxdate' => $b['rxdate'] ?? '', 'rxtime' => $b['rxtime'] ?? '',
        'vstdate' => $b['vstdate'] ?? '', 'vsttime' => $b['vsttime'] ?? '',
    ]) ?: 0;
    if ($a_dt !== $b_dt) {
        return $b_dt <=> $a_dt;
    }
    return strcmp($a['hn'] ?? '', $b['hn'] ?? '');
});

$timings['screen_loop_ms'] = (int)round((microtime(true) - $t_screen) * 1000);

$module_labels = [];
foreach ($modules as $mod) {
    $module_labels[$mod['module_key']] = $mod['label_th'];
}
$t_tg = microtime(true);
require_once __DIR__ . '/smart_pharma_notify_helper.php';
$telegram_result = ['sent' => 0, 'skipped' => 0, 'errors' => []];
$webhook_result = ['sent' => 0, 'skipped' => 0, 'errors' => []];
try {
    $notify_patients = sp_notify_screening_alert_patients($all_screened);
    $telegram_result = sp_telegram_notify_screening($con, $patient_type, $screen_date, $notify_patients, $module_labels);
} catch (Throwable $e) {
    $telegram_result['errors'][] = $e->getMessage();
}
$timings['telegram_ms'] = (int)round((microtime(true) - $t_tg) * 1000);

$t_wh = microtime(true);
try {
    if (!isset($notify_patients)) {
        $notify_patients = [];
    }
    $webhook_result = sp_webhook_notify_screening($con, $patient_type, $screen_date, $notify_patients, $module_labels);
} catch (Throwable $e) {
    $webhook_result['errors'][] = $e->getMessage();
}
$timings['webhook_ms'] = (int)round((microtime(true) - $t_wh) * 1000);

$timings['notify_repeat_ms'] = 0;

$elapsed = (int)round((microtime(true) - $t0) * 1000);
$timings['total_ms'] = $elapsed;
mysqli_close($hos);

$module_cols = $is_one_module ? $module_cols_all : array_map(function ($m) {
    return [
        'key' => $m['module_key'],
        'label' => $m['label_th'],
        'icon' => $m['icon'],
        'color' => $m['color'],
    ];
}, $modules);

ob_clean();
header('Content-Type: application/json; charset=utf-8');
$json_flags = JSON_UNESCAPED_UNICODE;
if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
    $json_flags |= JSON_INVALID_UTF8_SUBSTITUTE;
}
$payload = json_encode([
    'status' => 'success',
    'patients' => $out,
    'modules' => $module_cols,
    'module_key' => $is_one_module ? $module_key_filter : '',
    'meta' => [
        'patient_type' => $patient_type,
        'screen_date' => $screen_date,
        'count' => count($out),
        'total_patients' => count($patients_with_drugs),
        'time_window' => $time_window,
        'time_window_label' => sp_time_window_label($time_window, $time_from, $time_to),
        'time_from' => $time_from,
        'time_to' => $time_to,
        'is_today' => sp_is_screen_date_today($screen_date),
        'alert_count' => count(array_filter($out, function ($p) {
            return ($p['overall'] ?? '') === 'alert';
        })),
        'di_alert_count' => is_array($di_batch) ? count($di_batch['results'] ?? []) : 0,
        'elapsed_ms' => $elapsed,
        'timings' => $timings,
        'telegram' => $telegram_result,
        'webhook' => $webhook_result,
        'alert_log' => $alert_log_stats,
        'phase' => $is_one_module ? 'module' : 'full',
    ],
], $json_flags);
if ($payload === false) {
    throw new RuntimeException('JSON encode failed: ' . json_last_error_msg());
}
echo $payload;
} catch (Throwable $e) {
    if (isset($hos) && $hos) {
        @mysqli_close($hos);
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
    $json_flags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $json_flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    echo json_encode([
        'status' => 'error',
        'message' => 'คัดกรองไม่สำเร็จ: ' . $e->getMessage(),
        'module_key' => $module_key_filter ?? '',
    ], $json_flags);
    exit;
}
