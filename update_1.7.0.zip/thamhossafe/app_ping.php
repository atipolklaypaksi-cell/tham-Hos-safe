<?php
/**
 * จุดตรวจว่า Apache/PHP ตอบได้ โดยไม่แตะ MySQL / HOSxP / session
 * ใช้กับ cron_hang_watch.php — อย่า include connect.php ที่นี่
 */
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');
echo 'ok ' . date('Y-m-d H:i:s');
