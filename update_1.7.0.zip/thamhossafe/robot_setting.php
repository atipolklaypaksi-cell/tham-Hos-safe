<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/robot_db_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.robot') && !tham_menu_can('admin.hosxp') && !tham_menu_can('pharm_care.med_error') && ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: home.php');
    exit;
}
robot_ensure_config($con);
$cfg = robot_load_config($con);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เชื่อมต่อ Robot OPD - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .robot-hero {
            background: linear-gradient(135deg, #1e3a8a 0%, #1d4ed8 55%, #2563eb 100%);
            color: #fff; border-radius: 16px; padding: 1.2rem 1.4rem; margin-bottom: 1.1rem;
        }
        .robot-badge { background: rgba(255,255,255,.18); border: 1px solid rgba(255,255,255,.28); }
        .robot-stat { border: 0; border-radius: 12px; }
        .robot-stat .n { font-size: 1.45rem; font-weight: 800; }
        .robot-table-list { max-height: 280px; overflow: auto; }
        .robot-table-list button { text-align: left; }
        .robot-preview { font-size: .8rem; }
        .robot-preview th { white-space: nowrap; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="robot-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="small text-uppercase" style="letter-spacing:.08em;opacity:.75;">ตั้งค่าระบบ · Robot OPD</div>
                    <h4 class="fw-bold mb-1">เชื่อมต่อ Robot OPD</h4>
                    <p class="mb-0 small" style="opacity:.92;">อ่านข้อมูลจาก MySQL ของเครื่อง Robot OPD เท่านั้น ไม่มีการเขียนหรือแก้ข้อมูลต้นทาง</p>
                </div>
                <span class="badge robot-badge px-3 py-2 fs-6"><i class="fas fa-lock me-1"></i> Read Only</span>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-6 col-lg-3">
                    <div class="card robot-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">สถานะ</div>
                        <div class="n" id="statStatus">กำลังตรวจ…</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card robot-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">ฐานข้อมูล</div>
                        <div class="n" id="statDb">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card robot-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">ตาราง</div>
                        <div class="n" id="statTables">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card robot-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">เวลาตอบ</div>
                        <div class="n" id="statMs">—</div>
                    </div></div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-lg-5">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3"><i class="fas fa-robot me-2 text-primary"></i>ข้อมูลการเชื่อมต่อ MySQL (Robot OPD)</h6>
                            <form id="robotForm">
                                <div class="row g-3">
                                    <div class="col-8">
                                        <label class="form-label small fw-bold">Host / IP</label>
                                        <input type="text" class="form-control" id="robot_host" value="<?php echo htmlspecialchars($cfg['robot_host']); ?>">
                                    </div>
                                    <div class="col-4">
                                        <label class="form-label small fw-bold">Port</label>
                                        <input type="number" class="form-control" id="robot_port" value="<?php echo htmlspecialchars($cfg['robot_port']); ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label small fw-bold">Database Name</label>
                                        <input type="text" class="form-control" id="robot_db" list="robotDbList" value="<?php echo htmlspecialchars($cfg['robot_db']); ?>" placeholder="เว้นว่างได้ — กดทดสอบเพื่อดึงรายชื่อฐาน">
                                        <datalist id="robotDbList"></datalist>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Username</label>
                                        <input type="text" class="form-control" id="robot_user" value="<?php echo htmlspecialchars($cfg['robot_user']); ?>">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Password</label>
                                        <input type="password" class="form-control" id="robot_pass" value="<?php echo ($cfg['robot_pass'] ?? '') !== '' ? '********' : ''; ?>" autocomplete="new-password">
                                        <div class="form-text">เว้น ******** ไว้ถ้าไม่ต้องการเปลี่ยนรหัส</div>
                                    </div>
                                </div>
                                <div class="alert alert-info small mt-3 mb-0">
                                    <i class="fas fa-shield-alt me-1"></i>
                                    บัญชีนี้ถูกบังคับเป็น <b>Read Only</b> ในระบบ (SELECT/SHOW เท่านั้น)
                                </div>
                                <div class="small mt-3" id="robotHint"></div>
                                <div class="d-flex justify-content-end gap-2 mt-3">
                                    <button type="button" class="btn btn-outline-primary fw-bold" id="btnTest">
                                        <i class="fas fa-plug me-1"></i> ทดสอบการเชื่อมต่อ
                                    </button>
                                    <button type="submit" class="btn btn-primary fw-bold">
                                        <i class="fas fa-save me-1"></i> บันทึก
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body">
                            <h6 class="fw-bold mb-2"><i class="fas fa-table me-2 text-primary"></i>ดูตาราง (อ่านอย่างเดียว)</h6>
                            <div class="input-group input-group-sm mb-2">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" class="form-control" id="tableQ" placeholder="ค้นหาชื่อตาราง">
                            </div>
                            <div class="robot-table-list list-group mb-3" id="tableList">
                                <div class="text-muted small p-2">กำลังโหลดรายการตาราง…</div>
                            </div>
                            <div id="previewBox" class="d-none">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div class="fw-bold" id="previewTitle"></div>
                                    <span class="badge bg-secondary">ซ่อนคอลัมน์อ่อนไหว</span>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered bg-white robot-preview mb-0">
                                        <thead class="table-light" id="previewHead"></thead>
                                        <tbody id="previewBody"></tbody>
                                    </table>
                                </div>
                            </div>
                            <div id="previewEmpty" class="small text-muted">เลือกตารางด้านบนเพื่อดูตัวอย่าง 20 แถวแรก</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
function formBody(extra) {
    const body = {
        robot_host: document.getElementById('robot_host').value.trim(),
        robot_port: document.getElementById('robot_port').value.trim(),
        robot_db: document.getElementById('robot_db').value.trim(),
        robot_user: document.getElementById('robot_user').value.trim(),
        robot_pass: document.getElementById('robot_pass').value
    };
    return Object.assign(body, extra || {});
}
function api(action, extra) {
    return fetch('fetch_robot_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign(formBody({ action: action }), extra || {}))
    }).then(async function (res) {
        const text = await res.text();
        try { return JSON.parse(text); }
        catch (e) { throw new Error('ไฟล์ API ตอบกลับไม่ใช่ JSON'); }
    });
}
function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function fillDbList(dbs) {
    const list = document.getElementById('robotDbList');
    list.innerHTML = (dbs || []).map(function (d) {
        return '<option value="' + esc(d) + '"></option>';
    }).join('');
}
function applyPing(ping) {
    const ok = ping && ping.ok;
    document.getElementById('statStatus').textContent = ok ? 'เชื่อมต่อได้' : 'เชื่อมต่อไม่ได้';
    document.getElementById('statStatus').className = 'n ' + (ok ? 'text-success' : 'text-danger');
    document.getElementById('statDb').textContent = ok ? ((ping.db || '').trim() || (ping.databases || []).length + ' ฐาน') : '—';
    document.getElementById('statTables').textContent = ok ? (ping.table_count || 0).toLocaleString() : '—';
    document.getElementById('statMs').textContent = ping && ping.ms != null ? (ping.ms + ' ms') : '—';
    fillDbList(ping && ping.databases ? ping.databases : []);
    const hint = document.getElementById('robotHint');
    const msg = (ping && (ping.hint || ping.error)) ? String(ping.hint || ping.error) : '';
    if (ok) {
        hint.innerHTML = '<div class="text-success"><i class="fas fa-check-circle me-1"></i>เชื่อมต่อ Robot OPD สำเร็จ</div>';
    } else if (msg) {
        hint.innerHTML = '<div class="alert alert-danger py-2 mb-0">' + esc(msg) + '</div>';
    } else {
        hint.innerHTML = '';
    }
}
function loadTables(q) {
    const box = document.getElementById('tableList');
    box.innerHTML = '<div class="text-muted small p-2">กำลังค้นหา…</div>';
    api('tables', { q: q || '' }).then(function (data) {
        const tables = data.tables || [];
        if (!tables.length) {
            box.innerHTML = '<div class="text-muted small p-2">ไม่พบตาราง — ระบุ Database Name แล้วบันทึกหรือทดสอบอีกครั้ง</div>';
            return;
        }
        box.innerHTML = tables.map(function (t) {
            return '<button type="button" class="list-group-item list-group-item-action py-1 px-2 font-monospace" data-table="' + esc(t) + '">' + esc(t) + '</button>';
        }).join('');
    }).catch(function () {
        box.innerHTML = '<div class="text-danger small p-2">โหลดรายการตารางไม่สำเร็จ</div>';
    });
}
function previewTable(table) {
    document.getElementById('previewEmpty').classList.add('d-none');
    document.getElementById('previewBox').classList.remove('d-none');
    document.getElementById('previewTitle').textContent = table;
    document.getElementById('previewHead').innerHTML = '';
    document.getElementById('previewBody').innerHTML = '<tr><td class="text-muted">กำลังอ่าน…</td></tr>';
    api('preview', { table: table }).then(function (data) {
        const preview = data.preview || {};
        const cols = preview.columns || [];
        const rows = preview.rows || [];
        if (preview.error) {
            document.getElementById('previewBody').innerHTML = '<tr><td class="text-danger">' + esc(preview.error) + '</td></tr>';
            return;
        }
        document.getElementById('previewHead').innerHTML = '<tr>' + cols.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') + '</tr>';
        if (!rows.length) {
            document.getElementById('previewBody').innerHTML = '<tr><td colspan="' + cols.length + '" class="text-muted">ไม่มีข้อมูล</td></tr>';
            return;
        }
        document.getElementById('previewBody').innerHTML = rows.map(function (r) {
            return '<tr>' + cols.map(function (c) { return '<td>' + esc(r[c]) + '</td>'; }).join('') + '</tr>';
        }).join('');
    }).catch(function () {
        document.getElementById('previewBody').innerHTML = '<tr><td class="text-danger">อ่านตัวอย่างไม่สำเร็จ</td></tr>';
    });
}
document.getElementById('btnTest').addEventListener('click', function () {
    const btn = this;
    const html = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังทดสอบ...';
    api('test').then(function (data) {
        applyPing(data.ping || {});
        alert((data.status === 'success' ? '✅ ' : '❌ ') + (data.message || ''));
        if (data.status === 'success') loadTables('');
        else document.getElementById('tableList').innerHTML = '<div class="text-danger small p-2">' + esc(data.message || 'เชื่อมต่อไม่ได้') + '</div>';
    }).catch(function (err) {
        alert('❌ ' + (err.message || 'ทดสอบไม่สำเร็จ'));
    }).finally(function () {
        btn.innerHTML = html;
        btn.disabled = false;
    });
});
document.getElementById('robotForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    const html = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังบันทึก...';
    api('save').then(function (data) {
        alert((data.status === 'success' ? '✅ ' : '❌ ') + (data.message || ''));
        if (data.status === 'success') api('test').then(function (t) {
            applyPing(t.ping || {});
            if (t.status === 'success') loadTables('');
        });
    }).catch(function () {
        alert('❌ บันทึกไม่สำเร็จ');
    }).finally(function () {
        btn.innerHTML = html;
        btn.disabled = false;
    });
});
let tmr = null;
document.getElementById('tableQ').addEventListener('input', function () {
    clearTimeout(tmr);
    const q = this.value.trim();
    tmr = setTimeout(function () { loadTables(q); }, 250);
});
document.getElementById('tableList').addEventListener('click', function (e) {
    const btn = e.target.closest('[data-table]');
    if (!btn) return;
    previewTable(btn.getAttribute('data-table'));
});
api('test').then(function (data) {
    applyPing(data.ping || {});
    if (data.status === 'success') loadTables('');
    else document.getElementById('tableList').innerHTML = '<div class="text-danger small p-2">' + esc(data.message || 'เชื่อมต่อไม่ได้') + '</div>';
}).catch(function () {
    document.getElementById('statStatus').textContent = 'ตรวจไม่ได้';
});
</script>
</body>
</html>
