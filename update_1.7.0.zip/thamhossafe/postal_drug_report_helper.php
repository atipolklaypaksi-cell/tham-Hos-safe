<?php
/**
 * รายงานการรับยาทางไปรษณีย์ — จาก UE form HOSxP
 * universal_form_id = 132 (แบบบันทึกเลขพัสดุ สำหรับส่งยาทางไปรษณีย์)
 * ตาม CUSTOM-รายงานการลงทะเบียนการรับยาไปรษณีย์ (คีย์ผ่าน UE)
 */
require_once __DIR__ . '/rational_lab_use_helper.php';

/** Universal Entry form สำหรับลงทะเบียนส่งยาทางไปรษณีย์ */
define('PDR_UE_FORM_ID', 132);
/** ฟิลด์ UE */
define('PDR_UE_ITEM_EMS', 2052);
define('PDR_UE_ITEM_TELE', 2053);
define('PDR_UE_ITEM_PROBLEM', 2054);
define('PDR_UE_ITEM_PAGE_FEEDBACK', 2055);
define('PDR_UE_ITEM_NOTE', 2056);

function pdr_normalize_granularity($g) {
    $g = strtolower(trim((string)$g));
    if (in_array($g, ['day', 'month', 'year'], true)) {
        return $g;
    }
    return 'day';
}

function pdr_sql_patient_name_expr($patient_alias = 'p') {
    return "CAST(CONVERT(CONCAT(
        IFNULL({$patient_alias}.pname, ''),
        IFNULL({$patient_alias}.fname, ''),
        ' ',
        IFNULL({$patient_alias}.lname, '')
    ) USING utf8) AS CHAR)";
}

function pdr_sql_clinic_name_expr() {
    return "CAST(CONVERT(COALESCE(
        NULLIF(TRIM(k.department), ''),
        NULLIF(TRIM(sp.name), ''),
        'ไม่ระบุ'
    ) USING utf8) AS CHAR)";
}

/** subquery ค่า text ของฟิลด์ UE หนึ่งรายการ */
function pdr_sql_ue_item_value($item_id, $alias) {
    $item_id = (int)$item_id;
    return "(
        SELECT CAST(CONVERT(IFNULL(ud.universal_item_value_text, '') USING utf8) AS CHAR)
        FROM universal_detail ud
        WHERE ud.universal_head_id = uh.universal_head_id
          AND ud.universal_item_id = {$item_id}
        LIMIT 1
    ) AS {$alias}";
}

function pdr_sql_base_from() {
    $form_id = (int)PDR_UE_FORM_ID;
    return "
        FROM universal_head uh
        LEFT JOIN ovst o ON o.vn = uh.vn
        LEFT JOIN patient p ON p.hn = COALESCE(NULLIF(TRIM(uh.hn), ''), o.hn)
        LEFT JOIN pttype pt ON pt.pttype = o.pttype
        LEFT JOIN kskdepartment k ON k.depcode = o.main_dep
        LEFT JOIN spclty sp ON sp.spclty = o.spclty
    ";
}

function pdr_sql_date_where($hos, $start_date, $end_date) {
    $start_esc = mysqli_real_escape_string($hos, $start_date);
    $end_esc = mysqli_real_escape_string($hos, $end_date);
    $form_id = (int)PDR_UE_FORM_ID;
    return "
        WHERE uh.universal_form_id = {$form_id}
          AND uh.entry_date >= '{$start_esc}'
          AND uh.entry_date <= '{$end_esc}'
    ";
}

function pdr_empty_summary() {
    return [
        'item_count' => 0,
        'patient_count' => 0,
        'visit_count' => 0,
        'item_count_display' => '0',
        'patient_count_display' => '0',
        'visit_count_display' => '0',
        'period_count' => 0,
    ];
}

function pdr_metric_diff($a, $b) {
    $a = (float)$a;
    $b = (float)$b;
    $diff = $b - $a;
    return [
        'diff' => $diff,
        'diff_display' => ($diff > 0 ? '+' : '') . rlu_format_number($diff),
        'pct' => rlu_format_pct_change($a, $b),
        'dir' => $diff > 0 ? 'up' : ($diff < 0 ? 'down' : 'flat'),
    ];
}

function pdr_fetch_period_summary($hos, $start_date, $end_date, $granularity = 'day') {
    $granularity = pdr_normalize_granularity($granularity);
    if ($granularity === 'year') {
        $bucket_expr = "DATE_FORMAT(uh.entry_date, '%Y')";
        $label_expr = $bucket_expr;
    } elseif ($granularity === 'month') {
        $bucket_expr = "DATE_FORMAT(uh.entry_date, '%Y-%m')";
        $label_expr = $bucket_expr;
    } else {
        $bucket_expr = "uh.entry_date";
        $label_expr = "DATE_FORMAT(uh.entry_date, '%Y-%m-%d')";
    }

    $sql = "
        SELECT
            $bucket_expr AS bucket_key,
            $label_expr AS period_label,
            COUNT(*) AS item_count,
            COUNT(DISTINCT COALESCE(NULLIF(TRIM(uh.hn), ''), o.hn)) AS patient_count,
            COUNT(DISTINCT uh.vn) AS visit_count
        " . pdr_sql_base_from() . "
        " . pdr_sql_date_where($hos, $start_date, $end_date) . "
        GROUP BY bucket_key, period_label
        ORDER BY bucket_key ASC
    ";
    $t0 = microtime(true);
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['rows' => [], 'error' => mysqli_error($hos), 'elapsed_ms' => 0];
    }
    $rows = [];
    while ($row = mysqli_fetch_assoc($q)) {
        $cnt = (int)($row['item_count'] ?? 0);
        $patients = (int)($row['patient_count'] ?? 0);
        $visits = (int)($row['visit_count'] ?? 0);
        $rows[] = [
            'period_key' => trim((string)($row['bucket_key'] ?? '')),
            'period_label' => trim((string)($row['period_label'] ?? '')),
            'item_count' => $cnt,
            'patient_count' => $patients,
            'visit_count' => $visits,
            'item_count_display' => rlu_format_number($cnt),
            'patient_count_display' => rlu_format_number($patients),
            'visit_count_display' => rlu_format_number($visits),
        ];
    }

    $sql_pat = "
        SELECT
            COUNT(*) AS item_count,
            COUNT(DISTINCT COALESCE(NULLIF(TRIM(uh.hn), ''), o.hn)) AS patient_count,
            COUNT(DISTINCT uh.vn) AS visit_count
        " . pdr_sql_base_from() . "
        " . pdr_sql_date_where($hos, $start_date, $end_date) . "
    ";
    $qp = mysqli_query($hos, $sql_pat);
    $totals = $qp ? mysqli_fetch_assoc($qp) : [];
    $total_patients = (int)($totals['patient_count'] ?? 0);
    $total_items = (int)($totals['item_count'] ?? 0);
    $total_visits = (int)($totals['visit_count'] ?? 0);

    return [
        'rows' => $rows,
        'summary' => [
            'item_count' => $total_items,
            'patient_count' => $total_patients,
            'visit_count' => $total_visits,
            'item_count_display' => rlu_format_number($total_items),
            'patient_count_display' => rlu_format_number($total_patients),
            'visit_count_display' => rlu_format_number($total_visits),
            'period_count' => count($rows),
        ],
        'granularity' => $granularity,
        'error' => '',
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
    ];
}

function pdr_fetch_clinic_summary($hos, $start_date, $end_date) {
    $clinic_expr = pdr_sql_clinic_name_expr();
    $sql = "
        SELECT
            IFNULL(o.main_dep, '') AS clinic_code,
            $clinic_expr AS clinic_name,
            COUNT(*) AS item_count,
            COUNT(DISTINCT COALESCE(NULLIF(TRIM(uh.hn), ''), o.hn)) AS patient_count,
            COUNT(DISTINCT uh.vn) AS visit_count
        " . pdr_sql_base_from() . "
        " . pdr_sql_date_where($hos, $start_date, $end_date) . "
        GROUP BY clinic_code, clinic_name
        ORDER BY item_count DESC, clinic_name ASC
    ";
    $t0 = microtime(true);
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['rows' => [], 'error' => mysqli_error($hos), 'elapsed_ms' => 0];
    }
    $rows = [];
    $total_items = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $cnt = (int)($row['item_count'] ?? 0);
        $patients = (int)($row['patient_count'] ?? 0);
        $visits = (int)($row['visit_count'] ?? 0);
        $total_items += $cnt;
        $rows[] = [
            'clinic_code' => trim((string)($row['clinic_code'] ?? '')),
            'clinic_name' => trim((string)($row['clinic_name'] ?? '')) ?: 'ไม่ระบุ',
            'item_count' => $cnt,
            'patient_count' => $patients,
            'visit_count' => $visits,
            'item_count_display' => rlu_format_number($cnt),
            'patient_count_display' => rlu_format_number($patients),
            'visit_count_display' => rlu_format_number($visits),
        ];
    }
    foreach ($rows as &$r) {
        $pct = $total_items > 0 ? ($r['item_count'] * 100.0 / $total_items) : 0;
        $r['pct_share'] = $pct;
        $r['pct_share_display'] = rlu_format_number($pct, 1) . '%';
    }
    unset($r);

    return [
        'rows' => $rows,
        'error' => '',
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
    ];
}

function pdr_fetch_detail_rows($hos, $start_date, $end_date, $limit = 5000) {
    $limit = max(1, min(10000, (int)$limit));
    $name_expr = pdr_sql_patient_name_expr('p');
    $clinic_expr = pdr_sql_clinic_name_expr();
    $sql = "
        SELECT
            uh.universal_head_id,
            uh.entry_date AS rx_date,
            DATE_FORMAT(uh.entry_date, '%Y-%m-%d') AS rx_date_display,
            TIME_FORMAT(uh.entry_time, '%H:%i') AS rx_time,
            $name_expr AS patient_name,
            COALESCE(NULLIF(TRIM(uh.hn), ''), o.hn) AS hn,
            uh.vn,
            CAST(CONVERT(COALESCE(NULLIF(TRIM(pt.name), ''), o.pttype, 'ไม่ระบุ') USING utf8) AS CHAR) AS pttype_name,
            $clinic_expr AS clinic_name,
            " . pdr_sql_ue_item_value(PDR_UE_ITEM_EMS, 'ems_track') . ",
            " . pdr_sql_ue_item_value(PDR_UE_ITEM_TELE, 'tele_status') . ",
            " . pdr_sql_ue_item_value(PDR_UE_ITEM_PROBLEM, 'tele_comment') . ",
            " . pdr_sql_ue_item_value(PDR_UE_ITEM_PAGE_FEEDBACK, 'page_feedback') . ",
            " . pdr_sql_ue_item_value(PDR_UE_ITEM_NOTE, 'note') . ",
            CAST(CONVERT(IFNULL(uh.staff, '') USING utf8) AS CHAR) AS staff
        " . pdr_sql_base_from() . "
        " . pdr_sql_date_where($hos, $start_date, $end_date) . "
        ORDER BY uh.entry_date ASC, uh.entry_time ASC, uh.universal_head_id ASC
        LIMIT $limit
    ";
    $t0 = microtime(true);
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['rows' => [], 'error' => mysqli_error($hos), 'elapsed_ms' => 0, 'truncated' => false];
    }
    $rows = [];
    $n = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $n++;
        $rows[] = [
            'row_no' => $n,
            'universal_head_id' => (int)($row['universal_head_id'] ?? 0),
            'rx_date' => trim((string)($row['rx_date'] ?? '')),
            'rx_date_display' => trim((string)($row['rx_date_display'] ?? '')),
            'rx_time' => trim((string)($row['rx_time'] ?? '')),
            'patient_name' => trim((string)($row['patient_name'] ?? '')),
            'hn' => trim((string)($row['hn'] ?? '')),
            'vn' => trim((string)($row['vn'] ?? '')),
            'pttype_name' => trim((string)($row['pttype_name'] ?? '')),
            'clinic_name' => trim((string)($row['clinic_name'] ?? '')),
            'ems_track' => trim((string)($row['ems_track'] ?? '')),
            'tele_status' => trim((string)($row['tele_status'] ?? '')),
            'tele_comment' => trim((string)($row['tele_comment'] ?? '')),
            'page_feedback' => trim((string)($row['page_feedback'] ?? '')),
            'note' => trim((string)($row['note'] ?? '')),
            'staff' => trim((string)($row['staff'] ?? '')),
        ];
    }
    return [
        'rows' => $rows,
        'error' => '',
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
        'truncated' => count($rows) >= $limit,
        'limit' => $limit,
    ];
}

function pdr_build_compare_block(array $period_reports, $compare_mode, $peer_compare) {
    $compare_mode = trim((string)$compare_mode);
    $rows = [];
    foreach ($period_reports as $pi => $pr) {
        $sum = $pr['summary'] ?? pdr_empty_summary();
        $period = $pr['period'] ?? [];
        $row = [
            'index' => $pi,
            'label' => $period['label'] ?? ('ช่วง ' . ($pi + 1)),
            'start_date' => $period['start_date'] ?? '',
            'end_date' => $period['end_date'] ?? '',
            'item_count' => (int)($sum['item_count'] ?? 0),
            'patient_count' => (int)($sum['patient_count'] ?? 0),
            'visit_count' => (int)($sum['visit_count'] ?? 0),
            'item_count_display' => $sum['item_count_display'] ?? rlu_format_number((int)($sum['item_count'] ?? 0)),
            'patient_count_display' => $sum['patient_count_display'] ?? rlu_format_number((int)($sum['patient_count'] ?? 0)),
            'visit_count_display' => $sum['visit_count_display'] ?? rlu_format_number((int)($sum['visit_count'] ?? 0)),
        ];
        if ($pi > 0 && !empty($period_reports[0]['summary'])) {
            $base = $period_reports[0]['summary'];
            $dItems = pdr_metric_diff($base['item_count'] ?? 0, $row['item_count']);
            $dPatients = pdr_metric_diff($base['patient_count'] ?? 0, $row['patient_count']);
            $dVisits = pdr_metric_diff($base['visit_count'] ?? 0, $row['visit_count']);
            $row['diff_item_count'] = $dItems['diff'];
            $row['diff_item_count_display'] = $dItems['diff_display'];
            $row['pct_item_count'] = $dItems['pct'];
            $row['diff_item_dir'] = $dItems['dir'];
            $row['diff_patient_count'] = $dPatients['diff'];
            $row['diff_patient_count_display'] = $dPatients['diff_display'];
            $row['pct_patient_count'] = $dPatients['pct'];
            $row['diff_patient_dir'] = $dPatients['dir'];
            $row['diff_visit_count'] = $dVisits['diff'];
            $row['diff_visit_count_display'] = $dVisits['diff_display'];
            $row['pct_visit_count'] = $dVisits['pct'];
            $row['diff_visit_dir'] = $dVisits['dir'];
        }
        $rows[] = $row;
    }

    $label_a = $rows[0]['label'] ?? 'ช่วง A';
    $label_b = $rows[1]['label'] ?? 'ช่วง B';
    $out = [
        'enabled' => true,
        'mode' => $compare_mode !== '' ? $compare_mode : 'prev_year',
        'peer_compare' => (bool)$peer_compare,
        'multi' => count($rows) > 2,
        'label_a' => $label_a,
        'label_b' => $label_b,
        'labels' => array_column($rows, 'label'),
        'rows' => $rows,
        'chart' => [
            'labels' => array_column($rows, 'label'),
            'item_counts' => array_map(static function ($r) { return (int)$r['item_count']; }, $rows),
            'patient_counts' => array_map(static function ($r) { return (int)$r['patient_count']; }, $rows),
            'visit_counts' => array_map(static function ($r) { return (int)$r['visit_count']; }, $rows),
        ],
    ];

    if (count($period_reports) === 2 && !$peer_compare) {
        $aRows = $period_reports[0]['buckets'] ?? [];
        $bRows = $period_reports[1]['buckets'] ?? [];
        $n = max(count($aRows), count($bRows));
        $labels = [];
        $aItems = [];
        $bItems = [];
        for ($i = 0; $i < $n; $i++) {
            $a = $aRows[$i] ?? null;
            $b = $bRows[$i] ?? null;
            $labels[] = ($a['period_label'] ?? null) ?: ($b['period_label'] ?? ('#' . ($i + 1)));
            $aItems[] = $a ? (int)$a['item_count'] : 0;
            $bItems[] = $b ? (int)$b['item_count'] : 0;
        }
        $out['aligned_chart'] = [
            'labels' => $labels,
            'datasets' => [
                ['label' => $label_a, 'data' => $aItems],
                ['label' => $label_b, 'data' => $bItems],
            ],
        ];
    }

    return $out;
}

function pdr_build_report($hos, $start_date, $end_date, $granularity = 'day', $include_detail = true, array $options = []) {
    $period = rlu_parse_period($start_date, $end_date);
    $start_date = $period['start_date'];
    $end_date = $period['end_date'];
    $granularity = pdr_normalize_granularity($granularity);

    $compare_enabled = !empty($options['compare']);
    $compare_mode = trim((string)($options['compare_mode'] ?? 'prev_year'));
    $compare_params = [
        'compare_years' => $options['compare_years'] ?? '',
        'compare_months' => $options['compare_months'] ?? '',
        'compare_start' => $options['compare_start'] ?? '',
        'compare_end' => $options['compare_end'] ?? '',
    ];
    $peer = $compare_enabled && rlu_is_peer_compare_mode($compare_mode, $compare_params);
    $periods = rlu_resolve_detail_periods($start_date, $end_date, $compare_enabled, $compare_mode, $compare_params);
    if (empty($periods)) {
        $periods = [$period];
    }

    $period_reports = [];
    $elapsed = 0;
    foreach ($periods as $p) {
        $sum = pdr_fetch_period_summary($hos, $p['start_date'], $p['end_date'], $granularity);
        $elapsed += (int)($sum['elapsed_ms'] ?? 0);
        if (($sum['error'] ?? '') !== '') {
            return [
                'status' => 'error',
                'message' => $sum['error'],
                'period' => $p,
            ];
        }
        $period_reports[] = [
            'period' => $p,
            'summary' => $sum['summary'] ?? pdr_empty_summary(),
            'buckets' => $sum['rows'] ?? [],
        ];
    }

    $primary = $period_reports[0];

    $clinic = pdr_fetch_clinic_summary($hos, $primary['period']['start_date'], $primary['period']['end_date']);
    $elapsed += (int)($clinic['elapsed_ms'] ?? 0);
    if (($clinic['error'] ?? '') !== '') {
        return [
            'status' => 'error',
            'message' => $clinic['error'],
            'period' => $primary['period'],
        ];
    }

    $detail = ['rows' => [], 'elapsed_ms' => 0, 'truncated' => false, 'limit' => 0];
    if ($include_detail) {
        $detail = pdr_fetch_detail_rows($hos, $primary['period']['start_date'], $primary['period']['end_date']);
        $elapsed += (int)($detail['elapsed_ms'] ?? 0);
        if (($detail['error'] ?? '') !== '') {
            return [
                'status' => 'error',
                'message' => $detail['error'],
                'period' => $primary['period'],
            ];
        }
    }

    $compare = null;
    if ($compare_enabled && count($period_reports) >= 2) {
        $compare = pdr_build_compare_block($period_reports, $compare_mode, $peer);
    }

    return [
        'status' => 'success',
        'period' => $primary['period'],
        'granularity' => $granularity,
        'summary' => $primary['summary'],
        'periods' => $primary['buckets'],
        'clinics' => $clinic['rows'],
        'details' => $detail['rows'],
        'compare' => $compare,
        'meta' => [
            'source' => 'hosxp_ue_form_132',
            'source_label' => 'UE form: แบบบันทึกเลขพัสดุ สำหรับส่งยาทางไปรษณีย์',
            'universal_form_id' => (int)PDR_UE_FORM_ID,
            'compare_enabled' => $compare_enabled && $compare !== null,
            'compare_mode' => $compare_mode,
            'peer_compare' => $peer,
            'period_count' => count($period_reports),
            'clinic_count' => count($clinic['rows']),
            'detail_truncated' => !empty($detail['truncated']),
            'detail_limit' => (int)($detail['limit'] ?? 0),
            'elapsed_ms' => $elapsed,
            'detail_period_label' => $primary['period']['label'] ?? '',
        ],
    ];
}
