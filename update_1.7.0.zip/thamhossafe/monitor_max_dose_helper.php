<?php
/**
 * Monitor Max Dose / Duration — helper
 */

function mmdd_ensure_table($con) {
    $q = mysqli_query($con, "SHOW TABLES LIKE 'monitor_max_dose_settings'");
    if ($q && mysqli_num_rows($q) > 0) {
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_max_dose.sql');
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '' && !mysqli_query($con, $stmt)) {
            return false;
        }
    }
    return true;
}

function mmdd_alert_level($row) {
    return (($row['alert_level'] ?? '') === 'soft') ? 'soft' : 'hard';
}

function mmdd_alert_badge_html($level) {
    if ($level === 'hard') {
        return '<span class="badge bg-danger">Hard Alert</span>';
    }
    return '<span class="badge bg-warning text-dark">Soft Alert</span>';
}

function mmdd_h1_adult_alert_message($drug_label) {
    $drug_label = trim((string)$drug_label) ?: 'ยานี้';
    return $drug_label . ' เกิน Max 10 mg/วัน (ผู้ใหญ่) — ไม่ควรสั่ง 1 เม็ด TID แบบ CPM';
}

function mmdd_h1_adult_detail_text($drug_label) {
    $drug_label = trim((string)$drug_label) ?: 'Loratadine / Cetirizine';
    return $drug_label . ' เป็นยาแก้แพ้รุ่นใหม่ (2nd generation) ขนาดผู้ใหญ่ไม่เกิน 10 mg/วัน'
        . ' ไม่ควรสั่งจ่าย 1 เม็ด วันละ 3 ครั้ง (TID) เหมือน CPM ซึ่งเป็นยาแก้แพ้รุ่นเก่า'
        . ' เพราะเพิ่มผลข้างเคียง เช่น ปากแห้ง ใจสั่น ปัสสาวะคั่ง และง่วงซึมรุนแรง';
}

function mmdd_h1_adult_match_defs() {
    return [
        [
            'label' => 'Loratadine',
            'keys' => ['loratadine', 'clarityne', 'claritin', 'ลอราทาดีน', 'ลอราตาดีน'],
            'exclude' => ['desloratadine', 'เดสลอรา'],
        ],
        [
            'label' => 'Cetirizine',
            'keys' => ['cetirizine', 'cetirizin', 'cetrizine', 'zyrtec', 'เซทิริซีน', 'ซีไตรซีน', 'เซติริซีน'],
            'exclude' => ['levocetirizine', 'เลโวเซทิ', 'เลโวซีไตร'],
        ],
    ];
}

function mmdd_h1_text_has_any($hay, array $needles) {
    $hay_l = strtolower($hay);
    foreach ($needles as $n) {
        $n = trim((string)$n);
        if ($n === '') {
            continue;
        }
        if (preg_match('/^[\x20-\x7e]+$/', $n)) {
            if (strpos($hay_l, strtolower($n)) !== false) {
                return true;
            }
        } elseif (strpos($hay, $n) !== false) {
            return true;
        }
    }
    return false;
}

/** เฉพาะเม็ด/แคปซูล — ไม่เฝ้าระวังน้ำเชื่อม/ฉีด เพื่อลด false alert ในเด็ก */
function mmdd_h1_is_oral_solid($drug) {
    $blob = strtolower(trim(($drug['name_local'] ?? '') . ' ' . ($drug['name_tmt'] ?? '')));
    foreach (['syrup', 'syup', 'susp', 'inj', 'cream', 'oint', 'drop', 'eye', 'mg/ml', 'mg/5', 'มล.', 'ไซรัป', 'น้ำเชื่อม', 'ฉีด'] as $skip) {
        if ($skip !== '' && strpos($blob, strtolower($skip)) !== false) {
            return false;
        }
        if (strpos(trim(($drug['name_local'] ?? '') . ' ' . ($drug['name_tmt'] ?? '')), $skip) !== false) {
            return false;
        }
    }
    return true;
}

/**
 * ใส่กฎ Loratadine / Cetirizine Max 10 mg/วัน (ผู้ใหญ่)
 * @return array{added:int, updated:int, skipped:int, missing:array}
 */
function mmdd_seed_h1_adult_max_dose($con, array $hosxp_drugs) {
    mmdd_ensure_table($con);
    $stats = ['added' => 0, 'updated' => 0, 'skipped' => 0, 'missing' => []];
    if (empty($hosxp_drugs)) {
        $stats['missing'] = ['Loratadine', 'Cetirizine'];
        return $stats;
    }

    foreach (mmdd_h1_adult_match_defs() as $def) {
        $matched = [];
        foreach ($hosxp_drugs as $d) {
            $icode = trim((string)($d['icode'] ?? ''));
            if ($icode === '') {
                continue;
            }
            $hay = trim(($d['name_tmt'] ?? '') . ' ' . ($d['name_local'] ?? ''));
            if ($hay === '' || !mmdd_h1_text_has_any($hay, $def['keys'])) {
                continue;
            }
            if (mmdd_h1_text_has_any($hay, $def['exclude'])) {
                continue;
            }
            if (!mmdd_h1_is_oral_solid($d)) {
                continue;
            }
            $name = trim((string)($d['name_tmt'] ?? ''));
            if ($name === '') {
                $name = trim((string)($d['name_local'] ?? $def['label']));
            }
            $matched[$icode] = $name;
        }
        if (empty($matched)) {
            $stats['missing'][] = $def['label'];
            continue;
        }
        $msg = mmdd_h1_adult_alert_message($def['label']);
        $detail = mmdd_h1_adult_detail_text($def['label']);
        foreach ($matched as $icode => $drug_name) {
            $ic_esc = mysqli_real_escape_string($con, $icode);
            $name_esc = mysqli_real_escape_string($con, $drug_name);
            $msg_esc = mysqli_real_escape_string($con, $msg);
            $det_esc = mysqli_real_escape_string($con, $detail);
            $chk = mysqli_query($con, "SELECT id, max_dose_mg_per_day, alert_message, detail_text FROM monitor_max_dose_settings WHERE icode='$ic_esc' LIMIT 1");
            $row = $chk ? mysqli_fetch_assoc($chk) : null;
            if (!$row) {
                $ok = mysqli_query($con, "INSERT INTO monitor_max_dose_settings
                    (icode, drug_name, max_dose_mg_per_day, max_duration_days, alert_level, alert_message, detail_text, active)
                    VALUES ('$ic_esc', '$name_esc', 10, 0, 'hard', '$msg_esc', '$det_esc', 1)");
                if ($ok) {
                    $stats['added']++;
                } else {
                    $stats['skipped']++;
                }
                continue;
            }
            $msg_empty = trim((string)($row['alert_message'] ?? '')) === '';
            $det_empty = trim((string)($row['detail_text'] ?? '')) === '';
            if (!$msg_empty && !$det_empty) {
                $stats['skipped']++;
                continue;
            }
            $id = (int)$row['id'];
            $sets = ["drug_name='$name_esc'"];
            if ($msg_empty) {
                $sets[] = "alert_message='$msg_esc'";
            }
            if ($det_empty) {
                $sets[] = "detail_text='$det_esc'";
            }
            $ok = mysqli_query($con, 'UPDATE monitor_max_dose_settings SET ' . implode(', ', $sets) . " WHERE id=$id");
            if ($ok) {
                $stats['updated']++;
            } else {
                $stats['skipped']++;
            }
        }
    }
    if (($stats['added'] + $stats['updated']) > 0 && function_exists('sp_monitor_settings_changed')) {
        sp_monitor_settings_changed($con, 'max_dose');
    }
    return $stats;
}

function mmdd_load_active_rules($con, array $rule_ids = []) {
    mmdd_ensure_table($con);
    $rules = [];
    $q = mysqli_query($con, "SELECT * FROM monitor_max_dose_settings WHERE active = 1 ORDER BY drug_name ASC");
    if (!$q) {
        return $rules;
    }
    $filter = [];
    foreach ($rule_ids as $rid) {
        $rid = (int)$rid;
        if ($rid > 0) {
            $filter[$rid] = true;
        }
    }
    while ($row = mysqli_fetch_assoc($q)) {
        if (!empty($filter) && !isset($filter[(int)$row['id']])) {
            continue;
        }
        $icode = trim($row['icode'] ?? '');
        if ($icode === '') {
            continue;
        }
        if ((float)($row['max_dose_mg_per_day'] ?? 0) <= 0 && (int)($row['max_duration_days'] ?? 0) <= 0) {
            continue;
        }
        $rules[] = $row;
    }
    return $rules;
}

function mmdd_rule_is_valid(array $data) {
    $max_dose = (float)($data['max_dose_mg_per_day'] ?? 0);
    $max_days = (int)($data['max_duration_days'] ?? 0);
    if ($max_dose <= 0 && $max_days <= 0) {
        return ['ok' => false, 'error' => 'กรุณาระบุ Max Dose (mg/วัน) หรือ Max Duration (วัน) อย่างน้อย 1 ค่า'];
    }
    if ($max_dose < 0) {
        return ['ok' => false, 'error' => 'Max Dose ต้องมากกว่า 0'];
    }
    if ($max_days < 0) {
        return ['ok' => false, 'error' => 'Max Duration ต้องไม่ติดลบ'];
    }
    return ['ok' => true, 'error' => ''];
}

function mmdd_rules_duration_icodes(array $rules) {
    $out = [];
    foreach ($rules as $r) {
        if ((int)($r['max_duration_days'] ?? 0) <= 0) {
            continue;
        }
        $ic = trim((string)($r['icode'] ?? ''));
        if ($ic !== '') {
            $out[$ic] = true;
        }
    }
    return array_keys($out);
}

function mmdd_duration_lookback_days(array $rules) {
    $max = 0;
    foreach ($rules as $r) {
        $d = (int)($r['max_duration_days'] ?? 0);
        if ($d > $max) {
            $max = $d;
        }
    }
    if ($max <= 0) {
        return 0;
    }
    return min(90, max(21, $max + 14));
}

function mmdd_icode_needs_duration(array $rules_for_icode) {
    foreach ($rules_for_icode as $r) {
        if ((int)($r['max_duration_days'] ?? 0) > 0) {
            return true;
        }
    }
    return false;
}

/**
 * ดึงวันที่สั่งยาของคู่ HN+icode ที่ต้องเช็ค Duration รวมเป็นชุด แทนการยิงทีละราย
 */
function mmdd_prefetch_rx_dates($hos, array $pairs, $until_date, $lookback_days, array &$cache) {
    $until_date = trim((string)$until_date);
    $lookback_days = (int)$lookback_days;
    if (!$hos || $lookback_days <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $until_date)) {
        return 0;
    }
    if ($lookback_days > 90) {
        $lookback_days = 90;
    }
    $from_date = date('Y-m-d', strtotime($until_date . ' -' . $lookback_days . ' days'));
    if (!$from_date) {
        return 0;
    }
    $hn_set = [];
    $ic_set = [];
    $wanted = [];
    foreach ($pairs as $pair) {
        $hn = '';
        $icode = '';
        if (is_string($pair)) {
            $bits = explode('|', $pair, 2);
            $hn = trim((string)($bits[0] ?? ''));
            $icode = trim((string)($bits[1] ?? ''));
        } elseif (is_array($pair)) {
            $hn = trim((string)($pair['hn'] ?? $pair[0] ?? ''));
            $icode = trim((string)($pair['icode'] ?? $pair[1] ?? ''));
        }
        if ($hn === '' || $icode === '') {
            continue;
        }
        $store = $hn . '|' . $icode;
        $wanted[$store] = true;
        $hn_set[$hn] = true;
        $ic_set[$icode] = true;
    }
    if (!$wanted) {
        return 0;
    }
    $cache['_lookback'] = $lookback_days;
    $hn_list = array_keys($hn_set);
    $ic_sql = [];
    foreach (array_keys($ic_set) as $ic) {
        $ic_sql[] = "'" . mysqli_real_escape_string($hos, $ic) . "'";
    }
    $until_esc = mysqli_real_escape_string($hos, $until_date);
    $from_esc = mysqli_real_escape_string($hos, $from_date);
    $chunk = 80;
    $queries = 0;
    for ($i = 0, $n = count($hn_list); $i < $n; $i += $chunk) {
        $slice = array_slice($hn_list, $i, $chunk);
        $hn_sql = [];
        foreach ($slice as $hn) {
            $hn_sql[] = "'" . mysqli_real_escape_string($hos, $hn) . "'";
        }
        $sql = "SELECT o.hn, o.icode, o.rxdate
            FROM opitemrece o
            WHERE o.hn IN (" . implode(',', $hn_sql) . ")
              AND o.icode IN (" . implode(',', $ic_sql) . ")
              AND o.qty > 0
              AND o.rxdate BETWEEN '$from_esc' AND '$until_esc'
            GROUP BY o.hn, o.icode, o.rxdate";
        $q = mysqli_query($hos, $sql);
        $queries++;
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $hn = trim((string)($r['hn'] ?? ''));
            $ic = trim((string)($r['icode'] ?? ''));
            $d = trim((string)($r['rxdate'] ?? ''));
            if ($hn === '' || $ic === '' || $d === '' || $d === '0000-00-00') {
                continue;
            }
            $store = $hn . '|' . $ic;
            if (!isset($cache['_rx'][$store])) {
                $cache['_rx'][$store] = [];
            }
            $cache['_rx'][$store][$d] = true;
            $prev = (string)($cache['_until'][$store] ?? '');
            if ($prev === '' || $prev < $until_date) {
                $cache['_until'][$store] = $until_date;
            }
        }
    }
    foreach (array_keys($wanted) as $store) {
        if (!isset($cache['_rx'][$store])) {
            $cache['_rx'][$store] = [];
        }
        $prev = (string)($cache['_until'][$store] ?? '');
        if ($prev === '' || $prev < $until_date) {
            $cache['_until'][$store] = $until_date;
        }
    }
    return $queries;
}

/**
 * นับวันสั่งยาติดต่อกันย้อนหลังจากวันที่สั่ง (รวมวันนั้น)
 */
function mmdd_consecutive_days($hos, $hn, $icode, $as_of_date, array &$cache = []) {
    $hn = trim((string)$hn);
    $icode = trim((string)$icode);
    $as_of_date = trim((string)$as_of_date);
    if ($hn === '' || $icode === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $as_of_date)) {
        return 0;
    }
    $store = $hn . '|' . $icode;
    if (!isset($cache['_rx'][$store]) || (string)($cache['_until'][$store] ?? '') < $as_of_date) {
        $lookback = (int)($cache['_lookback'] ?? 90);
        if ($lookback < 7) {
            $lookback = 7;
        }
        if ($lookback > 90) {
            $lookback = 90;
        }
        $hn_esc = mysqli_real_escape_string($hos, $hn);
        $ic_esc = mysqli_real_escape_string($hos, $icode);
        $as_of_esc = mysqli_real_escape_string($hos, $as_of_date);
        $q = mysqli_query($hos, "SELECT DISTINCT o.rxdate
            FROM opitemrece o
            WHERE o.hn = '$hn_esc'
              AND o.icode = '$ic_esc'
              AND o.qty > 0
              AND o.rxdate <= '$as_of_esc'
              AND o.rxdate >= DATE_SUB('$as_of_esc', INTERVAL $lookback DAY)");
        $date_set = [];
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $d = trim((string)($r['rxdate'] ?? ''));
                if ($d !== '' && $d !== '0000-00-00') {
                    $date_set[$d] = true;
                }
            }
        }
        $cache['_rx'][$store] = $date_set;
        $cache['_until'][$store] = $as_of_date;
    }
    $date_set = $cache['_rx'][$store];
    $key = $store . '|' . $as_of_date;
    if (isset($cache[$key])) {
        return $cache[$key];
    }
    if (empty($date_set[$as_of_date])) {
        $cache[$key] = 0;
        return 0;
    }
    $count = 0;
    $cur = strtotime($as_of_date);
    while ($cur && isset($date_set[date('Y-m-d', $cur)])) {
        $count++;
        $cur -= 86400;
    }
    $cache[$key] = $count;
    return $count;
}

function mmdd_build_trigger_reasons(array $rule, $daily_mg, $consecutive_days) {
    $reasons = [];
    $max_dose = (float)($rule['max_dose_mg_per_day'] ?? 0);
    $max_days = (int)($rule['max_duration_days'] ?? 0);
    if ($max_dose > 0 && $daily_mg !== null && $daily_mg > $max_dose) {
        $reasons[] = 'dose';
    }
    if ($max_days > 0 && $consecutive_days > $max_days) {
        $reasons[] = 'duration';
    }
    return $reasons;
}

function mmdd_default_alert_message(array $rule, array $reasons, $daily_mg, $consecutive_days) {
    $custom = trim((string)($rule['alert_message'] ?? ''));
    if ($custom !== '') {
        return $custom;
    }
    $parts = [];
    $max_dose = (float)($rule['max_dose_mg_per_day'] ?? 0);
    $max_days = (int)($rule['max_duration_days'] ?? 0);
    if (in_array('dose', $reasons, true)) {
        $calc = $daily_mg !== null ? rtrim(rtrim(number_format($daily_mg, 2, '.', ''), '0'), '.') : '?';
        $parts[] = "ขนาดรวม {$calc} mg/วัน เกิน Max Dose {$max_dose} mg/วัน";
    }
    if (in_array('duration', $reasons, true)) {
        $parts[] = "สั่งยาติดต่อกัน {$consecutive_days} วัน เกิน Max Duration {$max_days} วัน";
    }
    return implode(' | ', $parts) ?: 'เกินขีดจำกัด Max Dose/Duration';
}
