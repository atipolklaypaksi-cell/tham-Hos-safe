<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
include('connect.php');
session_write_close();
include('hosxp_tmt_drug_helper.php');
mysqli_set_charset($con, 'utf8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$raw = json_decode(file_get_contents('php://input'), true);
$hn = trim($raw['hn'] ?? '');
$order_date = trim($raw['order_date'] ?? date('Y-m-d'));
$icodes = isset($raw['icodes']) && is_array($raw['icodes']) ? $raw['icodes'] : [];

if ($hn === '' || empty($icodes)) {
    echo json_encode(['status' => 'success', 'alerts' => []]);
    exit;
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $order_date)) {
    $order_date = date('Y-m-d');
}

$selected = [];
foreach ($icodes as $c) {
    $v = trim((string)$c);
    if ($v !== '') {
        $selected[$v] = true;
    }
}
if (empty($selected)) {
    echo json_encode(['status' => 'success', 'alerts' => []]);
    exit;
}

$con_hosxp = hosxp_connect($con);
if (!$con_hosxp) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อฐานข้อมูล HOSxP ได้']);
    exit;
}

$q_rules = mysqli_query($con, "SELECT * FROM monitor_drug_interaction_settings WHERE active_status = 1");
$raw_rules = [];
while ($q_rules && ($row = mysqli_fetch_assoc($q_rules))) {
    $drug_icode = trim((string)($row['drug_icode'] ?? ''));
    $hosxp_icode = trim((string)($row['hosxp_icode'] ?? ''));
    if ($drug_icode === '' || $hosxp_icode === '') {
        continue;
    }
    $raw_rules[] = $row;
}
$raw_rules = di_prepare_rules_icodes($con_hosxp, $raw_rules);
$rules = [];
foreach ($raw_rules as $row) {
    $hit = false;
    foreach ($row['_icodes_a'] ?? [] as $ic) {
        if (isset($selected[$ic])) {
            $hit = true;
            break;
        }
    }
    if ($hit) {
        $rules[] = $row;
    }
}

if (empty($rules)) {
    mysqli_close($con_hosxp);
    echo json_encode(['status' => 'success', 'alerts' => []]);
    exit;
}

$all_icodes = di_rules_scan_icodes($rules);
if (empty($all_icodes)) {
    mysqli_close($con_hosxp);
    echo json_encode(['status' => 'success', 'alerts' => []]);
    exit;
}

$need_dose_mg = di_rules_need_dose_mg($rules);
$window = di_compute_query_window($order_date, $order_date, $rules);
[$raw_rows] = di_fetch_hosxp_orders($con_hosxp, $all_icodes, $window['query_start'], date('Y-m-d', strtotime($order_date . ' + 30 days')), $need_dose_mg, [$hn], 5000);
mysqli_close($con_hosxp);

$prepared_all = di_prepare_orders($raw_rows, $need_dose_mg);
$prepared_rows = di_prepare_orders(di_dedupe_latest_orders($raw_rows), $need_dose_mg);
[$by_icode, $by_vn_icode, $by_hn_icode] = di_reindex_orders_fast($prepared_rows);
[$by_icode_all] = di_reindex_orders_fast($prepared_all);
$idx = [
    'by_icode' => $by_icode,
    'by_vn_icode' => $by_vn_icode,
    'by_hn_icode' => $by_hn_icode,
    'by_icode_all' => $by_icode_all,
];

$drug_names = [];
foreach ($prepared_all as $row) {
    $ic = trim((string)($row['icode'] ?? ''));
    if ($ic !== '' && !isset($drug_names[$ic])) {
        $drug_names[$ic] = trim($row['drug_name'] ?? '') ?: $ic;
    }
}

$alerts = [];
$seen = [];

foreach ($rules as $rule) {
    $level = (!empty($rule['alert_level']) && $rule['alert_level'] === 'hard') ? 'hard' : 'soft';
    $type = ($level === 'hard') ? 'DI Hard Alert' : 'DI Soft Alert';
    di_each_matching_pair($rule, $idx, ['date_eq' => $order_date], function ($o1, $o2, $check_mode, $lookback_days, $c1, $c2) use ($rule, $level, $type, $drug_names, &$alerts, &$seen) {
        $drug1_name = $drug_names[$o1['icode'] ?? ''] ?? ($rule['drug_name'] ?? '');
        $drug2_name = $drug_names[$o2['icode'] ?? ''] ?? ($rule['hosxp_drug_name'] ?? '');
        $alert = di_build_alert($rule, $o1, $o2, $level, $check_mode, $lookback_days, '', $drug1_name, $drug2_name, $c1, $c2);
        $msg = trim((string)($rule['detail_text'] ?? 'พบปฏิกิริยาระหว่างยา'));
        $full = $drug1_name . ' + ' . $drug2_name . ' | ' . $msg . ' | ' . ($alert['check_mode_label'] ?? '');
        $k = md5($type . '|' . $full);
        if (isset($seen[$k])) {
            return;
        }
        $seen[$k] = true;
        $alerts[] = [
            'level' => $level,
            'type' => $type,
            'title' => $type,
            'message' => $full,
        ];
    });
}

echo json_encode(['status' => 'success', 'alerts' => $alerts]);
exit;
