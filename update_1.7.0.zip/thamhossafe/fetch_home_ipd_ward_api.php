<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/home_ipd_ward_helper.php';

if (!hiw_can_view($con)) {
    echo json_encode([
        'status' => 'error',
        'msg' => 'แสดงเฉพาะเมื่อเลือกห้องจ่ายยาผู้ป่วยใน',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

session_write_close();

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? 'overview'));
$flags = JSON_UNESCAPED_UNICODE;
if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
    $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
}

if ($action === 'queue') {
    $kind = trim((string)($_GET['kind'] ?? $_POST['kind'] ?? 'pending_key'));
    $limit = (int)($_GET['limit'] ?? $_POST['limit'] ?? 200);
    $queue = hiw_list_order_queue($con, $kind, $limit);
    $out = json_encode([
        'status' => !empty($queue['ok']) ? 'success' : 'error',
        'msg' => !empty($queue['ok']) ? 'ok' : ($queue['error'] ?? 'โหลดคิวไม่สำเร็จ'),
        'data' => $queue,
    ], $flags);
    echo $out !== false ? $out : '{"status":"error","msg":"encode failed","data":null}';
    exit;
}

if ($action === 'timing_history') {
    $dateTo = trim((string)($_GET['to'] ?? $_POST['to'] ?? date('Y-m-d')));
    $dateFrom = trim((string)($_GET['from'] ?? $_POST['from'] ?? ''));
    if ($dateFrom === '') {
        $dateFrom = date('Y-m-d', strtotime($dateTo . ' -6 days'));
    }
    $hist = hiw_fetch_timing_history($con, $dateFrom, $dateTo);
    $out = json_encode([
        'status' => !empty($hist['ok']) ? 'success' : 'error',
        'msg' => !empty($hist['ok']) ? 'ok' : ($hist['error'] ?? 'โหลดประวัติไม่สำเร็จ'),
        'data' => $hist,
    ], $flags);
    echo $out !== false ? $out : '{"status":"error","msg":"encode failed","data":null}';
    exit;
}

$force = !empty($_GET['force']) || !empty($_POST['force']);
$data = hiw_get_overview($con, $force);

$out = json_encode([
    'status' => !empty($data['ok']) ? 'success' : 'error',
    'msg' => !empty($data['ok']) ? 'ok' : ($data['error'] ?? 'โหลดไม่สำเร็จ'),
    'data' => $data,
], $flags);
if ($out === false) {
    $out = '{"status":"error","msg":"encode failed","data":null}';
}
echo $out;
