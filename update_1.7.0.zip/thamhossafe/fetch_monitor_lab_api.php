<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('connect.php');
include('hosxp_tmt_drug_helper.php');
require_once __DIR__ . '/monitor_lab_hepatic_dosing_helper.php';
mysqli_set_charset($con, 'utf8');

set_time_limit(180);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

function monitor_lab_req($key, $default = '') {
    if (isset($_POST[$key]) && (is_string($_POST[$key]) || is_numeric($_POST[$key]))) {
        return trim((string)$_POST[$key]);
    }
    if (isset($_GET[$key]) && (is_string($_GET[$key]) || is_numeric($_GET[$key]))) {
        return trim((string)$_GET[$key]);
    }
    return $default;
}

ob_clean();
header('Content-Type: application/json; charset=utf-8');

$organ_raw = monitor_lab_req('organ', 'renal');
$organ = in_array($organ_raw, ['renal', 'hepatic', 'other'], true) ? $organ_raw : 'renal';
$renal_lab_types = ['GFR', 'CKD_EPI', 'SERUM_CR'];
$hepatic_lab_types = ['Bilirubin', 'Bilirubin_xULN', 'DirectBilirubin', 'IndirectBilirubin', 'AST', 'ALT', 'AST_xULN', 'ALT_xULN', 'AST_ALT_xULN', 'CHILD_PUGH', 'MELD_NA'];
$other_lab_types = ['CUSTOM'];
$organ_lab_types = ($organ === 'renal') ? $renal_lab_types : (($organ === 'hepatic') ? $hepatic_lab_types : $other_lab_types);
ensure_drug_safety_rules_lab_items_columns($con);
ensure_drug_safety_rules_lab_condition_columns($con);
ensure_drug_safety_rules_patient_extra_columns($con);
ensure_drug_safety_rules_duration_columns($con);
ensure_drug_safety_rules_dose_per_admin_columns($con);
ensure_drug_safety_rules_exempt_method_columns($con);
ensure_drug_safety_rules_first_order_columns($con);

$start_date = monitor_lab_req('start_date', date('Y-m-d', strtotime('-30 days')));
$end_date = monitor_lab_req('end_date', date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-30 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if ($start_date > $end_date) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$max_rows = 12000;
$max_prescriptions = 4000;
$response = [
    'status' => 'success',
    'hard_alerts' => [],
    'soft_alerts' => [],
    'prescriptions' => [],
    'meta' => [
        'organ' => $organ,
        'rule_count' => 0,
        'rules_selected' => 0,
        'rules_total' => 0,
        'orders_scanned' => 0,
        'orders_unique' => 0,
        'truncated' => false,
        'hard_count' => 0,
        'soft_count' => 0,
        'alert_count' => 0,
        'prescriptions_count' => 0,
        'prescriptions_ok' => 0,
        'prescriptions_alert' => 0,
        'prescriptions_no_lab' => 0,
        'prescriptions_truncated' => false,
    ],
    'score_details' => [],
];

$has_drug_icode_col = ensure_drug_safety_rules_hosxp_columns($con);
ensure_drug_safety_rules_alert_level_column($con);
if ($has_drug_icode_col) {
    $rules_sql = "SELECT r.*,
            COALESCE(NULLIF(TRIM(r.drug_name), ''), d.name) AS drug_name,
            COALESCE(NULLIF(TRIM(r.drug_icode), ''), d.icode) AS icode
        FROM drug_safety_rules r
        LEFT JOIN drugitems d ON r.drug_id = d.id
        WHERE r.active_status = 1";
} else {
    $rules_sql = "SELECT r.*, d.name AS drug_name, d.icode AS icode
        FROM drug_safety_rules r
        INNER JOIN drugitems d ON r.drug_id = d.id
        WHERE r.active_status = 1";
}
$q_rules = mysqli_query($con, $rules_sql);
$all_rules = [];
$icodes = [];
$icode_to_drugid = [];
$rules_total = 0;

while ($r = mysqli_fetch_assoc($q_rules)) {
    if (!in_array($r['lab_type'], $organ_lab_types, true)) {
        continue;
    }
    $icode = trim($r['icode'] ?? '');
    if ($icode === '') {
        continue;
    }
    if ($organ === 'other' && trim($r['lab_items_code'] ?? '') === '') {
        continue;
    }
    $all_rules[$icode][] = $r;
    $icodes[] = $icode;
    $rules_total++;
}
$icodes = array_values(array_unique($icodes));

$rules = $all_rules;
$rule_ids_param = monitor_lab_req('rule_ids', '');
if ($rule_ids_param !== '') {
    $allowed_ids = [];
    foreach (explode(',', $rule_ids_param) as $rid) {
        $rid = (int)trim($rid);
        if ($rid > 0) {
            $allowed_ids[$rid] = true;
        }
    }
    if (!empty($allowed_ids)) {
        $filtered = [];
        foreach ($all_rules as $icode => $icode_rules) {
            foreach ($icode_rules as $rule) {
                if (!isset($allowed_ids[(int)$rule['id']])) {
                    continue;
                }
                $filtered[$icode][] = $rule;
            }
        }
        $rules = $filtered;
        $icodes = array_keys($rules);
    }
}

$rules_selected = 0;
foreach ($rules as $icode_rules) {
    $rules_selected += count($icode_rules);
}
$response['meta']['rule_count'] = $rules_selected;
$response['meta']['rules_selected'] = $rules_selected;
$response['meta']['rules_total'] = $rules_total;

if ($rules_selected === 0) {
    echo json_encode([
        'status' => 'error',
        'message' => 'ไม่ได้เลือกกฎที่ต้องการรายงาน — กรุณาเลือกอย่างน้อย 1 รายการยา',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if (empty($rules) || empty($icodes)) {
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

$icode_map_sql = "'" . implode("','", array_map(function ($v) use ($con) {
    return mysqli_real_escape_string($con, $v);
}, $icodes)) . "'";
$q_drug_map = mysqli_query($con, "SELECT id, icode FROM drugitems WHERE icode IN ($icode_map_sql)");
if ($q_drug_map) {
    while ($dm = mysqli_fetch_assoc($q_drug_map)) {
        $icode_to_drugid[trim($dm['icode'])] = (int)$dm['id'];
    }
}

$need_drug_ids = [];
foreach ($icodes as $ic) {
    if (!empty($icode_to_drugid[$ic])) {
        $need_drug_ids[] = (int)$icode_to_drugid[$ic];
    }
}
$need_drug_ids = array_values(array_unique($need_drug_ids));
$max_doses = [];
if (!empty($need_drug_ids)) {
    $did_sql = implode(',', $need_drug_ids);
    $q_pd = mysqli_query($con, "SELECT drug_item_id, dose, unit FROM protocol_drugs WHERE drug_item_id IN ($did_sql) ORDER BY dose DESC");
    while ($r = mysqli_fetch_assoc($q_pd)) {
        $did = (int)$r['drug_item_id'];
        if (!isset($max_doses[$did])) {
            $max_doses[$did] = ['dose' => (float)$r['dose'], 'unit' => trim($r['unit'])];
        }
    }
}

$q_config = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name LIKE 'h\\_%' OR config_name LIKE 'lab\\_%'");
$sys = [];
while ($r = mysqli_fetch_assoc($q_config)) {
    $sys[$r['config_name']] = $r['config_value'];
}

$api_started = microtime(true);
$hos = hosxp_connect($con);
if (!$hos) {
    echo json_encode(['status' => 'error', 'message' => 'Connect HOSxP Failed'], JSON_UNESCAPED_UNICODE);
    exit;
}

// ดึง Lab ย้อนหลังไม่เกิน 4 ปีก่อนวันสั่งยา
$lab_lookback_years = 4;
$lab_min_date = date('Y-m-d', strtotime($start_date . " -{$lab_lookback_years} years"));

function monitor_lab_prefetch_vitals($hos, array $hn_padded_list, $tbl, $fld_bw, $fld_height, $min_date, $max_date) {
    $cache = [];
    if (empty($hn_padded_list)) {
        return $cache;
    }
    $min_esc = mysqli_real_escape_string($hos, $min_date);
    $max_esc = mysqli_real_escape_string($hos, $max_date);
    $per_hn_cap = 12;

    foreach (array_chunk(array_values(array_unique($hn_padded_list)), 80) as $hn_chunk) {
        $hn_in = "'" . implode("','", array_map(function ($h) use ($hos) {
            return mysqli_real_escape_string($hos, $h);
        }, $hn_chunk)) . "'";
        $sql = "SELECT hn, vstdate, $fld_bw AS bw, $fld_height AS height
            FROM $tbl
            WHERE hn IN ($hn_in)
              AND $fld_bw > 0
              AND vstdate >= '$min_esc'
              AND vstdate <= '$max_esc'
            ORDER BY hn, vstdate DESC";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $hn_key = ltrim($r['hn'], '0');
            if (!isset($cache[$hn_key])) {
                $cache[$hn_key] = [];
            }
            if (count($cache[$hn_key]) >= $per_hn_cap) {
                continue;
            }
            $cache[$hn_key][] = [
                'vstdate' => $r['vstdate'],
                'bw' => (float)$r['bw'],
                'height' => (float)$r['height'],
            ];
        }
    }
    return $cache;
}

function monitor_lab_get_vitals_from_cache(array $cache, $hn, $order_date) {
    $hn_key = ltrim($hn, '0');
    foreach ($cache[$hn_key] ?? [] as $row) {
        if ($row['vstdate'] <= $order_date) {
            $w = $row['bw'];
            $h = $row['height'];
            $bsa = ($w > 0 && $h > 0) ? sqrt(($w * $h) / 3600) : 0;
            return ['w' => $w, 'h' => $h, 'bsa' => $bsa];
        }
    }
    return ['w' => 0, 'h' => 0, 'bsa' => 0];
}

$icode_string = "'" . implode("','", array_map(function ($v) use ($hos) {
    return mysqli_real_escape_string($hos, $v);
}, $icodes)) . "'";
$start_esc = mysqli_real_escape_string($hos, $start_date);
$end_esc = mysqli_real_escape_string($hos, $end_date);

$method_expr = di_sql_method_expr('o');
$hn_raw = function_exists('monitor_req_hn') ? monitor_req_hn() : monitor_lab_req('hn', '');
$hn_clause = function_exists('monitor_hn_sql_clause') ? monitor_hn_sql_clause($hos, $hn_raw, 'o.hn') : '';
$strength_expr = ($organ === 'hepatic')
    ? "CAST(CONVERT(d.strength USING utf8) AS CHAR) AS strength"
    : "CAST(CONVERT(COALESCE(NULLIF(TRIM(tm.strength), ''), d.strength) USING utf8) AS CHAR) AS strength";
$tmt_join = ($organ === 'hepatic') ? '' : "LEFT JOIN tmt_tpu_code tm ON d.tpu_code_list = tm.tpu_code";
$method_joins = di_sql_method_joins('o');
if ($organ === 'hepatic') {
    $method_expr = "CAST(CONVERT(IF(o.sp_use <> '' AND o.sp_use IS NOT NULL, CONCAT(IFNULL(sp.name1,''),' ',IFNULL(sp.name2,''),' ',IFNULL(sp.name3,'')), TRIM(CONCAT(IFNULL(du.name1,''),' ',IFNULL(du.name2,''),' ',IFNULL(du.name3,'')))) USING utf8) AS CHAR)";
    $method_joins = "LEFT JOIN drugusage du ON du.drugusage = o.drugusage
            LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use";
}
$sql_hosxp = "
    SELECT o.hn, o.an, o.vn, o.vstdate, o.vsttime, o.rxdate, o.rxtime,
        CAST(CONVERT(CONCAT(IFNULL(pt.pname, ''), IFNULL(pt.fname, ''), ' ', IFNULL(pt.lname, '')) USING utf8) AS CHAR) AS ptname,
        pt.sex AS gender, pt.birthday AS dob, o.icode, o.qty,
        $strength_expr,
        CAST(CONVERT(d.units USING utf8) AS CHAR) AS units,
        $method_expr AS method,
        CAST(CONVERT(IFNULL(w.name, '') USING utf8) AS CHAR) AS ward_name
    FROM opitemrece o
    INNER JOIN patient pt ON pt.hn = o.hn
    INNER JOIN drugitems d ON d.icode = o.icode
    $tmt_join
    LEFT JOIN ipt i ON i.an = o.an AND o.an <> '' AND o.an <> '0'
    LEFT JOIN ward w ON w.ward = i.ward
    $method_joins
    WHERE o.icode IN ($icode_string)
      AND o.qty > 0
      AND o.vstdate >= '$start_esc'
      AND o.vstdate <= '$end_esc'
      $hn_clause
    ORDER BY o.vstdate DESC, o.rxdate DESC, o.rxtime DESC, o.vsttime DESC
    LIMIT $max_rows
";

$q_orders = mysqli_query($hos, $sql_hosxp);
if (!$q_orders) {
    mysqli_close($hos);
    mysqli_close($con);
    echo json_encode(['status' => 'error', 'message' => 'SQL Error: ' . mysqli_error($hos)], JSON_UNESCAPED_UNICODE);
    exit;
}

$orders = [];
$orders_scanned = 0;
while ($row = mysqli_fetch_assoc($q_orders)) {
    $orders_scanned++;
    $orders[] = $row;
}
$truncated = ($orders_scanned >= $max_rows);
$response['meta']['orders_scanned'] = $orders_scanned;
$response['meta']['truncated'] = $truncated;

$need_first_order = false;
$max_first_lookback = 0;
foreach ($rules as $icode_rules) {
    foreach ($icode_rules as $rule) {
        if (!empty($rule['first_order_only'])) {
            $need_first_order = true;
            $max_first_lookback = max($max_first_lookback, (int)($rule['first_order_lookback_days'] ?? 0));
        }
    }
}
$first_order_map = [];
if ($need_first_order && !empty($orders)) {
    $fo_hns = [];
    $fo_icodes = [];
    foreach ($orders as $pat) {
        $ic = trim((string)($pat['icode'] ?? ''));
        $has_fo = false;
        foreach ($rules[$ic] ?? [] as $rule) {
            if (!empty($rule['first_order_only'])) {
                $has_fo = true;
                break;
            }
        }
        if ($has_fo) {
            $fo_hns[] = $pat['hn'] ?? '';
            $fo_icodes[$ic] = true;
        }
    }
    $first_order_map = monitor_lab_prefetch_first_orders(
        $hos,
        $fo_hns,
        array_keys($fo_icodes),
        $end_date,
        $max_first_lookback,
        $start_date
    );
}

if (empty($orders)) {
    mysqli_close($hos);
    mysqli_close($con);
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

$hn_padded = [];
$hn_list = [];
foreach ($orders as $pat) {
    $hn_padded[] = str_pad($pat['hn'], 9, '0', STR_PAD_LEFT);
    $hn_list[] = ltrim($pat['hn'], '0');
}
$hn_padded_unique = array_values(array_unique($hn_padded));

$rule_lab_types = [];
foreach ($rules as $icode_rules) {
    foreach ($icode_rules as $rule) {
        $rule_lab_types[$rule['lab_type']] = true;
    }
}

$tbl_vital = !empty($sys['h_tbl_vital']) ? $sys['h_tbl_vital'] : 'opdscreen';
$fld_bw = !empty($sys['h_fld_bw']) ? $sys['h_fld_bw'] : 'bw';
$fld_height = !empty($sys['h_fld_height']) ? $sys['h_fld_height'] : 'height';

$lab_codes = [];
$need_vitals = false;
if ($organ === 'other') {
    foreach ($rules as $icode_rules) {
        foreach ($icode_rules as $rule) {
            $c = trim($rule['lab_items_code'] ?? '');
            if ($c !== '') {
                $lab_codes[] = $c;
            }
        }
    }
    $lab_codes = array_values(array_unique($lab_codes));
} elseif ($organ === 'renal') {
    if ((!empty($rule_lab_types['GFR']) || !empty($rule_lab_types['SERUM_CR'])) && !empty($sys['h_code_scr'])) {
        $lab_codes[] = $sys['h_code_scr'];
    }
    if (!empty($rule_lab_types['GFR'])) {
        $need_vitals = true;
    }
    if (!empty($rule_lab_types['CKD_EPI']) && !empty($sys['h_code_ckd_epi'])) {
        $lab_codes[] = $sys['h_code_ckd_epi'];
    }
    foreach ($rules as $icode_rules) {
        foreach ($icode_rules as $rule) {
            if (!empty($rule['use_weight_condition'])) {
                $need_vitals = true;
                break 2;
            }
        }
    }
    $lab_codes = array_values(array_unique($lab_codes));
} else {
    $hepatic_code_map = [
        'AST' => $sys['h_code_ast'] ?? '',
        'AST_xULN' => $sys['h_code_ast'] ?? '',
        'ALT' => $sys['h_code_alt'] ?? '',
        'ALT_xULN' => $sys['h_code_alt'] ?? '',
        'Bilirubin' => $sys['h_code_tbili'] ?? '',
        'Bilirubin_xULN' => $sys['h_code_tbili'] ?? '',
        'DirectBilirubin' => $sys['h_code_dbili'] ?? '',
        'IndirectBilirubin' => $sys['h_code_ibili'] ?? '',
        'AST_ALT_xULN' => $sys['h_code_ast'] ?? '',
        'CHILD_PUGH' => $sys['h_code_tbili'] ?? '',
        'MELD_NA' => $sys['h_code_tbili'] ?? '',
    ];
    foreach (array_keys($rule_lab_types) as $lt) {
        if (!empty($hepatic_code_map[$lt])) {
            $lab_codes[] = $hepatic_code_map[$lt];
        }
        if ($lt === 'AST_ALT_xULN' && !empty($sys['h_code_alt'])) {
            $lab_codes[] = $sys['h_code_alt'];
        }
        if ($lt === 'CHILD_PUGH' || $lt === 'MELD_NA') {
            foreach (['h_code_albumin', 'h_code_inr', 'h_code_scr', 'h_code_na'] as $ck) {
                if (!empty($sys[$ck])) {
                    $lab_codes[] = $sys[$ck];
                }
            }
        }
    }
    $lab_codes = array_values(array_unique(array_filter($lab_codes)));
}

$lab_fetch_memo = [];
$vital_cache = $need_vitals
    ? monitor_lab_prefetch_vitals($hos, $hn_padded_unique, $tbl_vital, $fld_bw, $fld_height, $lab_min_date, $end_date)
    : [];
$tbili_uln = (float)($sys['lab_tbili_uln'] ?? 1.2);
$ast_uln = (float)($sys['lab_ast_uln'] ?? 40);
$alt_uln = (float)($sys['lab_alt_uln'] ?? 40);
if ($tbili_uln <= 0) {
    $tbili_uln = 1.2;
}
if ($ast_uln <= 0) {
    $ast_uln = 40;
}
if ($alt_uln <= 0) {
    $alt_uln = 40;
}

$hepatic_clinical = [];
$hepatic_lab_prefetch = [];
$hepatic_did_prefetch = false;
$need_hepatic_scores = ($organ === 'hepatic') && (!empty($rule_lab_types['CHILD_PUGH']) || !empty($rule_lab_types['MELD_NA']));
$hepatic_lft_types = [];
if ($organ === 'hepatic') {
    foreach (array_keys($rule_lab_types) as $lt) {
        if ($lt !== 'CHILD_PUGH' && $lt !== 'MELD_NA') {
            $hepatic_lft_types[$lt] = true;
        }
    }
}
$hepatic_only_scores = $need_hepatic_scores && empty($hepatic_lft_types);
if ($organ === 'hepatic' && !empty($hn_padded_unique) && !empty($lab_codes)) {
    $prefetch_min = $hepatic_only_scores
        ? date('Y-m-d', strtotime($start_date . ' -90 days'))
        : date('Y-m-d', strtotime($start_date . ' -365 days'));
    $hepatic_lab_prefetch = monitor_lab_prefetch_hn_labs(
        $hos,
        $hn_padded_unique,
        $lab_codes,
        $prefetch_min,
        $end_date,
        $hepatic_only_scores ? 6 : 8
    );
    $hepatic_did_prefetch = true;
}
if ($need_hepatic_scores) {
    $hepatic_clinical = monitor_lab_hepatic_prefetch_clinical($hos, $hn_padded_unique, $end_date);
}

$lab_pick = static function ($hn, $code, $order_date, $order_time, $min_date, $cutoff) use ($hos, &$hepatic_lab_prefetch, &$lab_fetch_memo, $organ, $hepatic_did_prefetch) {
    $code = trim((string)$code);
    if ($code === '') {
        return ['value' => 0, 'raw' => '', 'date' => '-', 'time' => ''];
    }
    if ($organ === 'hepatic' && $hepatic_did_prefetch) {
        return monitor_lab_pick_prefetched($hepatic_lab_prefetch, $hn, $code, $order_date, $order_time);
    }
    return monitor_lab_get_lab_for_order($hos, $lab_fetch_memo, $hn, $code, $order_date, $order_time, $min_date, $cutoff);
};

$processed_patients = [];
$processed_drug_checks = [];
$orders_unique = 0;

foreach ($orders as $pat) {
    $hn = ltrim($pat['hn'], '0');
    $icode = trim($pat['icode']);
    if (!isset($rules[$icode])) {
        continue;
    }
    $drug_id = $icode_to_drugid[$icode] ?? 0;
    $order_dt = monitor_lab_order_datetime($pat);
    $order_date = $order_dt['date'];
    $order_time_raw = $order_dt['time'];
    $vstdate = trim((string)($pat['vstdate'] ?? ''));
    if ($vstdate === '' || $vstdate === '0000-00-00') {
        $vstdate = $order_date;
    }
    // Lab lookback ต่อรายการ: ไม่เกิน 4 ปีก่อนวันสั่งยา (rxdate)
    $order_lab_min = ($order_date !== '' && $order_date !== '0000-00-00')
        ? date('Y-m-d', strtotime($order_date . " -{$lab_lookback_years} years"))
        : $lab_min_date;

    $check_key = $hn . '_' . $icode . '_' . $order_date . '_' . monitor_lab_normalize_hosxp_time($order_time_raw);
    if (isset($processed_drug_checks[$check_key])) {
        continue;
    }
    $processed_drug_checks[$check_key] = true;
    $orders_unique++;

    $order_time_str = di_format_time($order_time_raw);
    $ident_an = trim((string)($pat['an'] ?? ''));
    $ident_vn = trim((string)($pat['vn'] ?? ''));
    $ident = [
        'organ' => $organ,
        'icode' => $icode,
        'an' => $ident_an,
        'vn' => $ident_vn,
        'type_patient' => monitor_lab_patient_type($ident_an, $ident_vn),
        'qty' => $pat['qty'] ?? '',
        'order_date_iso' => $order_date,
        'ward_name' => trim((string)($pat['ward_name'] ?? '')),
    ];
    $cache_key = $hn . '_' . $order_date . '_' . ($order_time_str !== '' ? $order_time_str : '00:00');

    if (!isset($processed_patients[$cache_key])) {
        $pt_age = monitor_lab_patient_age_years($pat['dob'] ?? '', $order_date);

        if ($organ === 'other') {
            $patient_labs = [
                'BSA' => 0,
                'Weight' => 0,
                'ptname' => trim($pat['ptname']),
            ];
            foreach ($lab_codes as $code) {
                $lab_data = monitor_lab_get_lab_for_order($hos, $lab_fetch_memo, $pat['hn'], $code, $order_date, $order_time_raw, $order_lab_min, $vstdate);
                $patient_labs[$code] = [
                    'val' => round($lab_data['value'], 4),
                    'raw' => $lab_data['raw'] ?? '',
                    'date' => $lab_data['date'],
                    'time' => $lab_data['time'],
                ];
            }
            $processed_patients[$cache_key] = $patient_labs;
        } elseif ($organ === 'renal') {
            $w = 0;
            $h = 0;
            $bsa = 0;
            if ($need_vitals) {
                $vitals = monitor_lab_get_vitals_from_cache($vital_cache, $pat['hn'], $order_date);
                $w = $vitals['w'];
                $h = $vitals['h'];
                $bsa = $vitals['bsa'];
            }

            $patient_labs = [
                'BSA' => $bsa,
                'Weight' => $w,
                'Age' => $pt_age,
                'ptname' => trim($pat['ptname']),
            ];

            $scr_data = ['value' => 0, 'date' => '-', 'time' => ''];
            if ((!empty($rule_lab_types['GFR']) || !empty($rule_lab_types['SERUM_CR'])) && !empty($sys['h_code_scr'])) {
                $scr_data = monitor_lab_get_lab_for_order($hos, $lab_fetch_memo, $pat['hn'], $sys['h_code_scr'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate);
            }

            if (!empty($rule_lab_types['GFR'])) {
                $gfr = 0;
                if ($pt_age > 0 && $w > 0 && $scr_data['value'] > 0) {
                    $gfr = ((140 - $pt_age) * $w) / (72 * $scr_data['value']);
                    if ($pat['gender'] == '2') {
                        $gfr = $gfr * 0.85;
                    }
                }
                $patient_labs['GFR'] = ['val' => round($gfr, 2), 'date' => $scr_data['date'], 'time' => $scr_data['time']];
            }
            if (!empty($rule_lab_types['SERUM_CR'])) {
                $patient_labs['SERUM_CR'] = ['val' => round($scr_data['value'], 2), 'date' => $scr_data['date'], 'time' => $scr_data['time']];
            }
            if (!empty($rule_lab_types['CKD_EPI'])) {
                $ckd_epi_data = monitor_lab_get_lab_for_order($hos, $lab_fetch_memo, $pat['hn'], $sys['h_code_ckd_epi'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate);
                $patient_labs['CKD_EPI'] = ['val' => round($ckd_epi_data['value'], 2), 'date' => $ckd_epi_data['date'], 'time' => $ckd_epi_data['time']];
            }

            $processed_patients[$cache_key] = $patient_labs;
        } else {
            $lab_empty = ['value' => 0, 'raw' => '', 'date' => '-', 'time' => ''];
            $need_ast = !empty($rule_lab_types['AST']) || !empty($rule_lab_types['AST_xULN']) || !empty($rule_lab_types['AST_ALT_xULN']);
            $need_alt = !empty($rule_lab_types['ALT']) || !empty($rule_lab_types['ALT_xULN']) || !empty($rule_lab_types['AST_ALT_xULN']);
            $need_tbili = !empty($rule_lab_types['Bilirubin']) || !empty($rule_lab_types['Bilirubin_xULN']) || $need_hepatic_scores;
            $need_dbili = !empty($rule_lab_types['DirectBilirubin']);
            $need_ibili = !empty($rule_lab_types['IndirectBilirubin']);
            $ast_data = $need_ast
                ? $lab_pick($pat['hn'], $sys['h_code_ast'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate)
                : $lab_empty;
            $alt_data = $need_alt
                ? $lab_pick($pat['hn'], $sys['h_code_alt'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate)
                : $lab_empty;
            $tbili_data = $need_tbili
                ? $lab_pick($pat['hn'], $sys['h_code_tbili'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate)
                : $lab_empty;
            $dbili_data = $need_dbili
                ? $lab_pick($pat['hn'], $sys['h_code_dbili'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate)
                : $lab_empty;
            $ibili_data = $need_ibili
                ? $lab_pick($pat['hn'], $sys['h_code_ibili'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate)
                : $lab_empty;

            $tbili_x = ($tbili_data['value'] > 0) ? round($tbili_data['value'] / $tbili_uln, 2) : 0;
            $ast_x = ($ast_data['value'] > 0) ? round($ast_data['value'] / $ast_uln, 2) : 0;
            $alt_x = ($alt_data['value'] > 0) ? round($alt_data['value'] / $alt_uln, 2) : 0;
            $max_x = max($ast_x, $alt_x);
            $max_x_date = ($ast_x >= $alt_x) ? $ast_data['date'] : $alt_data['date'];
            $max_x_time = ($ast_x >= $alt_x) ? $ast_data['time'] : $alt_data['time'];
            if ($max_x <= 0) {
                $max_x_date = '-';
                $max_x_time = '';
            }

            $processed_patients[$cache_key] = [
                'AST' => ['val' => $ast_data['value'], 'date' => $ast_data['date'], 'time' => $ast_data['time']],
                'ALT' => ['val' => $alt_data['value'], 'date' => $alt_data['date'], 'time' => $alt_data['time']],
                'Bilirubin' => ['val' => $tbili_data['value'], 'date' => $tbili_data['date'], 'time' => $tbili_data['time']],
                'Bilirubin_xULN' => ['val' => $tbili_x, 'date' => $tbili_data['date'], 'time' => $tbili_data['time']],
                'DirectBilirubin' => ['val' => $dbili_data['value'], 'date' => $dbili_data['date'], 'time' => $dbili_data['time']],
                'IndirectBilirubin' => ['val' => $ibili_data['value'], 'date' => $ibili_data['date'], 'time' => $ibili_data['time']],
                'AST_xULN' => ['val' => $ast_x, 'date' => $ast_data['date'], 'time' => $ast_data['time']],
                'ALT_xULN' => ['val' => $alt_x, 'date' => $alt_data['date'], 'time' => $alt_data['time']],
                'AST_ALT_xULN' => ['val' => $max_x, 'date' => $max_x_date, 'time' => $max_x_time],
                'BSA' => 0,
                'Weight' => 0,
                'ptname' => trim($pat['ptname']),
            ];
            if ($need_hepatic_scores) {
                $score_inputs = [
                    'tbili' => $tbili_data,
                    'albumin' => $lab_pick($pat['hn'], $sys['h_code_albumin'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate),
                    'inr' => $lab_pick($pat['hn'], $sys['h_code_inr'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate),
                    'scr' => $lab_pick($pat['hn'], $sys['h_code_scr'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate),
                    'na' => $lab_pick($pat['hn'], $sys['h_code_na'] ?? '', $order_date, $order_time_raw, $order_lab_min, $vstdate),
                ];
                $clinical = monitor_lab_hepatic_clinical_for_hn($hepatic_clinical, $pat['hn']);
                $score = monitor_lab_hepatic_compute_scores($score_inputs, $clinical);
                foreach (monitor_lab_hepatic_score_lab_slots($score) as $sk => $slot) {
                    $processed_patients[$cache_key][$sk] = $slot;
                }
            }
        }
    }

    $labs = $processed_patients[$cache_key];
    $patient_bsa = $labs['BSA'];
    $patient_wt = $labs['Weight'];
    $patient_age = $labs['Age'] ?? 0;

    $base_dose = 0;
    $base_unit = 'mg';
    if (isset($max_doses[$drug_id])) {
        $base_dose = $max_doses[$drug_id]['dose'];
        $base_unit = $max_doses[$drug_id]['unit'];
    }

    $dose_parsed = hosxp_parse_drug_daily_dose_mg([
        'qty' => $pat['qty'],
        'strength' => $pat['strength'] ?? '',
        'units' => $pat['units'] ?? '',
        'method' => $pat['method'] ?? '',
    ]);
    $per_admin_parsed = hosxp_parse_drug_per_admin_dose_mg([
        'qty' => $pat['qty'],
        'strength' => $pat['strength'] ?? '',
        'units' => $pat['units'] ?? '',
        'method' => $pat['method'] ?? '',
    ]);
    $actual_dose_val = ($dose_parsed['mg_dose'] !== null) ? (float)$dose_parsed['mg_dose'] : 0;
    $has_active_order = ($dose_parsed['mg_dose'] !== null && $dose_parsed['mg_dose'] > 0)
        || ($dose_parsed['pill_qty'] !== null && $dose_parsed['pill_qty'] > 0)
        || ((float)$pat['qty'] > 0);
    $actual_dose_str = hosxp_format_actual_dose_display($dose_parsed);
    $actual_dose_per_admin_str = hosxp_format_actual_dose_display($per_admin_parsed);
    $actual_dose_per_admin_out = ($actual_dose_per_admin_str !== '-') ? $actual_dose_per_admin_str : '';
    $order_date_str = date('d/m/Y', strtotime($pat['vstdate']));
    $drug_method = trim($pat['method'] ?? '');
    $icode_exempt_hit = monitor_lab_match_exempt_method_from_rules($drug_method, $rules[$icode]);

    foreach ($rules[$icode] as $rule) {
        $lab_type = $rule['lab_type'];
        $lab_key = ($organ === 'other') ? trim($rule['lab_items_code'] ?? '') : $lab_type;
        $cond_type = trim($rule['lab_condition_type'] ?? 'range');
        if ($cond_type === '') {
            $cond_type = 'range';
        }
        $cond_val = trim($rule['lab_condition_value'] ?? '');
        $min = (float)$rule['min_val'];
        $max = (float)$rule['max_val'];

        if ($lab_key === '' || !isset($labs[$lab_key])) {
            continue;
        }
        $current_val = $labs[$lab_key]['val'];
        $current_raw = $labs[$lab_key]['raw'] ?? '';
        $current_date = $labs[$lab_key]['date'];
        $current_time = $labs[$lab_key]['time'] ?? '';

        $lab_matched = false;
        $lab_value_display = $current_val;
        $lab_value_is_text = false;
        $has_lab_result = false;

        if ($organ === 'other' && $cond_type !== 'range') {
            $has_lab_result = ($current_raw !== '');
            $lab_value_display = $has_lab_result ? $current_raw : '-';
            $lab_value_is_text = true;
            if ($has_lab_result && monitor_lab_match_condition($cond_type, $cond_val, $current_raw)) {
                $lab_matched = true;
            }
        } else {
            $has_lab_result = ($current_raw !== '')
                || ($current_date !== '-' && $current_date !== '')
                || ((float)$current_val > 0);
            if ($current_val > 0 && $current_val >= $min && $current_val <= $max) {
                $lab_matched = true;
            }
        }
        $lab_display = trim((string)($labs[$lab_key]['display'] ?? ''));
        $score_key = '';
        if (function_exists('monitor_lab_hepatic_is_score_type') && monitor_lab_hepatic_is_score_type($lab_type)) {
            $score_key = $cache_key;
            if ($score_key !== '' && !isset($response['score_details'][$score_key])) {
                $response['score_details'][$score_key] = [
                    'display' => $lab_display,
                    'components' => is_array($labs[$lab_key]['components'] ?? null) ? $labs[$lab_key]['components'] : [],
                ];
            }
            if ($lab_display !== '') {
                $lab_value_display = $lab_display;
                $lab_value_is_text = true;
                $has_lab_result = ((float)$current_val > 0) || $lab_display !== '';
            }
        }

        // รายงานการสั่งใช้ยา: รวมทุกรายการ (แม้ Lab ปกติ / ไม่มี Lab)
        // ข้อยกเว้นใช้ร่วมกันทุกกฎของยา icode เดียวกัน (เช่น ADD PD ที่กฎ eGFR 10–20 ใช้กับแถบ 0–10 ด้วย)
        $exempt_hit = $icode_exempt_hit;
        $duration_chk = monitor_lab_duration_check($rule, $drug_method);
        $first_chk = monitor_lab_first_order_check($rule, $first_order_map, $hn, $icode, $order_date, $order_time_raw);
        $alert_level_for_rx = monitor_lab_alert_level_from_rule($rule);
        if ($exempt_hit !== '') {
            $rx_status = 'ok';
            $rx_status_text = 'ยกเว้น (วิธีใช้มีคำว่า ' . $exempt_hit . ')';
        } elseif (!$has_lab_result) {
            $rx_status = 'no_lab';
            $rx_status_text = 'ไม่มีผล Lab ก่อนสั่งยา';
        } elseif ($lab_matched) {
            if (!empty($first_chk['skip_alert'])) {
                $rx_status = 'ok';
                $rx_status_text = $first_chk['text'];
            } elseif (!empty($duration_chk['skip_alert'])) {
                $rx_status = 'ok';
                $rx_status_text = 'เหมาะสม (ช่วงให้ยาอยู่ในเกณฑ์)';
            } else {
                $rx_status = ($alert_level_for_rx === 'hard') ? 'alert_hard' : 'alert_soft';
                if (!empty($duration_chk['enabled']) && empty($duration_chk['ok'])) {
                    $rx_status_text = $duration_chk['fail_text'];
                } else {
                    $rx_status_text = ($alert_level_for_rx === 'hard') ? 'เข้าเงื่อนไข Hard Alert' : 'เข้าเงื่อนไข Soft Alert';
                }
            }
        } else {
            $rx_status = 'ok';
            $rx_status_text = 'เหมาะสม (ไม่เข้าเงื่อนไข Alert)';
        }

        if ($cond_type === 'greater_than') {
            $cond_summary = '> ' . $cond_val;
        } elseif ($cond_type === 'less_than') {
            $cond_summary = '< ' . $cond_val;
        } elseif ($cond_type === 'contains') {
            $cond_summary = 'มีคำว่า "' . $cond_val . '"';
        } elseif ($cond_type === 'regex') {
            $cond_summary = 'Regex: ' . $cond_val;
        } else {
            $cond_summary = $min . '–' . $max;
        }

        if (count($response['prescriptions']) < $max_prescriptions) {
            $response['prescriptions'][] = array_merge($ident, [
                'hn' => $hn,
                'ptname' => $labs['ptname'],
                'drug_name' => $rule['drug_name'],
                'order_date' => $order_date_str,
                'order_time' => $order_time_str,
                'drug_method' => $drug_method !== '' ? $drug_method : '-',
                'lab_type' => $lab_type,
                'lab_items_code' => trim($rule['lab_items_code'] ?? ''),
                'lab_items_name' => trim($rule['lab_items_name'] ?? ''),
                'lab_condition_type' => $cond_type,
                'lab_condition_value' => $cond_val,
                'lab_condition_summary' => $cond_summary,
                'lab_value' => $lab_value_display,
                'lab_value_is_text' => $lab_value_is_text,
                'lab_display' => $lab_display,
                'score_key' => $score_key,
                'lab_date' => $has_lab_result ? $current_date : '-',
                'lab_time' => $has_lab_result ? $current_time : '',
                'actual_dose' => $actual_dose_str,
                'actual_dose_per_admin' => $actual_dose_per_admin_out,
                'actual_interval' => $duration_chk['actual_text'] ?? '',
                'recommended_duration' => $duration_chk['recommended_text'] ?? '',
                'match_status' => $rx_status,
                'status_text' => $rx_status_text,
                'warning_msg' => $rule['suggestion_msg'],
                'alert_level' => $alert_level_for_rx,
            ]);
            if ($rx_status === 'ok') {
                $response['meta']['prescriptions_ok']++;
            } elseif ($rx_status === 'no_lab') {
                $response['meta']['prescriptions_no_lab']++;
            } else {
                $response['meta']['prescriptions_alert']++;
            }
        } else {
            $response['meta']['prescriptions_truncated'] = true;
        }

        if ($lab_matched) {
            if ($exempt_hit !== '') {
                continue;
            }
            if (!empty($first_chk['skip_alert'])) {
                continue;
            }
            if (!monitor_lab_match_patient_extra($rule, $patient_age, $patient_wt)) {
                continue;
            }
            $patient_extra_text = monitor_lab_patient_extra_display($rule, $patient_age, $patient_wt);
            if (!empty($duration_chk['skip_alert'])) {
                continue;
            }
            if (!monitor_lab_order_dose_conditions_match($rule, $pat)) {
                continue;
            }
            if ($lab_value_is_text) {
                $alert_level = monitor_lab_alert_level_from_rule($rule);
                $text_alert = array_merge($ident, [
                    'hn' => $hn,
                    'ptname' => $labs['ptname'],
                    'drug_name' => $rule['drug_name'],
                    'order_date' => $order_date_str,
                    'order_time' => $order_time_str,
                    'drug_method' => $drug_method !== '' ? $drug_method : '-',
                    'lab_type' => $lab_type,
                    'lab_items_code' => trim($rule['lab_items_code'] ?? ''),
                    'lab_items_name' => trim($rule['lab_items_name'] ?? ''),
                    'lab_condition_type' => $cond_type,
                    'lab_condition_value' => $cond_val,
                    'lab_value' => $lab_value_display,
                    'lab_value_is_text' => true,
                    'lab_display' => $lab_display,
                    'score_key' => $score_key,
                    'lab_date' => $current_date,
                    'lab_time' => $current_time,
                    'warning_msg' => $rule['suggestion_msg'],
                    'patient_extra_text' => $patient_extra_text,
                    'actual_dose' => $actual_dose_str,
                    'actual_dose_per_admin' => $actual_dose_per_admin_out,
                    'recommended_dose' => '-',
                    'actual_interval' => $duration_chk['actual_text'] ?? '',
                    'recommended_duration' => $duration_chk['recommended_text'] ?? '',
                    'is_pass' => false,
                    'pass_text' => (!empty($duration_chk['enabled']) && empty($duration_chk['ok']))
                        ? ($duration_chk['fail_text'] ?? 'พบผลตามเงื่อนไข')
                        : 'พบผลตามเงื่อนไข',
                    'alert_level' => $alert_level,
                ]);
                if ($alert_level === 'hard') {
                    $response['hard_alerts'][] = $text_alert;
                } else {
                    $response['soft_alerts'][] = $text_alert;
                }
                continue;
            }

            $action_type = $rule['action_type'];
            $action_value = (float)$rule['action_value'];
            $adj_base_dose = $base_dose;

            if ($action_type === 'percent') {
                $adj_base_dose = $base_dose - ($base_dose * ($action_value / 100));
            } elseif ($action_type === 'fixed') {
                $adj_base_dose = $action_value;
            } elseif ($action_type === 'omit') {
                $adj_base_dose = 0;
            }

            $recommended_dose_str = '-';
            $rec_calc = -1;

            if ($action_type === 'omit') {
                $recommended_dose_str = "<span class='text-danger fw-bold'>งดยา (Omit)</span>";
                $rec_calc = 0;
            } elseif ($adj_base_dose > 0) {
                $drug_name_lower = strtolower($rule['drug_name']);
                $unit_lower = strtolower(trim($base_unit));
                $disp_unit = (strpos($unit_lower, 'unit') !== false) ? 'unit' : 'mg';

                if (strpos($drug_name_lower, 'carboplatin') !== false && $current_val > 0) {
                    $auc = ($adj_base_dose <= 10) ? $adj_base_dose : 5;
                    $rec_calc = $auc * ($current_val + 25);
                    $recommended_dose_str = round($rec_calc, 2) . " mg <small class='text-muted'>(AUC $auc)</small>";
                } elseif (strpos($unit_lower, 'm2') !== false || strpos($unit_lower, 'm²') !== false) {
                    if ($patient_bsa > 0) {
                        $rec_calc = $adj_base_dose * $patient_bsa;
                        $recommended_dose_str = round($rec_calc, 2) . ' ' . $disp_unit;
                    } else {
                        $recommended_dose_str = 'รอข้อมูล นน./ส่วนสูง';
                    }
                } elseif (strpos($unit_lower, 'kg') !== false) {
                    if ($patient_wt > 0) {
                        $rec_calc = $adj_base_dose * $patient_wt;
                        $recommended_dose_str = round($rec_calc, 2) . ' ' . $disp_unit;
                    } else {
                        $recommended_dose_str = 'รอข้อมูล นน.';
                    }
                } else {
                    $rec_calc = $adj_base_dose;
                    $recommended_dose_str = $adj_base_dose . ' ' . $base_unit;
                }
            }

            $is_pass = false;
            $pass_text = 'รอข้อมูล';

            if ($rec_calc === 0) {
                $is_pass = !$has_active_order;
                $pass_text = $is_pass ? 'ผ่าน' : 'ไม่ผ่าน (คลาดเคลื่อน Omit)';
            } elseif ($rec_calc > 0) {
                if ($actual_dose_val <= 0) {
                    $is_pass = false;
                    $pass_text = 'ไม่ผ่าน (ไม่ได้สั่งยา)';
                } else {
                    $diff_percent = abs(($actual_dose_val - $rec_calc) / $rec_calc) * 100;
                    if ($diff_percent <= 5.0) {
                        $is_pass = true;
                        $pass_text = 'ผ่าน';
                    } else {
                        $is_pass = false;
                        $pass_text = 'ไม่ผ่าน (คลาดเคลื่อน ' . round($diff_percent, 1) . '%)';
                    }
                }
            }

            if (!empty($duration_chk['enabled']) && empty($duration_chk['ok'])) {
                $is_pass = false;
                $dur_fail = $duration_chk['fail_text'] ?? 'ไม่ผ่าน (ช่วงให้ยาไม่ตรงเกณฑ์)';
                if ($pass_text !== 'ผ่าน' && $pass_text !== 'รอข้อมูล' && $pass_text !== '') {
                    $pass_text .= ' · ' . $dur_fail;
                } else {
                    $pass_text = $dur_fail;
                }
            }

            $alert_level = monitor_lab_alert_level_from_rule($rule);
            $alert_data = array_merge($ident, [
                'hn' => $hn,
                'ptname' => $labs['ptname'],
                'drug_name' => $rule['drug_name'],
                'order_date' => $order_date_str,
                'order_time' => $order_time_str,
                'drug_method' => $drug_method !== '' ? $drug_method : '-',
                'lab_type' => $lab_type,
                'lab_items_code' => trim($rule['lab_items_code'] ?? ''),
                'lab_items_name' => trim($rule['lab_items_name'] ?? ''),
                'lab_condition_type' => $cond_type,
                'lab_condition_value' => $cond_val,
                'lab_value' => $current_val,
                'lab_value_is_text' => false,
                'lab_display' => $lab_display,
                'score_key' => $score_key,
                'lab_date' => $current_date,
                'lab_time' => $current_time,
                'warning_msg' => $rule['suggestion_msg'],
                'patient_extra_text' => $patient_extra_text,
                'actual_dose' => $actual_dose_str,
                'actual_dose_per_admin' => $actual_dose_per_admin_out,
                'recommended_dose' => $recommended_dose_str,
                'actual_interval' => $duration_chk['actual_text'] ?? '',
                'recommended_duration' => $duration_chk['recommended_text'] ?? '',
                'is_pass' => $is_pass,
                'pass_text' => $pass_text,
                'alert_level' => $alert_level,
            ]);

            if ($alert_level === 'hard') {
                $response['hard_alerts'][] = $alert_data;
            } else {
                $response['soft_alerts'][] = $alert_data;
            }
        }
    }
}

function monitor_lab_unique_rows(array $rows) {
    $seen = [];
    $out = [];
    foreach ($rows as $row) {
        $k = ($row['hn'] ?? '') . '|' . ($row['icode'] ?? '') . '|' . ($row['order_date'] ?? '') . '|'
            . ($row['order_time'] ?? '') . '|' . ($row['lab_type'] ?? '') . '|' . ($row['an'] ?? '') . '|'
            . ($row['vn'] ?? '') . '|' . ($row['match_status'] ?? '') . '|' . ($row['alert_level'] ?? '') . '|'
            . ($row['warning_msg'] ?? '') . '|' . ($row['lab_condition_summary'] ?? '') . '|' . ($row['lab_condition_value'] ?? '');
        if (isset($seen[$k])) {
            continue;
        }
        $seen[$k] = true;
        $out[] = $row;
    }
    return $out;
}

$response['hard_alerts'] = monitor_lab_unique_rows($response['hard_alerts']);
$response['soft_alerts'] = monitor_lab_unique_rows($response['soft_alerts']);
$response['prescriptions'] = monitor_lab_unique_rows($response['prescriptions']);

require_once __DIR__ . '/monitor_lab_consult_helper.php';
mlc_ensure_tables($con);
$response['hard_alerts'] = mlc_attach_to_alerts($con, $organ, $response['hard_alerts']);
$response['soft_alerts'] = mlc_attach_to_alerts($con, $organ, $response['soft_alerts']);
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
$response['hard_alerts'] = sp_alert_mute_filter_rows($con, $response['hard_alerts']);
$response['soft_alerts'] = sp_alert_mute_filter_rows($con, $response['soft_alerts']);

mysqli_close($hos);
mysqli_close($con);

$response['meta']['orders_unique'] = $orders_unique;
$response['meta']['hard_count'] = count($response['hard_alerts']);
$response['meta']['soft_count'] = count($response['soft_alerts']);
$response['meta']['alert_count'] = $response['meta']['hard_count'] + $response['meta']['soft_count'];
$response['meta']['prescriptions_count'] = count($response['prescriptions']);
// นับสถานะใหม่หลัง dedupe
$rx_ok = 0;
$rx_alert = 0;
$rx_no_lab = 0;
foreach ($response['prescriptions'] as $rx) {
    if (($rx['match_status'] ?? '') === 'ok') {
        $rx_ok++;
    } elseif (($rx['match_status'] ?? '') === 'no_lab') {
        $rx_no_lab++;
    } else {
        $rx_alert++;
    }
}
$response['meta']['prescriptions_ok'] = $rx_ok;
$response['meta']['prescriptions_alert'] = $rx_alert;
$response['meta']['prescriptions_no_lab'] = $rx_no_lab;
$response['meta']['elapsed_ms'] = (int)round((microtime(true) - $api_started) * 1000);
$response['meta']['patients_scanned'] = count(array_unique($hn_list));
$response['meta']['high_volume'] = ($response['meta']['patients_scanned'] > 150);
$response['meta']['lab_lookback_years'] = $lab_lookback_years;

echo json_encode($response, JSON_UNESCAPED_UNICODE);
