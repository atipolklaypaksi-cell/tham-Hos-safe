<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_amass_helper.php';
mysqli_set_charset($con, 'utf8');
amr_dict_ensure_tables($con);
amr_amass_seed_ward_aliases($con);
$cats = amr_dict_categories();
$amass_year = date('Y');
$amass_start = $amass_year . '-01-01';
$amass_end = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ตั้งค่า Dictionary AMR — THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        .amr-set-hero {
            background: linear-gradient(135deg, #1f4d3b 0%, #146c4a 100%);
            color: #fff; border-radius: 16px; padding: 1.25rem 1.4rem; margin-bottom: 1.1rem;
        }
        .amr-set-hero h1 { font-size: 1.35rem; font-weight: 800; margin: 0; }
        .amr-set-hero p { margin: .35rem 0 0; opacity: .88; font-size: .9rem; }
        .amr-drop {
            border: 2px dashed #74b49b; border-radius: 14px; background: #f8fcfa;
            padding: 1.4rem; text-align: center; cursor: pointer; transition: .15s;
        }
        .amr-drop.dragover { background: #e8f5ef; border-color: #1f4d3b; }
        .amr-file-card { border: 1px solid #d7e4dc; border-radius: 12px; padding: .75rem .9rem; background: #fff; height: 100%; }
        .amr-file-card .meta { font-size: .78rem; color: #5f7468; }
        .nav-pills .nav-link { color: #1f4d3b; font-weight: 700; font-size: .85rem; }
        .nav-pills .nav-link.active { background: #1f4d3b; }
        .amr-count { font-size: .72rem; font-weight: 700; }
        .table-amr td, .table-amr th { vertical-align: middle; font-size: .82rem; }
        .table-amr input.form-control, .table-amr select.form-select { font-size: .8rem; }
        .badge-src-builtin { background: #e0f2fe; color: #0369a1; }
        .badge-src-import { background: #dcfce7; color: #166534; }
        .badge-src-manual { background: #fef3c7; color: #92400e; }
        .amr-preview { font-size: .78rem; }
        .amr-preview th { background: #1f4d3b; color: #fff; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-3">
            <div class="amr-set-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="small text-uppercase" style="letter-spacing:.08em;opacity:.75;">AMR · AMASS Dictionary</div>
                    <h1>ตั้งค่า Dictionary</h1>
                    <p>นำเข้าไฟล์ dictionary_for_*.xlsx ของ AMASS แล้วปรับ mapping เชื้อ / specimen / ผลดื้อยา ที่ใช้ใน Dashboard</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="amr_dashboard.php" class="btn btn-light btn-sm"><i class="fas fa-chart-area me-1"></i>Dashboard</a>
                    <button type="button" class="btn btn-outline-light btn-sm" id="btnResetBuiltin">
                        <i class="fas fa-undo me-1"></i>คืนค่า CASE เดิม
                    </button>
                </div>
            </div>

            <div class="card shadow-sm border-0 mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-2"><i class="fas fa-file-import me-1 text-success"></i>นำเข้า Dictionary AMASS</h6>
                    <p class="text-muted small mb-3 mb-md-2">
                        รองรับ <code>dictionary_for_microbiology_data.xlsx</code>,
                        <code>dictionary_for_hospital_admission_data.xlsx</code>,
                        <code>dictionary_for_drug_data.xlsx</code>,
                        <code>dictionary_for_wards.xlsx</code>
                        — คอลัมน์ A คือค่ามาตรฐาน AMASS, คอลัมน์ B คือค่าในข้อมูลโรงพยาบาล (รองรับ wildcard <code>*</code>)
                    </p>
                    <div class="row g-3 align-items-stretch">
                        <div class="col-lg-5">
                            <div class="amr-drop" id="dropZone">
                                <i class="fas fa-cloud-upload-alt fa-2x text-success mb-2"></i>
                                <div class="fw-bold">ลากไฟล์มาวาง หรือคลิกเลือก</div>
                                <div class="text-muted small">.xlsx / .xls / .csv — เลือกได้หลายไฟล์</div>
                                <input type="file" id="fileInput" class="d-none" accept=".xlsx,.xls,.csv" multiple>
                            </div>
                            <div class="d-flex flex-wrap gap-2 mt-2">
                                <select id="dictFileType" class="form-select form-select-sm" style="max-width:220px">
                                    <option value="">ตรวจประเภทจากชื่อไฟล์</option>
                                    <option value="microbiology">Microbiology</option>
                                    <option value="admission">Hospital admission</option>
                                    <option value="drug">Drug</option>
                                    <option value="ward">Wards</option>
                                </select>
                                <div class="form-check mt-1">
                                    <input class="form-check-input" type="checkbox" id="replaceFile">
                                    <label class="form-check-label small" for="replaceFile">แทนที่รายการที่นำเข้าจากไฟล์นี้ก่อน</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div id="importResult"></div>
                            <div id="previewWrap" class="d-none">
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered amr-preview mb-0">
                                        <thead>
                                            <tr>
                                                <th>หมวด</th>
                                                <th>AMASS</th>
                                                <th>ค่าโรงพยาบาล</th>
                                                <th>ชื่อที่แสดง</th>
                                            </tr>
                                        </thead>
                                        <tbody id="previewBody"></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row g-2 mt-3" id="fileMeta"></div>
                </div>
            </div>

            <div class="card shadow-sm border-0 mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-2"><i class="fas fa-file-excel me-1 text-success"></i>เตรียมไฟล์สำหรับรัน AMASS</h6>
                    <p class="text-muted small mb-3">
                        <strong>หลัก:</strong> ดึง 3 ไฟล์จาก HOSxP โดยตรง &nbsp;|&nbsp;
                        <strong>สำรอง:</strong> โยนไฟล์ .xlsx ที่เตรียมไว้แล้วเพื่อเก็บเป็นชุดรัน AMASS
                    </p>
                    <div class="row g-2 align-items-end">
                        <div class="col-auto">
                            <label class="form-label small mb-1">ตั้งแต่</label>
                            <input type="date" id="amassStart" class="form-control form-control-sm" value="<?php echo htmlspecialchars($amass_start); ?>">
                        </div>
                        <div class="col-auto">
                            <label class="form-label small mb-1">ถึง</label>
                            <input type="date" id="amassEnd" class="form-control form-control-sm" value="<?php echo htmlspecialchars($amass_end); ?>">
                        </div>
                        <div class="col-auto">
                            <button type="button" class="btn btn-success btn-sm" id="btnAmassDrug">
                                <i class="fas fa-download me-1"></i>drug_data.xlsx
                            </button>
                        </div>
                        <div class="col-auto">
                            <button type="button" class="btn btn-success btn-sm" id="btnAmassAdmission">
                                <i class="fas fa-download me-1"></i>hospital_admission_data.xlsx
                            </button>
                        </div>
                        <div class="col-auto">
                            <button type="button" class="btn btn-success btn-sm" id="btnAmassMicro">
                                <i class="fas fa-download me-1"></i>microbiology_data.xlsx
                            </button>
                        </div>
                        <div class="col-auto">
                            <button type="button" class="btn btn-primary btn-sm" id="btnAmassAll">
                                <i class="fas fa-database me-1"></i>ดึงทั้ง 3 ไฟล์จาก HOSxP
                            </button>
                        </div>
                    </div>
                    <div id="amassExportStatus" class="small text-muted mt-2">ดึงจาก HOSxP ตามช่วงวันที่ หรือโยนไฟล์สำรองด้านล่าง</div>

                    <hr class="my-3">
                    <div class="fw-bold small mb-2">สำรอง — โยนไฟล์เพื่อรัน AMASS</div>
                    <div class="row g-2" id="amassUploadCards">
                        <div class="col-md-4">
                            <div class="amr-drop py-3 amass-upload-zone" data-dataset="drug">
                                <div class="fw-bold small">drug_data.xlsx</div>
                                <div class="text-muted" style="font-size:.75rem" id="stage-drug">ยังไม่มีไฟล์</div>
                                <input type="file" class="d-none amass-file" accept=".xlsx,.xls,.csv">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="amr-drop py-3 amass-upload-zone" data-dataset="admission">
                                <div class="fw-bold small">hospital_admission_data.xlsx</div>
                                <div class="text-muted" style="font-size:.75rem" id="stage-admission">ยังไม่มีไฟล์</div>
                                <input type="file" class="d-none amass-file" accept=".xlsx,.xls,.csv">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="amr-drop py-3 amass-upload-zone" data-dataset="microbiology">
                                <div class="fw-bold small">microbiology_data.xlsx</div>
                                <div class="text-muted" style="font-size:.75rem" id="stage-microbiology">ยังไม่มีไฟล์</div>
                                <input type="file" class="d-none amass-file" accept=".xlsx,.xls,.csv">
                            </div>
                        </div>
                    </div>
                    <div class="small text-muted mt-2">
                        ดึง 3 ไฟล์แล้ววิเคราะห์ WHO GLASS/AMASS ใน THAM Hos-Safe ได้ที่
                        <a href="amr_amass_dashboard.php">Dashboard AMASS</a>
                        — ไม่ต้องรัน AMASS.bat บน Windows (Annex B/D คำนวณใน PHP; Annex C เป็น Poisson ไม่ใช่ SaTScan)
                    </div>
                </div>
            </div>

            <ul class="nav nav-pills mb-3 flex-wrap gap-1" id="catTabs"></ul>

            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="d-flex flex-wrap gap-2 align-items-end mb-3">
                        <div class="flex-grow-1" style="min-width:220px">
                            <label class="form-label small mb-1">ค้นหา</label>
                            <input type="text" id="qSearch" class="form-control form-control-sm" placeholder="AMASS / ค่าโรงพยาบาล / ชื่อที่แสดง">
                        </div>
                        <button type="button" class="btn btn-success btn-sm" id="btnAdd">
                            <i class="fas fa-plus me-1"></i>เพิ่มแถว
                        </button>
                        <button type="button" class="btn btn-outline-danger btn-sm" id="btnDeleteBuiltin">
                            <i class="fas fa-trash me-1"></i>ลบค่าเดิม
                        </button>
                    </div>
                    <div class="alert alert-light border small mb-3" id="catHint"></div>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered table-amr align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th style="width:42px">ใช้</th>
                                    <th>AMASS / รหัส</th>
                                    <th>ค่าในข้อมูลโรงพยาบาล</th>
                                    <th>ชื่อที่แสดงใน Dashboard</th>
                                    <th style="width:110px">จับคู่</th>
                                    <th style="width:72px">ลำดับ</th>
                                    <th style="width:88px">ที่มา</th>
                                    <th style="width:130px"></th>
                                </tr>
                            </thead>
                            <tbody id="rowBody">
                                <tr><td colspan="8" class="text-center text-muted py-4">กำลังโหลด...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"></script>
<script src="js/amr_amass_export.js"></script>
<script>
const API = 'fetch_amr_dict_api.php';
const CATS = <?php echo json_encode($cats, JSON_UNESCAPED_UNICODE); ?>;
const HINTS = {
    organism: 'ใช้จัดกลุ่มชนิดเชื้อ (microtype) จากข้อความใน lab_head.result_rtf — ค่าโรงพยาบาลจะถูกค้นแบบ LIKE / wildcard',
    specimen: 'จับคู่ชนิดสิ่งส่งตรวจจากข้อความในผลแลป',
    result: 'จับคู่ผลดื้อยา เช่น MRSA, CRE_MDR, ESBL — ใช้ทั้งกรอง Dashboard และเงื่อนไขดึงเคส AMR',
    ward: 'แมพชื่อหอผู้ป่วยเป็น ICU / non-ICU ตาม AMASS (dictionary_for_wards)',
    ward_alias: 'แปลงชื่อหอ HOSxP เป็นชื่อสั้นในไฟล์ drug_data / hospital_admission_data ตาม CASE ที่ใช้รัน AMASS',
    antibiotic: 'แมพชื่อยาปฏิชีวนะในข้อมูลโรงพยาบาลเป็นชื่อมาตรฐาน AMASS',
    variable: 'แมพชื่อคอลัมน์ในไฟล์ข้อมูล ให้ตรงตัวแปรที่ AMASS ต้องการ เช่น hospital_number → hn',
    admission: 'แมพค่าในไฟล์ admit เช่น เพศ สถานะจำหน่าย',
    other: 'รายการอื่นที่อ่านได้จาก Dictionary แต่ยังไม่ได้จัดหมวดหลัก'
};
let currentCat = 'organism';
let counts = {};

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function post(body) {
    return fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    }).then(r => r.json());
}

function renderTabs() {
    const wrap = document.getElementById('catTabs');
    wrap.innerHTML = Object.keys(CATS).map(key => {
        const c = CATS[key];
        const n = (counts[key] && counts[key].active) || 0;
        const t = (counts[key] && counts[key].total) || 0;
        const dash = c.dashboard ? ' <i class="fas fa-chart-pie" style="font-size:.65rem"></i>' : '';
        return '<li class="nav-item">' +
            '<button type="button" class="nav-link ' + (key === currentCat ? 'active' : '') + '" data-cat="' + key + '">' +
            '<i class="fas ' + c.icon + ' me-1"></i>' + esc(c.label) + dash +
            ' <span class="badge bg-light text-dark amr-count">' + n + '/' + t + '</span></button></li>';
    }).join('');
}

function sourceBadge(src) {
    const s = src || 'manual';
    const map = { builtin: 'ค่าเดิม', import: 'นำเข้า', manual: 'เพิ่มเอง' };
    return '<span class="badge badge-src-' + s + '">' + (map[s] || s) + '</span>';
}

function loadSummary() {
    return post({ action: 'summary' }).then(res => {
        if (res.status !== 'success') return;
        counts = res.counts || {};
        renderTabs();
        const metaWrap = document.getElementById('fileMeta');
        const files = {
            microbiology: 'Microbiology',
            admission: 'Admission',
            drug: 'Drug',
            ward: 'Wards'
        };
        const meta = res.meta || {};
        metaWrap.innerHTML = Object.keys(files).map(k => {
            const m = meta[k] || {};
            const when = m.imported_at ? m.imported_at : 'ยังไม่ได้นำเข้า';
            const fn = m.filename ? esc(m.filename) : '—';
            return '<div class="col-md-6 col-xl-3"><div class="amr-file-card">' +
                '<div class="fw-bold">' + files[k] + '</div>' +
                '<div class="meta">' + fn + '<br>' + esc(when) +
                (m.row_count ? (' · ' + m.row_count + ' แถว') : '') + '</div></div></div>';
        }).join('');
    });
}

function rowHtml(r) {
    const id = r.id || '';
    return '<tr data-id="' + id + '">' +
        '<td class="text-center"><input type="checkbox" class="form-check-input js-active"' + (String(r.active) !== '0' ? ' checked' : '') + '></td>' +
        '<td><input class="form-control form-control-sm js-amass" value="' + esc(r.amass_key) + '"></td>' +
        '<td><input class="form-control form-control-sm js-local" value="' + esc(r.local_value) + '"></td>' +
        '<td><input class="form-control form-control-sm js-label" value="' + esc(r.display_label) + '"></td>' +
        '<td><select class="form-select form-select-sm js-mode">' +
            '<option value="like"' + (r.match_mode === 'like' ? ' selected' : '') + '>LIKE</option>' +
            '<option value="wildcard"' + (r.match_mode === 'wildcard' ? ' selected' : '') + '>Wildcard *</option>' +
            '<option value="exact"' + (r.match_mode === 'exact' ? ' selected' : '') + '>ตรงตัว</option>' +
        '</select></td>' +
        '<td><input type="number" class="form-control form-control-sm js-order" value="' + esc(r.sort_order || 0) + '"></td>' +
        '<td>' + sourceBadge(r.source) + '</td>' +
        '<td class="text-nowrap">' +
            '<button type="button" class="btn btn-sm btn-outline-success js-save" title="บันทึก"><i class="fas fa-save"></i></button> ' +
            '<button type="button" class="btn btn-sm btn-outline-danger js-del" title="ลบ"><i class="fas fa-trash"></i></button>' +
        '</td></tr>';
}

function loadRows() {
    const q = document.getElementById('qSearch').value.trim();
    document.getElementById('catHint').textContent = HINTS[currentCat] || '';
    document.getElementById('rowBody').innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">กำลังโหลด...</td></tr>';
    post({ action: 'list', category: currentCat, q: q }).then(res => {
        if (res.status !== 'success') {
            document.getElementById('rowBody').innerHTML = '<tr><td colspan="8" class="text-danger text-center">' + esc(res.message || 'โหลดไม่สำเร็จ') + '</td></tr>';
            return;
        }
        const rows = res.rows || [];
        if (!rows.length) {
            document.getElementById('rowBody').innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">ยังไม่มีรายการในหมวดนี้</td></tr>';
            return;
        }
        document.getElementById('rowBody').innerHTML = rows.map(rowHtml).join('');
    });
}

function readRow(tr) {
    return {
        id: parseInt(tr.getAttribute('data-id') || '0', 10) || 0,
        category: currentCat,
        amass_key: tr.querySelector('.js-amass').value.trim(),
        local_value: tr.querySelector('.js-local').value.trim(),
        display_label: tr.querySelector('.js-label').value.trim(),
        match_mode: tr.querySelector('.js-mode').value,
        sort_order: parseInt(tr.querySelector('.js-order').value || '0', 10) || 0,
        active: tr.querySelector('.js-active').checked ? 1 : 0,
        dict_file: 'manual'
    };
}

document.getElementById('catTabs').addEventListener('click', function(e) {
    const btn = e.target.closest('[data-cat]');
    if (!btn) return;
    currentCat = btn.getAttribute('data-cat');
    renderTabs();
    loadRows();
});

document.getElementById('qSearch').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') loadRows();
});
document.getElementById('qSearch').addEventListener('change', loadRows);

document.getElementById('btnAdd').addEventListener('click', function() {
    const tbody = document.getElementById('rowBody');
    if (tbody.querySelector('[data-id=""]') || tbody.querySelector('[data-id="0"]')) return;
    const empty = { id: 0, amass_key: '', local_value: '', display_label: '', match_mode: currentCat === 'variable' ? 'exact' : 'like', sort_order: 0, active: 1, source: 'manual' };
    if (tbody.querySelector('.text-muted')) tbody.innerHTML = '';
    tbody.insertAdjacentHTML('afterbegin', rowHtml(empty));
});

document.getElementById('btnDeleteBuiltin').addEventListener('click', function() {
    const label = (CATS[currentCat] && CATS[currentCat].label) ? CATS[currentCat].label : currentCat;
    if (!confirm('ลบรายการที่เป็นค่าเดิม (CASE HOSxP) ในหมวด "' + label + '" ทั้งหมด?\nรายการที่นำเข้าจาก AMASS และที่เพิ่มเองจะยังอยู่')) return;
    post({ action: 'delete_source', category: currentCat, source: 'builtin' }).then(function(res) {
        alert(res.message || (res.status === 'success' ? 'ลบแล้ว' : 'ลบไม่สำเร็จ'));
        loadSummary().then(loadRows);
    });
});

document.getElementById('rowBody').addEventListener('click', function(e) {
    const tr = e.target.closest('tr');
    if (!tr) return;
    if (e.target.closest('.js-save')) {
        const payload = Object.assign({ action: 'save' }, readRow(tr));
        post(payload).then(res => {
            if (res.status !== 'success') {
                alert(res.message || 'บันทึกไม่สำเร็จ');
                return;
            }
            loadSummary().then(loadRows);
        });
        return;
    }
    if (e.target.closest('.js-del')) {
        const id = parseInt(tr.getAttribute('data-id') || '0', 10);
        if (!id) { tr.remove(); return; }
        if (!confirm('ลบแถวนี้?')) return;
        post({ action: 'delete', id: id }).then(res => {
            if (res.status !== 'success') { alert(res.message || 'ลบไม่สำเร็จ'); return; }
            loadSummary().then(loadRows);
        });
    }
});

document.getElementById('rowBody').addEventListener('change', function(e) {
    if (!e.target.classList.contains('js-active')) return;
    const tr = e.target.closest('tr');
    const id = parseInt(tr.getAttribute('data-id') || '0', 10);
    if (!id) return;
    post({ action: 'toggle', id: id, active: e.target.checked ? 1 : 0 });
});

document.getElementById('btnResetBuiltin').addEventListener('click', function() {
    if (!confirm('คืนค่า mapping เชื้อ / specimen / ผลดื้อยา ตาม CASE เดิมของ HOSxP? รายการที่นำเข้าจาก AMASS จะไม่ถูกลบ')) return;
    post({ action: 'reset_builtin' }).then(res => {
        alert(res.message || (res.status === 'success' ? 'เรียบร้อย' : 'ไม่สำเร็จ'));
        loadSummary().then(loadRows);
    });
});

function showImportMsg(type, html) {
    document.getElementById('importResult').innerHTML = '<div class="alert alert-' + type + ' py-2 small mb-2">' + html + '</div>';
}

function catLabel(key) {
    return (CATS[key] && CATS[key].label) ? CATS[key].label : key;
}

function handleWorkbook(file, wb) {
    const sheets = (wb.SheetNames || []).map(function(name) {
        const sheet = wb.Sheets[name];
        return { name: name, rows: XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' }) };
    });
    const forced = document.getElementById('dictFileType').value;
    const mode = document.getElementById('replaceFile').checked ? 'replace_file' : 'merge';
    post({
        action: 'preview',
        filename: file.name,
        dict_file: forced,
        sheets: sheets
    }).then(function(pre) {
        if (pre.status !== 'success') {
            showImportMsg('warning', esc(pre.message || 'อ่านไฟล์ไม่สำเร็จ'));
            document.getElementById('previewWrap').classList.add('d-none');
            return;
        }
        const cats = Object.keys(pre.by_category || {}).map(k => catLabel(k) + ' ' + pre.by_category[k]).join(', ');
        document.getElementById('previewWrap').classList.remove('d-none');
        document.getElementById('previewBody').innerHTML = (pre.preview || []).map(function(r) {
            return '<tr><td>' + esc(catLabel(r.category)) + '</td><td>' + esc(r.amass_key) + '</td><td>' + esc(r.local_value) + '</td><td>' + esc(r.display_label) + '</td></tr>';
        }).join('');
        showImportMsg('info', 'พบ <strong>' + pre.total + '</strong> แถว ใน ' + esc(pre.dict_file) + (cats ? (' — ' + esc(cats)) : '') + ' — กำลังนำเข้า...');
        return post({
            action: 'import',
            filename: file.name,
            dict_file: pre.dict_file,
            sheets: sheets,
            mode: mode
        }).then(function(res) {
            if (res.status !== 'success') {
                showImportMsg('danger', esc(res.message || 'นำเข้าไม่สำเร็จ'));
                return;
            }
            const detail = Object.keys(res.by_category || {}).map(k => catLabel(k) + ' ' + res.by_category[k]).join(', ');
            showImportMsg('success', esc(res.message) + (detail ? ('<br>' + esc(detail)) : ''));
            if (res.by_category && res.by_category.organism) currentCat = 'organism';
            else if (res.by_category && res.by_category.specimen) currentCat = 'specimen';
            else if (res.by_category && res.by_category.variable) currentCat = 'variable';
            loadSummary().then(loadRows);
        });
    }).catch(function() {
        showImportMsg('danger', 'นำเข้าไม่สำเร็จ');
    });
}

function processFile(file) {
    if (!file) return;
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    if (ext === 'csv') {
        const reader = new FileReader();
        reader.onload = function(e) {
            const wb = XLSX.read(e.target.result, { type: 'string' });
            handleWorkbook(file, wb);
        };
        reader.readAsText(file, 'UTF-8');
        return;
    }
    if (ext === 'xlsx' || ext === 'xls') {
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const wb = XLSX.read(new Uint8Array(e.target.result), { type: 'array' });
                handleWorkbook(file, wb);
            } catch (err) {
                showImportMsg('danger', 'อ่านไฟล์ Excel ไม่สำเร็จ');
            }
        };
        reader.readAsArrayBuffer(file);
        return;
    }
    showImportMsg('warning', 'รองรับเฉพาะ .xlsx, .xls, .csv');
}

const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
dropZone.addEventListener('click', function() { fileInput.click(); });
fileInput.addEventListener('change', function() {
    Array.from(this.files || []).forEach(processFile);
    this.value = '';
});
['dragenter', 'dragover'].forEach(evt => dropZone.addEventListener(evt, e => { e.preventDefault(); dropZone.classList.add('dragover'); }));
['dragleave', 'drop'].forEach(evt => dropZone.addEventListener(evt, e => { e.preventDefault(); dropZone.classList.remove('dragover'); }));
dropZone.addEventListener('drop', function(e) {
    Array.from(e.dataTransfer.files || []).forEach(processFile);
});

const AMASS_API = 'fetch_amr_amass_api.php';

function setAmassStatus(msg, isError) {
    const el = document.getElementById('amassExportStatus');
    el.className = 'small mt-2 ' + (isError ? 'text-danger' : 'text-muted');
    el.innerHTML = msg;
}

function amassButtons(disabled) {
    ['btnAmassDrug', 'btnAmassAdmission', 'btnAmassMicro', 'btnAmassAll'].forEach(function(id) {
        const b = document.getElementById(id);
        if (b) b.disabled = disabled;
    });
}

function amassRange() {
    return {
        start: document.getElementById('amassStart').value,
        end: document.getElementById('amassEnd').value
    };
}

async function runAmassExport(dataset, filename) {
    const range = amassRange();
    if (!range.start || !range.end) {
        setAmassStatus('กรุณาเลือกช่วงวันที่', true);
        return;
    }
    amassButtons(true);
    try {
        const res = await AmassExport.exportOne({
            dataset: dataset,
            filename: filename,
            start: range.start,
            end: range.end,
            download: true,
            stage: true,
            onStatus: setAmassStatus
        });
        if (res.staged) renderStaged(res.staged);
    } catch (e) {
        setAmassStatus(e.message || String(e), true);
    } finally {
        amassButtons(false);
    }
}

document.getElementById('btnAmassDrug').addEventListener('click', function() {
    runAmassExport('drug', 'drug_data.xlsx');
});
document.getElementById('btnAmassAdmission').addEventListener('click', function() {
    runAmassExport('admission', 'hospital_admission_data.xlsx');
});
document.getElementById('btnAmassMicro').addEventListener('click', function() {
    runAmassExport('microbiology', 'microbiology_data.xlsx');
});
document.getElementById('btnAmassAll').addEventListener('click', async function() {
    const range = amassRange();
    if (!range.start || !range.end) {
        setAmassStatus('กรุณาเลือกช่วงวันที่', true);
        return;
    }
    amassButtons(true);
    try {
        const res = await AmassExport.exportAll({
            start: range.start,
            end: range.end,
            download: true,
            stage: true,
            onStatus: setAmassStatus
        });
        if (res.staged) renderStaged(res.staged);
    } catch (e) {
        setAmassStatus(e.message || String(e), true);
    } finally {
        amassButtons(false);
    }
});

function renderStaged(staged) {
    ['drug', 'admission', 'microbiology'].forEach(function(key) {
        const el = document.getElementById('stage-' + key);
        if (!el || !staged || !staged[key]) return;
        const s = staged[key];
        if (s.exists) {
            const src = s.source === 'hosxp' ? 'จาก HOSxP' : 'ไฟล์สำรอง';
            el.textContent = src + ' · ' + (s.updated_at || '') + ' · ' + Math.round((s.bytes || 0) / 1024) + ' KB';
            el.className = 'text-success';
            el.style.fontSize = '.75rem';
        } else {
            el.textContent = 'ยังไม่มีไฟล์';
            el.className = 'text-muted';
            el.style.fontSize = '.75rem';
        }
    });
}

function refreshStaged() {
    fetch(AMASS_API + '?action=staged', { credentials: 'same-origin' })
        .then(r => r.json())
        .then(function(res) { if (res.staged) renderStaged(res.staged); });
}

document.querySelectorAll('.amass-upload-zone').forEach(function(zone) {
    const input = zone.querySelector('.amass-file');
    zone.addEventListener('click', function() { input.click(); });
    ['dragenter', 'dragover'].forEach(evt => zone.addEventListener(evt, e => { e.preventDefault(); zone.classList.add('dragover'); }));
    ['dragleave', 'drop'].forEach(evt => zone.addEventListener(evt, e => { e.preventDefault(); zone.classList.remove('dragover'); }));
    zone.addEventListener('drop', function(e) {
        if (e.dataTransfer.files[0]) uploadAmassFile(zone.getAttribute('data-dataset'), e.dataTransfer.files[0]);
    });
    input.addEventListener('change', function() {
        if (this.files[0]) uploadAmassFile(zone.getAttribute('data-dataset'), this.files[0]);
        this.value = '';
    });
});

function uploadAmassFile(dataset, file) {
    const fd = new FormData();
    fd.append('action', 'upload');
    fd.append('dataset', dataset);
    fd.append('file', file);
    setAmassStatus('กำลังเก็บไฟล์สำรอง ' + file.name + '...');
    fetch(AMASS_API, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(r => r.json())
        .then(function(res) {
            if (res.status !== 'success') {
                setAmassStatus(res.message || 'อัปโหลดไม่สำเร็จ', true);
                return;
            }
            setAmassStatus(res.message || 'เก็บไฟล์แล้ว');
            if (res.staged) renderStaged(res.staged);
        })
        .catch(function() { setAmassStatus('อัปโหลดไม่สำเร็จ', true); });
}

refreshStaged();

loadSummary().then(loadRows);
</script>
</body>
</html>
