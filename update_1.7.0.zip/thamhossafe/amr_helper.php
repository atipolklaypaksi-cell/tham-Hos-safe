<?php
/**
 * AMR Dashboard — เชื้อดื้อยา จาก lab_head.result_rtf (HOSxP IPD)
 */

function amr_sql_utf8($expr) {
    return "CAST(CONVERT($expr USING utf8) AS CHAR)";
}

function amr_sql_in_list($hos, array $values) {
    $escaped = [];
    foreach ($values as $v) {
        $v = trim((string)$v);
        if ($v === '' || strcasecmp($v, 'all') === 0) {
            continue;
        }
        $escaped[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return empty($escaped) ? '' : implode(',', $escaped);
}

function amr_parse_list($raw) {
    if (is_array($raw)) {
        $parts = $raw;
    } else {
        $parts = preg_split('/\s*,\s*/', (string)$raw);
    }
    $out = [];
    foreach ($parts as $p) {
        $p = trim((string)$p);
        if ($p === '' || strcasecmp($p, 'all') === 0 || $p === '*') {
            continue;
        }
        $out[$p] = $p;
    }
    return array_values($out);
}

function amr_parse_date($value, $fallback) {
    $value = trim((string)$value);
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return $value;
    }
    return $fallback;
}

function amr_dashboard_culture_scope($scope) {
    $scope = strtolower(trim((string)$scope));
    return $scope === 'all' ? 'all' : 'resistant';
}

function amr_sql_microtype_case_builtin($col = 'lh.result_rtf') {
    return "
CASE
    WHEN $col LIKE '%Klebsiella pneumoniae..(CRE_MDR)%' THEN 'K.pneumoniae'
    WHEN $col LIKE '%Klebsiella pneumoniae ssp pneumoniae..(MDR)%' THEN 'K.pneumoniae'
    WHEN $col LIKE '%Acinetobacter baumannii complex..(MDR)%' THEN 'A.baumannii'
    WHEN $col LIKE '%Klebsiella pneumoniae..(MDR)%' THEN 'K.pneumoniae'
    WHEN $col LIKE '%Escherichia coli..(CRE_MDR)%' THEN 'E.coli'
    WHEN $col LIKE '%Escherichia coli..(MDR)%' THEN 'E.coli'
    WHEN $col LIKE '%Pseudomonas aeruginosa..(MDR)%' THEN 'P.aeruginosa'
    WHEN $col LIKE '%Klebsiella species..(MDR)%' THEN 'Klebsiella species'
    WHEN $col LIKE '%Enterococcus faecium..(VRE)%' THEN 'Enterococcus faecium'
    WHEN $col LIKE '%Staphylococcus aureus..(MRSA_VRSA)%' THEN 'S.aureus'
    WHEN $col LIKE '%Staphylococcus aureus..(MRSA)%' THEN 'S.aureus'
    WHEN $col LIKE '%Acinetobacter baumannii complex..(CRAB_MDR)%' THEN 'A.baumannii'
    WHEN $col LIKE '%Acinetobacter baumannii..(CRAB_MDR)%' THEN 'A.baumannii'
    WHEN $col LIKE '%Staphylococcus hominis ssp hominis..(MRSE)%' THEN 'Staphylococcus hominis'
    WHEN $col LIKE '%Pseudomonas aeruginosa..(CRPA_MDR)%' THEN 'P.aeruginosa'
    WHEN $col LIKE '%Staphylococcus epidermidis..(MRSE)%' THEN 'Staphylococcus epidermidis'
    WHEN $col LIKE '%Staphylococcus hominis..(MRSE)%' THEN 'Staphylococcus hominis'
    WHEN $col LIKE '%Staphylococcus haemolyticus..(MRSE)%' THEN 'Staphylococcus haemolyticus'
    WHEN $col LIKE '%Staphylococcus saprophyticus..(MRSE)%' THEN 'Staphylococcus saprophyticus'
    WHEN $col LIKE '%Klebsiella pneumoniae ssp pneumoniae..(CRE_MDR)%' THEN 'K.pneumoniae'
    WHEN $col LIKE '%Acinetobacter baumannii..(MDR)%' THEN 'A.baumannii'
    WHEN $col LIKE '%Staphylococcus hominis_..(MRSE)%' THEN 'Staphylococcus hominis'
    WHEN $col LIKE '%Stap. haemolyticus(Inducible Clindamycin Resistance)..(MRSE)%' THEN 'Staphylococcus haemolyticus'
    WHEN $col LIKE '%Stap. capitis(Inducible Clindamycin Resistance)..(MRSE)%' THEN 'Staphylococcus capitis'
    WHEN $col LIKE '%Klebsiella(Enterobacter) aerogenes..(MDR)%' THEN 'Klebsiella aerogenes'
    WHEN $col LIKE '%Achromobacter xylosoxidans..(MDR)%' THEN 'Achromobacter xylosoxidans'
    WHEN $col LIKE '%Enterobacter cloacae..(CRE_MDR)%' THEN 'Enterobacter cloacae'
    WHEN $col LIKE '%Staphylococcus cohnii ssp urealyticus..(MRSE)%' THEN 'Staphylococcus cohnii'
    WHEN $col LIKE '%Staphylococcus cohnii..(MRSE)%' THEN 'Staphylococcus cohnii'
    WHEN $col LIKE '%Staphylococcus capitis..(MRSE)%' THEN 'Staphylococcus capitis'
    WHEN $col LIKE '%Staphylococcus caprae..(MRSE)%' THEN 'Staphylococcus caprae'
    WHEN $col LIKE '%Staphylococcus warneri_..(MRSE)%' THEN 'Staphylococcus warneri'
    WHEN $col LIKE '%Ralstonia pickettii..(MDR)%' THEN 'Ralstonia pickettii'
    WHEN $col LIKE '%Stap. epidermidis(Inducible Clindamycin Resistance)..(MRSE%' THEN 'Staphylococcus epidermidis'
    WHEN $col LIKE '%Stap. hominis (Inducible Clindamycin Resistance)..(MRSE)%' THEN 'Staphylococcus hominis'
    WHEN $col LIKE '%Acinetobacter haemolyticus..(MDR)%' THEN 'Acinetobacter haemolyticus'
    WHEN $col LIKE '%Pseudomonas aeruginosa..(CRPA)%' THEN 'P.aeruginosa'
    WHEN $col LIKE '%Klebsiella species..(CRE_MDR)%' THEN 'Klebsiella species'
    WHEN $col LIKE '%Sphingomonas paucimobilis..(MDR)%' THEN 'Sphingomonas paucimobilis'
    WHEN $col LIKE '%Staphylococcus auricularis..(MRSE)%' THEN 'Staphylococcus auricularis'
    WHEN $col LIKE '%Staphylococcus hominis subsp. hominis_..(MRSE)%' THEN 'Staphylococcus hominis'
    WHEN $col LIKE '%Staphylococcus haemolyticus_..(MRSE)%' THEN 'Staphylococcus haemolyticus'
    WHEN $col LIKE '%Citrobacter freundii..(CRE_MDR)%' THEN 'Citrobacter freundii'
    WHEN $col LIKE '%Staphylococcus warneri..(MRSE)%' THEN 'Staphylococcus warneri'
    WHEN $col LIKE '%Acinetobacter species..(MDR)%' THEN 'Acinetobacter species'
    WHEN $col LIKE '%Acinetobacter lwoffii..(MDR%' THEN 'Acinetobacter lwoffii'
    WHEN $col LIKE '%Enterobacter cloacae complex..(CRE_MDR)%' THEN 'Enterobacter cloacae'
    WHEN $col LIKE '%Pseudomonas stutzeri..(MDR)%' THEN 'Pseudomonas stutzeri'
    WHEN $col LIKE '%Staphylococcus sciuri..(MRSE)%' THEN 'Staphylococcus sciuri'
    WHEN $col LIKE '%Staphylococcus kloosii..(MRSE)%' THEN 'Staphylococcus kloosii'
    WHEN $col LIKE '%Enterococcus faecalis..(VRE%' THEN 'Enterococcus faecalis'
    WHEN $col LIKE '%Staphylococcus epidermidis_..(MRSE)%' THEN 'Staphylococcus epidermidis'
    WHEN $col LIKE '%Enterobacter cloacae complex..(MDR)%' THEN 'Enterobacter cloacae'
    WHEN $col LIKE '%Ochrobactrum anthropi..(MDR)%' THEN 'Ochrobactrum anthropi'
    WHEN $col LIKE '%Staphylococcus xylosus_..(MRSE)%' THEN 'Staphylococcus xylosus'
    WHEN $col LIKE '%Kleb.pneumoniae (ESBL-producing strain)%' THEN 'K.pneumoniae'
    WHEN $col LIKE '%Moraxella species..(MDR)%' THEN 'Moraxella species'
    WHEN $col LIKE '%Salmonella serogroup C..(MDR)%' THEN 'Salmonella serogroup C'
    WHEN $col LIKE '%Staphylococcus xylosus..(MRSE)%' THEN 'Staphylococcus xylosus'
    WHEN $col LIKE '%Enterobacter cloacae..(MDR)%' THEN 'Enterobacter cloacae'
    WHEN $col LIKE '%Aeromonas veronii bv sobria..(MDR%' THEN 'Aeromonas veronii'
    WHEN $col LIKE '%Staphylococcus Coagulase-negative..(MRSE)%' THEN 'Staphylococcus Coagulase-negative'
    WHEN $col LIKE '%Staphylococcus kloosii_..(MRSE)%' THEN 'Staphylococcus kloosii'
    WHEN $col LIKE '%E.coli (ESBL-producing strain)..(MDR)%' THEN 'E.coli'
    WHEN $col LIKE '%Stap. warneri(Inducible Clindamycin Resistance)..(MRSE)%' THEN 'Staphylococcus warneri'
    WHEN $col LIKE '%Stap. sciuri(Inducible Clindamycin Resistance)..(MRSE)%' THEN 'Staphylococcus sciuri'
    WHEN $col LIKE '%Morganella morganii..(MDR)%' THEN 'Morganella morganii'
    WHEN $col LIKE '%Stap. saprophyticus(Inducible Clindamycin Resistance)..(MRSE)%' THEN 'Staphylococcus saprophyticus'
    WHEN $col LIKE '%Staphylococcus aureus (Inducible Clindamycin Resistance)..(MRSA)%' THEN 'S.aureus'
    WHEN $col LIKE '%Staphylococcus aureus_..(MRSA%' THEN 'S.aureus'
    WHEN $col LIKE '%E.coli (ESBL-producing strain)%' THEN 'E.coli'
    WHEN $col LIKE '%Brevundimonas diminuta/vesicularis..(MDR)%' THEN 'Brevundimonas diminuta'
    WHEN $col LIKE '%Elizabethkingia meningoseptica..(MDR)%' THEN 'Elizabethkingia meningoseptica'
    WHEN $col LIKE '%Proteus mirabilis..(MDR)%' THEN 'Proteus mirabilis'
    WHEN $col LIKE '%Staphylococcus arlettae..(MRSE)%' THEN 'Staphylococcus arlettae'
    WHEN $col LIKE '%Moraxella group..(MDR)%' THEN 'Moraxella group'
    WHEN $col LIKE '%Coag.Neg. Staphylococci_..(MRSE)%' THEN 'Coag.Neg. Staphylococci'
    WHEN $col LIKE '%Staphylococcus gallinarum..(MRSE)%' THEN 'Staphylococcus gallinarum'
    WHEN $col LIKE '%Pseudomonas species..(MDR)%' THEN 'Pseudomonas species'
    WHEN $col LIKE '%Morganella morganii ssp morganii..(MDR)%' THEN 'Morganella morganii'
    WHEN $col LIKE '%Proteus mirabilis..(CRE_MDR)%' THEN 'Proteus mirabilis'
    WHEN $col LIKE '%Klebsiella(Enterobacter) aerogenes..(CRE_MDR)%' THEN 'Klebsiella aerogenes'
    WHEN $col LIKE '%Providencia stuartii..(CRE_MDR)%' THEN 'Providencia stuartii'
    WHEN $col LIKE '%Pseudomonas putida..(MDR)%' THEN 'Pseudomonas putida'
    WHEN $col LIKE '%Staphylococcus saprophyticus_..(MRSE)%' THEN 'Staphylococcus saprophyticus'
    WHEN $col LIKE '%Acinetobacter baumannii complex..(CRAB)%' THEN 'A.baumannii'
    WHEN $col LIKE '%Acinetobacter junii..(MDR)%' THEN 'Acinetobacter junii'
    WHEN $col LIKE '%Staphylococcus saccharolyticus..(MRSE)%' THEN 'Staphylococcus saccharolyticus'
    WHEN $col LIKE '%Acinetobacter baumannii..(CRAB)%' THEN 'A.baumannii'
    WHEN $col LIKE '%Acinetobacter baumannii (CRAB_MDR)%' THEN 'A.baumannii'
    WHEN $col LIKE '%Pseudomonas aeruginosa..%' THEN 'P.aeruginosa'
    ELSE 'อื่นๆ'
END";
}

function amr_sql_result_case_builtin($col = 'lh.result_rtf') {
    return "
CASE
    WHEN $col LIKE '%(MRSA_VRSA)%' THEN 'MRSA_VRSA'
    WHEN $col LIKE '%(CRE_MDR)%' THEN 'CRE_MDR'
    WHEN $col LIKE '%vre%' THEN 'VRE'
    WHEN $col LIKE '%(mrsa)%' THEN 'MRSA'
    WHEN $col LIKE '%(MRSE)%' THEN 'MRSE'
    WHEN $col LIKE '%esbl%' THEN 'ESBL'
    WHEN $col LIKE '%(CRAB_MDR)%' THEN 'CRAB_MDR'
    WHEN $col LIKE '%(MDR)%' THEN 'MDR'
    WHEN $col LIKE '%(CRPA)%' THEN 'CRPA'
    WHEN $col LIKE '%(CRPA_MDR%' THEN 'CRPA_MDR'
    WHEN $col LIKE '%(CRAB)%' THEN 'CRAB'
    ELSE ''
END";
}

function amr_sql_specimen_case_builtin($col = 'lh.result_rtf') {
    return "
CASE
    WHEN $col LIKE '%Urine (MSU,Void)%' THEN 'Urine'
    WHEN $col LIKE '%SPECIMEN: Sputum%' THEN 'Sputum'
    WHEN $col LIKE '%Sputum%' THEN 'Sputum'
    WHEN $col LIKE '%Stool%' THEN 'Stool'
    WHEN $col LIKE '%Pus (site ??)%' THEN 'Pus'
    WHEN $col LIKE '%Others Specimen%' THEN 'Others Specimen'
    WHEN $col LIKE '%CSF (Cerebrospinal Fluid)%' THEN 'CSF'
    WHEN $col LIKE '%Blood-Hemoculture%' THEN 'Blood'
    WHEN $col LIKE '%TISSUE%' THEN 'TISSUE'
    WHEN $col LIKE '%Peritoneal Dialysis - PD%' THEN 'Peritoneal Dialysis'
    WHEN $col LIKE '%Catheter%' THEN 'Catheter'
    WHEN $col LIKE '%Genital Tract%' THEN 'Genital Tract'
    WHEN $col LIKE '%Ascitic Fluid%' THEN 'Ascitic Fluid'
    WHEN $col LIKE '%Ear(PUS)%' THEN 'Ear(PUS)'
    WHEN $col LIKE '%Ankle%' THEN 'Ankle'
    WHEN $col LIKE '%Others Source%' THEN 'Others Specimen'
    WHEN $col LIKE '%Body Fluid%' THEN 'Body Fluid'
    WHEN $col LIKE '%Eye%' THEN 'Eye'
    WHEN $col LIKE '%C-Line%' THEN 'C-Line'
    WHEN $col LIKE '%Calcaneus%' THEN 'Calcaneus'
    WHEN $col LIKE '%Peritoneal Dialysis%' THEN 'Peritoneal Dialysis'
    WHEN $col LIKE '%T-Tube%' THEN 'T-Tube'
    WHEN $col LIKE '%Ventricle%' THEN 'Ventricle'
    WHEN $col LIKE '%Bile%' THEN 'Bile'
    WHEN $col LIKE '%Cervix%' THEN 'Cervix'
    WHEN $col LIKE '%Joint - Synovial Fluid%' THEN 'Joint - Synovial Fluid'
    WHEN $col LIKE '%Pleural Fluid%' THEN 'Pleural Fluid'
    ELSE ''
END";
}

function amr_sql_amr_regexp_builtin() {
    return '(CRE_MDR)|(MRSE)|vre|(MRSA)|(MRSA_VRSA)|esbl|(CRAB_MDR)|(MDR)|(CRPA)|(CRPA_MDR)|(CRAB)';
}

function amr_sql_microtype_case($col = 'lh.result_rtf', $esc_mysqli = null) {
    if (function_exists('amr_dict_sql_case')) {
        $sql = amr_dict_sql_case('organism', $col, "'อื่นๆ'", $esc_mysqli);
        if ($sql !== '') {
            return $sql;
        }
    }
    return amr_sql_microtype_case_builtin($col);
}

function amr_sql_result_case($col = 'lh.result_rtf', $esc_mysqli = null) {
    if (function_exists('amr_dict_sql_case')) {
        $sql = amr_dict_sql_case('result', $col, "''", $esc_mysqli);
        if ($sql !== '') {
            return $sql;
        }
    }
    return amr_sql_result_case_builtin($col);
}

function amr_sql_specimen_case($col = 'lh.result_rtf', $esc_mysqli = null) {
    if (function_exists('amr_dict_sql_case')) {
        $sql = amr_dict_sql_case('specimen', $col, "''", $esc_mysqli);
        if ($sql !== '') {
            return $sql;
        }
    }
    return amr_sql_specimen_case_builtin($col);
}

function amr_sql_amr_regexp($esc_mysqli = null) {
    if (function_exists('amr_dict_sql_regexp')) {
        $sql = amr_dict_sql_regexp('result', $esc_mysqli);
        if ($sql !== '') {
            return $sql;
        }
    }
    return amr_sql_amr_regexp_builtin();
}

function amr_color_for($label) {
    static $fixed = [
        'A.baumannii' => '#f59e0b',
        'E.coli' => '#22c55e',
        'K.pneumoniae' => '#38bdf8',
        'P.aeruginosa' => '#a78bfa',
        'S.aureus' => '#f43f5e',
        'Klebsiella species' => '#60a5fa',
        'Enterococcus faecium' => '#fb7185',
        'Enterococcus faecalis' => '#f97316',
        'Staphylococcus haemolyticus' => '#eab308',
        'Staphylococcus epidermidis' => '#14b8a6',
        'Staphylococcus hominis' => '#84cc16',
        'Enterobacter cloacae' => '#06b6d4',
        'NI' => '#f2495c',
        'CI' => '#73bf69',
        'MRSA' => '#ef4444',
        'MRSA_VRSA' => '#b91c1c',
        'MRSE' => '#f97316',
        'VRE' => '#a855f7',
        'CRE_MDR' => '#dc2626',
        'CRAB_MDR' => '#ea580c',
        'CRAB' => '#fb923c',
        'CRPA' => '#8b5cf6',
        'CRPA_MDR' => '#7c3aed',
        'MDR' => '#64748b',
        'ESBL' => '#0ea5e9',
    ];
    if (isset($fixed[$label])) {
        return $fixed[$label];
    }
    $h = abs(crc32((string)$label)) % 360;
    return "hsl($h, 68%, 58%)";
}

function amr_fetch_wards($hos) {
    $sql = "SELECT ward, " . amr_sql_utf8('IFNULL(name, ward)') . " AS name
            FROM ward
            ORDER BY name";
    $q = mysqli_query($hos, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'ward' => (string)($r['ward'] ?? ''),
                'name' => (string)($r['name'] ?? ''),
            ];
        }
    }
    return $rows;
}

function amr_fetch_bed_days($hos, $start, $end, array $ward_codes) {
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $ward_sql = amr_sql_in_list($hos, $ward_codes);
    $ward_filter = $ward_sql !== '' ? " AND i.ward IN ($ward_sql)" : '';
    $sql = "
        SELECT
            i.ward AS ward_code,
            " . amr_sql_utf8('IFNULL(w.name, i.ward)') . " AS ward_name,
            SUM(GREATEST(0, DATEDIFF(
                LEAST(
                    IF(i.dchdate IS NULL OR i.dchdate = '0000-00-00', CURDATE(), i.dchdate),
                    '$end_esc'
                ),
                GREATEST(i.regdate, '$start_esc')
            ))) AS bed_days
        FROM ipt i
        LEFT JOIN ward w ON w.ward = i.ward
        WHERE i.regdate <= '$end_esc'
          AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00' OR i.dchdate >= '$start_esc')
          $ward_filter
        GROUP BY i.ward, w.name
    ";
    $q = mysqli_query($hos, $sql);
    $out = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $name = trim((string)($r['ward_name'] ?? ''));
            if ($name === '') {
                $name = '(ไม่ระบุหอผู้ป่วย)';
            }
            $out[$name] = [
                'ward_code' => (string)($r['ward_code'] ?? ''),
                'ward_name' => $name,
                'bed_days' => (int)$r['bed_days'],
            ];
        }
    }
    return $out;
}

function amr_fetch_cases($hos, $start, $end, array $filters) {
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $ward_mode = (($filters['ward_mode'] ?? 'snapshot') === 'now') ? 'now' : 'snapshot';

    $microtype_sql = amr_sql_microtype_case('lh.result_rtf', $hos);
    $result_sql = amr_sql_result_case('lh.result_rtf', $hos);
    $specimen_sql = amr_sql_specimen_case('lh.result_rtf', $hos);
    $amr_re = amr_sql_amr_regexp($hos);
    $scope = amr_dashboard_culture_scope($filters['culture_scope'] ?? 'resistant');
    $scope_sql = $scope === 'all'
        ? "AND (lh.result_rtf LIKE '%MIC%' OR lh.result_rtf LIKE '%SIR%' OR lh.result_rtf LIKE '%APPROVED%' OR lh.result_rtf LIKE '%Culture%')"
        : "AND lh.result_rtf REGEXP '$amr_re'";
    $ward_name_sql = $ward_mode === 'now'
        ? amr_sql_utf8("IFNULL(w.name, '')")
        : amr_sql_utf8("IFNULL(w1.name, IFNULL(w.name, ''))");

    $ward_in = amr_sql_in_list($hos, $filters['wards'] ?? []);
    $ward_filter = '';
    if ($ward_in !== '') {
        if ($ward_mode === 'now') {
            $ward_filter = " AND w.ward IN ($ward_in)";
        } else {
            $ward_filter = " AND COALESCE(w1.ward, w.ward) IN ($ward_in)";
        }
    }

    $having = [];
    $micro_in = amr_sql_in_list($hos, $filters['microtypes'] ?? []);
    if ($micro_in !== '') {
        $having[] = "microtype IN ($micro_in)";
    }
    $type_in = amr_sql_in_list($hos, $filters['typeinfect'] ?? []);
    if ($type_in !== '') {
        $having[] = "Typeinfect IN ($type_in)";
    }
    $spec_in = amr_sql_in_list($hos, $filters['specimens'] ?? []);
    if ($spec_in !== '') {
        $having[] = "Specimen IN ($spec_in)";
    }
    $result_in = amr_sql_in_list($hos, $filters['results'] ?? []);
    if ($result_in !== '') {
        $having[] = "result IN ($result_in)";
    }
    $having_sql = empty($having) ? '' : ('HAVING ' . implode(' AND ', $having));

    $sql = "
        SELECT
            MAX(" . amr_sql_utf8("IFNULL(w1.name, IFNULL(w.name, ''))") . ") AS wardsnapshot,
            MAX(" . amr_sql_utf8("IFNULL(w.name, '')") . ") AS ward_now,
            MAX($ward_name_sql) AS ward,
            MAX(IF((lh.order_date - i.regdate) > 2, 'NI', 'CI')) AS Typeinfect,
            MAX(i.regdate) AS regdate,
            MAX(CONCAT(lh.order_date, ' ', IFNULL(lh.order_time, ''))) AS ordertime,
            MAX(CONCAT(IFNULL(lh.report_date, ''), ' ', IFNULL(lh.report_time, ''))) AS reportdatetime,
            MAX(IFNULL(lh.order_time, '')) AS order_time,
            MAX(IFNULL(lh.report_date, '')) AS report_date,
            MAX(IFNULL(lh.report_time, '')) AS report_time,
            MAX(COALESCE(NULLIF(i.hn, ''), lh.hn)) AS hn,
            MAX(COALESCE(i.an, lh.vn)) AS an,
            MAX(" . amr_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))") . ") AS ptname,
            MAX(IFNULL(ia.bedno, '')) AS bedno,
            lh.lab_order_number,
            MAX(lh.order_date) AS order_date,
            MAX($microtype_sql) AS microtype,
            MAX($result_sql) AS result,
            MAX($specimen_sql) AS Specimen,
            MAX(" . amr_sql_utf8("IFNULL(ds.name, '')") . ") AS DCstatus
        FROM lab_head lh
        LEFT JOIN ipt i ON i.an = lh.vn
        LEFT JOIN iptadm ia ON ia.an = i.an
        LEFT JOIN patient pt ON pt.hn = COALESCE(NULLIF(i.hn, ''), lh.hn)
        LEFT JOIN ward w ON w.ward = i.ward
        LEFT JOIN (
            SELECT an, snap_date, MIN(ward) AS ward
            FROM ward_admit_snapshot
            WHERE snap_date BETWEEN '$start_esc' AND '$end_esc'
            GROUP BY an, snap_date
        ) wa ON wa.an = i.an AND wa.snap_date = lh.order_date
        LEFT JOIN ward w1 ON w1.ward = wa.ward
        LEFT JOIN dchstts ds ON ds.dchstts = i.dchstts
        WHERE lh.department = 'IPD'
          AND lh.order_date BETWEEN '$start_esc' AND '$end_esc'
          $scope_sql
          $ward_filter
        GROUP BY lh.lab_order_number
        $having_sql
        ORDER BY lh.order_date DESC, lh.order_time DESC
    ";

    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['error' => mysqli_error($hos), 'rows' => []];
    }
    $rows = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $ward = trim((string)($r['ward'] ?? ''));
        if ($ward === '') {
            $ward = '(ไม่ระบุหอผู้ป่วย)';
            $r['ward'] = $ward;
        }
        if (trim((string)($r['wardsnapshot'] ?? '')) === '') {
            $r['wardsnapshot'] = $ward;
        }
        if ($scope === 'all' && preg_match('/no\s*growth/i', (string)($r['microtype'] ?? ''))) {
            continue;
        }
        $rows[] = $r;
    }
    return ['error' => '', 'rows' => $rows];
}

/** นับแบบ Grafana ที่ไม่ได้ยุบ lab ซ้ำจาก ward_admit_snapshot */
function amr_count_grafana_join_rows($hos, $start, $end, array $filters) {
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $ward_in = amr_sql_in_list($hos, $filters['wards'] ?? []);
    $ward_filter = '';
    if ($ward_in !== '') {
        $ward_mode = (($filters['ward_mode'] ?? 'snapshot') === 'now') ? 'now' : 'snapshot';
        $ward_filter = $ward_mode === 'now'
            ? " AND w.ward IN ($ward_in)"
            : " AND COALESCE(w1.ward, w.ward) IN ($ward_in)";
    }
    $amr_re = amr_sql_amr_regexp($hos);
    $sql = "
        SELECT COUNT(*) AS c
        FROM lab_head lh
        LEFT JOIN ipt i ON i.an = lh.vn
        LEFT JOIN iptadm ia ON ia.an = i.an
        LEFT JOIN ward w ON w.ward = i.ward
        LEFT JOIN ward_admit_snapshot wa
            ON wa.an = i.an AND wa.snap_date = lh.order_date
           AND wa.snap_date BETWEEN '$start_esc' AND '$end_esc'
        LEFT JOIN ward w1 ON w1.ward = wa.ward
        WHERE lh.department = 'IPD'
          AND lh.order_date BETWEEN '$start_esc' AND '$end_esc'
          AND lh.result_rtf REGEXP '$amr_re'
          $ward_filter
    ";
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return 0;
    }
    $r = mysqli_fetch_assoc($q);
    return (int)($r['c'] ?? 0);
}

function amr_date_chunks($start, $end, $size = 3) {
    $size = max(1, (int)$size);
    $from = strtotime($start);
    $to = strtotime($end);
    $chunks = [];
    if ($from === false || $to === false || $from > $to) {
        return $chunks;
    }
    while ($from <= $to) {
        $cs = date('Y-m-d', $from);
        $ce_ts = strtotime('+' . ($size - 1) . ' days', $from);
        if ($ce_ts > $to) {
            $ce_ts = $to;
        }
        $chunks[] = ['start' => $cs, 'end' => date('Y-m-d', $ce_ts)];
        $from = strtotime('+1 day', $ce_ts);
    }
    return $chunks;
}

function amr_merge_case_rows(array $chunks_rows) {
    $seen = [];
    $rows = [];
    foreach ($chunks_rows as $r) {
        $id = (string)($r['lab_order_number'] ?? '');
        if ($id !== '') {
            if (isset($seen[$id])) {
                continue;
            }
            $seen[$id] = true;
        }
        $rows[] = $r;
    }
    usort($rows, function ($a, $b) {
        $da = strcmp((string)($b['order_date'] ?? ''), (string)($a['order_date'] ?? ''));
        if ($da !== 0) {
            return $da;
        }
        return strcmp((string)($b['ordertime'] ?? ''), (string)($a['ordertime'] ?? ''));
    });
    return $rows;
}

function amr_date_range_list($start, $end) {
    $dates = [];
    $from = strtotime($start);
    $to = strtotime($end);
    if ($from === false || $to === false || $from > $to) {
        return $dates;
    }
    for ($t = $from; $t <= $to; $t += 86400) {
        $dates[] = date('Y-m-d', $t);
    }
    return $dates;
}

function amr_inc_count(array &$map, $key, $amount = 1) {
    if ($key === '' || $key === null) {
        $key = '(ไม่ระบุ)';
    }
    if (!isset($map[$key])) {
        $map[$key] = 0;
    }
    $map[$key] += $amount;
}

function amr_build_dashboard($hos, $start, $end, array $filters) {
    $t0 = microtime(true);
    $all = [];
    foreach (amr_date_chunks($start, $end, 3) as $chunk) {
        $cases = amr_fetch_cases($hos, $chunk['start'], $chunk['end'], $filters);
        if ($cases['error'] !== '') {
            return [
                'status' => 'error',
                'message' => 'ดึงข้อมูลเชื้อดื้อยาไม่สำเร็จ: ' . $cases['error'],
            ];
        }
        foreach ($cases['rows'] as $r) {
            $all[] = $r;
        }
    }
    $bed_days = amr_fetch_bed_days($hos, $start, $end, $filters['wards'] ?? []);
    return amr_assemble_dashboard($all, $bed_days, $start, $end, 0, $t0);
}

function amr_assemble_dashboard(array $rows, array $bed_days, $start, $end, $grafana_join_count = 0, $t0 = null) {
    if ($t0 === null) {
        $t0 = microtime(true);
    }
    $rows = amr_merge_case_rows($rows);
    $grafana_join_count = (int)$grafana_join_count;

    $dates = amr_date_range_list($start, $end);
    $patients = [];
    $ni_patients_by_ward = [];
    $by_date = array_fill_keys($dates, 0);
    $by_date_micro = [];
    $by_ward = [];
    $by_micro = [];
    $by_result = [];
    $by_specimen = [];
    $by_type = ['NI' => 0, 'CI' => 0];
    $heatmap = [];
    $micro_set = [];
    $specimen_set = [];
    $result_set = [];
    $resistant_count = 0;

    foreach ($rows as $r) {
        $hn = (string)($r['hn'] ?? '');
        $an = (string)($r['an'] ?? '');
        $ward = (string)($r['ward'] ?? '(ไม่ระบุหอผู้ป่วย)');
        $micro = (string)($r['microtype'] ?? '');
        $result = (string)($r['result'] ?? '');
        $spec = (string)($r['Specimen'] ?? '');
        $type = (string)($r['Typeinfect'] ?? '');
        $order_date = substr((string)($r['order_date'] ?? ''), 0, 10);

        if ($hn !== '') {
            $patients[$hn] = true;
        }
        if ($type === 'NI') {
            if (!isset($ni_patients_by_ward[$ward])) {
                $ni_patients_by_ward[$ward] = 0;
            }
            $ni_patients_by_ward[$ward]++;
        }

        if (isset($by_date[$order_date])) {
            $by_date[$order_date]++;
        } elseif ($order_date !== '') {
            $by_date[$order_date] = 1;
        }
        if ($micro !== '') {
            $micro_set[$micro] = $micro;
            if (!isset($by_date_micro[$micro])) {
                $by_date_micro[$micro] = [];
            }
            if (!isset($by_date_micro[$micro][$order_date])) {
                $by_date_micro[$micro][$order_date] = 0;
            }
            $by_date_micro[$micro][$order_date]++;
            amr_inc_count($by_micro, $micro);
            $heat_key = $ward . ' · ' . $micro;
            if (!isset($heatmap[$heat_key])) {
                $heatmap[$heat_key] = [];
            }
            if (!isset($heatmap[$heat_key][$order_date])) {
                $heatmap[$heat_key][$order_date] = 0;
            }
            $heatmap[$heat_key][$order_date]++;
        }
        if ($result !== '') {
            $result_set[$result] = $result;
            amr_inc_count($by_result, $result);
            $resistant_count++;
        }
        if ($spec !== '') {
            $specimen_set[$spec] = $spec;
            amr_inc_count($by_specimen, $spec);
        }
        if ($type === 'NI' || $type === 'CI') {
            $by_type[$type]++;
        }
        amr_inc_count($by_ward, $ward);
    }

    $ni_rate = [];
    $zero_ni_wards = [];
    $ward_names = [];
    foreach ($bed_days as $name => $info) {
        $ward_names[$name] = true;
        $ni_count = isset($ni_patients_by_ward[$name]) ? (int)$ni_patients_by_ward[$name] : 0;
        $days = max(0, (int)$info['bed_days']);
        $rate = ($days > 0) ? round(($ni_count / $days) * 1000, 2) : null;
        $item = [
            'ward' => $name,
            'ni_count' => $ni_count,
            'bed_days' => $days,
            'rate' => $rate,
        ];
        if ($ni_count > 0 && $rate !== null) {
            $ni_rate[] = $item;
        } else {
            $zero_ni_wards[] = $item;
        }
    }
    foreach ($ni_patients_by_ward as $name => $cnt) {
        if (isset($ward_names[$name])) {
            continue;
        }
        $ni_rate[] = [
            'ward' => $name,
            'ni_count' => (int)$cnt,
            'bed_days' => 0,
            'rate' => null,
        ];
    }
    usort($ni_rate, function ($a, $b) {
        return ($b['rate'] ?? -1) <=> ($a['rate'] ?? -1);
    });
    usort($zero_ni_wards, function ($a, $b) {
        return strcasecmp($a['ward'], $b['ward']);
    });

    arsort($by_ward);
    arsort($by_micro);
    arsort($by_result);
    arsort($by_specimen);

    $by_date_series = [];
    foreach ($dates as $d) {
        $by_date_series[] = ['date' => $d, 'count' => (int)($by_date[$d] ?? 0)];
    }

    $scatter = [];
    foreach ($by_date_micro as $micro => $date_counts) {
        $points = [];
        foreach ($dates as $d) {
            $c = (int)($date_counts[$d] ?? 0);
            if ($c > 0) {
                $points[] = ['x' => $d, 'y' => $c];
            }
        }
        if (!empty($points)) {
            $scatter[] = [
                'label' => $micro,
                'color' => amr_color_for($micro),
                'points' => $points,
            ];
        }
    }
    usort($scatter, function ($a, $b) {
        return strcasecmp($a['label'], $b['label']);
    });

    $heat_rows = [];
    foreach ($heatmap as $label => $date_counts) {
        $total = 0;
        $cells = [];
        foreach ($dates as $d) {
            $c = (int)($date_counts[$d] ?? 0);
            $total += $c;
            $cells[] = $c;
        }
        $heat_rows[] = ['label' => $label, 'total' => $total, 'cells' => $cells];
    }
    usort($heat_rows, function ($a, $b) {
        return $b['total'] <=> $a['total'];
    });
    $heat_rows = array_slice($heat_rows, 0, 40);

    $pack_counts = function (array $map) {
        $out = [];
        foreach ($map as $label => $count) {
            $out[] = [
                'label' => (string)$label,
                'count' => (int)$count,
                'color' => amr_color_for((string)$label),
            ];
        }
        return $out;
    };

    $nat_sort = function ($a, $b) {
        return strcasecmp($a, $b);
    };
    $micro_list = array_values($micro_set);
    usort($micro_list, $nat_sort);
    $specimen_list = array_values($specimen_set);
    usort($specimen_list, $nat_sort);
    $result_list = array_values($result_set);
    usort($result_list, $nat_sort);

    $elapsed_ms = (int)round((microtime(true) - $t0) * 1000);

    return [
        'status' => 'success',
        'meta' => [
            'start_date' => $start,
            'end_date' => $end,
            'row_count' => count($rows),
            'patient_count' => count($patients),
            'grafana_join_count' => $grafana_join_count,
            'snapshot_dup_extra' => max(0, $grafana_join_count - count($rows)),
            'ni_count' => (int)$by_type['NI'],
            'ci_count' => (int)$by_type['CI'],
            'resistant_count' => $resistant_count,
            'elapsed_ms' => $elapsed_ms,
        ],
        'filters' => [
            'microtypes' => $micro_list,
            'specimens' => $specimen_list,
            'results' => $result_list,
            'typeinfect' => ['NI', 'CI'],
        ],
        'gauge' => [
            'value' => count($rows),
            'max' => max(50, (int)ceil(max(count($rows), 1) * 1.25)),
            'patient_count' => count($patients),
            'grafana_join_count' => $grafana_join_count,
        ],
        'ni_rate' => $ni_rate,
        'zero_ni_wards' => $zero_ni_wards,
        'by_date' => $by_date_series,
        'scatter' => $scatter,
        'by_ward' => $pack_counts($by_ward),
        'by_micro' => $pack_counts($by_micro),
        'by_result' => $pack_counts($by_result),
        'by_specimen' => $pack_counts($by_specimen),
        'heatmap' => [
            'dates' => $dates,
            'rows' => $heat_rows,
        ],
        'rows' => $rows,
    ];
}
