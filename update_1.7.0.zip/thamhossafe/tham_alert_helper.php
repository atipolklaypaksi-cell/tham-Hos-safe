<?php
/**
 * THAM Alert pipelines: Master (hosxp_master_setting) for "กำลัง key",
 * Slave (hosxp_setting) for names / labs / safety.
 */

function tham_alert_pipelines()
{
    return [
        'ward' => [
            'label' => 'Ward / Consult',
            'hint' => 'รับแจ้งจากเว็บ THAM (ไม่ดึง HOSxP) — ใช้ตอน Consult หรือส่งเตือนไปกลุ่มวอร์ด',
            'source' => 'web',
        ],
        'doctor' => [
            'label' => 'Doctor (OPD กำลัง key)',
            'hint' => 'Master: opitemrece ล่าสุดที่มี VN + ยาในรายการเสี่ยง — Slave: ชื่อผู้ป่วย',
            'source' => 'master',
        ],
        'phar_opd' => [
            'label' => 'Pharmacy OPD',
            'hint' => 'Master: ใบที่เภสัชกำลังจัด (rx_operator) — Slave: ตรวจ icode เสี่ยงใน VN นั้น',
            'source' => 'master',
        ],
        'phar_ipd' => [
            'label' => 'Pharmacy IPD',
            'hint' => 'Master: รายการกำลังคีย์ผู้ป่วยใน (ipt_order_item หรือ opitemrece ที่มี AN) — Slave: ชื่อผู้ป่วย',
            'source' => 'master',
        ],
    ];
}

function tham_alert_sys_get($con, $name, $default = '')
{
    $n = mysqli_real_escape_string($con, $name);
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='$n' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return (string)$r['config_value'];
    }
    return $default;
}

function tham_alert_sys_set($con, $name, $value)
{
    $n = mysqli_real_escape_string($con, $name);
    $v = mysqli_real_escape_string($con, (string)$value);
    $q = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$n' LIMIT 1");
    if ($q && mysqli_num_rows($q) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$n'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$n','$v')");
}

function tham_alert_ensure_tables($con)
{
    static $done = false;
    if ($done) {
        return true;
    }
    $sql = __DIR__ . '/sql/tham_alert_pipelines.sql';
    if (!is_file($sql)) {
        return false;
    }
    $raw = file_get_contents($sql);
    foreach (preg_split('/;\s*\n/', $raw) as $stmt) {
        $stmt = trim($stmt);
        if ($stmt !== '') {
            @mysqli_query($con, $stmt);
        }
    }
    $done = true;
    tham_alert_ensure_agent_schema($con);
    return true;
}

function tham_alert_ensure_agent_schema($con)
{
    @mysqli_query($con, "CREATE TABLE IF NOT EXISTS tham_alert_agents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        machine_key VARCHAR(64) NOT NULL,
        cookie_id VARCHAR(32) NOT NULL DEFAULT '',
        pipeline VARCHAR(20) NOT NULL DEFAULT '',
        client_hint VARCHAR(20) NOT NULL DEFAULT '',
        mapped TINYINT(1) NOT NULL DEFAULT 0,
        mapped_from VARCHAR(40) NOT NULL DEFAULT '',
        station_id VARCHAR(80) NOT NULL DEFAULT '',
        group_name VARCHAR(80) NOT NULL DEFAULT '',
        computername VARCHAR(80) NOT NULL DEFAULT '',
        ip_address VARCHAR(45) NOT NULL DEFAULT '',
        windows_user VARCHAR(80) NOT NULL DEFAULT '',
        agent_version VARCHAR(40) NOT NULL DEFAULT '',
        user_agent VARCHAR(180) NOT NULL DEFAULT '',
        last_user_id INT NOT NULL DEFAULT 0,
        last_user_name VARCHAR(120) NOT NULL DEFAULT '',
        last_user_role VARCHAR(40) NOT NULL DEFAULT '',
        last_dispense_room VARCHAR(10) NOT NULL DEFAULT '',
        first_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_login_at DATETIME NULL,
        poll_count INT NOT NULL DEFAULT 0,
        enabled TINYINT(1) NOT NULL DEFAULT 1,
        note VARCHAR(180) NOT NULL DEFAULT '',
        UNIQUE KEY uk_machine (machine_key),
        KEY idx_seen (last_seen),
        KEY idx_pipe (pipeline)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    @mysqli_query($con, "CREATE TABLE IF NOT EXISTS tham_alert_agent_logins (
        id INT AUTO_INCREMENT PRIMARY KEY,
        agent_id INT NOT NULL,
        user_id INT NOT NULL DEFAULT 0,
        username VARCHAR(80) NOT NULL DEFAULT '',
        full_name VARCHAR(120) NOT NULL DEFAULT '',
        role VARCHAR(40) NOT NULL DEFAULT '',
        dispense_room VARCHAR(10) NOT NULL DEFAULT '',
        ip_address VARCHAR(45) NOT NULL DEFAULT '',
        source VARCHAR(20) NOT NULL DEFAULT 'login',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_agent_created (agent_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    $cols = [
        'cookie_id' => "ALTER TABLE tham_alert_agents ADD COLUMN cookie_id VARCHAR(32) NOT NULL DEFAULT '' AFTER machine_key",
        'client_hint' => "ALTER TABLE tham_alert_agents ADD COLUMN client_hint VARCHAR(20) NOT NULL DEFAULT '' AFTER pipeline",
        'mapped' => "ALTER TABLE tham_alert_agents ADD COLUMN mapped TINYINT(1) NOT NULL DEFAULT 0 AFTER client_hint",
        'mapped_from' => "ALTER TABLE tham_alert_agents ADD COLUMN mapped_from VARCHAR(40) NOT NULL DEFAULT '' AFTER mapped",
        'last_user_id' => "ALTER TABLE tham_alert_agents ADD COLUMN last_user_id INT NOT NULL DEFAULT 0 AFTER user_agent",
        'last_user_name' => "ALTER TABLE tham_alert_agents ADD COLUMN last_user_name VARCHAR(120) NOT NULL DEFAULT '' AFTER last_user_id",
        'last_user_role' => "ALTER TABLE tham_alert_agents ADD COLUMN last_user_role VARCHAR(40) NOT NULL DEFAULT '' AFTER last_user_name",
        'last_dispense_room' => "ALTER TABLE tham_alert_agents ADD COLUMN last_dispense_room VARCHAR(10) NOT NULL DEFAULT '' AFTER last_user_role",
        'last_login_at' => "ALTER TABLE tham_alert_agents ADD COLUMN last_login_at DATETIME NULL AFTER last_seen",
        'last_agent_at' => "ALTER TABLE tham_alert_agents ADD COLUMN last_agent_at DATETIME NULL AFTER last_login_at",
        'enabled' => "ALTER TABLE tham_alert_agents ADD COLUMN enabled TINYINT(1) NOT NULL DEFAULT 1 AFTER poll_count",
        'last_web_at' => "ALTER TABLE tham_alert_agents ADD COLUMN last_web_at DATETIME NULL AFTER last_agent_at",
        'install_push_at' => "ALTER TABLE tham_alert_agents ADD COLUMN install_push_at DATETIME NULL AFTER last_web_at",
        'install_push_by' => "ALTER TABLE tham_alert_agents ADD COLUMN install_push_by INT NOT NULL DEFAULT 0 AFTER install_push_at",
        'install_ack_at' => "ALTER TABLE tham_alert_agents ADD COLUMN install_ack_at DATETIME NULL AFTER install_push_by",
        'update_push_at' => "ALTER TABLE tham_alert_agents ADD COLUMN update_push_at DATETIME NULL AFTER install_ack_at",
        'agent_version_at' => "ALTER TABLE tham_alert_agents ADD COLUMN agent_version_at DATETIME NULL AFTER agent_version",
        'device_kind' => "ALTER TABLE tham_alert_agents ADD COLUMN device_kind VARCHAR(16) NOT NULL DEFAULT '' AFTER user_agent",
        'ua_platform' => "ALTER TABLE tham_alert_agents ADD COLUMN ua_platform VARCHAR(40) NOT NULL DEFAULT '' AFTER device_kind",
        'ui_hidden' => "ALTER TABLE tham_alert_agents ADD COLUMN ui_hidden TINYINT(1) NOT NULL DEFAULT 0 AFTER enabled",
        'display_name' => "ALTER TABLE tham_alert_agents ADD COLUMN display_name VARCHAR(80) NOT NULL DEFAULT '' AFTER computername",
        'keep_login' => "ALTER TABLE tham_alert_agents ADD COLUMN keep_login TINYINT(1) NOT NULL DEFAULT 0 AFTER enabled",
    ];
    foreach ($cols as $col => $ddl) {
        $q = @mysqli_query($con, "SHOW COLUMNS FROM tham_alert_agents LIKE '$col'");
        if (!$q || mysqli_num_rows($q) === 0) {
            @mysqli_query($con, $ddl);
        }
    }
    if (tham_alert_sys_get($con, 'tham_alert_lan_auto', '') === '') {
        tham_alert_sys_set($con, 'tham_alert_lan_auto', '0');
    }
    if (tham_alert_sys_get($con, 'keep_login_seeded', '') === '') {
        @mysqli_query($con, "UPDATE tham_alert_agents SET keep_login=1
            WHERE ip_address IN ('10.10.81.156','10.10.80.127')
               OR UPPER(REPLACE(REPLACE(REPLACE(computername,' ',''),'-',''),'_','')) IN ('CCTVPHAMA','DRUG130')
               OR UPPER(REPLACE(REPLACE(REPLACE(display_name,' ',''),'-',''),'_','')) IN ('CCTVPHAMA','DRUG130')
               OR UPPER(REPLACE(REPLACE(REPLACE(station_id,' ',''),'-',''),'_','')) IN ('CCTVPHAMA','DRUG130')
               OR LOWER(TRIM(computername)) IN ('cctv','drug 130','drug-130')");
        tham_alert_sys_set($con, 'keep_login_seeded', '1');
    }
    tham_alert_keep_login_sync_file($con);
    @mysqli_query($con, "CREATE TABLE IF NOT EXISTS tham_alert_agent_livever (
        agent_id INT NOT NULL,
        agent_version VARCHAR(40) NOT NULL,
        seen_at DATETIME NOT NULL,
        PRIMARY KEY (agent_id, agent_version),
        KEY idx_seen (seen_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
}

function tham_alert_agent_touch_version($con, $agent_id, $version)
{
    $agent_id = (int)$agent_id;
    $version = trim((string)$version);
    if ($agent_id <= 0 || $version === '') {
        return;
    }
    $ver = mysqli_real_escape_string($con, mb_substr($version, 0, 40));
    @mysqli_query($con, "INSERT INTO tham_alert_agent_livever (agent_id, agent_version, seen_at)
        VALUES ($agent_id, '$ver', NOW())
        ON DUPLICATE KEY UPDATE seen_at=NOW()");
    if (mt_rand(1, 40) === 1) {
        @mysqli_query($con, "DELETE FROM tham_alert_agent_livever WHERE seen_at < NOW() - INTERVAL 1 DAY");
    }
}

function tham_alert_agent_live_versions($con, $agent_id)
{
    $agent_id = (int)$agent_id;
    if ($agent_id <= 0) {
        return [];
    }
    $out = [];
    $q = @mysqli_query($con, "SELECT agent_version FROM tham_alert_agent_livever
        WHERE agent_id=$agent_id AND seen_at > NOW() - INTERVAL 90 SECOND
        ORDER BY agent_version");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $v = trim((string)($r['agent_version'] ?? ''));
            if ($v !== '') {
                $out[] = $v;
            }
        }
    }
    return $out;
}

function tham_alert_request_ua()
{
    return substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 180);
}

function tham_alert_request_ua_platform()
{
    $p = trim((string)($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? ''));
    $p = trim($p, "\"'");
    return mb_substr($p, 0, 40);
}

function tham_alert_request_ch_mobile()
{
    return strtolower(trim((string)($_SERVER['HTTP_SEC_CH_UA_MOBILE'] ?? '')));
}

function tham_alert_classify_device($ua, array $row = [])
{
    $ua = (string)$ua;
    $low = strtolower($ua);
    $installed = !empty($row['agent_installed'])
        || !empty($row['last_agent_at'])
        || (int)($row['poll_count'] ?? 0) > 0
        || stripos($ua, 'THAM-Alert-Agent') !== false
        || stripos($ua, 'THAMHosSafe') !== false;
    $ch_mobile = strtolower(trim((string)($row['ch_mobile'] ?? '')));
    $ch_plat = trim((string)($row['ua_platform'] ?? $row['ch_platform'] ?? ''));
    $os = '';
    if ($ch_plat !== '') {
        $p = strtolower($ch_plat);
        if (strpos($p, 'android') !== false) {
            $os = 'Android';
        } elseif (strpos($p, 'ios') !== false || strpos($p, 'iphone') !== false) {
            $os = 'iOS';
        } elseif (strpos($p, 'ipad') !== false) {
            $os = 'iPadOS';
        } elseif (strpos($p, 'win') !== false) {
            $os = 'Windows';
        } elseif (strpos($p, 'mac') !== false) {
            $os = 'macOS';
        } elseif (strpos($p, 'chrome os') !== false || $p === 'chromeos' || $p === 'cros') {
            $os = 'ChromeOS';
        } elseif (strpos($p, 'linux') !== false) {
            $os = 'Linux';
        } else {
            $os = $ch_plat;
        }
    }
    if ($os === '') {
        if (preg_match('/android/i', $ua)) {
            $os = 'Android';
        } elseif (preg_match('/ipad/i', $ua)) {
            $os = 'iPadOS';
        } elseif (preg_match('/iphone|ipod|cpu iphone os|ios/i', $ua)) {
            $os = 'iOS';
        } elseif (preg_match('/windows nt|win64|win32|windows phone/i', $ua) || !empty($row['windows_user'])) {
            $os = 'Windows';
        } elseif (preg_match('/macintosh|mac os x/i', $ua)) {
            $os = 'macOS';
        } elseif (preg_match('/cros/i', $ua)) {
            $os = 'ChromeOS';
        } elseif (preg_match('/linux|x11/i', $ua)) {
            $os = 'Linux';
        }
    }
    if ($installed || trim((string)($row['windows_user'] ?? '')) !== '') {
        $kind = 'pc';
        if ($os === '') {
            $os = 'Windows';
        }
    } else {
        $is_tablet = (bool)preg_match('/ipad|tablet|playbook|silk|android(?!.*mobile)/i', $ua);
        $is_phone = (bool)preg_match('/iphone|ipod|windows phone|iemobile|opera mini|blackberry|webos|(android.+mobile)|mobile safari|mobile\b/i', $ua);
        if ($ch_mobile === '?1' || $ch_mobile === '1') {
            $kind = $is_tablet ? 'tablet' : 'mobile';
        } elseif ($is_tablet) {
            $kind = 'tablet';
        } elseif ($is_phone) {
            $kind = 'mobile';
        } elseif ($ch_mobile === '?0' || $ch_mobile === '0') {
            $kind = 'pc';
        } elseif (preg_match('/windows nt|win64|win32|macintosh|mac os x|cros|linux|x11/i', $ua)) {
            $kind = 'pc';
        } else {
            $kind = 'unknown';
        }
    }
    $labels = [
        'pc' => 'PC',
        'mobile' => 'มือถือ',
        'tablet' => 'แท็บเล็ต',
        'unknown' => 'ไม่ทราบ',
    ];
    $label = $labels[$kind] ?? 'ไม่ทราบ';
    $win = strcasecmp($os, 'Windows') === 0;
    return [
        'kind' => $kind,
        'label' => $label,
        'os' => $os,
        'detail' => trim($label . ($os !== '' ? ' · ' . $os : '')),
        'can_install_agent' => $kind === 'pc' && ($win || $installed),
    ];
}

function tham_alert_device_sql_sets($con, $ua, array $row = [])
{
    $plat = tham_alert_request_ua_platform();
    if ($plat !== '') {
        $row['ua_platform'] = $plat;
        $row['ch_platform'] = $plat;
    }
    $row['ch_mobile'] = tham_alert_request_ch_mobile();
    $dev = tham_alert_classify_device($ua, $row);
    $esc = function ($s, $n) use ($con) {
        return mysqli_real_escape_string($con, mb_substr((string)$s, 0, $n));
    };
    $plat_store = $plat !== '' ? $plat : $dev['os'];
    return [
        "device_kind='" . $esc($dev['kind'], 16) . "'",
        "ua_platform='" . $esc($plat_store, 40) . "'",
    ];
}

function tham_alert_apply_device($con, $id, $ua, array $row = [])
{
    $id = (int)$id;
    if ($id <= 0) {
        return;
    }
    $sets = tham_alert_device_sql_sets($con, $ua, $row);
    if (!$sets) {
        return;
    }
    @mysqli_query($con, "UPDATE tham_alert_agents SET " . implode(',', $sets) . " WHERE id=$id LIMIT 1");
}

function tham_alert_config($con)
{
    tham_alert_ensure_tables($con);
    $secret = trim(tham_alert_sys_get($con, 'tham_alert_cron_secret', ''));
    if ($secret === '') {
        $secret = bin2hex(random_bytes(16));
        tham_alert_sys_set($con, 'tham_alert_cron_secret', $secret);
    }
    $look = (int)tham_alert_sys_get($con, 'tham_alert_lookback_sec', '10');
    if ($look < 3) {
        $look = 3;
    }
    if ($look > 60) {
        $look = 60;
    }
    $poll = (int)tham_alert_sys_get($con, 'tham_alert_poll_sec', '4');
    if ($poll < 2) {
        $poll = 2;
    }
    if ($poll > 15) {
        $poll = 15;
    }
    $ttl = (int)tham_alert_sys_get($con, 'tham_alert_event_ttl_min', '15');
    if ($ttl < 5) {
        $ttl = 5;
    }
    if ($ttl > 120) {
        $ttl = 120;
    }
    return [
        'ward' => tham_alert_sys_get($con, 'tham_alert_ward', '1') === '1',
        'doctor' => tham_alert_sys_get($con, 'tham_alert_doctor', '1') === '1',
        'phar_opd' => tham_alert_sys_get($con, 'tham_alert_phar_opd', '1') === '1',
        'phar_ipd' => tham_alert_sys_get($con, 'tham_alert_phar_ipd', '1') === '1',
        'lab_hint' => tham_alert_sys_get($con, 'tham_alert_lab_hint', '1') === '1',
        'lan_auto' => tham_alert_sys_get($con, 'tham_alert_lan_auto', '0') === '1',
        'allergy_case' => tham_alert_sys_get($con, 'tham_alert_allergy_case', '0') === '1',
        'lookback_sec' => $look,
        'poll_sec' => $poll,
        'event_ttl_min' => $ttl,
        'cron_secret' => $secret,
        'slave_ok' => trim(tham_alert_sys_get($con, 'h_host', '')) !== '',
        'master_ok' => trim(tham_alert_sys_get($con, 'h_master_host', '')) !== '',
    ];
}

function tham_alert_save_config($con, $post)
{
    foreach (['ward', 'doctor', 'phar_opd', 'phar_ipd'] as $p) {
        $on = (!empty($post[$p]) && (string)$post[$p] !== '0') ? '1' : '0';
        tham_alert_sys_set($con, 'tham_alert_' . $p, $on);
    }
    if (isset($post['lookback_sec'])) {
        $n = (int)$post['lookback_sec'];
        if ($n < 3) {
            $n = 3;
        }
        if ($n > 60) {
            $n = 60;
        }
        tham_alert_sys_set($con, 'tham_alert_lookback_sec', (string)$n);
    }
    if (isset($post['poll_sec'])) {
        $n = (int)$post['poll_sec'];
        if ($n < 2) {
            $n = 2;
        }
        if ($n > 15) {
            $n = 15;
        }
        tham_alert_sys_set($con, 'tham_alert_poll_sec', (string)$n);
    }
    if (array_key_exists('lab_hint', $post)) {
        $on = (!empty($post['lab_hint']) && (string)$post['lab_hint'] !== '0') ? '1' : '0';
        tham_alert_sys_set($con, 'tham_alert_lab_hint', $on);
    }
    if (array_key_exists('lan_auto', $post)) {
        $on = (!empty($post['lan_auto']) && (string)$post['lan_auto'] !== '0') ? '1' : '0';
        tham_alert_sys_set($con, 'tham_alert_lan_auto', $on);
    }
    return tham_alert_config($con);
}

function tham_alert_hos_has_table($hos, $table)
{
    static $cache = [];
    $k = spl_object_id($hos) . ':' . $table;
    if (isset($cache[$k])) {
        return $cache[$k];
    }
    $t = mysqli_real_escape_string($hos, $table);
    $q = @mysqli_query($hos, "SHOW TABLES LIKE '$t'");
    $cache[$k] = ($q && mysqli_num_rows($q) > 0);
    return $cache[$k];
}

function tham_alert_hos_has_column($hos, $table, $col)
{
    static $cache = [];
    $k = spl_object_id($hos) . ':' . $table . ':' . $col;
    if (isset($cache[$k])) {
        return $cache[$k];
    }
    $t = mysqli_real_escape_string($hos, $table);
    $c = mysqli_real_escape_string($hos, $col);
    $q = @mysqli_query($hos, "SHOW COLUMNS FROM `$t` LIKE '$c'");
    $cache[$k] = ($q && mysqli_num_rows($q) > 0);
    return $cache[$k];
}

function tham_alert_col($hos, $table, $candidates, $alias)
{
    foreach ($candidates as $c) {
        if (tham_alert_hos_has_column($hos, $table, $c)) {
            return "`$c` AS $alias";
        }
    }
    return "'' AS $alias";
}

function tham_alert_time_sql($hos, $table, $alias, $sec)
{
    $sec = (int)$sec;
    foreach (['entry_datetime', 'last_update', 'update_datetime', 'order_datetime'] as $c) {
        if (tham_alert_hos_has_column($hos, $table, $c)) {
            return "`$alias`.`$c` >= DATE_SUB(NOW(), INTERVAL $sec SECOND)";
        }
    }
    $date_col = null;
    foreach (['rxdate', 'order_date', 'vstdate'] as $c) {
        if (tham_alert_hos_has_column($hos, $table, $c)) {
            $date_col = $c;
            break;
        }
    }
    $time_col = null;
    foreach (['rxtime', 'order_time', 'vsttime'] as $c) {
        if (tham_alert_hos_has_column($hos, $table, $c)) {
            $time_col = $c;
            break;
        }
    }
    if ($date_col && $time_col) {
        return "`$alias`.`$date_col` >= DATE(DATE_SUB(NOW(), INTERVAL $sec SECOND))
            AND CONCAT(`$alias`.`$date_col`,' ',IF(`$alias`.`$time_col` IS NULL OR TRIM(`$alias`.`$time_col`)='', '00:00:00', `$alias`.`$time_col`))
                >= DATE_SUB(NOW(), INTERVAL $sec SECOND)";
    }
    if ($date_col) {
        return "`$alias`.`$date_col` >= DATE(DATE_SUB(NOW(), INTERVAL $sec SECOND))";
    }
    return '1=0';
}

function tham_alert_in_list($hos, array $vals)
{
    $out = [];
    foreach ($vals as $v) {
        $v = trim((string)$v);
        if ($v === '') {
            continue;
        }
        $out[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return $out ? implode(',', $out) : "''";
}

function tham_alert_trigger_rows($con, $pipeline = '')
{
    tham_alert_ensure_tables($con);
    $sql = "SELECT id, icode, drug_name, use_doctor, use_phar_opd, use_phar_ipd, active
            FROM tham_alert_trigger_drugs WHERE active=1";
    if ($pipeline === 'doctor') {
        $sql .= " AND use_doctor=1";
    } elseif ($pipeline === 'phar_opd') {
        $sql .= " AND use_phar_opd=1";
    } elseif ($pipeline === 'phar_ipd') {
        $sql .= " AND use_phar_ipd=1";
    }
    $sql .= " ORDER BY drug_name, icode";
    $q = @mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function tham_alert_trigger_icodes($con, $pipeline)
{
    $out = [];
    foreach (tham_alert_trigger_rows($con, $pipeline) as $r) {
        $ic = trim((string)$r['icode']);
        if ($ic !== '') {
            $out[$ic] = (string)$r['drug_name'];
        }
    }
    return $out;
}

function tham_alert_add_drug($con, $icode, $name, $flags = [])
{
    tham_alert_ensure_tables($con);
    $icode = trim((string)$icode);
    if ($icode === '') {
        return ['ok' => false, 'error' => 'icode ว่าง'];
    }
    $name = trim((string)$name);
    $d = !empty($flags['use_doctor']) ? 1 : 0;
    $o = !empty($flags['use_phar_opd']) ? 1 : 0;
    $i = !empty($flags['use_phar_ipd']) ? 1 : 0;
    if (!$d && !$o && !$i) {
        $d = $o = $i = 1;
    }
    $ic = mysqli_real_escape_string($con, $icode);
    $nm = mysqli_real_escape_string($con, mb_substr($name, 0, 180));
    $ok = @mysqli_query($con, "INSERT INTO tham_alert_trigger_drugs (icode, drug_name, use_doctor, use_phar_opd, use_phar_ipd, active)
        VALUES ('$ic','$nm',$d,$o,$i,1)
        ON DUPLICATE KEY UPDATE drug_name=IF(VALUES(drug_name)='', drug_name, VALUES(drug_name)),
            use_doctor=VALUES(use_doctor), use_phar_opd=VALUES(use_phar_opd),
            use_phar_ipd=VALUES(use_phar_ipd), active=1");
    return ['ok' => (bool)$ok, 'error' => $ok ? '' : mysqli_error($con)];
}

function tham_alert_delete_drug($con, $id)
{
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)@mysqli_query($con, "DELETE FROM tham_alert_trigger_drugs WHERE id=$id LIMIT 1");
}

function tham_alert_connect_slave($con)
{
    if (!function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    }
    return @hosxp_connect($con, 30);
}

function tham_alert_connect_master($con)
{
    if (!function_exists('hosxp_connect_master')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    }
    return @hosxp_connect_master($con, 30);
}

function tham_alert_slave_patient_name($slave, $hn)
{
    $hn = trim((string)$hn);
    if ($hn === '' || !$slave) {
        return '';
    }
    if (!tham_alert_hos_has_table($slave, 'patient')) {
        return '';
    }
    $h = mysqli_real_escape_string($slave, $hn);
    $pname = tham_alert_hos_has_column($slave, 'patient', 'pname') ? 'pname' : "''";
    $fname = tham_alert_hos_has_column($slave, 'patient', 'fname') ? 'fname' : "''";
    $lname = tham_alert_hos_has_column($slave, 'patient', 'lname') ? 'lname' : "''";
    $q = @mysqli_query($slave, "SELECT CONCAT(IFNULL($pname,''), IFNULL($fname,''), ' ', IFNULL($lname,'')) AS n FROM patient WHERE hn='$h' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return trim(preg_replace('/\s+/', ' ', (string)$r['n']));
    }
    return '';
}

function tham_alert_slave_last_lab_hint($slave, $hn)
{
    $hn = trim((string)$hn);
    if ($hn === '' || !$slave || !tham_alert_hos_has_table($slave, 'lab_head') || !tham_alert_hos_has_table($slave, 'lab_order')) {
        return '';
    }
    $h = mysqli_real_escape_string($slave, $hn);
    $date_col = tham_alert_hos_has_column($slave, 'lab_head', 'report_date') ? 'h.report_date' : 'h.order_date';
    $q = @mysqli_query($slave, "SELECT o.lab_items_name_ref AS nm,
            CAST(CONVERT(o.lab_order_result USING utf8) AS CHAR) AS val,
            $date_col AS d
        FROM lab_head h
        INNER JOIN lab_order o ON o.lab_order_number = h.lab_order_number
        WHERE h.hn='$h' AND h.confirm_report='Y'
          AND (o.lab_items_name_ref LIKE '%Creatinine%' OR o.lab_items_name_ref LIKE '%eGFR%'
               OR o.lab_items_code IN ('201','202','203','Lab01'))
        ORDER BY $date_col DESC
        LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $nm = trim((string)$r['nm']);
        $val = trim((string)$r['val']);
        $d = trim((string)$r['d']);
        if ($val !== '') {
            return trim($nm . ' ' . $val . ($d !== '' ? " ($d)" : ''));
        }
    }
    return '';
}

function tham_alert_enqueue($con, array $ev)
{
    tham_alert_ensure_tables($con);
    $cfg = tham_alert_config($con);
    $ttl = (int)$cfg['event_ttl_min'];
    $key = trim((string)($ev['event_key'] ?? ''));
    if ($key === '') {
        $key = md5(implode('|', [
            $ev['pipeline'] ?? '', $ev['hn'] ?? '', $ev['vn'] ?? '', $ev['an'] ?? '',
            $ev['icode'] ?? '', $ev['computername'] ?? '', date('YmdHi'),
        ]));
    }
    $esc = function ($s, $n) use ($con) {
        $s = (string)$s;
        if (function_exists('mb_substr')) {
            $s = mb_substr($s, 0, $n);
        } elseif (strlen($s) > $n) {
            $s = substr($s, 0, $n);
        }
        return mysqli_real_escape_string($con, $s);
    };
    $sql = "INSERT IGNORE INTO tham_alert_events
        (pipeline, event_key, station_id, group_name, hn, vn, an, icode, drug_name, staff, computername, title, message, expires_at)
        VALUES (
            '" . $esc($ev['pipeline'] ?? '', 20) . "',
            '" . $esc($key, 96) . "',
            '" . $esc($ev['station_id'] ?? '', 80) . "',
            '" . $esc($ev['group_name'] ?? '', 80) . "',
            '" . $esc($ev['hn'] ?? '', 20) . "',
            '" . $esc($ev['vn'] ?? '', 20) . "',
            '" . $esc($ev['an'] ?? '', 20) . "',
            '" . $esc($ev['icode'] ?? '', 20) . "',
            '" . $esc($ev['drug_name'] ?? '', 180) . "',
            '" . $esc($ev['staff'] ?? '', 50) . "',
            '" . $esc($ev['computername'] ?? '', 80) . "',
            '" . $esc($ev['title'] ?? '', 180) . "',
            '" . $esc($ev['message'] ?? '', 500) . "',
            DATE_ADD(NOW(), INTERVAL $ttl MINUTE)
        )";
    @mysqli_query($con, $sql);
    return mysqli_affected_rows($con) > 0;
}

function tham_alert_purge($con)
{
    @mysqli_query($con, "DELETE FROM tham_alert_events WHERE expires_at IS NOT NULL AND expires_at < NOW()");
}

function tham_alert_query_rows($hos, $sql)
{
    $rows = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return [null, mysqli_error($hos)];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $rows[] = $r;
    }
    return [$rows, ''];
}

function tham_alert_scan_opitemrece($master, array $icodes, $sec, $visit_kind)
{
    if (!$icodes || !tham_alert_hos_has_table($master, 'opitemrece')) {
        return [[], ''];
    }
    $in = tham_alert_in_list($master, array_keys($icodes));
    $time = tham_alert_time_sql($master, 'opitemrece', 'o', $sec);
    $sel = [
        tham_alert_col($master, 'opitemrece', ['hn'], 'hn'),
        tham_alert_col($master, 'opitemrece', ['vn'], 'vn'),
        tham_alert_col($master, 'opitemrece', ['an'], 'an'),
        tham_alert_col($master, 'opitemrece', ['icode'], 'icode'),
        tham_alert_col($master, 'opitemrece', ['staff'], 'staff'),
        tham_alert_col($master, 'opitemrece', ['computername', 'computer', 'pc_name'], 'computername'),
        tham_alert_col($master, 'opitemrece', ['hos_guid', 'guid'], 'hos_guid'),
    ];
    $visit = '1=1';
    if ($visit_kind === 'opd') {
        $visit = "(o.vn IS NOT NULL AND TRIM(o.vn)<>'') AND (o.an IS NULL OR TRIM(o.an)='')";
        if (!tham_alert_hos_has_column($master, 'opitemrece', 'an')) {
            $visit = "(o.vn IS NOT NULL AND TRIM(o.vn)<>'')";
        }
    } elseif ($visit_kind === 'ipd') {
        $visit = "(o.an IS NOT NULL AND TRIM(o.an)<>'')";
        if (!tham_alert_hos_has_column($master, 'opitemrece', 'an')) {
            return [[], 'ตาราง opitemrece ไม่มีคอลัมน์ an'];
        }
    }
    $sql = "SELECT " . implode(', ', $sel) . "
            FROM opitemrece o
            WHERE o.icode IN ($in) AND $time AND $visit
            LIMIT 200";
    return tham_alert_query_rows($master, $sql);
}

function tham_alert_scan_rx_operator($master, $sec)
{
    if (!tham_alert_hos_has_table($master, 'rx_operator')) {
        return [null, 'ไม่พบตาราง rx_operator บน Master'];
    }
    $time = tham_alert_time_sql($master, 'rx_operator', 'r', $sec);
    $sel = [
        tham_alert_col($master, 'rx_operator', ['vn'], 'vn'),
        tham_alert_col($master, 'rx_operator', ['hn'], 'hn'),
        tham_alert_col($master, 'rx_operator', ['staff'], 'staff'),
        tham_alert_col($master, 'rx_operator', ['computername', 'computer', 'pc_name'], 'computername'),
        tham_alert_col($master, 'rx_operator', ['hos_guid', 'guid'], 'hos_guid'),
    ];
    $sql = "SELECT " . implode(', ', $sel) . " FROM rx_operator r WHERE $time LIMIT 80";
    return tham_alert_query_rows($master, $sql);
}

function tham_alert_slave_vn_trigger_hits($slave, array $vns, array $icodes)
{
    $hits = [];
    if (!$slave || !$vns || !$icodes || !tham_alert_hos_has_table($slave, 'opitemrece')) {
        return $hits;
    }
    $in_vn = tham_alert_in_list($slave, $vns);
    $in_ic = tham_alert_in_list($slave, array_keys($icodes));
    $sel = [
        tham_alert_col($slave, 'opitemrece', ['hn'], 'hn'),
        tham_alert_col($slave, 'opitemrece', ['vn'], 'vn'),
        tham_alert_col($slave, 'opitemrece', ['icode'], 'icode'),
        tham_alert_col($slave, 'opitemrece', ['hos_guid', 'guid'], 'hos_guid'),
    ];
    $sql = "SELECT " . implode(', ', $sel) . "
            FROM opitemrece
            WHERE vn IN ($in_vn) AND icode IN ($in_ic)
            LIMIT 400";
    [$rows, $err] = tham_alert_query_rows($slave, $sql);
    if ($err || !$rows) {
        return $hits;
    }
    foreach ($rows as $r) {
        $hits[] = $r;
    }
    return $hits;
}

function tham_alert_scan_ipt_order($master, array $icodes, $sec)
{
    if (!$icodes) {
        return [[], ''];
    }
    $table = '';
    foreach (['ipt_order_item', 'ipd_order_item', 'iptordr'] as $t) {
        if (tham_alert_hos_has_table($master, $t)) {
            $table = $t;
            break;
        }
    }
    if ($table === '') {
        return [null, 'no_ipt_order_item'];
    }
    $in = tham_alert_in_list($master, array_keys($icodes));
    $time = tham_alert_time_sql($master, $table, 'i', $sec);
    $sel = [
        tham_alert_col($master, $table, ['hn'], 'hn'),
        tham_alert_col($master, $table, ['an'], 'an'),
        tham_alert_col($master, $table, ['icode'], 'icode'),
        tham_alert_col($master, $table, ['staff'], 'staff'),
        tham_alert_col($master, $table, ['computername', 'computer', 'pc_name'], 'computername'),
        tham_alert_col($master, $table, ['hos_guid', 'guid'], 'hos_guid'),
    ];
    $sql = "SELECT " . implode(', ', $sel) . "
            FROM `$table` i
            WHERE i.icode IN ($in) AND $time
            LIMIT 200";
    return tham_alert_query_rows($master, $sql);
}

function tham_alert_build_message($name, $hn, $drug, $lab)
{
    $who = $name !== '' ? $name : 'HN ' . $hn;
    $msg = $who . ' — ' . $drug;
    if ($lab !== '') {
        $msg .= ' | Lab: ' . $lab;
    }
    return mb_substr($msg, 0, 500);
}

function tham_alert_enrich_and_enqueue($con, $slave, $pipeline, array $row, array $icodes, $lab_hint = true)
{
    $icode = trim((string)($row['icode'] ?? ''));
    $drug = $icodes[$icode] ?? $icode;
    $hn = trim((string)($row['hn'] ?? ''));
    $vn = trim((string)($row['vn'] ?? ''));
    $an = trim((string)($row['an'] ?? ''));
    $comp = trim((string)($row['computername'] ?? ''));
    $guid = trim((string)($row['hos_guid'] ?? ''));
    $name = ($hn !== '' && $slave) ? tham_alert_slave_patient_name($slave, $hn) : '';
    $lab = ($lab_hint && $hn !== '' && $slave) ? tham_alert_slave_last_lab_hint($slave, $hn) : '';
    $titles = [
        'doctor' => 'ยาเสี่ยงขณะคีย์ (แพทย์ OPD)',
        'phar_opd' => 'ยาเสี่ยงขณะจัดยา OPD',
        'phar_ipd' => 'ยาเสี่ยงขณะคีย์ IPD',
        'ward' => 'แจ้งเตือนวอร์ด',
    ];
    $key = $guid !== ''
        ? $pipeline . '|' . $guid
        : $pipeline . '|' . $hn . '|' . $vn . '|' . $an . '|' . $icode . '|' . $comp . '|' . date('YmdHi');
    return tham_alert_enqueue($con, [
        'pipeline' => $pipeline,
        'event_key' => substr($key, 0, 96),
        'station_id' => $comp,
        'hn' => $hn,
        'vn' => $vn,
        'an' => $an,
        'icode' => $icode,
        'drug_name' => $drug,
        'staff' => $row['staff'] ?? '',
        'computername' => $comp,
        'title' => $titles[$pipeline] ?? 'THAM Alert',
        'message' => tham_alert_build_message($name, $hn, $drug, $lab),
    ]);
}

function tham_alert_tick($con)
{
    $cfg = tham_alert_config($con);
    tham_alert_purge($con);
    $out = [
        'ok' => true,
        'ward' => $cfg['ward'] ? 'on' : 'off',
        'doctor' => ['on' => $cfg['doctor'], 'found' => 0, 'queued' => 0, 'error' => ''],
        'phar_opd' => ['on' => $cfg['phar_opd'], 'found' => 0, 'queued' => 0, 'error' => ''],
        'phar_ipd' => ['on' => $cfg['phar_ipd'], 'found' => 0, 'queued' => 0, 'error' => ''],
        'lookback_sec' => $cfg['lookback_sec'],
    ];
    $j2_on = tham_alert_j2_eval_enabled($con);
    $need_hos = $cfg['doctor'] || $cfg['phar_opd'] || $cfg['phar_ipd'] || $j2_on;
    if (!$need_hos) {
        return $out;
    }
    $master = tham_alert_connect_master($con);
    if (!$master) {
        $err = 'เชื่อม Master ไม่ได้ (hosxp_master_setting.php)';
        foreach (['doctor', 'phar_opd', 'phar_ipd'] as $p) {
            if ($cfg[$p]) {
                $out[$p]['error'] = $err;
            }
        }
        if ($j2_on) {
            $out['j2_eval'] = ['on' => true, 'found' => 0, 'queued' => 0, 'error' => $err];
        }
        return $out;
    }
    $slave = tham_alert_connect_slave($con);
    if (!$slave) {
        $out['slave_error'] = 'เชื่อม Slave ไม่ได้ (hosxp_setting.php) — จะบันทึก icode โดยไม่มีชื่อผู้ป่วย';
    }
    $sec = (int)$cfg['lookback_sec'];
    $lab_hint = !empty($cfg['lab_hint']);

    if ($cfg['doctor']) {
        $map = tham_alert_trigger_icodes($con, 'doctor');
        if (!$map) {
            $out['doctor']['error'] = 'ยังไม่มียาเสี่ยงสำหรับ pipeline นี้';
        } else {
            [$rows, $err] = tham_alert_scan_opitemrece($master, $map, $sec, 'opd');
            if ($err) {
                $out['doctor']['error'] = $err;
            } else {
                $out['doctor']['found'] = count($rows);
                foreach ($rows as $r) {
                    if (tham_alert_enrich_and_enqueue($con, $slave, 'doctor', $r, $map, $lab_hint)) {
                        $out['doctor']['queued']++;
                    }
                }
            }
        }
    }

    if ($cfg['phar_opd']) {
        $map = tham_alert_trigger_icodes($con, 'phar_opd');
        if (!$map) {
            $out['phar_opd']['error'] = 'ยังไม่มียาเสี่ยงสำหรับ pipeline นี้';
        } else {
            [$ops, $err] = tham_alert_scan_rx_operator($master, $sec);
            if ($ops === null) {
                $out['phar_opd']['error'] = $err;
            } else {
                $by_vn = [];
                foreach ($ops as $op) {
                    $vn = trim((string)($op['vn'] ?? ''));
                    if ($vn !== '') {
                        $by_vn[$vn] = $op;
                    }
                }
                $hits = $slave ? tham_alert_slave_vn_trigger_hits($slave, array_keys($by_vn), $map) : [];
                $out['phar_opd']['found'] = count($hits);
                foreach ($hits as $h) {
                    $vn = trim((string)($h['vn'] ?? ''));
                    $op = $by_vn[$vn] ?? [];
                    $h['staff'] = $op['staff'] ?? '';
                    $h['computername'] = $op['computername'] ?? '';
                    if (trim((string)($h['hn'] ?? '')) === '') {
                        $h['hn'] = $op['hn'] ?? '';
                    }
                    if (tham_alert_enrich_and_enqueue($con, $slave, 'phar_opd', $h, $map, $lab_hint)) {
                        $out['phar_opd']['queued']++;
                    }
                }
            }
        }
    }

    if ($cfg['phar_ipd']) {
        $map = tham_alert_trigger_icodes($con, 'phar_ipd');
        if (!$map) {
            $out['phar_ipd']['error'] = 'ยังไม่มียาเสี่ยงสำหรับ pipeline นี้';
        } else {
            [$rows, $err] = tham_alert_scan_ipt_order($master, $map, $sec);
            if ($rows === null && $err === 'no_ipt_order_item') {
                [$rows, $err] = tham_alert_scan_opitemrece($master, $map, $sec, 'ipd');
            }
            if ($err) {
                $out['phar_ipd']['error'] = $err;
            } else {
                $out['phar_ipd']['found'] = count($rows);
                foreach ($rows as $r) {
                    if (tham_alert_enrich_and_enqueue($con, $slave, 'phar_ipd', $r, $map, $lab_hint)) {
                        $out['phar_ipd']['queued']++;
                    }
                }
            }
        }
    }

    if ($j2_on && $master) {
        $out['j2_eval'] = tham_alert_scan_j2_eval($con, $master, $sec);
    }

    if ($master) {
        @mysqli_close($master);
    }
    if ($slave) {
        @mysqli_close($slave);
    }
    return $out;
}

function tham_alert_j2_eval_enabled($con)
{
    return tham_alert_sys_get($con, 'tham_alert_j2_eval', '1') === '1';
}

function tham_alert_set_j2_eval($con, $on)
{
    return tham_alert_sys_set($con, 'tham_alert_j2_eval', $on ? '1' : '0');
}

function tham_alert_j2_form_icodes($master)
{
    if (!function_exists('dej2_bucket')) {
        require_once __DIR__ . '/drug_eval_j2_helper.php';
    }
    $map = [];
    $q = @mysqli_query($master, "SELECT icode, CAST(CONVERT(name USING utf8) AS CHAR) AS name
        FROM drugitems
        WHERE istatus = 'Y'
          AND (name LIKE '%evacizumab%' OR name LIKE '%rlotinib%')");
    if (!$q) {
        return $map;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $name = trim((string)($r['name'] ?? ''));
        $icode = trim((string)($r['icode'] ?? ''));
        if ($icode === '' || $name === '') {
            continue;
        }
        $bucket = dej2_bucket($name);
        if (empty($bucket['form'])) {
            continue;
        }
        $map[$icode] = [
            'name' => $name,
            'label' => (string)$bucket['label'],
            'form' => (string)$bucket['form'],
        ];
    }
    return $map;
}

function tham_alert_j2_ensure_token_table($con)
{
    @mysqli_query($con, "CREATE TABLE IF NOT EXISTS tham_hosxp_login_token (
        token CHAR(48) NOT NULL,
        loginname VARCHAR(80) NOT NULL DEFAULT '',
        hn VARCHAR(20) NOT NULL DEFAULT '',
        icode VARCHAR(20) NOT NULL DEFAULT '',
        form_id VARCHAR(40) NOT NULL DEFAULT '',
        an VARCHAR(20) NOT NULL DEFAULT '',
        vn VARCHAR(20) NOT NULL DEFAULT '',
        expires_at DATETIME NOT NULL,
        used_at DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (token),
        KEY idx_exp (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    foreach (['an' => "ALTER TABLE tham_hosxp_login_token ADD COLUMN an VARCHAR(20) NOT NULL DEFAULT '' AFTER form_id",
              'vn' => "ALTER TABLE tham_hosxp_login_token ADD COLUMN vn VARCHAR(20) NOT NULL DEFAULT '' AFTER an"] as $col => $ddl) {
        $q = @mysqli_query($con, "SHOW COLUMNS FROM tham_hosxp_login_token LIKE '$col'");
        if (!$q || mysqli_num_rows($q) === 0) {
            @mysqli_query($con, $ddl);
        }
    }
}

function tham_alert_j2_lookup_visit($con, $hn, $icode)
{
    $empty = ['an' => '', 'vn' => ''];
    $hn = trim((string)$hn);
    $icode = trim((string)$icode);
    if ($hn === '' || $icode === '') {
        return $empty;
    }
    $master = tham_alert_connect_master($con);
    if (!$master) {
        return $empty;
    }
    mysqli_set_charset($master, 'utf8');
    $h = mysqli_real_escape_string($master, $hn);
    $ic = mysqli_real_escape_string($master, $icode);
    $q = @mysqli_query($master, "SELECT an, vn FROM opitemrece
        WHERE hn='$h' AND icode='$ic' AND rxdate>=DATE_SUB(CURDATE(), INTERVAL 2 DAY)
        ORDER BY rxdate DESC, rxtime DESC LIMIT 1");
    $row = ($q && ($got = mysqli_fetch_assoc($q))) ? $got : [];
    mysqli_close($master);
    $an = trim((string)($row['an'] ?? ''));
    $vn = trim((string)($row['vn'] ?? ''));
    if ($an === '' && $vn === '') {
        $h2 = mysqli_real_escape_string($con, $hn);
        $ic2 = mysqli_real_escape_string($con, $icode);
        $lq = @mysqli_query($con, "SELECT an, vn FROM tham_alert_events
            WHERE hn='$h2' AND icode='$ic2' AND (an<>'' OR vn<>'')
            ORDER BY id DESC LIMIT 1");
        $local = $lq ? mysqli_fetch_assoc($lq) : null;
        $an = trim((string)($local['an'] ?? ''));
        $vn = trim((string)($local['vn'] ?? ''));
    }
    if ($an === '' && $vn === '') {
        return $empty;
    }
    return ['an' => $an, 'vn' => $vn];
}

function tham_alert_j2_issue_token($con, $loginname, $hn, $icode, $form_id, $an = '', $vn = '')
{
    $loginname = trim((string)$loginname);
    if ($loginname === '') {
        return '';
    }
    tham_alert_j2_ensure_token_table($con);
    @mysqli_query($con, "DELETE FROM tham_hosxp_login_token WHERE expires_at < NOW() OR used_at IS NOT NULL");
    try {
        $token = bin2hex(random_bytes(24));
    } catch (Exception $e) {
        $token = sha1($loginname . '|' . $hn . '|' . microtime(true) . '|' . mt_rand());
    }
    $esc = function ($s, $n) use ($con) {
        $s = (string)$s;
        if (function_exists('mb_substr')) {
            $s = mb_substr($s, 0, $n);
        } elseif (strlen($s) > $n) {
            $s = substr($s, 0, $n);
        }
        return mysqli_real_escape_string($con, $s);
    };
    $ok = @mysqli_query($con, "INSERT INTO tham_hosxp_login_token
        (token, loginname, hn, icode, form_id, an, vn, expires_at)
        VALUES (
            '" . $esc($token, 48) . "',
            '" . $esc($loginname, 80) . "',
            '" . $esc($hn, 20) . "',
            '" . $esc($icode, 20) . "',
            '" . $esc($form_id, 40) . "',
            '" . $esc($an, 20) . "',
            '" . $esc($vn, 20) . "',
            DATE_ADD(NOW(), INTERVAL 20 MINUTE)
        )");
    return $ok ? $token : '';
}

function tham_alert_j2_redeem_token($con, $token)
{
    $token = strtolower(preg_replace('/[^a-f0-9]/', '', (string)$token));
    if (strlen($token) < 32) {
        return null;
    }
    tham_alert_j2_ensure_token_table($con);
    $esc = mysqli_real_escape_string($con, $token);
    $q = @mysqli_query($con, "SELECT token, loginname, hn, icode, form_id, an, vn
        FROM tham_hosxp_login_token
        WHERE token='$esc' AND used_at IS NULL AND expires_at >= NOW()
        LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return null;
    }
    $loginname = trim((string)$row['loginname']);
    $user = null;
    $uq = @mysqli_query($con, "SELECT * FROM users WHERE username='" . mysqli_real_escape_string($con, $loginname) . "' LIMIT 1");
    if ($uq && ($found = mysqli_fetch_assoc($uq))) {
        $user = $found;
    }
    if (!$user && $loginname !== '') {
        if (!function_exists('tham_opduser_connect')) {
            require_once __DIR__ . '/opduser_auth_helper.php';
        }
        $hos = tham_opduser_connect($con, 8);
        if ($hos) {
            $opd = tham_opduser_fetch_by_loginname($hos, $loginname);
            mysqli_close($hos);
            if ($opd) {
                $synced = tham_opduser_sync_local_user($con, $opd);
                if ($synced) {
                    $uq = @mysqli_query($con, "SELECT * FROM users WHERE id=" . (int)$synced['id'] . " LIMIT 1");
                    if ($uq) {
                        $user = mysqli_fetch_assoc($uq);
                    }
                }
            }
        }
    }
    if (!$user) {
        return null;
    }
    @mysqli_query($con, "UPDATE tham_hosxp_login_token SET used_at=NOW() WHERE token='$esc' AND used_at IS NULL LIMIT 1");
    return [
        'user' => $user,
        'hn' => trim((string)$row['hn']),
        'icode' => trim((string)$row['icode']),
        'form_id' => trim((string)$row['form_id']),
        'an' => trim((string)($row['an'] ?? '')),
        'vn' => trim((string)($row['vn'] ?? '')),
    ];
}

function tham_alert_j2_online_pc($master, $loginname)
{
    $loginname = trim((string)$loginname);
    if ($loginname === '' || !tham_alert_hos_has_table($master, 'onlineuser')) {
        return '';
    }
    $esc = mysqli_real_escape_string($master, $loginname);
    $q = @mysqli_query($master, "SELECT servername, computername FROM onlineuser
        WHERE kskloginname='$esc'
        ORDER BY ksklogintime DESC LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return '';
    }
    $server = trim((string)($row['servername'] ?? ''));
    $comp = trim((string)($row['computername'] ?? ''));
    if ($server !== '' && !preg_match('/^\d+\.\d+\.\d+\.\d+$/', $server)) {
        return $server;
    }
    if ($comp !== '' && !preg_match('/^\d+\.\d+\.\d+\.\d+$/', $comp)) {
        return $comp;
    }
    return '';
}

function tham_alert_scan_medplan_ipd($master, array $icodes, $sec)
{
    if (!$icodes || !tham_alert_hos_has_table($master, 'medplan_ipd')) {
        return [[], ''];
    }
    $in = tham_alert_in_list($master, array_keys($icodes));
    $sec = max(5, (int)$sec);
    $hn = tham_alert_hos_has_table($master, 'ipt')
        ? "(SELECT i.hn FROM ipt i WHERE i.an = p.an LIMIT 1) AS hn"
        : "'' AS hn";
    $guid = tham_alert_hos_has_column($master, 'medplan_ipd', 'hos_guid')
        ? 'p.hos_guid AS hos_guid'
        : "'' AS hos_guid";
    $sql = "SELECT $hn, p.an AS an, '' AS vn, p.icode AS icode,
            IF(TRIM(IFNULL(p.staff,''))='', TRIM(IFNULL(p.doctor,'')), TRIM(p.staff)) AS staff,
            '' AS computername, $guid
        FROM medplan_ipd p
        WHERE p.icode IN ($in)
          AND p.last_update >= DATE_SUB(NOW(), INTERVAL $sec SECOND)
        LIMIT 100";
    return tham_alert_query_rows($master, $sql);
}

function tham_alert_scan_j2_eval($con, $master, $sec)
{
    $out = ['on' => true, 'drugs' => 0, 'found' => 0, 'queued' => 0, 'error' => ''];
    $map = tham_alert_j2_form_icodes($master);
    $out['drugs'] = count($map);
    if (!$map) {
        $out['error'] = 'ไม่พบยา จ2 ที่มีแบบประเมินบน Master';
        return $out;
    }
    $icode_names = [];
    foreach ($map as $icode => $meta) {
        $icode_names[$icode] = $meta['label'];
    }
    $rows = [];
    $wide = max(90, (int)$sec);
    [$opd, $err1] = tham_alert_scan_opitemrece($master, $icode_names, $wide, '');
    if ($err1) {
        $out['error'] = $err1;
    } elseif (is_array($opd)) {
        $rows = array_merge($rows, $opd);
    }
    [$ipd, $err2] = tham_alert_scan_ipt_order($master, $icode_names, $wide);
    if (is_array($ipd)) {
        $rows = array_merge($rows, $ipd);
    } elseif ($err2 && $err2 !== 'no_ipt_order_item' && $out['error'] === '') {
        $out['error'] = $err2;
    }
    [$med, $err3] = tham_alert_scan_medplan_ipd($master, $icode_names, $wide);
    if (is_array($med)) {
        $rows = array_merge($rows, $med);
    } elseif ($err3 && $out['error'] === '') {
        $out['error'] = $err3;
    }
    $out['found'] = count($rows);
    $base = 'http://61.7.167.197/thamhossafe/drug_eval_j2.php';
    foreach ($rows as $r) {
        $icode = trim((string)($r['icode'] ?? ''));
        $meta = $map[$icode] ?? null;
        $staff = trim((string)($r['staff'] ?? ''));
        $comp = trim((string)($r['computername'] ?? ''));
        if ($comp === '' || preg_match('/^\d+\.\d+\.\d+\.\d+$/', $comp)) {
            $online = tham_alert_j2_online_pc($master, $staff);
            if ($online !== '') {
                $comp = $online;
            }
        }
        $hn = trim((string)($r['hn'] ?? ''));
        if (!$meta || $comp === '' || $hn === '') {
            continue;
        }
        $pipe = 'j2';
        $station = $comp;
        $esc_comp = mysqli_real_escape_string($con, $comp);
        $aq = @mysqli_query($con, "SELECT pipeline, station_id, computername FROM tham_alert_agents
            WHERE LOWER(station_id)=LOWER('$esc_comp') OR LOWER(computername)=LOWER('$esc_comp')
            ORDER BY last_agent_at DESC LIMIT 1");
        if ($aq && ($agent = mysqli_fetch_assoc($aq))) {
            $agent_pipe = tham_alert_normalize_pipeline($agent['pipeline'] ?? '');
            if ($agent_pipe !== '' && $agent_pipe !== 'all') {
                $pipe = $agent_pipe;
            }
            $agent_station = trim((string)($agent['station_id'] ?? ''));
            if ($agent_station !== '') {
                $station = $agent_station;
            }
        }
        $an = trim((string)($r['an'] ?? ''));
        $vn = trim((string)($r['vn'] ?? ''));
        $token = tham_alert_j2_issue_token($con, $staff, $hn, $icode, $meta['form'], $an, $vn);
        $qs = 'hn=' . rawurlencode($hn)
            . '&icode=' . rawurlencode($icode)
            . '&form=' . rawurlencode($meta['form'])
            . '&phase=first'
            . ($an !== '' ? '&an=' . rawurlencode($an) : '')
            . ($vn !== '' ? '&vn=' . rawurlencode($vn) : '');
        if ($token !== '') {
            $qs .= '&hosxp=' . rawurlencode($token);
        }
        $guid = trim((string)($r['hos_guid'] ?? ''));
        $key = 'j2|' . ($guid !== '' ? $guid : md5($hn . '|' . $icode . '|' . trim((string)($r['an'] ?? '')) . '|' . trim((string)($r['vn'] ?? '')) . '|' . $comp));
        $msg = $meta['label'] . "\nHN " . $hn . "\nเปิดแบบประเมิน " . $base . '?' . $qs;
        if (function_exists('mb_substr')) {
            $msg = mb_substr($msg, 0, 500);
        } elseif (strlen($msg) > 500) {
            $msg = substr($msg, 0, 500);
        }
        $ok = tham_alert_enqueue($con, [
            'pipeline' => $pipe,
            'event_key' => substr($key, 0, 96),
            'station_id' => $station,
            'computername' => $comp,
            'hn' => $hn,
            'vn' => $r['vn'] ?? '',
            'an' => $r['an'] ?? '',
            'icode' => $icode,
            'drug_name' => $meta['label'],
            'staff' => $staff,
            'title' => 'ต้องประเมินยา จ2',
            'message' => $msg,
        ]);
        if ($ok) {
            $out['queued']++;
        }
    }
    return $out;
}

function tham_alert_normalize_pipeline($raw)
{
    $s = strtolower(trim((string)$raw));
    $s = str_replace(['-', ' '], '_', $s);
    $map = [
        'ward' => 'ward',
        'doctor' => 'doctor',
        'phar_opd' => 'phar_opd',
        'pharmacy_opd' => 'phar_opd',
        'pharopd' => 'phar_opd',
        'phar_ipd' => 'phar_ipd',
        'pharmacy_ipd' => 'phar_ipd',
        'pharipd' => 'phar_ipd',
        'all' => 'all',
    ];
    return $map[$s] ?? preg_replace('/[^a-z_]/', '', $s);
}

function tham_alert_pending($con, $pipeline, $station_id, $since_id = 0, $group_name = '')
{
    tham_alert_ensure_tables($con);
    $pipeline = tham_alert_normalize_pipeline($pipeline);
    $since_id = (int)$since_id;
    $st = mysqli_real_escape_string($con, trim((string)$station_id));
    $grp = mysqli_real_escape_string($con, trim((string)$group_name));
    $where = "id > $since_id AND (expires_at IS NULL OR expires_at >= NOW())";
    if ($pipeline !== '' && $pipeline !== 'all') {
        $p = mysqli_real_escape_string($con, $pipeline);
        $where .= " AND pipeline='$p'";
    }
    $ors = [];
    if ($st !== '') {
        $ors[] = "station_id='$st'";
        $ors[] = "computername='$st'";
    }
    if ($grp !== '') {
        $ors[] = "group_name='$grp'";
    }
    if ($ors) {
        $ors[] = "(station_id='' AND computername='')";
        $where .= " AND (" . implode(' OR ', $ors) . ")";
    }
    $q = @mysqli_query($con, "SELECT id, pipeline, station_id, group_name, hn, vn, an, icode, drug_name,
            staff, computername, title, message, created_at
        FROM tham_alert_events
        WHERE $where
        ORDER BY id ASC
        LIMIT 50");
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function tham_alert_recent($con, $limit = 30)
{
    tham_alert_ensure_tables($con);
    $limit = max(1, min(100, (int)$limit));
    $q = @mysqli_query($con, "SELECT id, pipeline, station_id, hn, vn, an, icode, drug_name, computername, title, message, created_at
        FROM tham_alert_events ORDER BY id DESC LIMIT $limit");
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function tham_alert_ward_push($con, array $ev)
{
    $cfg = tham_alert_config($con);
    if (!$cfg['ward']) {
        return ['ok' => false, 'error' => 'pipeline Ward ปิดอยู่'];
    }
    $ok = tham_alert_enqueue($con, [
        'pipeline' => 'ward',
        'event_key' => 'ward|' . md5(($ev['hn'] ?? '') . '|' . ($ev['message'] ?? '') . '|' . date('YmdHi')),
        'station_id' => $ev['station_id'] ?? '',
        'group_name' => $ev['group_name'] ?? '',
        'hn' => $ev['hn'] ?? '',
        'vn' => $ev['vn'] ?? '',
        'an' => $ev['an'] ?? '',
        'icode' => $ev['icode'] ?? '',
        'drug_name' => $ev['drug_name'] ?? '',
        'staff' => $ev['staff'] ?? '',
        'computername' => $ev['station_id'] ?? '',
        'title' => $ev['title'] ?? 'แจ้งเตือนวอร์ด',
        'message' => $ev['message'] ?? '',
    ]);
    return ['ok' => true, 'queued' => $ok];
}

function tham_alert_cron_secret_ok($con, $given)
{
    $cfg = tham_alert_config($con);
    $want = (string)$cfg['cron_secret'];
    return $want !== '' && hash_equals($want, (string)$given);
}

function tham_alert_client_ip()
{
    foreach (['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'] as $k) {
        $raw = trim((string)($_SERVER[$k] ?? ''));
        if ($raw === '') {
            continue;
        }
        $ip = trim(explode(',', $raw)[0]);
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }
    }
    return '';
}

function tham_alert_cookie_path()
{
    $dir = str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/')));
    $dir = rtrim($dir, '/');
    return $dir === '' ? '/' : $dir;
}

function tham_alert_machine_cookie_id()
{
    $id = preg_replace('/[^a-f0-9]/', '', strtolower((string)($_COOKIE['tham_alert_machine'] ?? '')));
    if (strlen($id) !== 32) {
        $id = bin2hex(random_bytes(16));
        if (!headers_sent()) {
            setcookie('tham_alert_machine', $id, [
                'expires' => time() + 86400 * 400,
                'path' => tham_alert_cookie_path(),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }
        $_COOKIE['tham_alert_machine'] = $id;
    }
    return $id;
}

function tham_alert_suggest_pipeline($role, $dispense_room)
{
    $role = strtolower(trim((string)$role));
    $room = strtolower(trim((string)$dispense_room));
    if ($role === 'nurse') {
        return 'ward';
    }
    if ($room === 'opd') {
        return 'phar_opd';
    }
    if ($room === 'ipd') {
        return 'phar_ipd';
    }
    return '';
}

function tham_alert_agent_fetch($con, $sql)
{
    $q = @mysqli_query($con, $sql);
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return $r;
    }
    return null;
}

function tham_alert_agent_find($con, $cookie_id = '', $station_id = '', $ip = '')
{
    tham_alert_ensure_tables($con);
    $cookie_id = preg_replace('/[^a-f0-9]/', '', strtolower($cookie_id));
    $station_id = trim((string)$station_id);
    $ip = trim((string)$ip);
    if (strlen($cookie_id) === 32) {
        $c = mysqli_real_escape_string($con, $cookie_id);
        $row = tham_alert_agent_fetch($con, "SELECT * FROM tham_alert_agents WHERE cookie_id='$c' LIMIT 1");
        if ($row) {
            return $row;
        }
    }
    if ($station_id !== '') {
        $s = mysqli_real_escape_string($con, $station_id);
        $row = tham_alert_agent_fetch($con, "SELECT * FROM tham_alert_agents WHERE station_id='$s' AND station_id<>'' ORDER BY last_seen DESC LIMIT 1");
        if ($row) {
            return $row;
        }
    }
    if ($ip !== '') {
        $i = mysqli_real_escape_string($con, $ip);
        $row = tham_alert_agent_fetch($con, "SELECT * FROM tham_alert_agents WHERE ip_address='$i' AND ip_address<>'' ORDER BY last_seen DESC LIMIT 1");
        if ($row) {
            return $row;
        }
    }
    return null;
}

function tham_alert_agent_insert($con, array $row)
{
    $esc = function ($s, $n) use ($con) {
        return mysqli_real_escape_string($con, mb_substr((string)$s, 0, $n));
    };
    $key = trim((string)($row['machine_key'] ?? ''));
    if ($key === '') {
        $key = bin2hex(random_bytes(16));
    }
    $sql = "INSERT INTO tham_alert_agents
        (machine_key, cookie_id, pipeline, client_hint, mapped, mapped_from, station_id, group_name, computername,
         ip_address, windows_user, agent_version, user_agent, last_user_id, last_user_name, last_user_role,
         last_dispense_room, first_seen, last_seen, poll_count, note)
        VALUES (
            '" . $esc($key, 64) . "',
            '" . $esc($row['cookie_id'] ?? '', 32) . "',
            '" . $esc($row['pipeline'] ?? '', 20) . "',
            '" . $esc($row['client_hint'] ?? '', 20) . "',
            " . ((int)!empty($row['mapped'])) . ",
            '" . $esc($row['mapped_from'] ?? '', 40) . "',
            '" . $esc($row['station_id'] ?? '', 80) . "',
            '" . $esc($row['group_name'] ?? '', 80) . "',
            '" . $esc($row['computername'] ?? '', 80) . "',
            '" . $esc($row['ip_address'] ?? '', 45) . "',
            '" . $esc($row['windows_user'] ?? '', 80) . "',
            '" . $esc($row['agent_version'] ?? '', 40) . "',
            '" . $esc($row['user_agent'] ?? '', 180) . "',
            " . (int)($row['last_user_id'] ?? 0) . ",
            '" . $esc($row['last_user_name'] ?? '', 120) . "',
            '" . $esc($row['last_user_role'] ?? '', 40) . "',
            '" . $esc($row['last_dispense_room'] ?? '', 10) . "',
            NOW(), NOW(), 0, ''
        )";
    if (!@mysqli_query($con, $sql)) {
        return 0;
    }
    return (int)mysqli_insert_id($con);
}

function tham_alert_try_first_map($con, $agent_id, $role, $dispense_room)
{
    $agent_id = (int)$agent_id;
    if ($agent_id <= 0) {
        return '';
    }
    $suggest = tham_alert_suggest_pipeline($role, $dispense_room);
    if ($suggest === '') {
        return '';
    }
    $from = $suggest === 'ward' ? 'login_nurse' : ($suggest === 'phar_opd' ? 'login_opd' : 'login_ipd');
    $p = mysqli_real_escape_string($con, $suggest);
    $f = mysqli_real_escape_string($con, $from);
    @mysqli_query($con, "UPDATE tham_alert_agents
        SET pipeline='$p', mapped=1, mapped_from='$f'
        WHERE id=$agent_id AND mapped=0");
    return mysqli_affected_rows($con) > 0 ? $suggest : '';
}

function tham_alert_agent_heartbeat($con, array $req)
{
    tham_alert_ensure_tables($con);
    $hint = tham_alert_normalize_pipeline($req['pipeline'] ?? $req['client_type'] ?? $req['ClientType'] ?? '');
    if ($hint === '' || $hint === 'all') {
        $hint = '';
    }
    $station = trim((string)($req['station_id'] ?? $req['StationId'] ?? ''));
    $comp = trim((string)($req['computername'] ?? $req['ComputerName'] ?? $req['machine_name'] ?? $req['MachineName'] ?? ''));
    if (strcasecmp($station, 'AUTO_MACHINE_NAME') === 0) {
        $station = $comp;
    }
    if ($station === '') {
        $station = $comp;
    }
    if ($comp === '') {
        $comp = $station;
    }
    $group = trim((string)($req['group_name'] ?? $req['GroupName'] ?? ''));
    $winuser = trim((string)($req['windows_user'] ?? $req['UserName'] ?? $req['user'] ?? ''));
    $ver = trim((string)($req['agent_version'] ?? $req['Version'] ?? ''));
    $ip = tham_alert_client_ip();
    $ua = tham_alert_request_ua();
    $row = tham_alert_agent_find($con, '', $station, $ip);
    $esc = function ($s, $n) use ($con) {
        return mysqli_real_escape_string($con, mb_substr((string)$s, 0, $n));
    };
    if (!$row) {
        $id = tham_alert_agent_insert($con, [
            'machine_key' => 'ag|' . sha1($station . '|' . $group . '|' . $ip),
            'pipeline' => '',
            'client_hint' => $hint,
            'station_id' => $station,
            'group_name' => $group,
            'computername' => $comp,
            'ip_address' => $ip,
            'windows_user' => $winuser,
            'agent_version' => $ver,
            'user_agent' => $ua,
        ]);
        @mysqli_query($con, "UPDATE tham_alert_agents SET poll_count=1, last_seen=NOW(), last_agent_at=NOW() WHERE id=$id");
        tham_alert_agent_touch_version($con, $id, $ver);
        tham_alert_apply_device($con, $id, $ua, [
            'agent_installed' => true,
            'poll_count' => 1,
            'windows_user' => $winuser,
            'computername' => $comp,
        ]);
        return ['ok' => true, 'id' => $id, 'ip' => $ip, 'station_id' => $station, 'pipeline' => '', 'enabled' => 1];
    }
    $id = (int)$row['id'];
    $sets = [
        "last_seen=NOW()",
        "last_agent_at=NOW()",
        "poll_count=poll_count+1",
        "ip_address='" . $esc($ip, 45) . "'",
        "user_agent='" . $esc($ua, 180) . "'",
    ];
    if ($station !== '') {
        $sets[] = "station_id='" . $esc($station, 80) . "'";
    }
    if ($group !== '') {
        $sets[] = "group_name='" . $esc($group, 80) . "'";
    }
    if ($comp !== '') {
        $sets[] = "computername='" . $esc($comp, 80) . "'";
    }
    if ($winuser !== '') {
        $sets[] = "windows_user='" . $esc($winuser, 80) . "'";
    }
    if ($ver !== '') {
        tham_alert_agent_touch_version($con, $id, $ver);
        $curVer = trim((string)($row['agent_version'] ?? ''));
        $seenAt = strtotime((string)($row['agent_version_at'] ?? '')) ?: 0;
        $accept = $curVer === '' || version_compare($ver, $curVer, '>=') || (time() - $seenAt) > 120;
        if ($accept) {
            $sets[] = "agent_version='" . $esc($ver, 40) . "'";
            $sets[] = "agent_version_at=NOW()";
            if (!function_exists('tham_alert_agent_latest_exe')) {
                require_once __DIR__ . '/alert_agent_helper.php';
            }
            $latest = tham_alert_agent_latest_exe();
            if ($latest && version_compare($ver, $latest['version'], '>=')) {
                $sets[] = "update_push_at=NULL";
            }
        }
    }
    if ($hint !== '') {
        $sets[] = "client_hint='" . $esc($hint, 20) . "'";
    }
    $sets = array_merge($sets, tham_alert_device_sql_sets($con, $ua, [
        'agent_installed' => true,
        'poll_count' => (int)($row['poll_count'] ?? 0) + 1,
        'windows_user' => $winuser !== '' ? $winuser : ($row['windows_user'] ?? ''),
        'computername' => $comp !== '' ? $comp : ($row['computername'] ?? ''),
    ]));
    @mysqli_query($con, "UPDATE tham_alert_agents SET " . implode(',', $sets) . " WHERE id=$id");
    return [
        'ok' => true,
        'id' => $id,
        'ip' => $ip,
        'station_id' => $station !== '' ? $station : (string)$row['station_id'],
        'pipeline' => (string)$row['pipeline'],
        'enabled' => (int)($row['enabled'] ?? 1) === 1,
    ];
}

function tham_alert_record_login($con, $user_id, $source = 'login')
{
    tham_alert_ensure_tables($con);
    $user_id = (int)$user_id;
    if ($user_id <= 0) {
        return 0;
    }
    $cookie = tham_alert_machine_cookie_id();
    $ip = tham_alert_client_ip();
    $ua = tham_alert_request_ua();
    $q = @mysqli_query($con, "SELECT id, username, full_name, role, dispense_room FROM users WHERE id=$user_id LIMIT 1");
    $u = ($q && mysqli_num_rows($q)) ? mysqli_fetch_assoc($q) : [];
    $role = (string)($u['role'] ?? ($_SESSION['role'] ?? ''));
    $room = (string)($u['dispense_room'] ?? ($_SESSION['dispense_room'] ?? ''));
    $name = (string)($u['full_name'] ?? ($_SESSION['full_name'] ?? ''));
    $uname = (string)($u['username'] ?? ($_SESSION['username'] ?? ''));
    $row = tham_alert_agent_find($con, $cookie, '', $ip);
    if (!$row) {
        $id = tham_alert_agent_insert($con, [
            'machine_key' => 'ck|' . $cookie,
            'cookie_id' => $cookie,
            'ip_address' => $ip,
            'user_agent' => $ua,
            'last_user_id' => $user_id,
            'last_user_name' => $name,
            'last_user_role' => $role,
            'last_dispense_room' => $room,
        ]);
        if ($id > 0) {
            @mysqli_query($con, "UPDATE tham_alert_agents SET last_web_at=NOW(), last_login_at=NOW() WHERE id=$id");
            tham_alert_apply_device($con, $id, $ua, []);
        }
    } else {
        $id = (int)$row['id'];
        $esc = function ($s, $n) use ($con) {
            return mysqli_real_escape_string($con, mb_substr((string)$s, 0, $n));
        };
        $sets = [
            "last_seen=NOW()",
            "last_login_at=NOW()",
            "last_web_at=NOW()",
            "cookie_id=IF(cookie_id='', '" . $esc($cookie, 32) . "', cookie_id)",
            "ip_address='" . $esc($ip, 45) . "'",
            "user_agent='" . $esc($ua, 180) . "'",
            "last_user_id=$user_id",
            "last_user_name='" . $esc($name, 120) . "'",
            "last_user_role='" . $esc($role, 40) . "'",
            "last_dispense_room='" . $esc($room, 10) . "'",
        ];
        $sets = array_merge($sets, tham_alert_device_sql_sets($con, $ua, $row));
        @mysqli_query($con, "UPDATE tham_alert_agents SET " . implode(',', $sets) . " WHERE id=$id");
    }
    if ($id > 0) {
        tham_alert_try_first_map($con, $id, $role, $room);
        $esc = function ($s, $n) use ($con) {
            return mysqli_real_escape_string($con, mb_substr((string)$s, 0, $n));
        };
        @mysqli_query($con, "INSERT INTO tham_alert_agent_logins
            (agent_id, user_id, username, full_name, role, dispense_room, ip_address, source)
            VALUES (
                $id, $user_id,
                '" . $esc($uname, 80) . "',
                '" . $esc($name, 120) . "',
                '" . $esc($role, 40) . "',
                '" . $esc($room, 10) . "',
                '" . $esc($ip, 45) . "',
                '" . $esc($source, 20) . "'
            )");
    }
    return $id;
}

/** เครื่องนี้กำลังเปิดเว็บ THAM อยู่ — อัปเดตโดยไม่ถือว่าเป็นการลง Agent */
function tham_alert_touch_web($con)
{
    if (empty($_SESSION['user_id'])) {
        return 0;
    }
    $now = time();
    $last = (int)($_SESSION['tham_alert_web_touch_at'] ?? 0);
    if ($last > 0 && ($now - $last) < 45) {
        return 0;
    }
    $_SESSION['tham_alert_web_touch_at'] = $now;
    tham_alert_ensure_tables($con);
    $cookie = tham_alert_machine_cookie_id();
    $ip = tham_alert_client_ip();
    $ua = tham_alert_request_ua();
    $user_id = (int)$_SESSION['user_id'];
    $name = (string)($_SESSION['full_name'] ?? '');
    $role = (string)($_SESSION['role'] ?? '');
    $room = (string)($_SESSION['dispense_room'] ?? '');
    $row = tham_alert_agent_find($con, $cookie, '', $ip);
    $esc = function ($s, $n) use ($con) {
        return mysqli_real_escape_string($con, mb_substr((string)$s, 0, $n));
    };
    if (!$row) {
        $id = tham_alert_agent_insert($con, [
            'machine_key' => 'ck|' . $cookie,
            'cookie_id' => $cookie,
            'ip_address' => $ip,
            'user_agent' => $ua,
            'last_user_id' => $user_id,
            'last_user_name' => $name,
            'last_user_role' => $role,
            'last_dispense_room' => $room,
        ]);
        if ($id > 0) {
            @mysqli_query($con, "UPDATE tham_alert_agents SET last_web_at=NOW(), last_seen=NOW() WHERE id=$id");
            tham_alert_apply_device($con, $id, $ua, []);
        }
        return $id;
    }
    $id = (int)$row['id'];
    @mysqli_query($con, "UPDATE tham_alert_agents SET
        last_web_at=NOW(),
        last_seen=NOW(),
        cookie_id=IF(cookie_id='', '" . $esc($cookie, 32) . "', cookie_id),
        ip_address='" . $esc($ip, 45) . "',
        user_agent='" . $esc($ua, 180) . "',
        last_user_id=$user_id,
        last_user_name='" . $esc($name, 120) . "',
        last_user_role='" . $esc($role, 40) . "',
        last_dispense_room='" . $esc($room, 10) . "',
        " . implode(',', tham_alert_device_sql_sets($con, $ua, $row)) . "
        WHERE id=$id");
    return $id;
}

function tham_alert_this_machine_status($con)
{
    if (!function_exists('tham_alert_is_lan_ip')) {
        require_once __DIR__ . '/alert_agent_helper.php';
    }
    tham_alert_ensure_tables($con);
    $cookie = preg_replace('/[^a-f0-9]/', '', strtolower((string)($_COOKIE['tham_alert_machine'] ?? '')));
    $ip = tham_alert_client_ip();
    $row = null;
    if (strlen($cookie) === 32) {
        $c = mysqli_real_escape_string($con, $cookie);
        $row = tham_alert_agent_fetch($con, "SELECT * FROM tham_alert_agents WHERE cookie_id='$c' LIMIT 1");
    }
    $installed = false;
    $version = '';
    $last_agent_at = '';
    $poll = 0;
    if ($row) {
        $poll = (int)($row['poll_count'] ?? 0);
        $last_agent_at = trim((string)($row['last_agent_at'] ?? ''));
        $installed = $poll > 0 || $last_agent_at !== '';
        $version = trim((string)($row['agent_version'] ?? ''));
    }
    return [
        'found' => (bool)$row,
        'installed' => $installed,
        'agent_version' => $version,
        'last_agent_at' => $last_agent_at,
        'poll_count' => $poll,
        'ip' => $ip,
        'is_lan' => tham_alert_is_lan_ip($ip),
    ];
}

function tham_alert_lan_auto_enabled($con)
{
    return tham_alert_sys_get($con, 'tham_alert_lan_auto', '0') === '1';
}

function tham_alert_set_login_prompt($con, $on)
{
    return tham_alert_sys_set($con, 'tham_alert_lan_auto', $on ? '1' : '0');
}

function tham_alert_allergy_case_enabled($con)
{
    return tham_alert_sys_get($con, 'tham_alert_allergy_case', '0') === '1';
}

function tham_alert_set_allergy_case($con, $on)
{
    return tham_alert_sys_set($con, 'tham_alert_allergy_case', $on ? '1' : '0');
}

function tham_alert_allergy_case_config($con)
{
    $raw = tham_alert_sys_get($con, 'tham_alert_allergy_case_cfg', '');
    $cfg = json_decode($raw, true);
    if (!is_array($cfg)) {
        $cfg = [];
    }
    $target = (string)($cfg['target'] ?? 'both');
    if (!in_array($target, ['phar_ipd', 'phar_opd', 'both', 'machines'], true)) {
        $target = 'both';
    }
    $ids = [];
    foreach ((array)($cfg['agent_ids'] ?? []) as $id) {
        $id = (int)$id;
        if ($id > 0) {
            $ids[$id] = $id;
        }
    }
    $in = (array)($cfg['fields'] ?? []);
    $fields = [];
    foreach (['hn', 'ptname', 'ward', 'reporter', 'link'] as $key) {
        $fields[$key] = array_key_exists($key, $in) ? !empty($in[$key]) : true;
    }
    return [
        'target' => $target,
        'agent_ids' => array_values($ids),
        'fields' => $fields,
    ];
}

function tham_alert_set_allergy_case_config($con, array $cfg)
{
    $norm = tham_alert_allergy_case_config($con);
    $target = (string)($cfg['target'] ?? $norm['target']);
    if (!in_array($target, ['phar_ipd', 'phar_opd', 'both', 'machines'], true)) {
        return ['ok' => false, 'error' => 'เลือกผู้รับไม่ถูกต้อง'];
    }
    $ids = [];
    foreach ((array)($cfg['agent_ids'] ?? []) as $id) {
        $id = (int)$id;
        if ($id > 0) {
            $ids[$id] = $id;
        }
    }
    if ($target === 'machines' && !$ids) {
        return ['ok' => false, 'error' => 'เลือกอย่างน้อย 1 เครื่อง'];
    }
    $fields = [];
    $in = (array)($cfg['fields'] ?? []);
    foreach (['hn', 'ptname', 'ward', 'reporter', 'link'] as $key) {
        $fields[$key] = !empty($in[$key]);
    }
    $payload = json_encode([
        'target' => $target,
        'agent_ids' => array_values($ids),
        'fields' => $fields,
    ], JSON_UNESCAPED_UNICODE);
    $ok = tham_alert_sys_set($con, 'tham_alert_allergy_case_cfg', $payload);
    return ['ok' => $ok, 'error' => $ok ? '' : 'บันทึกไม่สำเร็จ', 'config' => tham_alert_allergy_case_config($con)];
}

function tham_alert_allergy_case_message(array $case, array $fields)
{
    $id = (int)($case['id'] ?? 0);
    $hn = trim((string)($case['hn'] ?? ''));
    $name = trim((string)($case['ptname'] ?? ''));
    $ward = trim((string)($case['ward'] ?? ''));
    $detail = trim((string)($case['ward_detail'] ?? ''));
    $reporter = trim((string)($case['reporter_name'] ?? ''));
    $place = trim($ward . ($detail !== '' ? ' ' . $detail : ''));
    $lines = ['เคสแพ้ยาใหม่จากหอผู้ป่วย'];
    if (!empty($fields['hn']) || !empty($fields['ptname'])) {
        $bits = [];
        if (!empty($fields['hn']) && $hn !== '') {
            $bits[] = 'HN ' . $hn;
        }
        if (!empty($fields['ptname']) && $name !== '') {
            $bits[] = $name;
        }
        if ($bits) {
            $lines[] = implode('  ', $bits);
        }
    }
    if (!empty($fields['ward']) && $place !== '') {
        $lines[] = 'หอ ' . $place;
    }
    if (!empty($fields['reporter']) && $reporter !== '') {
        $lines[] = 'ผู้แจ้ง ' . $reporter;
    }
    if (!empty($fields['link']) && $id > 0) {
        $lines[] = 'เปิดดูเคส http://61.7.167.197/thamhossafe/allergy_report.php?case=' . $id;
    }
    return implode("\n", $lines);
}

function tham_alert_notify_allergy_case($con, array $case)
{
    if (!tham_alert_allergy_case_enabled($con)) {
        return 0;
    }
    $id = (int)($case['id'] ?? 0);
    if ($id <= 0) {
        return 0;
    }
    $cfg = tham_alert_allergy_case_config($con);
    $hn = trim((string)($case['hn'] ?? ''));
    $reporter = trim((string)($case['reporter_name'] ?? ''));
    $message = tham_alert_allergy_case_message($case, $cfg['fields']);
    $where = '';
    if ($cfg['target'] === 'machines') {
        $ids = array_values(array_filter(array_map('intval', $cfg['agent_ids'])));
        if (!$ids) {
            return 0;
        }
        $where = 'id IN (' . implode(',', $ids) . ')';
    } else {
        $pipes = $cfg['target'] === 'both' ? ['phar_ipd', 'phar_opd'] : [$cfg['target']];
        $safe = [];
        foreach ($pipes as $pipe) {
            $safe[] = "'" . mysqli_real_escape_string($con, $pipe) . "'";
        }
        $where = 'pipeline IN (' . implode(',', $safe) . ')';
    }
    $targets = [];
    $q = @mysqli_query($con, "SELECT id, pipeline, station_id, computername, enabled, poll_count, last_agent_at
        FROM tham_alert_agents WHERE $where");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $installed = (int)($r['poll_count'] ?? 0) > 0 || !empty($r['last_agent_at']);
            if (!$installed || (int)($r['enabled'] ?? 1) !== 1) {
                continue;
            }
            $pipe = tham_alert_normalize_pipeline($r['pipeline'] ?? '');
            $station = trim((string)($r['station_id'] ?? ''));
            $comp = trim((string)($r['computername'] ?? ''));
            if ($station === '') {
                $station = $comp;
            }
            if ($pipe === '' || $pipe === 'all' || $station === '') {
                continue;
            }
            $targets[] = [
                'pipeline' => $pipe,
                'station_id' => $station,
                'computername' => $comp !== '' ? $comp : $station,
                'key' => 'allergy|' . $id . '|m' . (int)$r['id'],
            ];
        }
    }
    $queued = 0;
    foreach ($targets as $t) {
        $ok = tham_alert_enqueue($con, [
            'pipeline' => $t['pipeline'],
            'event_key' => $t['key'],
            'station_id' => $t['station_id'],
            'computername' => $t['computername'],
            'group_name' => '',
            'hn' => $hn,
            'drug_name' => 'แพ้ยา',
            'staff' => $reporter,
            'title' => 'เคสแพ้ยาใหม่จากหอผู้ป่วย',
            'message' => $message,
        ]);
        if ($ok) {
            $queued++;
        }
    }
    return $queued;
}

function tham_alert_agent_push_install($con, $id, $user_id = 0)
{
    $id = (int)$id;
    $user_id = (int)$user_id;
    if ($id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบเครื่อง'];
    }
    $row = tham_alert_agent_fetch($con, "SELECT id, poll_count, last_agent_at FROM tham_alert_agents WHERE id=$id LIMIT 1");
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบเครื่อง'];
    }
    $installed = (int)($row['poll_count'] ?? 0) > 0 || !empty($row['last_agent_at']);
    if ($installed) {
        return ['ok' => false, 'error' => 'เครื่องนี้ลง Agent แล้ว'];
    }
    $ok = (bool)@mysqli_query($con, "UPDATE tham_alert_agents
        SET install_push_at=NOW(), install_push_by=$user_id, install_ack_at=NULL
        WHERE id=$id LIMIT 1");
    return ['ok' => $ok, 'error' => $ok ? '' : 'บันทึกไม่สำเร็จ'];
}

function tham_alert_agent_request_update($con, $id)
{
    tham_alert_ensure_tables($con);
    if (!function_exists('tham_alert_agent_latest_exe')) {
        require_once __DIR__ . '/alert_agent_helper.php';
    }
    $latest = tham_alert_agent_latest_exe();
    if (!$latest) {
        return ['ok' => false, 'error' => 'ยังไม่มีไฟล์ THAM Notify ให้เครื่องดึง', 'queued' => 0];
    }
    $id = (int)$id;
    $latestVer = (string)$latest['version'];
    if ($id > 0) {
        $q = @mysqli_query($con, "SELECT id, agent_version, poll_count, last_agent_at FROM tham_alert_agents WHERE id=$id LIMIT 1");
    } else {
        $q = @mysqli_query($con, "SELECT id, agent_version, poll_count, last_agent_at FROM tham_alert_agents");
    }
    if (!$q) {
        return ['ok' => false, 'error' => 'อ่านรายการเครื่องไม่สำเร็จ', 'queued' => 0];
    }
    $queued = 0;
    $old = 0;
    $current = 0;
    $missing = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $installed = (int)($row['poll_count'] ?? 0) > 0 || !empty($row['last_agent_at']);
        if (!$installed) {
            $missing++;
            continue;
        }
        $ver = trim((string)($row['agent_version'] ?? ''));
        if ($ver === '' || version_compare($ver, '1.1.3', '<')) {
            $old++;
            continue;
        }
        if (version_compare($ver, $latestVer, '>=')) {
            $current++;
            continue;
        }
        $rid = (int)$row['id'];
        if (@mysqli_query($con, "UPDATE tham_alert_agents SET update_push_at=NOW() WHERE id=$rid LIMIT 1")) {
            $queued++;
        }
    }
    if ($queued > 0) {
        return ['ok' => true, 'error' => '', 'queued' => $queued, 'skipped_old' => $old];
    }
    if ($id > 0 && $old > 0) {
        return ['ok' => false, 'error' => 'เครื่องนี้ยังเป็นเวอร์ชันเก่าที่อัปเดตเองไม่ได้ ต้องเปิด THAM Notify 1.1.3 ครั้งแรกก่อน', 'queued' => 0];
    }
    if ($id > 0 && $current > 0) {
        return ['ok' => false, 'error' => 'เครื่องนี้เป็นเวอร์ชันล่าสุดแล้ว', 'queued' => 0];
    }
    if ($id > 0 && $missing > 0) {
        return ['ok' => false, 'error' => 'เครื่องนี้ยังไม่ได้ลงโปรแกรม', 'queued' => 0];
    }
    return ['ok' => false, 'error' => 'ไม่มีเครื่องที่อัปเดตเองได้', 'queued' => 0, 'skipped_old' => $old];
}

function tham_alert_my_install_push($con)
{
    require_once __DIR__ . '/alert_agent_helper.php';
    tham_alert_ensure_tables($con);
    $cookie = preg_replace('/[^a-f0-9]/', '', strtolower((string)($_COOKIE['tham_alert_machine'] ?? '')));
    $row = null;
    if (strlen($cookie) === 32) {
        $c = mysqli_real_escape_string($con, $cookie);
        $row = tham_alert_agent_fetch($con, "SELECT * FROM tham_alert_agents WHERE cookie_id='$c' LIMIT 1");
    }
    $installed = false;
    if ($row) {
        $installed = (int)($row['poll_count'] ?? 0) > 0 || !empty($row['last_agent_at']);
    }
    $latest = function_exists('tham_alert_agent_latest_file') ? tham_alert_agent_latest_file() : null;
    $push = false;
    $push_at = '';
    if ($row && !$installed) {
        $push_at = trim((string)($row['install_push_at'] ?? ''));
        $ack_at = trim((string)($row['install_ack_at'] ?? ''));
        if ($push_at !== '' && ($ack_at === '' || strtotime($push_at) > (strtotime($ack_at) ?: 0))) {
            $push = true;
        }
    }
    return [
        'ok' => true,
        'installed' => $installed,
        'push' => $push,
        'push_at' => $push ? $push_at : '',
        'url' => 'alert_agent_file.php?latest=1',
        'name' => $latest['name'] ?? 'THAM-Alert-Agent.exe',
    ];
}

function tham_alert_ack_install_push($con)
{
    tham_alert_ensure_tables($con);
    $cookie = preg_replace('/[^a-f0-9]/', '', strtolower((string)($_COOKIE['tham_alert_machine'] ?? '')));
    if (strlen($cookie) !== 32) {
        return false;
    }
    $c = mysqli_real_escape_string($con, $cookie);
    return (bool)@mysqli_query($con, "UPDATE tham_alert_agents SET install_ack_at=NOW() WHERE cookie_id='$c' LIMIT 1");
}

function tham_alert_agent_list($con)
{
    tham_alert_ensure_tables($con);
    if (!function_exists('tham_alert_ip_network_info')) {
        require_once __DIR__ . '/alert_agent_helper.php';
    }
    $online_sec = 120;
    $q = @mysqli_query($con, "SELECT id, pipeline, client_hint, mapped, mapped_from, station_id, group_name, computername, display_name,
            ip_address, windows_user, agent_version, agent_version_at, user_agent, device_kind, ua_platform, first_seen, last_seen, last_login_at, last_agent_at, last_web_at,
            install_push_at, install_ack_at, update_push_at, poll_count, enabled, keep_login, ui_hidden, note,
            last_user_id, last_user_name, last_user_role, last_dispense_room,
            TIMESTAMPDIFF(SECOND, last_seen, NOW()) AS age_sec,
            TIMESTAMPDIFF(SECOND, last_agent_at, NOW()) AS agent_age_sec,
            TIMESTAMPDIFF(SECOND, last_web_at, NOW()) AS web_age_sec
        FROM tham_alert_agents
        ORDER BY (pipeline='' OR pipeline='unknown') DESC, last_seen DESC
        LIMIT 400");
    if (!function_exists('tham_alert_agent_latest_exe')) {
        require_once __DIR__ . '/alert_agent_helper.php';
    }
    $latestExe = tham_alert_agent_latest_exe();
    $latestVer = (string)($latestExe['version'] ?? '');
    $liveMap = [];
    $lv = @mysqli_query($con, "SELECT agent_id, agent_version FROM tham_alert_agent_livever
        WHERE seen_at > NOW() - INTERVAL 90 SECOND");
    if ($lv) {
        while ($lr = mysqli_fetch_assoc($lv)) {
            $aid = (int)($lr['agent_id'] ?? 0);
            $vv = trim((string)($lr['agent_version'] ?? ''));
            if ($aid > 0 && $vv !== '') {
                $liveMap[$aid][] = $vv;
            }
        }
    }
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $installed = (int)($r['poll_count'] ?? 0) > 0 || !empty($r['last_agent_at']);
            $agent_age = $r['agent_age_sec'] === null ? null : (int)$r['agent_age_sec'];
            $web_age = $r['web_age_sec'] === null ? null : (int)$r['web_age_sec'];
            $web_online_sec = 180;
            $r['agent_installed'] = $installed;
            $r['online'] = $installed && $agent_age !== null && $agent_age >= 0 && $agent_age <= $online_sec;
            $r['web_online'] = $web_age !== null && $web_age >= 0 && $web_age <= $web_online_sec;
            $r['enabled'] = (int)($r['enabled'] ?? 1) === 1;
            $r['keep_login'] = (int)($r['keep_login'] ?? 0) === 1;
            $r['ui_hidden'] = (int)($r['ui_hidden'] ?? 0) === 1;
            $push_at = trim((string)($r['install_push_at'] ?? ''));
            $ack_at = trim((string)($r['install_ack_at'] ?? ''));
            $pending = !$installed && $push_at !== '' && ($ack_at === '' || strtotime($push_at) > (strtotime($ack_at) ?: 0));
            $verNow = trim((string)($r['agent_version'] ?? ''));
            $r['latest_version'] = $latestVer;
            $r['update_available'] = $installed && $latestVer !== '' && ($verNow === '' || version_compare($verNow, $latestVer, '<'));
            $r['update_capable'] = $installed && $verNow !== '' && version_compare($verNow, '1.1.3', '>=');
            $r['update_pushed'] = $r['update_available'] && !empty($r['update_push_at']);
            $live = $liveMap[(int)$r['id']] ?? [];
            $r['live_versions'] = $live;
            $r['duplicate_agent'] = count($live) > 1;
            $r['install_queued'] = $pending && empty($r['web_online']);
            $r['install_push_pending'] = $pending;
            $r['install_waiting_file'] = !$installed && $push_at !== '' && !$pending;
            $pipe = trim((string)$r['pipeline']);
            $r['unspecified'] = ($pipe === '' || $pipe === 'unknown');
            $dev = tham_alert_classify_device($r['user_agent'] ?? '', $r);
            $r['device_kind'] = $dev['kind'];
            $r['device_label'] = $dev['label'];
            $r['device_os'] = $dev['os'];
            $r['device_detail'] = $dev['detail'];
            $r['can_install_agent'] = $dev['can_install_agent'];
            $net = tham_alert_ip_network_info($r['ip_address'] ?? '');
            $r['is_lan'] = !empty($net['is_lan']);
            $r['network_kind'] = $net['kind'];
            $r['network_label'] = $net['label'];
            $r['network_detail'] = $net['detail'];
            $r['last_unit_ward'] = '';
            $rows[] = $r;
        }
    }
    $userIds = [];
    foreach ($rows as $r) {
        $uid = (int)($r['last_user_id'] ?? 0);
        if ($uid > 0) {
            $userIds[$uid] = true;
        }
    }
    if ($userIds) {
        $wardByUser = [];
        $inq = implode(',', array_map('intval', array_keys($userIds)));
        $wq = @mysqli_query($con, "SELECT id, TRIM(IFNULL(unit_ward,'')) AS unit_ward FROM users WHERE id IN ($inq)");
        if ($wq) {
            while ($wr = mysqli_fetch_assoc($wq)) {
                $wardByUser[(int)$wr['id']] = trim((string)($wr['unit_ward'] ?? ''));
            }
        }
        foreach ($rows as &$r) {
            $r['last_unit_ward'] = $wardByUser[(int)($r['last_user_id'] ?? 0)] ?? '';
        }
        unset($r);
    }
    usort($rows, function ($a, $b) {
        $as = (!empty($a['online']) ? 2 : 0) + (!empty($a['agent_installed']) ? 1 : 0);
        $bs = (!empty($b['online']) ? 2 : 0) + (!empty($b['agent_installed']) ? 1 : 0);
        if ($as !== $bs) {
            return $bs <=> $as;
        }
        $an = strtolower((string)($a['station_id'] ?: $a['computername'] ?: $a['ip_address']));
        $bn = strtolower((string)($b['station_id'] ?: $b['computername'] ?: $b['ip_address']));
        return strcmp($an, $bn);
    });
    return $rows;
}

function tham_alert_agent_logins($con, $agent_id, $limit = 40)
{
    tham_alert_ensure_tables($con);
    $agent_id = (int)$agent_id;
    $limit = max(1, min(100, (int)$limit));
    $rows = [];
    if ($agent_id <= 0) {
        return $rows;
    }
    $q = @mysqli_query($con, "SELECT l.id, l.user_id, l.username, l.full_name, l.role, l.dispense_room, l.ip_address, l.source, l.created_at,
            TRIM(IFNULL(u.unit_ward,'')) AS unit_ward
        FROM tham_alert_agent_logins l
        LEFT JOIN users u ON u.id = l.user_id
        WHERE l.agent_id=$agent_id
        ORDER BY l.id DESC
        LIMIT $limit");
    if ($q) {
        if (!function_exists('tham_alert_ip_network_info')) {
            require_once __DIR__ . '/alert_agent_helper.php';
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $net = tham_alert_ip_network_info($r['ip_address'] ?? '');
            $r['is_lan'] = !empty($net['is_lan']);
            $r['network_kind'] = $net['kind'];
            $r['network_label'] = $net['label'];
            $r['network_detail'] = $net['detail'];
            $rows[] = $r;
        }
    }
    return $rows;
}

function tham_alert_agent_set_hidden($con, $id, $hidden)
{
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    $on = $hidden ? 1 : 0;
    return (bool)@mysqli_query($con, "UPDATE tham_alert_agents SET ui_hidden=$on WHERE id=$id LIMIT 1");
}

function tham_alert_agent_delete($con, $id)
{
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    @mysqli_query($con, "DELETE FROM tham_alert_agent_logins WHERE agent_id=$id");
    return (bool)@mysqli_query($con, "DELETE FROM tham_alert_agents WHERE id=$id LIMIT 1");
}

function tham_alert_agent_set_display_name($con, $id, $name)
{
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    $raw = trim((string)$name);
    if (function_exists('mb_substr')) {
        $raw = mb_substr($raw, 0, 80);
    } elseif (strlen($raw) > 80) {
        $raw = substr($raw, 0, 80);
    }
    $n = mysqli_real_escape_string($con, $raw);
    return (bool)@mysqli_query($con, "UPDATE tham_alert_agents SET display_name='$n' WHERE id=$id LIMIT 1");
}

function tham_alert_agent_set_note($con, $id, $note)
{
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    $n = mysqli_real_escape_string($con, mb_substr(trim((string)$note), 0, 180));
    return (bool)@mysqli_query($con, "UPDATE tham_alert_agents SET note='$n' WHERE id=$id LIMIT 1");
}

function tham_alert_keep_login_file()
{
    return __DIR__ . '/storage/keep_login_machines.json';
}

function tham_alert_keep_login_sync_file($con)
{
    $ips = [];
    $q = @mysqli_query($con, "SELECT id, ip_address, last_user_id, computername, display_name, station_id
        FROM tham_alert_agents WHERE keep_login=1 AND ip_address<>''");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $ip = trim((string)$r['ip_address']);
            if (!filter_var($ip, FILTER_VALIDATE_IP)) {
                continue;
            }
            $ips[$ip] = [
                'id' => (int)$r['id'],
                'user_id' => (int)$r['last_user_id'],
                'name' => trim((string)($r['display_name'] ?: $r['computername'] ?: $r['station_id'])),
            ];
        }
    }
    $dir = dirname(tham_alert_keep_login_file());
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $ht = $dir . '/.htaccess';
    if (!is_file($ht)) {
        @file_put_contents($ht, "Require all denied\nDeny from all\n");
    }
    @file_put_contents(
        tham_alert_keep_login_file(),
        json_encode(['ips' => $ips], JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );
    return $ips;
}

function tham_alert_agent_set_keep_login($con, $id, $enabled)
{
    tham_alert_ensure_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    $on = $enabled ? 1 : 0;
    $ok = (bool)@mysqli_query($con, "UPDATE tham_alert_agents SET keep_login=$on WHERE id=$id LIMIT 1");
    if ($ok) {
        tham_alert_keep_login_sync_file($con);
    }
    return $ok;
}

function tham_alert_agent_set_enabled($con, $id, $enabled)
{
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    $on = $enabled ? 1 : 0;
    return (bool)@mysqli_query($con, "UPDATE tham_alert_agents SET enabled=$on WHERE id=$id LIMIT 1");
}

function tham_alert_agent_bind($con, $id, $pipeline, $station_id = '', $group_name = '', $note = null)
{
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    $pipeline = tham_alert_normalize_pipeline($pipeline);
    if ($pipeline === 'all') {
        $pipeline = '';
    }
    $esc = function ($s, $n) use ($con) {
        return mysqli_real_escape_string($con, mb_substr((string)$s, 0, $n));
    };
    $mapped = $pipeline !== '' && $pipeline !== 'unknown' ? 1 : 0;
    $from = $mapped ? 'admin' : '';
    $sql = "UPDATE tham_alert_agents SET
        pipeline='" . $esc($pipeline, 20) . "',
        mapped=$mapped,
        mapped_from='" . $esc($from, 40) . "'";
    if ($station_id !== null && $station_id !== '') {
        $sql .= ", station_id='" . $esc($station_id, 80) . "'";
    }
    if ($group_name !== null && $group_name !== '') {
        $sql .= ", group_name='" . $esc($group_name, 80) . "'";
    }
    if ($note !== null) {
        $sql .= ", note='" . $esc($note, 180) . "'";
    }
    $sql .= " WHERE id=$id LIMIT 1";
    return (bool)@mysqli_query($con, $sql);
}

function tham_alert_agent_test_send($con, $id, $message = '')
{
    $id = (int)$id;
    if ($id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบเครื่อง'];
    }
    $row = tham_alert_agent_fetch($con, "SELECT * FROM tham_alert_agents WHERE id=$id LIMIT 1");
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบเครื่อง'];
    }
    if ((int)($row['enabled'] ?? 1) !== 1) {
        return ['ok' => false, 'error' => 'เครื่องนี้ปิดระบบ Alert อยู่'];
    }
    $pipe = trim((string)$row['pipeline']);
    if ($pipe === '' || $pipe === 'unknown') {
        $pipe = trim((string)$row['client_hint']);
    }
    if ($pipe === '') {
        $pipe = 'ward';
    }
    $msg = trim((string)$message);
    if ($msg === '') {
        $msg = 'ทดสอบการแจ้งเตือน THAM Alert Agent';
    }
    $who = trim((string)$row['station_id'] ?: (string)$row['computername'] ?: (string)$row['ip_address']);
    $seen = strtotime((string)($row['last_agent_at'] ?? '')) ?: 0;
    $online = $seen > 0 && (time() - $seen) <= 120;
    $ok = tham_alert_enqueue($con, [
        'pipeline' => $pipe,
        'event_key' => 'test|' . $id . '|' . date('YmdHis'),
        'station_id' => $row['station_id'] ?? '',
        'group_name' => $row['group_name'] ?? '',
        'computername' => $row['computername'] ?? '',
        'title' => 'ทดสอบ Alert Agent',
        'message' => mb_substr($msg . ($who !== '' ? ' · ' . $who : ''), 0, 500),
    ]);
    $note = '';
    if (!$online) {
        $note = 'โปรแกรมบนเครื่องนี้ไม่ได้ทำงานอยู่ ข้อความถึงเซิร์ฟเวอร์แล้วแต่จะไม่ขึ้นบนจอ ต้องเปิด THAM Notify ที่เครื่องนั้นก่อน';
    }
    return ['ok' => true, 'queued' => $ok, 'pipeline' => $pipe, 'online' => $online, 'error' => $note];
}
