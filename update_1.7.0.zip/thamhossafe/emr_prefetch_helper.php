<?php
/**
 * Cache ข้อมูล Smart Drug / Smart Lab ที่เตรียมจาก Patient IPD
 * — ไฟล์ชั่วคราวต่อ user+HN (TTL ค่าเริ่มต้น 10 นาที)
 */

function emr_prefetch_ttl() {
    return 600;
}

function emr_prefetch_dir() {
    $dir = __DIR__ . '/cache/emr_prefetch';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return $dir;
}

function emr_prefetch_norm_hn($hn) {
    $hn = trim((string)$hn);
    if ($hn !== '' && ctype_digit($hn) && strlen($hn) < 9) {
        $hn = str_pad($hn, 9, '0', STR_PAD_LEFT);
    }
    return $hn;
}

function emr_prefetch_key($kind, $user_id, $hn, array $params) {
    ksort($params);
    return md5((string)$kind . '|' . (int)$user_id . '|' . emr_prefetch_norm_hn($hn) . '|' . json_encode($params, JSON_UNESCAPED_UNICODE));
}

function emr_prefetch_path($kind, $user_id, $hn, array $params) {
    return emr_prefetch_dir() . '/' . emr_prefetch_key($kind, $user_id, $hn, $params) . '.json';
}

function emr_prefetch_put($kind, $user_id, $hn, array $params, array $payload) {
    $hn = emr_prefetch_norm_hn($hn);
    if ($hn === '' || !(int)$user_id) {
        return false;
    }
    $path = emr_prefetch_path($kind, $user_id, $hn, $params);
    $wrap = [
        'ts' => time(),
        'kind' => (string)$kind,
        'hn' => $hn,
        'user_id' => (int)$user_id,
        'params' => $params,
        'payload' => $payload,
    ];
    $json = json_encode($wrap, JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return false;
    }
    return (bool)@file_put_contents($path, $json, LOCK_EX);
}

function emr_prefetch_get($kind, $user_id, $hn, array $params, $ttl = null) {
    $ttl = $ttl === null ? emr_prefetch_ttl() : (int)$ttl;
    $hn = emr_prefetch_norm_hn($hn);
    if ($hn === '' || !(int)$user_id) {
        return null;
    }
    $path = emr_prefetch_path($kind, $user_id, $hn, $params);
    if (!is_file($path)) {
        return null;
    }
    $raw = @file_get_contents($path);
    if ($raw === false || $raw === '') {
        return null;
    }
    $wrap = json_decode($raw, true);
    if (!is_array($wrap) || empty($wrap['payload']) || !is_array($wrap['payload'])) {
        return null;
    }
    $age = time() - (int)($wrap['ts'] ?? 0);
    if ($age < 0 || $age > $ttl) {
        @unlink($path);
        return null;
    }
    $payload = $wrap['payload'];
    $payload['_cache'] = [
        'hit' => true,
        'age_sec' => $age,
        'ts' => (int)($wrap['ts'] ?? 0),
    ];
    return $payload;
}

function emr_prefetch_lookback_months($raw, $default = 12) {
    if (function_exists('hds_lookback_months')) {
        return hds_lookback_months($raw ?? $default, $default);
    }
    $n = (int)$raw;
    return in_array($n, [3, 6, 12, 36, 60, 0], true) ? $n : $default;
}

/**
 * ดึงรายการใบสั่ง Lab (local + เครือข่าย) — ใช้ร่วมกันระหว่าง smart_lab.php กับ prefetch API
 */
function emr_prefetch_fetch_smart_lab($hos_con, $con, $raw_hn, $months = 12, $include_network = true) {
    require_once __DIR__ . '/hospital_ds_helper.php';
    $raw_hn = emr_prefetch_norm_hn($raw_hn);
    $search_hn = mysqli_real_escape_string($hos_con, $raw_hn);
    $months = emr_prefetch_lookback_months($months, 12);
    $local_hospital_name = hds_local_hospital_name();
    $lab_date_sql = hds_date_filter_sql('order_date', $months);

    $t_search_start = microtime(true);
    $local_ms = 0;
    $network_ms = 0;
    $patient_name = '';
    $patient_cid = '';
    $q_pt = mysqli_query($hos_con, "SELECT CONCAT(pname, fname, ' ', lname) as fullname, cid FROM patient WHERE hn = '$search_hn' LIMIT 1");
    if ($q_pt && ($pt = mysqli_fetch_assoc($q_pt))) {
        $patient_name = (string)($pt['fullname'] ?? '');
        $patient_cid = preg_replace('/\D+/', '', (string)($pt['cid'] ?? ''));
    } else {
        $patient_name = 'ไม่พบชื่อในระบบ HOSxP';
    }

    $lab_history = [];
    $fetch_local_labs = function () use ($hos_con, $search_hn, $raw_hn, $local_hospital_name, $lab_date_sql, &$lab_history, &$local_ms) {
        $t0 = microtime(true);
        $sql_all_labs = "SELECT lab_order_number, order_date, order_time,
                                CAST(CONVERT(IFNULL(form_name,'') USING utf8) AS CHAR) AS form_name
                         FROM lab_head WHERE hn = '$search_hn' AND confirm_report = 'Y'
                         $lab_date_sql
                         ORDER BY order_date DESC, order_time DESC";
        $q_all_labs = mysqli_query($hos_con, $sql_all_labs);
        if ($q_all_labs) {
            while ($row = mysqli_fetch_assoc($q_all_labs)) {
                $row['hospital_code'] = 'local';
                $row['hospital_name'] = $local_hospital_name;
                $row['order_key'] = 'local:' . $row['lab_order_number'];
                $row['matched_hn'] = $raw_hn;
                $row['form_name'] = trim((string)($row['form_name'] ?? ''));
                $lab_history[] = $row;
            }
        }
        $local_ms = (int)round((microtime(true) - $t0) * 1000);
    };

    $network_sources = [];
    if ($include_network) {
        $t_net0 = microtime(true);
        $net = hds_fetch_smart_lab_network($con, hds_hn_variants($raw_hn), $patient_cid, $months, 80, $fetch_local_labs);
        $network_ms = (int)round((microtime(true) - $t_net0) * 1000);
        $network_sources = $net['sources'] ?? [];
        foreach ($net['orders'] ?? [] as $ord) {
            $lab_history[] = [
                'lab_order_number' => $ord['lab_order_number'],
                'order_date' => $ord['order_date'],
                'order_time' => $ord['order_time'],
                'form_name' => trim((string)($ord['form_name'] ?? '')),
                'hospital_code' => $ord['hospital_code'],
                'hospital_name' => $ord['hospital_name'],
                'order_key' => $ord['order_key'],
                'matched_hn' => $ord['matched_hn'],
            ];
        }
        usort($lab_history, function ($a, $b) {
            $da = (string)($a['order_date'] ?? '');
            $db = (string)($b['order_date'] ?? '');
            if ($da !== $db) {
                return strcmp($db, $da);
            }
            return strcmp((string)($b['order_time'] ?? ''), (string)($a['order_time'] ?? ''));
        });
    } else {
        $fetch_local_labs();
    }

    return [
        'ok' => true,
        'hn' => $raw_hn,
        'patient_name' => $patient_name,
        'patient_cid' => $patient_cid,
        'orders' => $lab_history,
        'sources' => $network_sources,
        'local_ms' => $local_ms,
        'network_ms' => $network_ms,
        'total_ms' => (int)round((microtime(true) - $t_search_start) * 1000),
        'months' => $months,
        'include_network' => (bool)$include_network,
        'local_hospital_name' => $local_hospital_name,
        'order_count' => count($lab_history),
    ];
}
