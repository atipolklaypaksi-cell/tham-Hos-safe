<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
require_once __DIR__ . '/rational_lab_use_helper.php';
$default_end = date('Y-m-d');
$default_start = date('Y-m-01');
$default_compare_year = (int)date('Y') - 1;
$compare_year_options = [];
for ($y = (int)date('Y'); $y >= (int)date('Y') - 15; $y--) {
    $compare_year_options[] = $y;
}
$default_compare_months = [];
for ($slot = 1; $slot <= 3; $slot++) {
    $default_compare_months[$slot] = date('Y-m', strtotime('-' . $slot . ' month'));
}
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>รายงานการรับยา ปณ.</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .pdr-stat-card { border: 0; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,.06); }
        .pdr-stat-card .stat-value { font-size: 1.35rem; font-weight: 700; }
        .pdr-table thead { background: #0d9488; color: #fff; }
        .pdr-compare-up { color: #dc3545; }
        .pdr-compare-down { color: #198754; }
        #summaryChartWrap { position: relative; height: 280px; }
        #summaryChartStats {
            position: absolute;
            top: 6px;
            right: 10px;
            z-index: 2;
            font-size: .78rem;
            line-height: 1.35;
            color: #475569;
            background: rgba(255,255,255,.88);
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 6px 10px;
            pointer-events: none;
            text-align: right;
        }
        #summaryChartStats .stat-line strong { color: #0f172a; font-weight: 700; }
        #summaryChartStats .stat-avg strong { color: #0d9488; }
        #summaryChartStats .stat-max strong { color: #dc2626; }
        #summaryChartStats .stat-min strong { color: #2563eb; }
        #clinicChartWrap { position: relative; min-height: 280px; height: 360px; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-1 text-dark">
                <i class="fas fa-mail-bulk me-2" style="color:#0d9488;"></i>
                รายงานการรับยาทางไปรษณีย์
            </h4>
            <p class="text-muted small mb-4">
                สรุปการลงทะเบียนรับยา ปณ. จาก UE form HOSxP (แบบบันทึกเลขพัสดุ สำหรับส่งยาทางไปรษณีย์) — แยกตามวัน / เดือน / ปี
            </p>

            <div class="bg-white border rounded shadow-sm p-3 mb-3">
                <div class="row g-2 align-items-end">
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">ตั้งแต่</label>
                        <input type="text" id="filterStart" class="form-control form-control-sm" value="<?php echo htmlspecialchars($default_start); ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">ถึง</label>
                        <input type="text" id="filterEnd" class="form-control form-control-sm" value="<?php echo htmlspecialchars($default_end); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold mb-1">สรุปแยกตาม</label>
                        <div class="btn-group btn-group-sm w-100" role="group">
                            <input type="radio" class="btn-check" name="granularity" id="granDay" value="day" checked>
                            <label class="btn btn-outline-secondary" for="granDay">วัน</label>
                            <input type="radio" class="btn-check" name="granularity" id="granMonth" value="month">
                            <label class="btn btn-outline-secondary" for="granMonth">เดือน</label>
                            <input type="radio" class="btn-check" name="granularity" id="granYear" value="year">
                            <label class="btn btn-outline-secondary" for="granYear">ปี</label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary w-100" onclick="setQuickRange('month')">เดือนนี้</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary w-100" onclick="setQuickRange('ytd')">ตั้งแต่ต้นปี</button>
                    </div>
                    <div class="col-md-1">
                        <button type="button" class="btn btn-sm fw-bold text-white w-100" style="background:#0d9488;" id="btnLoad" onclick="loadPostalReport()">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>
                </div>

                <div class="border rounded p-2 mt-3 bg-light">
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" id="enableCompare" onchange="toggleComparePanel()">
                        <label class="form-check-label small fw-bold" for="enableCompare">เปรียบเทียบช่วงเวลา</label>
                    </div>
                    <div id="comparePanel" class="d-none">
                        <div class="row g-2 align-items-end">
                            <div class="col-md-3">
                                <label class="form-label small mb-1">โหมดเปรียบเทียบ</label>
                                <select id="compareMode" class="form-select form-select-sm" onchange="toggleComparePanel()">
                                    <option value="prev_year">ช่วงเดียวกันปีก่อน</option>
                                    <option value="year">เทียบเป็นปี</option>
                                    <option value="month">เทียบเป็นเดือน</option>
                                    <option value="custom">กำหนดช่วงเอง</option>
                                </select>
                            </div>
                            <div class="col-md-2 compare-year d-none">
                                <label class="form-label small mb-1">จำนวนปีที่เทียบ</label>
                                <select id="compareYearCount" class="form-select form-select-sm" onchange="toggleCompareYearPickers()">
                                    <option value="1">1 ปี</option>
                                    <option value="2">2 ปี</option>
                                    <option value="3">3 ปี</option>
                                </select>
                            </div>
                            <?php for ($slot = 1; $slot <= 3; $slot++): ?>
                            <div class="col-md-2 compare-year compare-year-pick d-none" data-slot="<?php echo $slot; ?>"<?php echo $slot > 1 ? ' style="display:none"' : ''; ?>>
                                <label class="form-label small mb-1">ปีที่ <?php echo $slot; ?></label>
                                <select id="compareYear<?php echo $slot; ?>" class="form-select form-select-sm compare-year-select">
                                    <?php foreach ($compare_year_options as $y): ?>
                                    <option value="<?php echo (int)$y; ?>"<?php echo $y === ($default_compare_year - ($slot - 1)) ? ' selected' : ''; ?>><?php echo (int)$y; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endfor; ?>
                            <div class="col-md-2 compare-month d-none">
                                <label class="form-label small mb-1">จำนวนเดือนที่เทียบ</label>
                                <select id="compareMonthCount" class="form-select form-select-sm" onchange="toggleCompareMonthPickers()">
                                    <option value="1">1 เดือน</option>
                                    <option value="2">2 เดือน</option>
                                    <option value="3">3 เดือน</option>
                                </select>
                            </div>
                            <?php for ($slot = 1; $slot <= 3; $slot++): ?>
                            <div class="col-md-2 compare-month compare-month-pick d-none" data-slot="<?php echo $slot; ?>"<?php echo $slot > 1 ? ' style="display:none"' : ''; ?>>
                                <label class="form-label small mb-1">เดือนที่ <?php echo $slot; ?></label>
                                <input type="month" id="compareMonth<?php echo $slot; ?>" class="form-control form-control-sm"
                                    value="<?php echo htmlspecialchars($default_compare_months[$slot] ?? date('Y-m')); ?>">
                            </div>
                            <?php endfor; ?>
                            <div class="col-md-2 compare-custom d-none">
                                <label class="form-label small mb-1">เปรียบเทียบ ตั้งแต่</label>
                                <input type="text" id="compareStart" class="form-control form-control-sm">
                            </div>
                            <div class="col-md-2 compare-custom d-none">
                                <label class="form-label small mb-1">เปรียบเทียบ ถึง</label>
                                <input type="text" id="compareEnd" class="form-control form-control-sm">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="metaBox" class="alert alert-info py-2 small d-none mb-3"></div>

            <div id="kpiSingle" class="row g-3 mb-3">
                <div class="col-md-4">
                    <div class="card pdr-stat-card p-3">
                        <div class="text-muted small">จำนวนรายการ</div>
                        <div class="stat-value text-dark" id="sumItems">—</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card pdr-stat-card p-3">
                        <div class="text-muted small">จำนวนผู้ป่วย (HN)</div>
                        <div class="stat-value text-dark" id="sumPatients">—</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card pdr-stat-card p-3">
                        <div class="text-muted small">จำนวน visit (VN)</div>
                        <div class="stat-value text-success" id="sumVisits">—</div>
                    </div>
                </div>
            </div>

            <div id="kpiCompare" class="d-none mb-3">
                <div class="table-responsive bg-white border rounded shadow-sm">
                    <table class="table table-sm mb-0 align-middle">
                        <thead class="table-light text-center small">
                            <tr>
                                <th>ช่วง</th>
                                <th>จำนวนรายการ</th>
                                <th>ผู้ป่วย (HN)</th>
                                <th>Visit (VN)</th>
                                <th>ต่างรายการ</th>
                                <th>%</th>
                            </tr>
                        </thead>
                        <tbody id="compareKpiTbody"></tbody>
                    </table>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-chart-bar me-1 text-secondary"></i> <span id="chartTitle">สรุปตามช่วง</span>
                </div>
                <div class="card-body">
                    <div id="summaryChartWrap">
                        <div id="summaryChartStats" class="d-none"></div>
                        <canvas id="summaryChart"></canvas>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle pdr-table">
                        <thead class="text-center small" id="periodThead">
                            <tr>
                                <th id="periodHeader">ช่วง</th>
                                <th>จำนวนรายการ</th>
                                <th>ผู้ป่วย (HN)</th>
                                <th>Visit (VN)</th>
                            </tr>
                        </thead>
                        <tbody id="periodTbody">
                            <tr><td colspan="4" class="text-center py-4 text-muted">กดโหลดข้อมูล</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white fw-bold d-flex flex-wrap align-items-center gap-2">
                    <span><i class="fas fa-hospital me-1 text-secondary"></i> สรุปแยกตามจุดตรวจ</span>
                    <span class="small text-muted ms-auto" id="clinicChartHint"></span>
                </div>
                <div class="card-body">
                    <div id="clinicChartWrap"><canvas id="clinicChart"></canvas></div>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle pdr-table">
                        <thead class="text-center small">
                            <tr>
                                <th class="text-start">จุดตรวจ</th>
                                <th>จำนวนรายการ</th>
                                <th>ผู้ป่วย (HN)</th>
                                <th>Visit (VN)</th>
                                <th>สัดส่วน</th>
                            </tr>
                        </thead>
                        <tbody id="clinicTbody">
                            <tr><td colspan="5" class="text-center py-4 text-muted">กดโหลดข้อมูล</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white fw-bold d-flex flex-wrap align-items-center gap-2">
                    <span><i class="fas fa-list me-1 text-secondary"></i> รายละเอียดลงทะเบียน</span>
                    <button type="button" class="btn btn-sm btn-outline-success ms-auto" id="btnExportExcel" disabled onclick="exportExcel()">
                        <i class="fas fa-file-excel me-1"></i> ส่งออก Excel
                    </button>
                </div>
                <div class="px-3 pt-2 pb-0 border-bottom">
                    <input type="search" id="detailSearch" class="form-control form-control-sm" placeholder="ค้นหาชื่อ HN / EMS / จุดตรวจ..." autocomplete="off">
                </div>
                <div class="table-responsive">
                    <table class="table table-sm table-hover mb-0 align-middle" style="font-size:.85rem;">
                        <thead class="table-light text-center small">
                            <tr>
                                <th>ลำดับ</th>
                                <th>วันเดือนปีที่รับใบสั่งยา</th>
                                <th class="text-start">ชื่อ-นามสกุลผู้ป่วย</th>
                                <th>HN</th>
                                <th>สิทธิ์การรักษา</th>
                                <th>จุดตรวจ</th>
                                <th>EMS</th>
                                <th>การโทรติดตาม</th>
                                <th>ปัญหาที่พบ</th>
                                <th>ผู้ป่วยแจ้งปัญหาทางเพจ/โทรมา</th>
                                <th>หมายเหตุ</th>
                            </tr>
                        </thead>
                        <tbody id="detailTbody">
                            <tr><td colspan="11" class="text-center py-4 text-muted">กดโหลดข้อมูล</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/flatpickr.min.js"></script>
<script src="js/chart.min.js"></script>
<script src="https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"></script>
<script>
const PDR_API = 'fetch_postal_drug_report_api.php';
const CHART_COLORS = ['#0d9488', '#64748b', '#f59e0b', '#3b82f6', '#ef4444', '#8b5cf6', '#14b8a6', '#f97316', '#06b6d4', '#84cc16'];
let fpStart = null, fpEnd = null, fpCompareStart = null, fpCompareEnd = null;
let summaryChart = null;
let clinicChart = null;
let detailRows = [];
let currentReport = null;

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function qs(obj) {
    return Object.keys(obj).filter(k => obj[k] !== '' && obj[k] != null)
        .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(obj[k])).join('&');
}

async function fetchJson(url) {
    const r = await fetch(url, { credentials: 'same-origin' });
    const text = await r.text();
    try { return JSON.parse(text); } catch (e) { throw new Error(text ? text.substring(0, 300) : ('HTTP ' + r.status)); }
}

function getGranularity() {
    return $('input[name="granularity"]:checked').val() || 'day';
}

function granularityLabel(g) {
    if (g === 'year') return 'ปี';
    if (g === 'month') return 'เดือน';
    return 'วัน';
}

function setQuickRange(mode) {
    const end = new Date();
    let start = new Date(end.getFullYear(), end.getMonth(), 1);
    if (mode === 'ytd') start = new Date(end.getFullYear(), 0, 1);
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    if (fpStart) fpStart.setDate(fmt(start), true); else $('#filterStart').val(fmt(start));
    if (fpEnd) fpEnd.setDate(fmt(end), true); else $('#filterEnd').val(fmt(end));
}

function toggleComparePanel() {
    const on = $('#enableCompare').is(':checked');
    $('#comparePanel').toggleClass('d-none', !on);
    const mode = $('#compareMode').val();
    $('.compare-custom').toggleClass('d-none', !(on && mode === 'custom'));
    const byYear = on && mode === 'year';
    $('.compare-year').toggleClass('d-none', !byYear);
    const byMonth = on && mode === 'month';
    $('.compare-month').toggleClass('d-none', !byMonth);
    if (byYear) toggleCompareYearPickers();
    else if (byMonth) toggleCompareMonthPickers();
    else {
        $('.compare-year-pick').hide();
        $('.compare-month-pick').hide();
    }
}

function toggleCompareYearPickers() {
    const n = parseInt($('#compareYearCount').val(), 10) || 1;
    $('.compare-year-pick').each(function() {
        const slot = parseInt($(this).data('slot'), 10);
        $(this).toggle(slot <= n);
    });
}

function toggleCompareMonthPickers() {
    const n = parseInt($('#compareMonthCount').val(), 10) || 1;
    $('.compare-month-pick').each(function() {
        const slot = parseInt($(this).data('slot'), 10);
        $(this).toggle(slot <= n);
    });
}

function getCompareMonthList() {
    const months = [];
    const n = parseInt($('#compareMonthCount').val(), 10) || 1;
    for (let i = 1; i <= n; i++) {
        const m = $('#compareMonth' + i).val();
        if (m && months.indexOf(m) === -1) months.push(m);
    }
    return months;
}

function getReportParams() {
    const p = {
        action: 'report',
        start_date: $('#filterStart').val(),
        end_date: $('#filterEnd').val(),
        granularity: getGranularity(),
    };
    if ($('#enableCompare').is(':checked')) {
        p.compare = '1';
        p.compare_mode = $('#compareMode').val();
        if (p.compare_mode === 'custom') {
            p.compare_start = $('#compareStart').val();
            p.compare_end = $('#compareEnd').val();
        } else if (p.compare_mode === 'year') {
            const years = [];
            const n = parseInt($('#compareYearCount').val(), 10) || 1;
            for (let i = 1; i <= n; i++) {
                const y = $('#compareYear' + i).val();
                if (y && years.indexOf(y) === -1) years.push(y);
            }
            p.compare_years = years.join(',');
        } else if (p.compare_mode === 'month') {
            p.compare_months = getCompareMonthList().join(',');
        }
    }
    return p;
}

function getFilteredDetails() {
    const q = ($('#detailSearch').val() || '').trim().toLowerCase();
    if (!q) return detailRows;
    return detailRows.filter(r => {
        const blob = [r.patient_name, r.hn, r.vn, r.pttype_name, r.clinic_name, r.ems_track, r.tele_status, r.tele_comment, r.page_feedback, r.note]
            .join(' ').toLowerCase();
        return blob.indexOf(q) !== -1;
    });
}

function dirClass(dir) {
    if (dir === 'up') return 'pdr-compare-up';
    if (dir === 'down') return 'pdr-compare-down';
    return '';
}

function renderPeriodRows(rows) {
    if (!rows || !rows.length) {
        return '<tr><td colspan="4" class="text-center py-4 text-muted">ไม่มีข้อมูล</td></tr>';
    }
    return rows.map(r => '<tr>'
        + '<td class="text-center fw-bold">' + esc(r.period_label) + '</td>'
        + '<td class="text-center">' + esc(r.item_count_display) + '</td>'
        + '<td class="text-center">' + esc(r.patient_count_display) + '</td>'
        + '<td class="text-center">' + esc(r.visit_count_display) + '</td>'
        + '</tr>').join('');
}

function renderCompareKpi(comp) {
    const rows = (comp && comp.rows) || [];
    if (!rows.length) {
        $('#compareKpiTbody').html('<tr><td colspan="6" class="text-center text-muted py-3">ไม่มีข้อมูลเปรียบเทียบ</td></tr>');
        return;
    }
    $('#compareKpiTbody').html(rows.map((r, i) => {
        const diff = i === 0 ? '—' : esc(r.diff_item_count_display || '0');
        const pct = i === 0 ? '—' : esc(r.pct_item_count || '0%');
        const cls = i === 0 ? '' : dirClass(r.diff_item_dir);
        return '<tr>'
            + '<td class="fw-bold">' + esc(r.label) + '</td>'
            + '<td class="text-center">' + esc(r.item_count_display) + '</td>'
            + '<td class="text-center">' + esc(r.patient_count_display) + '</td>'
            + '<td class="text-center">' + esc(r.visit_count_display) + '</td>'
            + '<td class="text-center fw-bold ' + cls + '">' + diff + '</td>'
            + '<td class="text-center ' + cls + '">' + pct + '</td>'
            + '</tr>';
    }).join(''));
}

function renderDetailRows(rows) {
    if (!rows || !rows.length) {
        const emptyMsg = detailRows.length ? 'ไม่พบรายการที่ค้นหา' : 'ไม่มีข้อมูล';
        return '<tr><td colspan="11" class="text-center py-4 text-muted">' + emptyMsg + '</td></tr>';
    }
    return rows.map((r, i) => '<tr>'
        + '<td class="text-center">' + (i + 1) + '</td>'
        + '<td class="text-center">' + esc(r.rx_date_display) + (r.rx_time ? '<div class="small text-muted">' + esc(r.rx_time) + '</div>' : '') + '</td>'
        + '<td>' + esc(r.patient_name || '—') + '</td>'
        + '<td class="text-center"><code>' + esc(r.hn || '—') + '</code></td>'
        + '<td>' + esc(r.pttype_name || '—') + '</td>'
        + '<td>' + esc(r.clinic_name || '—') + '</td>'
        + '<td class="text-center">' + esc(r.ems_track || '—') + '</td>'
        + '<td class="text-center">' + esc(r.tele_status || '—') + '</td>'
        + '<td>' + esc(r.tele_comment || '—') + '</td>'
        + '<td>' + esc(r.page_feedback || '—') + '</td>'
        + '<td>' + esc(r.note || '—') + '</td>'
        + '</tr>').join('');
}

function destroyChart() {
    if (summaryChart) { summaryChart.destroy(); summaryChart = null; }
}

function formatChartStat(n) {
    const v = Number(n);
    if (!isFinite(v)) return '—';
    if (Math.abs(v - Math.round(v)) < 0.05) return String(Math.round(v));
    return v.toFixed(1);
}

function updateSummaryChartStats(values) {
    const el = document.getElementById('summaryChartStats');
    if (!el) return;
    const nums = (values || []).map(Number).filter(v => isFinite(v));
    if (!nums.length) {
        el.classList.add('d-none');
        el.innerHTML = '';
        return;
    }
    const min = Math.min.apply(null, nums);
    const max = Math.max.apply(null, nums);
    const avg = nums.reduce((a, b) => a + b, 0) / nums.length;
    el.innerHTML =
        '<div class="stat-line stat-avg">Avg <strong>' + formatChartStat(avg) + '</strong></div>' +
        '<div class="stat-line stat-max">Max <strong>' + formatChartStat(max) + '</strong></div>' +
        '<div class="stat-line stat-min">Min <strong>' + formatChartStat(min) + '</strong></div>';
    el.classList.remove('d-none');
}

function clearSummaryChartStats() {
    const el = document.getElementById('summaryChartStats');
    if (!el) return;
    el.classList.add('d-none');
    el.innerHTML = '';
}

function destroyClinicChart() {
    if (clinicChart) { clinicChart.destroy(); clinicChart = null; }
}

function clinicPalette(n) {
    const out = [];
    for (let i = 0; i < n; i++) out.push(CHART_COLORS[i % CHART_COLORS.length]);
    return out;
}

function renderClinicRows(rows) {
    if (!rows || !rows.length) {
        return '<tr><td colspan="5" class="text-center py-4 text-muted">ไม่มีข้อมูล</td></tr>';
    }
    return rows.map(r => '<tr>'
        + '<td class="text-start fw-bold">' + esc(r.clinic_name) + '</td>'
        + '<td class="text-center">' + esc(r.item_count_display) + '</td>'
        + '<td class="text-center">' + esc(r.patient_count_display) + '</td>'
        + '<td class="text-center">' + esc(r.visit_count_display) + '</td>'
        + '<td class="text-center">' + esc(r.pct_share_display || '0%') + '</td>'
        + '</tr>').join('');
}

function renderClinicChart(rows) {
    const ctx = document.getElementById('clinicChart');
    if (!ctx || typeof Chart === 'undefined') return;
    destroyClinicChart();
    if (!rows || !rows.length) {
        $('#clinicChartHint').text('');
        $('#clinicChartWrap').css('height', '280px');
        return;
    }
    const top = rows.slice(0, 20);
    const h = Math.max(280, Math.min(720, 48 + top.length * 28));
    $('#clinicChartWrap').css('height', h + 'px');
    if (rows.length > top.length) {
        $('#clinicChartHint').text('แสดง Top ' + top.length + ' จาก ' + rows.length + ' จุดตรวจ (เรียงตามจำนวนรายการ)');
    } else {
        $('#clinicChartHint').text(rows.length + ' จุดตรวจ');
    }
    clinicChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: top.map(r => r.clinic_name),
            datasets: [{
                label: 'จำนวนรายการ',
                data: top.map(r => Number(r.item_count) || 0),
                backgroundColor: clinicPalette(top.length),
                borderRadius: 4,
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: function(ctx) {
                            const row = top[ctx.dataIndex];
                            if (!row) return '';
                            return [
                                'HN: ' + (row.patient_count_display || row.patient_count || 0),
                                'VN: ' + (row.visit_count_display || row.visit_count || 0),
                                'สัดส่วน: ' + (row.pct_share_display || ''),
                            ];
                        }
                    }
                }
            },
            scales: {
                x: { beginAtZero: true, ticks: { precision: 0 } },
                y: { ticks: { autoSkip: false } }
            }
        }
    });
}

function renderSummaryChart(rows) {
    const ctx = document.getElementById('summaryChart');
    if (!ctx || typeof Chart === 'undefined') return;
    destroyChart();
    if (!rows || !rows.length) {
        clearSummaryChartStats();
        return;
    }
    const values = rows.map(r => Number(r.item_count) || 0);
    updateSummaryChartStats(values);
    summaryChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: rows.map(r => r.period_label),
            datasets: [{
                label: 'จำนวนรายการ',
                data: values,
                backgroundColor: '#0d9488',
                borderRadius: 4,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: { padding: { top: 8, right: 88 } },
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
        }
    });
}

function renderCompareChart(comp) {
    const ctx = document.getElementById('summaryChart');
    if (!ctx || typeof Chart === 'undefined' || !comp) return;
    destroyChart();

    if (comp.aligned_chart && comp.aligned_chart.labels && comp.aligned_chart.labels.length) {
        const allVals = [];
        (comp.aligned_chart.datasets || []).forEach(ds => {
            (ds.data || []).forEach(v => allVals.push(Number(v) || 0));
        });
        updateSummaryChartStats(allVals);
        summaryChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: comp.aligned_chart.labels,
                datasets: (comp.aligned_chart.datasets || []).map((ds, i) => ({
                    label: ds.label,
                    data: ds.data || [],
                    backgroundColor: CHART_COLORS[i % CHART_COLORS.length],
                    borderRadius: 4,
                }))
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                layout: { padding: { top: 8, right: 88 } },
                plugins: { legend: { display: true, position: 'top' } },
                scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
            }
        });
        return;
    }

    const chart = comp.chart || {};
    const values = chart.item_counts || [];
    updateSummaryChartStats(values);
    summaryChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chart.labels || [],
            datasets: [{
                label: 'จำนวนรายการ',
                data: values,
                backgroundColor: (chart.labels || []).map((_, i) => CHART_COLORS[i % CHART_COLORS.length]),
                borderRadius: 4,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: { padding: { top: 8, right: 88 } },
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
        }
    });
}

function exportExcel() {
    const rows = getFilteredDetails();
    if (!rows.length || typeof XLSX === 'undefined') {
        alert(rows.length ? 'ไม่สามารถโหลดไลบรารี Excel ได้' : 'ไม่มีข้อมูลสำหรับส่งออก');
        return;
    }
    const headers = ['ลำดับ','วันเดือนปีที่รับใบสั่งยา','เวลา','ชื่อ-นามสกุลผู้ป่วย','HN','VN','สิทธิ์การรักษา','จุดตรวจ','EMS','การโทรติดตาม','ปัญหาที่พบ','ผู้ป่วยแจ้งปัญหาทางเพจ/โทรมา','หมายเหตุ'];
    const data = rows.map((r, i) => [
        i + 1, r.rx_date_display || '', r.rx_time || '', r.patient_name || '', r.hn || '', r.vn || '',
        r.pttype_name || '', r.clinic_name || '', r.ems_track || '', r.tele_status || '', r.tele_comment || '',
        r.page_feedback || '', r.note || ''
    ]);
    const ws = XLSX.utils.aoa_to_sheet([headers].concat(data));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'รับยาปณ');
    const start = ($('#filterStart').val() || '').replace(/[\\/:*?"<>|]/g, '_');
    const end = ($('#filterEnd').val() || '').replace(/[\\/:*?"<>|]/g, '_');
    XLSX.writeFile(wb, 'postal_drug_ue_' + start + '_' + end + '.xlsx');
}

async function loadPostalReport() {
    $('#btnLoad').prop('disabled', true);
    $('#detailTbody').html('<tr><td colspan="11" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังโหลด...</td></tr>');
    $('#periodTbody').html('<tr><td colspan="4" class="text-center py-3 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังโหลด...</td></tr>');
    $('#clinicTbody').html('<tr><td colspan="5" class="text-center py-3 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังโหลด...</td></tr>');
    try {
        const gran = getGranularity();
        const data = await fetchJson(PDR_API + '?' + qs(getReportParams()));
        if (data.status !== 'success') throw new Error(data.message || 'โหลดไม่สำเร็จ');
        currentReport = data;
        const sum = data.summary || {};
        const comp = data.compare || null;
        const comparing = !!(comp && comp.rows && comp.rows.length >= 2);

        $('#sumItems').text(sum.item_count_display || '0');
        $('#sumPatients').text(sum.patient_count_display || '0');
        $('#sumVisits').text(sum.visit_count_display || '0');
        $('#kpiSingle').toggleClass('d-none', comparing);
        $('#kpiCompare').toggleClass('d-none', !comparing);
        if (comparing) renderCompareKpi(comp);

        $('#periodHeader').text(granularityLabel(gran));
        $('#periodTbody').html(renderPeriodRows(data.periods || []));
        $('#clinicTbody').html(renderClinicRows(data.clinics || []));
        renderClinicChart(data.clinics || []);
        if (comparing) {
            $('#chartTitle').text('เปรียบเทียบช่วงเวลา');
            renderCompareChart(comp);
        } else {
            $('#chartTitle').text('สรุปตามช่วง');
            renderSummaryChart(data.periods || []);
        }

        detailRows = data.details || [];
        $('#detailSearch').val('');
        $('#detailTbody').html(renderDetailRows(detailRows));
        $('#btnExportExcel').prop('disabled', !detailRows.length);

        const meta = data.meta || {};
        let metaHtml = '<i class="fas fa-info-circle me-1"></i>ช่วง: ' + esc((data.period && data.period.label) || '');
        metaHtml += ' | สรุปแยก' + granularityLabel(gran);
        metaHtml += ' | แหล่ง: UE form #' + esc(meta.universal_form_id || 132);
        if (comparing) metaHtml += ' | เปรียบเทียบ: ' + esc((comp.labels || []).join(' vs '));
        if (meta.elapsed_ms != null) metaHtml += ' | อ่าน ' + (meta.elapsed_ms / 1000).toFixed(2) + ' วินาที';
        if (meta.detail_truncated) metaHtml += ' | รายละเอียดถูกจำกัดที่ ' + esc(meta.detail_limit) + ' รายการ';
        $('#metaBox').removeClass('d-none alert-danger').addClass('alert-info').html(metaHtml);
    } catch (err) {
        const msg = esc(err.message || 'เกิดข้อผิดพลาด');
        $('#sumItems,#sumPatients,#sumVisits').text('0');
        $('#kpiSingle').removeClass('d-none');
        $('#kpiCompare').addClass('d-none');
        $('#periodTbody').html('<tr><td colspan="4" class="text-center text-danger py-3">' + msg + '</td></tr>');
        $('#clinicTbody').html('<tr><td colspan="5" class="text-center text-danger py-3">' + msg + '</td></tr>');
        $('#clinicChartHint').text('');
        $('#detailTbody').html('<tr><td colspan="11" class="text-center text-danger py-4">' + msg + '</td></tr>');
        $('#metaBox').removeClass('d-none alert-info').addClass('alert-danger').html('<i class="fas fa-exclamation-circle me-1"></i>' + msg);
        $('#btnExportExcel').prop('disabled', true);
        destroyChart();
        destroyClinicChart();
        clearSummaryChartStats();
    } finally {
        $('#btnLoad').prop('disabled', false);
    }
}

$(function() {
    if (typeof flatpickr !== 'undefined') {
        fpStart = flatpickr('#filterStart', { dateFormat: 'Y-m-d' });
        fpEnd = flatpickr('#filterEnd', { dateFormat: 'Y-m-d' });
        fpCompareStart = flatpickr('#compareStart', { dateFormat: 'Y-m-d' });
        fpCompareEnd = flatpickr('#compareEnd', { dateFormat: 'Y-m-d' });
    }
    toggleComparePanel();
    $(document).on('input', '#detailSearch', function() {
        $('#detailTbody').html(renderDetailRows(getFilteredDetails()));
    });
    $(document).on('change', 'input[name="granularity"]', function() {
        if (currentReport) loadPostalReport();
    });
});
</script>
</body>
</html>
