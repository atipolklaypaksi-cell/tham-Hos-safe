<?php
/**
 * Cron ซิงก์ mLAB → THAM Hos-Safe ตามช่วงที่ตั้งในหน้าเชื่อมต่อ AMR (ตรวจทุก 5 นาที)
 * CLI:  php cron_amr_mlab_sync.php
 * HTTP: cron_amr_mlab_sync.php?key=SECRET
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
set_time_limit(600);
ini_set('memory_limit', '1024M');

include(__DIR__ . '/connect.php');
require_once __DIR__ . '/amr_mlab_helper.php';
mysqli_set_charset($con, 'utf8');
amr_mlab_ensure_tables($con);

$cfg = amr_mlab_get_config($con);
$interval = amr_mlab_norm_sync_interval($cfg['sync_interval_min'] ?? 10);
$label = amr_mlab_sync_interval_label($interval);

if (php_sapi_name() !== 'cli') {
    $secret = trim((string)($cfg['cron_secret'] ?? ''));
    $key = trim((string)($_GET['key'] ?? ''));
    if ($secret === '' || $key !== $secret) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Forbidden';
        exit;
    }
}

$force = !empty($_GET['force']) || (isset($argv) && in_array('--force', $argv, true));
if (($cfg['sync_enabled'] ?? '0') !== '1' && !$force) {
    $out = ['status' => 'skipped', 'message' => 'ยังไม่เปิดซิงก์อัตโนมัติ'];
    echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
    exit(0);
}

$due = amr_mlab_cron_due($con, $interval, $force);
if (empty($due['due'])) {
    $wait = (int)($due['wait_sec'] ?? 0);
    $out = [
        'status' => 'skipped',
        'message' => 'ยังไม่ถึงรอบซิงก์ (ทุก ' . $label . ' · อีก ' . max(1, (int)ceil($wait / 60)) . ' นาที)',
        'interval_min' => $interval,
        'wait_sec' => $wait,
    ];
    echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
    exit(0);
}

$log_dir = __DIR__ . '/logs';
if (!is_dir($log_dir)) {
    @mkdir($log_dir, 0775, true);
}

$lock = fopen(__DIR__ . '/logs/cron_amr_mlab.lock', 'c+');
if ($lock && !flock($lock, LOCK_EX | LOCK_NB)) {
    echo json_encode(['status' => 'skipped', 'message' => 'มีรอบซิงก์กำลังทำงาน'], JSON_UNESCAPED_UNICODE) . PHP_EOL;
    exit(0);
}

$res = amr_mlab_sync($con, false);
if (($res['status'] ?? '') === 'ok') {
    amr_mlab_state_set($con, 'cron', date('Y-m-d'), time(), (int)(($res['inserted'] ?? 0) + ($res['updated'] ?? 0)), '');
}
if ($lock) {
    flock($lock, LOCK_UN);
    fclose($lock);
}

if (php_sapi_name() !== 'cli') {
    header('Content-Type: application/json; charset=utf-8');
}
echo json_encode($res, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
