<?php
/**
 * Monitor mg → mL — ตรวจการแปลงขนาดยา mg เป็น mL ในวิธีใช้
 * รองรับชั้นตรวจเพิ่ม: น้ำหนัก (mg/kg, mg/kg/hr), จำนวนจ่าย (Amp), Rate (ml/hr)
 */

require_once __DIR__ . '/monitor_mg_ml_catalog.php';

function mmgml_ensure_table($con) {
    $q = mysqli_query($con, "SHOW TABLES LIKE 'monitor_mg_ml_settings'");
    if ($q && mysqli_num_rows($q) > 0) {
        return mmgml_ensure_extra_columns($con);
    }
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_mg_ml.sql');
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '' && !mysqli_query($con, $stmt)) {
            return false;
        }
    }
    return mmgml_ensure_extra_columns($con);
}

/** เพิ่มคอลัมน์น้ำหนัก / จำนวนจ่าย / Rate บนตารางเดิม */
function mmgml_ensure_extra_columns($con) {
    $chk = mysqli_query($con, "SHOW COLUMNS FROM monitor_mg_ml_settings LIKE 'use_weight'");
    if (!$chk || mysqli_num_rows($chk) === 0) {
        $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
        try {
            $altered = mysqli_query(
                $con,
                "ALTER TABLE monitor_mg_ml_settings
                    ADD COLUMN use_weight TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'ใช้น้ำหนักคำนวณขนาดยา' AFTER tolerance_ml,
                    ADD COLUMN dose_mg_per_kg DECIMAL(12,4) NULL DEFAULT NULL COMMENT 'Bolus mg/kg' AFTER use_weight,
                    ADD COLUMN dose_mg_per_kg_hr DECIMAL(12,4) NULL DEFAULT NULL COMMENT 'Infusion mg/kg/hr' AFTER dose_mg_per_kg,
                    ADD COLUMN check_qty TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'ตรวจจำนวนจ่าย Amp' AFTER dose_mg_per_kg_hr,
                    ADD COLUMN mg_per_amp DECIMAL(12,4) NULL DEFAULT NULL COMMENT 'mg ต่อ Amp' AFTER check_qty,
                    ADD COLUMN check_rate TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'ตรวจ rate ml/hr' AFTER mg_per_amp,
                    ADD COLUMN default_hours DECIMAL(8,2) NULL DEFAULT NULL COMMENT 'ชั่วโมง default' AFTER check_rate,
                    ADD COLUMN default_volume_ml DECIMAL(12,2) NULL DEFAULT NULL COMMENT 'ปริมาตรสารน้ำ default' AFTER default_hours"
            );
            if (!$altered) {
                return false;
            }
        } catch (mysqli_sql_exception $e) {
            return false;
        } finally {
            mysqli_report($prev_mode);
        }
    }

    $chk2 = mysqli_query($con, "SHOW COLUMNS FROM monitor_mg_ml_settings LIKE 'weight_lookback_days'");
    if (!$chk2 || mysqli_num_rows($chk2) === 0) {
        $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
        try {
            $ok = mysqli_query(
                $con,
                "ALTER TABLE monitor_mg_ml_settings
                    ADD COLUMN weight_lookback_days INT NOT NULL DEFAULT 365
                    COMMENT 'ย้อนหลังกี่วันสำหรับน้ำหนักเก่า (จากวันสั่งยา)' AFTER dose_mg_per_kg_hr"
            );
            if (!$ok) {
                return false;
            }
        } catch (mysqli_sql_exception $e) {
            return false;
        } finally {
            mysqli_report($prev_mode);
        }
    }

    $chk3 = mysqli_query($con, "SHOW COLUMNS FROM monitor_mg_ml_settings LIKE 'use_weight'");
    if (!$chk3 || mysqli_num_rows($chk3) === 0) {
        return false;
    }

    $chk4 = mysqli_query($con, "SHOW COLUMNS FROM monitor_mg_ml_settings LIKE 'exempt_fixed_dose'");
    if (!$chk4 || mysqli_num_rows($chk4) === 0) {
        $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
        try {
            $ok = mysqli_query(
                $con,
                "ALTER TABLE monitor_mg_ml_settings
                    ADD COLUMN exempt_fixed_dose TINYINT(1) NOT NULL DEFAULT 0
                    COMMENT 'ยกเว้นขนาดคงที่ (ไม่คิดตามน้ำหนัก) เช่น IV 1 GM / 500 MG drip นาน … นาที'
                    AFTER default_volume_ml"
            );
            if (!$ok) {
                return false;
            }
        } catch (mysqli_sql_exception $e) {
            return false;
        } finally {
            mysqli_report($prev_mode);
        }
    }

    $chk5 = mysqli_query($con, "SHOW COLUMNS FROM monitor_mg_ml_settings LIKE 'exempt_dose_patterns'");
    if (!$chk5 || mysqli_num_rows($chk5) === 0) {
        $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
        try {
            $ok = mysqli_query(
                $con,
                "ALTER TABLE monitor_mg_ml_settings
                    ADD COLUMN exempt_dose_patterns VARCHAR(500) NULL DEFAULT NULL
                    COMMENT 'ข้อความในวิธีใช้ที่ยกเว้น คั่นด้วยจุลภาค เช่น 1 GM, 500 MG'
                    AFTER exempt_fixed_dose"
            );
            if (!$ok) {
                return false;
            }
        } catch (mysqli_sql_exception $e) {
            return false;
        } finally {
            mysqli_report($prev_mode);
        }
    }

    $chk_lvl = mysqli_query($con, "SHOW COLUMNS FROM monitor_mg_ml_settings LIKE 'alert_level'");
    if ($chk_lvl && ($col = mysqli_fetch_assoc($chk_lvl))) {
        $def = strtolower(trim((string)($col['Default'] ?? '')));
        if ($def !== 'soft') {
            $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
            try {
                mysqli_query($con, "ALTER TABLE monitor_mg_ml_settings MODIFY alert_level VARCHAR(10) NOT NULL DEFAULT 'soft'");
                mysqli_query($con, "UPDATE monitor_mg_ml_settings SET alert_level='soft' WHERE alert_level <> 'soft'");
            } catch (mysqli_sql_exception $e) {
                // ignore
            } finally {
                mysqli_report($prev_mode);
            }
            if (function_exists('sp_monitor_settings_changed')) {
                sp_monitor_settings_changed($con, 'mg_ml');
            }
        }
    }

    $chk6 = mysqli_query($con, "SHOW COLUMNS FROM monitor_mg_ml_settings LIKE 'calc_mg_per_kg_min'");
    if (!$chk6 || mysqli_num_rows($chk6) === 0) {
        $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
        try {
            mysqli_query(
                $con,
                "ALTER TABLE monitor_mg_ml_settings
                    ADD COLUMN calc_mg_per_kg_min DECIMAL(12,4) NULL DEFAULT NULL COMMENT 'ขนาดต่ำสุด mg/kg ต่อครั้ง (เครื่องคำนวณ)' AFTER mg_per_amp,
                    ADD COLUMN calc_mg_per_kg_max DECIMAL(12,4) NULL DEFAULT NULL COMMENT 'ขนาดสูงสุด mg/kg ต่อครั้ง (เครื่องคำนวณ)' AFTER calc_mg_per_kg_min,
                    ADD COLUMN calc_interval_hours DECIMAL(8,2) NULL DEFAULT NULL COMMENT 'ช่วงให้ยา ชม. เช่น 6 = ทุก 6 ชม. ×4/วัน' AFTER calc_mg_per_kg_max"
            );
            mysqli_query(
                $con,
                "UPDATE monitor_mg_ml_settings
                 SET calc_mg_per_kg_min = dose_mg_per_kg,
                     calc_mg_per_kg_max = dose_mg_per_kg
                 WHERE dose_mg_per_kg IS NOT NULL AND dose_mg_per_kg > 0
                   AND calc_mg_per_kg_min IS NULL"
            );
        } catch (mysqli_sql_exception $e) {
            // ignore
        } finally {
            mysqli_report($prev_mode);
        }
    }

    return true;
}

function mmgml_escape($con, $v) {
    return mysqli_real_escape_string($con, $v ?? '');
}

function mmgml_alert_level($row) {
    return (($row['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
}

function mmgml_alert_badge_html($level) {
    if ($level === 'hard') {
        return '<span class="badge bg-danger">Hard Alert</span>';
    }
    return '<span class="badge bg-warning text-dark">Soft Alert</span>';
}

function mmgml_flag_int($v) {
    return !empty($v) ? 1 : 0;
}

function mmgml_nullable_float($v) {
    if ($v === null || $v === '') {
        return null;
    }
    $f = (float)$v;
    return $f;
}

function mmgml_sql_nullable_num($v) {
    if ($v === null || $v === '') {
        return 'NULL';
    }
    return (string)(float)$v;
}

function mmgml_sql_in_strings($hos, array $vals) {
    $out = [];
    foreach ($vals as $v) {
        $v = trim((string)$v);
        if ($v === '') {
            continue;
        }
        $out[$v] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return implode(',', array_values($out));
}

function mmgml_sql_utf8($expr) {
    return "CAST(CONVERT({$expr} USING utf8) AS CHAR)";
}

/**
 * คิวรีใบยาแบบเบา (ไม่ JOIN TMT/วิธีใช้/ผู้ป่วย) แล้วค่อยเติมข้อมูลทีหลัง
 * กัน nginx 504 เมื่อเลือกยาฉีดจำนวนมาก
 */
function mmgml_fetch_orders_lean($hos, array $icodes, $start, $end, $recent_minutes, $limit, $hn_raw = '') {
    $limit = max(100, min(8000, (int)$limit));
    $recent_minutes = max(0, min(1440, (int)$recent_minutes));
    $all = [];
    $startEsc = mysqli_real_escape_string($hos, $start);
    $endEsc = mysqli_real_escape_string($hos, $end);
    $hn_clause = function_exists('monitor_hn_sql_clause') ? monitor_hn_sql_clause($hos, $hn_raw, 'o.hn') : '';
    $ics = [];
    foreach ($icodes as $ic) {
        $ic = trim((string)$ic);
        if ($ic !== '') {
            $ics[$ic] = true;
        }
    }
    $chunks = array_chunk(array_keys($ics), 40);
    foreach ($chunks as $chunk) {
        if (count($all) >= $limit) {
            break;
        }
        $in = mmgml_sql_in_strings($hos, $chunk);
        if ($in === '') {
            continue;
        }
        $dateSql = "o.rxdate BETWEEN '{$startEsc}' AND '{$endEsc}'";
        if ($recent_minutes > 0) {
            $dateSql .= " AND UNIX_TIMESTAMP(CONCAT(o.rxdate, ' ', IFNULL(o.rxtime,'00:00:00')))
                BETWEEN UNIX_TIMESTAMP(SUBDATE(NOW(), INTERVAL {$recent_minutes} MINUTE)) AND UNIX_TIMESTAMP(NOW())";
        }
        $remain = $limit - count($all);
        $sql = "SELECT o.hn, o.vn, o.an, o.vstdate, o.rxdate, o.rxtime, o.icode, o.qty, o.item_no,
                       o.drugusage, o.sp_use, o.hos_guid
                FROM opitemrece o
                WHERE o.icode IN ({$in})
                  AND {$dateSql}
                  AND o.qty > 0
                  {$hn_clause}
                LIMIT {$remain}";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $all[] = $r;
        }
    }
    usort($all, static function ($a, $b) {
        $ka = (string)($a['rxdate'] ?? '') . ' ' . (string)($a['rxtime'] ?? '') . ' ' . (string)($a['item_no'] ?? '');
        $kb = (string)($b['rxdate'] ?? '') . ' ' . (string)($b['rxtime'] ?? '') . ' ' . (string)($b['item_no'] ?? '');
        return strcmp($kb, $ka);
    });
    return array_slice($all, 0, $limit);
}

function mmgml_enrich_monitor_orders($hos, array $rows, array $opts = []) {
    if (!$rows) {
        return $rows;
    }
    $want_drug = $opts['drug'] ?? true;
    $want_method = $opts['method'] ?? true;
    $want_patient = $opts['patient'] ?? true;
    $want_ward = $opts['ward'] ?? true;

    $hns = [];
    $ans = [];
    $icodes = [];
    $dusage = [];
    $spuse = [];
    $guidsNeedDisp = [];
    foreach ($rows as $r) {
        if ($want_patient) {
            $hn = trim((string)($r['hn'] ?? ''));
            if ($hn !== '') {
                $hns[$hn] = true;
            }
        }
        if ($want_ward) {
            $an = trim((string)($r['an'] ?? ''));
            if ($an !== '') {
                $ans[$an] = true;
            }
        }
        if ($want_drug) {
            $ic = trim((string)($r['icode'] ?? ''));
            if ($ic !== '') {
                $icodes[$ic] = true;
            }
        }
        if ($want_method) {
            $du = trim((string)($r['drugusage'] ?? ''));
            if ($du !== '') {
                $dusage[$du] = true;
            }
            $sp = trim((string)($r['sp_use'] ?? ''));
            if ($sp !== '') {
                $spuse[$sp] = true;
            } else {
                $g = trim((string)($r['hos_guid'] ?? ''));
                if ($g !== '') {
                    $guidsNeedDisp[$g] = true;
                }
            }
        }
    }

    $drugMap = [];
    if ($want_drug) {
        $icIn = mmgml_sql_in_strings($hos, array_keys($icodes));
        if ($icIn !== '') {
            $nameExpr = mmgml_sql_utf8('IFNULL(d.name,\'\')');
            $unitExpr = mmgml_sql_utf8('IFNULL(d.units,\'\')');
            $hasTmt = function_exists('hosxp_sql_tmt_strength') && function_exists('hosxp_sql_tmt_join');
            if ($hasTmt) {
                $tmtStrExpr = mmgml_sql_utf8(hosxp_sql_tmt_strength('d', 'tm'));
                $tmtJoin = hosxp_sql_tmt_join('d', 'tm');
            } else {
                $tmtStrExpr = mmgml_sql_utf8('IFNULL(d.strength,\'\')');
                $tmtJoin = '';
            }
            $hosStrExpr = mmgml_sql_utf8('IFNULL(d.strength,\'\')');
            $q = mysqli_query($hos, "SELECT d.icode, {$nameExpr} AS name,
                                            {$tmtStrExpr} AS strength,
                                            {$hosStrExpr} AS strength_hosxp,
                                            {$unitExpr} AS units
                                     FROM drugitems d {$tmtJoin}
                                     WHERE d.icode IN ({$icIn})");
            if ($q) {
                while ($r = mysqli_fetch_assoc($q)) {
                    $drugMap[(string)$r['icode']] = $r;
                }
            }
        }
    }

    $ptMap = [];
    if ($want_patient) {
        $hnIn = mmgml_sql_in_strings($hos, array_keys($hns));
        if ($hnIn !== '') {
            $ptExpr = mmgml_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))");
            $q = mysqli_query($hos, "SELECT pt.hn, {$ptExpr} AS ptname FROM patient pt WHERE pt.hn IN ({$hnIn})");
            if ($q) {
                while ($r = mysqli_fetch_assoc($q)) {
                    $ptMap[(string)$r['hn']] = trim((string)($r['ptname'] ?? ''));
                }
            }
        }
    }

    $duMap = [];
    $spMap = [];
    $dispMap = [];
    if ($want_method) {
        $duIn = mmgml_sql_in_strings($hos, array_keys($dusage));
        if ($duIn !== '') {
            $duExpr = mmgml_sql_utf8("CONCAT(IFNULL(name1,''),' ',IFNULL(name2,''),' ',IFNULL(name3,''))");
            $q = mysqli_query($hos, "SELECT drugusage, {$duExpr} AS method FROM drugusage WHERE drugusage IN ({$duIn})");
            if ($q) {
                while ($r = mysqli_fetch_assoc($q)) {
                    $duMap[(string)$r['drugusage']] = trim((string)($r['method'] ?? ''));
                }
            }
        }
        $spIn = mmgml_sql_in_strings($hos, array_keys($spuse));
        if ($spIn !== '') {
            $spExpr = mmgml_sql_utf8("CONCAT(IFNULL(name1,''),' ',IFNULL(name2,''),' ',IFNULL(name3,''))");
            $q = mysqli_query($hos, "SELECT sp_use, {$spExpr} AS method FROM sp_use WHERE sp_use IN ({$spIn})");
            if ($q) {
                while ($r = mysqli_fetch_assoc($q)) {
                    $spMap[(string)$r['sp_use']] = trim((string)($r['method'] ?? ''));
                }
            }
        }
        foreach (array_chunk(array_keys($guidsNeedDisp), 150) as $gchunk) {
            $gIn = mmgml_sql_in_strings($hos, $gchunk);
            if ($gIn === '') {
                continue;
            }
            $odExpr = mmgml_sql_utf8("CONCAT(IFNULL(usage_line1,''),' ',IFNULL(usage_line2,''),' ',IFNULL(usage_line3,''))");
            $q = mysqli_query($hos, "SELECT hos_guid, {$odExpr} AS method FROM opi_dispense WHERE hos_guid IN ({$gIn})");
            if (!$q) {
                continue;
            }
            while ($r = mysqli_fetch_assoc($q)) {
                $dispMap[(string)$r['hos_guid']] = trim((string)($r['method'] ?? ''));
            }
        }
    }

    $wardMap = [];
    $bedMap = [];
    if ($want_ward) {
        $anIn = mmgml_sql_in_strings($hos, array_keys($ans));
        if ($anIn !== '') {
            $wardExpr = mmgml_sql_utf8("IFNULL(w1.name,'')");
            $sqlW = "SELECT ia.an, IFNULL(ia.bedno,'') AS bedno, {$wardExpr} AS ward_name
                     FROM iptadm ia
                     LEFT JOIN ward_admit_snapshot wa ON wa.an = ia.an
                     LEFT JOIN ward w1 ON w1.ward = wa.ward
                     WHERE ia.an IN ({$anIn})";
            $q = mysqli_query($hos, $sqlW);
            if ($q) {
                while ($r = mysqli_fetch_assoc($q)) {
                    $an = (string)$r['an'];
                    $wardMap[$an] = trim((string)($r['ward_name'] ?? ''));
                    $bedMap[$an] = trim((string)($r['bedno'] ?? ''));
                }
            }
        }
    }

    foreach ($rows as &$r) {
        $hn = (string)($r['hn'] ?? '');
        $an = trim((string)($r['an'] ?? ''));
        $ic = (string)($r['icode'] ?? '');
        if ($want_method) {
            $du = trim((string)($r['drugusage'] ?? ''));
            $sp = trim((string)($r['sp_use'] ?? ''));
            $g = (string)($r['hos_guid'] ?? '');
            if ($sp !== '') {
                $method = $spMap[$sp] ?? '';
            } else {
                $method = $dispMap[$g] ?? '';
                if ($method === '') {
                    $method = $duMap[$du] ?? '';
                }
            }
            $r['method'] = $method;
        }
        if ($want_patient) {
            $r['ptname'] = $ptMap[$hn] ?? ($r['ptname'] ?? '');
        }
        if ($want_ward) {
            $r['ward_name'] = $an !== '' ? ($wardMap[$an] ?? '') : '';
            $r['bedno'] = $an !== '' ? ($bedMap[$an] ?? '') : '';
        }
        if (!isset($r['type_patient']) || $r['type_patient'] === '') {
            $r['type_patient'] = (trim((string)($r['vn'] ?? '')) === '') ? 'IPD' : 'OPD';
        }
        if ($want_drug) {
            $drug = $drugMap[$ic] ?? [];
            $r['drug_name'] = trim((string)($drug['name'] ?? ''));
            $r['strength'] = trim((string)($drug['strength'] ?? ''));
            $r['strength_hosxp'] = trim((string)($drug['strength_hosxp'] ?? $drug['strength'] ?? ''));
            $r['units'] = trim((string)($drug['units'] ?? ''));
        }
    }
    unset($r);
    return $rows;
}

function mmgml_load_active_rules($con, array $rule_ids = []) {
    mmgml_ensure_table($con);
    mmgml_get_ml_extract_opts($con);
    $rules = [];
    $q = mysqli_query($con, "SELECT * FROM monitor_mg_ml_settings WHERE active = 1 ORDER BY drug_name ASC");
    if (!$q) {
        return $rules;
    }
    $filter = [];
    foreach ($rule_ids as $rid) {
        $rid = (int)$rid;
        if ($rid > 0) {
            $filter[$rid] = true;
        }
    }
    while ($row = mysqli_fetch_assoc($q)) {
        if (!empty($filter) && !isset($filter[(int)$row['id']])) {
            continue;
        }
        $icode = trim($row['icode'] ?? '');
        $mg_per_ml = (float)($row['mg_per_ml'] ?? 0);
        if ($icode === '' || $mg_per_ml <= 0) {
            continue;
        }
        $rules[] = $row;
    }
    return $rules;
}

function mmgml_rules_need_weight(array $rules) {
    foreach ($rules as $r) {
        if (!empty($r['use_weight'])) {
            return true;
        }
        // จำนวนจ่ายที่อิง mg/kg ก็ต้องใช้น้ำหนัก
        if (!empty($r['check_qty'])) {
            $has_kg = (float)($r['dose_mg_per_kg'] ?? 0) > 0 || (float)($r['dose_mg_per_kg_hr'] ?? 0) > 0;
            if ($has_kg) {
                return true;
            }
        }
    }
    return false;
}

function mmgml_rule_is_valid(array $data) {
    $mg_per_ml = (float)($data['mg_per_ml'] ?? 0);
    if ($mg_per_ml <= 0) {
        return ['ok' => false, 'error' => 'กรุณาระบุความเข้มข้น mg/mL มากกว่า 0'];
    }
    $tol_pct = (float)($data['tolerance_pct'] ?? 5);
    $tol_ml = (float)($data['tolerance_ml'] ?? 0.02);
    if ($tol_pct < 0 || $tol_pct > 50) {
        return ['ok' => false, 'error' => 'อนุโลม % ต้องอยู่ระหว่าง 0–50'];
    }
    if ($tol_ml < 0) {
        return ['ok' => false, 'error' => 'อนุโลม mL ต้องไม่ติดลบ'];
    }

    $use_weight = !empty($data['use_weight']);
    $dose_kg = (float)($data['dose_mg_per_kg'] ?? 0);
    $dose_kg_hr = (float)($data['dose_mg_per_kg_hr'] ?? 0);
    if ($use_weight && $dose_kg <= 0 && $dose_kg_hr <= 0) {
        return ['ok' => false, 'error' => 'เปิดใช้น้ำหนักแล้ว ต้องระบุ mg/kg หรือ mg/kg/hr อย่างน้อยหนึ่งค่า'];
    }
    $lookback = (int)($data['weight_lookback_days'] ?? 365);
    if ($use_weight && ($lookback < 1 || $lookback > 3650)) {
        return ['ok' => false, 'error' => 'ช่วงย้อนหลังน้ำหนักต้องอยู่ระหว่าง 1–3650 วัน'];
    }

    $check_qty = !empty($data['check_qty']);
    $mg_per_amp = (float)($data['mg_per_amp'] ?? 0);
    if ($check_qty && $mg_per_amp <= 0) {
        return ['ok' => false, 'error' => 'เปิดตรวจจำนวนจ่ายแล้ว ต้องระบุ mg/Amp มากกว่า 0'];
    }

    $check_rate = !empty($data['check_rate']);
    $def_hours = (float)($data['default_hours'] ?? 0);
    $def_vol = (float)($data['default_volume_ml'] ?? 0);
    if ($check_rate && ($def_hours <= 0 || $def_vol <= 0)) {
        return ['ok' => false, 'error' => 'เปิดตรวจ Rate แล้ว ต้องระบุชั่วโมงและปริมาตรสารน้ำ default (ใช้เมื่อวิธีใช้ไม่มี)'];
    }

    return ['ok' => true, 'error' => ''];
}

/**
 * แปลง strength เช่น "250 mg/ml", "62.5 mg/5 mL", "600 mcg/1 mL" → mg/mL
 */
function mmgml_parse_concentration_from_strength($strength) {
    $s = trim((string)$strength);
    if ($s === '') {
        return null;
    }
    $s_norm = preg_replace('/\s+/u', ' ', $s);

    $patterns = [
        [
            'regex' => '/(\d+(?:\.\d+)?)\s*mg\s*\/\s*(\d+(?:\.\d+)?)?\s*ml\b/iu',
            'unit' => 'mg',
        ],
        [
            'regex' => '/(\d+(?:\.\d+)?)\s*(?:mcg|µg|μg|ug)\s*\/\s*(\d+(?:\.\d+)?)?\s*ml\b/iu',
            'unit' => 'mcg',
        ],
        [
            'regex' => '/(\d+(?:\.\d+)?)\s*(?:g|gm|gram|กร\.?|กรัม)\s*\/\s*(\d+(?:\.\d+)?)?\s*ml\b/iu',
            'unit' => 'g',
        ],
    ];

    foreach ($patterns as $p) {
        if (!preg_match($p['regex'], $s_norm, $m)) {
            continue;
        }
        $num = (float)$m[1];
        $vol = isset($m[2]) && $m[2] !== '' ? (float)$m[2] : 1.0;
        if ($vol <= 0) {
            continue;
        }
        if ($p['unit'] === 'mcg') {
            $num = $num / 1000;
        } elseif ($p['unit'] === 'g') {
            $num = $num * 1000;
        }
        $mg_per_ml = $num / $vol;
        if ($mg_per_ml <= 0) {
            continue;
        }
        return [
            'mg_per_ml' => $mg_per_ml,
            'strength_text' => $s,
            'parse_note' => rtrim(rtrim(number_format($num, 4, '.', ''), '0'), '.') . ' mg / '
                . rtrim(rtrim(number_format($vol, 4, '.', ''), '0'), '.') . ' mL',
        ];
    }

    return null;
}

function mmgml_default_ml_paren_units() {
    return ['mcg', 'µg', 'ug', 'mg', 'gm', 'mEq', 'IU', 'unit', 'g'];
}

function mmgml_parse_ml_paren_units($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return mmgml_default_ml_paren_units();
    }
    $parts = preg_split('/[,;|\/\n]+/u', $text);
    $out = [];
    $seen = [];
    foreach ($parts as $p) {
        $p = trim((string)$p);
        $p = preg_replace('/[^\p{L}\p{N}µμ.]/u', '', $p);
        if ($p === '' || strlen($p) > 12) {
            continue;
        }
        $key = function_exists('mb_strtolower') ? mb_strtolower($p, 'UTF-8') : strtolower($p);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = $p;
    }
    return $out ?: mmgml_default_ml_paren_units();
}

function mmgml_format_ml_paren_units(array $units) {
    $units = array_values(array_filter(array_map('trim', $units), function ($u) {
        return $u !== '';
    }));
    return $units ? implode(', ', $units) : implode(', ', mmgml_default_ml_paren_units());
}

function mmgml_ml_paren_unit_regex(array $units) {
    $units = array_values(array_filter(array_map('trim', $units), function ($u) {
        return $u !== '';
    }));
    if (empty($units)) {
        $units = mmgml_default_ml_paren_units();
    }
    usort($units, function ($a, $b) {
        return strlen($b) - strlen($a);
    });
    $parts = [];
    foreach ($units as $u) {
        $parts[] = preg_quote($u, '/');
    }
    return implode('|', $parts);
}

function mmgml_default_ml_extract_opts() {
    return [
        'exempt_strength_paren' => true,
        'units' => mmgml_default_ml_paren_units(),
        'units_text' => mmgml_format_ml_paren_units(mmgml_default_ml_paren_units()),
    ];
}

function mmgml_sys_config_get($con, $name, $default = null) {
    if (!$con || $name === '') {
        return $default;
    }
    $name_esc = mysqli_real_escape_string($con, $name);
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='$name_esc' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q)) && $r['config_value'] !== null) {
        return $r['config_value'];
    }
    return $default;
}

function mmgml_sys_config_set($con, $name, $value) {
    if (!$con || $name === '') {
        return false;
    }
    $name_esc = mysqli_real_escape_string($con, $name);
    $val_esc = mysqli_real_escape_string($con, (string)$value);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$name_esc' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$val_esc' WHERE config_name='$name_esc'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$name_esc', '$val_esc')");
}

/**
 * ตั้งค่ายกเว้นปริมาตรในวงเล็บที่เป็นความแรงยา เช่น IV (4 mg:250 ml)
 * นับ mL ที่ระบุเฉพาะรูปแบบ 50 MG (1 ml) หรือ (0.28 ml)
 */
function mmgml_get_ml_extract_opts($con = null) {
    static $cached = null;
    if ($cached !== null && $con === null) {
        return $cached;
    }
    $opts = mmgml_default_ml_extract_opts();
    if ($con) {
        $ex = mmgml_sys_config_get($con, 'mmgml_exempt_strength_paren', null);
        if ($ex !== null && $ex !== '') {
            $opts['exempt_strength_paren'] = !in_array(strtolower(trim((string)$ex)), ['0', 'off', 'false', 'no'], true);
        }
        $units_raw = mmgml_sys_config_get($con, 'mmgml_ml_paren_units', null);
        if ($units_raw !== null && trim((string)$units_raw) !== '') {
            $opts['units'] = mmgml_parse_ml_paren_units($units_raw);
            $opts['units_text'] = mmgml_format_ml_paren_units($opts['units']);
        }
        $cached = $opts;
    } elseif ($cached === null) {
        $cached = $opts;
    }
    return $con ? $opts : $cached;
}

function mmgml_save_ml_extract_opts($con, array $in) {
    $exempt = !empty($in['exempt_strength_paren']);
    $units = mmgml_parse_ml_paren_units($in['units_text'] ?? ($in['units'] ?? ''));
    mmgml_sys_config_set($con, 'mmgml_exempt_strength_paren', $exempt ? '1' : '0');
    mmgml_sys_config_set($con, 'mmgml_ml_paren_units', mmgml_format_ml_paren_units($units));
    return mmgml_get_ml_extract_opts($con);
}

function mmgml_strength_paren_ranges($text, $unit_re) {
    $ranges = [];
    if ($text === '' || $unit_re === '') {
        return $ranges;
    }
    if (!preg_match_all('/\(([^()]*)\)/u', $text, $all, PREG_SET_ORDER | PREG_OFFSET_CAPTURE)) {
        return $ranges;
    }
    foreach ($all as $m) {
        $inner = $m[1][0];
        if (!preg_match('/(?:' . $unit_re . ')\b/iu', $inner)) {
            continue;
        }
        if (!preg_match('/\d+(?:\.\d+)?\s*ml\b/iu', $inner)) {
            continue;
        }
        $start = (int)$m[0][1];
        $ranges[] = [$start, $start + strlen($m[0][0])];
    }
    return $ranges;
}

function mmgml_offset_in_ranges($pos, array $ranges) {
    foreach ($ranges as $r) {
        if ($pos >= $r[0] && $pos < $r[1]) {
            return true;
        }
    }
    return false;
}

function mmgml_ml_after_is_per_hr($text, $pos, $match_len) {
    $after = substr($text, $pos + $match_len);
    return (bool)preg_match('/^\s*\/\s*hr\b/i', $after);
}

/**
 * ดึง mL จากวิธีใช้ — เน้นรูปแบบ (0.28 ml) หรือ 70 MG (0.28 ml); ข้าม ml/hr
 * ถ้าเปิดยกเว้นความแรงยา: ไม่นับปริมาตรในวงเล็บแบบ (4 mg:250 ml)
 */
function mmgml_extract_ml_from_usage($text, $opts = null) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (!is_array($opts)) {
        $opts = mmgml_get_ml_extract_opts();
    }
    $exempt = !empty($opts['exempt_strength_paren']);
    $unit_re = mmgml_ml_paren_unit_regex($opts['units'] ?? []);
    $skip = ($exempt && $unit_re !== '') ? mmgml_strength_paren_ranges($text, $unit_re) : [];

    // รูปแบบคำนวณ mL: 50 MG (1 ml) / 1 GM (4 ml) / 100 mcg (0.2 ml)
    if ($exempt && $unit_re !== '') {
        $re = '/(?:\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:\.\d+)?)\s*(?:' . $unit_re . ')\b\s*\(\s*(\d+(?:\.\d+)?)\s*ml\s*\)/iu';
        if (preg_match_all($re, $text, $pairs, PREG_SET_ORDER | PREG_OFFSET_CAPTURE)) {
            foreach ($pairs as $m) {
                $pos = (int)$m[0][1];
                if (mmgml_ml_after_is_per_hr($text, $pos, strlen($m[0][0]))) {
                    continue;
                }
                $ml = (float)$m[1][0];
                if ($ml > 0) {
                    return $ml;
                }
            }
        }
    }

    if (preg_match_all('/\((\d+(?:\.\d+)?)\s*ml\)/iu', $text, $paren, PREG_SET_ORDER | PREG_OFFSET_CAPTURE)) {
        foreach ($paren as $m) {
            $pos = (int)$m[0][1];
            if (mmgml_offset_in_ranges($pos, $skip)) {
                continue;
            }
            if (mmgml_ml_after_is_per_hr($text, $pos, strlen($m[0][0]))) {
                continue;
            }
            $ml = (float)$m[1][0];
            if ($ml > 0) {
                return $ml;
            }
        }
    }

    if ($exempt) {
        return null;
    }

    if (preg_match('/(\d+(?:\.\d+)?)\s*mg\b[^()]*\((\d+(?:\.\d+)?)\s*ml\)/iu', $text, $pair)) {
        return (float)$pair[2];
    }

    if (preg_match_all('/(\d+(?:\.\d+)?)\s*ml\b/iu', $text, $all, PREG_SET_ORDER | PREG_OFFSET_CAPTURE)) {
        foreach ($all as $m) {
            $pos = (int)$m[0][1];
            if (mmgml_ml_after_is_per_hr($text, $pos, strlen($m[0][0]))) {
                continue;
            }
            return (float)$m[1][0];
        }
    }

    return null;
}

/**
 * ความเข้มข้นหลังผสมจากวิธีใช้
 * - IV (1:1) / (1 : 1) ไม่มีหน่วย = 1 mg : 1 ml (ไม่ใช้สัดส่วนใหญ่เช่น 1:1000)
 * - (1 mg : 1 ml) / (4 mg:250 ml)
 * @return array{mg_per_ml:float,label:string}|null
 */
function mmgml_extract_mix_mg_per_ml($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }

    if (preg_match('/\(\s*(\d+(?:\.\d+)?)\s*mg\s*[:\/]\s*(\d+(?:\.\d+)?)\s*ml\s*\)/iu', $text, $m)) {
        $mg = (float)$m[1];
        $ml = (float)$m[2];
        if ($mg > 0 && $ml > 0) {
            return [
                'mg_per_ml' => $mg / $ml,
                'label' => mmgml_format_mg($mg) . ' mg:' . mmgml_format_ml($ml) . ' ml',
            ];
        }
    }

    if (preg_match('/\(\s*(\d+(?:\.\d+)?)\s*:\s*(\d+(?:\.\d+)?)\s*\)/', $text, $m)) {
        $a = (float)$m[1];
        $b = (float)$m[2];
        if ($a > 0 && $b > 0 && $a <= 20 && $b <= 20) {
            return [
                'mg_per_ml' => $a / $b,
                'label' => $m[1] . ':' . $m[2],
            ];
        }
    }

    return null;
}

function mmgml_resolve_mg_per_ml_for_method($method, $rule_mg_per_ml) {
    $rule_mg_per_ml = (float)$rule_mg_per_ml;
    $mix = mmgml_extract_mix_mg_per_ml($method);
    if ($mix && (float)$mix['mg_per_ml'] > 0) {
        return [
            'mg_per_ml' => (float)$mix['mg_per_ml'],
            'from_mix' => true,
            'mix_label' => (string)$mix['label'],
        ];
    }
    return [
        'mg_per_ml' => $rule_mg_per_ml,
        'from_mix' => false,
        'mix_label' => '',
    ];
}

function mmgml_conc_phrase($mg_per_ml, $mix_label = '') {
    $s = mmgml_format_mg($mg_per_ml) . ' mg/mL';
    if (trim((string)$mix_label) !== '') {
        $s .= ' จากผสม ' . trim((string)$mix_label);
    }
    return $s;
}

/** ดึง rate ml/hr จากวิธีใช้ เช่น 43.50 ml/hr */
function mmgml_extract_rate_ml_hr($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*ml\s*\/\s*hr\b/iu', $text, $m)) {
        return (float)$m[1];
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*mL\s*per\s*hr(?:our)?\b/iu', $text, $m2)) {
        return (float)$m2[1];
    }
    return null;
}

/** ดึงชั่วโมงจากวิธีใช้ เช่น drip in 23 ชั่วโมง / 23 hr / 23 ชม. */
function mmgml_extract_hours($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    $patterns = [
        '/(?:drip\s*in|ใน|ตลอด)\s*(\d+(?:\.\d+)?)\s*(?:ชั่วโมง|ชม\.?|hr|hour|hours)\b/iu',
        '/(\d+(?:\.\d+)?)\s*(?:ชั่วโมง|ชม\.?)\b/iu',
        '/(\d+(?:\.\d+)?)\s*(?:hr|hours?)\b/iu',
    ];
    foreach ($patterns as $re) {
        if (preg_match($re, $text, $m)) {
            $h = (float)$m[1];
            if ($h > 0 && $h <= 168) {
                return $h;
            }
        }
    }
    return null;
}

/**
 * ดึงปริมาตรสารน้ำรวมจากวิธีใช้ถ้ามี
 * เช่น Methylpred 139 ml + NSS 861 ml → 1000
 * ไม่ใช้ NSS เดี่ยวเป็นปริมาตรรวม (ให้ใช้ default ในกฎ)
 */
function mmgml_extract_volume_ml($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(?:รวม|total|ปริมาตร|volume)\s*(\d+(?:\.\d+)?)\s*ml\b/iu', $text, $m)) {
        return (float)$m[1];
    }
    // ยา (N ml) + NSS M ml → รวม
    if (preg_match('/\((\d+(?:\.\d+)?)\s*ml\)[^+]*\+\s*(?:NSS|NS|N\/?S|0\.9%?\s*NaCl|normal\s*saline)[^\d]*(\d+(?:\.\d+)?)\s*ml\b/iu', $text, $sum)) {
        $total = (float)$sum[1] + (float)$sum[2];
        if ($total >= 50) {
            return $total;
        }
    }
    if (preg_match('/(?:in|ใน)\s*(\d+(?:\.\d+)?)\s*ml\b/iu', $text, $m2)) {
        $v = (float)$m2[1];
        if ($v >= 50) {
            return $v;
        }
    }
    return null;
}

/** ดึง mg/hr จากวิธีใช้ เช่น (378 mg/hr) หรือ (378 mg/hr.) */
function mmgml_extract_mg_hr($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*mg\s*\/\s*hr\.?\b/iu', $text, $m)) {
        return (float)$m[1];
    }
    return null;
}

function mmgml_format_ml($val) {
    if ($val === null) {
        return '—';
    }
    $v = (float)$val;
    if ($v <= 0) {
        return '—';
    }
    return rtrim(rtrim(number_format($v, 4, '.', ''), '0'), '.');
}

function mmgml_format_mg($val) {
    if ($val === null) {
        return '—';
    }
    $v = (float)$val;
    if ($v <= 0) {
        return '—';
    }
    return rtrim(rtrim(number_format($v, 4, '.', ''), '0'), '.');
}

function mmgml_format_num($val, $decimals = 4) {
    if ($val === null) {
        return '—';
    }
    $v = (float)$val;
    if ($decimals <= 0) {
        return (string)(int)round($v);
    }
    $s = number_format($v, $decimals, '.', '');
    if (strpos($s, '.') !== false) {
        $s = rtrim(rtrim($s, '0'), '.');
    }
    return $s === '' ? '0' : $s;
}

function mmgml_compute_tolerance_ml($expected_ml, array $rule) {
    $expected_ml = (float)$expected_ml;
    $tol_pct = max(0, (float)($rule['tolerance_pct'] ?? 5));
    $tol_ml = max(0, (float)($rule['tolerance_ml'] ?? 0.02));
    $from_pct = $expected_ml * ($tol_pct / 100);
    return max($tol_ml, $from_pct);
}

function mmgml_within_pct($actual, $expected, $tol_pct) {
    $expected = (float)$expected;
    $actual = (float)$actual;
    if ($expected == 0.0) {
        return abs($actual) < 1e-9;
    }
    $tol = abs($expected) * (max(0, (float)$tol_pct) / 100);
    // ขั้นต่ำเล็กน้อยสำหรับค่าใหญ่
    if ($tol < 1e-6) {
        $tol = 1e-6;
    }
    return abs($actual - $expected) <= $tol;
}

/** อนุโลม % — ถ้าใช้น้ำหนักเก่า (stale) คูณ 2 ตามที่ตั้งไว้ เช่น 5% → 10% */
function mmgml_effective_tol_pct(array $rule, array $ctx = [], $for_weight_based = false) {
    $tol = max(0, (float)($rule['tolerance_pct'] ?? 5));
    if ($for_weight_based && !empty($ctx['weight_stale'])) {
        return $tol * 2;
    }
    return $tol;
}

/**
 * คำนวณ expected dose ตามน้ำหนัก
 * @return array{bolus:?float,infusion:?float,total:?float,mg_hr:?float}
 */
function mmgml_expected_doses(array $rule, $weight_kg, $hours) {
    $weight_kg = (float)$weight_kg;
    $hours = (float)$hours;
    $per_kg = (float)($rule['dose_mg_per_kg'] ?? 0);
    $per_kg_hr = (float)($rule['dose_mg_per_kg_hr'] ?? 0);

    $bolus = null;
    $infusion = null;
    $mg_hr = null;

    if ($weight_kg > 0 && $per_kg > 0) {
        $bolus = $per_kg * $weight_kg;
    }
    if ($weight_kg > 0 && $per_kg_hr > 0) {
        $mg_hr = $per_kg_hr * $weight_kg;
        if ($hours > 0) {
            $infusion = $mg_hr * $hours;
        }
    }

    $total = null;
    if ($bolus !== null || $infusion !== null) {
        $total = ($bolus ?? 0) + ($infusion ?? 0);
    }

    return [
        'bolus' => $bolus,
        'infusion' => $infusion,
        'total' => $total,
        'mg_hr' => $mg_hr,
    ];
}

function mmgml_expected_amps($expected_mg, $mg_per_amp) {
    $mg_per_amp = (float)$mg_per_amp;
    $expected_mg = (float)$expected_mg;
    if ($mg_per_amp <= 0 || $expected_mg <= 0) {
        return null;
    }
    return $expected_mg / $mg_per_amp;
}

function mmgml_expected_rate($volume_ml, $hours) {
    $volume_ml = (float)$volume_ml;
    $hours = (float)$hours;
    if ($volume_ml <= 0 || $hours <= 0) {
        return null;
    }
    return $volume_ml / $hours;
}

/** ทายว่าวิธีใช้เป็น bolus / infusion / unknown */
function mmgml_method_phase($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return 'unknown';
    }
    // drip in 23 hr / 24 ชั่วโมง → infusion ชัดเจน (สำคัญกว่าคำว่า bolus ถ้ามีทั้งคู่)
    if (preg_match('/drip\s*in\s*\d+(?:\.\d+)?\s*(?:ชั่วโมง|ชม\.?|hr|hours?)\b/iu', $m)) {
        return 'infusion';
    }
    if (preg_match('/bolus|โบลัส|ฉีดรวด|15\s*นาที|15\s*min/iu', $m)) {
        return 'bolus';
    }
    if (mmgml_extract_rate_ml_hr($method) !== null || mmgml_extract_mg_hr($method) !== null) {
        return 'infusion';
    }
    if (preg_match('/infusion|ดริป|drip|ต่อเนื่อง/iu', $m)) {
        return 'infusion';
    }
    return 'unknown';
}

/**
 * ตรวจว่าวิธีใช้มีข้อความยกเว้นที่กำหนดไว้หรือไม่
 * รองรับเช่น "1 GM", "500 MG", "1 G" (ช่องว่างยืดหยุ่น ไม่สนตัวพิมพ์)
 */
function mmgml_method_matches_exempt_patterns($method, $patterns_str) {
    $method = trim((string)$method);
    $patterns_str = trim((string)$patterns_str);
    if ($method === '' || $patterns_str === '') {
        return false;
    }
    $parts = preg_split('/[,;|\n]+/u', $patterns_str);
    if (!$parts) {
        return false;
    }
    foreach ($parts as $p) {
        $p = trim($p);
        if ($p === '') {
            continue;
        }
        // รูปแบบตัวเลข + หน่วย mg/gm/g
        if (preg_match('/^(\d+(?:[.,]\d+)?)\s*(mg|gm|g)$/iu', $p, $m)) {
            $num = str_replace(',', '', $m[1]);
            $unit = strtolower($m[2]);
            if ($unit === 'g') {
                // "1 G" ไม่ให้ไป match "1 GM"
                $re = '/(?<![\d.,])' . preg_quote($num, '/') . '\s*g\b(?!m)/iu';
            } elseif ($unit === 'gm') {
                $re = '/(?<![\d.,])' . preg_quote($num, '/') . '\s*gm\b/iu';
            } else {
                $re = '/(?<![\d.,])' . preg_quote($num, '/') . '\s*mg\b/iu';
            }
            if (preg_match($re, $method)) {
                return true;
            }
            continue;
        }
        // ข้อความทั่วไป: เทียบแบบมีช่องว่างยืดหยุ่น
        $escaped = preg_quote($p, '/');
        $escaped = preg_replace('/\\\s+/u', '\\s*', $escaped);
        $escaped = str_replace(' ', '\\s*', $escaped);
        if (@preg_match('/' . $escaped . '/iu', $method)) {
            return true;
        }
    }
    return false;
}

/**
 * วิธีใช้แบบ protocol ตามน้ำหนัก / infusion ยาว — ไม่ใช่ขนาดคงที่
 * เช่น drip in 23 ชั่วโมง มี ml/hr และ mg/hr, หรือ bolus = 30 mg/kg
 */
function mmgml_is_weight_based_protocol_method($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return false;
    }
    if (preg_match('/(?:mg|mcg|µg|μg|ug)\s*\/\s*kg\b/iu', $m)) {
        return true;
    }
    $hours = mmgml_extract_hours($m);
    $has_ml_hr = mmgml_extract_rate_ml_hr($m) !== null;
    $has_mg_hr = mmgml_extract_mg_hr($m) !== null;
    if ($hours !== null && $hours >= 6) {
        return true;
    }
    if ($has_ml_hr && $has_mg_hr) {
        return true;
    }
    if (($has_ml_hr || $has_mg_hr)
        && !preg_match('/วันละ|ครั้ง|DAY\s*\d/iu', $m)
        && !preg_match('/\d+(?:\.\d+)?\s*(?:gm|g)\b(?!\w)/iu', $m)
        && !preg_match('/นาที|mins?\b/iu', $m)
    ) {
        return true;
    }
    return false;
}

/**
 * วิธีใช้แบบขนาดคงที่ (ไม่ใช่ protocol ตามน้ำหนัก)
 * เช่น IV 1 GM + D5W drip in 1 hr วันละ 1 ครั้ง, IV 500 MG (8 ml) drip นาน 30 นาที
 * ไม่ใช่: drip in 23 hr มี ml/hr หรือ mg/hr, หรือ Bolus 30 mg/kg
 *
 * $max_mg_per_dose = เพดานขนาดคงที่ (ปกติ = mg/Amp เช่น 1000)
 */
function mmgml_is_fixed_dose_method($method, $max_mg_per_dose = 1000.0) {
    $m = trim((string)$method);
    if ($m === '') {
        return false;
    }
    if (mmgml_is_weight_based_protocol_method($m)) {
        return false;
    }
    $has_dose = (bool)preg_match('/\d{1,3}(?:,\d{3})*(?:\.\d+)?\s*mg\b/iu', $m)
        || (bool)preg_match('/\d+(?:\.\d+)?\s*gm\b/iu', $m)
        || (bool)preg_match('/\d+(?:\.\d+)?\s*g\b(?!\w)/iu', $m);
    if (!$has_dose) {
        return false;
    }
    $max_mg_per_dose = (float)$max_mg_per_dose;
    if ($max_mg_per_dose <= 0) {
        $max_mg_per_dose = 1000.0;
    }
    $dose_mg = mmgml_extract_dose_mg_for_ml($m);
    if ($dose_mg !== null && $dose_mg > ($max_mg_per_dose + 0.05)) {
        return false;
    }
    if (preg_match('/นาที|mins?\b|วันละ|ครั้ง|x\s*\d+\s*วัน|DAY\s*\d/iu', $m)) {
        return true;
    }
    $hours = mmgml_extract_hours($m);
    if ($hours !== null && $hours > 0 && $hours < 6) {
        return true;
    }
    if (preg_match('/\d+(?:\.\d+)?\s*(?:gm|g)\b(?!\w)/iu', $m)) {
        return true;
    }
    return false;
}

/**
 * ยกเว้นตรวจตามน้ำหนักเมื่อ:
 * 1) protocol ตามน้ำหนัก — ไม่ยกเว้น (30 mg/kg, drip 23 ชม.)
 * 2) วิธีใช้มีข้อความใน exempt_dose_patterns (เช่น 1 GM, 500 MG, x 3 วัน)
 * 3) เปิดสวิตช์ exempt_fixed_dose หรือเปิดใช้น้ำหนัก แล้ววิธีใช้เข้าข่ายขนาดคงที่
 */
function mmgml_should_exempt_fixed_dose(array $rule, $method) {
    if (mmgml_is_weight_based_protocol_method($method)) {
        return false;
    }
    $patterns = trim((string)($rule['exempt_dose_patterns'] ?? ''));
    if ($patterns !== '' && mmgml_method_matches_exempt_patterns($method, $patterns)) {
        return true;
    }
    $cap = (float)($rule['mg_per_amp'] ?? 0);
    if ($cap <= 0) {
        $cap = 1000.0;
    }
    if (!mmgml_is_fixed_dose_method($method, $cap)) {
        return false;
    }
    return !empty($rule['exempt_fixed_dose']) || !empty($rule['use_weight']);
}

function mmgml_usage_name_stopwords() {
    return [
        'inj', 'injection', 'inject', 'amp', 'ampoule', 'vial', 'tab', 'syrup',
        'hcl', 'sodium', 'sulfate', 'sulphate', 'bitartrate', 'phosphate',
        'hydrate', 'the', 'and', 'for', 'oral', 'eye', 'drop', 'drops',
        'cream', 'gel', 'free', 'flow', 'drip', 'infusion', 'intravenous',
        'intramuscular', 'subcutaneous', 'bolus', 'nacl', 'dextrose',
        'normal', 'saline', 'sterile', 'water', 'hour', 'hours', 'min',
        'mins', 'minute', 'minutes', 'once', 'daily', 'dose', 'plus',
        'with', 'from', 'this', 'that', 'then', 'over', 'into', 'onto',
        'unit', 'units', 'slow', 'push', 'stat', 'keep', 'open', 'vein',
        'then', 'max', 'titrate', 'doses', 'dose', 'until', 'after', 'before',
        'when', 'each', 'every', 'times', 'total', 'per', 'day', 'days',
        'hour', 'hours', 'minute', 'minutes', 'min', 'mins', 'hydrochloride',
        'bitartrate', 'tartrate', 'acetate', 'maleate', 'citrate',
    ];
}

function mmgml_drug_name_tokens($drug_name) {
    $s = strtolower(trim((string)$drug_name));
    if ($s === '') {
        return [];
    }
    $s = preg_replace('/\([^)]*\)/u', ' ', $s);
    $s = preg_replace('/[^a-z0-9\s\-]/u', ' ', $s);
    $stop = mmgml_usage_name_stopwords();
    $parts = preg_split('/[\s\-]+/u', $s);
    $tokens = [];
    foreach ($parts as $p) {
        $p = trim((string)$p);
        if (strlen($p) < 4 || ctype_digit($p) || in_array($p, $stop, true)) {
            continue;
        }
        $tokens[] = $p;
    }
    return array_values(array_unique($tokens));
}

function mmgml_drug_match_needles($drug_name) {
    $tokens = mmgml_drug_name_tokens($drug_name);
    if ($drug_name === '' || !function_exists('mmgml_injection_catalog')) {
        return $tokens;
    }
    $low = strtolower((string)$drug_name);
    foreach (mmgml_injection_catalog() as $item) {
        $aliases = array_merge([(string)($item['name'] ?? '')], $item['aliases'] ?? []);
        $hit = false;
        foreach ($aliases as $a) {
            $a = strtolower(trim((string)$a));
            if ($a === '') {
                continue;
            }
            if (strpos($low, $a) !== false || strpos($a, $low) !== false) {
                $hit = true;
                break;
            }
            foreach ($tokens as $t) {
                if (strlen($t) >= 5 && (strpos($a, $t) !== false || strpos($t, $a) !== false)) {
                    $hit = true;
                    break 2;
                }
            }
        }
        if (!$hit) {
            continue;
        }
        foreach ($aliases as $a) {
            foreach (mmgml_drug_name_tokens($a) as $t) {
                $tokens[] = $t;
            }
        }
    }
    return array_values(array_unique($tokens));
}

function mmgml_token_similar($a, $b) {
    $a = strtolower(trim((string)$a));
    $b = strtolower(trim((string)$b));
    if ($a === '' || $b === '') {
        return false;
    }
    if ($a === $b) {
        return true;
    }
    if (strpos($a, $b) !== false || strpos($b, $a) !== false) {
        return strlen($a) >= 5 && strlen($b) >= 5;
    }
    $la = strlen($a);
    $lb = strlen($b);
    if ($la < 6 || $lb < 6) {
        return false;
    }
    $max = min(2, max(1, (int)floor(min($la, $lb) * 0.2)));
    return levenshtein($a, $b) <= $max;
}

function mmgml_segment_name_words($seg) {
    $seg = (string)$seg;
    if ($seg === '' || !preg_match_all('/[A-Za-z][A-Za-z\-]{3,}/u', $seg, $m)) {
        return [];
    }
    $stop = mmgml_usage_name_stopwords();
    $out = [];
    foreach ($m[0] as $w) {
        $lw = strtolower($w);
        if (in_array($lw, $stop, true)) {
            continue;
        }
        $out[] = $lw;
    }
    return $out;
}

function mmgml_segment_matches_needles($segment, array $needles) {
    if (empty($needles)) {
        return false;
    }
    $low = strtolower((string)$segment);
    foreach ($needles as $n) {
        $n = strtolower(trim((string)$n));
        if (strlen($n) >= 4 && strpos($low, $n) !== false) {
            return true;
        }
    }
    foreach (mmgml_segment_name_words($segment) as $w) {
        foreach ($needles as $n) {
            if (mmgml_token_similar($w, $n)) {
                return true;
            }
        }
    }
    return false;
}

function mmgml_is_diluent_segment($seg) {
    $s = trim((string)$seg);
    if ($s === '') {
        return false;
    }
    if (preg_match(
        '/^\s*(?:0\.9\s*%?\s*)?(?:NSS|N\/?S|NS(?![A-Za-z])|D5W|D5S|DNS|SWI|SWFI|0\.9\s*%?\s*NaCl|normal\s*saline|น้ำเกลือ|5\s*%\s*dextrose)\b/iu',
        $s
    )) {
        return true;
    }
    // เช่น 0.9%NSS 50 ml … (ไม่ขึ้นต้นด้วย NSS แต่เป็นส่วน diluent ล้วน)
    if (preg_match('/(?:0\.9\s*%?\s*)?(?:NSS|N\/?S|NS(?![A-Za-z]))\s+\d+(?:\.\d+)?\s*ml\b/iu', $s)
        && !preg_match('/([A-Za-z][A-Za-z\-]{3,})(\d+(?:\.\d+)?|\s+\d+(?:\.\d+)?)\s*mg\b/iu', $s)
    ) {
        return true;
    }
    return false;
}

/** ชื่อยานำหน้าขนาดในช่วง — รองรับ Dexamethasone 10 mg และ Dexamethasone10 mg */
function mmgml_segment_drug_words_before_dose($seg) {
    $seg = (string)$seg;
    $stop = mmgml_usage_name_stopwords();
    $route = ['iv', 'im', 'sc', 'po', 'drip', 'push', 'bolus', 'infusion'];
    $words = [];
    if (preg_match_all(
        '/([A-Za-z][A-Za-z\-]{3,})\s+\d+(?:[.,]\d+)?\s*(?:mg|gm|g|mcg|ug|µg|ml)?\b/iu',
        $seg,
        $m1
    )) {
        foreach ($m1[1] as $w) {
            $words[] = strtolower($w);
        }
    }
    if (preg_match_all(
        '/([A-Za-z][A-Za-z\-]{3,})(\d+(?:\.\d+)?)\s*(?:mg|gm|g|mcg|ug|µg|ml)?\b/iu',
        $seg,
        $m2
    )) {
        foreach ($m2[1] as $w) {
            $words[] = strtolower($w);
        }
    }
    $out = [];
    foreach ($words as $lw) {
        if (in_array($lw, $stop, true) || in_array($lw, $route, true)) {
            continue;
        }
        $out[] = $lw;
    }
    return array_values(array_unique($out));
}

/** มีชื่อยาอื่นนำหน้าขนาด เช่น Dexamethasone 10 mg / Dexamethasone10 mg */
function mmgml_segment_has_unrelated_drug_name($seg, array $needles) {
    foreach (mmgml_segment_drug_words_before_dose($seg) as $lw) {
        $is_target = false;
        foreach ($needles as $n) {
            if (mmgml_token_similar($lw, $n)) {
                $is_target = true;
                break;
            }
        }
        if (!$is_target) {
            return true;
        }
    }
    return false;
}

/** ช่วงที่มีแค่ขนาด (เช่น IV 8 mg) ไม่มีชื่อยาอื่น — มักเป็นยาหลักใน admixture */
function mmgml_segment_is_dose_only($seg) {
    if (!preg_match('/\d+(?:\.\d+)?\s*(?:mg|gm|g|mcg|ug|µg)\b/iu', (string)$seg)) {
        return false;
    }
    return empty(mmgml_segment_drug_words_before_dose($seg));
}

function mmgml_split_admixture_segments($method) {
    $method = trim((string)$method);
    if ($method === '') {
        return [];
    }
    // ตัดสูตรผสมเฉพาะเครื่องหมาย + / และ — ไม่แยกที่คำว่า push 10 / drip 5
    $parts = preg_split('/\s*(?:\+|และ)\s*/u', $method);
    $parts = array_values(array_filter(array_map('trim', $parts), function ($p) {
        return $p !== '';
    }));
    return $parts ?: [$method];
}

/**
 * ตัดวิธีใช้ให้เหลือเฉพาะช่วงของยาที่กำลังตรวจ (ชื่อตรงหรือคล้าย)
 * เช่น "Dexamethaxone 10 mg (2.5 ml) + Ondansetron 8 mg (4ml) + NSS 50 ml"
 * เมื่อตรวจ Ondansetron → "Ondansetron 8 mg (4ml)"
 */
function mmgml_usage_for_drug($method, array $rule, array $ctx = []) {
    $method = trim(preg_replace('/\s+/u', ' ', (string)$method));
    if ($method === '') {
        return '';
    }
    $needles = [];
    foreach ([$rule['drug_name'] ?? '', $ctx['drug_name'] ?? ''] as $name) {
        foreach (mmgml_drug_match_needles($name) as $t) {
            $needles[] = $t;
        }
    }
    $needles = array_values(array_unique($needles));
    $parts = mmgml_split_admixture_segments($method);
    if (count($parts) <= 1 && empty($needles)) {
        return $method;
    }

    $matched = [];
    $dose_only = [];
    $fallback = [];
    foreach ($parts as $p) {
        if (mmgml_is_diluent_segment($p)) {
            continue;
        }
        if ($needles && mmgml_segment_matches_needles($p, $needles)) {
            $matched[] = $p;
            continue;
        }
        if ($needles && mmgml_segment_has_unrelated_drug_name($p, $needles)) {
            continue;
        }
        if ($needles && mmgml_segment_is_dose_only($p)) {
            $dose_only[] = $p;
            continue;
        }
        $fallback[] = $p;
    }
    if ($matched) {
        return implode(' + ', $matched);
    }
    if ($dose_only) {
        return implode(' + ', $dose_only);
    }
    if ($fallback) {
        return implode(' + ', $fallback);
    }
    return '';
}

/**
 * ดึง dose mg สำหรับตรวจ mg→mL
 * - infusion: ไม่ใช้ค่า mg/hr — หา total mg เช่น "Methylpred 8,694 mg" / "9072mg"
 * - bolus/อื่น: ใช้ mg ปกติ แต่ข้าม mg/hr
 */
function mmgml_extract_dose_mg_for_ml($method, $phase = null) {
    $text = trim((string)$method);
    if ($text === '') {
        return null;
    }
    if ($phase === null) {
        $phase = mmgml_method_phase($text);
    }

    // รูปแบบมี comma เช่น 8,694 mg หรือ 9,072mg
    if (preg_match_all('/(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)\s*mg(?!\s*\/\s*(?:hr|day|kg))\b/iu', $text, $all, PREG_OFFSET_CAPTURE)) {
        $paired = [];
        $plain = [];
        foreach ($all[1] as $i => $cap) {
            $raw = str_replace(',', '', $cap[0]);
            $val = (float)$raw;
            if ($val <= 0) {
                continue;
            }
            $pos = $cap[1];
            $after = substr($text, $pos + strlen($cap[0]));
            if (preg_match('/^\s*mg\s*\/\s*(?:hr|day|kg)\b/iu', $after) || preg_match('/^\s*\/\s*(?:hr|day|kg)\b/iu', $after)) {
                continue;
            }
            $before = substr($text, max(0, $pos - 12), 12);
            if (preg_match('/\(\s*$/u', $before) && preg_match('/^\s*mg\s*\/\s*(?:hr|day|kg)/iu', $after)) {
                continue;
            }
            if (preg_match('/^\s*mg\b\s*\(\s*\d+(?:\.\d+)?\s*ml\s*\)/iu', $after)) {
                $paired[] = $val;
            } else {
                $plain[] = $val;
            }
        }
        $candidates = $paired ?: $plain;
        if (!empty($candidates)) {
            if ($phase === 'infusion' && empty($paired)) {
                return max($candidates);
            }
            return $candidates[0];
        }
    }

    // mcg / µg → mg — ข้ามขนาดตามน้ำหนัก/เรท เช่น [1 mcg/kg/hr]
    if (preg_match_all('/(\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:\.\d+)?)\s*(?:mcg|µg|μg|ug|ไมโครกรัม)\b/iu', $text, $all, PREG_OFFSET_CAPTURE)) {
        $paired = [];
        $plain = [];
        foreach ($all[1] as $cap) {
            $raw = str_replace(',', '', $cap[0]);
            $val = (float)$raw;
            if ($val <= 0) {
                continue;
            }
            $pos = $cap[1];
            $after = substr($text, $pos + strlen($cap[0]));
            if (preg_match('/^\s*(?:mcg|µg|μg|ug|ไมโครกรัม)\s*\/\s*(?:kg|hr|min)\b/iu', $after)) {
                continue;
            }
            $mg_val = $val / 1000.0;
            if (preg_match('/^\s*(?:mcg|µg|μg|ug|ไมโครกรัม)\b\s*\(\s*\d+(?:\.\d+)?\s*ml\s*\)/iu', $after)) {
                $paired[] = $mg_val;
            } else {
                $plain[] = $mg_val;
            }
        }
        $candidates = $paired ?: $plain;
        if (!empty($candidates)) {
            if ($phase === 'infusion' && empty($paired)) {
                return max($candidates);
            }
            return $candidates[0];
        }
    }

    // GM / G → mg (เช่น 1 GM, 1 G)
    if (preg_match('/(\d+(?:\.\d+)?)\s*gm\b/iu', $text, $gm)) {
        $val = (float)$gm[1] * 1000.0;
        if ($val > 0) {
            return $val;
        }
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*g\b(?!\w)/iu', $text, $g)) {
        $val = (float)$g[1] * 1000.0;
        if ($val > 0) {
            return $val;
        }
    }

    // fallback — ไม่ใช้ mcg จากเรท เช่น 1 mcg/kg/hr
    $has_mcg_rate_only = (bool)preg_match('/(?:mcg|µg|μg|ug|ไมโครกรัม)\s*\/\s*(?:kg|hr|min)\b/iu', $text)
        && !preg_match('/(?:mcg|µg|μg|ug|ไมโครกรัม)\s*\(\s*\d+(?:\.\d+)?\s*ml\s*\)/iu', $text);
    if (!$has_mcg_rate_only && function_exists('hosxp_extract_mg_from_usage')) {
        $mg = hosxp_extract_mg_from_usage($text);
        if ($mg === null) {
            return null;
        }
        if ($phase === 'infusion') {
            $mg_hr = mmgml_extract_mg_hr($text);
            if ($mg_hr !== null && abs($mg - $mg_hr) < 0.01) {
                return null;
            }
        }
        return $mg;
    }
    return null;
}

/**
 * ดึง BW จาก HOSxP (opdscreen หรือตารางที่ตั้งใน sys_config)
 * $lookback_days = ย้อนหลังสูงสุดจาก max_date (ค่าจากกฎ)
 * คืน cache: [hn_key => [{vstdate,bw,height}, ...]] เรียง vstdate DESC
 */
function mmgml_prefetch_vitals($hos, $con, array $hn_list, $min_date = null, $max_date = null, $lookback_days = 365) {
    $cache = [];
    if (!$hos || empty($hn_list)) {
        return $cache;
    }

    $sys = [];
    $q_cfg = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ('h_tbl_vital','h_fld_bw','h_fld_height')");
    if ($q_cfg) {
        while ($r = mysqli_fetch_assoc($q_cfg)) {
            $sys[$r['config_name']] = $r['config_value'];
        }
    }
    $tbl = preg_replace('/[^a-zA-Z0-9_]/', '', $sys['h_tbl_vital'] ?? 'opdscreen') ?: 'opdscreen';
    $fld_bw = preg_replace('/[^a-zA-Z0-9_]/', '', $sys['h_fld_bw'] ?? 'bw') ?: 'bw';
    $fld_height = preg_replace('/[^a-zA-Z0-9_]/', '', $sys['h_fld_height'] ?? 'height') ?: 'height';

    $lookback_days = (int)$lookback_days;
    if ($lookback_days < 1) {
        $lookback_days = 365;
    }
    if ($lookback_days > 3650) {
        $lookback_days = 3650;
    }

    $max_esc = mysqli_real_escape_string($hos, $max_date ?: date('Y-m-d'));
    $per_hn_cap = 20;

    $padded = [];
    foreach ($hn_list as $hn) {
        $hn = trim((string)$hn);
        if ($hn === '') {
            continue;
        }
        $padded[] = $hn;
        if (ctype_digit($hn) && strlen($hn) < 9) {
            $padded[] = str_pad($hn, 9, '0', STR_PAD_LEFT);
        }
    }
    $padded = array_values(array_unique($padded));

    foreach (array_chunk($padded, 80) as $hn_chunk) {
        $hn_in = "'" . implode("','", array_map(function ($h) use ($hos) {
            return mysqli_real_escape_string($hos, $h);
        }, $hn_chunk)) . "'";
        $sql = "SELECT hn, vstdate, $fld_bw AS bw, $fld_height AS height
            FROM $tbl
            WHERE hn IN ($hn_in)
              AND $fld_bw > 0
              AND vstdate >= DATE_SUB('$max_esc', INTERVAL $lookback_days DAY)
              AND vstdate <= DATE_ADD('$max_esc', INTERVAL 1 DAY)
            ORDER BY hn, vstdate DESC";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $hn_key = ltrim($r['hn'], '0');
            if ($hn_key === '') {
                $hn_key = '0';
            }
            if (!isset($cache[$hn_key])) {
                $cache[$hn_key] = [];
            }
            if (count($cache[$hn_key]) >= $per_hn_cap) {
                continue;
            }
            $cache[$hn_key][] = [
                'vstdate' => $r['vstdate'],
                'bw' => (float)$r['bw'],
                'height' => (float)$r['height'],
            ];
        }
    }
    return $cache;
}

/**
 * น้ำหนักล่าสุดภายในช่วง lookback จากวันสั่งยา
 * stale=true เมื่อไม่มี BW ในวันสั่งยา (ใช้น้ำหนักเก่า) → ควรขยายอนุโลมเป็น 2 เท่า
 * @return array{bw:?float,vstdate:?string,stale:bool}
 */
function mmgml_get_weight_info_from_cache(array $cache, $hn, $order_date = '', $lookback_days = 365) {
    $hn_key = ltrim((string)$hn, '0');
    if ($hn_key === '') {
        $hn_key = '0';
    }
    $empty = ['bw' => null, 'vstdate' => null, 'stale' => true];
    $lookback_days = (int)$lookback_days;
    if ($lookback_days < 1) {
        $lookback_days = 365;
    }

    $order_date = trim((string)$order_date);
    $min_ok = null;
    if ($order_date !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $order_date)) {
        $min_ok = date('Y-m-d', strtotime($order_date . ' -' . $lookback_days . ' days'));
    }

    foreach ($cache[$hn_key] ?? [] as $row) {
        $bw = (float)($row['bw'] ?? 0);
        $vstdate = trim((string)($row['vstdate'] ?? ''));
        if ($bw <= 0 || $vstdate === '') {
            continue;
        }
        // ไม่ใช้ BW หลังวันสั่ง
        if ($order_date !== '' && $vstdate > $order_date) {
            continue;
        }
        // นอกช่วงย้อนหลัง
        if ($min_ok !== null && $vstdate < $min_ok) {
            continue;
        }
        $fresh = ($order_date !== '' && $vstdate === $order_date);
        return [
            'bw' => $bw,
            'vstdate' => $vstdate,
            'stale' => !$fresh,
        ];
    }
    return $empty;
}

/** @deprecated ใช้ mmgml_get_weight_info_from_cache */
function mmgml_get_weight_from_cache(array $cache, $hn, $order_date = '', $lookback_days = 365) {
    $info = mmgml_get_weight_info_from_cache($cache, $hn, $order_date, $lookback_days);
    return $info['bw'];
}

/** ค่า lookback สูงสุดจากกฎที่ต้องใช้น้ำหนัก */
function mmgml_max_weight_lookback_days(array $rules) {
    $max = 365;
    foreach ($rules as $r) {
        if (empty($r['use_weight']) && empty($r['check_qty'])) {
            continue;
        }
        $needs = !empty($r['use_weight']);
        if (!empty($r['check_qty']) && ((float)($r['dose_mg_per_kg'] ?? 0) > 0 || (float)($r['dose_mg_per_kg_hr'] ?? 0) > 0)) {
            $needs = true;
        }
        if (!$needs) {
            continue;
        }
        $d = (int)($r['weight_lookback_days'] ?? 365);
        if ($d < 1) {
            $d = 365;
        }
        if ($d > $max) {
            $max = $d;
        }
    }
    return min(3650, $max);
}

/** กฎมีทั้ง Bolus (mg/kg) และ Infusion (mg/kg/hr) — ต้องรวม Amp ในใบสั่งเดียวกัน */
function mmgml_rule_has_bolus_and_infusion(array $rule) {
    return (float)($rule['dose_mg_per_kg'] ?? 0) > 0
        && (float)($rule['dose_mg_per_kg_hr'] ?? 0) > 0;
}

/**
 * คีย์ใบสั่งยาเดียวกัน: HN + AN + วันสั่ง + เวลา (HH:MM) + icode + rule
 */
function mmgml_same_rx_group_key(array $row, $rule_id) {
    $hn = ltrim((string)($row['hn'] ?? ''), '0');
    if ($hn === '') {
        $hn = '0';
    }
    $rxtime = di_format_time(monitor_lab_normalize_hosxp_time($row['rxtime'] ?? ''));
    return implode('|', [
        $hn,
        trim((string)($row['an'] ?? '')),
        trim((string)($row['rxdate'] ?? '')),
        $rxtime,
        trim((string)($row['icode'] ?? '')),
        (int)$rule_id,
    ]);
}

/**
 * ตรวจจำนวนจ่ายแบบรวม Bolus + Infusion ในใบสั่งเดียวกัน
 * $parts = [ ['phase'=>'bolus'|'infusion'|'unknown', 'qty'=>float, 'hours'=>?float], ... ]
 * คืน null ถ้าผ่าน/ข้าม, หรือ array mismatch
 */
function mmgml_evaluate_combined_qty(array $rule, array $parts, $weight_kg, $weight_stale = false) {
    if (empty($rule['check_qty'])) {
        return null;
    }
    $mg_per_amp = (float)($rule['mg_per_amp'] ?? 0);
    $weight_kg = (float)$weight_kg;
    if ($mg_per_amp <= 0 || $weight_kg <= 0 || empty($parts)) {
        return null;
    }

    $qty_sum = 0.0;
    $has_bolus = false;
    $has_inf = false;
    $hours = null;
    foreach ($parts as $p) {
        $q = (float)($p['qty'] ?? 0);
        if ($q > 0) {
            $qty_sum += $q;
        }
        $phase = $p['phase'] ?? 'unknown';
        if ($phase === 'bolus') {
            $has_bolus = true;
        } elseif ($phase === 'infusion') {
            $has_inf = true;
        }
        if ($hours === null && isset($p['hours']) && (float)$p['hours'] > 0) {
            $hours = (float)$p['hours'];
        }
    }
    if ($qty_sum <= 0) {
        return null;
    }
    if ($hours === null || $hours <= 0) {
        $def = (float)($rule['default_hours'] ?? 0);
        $hours = $def > 0 ? $def : 0;
    }

    $doses = mmgml_expected_doses($rule, $weight_kg, $hours);
    if ($has_bolus && $has_inf) {
        $exp_mg = (float)($doses['total'] ?? 0);
        $label = 'รวม Bolus+Infusion';
    } elseif ($has_bolus) {
        $exp_mg = (float)($doses['bolus'] ?? 0);
        $label = 'Bolus';
    } elseif ($has_inf) {
        $exp_mg = (float)($doses['infusion'] ?? 0);
        $label = 'Infusion';
    } else {
        $exp_mg = (float)($doses['total'] ?? $doses['bolus'] ?? $doses['infusion'] ?? 0);
        $label = 'รวม';
    }
    if ($exp_mg <= 0) {
        return null;
    }

    $expected_amp = mmgml_expected_amps($exp_mg, $mg_per_amp);
    if ($expected_amp === null) {
        return null;
    }

    $tol = mmgml_effective_tol_pct($rule, ['weight_stale' => $weight_stale], true);
    if (mmgml_within_pct($qty_sum, $expected_amp, $tol)) {
        return null;
    }

    $diff = $qty_sum - $expected_amp;
    $dir = $diff < 0 ? 'ขาด' : 'เกิน';
    return [
        'type' => 'qty',
        'message' => 'จำนวนจ่าย ' . $label . ' ควรเป็น ' . mmgml_format_num($expected_amp, 3)
            . ' Amp (จาก ' . mmgml_format_mg($exp_mg) . ' mg ÷ ' . mmgml_format_mg($mg_per_amp) . ' mg/Amp)'
            . ' แต่จ่ายรวม ' . mmgml_format_num($qty_sum, 3) . ' Amp (' . $dir . ' '
            . mmgml_format_num(abs($diff), 3) . ' Amp)'
            . ($weight_stale ? ' (ใช้น้ำหนักล่าสุด อนุโลม ' . mmgml_format_num($tol, 1) . '%)' : ''),
        'expected_amp' => $expected_amp,
        'stated_qty' => $qty_sum,
        'combined' => ($has_bolus && $has_inf),
    ];
}

/**
 * หลังประเมินรายบรรทัดแล้ว — รวมตรวจ Amp เมื่อกฎมีทั้ง Bolus+Infusion ในใบสั่งเดียวกัน
 * $items[] = [
 *   'rule' => array, 'row' => array (hn/an/rxdate/rxtime/icode/qty/method),
 *   'eval' => evaluate_order|evaluate_method result (อาจ null สำหรับ method ที่ผ่าน),
 *   'weight_kg' => ?float, 'weight_stale' => bool,
 * ]
 * แก้ $items[$i]['eval'] in-place (สร้างโครงเมื่อเดิมเป็น null และต้องแจ้ง qty)
 */
function mmgml_apply_combined_qty_checks(array &$items) {
    $groups = [];
    foreach ($items as $i => $it) {
        $rule = $it['rule'] ?? [];
        if (!mmgml_rule_has_bolus_and_infusion($rule) || empty($rule['check_qty'])) {
            continue;
        }
        $row = $it['row'] ?? [];
        $method = (string)($row['method'] ?? '');
        if (mmgml_should_exempt_fixed_dose($rule, $method)) {
            continue;
        }
        $key = mmgml_same_rx_group_key($row, (int)($rule['id'] ?? 0));
        $groups[$key][] = $i;
    }

    foreach ($groups as $indices) {
        $first = $items[$indices[0]];
        $rule = $first['rule'];
        $weight_kg = $first['weight_kg'] ?? null;
        $stale = !empty($first['weight_stale']);
        $parts = [];

        foreach ($indices as $i) {
            $ev = $items[$i]['eval'];
            if (!is_array($ev)) {
                $ev = [];
            }
            // กันค้างจาก qty รายบรรทัด (ถ้ามี)
            if (!empty($ev['mismatches']) && is_array($ev['mismatches'])) {
                $ev['mismatches'] = array_values(array_filter($ev['mismatches'], function ($m) {
                    return ($m['type'] ?? '') !== 'qty';
                }));
                $items[$i]['eval'] = $ev;
            }

            $method = (string)(($items[$i]['row']['method'] ?? '') ?: '');
            $phase = $ev['phase'] ?? mmgml_method_phase($method);
            $hours = $ev['hours'] ?? null;
            if ($hours === null && $method !== '') {
                $hours = mmgml_extract_hours($method);
            }
            $qty = (float)($items[$i]['row']['qty'] ?? ($ev['qty'] ?? 0));
            $parts[] = [
                'phase' => $phase,
                'qty' => $qty,
                'hours' => $hours,
            ];
        }

        $mm = mmgml_evaluate_combined_qty($rule, $parts, $weight_kg, $stale);

        if ($mm === null) {
            foreach ($indices as $i) {
                $ev = $items[$i]['eval'];
                if (!is_array($ev)) {
                    continue;
                }
                if (($ev['status'] ?? '') === 'alert' && empty($ev['mismatches'])) {
                    $ev['status'] = !empty($ev['unverifiable']) ? 'unverifiable' : 'pass';
                    $items[$i]['eval'] = $ev;
                }
            }
            continue;
        }

        foreach ($indices as $i) {
            $ev = $items[$i]['eval'];
            if (!is_array($ev)) {
                $method = (string)(($items[$i]['row']['method'] ?? '') ?: '');
                $ev = [
                    'mismatches' => [],
                    'phase' => mmgml_method_phase($method),
                    'qty' => (float)($items[$i]['row']['qty'] ?? 0),
                ];
            }
            if (!isset($ev['mismatches']) || !is_array($ev['mismatches'])) {
                $ev['mismatches'] = [];
            }
            $ev['mismatches'][] = $mm;
            $ev['status'] = 'alert';
            $ev['expected_amp'] = $mm['expected_amp'];
            $items[$i]['eval'] = $ev;
        }
    }
}

/**
 * ประเมินวิธีใช้กับกฎ — คืน null ถ้าไม่ต้องแจ้ง (ข้าม/ถูกต้อง)
 * $ctx: weight_kg, qty
 *
 * เมื่อ fail คืน array พร้อม mismatches[] และฟิลด์เดิมเพื่อเข้ากันได้กับ UI
 * ถ้าต้องการน้ำหนักแต่ไม่มี: mismatches type=unverifiable (ไม่ใช่ error ขนาดยา)
 */
function mmgml_evaluate_method(array $rule, $method, array $ctx = []) {
    $method = trim(preg_replace('/\s+/u', ' ', (string)$method));
    $catalog_mg_per_ml = (float)($rule['mg_per_ml'] ?? 0);
    if ($method === '' || $catalog_mg_per_ml <= 0) {
        return null;
    }
    $conc = mmgml_resolve_mg_per_ml_for_method($method, $catalog_mg_per_ml);
    $mg_per_ml = (float)$conc['mg_per_ml'];
    $mix_label = (string)($conc['mix_label'] ?? '');
    if ($mg_per_ml <= 0) {
        return null;
    }

    $tol_pct = mmgml_effective_tol_pct($rule, $ctx, false); // สำหรับ ml / rate = ตามที่ตั้ง
    $tol_weight = mmgml_effective_tol_pct($rule, $ctx, true); // weight/qty ถ้า stale = 2 เท่า
    $phase = mmgml_method_phase($method);
    $ml_method = mmgml_usage_for_drug($method, $rule, $ctx);
    $dose_mg = $ml_method !== '' ? mmgml_extract_dose_mg_for_ml($ml_method, $phase) : null;
    $stated_ml = $ml_method !== '' ? mmgml_extract_ml_from_usage($ml_method) : null;
    $stated_rate = mmgml_extract_rate_ml_hr($method);
    $stated_mg_hr = mmgml_extract_mg_hr($method);
    $hours_from_method = mmgml_extract_hours($method);
    $vol_from_method = mmgml_extract_volume_ml($method);

    $def_hours = (float)($rule['default_hours'] ?? 0);
    $def_vol = (float)($rule['default_volume_ml'] ?? 0);
    $hours = $hours_from_method !== null ? $hours_from_method : ($def_hours > 0 ? $def_hours : null);
    $volume_ml = $vol_from_method !== null ? $vol_from_method : ($def_vol > 0 ? $def_vol : null);

    $weight_kg = isset($ctx['weight_kg']) ? (float)$ctx['weight_kg'] : 0;
    if ($weight_kg <= 0) {
        $weight_kg = null;
    }
    $qty = isset($ctx['qty']) ? (float)$ctx['qty'] : null;

    $use_weight = !empty($rule['use_weight']);
    $check_qty = !empty($rule['check_qty']);
    $check_rate = !empty($rule['check_rate']);
    $mg_per_amp = (float)($rule['mg_per_amp'] ?? 0);
    $fixed_exempt = mmgml_should_exempt_fixed_dose($rule, $method);
    if ($fixed_exempt) {
        // ขนาดคงที่: ตรวจเฉพาะ mg/GM → mL (ถ้ามี) ไม่เทียบ BW / Amp ตาม BW / Rate
        $use_weight = false;
        $check_qty = false;
        $check_rate = false;
    }

    $mismatches = [];
    $expected_ml = null;
    $tolerance_ml = null;
    $diff_ml = null;
    $did_ml_check = false;
    $needs_weight = $use_weight || ($check_qty && ((float)($rule['dose_mg_per_kg'] ?? 0) > 0 || (float)($rule['dose_mg_per_kg_hr'] ?? 0) > 0));
    $unverifiable = ($needs_weight && $weight_kg === null);

    $expected_doses = ['bolus' => null, 'infusion' => null, 'total' => null, 'mg_hr' => null];
    if ($weight_kg !== null && ($use_weight || $check_qty)) {
        $expected_doses = mmgml_expected_doses($rule, $weight_kg, $hours ?? 0);
    }

    // สำหรับ infusion: ถ้าไม่มี total mg ในวิธีใช้ แต่มี expected จากน้ำหนัก — ใช้ expected ตรวจ mL
    $dose_for_ml = $dose_mg;
    if ($phase === 'infusion' && ($dose_for_ml === null || $dose_for_ml <= 0) && $expected_doses['infusion'] !== null) {
        $dose_for_ml = $expected_doses['infusion'];
    }

    // 1) ตรวจ mg → mL
    if ($dose_for_ml !== null && $dose_for_ml > 0 && $stated_ml !== null && $stated_ml > 0) {
        $did_ml_check = true;
        $expected_ml = $dose_for_ml / $mg_per_ml;
        $tolerance_ml = mmgml_compute_tolerance_ml($expected_ml, $rule);
        $diff_ml = abs($stated_ml - $expected_ml);
        if ($diff_ml > $tolerance_ml) {
            $mismatches[] = [
                'type' => 'ml',
                'message' => mmgml_format_mg($dose_for_ml) . ' mg ควรเป็น ' . mmgml_format_ml($expected_ml)
                    . ' mL (ที่ ' . mmgml_conc_phrase($mg_per_ml, $mix_label) . ') แต่ระบุ ' . mmgml_format_ml($stated_ml) . ' mL',
            ];
        }
    }

    // 2) ตรวจขนาดตามน้ำหนัก — ข้ามถ้าไม่มี BW (ไม่นับ error)
    if ($use_weight && $weight_kg !== null) {
        $matched = false;

        // infusion: เทียบ mg/hr เป็นหลัก แล้วค่อย total infusion mg
        if ($phase === 'infusion') {
            if ($stated_mg_hr !== null && $expected_doses['mg_hr'] !== null) {
                $matched = mmgml_within_pct($stated_mg_hr, $expected_doses['mg_hr'], $tol_weight);
            }
            if (!$matched && $dose_mg !== null && $expected_doses['infusion'] !== null) {
                $matched = mmgml_within_pct($dose_mg, $expected_doses['infusion'], $tol_weight);
            }
            if (!$matched && ($stated_mg_hr !== null || $dose_mg !== null) && $expected_doses['mg_hr'] !== null) {
                $got = $stated_mg_hr !== null
                    ? mmgml_format_mg($stated_mg_hr) . ' mg/hr'
                    : mmgml_format_mg($dose_mg) . ' mg';
                $parts = [];
                if ($expected_doses['mg_hr'] !== null) {
                    $parts[] = mmgml_format_mg($expected_doses['mg_hr']) . ' mg/hr';
                }
                if ($expected_doses['infusion'] !== null) {
                    $parts[] = 'Infusion ' . mmgml_format_mg($expected_doses['infusion']) . ' mg';
                }
                $mismatches[] = [
                    'type' => 'weight_dose',
                    'message' => 'Infusion ตามน้ำหนัก ' . mmgml_format_num($weight_kg, 1) . ' kg ควรเป็น '
                        . implode(' / ', $parts) . ' แต่ระบุ ' . $got
                        . (!empty($ctx['weight_stale']) ? ' (ใช้น้ำหนักล่าสุด อนุโลม ' . mmgml_format_num($tol_weight, 1) . '%)' : ''),
                ];
            }
        } elseif ($phase === 'bolus') {
            if ($dose_mg !== null && $expected_doses['bolus'] !== null) {
                $matched = mmgml_within_pct($dose_mg, $expected_doses['bolus'], $tol_weight);
            }
            if (!$matched && $dose_mg !== null && $expected_doses['bolus'] !== null) {
                $mismatches[] = [
                    'type' => 'weight_dose',
                    'message' => 'Bolus ตามน้ำหนัก ' . mmgml_format_num($weight_kg, 1) . ' kg ควรเป็น '
                        . mmgml_format_mg($expected_doses['bolus']) . ' mg แต่ระบุ ' . mmgml_format_mg($dose_mg) . ' mg'
                        . (!empty($ctx['weight_stale']) ? ' (ใช้น้ำหนักล่าสุด อนุโลม ' . mmgml_format_num($tol_weight, 1) . '%)' : ''),
                ];
            }
        } else {
            // unknown: เทียบได้หลายแบบ
            $candidates = [];
            if ($expected_doses['bolus'] !== null) {
                $candidates['bolus'] = $expected_doses['bolus'];
            }
            if ($expected_doses['infusion'] !== null) {
                $candidates['infusion'] = $expected_doses['infusion'];
            }
            if ($expected_doses['total'] !== null) {
                $candidates['total'] = $expected_doses['total'];
            }
            if ($stated_mg_hr !== null && $expected_doses['mg_hr'] !== null
                && mmgml_within_pct($stated_mg_hr, $expected_doses['mg_hr'], $tol_weight)) {
                $matched = true;
            }
            if (!$matched && $dose_mg !== null && $dose_mg > 0) {
                foreach ($candidates as $exp) {
                    if (mmgml_within_pct($dose_mg, $exp, $tol_weight)) {
                        $matched = true;
                        break;
                    }
                }
            }
            $has_stated = ($dose_mg !== null && $dose_mg > 0) || ($stated_mg_hr !== null && $stated_mg_hr > 0);
            if ($has_stated && !empty($candidates) && !$matched) {
                $parts = [];
                if ($expected_doses['bolus'] !== null) {
                    $parts[] = 'Bolus ' . mmgml_format_mg($expected_doses['bolus']) . ' mg';
                }
                if ($expected_doses['infusion'] !== null) {
                    $parts[] = 'Infusion ' . mmgml_format_mg($expected_doses['infusion']) . ' mg';
                }
                if ($expected_doses['mg_hr'] !== null) {
                    $parts[] = mmgml_format_mg($expected_doses['mg_hr']) . ' mg/hr';
                }
                $got = $dose_mg !== null && $dose_mg > 0
                    ? mmgml_format_mg($dose_mg) . ' mg'
                    : mmgml_format_mg($stated_mg_hr) . ' mg/hr';
                $mismatches[] = [
                    'type' => 'weight_dose',
                    'message' => 'ขนาดตามน้ำหนัก ' . mmgml_format_num($weight_kg, 1) . ' kg ควรเป็น '
                        . implode(' / ', $parts) . ' แต่ระบุ ' . $got
                        . (!empty($ctx['weight_stale']) ? ' (ใช้น้ำหนักล่าสุด อนุโลม ' . mmgml_format_num($tol_weight, 1) . '%)' : ''),
                ];
            }
        }
    }

    // 3) ตรวจจำนวนจ่าย (Amp) — กฎที่มีทั้ง Bolus+Infusion ข้ามรายบรรทัด (รวมในใบสั่งเดียวกันทีหลัง)
    //    ถ้าต้องใช้น้ำหนักแต่ไม่มี BW ข้าม (unverifiable)
    $defer_combined_qty = mmgml_rule_has_bolus_and_infusion($rule) && empty($ctx['allow_single_qty']);
    if ($check_qty && !$defer_combined_qty && $mg_per_amp > 0 && $qty !== null && $qty > 0 && !($unverifiable && $needs_weight)) {
        $exp_mg_for_qty = null;

        if ($weight_kg !== null && ($expected_doses['total'] !== null || $expected_doses['bolus'] !== null || $expected_doses['infusion'] !== null)) {
            if ($phase === 'bolus' && $expected_doses['bolus'] !== null) {
                $exp_mg_for_qty = $expected_doses['bolus'];
            } elseif ($phase === 'infusion' && $expected_doses['infusion'] !== null) {
                $exp_mg_for_qty = $expected_doses['infusion'];
            } elseif ($expected_doses['total'] !== null) {
                $exp_mg_for_qty = $expected_doses['total'];
            } elseif ($expected_doses['bolus'] !== null) {
                $exp_mg_for_qty = $expected_doses['bolus'];
            } elseif ($expected_doses['infusion'] !== null) {
                $exp_mg_for_qty = $expected_doses['infusion'];
            }
        } elseif ($dose_mg !== null && $dose_mg > 0) {
            $exp_mg_for_qty = $dose_mg;
        }

        if ($exp_mg_for_qty !== null && $exp_mg_for_qty > 0) {
            $expected_amp = mmgml_expected_amps($exp_mg_for_qty, $mg_per_amp);
            if ($expected_amp !== null && !mmgml_within_pct($qty, $expected_amp, $tol_weight)) {
                $ok_alt = false;
                if ($phase === 'unknown' && $weight_kg !== null) {
                    foreach (['bolus', 'infusion', 'total'] as $k) {
                        if ($expected_doses[$k] === null) {
                            continue;
                        }
                        $alt = mmgml_expected_amps($expected_doses[$k], $mg_per_amp);
                        if ($alt !== null && mmgml_within_pct($qty, $alt, $tol_weight)) {
                            $ok_alt = true;
                            break;
                        }
                    }
                }
                if (!$ok_alt) {
                    $mismatches[] = [
                        'type' => 'qty',
                        'message' => 'จำนวนจ่ายควรเป็น ' . mmgml_format_num($expected_amp, 3)
                            . ' Amp (จาก ' . mmgml_format_mg($exp_mg_for_qty) . ' mg ÷ '
                            . mmgml_format_mg($mg_per_amp) . ' mg/Amp) แต่จ่าย ' . mmgml_format_num($qty, 3) . ' Amp'
                            . (!empty($ctx['weight_stale']) ? ' (ใช้น้ำหนักล่าสุด อนุโลม ' . mmgml_format_num($tol_weight, 1) . '%)' : ''),
                        'expected_amp' => $expected_amp,
                        'stated_qty' => $qty,
                    ];
                }
            }
        }
    }

    // 4) ตรวจ Rate (สำคัญกับ infusion)
    if ($check_rate) {
        $exp_rate = null;
        if ($volume_ml !== null && $hours !== null) {
            $exp_rate = mmgml_expected_rate($volume_ml, $hours);
        }
        if ($exp_rate !== null && $stated_rate !== null && $stated_rate > 0) {
            if (!mmgml_within_pct($stated_rate, $exp_rate, $tol_pct)) {
                $mismatches[] = [
                    'type' => 'rate',
                    'message' => 'Rate ควรเป็น ' . mmgml_format_num($exp_rate, 2) . ' ml/hr'
                        . ' (' . mmgml_format_num($volume_ml, 0) . ' mL ÷ ' . mmgml_format_num($hours, 1) . ' hr)'
                        . ' แต่ระบุ ' . mmgml_format_num($stated_rate, 2) . ' ml/hr',
                    'expected_rate' => $exp_rate,
                    'stated_rate' => $stated_rate,
                ];
            }
        }
        if ($exp_rate !== null && ($stated_rate === null || $stated_rate <= 0) && $phase === 'infusion') {
            $mismatches[] = [
                'type' => 'rate',
                'message' => 'วิธีใช้แบบ Infusion ควรระบุ rate ประมาณ ' . mmgml_format_num($exp_rate, 2) . ' ml/hr'
                    . ' (' . mmgml_format_num($volume_ml, 0) . ' mL ÷ ' . mmgml_format_num($hours, 1) . ' hr) แต่ไม่พบ ml/hr',
                'expected_rate' => $exp_rate,
                'stated_rate' => null,
            ];
        }
    }

    if (!$did_ml_check && empty($mismatches) && !$use_weight && !$check_qty && !$check_rate) {
        return null;
    }

    // ไม่มี mismatch จริง แต่ต้องใช้น้ำหนักและไม่มี BW → ไม่นับ error (Smart Pharma ข้าม)
    if (empty($mismatches)) {
        if ($unverifiable) {
            return null;
        }
        return null;
    }

    return [
        'dose_mg' => $dose_for_ml !== null ? $dose_for_ml : $dose_mg,
        'stated_ml' => $stated_ml,
        'expected_ml' => $expected_ml,
        'tolerance_ml' => $tolerance_ml,
        'diff_ml' => $diff_ml,
        'mg_per_ml' => $mg_per_ml,
        'mix_label' => $mix_label,
        'strength_text' => trim($rule['strength_text'] ?? ''),
        'weight_kg' => $weight_kg,
        'qty' => $qty,
        'hours' => $hours,
        'volume_ml' => $volume_ml,
        'stated_rate' => $stated_rate,
        'expected_doses' => $expected_doses,
        'mismatches' => $mismatches,
        'phase' => $phase,
        'unverifiable' => $unverifiable,
    ];
}

/**
 * ประเมินแบบละเอียด — คืนผลทั้งผ่านและไม่ผ่าน สำหรับหน้า Monitor
 * status: skip | pass | alert | unverifiable
 */
function mmgml_evaluate_order(array $rule, $method, array $ctx = []) {
    $method = trim(preg_replace('/\s+/u', ' ', (string)$method));
    $catalog_mg_per_ml = (float)($rule['mg_per_ml'] ?? 0);
    if ($method === '' || $catalog_mg_per_ml <= 0) {
        return ['status' => 'skip'];
    }
    $conc = mmgml_resolve_mg_per_ml_for_method($method, $catalog_mg_per_ml);
    $mg_per_ml = (float)$conc['mg_per_ml'];
    $mix_label = (string)($conc['mix_label'] ?? '');
    if ($mg_per_ml <= 0) {
        return ['status' => 'skip'];
    }

    $tol_pct = max(0, (float)($rule['tolerance_pct'] ?? 5));
    $phase = mmgml_method_phase($method);
    $ml_method = mmgml_usage_for_drug($method, $rule, $ctx);
    $dose_mg = $ml_method !== '' ? mmgml_extract_dose_mg_for_ml($ml_method, $phase) : null;
    $stated_ml = $ml_method !== '' ? mmgml_extract_ml_from_usage($ml_method) : null;
    $stated_rate = mmgml_extract_rate_ml_hr($method);
    $stated_mg_hr = mmgml_extract_mg_hr($method);
    $hours_from_method = mmgml_extract_hours($method);
    $vol_from_method = mmgml_extract_volume_ml($method);

    $def_hours = (float)($rule['default_hours'] ?? 0);
    $def_vol = (float)($rule['default_volume_ml'] ?? 0);
    $hours = $hours_from_method !== null ? $hours_from_method : ($def_hours > 0 ? $def_hours : null);
    $volume_ml = $vol_from_method !== null ? $vol_from_method : ($def_vol > 0 ? $def_vol : null);

    $weight_kg = isset($ctx['weight_kg']) ? (float)$ctx['weight_kg'] : 0;
    if ($weight_kg <= 0) {
        $weight_kg = null;
    }
    $qty = isset($ctx['qty']) ? (float)$ctx['qty'] : null;

    $use_weight = !empty($rule['use_weight']);
    $check_qty = !empty($rule['check_qty']);
    $check_rate = !empty($rule['check_rate']);
    $fixed_exempt = mmgml_should_exempt_fixed_dose($rule, $method);
    if ($fixed_exempt) {
        $use_weight = false;
        $check_qty = false;
        $check_rate = false;
    }
    $needs_weight = $use_weight || ($check_qty && ((float)($rule['dose_mg_per_kg'] ?? 0) > 0 || (float)($rule['dose_mg_per_kg_hr'] ?? 0) > 0));
    $unverifiable = ($needs_weight && $weight_kg === null);

    $expected_doses = ['bolus' => null, 'infusion' => null, 'total' => null, 'mg_hr' => null];
    if ($weight_kg !== null && ($use_weight || $check_qty)) {
        $expected_doses = mmgml_expected_doses($rule, $weight_kg, $hours ?? 0);
    }

    $dose_for_ml = $dose_mg;
    if ($phase === 'infusion' && ($dose_for_ml === null || $dose_for_ml <= 0) && $expected_doses['infusion'] !== null) {
        $dose_for_ml = $expected_doses['infusion'];
    }

    $can_ml = ($dose_for_ml !== null && $dose_for_ml > 0 && $stated_ml !== null && $stated_ml > 0);
    $needs_extra = $use_weight || $check_qty || $check_rate || $fixed_exempt;

    if (!$can_ml && !$needs_extra) {
        return ['status' => 'skip'];
    }

    $fail = mmgml_evaluate_method($rule, $method, $ctx);

    $expected_ml = $can_ml ? ($dose_for_ml / $mg_per_ml) : null;
    $tolerance_ml = $can_ml ? mmgml_compute_tolerance_ml($expected_ml, $rule) : null;
    $diff_ml = ($can_ml && $expected_ml !== null) ? abs($stated_ml - $expected_ml) : null;
    $expected_rate = ($volume_ml !== null && $hours !== null) ? mmgml_expected_rate($volume_ml, $hours) : null;

    $expected_amp = null;
    $mg_per_amp = (float)($rule['mg_per_amp'] ?? 0);
    if ($check_qty && $mg_per_amp > 0 && !$unverifiable) {
        $exp_mg = null;
        if ($expected_doses['total'] !== null || $expected_doses['bolus'] !== null || $expected_doses['infusion'] !== null) {
            if ($phase === 'bolus' && $expected_doses['bolus'] !== null) {
                $exp_mg = $expected_doses['bolus'];
            } elseif ($phase === 'infusion' && $expected_doses['infusion'] !== null) {
                $exp_mg = $expected_doses['infusion'];
            } else {
                $exp_mg = $expected_doses['total'] ?? $expected_doses['bolus'] ?? $expected_doses['infusion'];
            }
        } elseif ($dose_for_ml !== null && $dose_for_ml > 0) {
            $exp_mg = $dose_for_ml;
        }
        if ($exp_mg !== null) {
            $expected_amp = mmgml_expected_amps($exp_mg, $mg_per_amp);
        }
    }

    $did_anything = $can_ml;
    if ($use_weight && $weight_kg !== null && (($dose_for_ml !== null && $dose_for_ml > 0) || ($stated_mg_hr !== null))) {
        $did_anything = true;
    }
    if ($fixed_exempt && $dose_for_ml !== null && $dose_for_ml > 0) {
        $did_anything = true;
    }
    if ($unverifiable) {
        $did_anything = true;
    }
    if ($check_qty && $qty !== null && $qty > 0 && $expected_amp !== null) {
        $did_anything = true;
    }
    if ($check_rate && $expected_rate !== null && ($stated_rate !== null || $phase === 'infusion')) {
        $did_anything = true;
    }

    if (!$did_anything) {
        return ['status' => 'skip'];
    }

    $base = [
        'dose_mg' => $dose_for_ml,
        'stated_ml' => $stated_ml,
        'expected_ml' => $expected_ml,
        'tolerance_ml' => $tolerance_ml,
        'diff_ml' => $diff_ml,
        'mg_per_ml' => $mg_per_ml,
        'mix_label' => $mix_label,
        'strength_text' => trim($rule['strength_text'] ?? ''),
        'weight_kg' => $weight_kg,
        'qty' => $qty,
        'hours' => $hours,
        'volume_ml' => $volume_ml,
        'stated_rate' => $stated_rate,
        'expected_rate' => $expected_rate,
        'expected_amp' => $expected_amp,
        'expected_doses' => $expected_doses,
        'stated_mg_hr' => $stated_mg_hr,
        'tolerance_pct' => $tol_pct,
        'phase' => $phase,
        'unverifiable' => $unverifiable,
        'fixed_dose_exempt' => $fixed_exempt,
    ];

    if ($fail !== null && !empty($fail['mismatches'])) {
        $base['status'] = 'alert';
        $base['mismatches'] = $fail['mismatches'];
        return $base;
    }

    if ($unverifiable) {
        $base['status'] = 'unverifiable';
        $base['mismatches'] = [[
            'type' => 'unverifiable',
            'message' => 'ตรวจสอบไม่ได้ (ไม่พบน้ำหนักผู้ป่วยล่าสุด)',
        ]];
        return $base;
    }

    $base['status'] = 'pass';
    $base['mismatches'] = [];
    return $base;
}

function mmgml_default_alert_message(array $rule, array $eval) {
    $custom = trim($rule['alert_message'] ?? '');
    if ($custom !== '') {
        return $custom;
    }
    $drug = trim($rule['drug_name'] ?? '');
    $prefix = $drug !== '' ? $drug . ': ' : '';

    if (!empty($eval['mismatches']) && is_array($eval['mismatches'])) {
        $msgs = [];
        foreach ($eval['mismatches'] as $mm) {
            if (!empty($mm['message'])) {
                $msgs[] = $mm['message'];
            }
        }
        if (!empty($msgs)) {
            return $prefix . implode(' | ', $msgs);
        }
    }

    $exp = mmgml_format_ml($eval['expected_ml'] ?? null);
    $got = mmgml_format_ml($eval['stated_ml'] ?? null);
    $mg = mmgml_format_mg($eval['dose_mg'] ?? null);
    $conc = mmgml_conc_phrase($eval['mg_per_ml'] ?? null, $eval['mix_label'] ?? '');
    return $prefix . "{$mg} mg ควรเป็น {$exp} mL (ที่ {$conc}) แต่ระบุ {$got} mL";
}

/** สแกน HOSxP — ดึงยาที่ strength มี mg/mL หรือ mcg/mL */
function mmgml_scan_from_tmt($hos, $con) {
    mmgml_ensure_table($con);
    if (!$hos) {
        return ['inserted' => 0, 'updated' => 0, 'skipped' => 0, 'scanned' => 0, 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP'];
    }

    $strength_expr = hosxp_sql_tmt_strength('d', 'tm');
    $name_expr = hosxp_sql_tmt_drug_name('d', 'tm');
    $sql = "
        SELECT d.icode,
               CAST(CONVERT($name_expr USING utf8) AS CHAR) AS drug_name,
               CAST(CONVERT($strength_expr USING utf8) AS CHAR) AS strength
        FROM drugitems d
        " . hosxp_sql_tmt_join('d', 'tm') . "
        WHERE d.istatus = 'Y'
          AND d.icode IS NOT NULL
          AND TRIM(d.icode) <> ''
          AND (
            LOWER(CAST(CONVERT($strength_expr USING utf8) AS CHAR)) REGEXP '[0-9].*mg.*[/].*ml'
            OR LOWER(CAST(CONVERT($strength_expr USING utf8) AS CHAR)) REGEXP '[0-9].*(mcg|µg|μg|ug).*[ /].*ml'
          )
        ORDER BY drug_name ASC
    ";

    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['inserted' => 0, 'updated' => 0, 'skipped' => 0, 'scanned' => 0, 'message' => mysqli_error($hos)];
    }

    $inserted = 0;
    $updated = 0;
    $skipped = 0;
    $scanned = 0;

    while ($row = mysqli_fetch_assoc($q)) {
        $scanned++;
        $icode = trim($row['icode'] ?? '');
        $strength = trim($row['strength'] ?? '');
        $drug_name = trim($row['drug_name'] ?? '');
        if ($icode === '' || $strength === '') {
            $skipped++;
            continue;
        }

        $parsed = mmgml_parse_concentration_from_strength($strength);
        if ($parsed === null || (float)$parsed['mg_per_ml'] <= 0) {
            $skipped++;
            continue;
        }

        $mg_per_ml = (float)$parsed['mg_per_ml'];
        $icode_e = mmgml_escape($con, $icode);
        $name_e = mmgml_escape($con, $drug_name);
        $strength_e = mmgml_escape($con, $strength);

        $chk = mysqli_query($con, "SELECT id, mg_per_ml, auto_from_tmt FROM monitor_mg_ml_settings WHERE icode='$icode_e' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            $existing = mysqli_fetch_assoc($chk);
            if (!empty($existing['auto_from_tmt'])) {
                $id = (int)$existing['id'];
                $sql_up = "UPDATE monitor_mg_ml_settings SET
                    drug_name='$name_e',
                    strength_text='$strength_e',
                    mg_per_ml=$mg_per_ml,
                    auto_from_tmt=1
                    WHERE id=$id";
                if (mysqli_query($con, $sql_up)) {
                    $updated++;
                }
            } else {
                $skipped++;
            }
            continue;
        }

        $sql_ins = "INSERT INTO monitor_mg_ml_settings
            (icode, drug_name, strength_text, mg_per_ml, tolerance_pct, tolerance_ml, auto_from_tmt, alert_level, active)
            VALUES ('$icode_e', '$name_e', '$strength_e', $mg_per_ml, 5.00, 0.0200, 1, 'soft', 1)";
        if (mysqli_query($con, $sql_ins)) {
            $inserted++;
        }
    }

    return [
        'inserted' => $inserted,
        'updated' => $updated,
        'skipped' => $skipped,
        'scanned' => $scanned,
        'message' => 'ok',
    ];
}

/**
 * นำเข้าคลังยาฉีดจากตารางคำนวณ — จับคู่ชื่อ+ความแรงกับยา HOSxP แล้วเพิ่มกฎ (ไม่ทับรายการที่มีแล้ว)
 * @return array{inserted:int,updated:int,skipped:int,unmatched:int,matched:int,message:string,unmatched_names:array}
 */
function mmgml_import_injection_catalog($hos, $con) {
    mmgml_ensure_table($con);
    if (!$hos) {
        return [
            'inserted' => 0, 'updated' => 0, 'skipped' => 0, 'unmatched' => 0, 'matched' => 0,
            'message' => 'ไม่สามารถเชื่อมต่อ HOSxP', 'unmatched_names' => [],
        ];
    }

    $catalog = mmgml_injection_catalog();
    $strength_expr = hosxp_sql_tmt_strength('d', 'tm');
    $name_expr = hosxp_sql_tmt_drug_name('d', 'tm');
    $sql = "
        SELECT d.icode,
               CAST(CONVERT(d.name USING utf8) AS CHAR) AS name_local,
               CAST(CONVERT($name_expr USING utf8) AS CHAR) AS name_tmt,
               CAST(CONVERT($strength_expr USING utf8) AS CHAR) AS strength
        FROM drugitems d
        " . hosxp_sql_tmt_join('d', 'tm') . "
        WHERE d.istatus = 'Y'
          AND d.icode IS NOT NULL
          AND TRIM(d.icode) <> ''
    ";
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return [
            'inserted' => 0, 'updated' => 0, 'skipped' => 0, 'unmatched' => 0, 'matched' => 0,
            'message' => mysqli_error($hos), 'unmatched_names' => [],
        ];
    }

    $drugs = [];
    while ($row = mysqli_fetch_assoc($q)) {
        $drugs[] = $row;
    }

    $inserted = 0;
    $updated = 0;
    $skipped = 0;
    $matched = 0;
    $unmatched_names = [];

    foreach ($catalog as $item) {
        $hits = mmgml_catalog_match_drugs($drugs, $item);
        if (empty($hits)) {
            $unmatched_names[] = $item['name'];
            continue;
        }
        $matched += count($hits);
        foreach ($hits as $d) {
            $icode = trim((string)($d['icode'] ?? ''));
            if ($icode === '') {
                continue;
            }
            $res = mmgml_catalog_upsert_rule($con, $d, $item);
            if ($res === 'inserted') {
                $inserted++;
            } elseif ($res === 'updated') {
                $updated++;
            } else {
                $skipped++;
            }
        }
    }

    return [
        'inserted' => $inserted,
        'updated' => $updated,
        'skipped' => $skipped,
        'unmatched' => count($unmatched_names),
        'matched' => $matched,
        'message' => 'ok',
        'unmatched_names' => $unmatched_names,
    ];
}

function mmgml_catalog_norm($s) {
    $s = strtolower(trim((string)$s));
    $s = str_replace(['µ', 'μ'], 'u', $s);
    $s = preg_replace('/[^a-z0-9ก-๙.+%]+/u', ' ', $s);
    return trim(preg_replace('/\s+/u', ' ', $s));
}

/** ยาหยอดตา/หู ครีม ฯลฯ — ไม่ใช่ยาฉีด ไม่ควรจับคู่คลังยาฉีด */
function mmgml_catalog_is_non_injectable($blob) {
    return (bool)preg_match(
        '/\b(eye\s*drop|eardrop|ear\s*drop|ophthalmic|ointment|cream|gel|lotion|topical|nasal\s*drop|ยาหยอด|ครีม)\b/u',
        (string)$blob
    );
}

/** strength แบบ 1 g / 1 gm ถือเป็น 1000 mg */
function mmgml_catalog_blob_has_mg($blob, $mg) {
    $mg = (float)$mg;
    if ($mg <= 0) {
        return false;
    }
    $mgStr = rtrim(rtrim(number_format($mg, 4, '.', ''), '0'), '.');
    if ($mgStr !== '' && preg_match('/(?:^|[^0-9.])' . preg_quote($mgStr, '/') . '(?:[^0-9.]|$)/', $blob)) {
        return true;
    }
    if (preg_match_all('/(?:^|[^a-z0-9.])(\d+(?:\.\d+)?)\s*(?:grams?|gms?|g)\b/u', $blob, $m)) {
        foreach ($m[1] as $g) {
            $as_mg = (float)$g * 1000.0;
            if ($as_mg > 0 && abs($as_mg - $mg) / $mg <= 0.08) {
                return true;
            }
        }
    }
    return false;
}

function mmgml_catalog_match_drugs(array $drugs, array $item) {
    $aliases = $item['aliases'] ?? [];
    $mg = (float)($item['mg'] ?? 0);
    $ml = (float)($item['ml'] ?? 0);
    $wantConc = (float)($item['mg_per_ml'] ?? 0);
    $scored = [];

    foreach ($drugs as $d) {
        $blob = mmgml_catalog_norm(
            ($d['name_local'] ?? '') . ' ' . ($d['name_tmt'] ?? '') . ' ' . ($d['strength'] ?? '')
        );
        if (mmgml_catalog_is_non_injectable($blob)) {
            continue;
        }
        $nameHit = false;
        foreach ($aliases as $a) {
            $a = mmgml_catalog_norm($a);
            if ($a !== '' && strpos($blob, $a) !== false) {
                $nameHit = true;
                break;
            }
        }
        if (!$nameHit) {
            continue;
        }

        $score = 1;
        $strength = (string)($d['strength'] ?? '');
        $parsed = mmgml_parse_concentration_from_strength($strength);
        $conc = $parsed ? (float)$parsed['mg_per_ml'] : 0.0;
        $mgHit = mmgml_catalog_blob_has_mg($blob, $mg);
        if ($mgHit) {
            $score += 8;
        }
        $mlStr = rtrim(rtrim(number_format($ml, 4, '.', ''), '0'), '.');
        // อย่าให้ขวดยาหยอด "10 ml." ไปชนปริมาตรละลายยาฉีด
        if ($mgHit && $mlStr !== '' && $ml >= 1 && preg_match('/(?:^|[^0-9.])' . preg_quote($mlStr, '/') . '\s*ml\b/', $blob)) {
            $score += 4;
        }
        if ($wantConc > 0 && $conc > 0) {
            $diff = abs($conc - $wantConc) / $wantConc;
            if ($diff <= 0.08) {
                $score += 10;
            } elseif ($diff <= 0.25) {
                $score += 3;
            }
        }
        if (preg_match('/\b(injection|injectable|inj|vial|ampoule|\bamp\b)\b/u', $blob)) {
            $score += 3;
        }
        $scored[] = ['drug' => $d, 'score' => $score];
    }

    if (empty($scored)) {
        return [];
    }
    usort($scored, function ($a, $b) {
        return $b['score'] <=> $a['score'];
    });
    $best = (int)$scored[0]['score'];
    $minKeep = ($best >= 9) ? 9 : (($best >= 5) ? 5 : 1);
    $out = [];
    $seen = [];
    foreach ($scored as $row) {
        if ($row['score'] < $minKeep) {
            continue;
        }
        $ic = trim((string)($row['drug']['icode'] ?? ''));
        if ($ic === '' || isset($seen[$ic])) {
            continue;
        }
        $seen[$ic] = true;
        $out[] = $row['drug'];
        if (count($out) >= 8) {
            break;
        }
    }
    return $out;
}

function mmgml_catalog_upsert_rule($con, array $drug, array $item) {
    $icode = mmgml_escape($con, trim((string)($drug['icode'] ?? '')));
    $name = trim((string)($drug['name_tmt'] ?? ''));
    if ($name === '') {
        $name = trim((string)($drug['name_local'] ?? $item['name']));
    }
    $mg = (float)$item['mg'];
    $ml = (float)$item['ml'];
    $mg_per_ml = (float)$item['mg_per_ml'];
    $unit = $item['unit'] ?? 'mg';
    $pack = $item['pack'] ?? '';
    $notes = trim((string)($item['notes'] ?? ''));
    $strength = trim((string)($drug['strength'] ?? ''));
    if ($strength === '') {
        $strength = rtrim(rtrim(number_format($mg, 4, '.', ''), '0'), '.') . ' ' . $unit . '/'
            . rtrim(rtrim(number_format($ml, 4, '.', ''), '0'), '.') . ' mL';
    }
    $detail = $item['name'] . ' — ' . rtrim(rtrim(number_format($mg, 4, '.', ''), '0'), '.')
        . ' ' . $unit . ' / ' . rtrim(rtrim(number_format($ml, 4, '.', ''), '0'), '.') . ' mL'
        . ($pack !== '' ? ' (' . $pack . ')' : '');
    if ($notes !== '') {
        $detail .= ' | ' . $notes;
    }
    $name_e = mmgml_escape($con, $name);
    $strength_e = mmgml_escape($con, $strength);
    $detail_e = mmgml_escape($con, $detail);
    $sql_amp = mmgml_sql_nullable_num($mg);

    $chk = mysqli_query($con, "SELECT id, auto_from_tmt FROM monitor_mg_ml_settings WHERE icode='$icode' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $ex = mysqli_fetch_assoc($chk);
        $id = (int)$ex['id'];
        if (empty($ex['auto_from_tmt'])) {
            return 'skipped';
        }
        $ok = mysqli_query($con, "UPDATE monitor_mg_ml_settings SET
            drug_name='$name_e',
            strength_text='$strength_e',
            mg_per_ml=$mg_per_ml,
            mg_per_amp=$sql_amp,
            detail_text='$detail_e',
            auto_from_tmt=1
            WHERE id=$id");
        return $ok ? 'updated' : 'skipped';
    }

    $ok = mysqli_query($con, "INSERT INTO monitor_mg_ml_settings
        (icode, drug_name, strength_text, mg_per_ml, tolerance_pct, tolerance_ml,
         check_qty, mg_per_amp, auto_from_tmt, alert_level, detail_text, active)
        VALUES ('$icode', '$name_e', '$strength_e', $mg_per_ml, 5.00, 0.0200,
         0, $sql_amp, 1, 'soft', '$detail_e', 1)");
    return $ok ? 'inserted' : 'skipped';
}

function mmgml_build_rule_map_by_icode(array $rules) {
    $map = [];
    foreach ($rules as $rule) {
        $ic = trim($rule['icode'] ?? '');
        if ($ic === '') {
            continue;
        }
        if (!isset($map[$ic])) {
            $map[$ic] = [];
        }
        $map[$ic][] = $rule;
    }
    return $map;
}

function mmgml_rule_for_calculator(array $rule) {
    $mg_per_ml = (float)($rule['mg_per_ml'] ?? 0);
    $mg_per_amp = isset($rule['mg_per_amp']) && $rule['mg_per_amp'] !== '' && $rule['mg_per_amp'] !== null
        ? (float)$rule['mg_per_amp'] : null;
    $kg_min = isset($rule['calc_mg_per_kg_min']) && $rule['calc_mg_per_kg_min'] !== '' && $rule['calc_mg_per_kg_min'] !== null
        ? (float)$rule['calc_mg_per_kg_min'] : null;
    $kg_max = isset($rule['calc_mg_per_kg_max']) && $rule['calc_mg_per_kg_max'] !== '' && $rule['calc_mg_per_kg_max'] !== null
        ? (float)$rule['calc_mg_per_kg_max'] : null;
    if (($kg_min === null || $kg_min <= 0) && (float)($rule['dose_mg_per_kg'] ?? 0) > 0) {
        $kg_min = (float)$rule['dose_mg_per_kg'];
        if ($kg_max === null || $kg_max <= 0) {
            $kg_max = $kg_min;
        }
    }
    $interval = isset($rule['calc_interval_hours']) && $rule['calc_interval_hours'] !== '' && $rule['calc_interval_hours'] !== null
        ? (float)$rule['calc_interval_hours'] : null;
    return [
        'id' => (int)($rule['id'] ?? 0),
        'icode' => trim((string)($rule['icode'] ?? '')),
        'drug_name' => trim((string)($rule['drug_name'] ?? '')),
        'strength_text' => trim((string)($rule['strength_text'] ?? '')),
        'mg_per_ml' => $mg_per_ml,
        'mg_per_amp' => ($mg_per_amp !== null && $mg_per_amp > 0) ? $mg_per_amp : null,
        'calc_mg_per_kg_min' => ($kg_min !== null && $kg_min > 0) ? $kg_min : null,
        'calc_mg_per_kg_max' => ($kg_max !== null && $kg_max > 0) ? $kg_max : null,
        'calc_interval_hours' => ($interval !== null && $interval > 0) ? $interval : null,
        'detail_text' => trim((string)($rule['detail_text'] ?? '')),
        'active' => !empty($rule['active']) ? 1 : 0,
    ];
}

function mmgml_doses_per_day($interval_hours) {
    $h = (float)$interval_hours;
    if ($h <= 0) {
        return null;
    }
    return 24.0 / $h;
}

function mmgml_format_kg_range($min, $max) {
    $lo = ($min !== null && $min !== '' && (float)$min > 0) ? (float)$min : null;
    $hi = ($max !== null && $max !== '' && (float)$max > 0) ? (float)$max : null;
    if ($lo === null && $hi === null) {
        return '—';
    }
    if ($lo !== null && $hi !== null) {
        if (abs($lo - $hi) < 0.0001) {
            return mmgml_format_mg($lo);
        }
        return mmgml_format_mg($lo) . '–' . mmgml_format_mg($hi);
    }
    return mmgml_format_mg($lo !== null ? $lo : $hi);
}

function mmgml_format_interval_label($hours) {
    $h = (float)$hours;
    if ($h <= 0) {
        return '—';
    }
    $n = mmgml_doses_per_day($h);
    if ($n === null) {
        return 'ทุก ' . mmgml_format_mg($h) . ' ชม.';
    }
    $n_disp = (abs($n - round($n)) < 0.001) ? (string)(int)round($n) : mmgml_format_mg($n);
    return 'ทุก ' . mmgml_format_mg($h) . ' ชม. (×' . $n_disp . ')';
}

function mmgml_calc_volume($dose_mg, $mg_per_ml, $mg_per_amp = null) {
    $dose_mg = (float)$dose_mg;
    $mg_per_ml = (float)$mg_per_ml;
    if ($dose_mg <= 0 || $mg_per_ml <= 0) {
        return ['ml' => null, 'amp' => null];
    }
    $ml = $dose_mg / $mg_per_ml;
    $amp = null;
    $cap = (float)$mg_per_amp;
    if ($cap > 0) {
        $amp = $dose_mg / $cap;
    }
    return ['ml' => $ml, 'amp' => $amp];
}

function mmgml_fetch_orders_for_hn($hos, array $hn_variants, array $icodes, $days = 14, $limit = 300) {
    $days = max(1, min(90, (int)$days));
    $limit = max(20, min(500, (int)$limit));
    $hnIn = mmgml_sql_in_strings($hos, $hn_variants);
    $icIn = mmgml_sql_in_strings($hos, $icodes);
    if ($hnIn === '' || $icIn === '') {
        return [];
    }
    $start = date('Y-m-d', strtotime('-' . ($days - 1) . ' days'));
    $end = date('Y-m-d');
    $startEsc = mysqli_real_escape_string($hos, $start);
    $endEsc = mysqli_real_escape_string($hos, $end);
    $sql = "SELECT o.hn, o.vn, o.an, o.vstdate, o.rxdate, o.rxtime, o.icode, o.qty, o.item_no,
                   o.drugusage, o.sp_use, o.hos_guid
            FROM opitemrece o
            WHERE o.hn IN ({$hnIn})
              AND o.icode IN ({$icIn})
              AND o.rxdate BETWEEN '{$startEsc}' AND '{$endEsc}'
              AND o.qty > 0
            ORDER BY o.rxdate DESC, o.rxtime DESC, o.item_no DESC
            LIMIT {$limit}";
    $q = mysqli_query($hos, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return mmgml_enrich_monitor_orders($hos, $rows);
}

function mmgml_save_catalog_item($con, array $in, $id = 0) {
    mmgml_ensure_table($con);
    $icode = trim((string)($in['icode'] ?? ''));
    $drug_name = trim((string)($in['drug_name'] ?? ''));
    $strength_text = trim((string)($in['strength_text'] ?? ''));
    $mg_per_ml = (float)($in['mg_per_ml'] ?? 0);
    $mg_per_amp = ($in['mg_per_amp'] ?? '') === '' || $in['mg_per_amp'] === null
        ? null : (float)$in['mg_per_amp'];
    $kg_min = ($in['calc_mg_per_kg_min'] ?? '') === '' || $in['calc_mg_per_kg_min'] === null
        ? null : (float)$in['calc_mg_per_kg_min'];
    $kg_max = ($in['calc_mg_per_kg_max'] ?? '') === '' || $in['calc_mg_per_kg_max'] === null
        ? null : (float)$in['calc_mg_per_kg_max'];
    $interval = ($in['calc_interval_hours'] ?? '') === '' || $in['calc_interval_hours'] === null
        ? null : (float)$in['calc_interval_hours'];
    $detail_text = trim((string)($in['detail_text'] ?? ''));
    $active = !empty($in['active']) ? 1 : 0;
    $id = (int)$id;

    if ($icode === '') {
        return ['ok' => false, 'error' => 'กรุณาเลือกยาจาก HOSxP'];
    }
    if ($drug_name === '') {
        $drug_name = $icode;
    }
    if ($mg_per_ml <= 0) {
        return ['ok' => false, 'error' => 'กรุณาระบุความเข้มข้น mg/mL มากกว่า 0'];
    }
    if ($mg_per_amp !== null && $mg_per_amp < 0) {
        return ['ok' => false, 'error' => 'mg/Amp ต้องไม่ติดลบ'];
    }
    if ($kg_min !== null && $kg_min < 0) {
        return ['ok' => false, 'error' => 'mg/kg ต่ำสุดต้องไม่ติดลบ'];
    }
    if ($kg_max !== null && $kg_max < 0) {
        return ['ok' => false, 'error' => 'mg/kg สูงสุดต้องไม่ติดลบ'];
    }
    if ($kg_min !== null && $kg_max !== null && $kg_max < $kg_min) {
        return ['ok' => false, 'error' => 'mg/kg สูงสุดต้องไม่น้อยกว่าค่าต่ำสุด'];
    }
    if ($interval !== null && $interval <= 0) {
        return ['ok' => false, 'error' => 'ช่วงการให้ยาต้องมากกว่า 0 ชั่วโมง'];
    }

    $icode_e = mmgml_escape($con, $icode);
    $name_e = mmgml_escape($con, $drug_name);
    $str_e = mmgml_escape($con, $strength_text);
    $det_e = mmgml_escape($con, $detail_text);
    $sql_amp = mmgml_sql_nullable_num($mg_per_amp);
    $sql_kg_min = mmgml_sql_nullable_num($kg_min);
    $sql_kg_max = mmgml_sql_nullable_num($kg_max);
    $sql_int = mmgml_sql_nullable_num($interval);

    if ($id > 0) {
        $ok = mysqli_query($con, "UPDATE monitor_mg_ml_settings SET
            icode='$icode_e',
            drug_name='$name_e',
            strength_text='$str_e',
            mg_per_ml=$mg_per_ml,
            mg_per_amp=$sql_amp,
            calc_mg_per_kg_min=$sql_kg_min,
            calc_mg_per_kg_max=$sql_kg_max,
            calc_interval_hours=$sql_int,
            detail_text='$det_e',
            active=$active
            WHERE id=$id");
        if (!$ok) {
            return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ: ' . mysqli_error($con)];
        }
        return ['ok' => true, 'id' => $id, 'message' => 'บันทึกการแก้ไขเรียบร้อย'];
    }

    $chk = mysqli_query($con, "SELECT id FROM monitor_mg_ml_settings WHERE icode='$icode_e' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return ['ok' => false, 'error' => 'มีรายการยานี้แล้ว — กดแก้ไขจากตารางด้านขวา'];
    }
    $ok = mysqli_query($con, "INSERT INTO monitor_mg_ml_settings
        (icode, drug_name, strength_text, mg_per_ml, tolerance_pct, tolerance_ml,
         mg_per_amp, calc_mg_per_kg_min, calc_mg_per_kg_max, calc_interval_hours,
         auto_from_tmt, alert_level, detail_text, active)
        VALUES ('$icode_e', '$name_e', '$str_e', $mg_per_ml, 5.00, 0.0200,
         $sql_amp, $sql_kg_min, $sql_kg_max, $sql_int,
         0, 'soft', '$det_e', $active)");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ: ' . mysqli_error($con)];
    }
    return ['ok' => true, 'id' => (int)mysqli_insert_id($con), 'message' => 'เพิ่มรายการยาเรียบร้อย'];
}
