<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
require_once __DIR__ . '/smart_drug_tmt_except_helper.php';
session_write_close();
mysqli_set_charset($con, 'utf8');

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = [];
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'list'));

if ($action === 'list') {
    echo json_encode(['status' => 'success', 'items' => sd_tmt_except_list($con)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'search') {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 15) : null;
    if (!$hos) {
        echo json_encode(['status' => 'error', 'message' => 'เชื่อมต่อ HOSxP ไม่ได้', 'items' => []], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $items = hosxp_search_drugs_tmt($hos, $input['q'] ?? $_GET['q'] ?? '', 25);
    echo json_encode(['status' => 'success', 'items' => $items], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'add') {
    $res = sd_tmt_except_add($con, $input);
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['message'] ?? '',
        'items' => sd_tmt_except_list($con),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'delete') {
    $ok = sd_tmt_except_delete($con, $input['id'] ?? 0);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'message' => $ok ? '' : 'ลบไม่สำเร็จ',
        'items' => sd_tmt_except_list($con),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'ไม่รู้จักคำสั่ง'], JSON_UNESCAPED_UNICODE);
