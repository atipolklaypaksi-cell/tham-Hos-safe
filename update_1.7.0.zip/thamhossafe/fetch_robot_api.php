<?php
/**
 * API เชื่อมต่อระบบ Robot OPD MySQL (Read Only)
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();
include(__DIR__ . '/connect.php');
require_once __DIR__ . '/robot_db_helper.php';
mysqli_set_charset($con, 'utf8');

function robot_api_json(array $payload, $code = 200) {
    ob_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    robot_api_json(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], 401);
}

require_once __DIR__ . '/menu_permissions_helper.php';
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (
    !tham_menu_can('pharm_care.med_error')
    && !tham_menu_can('admin.robot')
    && !tham_menu_can('admin.hosxp')
) {
    robot_api_json(['status' => 'error', 'message' => 'ไม่มีสิทธิ์ตั้งค่า Robot OPD'], 403);
}
session_write_close();

robot_ensure_config($con);
$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'get'));

if ($action === 'get') {
    robot_api_json([
        'status' => 'success',
        'config' => robot_public_config(robot_load_config($con)),
    ]);
}

if ($action === 'save') {
    $cfg = robot_save_config($con, $input);
    robot_api_json([
        'status' => 'success',
        'message' => 'บันทึกการเชื่อมต่อ Robot OPD แล้ว',
        'config' => robot_public_config($cfg),
    ]);
}

if ($action === 'test') {
    $override = [];
    foreach (['robot_host', 'robot_port', 'robot_user', 'robot_db'] as $k) {
        if (isset($input[$k])) {
            $override[$k] = trim((string)$input[$k]);
        }
    }
    if (isset($input['robot_pass']) && (string)$input['robot_pass'] !== '' && (string)$input['robot_pass'] !== '********') {
        $override['robot_pass'] = (string)$input['robot_pass'];
    }
    $ping = robot_ping($con, $override ?: null);
    robot_api_json([
        'status' => $ping['ok'] ? 'success' : 'error',
        'message' => $ping['ok']
            ? ('เชื่อมต่อ Robot OPD สำเร็จ' . ($ping['db'] !== '' ? (' · ฐาน ' . $ping['db']) : ' · ยังไม่ได้เลือกฐานข้อมูล'))
            : ('เชื่อมต่อล้มเหลว: ' . ($ping['error'] ?: 'ไม่ทราบสาเหตุ')),
        'ping' => $ping,
    ]);
}

if ($action === 'tables') {
    $mysql_err = '';
    $robot = robot_connect($con, 20, null, $mysql_err);
    if (!$robot) {
        robot_api_json([
            'status' => 'error',
            'message' => $mysql_err ?: 'เชื่อมต่อ Robot OPD ไม่ได้',
            'tables' => [],
        ]);
    }
    $tables = robot_list_tables($robot, (string)($input['q'] ?? $_GET['q'] ?? ''), 120);
    robot_close($robot);
    robot_api_json(['status' => 'success', 'tables' => $tables]);
}

if ($action === 'preview') {
    $table = trim((string)($input['table'] ?? $_GET['table'] ?? ''));
    $mysql_err = '';
    $robot = robot_connect($con, 20, null, $mysql_err);
    if (!$robot) {
        robot_api_json([
            'status' => 'error',
            'message' => $mysql_err ?: 'เชื่อมต่อ Robot OPD ไม่ได้',
            'preview' => ['columns' => [], 'rows' => [], 'error' => 'เชื่อมต่อไม่ได้'],
        ]);
    }
    $preview = robot_preview_table($robot, $table, 20);
    robot_close($robot);
    robot_api_json(['status' => $preview['error'] === '' ? 'success' : 'error', 'preview' => $preview]);
}

robot_api_json(['status' => 'error', 'message' => 'ไม่รู้จักคำสั่ง'], 400);
