<?php
/**
 * เชื่อมฐานข้อมูลรพ. ต่างๆ ในจังหวัด (MySQL) แบบอ่านอย่างเดียว
 * รูปแบบคล้าย Grafana Data sources — ตั้งค่าแล้ว Explore ตาราง/คิวรี SELECT
 */

function hds_catalog() {
    return [
        ['code' => 'scph', 'name' => 'รพ.สมเด็จพระยุพราชสระแก้ว', 'grafana' => 'mysql-scph', 'host' => '192.168.65.2', 'username' => 'grafana', 'dbname' => 'hos'],
        ['code' => 'aran', 'name' => 'รพ.อรัญประเทศ', 'grafana' => 'mysql-aran', 'host' => 'mysql-arypt', 'username' => 'Grafana', 'dbname' => 'hos'],
        ['code' => 'kck', 'name' => 'รพ.เขาฉกรรจ์', 'grafana' => 'mysql-kck', 'host' => 'mysql-kck', 'username' => 'Grafana', 'dbname' => 'hos'],
        ['code' => 'khh', 'name' => 'รพ.คลองหาด', 'grafana' => 'mysql-khh', 'host' => 'mysql-khh', 'username' => 'Grafana', 'dbname' => 'hos'],
        ['code' => 'ksh', 'name' => 'รพ.โคกสูง', 'grafana' => 'mysql-ksh', 'host' => 'mysql-ksh', 'username' => 'Grafana', 'dbname' => 'hos28850'],
        ['code' => 'tpy', 'name' => 'รพ.ตาพระยา', 'grafana' => 'mysql-tpy', 'host' => 'mysql-tpy', 'username' => 'Grafana', 'dbname' => 'hos'],
        ['code' => 'wnh', 'name' => 'รพ.วัฒนานคร', 'grafana' => 'mysql-wnh', 'host' => 'mysql-wtn', 'username' => 'Grafana', 'dbname' => 'hos'],
        ['code' => 'wny', 'name' => 'รพ.วังน้ำเย็น', 'grafana' => 'mysql-wny', 'host' => 'mysql-wny', 'username' => 'Grafana', 'dbname' => 'hos'],
        ['code' => 'wsb', 'name' => 'รพ.วังสมบูรณ์', 'grafana' => 'mysql-wsb', 'host' => 'mysql-wsb', 'username' => 'grafana', 'dbname' => 'hos'],
    ];
}

function hds_grafana_cfg_defaults() {
    return [
        'url' => 'https://main.srakw.net',
        'user' => 'tum',
        'pass' => 'tum10699',
    ];
}

function hds_ensure_tables($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $ok = mysqli_query($con, "CREATE TABLE IF NOT EXISTS hospital_datasources (
        id INT AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(32) NOT NULL,
        name VARCHAR(191) NOT NULL,
        engine VARCHAR(16) NOT NULL DEFAULT 'mysql',
        host VARCHAR(191) NOT NULL DEFAULT '',
        port INT NOT NULL DEFAULT 3306,
        dbname VARCHAR(128) NOT NULL DEFAULT 'hos',
        username VARCHAR(128) NOT NULL DEFAULT '',
        password VARCHAR(255) NOT NULL DEFAULT '',
        grafana_uid VARCHAR(64) NOT NULL DEFAULT '',
        grafana_ds_uid VARCHAR(64) NOT NULL DEFAULT '',
        active TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        last_ok TINYINT(1) NULL DEFAULT NULL,
        last_ms INT NULL DEFAULT NULL,
        last_error VARCHAR(255) NOT NULL DEFAULT '',
        last_checked_at DATETIME NULL DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uk_hds_code (code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if ($ok) {
        $alters = [
            'grafana_uid' => "ALTER TABLE hospital_datasources ADD COLUMN grafana_uid VARCHAR(64) NOT NULL DEFAULT '' AFTER password",
            'grafana_ds_uid' => "ALTER TABLE hospital_datasources ADD COLUMN grafana_ds_uid VARCHAR(64) NOT NULL DEFAULT '' AFTER grafana_uid",
            'grafana_ds_id' => "ALTER TABLE hospital_datasources ADD COLUMN grafana_ds_id INT NOT NULL DEFAULT 0 AFTER grafana_ds_uid",
            'max_open' => "ALTER TABLE hospital_datasources ADD COLUMN max_open INT NOT NULL DEFAULT 200 AFTER grafana_ds_id",
            'max_idle' => "ALTER TABLE hospital_datasources ADD COLUMN max_idle INT NOT NULL DEFAULT 200 AFTER max_open",
            'max_idle_auto' => "ALTER TABLE hospital_datasources ADD COLUMN max_idle_auto TINYINT(1) NOT NULL DEFAULT 1 AFTER max_idle",
            'max_lifetime' => "ALTER TABLE hospital_datasources ADD COLUMN max_lifetime INT NOT NULL DEFAULT 14400 AFTER max_idle_auto",
            'session_tz' => "ALTER TABLE hospital_datasources ADD COLUMN session_tz VARCHAR(64) NOT NULL DEFAULT '' AFTER max_lifetime",
            'min_interval' => "ALTER TABLE hospital_datasources ADD COLUMN min_interval VARCHAR(16) NOT NULL DEFAULT '1m' AFTER session_tz",
            'connect_via' => "ALTER TABLE hospital_datasources ADD COLUMN connect_via VARCHAR(16) NOT NULL DEFAULT 'auto' AFTER min_interval",
        ];
        $added_pool = false;
        foreach ($alters as $colname => $ddl) {
            $col = @mysqli_query($con, "SHOW COLUMNS FROM hospital_datasources LIKE '" . mysqli_real_escape_string($con, $colname) . "'");
            if ($col && mysqli_num_rows($col) === 0) {
                mysqli_query($con, $ddl);
                if (in_array($colname, ['max_open', 'max_idle', 'max_lifetime'], true)) {
                    $added_pool = true;
                }
            }
        }
        hds_seed_defaults($con);
        hds_fill_from_catalog($con);
        hds_grafana_ensure_config($con);
        hds_connect_mode($con);
        hds_home_code($con);
        hds_hosxp_credentials($con);
        if ($added_pool) {
            hds_grafana_sync($con);
        }
    }
    $ready = (bool)$ok;
    return $ready;
}

function hds_seed_defaults($con) {
    $cnt = mysqli_query($con, 'SELECT COUNT(*) AS n FROM hospital_datasources');
    $row = $cnt ? mysqli_fetch_assoc($cnt) : null;
    if ($row && (int)$row['n'] > 0) {
        return;
    }
    $hos = [];
    $q = @mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ('h_host','h_db','h_user','h_pass')");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $hos[$r['config_name']] = (string)$r['config_value'];
        }
    }
    $i = 0;
    foreach (hds_catalog() as $item) {
        $i++;
        $host = '';
        $db = 'hos';
        $user = 'tum';
        $pass = 'tum10699';
        if ($item['code'] === 'scph') {
            if (!empty($hos['h_host'])) {
                $host = $hos['h_host'];
            }
            if (!empty($hos['h_db'])) {
                $db = $hos['h_db'];
            }
            if (!empty($hos['h_user'])) {
                $user = $hos['h_user'];
            }
            if (isset($hos['h_pass']) && $hos['h_pass'] !== '') {
                $pass = $hos['h_pass'];
            }
        }
        $code = mysqli_real_escape_string($con, $item['code']);
        $name = mysqli_real_escape_string($con, $item['name']);
        $g = mysqli_real_escape_string($con, $item['grafana']);
        $host_e = mysqli_real_escape_string($con, $host);
        $db_e = mysqli_real_escape_string($con, $db);
        $user_e = mysqli_real_escape_string($con, $user);
        $pass_e = mysqli_real_escape_string($con, $pass);
        mysqli_query($con, "INSERT INTO hospital_datasources
            (code, name, engine, host, port, dbname, username, password, grafana_uid, active, sort_order)
            VALUES ('$code','$name','mysql','$host_e',3306,'$db_e','$user_e','$pass_e','$g',1,$i)");
    }
}

function hds_fill_from_catalog($con) {
    foreach (hds_catalog() as $item) {
        $code = mysqli_real_escape_string($con, $item['code']);
        $host = mysqli_real_escape_string($con, $item['host'] ?? '');
        $user = mysqli_real_escape_string($con, $item['username'] ?? '');
        $db = mysqli_real_escape_string($con, $item['dbname'] ?? 'hos');
        $g = mysqli_real_escape_string($con, $item['grafana'] ?? '');
        $q = mysqli_query($con, "SELECT id, host, username, dbname FROM hospital_datasources WHERE code='$code' LIMIT 1");
        if (!$q || !($row = mysqli_fetch_assoc($q))) {
            continue;
        }
        $cur_host = trim((string)$row['host']);
        $cur_user = trim((string)$row['username']);
        $cur_db = trim((string)$row['dbname']);
        $sets = [];
        if ($item['code'] !== 'scph') {
            if ($cur_host === '' || stripos($cur_host, 'ยังไม่ได้') !== false) {
                $sets[] = "host='$host'";
            }
            if ($cur_user === '' || strtolower($cur_user) === 'tum') {
                $sets[] = "username='$user'";
            }
            if ($cur_db === '' || ($db !== '' && $cur_db === 'hos' && $db !== 'hos')) {
                $sets[] = "dbname='$db'";
            }
        } elseif ($cur_host === '') {
            $sets[] = "host='$host'";
        }
        if ($g !== '') {
            $sets[] = "grafana_uid='$g'";
        }
        if ($sets) {
            mysqli_query($con, 'UPDATE hospital_datasources SET ' . implode(',', $sets) . ' WHERE code=\'' . $code . '\' LIMIT 1');
        }
    }
}

function hds_grafana_ensure_config($con) {
    $defaults = hds_grafana_cfg_defaults();
    $map = [
        'hds_grafana_url' => $defaults['url'],
        'hds_grafana_user' => $defaults['user'],
        'hds_grafana_pass' => $defaults['pass'],
    ];
    foreach ($map as $key => $val) {
        $k = mysqli_real_escape_string($con, $key);
        $chk = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='$k' LIMIT 1");
        if (!$chk || mysqli_num_rows($chk) === 0) {
            $v = mysqli_real_escape_string($con, $val);
            mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k','$v')");
        }
    }
}

function hds_grafana_get_config($con) {
    hds_grafana_ensure_config($con);
    $cfg = hds_grafana_cfg_defaults();
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ('hds_grafana_url','hds_grafana_user','hds_grafana_pass')");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            if ($r['config_name'] === 'hds_grafana_url') {
                $cfg['url'] = rtrim((string)$r['config_value'], '/');
            } elseif ($r['config_name'] === 'hds_grafana_user') {
                $cfg['user'] = (string)$r['config_value'];
            } elseif ($r['config_name'] === 'hds_grafana_pass') {
                $cfg['pass'] = (string)$r['config_value'];
            }
        }
    }
    return $cfg;
}

function hds_grafana_save_config($con, array $in) {
    $cur = hds_grafana_get_config($con);
    $url = trim((string)($in['url'] ?? $cur['url']));
    $user = trim((string)($in['user'] ?? $cur['user']));
    $pass = $cur['pass'];
    if (isset($in['pass']) && (string)$in['pass'] !== '' && (string)$in['pass'] !== '********') {
        $pass = (string)$in['pass'];
    }
    $url = rtrim($url, '/');
    foreach (['hds_grafana_url' => $url, 'hds_grafana_user' => $user, 'hds_grafana_pass' => $pass] as $k => $v) {
        $kk = mysqli_real_escape_string($con, $k);
        $vv = mysqli_real_escape_string($con, $v);
        $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$kk' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            mysqli_query($con, "UPDATE sys_config SET config_value='$vv' WHERE config_name='$kk'");
        } else {
            mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$kk','$vv')");
        }
    }
    return hds_grafana_get_config($con);
}

function hds_grafana_public_config(array $cfg) {
    return [
        'url' => $cfg['url'] ?? '',
        'user' => $cfg['user'] ?? '',
        'pass' => (($cfg['pass'] ?? '') !== '') ? '********' : '',
        'has_pass' => (($cfg['pass'] ?? '') !== ''),
    ];
}

function hds_pool_defaults() {
    return [
        'max_open' => 200,
        'max_idle' => 200,
        'max_idle_auto' => 1,
        'max_lifetime' => 14400,
        'session_tz' => '',
        'min_interval' => '1m',
    ];
}

function hds_pool_from_input(array $in, array $cur = []) {
    $d = hds_pool_defaults();
    foreach ($d as $k => $v) {
        if (isset($cur[$k]) && $cur[$k] !== '' && $cur[$k] !== null) {
            $d[$k] = $k === 'session_tz' || $k === 'min_interval' ? (string)$cur[$k] : (int)$cur[$k];
        }
    }
    if (isset($in['max_open']) && $in['max_open'] !== '') {
        $d['max_open'] = max(0, (int)$in['max_open']);
    }
    if (array_key_exists('max_idle_auto', $in)) {
        $d['max_idle_auto'] = !empty($in['max_idle_auto']) ? 1 : 0;
    }
    if (isset($in['max_idle']) && $in['max_idle'] !== '') {
        $d['max_idle'] = max(0, (int)$in['max_idle']);
    }
    if (!empty($d['max_idle_auto'])) {
        $d['max_idle'] = $d['max_open'];
    }
    if (isset($in['max_lifetime']) && $in['max_lifetime'] !== '') {
        $d['max_lifetime'] = max(0, (int)$in['max_lifetime']);
    }
    if (isset($in['session_tz'])) {
        $d['session_tz'] = substr(trim((string)$in['session_tz']), 0, 64);
    }
    if (isset($in['min_interval'])) {
        $d['min_interval'] = substr(trim((string)$in['min_interval']), 0, 16);
        if ($d['min_interval'] === '') {
            $d['min_interval'] = '1m';
        }
    }
    return $d;
}

function hds_pool_from_grafana_json($jsonData) {
    $d = hds_pool_defaults();
    $jd = is_array($jsonData) ? $jsonData : [];
    if (isset($jd['maxOpenConns']) && $jd['maxOpenConns'] !== '') {
        $d['max_open'] = max(0, (int)$jd['maxOpenConns']);
    }
    if (array_key_exists('maxIdleConnsAuto', $jd)) {
        $d['max_idle_auto'] = !empty($jd['maxIdleConnsAuto']) ? 1 : 0;
    }
    if (isset($jd['maxIdleConns']) && $jd['maxIdleConns'] !== '') {
        $d['max_idle'] = max(0, (int)$jd['maxIdleConns']);
    }
    if (!empty($d['max_idle_auto'])) {
        $d['max_idle'] = $d['max_open'];
    }
    if (isset($jd['connMaxLifetime']) && $jd['connMaxLifetime'] !== '') {
        $d['max_lifetime'] = max(0, (int)$jd['connMaxLifetime']);
    }
    if (isset($jd['timezone'])) {
        $d['session_tz'] = substr(trim((string)$jd['timezone']), 0, 64);
    }
    if (!empty($jd['timeInterval'])) {
        $d['min_interval'] = substr(trim((string)$jd['timeInterval']), 0, 16);
    }
    return $d;
}

function hds_pool_sql_set($con, array $pool) {
    $tz = mysqli_real_escape_string($con, $pool['session_tz']);
    $iv = mysqli_real_escape_string($con, $pool['min_interval']);
    return 'max_open=' . (int)$pool['max_open']
        . ', max_idle=' . (int)$pool['max_idle']
        . ', max_idle_auto=' . (int)$pool['max_idle_auto']
        . ', max_lifetime=' . (int)$pool['max_lifetime']
        . ", session_tz='$tz', min_interval='$iv'";
}

function hds_grafana_cookie_file(array $cfg) {
    $base = rtrim((string)($cfg['url'] ?? ''), '/');
    $user = (string)($cfg['user'] ?? '');
    return sys_get_temp_dir() . '/hds_grafana_' . md5($base . '|' . $user) . '_' . getmypid() . '.ck';
}

function hds_grafana_auth_mode(array $cfg, $set = null) {
    static $mode = [];
    $key = rtrim((string)($cfg['url'] ?? ''), '/') . '|' . (string)($cfg['user'] ?? '');
    if ($set !== null) {
        $mode[$key] = (string)$set;
    }
    return $mode[$key] ?? '';
}

function hds_grafana_resolve_v4($base) {
    static $cache = [];
    $host = (string)parse_url($base, PHP_URL_HOST);
    if ($host === '') {
        return [];
    }
    if (array_key_exists($host, $cache)) {
        return $cache[$host];
    }
    $scheme = (string)(parse_url($base, PHP_URL_SCHEME) ?: 'https');
    $port = (int)(parse_url($base, PHP_URL_PORT) ?: ($scheme === 'https' ? 443 : 80));
    $ip = gethostbyname($host);
    if ($ip && $ip !== $host && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $cache[$host] = [$host . ':' . $port . ':' . $ip];
    } else {
        $cache[$host] = [];
    }
    return $cache[$host];
}

function hds_grafana_cookie_value($file, $name) {
    if ($file === '' || !is_readable($file)) {
        return '';
    }
    $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$lines) {
        return '';
    }
    foreach ($lines as $line) {
        if ($line === '' || $line[0] === '#') {
            continue;
        }
        $parts = explode("\t", $line);
        if (count($parts) >= 7 && strcasecmp((string)$parts[5], $name) === 0) {
            return (string)$parts[6];
        }
    }
    return '';
}

function hds_grafana_is_token($pass) {
    $pass = trim((string)$pass);
    return $pass !== '' && (strpos($pass, 'glsa_') === 0 || strpos($pass, 'eyJ') === 0);
}

function hds_grafana_curl_init($cfg, $method, $path, $body = null, array $opts = []) {
    $base = rtrim((string)($cfg['url'] ?? ''), '/');
    $url = $base . $path;
    $cookie = hds_grafana_cookie_file($cfg);
    $user = (string)($cfg['user'] ?? '');
    $pass = (string)($cfg['pass'] ?? '');
    $method = strtoupper((string)$method);
    $isApi = strpos($path, '/api/') === 0;
    $useBasic = !empty($opts['basic']) || (hds_grafana_auth_mode($cfg) === 'basic' && $isApi);
    $follow = array_key_exists('follow', $opts) ? !empty($opts['follow']) : !$isApi;
    $timeout = max(6, (int)($opts['timeout'] ?? ($isApi ? 20 : 12)));
    $ch = curl_init($url);
    $headers = [
        'Accept: application/json',
        'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Origin: ' . $base,
        'Referer: ' . $base . '/login',
    ];
    $csrf = hds_grafana_cookie_value($cookie, 'grafana_csrf');
    if ($csrf === '') {
        $csrf = hds_grafana_cookie_value($cookie, 'csrf_token');
    }
    if ($csrf !== '' && in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        $headers[] = 'X-Grafana-CSRF: ' . $csrf;
        $headers[] = 'X-CSRF-Token: ' . $csrf;
    }
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => $follow ? true : false,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_COOKIEFILE => $cookie,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_ENCODING => '',
        CURLOPT_NOSIGNAL => true,
    ]);
    if (empty($opts['no_jar'])) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
    }
    $resolve = hds_grafana_resolve_v4($base);
    if ($resolve) {
        curl_setopt($ch, CURLOPT_RESOLVE, $resolve);
    }
    if ($isApi && $user !== '' && $pass !== '') {
        if (hds_grafana_is_token($pass)) {
            $headers[] = 'Authorization: Bearer ' . $pass;
        } elseif ($useBasic) {
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, $user . ':' . $pass);
        }
    }
    if (in_array($method, ['POST', 'PUT', 'PATCH'], true)) {
        $headers[] = 'Content-Type: application/json';
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
        } else {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body === null ? '{}' : json_encode($body, JSON_UNESCAPED_UNICODE));
    } elseif ($method === 'DELETE') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    } else {
        curl_setopt($ch, CURLOPT_HTTPGET, true);
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    return $ch;
}

function hds_grafana_http_parse($ch, $raw) {
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    $ms = (int)round(((float)curl_getinfo($ch, CURLINFO_TOTAL_TIME)) * 1000);
    if ($raw === false) {
        $errText = 'เรียก Grafana ไม่ได้ (' . $code . '): ' . ($err !== '' ? $err : 'ไม่ตอบกลับ');
        if ($err !== '' && (stripos($err, 'timed out') !== false || stripos($err, 'timeout') !== false)) {
            $errText = 'หมดเวลาเชื่อม Grafana (' . max(1, (int)round($ms / 1000)) . ' วิ)';
        }
        return ['ok' => false, 'code' => $code, 'error' => $errText, 'json' => null, 'ms' => $ms];
    }
    $json = json_decode($raw, true);
    $errText = '';
    if ($code >= 400) {
        if (is_array($json) && !empty($json['message'])) {
            $errText = (string)$json['message'];
        } else {
            $errText = substr(trim(strip_tags((string)$raw)), 0, 180);
        }
    }
    return [
        'ok' => $code >= 200 && $code < 300,
        'code' => $code,
        'error' => $errText,
        'json' => $json,
        'raw' => $raw,
        'ms' => $ms,
    ];
}

function hds_grafana_http($cfg, $method, $path, $body = null, array $opts = []) {
    $ch = hds_grafana_curl_init($cfg, $method, $path, $body, $opts);
    $raw = curl_exec($ch);
    $out = hds_grafana_http_parse($ch, $raw);
    curl_close($ch);
    return $out;
}

/** ยิงหลายคิวรี Grafana พร้อมกัน (หนึ่ง datasource ต่องาน) */
function hds_grafana_query_multi($cfg, array $jobs, array $opt = []) {
    $out = [];
    if (!$jobs) {
        return $out;
    }
    $login = hds_grafana_login($cfg);
    if (empty($login['ok'])) {
        foreach ($jobs as $key => $_) {
            $out[$key] = ['ok' => false, 'error' => $login['error'], 'columns' => [], 'rows' => [], 'ms' => 0];
        }
        return $out;
    }
    $max_points = max(50, min(8000, (int)($opt['max_points'] ?? 800)));
    $timeout = max(8, min(45, (int)($opt['timeout'] ?? 22)));
    $mh = curl_multi_init();
    if (defined('CURLMOPT_MAX_TOTAL_CONNECTIONS')) {
        curl_multi_setopt($mh, CURLMOPT_MAX_TOTAL_CONNECTIONS, 10);
    }
    if (defined('CURLMOPT_MAX_HOST_CONNECTIONS')) {
        curl_multi_setopt($mh, CURLMOPT_MAX_HOST_CONNECTIONS, 10);
    }
    $handles = [];
    foreach ($jobs as $key => $job) {
        $uid = trim((string)($job['uid'] ?? ''));
        $sql = (string)($job['sql'] ?? '');
        if ($uid === '' || $sql === '') {
            $out[$key] = ['ok' => false, 'error' => 'ไม่มี UID หรือ SQL', 'columns' => [], 'rows' => [], 'ms' => 0];
            continue;
        }
        $payload = [
            'from' => 'now-5m',
            'to' => 'now',
            'queries' => [[
                'refId' => 'A',
                'datasource' => ['type' => 'mysql', 'uid' => $uid],
                'rawSql' => $sql,
                'format' => 'table',
                'rawQuery' => true,
                'editorMode' => 'code',
                'intervalMs' => 1000,
                'maxDataPoints' => $max_points,
            ]],
        ];
        $ch = hds_grafana_curl_init($cfg, 'POST', '/api/ds/query', $payload, [
            'timeout' => $timeout,
            'no_jar' => true,
        ]);
        curl_multi_add_handle($mh, $ch);
        $handles[$key] = $ch;
    }
    $running = 0;
    $status = CURLM_OK;
    if ($handles) {
        $status = curl_multi_exec($mh, $running);
    }
    $during = (isset($opt['during']) && is_callable($opt['during'])) ? $opt['during'] : null;
    if ($during) {
        $during();
    }
    if ($handles) {
        while ($running && $status === CURLM_OK) {
            curl_multi_select($mh, 0.25);
            $status = curl_multi_exec($mh, $running);
        }
    }

    foreach ($handles as $key => $ch) {
        $raw = curl_multi_getcontent($ch);
        $http = hds_grafana_http_parse($ch, $raw === false ? false : $raw);
        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
        if (empty($http['ok'])) {
            $detail = trim((string)($http['error'] ?? ''));
            $msg = 'คิวรีผ่าน Grafana ไม่สำเร็จ (' . ($http['code'] ?? 0) . ')' . ($detail !== '' ? ': ' . $detail : '');
            $out[$key] = ['ok' => false, 'error' => $msg, 'columns' => [], 'rows' => [], 'ms' => (int)($http['ms'] ?? 0)];
            continue;
        }
        $parsed = hds_grafana_parse_frames($http['json']);
        $parsed['ok'] = empty($parsed['error']);
        $parsed['ms'] = (int)($http['ms'] ?? 0);
        $out[$key] = $parsed;
    }
    curl_multi_close($mh);
    return $out;
}

function hds_grafana_login($cfg) {
    static $ok = [];
    $key = rtrim((string)($cfg['url'] ?? ''), '/') . '|' . (string)($cfg['user'] ?? '');
    if (!empty($ok[$key])) {
        return ['ok' => true, 'error' => ''];
    }
    if (hds_grafana_is_token((string)($cfg['pass'] ?? ''))) {
        $probe = hds_grafana_http($cfg, 'GET', '/api/user', null, ['timeout' => 12]);
        if (!empty($probe['ok'])) {
            hds_grafana_auth_mode($cfg, 'token');
            $ok[$key] = true;
            return ['ok' => true, 'error' => ''];
        }
        $detail = trim((string)($probe['error'] ?? ''));
        return ['ok' => false, 'error' => 'Service Account token ใช้กับ Grafana ไม่ได้ (' . $probe['code'] . ')' . ($detail !== '' ? ': ' . $detail : '')];
    }

    $login = hds_grafana_http($cfg, 'POST', '/login', [
        'user' => $cfg['user'] ?? '',
        'password' => $cfg['pass'] ?? '',
    ], ['follow' => false, 'timeout' => 12]);
    if ((int)$login['code'] === 0) {
        return ['ok' => false, 'error' => $login['error'] . ' — เครื่องนี้ต่อ https://main.srakw.net ไม่ทัน (IPv6/HTTP2/Cloudflare)'];
    }
    if (!empty($login['ok'])) {
        $me = hds_grafana_http($cfg, 'GET', '/api/user', null, ['timeout' => 12]);
        if (!empty($me['ok'])) {
            hds_grafana_auth_mode($cfg, 'cookie');
            $ok[$key] = true;
            return ['ok' => true, 'error' => ''];
        }
    }

    $basic = hds_grafana_http($cfg, 'GET', '/api/user', null, ['basic' => true, 'timeout' => 12]);
    if (!empty($basic['ok'])) {
        hds_grafana_auth_mode($cfg, 'basic');
        $ok[$key] = true;
        return ['ok' => true, 'error' => ''];
    }

    $parts = [];
    if (!empty($login['error'])) {
        $parts[] = 'ล็อกอินเว็บ (' . $login['code'] . '): ' . $login['error'];
    }
    if (!empty($basic['error'])) {
        $parts[] = 'Basic Auth (' . $basic['code'] . '): ' . $basic['error'];
    }
    $hint = $parts ? implode(' · ', $parts) : 'ยืนยันตัวตน Grafana ไม่สำเร็จ';
    if ((int)$login['code'] === 401 || (int)$basic['code'] === 401) {
        $hint .= ' — ตรวจ user/pass หรือใส่ Service Account token ในช่องรหัส';
    }
    return ['ok' => false, 'error' => $hint];
}

function hds_grafana_sync($con) {
    $cfg = hds_grafana_get_config($con);
    $login = hds_grafana_login($cfg);
    if (empty($login['ok'])) {
        return ['ok' => false, 'error' => $login['error'], 'updated' => 0];
    }
    $res = hds_grafana_http($cfg, 'GET', '/api/datasources');
    if (!$res['ok'] || !is_array($res['json'])) {
        return ['ok' => false, 'error' => 'ดึงรายการ Data sources จาก Grafana ไม่ได้', 'updated' => 0];
    }
    $by_name = [];
    foreach ($res['json'] as $ds) {
        if (($ds['type'] ?? '') !== 'mysql') {
            continue;
        }
        $by_name[strtolower((string)($ds['name'] ?? ''))] = $ds;
    }
    $n = 0;
    foreach (hds_catalog() as $item) {
        $gname = strtolower($item['grafana']);
        if (!isset($by_name[$gname])) {
            continue;
        }
        $ds = $by_name[$gname];
        $code = mysqli_real_escape_string($con, $item['code']);
        $uid = mysqli_real_escape_string($con, (string)($ds['uid'] ?? ''));
        $g = mysqli_real_escape_string($con, $item['grafana']);
        $gid = (int)($ds['id'] ?? 0);
        $pool = hds_pool_from_grafana_json($ds['jsonData'] ?? []);
        $pool_sql = hds_pool_sql_set($con, $pool);
        $q = mysqli_query($con, "SELECT id, host, username FROM hospital_datasources WHERE code='$code' LIMIT 1");
        if (!$q || mysqli_num_rows($q) === 0) {
            continue;
        }
        $cur = mysqli_fetch_assoc($q);
        // รพ.สระแก้วใช้ phpapi ตรงกับ HOSxP อยู่แล้ว — เก็บแค่ UID / pool ของ Grafana
        if ($item['code'] === 'scph' && hds_host_is_direct($cur['host'] ?? '')) {
            mysqli_query($con, "UPDATE hospital_datasources
                SET grafana_uid='$g', grafana_ds_uid='$uid', grafana_ds_id=$gid, $pool_sql
                WHERE code='$code' LIMIT 1");
        } else {
            $host = mysqli_real_escape_string($con, (string)($ds['url'] ?? $item['host']));
            $user = mysqli_real_escape_string($con, (string)($ds['user'] ?? $item['username']));
            $dbName = (string)(($ds['database'] ?? '') ?: (($ds['jsonData']['database'] ?? '') ?: $item['dbname']));
            $db = mysqli_real_escape_string($con, $dbName);
            mysqli_query($con, "UPDATE hospital_datasources
                SET host='$host', username='$user', dbname='$db', grafana_uid='$g', grafana_ds_uid='$uid', grafana_ds_id=$gid, $pool_sql
                WHERE code='$code' LIMIT 1");
        }
        $n++;
    }
    return ['ok' => true, 'error' => '', 'updated' => $n];
}

function hds_grafana_update_pool($con, array $row, array $pool) {
    $uid = trim((string)($row['grafana_ds_uid'] ?? ''));
    if ($uid === '') {
        return ['ok' => true, 'skipped' => true, 'error' => ''];
    }
    $cfg = hds_grafana_get_config($con);
    $login = hds_grafana_login($cfg);
    if (empty($login['ok'])) {
        return ['ok' => false, 'skipped' => false, 'error' => $login['error']];
    }
    $path = '/api/datasources/uid/' . rawurlencode($uid);
    $get = hds_grafana_http($cfg, 'GET', $path);
    if (empty($get['ok']) || !is_array($get['json'])) {
        return ['ok' => false, 'skipped' => false, 'error' => 'อ่าน datasource จาก Grafana ไม่ได้'];
    }
    $ds = $get['json'];
    $json = is_array($ds['jsonData'] ?? null) ? $ds['jsonData'] : [];
    $json['maxOpenConns'] = (int)$pool['max_open'];
    $json['maxIdleConns'] = (int)$pool['max_idle'];
    $json['maxIdleConnsAuto'] = !empty($pool['max_idle_auto']);
    $json['connMaxLifetime'] = (int)$pool['max_lifetime'];
    if (($pool['session_tz'] ?? '') !== '') {
        $json['timezone'] = $pool['session_tz'];
    } else {
        unset($json['timezone']);
    }
    if (($pool['min_interval'] ?? '') !== '') {
        $json['timeInterval'] = $pool['min_interval'];
    }
    $payload = [
        'id' => (int)($ds['id'] ?? 0),
        'uid' => (string)($ds['uid'] ?? $uid),
        'orgId' => (int)($ds['orgId'] ?? 1),
        'name' => (string)($ds['name'] ?? ''),
        'type' => (string)($ds['type'] ?? 'mysql'),
        'access' => (string)($ds['access'] ?? 'proxy'),
        'url' => (string)($ds['url'] ?? ''),
        'user' => (string)($ds['user'] ?? ''),
        'database' => (string)($ds['database'] ?? ''),
        'basicAuth' => !empty($ds['basicAuth']),
        'isDefault' => !empty($ds['isDefault']),
        'jsonData' => $json,
        'version' => (int)($ds['version'] ?? 0),
    ];
    $put = hds_grafana_http($cfg, 'PUT', $path, $payload);
    if (empty($put['ok'])) {
        $detail = trim((string)($put['error'] ?? ''));
        return ['ok' => false, 'skipped' => false, 'error' => 'อัปเดต Grafana ไม่สำเร็จ (' . $put['code'] . ')' . ($detail !== '' ? ': ' . $detail : '')];
    }
    return ['ok' => true, 'skipped' => false, 'error' => ''];
}

function hds_grafana_query($cfg, $uid, $sql, array $opt = []) {
    $login = hds_grafana_login($cfg);
    if (empty($login['ok'])) {
        return ['ok' => false, 'error' => $login['error'], 'columns' => [], 'rows' => []];
    }
    $max_points = max(50, min(8000, (int)($opt['max_points'] ?? 200)));
    $timeout = max(8, min(45, (int)($opt['timeout'] ?? 20)));
    $payload = [
        'from' => 'now-5m',
        'to' => 'now',
        'queries' => [[
            'refId' => 'A',
            'datasource' => ['type' => 'mysql', 'uid' => $uid],
            'rawSql' => $sql,
            'format' => 'table',
            'rawQuery' => true,
            'editorMode' => 'code',
            'intervalMs' => 1000,
            'maxDataPoints' => $max_points,
        ]],
    ];
    $http_opt = ['timeout' => $timeout];
    $res = hds_grafana_http($cfg, 'POST', '/api/ds/query', $payload, $http_opt);
    if (!$res['ok'] && (int)$res['code'] === 401 && hds_grafana_auth_mode($cfg) !== 'basic') {
        hds_grafana_auth_mode($cfg, 'basic');
        $res = hds_grafana_http($cfg, 'POST', '/api/ds/query', $payload, $http_opt + ['basic' => true]);
    }
    if (!$res['ok']) {
        $detail = trim((string)($res['error'] ?? ''));
        $msg = 'คิวรีผ่าน Grafana ไม่สำเร็จ (' . $res['code'] . ')' . ($detail !== '' ? ': ' . $detail : '');
        if ((int)$res['code'] === 401) {
            $msg .= ' — บัญชี Grafana ไม่มีสิทธิ์เรียก API หรือ Basic Auth ถูกปิด ให้ใส่ Service Account token';
        }
        return ['ok' => false, 'error' => $msg, 'columns' => [], 'rows' => []];
    }
    $parsed = hds_grafana_parse_frames($res['json']);
    $parsed['ok'] = empty($parsed['error']);
    return $parsed;
}

function hds_grafana_parse_frames($json) {
    $out = ['columns' => [], 'rows' => [], 'error' => ''];
    $block = $json['results']['A'] ?? null;
    if (!$block) {
        $out['error'] = 'Grafana ไม่ส่งผลลัพธ์';
        return $out;
    }
    if (!empty($block['error'])) {
        $out['error'] = (string)$block['error'];
        return $out;
    }
    $frame = $block['frames'][0] ?? null;
    if (!$frame) {
        return $out;
    }
    $fields = $frame['schema']['fields'] ?? [];
    $values = $frame['data']['values'] ?? [];
    foreach ($fields as $f) {
        $out['columns'][] = (string)($f['name'] ?? '');
    }
    $nrows = 0;
    foreach ($values as $col) {
        $nrows = max($nrows, is_array($col) ? count($col) : 0);
    }
    for ($i = 0; $i < $nrows; $i++) {
        $row = [];
        foreach ($out['columns'] as $ci => $name) {
            $v = $values[$ci][$i] ?? null;
            $row[$name] = hds_cell($v, 0);
        }
        $out['rows'][] = $row;
    }
    return $out;
}

function hds_host_is_direct($host) {
    $host = trim((string)$host);
    return $host !== '' && (filter_var($host, FILTER_VALIDATE_IP) !== false);
}

function hds_host_can_connect($host) {
    $host = trim((string)$host);
    if ($host === '') {
        return false;
    }
    if (filter_var($host, FILTER_VALIDATE_IP) !== false) {
        return true;
    }
    $ip = @gethostbyname($host);
    return is_string($ip) && $ip !== '' && $ip !== $host;
}

/** direct = เฉพาะ Host ที่เป็น IP · mysql = ใช้ Host/User/Password ที่บันทึกไว้ทุกโรงพยาบาล · grafana = ผ่าน Grafana ทั้งหมด */
function hds_connect_mode($con = null, $set = null) {
    static $mode = null;
    $allowed = ['direct', 'mysql', 'grafana'];
    if (in_array($set, $allowed, true)) {
        $mode = $set;
        return $mode;
    }
    if ($con) {
        $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='hds_connect_mode' LIMIT 1");
        $v = ($q && ($r = mysqli_fetch_assoc($q))) ? trim((string)$r['config_value']) : '';
        $mode = in_array($v, $allowed, true) ? $v : 'direct';
        return $mode;
    }
    return $mode ?: 'direct';
}

function hds_connect_mode_save($con, $mode) {
    $mode = in_array($mode, ['direct', 'mysql', 'grafana'], true) ? $mode : 'direct';
    $vv = mysqli_real_escape_string($con, $mode);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='hds_connect_mode' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        mysqli_query($con, "UPDATE sys_config SET config_value='$vv' WHERE config_name='hds_connect_mode'");
    } else {
        mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('hds_connect_mode','$vv')");
    }
    return hds_connect_mode($con, $mode);
}

function hds_connect_via_norm($raw) {
    $v = strtolower(trim((string)$raw));
    return in_array($v, ['auto', 'direct', 'grafana'], true) ? $v : 'auto';
}

function hds_route_is_grafana(array $row = []) {
    $via = hds_connect_via_norm($row['connect_via'] ?? 'auto');
    if ($via === 'grafana') {
        return true;
    }
    if ($via === 'direct') {
        return false;
    }
    if (hds_connect_mode() === 'grafana') {
        return true;
    }
    if (hds_connect_mode() === 'mysql') {
        return trim((string)($row['host'] ?? '')) === '';
    }
    return !hds_host_is_direct($row['host'] ?? '');
}

function hds_home_code($con = null, $set = null) {
    static $code = null;
    if (is_string($set)) {
        $code = hds_norm_code($set);
        return $code !== '' ? $code : 'scph';
    }
    if ($con) {
        $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='hds_home_code' LIMIT 1");
        $v = ($q && ($r = mysqli_fetch_assoc($q))) ? hds_norm_code($r['config_value']) : '';
        $code = $v !== '' ? $v : 'scph';
        return $code;
    }
    return $code ?: 'scph';
}

function hds_home_code_save($con, $code) {
    $code = hds_norm_code($code);
    if ($code === '') {
        $code = 'scph';
    }
    $e = mysqli_real_escape_string($con, $code);
    $q = mysqli_query($con, "SELECT id FROM hospital_datasources WHERE code='$e' LIMIT 1");
    if (!$q || mysqli_num_rows($q) === 0) {
        $code = 'scph';
        $e = 'scph';
    }
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='hds_home_code' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        mysqli_query($con, "UPDATE sys_config SET config_value='$e' WHERE config_name='hds_home_code'");
    } else {
        mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('hds_home_code','$e')");
    }
    return hds_home_code($con, $code);
}

function hds_hosxp_credentials($con = null) {
    static $cfg = null;
    if ($con) {
        $cfg = ['host' => '', 'dbname' => '', 'username' => '', 'password' => ''];
        $q = @mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ('h_host','h_db','h_user','h_pass')");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                if ($r['config_name'] === 'h_host') {
                    $cfg['host'] = trim((string)$r['config_value']);
                } elseif ($r['config_name'] === 'h_db') {
                    $cfg['dbname'] = trim((string)$r['config_value']);
                } elseif ($r['config_name'] === 'h_user') {
                    $cfg['username'] = trim((string)$r['config_value']);
                } elseif ($r['config_name'] === 'h_pass') {
                    $cfg['password'] = (string)$r['config_value'];
                }
            }
        }
    }
    return $cfg ?: ['host' => '', 'dbname' => '', 'username' => '', 'password' => ''];
}

function hds_is_home_row(array $row) {
    $code = strtolower(trim((string)($row['code'] ?? '')));
    return $code !== '' && $code === hds_home_code();
}

function hds_apply_home_credentials($con, array $row) {
    if (!hds_is_home_row($row)) {
        return $row;
    }
    $cfg = hds_hosxp_credentials($con);
    if ($cfg['host'] === '' || $cfg['username'] === '') {
        return $row;
    }
    $row['host'] = $cfg['host'];
    $row['port'] = 3306;
    if ($cfg['dbname'] !== '') {
        $row['dbname'] = $cfg['dbname'];
    }
    $row['username'] = $cfg['username'];
    $row['password'] = $cfg['password'];
    return $row;
}

function hds_set_connect_via($con, $id, $via) {
    hds_ensure_tables($con);
    $id = (int)$id;
    $via = hds_connect_via_norm($via);
    $row = hds_get($con, $id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบแหล่งข้อมูล', 'item' => null];
    }
    $v = mysqli_real_escape_string($con, $via);
    mysqli_query($con, "UPDATE hospital_datasources SET connect_via='$v' WHERE id=$id LIMIT 1");
    $fresh = hds_get($con, $id);
    return ['ok' => true, 'error' => '', 'item' => $fresh ? hds_public_row($fresh) : null];
}

function hds_list($con, $q = '') {
    hds_ensure_tables($con);
    $sql = 'SELECT id, code, name, engine, host, port, dbname, username, grafana_uid, grafana_ds_uid, grafana_ds_id,
                   max_open, max_idle, max_idle_auto, max_lifetime, session_tz, min_interval, connect_via,
                   active, sort_order, last_ok, last_ms, last_error, last_checked_at, updated_at
            FROM hospital_datasources';
    $q = trim($q);
    if ($q !== '') {
        $like = mysqli_real_escape_string($con, '%' . $q . '%');
        $sql .= " WHERE code LIKE '$like' OR name LIKE '$like' OR host LIKE '$like' OR dbname LIKE '$like' OR grafana_uid LIKE '$like'";
    }
    $sql .= ' ORDER BY sort_order ASC, name ASC';
    $res = mysqli_query($con, $sql);
    $out = [];
    if ($res) {
        while ($r = mysqli_fetch_assoc($res)) {
            $out[] = hds_public_row($r);
        }
    }
    return $out;
}

function hds_get($con, $id) {
    hds_ensure_tables($con);
    $id = (int)$id;
    $q = mysqli_query($con, "SELECT * FROM hospital_datasources WHERE id=$id LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function hds_public_row(array $r) {
    $via = hds_route_is_grafana($r) ? 'grafana' : 'direct';
    $is_home = hds_is_home_row($r);
    $uses_hosxp = false;
    if ($is_home && $via === 'direct') {
        $cfg = hds_hosxp_credentials();
        if ($cfg['host'] !== '' && $cfg['username'] !== '') {
            $r['host'] = $cfg['host'];
            $r['port'] = 3306;
            if ($cfg['dbname'] !== '') {
                $r['dbname'] = $cfg['dbname'];
            }
            $r['username'] = $cfg['username'];
            $r['password'] = $cfg['password'];
            $uses_hosxp = true;
        }
    }
    return [
        'id' => (int)($r['id'] ?? 0),
        'code' => (string)($r['code'] ?? ''),
        'name' => (string)($r['name'] ?? ''),
        'engine' => (string)($r['engine'] ?? 'mysql'),
        'host' => (string)($r['host'] ?? ''),
        'port' => (int)($r['port'] ?? 3306),
        'dbname' => (string)($r['dbname'] ?? ''),
        'username' => (string)($r['username'] ?? ''),
        'password' => (!empty($r['password']) ? '********' : ''),
        'has_password' => (($r['password'] ?? '') !== ''),
        'grafana_uid' => (string)($r['grafana_uid'] ?? ''),
        'grafana_ds_uid' => (string)($r['grafana_ds_uid'] ?? ''),
        'grafana_ds_id' => (int)($r['grafana_ds_id'] ?? 0),
        'max_open' => (int)($r['max_open'] ?? 200),
        'max_idle' => (int)($r['max_idle'] ?? 200),
        'max_idle_auto' => (int)($r['max_idle_auto'] ?? 1),
        'max_lifetime' => (int)($r['max_lifetime'] ?? 14400),
        'session_tz' => (string)($r['session_tz'] ?? ''),
        'min_interval' => (string)(($r['min_interval'] ?? '') !== '' ? $r['min_interval'] : '1m'),
        'connect_via' => hds_connect_via_norm($r['connect_via'] ?? 'auto'),
        'via' => $via,
        'is_home' => $is_home,
        'uses_hosxp_setting' => $uses_hosxp,
        'active' => (int)($r['active'] ?? 1),
        'sort_order' => (int)($r['sort_order'] ?? 0),
        'last_ok' => isset($r['last_ok']) && $r['last_ok'] !== null ? (int)$r['last_ok'] : null,
        'last_ms' => isset($r['last_ms']) && $r['last_ms'] !== null ? (int)$r['last_ms'] : null,
        'last_error' => (string)($r['last_error'] ?? ''),
        'last_checked_at' => (string)($r['last_checked_at'] ?? ''),
        'updated_at' => (string)($r['updated_at'] ?? ''),
    ];
}

function hds_norm_code($raw) {
    $s = strtolower(trim((string)$raw));
    $s = preg_replace('/[^a-z0-9_\-]/', '', $s);
    return substr($s, 0, 32);
}

function hds_save($con, array $in) {
    hds_ensure_tables($con);
    $id = (int)($in['id'] ?? 0);
    $code = hds_norm_code($in['code'] ?? '');
    $name = trim((string)($in['name'] ?? ''));
    $host = trim((string)($in['host'] ?? ''));
    $port = (int)($in['port'] ?? 3306);
    if ($port <= 0) {
        $port = 3306;
    }
    $db = trim((string)($in['dbname'] ?? 'hos'));
    if ($db === '') {
        $db = 'hos';
    }
    $user = trim((string)($in['username'] ?? ''));
    $grafana = trim((string)($in['grafana_uid'] ?? ''));
    $active = !empty($in['active']) ? 1 : 0;
    $sort = (int)($in['sort_order'] ?? 0);
    if ($code === '' || $name === '') {
        return ['ok' => false, 'error' => 'กรอกรหัสและชื่อรพ. ให้ครบ'];
    }
    $cur = $id > 0 ? hds_get($con, $id) : null;
    $pass = $cur['password'] ?? '';
    if (array_key_exists('password', $in)) {
        $p = (string)$in['password'];
        if ($p !== '' && $p !== '********') {
            $pass = $p;
        }
    }
    $code_e = mysqli_real_escape_string($con, $code);
    $name_e = mysqli_real_escape_string($con, $name);
    $host_e = mysqli_real_escape_string($con, $host);
    $db_e = mysqli_real_escape_string($con, $db);
    $user_e = mysqli_real_escape_string($con, $user);
    $pass_e = mysqli_real_escape_string($con, $pass);
    $g_e = mysqli_real_escape_string($con, $grafana);
    $pool = hds_pool_from_input($in, $cur ?: []);
    $pool_sql = hds_pool_sql_set($con, $pool);
    $via = hds_connect_via_norm($in['connect_via'] ?? ($cur['connect_via'] ?? 'auto'));
    $via_e = mysqli_real_escape_string($con, $via);
    if ($id > 0) {
        $dup = mysqli_query($con, "SELECT id FROM hospital_datasources WHERE code='$code_e' AND id<>$id LIMIT 1");
        if ($dup && mysqli_num_rows($dup) > 0) {
            return ['ok' => false, 'error' => 'รหัสนี้ถูกใช้แล้ว'];
        }
        $ok = mysqli_query($con, "UPDATE hospital_datasources SET
            code='$code_e', name='$name_e', host='$host_e', port=$port, dbname='$db_e',
            username='$user_e', password='$pass_e', grafana_uid='$g_e', active=$active, sort_order=$sort,
            connect_via='$via_e', $pool_sql
            WHERE id=$id");
        if (!$ok) {
            return ['ok' => false, 'error' => mysqli_error($con) ?: 'บันทึกไม่ได้'];
        }
        $fresh = hds_get($con, $id);
        $push = ['ok' => true, 'skipped' => true, 'error' => ''];
        $changed = !$cur || (int)($cur['max_open'] ?? 0) !== (int)$pool['max_open']
            || (int)($cur['max_idle'] ?? 0) !== (int)$pool['max_idle']
            || (int)($cur['max_idle_auto'] ?? 0) !== (int)$pool['max_idle_auto']
            || (int)($cur['max_lifetime'] ?? 0) !== (int)$pool['max_lifetime']
            || (string)($cur['session_tz'] ?? '') !== (string)$pool['session_tz']
            || (string)($cur['min_interval'] ?? '') !== (string)$pool['min_interval'];
        if ($changed) {
            $push = hds_grafana_update_pool($con, $fresh ?: [], $pool);
        }
        $row = hds_public_row($fresh ?: []);
        if (empty($push['ok'])) {
            return ['ok' => true, 'row' => $row, 'warning' => $push['error']];
        }
        return ['ok' => true, 'row' => $row];
    }
    $dup = mysqli_query($con, "SELECT id FROM hospital_datasources WHERE code='$code_e' LIMIT 1");
    if ($dup && mysqli_num_rows($dup) > 0) {
        return ['ok' => false, 'error' => 'รหัสนี้ถูกใช้แล้ว'];
    }
    $ok = mysqli_query($con, "INSERT INTO hospital_datasources
        (code, name, engine, host, port, dbname, username, password, grafana_uid, active, sort_order, connect_via,
         max_open, max_idle, max_idle_auto, max_lifetime, session_tz, min_interval)
        VALUES ('$code_e','$name_e','mysql','$host_e',$port,'$db_e','$user_e','$pass_e','$g_e',$active,$sort,'$via_e',
         " . (int)$pool['max_open'] . ',' . (int)$pool['max_idle'] . ',' . (int)$pool['max_idle_auto'] . ',' . (int)$pool['max_lifetime'] . ",
         '" . mysqli_real_escape_string($con, $pool['session_tz']) . "','" . mysqli_real_escape_string($con, $pool['min_interval']) . "')");
    if (!$ok) {
        return ['ok' => false, 'error' => mysqli_error($con) ?: 'บันทึกไม่ได้'];
    }
    $nid = (int)mysqli_insert_id($con);
    return ['ok' => true, 'row' => hds_public_row(hds_get($con, $nid))];
}

function hds_delete($con, $id) {
    $id = (int)$id;
    if ($id < 1) {
        return false;
    }
    return (bool)mysqli_query($con, "DELETE FROM hospital_datasources WHERE id=$id LIMIT 1");
}

function hds_touch($con, $id, $ok, $ms, $error = '') {
    $id = (int)$id;
    $okv = $ok ? 1 : 0;
    $ms = (int)$ms;
    $err = mysqli_real_escape_string($con, substr((string)$error, 0, 255));
    mysqli_query($con, "UPDATE hospital_datasources
        SET last_ok=$okv, last_ms=$ms, last_error='$err', last_checked_at=NOW()
        WHERE id=$id");
}

function hds_is_readonly_sql($sql) {
    $sql = trim((string)$sql);
    if ($sql === '') {
        return false;
    }
    $sql = preg_replace('/^\s*\/\*.*?\*\//s', '', $sql);
    $sql = preg_replace('/^\s*--[^\n]*\n/', '', $sql);
    $sql = ltrim($sql);
    if (!preg_match('/^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN|WITH)\b/i', $sql)) {
        return false;
    }
    if (preg_match('/\b(INSERT|UPDATE|DELETE|REPLACE|ALTER|DROP|CREATE|TRUNCATE|GRANT|REVOKE|LOAD\s+DATA|INTO\s+OUTFILE|INTO\s+DUMPFILE|FOR\s+UPDATE)\b/i', $sql)) {
        return false;
    }
    return true;
}

function hds_ident($name) {
    $name = trim((string)$name);
    if ($name === '' || !preg_match('/^[A-Za-z0-9_]+$/', $name)) {
        return null;
    }
    return '`' . $name . '`';
}

function hds_is_sensitive_column($name, $type = '') {
    $n = strtolower((string)$name);
    $t = strtolower((string)$type);
    if (strpos($t, 'blob') !== false || strpos($t, 'binary') !== false) {
        return true;
    }
    $needles = ['password', 'passwd', 'pass_hash', 'hash', 'token', 'secret', 'otp', 'cid', 'salary', 'finger', 'licen'];
    foreach ($needles as $w) {
        if (strpos($n, $w) !== false) {
            return true;
        }
    }
    return false;
}

function hds_last_error($set = null) {
    static $err = '';
    if ($set !== null) {
        $err = (string)$set;
    }
    return $err;
}

function hds_connect_row(array $row, $read_timeout = 12) {
    hds_last_error('');
    $host = trim((string)($row['host'] ?? ''));
    $user = trim((string)($row['username'] ?? ''));
    $pass = (string)($row['password'] ?? '');
    $db = trim((string)($row['dbname'] ?? ''));
    $port = (int)($row['port'] ?? 3306);
    if ($host === '' || $user === '') {
        hds_last_error('ยังไม่ได้ใส่ Host / Username');
        return null;
    }
    if ($port <= 0) {
        $port = 3306;
    }
    mysqli_report(MYSQLI_REPORT_OFF);
    $c = mysqli_init();
    if (!$c) {
        hds_last_error('สร้างการเชื่อมต่อไม่ได้');
        return null;
    }
    $read_timeout = max(5, min(60, (int)$read_timeout));
    mysqli_options($c, MYSQLI_OPT_CONNECT_TIMEOUT, 8);
    if (defined('MYSQLI_OPT_READ_TIMEOUT')) {
        mysqli_options($c, MYSQLI_OPT_READ_TIMEOUT, $read_timeout);
    }
    $ok = $db !== ''
        ? @mysqli_real_connect($c, $host, $user, $pass, $db, $port)
        : @mysqli_real_connect($c, $host, $user, $pass, '', $port);
    if (!$ok) {
        $err = mysqli_connect_error() ?: 'เชื่อมต่อไม่ได้';
        if (stripos($err, 'getaddrinfo') !== false || stripos($err, 'name or service not known') !== false || stripos($err, 'php_network_getaddresses') !== false) {
            $err = 'เครื่องเว็บนี้หา Host "' . $host . '" ไม่เจอ ชื่อนี้ใช้ได้ในเครือข่าย Grafana ให้ใส่ IP ที่เครื่องนี้เข้าถึงได้ หรือตั้งช่องทางกลับเป็นผ่าน Grafana';
        }
        hds_last_error($err);
        return null;
    }
    mysqli_set_charset($c, 'utf8mb4');
    @mysqli_query($c, 'SET SESSION TRANSACTION READ ONLY');
    @mysqli_query($c, 'SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED');
    return $c;
}

function hds_connect($con, $id, $read_timeout = 12, array $override = null) {
    $row = hds_get($con, $id);
    if (!$row) {
        hds_last_error('ไม่พบแหล่งข้อมูล');
        return null;
    }
    if ($override) {
        foreach (['host', 'port', 'dbname', 'username'] as $k) {
            if (isset($override[$k]) && (string)$override[$k] !== '') {
                $row[$k] = $override[$k];
            }
        }
        if (isset($override['password']) && $override['password'] !== '' && $override['password'] !== '********') {
            $row['password'] = $override['password'];
        }
    }
    hds_connect_mode($con);
    if (!hds_route_is_grafana($row)) {
        $row = hds_apply_home_credentials($con, $row);
    }
    return hds_connect_row($row, $read_timeout);
}

function hds_query($db, $sql) {
    if (!$db || !hds_is_readonly_sql($sql)) {
        return false;
    }
    return @mysqli_query($db, $sql);
}

function hds_close($db) {
    if ($db) {
        @mysqli_close($db);
    }
}

function hds_grafana_uid_for($con, array $row) {
    $uid = trim((string)($row['grafana_ds_uid'] ?? ''));
    if ($uid !== '') {
        return $uid;
    }
    $sync = hds_grafana_sync($con);
    if (empty($sync['ok'])) {
        return '';
    }
    $fresh = hds_get($con, (int)$row['id']);
    return trim((string)($fresh['grafana_ds_uid'] ?? ''));
}

function hds_ping($con, $id, array $override = null) {
    $t0 = microtime(true);
    $row = hds_get($con, $id);
    $out = [
        'ok' => false,
        'ms' => 0,
        'id' => (int)$id,
        'host' => (string)($row['host'] ?? ''),
        'port' => (int)($row['port'] ?? 3306),
        'dbname' => (string)($row['dbname'] ?? ''),
        'username' => (string)($row['username'] ?? ''),
        'version' => '',
        'table_count' => 0,
        'error' => '',
        'readonly' => true,
        'via' => 'direct',
    ];
    if (!$row) {
        $out['error'] = 'ไม่พบแหล่งข้อมูล';
        return $out;
    }
    $probe = $row;
    if ($override && isset($override['host']) && trim((string)$override['host']) !== '') {
        $probe['host'] = $override['host'];
    }
    hds_connect_mode($con);
    if (hds_route_is_grafana($probe)) {
        $cfg = hds_grafana_get_config($con);
        $uid = hds_grafana_uid_for($con, $row ?: []);
        $sql = 'SELECT DATABASE() AS db, VERSION() AS ver, (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE()) AS tc';
        $q = $uid !== '' ? hds_grafana_query($cfg, $uid, $sql) : ['ok' => false, 'error' => 'ยังไม่มี UID ของ Grafana'];
        $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
        $out['via'] = 'grafana';
        if (empty($q['ok'])) {
            $out['error'] = $q['error'] ?? 'เชื่อมผ่าน Grafana ไม่ได้';
            hds_touch($con, $id, false, $out['ms'], $out['error']);
            return $out;
        }
        if (!empty($q['rows'][0]['db'])) {
            $out['dbname'] = (string)$q['rows'][0]['db'];
        }
        if (!empty($q['rows'][0]['ver'])) {
            $out['version'] = (string)$q['rows'][0]['ver'];
        }
        $out['table_count'] = (int)($q['rows'][0]['tc'] ?? 0);
        $out['ok'] = true;
        hds_touch($con, $id, true, $out['ms'], '');
        $fresh = hds_get($con, $id);
        if ($fresh) {
            $out['host'] = (string)$fresh['host'];
            $out['username'] = (string)$fresh['username'];
            $out['dbname'] = (string)$fresh['dbname'] ?: $out['dbname'];
        }
        return $out;
    }
    $db = hds_connect($con, $id, 10, $override);
    $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
    if (!$db) {
        $out['error'] = hds_last_error() ?: 'เชื่อมต่อไม่ได้';
        hds_touch($con, $id, false, $out['ms'], $out['error']);
        return $out;
    }
    $info = hds_query($db, 'SELECT DATABASE() AS db, VERSION() AS ver');
    if ($info && ($r = mysqli_fetch_assoc($info))) {
        $out['version'] = (string)($r['ver'] ?? '');
        if (!empty($r['db'])) {
            $out['dbname'] = (string)$r['db'];
        }
    }
    $tc = hds_query($db, 'SHOW TABLES');
    $out['table_count'] = $tc ? (int)mysqli_num_rows($tc) : 0;
    $out['ok'] = true;
    hds_close($db);
    hds_touch($con, $id, true, $out['ms'], '');
    return $out;
}

function hds_explore_sql($con, $id, $sql, $dbn = '') {
    if (!hds_is_readonly_sql($sql)) {
        return ['ok' => false, 'error' => 'อนุญาตเฉพาะ SELECT / SHOW / DESCRIBE', 'columns' => [], 'rows' => []];
    }
    $row = hds_get($con, $id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบแหล่งข้อมูล', 'columns' => [], 'rows' => []];
    }
    hds_connect_mode($con);
    if (hds_route_is_grafana($row)) {
        $cfg = hds_grafana_get_config($con);
        $uid = hds_grafana_uid_for($con, $row);
        if ($uid === '') {
            return ['ok' => false, 'error' => 'ยังซิงก์ UID จาก Grafana ไม่ได้ กดปุ่มซิงก์ที่หน้าเชื่อมต่อรพ.', 'columns' => [], 'rows' => []];
        }
        $q = hds_grafana_query($cfg, $uid, $sql);
        $rows = $q['rows'] ?? [];
        foreach ($rows as &$r0) {
            foreach ($r0 as $k => $v) {
                if (hds_is_sensitive_column($k, '')) {
                    $r0[$k] = '••••';
                }
            }
        }
        unset($r0);
        return [
            'ok' => !empty($q['ok']),
            'error' => $q['error'] ?? '',
            'columns' => $q['columns'] ?? [],
            'rows' => $rows,
            'via' => 'grafana',
        ];
    }
    $db = hds_connect($con, $id, 20);
    if (!$db) {
        return ['ok' => false, 'error' => hds_last_error() ?: 'เชื่อมต่อไม่ได้', 'columns' => [], 'rows' => []];
    }
    if ($dbn !== '') {
        hds_use_db($db, $dbn);
    }
    $st = hds_query($db, $sql);
    if (!$st) {
        $err = mysqli_error($db) ?: 'คิวรีไม่สำเร็จ';
        hds_close($db);
        return ['ok' => false, 'error' => $err, 'columns' => [], 'rows' => []];
    }
    if ($st === true) {
        hds_close($db);
        return ['ok' => true, 'error' => '', 'columns' => [], 'rows' => [], 'via' => 'direct'];
    }
    $headers = [];
    $fields = mysqli_fetch_fields($st);
    if ($fields) {
        foreach ($fields as $f) {
            $headers[] = (string)$f->name;
        }
    }
    $rows = [];
    $n = 0;
    while ($r = mysqli_fetch_assoc($st)) {
        $rowv = [];
        foreach ($headers as $h) {
            $rowv[$h] = hds_is_sensitive_column($h, '') ? '••••' : hds_cell($r[$h] ?? null);
        }
        $rows[] = $rowv;
        $n++;
        if ($n >= 200) {
            break;
        }
    }
    hds_close($db);
    return ['ok' => true, 'error' => '', 'columns' => $headers, 'rows' => $rows, 'via' => 'direct'];
}

function hds_list_databases($db) {
    $q = hds_query($db, 'SHOW DATABASES');
    $out = [];
    $skip = ['information_schema', 'performance_schema', 'mysql', 'sys'];
    if ($q) {
        while ($r = mysqli_fetch_row($q)) {
            $name = (string)($r[0] ?? '');
            if ($name === '' || in_array(strtolower($name), $skip, true)) {
                continue;
            }
            $out[] = $name;
        }
    }
    if (empty($out)) {
        $cur = hds_query($db, 'SELECT DATABASE() AS db');
        if ($cur && ($r = mysqli_fetch_assoc($cur)) && !empty($r['db'])) {
            $out[] = (string)$r['db'];
        }
    }
    return $out;
}

function hds_use_db($db, $name) {
    $ident = hds_ident($name);
    if (!$ident) {
        return false;
    }
    return (bool)@mysqli_select_db($db, $name);
}

function hds_list_tables($db, $q = '', $limit = 200) {
    $limit = max(1, min(400, (int)$limit));
    $res = hds_query($db, 'SHOW TABLES');
    if (!$res) {
        return [];
    }
    $q = trim(mb_strtolower($q, 'UTF-8'));
    $preferred = ['ovst', 'opdscreen', 'ipt', 'patient', 'opduser', 'lab_head', 'lab_order', 'drugitems', 'opitemrece'];
    $first = [];
    $rest = [];
    while ($row = mysqli_fetch_row($res)) {
        $name = (string)($row[0] ?? '');
        if ($name === '') {
            continue;
        }
        if ($q !== '' && mb_strpos(mb_strtolower($name, 'UTF-8'), $q) === false) {
            continue;
        }
        if (in_array($name, $preferred, true)) {
            $first[] = $name;
        } else {
            $rest[] = $name;
        }
    }
    return array_slice(array_merge($first, $rest), 0, $limit);
}

function hds_describe_table($db, $table) {
    $ident = hds_ident($table);
    if (!$ident) {
        return [];
    }
    $q = hds_query($db, "SHOW COLUMNS FROM $ident");
    if (!$q) {
        return [];
    }
    $cols = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $name = (string)($r['Field'] ?? '');
        $type = (string)($r['Type'] ?? '');
        $cols[] = [
            'name' => $name,
            'type' => $type,
            'null' => (string)($r['Null'] ?? ''),
            'key' => (string)($r['Key'] ?? ''),
            'sensitive' => hds_is_sensitive_column($name, $type),
        ];
    }
    return $cols;
}

function hds_cell($v, $max_len = 200) {
    if ($v === null) {
        return null;
    }
    if (is_resource($v)) {
        return '[binary]';
    }
    $s = (string)$v;
    if ($max_len > 0 && strlen($s) > $max_len) {
        if (function_exists('mb_strcut')) {
            return mb_strcut($s, 0, $max_len, 'UTF-8') . '…';
        }
        return substr($s, 0, $max_len) . '…';
    }
    return $s;
}

function hds_preview_table($db, $table, $limit = 30) {
    $ident = hds_ident($table);
    if (!$ident) {
        return ['columns' => [], 'rows' => [], 'error' => 'ชื่อตารางไม่ถูกต้อง'];
    }
    $cols = hds_describe_table($db, $table);
    if (empty($cols)) {
        return ['columns' => [], 'rows' => [], 'error' => 'ไม่พบตารางนี้ หรืออ่านโครงสร้างไม่ได้'];
    }
    $select = [];
    $headers = [];
    foreach ($cols as $c) {
        if (!empty($c['sensitive'])) {
            continue;
        }
        $colIdent = hds_ident($c['name']);
        if (!$colIdent) {
            continue;
        }
        $select[] = $colIdent;
        $headers[] = $c['name'];
        if (count($select) >= 16) {
            break;
        }
    }
    if (empty($select)) {
        return ['columns' => [], 'rows' => [], 'error' => 'คอลัมน์ที่แสดงได้ถูกซ่อนเพราะเป็นข้อมูลอ่อนไหว'];
    }
    $limit = max(1, min(100, (int)$limit));
    $st = hds_query($db, 'SELECT ' . implode(', ', $select) . ' FROM ' . $ident . ' LIMIT ' . $limit);
    if (!$st) {
        return ['columns' => $headers, 'rows' => [], 'error' => 'อ่านข้อมูลไม่ได้'];
    }
    $rows = [];
    while ($r = mysqli_fetch_assoc($st)) {
        $row = [];
        foreach ($headers as $h) {
            $row[$h] = hds_cell($r[$h] ?? null);
        }
        $rows[] = $row;
    }
    $cnt = hds_query($db, "SELECT COUNT(*) AS c FROM $ident");
    $total = null;
    if ($cnt && ($cr = mysqli_fetch_assoc($cnt))) {
        $total = (int)$cr['c'];
    }
    return ['columns' => $headers, 'rows' => $rows, 'error' => '', 'total' => $total];
}

function hds_run_select($db, $sql, $limit = 100) {
    $sql = trim((string)$sql);
    if (!hds_is_readonly_sql($sql)) {
        return ['columns' => [], 'rows' => [], 'error' => 'อนุญาตเฉพาะ SELECT / SHOW / DESCRIBE'];
    }
    if (strlen($sql) > 4000) {
        return ['columns' => [], 'rows' => [], 'error' => 'คำสั่งยาวเกินไป'];
    }
    if (preg_match('/^(SELECT|WITH)\b/i', $sql) && !preg_match('/\bLIMIT\s+\d+/i', $sql)) {
        $limit = max(1, min(200, (int)$limit));
        $sql = rtrim($sql, " \t\n\r;") . ' LIMIT ' . $limit;
    }
    $st = hds_query($db, $sql);
    if (!$st) {
        return ['columns' => [], 'rows' => [], 'error' => mysqli_error($db) ?: 'คิวรีไม่สำเร็จ'];
    }
    if ($st === true) {
        return ['columns' => [], 'rows' => [], 'error' => '', 'message' => 'สำเร็จ (ไม่มีแถวผลลัพธ์)'];
    }
    $headers = [];
    $fields = mysqli_fetch_fields($st);
    if ($fields) {
        foreach ($fields as $f) {
            $headers[] = (string)$f->name;
        }
    }
    $rows = [];
    $n = 0;
    while ($r = mysqli_fetch_assoc($st)) {
        $row = [];
        foreach ($headers as $h) {
            if (hds_is_sensitive_column($h, '')) {
                $row[$h] = '••••';
            } else {
                $row[$h] = hds_cell($r[$h] ?? null);
            }
        }
        $rows[] = $row;
        $n++;
        if ($n >= 200) {
            break;
        }
    }
    return ['columns' => $headers, 'rows' => $rows, 'error' => ''];
}

function hds_sql_th($expr) {
    return 'HEX(CAST(CONVERT(' . $expr . ' USING utf8) AS BINARY))';
}

function hds_unhex_utf8($s) {
    $s = strtoupper(preg_replace('/\s+/', '', (string)$s));
    if ($s === '') {
        return '';
    }
    if (ctype_xdigit($s) && (strlen($s) % 2) === 0) {
        $bin = @hex2bin($s);
        if ($bin !== false && $bin !== '') {
            return hds_thai_text($bin);
        }
    }
    return hds_thai_text($s);
}

function hds_thai_text($s) {
    $s = trim((string)$s);
    if ($s === '') {
        return '';
    }
    if (preg_match('/[\x{0E00}-\x{0E7F}]/u', $s) && strpos($s, 'à¸') === false && strpos($s, 'à¹') === false) {
        return $s;
    }
    if (strpos($s, 'à¸') !== false || strpos($s, 'à¹') !== false) {
        $raw = @iconv('UTF-8', 'ISO-8859-1//IGNORE', $s);
        if (is_string($raw) && $raw !== '' && preg_match('/[\x{0E00}-\x{0E7F}]/u', $raw)) {
            return trim($raw);
        }
    }
    if (preg_match('/[\x{0E00}-\x{0E7F}]/u', $s)) {
        return $s;
    }
    $asTis = @iconv('TIS-620', 'UTF-8//IGNORE', $s);
    if (is_string($asTis) && $asTis !== '' && preg_match('/[\x{0E00}-\x{0E7F}]/u', $asTis)) {
        return trim($asTis);
    }
    $latin = @iconv('UTF-8', 'ISO-8859-1//IGNORE', $s);
    if (is_string($latin) && $latin !== '') {
        $fromTis = @iconv('TIS-620', 'UTF-8//IGNORE', $latin);
        if (is_string($fromTis) && $fromTis !== '' && preg_match('/[\x{0E00}-\x{0E7F}]/u', $fromTis)) {
            return trim($fromTis);
        }
        if (preg_match('/[\x{0E00}-\x{0E7F}]/u', $latin)) {
            return trim($latin);
        }
    }
    return $s;
}

function hds_sql_quote($s) {
    return "'" . str_replace(['\\', "'"], ['\\\\', "''"], (string)$s) . "'";
}

function hds_lookback_months($raw, $default = 12) {
    $n = (int)$raw;
    $allowed = [0, 3, 6, 12, 36, 60];
    return in_array($n, $allowed, true) ? $n : $default;
}

function hds_lookback_labels() {
    return [
        3 => '3 เดือน',
        6 => '6 เดือน',
        12 => '1 ปี',
        36 => '3 ปี',
        60 => '5 ปี',
        0 => 'ทั้งหมด',
    ];
}

function hds_lookback_label($months) {
    $m = hds_lookback_months($months, 12);
    $labels = hds_lookback_labels();
    return $labels[$m] ?? ($m > 0 ? $m . ' เดือน' : 'ทั้งหมด');
}

function hds_lookback_options_html($selected = 12) {
    $selected = hds_lookback_months($selected, 12);
    $html = '';
    foreach (hds_lookback_labels() as $val => $label) {
        $sel = ((int)$val === $selected) ? ' selected' : '';
        $html .= '<option value="' . (int)$val . '"' . $sel . '>' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</option>';
    }
    return $html;
}

function hds_format_duration_ms($ms) {
    $ms = max(0, (int)$ms);
    if ($ms < 1000) {
        return $ms . ' ms';
    }
    return number_format($ms / 1000, 1, '.', '') . ' วินาที';
}

function hds_patient_lookup_sql($cid, array $hn_variants) {
    $cid = preg_replace('/\D+/', '', (string)$cid);
    // HN ของแต่ละ รพ. ไม่ใช่คนเดียวกัน — มีเลขบัตรแล้วห้ามจับคู่ด้วย HN
    if (strlen($cid) === 13) {
        return 'SELECT hn FROM patient WHERE cid = ' . hds_sql_quote($cid) . ' LIMIT 1';
    }
    $parts = [];
    $in = [];
    foreach ($hn_variants as $v) {
        $v = trim((string)$v);
        if ($v !== '') {
            $in[] = hds_sql_quote($v);
        }
    }
    if ($in) {
        $parts[] = 'hn IN (' . implode(',', $in) . ')';
    }
    if (!$parts) {
        return 'SELECT hn FROM patient WHERE 0=1 LIMIT 1';
    }
    return 'SELECT hn FROM patient WHERE ' . implode(' OR ', $parts) . ' LIMIT 1';
}

function hds_row_hn(array $res) {
    if (empty($res['ok'])) {
        return '';
    }
    $row = $res['rows'][0] ?? [];
    return trim((string)($row['hn'] ?? $row['matched_hn'] ?? ''));
}

function hds_patient_match_sql($cid, array $hn_variants, $alias = 'p') {
    $parts = [];
    $cid = preg_replace('/\D+/', '', (string)$cid);
    if (strlen($cid) === 13) {
        return "($alias.cid = " . hds_sql_quote($cid) . ')';
    }
    $in = [];
    foreach ($hn_variants as $v) {
        $v = trim((string)$v);
        if ($v !== '') {
            $in[] = hds_sql_quote($v);
        }
    }
    if ($in) {
        $parts[] = "$alias.hn IN (" . implode(',', $in) . ")";
    }
    return $parts ? '(' . implode(' OR ', $parts) . ')' : '0=1';
}

function hds_date_filter_sql($column, $months) {
    $months = (int)$months;
    if ($months <= 0) {
        return '';
    }
    return ' AND ' . $column . ' >= DATE_SUB(CURDATE(), INTERVAL ' . $months . ' MONTH)';
}

function hds_active_sources($con) {
    hds_ensure_tables($con);
    $q = mysqli_query($con, "SELECT * FROM hospital_datasources WHERE active = 1 ORDER BY sort_order ASC, name ASC");
    $out = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $out[] = $r;
        }
    }
    return $out;
}

function hds_local_hosxp_host($con) {
    $q = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = 'h_host' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return trim((string)$r['config_value']);
    }
    return '';
}

function hds_is_local_source($con, array $row, $local_host = null) {
    if ($local_host === null) {
        $local_host = hds_local_hosxp_host($con);
    }
    $host = trim((string)($row['host'] ?? ''));
    hds_home_code($con);
    if (hds_is_home_row($row)) {
        return true;
    }
    if ($local_host !== '' && $host !== '' && strcasecmp($host, $local_host) === 0) {
        return true;
    }
    return false;
}

/** คิวรีอ่านอย่างเดียว — ตรง MySQL ถ้าเป็น IP, ไม่เช่นนั้นผ่าน Grafana */
function hds_query_sql($con, array $row, $sql, array $opt = []) {
    if (!hds_is_readonly_sql($sql)) {
        return ['ok' => false, 'error' => 'อนุญาตเฉพาะ SELECT', 'rows' => [], 'via' => ''];
    }
    $timeout = max(8, min(40, (int)($opt['timeout'] ?? 18)));
    $max_points = max(50, min(8000, (int)($opt['max_points'] ?? 2000)));
    hds_connect_mode($con);
    $via_grafana = hds_route_is_grafana($row);
    $row = hds_apply_home_credentials($con, $row);
    if (!$via_grafana && !hds_host_can_connect($row['host'] ?? '')) {
        $via_grafana = true;
    }
    if ($via_grafana) {
        $uid = trim((string)($row['grafana_ds_uid'] ?? ''));
        if ($uid === '') {
            return ['ok' => false, 'error' => 'ยังไม่มี UID Grafana — กดซิงก์ที่หน้าเชื่อมต่อรพ.', 'rows' => [], 'via' => 'grafana'];
        }
        $cfg = hds_grafana_get_config($con);
        $q = hds_grafana_query($cfg, $uid, $sql, ['max_points' => $max_points, 'timeout' => $timeout]);
        return [
            'ok' => !empty($q['ok']),
            'error' => (string)($q['error'] ?? ''),
            'rows' => $q['rows'] ?? [],
            'via' => 'grafana',
        ];
    }
    $db = hds_connect_row($row, $timeout);
    if (!$db) {
        $uid = trim((string)($row['grafana_ds_uid'] ?? ''));
        if ($uid !== '') {
            $cfg = hds_grafana_get_config($con);
            $q = hds_grafana_query($cfg, $uid, $sql, ['max_points' => $max_points, 'timeout' => $timeout]);
            if (!empty($q['ok'])) {
                return [
                    'ok' => true,
                    'error' => '',
                    'rows' => $q['rows'] ?? [],
                    'via' => 'grafana',
                ];
            }
        }
        return ['ok' => false, 'error' => hds_last_error() ?: 'เชื่อมต่อไม่ได้', 'rows' => [], 'via' => 'direct'];
    }
    $st = hds_query($db, $sql);
    if (!$st) {
        $err = mysqli_error($db) ?: 'คิวรีไม่สำเร็จ';
        hds_close($db);
        return ['ok' => false, 'error' => $err, 'rows' => [], 'via' => 'direct'];
    }
    $rows = [];
    $cap = $max_points;
    while ($r = mysqli_fetch_assoc($st)) {
        $rows[] = $r;
        if (count($rows) >= $cap) {
            break;
        }
    }
    hds_close($db);
    return ['ok' => true, 'error' => '', 'rows' => $rows, 'via' => 'direct'];
}

function hds_norm_sql_date($v) {
    if ($v === null || $v === '') {
        return '';
    }
    if (is_numeric($v)) {
        $n = (float)$v;
        if ($n > 20000000000) {
            $n = $n / 1000;
        }
        if ($n > 1000000000) {
            return date('Y-m-d', (int)$n);
        }
    }
    $s = trim((string)$v);
    if ($s === '' || $s === '0000-00-00') {
        return '';
    }
    if (preg_match('/^(\d{4}-\d{2}-\d{2})/', $s, $m)) {
        return $m[1];
    }
    $ts = strtotime($s);
    return $ts ? date('Y-m-d', $ts) : '';
}

function hds_norm_sql_time($v) {
    if ($v === null || $v === '') {
        return '';
    }
    $s = trim((string)$v);
    if (preg_match('/(\d{1,2}:\d{2}(?::\d{2})?)/', $s, $m)) {
        $p = explode(':', $m[1]);
        return sprintf('%02d:%02d:%02d', (int)$p[0], (int)($p[1] ?? 0), (int)($p[2] ?? 0));
    }
    if (is_numeric($v) && (float)$v > 1000000000) {
        $n = (float)$v;
        if ($n > 20000000000) {
            $n = $n / 1000;
        }
        return date('H:i:s', (int)$n);
    }
    return substr($s, 0, 8);
}

function hds_fetch_network_patient(callable $q, $cid, array $hn_variants) {
    $cid = preg_replace('/\D+/', '', (string)$cid);
    if (strlen($cid) === 13) {
        $sql = 'SELECT hn FROM patient WHERE cid = ' . hds_sql_quote($cid) . ' LIMIT 1';
        $res = $q($sql);
        if (empty($res['ok'])) {
            return ['hn' => '', 'error' => (string)($res['error'] ?? 'ค้นหาผู้ป่วยไม่สำเร็จ')];
        }
        if (!empty($res['rows'][0]['hn'])) {
            return ['hn' => trim((string)$res['rows'][0]['hn']), 'error' => ''];
        }
        return ['hn' => '', 'error' => ''];
    }
    $in = [];
    foreach ($hn_variants as $v) {
        $v = trim((string)$v);
        if ($v !== '') {
            $in[] = hds_sql_quote($v);
        }
    }
    if (!$in) {
        return ['hn' => '', 'error' => ''];
    }
    $sql = 'SELECT hn FROM patient WHERE hn IN (' . implode(',', $in) . ') LIMIT 1';
    $res = $q($sql);
    if (empty($res['ok'])) {
        return ['hn' => '', 'error' => (string)($res['error'] ?? 'ค้นหาผู้ป่วยไม่สำเร็จ')];
    }
    if (!empty($res['rows'][0]['hn'])) {
        return ['hn' => trim((string)$res['rows'][0]['hn']), 'error' => ''];
    }
    return ['hn' => '', 'error' => ''];
}

/**
 * ประวัติยาจากรพ.ในเครือข่าย — ค้น HN ก่อน (เบา) แล้วดึงยาเฉพาะรพ.ที่พบ แบบขนาน
 */
function hds_smart_drug_by_hn_sql($hn, $months, $limit) {
    $hn_esc = hds_sql_quote($hn);
    $date_sql = hds_date_filter_sql('o.vstdate', $months);
    $limit = max(50, min(800, (int)$limit));
    // กฎเดียวกับรพ.ท้องถิ่น: drug_name = TMT (active_ingredient + strength), drug_name_local = drugitems.name
    $name_local = hds_sql_th('d.name');
    $name_tmt = hds_sql_th(
        "COALESCE(NULLIF(TRIM(CONCAT(IFNULL(tm.active_ingredient,''),' ',IFNULL(tm.strength,''))),''), d.name)"
    );
    $strength = hds_sql_th("COALESCE(NULLIF(TRIM(tm.strength),''), IFNULL(d.strength,''))");
    $strength_local = hds_sql_th("IFNULL(d.strength,'')");
    $units = hds_sql_th("IFNULL(d.units,'')");
    $tpu = "TRIM(IFNULL(d.tpu_code_list,'')) AS tpu_code";
    $continuous = "IFNULL(d.continuous,'') AS continuous";
    $method = hds_sql_th(
        "IF(o.sp_use IS NOT NULL AND o.sp_use <> '',
            CONCAT(IFNULL(sp.name1,''),' ',IFNULL(sp.name2,''),' ',IFNULL(sp.name3,'')),
            CONCAT(IFNULL(du.name1,''),' ',IFNULL(du.name2,''),' ',IFNULL(du.name3,''))
         )"
    );
    return "SELECT o.vn, o.an, o.vstdate, o.vsttime, o.rxdate, o.rxtime, o.order_no, o.item_type, o.item_no,
                   o.icode, o.qty,
                   $name_local AS drug_name_local,
                   $name_tmt AS drug_name,
                   $strength AS strength,
                   $strength_local AS strength_local,
                   $units AS units,
                   $tpu,
                   $continuous,
                   $method AS method,
                   o.hn AS matched_hn
            FROM opitemrece o
            INNER JOIN drugitems d ON d.icode = o.icode
            LEFT JOIN tmt_tpu_code tm ON d.tpu_code_list = tm.tpu_code
            LEFT JOIN drugusage du ON du.drugusage = o.drugusage
            LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
            WHERE o.hn = $hn_esc
              $date_sql
            ORDER BY o.vstdate DESC, o.vsttime DESC, o.item_no ASC
            LIMIT $limit";
}

function hds_smart_lab_by_hn_sql($hn, $months, $limit) {
    $hn_esc = hds_sql_quote($hn);
    $date_sql = hds_date_filter_sql('h.order_date', $months);
    $limit = max(20, min(120, (int)$limit));
    $form_name = hds_sql_th("IFNULL(h.form_name,'')") . ' AS form_name';
    return "SELECT h.lab_order_number, h.order_date, h.order_time, h.hn AS matched_hn, $form_name
            FROM lab_head h
            WHERE h.hn = $hn_esc
              AND h.confirm_report = 'Y'
              $date_sql
            ORDER BY h.order_date DESC, h.order_time DESC
            LIMIT $limit";
}

function hds_split_remote_sources($con) {
    $local_host = hds_local_hosxp_host($con);
    hds_connect_mode($con);
    $grafana = [];
    $direct = [];
    $skipped = [];
    foreach (hds_active_sources($con) as $row) {
        if (hds_is_local_source($con, $row, $local_host)) {
            continue;
        }
        $code = (string)($row['code'] ?? '');
        if (!hds_route_is_grafana($row)) {
            $probe = hds_apply_home_credentials($con, $row);
            if (hds_host_can_connect($probe['host'] ?? '')) {
                $direct[$code] = $probe;
                continue;
            }
        }
        $uid = trim((string)($row['grafana_ds_uid'] ?? ''));
        if ($uid === '') {
            $skipped[] = $row;
            continue;
        }
        $grafana[$code] = $row;
    }
    return [$grafana, $direct, $skipped];
}

function hds_grafana_fill_ms(array $multi, $wall) {
    foreach ($multi as $k => $res) {
        if (empty($res['ms'])) {
            $multi[$k]['ms'] = $wall;
        }
    }
    return $multi;
}

function hds_source_stub(array $row) {
    $code = (string)($row['code'] ?? '');
    return [
        'code' => $code,
        'name' => (string)($row['name'] ?? $code),
        'ok' => false,
        'via' => hds_route_is_grafana($row) ? 'grafana' : 'direct',
        'matched_hn' => '',
        'rows' => 0,
        'visits' => 0,
        'error' => '',
        'ms' => 0,
    ];
}

function hds_merge_smart_drug_result(array &$out, array $row, array $res, $limit) {
    $item = hds_source_stub($row);
    $item['ms'] = (int)($res['ms'] ?? 0);
    $item['via'] = $res['via'] ?? $item['via'];
    if (empty($res['ok'])) {
        $item['error'] = $res['error'] ?? 'คิวรีไม่สำเร็จ';
        $out['sources'][] = $item;
        return;
    }
    $item['ok'] = true;
    $rows = $res['rows'] ?? [];
    if ($rows) {
        $item['matched_hn'] = trim((string)($rows[0]['matched_hn'] ?? ''));
    }
    $packed = hds_pack_smart_drug_rows($rows, $item['code'], $item['name'], $limit);
    $item['rows'] = count($packed['history']);
    $item['visits'] = count($packed['visits']);
    foreach ($packed['history'] as $h) {
        $out['history'][] = $h;
    }
    foreach ($packed['visits'] as $v) {
        $out['visits'][] = $v;
    }
    $out['sources'][] = $item;
}

/**
 * ประวัติยาจากรพ.ในเครือข่าย — Grafana ยิงขนาน, รพ.ที่เป็น IP ดึงตรง
 */
function hds_fetch_smart_drug_network($con, array $hn_variants, $cid, $months, $limit_each = 400, $during = null) {
    $out = ['sources' => [], 'history' => [], 'visits' => [], 'appointments' => []];
    $ran_during = false;
    $run_during = function () use (&$during, &$ran_during) {
        if ($ran_during || !is_callable($during)) {
            return;
        }
        $ran_during = true;
        $during();
    };
    list($grafana_rows, $direct, $skipped) = hds_split_remote_sources($con);
    foreach ($skipped as $row) {
        $item = hds_source_stub($row);
        $item['error'] = 'ยังไม่มี UID Grafana — กดซิงก์ที่หน้าเชื่อมต่อรพ.';
        $out['sources'][] = $item;
    }
    if (!$grafana_rows && !$direct) {
        $run_during();
        return $out;
    }
    $months = hds_lookback_months($months, 12);
    $limit_each = max(50, min(800, (int)$limit_each));
    $lookup_sql = hds_patient_lookup_sql($cid, $hn_variants);
    $cfg = $grafana_rows ? hds_grafana_get_config($con) : null;

    $lookup_jobs = [];
    foreach ($grafana_rows as $code => $row) {
        $lookup_jobs[$code] = ['uid' => $row['grafana_ds_uid'], 'sql' => $lookup_sql];
    }
    $lookup_res = [];
    if ($lookup_jobs) {
        $t0 = microtime(true);
        $lookup_res = hds_grafana_query_multi($cfg, $lookup_jobs, [
            'timeout' => 8,
            'max_points' => 4,
            'during' => $run_during,
        ]);
        $lookup_res = hds_grafana_fill_ms($lookup_res, (int)round((microtime(true) - $t0) * 1000));
    }
    $run_during();

    $phase2 = [];
    foreach ($grafana_rows as $code => $row) {
        $res = $lookup_res[$code] ?? ['ok' => false, 'error' => 'ไม่มีผลลัพธ์', 'rows' => [], 'ms' => 0];
        $res['via'] = 'grafana';
        if (empty($res['ok'])) {
            hds_merge_smart_drug_result($out, $row, $res, $limit_each);
            continue;
        }
        $hn = hds_row_hn($res);
        if ($hn === '') {
            $res['rows'] = [];
            hds_merge_smart_drug_result($out, $row, $res, $limit_each);
            continue;
        }
        $phase2[$code] = [
            'uid' => $row['grafana_ds_uid'],
            'sql' => hds_smart_drug_by_hn_sql($hn, $months, $limit_each),
            'hn' => $hn,
            'lookup_ms' => (int)($res['ms'] ?? 0),
        ];
    }
    if ($phase2) {
        $jobs = [];
        foreach ($phase2 as $code => $job) {
            $jobs[$code] = ['uid' => $job['uid'], 'sql' => $job['sql']];
            $jobs[$code . '#appt'] = ['uid' => $job['uid'], 'sql' => hds_appointment_by_hn_sql($job['hn'], true)];
        }
        $t0 = microtime(true);
        $hist = hds_grafana_query_multi($cfg, $jobs, ['timeout' => 12, 'max_points' => $limit_each]);
        $wall = (int)round((microtime(true) - $t0) * 1000);
        $hist = hds_grafana_fill_ms($hist, $wall);
        $appt_retry = [];
        foreach ($phase2 as $code => $job) {
            $res = $hist[$code] ?? ['ok' => false, 'error' => 'ไม่มีผลลัพธ์', 'rows' => [], 'ms' => 0];
            $res['via'] = 'grafana';
            $res['ms'] = (int)$job['lookup_ms'] + (int)($res['ms'] ?? 0);
            hds_merge_smart_drug_result($out, $grafana_rows[$code], $res, $limit_each);
            $ares = $hist[$code . '#appt'] ?? ['ok' => false, 'rows' => []];
            if (!empty($ares['ok'])) {
                $src = $grafana_rows[$code];
                foreach (hds_pack_appointment_rows($ares['rows'] ?? [], (string)($src['code'] ?? $code), (string)($src['name'] ?? '')) as $p) {
                    $out['appointments'][] = $p;
                }
            } else {
                $appt_retry[$code] = $job;
            }
        }
        if ($appt_retry) {
            $retry_jobs = [];
            foreach ($appt_retry as $code => $job) {
                $retry_jobs[$code . '#appt'] = ['uid' => $job['uid'], 'sql' => hds_appointment_by_hn_sql($job['hn'], false)];
            }
            $retry = hds_grafana_query_multi($cfg, $retry_jobs, ['timeout' => 8, 'max_points' => 80]);
            foreach ($appt_retry as $code => $job) {
                $ares = $retry[$code . '#appt'] ?? ['ok' => false, 'rows' => []];
                if (empty($ares['ok'])) {
                    continue;
                }
                $src = $grafana_rows[$code];
                foreach (hds_pack_appointment_rows($ares['rows'] ?? [], (string)($src['code'] ?? $code), (string)($src['name'] ?? '')) as $p) {
                    $out['appointments'][] = $p;
                }
            }
        }
    }

    foreach ($direct as $row) {
        $t0 = microtime(true);
        $look = hds_query_sql($con, $row, $lookup_sql, ['timeout' => 8, 'max_points' => 4]);
        $look['via'] = 'direct';
        if (empty($look['ok'])) {
            $look['ms'] = (int)round((microtime(true) - $t0) * 1000);
            hds_merge_smart_drug_result($out, $row, $look, $limit_each);
            continue;
        }
        $hn = hds_row_hn($look);
        if ($hn === '') {
            $look['rows'] = [];
            $look['ms'] = (int)round((microtime(true) - $t0) * 1000);
            hds_merge_smart_drug_result($out, $row, $look, $limit_each);
            continue;
        }
        $res = hds_query_sql($con, $row, hds_smart_drug_by_hn_sql($hn, $months, $limit_each), [
            'timeout' => 12,
            'max_points' => $limit_each,
        ]);
        $res['via'] = 'direct';
        $res['ms'] = (int)round((microtime(true) - $t0) * 1000);
        hds_merge_smart_drug_result($out, $row, $res, $limit_each);
    }
    return $out;
}

function hds_pack_smart_drug_rows(array $raw_rows, $hospital_code, $hospital_name, $limit) {
    $history = [];
    $visits_map = [];
    $n = 0;
    foreach ($raw_rows as $row) {
        if ($n >= $limit) {
            break;
        }
        $vstdate = hds_norm_sql_date($row['vstdate'] ?? '');
        if ($vstdate === '') {
            continue;
        }
        $ts = strtotime($vstdate);
        if (!$ts) {
            continue;
        }
        $be_year = (int)date('Y', $ts) + 543;
        $vsttime = hds_norm_sql_time($row['vsttime'] ?? '');
        $method = hds_unhex_utf8($row['method'] ?? '');
        $rxdate_raw = hds_norm_sql_date($row['rxdate'] ?? '');
        $rxtime_raw = hds_norm_sql_time($row['rxtime'] ?? '');
        $order_date_raw = $rxdate_raw !== '' ? $rxdate_raw : $vstdate;
        $order_time_raw = $rxtime_raw !== '' ? $rxtime_raw : $vsttime;
        $order_ts = strtotime(trim($order_date_raw . ' ' . $order_time_raw));
        if (!$order_ts) {
            $order_ts = strtotime($order_date_raw) ?: $ts;
        }
        $order_be = (int)date('Y', $order_ts) + 543;
        $vn = trim((string)($row['vn'] ?? ''));
        $an = trim((string)($row['an'] ?? ''));
        if ($an !== '') {
            $visit_type = 'ipd';
            $visit_key = $hospital_code . ':ipd:' . $an;
        } elseif ($vn !== '') {
            $visit_type = 'opd';
            $visit_key = $hospital_code . ':opd:' . $vn;
        } else {
            continue;
        }
        $item = [
            'vn' => $vn,
            'an' => $an,
            'vstdate' => $vstdate,
            'vsttime' => $vsttime,
            'rxdate' => $rxdate_raw,
            'rxtime' => $rxtime_raw,
            'order_no' => $row['order_no'] ?? '',
            'item_type' => $row['item_type'] ?? '',
            'order_type' => '',
            'item_no' => $row['item_no'] ?? '',
            'icode' => $row['icode'] ?? '',
            'qty' => (float)($row['qty'] ?? 0),
            'drug_name_local' => hds_unhex_utf8($row['drug_name_local'] ?? $row['drug_name'] ?? ''),
            'drug_name' => hds_unhex_utf8($row['drug_name'] ?? $row['drug_name_local'] ?? ''),
            'strength' => hds_unhex_utf8($row['strength'] ?? ''),
            'strength_local' => hds_unhex_utf8($row['strength_local'] ?? ''),
            'units' => hds_unhex_utf8($row['units'] ?? ''),
            'method' => $method,
            'vstdate_iso' => $vstdate,
            'vstdate_display' => date('d/m/', $ts) . $be_year,
            'vsttime_display' => $vsttime,
            'numeric_mg_value' => null,
            'order_date_iso' => date('Y-m-d', $order_ts),
            'order_date_display' => date('d/m/', $order_ts) . $order_be,
            'order_time_display' => $order_time_raw,
            'order_sort_key' => date('Y-m-d', $order_ts) . ' ' . str_pad(substr($order_time_raw, 0, 8), 8, '0'),
            'is_hme' => (strcasecmp((string)($row['item_type'] ?? ''), 'H') === 0),
            'tpu_code' => trim((string)($row['tpu_code'] ?? '')),
            'continuous' => strtoupper(trim((string)($row['continuous'] ?? ''))),
            'is_chronic' => false,
            'visit_key' => $visit_key,
            'visit_type' => $visit_type,
            'hospital_code' => $hospital_code,
            'hospital_name' => $hospital_name,
        ];
        if ($method !== '' && preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|μg|ug|ไมโครกรัม)/iu', $method, $mc)) {
            $item['numeric_mg_value'] = (float)$mc[1] / 1000;
        } elseif ($method !== '' && preg_match('/(\d+(?:\.\d+)?)\s*mg(?!cg)/i', $method, $m)) {
            $item['numeric_mg_value'] = (float)$m[1];
        } elseif ($method !== '' && preg_match('/(\d+(?:\.\d+)?)\s*(?:g|gm|gram|กร\.?|กรัม)(?![a-zA-Z])/iu', $method, $g)) {
            $item['numeric_mg_value'] = (float)$g[1] * 1000;
        }
        if (!isset($visits_map[$visit_key])) {
            $visits_map[$visit_key] = [
                'visit_key' => $visit_key,
                'visit_type' => $visit_type,
                'vn' => $vn,
                'an' => $an,
                'vstdate_iso' => $vstdate,
                'vstdate_display' => $item['vstdate_display'],
                'vsttime_display' => $vsttime,
                'drug_count' => 0,
                'ward_name' => '',
                'admit_date' => '',
                'hospital_code' => $hospital_code,
                'hospital_name' => $hospital_name,
            ];
        }
        $visits_map[$visit_key]['drug_count']++;
        if ($vstdate > $visits_map[$visit_key]['vstdate_iso']) {
            $visits_map[$visit_key]['vstdate_iso'] = $vstdate;
            $visits_map[$visit_key]['vstdate_display'] = $item['vstdate_display'];
            $visits_map[$visit_key]['vsttime_display'] = $vsttime;
        }
        $history[] = $item;
        $n++;
    }
    return ['history' => $history, 'visits' => array_values($visits_map)];
}

function hds_hn_variants($hn) {
    $hn = trim((string)$hn);
    $out = [];
    if ($hn === '') {
        return $out;
    }
    if (is_numeric($hn)) {
        $out[] = str_pad($hn, 9, '0', STR_PAD_LEFT);
        $trim = ltrim($hn, '0');
        $out[] = $trim === '' ? '0' : $trim;
    } else {
        $out[] = $hn;
    }
    return array_values(array_unique($out));
}

function hds_source_by_code($con, $code) {
    $code = strtolower(trim((string)$code));
    if ($code === '' || $code === 'local') {
        return null;
    }
    foreach (hds_active_sources($con) as $row) {
        if (strtolower((string)($row['code'] ?? '')) === $code) {
            return $row;
        }
    }
    return null;
}

function hds_local_hospital_name() {
    foreach (hds_catalog() as $cat) {
        if (($cat['code'] ?? '') === 'scph') {
            return (string)$cat['name'];
        }
    }
    return 'รพ.นี้ (HOSxP)';
}

/**
 * รายการ lab_head จากรพ.เครือข่าย — Grafana ยิงขนาน
 */
function hds_fetch_smart_lab_network($con, array $hn_variants, $cid, $months = 12, $limit_each = 80, $during = null) {
    $out = ['sources' => [], 'orders' => []];
    $ran_during = false;
    $run_during = function () use (&$during, &$ran_during) {
        if ($ran_during || !is_callable($during)) {
            return;
        }
        $ran_during = true;
        $during();
    };
    list($grafana_rows, $direct, $skipped) = hds_split_remote_sources($con);
    foreach ($skipped as $row) {
        $item = hds_source_stub($row);
        unset($item['visits']);
        $item['error'] = 'ยังไม่มี UID Grafana — กดซิงก์ที่หน้าเชื่อมต่อรพ.';
        $out['sources'][] = $item;
    }
    if (!$grafana_rows && !$direct) {
        $run_during();
        return $out;
    }
    $months = hds_lookback_months($months, 12);
    $limit_each = max(20, min(120, (int)$limit_each));
    $lookup_sql = hds_patient_lookup_sql($cid, $hn_variants);
    $cfg = $grafana_rows ? hds_grafana_get_config($con) : null;

    $apply = function (array $row, array $res) use (&$out) {
        $item = hds_source_stub($row);
        unset($item['visits']);
        $item['ms'] = (int)($res['ms'] ?? 0);
        $item['via'] = $res['via'] ?? $item['via'];
        $code = $item['code'];
        $name = $item['name'];
        if (empty($res['ok'])) {
            $item['error'] = $res['error'] ?? 'คิวรีไม่สำเร็จ';
            $out['sources'][] = $item;
            return;
        }
        $item['ok'] = true;
        foreach ($res['rows'] ?? [] as $r) {
            $ord = trim((string)($r['lab_order_number'] ?? ''));
            $od = hds_norm_sql_date($r['order_date'] ?? '');
            if ($ord === '' || $od === '') {
                continue;
            }
            if ($item['matched_hn'] === '') {
                $item['matched_hn'] = trim((string)($r['matched_hn'] ?? $r['hn'] ?? ''));
            }
            $out['orders'][] = [
                'lab_order_number' => $ord,
                'order_key' => $code . ':' . $ord,
                'order_date' => $od,
                'order_time' => hds_norm_sql_time($r['order_time'] ?? ''),
                'form_name' => trim(hds_unhex_utf8($r['form_name'] ?? '')),
                'hospital_code' => $code,
                'hospital_name' => $name,
                'matched_hn' => $item['matched_hn'],
            ];
            $item['rows']++;
        }
        $out['sources'][] = $item;
    };

    $lookup_jobs = [];
    foreach ($grafana_rows as $code => $row) {
        $lookup_jobs[$code] = ['uid' => $row['grafana_ds_uid'], 'sql' => $lookup_sql];
    }
    $lookup_res = [];
    if ($lookup_jobs) {
        $t0 = microtime(true);
        $lookup_res = hds_grafana_query_multi($cfg, $lookup_jobs, [
            'timeout' => 8,
            'max_points' => 4,
            'during' => $run_during,
        ]);
        $lookup_res = hds_grafana_fill_ms($lookup_res, (int)round((microtime(true) - $t0) * 1000));
    }
    $run_during();

    $phase2 = [];
    foreach ($grafana_rows as $code => $row) {
        $res = $lookup_res[$code] ?? ['ok' => false, 'error' => 'ไม่มีผลลัพธ์', 'rows' => [], 'ms' => 0];
        $res['via'] = 'grafana';
        if (empty($res['ok'])) {
            $apply($row, $res);
            continue;
        }
        $hn = hds_row_hn($res);
        if ($hn === '') {
            $res['rows'] = [];
            $apply($row, $res);
            continue;
        }
        $phase2[$code] = [
            'uid' => $row['grafana_ds_uid'],
            'sql' => hds_smart_lab_by_hn_sql($hn, $months, $limit_each),
            'lookup_ms' => (int)($res['ms'] ?? 0),
        ];
    }
    if ($phase2) {
        $jobs = [];
        foreach ($phase2 as $code => $job) {
            $jobs[$code] = ['uid' => $job['uid'], 'sql' => $job['sql']];
        }
        $t0 = microtime(true);
        $hist = hds_grafana_query_multi($cfg, $jobs, ['timeout' => 12, 'max_points' => $limit_each]);
        $hist = hds_grafana_fill_ms($hist, (int)round((microtime(true) - $t0) * 1000));
        foreach ($phase2 as $code => $job) {
            $res = $hist[$code] ?? ['ok' => false, 'error' => 'ไม่มีผลลัพธ์', 'rows' => [], 'ms' => 0];
            $res['via'] = 'grafana';
            $res['ms'] = (int)$job['lookup_ms'] + (int)($res['ms'] ?? 0);
            $apply($grafana_rows[$code], $res);
        }
    }

    foreach ($direct as $row) {
        $t0 = microtime(true);
        $look = hds_query_sql($con, $row, $lookup_sql, ['timeout' => 8, 'max_points' => 4]);
        $look['via'] = 'direct';
        if (empty($look['ok'])) {
            $look['ms'] = (int)round((microtime(true) - $t0) * 1000);
            $apply($row, $look);
            continue;
        }
        $hn = hds_row_hn($look);
        if ($hn === '') {
            $look['rows'] = [];
            $look['ms'] = (int)round((microtime(true) - $t0) * 1000);
            $apply($row, $look);
            continue;
        }
        $res = hds_query_sql($con, $row, hds_smart_lab_by_hn_sql($hn, $months, $limit_each), [
            'timeout' => 12,
            'max_points' => $limit_each,
        ]);
        $res['via'] = 'direct';
        $res['ms'] = (int)round((microtime(true) - $t0) * 1000);
        $apply($row, $res);
    }
    return $out;
}

function hds_fetch_smart_lab_items($con, array $source_row, $lab_order_number) {
    $ord = hds_sql_quote($lab_order_number);
    $sql = "SELECT o.lab_items_code,
                   " . hds_sql_th('o.lab_items_name_ref') . " AS lab_items_name_ref,
                   " . hds_sql_th('o.lab_order_result') . " AS lab_order_result,
                   " . hds_sql_th('i.lab_items_normal_value') . " AS lab_items_normal_value,
                   i.tmlt_code, i.loinc_code
            FROM lab_order o
            LEFT JOIN lab_items i ON o.lab_items_code = i.lab_items_code
            WHERE o.lab_order_number = $ord
            ORDER BY o.lab_items_name_ref ASC";
    $res = hds_query_sql($con, $source_row, $sql, ['timeout' => 18, 'max_points' => 300]);
    if (!empty($res['ok'])) {
        foreach ($res['rows'] as $i => $r) {
            $res['rows'][$i]['lab_items_name_ref'] = hds_unhex_utf8($r['lab_items_name_ref'] ?? '');
            $res['rows'][$i]['lab_order_result'] = hds_unhex_utf8($r['lab_order_result'] ?? '');
            $res['rows'][$i]['lab_items_normal_value'] = hds_unhex_utf8($r['lab_items_normal_value'] ?? '');
            $res['rows'][$i]['tmlt_code'] = trim((string)($r['tmlt_code'] ?? ''));
            $res['rows'][$i]['loinc_code'] = trim((string)($r['loinc_code'] ?? ''));
        }
    }
    return $res;
}

function hds_fetch_smart_lab_item_history($con, array $source_row, $hn, $lab_code, $limit = 10) {
    $limit = max(1, min(20, (int)$limit));
    $hn_esc = hds_sql_quote($hn);
    $code_esc = hds_sql_quote($lab_code);
    $sql = "SELECT h.lab_order_number, h.order_date, h.order_time, h.report_date, h.report_time,
                   " . hds_sql_th('o.lab_order_result') . " AS lab_order_result,
                   " . hds_sql_th('i.lab_items_normal_value') . " AS lab_items_normal_value
            FROM lab_head h
            JOIN lab_order o ON h.lab_order_number = o.lab_order_number
            LEFT JOIN lab_items i ON o.lab_items_code = i.lab_items_code
            WHERE h.hn = $hn_esc
              AND o.lab_items_code = $code_esc
              AND h.confirm_report = 'Y'
            ORDER BY h.lab_order_number DESC
            LIMIT $limit";
    $res = hds_query_sql($con, $source_row, $sql, ['timeout' => 18, 'max_points' => 40]);
    if (!empty($res['ok'])) {
        foreach ($res['rows'] as $i => $r) {
            $res['rows'][$i]['lab_order_result'] = hds_unhex_utf8($r['lab_order_result'] ?? '');
            $res['rows'][$i]['lab_items_normal_value'] = hds_unhex_utf8($r['lab_items_normal_value'] ?? '');
        }
    }
    return $res;
}

function hds_lab_name_key($name) {
    $s = strtolower(trim((string)$name));
    $s = preg_replace('/\s+/u', ' ', $s);
    return $s;
}

function hds_lab_specimen_tag($name) {
    $s = strtolower((string)$name);
    if (preg_match('/urine|urin|ปัสสาวะ|24\s*hr/u', $s)) {
        return 'urine';
    }
    if (preg_match('/น้ำล้าง|dialys/u', $s)) {
        return 'dialysate';
    }
    if (preg_match('/blood|เลือด|serum|plasma/u', $s)) {
        return 'blood';
    }
    return '';
}

function hds_lab_row_matches(array $row, $lab_code, $tmlt, $name) {
    $code = trim((string)($row['lab_items_code'] ?? ''));
    $got_tmlt = trim((string)($row['tmlt_code'] ?? ''));
    $got_name = hds_lab_name_key($row['lab_name'] ?? $row['lab_items_name_ref'] ?? $row['lab_items_name'] ?? '');
    $want_code = trim((string)$lab_code);
    $want_tmlt = trim((string)$tmlt);
    $want_name = hds_lab_name_key($name);
    if ($want_code !== '' && $code !== '' && (string)$code === $want_code) {
        return true;
    }
    if ($want_name !== '' && $got_name === $want_name) {
        return true;
    }
    if ($want_tmlt !== '' && $got_tmlt !== '' && $got_tmlt === $want_tmlt) {
        $want_tag = hds_lab_specimen_tag($name);
        $got_tag = hds_lab_specimen_tag($got_name);
        if ($want_tag === '' || $got_tag === '' || $want_tag === $got_tag) {
            return true;
        }
    }
    return false;
}

function hds_smart_lab_trend_sql($hn, $lab_code, $tmlt, $name, $months, $limit, $hex_text = true) {
    $hn_esc = hds_sql_quote($hn);
    $limit = max(5, min(20, (int)$limit));
    $date_sql = hds_date_filter_sql('h.order_date', $months);
    $ors = [];
    $lab_code = trim((string)$lab_code);
    $tmlt = trim((string)$tmlt);
    $name = trim((string)$name);
    if ($lab_code !== '') {
        $ors[] = 'o.lab_items_code = ' . hds_sql_quote($lab_code);
    }
    if ($tmlt !== '') {
        $ors[] = "(i.tmlt_code IS NOT NULL AND TRIM(i.tmlt_code) <> '' AND i.tmlt_code = " . hds_sql_quote($tmlt) . ')';
    }
    if ($name !== '') {
        $n = hds_sql_quote($name);
        $ors[] = 'LOWER(TRIM(i.lab_items_name)) = LOWER(TRIM(' . $n . '))';
        $ors[] = 'LOWER(TRIM(o.lab_items_name_ref)) = LOWER(TRIM(' . $n . '))';
    }
    $match = $ors ? '(' . implode(' OR ', $ors) . ')' : '0=1';
    $res_col = $hex_text ? hds_sql_th('o.lab_order_result') : 'CAST(CONVERT(o.lab_order_result USING utf8) AS CHAR)';
    $norm_col = $hex_text ? hds_sql_th("IFNULL(i.lab_items_normal_value,'')") : "CAST(CONVERT(IFNULL(i.lab_items_normal_value,'') USING utf8) AS CHAR)";
    $name_expr = "COALESCE(NULLIF(TRIM(o.lab_items_name_ref),''), i.lab_items_name)";
    $name_col = $hex_text ? hds_sql_th($name_expr) : 'CAST(CONVERT(' . $name_expr . ' USING utf8) AS CHAR)';
    return "SELECT h.lab_order_number, h.order_date, h.order_time, h.report_date, h.report_time,
                   $res_col AS lab_order_result,
                   $norm_col AS lab_items_normal_value,
                   o.lab_items_code,
                   i.tmlt_code,
                   $name_col AS lab_name
            FROM lab_head h
            JOIN lab_order o ON h.lab_order_number = o.lab_order_number
            LEFT JOIN lab_items i ON o.lab_items_code = i.lab_items_code
            WHERE h.hn = $hn_esc
              AND h.confirm_report = 'Y'
              AND $match
              $date_sql
            ORDER BY h.order_date DESC, h.order_time DESC
            LIMIT $limit";
}

function hds_pack_lab_trend_rows(array $rows, $hospital_code, $hospital_name, $lab_code, $tmlt, $name, $hex_text = true) {
    $out = [];
    foreach ($rows as $r) {
        $lab_name = $hex_text ? hds_unhex_utf8($r['lab_name'] ?? '') : trim((string)($r['lab_name'] ?? ''));
        $result = $hex_text ? hds_unhex_utf8($r['lab_order_result'] ?? '') : trim((string)($r['lab_order_result'] ?? ''));
        $normal = $hex_text ? hds_unhex_utf8($r['lab_items_normal_value'] ?? '') : trim((string)($r['lab_items_normal_value'] ?? ''));
        $packed = [
            'lab_items_code' => trim((string)($r['lab_items_code'] ?? '')),
            'tmlt_code' => trim((string)($r['tmlt_code'] ?? '')),
            'lab_name' => $lab_name,
            'lab_items_name_ref' => $lab_name,
        ];
        if (!hds_lab_row_matches($packed, $lab_code, $tmlt, $name)) {
            continue;
        }
        $od = hds_norm_sql_date($r['order_date'] ?? '') ?: trim((string)($r['order_date'] ?? ''));
        $rd = hds_norm_sql_date($r['report_date'] ?? '') ?: trim((string)($r['report_date'] ?? ''));
        $out[] = [
            'lab_order_number' => trim((string)($r['lab_order_number'] ?? '')),
            'order_date' => $od,
            'order_time' => hds_norm_sql_time($r['order_time'] ?? '') ?: trim((string)($r['order_time'] ?? '')),
            'report_date' => $rd,
            'report_time' => hds_norm_sql_time($r['report_time'] ?? '') ?: trim((string)($r['report_time'] ?? '')),
            'lab_order_result' => $result,
            'lab_items_normal_value' => $normal,
            'lab_items_code' => $packed['lab_items_code'],
            'tmlt_code' => $packed['tmlt_code'],
            'lab_name' => $lab_name,
            'hospital_code' => $hospital_code,
            'hospital_name' => $hospital_name,
        ];
    }
    return $out;
}

function hds_fetch_smart_lab_trend_network($con, array $hn_variants, $cid, $lab_code, $tmlt, $name, $months = 12, $limit_each = 12) {
    $out = ['points' => []];
    list($grafana_rows, $direct, $skipped) = hds_split_remote_sources($con);
    if (!$grafana_rows && !$direct) {
        return $out;
    }
    $months = hds_lookback_months($months, 12);
    $limit_each = max(5, min(20, (int)$limit_each));
    $lookup_sql = hds_patient_lookup_sql($cid, $hn_variants);
    $cfg = $grafana_rows ? hds_grafana_get_config($con) : null;
    $lookup_jobs = [];
    foreach ($grafana_rows as $code => $row) {
        $lookup_jobs[$code] = ['uid' => $row['grafana_ds_uid'], 'sql' => $lookup_sql];
    }
    $lookup_res = [];
    if ($lookup_jobs) {
        $lookup_res = hds_grafana_query_multi($cfg, $lookup_jobs, ['timeout' => 8, 'max_points' => 4]);
    }
    $phase2 = [];
    foreach ($grafana_rows as $code => $row) {
        $res = $lookup_res[$code] ?? ['ok' => false, 'rows' => []];
        if (empty($res['ok'])) {
            continue;
        }
        $hn = hds_row_hn($res);
        if ($hn === '') {
            continue;
        }
        $phase2[$code] = [
            'uid' => $row['grafana_ds_uid'],
            'sql' => hds_smart_lab_trend_sql($hn, $lab_code, $tmlt, $name, $months, $limit_each, true),
            'name' => (string)($row['name'] ?? $code),
        ];
    }
    if ($phase2) {
        $jobs = [];
        foreach ($phase2 as $code => $job) {
            $jobs[$code] = ['uid' => $job['uid'], 'sql' => $job['sql']];
        }
        $hist = hds_grafana_query_multi($cfg, $jobs, ['timeout' => 12, 'max_points' => $limit_each]);
        foreach ($phase2 as $code => $job) {
            $res = $hist[$code] ?? ['ok' => false, 'rows' => []];
            if (empty($res['ok'])) {
                continue;
            }
            foreach (hds_pack_lab_trend_rows($res['rows'] ?? [], $code, $job['name'], $lab_code, $tmlt, $name, true) as $p) {
                $out['points'][] = $p;
            }
        }
    }
    foreach ($direct as $code => $row) {
        $look = hds_query_sql($con, $row, $lookup_sql, ['timeout' => 8, 'max_points' => 4]);
        $hn = hds_row_hn($look);
        if ($hn === '') {
            continue;
        }
        $res = hds_query_sql($con, $row, hds_smart_lab_trend_sql($hn, $lab_code, $tmlt, $name, $months, $limit_each, true), [
            'timeout' => 12,
            'max_points' => $limit_each,
        ]);
        if (empty($res['ok'])) {
            continue;
        }
        $hname = (string)($row['name'] ?? $code);
        foreach (hds_pack_lab_trend_rows($res['rows'] ?? [], $code, $hname, $lab_code, $tmlt, $name, true) as $p) {
            $out['points'][] = $p;
        }
    }
    return $out;
}

function hds_allergy_is_blank($agent) {
    $a = trim((string)$agent);
    if ($a === '' || $a === '-' || strcasecmp($a, 'null') === 0) {
        return true;
    }
    return (bool)preg_match('/^(NKA|NKDA|N\/A|ไม่มี|ไม่แพ้|none|no\s*known)/iu', $a);
}

function hds_allergy_date_fields($raw) {
    $iso = hds_norm_sql_date($raw);
    if ($iso === '') {
        return ['', ''];
    }
    $ts = strtotime($iso);
    if (!$ts) {
        return [$iso, $iso];
    }
    return [$iso, date('d/m/', $ts) . ((int)date('Y', $ts) + 543)];
}

function hds_pack_allergy_item($agent, $symptom, $report_date, $hospital_code, $hospital_name, $source_kind, array $extra = []) {
    $agent = trim((string)$agent);
    if (hds_allergy_is_blank($agent)) {
        return null;
    }
    list($iso, $disp) = hds_allergy_date_fields($report_date);
    $item = [
        'agent' => $agent,
        'symptom' => trim((string)$symptom),
        'severity' => trim((string)($extra['severity'] ?? '')),
        'report_date' => $iso,
        'report_date_display' => $disp,
        'hospital_code' => (string)$hospital_code,
        'hospital_name' => (string)$hospital_name,
        'source_kind' => (string)$source_kind,
        'source_label' => (string)$hospital_name,
    ];
    foreach ($extra as $k => $v) {
        if (!array_key_exists($k, $item)) {
            $item[$k] = $v;
        }
    }
    return $item;
}

function hds_allergy_source_stub(array $row, $kind = 'network') {
    $code = (string)($row['code'] ?? '');
    return [
        'code' => $code,
        'name' => (string)($row['name'] ?? $code),
        'kind' => $kind,
        'ok' => false,
        'count' => 0,
        'error' => '',
        'ms' => 0,
    ];
}

function hds_allergy_by_patient_sql($cid, array $hn_variants) {
    $where = hds_patient_match_sql($cid, $hn_variants, 'p');
    $agent = hds_sql_th("IFNULL(a.agent,'')");
    $symptom = hds_sql_th("IFNULL(a.symptom,'')");
    return "SELECT p.hn AS matched_hn,
                   $agent AS agent,
                   $symptom AS symptom,
                   a.report_date
            FROM opd_allergy a
            INNER JOIN patient p ON p.hn = a.hn
            WHERE $where
            ORDER BY a.report_date DESC
            LIMIT 80";
}

function hds_pack_network_allergy_rows(array $raw_rows, $code, $name) {
    $out = [];
    $seen = [];
    foreach ($raw_rows as $row) {
        $item = hds_pack_allergy_item(
            hds_unhex_utf8($row['agent'] ?? ''),
            hds_unhex_utf8($row['symptom'] ?? ''),
            $row['report_date'] ?? '',
            $code,
            $name,
            'network'
        );
        if (!$item) {
            continue;
        }
        $key = function_exists('mb_strtolower')
            ? mb_strtolower($item['agent'], 'UTF-8')
            : strtolower($item['agent']);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = $item;
    }
    return $out;
}

function hds_fetch_local_allergy($hos, $hn_sql, $hospital_code, $hospital_name) {
    $t0 = microtime(true);
    $src = [
        'code' => (string)$hospital_code,
        'name' => (string)$hospital_name,
        'kind' => 'local',
        'ok' => false,
        'count' => 0,
        'error' => '',
        'ms' => 0,
    ];
    $rows = [];
    if (!$hos || trim((string)$hn_sql) === '') {
        $src['error'] = 'ไม่มี HN';
        $src['ms'] = (int)round((microtime(true) - $t0) * 1000);
        return ['source' => $src, 'rows' => []];
    }
    $sql = "
        SELECT CAST(CONVERT(IFNULL(agent,'') USING utf8) AS CHAR) AS agent,
               CAST(CONVERT(IFNULL(symptom,'') USING utf8) AS CHAR) AS symptom,
               report_date
        FROM opd_allergy
        WHERE hn IN ($hn_sql)
        ORDER BY report_date DESC
        LIMIT 80
    ";
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        $q = @mysqli_query($hos, "
            SELECT agent, symptom, report_date
            FROM opd_allergy
            WHERE hn IN ($hn_sql)
            ORDER BY report_date DESC
            LIMIT 80
        ");
    }
    if (!$q) {
        $src['error'] = mysqli_error($hos) ?: 'อ่าน opd_allergy ไม่ได้';
        $src['ms'] = (int)round((microtime(true) - $t0) * 1000);
        return ['source' => $src, 'rows' => []];
    }
    $seen = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $item = hds_pack_allergy_item(
            $r['agent'] ?? '',
            $r['symptom'] ?? '',
            $r['report_date'] ?? '',
            $hospital_code,
            $hospital_name,
            'local'
        );
        if (!$item) {
            continue;
        }
        $key = function_exists('mb_strtolower')
            ? mb_strtolower($item['agent'], 'UTF-8')
            : strtolower($item['agent']);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $rows[] = $item;
    }
    $src['ok'] = true;
    $src['count'] = count($rows);
    $src['ms'] = (int)round((microtime(true) - $t0) * 1000);
    return ['source' => $src, 'rows' => $rows];
}

/**
 * ประวัติแพ้ยาจากรพ.ในเครือข่าย (opd_allergy) — ค้นด้วย CID / HN
 */
function hds_fetch_allergy_network($con, array $hn_variants, $cid) {
    $out = ['sources' => [], 'rows' => []];
    list($grafana_rows, $direct, $skipped) = hds_split_remote_sources($con);
    foreach ($skipped as $row) {
        $item = hds_allergy_source_stub($row, 'network');
        $item['error'] = 'ยังไม่มี UID Grafana — กดซิงก์ที่หน้าเชื่อมต่อรพ.';
        $out['sources'][] = $item;
    }
    if (!$grafana_rows && !$direct) {
        return $out;
    }
    $sql = hds_allergy_by_patient_sql($cid, $hn_variants);
    $cfg = $grafana_rows ? hds_grafana_get_config($con) : null;
    $jobs = [];
    foreach ($grafana_rows as $code => $row) {
        $jobs[$code] = ['uid' => $row['grafana_ds_uid'], 'sql' => $sql];
    }
    $gres = [];
    if ($jobs) {
        $t0 = microtime(true);
        $gres = hds_grafana_query_multi($cfg, $jobs, ['timeout' => 10, 'max_points' => 80]);
        $gres = hds_grafana_fill_ms($gres, (int)round((microtime(true) - $t0) * 1000));
    }
    foreach ($grafana_rows as $code => $row) {
        $src = hds_allergy_source_stub($row, 'network');
        $res = $gres[$code] ?? ['ok' => false, 'error' => 'ไม่มีผลลัพธ์', 'rows' => [], 'ms' => 0];
        $src['ms'] = (int)($res['ms'] ?? 0);
        if (empty($res['ok'])) {
            $src['error'] = (string)($res['error'] ?? 'คิวรีไม่สำเร็จ');
            $out['sources'][] = $src;
            continue;
        }
        $packed = hds_pack_network_allergy_rows($res['rows'] ?? [], $src['code'], $src['name']);
        $src['ok'] = true;
        $src['count'] = count($packed);
        foreach ($packed as $p) {
            $out['rows'][] = $p;
        }
        $out['sources'][] = $src;
    }
    foreach ($direct as $row) {
        $src = hds_allergy_source_stub($row, 'network');
        $t0 = microtime(true);
        $res = hds_query_sql($con, $row, $sql, ['timeout' => 10, 'max_points' => 80]);
        $src['ms'] = (int)round((microtime(true) - $t0) * 1000);
        if (empty($res['ok'])) {
            $src['error'] = (string)($res['error'] ?? 'คิวรีไม่สำเร็จ');
            $out['sources'][] = $src;
            continue;
        }
        $packed = hds_pack_network_allergy_rows($res['rows'] ?? [], $src['code'], $src['name']);
        $src['ok'] = true;
        $src['count'] = count($packed);
        foreach ($packed as $p) {
            $out['rows'][] = $p;
        }
        $out['sources'][] = $src;
    }
    return $out;
}

function hds_appointment_by_hn_sql($hn, $with_names = true) {
    $hn = str_replace(["\\", "'"], '', trim((string)$hn));
    if ($hn === '') {
        return 'SELECT 1 WHERE 0';
    }
    if ($with_names) {
        $clinic = hds_sql_th("IFNULL(c.name,'')");
        $doctor = hds_sql_th("IFNULL(doc.name,'')");
        $join = "LEFT JOIN clinic c ON c.clinic = o.clinic LEFT JOIN doctor doc ON doc.code = o.doctor";
    } else {
        $clinic = "''";
        $doctor = "''";
        $join = '';
    }
    return "SELECT o.vn, IFNULL(o.an,'') AS an, o.vstdate, o.nextdate,
                   SUBSTR(IFNULL(o.nexttime,''),1,8) AS nexttime,
                   $clinic AS clinic_name, $doctor AS doctor_name
            FROM oapp o
            $join
            WHERE o.hn = '$hn'
              AND o.vstdate IS NOT NULL AND o.vstdate <> '0000-00-00'
              AND o.nextdate IS NOT NULL AND o.nextdate <> '0000-00-00'
            ORDER BY o.vstdate DESC
            LIMIT 80";
}

function hds_appointment_by_patient_sql($cid, array $hn_variants, $with_clinic = true) {
    $where = hds_patient_match_sql($cid, $hn_variants, 'p');
    if ($with_clinic) {
        $clinic = hds_sql_th("IFNULL(c.name,'')");
        $doctor = hds_sql_th("IFNULL(doc.name,'')");
        $join = "LEFT JOIN clinic c ON c.clinic = o.clinic LEFT JOIN doctor doc ON doc.code = o.doctor";
    } else {
        $clinic = "''";
        $doctor = "''";
        $join = '';
    }
    return "SELECT o.vn, IFNULL(o.an,'') AS an, o.vstdate, o.nextdate, o.nexttime,
                   $clinic AS clinic_name, $doctor AS doctor_name
            FROM oapp o
            INNER JOIN patient p ON p.hn = o.hn
            $join
            WHERE $where
              AND o.nextdate IS NOT NULL AND o.nextdate <> '0000-00-00'
            ORDER BY o.vstdate DESC
            LIMIT 200";
}

function hds_pack_appointment_rows(array $raw_rows, $code, $name) {
    $out = [];
    $seen = [];
    foreach ($raw_rows as $row) {
        $next = hds_norm_sql_date($row['nextdate'] ?? '');
        $vst = hds_norm_sql_date($row['vstdate'] ?? '');
        if ($next === '') {
            continue;
        }
        $vn = trim((string)($row['vn'] ?? ''));
        $an = trim((string)($row['an'] ?? ''));
        $clinic = trim(hds_unhex_utf8($row['clinic_name'] ?? ''));
        $doctor = trim(hds_unhex_utf8($row['doctor_name'] ?? ''));
        $key = $vst . '|' . $next . '|' . $vn . '|' . $an . '|' . $clinic . '|' . $doctor;
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = [
            'vn' => $vn,
            'an' => $an,
            'vstdate' => $vst,
            'nextdate' => $next,
            'nexttime' => substr(trim((string)($row['nexttime'] ?? '')), 0, 8),
            'clinic_name' => $clinic,
            'doctor_name' => $doctor,
            'hospital_code' => (string)$code,
            'hospital_name' => (string)$name,
        ];
    }
    return $out;
}

/**
 * นัดหมายจากรพ.ในเครือข่าย (oapp) — ค้นด้วย CID / HN
 */
function hds_fetch_appointment_network($con, array $hn_variants, $cid) {
    $out = ['sources' => [], 'rows' => []];
    list($grafana_rows, $direct, $skipped) = hds_split_remote_sources($con);
    foreach ($skipped as $row) {
        $item = hds_allergy_source_stub($row, 'network');
        $item['error'] = 'ยังไม่มี UID Grafana — กดซิงก์ที่หน้าเชื่อมต่อรพ.';
        $out['sources'][] = $item;
    }
    if (!$grafana_rows && !$direct) {
        return $out;
    }
    $sql = hds_appointment_by_patient_sql($cid, $hn_variants, true);
    $sql_plain = hds_appointment_by_patient_sql($cid, $hn_variants, false);
    $cfg = $grafana_rows ? hds_grafana_get_config($con) : null;
    $jobs = [];
    foreach ($grafana_rows as $code => $row) {
        $jobs[$code] = ['uid' => $row['grafana_ds_uid'], 'sql' => $sql];
    }
    $gres = [];
    if ($jobs) {
        $t0 = microtime(true);
        $gres = hds_grafana_query_multi($cfg, $jobs, ['timeout' => 10, 'max_points' => 200]);
        $gres = hds_grafana_fill_ms($gres, (int)round((microtime(true) - $t0) * 1000));
    }
    foreach ($grafana_rows as $code => $row) {
        $src = hds_allergy_source_stub($row, 'network');
        $res = $gres[$code] ?? ['ok' => false, 'error' => 'ไม่มีผลลัพธ์', 'rows' => [], 'ms' => 0];
        $src['ms'] = (int)($res['ms'] ?? 0);
        if (empty($res['ok'])) {
            $retry = hds_grafana_query_multi($cfg, [
                $code => ['uid' => $row['grafana_ds_uid'], 'sql' => $sql_plain],
            ], ['timeout' => 10, 'max_points' => 200]);
            $res = $retry[$code] ?? $res;
        }
        if (empty($res['ok'])) {
            $src['error'] = (string)($res['error'] ?? 'คิวรีไม่สำเร็จ');
            $out['sources'][] = $src;
            continue;
        }
        $packed = hds_pack_appointment_rows($res['rows'] ?? [], $src['code'], $src['name']);
        $src['ok'] = true;
        $src['count'] = count($packed);
        foreach ($packed as $p) {
            $out['rows'][] = $p;
        }
        $out['sources'][] = $src;
    }
    foreach ($direct as $row) {
        $src = hds_allergy_source_stub($row, 'network');
        $t0 = microtime(true);
        $res = hds_query_sql($con, $row, $sql, ['timeout' => 10, 'max_points' => 80]);
        $src['ms'] = (int)round((microtime(true) - $t0) * 1000);
        if (empty($res['ok'])) {
            $src['error'] = (string)($res['error'] ?? 'คิวรีไม่สำเร็จ');
            $out['sources'][] = $src;
            continue;
        }
        $packed = hds_pack_appointment_rows($res['rows'] ?? [], $src['code'], $src['name']);
        $src['ok'] = true;
        $src['count'] = count($packed);
        foreach ($packed as $p) {
            $out['rows'][] = $p;
        }
        $out['sources'][] = $src;
    }
    return $out;
}



