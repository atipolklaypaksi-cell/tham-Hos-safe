<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ini_set('memory_limit', '512M');
set_time_limit(180);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/amr_helper.php');
if (is_file(__DIR__ . '/amr_sensitivity_helper.php')) {
    require_once __DIR__ . '/amr_sensitivity_helper.php';
}
if (is_file(__DIR__ . '/amr_amass_annex.php')) {
    require_once __DIR__ . '/amr_amass_annex.php';
}
require_once __DIR__ . '/amr_kpi_helper.php';
if (is_file(__DIR__ . '/menu_permissions_helper.php')) {
    require_once __DIR__ . '/menu_permissions_helper.php';
}
mysqli_set_charset($con, 'utf8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
if (function_exists('tham_menu_can') && isset($_SESSION['user_id'])
    && !tham_menu_can('amr.kpi') && !tham_menu_can('amr.antibiogram') && !tham_menu_can('amr.dashboard')) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์เข้าถึง KPI AMR'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

function amr_kpi_api_out(array $payload) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = [];
}
$src = array_merge($_GET, $_POST, $input);
$action = trim((string)($src['action'] ?? 'list'));

if ($action === 'settings_get') {
    amr_kpi_api_out([
        'status' => 'success',
        'settings' => amr_kpi_settings_get($con),
    ]);
}

if ($action === 'settings_save') {
    $saved = amr_kpi_settings_save($con, $src);
    amr_kpi_api_out([
        'status' => 'success',
        'settings' => $saved,
        'message' => 'บันทึกการตั้งค่าแล้ว',
    ]);
}

$end = amr_parse_date($src['end_date'] ?? '', date('Y-m-d'));
$start = amr_parse_date($src['start_date'] ?? '', date('Y-01-01'));
if ($start > $end) {
    $tmp = $start;
    $start = $end;
    $end = $tmp;
}

$result = amr_kpi_build($con, [
    'start' => $start,
    'end' => $end,
    'lookback_days' => $src['lookback_days'] ?? null,
    'prior_admit_days' => $src['prior_admit_days'] ?? null,
    'principal_only' => $src['principal_only'] ?? null,
    'lite' => !empty($src['lite']),
    'include_rows' => isset($src['include_rows']) ? !empty($src['include_rows']) : true,
]);

if (!empty($result['error'])) {
    amr_kpi_api_out(['status' => 'error', 'message' => $result['error']]);
}

amr_kpi_api_out([
    'status' => 'success',
    'meta' => $result['meta'],
    'settings' => $result['settings'],
    'official' => $result['official'] ?? null,
    'official_community' => $result['official_community'] ?? null,
    'official_risk_and' => $result['official_risk_and'] ?? null,
    'cohorts' => $result['cohorts'],
    'rows_community' => $result['rows_community'],
    'rows_risk_and' => $result['rows_risk_and'],
    'rows_all' => $result['rows_all'],
]);
