<?php
/**
 * เชื่อมต่อฐานข้อมูลระบบ Robot OPD (MySQL) แบบอ่านอย่างเดียว
 */

function robot_config_keys() {
    return ['robot_host', 'robot_port', 'robot_user', 'robot_pass', 'robot_db'];
}

function robot_default_config() {
    return [
        'robot_host' => '10.10.10.115',
        'robot_port' => '3306',
        'robot_user' => 'scph',
        'robot_pass' => 'scph!10699',
        'robot_db' => '',
    ];
}

function robot_upsert_config($con, $key, $value) {
    $k = mysqli_real_escape_string($con, $key);
    $v = mysqli_real_escape_string($con, (string)$value);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$k'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
}

function robot_ensure_config($con) {
    foreach (robot_default_config() as $key => $value) {
        $k = mysqli_real_escape_string($con, $key);
        $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
        if (!$chk || mysqli_num_rows($chk) === 0) {
            robot_upsert_config($con, $key, $value);
        }
    }
}

function robot_load_config($con) {
    robot_ensure_config($con);
    $cfg = robot_default_config();
    $keys = "'" . implode("','", array_map(function ($k) use ($con) {
        return mysqli_real_escape_string($con, $k);
    }, robot_config_keys())) . "'";
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ($keys)");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cfg[$r['config_name']] = (string)$r['config_value'];
        }
    }
    $port = (int)($cfg['robot_port'] ?? 3306);
    $cfg['robot_port'] = (string)($port > 0 ? $port : 3306);
    return $cfg;
}

function robot_save_config($con, array $input) {
    $cur = robot_load_config($con);
    $next = $cur;
    foreach (['robot_host', 'robot_port', 'robot_user', 'robot_db'] as $key) {
        if (array_key_exists($key, $input)) {
            $next[$key] = trim((string)$input[$key]);
        }
    }
    if (isset($input['robot_pass'])) {
        $pass = (string)$input['robot_pass'];
        if ($pass !== '' && $pass !== '********') {
            $next['robot_pass'] = $pass;
        }
    }
    $port = (int)$next['robot_port'];
    $next['robot_port'] = (string)($port > 0 ? $port : 3306);
    foreach (robot_config_keys() as $key) {
        robot_upsert_config($con, $key, $next[$key] ?? '');
    }
    return robot_load_config($con);
}

function robot_public_config(array $cfg) {
    $out = $cfg;
    $out['robot_pass'] = ($cfg['robot_pass'] ?? '') !== '' ? '********' : '';
    return $out;
}

function robot_is_readonly_sql($sql) {
    $sql = trim((string)$sql);
    if ($sql === '') {
        return false;
    }
    $sql = preg_replace('/^\s*\/\*.*?\*\//s', '', $sql);
    $sql = preg_replace('/^\s*--[^\n]*\n/', '', $sql);
    $sql = ltrim($sql);
    if (!preg_match('/^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN|WITH)\b/i', $sql)) {
        return false;
    }
    if (preg_match('/\b(INSERT|UPDATE|DELETE|ALTER|DROP|CREATE|TRUNCATE|GRANT|REVOKE|LOAD\s+DATA|INTO\s+OUTFILE|INTO\s+DUMPFILE|FOR\s+UPDATE)\b/i', $sql)) {
        return false;
    }
    return true;
}

function robot_ident($name) {
    $name = trim((string)$name);
    if ($name === '' || !preg_match('/^[A-Za-z0-9_]+$/', $name)) {
        return null;
    }
    return '`' . $name . '`';
}

function robot_tcp_probe($host, $port, $timeout = 2) {
    $host = trim((string)$host);
    $port = (int)$port;
    $out = ['ok' => false, 'errno' => 0, 'error' => '', 'ms' => 0];
    if ($host === '' || $port <= 0) {
        $out['error'] = 'ไม่ได้ระบุโฮสต์หรือพอร์ต';
        return $out;
    }
    $errno = 0;
    $errstr = '';
    $t0 = microtime(true);
    $fp = @fsockopen($host, $port, $errno, $errstr, max(1, min(8, (int)$timeout)));
    $out['ms'] = round((microtime(true) - $t0) * 1000, 1);
    $out['errno'] = (int)$errno;
    $out['error'] = trim((string)$errstr);
    if ($fp) {
        fclose($fp);
        $out['ok'] = true;
        $out['error'] = '';
    }
    return $out;
}

function robot_connect_hint($host, $port, $tcp, $mysql_err) {
    $host = trim((string)$host);
    $port = (int)$port;
    $mysql_err = trim((string)$mysql_err);
    if (!empty($tcp['ok'])) {
        if ($mysql_err === '') {
            return 'พอร์ตเปิดแล้ว แต่ล็อกอิน MySQL ไม่สำเร็จ — ตรวจ username / password และสิทธิ์ remote ของบัญชี';
        }
        return $mysql_err;
    }
    $errno = (int)($tcp['errno'] ?? 0);
    $raw = strtolower(trim((string)($tcp['error'] ?? '') . ' ' . $mysql_err));
    if ($errno === 111 || strpos($raw, 'refused') !== false) {
        return 'เครื่อง ' . $host . ' ถึงได้ แต่พอร์ต ' . $port . ' ไม่รับ MySQL (Connection refused) — เปิดบริการ MySQL บนเครื่อง Robot OPD, ตั้ง bind-address ให้รับเครื่องนี้ และเปิด firewall พอร์ต ' . $port;
    }
    if ($errno === 110 || strpos($raw, 'timed out') !== false || strpos($raw, 'timeout') !== false) {
        return 'รอตอบจาก ' . $host . ':' . $port . ' ไม่ทัน — firewall อาจบล็อกพอร์ต MySQL';
    }
    if ($mysql_err !== '') {
        return $mysql_err;
    }
    if (!empty($tcp['error'])) {
        return $tcp['error'];
    }
    return 'เชื่อมต่อ Robot OPD MySQL ไม่ได้';
}

function robot_connect($con, $read_timeout = 12, array $override = null, &$connect_error = null) {
    $connect_error = '';
    $cfg = $override ? array_merge(robot_load_config($con), $override) : robot_load_config($con);
    $host = trim((string)($cfg['robot_host'] ?? ''));
    $user = trim((string)($cfg['robot_user'] ?? ''));
    $pass = (string)($cfg['robot_pass'] ?? '');
    $db = trim((string)($cfg['robot_db'] ?? ''));
    $port = (int)($cfg['robot_port'] ?? 3306);
    if ($host === '' || $user === '') {
        $connect_error = 'กรุณากรอก Host และ Username';
        return null;
    }
    if ($port <= 0) {
        $port = 3306;
    }
    mysqli_report(MYSQLI_REPORT_OFF);
    $c = mysqli_init();
    if (!$c) {
        $connect_error = 'สร้างการเชื่อมต่อ MySQL ไม่สำเร็จ';
        return null;
    }
    $read_timeout = max(8, min(60, (int)$read_timeout));
    mysqli_options($c, MYSQLI_OPT_CONNECT_TIMEOUT, 8);
    if (defined('MYSQLI_OPT_READ_TIMEOUT')) {
        mysqli_options($c, MYSQLI_OPT_READ_TIMEOUT, $read_timeout);
    }
    $dbname = $db !== '' ? $db : null;
    $ok = @mysqli_real_connect($c, $host, $user, $pass, $dbname, $port);
    if (!$ok) {
        $connect_error = trim((string)($c->connect_error ?: mysqli_connect_error() ?: ''));
        return null;
    }
    @mysqli_set_charset($c, 'utf8mb4');
    @mysqli_query($c, 'SET SESSION TRANSACTION READ ONLY');
    return $c;
}

function robot_query($robot, $sql) {
    if (!$robot || !robot_is_readonly_sql($sql)) {
        return false;
    }
    return @mysqli_query($robot, $sql);
}

function robot_close($robot) {
    if ($robot) {
        try {
            @mysqli_close($robot);
        } catch (Throwable $e) {
            // ignore
        }
    }
}

function robot_list_databases($robot) {
    $skip = ['information_schema' => true, 'mysql' => true, 'performance_schema' => true, 'sys' => true];
    $out = [];
    $q = robot_query($robot, 'SHOW DATABASES');
    if ($q) {
        while ($r = mysqli_fetch_row($q)) {
            $name = trim((string)($r[0] ?? ''));
            if ($name === '' || isset($skip[strtolower($name)])) {
                continue;
            }
            $out[] = $name;
        }
    }
    return $out;
}

function robot_list_tables($robot, $q = '', $limit = 80) {
    $limit = max(1, min(200, (int)$limit));
    $res = robot_query($robot, 'SHOW TABLES');
    if (!$res) {
        return [];
    }
    $q = function_exists('mb_strtolower') ? mb_strtolower(trim((string)$q), 'UTF-8') : strtolower(trim((string)$q));
    $tables = [];
    while ($row = mysqli_fetch_row($res)) {
        $name = (string)($row[0] ?? '');
        if ($name === '') {
            continue;
        }
        $hay = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
        if ($q !== '' && strpos($hay, $q) === false) {
            continue;
        }
        $tables[] = $name;
    }
    return array_slice($tables, 0, $limit);
}

function robot_is_sensitive_column($name) {
    $n = strtolower((string)$name);
    return (bool)preg_match('/(pass|passwd|password|secret|token|cid|id_card|pin)/i', $n);
}

function robot_preview_table($robot, $table, $limit = 20) {
    $ident = robot_ident($table);
    if (!$ident) {
        return ['columns' => [], 'rows' => [], 'error' => 'ชื่อตารางไม่ถูกต้อง'];
    }
    $desc = robot_query($robot, "SHOW COLUMNS FROM $ident");
    if (!$desc) {
        return ['columns' => [], 'rows' => [], 'error' => 'ไม่พบตารางนี้ หรืออ่านโครงสร้างไม่ได้'];
    }
    $headers = [];
    $select = [];
    while ($c = mysqli_fetch_assoc($desc)) {
        $name = (string)($c['Field'] ?? '');
        if ($name === '' || robot_is_sensitive_column($name)) {
            continue;
        }
        if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) {
            continue;
        }
        $headers[] = $name;
        $select[] = '`' . $name . '`';
        if (count($select) >= 12) {
            break;
        }
    }
    if (!$select) {
        return ['columns' => [], 'rows' => [], 'error' => 'ไม่มีคอลัมน์ที่แสดงได้'];
    }
    $limit = max(1, min(50, (int)$limit));
    $q = robot_query($robot, 'SELECT ' . implode(',', $select) . " FROM $ident LIMIT $limit");
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return ['columns' => $headers, 'rows' => $rows, 'error' => ''];
}

function robot_ping($con, array $override = null) {
    $t0 = microtime(true);
    $cfg = $override ? array_merge(robot_load_config($con), $override) : robot_load_config($con);
    $out = [
        'ok' => false,
        'ms' => 0,
        'host' => trim((string)($cfg['robot_host'] ?? '')),
        'port' => (int)($cfg['robot_port'] ?? 3306),
        'db' => (string)($cfg['robot_db'] ?? ''),
        'user' => (string)($cfg['robot_user'] ?? ''),
        'version' => '',
        'table_count' => 0,
        'databases' => [],
        'error' => '',
        'tcp_ok' => false,
        'hint' => '',
    ];
    $tcp = robot_tcp_probe($out['host'], $out['port'], 2);
    $out['tcp_ok'] = !empty($tcp['ok']);
    $mysql_err = '';
    $robot = robot_connect($con, 12, $override, $mysql_err);
    $out['ms'] = round((microtime(true) - $t0) * 1000, 1);
    if (!$robot) {
        $out['error'] = robot_connect_hint($out['host'], $out['port'], $tcp, $mysql_err);
        $out['hint'] = $out['error'];
        return $out;
    }
    $info = robot_query($robot, 'SELECT DATABASE() AS db, VERSION() AS ver');
    if ($info && ($r = mysqli_fetch_assoc($info))) {
        $out['version'] = (string)($r['ver'] ?? '');
        if (trim((string)($r['db'] ?? '')) !== '') {
            $out['db'] = (string)$r['db'];
        }
    }
    $out['databases'] = robot_list_databases($robot);
    if ($out['db'] !== '') {
        $tc = robot_query($robot, 'SHOW TABLES');
        $out['table_count'] = $tc ? (int)mysqli_num_rows($tc) : 0;
    }
    $out['ok'] = true;
    robot_close($robot);
    return $out;
}
