<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
mysqli_set_charset($con, 'utf8');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ระบบ INVC - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .invc-hero {
            background: linear-gradient(135deg, #1e1b4b 0%, #3730a3 55%, #4f46e5 100%);
            color: #fff; border-radius: 16px; padding: 1.2rem 1.4rem; margin-bottom: 1rem;
        }
        .invc-kpi { border: 0; border-radius: 12px; cursor: pointer; transition: transform .12s ease; }
        .invc-kpi:hover { transform: translateY(-1px); }
        .invc-kpi.active { outline: 2px solid #4f46e5; }
        .invc-kpi .n { font-size: 1.45rem; font-weight: 800; line-height: 1.1; }
        #stockTable { font-size: .86rem; }
        #stockTable thead th { background: #312e81; color: #fff; white-space: nowrap; position: sticky; top: 0; }
        #stockTable td { vertical-align: top; }
        .lot-line { display: flex; flex-wrap: wrap; gap: .35rem; align-items: center; font-size: .78rem; line-height: 1.35; margin-top: .15rem; }
        .lot-soon { color: #c2410c; font-weight: 700; }
        .lot-expired { color: #b91c1c; font-weight: 800; }
        .lot-risk { color: #9a3412; }
        .qty-low { color: #b91c1c; font-weight: 800; }
        .qty-high { color: #b45309; font-weight: 800; }
        .suggest { color: #1d4ed8; font-weight: 700; font-size: .82rem; }
        .flag-low, .flag-high, .flag-ok {
            display: inline-flex; align-items: center; justify-content: center;
            width: 1.7rem; height: 1.7rem; border-radius: 999px; font-size: .85rem;
        }
        .flag-low { background: #fee2e2; color: #b91c1c; }
        .flag-high { background: #ffedd5; color: #c2410c; }
        .flag-ok { background: #ecfdf5; color: #047857; }
        .flag-soon { background: #ffedd5; color: #c2410c; }
        .flag-expired { background: #fee2e2; color: #b91c1c; }
        .flag-risk { background: #fef3c7; color: #b45309; }
        .flag-soon, .flag-expired, .flag-risk, .flag-pending {
            display: inline-flex; align-items: center; justify-content: center;
            width: 1.7rem; height: 1.7rem; border-radius: 999px; font-size: .85rem;
        }
        .flag-pending { background: #e0e7ff; color: #3730a3; }
        .pending-cell { color: #3730a3; font-weight: 700; font-size: .82rem; }
        .pending-blink {
            background: #fef08a !important;
            color: #854d0e;
            font-weight: 800;
            border-radius: 6px;
            animation: pendingPulse 1.1s ease-in-out infinite;
        }
        .pending-blink .pending-cell { color: #854d0e; }
        .pending-blink .text-muted { color: #a16207 !important; }
        @keyframes pendingPulse {
            0%, 100% { background: #fef08a; box-shadow: 0 0 0 0 rgba(250, 204, 21, .55); }
            50% { background: #fde047; box-shadow: 0 0 0 4px rgba(250, 204, 21, .25); }
        }
        .table-wrap { max-height: calc(100vh - 320px); overflow: auto; border-radius: 12px; }
        #histTable thead th { background: #1e293b; color: #fff; font-size: .8rem; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="invc-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="small text-uppercase" style="letter-spacing:.08em;opacity:.75;">คลังยา · อ่านอย่างเดียว</div>
                    <h4 class="fw-bold mb-1">ระบบ INVC</h4>
                    <p class="mb-0 small" style="opacity:.92;">คงเหลือจากคลังกลาง ค้นชื่อ ดู Min/Max และประวัติการเบิกจ่าย</p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-light btn-sm fw-bold" id="btnRefreshSheet" title="ดึง Google Sheet ใหม่ทันที">
                        <i class="fas fa-sync-alt me-1"></i> รีเฟรช Sheet
                    </button>
                    <a href="invc_setting.php" class="btn btn-light btn-sm fw-bold">
                        <i class="fas fa-plug me-1"></i> ตั้งค่าการเชื่อมต่อ
                    </a>
                </div>
            </div>

            <div class="alert alert-light border small mb-3">
                <i class="fas fa-calculator me-1 text-primary"></i>
                <b>อัตราใช้ต่อเดือน</b> = ยอดเบิกจ่าย 6 เดือนล่าสุด ÷ 6
                (ใบจ่ายสถานะ S ในสมุดคลัง ไม่นับรายการที่ยกเลิก)
                · <b>Min แนะนำ</b> = อัตรา × 1 เดือน
                · <b>Max แนะนำ</b> = อัตรา × 4 เดือน
                · <span class="flag-low"><i class="fas fa-arrow-down"></i></span> ต่ำกว่า Min
                · <span class="flag-high"><i class="fas fa-arrow-up"></i></span> สูงกว่า Max
                · <span class="flag-soon"><i class="fas fa-hourglass-half"></i></span> หมดอายุภายใน 6 เดือน
                · <span class="flag-risk"><i class="fas fa-exclamation-triangle"></i></span> จำนวนคงเหลือ ÷ อัตราใช้ต่อเดือน นานกว่าเวลาที่เหลือก่อนหมดอายุ (ใช้ล็อตที่หมดก่อน เฉพาะรายการที่มีอัตราใช้)
                · <span class="flag-pending"><i class="fas fa-truck-loading"></i></span> คลัง = 0 แต่มีสั่งใน Google Sheet และวันที่รับ (N) หลังวันที่จ่ายล่าสุด = รอตรวจรับ
            </div>

            <div class="row g-2 mb-3" id="kpiRow">
                <div class="col-6 col-lg">
                    <div class="card invc-kpi shadow-sm active" data-status="all"><div class="card-body py-3">
                        <div class="small text-muted">รายการ</div>
                        <div class="n" id="kpiTotal">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card invc-kpi shadow-sm" data-status="low"><div class="card-body py-3">
                        <div class="small text-muted">ต่ำกว่า Min</div>
                        <div class="n text-danger" id="kpiLow">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card invc-kpi shadow-sm" data-status="high"><div class="card-body py-3">
                        <div class="small text-muted">สูงกว่า Max</div>
                        <div class="n text-warning" id="kpiHigh">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card invc-kpi shadow-sm" data-status="ok"><div class="card-body py-3">
                        <div class="small text-muted">อยู่ในช่วง</div>
                        <div class="n text-success" id="kpiOk">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card invc-kpi shadow-sm" data-status="zero"><div class="card-body py-3">
                        <div class="small text-muted">คงเหลือ 0</div>
                        <div class="n" id="kpiZero">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card invc-kpi shadow-sm" data-status="pending"><div class="card-body py-3">
                        <div class="small text-muted">รอตรวจรับ (คลัง 0)</div>
                        <div class="n" style="color:#3730a3;" id="kpiPending">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card invc-kpi shadow-sm" data-status="soon"><div class="card-body py-3">
                        <div class="small text-muted">ใกล้หมดอายุ</div>
                        <div class="n text-warning" id="kpiSoon">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card invc-kpi shadow-sm" data-status="risk"><div class="card-body py-3">
                        <div class="small text-muted">เสี่ยงหมดอายุ</div>
                        <div class="n" style="color:#9a3412;" id="kpiRisk">—</div>
                    </div></div>
                </div>
            </div>

            <div class="card shadow-sm border-0 mb-3">
                <div class="card-body">
                    <div class="row g-2 align-items-end">
                        <div class="col-lg-5">
                            <label class="form-label small fw-bold mb-1">ค้นชื่อหรือรหัส</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" class="form-control" id="q" placeholder="เช่น paracetamol หรือรหัส working code" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-6 col-lg-3">
                            <label class="form-label small fw-bold mb-1">เรียง</label>
                            <select class="form-select" id="sort">
                                <option value="alert">เตือนก่อน แล้วตามชื่อ</option>
                                <option value="name">ชื่อ</option>
                                <option value="qty">คงเหลือน้อยก่อน</option>
                                <option value="rate">อัตราใช้สูงก่อน</option>
                                <option value="code">รหัส</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <div class="form-check mt-4">
                                <input class="form-check-input" type="checkbox" id="includeInactive">
                                <label class="form-check-label small" for="includeInactive">รวมเลิกใช้</label>
                            </div>
                        </div>
                        <div class="col-lg-2 text-lg-end">
                            <button type="button" class="btn btn-primary fw-bold" id="btnSearch"><i class="fas fa-search me-1"></i>ค้นหา</button>
                        </div>
                    </div>
                </div>
            </div>

            <div id="errBox" class="alert alert-danger d-none"></div>

            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div class="table-wrap">
                        <table class="table table-hover table-sm mb-0" id="stockTable">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>รหัส</th>
                                    <th>ชื่อรายการ</th>
                                    <th>Lot คงเหลือ / EXP</th>
                                    <th class="text-end">คงเหลือ</th>
                                    <th class="text-end">Min</th>
                                    <th class="text-end">Max</th>
                                    <th class="text-end">ใช้/เดือน</th>
                                    <th class="text-end">Min แนะนำ</th>
                                    <th class="text-end">Max แนะนำ</th>
                                    <th class="text-end">รอตรวจรับ</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="stockBody">
                                <tr><td colspan="12" class="text-center text-muted py-4">กำลังโหลดสต็อก…</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div class="small text-muted" id="pageInfo">—</div>
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-secondary" id="btnPrev">ก่อนหน้า</button>
                        <button type="button" class="btn btn-outline-secondary" id="btnNext">ถัดไป</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="histModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title mb-0" id="histTitle">ประวัติการเบิกจ่าย</h5>
                    <div class="small text-muted" id="histSub"></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-2 mb-3" id="histSummary"></div>
                <div class="fw-bold small mb-2">Lot ที่คงเหลือ</div>
                <div class="mb-3" id="histLots"></div>
                <div class="fw-bold small mb-2">เบิกรายเดือน (6 เดือนล่าสุด)</div>
                <div class="d-flex flex-wrap gap-2 mb-3" id="histMonths"></div>
                <div class="table-responsive">
                    <table class="table table-sm table-bordered mb-0" id="histTable">
                        <thead>
                            <tr>
                                <th>วันที่</th>
                                <th>เลขที่</th>
                                <th>หน่วยงาน</th>
                                <th class="text-end">จำนวนเบิก</th>
                                <th class="text-end">คงเหลือหลังเบิก</th>
                                <th class="text-end">มูลค่า</th>
                            </tr>
                        </thead>
                        <tbody id="histBody"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const state = { page: 1, status: 'all', pages: 1, forceSheet: false };
let timer = null;

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function num(n) {
    const x = Number(n);
    if (!isFinite(x)) return '—';
    return x.toLocaleString('th-TH', { maximumFractionDigits: 2 });
}
function flagHtml(flag) {
    if (flag === 'low') return '<span class="flag-low" title="ต่ำกว่า Min"><i class="fas fa-arrow-down"></i></span>';
    if (flag === 'high') return '<span class="flag-high" title="สูงกว่า Max"><i class="fas fa-arrow-up"></i></span>';
    return '<span class="flag-ok" title="อยู่ในช่วง Min–Max"><i class="fas fa-check"></i></span>';
}
function pendingIcon(row) {
    if (!row.pending_recv) return '';
    const tip = 'รอตรวจรับ · วันที่รับ ' + (row.pending_recv_date || '—') +
        (row.last_dispense ? ' (จ่ายล่าสุด ' + row.last_dispense + ')' : '');
    return '<span class="flag-pending" title="' + esc(tip) + '"><i class="fas fa-truck-loading"></i></span>';
}
function pendingQty(row) {
    if (!row.pending_recv) return '<span class="text-muted">—</span>';
    const pack = Number(row.pending_pack || 0);
    const order = Number(row.pending_order || 0);
    let html = '<div class="pending-cell">' + num(pack) + ' × ' + num(order) + '</div>';
    if (Number(row.pending_lines || 0) > 1) {
        html += '<div class="small text-muted">' + Number(row.pending_lines) + ' ใบสั่ง</div>';
    }
    if (row.pending_recv_date) {
        html += '<div class="small text-muted">รับ ' + esc(row.pending_recv_date) + '</div>';
    }
    return html;
}
function expIcons(row) {
    let html = '';
    if (row.exp_flag === 'expired') html += '<span class="flag-expired" title="มียาหมดอายุแล้ว"><i class="fas fa-calendar-times"></i></span>';
    else if (row.exp_flag === 'soon') html += '<span class="flag-soon" title="หมดอายุภายใน 6 เดือน"><i class="fas fa-hourglass-half"></i></span>';
    if (row.use_risk) html += '<span class="flag-risk" title="จำนวนคงเหลือเทียบอัตราใช้ต่อเดือนแล้วไม่ทันก่อนหมดอายุ"><i class="fas fa-exclamation-triangle"></i></span>';
    return html;
}
function lotHtml(lots) {
    if (!lots || !lots.length) return '<span class="text-muted small">ไม่มี Lot</span>';
    return lots.map(function (lot) {
        let exp = 'ไม่ระบุ EXP';
        let expClass = 'text-muted';
        if (lot.exp) {
            exp = 'EXP ' + lot.exp;
            if (lot.level === 'expired') { expClass = 'lot-expired'; exp += ' หมดแล้ว'; }
            else if (lot.level === 'soon') { expClass = 'lot-soon'; exp += ' อีก ' + lot.days_left + ' วัน'; }
        }
        const risk = lot.risk
            ? ' <span class="flag-risk" title="คาดว่าเหลืออีก ' + num(lot.short_qty) + ' เมื่อถึงวันหมดอายุ"><i class="fas fa-exclamation-triangle"></i></span>'
            : '';
        const soonIcon = lot.level === 'expired'
            ? ' <span class="flag-expired" title="หมดอายุแล้ว"><i class="fas fa-calendar-times"></i></span>'
            : (lot.level === 'soon' ? ' <span class="flag-soon" title="หมดอายุภายใน 6 เดือน"><i class="fas fa-hourglass-half"></i></span>' : '');
        return '<div class="lot-line"><span class="fw-bold">' + esc(lot.lot_no || '—') + '</span>' +
            '<span>' + num(lot.qty) + '</span>' +
            '<span class="' + expClass + '">' + esc(exp) + '</span>' + soonIcon + risk + '</div>';
    }).join('');
}
function qtyClass(flag) {
    if (flag === 'low') return 'qty-low';
    if (flag === 'high') return 'qty-high';
    return 'fw-bold';
}

function load() {
    const body = document.getElementById('stockBody');
    body.innerHTML = '<tr><td colspan="12" class="text-center text-muted py-4">กำลังโหลด…</td></tr>';
    document.getElementById('errBox').classList.add('d-none');
    const payload = {
        action: 'list',
        q: document.getElementById('q').value.trim(),
        status: state.status,
        include_inactive: document.getElementById('includeInactive').checked ? 1 : 0,
        page: state.page,
        per_page: 200,
        sort: document.getElementById('sort').value,
        force_sheet: state.forceSheet ? 1 : 0
    };
    state.forceSheet = false;
    fetch('fetch_invc_stock_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    }).then(r => r.json()).then(res => {
        if (res.status !== 'success') {
            document.getElementById('errBox').textContent = res.message || 'โหลดไม่ได้';
            document.getElementById('errBox').classList.remove('d-none');
            body.innerHTML = '<tr><td colspan="12" class="text-center text-danger py-4">โหลดสต็อกไม่ได้</td></tr>';
            return;
        }
        const s = res.summary || {};
        document.getElementById('kpiTotal').textContent = num(s.total);
        document.getElementById('kpiLow').textContent = num(s.low);
        document.getElementById('kpiHigh').textContent = num(s.high);
        document.getElementById('kpiOk').textContent = num(s.ok);
        document.getElementById('kpiZero').textContent = num(s.zero);
        document.getElementById('kpiPending').textContent = num(s.pending);
        document.getElementById('kpiSoon').textContent = num(s.soon);
        document.getElementById('kpiRisk').textContent = num(s.risk);
        const gs = res.gsheet || {};
        let pageInfo = 'แสดง ' + (res.rows || []).length + ' จาก ' + num(res.filtered) + ' รายการ · หน้า ' + (res.page || 1) + '/' + (res.pages || 1);
        if (gs.enabled && gs.ok === false && gs.error) {
            pageInfo += ' · Sheet: ' + gs.error;
        } else if (gs.enabled && gs.ok) {
            const mode = gs.mode === 'service_account' ? 'SA' : (gs.mode === 'csv' ? 'CSV' : 'Sheet');
            pageInfo += ' · ' + mode + ' ' + num(gs.row_count) + ' แถว' + (gs.from_cache ? ' (cache)' : ' (สด)');
            if (gs.sheet_title) pageInfo += ' · ' + gs.sheet_title;
        }
        state.pages = res.pages || 1;
        state.page = res.page || 1;
        document.getElementById('pageInfo').textContent = pageInfo;
        if (!res.rows || !res.rows.length) {
            body.innerHTML = '<tr><td colspan="12" class="text-center text-muted py-4">ไม่พบรายการ</td></tr>';
            return;
        }
        body.innerHTML = res.rows.map(r => {
            const unit = r.unit ? ' <span class="text-muted">' + esc(r.unit) + '</span>' : '';
            return '<tr>' +
                '<td><div class="d-flex flex-wrap gap-1">' + flagHtml(r.flag) + expIcons(r) + pendingIcon(r) + '</div></td>' +
                '<td class="text-nowrap">' + esc(r.code) + '</td>' +
                '<td><div class="fw-bold">' + esc(r.name) + '</div>' +
                    (r.location ? '<div class="small text-muted">' + esc(r.location) + '</div>' : '') +
                '</td>' +
                '<td>' + lotHtml(r.lots) + '</td>' +
                '<td class="text-end ' + qtyClass(r.flag) + '">' + num(r.qty) + unit + '</td>' +
                '<td class="text-end">' + (Number(r.min) > 0 ? num(r.min) : '<span class="text-muted">—</span>') + '</td>' +
                '<td class="text-end">' + (Number(r.max) > 0 ? num(r.max) : '<span class="text-muted">—</span>') + '</td>' +
                '<td class="text-end"><div class="fw-bold">' + num(r.monthly_rate) + '</div>' +
                    '<div class="small text-muted">เบิก ' + num(r.issued_6m) + '</div></td>' +
                '<td class="text-end suggest">' + num(r.suggest_min) + '</td>' +
                '<td class="text-end suggest">' + num(r.suggest_max) + '</td>' +
                '<td class="text-end' + (r.pending_recv ? ' pending-blink' : '') + '">' + pendingQty(r) + '</td>' +
                '<td class="text-end"><button type="button" class="btn btn-outline-primary btn-sm btn-hist" data-code="' + esc(r.code) + '"><i class="fas fa-history me-1"></i>ประวัติ</button></td>' +
            '</tr>';
        }).join('');
    }).catch(() => {
        document.getElementById('errBox').textContent = 'ติดต่อเซิร์ฟเวอร์ไม่ได้';
        document.getElementById('errBox').classList.remove('d-none');
    });
}

function openHistory(code) {
    const body = document.getElementById('histBody');
    body.innerHTML = '<tr><td colspan="6" class="text-center text-muted">กำลังโหลด…</td></tr>';
    document.getElementById('histMonths').innerHTML = '';
    document.getElementById('histSummary').innerHTML = '';
    document.getElementById('histLots').innerHTML = '';
    new bootstrap.Modal(document.getElementById('histModal')).show();
    fetch('fetch_invc_stock_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'history', code: code })
    }).then(r => r.json()).then(res => {
        if (res.status !== 'success') {
            body.innerHTML = '<tr><td colspan="6" class="text-danger">' + esc(res.message || 'โหลดไม่ได้') + '</td></tr>';
            return;
        }
        const item = res.item || {};
        document.getElementById('histTitle').textContent = item.name || code;
        document.getElementById('histSub').textContent = (item.code || code) + (item.unit ? ' · หน่วย ' + item.unit : '') + (item.location ? ' · ' + item.location : '');
        const cards = [
            ['คงเหลือ', num(item.qty), qtyClass(item.flag)],
            ['Min / Max', num(item.min) + ' / ' + num(item.max), ''],
            ['ใช้/เดือน', num(item.monthly_rate), ''],
            ['แนะนำ', num(item.suggest_min) + ' – ' + num(item.suggest_max), 'text-primary']
        ];
        document.getElementById('histSummary').innerHTML = cards.map(c =>
            '<div class="col-6 col-md-3"><div class="border rounded p-2"><div class="small text-muted">' + c[0] + '</div><div class="fw-bold ' + c[2] + '">' + c[1] + '</div></div></div>'
        ).join('');
        document.getElementById('histLots').innerHTML = lotHtml(item.lots);
        const months = res.by_month || [];
        document.getElementById('histMonths').innerHTML = months.length ? months.map(m =>
            '<span class="badge bg-light text-dark border">เดือน ' + m.month + '/' + m.year + ' · ' + num(m.qty) + ' (' + m.count + ' ใบ)</span>'
        ).join('') : '<span class="text-muted small">ไม่มีรายการเบิกในช่วง 6 เดือน</span>';
        const rows = res.history || [];
        body.innerHTML = rows.length ? rows.map(h =>
            '<tr><td>' + esc(h.date) + '</td><td>' + esc(h.doc_no) + '</td><td>' + esc(h.dept_name || h.dept_id) + '</td>' +
            '<td class="text-end fw-bold">' + num(h.qty) + '</td><td class="text-end">' + num(h.remain) + '</td><td class="text-end">' + num(h.value) + '</td></tr>'
        ).join('') : '<tr><td colspan="6" class="text-center text-muted">ไม่มีประวัติการเบิกจ่าย</td></tr>';
    });
}

document.getElementById('btnRefreshSheet').addEventListener('click', function () {
    state.forceSheet = true;
    load();
});
document.getElementById('btnSearch').addEventListener('click', function () { state.page = 1; load(); });
document.getElementById('q').addEventListener('input', function () {
    clearTimeout(timer);
    timer = setTimeout(function () { state.page = 1; load(); }, 350);
});
document.getElementById('q').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { state.page = 1; load(); }
});
document.getElementById('sort').addEventListener('change', function () { state.page = 1; load(); });
document.getElementById('includeInactive').addEventListener('change', function () { state.page = 1; load(); });
document.getElementById('btnPrev').addEventListener('click', function () {
    if (state.page > 1) { state.page--; load(); }
});
document.getElementById('btnNext').addEventListener('click', function () {
    if (state.page < state.pages) { state.page++; load(); }
});
document.getElementById('kpiRow').addEventListener('click', function (e) {
    const card = e.target.closest('[data-status]');
    if (!card) return;
    state.status = card.getAttribute('data-status');
    state.page = 1;
    document.querySelectorAll('.invc-kpi').forEach(el => el.classList.toggle('active', el === card));
    load();
});
document.getElementById('stockBody').addEventListener('click', function (e) {
    const btn = e.target.closest('.btn-hist');
    if (btn) openHistory(btn.getAttribute('data-code'));
});
load();
</script>
</body>
</html>
