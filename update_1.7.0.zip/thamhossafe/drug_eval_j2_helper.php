<?php

function dej2_h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function dej2_lower($s) {
    $s = (string)$s;
    return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
}

function dej2_has($hay, $needle) {
    $hay = (string)$hay;
    $needle = (string)$needle;
    if ($needle === '') {
        return false;
    }
    if (function_exists('mb_strpos')) {
        return mb_strpos($hay, $needle, 0, 'UTF-8') !== false;
    }
    return strpos($hay, $needle) !== false;
}

function dej2_cut($s, $n) {
    $s = trim((string)$s);
    $n = (int)$n;
    if (function_exists('mb_substr')) {
        return mb_substr($s, 0, $n);
    }
    return substr($s, 0, $n);
}

function dej2_ensure($con) {
    mysqli_query($con, "CREATE TABLE IF NOT EXISTS drug_eval_j2_sheet (
        id INT AUTO_INCREMENT PRIMARY KEY,
        hn VARCHAR(20) NOT NULL DEFAULT '',
        an VARCHAR(16) NOT NULL DEFAULT '',
        icode VARCHAR(24) NOT NULL DEFAULT '',
        drug_name VARCHAR(255) NOT NULL DEFAULT '',
        form_id VARCHAR(40) NOT NULL DEFAULT '',
        phase VARCHAR(12) NOT NULL DEFAULT '',
        answers MEDIUMTEXT,
        evaluator VARCHAR(120) NOT NULL DEFAULT '',
        user_id INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
}

function dej2_forms() {
    $beva_dose_note = 'ขนาดยาที่แนะนำ'
        . "\n1) bevacizumab 7.5 mg/kg ร่วมกับสูตรยาเคมีบำบัด ทุก 3 สัปดาห์ จำนวน 5–6 cycles"
        . "\n2) maintenance bevacizumab 7.5 mg/kg ทุก 3 สัปดาห์ จำนวนไม่เกิน 18 cycles นับตั้งแต่ใช้ยาครั้งแรก";
    $erlo_dose_note = 'ไม่อนุมัติให้ใช้ยา erlotinib เกินกว่าขนาด 150 มิลลิกรัมต่อวัน แม้ว่าการให้ยาไม่ได้ผลหรือโรคลุกลามขึ้นขณะให้ยา';
    return [
        'bevacizumab_ovarian' => [
            'label' => 'Bevacizumab',
            'hint' => 'มะเร็งรังไข่ · ครั้งแรก / ต่อเนื่อง',
            'kicker' => 'แบบฟอร์ม จ(2)',
            'doc_title' => 'แบบฟอร์มกำกับการใช้ยา bevacizumab',
            'condition' => 'เงื่อนไข โรคมะเร็งรังไข่ชนิดเยื่อบุผิว มะเร็งเยื่อบุท่อนำไข่ หรือมะเร็งเยื่อบุช่องท้องชนิดปฐมภูมิ',
            'footnote' => '(รายละเอียดการใช้ยาโปรดอ้างอิงจากแนวทางกำกับการใช้ยาตามบัญชียาหลักแห่งชาติ)',
            'sex_mode' => 'female',
            'phases' => [
                'first' => [
                    'subtitle' => 'bevacizumab _ ovarian cancer ครั้งแรก',
                    'case' => 'กรณีขออนุมัติใช้ครั้งแรก',
                    'part2' => 'ส่วนที่ 2 ข้อมูลประกอบการอนุมัติและข้อมูลการใช้ยา กรณีขออนุมัติใช้ยาครั้งแรก',
                    'blocks' => [
                        ['t' => 'date', 'id' => 'req_date', 'label' => 'วัน/เดือน/ปีที่ขออนุมัติ'],
                        ['t' => 'yn', 'id' => 'q1', 'text' => '1. ผู้ป่วยไม่อยู่ในภาวะ terminally ill'],
                        ['t' => 'yn', 'id' => 'q2', 'text' => '2. ผู้ป่วยได้รับการตรวจวินิจฉัยว่าเป็นโรคมะเร็ง ตามข้อใดข้อหนึ่ง ดังต่อไปนี้'],
                        ['t' => 'check', 'id' => 'c21', 'text' => '2.1 มะเร็งรังไข่ชนิดเยื่อบุผิว (epithelial ovarian cancer)'],
                        ['t' => 'check', 'id' => 'c22', 'text' => '2.2 มะเร็งเยื่อบุท่อนำไข่ (fallopian tube cancer)'],
                        ['t' => 'check', 'id' => 'c23', 'text' => '2.3 มะเร็งเยื่อบุช่องท้องชนิดปฐมภูมิ (primary peritoneal cancer)'],
                        ['t' => 'note', 'text' => 'โดยมีการยืนยันผลด้วยการตรวจทางพยาธิวิทยา'],
                        ['t' => 'yn', 'id' => 'q3', 'text' => '3. ผู้ป่วยมีลักษณะ ตามข้อใดข้อหนึ่ง ดังต่อไปนี้'],
                        ['t' => 'check', 'id' => 'c31', 'text' => '3.1 เป็นผู้ป่วยระยะที่ IIIB–IIIC ที่ได้รับการผ่าตัด (debulked) แล้วมีขนาดก้อนเหลือมากกว่า 1 เซนติเมตร พร้อมแนบหลักฐานสนับสนุน เช่น บันทึกการผ่าตัด หรือผลการตรวจทางรังสีวินิจฉัยหลังการผ่าตัดที่บ่งชี้ถึงรอยโรค'],
                        ['t' => 'check', 'id' => 'c32', 'text' => '3.2 เป็นผู้ป่วยระยะลุกลาม (ระยะที่ IV) พร้อมแนบหลักฐานสนับสนุน เช่น รายงานการผ่าตัด รายงานผลการตรวจทางรังสีวินิจฉัย'],
                        ['t' => 'yn', 'id' => 'q4', 'text' => '4. ผู้ป่วยมี ECOG performance status ตั้งแต่ 0 ถึง 1'],
                        ['t' => 'radios', 'id' => 'ecog', 'text' => 'โปรดระบุ ECOG performance status ของผู้ป่วย', 'opts' => ['0', '1', '2', '3', '4']],
                        ['t' => 'yn', 'id' => 'q5', 'text' => '5. ใช้ยา bevacizumab เป็นยาขนานแรกร่วมกับยาเคมีบำบัดสูตรมาตรฐาน โดยไม่เป็นการใช้ยา bevacizumab เป็นยาเดี่ยว หรือใช้ในกรณี subsequent therapy'],
                        ['t' => 'line', 'id' => 'dose', 'before' => '6. ขนาดยา bevacizumab ที่ขออนุมัติใช้', 'after' => 'มิลลิกรัม'],
                        ['t' => 'note', 'text' => $beva_dose_note],
                        ['t' => 'range', 'from' => 'use_from', 'to' => 'use_to', 'label' => '7. ระยะเวลาที่ขอใช้ยา', 'hint' => 'ขออนุมัติให้ใช้ยาไม่เกิน 4 เดือน'],
                        ['t' => 'sign', 'break' => true],
                        ['t' => 'barthel', 'break' => true],
                    ],
                ],
                'cont' => [
                    'subtitle' => 'bevacizumab _ ovarian cancer ต่อเนื่อง',
                    'case' => 'กรณีขออนุมัติใช้ยาต่อเนื่อง',
                    'part2' => 'ส่วนที่ 2 ข้อมูลประกอบการอนุมัติและข้อมูลการใช้ยา กรณีขออนุมัติใช้ยาต่อเนื่อง',
                    'blocks' => [
                        ['t' => 'times', 'id' => 'round', 'label' => 'ครั้งที่ขอต่อเนื่อง'],
                        ['t' => 'date', 'id' => 'req_date', 'label' => 'วัน/เดือน/ปีที่ขออนุมัติ'],
                        ['t' => 'yn', 'id' => 'q1', 'text' => '1. ผู้ป่วยไม่อยู่ในภาวะ terminally ill'],
                        ['t' => 'yn', 'id' => 'q2', 'text' => '2. ผู้ป่วยสามารถรับการรักษาต่อเนื่องได้'],
                        ['t' => 'date', 'id' => 'eval_date', 'label' => 'วัน/เดือน/ปีที่ประเมิน'],
                        ['t' => 'note', 'text' => 'ยืนยันด้วยผลการประเมินรอยโรคด้วยการตรวจทางรังสีวินิจฉัยในบริเวณรอยโรคที่วัดได้'],
                        ['t' => 'date', 'id' => 'last_status_date', 'label' => 'สรุปผลประเมินสภาวะโรคครั้งล่าสุด เมื่อวันที่'],
                        ['t' => 'radios', 'id' => 'response', 'text' => 'ผลการประเมิน', 'opts' => [
                            'complete' => 'complete response',
                            'partial' => 'partial response',
                            'stable' => 'stable disease',
                            'progression' => 'progression of disease (เข้าเกณฑ์การหยุดใช้ยา)',
                        ]],
                        ['t' => 'date', 'id' => 'last_dose_date', 'label' => 'ผู้ป่วยได้รับยา bevacizumab ครั้งล่าสุด เมื่อวันที่'],
                        ['t' => 'line', 'id' => 'cycle_no', 'before' => 'การให้ยาครั้งนี้ เป็นครั้งที่', 'after' => ''],
                        ['t' => 'line', 'id' => 'dose', 'before' => 'ขนาดยา bevacizumab ที่ขออนุมัติใช้', 'after' => 'มิลลิกรัม'],
                        ['t' => 'note', 'text' => $beva_dose_note],
                        ['t' => 'range', 'from' => 'use_from', 'to' => 'use_to', 'label' => 'ระยะเวลาที่ขอใช้ยา', 'hint' => 'ขออนุมัติใช้ยาทุก 3 เดือน'],
                        ['t' => 'sign'],
                    ],
                ],
            ],
        ],
        'erlotinib' => [
            'label' => 'Erlotinib',
            'hint' => 'NSCLC · ครั้งแรก / ต่อเนื่อง',
            'kicker' => 'แบบฟอร์ม จ(2)',
            'doc_title' => 'แบบฟอร์มกำกับการใช้ยา Erlotinib',
            'condition' => 'ข้อบ่งใช้ non-small-cell lung carcinoma (NSCLC) ระยะลุกลามถึงแพร่กระจาย ที่มีผลตรวจการกลายพันธุ์ของยีน epidermal growth factor receptor (EGFR) เป็นบวก',
            'footnote' => '(รายละเอียดการใช้ยาโปรดอ้างอิงจากแนวทางกำกับการใช้ยาตามบัญชียาหลักแห่งชาติ)',
            'sex_mode' => 'choice',
            'phases' => [
                'first' => [
                    'subtitle' => 'Erlotinib _ NSCLC ครั้งแรก',
                    'case' => 'กรณีขออนุมัติใช้ยาครั้งแรก',
                    'part2' => 'ส่วนที่ 2 ข้อมูลประกอบการอนุมัติและข้อมูลการใช้ยา กรณีขออนุมัติใช้ยาครั้งแรก',
                    'blocks' => [
                        ['t' => 'date', 'id' => 'req_date', 'label' => 'วัน/เดือน/ปีที่ขออนุมัติ'],
                        ['t' => 'yn', 'id' => 'q1', 'text' => '1. ผู้ป่วยไม่อยู่ในภาวะ terminally ill'],
                        ['t' => 'radios', 'id' => 'ecog_band', 'text' => '2. ผู้ป่วยอยู่ในสภาพร่างกายดีพอสมควร ตามเกณฑ์ ECOG ข้อใดข้อหนึ่ง', 'opts' => [
                            'e02' => 'ECOG performance status 0–2',
                            'e34' => 'ECOG performance status 3–4 ที่เป็นผลจากโรค NSCLC ไม่ได้เกิดจาก co-morbidity อื่น',
                        ]],
                        ['t' => 'note', 'text' => '3. ตรวจพบการกลายพันธุ์ของยีน EGFR ชนิดที่ไวต่อยา tyrosine kinase inhibitor'],
                        ['t' => 'pair', 'id' => 'g19', 'text' => '3.1 exon 19 deletion'],
                        ['t' => 'pair', 'id' => 'g21', 'text' => '3.2 exon 21 [L858R] substitution mutations'],
                        ['t' => 'pair', 'id' => 'g861', 'text' => '3.3 L861Q'],
                        ['t' => 'pair', 'id' => 'g719', 'text' => '3.4 G719X'],
                        ['t' => 'note', 'text' => '4. ผู้ป่วยได้รับการตรวจ'],
                        ['t' => 'check', 'id' => 'img_ct', 'text' => 'computerized tomography (CT)'],
                        ['t' => 'check', 'id' => 'img_mri', 'text' => 'magnetic resonance imaging (MRI)'],
                        ['t' => 'yn', 'id' => 'q41', 'text' => '4.1 เป็นผู้ป่วย NSCLC ระยะลุกลามเฉพาะที่ ที่มีการลุกลามเพิ่มขึ้นหลังได้รับการรักษาด้วยการฉายรังสี'],
                        ['t' => 'yn', 'id' => 'q42', 'text' => '4.2 เป็นผู้ป่วย NSCLC ที่มีการกระจายของโรค ที่ปรากฏรอยโรคที่สามารถประเมินการตอบสนองทางคลินิกและการตรวจทางรังสีได้'],
                        ['t' => 'yn', 'id' => 'q5', 'text' => '5. ผู้ป่วยไม่เคยได้รับการรักษาด้วยยาอื่นใดมาก่อน อนุมัติให้ใช้ยา erlotinib เป็นยาขนานแรก (first line drug)'],
                        ['t' => 'line', 'id' => 'every_days', 'before' => '6. ขนาดยา erlotinib ที่จะใช้คือ 150 มิลลิกรัม ทุก', 'after' => 'วัน'],
                        ['t' => 'note', 'text' => $erlo_dose_note],
                        ['t' => 'range', 'from' => 'use_from', 'to' => 'use_to', 'label' => '7. เริ่มต้นให้ยา', 'hint' => 'อนุมัติให้ยาไม่เกิน 90 วันในครั้งแรก'],
                        ['t' => 'sign', 'break' => true],
                    ],
                ],
                'cont' => [
                    'subtitle' => 'Erlotinib _ NSCLC ต่อเนื่อง',
                    'case' => 'กรณีขออนุมัติใช้ยาต่อเนื่อง',
                    'part2' => 'ส่วนที่ 2 ข้อมูลประกอบการอนุมัติและข้อมูลการใช้ยา กรณีขออนุมัติใช้ยาต่อเนื่อง',
                    'blocks' => [
                        ['t' => 'yn', 'id' => 'q1', 'text' => '1. ผู้ป่วยไม่อยู่ในภาวะ terminally ill'],
                        ['t' => 'yn', 'id' => 'q2', 'text' => '2. ผู้ป่วยตอบสนองต่อการรักษา'],
                        ['t' => 'date', 'id' => 'eval_date', 'label' => 'วัน/เดือน/ปีที่ประเมิน (ประเมินผลการรักษาทุก 8–12 สัปดาห์)'],
                        ['t' => 'check', 'id' => 'img_ct', 'text' => 'computerized tomography (CT)'],
                        ['t' => 'check', 'id' => 'img_mri', 'text' => 'magnetic resonance imaging (MRI)'],
                        ['t' => 'radios', 'id' => 'response', 'text' => '3. สรุปผลการประเมินการตอบสนองต่อการรักษา', 'opts' => [
                            'stable' => 'stable disease to complete response',
                            'progress' => 'progressive disease',
                        ]],
                        ['t' => 'yn', 'id' => 'q4', 'text' => '4. ผู้ป่วยทนต่ออาการไม่พึงประสงค์จากการใช้ยาได้'],
                        ['t' => 'line', 'id' => 'every_days', 'before' => '5. ขนาดยา erlotinib ที่จะใช้คือ 150 มิลลิกรัม ทุก', 'after' => 'วัน'],
                        ['t' => 'note', 'text' => $erlo_dose_note],
                        ['t' => 'sign'],
                    ],
                ],
            ],
        ],
    ];
}

function dej2_form($id) {
    $all = dej2_forms();
    return $all[$id] ?? null;
}

function dej2_phase_label($phase) {
    return $phase === 'cont' ? 'ต่อเนื่อง' : 'ครั้งแรก';
}

function dej2_bucket($name) {
    $n = dej2_lower($name);
    if (dej2_has($n, 'bevacizumab')) {
        if (dej2_has($n, '1.25')) {
            return ['key' => 'bevacizumab_eye', 'label' => 'Bevacizumab 1.25 mg', 'form' => null, 'hint' => 'ใช้ในตา — ยังไม่มีแบบฟอร์มนี้'];
        }
        return ['key' => 'bevacizumab', 'label' => 'Bevacizumab', 'form' => 'bevacizumab_ovarian', 'hint' => 'มะเร็งรังไข่ · ครั้งแรก / ต่อเนื่อง'];
    }
    $known = [
        'erlotinib' => ['Erlotinib', 'erlotinib', 'NSCLC · ครั้งแรก / ต่อเนื่อง'],
        'rituximab' => ['Rituximab', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'trastuzumab' => ['Trastuzumab', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'imatinib' => ['Imatinib', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'nilotinib' => ['Nilotinib', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'dasatinib' => ['Dasatinib', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'bortezomib' => ['Bortezomib', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'bendamustine' => ['Bendamustine', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'infliximab' => ['Infliximab', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'deferasirox' => ['Deferasirox', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'voriconazole' => ['Voriconazole', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'ivig' => ['IVIG', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'prothromplex' => ['Prothrombin complex (4F-PCC)', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
        'ceftazidime' => ['Ceftazidime/Avibactam', null, 'ยังไม่มีแบบกำกับการใช้ยา'],
    ];
    foreach ($known as $needle => $meta) {
        if (dej2_has($n, $needle)) {
            return ['key' => $needle, 'label' => $meta[0], 'form' => $meta[1], 'hint' => $meta[2]];
        }
    }
    foreach (['epoetin', 'espogen', 'epiao', 'hema-plus', 'hema plus', 'hypercrit', 'renogen', 'binocrit'] as $needle) {
        if (dej2_has($n, $needle)) {
            return ['key' => 'epoetin', 'label' => 'Epoetin', 'form' => null, 'hint' => 'ยังไม่มีแบบกำกับการใช้ยา'];
        }
    }
    $label = preg_replace('/^\([^)]*\)\s*/u', '', (string)$name);
    $label = trim(preg_replace('/\s+/u', ' ', (string)$label));
    if ($label === '') {
        $label = (string)$name;
    }
    return ['key' => 'n_' . substr(md5($label), 0, 10), 'label' => $label, 'form' => null, 'hint' => 'ยังไม่มีแบบกำกับการใช้ยา'];
}

function dej2_load_patient($hos, $hn) {
    $p = pop_fetch_patient($hos, $hn);
    if (!$p) {
        return null;
    }
    $in = pop_hn_in($hos, $p['hn']);
    $p['an'] = '';
    $p['ward'] = '';
    $p['pttype_name'] = '';
    $p['age_y'] = '';
    $p['age_m'] = '';
    $p['birth_th'] = '';
    if ($in !== '') {
        $adm = pop_query_one($hos, "SELECT i.an,
                CAST(CONVERT(IFNULL(w.name,'') USING utf8) AS CHAR) AS ward,
                CAST(CONVERT(IFNULL(pt.name,'') USING utf8) AS CHAR) AS pttype_name
            FROM ipt i
            LEFT JOIN ward w ON w.ward = i.ward
            LEFT JOIN pttype pt ON pt.pttype = i.pttype
            WHERE i.hn IN ($in)
              AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00' OR TRIM(i.dchdate) = '')
            ORDER BY i.regdate DESC, i.an DESC
            LIMIT 1");
        if ($adm) {
            $p['an'] = trim((string)($adm['an'] ?? ''));
            $p['ward'] = trim((string)($adm['ward'] ?? ''));
            $p['pttype_name'] = trim((string)($adm['pttype_name'] ?? ''));
        }
        if ($p['pttype_name'] === '') {
            $ov = pop_query_one($hos, "SELECT CAST(CONVERT(IFNULL(pt.name,'') USING utf8) AS CHAR) AS pttype_name
                FROM ovst o LEFT JOIN pttype pt ON pt.pttype = o.pttype
                WHERE o.hn IN ($in) ORDER BY o.vstdate DESC LIMIT 1");
            $p['pttype_name'] = trim((string)($ov['pttype_name'] ?? ''));
        }
    }
    $bday = substr(trim((string)($p['birthday'] ?? '')), 0, 10);
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $bday, $m) && $m[1] !== '0000') {
        $p['birth_th'] = $m[3] . '/' . $m[2] . '/' . ((int)$m[1] + 543);
        try {
            $diff = (new DateTime($bday))->diff(new DateTime('today'));
            $p['age_y'] = (string)$diff->y;
            $p['age_m'] = (string)$diff->m;
        } catch (Exception $e) {
        }
    }
    return $p;
}

function dej2_prefill(array $patient, array $answers) {
    $fill = [
        'fname' => trim((string)($patient['pname'] ?? '') . (string)($patient['fname'] ?? '')),
        'lname' => trim((string)($patient['lname'] ?? '')),
        'hn' => (string)($patient['hn_display'] ?? $patient['hn'] ?? ''),
        'hosp' => '10699',
        'cid' => (string)($patient['cid'] ?? ''),
        'birth' => (string)($patient['birth_th'] ?? ''),
        'age_y' => (string)($patient['age_y'] ?? ''),
        'age_m' => (string)($patient['age_m'] ?? ''),
        'sex' => (string)($patient['sex_label'] ?? ''),
        'right_other' => (string)($patient['pttype_name'] ?? ''),
    ];
    foreach ($fill as $k => $v) {
        if (!isset($answers[$k]) || trim((string)$answers[$k]) === '') {
            $answers[$k] = $v;
        }
    }
    return $answers;
}

function dej2_orders($hos, $hn, $an) {
    $in = pop_hn_in($hos, $hn);
    $rows = [];
    if ($an !== '') {
        $an_esc = mysqli_real_escape_string($hos, $an);
        $q = mysqli_query($hos, "SELECT m.icode,
                MAX(CAST(CONVERT(d.name USING utf8) AS CHAR)) AS name,
                MAX(DATE(m.orderdate)) AS od
            FROM medplan_ipd m
            INNER JOIN drugitems d ON d.icode = m.icode
            WHERE m.an = '$an_esc' AND TRIM(d.drugaccount) = 'จ2'
              AND (m.offdate IS NULL OR m.offdate = '0000-00-00' OR m.offdate = '0000-00-00 00:00:00')
            GROUP BY m.icode");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $rows[$r['icode']] = ['icode' => $r['icode'], 'name' => $r['name'], 'date' => $r['od'], 'where' => 'กำลังใช้ในหอ'];
            }
        }
    }
    if ($in !== '') {
        $q = mysqli_query($hos, "SELECT o.icode,
                MAX(CAST(CONVERT(d.name USING utf8) AS CHAR)) AS name,
                MAX(o.vstdate) AS od
            FROM opitemrece o
            INNER JOIN drugitems d ON d.icode = o.icode
            WHERE o.hn IN ($in) AND TRIM(d.drugaccount) = 'จ2'
              AND o.vstdate >= DATE_SUB(CURDATE(), INTERVAL 180 DAY)
            GROUP BY o.icode
            ORDER BY od DESC
            LIMIT 30");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                if (!isset($rows[$r['icode']])) {
                    $rows[$r['icode']] = ['icode' => $r['icode'], 'name' => $r['name'], 'date' => $r['od'], 'where' => 'จ่ายใน 180 วัน'];
                }
            }
        }
    }
    return array_values($rows);
}

function dej2_catalog($hos, array $orders) {
    $q = mysqli_query($hos, "SELECT icode, CAST(CONVERT(name USING utf8) AS CHAR) AS name
        FROM drugitems
        WHERE istatus = 'Y' AND TRIM(drugaccount) = 'จ2'
        ORDER BY name");
    $groups = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $b = dej2_bucket($r['name']);
            $key = $b['key'];
            if (!isset($groups[$key])) {
                $groups[$key] = $b + ['icode' => $r['icode'], 'drug_name' => $r['name'], 'ordered' => false, 'order_date' => '', 'order_where' => ''];
            }
        }
    }
    foreach ($orders as $ord) {
        $b = dej2_bucket($ord['name']);
        $key = $b['key'];
        if (!isset($groups[$key])) {
            $groups[$key] = $b + ['icode' => $ord['icode'], 'drug_name' => $ord['name'], 'ordered' => true, 'order_date' => $ord['date'], 'order_where' => $ord['where']];
        } else {
            $groups[$key]['ordered'] = true;
            $groups[$key]['icode'] = $ord['icode'];
            $groups[$key]['drug_name'] = $ord['name'];
            $groups[$key]['order_date'] = $ord['date'];
            $groups[$key]['order_where'] = $ord['where'];
        }
    }
    $list = array_values($groups);
    usort($list, function ($a, $b) {
        if ($a['ordered'] !== $b['ordered']) {
            return $a['ordered'] ? -1 : 1;
        }
        if (($a['form'] !== null) !== ($b['form'] !== null)) {
            return $a['form'] !== null ? -1 : 1;
        }
        return strcmp($a['label'], $b['label']);
    });
    return $list;
}

function dej2_drug_by_icode($hos, $icode) {
    $icode = trim((string)$icode);
    if ($icode === '') {
        return null;
    }
    $esc = mysqli_real_escape_string($hos, $icode);
    $q = mysqli_query($hos, "SELECT icode, CAST(CONVERT(name USING utf8) AS CHAR) AS name,
            CAST(CONVERT(IFNULL(drugaccount,'') USING utf8) AS CHAR) AS da
        FROM drugitems WHERE icode = '$esc' LIMIT 1");
    $r = $q ? mysqli_fetch_assoc($q) : null;
    return $r ?: null;
}

function dej2_clean_answers($src) {
    $out = [];
    if (!is_array($src)) {
        return $out;
    }
    foreach ($src as $k => $v) {
        $k = preg_replace('/[^a-z0-9_]/', '', (string)$k);
        if ($k === '') {
            continue;
        }
        if (is_array($v)) {
            continue;
        }
        $out[$k] = dej2_cut($v, 500);
    }
    return $out;
}

function dej2_save($con, $id, array $row) {
    $esc = function ($s, $n) use ($con) {
        return mysqli_real_escape_string($con, dej2_cut($s, $n));
    };
    $answers = mysqli_real_escape_string($con, json_encode($row['answers'], JSON_UNESCAPED_UNICODE));
    $id = (int)$id;
    if ($id > 0) {
        $ok = mysqli_query($con, "UPDATE drug_eval_j2_sheet SET
            hn='" . $esc($row['hn'], 20) . "',
            an='" . $esc($row['an'], 16) . "',
            icode='" . $esc($row['icode'], 24) . "',
            drug_name='" . $esc($row['drug_name'], 255) . "',
            form_id='" . $esc($row['form_id'], 40) . "',
            phase='" . $esc($row['phase'], 12) . "',
            answers='$answers',
            evaluator='" . $esc($row['evaluator'], 120) . "',
            updated_at=NOW()
            WHERE id=$id");
        return $ok ? $id : 0;
    }
    $ok = mysqli_query($con, "INSERT INTO drug_eval_j2_sheet
        (hn, an, icode, drug_name, form_id, phase, answers, evaluator, user_id, updated_at)
        VALUES (
            '" . $esc($row['hn'], 20) . "',
            '" . $esc($row['an'], 16) . "',
            '" . $esc($row['icode'], 24) . "',
            '" . $esc($row['drug_name'], 255) . "',
            '" . $esc($row['form_id'], 40) . "',
            '" . $esc($row['phase'], 12) . "',
            '$answers',
            '" . $esc($row['evaluator'], 120) . "',
            " . (int)$row['user_id'] . ",
            NOW()
        )");
    return $ok ? (int)mysqli_insert_id($con) : 0;
}

function dej2_get($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM drug_eval_j2_sheet WHERE id=$id LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return null;
    }
    $ans = json_decode((string)($row['answers'] ?? ''), true);
    $row['answers'] = is_array($ans) ? $ans : [];
    return $row;
}

function dej2_recent($con, $hn, $limit = 8) {
    $limit = max(1, min(20, (int)$limit));
    $where = '';
    $hn = dej2_cut($hn, 20);
    if ($hn !== '') {
        $pad = ctype_digit($hn) ? str_pad(ltrim($hn, '0'), 9, '0', STR_PAD_LEFT) : $hn;
        $trim = ctype_digit($hn) ? ltrim($hn, '0') : $hn;
        if ($trim === '') {
            $trim = '0';
        }
        $where = "WHERE hn IN ('" . mysqli_real_escape_string($con, $hn) . "','" . mysqli_real_escape_string($con, $pad) . "','" . mysqli_real_escape_string($con, $trim) . "')";
    }
    $q = mysqli_query($con, "SELECT id, hn, drug_name, form_id, phase, evaluator, created_at, updated_at
        FROM drug_eval_j2_sheet $where ORDER BY id DESC LIMIT $limit");
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function dej2_val(array $a, $key) {
    return trim((string)($a[$key] ?? ''));
}

function dej2_box($on) {
    return '<span class="box">' . ($on ? '✓' : '') . '</span>';
}

function dej2_radio($name, $value, $current, $print) {
    $on = (string)$current === (string)$value;
    if ($print) {
        return dej2_box($on);
    }
    return '<input type="radio" name="a[' . dej2_h($name) . ']" value="' . dej2_h($value) . '"' . ($on ? ' checked' : '') . '>';
}

function dej2_check($name, $current, $print, $text) {
    $on = $current === '1' || $current === 'Y';
    if ($print) {
        return '<div class="sub">' . dej2_box($on) . ' ' . dej2_h($text) . '</div>';
    }
    return '<label class="chk"><input type="checkbox" name="a[' . dej2_h($name) . ']" value="1"' . ($on ? ' checked' : '') . '><span>' . dej2_h($text) . '</span></label>';
}

function dej2_line($name, $value, $print, $wide) {
    if ($print) {
        $shown = $value !== '' ? dej2_h($value) : '………………';
        return '<span class="fill' . ($wide ? ' fill-wide' : '') . '">' . $shown . '</span>';
    }
    $cls = $wide ? 'line wide' : 'line';
    return '<input class="' . $cls . '" name="a[' . dej2_h($name) . ']" value="' . dej2_h($value) . '">';
}

function dej2_barthel_items() {
    return [
        ['id' => 'adl1', 'title' => '1. Feeding (รับประทานอาหารเมื่อเตรียมสำรับไว้ให้เรียบร้อยต่อหน้า)', 'opts' => [
            '0' => 'ไม่สามารถตักอาหารเข้าปากได้ ต้องมีคนป้อนให้',
            '1' => 'ตักอาหารเองได้แต่ต้องมีคนช่วย เช่น ช่วยใช้ช้อนตักเตรียมไว้ให้หรือตัดเป็นเล็ก ๆ ไว้ล่วงหน้า',
            '2' => 'ตักอาหารและช่วยตัวเองได้เป็นปกติ',
        ]],
        ['id' => 'adl2', 'title' => '2. Grooming (ล้างหน้า หวีผม แปรงฟัน โกนหนวด ใน 24–48 ชั่วโมงที่ผ่านมา)', 'opts' => [
            '0' => 'ต้องการความช่วยเหลือ',
            '1' => 'ทำเองได้ (รวมทั้งที่ทำได้เองถ้าเตรียมอุปกรณ์ไว้ให้)',
        ]],
        ['id' => 'adl3', 'title' => '3. Transfer (ลุกนั่งจากที่นอน หรือจากเตียงไปยังเก้าอี้)', 'opts' => [
            '0' => 'ไม่สามารถนั่งได้ หรือต้องใช้คนสองคนช่วยกันยกขึ้น',
            '1' => 'ต้องการความช่วยเหลืออย่างมากจึงจะนั่งได้',
            '2' => 'ต้องการความช่วยเหลือบ้าง หรือต้องมีคนดูแลเพื่อความปลอดภัย',
            '3' => 'ทำได้เอง',
        ]],
        ['id' => 'adl4', 'title' => '4. Toilet use (ใช้ห้องน้ำ)', 'opts' => [
            '0' => 'ช่วยตัวเองไม่ได้',
            '1' => 'ทำเองได้บ้าง แต่ต้องการความช่วยเหลือในบางสิ่ง',
            '2' => 'ช่วยตัวเองได้ดี',
        ]],
        ['id' => 'adl5', 'title' => '5. Mobility (การเคลื่อนที่ภายในห้องหรือบ้าน)', 'opts' => [
            '0' => 'เคลื่อนที่ไปไหนไม่ได้',
            '1' => 'ต้องใช้รถเข็นช่วยตัวเองให้เคลื่อนที่ได้เอง และเข้าออกมุมห้องหรือประตูได้',
            '2' => 'เดินหรือเคลื่อนที่โดยมีคนช่วย',
            '3' => 'เดินหรือเคลื่อนที่ได้เอง',
        ]],
        ['id' => 'adl6', 'title' => '6. Dressing (การสวมใส่เสื้อผ้า)', 'opts' => [
            '0' => 'ต้องมีคนสวมใส่ให้ ช่วยตัวเองแทบไม่ได้หรือได้น้อย',
            '1' => 'ช่วยตัวเองได้ประมาณร้อยละ 50 ที่เหลือต้องมีคนช่วย',
            '2' => 'ช่วยตัวเองได้ดี (รวมทั้งติดกระดุม รูดซิบ)',
        ]],
        ['id' => 'adl7', 'title' => '7. Stairs (การขึ้นลงบันได 1 ชั้น)', 'opts' => [
            '0' => 'ไม่สามารถทำได้',
            '1' => 'ต้องการคนช่วย',
            '2' => 'ขึ้นลงได้เอง (ถ้าต้องใช้เครื่องช่วยเดิน จะต้องเอาขึ้นลงได้ด้วย)',
        ]],
        ['id' => 'adl8', 'title' => '8. Bathing (การอาบน้ำ)', 'opts' => [
            '0' => 'ต้องมีคนช่วยหรือทำให้',
            '1' => 'อาบน้ำเองได้',
        ]],
        ['id' => 'adl9', 'title' => '9. Bowels (การกลั้นการถ่ายอุจจาระใน 1 สัปดาห์ที่ผ่านมา)', 'opts' => [
            '0' => 'กลั้นไม่ได้ หรือต้องการการสวนอุจจาระอยู่เสมอ',
            '1' => 'กลั้นไม่ได้บางครั้ง (น้อยกว่า 1 ครั้งต่อสัปดาห์)',
            '2' => 'กลั้นได้เป็นปกติ',
        ]],
        ['id' => 'adl10', 'title' => '10. Bladder (การกลั้นปัสสาวะใน 1 สัปดาห์ที่ผ่านมา)', 'opts' => [
            '0' => 'กลั้นไม่ได้ หรือใส่สายสวนปัสสาวะแต่ไม่สามารถดูแลเองได้',
            '1' => 'กลั้นไม่ได้บางครั้ง (น้อยกว่าวันละ 1 ครั้ง)',
            '2' => 'กลั้นได้เป็นปกติ',
        ]],
    ];
}

function dej2_adl_sum(array $a) {
    $sum = 0;
    $any = false;
    foreach (dej2_barthel_items() as $item) {
        $v = dej2_val($a, $item['id']);
        if ($v === '' || !preg_match('/^\d+$/', $v)) {
            continue;
        }
        $any = true;
        $sum += (int)$v;
    }
    return $any ? $sum : null;
}

function dej2_adl_group($sum) {
    if ($sum === null) {
        return '';
    }
    if ($sum >= 12) {
        return 'กลุ่มติดสังคม (12 คะแนนขึ้นไป)';
    }
    if ($sum >= 5) {
        return 'กลุ่มติดบ้าน (5–11 คะแนน)';
    }
    return 'กลุ่มติดเตียง (0–4 คะแนน)';
}

function dej2_render_patient(array $form, array $a, $print) {
    $sex = dej2_val($a, 'sex');
    ?>
    <h3 class="part">ส่วนที่ 1 ข้อมูลผู้ป่วย</h3>
    <div class="id-grid">
        <div>1. ชื่อ <?= dej2_line('fname', dej2_val($a, 'fname'), $print, true) ?></div>
        <div>สกุล <?= dej2_line('lname', dej2_val($a, 'lname'), $print, true) ?></div>
        <div>2. เพศ
            <?php if (($form['sex_mode'] ?? '') === 'female'): ?>
                <strong>หญิง</strong>
                <?php if (!$print): ?>
                    <input type="hidden" name="a[sex]" value="<?= dej2_h($sex !== '' ? $sex : 'หญิง') ?>">
                    <?php if ($sex !== '' && $sex !== 'หญิง'): ?>
                    <span class="warn">ข้อมูล HOSxP เป็นเพศ <?= dej2_h($sex) ?></span>
                    <?php endif; ?>
                <?php endif; ?>
            <?php else: ?>
                <label class="inline"><?= dej2_radio('sex', 'ชาย', $sex, $print) ?> ชาย</label>
                <label class="inline"><?= dej2_radio('sex', 'หญิง', $sex, $print) ?> หญิง</label>
            <?php endif; ?>
        </div>
        <div>3. HN <?= dej2_line('hn', dej2_val($a, 'hn'), $print, false) ?></div>
        <div>4. รหัสโรงพยาบาล <?= dej2_line('hosp', dej2_val($a, 'hosp'), $print, false) ?></div>
        <div class="span2">5. เลขประจำตัวประชาชน <?= dej2_line('cid', dej2_val($a, 'cid'), $print, true) ?></div>
        <div>6. วัน/เดือน/ปีเกิด <?= dej2_line('birth', dej2_val($a, 'birth'), $print, false) ?></div>
        <div>7. อายุ <?= dej2_line('age_y', dej2_val($a, 'age_y'), $print, false) ?> ปี <?= dej2_line('age_m', dej2_val($a, 'age_m'), $print, false) ?> เดือน</div>
        <div class="span2">8. สิทธิการรักษา
            <?php
            $right = dej2_val($a, 'right');
            $rights = ['uc' => 'สปสช.', 'sso' => 'ประกันสังคม', 'csg' => 'สวัสดิการข้าราชการ', 'other' => 'อื่น ๆ'];
            foreach ($rights as $rk => $rl):
            ?>
            <label class="inline"><?= dej2_radio('right', $rk, $right, $print) ?> <?= dej2_h($rl) ?></label>
            <?php endforeach; ?>
            <?= dej2_line('right_other', dej2_val($a, 'right_other'), $print, true) ?>
        </div>
    </div>
    <?php
}

function dej2_render_blocks(array $blocks, array $a, $print) {
    $mode = '';
    $open = function ($next) use (&$mode) {
        if ($mode === $next) {
            return;
        }
        if ($mode !== '') {
            echo '</tbody></table>';
        }
        $y = $next === 'pair' ? 'พบ' : 'ใช่';
        $n = $next === 'pair' ? 'ไม่พบ' : 'ไม่ใช่';
        echo '<table class="grid"><thead><tr><th>รายการ</th><th class="yn">' . $y . '</th><th class="yn">' . $n . '</th></tr></thead><tbody>';
        $mode = $next;
    };
    $close = function () use (&$mode) {
        if ($mode !== '') {
            echo '</tbody></table>';
            $mode = '';
        }
    };
    foreach ($blocks as $b) {
        $t = $b['t'];
        if ($t !== 'yn' && $t !== 'pair') {
            $close();
        }
        if (!empty($b['break'])) {
            echo '<div class="page-break"></div>';
        }
        if ($t === 'date') {
            echo '<p class="ask">' . dej2_h($b['label']) . ' ' . dej2_line($b['id'], dej2_val($a, $b['id']), $print, false) . '</p>';
        } elseif ($t === 'yn' || $t === 'pair') {
            $open($t);
            $cur = dej2_val($a, $b['id']);
            echo '<tr><td>' . dej2_h($b['text']) . '</td><td class="yn"><label class="hit">' . dej2_radio($b['id'], 'Y', $cur, $print) . '</label></td><td class="yn"><label class="hit">' . dej2_radio($b['id'], 'N', $cur, $print) . '</label></td></tr>';
        } elseif ($t === 'check') {
            echo dej2_check($b['id'], dej2_val($a, $b['id']), $print, $b['text']);
        } elseif ($t === 'radios') {
            echo '<div class="ask"><div class="ask-label">' . dej2_h($b['text']) . '</div><div class="opts">';
            foreach ($b['opts'] as $k => $lab) {
                $val = is_int($k) ? (string)$lab : (string)$k;
                $label = is_int($k) ? (string)$lab : (string)$lab;
                $cur = dej2_val($a, $b['id']);
                echo '<label class="opt">' . dej2_radio($b['id'], $val, $cur, $print) . ' ' . dej2_h($label) . '</label>';
            }
            echo '</div></div>';
        } elseif ($t === 'line') {
            echo '<p class="ask">' . dej2_h($b['before']) . ' ' . dej2_line($b['id'], dej2_val($a, $b['id']), $print, false) . ' ' . dej2_h($b['after']) . '</p>';
        } elseif ($t === 'range') {
            echo '<p class="ask">' . dej2_h($b['label']) . ' ตั้งแต่วันที่ ' . dej2_line($b['from'], dej2_val($a, $b['from']), $print, false)
                . ' ถึง ' . dej2_line($b['to'], dej2_val($a, $b['to']), $print, false);
            if (!empty($b['hint'])) {
                echo ' <span class="hint">(' . dej2_h($b['hint']) . ')</span>';
            }
            echo '</p>';
        } elseif ($t === 'note') {
            echo '<p class="note">' . nl2br(dej2_h($b['text'])) . '</p>';
        } elseif ($t === 'times') {
            $cur = dej2_val($a, $b['id']);
            echo '<p class="ask">' . dej2_h($b['label']);
            foreach (['1', '2', '3'] as $n) {
                echo ' <label class="inline">' . dej2_radio($b['id'], $n, $cur, $print) . ' ครั้งที่ ' . $n . '</label>';
            }
            echo '</p>';
        } elseif ($t === 'sign') {
            $dec = dej2_val($a, 'decision');
            echo '<section class="sign"><h3>สำหรับผู้อนุมัติตามที่กองทุนฯ กำหนด</h3>';
            echo '<p>แพทย์ผู้สั่งใช้ยา ';
            echo '<label class="inline">' . dej2_radio('decision', 'Y', $dec, $print) . ' อนุมัติ</label>';
            echo '<label class="inline">' . dej2_radio('decision', 'N', $dec, $print) . ' ไม่อนุมัติ</label></p>';
            echo '<div class="sign-row"><div><div>ลงชื่อ ' . dej2_line('doctor_name', dej2_val($a, 'doctor_name'), $print, true) . '</div><div class="role">แพทย์ผู้สั่งใช้ยา</div><div>ว. ' . dej2_line('doctor_license', dej2_val($a, 'doctor_license'), $print, false) . '</div></div>';
            echo '<div><div>ลงชื่อ ' . dej2_line('approver_name', dej2_val($a, 'approver_name'), $print, true) . '</div><div class="role">ผู้อนุมัติ</div><div>ว. ' . dej2_line('approver_license', dej2_val($a, 'approver_license'), $print, false) . '</div></div></div>';
            echo '<p>วัน/เดือน/ปีที่อนุมัติ ' . dej2_line('approve_date', dej2_val($a, 'approve_date'), $print, false) . '</p></section>';
        } elseif ($t === 'barthel') {
            $sum = dej2_adl_sum($a);
            echo '<section class="adl"><h3>เอกสารแนบ แบบประเมินคัดกรอง Barthel ADL</h3>';
            echo '<p class="muted">ชื่อ ' . dej2_h(dej2_val($a, 'fname')) . ' สกุล ' . dej2_h(dej2_val($a, 'lname')) . ' &nbsp; HN ' . dej2_h(dej2_val($a, 'hn')) . '</p>';
            foreach (dej2_barthel_items() as $item) {
                echo '<div class="adl-item"><div class="adl-title">' . dej2_h($item['title']) . '</div>';
                foreach ($item['opts'] as $score => $lab) {
                    $cur = dej2_val($a, $item['id']);
                    echo '<label class="opt">' . dej2_radio($item['id'], (string)$score, $cur, $print) . ' <b>' . dej2_h($score) . '</b> ' . dej2_h($lab) . '</label>';
                }
                echo '</div>';
            }
            echo '<p class="sum">สรุปผลรวมคะแนน = <b id="adlSum">' . ($sum === null ? '' : (int)$sum) . '</b></p>';
            echo '<ul class="adl-key"><li>กลุ่มติดสังคม มีผลรวมคะแนน ADL ตั้งแต่ 12 คะแนนขึ้นไป</li>';
            echo '<li>กลุ่มติดบ้าน มีผลรวมคะแนน ADL อยู่ในช่วง 5–11 คะแนน</li>';
            echo '<li>กลุ่มติดเตียง มีผลรวมคะแนน ADL อยู่ในช่วง 0–4 คะแนน</li></ul>';
            echo '<p class="sum" id="adlGroup">' . dej2_h(dej2_adl_group($sum)) . '</p></section>';
        }
    }
    $close();
}

function dej2_render_sheet(array $form, $phase, array $a, $drugName, $print) {
    $ph = $form['phases'][$phase] ?? null;
    if (!$ph) {
        return;
    }
    ?>
    <article class="paper">
        <header class="paper-head">
            <div class="kicker"><?= dej2_h($form['kicker']) ?></div>
            <h1><?= dej2_h($ph['subtitle']) ?></h1>
            <h2><?= dej2_h($form['doc_title']) ?></h2>
            <p><?= dej2_h($form['condition']) ?></p>
            <p class="footnote"><?= dej2_h($form['footnote']) ?></p>
            <div class="case"><?= dej2_h($ph['case']) ?></div>
            <?php if ($drugName !== ''): ?>
            <p class="drug-line">รายการยา <?= dej2_h($drugName) ?></p>
            <?php endif; ?>
        </header>
        <?php dej2_render_patient($form, $a, $print); ?>
        <h3 class="part"><?= dej2_h($ph['part2']) ?></h3>
        <?php dej2_render_blocks($ph['blocks'], $a, $print); ?>
    </article>
    <?php
}

function dej2_css() {
    return <<<'CSS'
.paper{width:210mm;max-width:100%;margin:0 auto;background:#fff;color:#1a1a1a;padding:12mm 14mm;border:1px solid #e3e8ee;box-shadow:0 8px 28px rgba(16,24,40,.06);font-family:"TH Sarabun New","TH SarabunPSK",Tahoma,sans-serif;font-size:17px;line-height:1.45}
.paper-head{text-align:center;margin-bottom:10px}
.kicker{display:inline-block;border:1px solid #111;padding:1px 10px;font-weight:700;letter-spacing:.02em}
.paper h1{font-size:22px;margin:8px 0 2px;font-weight:700}
.paper h2{font-size:20px;margin:0 0 4px;font-weight:700}
.paper-head p{margin:0}
.footnote{color:#333}
.case{margin-top:8px;font-weight:700;font-size:18px}
.drug-line{margin-top:4px;font-size:15px;color:#444}
.part{font-size:18px;margin:14px 0 8px;padding-bottom:3px;border-bottom:1.5px solid #111}
.id-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px 16px}
.id-grid .span2{grid-column:1 / -1}
.line{border:0;border-bottom:1px dotted #222;background:transparent;font:inherit;padding:0 4px;min-width:7rem}
.line.wide{min-width:14rem}
.fill{display:inline-block;min-width:7rem;border-bottom:1px dotted #222;padding:0 6px}
.fill-wide{min-width:14rem}
.grid{width:100%;border-collapse:collapse;margin:6px 0 8px}
.grid th,.grid td{border:1px solid #222;padding:5px 8px;vertical-align:top}
.grid th{background:#f4f6f8;font-weight:700;text-align:center}
.grid .yn{width:68px;text-align:center}
.hit{display:flex;align-items:center;justify-content:center;min-height:28px;cursor:pointer;margin:0}
.hit input{width:18px;height:18px;cursor:pointer}
.box{display:inline-flex;width:16px;height:16px;border:1.5px solid #111;align-items:center;justify-content:center;font-weight:700;line-height:1;vertical-align:middle}
.chk,.opt,.inline{display:flex;gap:8px;align-items:flex-start;margin:3px 0;cursor:pointer}
.inline{display:inline-flex;margin-right:12px;align-items:center}
.chk input,.opt input{width:16px;height:16px;margin-top:4px;cursor:pointer}
.sub{margin:2px 0 2px 18px}
.ask{margin:8px 0}
.ask-label{font-weight:700;margin-bottom:2px}
.opts{display:flex;flex-direction:column;gap:2px}
.note{margin:4px 0 8px 12px;white-space:pre-line;color:#222}
.hint{color:#333}
.mini{font-size:13px;color:#444}
.sign{margin-top:16px}
.sign-row{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:8px}
.role{text-align:center;color:#333}
.adl{margin-top:8px}
.adl-item{margin:8px 0;padding-bottom:6px;border-bottom:1px dashed #ccc}
.adl-title{font-weight:700}
.sum{font-size:18px}
.adl-key{margin:4px 0 0 18px}
.warn{color:#9a3412;font-size:14px;margin-left:6px}
.page-break{break-before:page;page-break-before:always}
@media print{
  .paper{box-shadow:none;border:0;width:auto;padding:0}
  .hit input,.chk input,.opt input{display:none}
}
CSS;
}
