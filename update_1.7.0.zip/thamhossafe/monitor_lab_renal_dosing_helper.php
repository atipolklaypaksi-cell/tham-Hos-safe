<?php
/**
 * กฎปรับยาในผู้ป่วยไต จากตาราง "ยาที่ต้องปรับในผู้ป่วยไต"
 * ห้ามใช้ (แดง) = Hard Alert · ปรับขนาดยา (เหลือง/ส้ม) = Soft Alert
 */

function monitor_lab_renal_dosing_catalog() {
    $eye = '/eye\s*drop|ยาหยอด|eardrop/i';
    return [
        [
            'name' => 'ACYCLOVIR',
            'generic' => ['ACYCLOVIR', 'ACICLOVIR'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 10.01, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR ≤50: 5–12.5 mg/kg q12–24h'],
                ['min' => 0, 'max' => 10, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR ≤10: 2.5–5.625 mg/kg q24h (หลัง HD ตามตาราง)'],
            ],
        ],
        [
            'name' => 'ALLOPURINOL',
            'generic' => ['ALLOPURINOL'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 10.01, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Allopurinol เมื่อ eGFR ≤50 (eGFR <20 สูงสุดประมาณ 200 mg/วัน)'],
                ['min' => 0, 'max' => 10, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR ≤10: Allopurinol ประมาณ 100 mg/วัน'],
            ],
        ],
        [
            'name' => 'AMIKACIN',
            'generic' => ['AMIKACIN'],
            'skip_combo' => true,
            'exclude_name' => $eye,
            'rules' => [
                ['min' => 0, 'max' => 60, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Amikacin เมื่อ eGFR ≤60 (ดูระดับยา/ช่วงให้ยาตามตารางไต)'],
            ],
        ],
        [
            'name' => 'AMOXICILLIN',
            'generic' => ['AMOXICILLIN', 'AMOXYCILLIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR ≤30: Amoxicillin 250–500 mg q12–24h'],
            ],
        ],
        [
            'name' => 'AMPICILLIN',
            'generic' => ['AMPICILLIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Ampicillin เมื่อ eGFR ≤50'],
            ],
        ],
        [
            'name' => 'ASPIRIN',
            'generic' => ['ASPIRIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 10, 'level' => 'hard', 'msg' => 'ห้ามใช้ Aspirin เมื่อ eGFR < 10'],
            ],
        ],
        [
            'name' => 'ATENOLOL',
            'generic' => ['ATENOLOL'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 10.01, 'max' => 30, 'level' => 'soft', 'msg' => 'ใช้ Atenolol อย่างระวังและพิจารณาปรับขนาดเมื่อ eGFR < 30'],
                ['min' => 0, 'max' => 10, 'level' => 'hard', 'msg' => 'ห้ามใช้ Atenolol เมื่อ eGFR < 10'],
            ],
        ],
        [
            'name' => 'ATORVASTATIN',
            'generic' => ['ATORVASTATIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 30, 'level' => 'hard', 'msg' => 'ห้ามใช้ Atorvastatin เมื่อ eGFR < 30 (ขณะที่ยังไม่ HD/PD)'],
            ],
        ],
        [
            'name' => 'BISOPROLOL',
            'generic' => ['BISOPROLOL'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 10.01, 'max' => 20, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR ≤20: Bisoprolol สูงสุด 10 mg/วัน'],
                ['min' => 0, 'max' => 10, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR ≤10: Bisoprolol 2.5–5 mg q24h'],
            ],
        ],
        [
            'name' => 'CAPTOPRIL',
            'generic' => ['CAPTOPRIL'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Captopril เมื่อ eGFR ≤50'],
            ],
        ],
        [
            'name' => 'CEFAZOLIN',
            'generic' => ['CEFAZOLIN'],
            'skip_combo' => true,
            'exclude_name' => $eye,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Cefazolin เมื่อ eGFR ≤50'],
            ],
        ],
        [
            'name' => 'CEFDINIR',
            'generic' => ['CEFDINIR'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Cefdinir เมื่อ eGFR ≤30'],
            ],
        ],
        [
            'name' => 'CEFOTAXIME',
            'generic' => ['CEFOTAXIME'],
            'skip_combo' => true,
            'exclude_name' => $eye,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Cefotaxime เมื่อ eGFR ≤50 (eGFR <10: 2 g q24h)'],
            ],
        ],
        [
            'name' => 'CEFTAZIDIME',
            'generic' => ['CEFTAZIDIME'],
            'skip_combo' => true,
            'exclude_name' => $eye,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Ceftazidime เมื่อ eGFR ≤50'],
            ],
        ],
        [
            'name' => 'CEPHALEXIN',
            'generic' => ['CEPHALEXIN', 'CEFALEXIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Cephalexin เมื่อ eGFR ≤50: 500 mg q8–12h'],
            ],
        ],
        [
            'name' => 'CIPROFLOXACIN',
            'generic' => ['CIPROFLOXACIN'],
            'skip_combo' => true,
            'exclude_name' => $eye,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Ciprofloxacin เมื่อ eGFR ≤50: 250–500 mg q12–24h'],
            ],
        ],
        [
            'name' => 'CLARITHROMYCIN',
            'generic' => ['CLARITHROMYCIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Clarithromycin เมื่อ eGFR ≤30'],
            ],
        ],
        [
            'name' => 'COLCHICINE',
            'generic' => ['COLCHICINE'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 10, 'level' => 'hard', 'msg' => 'ห้ามใช้ Colchicine เมื่อ eGFR < 10'],
            ],
        ],
        [
            'name' => 'COLISTIN',
            'generic' => ['COLISTIN', 'COLISTIMETHATE'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Colistin เมื่อ eGFR ≤50 ตามตารางไต'],
            ],
        ],
        [
            'name' => 'DAPAGLIFLOZIN',
            'generic' => ['DAPAGLIFLOZIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 45, 'level' => 'hard', 'msg' => 'ห้ามใช้ Dapagliflozin เมื่อ eGFR < 45'],
            ],
        ],
        [
            'name' => 'DIGOXIN',
            'generic' => ['DIGOXIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับลดขนาดยา Digoxin เมื่อ eGFR ≤50'],
            ],
        ],
        [
            'name' => 'ENALAPRIL',
            'generic' => ['ENALAPRIL'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 15.01, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR ≤50: Enalapril 2.5–5 mg q12–24h'],
                ['min' => 0, 'max' => 15, 'level' => 'hard', 'msg' => 'ห้ามใช้ Enalapril เมื่อ eGFR < 15'],
            ],
        ],
        [
            'name' => 'FENOFIBRATE',
            'generic' => ['FENOFIBRATE'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 30, 'level' => 'hard', 'msg' => 'ห้ามใช้ Fenofibrate เมื่อ eGFR < 30'],
            ],
        ],
        [
            'name' => 'FLUCONAZOLE',
            'generic' => ['FLUCONAZOLE'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR ≤50: ลดขนาด Fluconazole ประมาณ 50%'],
            ],
        ],
        [
            'name' => 'GABAPENTIN',
            'generic' => ['GABAPENTIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 30.01, 'max' => 60, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 30–60: Gabapentin 200–700 mg bid'],
                ['min' => 15.01, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 15–30: Gabapentin 200–700 mg/วัน'],
                ['min' => 0, 'max' => 15, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR < 15: Gabapentin 100–300 mg/วัน'],
            ],
        ],
        [
            'name' => 'GEMFIBROZIL',
            'generic' => ['GEMFIBROZIL'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 15, 'level' => 'hard', 'msg' => 'ห้ามใช้ Gemfibrozil เมื่อ eGFR < 15'],
            ],
        ],
        [
            'name' => 'GENTAMICIN',
            'generic' => ['GENTAMICIN'],
            'skip_combo' => true,
            'exclude_name' => $eye,
            'rules' => [
                ['min' => 0, 'max' => 60, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Gentamicin เมื่อ eGFR ≤60 (ดูระดับยา/ช่วงให้ยาตามตารางไต)'],
            ],
        ],
        [
            'name' => 'GLIPIZIDE',
            'generic' => ['GLIPIZIDE'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 15, 'level' => 'hard', 'msg' => 'ห้ามใช้ Glipizide เมื่อ eGFR < 15'],
            ],
        ],
        [
            'name' => 'HCTZ',
            'generic' => ['HYDROCHLOROTHIAZIDE', 'HCTZ'],
            'rules' => [
                ['min' => 0, 'max' => 30, 'level' => 'hard', 'msg' => 'ห้ามใช้ HCTZ เมื่อ eGFR < 30'],
            ],
        ],
        [
            'name' => 'IMIPENEM',
            'generic' => ['IMIPENEM'],
            'rules' => [
                ['min' => 15.01, 'max' => 60, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Imipenem เมื่อ eGFR 15–60: 200–500 mg q6–12h'],
                ['min' => 0, 'max' => 15, 'level' => 'hard', 'msg' => 'ห้ามใช้ Imipenem เมื่อ eGFR < 15'],
            ],
        ],
        [
            'name' => 'LEVOFLOXACIN',
            'generic' => ['LEVOFLOXACIN'],
            'skip_combo' => true,
            'exclude_name' => '/eye\s*drop|ยาหยอด|eardrop|\bED[- ]/i',
            'rules' => [
                ['min' => 20.01, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 20–50: Levofloxacin 750 mg q48h'],
                ['min' => 0, 'max' => 20, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR < 20: Levofloxacin 750 mg ครั้งแรก แล้ว 500 mg q48h'],
            ],
        ],
        [
            'name' => 'METFORMIN',
            'generic' => ['METFORMIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 45.01, 'max' => 60, 'level' => 'soft', 'msg' => 'eGFR 45–60 สูงสุด Metformin 2000 mg/วัน', 'dose_min' => 2001, 'dose_max' => 9999],
            ],
        ],
        [
            'name' => 'OSELTAMIVIR',
            'generic' => ['OSELTAMIVIR'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 30.01, 'max' => 60, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 30–60: Oseltamivir 30 mg po q12h'],
                ['min' => 15.01, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 15–30: Oseltamivir 30 mg po q24h'],
                ['min' => 0, 'max' => 15, 'level' => 'hard', 'msg' => 'ห้ามใช้ Oseltamivir เมื่อ eGFR < 15'],
            ],
        ],
        [
            'name' => 'PIPERACILLIN+TAZOBACTAM',
            'generic' => ['PIPERACILLIN', 'TAZOBACTAM', 'TAZOCIN'],
            'rules' => [
                ['min' => 20.01, 'max' => 40, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 20–40: Piperacillin/Tazobactam 2.25 g q6h'],
                ['min' => 0, 'max' => 20, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR < 20: Piperacillin/Tazobactam 2.25 g q8h'],
            ],
        ],
        [
            'name' => 'PYRAZINAMIDE',
            'generic' => ['PYRAZINAMIDE'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 5.01, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 10–30: Pyrazinamide 20–30 mg/kg 3 ครั้ง/สัปดาห์'],
                ['min' => 0, 'max' => 5, 'level' => 'hard', 'msg' => 'ห้ามใช้ Pyrazinamide เมื่อ eGFR < 5'],
            ],
        ],
        [
            'name' => 'RANITIDINE IV',
            'generic' => ['RANITIDINE'],
            'skip_combo' => true,
            'require_name' => '/inj|injection/i',
            'rules' => [
                ['min' => 30.01, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 30–50: Ranitidine IV 50 mg q12h'],
                ['min' => 0, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR < 30: Ranitidine IV 50 mg q24h'],
            ],
        ],
        [
            'name' => 'RANITIDINE oral',
            'generic' => ['RANITIDINE'],
            'skip_combo' => true,
            'exclude_name' => '/inj|injection/i',
            'rules' => [
                ['min' => 0, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR < 30: Ranitidine oral 150 mg qd'],
            ],
        ],
        [
            'name' => 'SIMVASTATIN',
            'generic' => ['SIMVASTATIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 10.01, 'max' => 60, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Simvastatin เมื่อ eGFR ≤60: 10–40 mg/วัน'],
                ['min' => 0, 'max' => 10, 'level' => 'hard', 'msg' => 'ห้ามใช้ Simvastatin เมื่อ eGFR < 10'],
            ],
        ],
        [
            'name' => 'SPIRONOLACTONE',
            'generic' => ['SPIRONOLACTONE'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 10.01, 'max' => 45, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Spironolactone เมื่อ eGFR 10–45'],
                ['min' => 0, 'max' => 10, 'level' => 'hard', 'msg' => 'ห้ามใช้ Spironolactone เมื่อ eGFR < 10'],
            ],
        ],
        [
            'name' => 'STAVUDINE',
            'generic' => ['STAVUDINE'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Stavudine เมื่อ eGFR ≤50 ตามน้ำหนักตัว'],
            ],
        ],
        [
            'name' => 'STREPTOMYCIN',
            'generic' => ['STREPTOMYCIN'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 0, 'max' => 40, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Streptomycin เมื่อ eGFR ≤40: 15 mg/kg q24–96h'],
            ],
        ],
        [
            'name' => 'TAF',
            'match' => 'taf',
            'generic' => ['TENOFOVIR ALAFENAMIDE'],
            'rules' => [
                ['min' => 0, 'max' => 15, 'level' => 'hard', 'msg' => 'ไม่แนะนำ TAF เมื่อ eGFR < 15 หากไม่ได้ทำ HD'],
            ],
        ],
        [
            'name' => 'TDF',
            'match' => 'tdf',
            'generic' => ['TENOFOVIR'],
            'rules' => [
                ['min' => 30.01, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 30–50: TDF 300 mg q48h'],
                ['min' => 10.01, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 10–30: TDF 300 mg q72–96h'],
                ['min' => 0, 'max' => 10, 'level' => 'hard', 'msg' => 'ไม่แนะนำ TDF เมื่อ eGFR < 10 หากไม่ได้ทำ HD'],
            ],
        ],
        [
            'name' => 'TRAMADOL',
            'generic' => ['TRAMADOL'],
            'skip_combo' => true,
            'rules' => [
                ['min' => 30.01, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 30–50: Tramadol q8–12h'],
                ['min' => 0, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR < 30: Tramadol 50–100 mg q12h'],
            ],
        ],
        [
            'name' => 'CO-TRIMOXAZOLE',
            'generic' => ['SULFAMETHOXAZOLE', 'TRIMETHOPRIM', 'CO-TRIMOXAZOLE', 'COTRIMOXAZOLE'],
            'rules' => [
                ['min' => 15.01, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 15–30: Co-trimoxazole 5–10 mg/kg/วัน'],
                ['min' => 0, 'max' => 15, 'level' => 'hard', 'msg' => 'ไม่แนะนำ Co-trimoxazole เมื่อ eGFR < 15'],
            ],
        ],
        [
            'name' => 'VANCOMYCIN',
            'generic' => ['VANCOMYCIN'],
            'skip_combo' => true,
            'require_name' => '/inj|injection/i',
            'exclude_name' => $eye,
            'rules' => [
                ['min' => 20.01, 'max' => 50, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 20–50: Vancomycin 15–20 mg/kg q24h'],
                ['min' => 10.01, 'max' => 20, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR 10–20: Vancomycin 15–20 mg/kg q48h'],
                ['min' => 0, 'max' => 10, 'level' => 'soft', 'msg' => 'ปรับขนาดยา Vancomycin เมื่อ eGFR < 10 ตามระดับยา (หลัง HD ตาม Sanford)'],
            ],
        ],
        [
            'name' => 'ZIDOVUDINE',
            'generic' => ['ZIDOVUDINE'],
            'rules' => [
                ['min' => 0, 'max' => 30, 'level' => 'soft', 'msg' => 'ปรับขนาดยาเมื่อ eGFR < 30: Zidovudine 100 mg q8h หรือตามตารางไต'],
            ],
        ],
    ];
}

function monitor_lab_catalog_blob(array $drug) {
    return trim(implode(' ', [
        $drug['generic_name'] ?? '',
        $drug['name_local'] ?? '',
        $drug['name_tmt'] ?? '',
    ]));
}

function monitor_lab_catalog_drug_matches(array $item, array $drug) {
    $blob = monitor_lab_catalog_blob($drug);
    if (monitor_lab_egfr_is_sample($blob) || monitor_lab_egfr_is_topical($blob)) {
        return false;
    }
    if (!empty($item['exclude_name']) && preg_match($item['exclude_name'], $blob)) {
        return false;
    }
    if (!empty($item['require_name']) && !preg_match($item['require_name'], $blob)) {
        return false;
    }

    $gen = monitor_lab_egfr_norm_generic($drug['generic_name'] ?? '');
    $mode = $item['match'] ?? 'generic';
    if ($mode === 'tdf') {
        if (strpos($gen, 'ALAFENAMIDE') !== false) {
            return false;
        }
        return strpos($gen, 'TENOFOVIR') !== false
            || monitor_lab_egfr_generic_in_drug('TDF', $drug);
    }
    if ($mode === 'taf') {
        return strpos($gen, 'TENOFOVIR ALAFENAMIDE') !== false;
    }

    $ok = false;
    foreach ((array)($item['generic'] ?? []) as $g) {
        if (monitor_lab_egfr_generic_in_drug($g, $drug)) {
            $ok = true;
            break;
        }
    }
    if (!$ok) {
        return false;
    }
    if (!empty($item['skip_combo']) && strpos($gen, '+') !== false) {
        return false;
    }
    foreach ((array)($item['exclude_generic'] ?? []) as $ex) {
        if ($ex !== '' && strpos($gen, monitor_lab_egfr_norm_generic($ex)) !== false) {
            return false;
        }
    }
    return true;
}

function monitor_lab_insert_renal_rule($con, array $drug, array $rule) {
    $icode_esc = mysqli_real_escape_string($con, $drug['icode']);
    $min_val = number_format((float)$rule['min'], 2, '.', '');
    $max_val = number_format((float)$rule['max'], 2, '.', '');
    $exists = mysqli_query(
        $con,
        "SELECT id FROM drug_safety_rules
         WHERE drug_icode = '$icode_esc'
           AND lab_type = 'CKD_EPI'
           AND min_val = '$min_val'
           AND max_val = '$max_val'
         LIMIT 1"
    );
    if ($exists && mysqli_num_rows($exists) > 0) {
        return 'skipped';
    }
    $name = trim((string)($drug['name_tmt'] ?? ''));
    if ($name === '') {
        $name = trim((string)($drug['name_local'] ?? ''));
    }
    $name_esc = mysqli_real_escape_string($con, $name);
    $msg_esc = mysqli_real_escape_string($con, (string)$rule['msg']);
    $level = (($rule['level'] ?? 'soft') === 'hard') ? 'hard' : 'soft';
    $use_dose = (isset($rule['dose_min']) || isset($rule['dose_max'])) ? 1 : 0;
    $dose_min = isset($rule['dose_min']) ? "'" . mysqli_real_escape_string($con, (string)$rule['dose_min']) . "'" : 'NULL';
    $dose_max = isset($rule['dose_max']) ? "'" . mysqli_real_escape_string($con, (string)$rule['dose_max']) . "'" : 'NULL';
    $dose_unit = $use_dose ? "'mg'" : 'NULL';
    $sql = "INSERT INTO drug_safety_rules
        (drug_id, drug_icode, drug_name, lab_type, min_val, max_val,
         use_dose_condition, dose_min, dose_max, dose_unit,
         use_age_condition, age_min, age_max,
         use_weight_condition, weight_min, weight_max,
         action_type, action_value, suggestion_msg, alert_level, active_status, lab_condition_type)
        VALUES
        (0, '$icode_esc', '$name_esc', 'CKD_EPI', '$min_val', '$max_val',
         $use_dose, $dose_min, $dose_max, $dose_unit,
         0, NULL, NULL,
         0, NULL, NULL,
         'omit', 0, '$msg_esc', '$level', 1, 'range')";
    return mysqli_query($con, $sql) ? 'inserted' : 'error';
}

function monitor_lab_import_renal_dosing_catalog($con, $hos) {
    $empty = [
        'ok' => false,
        'inserted' => 0,
        'skipped' => 0,
        'unmatched' => 0,
        'unmatched_names' => [],
        'message' => 'นำเข้าไม่สำเร็จ',
    ];
    if (!$hos) {
        $empty['message'] = 'ไม่สามารถเชื่อมต่อ HOSxP';
        return $empty;
    }
    ensure_drug_safety_rules_hosxp_columns($con);
    ensure_drug_safety_rules_alert_level_column($con);
    ensure_drug_safety_rules_lab_condition_columns($con);
    ensure_drug_safety_rules_patient_extra_columns($con);
    ensure_drug_safety_rules_duration_columns($con);
    ensure_drug_safety_rules_exempt_method_columns($con);

    $drugs = monitor_lab_fetch_active_drugs_for_egfr($hos);
    $inserted = 0;
    $skipped = 0;
    $unmatched_names = [];

    foreach (monitor_lab_renal_dosing_catalog() as $item) {
        $hits = [];
        $inactive_hits = [];
        foreach ($drugs as $d) {
            if (($d['icode'] ?? '') === '') {
                continue;
            }
            if (!monitor_lab_catalog_drug_matches($item, $d)) {
                continue;
            }
            if (($d['istatus'] ?? '') === 'Y') {
                $hits[$d['icode']] = $d;
            } else {
                $inactive_hits[$d['icode']] = $d;
            }
        }
        if (empty($hits)) {
            $hits = $inactive_hits;
        }
        if (empty($hits)) {
            $unmatched_names[] = $item['name'];
            continue;
        }
        foreach ($item['rules'] as $rule) {
            foreach ($hits as $d) {
                $res = monitor_lab_insert_renal_rule($con, $d, $rule);
                if ($res === 'inserted') {
                    $inserted++;
                } elseif ($res === 'skipped') {
                    $skipped++;
                }
            }
        }
    }

    return [
        'ok' => true,
        'inserted' => $inserted,
        'skipped' => $skipped,
        'unmatched' => count($unmatched_names),
        'unmatched_names' => $unmatched_names,
        'message' => 'ok',
    ];
}
