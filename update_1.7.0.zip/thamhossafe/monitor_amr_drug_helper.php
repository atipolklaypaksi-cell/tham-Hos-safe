<?php
/**
 * Monitor AMR Drug — ประเมินยาปฏิชีวนะที่กำลังให้ (ยังไม่ off) เทียบผล AST (R / S / I)
 */

function mad_skip_method_defaults() {
    return ['ADD PD'];
}

function mad_skip_method_normalize($raw) {
    if (is_array($raw)) {
        $list = $raw;
    } else {
        $s = trim((string)$raw);
        if ($s === '') {
            return [];
        }
        $decoded = json_decode($s, true);
        $list = is_array($decoded) ? $decoded : preg_split('/[\r\n,;]+/', $s);
    }
    $out = [];
    foreach ($list as $kw) {
        $kw = trim(preg_replace('/\s+/u', ' ', (string)$kw));
        if ($kw === '') {
            continue;
        }
        $key = function_exists('mb_strtolower') ? mb_strtolower($kw, 'UTF-8') : strtolower($kw);
        $out[$key] = $kw;
    }
    return array_values($out);
}

function mad_skip_method_list($con) {
    $defaults = mad_skip_method_defaults();
    if (!$con || !function_exists('amr_sens_cdss_config_ensure') || !amr_sens_cdss_config_ensure($con)) {
        return $defaults;
    }
    $q = @mysqli_query($con, "SELECT config_value FROM amr_cdss_config WHERE config_key = 'skip_method_keywords' LIMIT 1");
    if (!$q || !($r = mysqli_fetch_assoc($q))) {
        return $defaults;
    }
    return mad_skip_method_normalize($r['config_value'] ?? '');
}

function mad_skip_method_save($con, $raw) {
    $list = mad_skip_method_normalize($raw);
    if (!$con || !function_exists('amr_sens_cdss_config_ensure') || !amr_sens_cdss_config_ensure($con)) {
        return $list;
    }
    $json = mysqli_real_escape_string($con, json_encode(array_values($list), JSON_UNESCAPED_UNICODE));
    @mysqli_query($con, "INSERT INTO amr_cdss_config (config_key, config_value)
        VALUES ('skip_method_keywords', '$json')
        ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)");
    return $list;
}

function mad_method_should_skip($method, array $keywords) {
    $m = trim(preg_replace('/\s+/u', ' ', (string)$method));
    if ($m === '' || !$keywords) {
        return false;
    }
    $hay = function_exists('mb_strtolower') ? mb_strtolower($m, 'UTF-8') : strtolower($m);
    foreach ($keywords as $kw) {
        $n = trim((string)$kw);
        if ($n === '') {
            continue;
        }
        $needle = function_exists('mb_strtolower') ? mb_strtolower($n, 'UTF-8') : strtolower($n);
        if (function_exists('mb_strpos')) {
            if (mb_strpos($hay, $needle, 0, 'UTF-8') !== false) {
                return true;
            }
        } elseif (strpos($hay, $needle) !== false) {
            return true;
        }
    }
    return false;
}

function mad_filter_skip_method(array $rows, array $keywords) {
    if (!$keywords) {
        return ['rows' => $rows, 'skipped' => 0];
    }
    $kept = [];
    $n = 0;
    foreach ($rows as $r) {
        if (mad_method_should_skip($r['method'] ?? '', $keywords)) {
            $n++;
            continue;
        }
        $kept[] = $r;
    }
    return ['rows' => $kept, 'skipped' => $n];
}

function mad_parse_lookback($raw, $default = '7d') {
    $s = strtolower(trim((string)$raw));
    $map = [
        '30m' => ['key' => '30m', 'minutes' => 30, 'today' => false, 'label' => 'หลังผลแล็บ 30 นาที'],
        '1h' => ['key' => '1h', 'minutes' => 60, 'today' => false, 'label' => 'หลังผลแล็บ 1 ชั่วโมง'],
        '3h' => ['key' => '3h', 'minutes' => 180, 'today' => false, 'label' => 'หลังผลแล็บ 3 ชั่วโมง'],
        '1d' => ['key' => '1d', 'minutes' => 1440, 'today' => true, 'label' => 'วันที่รายงานเฉพาะวันนี้'],
    ];
    if (isset($map[$s])) {
        return $map[$s];
    }
    $n = 0;
    if (preg_match('/^(\d+)\s*d$/', $s, $m) || preg_match('/^(\d+)$/', $s, $m)) {
        $n = (int)$m[1];
    }
    if ($n <= 0) {
        if (preg_match('/^(\d+)d$/', $default, $m)) {
            $n = (int)$m[1];
        } else {
            $n = 7;
        }
    }
    $n = max(1, min(90, $n));
    if ($n === 1) {
        return $map['1d'];
    }
    return [
        'key' => $n . 'd',
        'minutes' => $n * 1440,
        'today' => false,
        'label' => 'วันที่รายงานไม่เกิน ' . $n . ' วัน',
        'days' => $n,
    ];
}

function mad_lookback_days($raw, $default = 7) {
    $p = mad_parse_lookback($raw, $default <= 1 ? '1d' : ($default . 'd'));
    if (!empty($p['today'])) {
        return 1;
    }
    if (!empty($p['days'])) {
        return (int)$p['days'];
    }
    return max(1, (int)ceil(((int)$p['minutes']) / 1440));
}

function mad_fetch_current_atb($hos, $con = null, array $an_filter = [], $rxdate = '') {
    $today = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$rxdate) ? $rxdate : date('Y-m-d');
    $an_in = mad_an_in_sql($hos, $an_filter);
    if ($an_filter && $an_in === '') {
        return ['error' => '', 'rows' => []];
    }
    $an_clause = $an_in !== '' ? "AND i.an IN ($an_in)" : '';
    $atb_flag = amr_sens_atb_icode_sql($hos, $con, 'd');
    $drug = amr_sql_utf8("TRIM(CONCAT(IFNULL(NULLIF(d.name,''), IFNULL(d.generic_name,'')), ' ', IFNULL(d.strength,'')))");
    $ptname = amr_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))");
    $ward = amr_sql_utf8("IFNULL(w.name, '')");
    $method = amr_sens_atb_method_sql('o');
    $sql = "
        SELECT i.an,
               COALESCE(NULLIF(i.hn, ''), o.hn) AS hn,
               $ptname AS ptname,
               $ward AS wname,
               DATE_FORMAT(i.regdate, '%Y-%m-%d') AS regdate,
               mp.icode,
               $drug AS drugName,
               CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
               CAST(CONVERT($method USING utf8) AS CHAR) AS method,
               MAX(o.qty) AS qty,
               CAST(CONVERT(IFNULL(d.strength, '') USING utf8) AS CHAR) AS strength,
               IFNULL(d.units, '') AS units,
               DATE_FORMAT(pt.birthday, '%Y-%m-%d') AS birthday,
               IFNULL(pt.sex, '') AS sex,
               DATE_FORMAT(mp.orderdate, '%Y-%m-%d') AS orderdate,
               DATE_FORMAT(MAX(o.rxdate), '%Y-%m-%d') AS rxdate
        FROM medplan_ipd mp
        INNER JOIN ipt i ON i.an = mp.an
            AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00')
        INNER JOIN opitemrece o ON o.an = mp.an
            AND o.icode = mp.icode
            AND o.rxdate = '$today'
            AND o.qty > 0
        INNER JOIN drugitems d ON d.icode = mp.icode AND $atb_flag
        LEFT JOIN patient pt ON pt.hn = COALESCE(NULLIF(i.hn, ''), o.hn)
        LEFT JOIN ward w ON w.ward = i.ward
        LEFT JOIN drugusage du ON du.drugusage = o.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
        WHERE (mp.offdate IS NULL OR mp.offdate = '0000-00-00')
          AND mp.qty > 0
          $an_clause
        GROUP BY i.an, i.hn, o.hn, pt.pname, pt.fname, pt.lname, w.name,
                 i.regdate,
                 mp.icode, d.name, d.generic_name, d.strength, d.units, mp.orderdate,
                 pt.birthday, pt.sex,
                 o.sp_use, o.drugusage, du.name1, du.name2, du.name3,
                 sp.name1, sp.name2, sp.name3
        ORDER BY wname ASC, ptname ASC, drugName ASC
        LIMIT 400
    ";
    $out = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return ['error' => mysqli_error($hos), 'rows' => []];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $r['drugName'] = trim((string)($r['drugName'] ?? ''));
        $r['method'] = trim(preg_replace('/\\s+/u', ' ', (string)($r['method'] ?? '')));
        $r['hn'] = preg_replace('/\D+/', '', (string)($r['hn'] ?? ''));
        $r['an'] = preg_replace('/\D+/', '', (string)($r['an'] ?? ''));
        $r['regdate'] = substr(trim((string)($r['regdate'] ?? '')), 0, 10);
        if ($r['icode'] === '' || $r['hn'] === '') {
            continue;
        }
        $r['qty'] = (float)($r['qty'] ?? 0);
        $r['strength'] = trim((string)($r['strength'] ?? ''));
        $r['units'] = trim((string)($r['units'] ?? ''));
        $r['birthday'] = trim((string)($r['birthday'] ?? ''));
        $r['sex'] = trim((string)($r['sex'] ?? ''));
        $r['age'] = function_exists('monitor_lab_patient_age_years')
            ? monitor_lab_patient_age_years($r['birthday'], $r['rxdate'] ?: date('Y-m-d'))
            : 0;
        $out[] = $r;
    }
    return ['error' => '', 'rows' => $out];
}

function mad_hn_in_sql($hos, array $hns) {
    $vals = [];
    foreach ($hns as $hn) {
        $hn = preg_replace('/\D+/', '', (string)$hn);
        if ($hn === '') {
            continue;
        }
        $vals[$hn] = true;
        $vals[ltrim($hn, '0')] = true;
        $vals[str_pad($hn, 9, '0', STR_PAD_LEFT)] = true;
    }
    $out = [];
    foreach (array_keys($vals) as $v) {
        if ($v === '') {
            continue;
        }
        $out[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return implode(',', $out);
}

function mad_an_in_sql($hos, array $ans) {
    $vals = [];
    foreach ($ans as $an) {
        $an = preg_replace('/\D+/', '', (string)$an);
        if ($an === '') {
            continue;
        }
        $vals[$an] = true;
    }
    $out = [];
    foreach (array_keys($vals) as $v) {
        $out[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return implode(',', $out);
}

function mad_fetch_cultures($hos, array $hns, $lookback, array $ans = [], $con = null) {
    if ($con && function_exists('amr_mlab_using_direct') && amr_mlab_using_direct($con)) {
        return mad_fetch_cultures_mlab($con, $hos, $hns, $lookback, $ans);
    }
    $an_in = mad_an_in_sql($hos, $ans);
    if ($an_in === '') {
        return [];
    }
    $lb = is_array($lookback) ? $lookback : mad_parse_lookback($lookback);
    if (!empty($lb['today'])) {
        $date_filter = "lh.report_date = CURDATE()";
    } else {
        $mins = max(1, (int)($lb['minutes'] ?? 60));
        $date_filter = "lh.report_date >= DATE(DATE_SUB(NOW(), INTERVAL $mins MINUTE))
          AND TIMESTAMP(lh.report_date, IFNULL(NULLIF(TRIM(lh.report_time), ''), '00:00:00'))
              >= DATE_SUB(NOW(), INTERVAL $mins MINUTE)";
    }
    $today = date('Y-m-d');
    $culture = "(lh.result_rtf LIKE '%MIC%' OR lh.result_rtf LIKE '%SIR%' OR lh.result_rtf LIKE '%APPROVED%' OR lh.result_rtf LIKE '%Culture%')";
    $rtf = function_exists('amr_sens_sql_result_text')
        ? amr_sens_sql_result_text()
        : amr_sql_utf8('lh.result_rtf');
    $microtype_sql = function_exists('amr_sql_microtype_case')
        ? amr_sql_microtype_case('lh.result_rtf', $hos)
        : "''";
    $result_sql = function_exists('amr_sql_result_case')
        ? amr_sql_result_case('lh.result_rtf', $hos)
        : "''";
    $specimen_sql = function_exists('amr_sql_specimen_case')
        ? amr_sql_specimen_case('lh.result_rtf', $hos)
        : "''";
    $sql = "
        SELECT lh.lab_order_number,
               COALESCE(NULLIF(i.hn, ''), lh.hn) AS hn,
               i.an,
               DATE_FORMAT(i.regdate, '%Y-%m-%d') AS regdate,
               CONCAT(IFNULL(lh.report_date, ''), ' ', IFNULL(lh.report_time, '')) AS reportdatetime,
               DATE_FORMAT(lh.report_date, '%Y-%m-%d') AS report_date,
               DATE_FORMAT(lh.order_date, '%Y-%m-%d') AS order_date,
               $rtf AS result_text,
               $microtype_sql AS microtype,
               $result_sql AS result,
               $specimen_sql AS Specimen
        FROM lab_head lh
        INNER JOIN ipt i ON i.an = lh.vn
            AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00')
            AND i.an IN ($an_in)
        WHERE $date_filter
          AND lh.report_date <= '$today'
          AND lh.report_date > '0000-00-00'
          AND (i.regdate IS NULL OR i.regdate = '0000-00-00'
               OR COALESCE(NULLIF(lh.order_date, '0000-00-00'), lh.report_date) >= i.regdate)
          AND lh.result_rtf IS NOT NULL
          AND TRIM(lh.result_rtf) <> ''
          AND $culture
        ORDER BY lh.report_date DESC, lh.report_time DESC
        LIMIT 2500
    ";
    $out = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return [];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $r['hn'] = preg_replace('/\D+/', '', (string)($r['hn'] ?? ''));
        $r['an'] = preg_replace('/\D+/', '', (string)($r['an'] ?? ''));
        $r['result_text'] = amr_sens_clean_rtf($r['result_text'] ?? '');
        $out[] = $r;
    }
    return $out;
}

function mad_lookback_ymd($lookback) {
    $lb = is_array($lookback) ? $lookback : mad_parse_lookback($lookback);
    if (!empty($lb['today'])) {
        $d = date('Y-m-d');
        return [$d, $d, $lb, null];
    }
    $mins = max(1, (int)($lb['minutes'] ?? 1440));
    $start = date('Y-m-d', strtotime('-' . $mins . ' minutes'));
    $cutoff = date('Y-m-d H:i:s', strtotime('-' . $mins . ' minutes'));
    return [$start, date('Y-m-d'), $lb, $cutoff];
}

function mad_fetch_cultures_mlab($con, $hos, array $hns, $lookback, array $ans) {
    if (!function_exists('amr_mlab_load_labs')) {
        require_once __DIR__ . '/amr_mlab_helper.php';
    }
    amr_mlab_ensure_tables($con);
    list($start, $end, $lb, $cutoff) = mad_lookback_ymd($lookback);
    $loaded = amr_mlab_load_labs($con, $start, $end);
    if (($loaded['error'] ?? '') !== '' || empty($loaded['labs'])) {
        return [];
    }
    $want_an = [];
    foreach ($ans as $an) {
        $a = preg_replace('/\D+/', '', (string)$an);
        if ($a !== '') {
            $want_an[$a] = true;
        }
    }
    if (!$want_an) {
        return [];
    }
    $lab_keys = [];
    $lab_hns = [];
    foreach ($loaded['labs'] as $lab) {
        $lab_keys[] = $lab['lab_key'] ?? '';
        if (trim((string)($lab['hn'] ?? '')) !== '') {
            $lab_hns[] = $lab['hn'];
        }
    }
    $overlay = $hos ? amr_mlab_hosxp_overlay($hos, $lab_keys) : [];
    $ov_ans = [];
    foreach ($overlay as $ov) {
        if (!empty($ov['an'])) {
            $ov_ans[] = $ov['an'];
        }
    }
    $patients = $hos ? amr_mlab_fetch_hosxp_patients($hos, array_merge($hns, $lab_hns)) : [];
    $stays = $hos ? amr_mlab_fetch_ipt_stays($hos, array_merge($hns, $lab_hns), $start, $end) : [];
    $byAn = $hos ? amr_mlab_fetch_ipt_by_an($hos, array_merge($ans, $ov_ans)) : [];
    $today = date('Y-m-d');
    $out = [];
    foreach ($loaded['labs'] as $lab) {
        $row = amr_mlab_pack_case($lab, false);
        if (!$row) {
            continue;
        }
        $row = amr_mlab_enrich_row_hosxp($row, $lab, $hos, $overlay, $patients, $stays, $byAn);
        $an = preg_replace('/\D+/', '', (string)($row['an'] ?? ''));
        if ($an === '' || empty($want_an[$an])) {
            continue;
        }
        $rd = substr((string)($lab['report_date'] ?? $lab['order_date'] ?? ''), 0, 10);
        if ($rd === '' || $rd === '0000-00-00' || $rd > $today) {
            continue;
        }
        if (!empty($lb['today']) && $rd !== $today) {
            continue;
        }
        $rt = trim((string)($lab['report_time'] ?? $lab['order_time'] ?? ''));
        if (preg_match('/^(\d{1,2}):(\d{2})/', $rt, $tm)) {
            $rt = sprintf('%02d:%02d:00', $tm[1], $tm[2]);
        } elseif ($rt === '') {
            $rt = '00:00:00';
        }
        $dt = trim($rd . ' ' . ($rt !== '' ? $rt : '00:00:00'));
        if ($cutoff && strcmp($dt, $cutoff) < 0) {
            continue;
        }
        $reg = substr((string)($row['regdate'] ?? ''), 0, 10);
        $od = substr((string)($lab['order_date'] ?? $rd), 0, 10);
        if ($reg !== '' && $od !== '' && $od < $reg) {
            continue;
        }
        $ast = function_exists('amr_sens_ast_from_mlab')
            ? amr_sens_ast_from_mlab($lab['ast'] ?? [])
            : [];
        $out[] = [
            'lab_order_number' => $row['lab_order_number'],
            'hn' => preg_replace('/\D+/', '', (string)($row['hn'] ?? '')),
            'an' => $an,
            'regdate' => $reg,
            'reportdatetime' => $dt,
            'report_date' => $rd,
            'order_date' => $od,
            'result_text' => amr_mlab_case_result_text($lab, $row),
            'microtype' => $row['microtype'] ?? '',
            'result' => $row['result'] ?? '',
            'Specimen' => $row['Specimen'] ?? '',
            '_ast' => $ast,
        ];
    }
    usort($out, static function ($a, $b) {
        return strcmp((string)($b['reportdatetime'] ?? ''), (string)($a['reportdatetime'] ?? ''));
    });
    return array_slice($out, 0, 2500);
}

function mad_cultures_by_an(array $cultures) {
    $map = [];
    foreach ($cultures as $c) {
        $an = preg_replace('/\D+/', '', (string)($c['an'] ?? ''));
        if ($an === '') {
            continue;
        }
        $map[$an][] = $c;
    }
    return $map;
}

function mad_cultures_by_hn(array $cultures) {
    $map = [];
    foreach ($cultures as $c) {
        $hn = ltrim((string)($c['hn'] ?? ''), '0');
        if ($hn === '') {
            continue;
        }
        $map[$hn][] = $c;
    }
    return $map;
}

function mad_ast_hit_from_culture(array $c, array $a, $sir) {
    return [
        'ast_drug' => $a['drug'] ?? '',
        'sir' => $sir,
        'mic' => $a['mic'] ?? '',
        'lab_order_number' => $c['lab_order_number'] ?? '',
        'reportdatetime' => $c['reportdatetime'] ?? '',
        'report_date' => $c['report_date'] ?? '',
        'microtype' => $c['microtype'] ?? '',
        'result' => $c['result'] ?? '',
        'Specimen' => $c['Specimen'] ?? '',
        'fit' => $sir === 'R' ? 'inappropriate' : ($sir === 'S' ? 'appropriate' : 'caution'),
    ];
}

function mad_best_ast_hit(array $cultures, $drug_name) {
    $rank = ['R' => 3, 'I' => 2, 'S' => 1];
    $best = null;
    $best_rank = 0;
    foreach ($cultures as $c) {
        if (amr_sens_is_no_growth($c['result_text'] ?? '')
            || amr_sens_is_no_growth((string)($c['microtype'] ?? ''))) {
            continue;
        }
        $ast = !empty($c['_ast']) && is_array($c['_ast'])
            ? $c['_ast']
            : (function_exists('amr_sens_parse_ast') ? amr_sens_parse_ast($c['result_text'] ?? '') : []);
        $a = function_exists('amr_sens_sir_for_atb_name')
            ? amr_sens_sir_for_atb_name($ast, $drug_name)
            : null;
        if (!$a) {
            continue;
        }
        $sir = strtoupper((string)($a['sir'] ?? ''));
        $r = $rank[$sir] ?? 0;
        if ($r <= $best_rank) {
            continue;
        }
        $best_rank = $r;
        $best = mad_ast_hit_from_culture($c, $a, $sir);
        if ($best_rank >= 3) {
            break;
        }
    }
    return $best;
}

function mad_fetch_egfr_map($hos, array $hns, $con = null) {
    $in = mad_hn_in_sql($hos, $hns);
    if ($in === '') {
        return [];
    }
    $egfr_codes = function_exists('amr_sens_egfr_codes') ? amr_sens_egfr_codes($hos, $con) : [];
    $name_sql = amr_sql_utf8("IFNULL(NULLIF(i.lab_items_name, ''), IFNULL(lo.lab_items_name_ref, ''))");
    $value_sql = amr_sql_utf8("IFNULL(lo.lab_order_result, '')");
    $dt_sql = function_exists('amr_sens_lab_dt_sql')
        ? amr_sens_lab_dt_sql()
        : "CONCAT(IFNULL(lh.report_date,''), ' ', IFNULL(lh.report_time,''))";
    $code_in = [];
    foreach ($egfr_codes as $c) {
        $code_in[] = "'" . mysqli_real_escape_string($hos, $c) . "'";
    }
    $code_sql = $code_in ? ('lo.lab_items_code IN (' . implode(',', $code_in) . ') OR ') : '';
    $filter = "($code_sql $name_sql LIKE '%eGFR%' OR $name_sql LIKE '%CKD-EPI%' OR $name_sql LIKE '%CKD EPI%')";
    $sql = "
        SELECT lh.hn, $value_sql AS value, $dt_sql AS reporttime
        FROM lab_head lh
        INNER JOIN lab_order lo ON lo.lab_order_number = lh.lab_order_number
        LEFT JOIN lab_items i ON i.lab_items_code = lo.lab_items_code
        WHERE lh.hn IN ($in)
          AND lh.report_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
          AND lh.report_date > '0000-00-00'
          AND lo.lab_order_result IS NOT NULL
          AND TRIM(lo.lab_order_result) <> ''
          AND $filter
        ORDER BY lh.report_date DESC, lh.report_time DESC
    ";
    $out = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return [];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $hn = ltrim(preg_replace('/\D+/', '', (string)($r['hn'] ?? '')), '0');
        if ($hn === '' || isset($out[$hn])) {
            continue;
        }
        $val = function_exists('amr_sens_parse_lab_num')
            ? amr_sens_parse_lab_num($r['value'] ?? '')
            : (float)preg_replace('/[^0-9.]/', '', (string)($r['value'] ?? ''));
        if ($val === null || $val <= 0) {
            continue;
        }
        $out[$hn] = [
            'val' => (float)$val,
            'date' => substr((string)($r['reporttime'] ?? ''), 0, 10),
            'raw' => trim((string)($r['value'] ?? '')),
        ];
    }
    return $out;
}

function mad_sys_lab_codes($con, $name) {
    $codes = [];
    if (!$con) {
        return $codes;
    }
    $esc = mysqli_real_escape_string($con, $name);
    $cfg = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = '$esc' LIMIT 1");
    if ($cfg && ($row = mysqli_fetch_assoc($cfg))) {
        foreach (preg_split('/\s*,\s*/', (string)$row['config_value']) as $c) {
            $c = trim($c);
            if ($c !== '') {
                $codes[] = $c;
            }
        }
    }
    return $codes;
}

function mad_fetch_scr_map($hos, array $hns, $con = null) {
    $in = mad_hn_in_sql($hos, $hns);
    if ($in === '') {
        return [];
    }
    $codes = mad_sys_lab_codes($con, 'h_code_scr');
    $name_sql = amr_sql_utf8("IFNULL(NULLIF(i.lab_items_name, ''), IFNULL(lo.lab_items_name_ref, ''))");
    $value_sql = amr_sql_utf8("IFNULL(lo.lab_order_result, '')");
    $dt_sql = function_exists('amr_sens_lab_dt_sql')
        ? amr_sens_lab_dt_sql()
        : "CONCAT(IFNULL(lh.report_date,''), ' ', IFNULL(lh.report_time,''))";
    $code_in = [];
    foreach ($codes as $c) {
        $code_in[] = "'" . mysqli_real_escape_string($hos, $c) . "'";
    }
    $code_sql = $code_in ? ('lo.lab_items_code IN (' . implode(',', $code_in) . ') OR ') : '';
    $filter = "($code_sql $name_sql LIKE '%Creatinine%' OR $name_sql LIKE '%CREATININE%' OR $name_sql LIKE '%Serum Cr%' OR $name_sql LIKE '%Cr%')";
    $sql = "
        SELECT lh.hn, $value_sql AS value, $dt_sql AS reporttime, $name_sql AS lab_name
        FROM lab_head lh
        INNER JOIN lab_order lo ON lo.lab_order_number = lh.lab_order_number
        LEFT JOIN lab_items i ON i.lab_items_code = lo.lab_items_code
        WHERE lh.hn IN ($in)
          AND lh.report_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
          AND lh.report_date > '0000-00-00'
          AND lo.lab_order_result IS NOT NULL
          AND TRIM(lo.lab_order_result) <> ''
          AND $filter
        ORDER BY lh.report_date DESC, lh.report_time DESC
    ";
    $out = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return [];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $hn = ltrim(preg_replace('/\D+/', '', (string)($r['hn'] ?? '')), '0');
        if ($hn === '' || isset($out[$hn])) {
            continue;
        }
        $nm = strtoupper((string)($r['lab_name'] ?? ''));
        if (strpos($nm, 'EGFR') !== false || strpos($nm, 'CKD') !== false || strpos($nm, 'CRP') !== false) {
            continue;
        }
        $val = function_exists('amr_sens_parse_lab_num')
            ? amr_sens_parse_lab_num($r['value'] ?? '')
            : (float)preg_replace('/[^0-9.]/', '', (string)($r['value'] ?? ''));
        if ($val === null || $val <= 0 || $val > 30) {
            continue;
        }
        $out[$hn] = [
            'val' => (float)$val,
            'date' => substr((string)($r['reporttime'] ?? ''), 0, 10),
        ];
    }
    return $out;
}

function mad_fetch_weight_map($hos, array $hns) {
    $in = mad_hn_in_sql($hos, $hns);
    if ($in === '') {
        return [];
    }
    $sql = "
        SELECT hn, bw
        FROM opdscreen
        WHERE hn IN ($in)
          AND vstdate >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
          AND bw > 0
        ORDER BY vstdate DESC, vsttime DESC
    ";
    $out = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return [];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $hn = ltrim(preg_replace('/\D+/', '', (string)($r['hn'] ?? '')), '0');
        if ($hn === '' || isset($out[$hn])) {
            continue;
        }
        $out[$hn] = (float)$r['bw'];
    }
    return $out;
}

function mad_renal_for_row($con, array $row, array $egfr_map, array $rule_map, array $scr_map = [], array $wt_map = []) {
    $hnk = ltrim((string)($row['hn'] ?? ''), '0');
    $kid = $egfr_map[$hnk] ?? null;
    $egfr = (float)($kid['val'] ?? 0);
    $scr = (float)($scr_map[$hnk]['val'] ?? 0);
    $weight = (float)($wt_map[$hnk] ?? 0);
    $age = (float)($row['age'] ?? 0);
    $gfr = 0.0;
    if ($age > 0 && $weight > 0 && $scr > 0) {
        $gfr = ((140 - $age) * $weight) / (72 * $scr);
        if ((string)($row['sex'] ?? '') === '2') {
            $gfr *= 0.85;
        }
    }
    $row['weight'] = $weight;
    $row['age'] = $age;
    $row['labs'] = [
        'CKD_EPI' => $egfr,
        'GFR' => $gfr,
        'SERUM_CR' => $scr,
    ];
    $name = trim((string)($row['drugName'] ?? $row['generic_name'] ?? ''));
    $renal = function_exists('amr_sens_renal_advice_for_name')
        ? amr_sens_renal_advice_for_name($con, $name, $row['labs'], (string)($row['icode'] ?? ''), $row, $rule_map)
        : ['status' => 'ok', 'level' => '', 'msg' => ''];
    $renal['egfr'] = $egfr > 0 ? $egfr : null;
    $renal['egfr_date'] = (string)($kid['date'] ?? '');
    if ($scr > 0) {
        $renal['scr'] = $scr;
        $renal['scr_date'] = (string)($scr_map[$hnk]['date'] ?? '');
    }
    return $renal;
}

function mad_best_r_hit(array $cultures, $drug_name) {
    $hit = mad_best_ast_hit($cultures, $drug_name);
    if ($hit && ($hit['sir'] ?? '') === 'R') {
        return $hit;
    }
    return null;
}

function mad_ast_cached(array &$cache, array $c) {
    $k = (string)($c['lab_order_number'] ?? '');
    if ($k === '') {
        return [];
    }
    if (!isset($cache[$k])) {
        if (!empty($c['_ast']) && is_array($c['_ast'])) {
            $cache[$k] = $c['_ast'];
        } else {
            $cache[$k] = function_exists('amr_sens_parse_ast')
                ? amr_sens_parse_ast($c['result_text'] ?? '')
                : [];
        }
    }
    return $cache[$k];
}

function mad_names_from_alts(array $list, $n = 4) {
    $out = [];
    foreach (array_slice($list, 0, $n) as $x) {
        $drug = trim((string)($x['drug'] ?? ''));
        if ($drug === '') {
            continue;
        }
        $tag = trim((string)($x['aware'] ?? ''));
        $out[] = $tag !== '' ? ($drug . ' (' . $tag . ')') : $drug;
    }
    return $out;
}

function mad_attach_steward(array $row, array $cultures, array $ranks, array &$ast_cache) {
    $order = (string)($row['lab_order_number'] ?? '');
    $ast = [];
    foreach ($cultures as $c) {
        if ((string)($c['lab_order_number'] ?? '') === $order) {
            $ast = mad_ast_cached($ast_cache, $c);
            break;
        }
    }
    if (!$ast && $cultures) {
        $ast = mad_ast_cached($ast_cache, $cultures[0]);
    }
    if (!$ast) {
        return $row;
    }
    $name = trim((string)($row['drugName'] ?? $row['generic_name'] ?? ''));
    $sir = strtoupper((string)($row['sir'] ?? ''));
    $alts = function_exists('amr_sens_s_alts_for_current')
        ? amr_sens_s_alts_for_current($ast, $name, $ranks, $sir)
        : ['deescalate' => [], 'escalate' => []];
    $meta = function_exists('amr_sens_ast_meta') ? amr_sens_ast_meta($name) : ['aware' => '', 'class' => ''];
    $row['aware'] = $meta['aware'] ?? '';
    $row['who_aware'] = $meta['who_aware'] ?? '';
    $row['class'] = $meta['class'] ?? '';
    $row['can_deescalate'] = ($sir === 'S' && !empty($alts['deescalate'])) ? 1 : 0;
    $row['need_escalate'] = ($sir === 'R' || $sir === 'I') ? 1 : 0;
    $row['deescalate_to'] = mad_names_from_alts($alts['deescalate'] ?? []);
    $row['escalate_to'] = mad_names_from_alts($alts['escalate'] ?? []);
    if ($row['need_escalate'] && empty($row['escalate_to']) && !empty($alts['same'])) {
        $row['escalate_to'] = mad_names_from_alts($alts['same']);
    }
    if ($row['need_escalate'] && empty($row['escalate_to']) && !empty($alts['deescalate'])) {
        $row['escalate_to'] = mad_names_from_alts($alts['deescalate']);
    }
    return $row;
}

function mad_scan($hos, $con = null, $lookback = '7d', array $an_filter = [], $rxdate = '') {
    $lb = mad_parse_lookback($lookback);
    $empty_meta = [
        'atb' => 0,
        'matched' => 0,
        'patients' => 0,
        'patients_ok' => 0,
        'patients_caution' => 0,
        'patients_matched' => 0,
        'alerts' => 0,
        'appropriate' => 0,
        'caution' => 0,
        'pct_inappropriate' => null,
        'pct_appropriate' => null,
        'pct_caution' => null,
        'pct_patient_inappropriate' => null,
    ];
    $cur = mad_fetch_current_atb($hos, $con, $an_filter, $rxdate);
    if ($cur['error'] !== '') {
        return ['error' => $cur['error'], 'rows' => [], 'rows_ok' => [], 'rows_caution' => [], 'rows_renal' => [], 'rows_escalate' => [], 'rows_deescalate' => [], 'meta' => $empty_meta];
    }
    $skip_kw = mad_skip_method_list($con);
    $filtered = mad_filter_skip_method($cur['rows'], $skip_kw);
    $atb = $filtered['rows'];
    $skip_n = (int)$filtered['skipped'];
    $hns = [];
    $ans = [];
    foreach ($atb as $r) {
        $hns[] = $r['hn'];
        if (!empty($r['an'])) {
            $ans[] = $r['an'];
        }
    }
    $cultures = mad_fetch_cultures($hos, $hns, $lb, $ans, $con);
    $by_an = mad_cultures_by_an($cultures);
    $egfr_map = mad_fetch_egfr_map($hos, $hns, $con);
    $scr_map = mad_fetch_scr_map($hos, $hns, $con);
    $wt_map = mad_fetch_weight_map($hos, $hns);
    $rule_map = function_exists('amr_sens_load_renal_rule_map')
        ? amr_sens_load_renal_rule_map($con)
        : [];
    $ranks = function_exists('amr_sens_rec_rank_maps')
        ? amr_sens_rec_rank_maps($con)
        : ['aware' => [], 'class' => []];
    $mode = function_exists('amr_sens_steward_mode')
        ? amr_sens_steward_mode($con)
        : 'both';
    $ast_cache = [];
    $rows_r = [];
    $rows_s = [];
    $rows_i = [];
    $rows_renal = [];
    $seen = [];
    $seen_renal = [];
    $n_adjust = 0;
    $n_avoid = 0;
    $n_renal_ok = 0;
    $hn_renal = [];
    foreach ($atb as $r) {
        $r['renal'] = mad_renal_for_row($con, $r, $egfr_map, $rule_map, $scr_map, $wt_map);
        $st = (string)($r['renal']['status'] ?? '');
        if ($st === 'avoid') {
            $n_avoid++;
            $hn_renal[$r['hn']] = true;
        } elseif ($st === 'adjust') {
            $n_adjust++;
            $hn_renal[$r['hn']] = true;
        } elseif ($st === 'ok') {
            $n_renal_ok++;
        }
        if ($st === 'adjust' || $st === 'avoid') {
            $rk = $r['an'] . '|' . $r['icode'];
            if (!isset($seen_renal[$rk])) {
                $seen_renal[$rk] = true;
                $rows_renal[] = $r;
            }
        }
        $list = $by_an[(string)$r['an']] ?? [];
        if (!$list) {
            continue;
        }
        $name = $r['drugName'] ?: ($r['generic_name'] ?? '');
        $hit = mad_best_ast_hit($list, $name);
        if (!$hit && ($r['generic_name'] ?? '') !== '' && $r['generic_name'] !== $name) {
            $hit = mad_best_ast_hit($list, $r['generic_name']);
        }
        if (!$hit) {
            continue;
        }
        $key = $r['an'] . '|' . $r['icode'] . '|' . ($hit['lab_order_number'] ?? '');
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $row = mad_attach_steward(array_merge($r, $hit), $list, $ranks, $ast_cache);
        $sir = strtoupper((string)($row['sir'] ?? ''));
        if ($sir === 'R') {
            $rows_r[] = $row;
        } elseif ($sir === 'S') {
            $rows_s[] = $row;
        } elseif ($sir === 'I') {
            $rows_i[] = $row;
        }
    }
    $hn_r = [];
    $hn_s = [];
    $hn_i = [];
    foreach ($rows_r as $r) {
        $hn_r[$r['hn']] = true;
    }
    foreach ($rows_s as $r) {
        $hn_s[$r['hn']] = true;
    }
    foreach ($rows_i as $r) {
        $hn_i[$r['hn']] = true;
    }
    $hn_matched = $hn_r + $hn_s + $hn_i;
    $n_r = count($rows_r);
    $n_s = count($rows_s);
    $n_i = count($rows_i);
    $matched = $n_r + $n_s + $n_i;
    $rows_es = [];
    $rows_de = [];
    $hn_es = [];
    $hn_de = [];
    foreach (array_merge($rows_r, $rows_s, $rows_i) as $row) {
        if (!empty($row['need_escalate'])) {
            $rows_es[] = $row;
            $hn_es[$row['hn']] = true;
        }
        if (!empty($row['can_deescalate'])) {
            $rows_de[] = $row;
            $hn_de[$row['hn']] = true;
        }
    }
    $pct = static function ($n, $den) {
        if ($den <= 0) {
            return null;
        }
        return round(100.0 * $n / $den, 1);
    };
    $sort_report = static function (array $rows) {
        usort($rows, static function ($a, $b) {
            return strcmp(
                (string)($b['reportdatetime'] ?? $b['report_date'] ?? ''),
                (string)($a['reportdatetime'] ?? $a['report_date'] ?? '')
            );
        });
        return $rows;
    };
    return [
        'error' => '',
        'rows' => $sort_report($rows_r),
        'rows_ok' => $sort_report($rows_s),
        'rows_caution' => $sort_report($rows_i),
        'rows_renal' => $sort_report($rows_renal),
        'rows_escalate' => $sort_report($rows_es),
        'rows_deescalate' => $sort_report($rows_de),
        'steward' => function_exists('amr_sens_steward_mode_meta')
            ? amr_sens_steward_mode_meta($mode)
            : ['mode' => $mode, 'label' => $mode],
        'meta' => [
            'atb' => count($atb),
            'matched' => $matched,
            'patients' => count($hn_r),
            'patients_ok' => count($hn_s),
            'patients_caution' => count($hn_i),
            'patients_matched' => count($hn_matched),
            'alerts' => $n_r,
            'appropriate' => $n_s,
            'caution' => $n_i,
            'escalate' => count($rows_es),
            'deescalate' => count($rows_de),
            'patients_escalate' => count($hn_es),
            'patients_deescalate' => count($hn_de),
            'renal_adjust' => $n_adjust,
            'renal_avoid' => $n_avoid,
            'renal_ok' => $n_renal_ok,
            'patients_renal' => count($hn_renal),
            'pct_inappropriate' => $pct($n_r, $matched),
            'pct_appropriate' => $pct($n_s, $matched),
            'pct_caution' => $pct($n_i, $matched),
            'pct_patient_inappropriate' => $pct(count($hn_r), count($hn_matched)),
            'lookback' => $lb['key'],
            'lookback_label' => $lb['label'],
            'lookback_days' => mad_lookback_days($lb['key']),
            'as_of' => date('Y-m-d H:i'),
            'skip_method_keywords' => $skip_kw,
            'skip_method_count' => $skip_n,
            'micro_source' => ($con && function_exists('amr_mlab_using_direct') && amr_mlab_using_direct($con)) ? 'mlab' : 'hosxp',
            'micro_source_label' => ($con && function_exists('amr_mlab_using_direct') && amr_mlab_using_direct($con))
                ? 'mLAB (ตาราง THAM Hos-Safe)'
                : 'HOSxP lab_head',
        ],
    ];
}
