<?php
/**
 * OAuth callback จาก Health ID → แลก Provider ID → เข้าสู่ระบบ
 */
session_start();
header('Content-Type: text/html; charset=utf-8');

require_once __DIR__ . '/connect.php';
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/provider_oauth_helper.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/user_access_helper.php';

function oauth_callback_fail($msg) {
    $params = ['oauth_error' => $msg, 'mode' => 'provider'];
    if (!empty($_SESSION['login_return_url'])) {
        $params['return'] = (string)$_SESSION['login_return_url'];
    }
    header('Location: login.php?' . http_build_query($params));
    exit;
}

function oauth_pakping_url($path) {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ((int)($_SERVER['SERVER_PORT'] ?? 0) === 443)
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return ($https ? 'https' : 'http') . '://' . $host . '/scphpakping/' . ltrim($path, '/');
}

function oauth_pakping_fail($msg) {
    header('Location: ' . oauth_pakping_url('login.php?oauth_error=' . rawurlencode($msg)));
    exit;
}

function oauth_is_pakping_state($con, $state) {
    if (!preg_match('/^[a-f0-9]{32}$/', (string)$state)) {
        return false;
    }
    $esc = mysqli_real_escape_string($con, $state);
    $q = mysqli_query($con, "SELECT state FROM pp_oauth_states WHERE state = '$esc' AND used = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL 15 MINUTE) LIMIT 1");
    return $q && mysqli_num_rows($q) > 0;
}

$code = trim((string)($_GET['code'] ?? ''));
$state = trim((string)($_GET['state'] ?? ''));
$error = trim((string)($_GET['error'] ?? ''));
$error_desc = trim((string)($_GET['error_description'] ?? ''));
$for_pakping = oauth_is_pakping_state($con, $state);

if ($error !== '') {
    $msg = $error_desc !== '' ? $error_desc : ('OAuth error: ' . $error);
    if ($for_pakping) {
        oauth_pakping_fail($msg);
    }
    oauth_callback_fail($msg);
}

if ($for_pakping) {
    $esc = mysqli_real_escape_string($con, $state);
    mysqli_query($con, "UPDATE pp_oauth_states SET used = 1 WHERE state = '$esc'");
    $_SESSION['provider_oauth_state'] = $state;
    $result = provider_oauth_complete_login($con, $code, $state);
    if (empty($result['ok'])) {
        oauth_pakping_fail($result['error'] ?? 'เข้าสู่ระบบด้วย Provider ID ไม่สำเร็จ');
    }
    $user_row = $result['user'];
    $profile = is_array($result['provider_profile'] ?? null) ? $result['provider_profile'] : [];
    $username = trim((string)($user_row['username'] ?? ''));
    $full_name = trim((string)($profile['name_th'] ?? $user_row['full_name'] ?? $username));
    $provider_id = trim((string)($profile['provider_id'] ?? ''));
    $position = substr(trim((string)($user_row['entryposition'] ?? '')), 0, 255);
    if ($position === '') {
        $position = substr(trim((string)($profile['position'] ?? '')), 0, 255);
    }
    $ticket = bin2hex(random_bytes(32));
    $now = date('Y-m-d H:i:s');
    $chk = mysqli_query($con, "SHOW COLUMNS FROM pp_oauth_tickets LIKE 'entryposition'");
    if ($chk && mysqli_num_rows($chk) === 0) {
        mysqli_query($con, "ALTER TABLE pp_oauth_tickets ADD COLUMN entryposition VARCHAR(255) NULL AFTER provider_id");
    }
    $st = mysqli_prepare($con, 'INSERT INTO pp_oauth_tickets (ticket, username, full_name, provider_id, entryposition, created_at, used) VALUES (?,?,?,?,?,?,0)');
    mysqli_stmt_bind_param($st, 'ssssss', $ticket, $username, $full_name, $provider_id, $position, $now);
    $saved = mysqli_stmt_execute($st);
    mysqli_stmt_close($st);
    if (!$saved) {
        oauth_pakping_fail('บันทึกการเข้าสู่ระบบไม่สำเร็จ');
    }
    header('Location: ' . oauth_pakping_url('oauth_finish.php?ticket=' . rawurlencode($ticket)));
    exit;
}

$result = provider_oauth_complete_login($con, $code, $state);
if (empty($result['ok'])) {
    oauth_callback_fail($result['error'] ?? 'เข้าสู่ระบบด้วย Provider ID ไม่สำเร็จ');
}

$user_row = $result['user'];
require_once __DIR__ . '/local_web_helper.php';
if (!tham_local_web_allow_login($con, $user_row)) {
    oauth_callback_fail(tham_local_web_deny_message());
}

$_SESSION['user_id'] = $user_row['id'];
$_SESSION['username'] = $user_row['username'];
$_SESSION['full_name'] = $user_row['full_name'];
$_SESSION['role'] = $user_row['role'];
$_SESSION['auth_source'] = $user_row['auth_source'] ?? 'provider_id';
$_SESSION['local_web_only'] = tham_user_local_web_only_flag($con, (int)$user_row['id']) ? 1 : 0;
$_SESSION['login_via'] = 'provider_id';
$_SESSION['moph_access_token_idp'] = $result['moph_access_token_idp'] ?? '';
$_SESSION['provider_access_token'] = $result['provider_access_token'] ?? '';
$_SESSION['provider_profile'] = $result['provider_profile'] ?? [];
$sess_pos = trim((string)($user_row['entryposition'] ?? ''));
if ($sess_pos === '') {
    $sess_pos = trim((string)(($result['provider_profile']['position'] ?? '') ?: ''));
}
$_SESSION['entryposition'] = $sess_pos;

if (empty($_SESSION['moph_access_token_idp'])) {
    $org_count = (int)($_SESSION['provider_profile']['org_count'] ?? 0);
    $hint = $org_count === 0
        ? 'ไม่พบข้อมูลสังกัดใน Provider ID'
        : 'โปรไฟล์มีสังกัด แต่ไม่ได้รับ moph_access_token_idp (อาจยังไม่มีสิทธิ์ขอ MOPH JWT จากทีม Provider ID)';
    $_SESSION['provider_oauth_warning'] = 'เข้าสู่ระบบสำเร็จ แต่ยังไม่มี moph token สำหรับ Drugs Center — ' . $hint;
} elseif (!empty($result['linked_opduser'])) {
    $_SESSION['provider_oauth_notice'] = 'เชื่อมกับบัญชี HOSxP แล้ว — ใช้สิทธิ์เมนูตามตำแหน่ง (entryposition) ใน HOSxP';
}

tham_menu_load_session_permissions($con, (int)$user_row['id'], $user_row['role']);
tham_user_access_log_login($con, (int)$user_row['id']);

require_once __DIR__ . '/hapysure_helper.php';
$pid = '';
if (is_array($_SESSION['provider_profile'] ?? null)) {
    $pid = trim((string)($_SESSION['provider_profile']['provider_id'] ?? ''));
    if ($pid === '' && isset($_SESSION['provider_profile']['data']) && is_array($_SESSION['provider_profile']['data'])) {
        $pid = trim((string)($_SESSION['provider_profile']['data']['provider_id'] ?? ''));
    }
}
if ($pid !== '') {
    $_SESSION['hapysure_user'] = $pid;
}

require_once __DIR__ . '/user_unit_helper.php';
tham_user_post_login_redirect($con);
