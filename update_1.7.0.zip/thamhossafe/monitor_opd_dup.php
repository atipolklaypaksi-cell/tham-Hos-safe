<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('hosxp_tmt_drug_helper.php');
include('monitor_opd_dup_helper.php');
include('monitor_opd_dup_consult_helper.php');
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
mysqli_set_charset($con, 'utf8');

mopd_ensure_tables($con);
mopdc_ensure_tables($con);

$default_start = date('Y-m-d', strtotime('-3 days'));
$default_end = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_config') {
    $ok = mopd_save_config($con, [
        'lookback_days' => $_POST['lookback_days'] ?? 90,
        'match_mode' => $_POST['match_mode'] ?? 'icode_or_tmt',
        'min_remaining_days' => $_POST['min_remaining_days'] ?? 1,
        'include_unknown_remaining' => isset($_POST['include_unknown_remaining']) ? 1 : 0,
        'exclude_prn' => isset($_POST['exclude_prn']) ? 1 : 0,
        'alert_level_remaining' => $_POST['alert_level_remaining'] ?? 'soft',
        'alert_level_unknown' => $_POST['alert_level_unknown'] ?? 'soft',
        'exclude_icodes' => $_POST['exclude_icodes'] ?? '',
        'monitor_active' => isset($_POST['monitor_active']) ? 1 : 0,
        'hide_low_remaining' => isset($_POST['hide_low_remaining']) ? 1 : 0,
        'hide_low_remaining_days' => $_POST['hide_low_remaining_days'] ?? 20,
        'hide_short_hme' => isset($_POST['hide_short_hme']) ? 1 : 0,
        'hide_short_hme_days' => $_POST['hide_short_hme_days'] ?? 14,
        'unitprice_exception' => $_POST['unitprice_exception'] ?? 50,
        'min_remaining_value' => $_POST['min_remaining_value'] ?? 0,
        'only_off_appointment' => isset($_POST['only_off_appointment']) ? 1 : 0,
    ]);
    if ($ok && function_exists('sp_monitor_settings_changed')) {
        sp_monitor_settings_changed($con, 'opd_dup');
    }
    $_SESSION['mopd_msg'] = $ok ? 'บันทึกการตั้งค่า Monitor ยาเหลือ OPD เรียบร้อย' : ('บันทึกไม่สำเร็จ: ' . mysqli_error($con));
    header('Location: monitor_opd_dup.php?tab=settings');
    exit;
}

$config = mopd_get_config($con);
$tab = (isset($_GET['tab']) && $_GET['tab'] === 'settings') ? 'settings' : 'monitor';
$flash_msg = $_SESSION['mopd_msg'] ?? '';
$flash_err = $_SESSION['mopd_error'] ?? '';
unset($_SESSION['mopd_msg'], $_SESSION['mopd_error']);

$current_user_id = (int)($_SESSION['user_id'] ?? 0);
$pharmacist_options = mopdc_list_pharmacists($con, $current_user_id);
$mopdc_reply_wait_days = mopdc_get_reply_wait_days($con);

session_write_close();

$exclude_text = implode("\n", $config['exclude_icodes']);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor ยาเหลือ OPD - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .section-hard .table thead { background-color: #dc3545 !important; color: #fff !important; }
        .section-soft .table thead { background-color: #fd7e14 !important; color: #fff !important; }
        .mhm-range-btn.active { background-color: #c2410c !important; border-color: #c2410c !important; color: #fff !important; }
        .mhm-dup { background: #fff7ed; border-left: 3px solid #ea580c; padding: 4px 8px; border-radius: 4px; }
        .mhm-remain { font-weight: 700; color: #b91c1c; }
        .mhm-remain-qty { font-weight: 800; color: #9a3412; font-size: 0.95rem; }
        .mhm-appt-days { font-weight: 700; color: #0369a1; }
        .mhm-appt-list { display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
        .mhm-appt-list .badge { font-weight: 600; white-space: normal; text-align: left; }
        .mhm-patient { border: 1px solid #e5e7eb; border-radius: 10px; margin-bottom: 12px; overflow: hidden; background: #fff; }
        .mhm-patient.has-prior { border-color: #fdba74; }
        .mhm-pt-head { display: flex; flex-wrap: wrap; gap: 8px 16px; align-items: center; padding: 10px 14px; background: #fff7ed; border-bottom: 1px solid #fed7aa; }
        .mhm-patient:not(.has-prior) .mhm-pt-head { background: #f8fafc; border-bottom-color: #e2e8f0; }
        .mhm-pt-hn { font-size: 1.05rem; color: #9a3412; }
        .mhm-prior-mark { display: inline-flex; align-items: center; gap: 4px; background: #ea580c; color: #fff; font-weight: 700; font-size: 0.75rem; padding: 2px 8px; border-radius: 999px; }
        .mhm-drug-table { margin: 0; }
        .mhm-drug-table th { font-size: 0.75rem; background: #f1f5f9; }
        .mhm-drug-row.prior td { background: #fff7ed; }
        .mhm-legend span { margin-right: 12px; }
        .mhm-alert-card { border: 2px solid #e2e8f0; border-radius: 10px; padding: 0.7rem 0.85rem; cursor: pointer; height: 100%; }
        .mhm-alert-card.active-soft { border-color: #ca8a04; background: #fffbeb; }
        .mhm-alert-card.active-hard { border-color: #dc2626; background: #fef2f2; }
        .mlc-outcome-group { gap: .35rem 1.1rem; }
        .mlc-outcome-group .form-check { min-width: 7.5rem; }
        .mopd-consult-cell { min-width: 132px; }
        .mopd-sum-card { border-radius: 10px; padding: 12px 14px; height: 100%; border: 1px solid #e5e7eb; background: #fff; }
        .mopd-sum-card .mopd-sum-num { font-size: 1.55rem; font-weight: 800; line-height: 1.2; }
        .mopd-sum-case { border-top: 4px solid #c2410c; }
        .mopd-sum-value { border-top: 4px solid #0369a1; }
        .mopd-sum-avg { border-top: 4px solid #7c3aed; }
        .mopd-sum-max { border-top: 4px solid #15803d; }
        .mopd-sum-case .mopd-sum-num { color: #c2410c; }
        .mopd-sum-value .mopd-sum-num { color: #0369a1; }
        .mopd-sum-avg .mopd-sum-num { color: #7c3aed; }
        .mopd-sum-max .mopd-sum-num { color: #15803d; }
        .mopd-pt-val { background: #0369a1; font-weight: 700; }
        .mopd-pttype { display: inline-flex; align-items: center; gap: 4px; background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; font-weight: 700; font-size: 0.75rem; padding: 2px 8px; border-radius: 999px; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-2 text-dark">
                <i class="fas fa-history me-2" style="color:#c2410c;"></i>
                Monitor ยาเหลือ OPD <span class="badge bg-secondary">OPD</span>
            </h4>
            <p class="text-muted small mb-4">
                ตรวจใบยา <b>ผู้ป่วยนอก (OPD)</b> เทียบกับยาเดิมของ HN เดียวกันที่ยังเหลือที่บ้าน
                — จับการสั่งซ้ำเมื่อยาเดิมยังไม่หมด (ไม่ใช่คู่ยาคนละชนิด)
            </p>

            <?php if ($flash_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo htmlspecialchars($flash_msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            <?php if ($flash_err): ?>
            <div class="alert alert-danger alert-dismissible fade show"><?php echo htmlspecialchars($flash_err); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <ul class="nav nav-tabs fw-bold" role="tablist">
                <li class="nav-item">
                    <button class="nav-link <?php echo $tab === 'monitor' ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#monitor" type="button">
                        <i class="fas fa-desktop me-1"></i> รายการเฝ้าระวัง
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link <?php echo $tab === 'settings' ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#settings" type="button">
                        <i class="fas fa-cogs me-1"></i> ตั้งค่า
                    </button>
                </li>
            </ul>

            <div class="tab-content bg-white border border-top-0 p-4 rounded-bottom shadow-sm">
                <div class="tab-pane fade <?php echo $tab === 'monitor' ? 'show active' : ''; ?>" id="monitor">
                    <div class="filter-box p-3 mb-3">
                        <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-filter me-2"></i>วันที่สั่งยา OPD</h6>
                        <div class="row g-2 align-items-end">
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ตั้งแต่</label>
                                <input type="text" id="filter_start" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_start); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ถึงวันที่</label>
                                <input type="text" id="filter_end" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_end); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold mb-1">ค้นหา HN</label>
                                <input type="search" id="mopdHnSearch" class="form-control form-control-sm bg-white" placeholder="HN / ชื่อ / สิทธิ" autocomplete="off" oninput="mopdOnHnSearch()">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-sm fw-bold text-white w-100 shadow-sm" style="background:#c2410c;" id="btnFetchMHM" onclick="fetchMHMData()">
                                    <i class="fas fa-sync-alt me-1"></i> ประมวลผล
                                </button>
                            </div>
                        </div>
                        <div class="row g-2 mt-2 align-items-center">
                            <div class="col-auto"><label class="form-label small fw-bold mb-0 text-secondary">ช่วงเร็ว:</label></div>
                            <div class="col">
                                <div class="btn-group btn-group-sm flex-wrap">
                                    <button type="button" class="btn btn-outline-secondary fw-bold mhm-range-btn" data-days="1" onclick="setMHMDateRange(1)">วันนี้</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mhm-range-btn active" data-days="3" onclick="setMHMDateRange(3)">3 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mhm-range-btn" data-days="7" onclick="setMHMDateRange(7)">7 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mhm-range-btn" data-days="30" onclick="setMHMDateRange(30)">30 วัน</button>
                                </div>
                            </div>
                        </div>
                        <div class="small text-muted mt-2"><i class="fas fa-info-circle me-1"></i> ประมวลผลทีละวัน แบ่งกลุ่มคนไข้ แล้วรันคู่ขนาน — แนะนำเริ่มที่ <b>3 วัน</b> · เปิดจาก Smart Pharma จะกรองตาม HN</div>
                        <div id="offApptBanner" class="alert alert-warning py-2 px-3 mt-2 mb-0 fw-bold<?php echo empty($config['only_off_appointment']) ? ' d-none' : ''; ?>">
                            <i class="fas fa-calendar-times me-1"></i> รายงานที่แสดง ดึงเฉพาะกรณีที่ผู้ป่วยมาไม่ตรงวันนัด
                            <div class="fw-normal small mt-1">วันมา (วันที่สั่งยาครั้งนี้) ไม่ตรงกับวันนัดที่เคยสั่งไว้ก่อนหน้า · คนที่มาตรงวันนัดจะไม่ถูกดึง</div>
                        </div>
                        <div id="hnFocusBanner" class="alert alert-warning py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                        <div id="reportMeta" class="alert alert-info py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                    </div>

                    <div id="mopdSummary" class="row g-2 mb-3 d-none">
                        <div class="col-sm-6 col-lg-3">
                            <div class="mopd-sum-card mopd-sum-case">
                                <div class="small fw-bold text-muted"><i class="fas fa-user-injured me-1"></i> จำนวนเคส</div>
                                <div class="mopd-sum-num" id="mopdSumCases">0</div>
                                <div class="small text-muted">คนไข้ที่มียาเหลือ · ใบสั่งยา <span id="mopdSumRx">0</span> ใบ</div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="mopd-sum-card mopd-sum-value">
                                <div class="small fw-bold text-muted"><i class="fas fa-coins me-1"></i> มูลค่าที่ประหยัดได้</div>
                                <div class="mopd-sum-num" id="mopdSumTotal">0.00</div>
                                <div class="small text-muted">ถ้าตรวจยาคงเหลือแล้วไม่จ่ายซ้ำ (บาท)</div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="mopd-sum-card mopd-sum-avg">
                                <div class="small fw-bold text-muted"><i class="fas fa-user me-1"></i> ประหยัดได้ต่อเคส</div>
                                <div class="mopd-sum-num" id="mopdSumAvg">0.00</div>
                                <div class="small text-muted">เฉลี่ยต่อคนไข้ (มูลค่ารวม ÷ จำนวนเคส)</div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="mopd-sum-card mopd-sum-max">
                                <div class="small fw-bold text-muted"><i class="fas fa-arrow-up me-1"></i> ประหยัดได้สูงสุดต่อใบสั่งยา</div>
                                <div class="mopd-sum-num" id="mopdSumMax">0.00</div>
                                <div class="small text-muted" id="mopdSumMaxHint">ใบสั่งยาที่มีมูลค่ายาเหลือสูงสุด</div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
                        <span class="small fw-bold text-muted me-1">แสดง:</span>
                        <div class="btn-group btn-group-sm" role="group">
                            <button type="button" class="btn btn-outline-secondary active fw-bold" data-mhm-filter="all" onclick="setMHMFilter('all', this)">ทั้งหมด <span id="mhmCountAll" class="badge bg-secondary">0</span></button>
                            <button type="button" class="btn btn-outline-warning fw-bold" data-mhm-filter="prior" onclick="setMHMFilter('prior', this)">เคยได้ OPD <span id="mhmCountPrior" class="badge bg-warning text-dark">0</span></button>
                            <button type="button" class="btn btn-outline-danger fw-bold" data-mhm-filter="hard" onclick="setMHMFilter('hard', this)">Hard Alert <span id="mhmCountHard" class="badge bg-danger">0</span></button>
                            <button type="button" class="btn btn-outline-warning fw-bold" data-mhm-filter="soft" onclick="setMHMFilter('soft', this)">Soft Alert <span id="mhmCountSoft" class="badge bg-warning text-dark">0</span></button>
                        </div>
                        <div class="mhm-legend small text-muted ms-2">
                            <span class="mhm-prior-mark"><i class="fas fa-history"></i> เคยได้ OPD</span>
                            = ยาที่สั่งวันนี้เคยจ่ายจาก OPD ครั้งก่อนและยังเหลือ
                            · คอลัมน์ <b>ถึงวันนัด</b> = นัดที่สั่งในวันเดียวกับวันที่สั่งยา (วันที่มา / วันที่สั่งนัด = วันที่สั่งยา)
                        </div>
                    </div>
                    <div id="mhmPatients">
                        <div class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</div>
                    </div>
                </div>

                <div class="tab-pane fade <?php echo $tab === 'settings' ? 'show active' : ''; ?>" id="settings">
                    <form method="post" class="row g-4">
                        <input type="hidden" name="action" value="save_config">
                        <div class="col-lg-7">
                            <div class="card shadow-sm border-0">
                                <div class="card-header text-white fw-bold" style="background:#c2410c;">
                                    <i class="fas fa-sliders-h me-1"></i> เกณฑ์ตรวจยาเหลือ OPD
                                </div>
                                <div class="card-body">
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" name="monitor_active" id="mhm_active" <?php echo !empty($config['monitor_active']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label fw-bold" for="mhm_active">เปิดใช้งาน Monitor</label>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">ย้อนหลังดูยา OPD เดิม (วัน)</label>
                                        <input type="number" name="lookback_days" class="form-control form-control-sm" min="7" max="365" value="<?php echo (int)$config['lookback_days']; ?>">
                                        <div class="form-text">เช่น 90 = ดูใบยา OPD ภายใน 90 วันก่อนวันสั่งยาครั้งนี้</div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">วิธีจับคู่ยา</label>
                                        <select name="match_mode" class="form-select form-select-sm">
                                            <option value="icode_or_tmt" <?php echo $config['match_mode'] === 'icode_or_tmt' ? 'selected' : ''; ?>>icode เดียวกัน หรือชื่อ TMT (ตัวยา+ความแรง) เดียวกัน</option>
                                            <option value="icode" <?php echo $config['match_mode'] === 'icode' ? 'selected' : ''; ?>>เฉพาะ icode เดียวกัน</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">แจ้งเตือนเมื่อยา OPD เหลืออย่างน้อย (วัน)</label>
                                        <input type="number" name="min_remaining_days" class="form-control form-control-sm" min="0" max="180" value="<?php echo (int)$config['min_remaining_days']; ?>">
                                        <div class="form-text">คำนวณจากจำนวนจ่าย OPD เดิม ÷ ปริมาณต่อวัน ตามวิธีใช้ แล้วหักจำนวนวันถึงวันสั่งยาครั้งนี้</div>
                                    </div>
                                    <?php
                                    $lvl_rem = mhm_normalize_alert_level($config['alert_level_remaining'] ?? 'soft');
                                    $lvl_unk = mhm_normalize_alert_level($config['alert_level_unknown'] ?? 'soft');
                                    ?>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">ระดับเมื่อมียาเหลือ ณ วันสั่งใหม่ <span class="text-muted fw-normal">(ค่าเริ่มต้น Soft Alert)</span></label>
                                        <div class="row g-2">
                                            <div class="col-6">
                                                <label class="mhm-alert-card d-block <?php echo $lvl_rem !== 'hard' ? 'active-soft' : ''; ?>">
                                                    <div class="form-check mb-0">
                                                        <input class="form-check-input" type="radio" name="alert_level_remaining" id="mopd_rem_soft" value="soft" <?php echo $lvl_rem !== 'hard' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label small" for="mopd_rem_soft">
                                                            <span class="badge bg-warning text-dark">Soft Alert</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-text small mb-0">เตือนสีเหลือง ไม่บล็อก</div>
                                                </label>
                                            </div>
                                            <div class="col-6">
                                                <label class="mhm-alert-card d-block <?php echo $lvl_rem === 'hard' ? 'active-hard' : ''; ?>">
                                                    <div class="form-check mb-0">
                                                        <input class="form-check-input" type="radio" name="alert_level_remaining" id="mopd_rem_hard" value="hard" <?php echo $lvl_rem === 'hard' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label small" for="mopd_rem_hard">
                                                            <span class="badge bg-danger">Hard Alert</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-text small mb-0">เตือนระดับสูง สีแดง</div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">ระดับเมื่อคำนวณวันที่เหลือไม่ได้ <span class="text-muted fw-normal">(ค่าเริ่มต้น Soft Alert)</span></label>
                                        <div class="row g-2">
                                            <div class="col-6">
                                                <label class="mhm-alert-card d-block <?php echo $lvl_unk !== 'hard' ? 'active-soft' : ''; ?>">
                                                    <div class="form-check mb-0">
                                                        <input class="form-check-input" type="radio" name="alert_level_unknown" id="mopd_unk_soft" value="soft" <?php echo $lvl_unk !== 'hard' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label small" for="mopd_unk_soft">
                                                            <span class="badge bg-warning text-dark">Soft Alert</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-text small mb-0">เตือนสีเหลือง ไม่บล็อก</div>
                                                </label>
                                            </div>
                                            <div class="col-6">
                                                <label class="mhm-alert-card d-block <?php echo $lvl_unk === 'hard' ? 'active-hard' : ''; ?>">
                                                    <div class="form-check mb-0">
                                                        <input class="form-check-input" type="radio" name="alert_level_unknown" id="mopd_unk_hard" value="hard" <?php echo $lvl_unk === 'hard' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label small" for="mopd_unk_hard">
                                                            <span class="badge bg-danger">Hard Alert</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-text small mb-0">เตือนระดับสูง สีแดง</div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" name="include_unknown_remaining" id="mhm_unk" <?php echo !empty($config['include_unknown_remaining']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small" for="mhm_unk">แจ้งเตือนแม้คำนวณวันที่เหลือไม่ได้ (วิธีใช้ PRN / ไม่ชัด)</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="checkbox" name="exclude_prn" id="mhm_prn" <?php echo !empty($config['exclude_prn']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small" for="mhm_prn">ข้ามยา OPD ที่วิธีใช้เป็น PRN / ตามอาการ</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="checkbox" name="only_off_appointment" id="mhm_off_appt" <?php echo !empty($config['only_off_appointment']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small" for="mhm_off_appt">ดึงเฉพาะกรณีที่ผู้ป่วย<b>มาไม่ตรงวันนัด</b></label>
                                        <div class="form-text">วันมาไม่ตรงกับวันนัดที่เคยสั่งไว้ก่อนหน้า (oapp) · คนที่มาตรงวันนัด หรือไม่เคยมีนัด จะไม่ถูกดึง · เมื่อเปิดไว้ รายงานจะแจ้งเงื่อนไขนี้ชัดเจน</div>
                                    </div>
                                    <hr class="my-3">
                                    <div class="fw-bold small mb-2">ตัดยาเดิมที่เหลือ ณ วันสั่งใหม่ น้อยเกินไป</div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" name="hide_low_remaining" id="mhm_hide_low" <?php echo !empty($config['hide_low_remaining']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small" for="mhm_hide_low">ไม่นับยาเดิมที่เหลือ ณ วันสั่งใหม่ <strong>น้อยกว่าเกณฑ์</strong> และไม่ดึงเคสถ้าไม่มียาเดิมเหลือพอ</label>
                                    </div>
                                    <div class="row g-2 mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label small fw-bold">เกณฑ์วันที่เหลือ ณ วันสั่งใหม่ (วัน)</label>
                                            <input type="number" name="hide_low_remaining_days" class="form-control form-control-sm" min="0" max="365" value="<?php echo (int)$config['hide_low_remaining_days']; ?>">
                                            <div class="form-text">ค่าเริ่มต้น 20 วัน — เช่น เหลือ 1 วัน จะไม่ขึ้น “เคยได้ OPD”</div>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label small fw-bold">ยกเว้นยามูลค่าต่อชิ้นมากกว่า (บาท)</label>
                                            <input type="number" name="unitprice_exception" class="form-control form-control-sm" min="0" step="0.01" value="<?php echo htmlspecialchars(number_format((float)$config['unitprice_exception'], 2, '.', '')); ?>">
                                            <div class="form-text">ค่าเริ่มต้น 50 บาท — ใช้ร่วมกับเงื่อนไขตัดใบยาสั้นด้านล่าง</div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">มูลค่ายาคงเหลือขั้นต่ำที่ดึงข้อมูล (บาท)</label>
                                        <input type="number" name="min_remaining_value" class="form-control form-control-sm" min="0" step="0.01" value="<?php echo htmlspecialchars(number_format((float)($config['min_remaining_value'] ?? 0), 2, '.', '')); ?>">
                                        <div class="form-text">ไม่ดึงทั้งใบสั่งยาที่มูลค่ายาเดิมคงเหลือรวม (ผลรวมจำนวนที่เหลือ × ราคาต่อหน่วยของทุกรายการในใบ) ต่ำกว่านี้ · ตั้ง 0 = ไม่ตัดตามมูลค่า</div>
                                    </div>
                                    <div class="fw-bold small mb-2">ตัดรายการที่สั่ง OPD จำนวนวันน้อย</div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" name="hide_short_hme" id="mhm_hide_short" <?php echo !empty($config['hide_short_hme']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small" for="mhm_hide_short">ซ่อนรายการที่จำนวนวัน OPD ครั้งนี้ <strong>น้อยกว่าเกณฑ์</strong></label>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">เกณฑ์จำนวนวัน OPD (วัน)</label>
                                        <input type="number" name="hide_short_hme_days" class="form-control form-control-sm" min="0" max="365" value="<?php echo (int)$config['hide_short_hme_days']; ?>">
                                        <div class="form-text">ค่าเริ่มต้น 14 วัน — คำนวณจากจำนวนจ่าย ÷ ปริมาณต่อวัน ถ้าคำนวณไม่ได้ใช้จำนวนวันถึงวันนัด · ยามูลค่าสูงกว่าที่ตั้งด้านบนจะไม่ตัด</div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">icode ที่ไม่ต้องตรวจ (หนึ่งบรรทัดต่อรายการ)</label>
                                        <textarea name="exclude_icodes" class="form-control form-control-sm" rows="4" placeholder="เช่น ยาฉีด / ยา PRN"><?php echo htmlspecialchars($exclude_text); ?></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-sm text-white fw-bold" style="background:#c2410c;">
                                        <i class="fas fa-save me-1"></i> บันทึกการตั้งค่า
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="alert alert-light border small">
                                <div class="fw-bold mb-2"><i class="fas fa-info-circle me-1 text-warning"></i> เงื่อนไขการตรวจ</div>
                                <ol class="mb-0 ps-3">
                                    <li>คนไข้มา <b>OPD</b> และมีใบยาในวันที่เลือก</li>
                                    <li>ถ้าเปิดตัวเลือกวันนัด จะดึงเฉพาะคนที่<b>มาไม่ตรงวันนัด</b> คือวันมาไม่ตรงกับวันนัดที่เคยสั่งไว้ก่อนหน้า</li>
                                    <li>ดึงยา OPD เดิมของ HN เดียวกัน ที่จ่าย <b>ก่อนวันสั่งครั้งนี้</b> (คนละ VN) ภายในช่วงย้อนหลังที่ตั้ง</li>
                                    <li>จับคู่ยาซ้ำด้วย icode หรือชื่อ TMT</li>
                                    <li>ถ้ายาเดิมยังเหลือ ณ วันสั่งใหม่ จะแจ้งเตือนเพื่อไม่ให้จ่ายซ้ำ</li>
                                    <li>ไม่ดึงรายการที่ยาเหลือ <b>ติดลบ</b> หรือ <b>คำนวณประวัติ/วิธีใช้ไม่ได้</b></li>
                                    <li>ไม่ดึงคนไข้ที่ยา OPD ครั้งนี้ <b>ทั้งหมดไม่พบยาเดิมที่เหลือ</b></li>
                                    <li>ตัดยาเดิมที่เหลือ ณ วันสั่งใหม่ <b>น้อยกว่าเกณฑ์</b> (ค่าเริ่มต้น 20 วัน) ไม่นับเป็นเคยได้ OPD — ถ้ารายการนั้นมูลค่าต่อชิ้นมากกว่าที่ตั้ง (ค่าเริ่มต้น 50 บาท) จะยังแสดง</li>
                                    <li>ไม่ดึงทั้งใบสั่งยาที่ <b>มูลค่าคงเหลือรวม</b> ต่ำกว่าเกณฑ์ (ผลรวมจำนวนที่เหลือ × ราคาต่อหน่วยของทุกรายการในใบ) — ตั้ง 0 = ไม่ตัดตามมูลค่า</li>
                                    <li>ตัดรายการที่สั่ง OPD ครั้งนี้ <b>น้อยกว่าเกณฑ์วัน</b> (ค่าเริ่มต้น 14 วัน) ยกเว้นยามูลค่าต่อชิ้นมากกว่าที่ตั้ง</li>
                                    <li>ระดับเตือนค่าเริ่มต้นเป็น <b>Soft Alert</b> ทั้งกรณีมียาเหลือและคำนวณวันที่เหลือไม่ได้ — เปลี่ยนเป็น Hard ได้ที่การ์ดด้านซ้าย</li>
                                </ol>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="modal fade" id="mopdConsultModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold"><i class="fas fa-notes-medical me-2 text-danger"></i>บันทึก Intervention — ยาเหลือ OPD</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="small text-muted mb-2" id="mopdConsultCaseInfo"></div>
                            <div class="border rounded p-2 mb-3 bg-light" id="mopdDrugSelectBox">
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                                    <label class="form-label small fw-bold mb-0">
                                        <i class="fas fa-pills me-1 text-success"></i>
                                        เลือกยาที่จะปรึกษา (HN เดียวกัน)
                                    </label>
                                    <div class="btn-group btn-group-sm">
                                        <button type="button" class="btn btn-outline-secondary" onclick="mopdToggleDrugChecks(true)">เลือกทั้งหมด</button>
                                        <button type="button" class="btn btn-outline-secondary" onclick="mopdToggleDrugChecks(false)">ยกเลิกทั้งหมด</button>
                                    </div>
                                </div>
                                <div id="mopdDrugCheckList" class="small"></div>
                                <div class="form-text mb-0">ค่าเริ่มต้นเลือกทั้งหมด — ติ๊กเฉพาะยาที่ต้องการปรึกษาในใบนี้</div>
                            </div>
                            <div class="row g-2">
                                <div class="col-md-8">
                                    <label class="form-label small fw-bold">เภสัชกรที่ Consult</label>
                                    <select id="mopdPharmacist" class="form-select form-select-sm">
                                        <?php if (empty($pharmacist_options)): ?>
                                        <option value="">— ไม่พบผู้ใช้ตำแหน่งเภสัชกร —</option>
                                        <?php else: ?>
                                        <?php foreach ($pharmacist_options as $ph):
                                            $ph_name = trim((string)($ph['full_name'] ?: $ph['username']));
                                            $ph_pos = trim((string)($ph['entryposition'] ?? ''));
                                            $ph_label = $ph_pos !== '' ? ($ph_name . ' (' . $ph_pos . ')') : $ph_name;
                                        ?>
                                        <option value="<?php echo (int)$ph['id']; ?>"
                                            <?php echo ((int)$ph['id'] === $current_user_id) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($ph_label); ?>
                                        </option>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label small fw-bold">รอตอบกลับ</label>
                                    <select id="mopdReplyWait" class="form-select form-select-sm">
                                        <option value="0"<?php echo ((int)$mopdc_reply_wait_days === 0) ? ' selected' : ''; ?>>ทันที</option>
                                        <?php for ($d = 1; $d <= 7; $d++): ?>
                                        <option value="<?php echo $d; ?>"<?php echo ((int)$mopdc_reply_wait_days === $d) ? ' selected' : ''; ?>><?php echo $d; ?> วัน</option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">การแทรกแซง</label>
                                    <select id="mopdIvType" class="form-select form-select-sm">
                                        <option value="recommend">แนะนำ / Consult</option>
                                        <option value="adjust">ปรับยา</option>
                                        <option value="reject">ไม่จ่าย / Hold</option>
                                        <option value="followup">ติดตาม</option>
                                        <option value="document">บันทึกเท่านั้น</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">ใช่ความคลาดเคลื่อนไหม</label>
                                    <select id="mopdIvDeviation" class="form-select form-select-sm" onchange="AlertMute.sync('mopdIvDeviation')">
                                        <option value="">— ไม่ระบุ —</option>
                                        <option value="ความคลาดเคลื่อนจริง">ความคลาดเคลื่อนจริง</option>
                                        <option value="ไม่ใช่ความคลาดเคลื่อน">ไม่ใช่ความคลาดเคลื่อน</option>
                                    </select>
                                    <?php require_once __DIR__ . '/monitor_alert_mute_ui.php'; monitor_alert_mute_box('mopdIvDeviation'); ?>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold">หมายเหตุ</label>
                                    <textarea id="mopdConsultNote" class="form-control form-control-sm" rows="2" placeholder="รายละเอียดที่ต้องการบันทึกใน Intervention และใส่ในใบปรึกษา"></textarea>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold">รายละเอียดหลัง Consult <span class="fw-normal text-muted">(บันทึกภายหลังได้ใน Intervention Report)</span></label>
                                    <div class="d-flex flex-wrap gap-1 mb-1">
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mopdChip('แพทย์ Off')">แพทย์ Off</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mopdChip('แพทย์ Hold')">แพทย์ Hold</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mopdChip('แพทย์ลดขนาดยา')">แพทย์ลดขนาดยา</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mopdChip('แพทย์ให้ยาต่อ')">แพทย์ให้ยาต่อ</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mopdChip('')">อื่นๆ</button>
                                    </div>
                                    <textarea id="mopdIvConsult" class="form-control form-control-sm" rows="2" placeholder="เลือกตัวช่วยด้านบน หรือพิมพ์รายละเอียดเอง"></textarea>
                                </div>
                            </div>
                            <div id="mopdConsultMsg" class="alert mt-3 mb-0 py-2 small d-none"></div>
                        </div>
                        <div class="modal-footer flex-wrap">
                            <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิดหน้าต่าง</button>
                            <button type="button" class="btn btn-outline-info btn-sm fw-bold" onclick="mopdOpenHistory()">
                                <i class="fas fa-history me-1"></i> เปิดดูประวัติ
                            </button>
                            <button type="button" class="btn btn-outline-warning btn-sm fw-bold" onclick="mopdResetWaiting()">
                                ตั้งเป็นรอ Consult
                            </button>
                            <button type="button" class="btn btn-outline-success btn-sm fw-bold" onclick="mopdCloseConsult()">
                                ปิดการ Consult
                            </button>
                            <button type="button" class="btn btn-success btn-sm fw-bold" onclick="mopdSaveIntervention(true)">
                                <i class="fas fa-print me-1"></i> บันทึกและพิมพ์ใบปรึกษาแพทย์
                            </button>
                            <button type="button" class="btn btn-sm fw-bold text-white" style="background:#0d9488;" onclick="mopdSaveIntervention(false)">บันทึก Intervention</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mopdHistoryModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-scrollable">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold"><i class="fas fa-history me-2 text-info"></i>ประวัติ Consult</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="small text-muted mb-2" id="mopdHistoryInfo"></div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>เวลา</th>
                                            <th>ยา</th>
                                            <th>การดำเนินการ</th>
                                            <th>สถานะ</th>
                                            <th>กำหนดตอบกลับ</th>
                                            <th>ผู้ทำ</th>
                                            <th>หมายเหตุ</th>
                                        </tr>
                                    </thead>
                                    <tbody id="mopdHistoryBody">
                                        <tr><td colspan="7" class="text-center text-muted py-3">ยังไม่มีประวัติ</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">ปิด</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/monitor_hn_filter.js"></script>
<script src="js/flatpickr.min.js"></script>
<script>
const MOPD_CURRENT_USER_ID = <?php echo (int)$current_user_id; ?>;
const MOPD_REPLY_WAIT = <?php echo (int)$mopdc_reply_wait_days; ?>;
let fpStart, fpEnd;

function mopdNormHn(s) {
    const d = String(s || '').replace(/\D+/g, '').replace(/^0+/, '');
    return d === '' ? '0' : d;
}
function mopdFocusHn() {
    const typed = String($('#mopdHnSearch').val() || $('#filter_hn').val() || '').trim();
    if (typed && /^[0-9]+$/.test(typed)) return typed;
    if (typeof monitorFilterHn === 'function') {
        const fromFilter = monitorFilterHn();
        if (fromFilter) return fromFilter;
    }
    return String(new URLSearchParams(location.search).get('hn') || '').trim();
}

function mhmEsc(s) {
    if (s == null) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

$(function() {
    if (typeof flatpickr !== 'undefined') {
        fpStart = flatpickr('#filter_start', { dateFormat: 'Y-m-d' });
        fpEnd = flatpickr('#filter_end', { dateFormat: 'Y-m-d' });
    }
    const hnQ = mopdFocusHn();
    if (hnQ) $('#mopdHnSearch').val(hnQ);
    monitorInitHnFilter({
        inputId: 'mopdHnSearch',
        clearHref: 'monitor_opd_dup.php',
        fetchFn: fetchMHMData,
        autofetch: fetchMHMData
    });
    $(document).on('change', 'input[name="alert_level_remaining"], input[name="alert_level_unknown"]', function() {
        const wrap = $(this).closest('.row');
        wrap.find('.mhm-alert-card').removeClass('active-soft active-hard');
        $(this).closest('.mhm-alert-card').addClass(this.value === 'hard' ? 'active-hard' : 'active-soft');
    });
});

function setMHMDateRange(days) {
    const end = new Date();
    const start = new Date();
    if (days <= 1) {
        start.setHours(0,0,0,0);
    } else {
        start.setDate(end.getDate() - (days - 1));
    }
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    if (fpStart) fpStart.setDate(fmt(start), true); else $('#filter_start').val(fmt(start));
    if (fpEnd) fpEnd.setDate(fmt(end), true); else $('#filter_end').val(fmt(end));
    $('.mhm-range-btn').removeClass('active');
    $('.mhm-range-btn[data-days="' + days + '"]').addClass('active');
}

function mhmDaysBetween(from, to) {
    if (!from || !to) return null;
    const a = Date.parse(String(from).slice(0, 10) + 'T00:00:00');
    const b = Date.parse(String(to).slice(0, 10) + 'T00:00:00');
    if (isNaN(a) || isNaN(b)) return null;
    return Math.round((b - a) / 86400000);
}
function mhmDaysText(days) {
    if (days === null || days === undefined || days === '') return '';
    const n = parseInt(days, 10);
    if (isNaN(n)) return '';
    if (n < 0) return 'นัดก่อนได้ยา ' + Math.abs(n) + ' วัน';
    if (n === 0) return 'วันเดียวกับวันนัด';
    return n + ' วัน';
}
function mhmApptDaysFromOrder(orderDate, a) {
    const date = a && (a.date || '');
    if (date && orderDate) return mhmDaysBetween(orderDate, date);
    if (a && a.days !== undefined && a.days !== null && a.days !== '') {
        const n = parseInt(a.days, 10);
        return isNaN(n) ? null : n;
    }
    return null;
}
function mhmApptsForOrderDate(list, orderDate) {
    const od = String(orderDate || '').slice(0, 10);
    const rows = list || [];
    if (!od) return rows;
    const hasVst = rows.some(function(a) { return a && a.vstdate; });
    if (!hasVst) return rows;
    return rows.filter(function(a) { return String(a.vstdate || '').slice(0, 10) === od; });
}
function mhmKeepFutureAppt(orderDate, a) {
    const days = mhmApptDaysFromOrder(orderDate, a);
    return days === null || days > 0;
}
function mhmLatestHmeDate(p) {
    let max = '';
    (p.admissions || []).forEach(function(adm) {
        (adm.drugs || []).forEach(function(d) {
            const hd = String(d.hme_date || '').slice(0, 10);
            if (hd && hd > max) max = hd;
        });
    });
    return max;
}

function mhmPatientAppointments(p) {
    if (p && p.appointments && p.appointments.length) return p.appointments;
    if (p && p.next_appointment) {
        return [{
            date: p.next_appointment,
            date_fmt: p.next_appointment_fmt || '',
            time: p.next_appointment_time || '',
            clinic: p.next_appointment_clinic || '',
            doctor: p.next_appointment_doctor || ''
        }];
    }
    return [];
}

function mhmFmtRemainQty(q) {
    if (q === null || q === '' || typeof q === 'undefined') return '';
    const n = parseFloat(q);
    if (isNaN(n) || n < 0) return '';
    const txt = Math.abs(n - Math.round(n)) < 0.05
        ? String(Math.round(n))
        : String(Math.round(n * 100) / 100);
    return txt + ' เม็ด';
}

function renderMHMDrug(d, appointments) {
    const prior = !!d.prior_opd;
    const mark = prior
        ? '<span class="mhm-prior-mark"><i class="fas fa-history"></i> เคยได้ OPD</span>'
        : '<span class="text-muted small">—</span>';
    const hmeWhen = d.hme_time
        ? mhmEsc(d.hme_date_fmt) + ' <span class="text-dark">' + mhmEsc(d.hme_time) + '</span>'
        : mhmEsc(d.hme_date_fmt || '-');
    const qtyTxt = d.remaining_qty_text || mhmFmtRemainQty(d.remaining_qty);
    const remainDays = (d.remaining_days !== null && d.remaining_days !== '' && typeof d.remaining_days !== 'undefined')
        ? (d.remaining_days + ' วัน')
        : '';
    const remainVal = (d.remaining_value !== null && d.remaining_value !== '' && typeof d.remaining_value !== 'undefined')
        ? (Number(d.remaining_value).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' บาท')
        : '';
    let remainMain = '';
    if (remainDays) {
        remainMain = '<div class="mhm-remain">' + mhmEsc(remainDays) + '</div>'
            + (qtyTxt ? '<div class="mhm-remain-qty">' + mhmEsc(qtyTxt) + '</div>' : '')
            + (remainVal ? '<div class="small text-muted">' + mhmEsc(remainVal) + '</div>' : '');
    } else {
        remainMain = '<div class="mhm-remain">' + mhmEsc(d.remaining_text || '-') + '</div>'
            + (qtyTxt ? '<div class="mhm-remain-qty">' + mhmEsc(qtyTxt) + '</div>' : '');
    }
    const remain = prior
        ? (remainMain
            + (d.alert_level === 'hard' ? '<span class="badge bg-danger">Hard Alert</span>'
                : (d.alert_level === 'soft' ? '<span class="badge bg-warning text-dark">Soft Alert</span>' : '')))
        : (d.remaining_ignored
            ? remainMain + '<div class="small text-muted">น้อยกว่าเกณฑ์ — ไม่นับ</div>'
            : '<span class="text-muted">—</span>');
    const opd = prior
        ? ('<div><b>' + mhmEsc(d.opd_drug_name || d.hme_drug_name) + '</b></div>'
            + '<div class="small text-muted">จ่าย ' + mhmEsc(d.opd_date_fmt || '-')
            + (d.opd_qty ? ' · qty ' + mhmEsc(d.opd_qty) : '')
            + (d.opd_vn ? ' · VN ' + mhmEsc(d.opd_vn) : '') + '</div>'
            + '<div class="small">' + mhmEsc(d.opd_method || '-') + '</div>'
            + (d.match_label ? '<span class="badge bg-light text-dark border">' + mhmEsc(d.match_label) + '</span>' : ''))
        : (d.remaining_ignored
            ? '<span class="text-muted small">ยาเดิมเหลือน้อยกว่าเกณฑ์ — ไม่นับ</span>'
            : '<span class="text-muted small">ไม่พบยาเดิมที่เหลือ</span>');
    const list = mhmApptsForOrderDate(
        (appointments && appointments.length) ? appointments : (d.appointment_days || []),
        d.hme_date
    );
    let apptDays = '';
    list.forEach(function(a) {
        const date = a.date || '';
        const days = date ? mhmDaysBetween(d.hme_date, date) : a.days;
        if (days !== null && days !== undefined && days !== '' && parseInt(days, 10) <= 0) return;
        const txt = mhmDaysText(days);
        if (!txt) return;
        apptDays += '<div class="mb-1">'
            + '<div class="mhm-appt-days">' + mhmEsc(txt) + '</div>'
            + '<div class="small text-muted">' + mhmEsc(a.date_fmt || date) + '</div>'
            + '</div>';
    });
    if (!apptDays) apptDays = '<span class="text-muted">—</span>';
    const ck = String(d.case_key || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    const consultCell = prior
        ? ('<div class="mopd-consult-cell text-center">'
            + '<div class="mb-1">' + mopdConsultBadge(d.consult) + '</div>'
            + '<button type="button" class="btn btn-sm btn-success fw-bold me-1" onclick="mopdOpenConsult(\'' + ck + '\')">'
            + '<i class="fas fa-notes-medical me-1"></i>บันทึก Intervention</button>'
            + '<button type="button" class="btn btn-sm btn-outline-info" title="ประวัติการปรึกษาแพทย์" onclick="mopdOpenHistoryFromKey(\'' + ck + '\')">'
            + '<i class="fas fa-history"></i></button>'
            + '</div>')
        : '<span class="text-muted">—</span>';
    return '<tr class="' + (prior ? 'prior' : '') + '">'
        + '<td class="text-center">' + mark + '</td>'
        + '<td><div class="fw-bold">' + mhmEsc(d.hme_drug_name) + '</div>'
        + '<div class="small text-muted">icode: ' + mhmEsc(d.hme_icode)
        + (d.hme_qty ? ' · qty ' + mhmEsc(d.hme_qty) : '') + '</div>'
        + '<div class="small">' + mhmEsc(d.hme_method || '-') + '</div></td>'
        + '<td class="small text-nowrap">' + hmeWhen + '</td>'
        + '<td class="small">' + apptDays + '</td>'
        + '<td class="small">' + opd + '</td>'
        + '<td class="small">' + remain + '</td>'
        + '<td class="text-center text-nowrap">' + consultCell + '</td>'
        + '</tr>';
}

function renderMHMApptBadges(p, latestHme) {
    const list = mhmApptsForOrderDate(mhmPatientAppointments(p), latestHme).filter(function(a) { return mhmKeepFutureAppt(latestHme, a); });
    if (!list.length) {
        return '<span class="badge bg-light text-muted border">ไม่มีวันนัดข้างหน้า</span>';
    }
    let html = '<div class="mhm-appt-list">';
    list.forEach(function(a) {
        let t = mhmEsc(a.date_fmt || a.date || '');
        if (a.time) t += ' ' + mhmEsc(a.time);
        if (a.clinic) t += ' · ' + mhmEsc(a.clinic);
        if (a.doctor) t += ' · ' + mhmEsc(a.doctor);
        const days = a.date && latestHme ? mhmDaysBetween(latestHme, a.date) : a.days;
        let extra = '';
        if (days !== null && days !== undefined && days !== '' && parseInt(days, 10) > 0) {
            extra = ' · อีก ' + parseInt(days, 10) + ' วัน';
        }
        html += '<span class="badge bg-info text-dark"><i class="fas fa-calendar-alt me-1"></i>นัด ' + t + extra + '</span>';
    });
    html += '</div>';
    return html;
}

function mhmSkipUnusable(d) {
    if (!d || !d.prior_opd) return false;
    if (d.remaining_days === null || d.remaining_days === '' || typeof d.remaining_days === 'undefined') return true;
    const n = parseInt(d.remaining_days, 10);
    return !isNaN(n) && n < 0;
}

function mopdPttypeText(src) {
    const name = String((src && src.pttype_name) || '').trim();
    if (name) return name;
    return String((src && src.pttype) || '').trim();
}

function renderMHMPatient(p) {
    const ads = p.admissions || [];
    const appointments = mhmPatientAppointments(p);
    let body = '';
    let shown = 0;
    ads.forEach(function(adm) {
        const drugs = (adm.drugs || []).filter(function(d) { return !mhmSkipUnusable(d); });
        if (!drugs.length) return;
        shown += drugs.length;
        if (ads.length > 1) {
            const rxVal = mopdRxRemainValue(adm);
            const admRight = mopdPttypeText(adm);
            body += '<div class="px-3 pt-2 small text-muted"><b>VN ' + mhmEsc(adm.an) + '</b>'
                + ' · Visit ' + mhmEsc(adm.admit_date_fmt)
                + ' · ' + mhmEsc(adm.ward_display || '-')
                + (admRight ? (' · สิทธิ ' + mhmEsc(admRight)) : '')
                + (rxVal > 0 ? (' · <span class="fw-bold" style="color:#0369a1;">' + mopdFmtBaht(rxVal) + ' บาท</span>') : '')
                + '</div>';
        }
        body += '<div class="table-responsive"><table class="table table-sm align-middle mhm-drug-table mb-0">'
            + '<thead><tr>'
            + '<th width="11%">สัญลักษณ์</th>'
            + '<th>ยาที่สั่ง OPD</th><th width="13%">สั่งเมื่อ</th>'
            + '<th width="14%">ถึงวันนัด</th>'
            + '<th>ยา OPD เดิม</th><th width="12%">เหลือ ณ วันสั่งใหม่</th>'
            + '<th width="14%">Consult</th>'
            + '</tr></thead><tbody>';
        drugs.forEach(function(d) { body += renderMHMDrug(d, appointments); });
        body += '</tbody></table></div>';
    });
    if (!shown) return '';
    const hasPrior = (p.admissions || []).some(function(adm) {
        return (adm.drugs || []).some(function(d) { return d.prior_opd && !mhmSkipUnusable(d); });
    });
    if (!hasPrior) return '';
    const first = ads[0] || {};
    const cls = p.prior_count > 0 ? 'mhm-patient has-prior' : 'mhm-patient';
    const latestHme = p.hme_latest_date || mhmLatestHmeDate(p);
    const apptHtml = renderMHMApptBadges(p, latestHme);
    const caseVal = mopdPatientRemainValue(p);
    const pttype = mopdPttypeText(first) || mopdPttypeText(p);
    return '<div class="' + cls + '" data-hn="' + mhmEsc(p.hn) + '">'
        + '<div class="mhm-pt-head">'
        + '<div><span class="mhm-pt-hn fw-bold">HN ' + mhmEsc(p.hn) + '</span>'
        + ' <span class="ms-1">' + mhmEsc(p.ptname) + '</span>'
        + (pttype ? (' <span class="mopd-pttype ms-2"><i class="fas fa-id-card"></i> ' + mhmEsc(pttype) + '</span>') : '')
        + '</div>'
        + '<div class="small text-muted">VN ' + mhmEsc(first.an || '-')
        + ' · Visit ' + mhmEsc(first.admit_date_fmt || '-')
        + ' · ' + mhmEsc(first.ward_display || '-') + '</div>'
        + apptHtml
        + '<div class="ms-auto d-flex flex-wrap gap-1">'
        + (caseVal > 0 ? '<span class="badge mopd-pt-val">ประหยัดได้ ' + mopdFmtBaht(caseVal) + ' บาท</span>' : '')
        + '<span class="badge bg-secondary">ยา ' + (p.drug_count || 0) + '</span>'
        + (p.prior_count ? '<span class="badge" style="background:#ea580c;">เคยได้ OPD ' + p.prior_count + '</span>' : '')
        + (p.hard_count ? '<span class="badge bg-danger">Hard Alert ' + p.hard_count + '</span>' : '')
        + (p.soft_count ? '<span class="badge bg-warning text-dark">Soft Alert ' + p.soft_count + '</span>' : '')
        + '</div></div>'
        + body
        + '</div>';
}

function mhmMergePatients(into, add) {
    const map = {};
    (into || []).forEach(function(p) { map[String(p.hn || '')] = p; });
    (add || []).forEach(function(p) {
        const hn = String(p.hn || '');
        if (!map[hn]) {
            const copy = JSON.parse(JSON.stringify(p));
            (copy.admissions || []).forEach(function(a) {
                a.drugs = (a.drugs || []).filter(function(d) { return !mhmSkipUnusable(d); });
            });
            copy.admissions = (copy.admissions || []).filter(function(a) { return (a.drugs || []).length; });
            if (!copy.admissions.length) return;
            let priorN = 0;
            copy.admissions.forEach(function(a) {
                (a.drugs || []).forEach(function(d) { if (d.prior_opd) priorN++; });
            });
            if (!priorN) return;
            map[hn] = copy;
            return;
        }
        const cur = map[hn];
        if (!cur.ptname && p.ptname) cur.ptname = p.ptname;
        if (!cur.pttype_name && p.pttype_name) {
            cur.pttype_name = p.pttype_name;
            cur.pttype = p.pttype || cur.pttype;
        }
        const mergedAppt = {};
        mhmPatientAppointments(cur).concat(mhmPatientAppointments(p)).forEach(function(a) {
            const k = String(a.vstdate || '') + '|' + String(a.date || '') + '|' + String(a.time || '') + '|' + String(a.clinic || '');
            if (a.date && (!mergedAppt[k] || (!mergedAppt[k].doctor && a.doctor))) mergedAppt[k] = a;
        });
        cur.appointments = Object.keys(mergedAppt).map(function(k) { return mergedAppt[k]; })
            .sort(function(a, b) { return String(a.date).localeCompare(String(b.date)); });
        if (cur.appointments.length) {
            const first = cur.appointments[0];
            cur.next_appointment = first.date;
            cur.next_appointment_fmt = first.date_fmt || cur.next_appointment_fmt;
            cur.next_appointment_time = first.time || '';
            cur.next_appointment_clinic = first.clinic || '';
            cur.next_appointment_doctor = first.doctor || '';
        }
        if (p.hme_latest_date && (!cur.hme_latest_date || p.hme_latest_date > cur.hme_latest_date)) {
            cur.hme_latest_date = p.hme_latest_date;
        }
        const admMap = {};
        (cur.admissions || []).forEach(function(a) { admMap[String(a.an || '')] = a; });
        (p.admissions || []).forEach(function(a) {
            const an = String(a.an || '');
            if (!admMap[an]) {
                admMap[an] = JSON.parse(JSON.stringify(a));
                return;
            }
            if (!admMap[an].pttype_name && a.pttype_name) {
                admMap[an].pttype_name = a.pttype_name;
                admMap[an].pttype = a.pttype || admMap[an].pttype;
            }
            const drugs = {};
            (admMap[an].drugs || []).forEach(function(d) {
                drugs[String(d.hme_icode || d.hme_drug_name)] = d;
            });
            (a.drugs || []).forEach(function(d) {
                const k = String(d.hme_icode || d.hme_drug_name);
                const prev = drugs[k];
                if (!prev || (d.hme_date || '') > (prev.hme_date || '') || (d.prior_opd && !prev.prior_opd)) {
                    drugs[k] = d;
                }
            });
            admMap[an].drugs = Object.keys(drugs).map(function(k) { return drugs[k]; })
                .filter(function(d) { return !mhmSkipUnusable(d); });
        });
        cur.admissions = Object.keys(admMap).map(function(k) { return admMap[k]; })
            .filter(function(a) {
                a.drugs = (a.drugs || []).filter(function(d) { return !mhmSkipUnusable(d); });
                return a.drugs.length > 0;
            });
        let prior = 0, hardN = 0, softN = 0, drugN = 0;
        cur.admissions.forEach(function(a) {
            (a.drugs || []).forEach(function(d) {
                if (mhmSkipUnusable(d)) return;
                drugN++;
                if (d.prior_opd) prior++;
                if (d.alert_level === 'hard') hardN++;
                else if (d.alert_level === 'soft') softN++;
            });
        });
        cur.drug_count = drugN;
        cur.prior_count = prior;
        cur.hard_count = hardN;
        cur.soft_count = softN;
    });
    const list = Object.keys(map).map(function(k) { return map[k]; })
        .filter(function(p) { return (p.prior_count || 0) > 0; });
    list.sort(function(a, b) {
        if ((b.prior_count || 0) !== (a.prior_count || 0)) return (b.prior_count || 0) - (a.prior_count || 0);
        return String(a.hn).localeCompare(String(b.hn), undefined, { numeric: true });
    });
    return list;
}

let lastMHMPatients = [];
let currentMHMFilter = 'all';
window.mopdOnlyOffAppointment = <?php echo !empty($config['only_off_appointment']) ? 'true' : 'false'; ?>;

function setMHMFilter(filter, btn) {
    currentMHMFilter = filter || 'all';
    $('[data-mhm-filter]').removeClass('active');
    if (btn) $(btn).addClass('active');
    mhmPaint(lastMHMPatients, '');
}

function mopdOnHnSearch() {
    mhmPaint(lastMHMPatients, '');
}

function mopdSearchQ() {
    return String($('#mopdHnSearch').val() || '').trim();
}

function mopdMatchPatient(p, q) {
    q = String(q || '').trim().toLowerCase();
    if (!q) return true;
    const hn = String(p.hn || '');
    const hnFull = String(p.hn_full || '');
    const name = String(p.ptname || '').toLowerCase();
    const pttype = String(p.pttype_name || p.pttype || '').toLowerCase();
    if (name.indexOf(q) >= 0 || pttype.indexOf(q) >= 0) return true;
    const blob = (hn + ' ' + hnFull + ' ' + name + ' ' + pttype).toLowerCase();
    if (blob.indexOf(q) >= 0) return true;
    const ads = p.admissions || [];
    for (let i = 0; i < ads.length; i++) {
        const t = mopdPttypeText(ads[i]).toLowerCase();
        if (t && t.indexOf(q) >= 0) return true;
    }
    const qDigits = q.replace(/\D+/g, '');
    if (!qDigits) return false;
    const qN = mopdNormHn(qDigits);
    const hnN = mopdNormHn(hn);
    const fullN = mopdNormHn(hnFull);
    return hn.indexOf(qDigits) >= 0 || hnFull.indexOf(qDigits) >= 0
        || hnN.indexOf(qN) >= 0 || fullN.indexOf(qN) >= 0;
}

function mhmPaint(patients, metaHtml) {
    lastMHMPatients = patients || [];
    const all = lastMHMPatients;
    const priorPts = all.filter(function(p) { return (p.prior_count || 0) > 0; });
    const hardPts = all.filter(function(p) { return (p.hard_count || 0) > 0; });
    const softPts = all.filter(function(p) { return (p.soft_count || 0) > 0; });
    const hardN = all.reduce(function(s, p) { return s + (p.hard_count || 0); }, 0);
    const softN = all.reduce(function(s, p) { return s + (p.soft_count || 0); }, 0);
    $('#mhmCountAll').text(all.length);
    $('#mhmCountPrior').text(priorPts.length);
    $('#mhmCountHard').text(hardN);
    $('#mhmCountSoft').text(softN);
    if (metaHtml) {
        $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info').html(metaHtml);
    }
    let shownRaw = all;
    if (currentMHMFilter === 'prior') shownRaw = priorPts;
    else if (currentMHMFilter === 'hard') shownRaw = hardPts;
    else if (currentMHMFilter === 'soft') shownRaw = softPts;
    const q = mopdSearchQ();
    const shown = q
        ? shownRaw.filter(function(p) { return mopdMatchPatient(p, q); })
        : shownRaw;
    mopdPaintSummary(shown);
    if (!shown.length) {
        let empty = 'ไม่พบรายการในช่วงเวลานี้';
        if (q) empty = 'ไม่พบ HN / ชื่อตามที่ค้นหา';
        else if (mopdFocusHn()) empty = 'ไม่พบยาเหลือ OPD ของ HN ' + mopdFocusHn() + ' ในช่วงนี้';
        $('#mhmPatients').html('<div class="text-center py-4 text-muted">' + empty + '</div>');
        return;
    }
    $('#mhmPatients').html(shown.map(renderMHMPatient).join(''));
}

function mopdFmtBaht(n) {
    const x = Number(n);
    if (!isFinite(x)) return '0.00';
    return x.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function mopdRxRemainValue(adm) {
    const raw = adm && adm.rx_remaining_value;
    if (raw !== null && raw !== '' && typeof raw !== 'undefined') {
        const n = parseFloat(raw);
        if (!isNaN(n)) return n;
    }
    let sum = 0;
    let any = false;
    ((adm && adm.drugs) || []).forEach(function(d) {
        if (!d || !d.prior_opd || mhmSkipUnusable(d) || d.remaining_ignored) return;
        const v = parseFloat(d.remaining_value);
        if (isNaN(v)) return;
        sum += v;
        any = true;
    });
    return any ? sum : 0;
}

function mopdPatientRemainValue(p) {
    let sum = 0;
    ((p && p.admissions) || []).forEach(function(adm) {
        sum += mopdRxRemainValue(adm);
    });
    return sum;
}

function mopdPaintSummary(patients) {
    let cases = 0;
    let rxN = 0;
    let total = 0;
    let maxRx = 0;
    let maxHint = 'ใบสั่งยาที่มีมูลค่ายาเหลือสูงสุด';
    (patients || []).forEach(function(p) {
        let ptAny = false;
        (p.admissions || []).forEach(function(adm) {
            const drugs = (adm.drugs || []).filter(function(d) {
                return d.prior_opd && !mhmSkipUnusable(d) && !d.remaining_ignored;
            });
            if (!drugs.length) return;
            ptAny = true;
            rxN++;
            const v = mopdRxRemainValue(adm);
            total += v;
            if (v > maxRx) {
                maxRx = v;
                const vn = adm.an || adm.vn || '';
                maxHint = 'HN ' + (p.hn || '-') + (vn ? (' · VN ' + vn) : '')
                    + (p.ptname ? (' · ' + p.ptname) : '');
            }
        });
        if (ptAny) cases++;
    });
    const avg = cases > 0 ? (total / cases) : 0;
    $('#mopdSumCases').text(cases.toLocaleString('th-TH'));
    $('#mopdSumRx').text(rxN.toLocaleString('th-TH'));
    $('#mopdSumTotal').text(mopdFmtBaht(total));
    $('#mopdSumAvg').text(mopdFmtBaht(avg));
    $('#mopdSumMax').text(mopdFmtBaht(maxRx));
    $('#mopdSumMaxHint').text(maxRx > 0 ? maxHint : 'ใบสั่งยาที่มีมูลค่ายาเหลือสูงสุด');
    $('#mopdSummary').removeClass('d-none');
}

function mhmFriendlyError(text, status) {
    const raw = String(text || '');
    if (status === 504 || /504|Gateway Time-out/i.test(raw)) {
        return 'ประมวลผลนานเกินกำหนด (504) — ระบบจะแบ่งกลุ่มคนไข้แล้วรันคู่ขนาน กรุณากดอีกครั้ง หรือย่อช่วงวันที่';
    }
    if (status === 502 || /Bad Gateway/i.test(raw)) {
        return 'เซิร์ฟเวอร์ไม่ตอบ (502) — ลองใหม่ในอีกสักครู่';
    }
    const stripped = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    return (stripped || ('HTTP ' + status)).substring(0, 240);
}

function mhmDatesInRange(start, end) {
    const out = [];
    const a = new Date(start + 'T00:00:00');
    const b = new Date(end + 'T00:00:00');
    if (isNaN(a.getTime()) || isNaN(b.getTime()) || a > b) return out;
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    const cur = new Date(a);
    while (cur <= b) {
        out.push(fmt(cur));
        cur.setDate(cur.getDate() + 1);
    }
    return out;
}

let mhmAbort = null;
let mhmFetchGen = 0;
const MOPD_PARALLEL = 3;
const MOPD_SHARDS = 4;

function mopdBuildJobs(days) {
    const jobs = [];
    const shards = mopdFocusHn() ? 1 : MOPD_SHARDS;
    (days || []).forEach(function(day) {
        for (let s = 0; s < shards; s++) {
            jobs.push({ day: day, shard: s, shards: shards, label: day + (shards > 1 ? (' กลุ่ม ' + (s + 1)) : '') });
        }
    });
    return jobs;
}

async function mopdPostJob(job, signal) {
    const body = {
        start_date: job.day,
        end_date: job.day,
        shard: String(job.shard),
        shards: String(job.shards)
    };
    const hn = mopdFocusHn();
    if (hn) body.hn = hn;
    const r = await fetch('fetch_monitor_opd_dup_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        signal: signal,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams(body)
    });
    const text = await r.text();
    let data;
    try {
        data = JSON.parse(text);
    } catch (e) {
        throw new Error(mhmFriendlyError(text, r.status));
    }
    if (data.status !== 'success') {
        throw new Error(data.message || ('HTTP ' + r.status));
    }
    return data;
}

async function mopdPostJobRetry(job, signal) {
    try {
        return await mopdPostJob(job, signal);
    } catch (err) {
        if (err && err.name === 'AbortError') throw err;
        const msg = String(err && err.message ? err.message : '');
        if (/504|นานเกินกำหนด|502/.test(msg)) {
            return await mopdPostJob(job, signal);
        }
        throw err;
    }
}

async function fetchMHMData() {
    const start = $('#filter_start').val();
    const end = $('#filter_end').val();
    const days = mhmDatesInRange(start, end);
    if (!days.length) {
        alert('กรุณาเลือกช่วงวันที่ให้ถูกต้อง');
        return;
    }
    const jobs = mopdBuildJobs(days);
    const gen = ++mhmFetchGen;
    if (mhmAbort) {
        try { mhmAbort.abort(); } catch (e) {}
    }
    const ac = new AbortController();
    mhmAbort = ac;
    const workers = Math.min(MOPD_PARALLEL, jobs.length);

    $('#btnFetchMHM').prop('disabled', true);
    $('#mhmPatients').html('<div class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังประมวลผลคู่ขนาน (พร้อมกัน ' + workers + ' งาน)...</div>');
    mopdPaintSummary([]);
    $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info')
        .html('<i class="fas fa-spinner fa-spin me-1"></i> เริ่มตรวจ 0/' + jobs.length + ' งาน (พร้อมกัน ' + workers + ')');

    let patients = [];
    let hmeOrders = 0;
    let hiddenLow = 0;
    let hiddenShort = 0;
    const failed = [];
    const t0 = Date.now();
    let done = 0;
    let next = 0;
    let applyLock = Promise.resolve();

    function applyResult(data) {
        applyLock = applyLock.then(function() {
            patients = mhmMergePatients(patients, data.patients || []);
            const m = data.meta || {};
            hmeOrders += m.hme_orders || 0;
            hiddenLow += m.hidden_low_remaining || 0;
            hiddenShort += m.hidden_short_hme || 0;
            if (m.only_off_appointment) {
                window.mopdOnlyOffAppointment = true;
                $('#offApptBanner').removeClass('d-none');
            }
        });
        return applyLock;
    }

    function updateMeta(isFinal) {
        if (gen !== mhmFetchGen) return;
        const sec = ((Date.now() - t0) / 1000).toFixed(1);
        const priorPts = patients.filter(function(p) { return (p.prior_count || 0) > 0; }).length;
        const hardN = patients.reduce(function(s, p) { return s + (p.hard_count || 0); }, 0);
        const softN = patients.reduce(function(s, p) { return s + (p.soft_count || 0); }, 0);
        let html = '<i class="fas fa-info-circle me-1"></i> ตรวจแล้ว ' + done + '/' + jobs.length + ' งาน'
            + ' | พร้อมกัน ' + workers
            + ' | คนไข้: ' + patients.length
            + ' | เคยได้ OPD: ' + priorPts
            + ' | ยา OPD: ' + hmeOrders
            + ' | Hard Alert: ' + hardN
            + ' | Soft Alert: ' + softN
            + (hiddenLow ? (' | ซ่อนยาเหลือน้อย: ' + hiddenLow) : '')
            + (hiddenShort ? (' | ซ่อนใบยาสั้น: ' + hiddenShort) : '')
            + ' | ' + sec + ' วินาที';
        if (isFinal) html += ' | ช่วง ' + days.length + ' วัน';
        if (window.mopdOnlyOffAppointment) {
            html += '<div class="mt-1"><i class="fas fa-calendar-times me-1"></i> รายงานที่แสดง ดึงเฉพาะกรณีที่ผู้ป่วยมาไม่ตรงวันนัด</div>';
        }
        if (failed.length) {
            html += ' | <span class="text-danger">ไม่สำเร็จ ' + failed.length + ' งาน</span>';
            if (isFinal) html += '<div class="small fw-normal mt-1">' + failed.map(mhmEsc).join('<br>') + '</div>';
        }
        $('#reportMeta').toggleClass('alert-danger', failed.length > 0 && isFinal)
            .toggleClass('alert-info', !(failed.length > 0 && isFinal)).removeClass('d-none').html(html);
    }

    async function worker() {
        while (next < jobs.length) {
            if (gen !== mhmFetchGen) return;
            const job = jobs[next++];
            try {
                const data = await mopdPostJobRetry(job, ac.signal);
                await applyResult(data);
            } catch (err) {
                if (err && err.name === 'AbortError') throw err;
                failed.push((job.label || job.day) + ' — ' + (err && err.message ? err.message : 'เชื่อมต่อไม่สำเร็จ'));
            }
            done++;
            updateMeta(false);
            if (patients.length) mhmPaint(patients, '');
        }
    }

    try {
        await Promise.all(Array.from({ length: workers }, worker));
    } catch (err) {
        if (err && err.name === 'AbortError') return;
        if (gen !== mhmFetchGen) return;
        $('#btnFetchMHM').prop('disabled', false);
        $('#mhmPatients').html('<div class="text-center text-danger py-4">' + mhmEsc(err.message || 'เชื่อมต่อ API ไม่สำเร็จ') + '</div>');
        $('#reportMeta').removeClass('alert-info').addClass('alert-danger').removeClass('d-none')
            .html('<i class="fas fa-times-circle me-1"></i> ' + mhmEsc(err.message || 'ไม่สำเร็จ'));
        return;
    }

    if (gen !== mhmFetchGen) return;
    $('#btnFetchMHM').prop('disabled', false);
    updateMeta(true);
    if (!patients.length && failed.length) {
        $('#mhmPatients').html('<div class="text-center text-danger py-4">ประมวลผลไม่สำเร็จ — ลองย่อช่วงวันที่แล้วกดอีกครั้ง</div>');
        return;
    }
    mhmPaint(patients, '');
}

let mopdCurrentCase = null;
let mopdHnCases = [];
let mopdConsultModal = null;

function mopdAllPriorDrugs() {
    const out = [];
    (lastMHMPatients || []).forEach(function(p) {
        (p.admissions || []).forEach(function(adm) {
            (adm.drugs || []).forEach(function(d) {
                if (d.prior_opd && !mhmSkipUnusable(d)) out.push(d);
            });
        });
    });
    return out;
}
function mopdFindDrug(caseKey) {
    const want = String(caseKey || '');
    if (!want) return null;
    let found = null;
    mopdAllPriorDrugs().forEach(function(d) {
        if (String(d.case_key || '') === want) found = d;
    });
    return found;
}
function mopdConsultBadge(c) {
    c = c || {};
    const st = c.status || 'waiting';
    const label = c.status_label || st;
    let cls = 'bg-warning text-dark';
    let extra = '';
    if (st === 'in_progress') {
        cls = 'bg-primary';
        if (c.reply_due_at) {
            extra = '<div class="small text-muted">ตอบภายใน ' + mhmEsc(c.reply_due_at) + '</div>';
        } else if (Number(c.reply_wait_days) === 0) {
            extra = '<div class="small text-muted">ทันที</div>';
        }
    } else if (st === 'closed') {
        cls = 'bg-success';
    }
    return '<span class="badge ' + cls + '">' + mhmEsc(label) + '</span>' + extra;
}
function mopdToggleDrugChecks(on) {
    document.querySelectorAll('.mopd-drug-cb').forEach(function(cb) { cb.checked = !!on; });
}
function mopdRenderDrugChecks(cases) {
    const box = document.getElementById('mopdDrugCheckList');
    if (!box) return;
    if (!cases.length) {
        box.innerHTML = '<div class="text-muted">ไม่พบยา</div>';
        return;
    }
    let html = '';
    cases.forEach(function(it, i) {
        const id = 'mopdDrugCb' + i;
        const st = (it.consult && it.consult.status_label) ? it.consult.status_label : 'รอ Consult';
        const remain = it.remaining_text ? ('เหลือ ' + it.remaining_text) : '';
        html += '<div class="form-check border-bottom py-1">'
            + '<input class="form-check-input mopd-drug-cb" type="checkbox" id="' + id + '" data-idx="' + i + '" checked>'
            + '<label class="form-check-label" for="' + id + '">'
            + '<b>' + mhmEsc(it.hme_drug_name || it.drug_name) + '</b>'
            + ' <span class="text-muted">· ' + mhmEsc(it.hme_method || it.method_text || '-') + '</span>'
            + (remain ? ' <span class="badge bg-secondary">' + mhmEsc(remain) + '</span>' : '')
            + ' <span class="text-muted">(' + mhmEsc(st) + ')</span>'
            + '</label></div>';
    });
    box.innerHTML = html;
}
function mopdOpenConsult(caseKey) {
    const it = mopdFindDrug(caseKey);
    if (!it) return;
    mopdCurrentCase = it;
    mopdHnCases = mopdAllPriorDrugs().filter(function(x) {
        return mopdNormHn(x.hn) === mopdNormHn(it.hn);
    });
    if (!mopdHnCases.length) mopdHnCases = [it];
    const c = it.consult || {};
    document.getElementById('mopdConsultCaseInfo').innerHTML =
        '<b>HN ' + mhmEsc(it.hn) + '</b> · ' + mhmEsc(it.ptname)
        + ' <span class="badge bg-info text-dark">OPD</span>'
        + '<br>พบยาเหลือในช่วงนี้ <b>' + mopdHnCases.length + '</b> รายการ — เลือกยาที่จะใส่ในใบปรึกษาด้านล่าง';
    mopdRenderDrugChecks(mopdHnCases);
    mopdApplyOutcomeNote(c.consult_note || c.doctor_reply || '');
    document.getElementById('mopdReplyWait').value = String(MOPD_REPLY_WAIT);
    const sel = document.getElementById('mopdPharmacist');
    if (c.pharmacist_user_id && sel.querySelector('option[value="' + c.pharmacist_user_id + '"]')) {
        sel.value = String(c.pharmacist_user_id);
    } else {
        sel.value = String(MOPD_CURRENT_USER_ID);
    }
    if (window.AlertMute) {
        AlertMute.set('mopdIvDeviation', { hn: it.hn || '', vn: it.vn || '', an: it.an || '', patient_type: 'OPD' });
    }
    document.getElementById('mopdConsultMsg').className = 'alert mt-3 mb-0 py-2 small d-none';
    if (!mopdConsultModal) {
        mopdConsultModal = new bootstrap.Modal(document.getElementById('mopdConsultModal'));
    }
    mopdConsultModal.show();
}
function mopdSelectedCases() {
    const selected = [];
    document.querySelectorAll('.mopd-drug-cb:checked').forEach(function(cb) {
        const i = parseInt(cb.getAttribute('data-idx'), 10);
        if (!isNaN(i) && mopdHnCases[i]) selected.push(mopdHnCases[i]);
    });
    return selected;
}
function mopdCasesPayloadList() {
    return mopdSelectedCases().map(function(it) {
        return {
            hn: it.hn || '',
            an: it.vn || it.an || '',
            vn: it.vn || it.an || '',
            icode: it.hme_icode || it.icode || '',
            drug_name: it.hme_drug_name || it.drug_name || '',
            method_text: it.hme_method || it.method_text || '',
            qty: it.hme_qty || it.qty || '',
            ward_name: it.ward_name || '',
            ptname: it.ptname || '',
            order_date: it.hme_date || it.order_date || '',
            order_time: it.hme_time || it.order_time || '',
            opd_drug_name: it.opd_drug_name || '',
            opd_date: it.opd_date || '',
            remaining_text: it.remaining_text || '',
            remaining_days: it.remaining_days,
            warning_msg: it.warning_msg || it.alert_message || '',
            alert_level: it.alert_level || 'soft',
            case_key: it.case_key || '',
            consult_id: (it.consult && it.consult.id) ? it.consult.id : 0
        };
    });
}
function mopdChip(text) {
    const box = document.getElementById('mopdIvConsult');
    if (!box) return;
    const phrase = String(text || '').trim();
    if (!phrase) { box.focus(); return; }
    const cur = box.value.replace(/\s+$/, '');
    if (!cur) box.value = phrase + ' ';
    else if (cur.indexOf(phrase) === -1) box.value = cur + '\n' + phrase + ' ';
    box.focus();
}
function mopdComposeNote() {
    const note = String((document.getElementById('mopdConsultNote') || {}).value || '').trim();
    const after = String((document.getElementById('mopdIvConsult') || {}).value || '').trim();
    const lines = [];
    if (note) lines.push(note);
    if (after) lines.push('หลัง Consult: ' + after);
    return lines.join('\n');
}
function mopdApplyOutcomeNote(text) {
    const typeEl = document.getElementById('mopdIvType');
    const devEl = document.getElementById('mopdIvDeviation');
    const noteEl = document.getElementById('mopdConsultNote');
    const consultEl = document.getElementById('mopdIvConsult');
    if (typeEl) typeEl.value = 'recommend';
    if (devEl) devEl.value = '';
    if (window.AlertMute) AlertMute.sync('mopdIvDeviation');
    if (noteEl) noteEl.value = String(text || '');
    if (consultEl) consultEl.value = '';
}
function mopdCommonPayload() {
    const sel = document.getElementById('mopdPharmacist');
    const opt = sel.options[sel.selectedIndex];
    const note = mopdComposeNote();
    return {
        pharmacist_user_id: sel.value,
        pharmacist_name: opt ? opt.text.replace(/\s*\([^)]*\)\s*$/, '').trim() : '',
        consult_note: note,
        doctor_reply: note,
        reply_wait_days: document.getElementById('mopdReplyWait').value,
        intervention_type: (document.getElementById('mopdIvType') || {}).value || 'recommend',
        deviation_category: (document.getElementById('mopdIvDeviation') || {}).value || '',
        mute_visit: (window.AlertMute && AlertMute.checked('mopdIvDeviation')) ? 1 : 0,
        note_text: String((document.getElementById('mopdConsultNote') || {}).value || '').trim(),
        consult_result: String((document.getElementById('mopdIvConsult') || {}).value || '').trim(),
        cases_json: JSON.stringify(mopdCasesPayloadList())
    };
}
function mopdShowMsg(ok, text) {
    const el = document.getElementById('mopdConsultMsg');
    el.className = 'alert mt-3 mb-0 py-2 small ' + (ok ? 'alert-success' : 'alert-danger');
    el.textContent = text || '';
}
function mopdApplyConsults(consults) {
    const map = {};
    (consults || []).forEach(function(c) {
        if (c && c.case_key) map[c.case_key] = c;
    });
    mopdAllPriorDrugs().forEach(function(it) {
        if (it.case_key && map[it.case_key]) it.consult = map[it.case_key];
        (consults || []).forEach(function(c) {
            if (c && c.id && it.consult && Number(it.consult.id) === Number(c.id)) {
                it.consult = c;
            }
        });
    });
    mhmPaint(lastMHMPatients, '');
}
function mopdPatchSelectedConsult(extra) {
    extra = extra || {};
    mopdSelectedCases().forEach(function(it) {
        it.consult = Object.assign({}, it.consult || {}, extra);
    });
    mhmPaint(lastMHMPatients, '');
}
function mopdPostConsult(action) {
    const cases = mopdSelectedCases();
    if (!cases.length) {
        return Promise.resolve({ status: 'error', message: 'กรุณาเลือกอย่างน้อย 1 รายการยา' });
    }
    const data = Object.assign(mopdCommonPayload(), { action: action });
    const body = new URLSearchParams();
    Object.keys(data).forEach(function(k) { body.append(k, data[k] == null ? '' : data[k]); });
    return fetch('fetch_monitor_opd_dup_consult_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString()
    }).then(function(r) { return r.json(); });
}
function mopdSaveIntervention(andPrint) {
    let printWin = null;
    if (andPrint) printWin = window.open('about:blank', '_blank');
    mopdPostConsult('start').then(function(res) {
        if (res.status !== 'success') {
            if (printWin) printWin.close();
            mopdShowMsg(false, res.message || 'บันทึกไม่สำเร็จ');
            return;
        }
        mopdShowMsg(true, andPrint ? 'บันทึก Intervention และเปิดใบปรึกษาแล้ว' : 'บันทึก Intervention แล้ว');
        if (res.consults) mopdApplyConsults(res.consults);
        else if (res.consult) mopdApplyConsults([res.consult]);
        if (andPrint && res.print_url && printWin) {
            printWin.location = res.print_url + (res.print_url.indexOf('?') >= 0 ? '&' : '?') + 'autoprint=1';
        } else if (printWin) {
            printWin.close();
        }
    }).catch(function(e) {
        if (printWin) printWin.close();
        mopdShowMsg(false, String(e));
    });
}
function mopdStartAndPrint() {
    mopdSaveIntervention(true);
}
function mopdCloseConsult() {
    const n = mopdSelectedCases().length;
    if (!n) { mopdShowMsg(false, 'กรุณาเลือกอย่างน้อย 1 รายการยา'); return; }
    if (!confirm('ปิด Consult ' + n + ' รายการ?')) return;
    mopdPostConsult('close').then(function(res) {
        mopdShowMsg(res.status === 'success', res.message || '');
        if (res.status === 'success') {
            mopdPatchSelectedConsult({ status: 'closed', status_label: 'ปิด Consult', reply_due_at: '' });
            if (res.consult) mopdApplyConsults([res.consult]);
        }
    }).catch(function(e) { mopdShowMsg(false, String(e)); });
}
function mopdSaveResult() {
    mopdSaveIntervention(false);
}
function mopdResetWaiting() {
    const n = mopdSelectedCases().length;
    if (!n) { mopdShowMsg(false, 'กรุณาเลือกอย่างน้อย 1 รายการยา'); return; }
    mopdPostConsult('reset_waiting').then(function(res) {
        mopdShowMsg(res.status === 'success', res.message || '');
        if (res.status === 'success') {
            mopdPatchSelectedConsult({ status: 'waiting', status_label: 'รอ Consult', reply_due_at: '' });
            if (res.consult) mopdApplyConsults([res.consult]);
        }
    }).catch(function(e) { mopdShowMsg(false, String(e)); });
}
function mopdRenderHistory(rows) {
    const tbody = document.getElementById('mopdHistoryBody');
    if (!rows || !rows.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted py-3">ยังไม่มีประวัติ</td></tr>';
        return;
    }
    let html = '';
    rows.forEach(function(h) {
        let dayInfo = '-';
        if (h.reply_due_at) {
            dayInfo = 'ตอบภายใน<br><span class="text-muted">' + mhmEsc(h.reply_due_at) + '</span>';
        }
        const note = [];
        if (h.note_text) note.push(mhmEsc(h.note_text));
        if (h.doctor_reply && h.doctor_reply !== h.note_text) note.push(mhmEsc(h.doctor_reply));
        html += '<tr>'
            + '<td class="small text-nowrap">' + mhmEsc(h.created_at) + '</td>'
            + '<td class="small">' + mhmEsc(h.drug_name) + '</td>'
            + '<td class="small fw-bold">' + mhmEsc(h.action_label || h.action_key) + '</td>'
            + '<td class="small">' + mhmEsc(h.status_before_label || h.status_before || '-')
            + ' → ' + mhmEsc(h.status_after_label || h.status_after || '-') + '</td>'
            + '<td class="small">' + dayInfo + '</td>'
            + '<td class="small">' + mhmEsc(h.actor_name || h.pharmacist_name || '-') + '</td>'
            + '<td class="small">' + (note.length ? note.join('<br>') : '-') + '</td>'
            + '</tr>';
    });
    tbody.innerHTML = html;
}
function mopdOpenHistoryFromKey(caseKey) {
    const it = mopdFindDrug(caseKey);
    if (!it) return;
    mopdCurrentCase = it;
    mopdHnCases = mopdAllPriorDrugs().filter(function(x) {
        return mopdNormHn(x.hn) === mopdNormHn(it.hn);
    });
    mopdOpenHistory();
}
function mopdOpenHistory() {
    const it = mopdCurrentCase || (mopdHnCases && mopdHnCases[0]) || null;
    if (!it) {
        alert('ไม่พบข้อมูลผู้ป่วย');
        return;
    }
    document.getElementById('mopdHistoryInfo').innerHTML =
        '<b>HN ' + mhmEsc(it.hn) + '</b> · ' + mhmEsc(it.ptname)
        + ' <span class="badge bg-info text-dark">OPD</span>';
    const params = new URLSearchParams({
        action: 'history',
        hn: it.hn || '',
        limit: '150'
    });
    fetch('fetch_monitor_opd_dup_consult_api.php?' + params.toString(), { credentials: 'same-origin' })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            mopdRenderHistory(res.history || []);
            const modalEl = document.getElementById('mopdHistoryModal');
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        })
        .catch(function(e) { alert('โหลดประวัติไม่สำเร็จ: ' + e); });
}

</script>
</body>
</html>
