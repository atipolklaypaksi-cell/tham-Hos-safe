<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
session_write_close();
include('hosxp_tmt_drug_helper.php');
include('dose_calculator_helper.php');
mysqli_set_charset($con, 'utf8');
dc_ensure_tables($con);

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$raw = file_get_contents('php://input');
$body = [];
if ($raw !== false && $raw !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
        if ($action === '' && !empty($body['action'])) {
            $action = $body['action'];
        }
    }
}

if ($action === 'lookup') {
    $hn = trim((string)($_GET['hn'] ?? $body['hn'] ?? ''));
    $hos = hosxp_connect($con);
    if (!$hos) {
        echo json_encode(['status' => 'error', 'message' => 'เชื่อมต่อ HOSxP ไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    mysqli_set_charset($hos, 'utf8');
    $res = dc_lookup_patient($hos, $con, $hn);
    mysqli_close($hos);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'ไม่พบข้อมูล'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode(['status' => 'success', 'data' => $res], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_bw') {
    $payload = !empty($body) ? $body : $_POST;
    $payload['user_id'] = (int)($_SESSION['user_id'] ?? 0);
    $payload['user_name'] = (string)($_SESSION['full_name'] ?? '');
    $payload['source_module'] = trim((string)($payload['source_module'] ?? 'dose_calculator'));
    $res = dc_save_vitals_bw($con, $payload);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกน้ำหนักไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'message' => $res['message'] ?? 'บันทึกน้ำหนักแล้ว',
        'bw' => $res['bw'] ?? null,
        'source' => $res['source'] ?? 'tham',
        'source_label' => $res['source_label'] ?? 'THAM',
        'updated_at' => $res['updated_at'] ?? null,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save') {
    $payload = !empty($body) ? $body : $_POST;
    $payload['user_id'] = (int)($_SESSION['user_id'] ?? 0);
    $payload['user_name'] = (string)($_SESSION['full_name'] ?? '');
    $res = dc_save_calculation($con, $payload);
    if (!empty($res['need_age_confirm'])) {
        echo json_encode([
            'status' => 'need_age_confirm',
            'message' => $res['error'] ?? 'กรุณายืนยันการแก้ไขอายุ',
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (!empty($res['need_confirm'])) {
        echo json_encode([
            'status' => 'need_confirm',
            'message' => $res['error'] ?? '',
            'reasons' => $res['reasons'] ?? [],
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'message' => $res['message'],
        'log_id' => $res['log_id'] ?? null,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
