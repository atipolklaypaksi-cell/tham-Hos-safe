<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/allergy_eval_dashboard_helper.php';
require_once __DIR__ . '/allergy_followup_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('allergy_eval_dashboard') && !tham_menu_can('allergy_followup') && !tham_menu_can('allergy_history')) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

$action = $_GET['action'] ?? $_POST['action'] ?? 'summary';
$flags = JSON_UNESCAPED_UNICODE;
$can_edit = function_exists('af_can_assess') ? af_can_assess() : (($_SESSION['role'] ?? '') === 'admin');

$start = trim((string)($_GET['start_date'] ?? $_POST['start_date'] ?? ''));
$end = trim((string)($_GET['end_date'] ?? $_POST['end_date'] ?? ''));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start)) {
    $start = ((int)date('n') >= 10) ? date('Y-10-01') : date('Y-10-01', strtotime('-1 year'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
    $end = date('Y-m-d');
}
if ($start > $end) {
    $tmp = $start;
    $start = $end;
    $end = $tmp;
}

if ($action === 'fees') {
    echo json_encode(['status' => 'success', 'fees' => aed_load_fees($con), 'can_edit' => $can_edit], $flags);
    exit;
}

if ($action === 'save_fees' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_edit) {
        echo json_encode(['status' => 'error', 'message' => 'เฉพาะเภสัชกร/ผู้ดูแลตั้งค่ามูลค่าได้'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $fees_in = $raw['fees'] ?? $raw;
    $res = aed_save_fees($con, is_array($fees_in) ? $fees_in : []);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'fees' => $res['fees']], $flags);
    exit;
}

if ($action === 'summary') {
    $data = aed_build_dashboard($con, $start, $end);
    echo json_encode([
        'status' => 'success',
        'start_date' => $start,
        'end_date' => $end,
        'can_edit' => $can_edit,
        'fees' => $data['fees'],
        'hosxp_error' => $data['hosxp_error'],
        'summary' => $data['summary'],
        'pharmacists' => $data['pharmacists'],
        'incomplete' => $data['incomplete'],
        'cases' => $data['cases'],
    ], $flags);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], $flags);
