<?php
/**
 * Cron Smart Pharma — แจ้งเตือน Telegram + บันทึก Intervention Log (ไม่ซ้ำ)
 * CLI:  php cron_smart_pharma_telegram.php
 * HTTP: cron_smart_pharma_telegram.php?key=YOUR_SECRET
 *
 * มี flock กันรันซ้อน: ถ้ารอบก่อนยังไม่จบ รอบนี้จะข้ามทันที
 * คัดกรองเฉพาะช่วงสั้น (30 นาทีล่าสุด) เพื่อไม่แย่ง HOSxP กับหน้าเว็บ
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
set_time_limit(300);
ini_set('memory_limit', '512M');

require_once __DIR__ . '/server_health_helper.php';

$cron_lock = sh_cron_lock_acquire();
$cron_started_at = sh_now_iso();
$cron_t0 = microtime(true);
$cron_pid = getmypid();

if ($cron_lock === false) {
    include(__DIR__ . '/connect.php');
    mysqli_set_charset($con, 'utf8');
    sh_cron_status_save($con, [
        'status' => 'skipped',
        'started_at' => $cron_started_at,
        'ended_at' => sh_now_iso(),
        'duration_sec' => round(microtime(true) - $cron_t0, 1),
        'pid' => $cron_pid,
        'message' => 'ข้าม — มี Cron อีกตัวกำลังรันอยู่ (flock)',
    ]);
    $out = ['status' => 'skipped', 'message' => 'already running'];
    echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
    exit(0);
}

include(__DIR__ . '/connect.php');
include(__DIR__ . '/smart_pharma_helper.php');
include(__DIR__ . '/smart_pharma_telegram_helper.php');
include(__DIR__ . '/smart_pharma_webhook_helper.php');
include(__DIR__ . '/smart_pharma_alert_log_helper.php');
mysqli_set_charset($con, 'utf8');
sp_ensure_tables($con);

$cron_finished = false;
register_shutdown_function(function () use (&$con, &$cron_lock, &$cron_finished, $cron_started_at, $cron_t0, $cron_pid) {
    if (!$cron_finished) {
        $err = error_get_last();
        $msg = 'Cron จบผิดปกติ';
        if ($err && !empty($err['message'])) {
            $msg = $err['message'] . ' in ' . basename((string)($err['file'] ?? '')) . ':' . (int)($err['line'] ?? 0);
        }
        if (isset($con) && $con) {
            sh_cron_status_save($con, [
                'status' => 'error',
                'started_at' => $cron_started_at,
                'ended_at' => sh_now_iso(),
                'duration_sec' => round(microtime(true) - $cron_t0, 1),
                'pid' => $cron_pid,
                'message' => $msg,
            ]);
        }
    }
    sh_cron_lock_release($cron_lock);
});

if (php_sapi_name() !== 'cli') {
    $secret = '';
    $q = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='sp_telegram_cron_secret' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $secret = trim((string)($r['config_value'] ?? ''));
    }
    $key = trim((string)($_GET['key'] ?? ''));
    if ($secret === '' || $key !== $secret) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Forbidden';
        $cron_finished = true;
        exit;
    }
    header('Content-Type: application/json; charset=utf-8');
}

$force = !empty($_GET['force']) || (isset($argv) && in_array('--force', $argv, true));
$gate = sh_smart_pharma_gate($con, $force);
if (empty($gate['run'])) {
    $disabled = strpos((string)$gate['reason'], 'ปิดจากหน้า') !== false;
    if ($disabled) {
        sh_cron_status_save($con, [
            'status' => 'skipped',
            'started_at' => $cron_started_at,
            'ended_at' => sh_now_iso(),
            'duration_sec' => round(microtime(true) - $cron_t0, 1),
            'pid' => $cron_pid,
            'message' => $gate['reason'],
        ]);
    }
    echo json_encode(['status' => 'skipped', 'message' => $gate['reason']], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
    $cron_finished = true;
    exit(0);
}

sh_cron_status_save($con, [
    'status' => 'running',
    'started_at' => $cron_started_at,
    'ended_at' => '',
    'duration_sec' => 0,
    'pid' => $cron_pid,
    'message' => 'กำลังคัดกรอง OPD/IPD (ช่วงสั้น)',
]);

// timeout สั้นกว่าเดิม — ไม่ยึด connection HOSxP นานเกินจำเป็น
$hos = hosxp_connect($con, 120);
if ($hos) {
    hosxp_extend_read_timeout($hos, 180);
}
if (!$hos) {
    $out = ['status' => 'error', 'message' => 'HOSxP connect failed'];
    sh_cron_status_save($con, [
        'status' => 'error',
        'started_at' => $cron_started_at,
        'ended_at' => sh_now_iso(),
        'duration_sec' => round(microtime(true) - $cron_t0, 1),
        'pid' => $cron_pid,
        'message' => 'HOSxP connect failed',
    ]);
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    $cron_finished = true;
    exit(1);
}

$screen_date = sp_today_date();
// เดิมใช้ 3h แต่คัดทั้งวันจริง → หนักมาก; ใช้ 30 นาทีให้ทัน alert และจบก่อนรอบถัดไป
$time_window = sp_is_screen_date_today($screen_date) ? '30m' : 'full';
$summary = [
    'screen_date' => $screen_date,
    'time_window' => $time_window,
    'alert_log_totals' => ['new' => 0, 'updated' => 0, 'reopened' => 0, 'resolved' => 0, 'skipped' => 0],
    'results' => [],
];

foreach (['OPD', 'IPD'] as $patient_type) {
    // งบเวลารวม — เหลือน้อยให้ข้ามฝั่งที่เหลือ กันค้างข้ามรอบ
    $elapsed = microtime(true) - $cron_t0;
    if ($elapsed > 240) {
        $summary['results'][$patient_type] = [
            'patients' => 0,
            'error' => 'ข้าม — ใกล้หมดเวลารอบ cron (' . round($elapsed, 1) . 's)',
        ];
        continue;
    }
    if (!hosxp_ensure_connection($con, $hos, 120)) {
        $summary['results'][$patient_type] = [
            'patients' => 0,
            'error' => 'HOSxP connection lost',
        ];
        continue;
    }
    $batch = sp_run_screening_list($con, $hos, $patient_type, $screen_date, $time_window);
    $alert_log = $batch['alert_log'] ?? ['new' => 0, 'updated' => 0, 'reopened' => 0, 'resolved' => 0, 'skipped' => 0];
    foreach (['new', 'updated', 'reopened', 'resolved', 'skipped'] as $k) {
        $summary['alert_log_totals'][$k] += (int)($alert_log[$k] ?? 0);
    }
    require_once __DIR__ . '/smart_pharma_notify_helper.php';
    $notify_patients = sp_notify_screening_alert_patients($batch['all_screened'] ?? $batch['patients']);
    $tg = sp_telegram_notify_screening(
        $con,
        $patient_type,
        $screen_date,
        $notify_patients,
        $batch['module_labels']
    );
    $wh = sp_webhook_notify_screening(
        $con,
        $patient_type,
        $screen_date,
        $notify_patients,
        $batch['module_labels']
    );
    $summary['results'][$patient_type] = [
        'patients' => count($batch['patients']),
        'screened' => (int)($batch['screened'] ?? count($batch['patients'])),
        'total_day' => (int)($batch['total_day'] ?? 0),
        'alert_log' => $alert_log,
        'telegram' => $tg,
        'webhook' => $wh,
    ];
    if (!empty($batch['error'])) {
        $summary['results'][$patient_type]['error'] = $batch['error'];
    }
}

sp_alert_log_apply_monitor_settings($con);
$tg_repeat = sp_telegram_notify_pending_repeats($con);
$wh_repeat = sp_webhook_notify_pending_repeats($con);
$summary['pending_repeats'] = ['telegram' => $tg_repeat, 'webhook' => $wh_repeat];

if ($hos) {
    try {
        @mysqli_close($hos);
    } catch (Throwable $e) {
        // already closed
    }
}

$duration = round(microtime(true) - $cron_t0, 1);
$opd_n = (int)($summary['results']['OPD']['patients'] ?? 0);
$ipd_n = (int)($summary['results']['IPD']['patients'] ?? 0);
$err_parts = [];
foreach (['OPD', 'IPD'] as $pt) {
    if (!empty($summary['results'][$pt]['error'])) {
        $err_parts[] = $pt . ': ' . $summary['results'][$pt]['error'];
    }
}
sh_cron_status_save($con, [
    'status' => empty($err_parts) ? 'ok' : 'error',
    'started_at' => $cron_started_at,
    'ended_at' => sh_now_iso(),
    'duration_sec' => $duration,
    'pid' => $cron_pid,
    'message' => empty($err_parts)
        ? ('คัดกรอง (' . $time_window . ') OPD ' . $opd_n . ' / IPD ' . $ipd_n . ' ราย ใน ' . $duration . ' วินาที')
        : implode(' · ', $err_parts),
    'opd_patients' => $opd_n,
    'ipd_patients' => $ipd_n,
    'time_window' => $time_window,
]);
$cron_finished = true;

if (php_sapi_name() === 'cli') {
    echo json_encode($summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
} else {
    echo json_encode(['status' => 'success'] + $summary, JSON_UNESCAPED_UNICODE);
}
