<?php
/**
 * Patient IPD — Medication Profile คล้าย PharMS (จาก HOSxP)
 */
require_once __DIR__ . '/patient_opd_helper.php';

function pip_empty_offdate($d) {
    $d = trim((string)$d);
    return ($d === '' || $d === '0000-00-00' || $d === '0000-00-00 00:00:00');
}

/**
 * ยา Continuous ที่ “หยุดจริงแล้ว” — ตั้ง off ล่วงหน้ายังถือว่า Active
 * ถือเป็น OFF เมื่อมี offdate และเลยวันนั้นแล้ว (offdate < วันนี้)
 * เช่น off 14/10 · วันนี้ 14/10 = Active · วันนี้ 15/10 = OFF
 */
function pip_med_is_effectively_off($offdate, $asOf = null) {
    if (pip_empty_offdate($offdate)) {
        return false;
    }
    $off = substr(trim((string)$offdate), 0, 10);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $off)) {
        return true;
    }
    $today = $asOf !== null && $asOf !== ''
        ? substr(trim((string)$asOf), 0, 10)
        : date('Y-m-d');
    return strcmp($off, $today) < 0;
}

function pip_is_injection($name, $units = '', $dosageform = '') {
    $blob = strtolower(trim((string)$name) . ' ' . trim((string)$units) . ' ' . trim((string)$dosageform));
    if ($blob === '') {
        return false;
    }
    $keys = [
        'inj', 'injection', 'amp', 'ampoule', 'vial', 'syringe',
        ' iv', ' im', ' sc', 'iv.', 'im.', 'sc.',
        'ฉีด', 'แอมพูล', 'แอมปูล', 'ไวอัล', 'อินเจค',
    ];
    foreach ($keys as $k) {
        if (strpos($blob, $k) !== false) {
            return true;
        }
    }
    return false;
}

/** ยาเม็ด/แคปซูล (TAB/CAP) — ใช้คำนวณจำนวนเข้า Robot */
function pip_is_tab_cap($name, $units = '', $dosageform = '') {
    $blob = strtoupper(trim(
        (string)$name . ' ' . (string)$units . ' ' . (string)$dosageform
    ));
    if ($blob === '') {
        return false;
    }
    if (preg_match('/\bTAB(?:LET)?S?\b|\bCAP(?:SULE)?S?\b/', $blob)) {
        return true;
    }
    $low = strtolower($blob);
    if (strpos($low, 'เม็ด') !== false || strpos($low, 'แคปซูล') !== false || strpos($low, 'แคปซู') !== false) {
        return true;
    }
    return false;
}

function pip_order_type_display($type) {
    $t = strtoupper(trim((string)$type));
    if ($t === 'IRX') {
        return 'IRx';
    }
    if ($t === '') {
        return '-';
    }
    return $t;
}

function pip_is_oneday_order_type($type) {
    $t = strtoupper(trim((string)$type));
    return in_array($t, ['OD', 'OND', 'ONEDAY', 'ONE-DAY', 'STAT', 'PRN', 'ONCE'], true);
}

/** ดึง Interval จากวิธีใช้ เช่น ทุก 6 ชม. / วันละ 2 ครั้ง */
function pip_extract_interval($usage) {
    $usage = trim((string)$usage);
    if ($usage === '') {
        return '';
    }
    if (preg_match('/ทุก\s*(\d+(?:\.\d+)?)\s*(ชม\.?|ชั่วโมง|hr|hrs|h)\b/ui', $usage, $m)) {
        return 'ทุก ' . $m[1] . ' ชม.';
    }
    if (preg_match('/ทุก\s*(\d+)\s*(วัน|d)\b/ui', $usage, $m)) {
        return 'ทุก ' . $m[1] . ' วัน';
    }
    if (preg_match('/วันละ\s*(\d+)\s*ครั้ง/u', $usage, $m)) {
        return 'วันละ ' . $m[1] . ' ครั้ง';
    }
    if (preg_match('/\b(?:x|×)\s*(\d+)\b/i', $usage, $m)) {
        return 'x' . $m[1];
    }
    if (preg_match('/(\d+)\s*x\s*(\d+)/i', $usage, $m)) {
        return $m[1] . 'x' . $m[2];
    }
    if (preg_match('/PRN|เมื่อมีอาการ|อาการปวด/ui', $usage)) {
        return 'PRN';
    }
    return '';
}

function pip_fmt_date_dmy($date) {
    $date = substr(trim((string)$date), 0, 10);
    if ($date === '' || $date === '0000-00-00') {
        return '';
    }
    $ts = strtotime($date);
    return $ts ? date('d/m/Y', $ts) : $date;
}

/** แสดงวันที่+เวลา รูปแบบ d/m/Y H:i */
function pip_fmt_datetime_dmy($dt) {
    $dt = trim((string)$dt);
    if ($dt === '' || strpos($dt, '0000-00-00') === 0) {
        return '';
    }
    $ts = strtotime($dt);
    return $ts ? date('d/m/Y H:i', $ts) : $dt;
}

/**
 * แผนที่วันที่ → ผู้ Key ของ IRx (entry_staff) สำหรับ AN
 * ใช้เป็น fallback ผู้บันทึกเมื่อ medplan_ipd.staff ว่าง
 */
function pip_irx_key_by_date($hos, $an) {
    $an = trim((string)$an);
    if ($an === '' || !$hos) {
        return [];
    }
    $an_esc = mysqli_real_escape_string($hos, $an);
    $ocols = pop_cols($hos, 'ipt_order_no');
    if (!$ocols || !pop_has($ocols, 'order_type')) {
        return [];
    }
    $rxdate = pop_has($ocols, 'rxdate') ? 'ion.rxdate' : (pop_has($ocols, 'order_date') ? 'ion.order_date' : '');
    if ($rxdate === '') {
        return [];
    }
    $rxtime = pop_has($ocols, 'rxtime') ? 'ion.rxtime' : (pop_has($ocols, 'order_time') ? 'ion.order_time' : "''");
    $staff = pip_col_expr($ocols, 'ion', ['entry_staff', 'staff', 'officer'], "''");
    $rows = pop_query_all($hos, "
        SELECT DATE($rxdate) AS d, $staff AS staff_code,
               " . pop_utf8('IFNULL(NULLIF(ou.name,\'\'), \'\')') . " AS staff_name
        FROM ipt_order_no ion
        LEFT JOIN opduser ou ON ou.loginname = $staff
        WHERE ion.an = '$an_esc'
          AND UPPER(TRIM(IFNULL(ion.order_type,''))) = 'IRX'
          AND TRIM(IFNULL($staff,'')) <> ''
        ORDER BY $rxdate DESC, $rxtime DESC
        LIMIT 500
    ");
    $map = [];
    foreach ($rows as $r) {
        $d = substr(trim((string)($r['d'] ?? '')), 0, 10);
        if ($d === '' || $d === '0000-00-00' || isset($map[$d])) {
            continue;
        }
        $code = trim((string)($r['staff_code'] ?? ''));
        $name = pop_clean($r['staff_name'] ?? '');
        if ($code === '') {
            continue;
        }
        $map[$d] = [
            'code' => $code,
            'name' => $name !== '' ? $name : $code,
        ];
    }
    return $map;
}

function pip_col_expr(array $cols, $alias, array $cands, $fallback = "''") {
    foreach ($cands as $c) {
        if (pop_has($cols, $c)) {
            return $alias . '.' . $c;
        }
    }
    return $fallback;
}

function pip_method_expr($alias = 'o', $du = 'du', $sp = 'sp') {
    return pop_utf8("IF($alias.sp_use IS NOT NULL AND TRIM($alias.sp_use) <> '',
        CONCAT(IFNULL($sp.name1,''),' ',IFNULL($sp.name2,''),' ',IFNULL($sp.name3,'')),
        CONCAT(IFNULL($du.name1,''),' ',IFNULL($du.name2,''),' ',IFNULL($du.name3,''))
    )");
}

function pip_medplan_method_expr($m = 'm', $du = 'du', $sp = 'sp') {
    return pop_utf8("IF($m.sp_use IS NOT NULL AND TRIM($m.sp_use) <> '',
        CONCAT(IFNULL($sp.name1,''),' ',IFNULL($sp.name2,''),' ',IFNULL($sp.name3,'')),
        CONCAT(IFNULL($du.name1,''),' ',IFNULL($du.name2,''),' ',IFNULL($du.name3,''))
    )");
}

function pip_drug_label($name, $strength = '', $units = '') {
    $label = pop_clean($name);
    $strength = pop_clean($strength);
    $units = pop_clean($units);
    if ($strength !== '' && stripos($label, $strength) === false) {
        $label = trim($label . ' ' . $strength);
    }
    if ($units !== '' && stripos($label, $units) === false) {
        $label = trim($label . ' ' . $units);
    }
    return $label;
}

function pip_fetch_admissions($hos, $hn, $limit = 40) {
    $in = pop_hn_in($hos, $hn);
    if ($in === '') {
        return [];
    }
    $rows = pop_query_all($hos, "
        SELECT i.an, i.vn, i.hn, i.regdate, i.regtime, i.dchdate, i.dchtime, i.ward, i.admdoctor, i.pttype,
               " . pop_utf8('w.name') . " AS ward_name,
               " . pop_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . " AS doctor_name,
               " . pop_utf8('pt.name') . " AS pttype_name
        FROM ipt i
        LEFT JOIN ward w ON w.ward = i.ward
        LEFT JOIN doctor doc ON doc.code = i.admdoctor
        LEFT JOIN pttype pt ON pt.pttype = i.pttype
        WHERE i.hn IN ($in)
        ORDER BY i.regdate DESC, i.an DESC
        LIMIT " . (int)$limit . "
    ");
    $out = [];
    foreach ($rows as $r) {
        $an = trim((string)($r['an'] ?? ''));
        if ($an === '') {
            continue;
        }
        $reg = substr(trim((string)($r['regdate'] ?? '')), 0, 10);
        if ($reg === '0000-00-00') {
            $reg = '';
        }
        $dch = substr(trim((string)($r['dchdate'] ?? '')), 0, 10);
        if ($dch === '0000-00-00') {
            $dch = '';
        }
        $out[] = [
            'an' => $an,
            'vn' => trim((string)($r['vn'] ?? '')),
            'hn' => trim((string)($r['hn'] ?? '')),
            'regdate' => $reg,
            'regtime' => pop_fmt_time($r['regtime'] ?? ''),
            'regdate_th' => pop_fmt_date_th($reg),
            'dchdate' => $dch,
            'dchtime' => pop_fmt_time($r['dchtime'] ?? ''),
            'ward' => trim((string)($r['ward'] ?? '')),
            'ward_name' => pop_clean($r['ward_name'] ?? ''),
            'doctor_name' => pop_clean($r['doctor_name'] ?? ''),
            'pttype' => trim((string)($r['pttype'] ?? '')),
            'pttype_name' => pop_clean($r['pttype_name'] ?? ''),
            'is_active' => pip_empty_offdate($dch) ? 1 : 0,
        ];
    }
    return $out;
}

/**
 * ยาที่ติ๊ก "รายการที่ต้องชำระเงิน (ใช้สิทธิไม่ได้)" ใน HOSxP (drugitems.must_paid = Y)
 * ถ้าระบุสิทธิใน drugitems_pttype จะเตือนเฉพาะเมื่อสิทธิผู้ป่วยอยู่ในรายการ
 * ถ้าไม่ระบุสิทธิ = ชำระทั้งหมด → เตือนทุกรายการ must_paid
 */
function pip_fetch_must_paid_drugs($hos, $an, $pttype = '') {
    $an = trim((string)$an);
    if ($an === '' || !$hos) {
        return [];
    }
    $dcols = pop_cols($hos, 'drugitems');
    if (!$dcols || !pop_has($dcols, 'must_paid')) {
        return [];
    }
    $an_esc = mysqli_real_escape_string($hos, $an);
    $pttype = trim((string)$pttype);
    $price = pop_has($dcols, 'price') ? 'd.price' : (pop_has($dcols, 'unitprice') ? 'd.unitprice' : '0');
    $units = pop_has($dcols, 'units') ? pop_utf8('d.units') : "''";
    $strength = pop_has($dcols, 'strength') ? pop_utf8('d.strength') : "''";

    $rows = pop_query_all($hos, "
        SELECT x.icode, x.src,
               " . pop_utf8('d.name') . " AS drug_name,
               $strength AS strength,
               $units AS units,
               $price AS price,
               IFNULL(d.must_paid,'N') AS must_paid
        FROM (
            SELECT m.icode, 'medplan' AS src
            FROM medplan_ipd m
            WHERE m.an = '$an_esc'
              AND (
                    m.offdate IS NULL OR m.offdate = '0000-00-00'
                    OR CAST(m.offdate AS CHAR) = '0000-00-00 00:00:00'
                    OR DATE(m.offdate) >= CURDATE()
              )
            UNION
            SELECT o.icode, 'order' AS src
            FROM opitemrece o
            WHERE o.an = '$an_esc'
              AND TRIM(IFNULL(o.icode,'')) <> ''
        ) x
        INNER JOIN drugitems d ON d.icode = x.icode
        WHERE UPPER(TRIM(IFNULL(d.must_paid,''))) IN ('Y','1')
        GROUP BY x.icode
        ORDER BY d.name
        LIMIT 200
    ");

    $ptCols = pop_cols($hos, 'drugitems_pttype');
    $hasPtLink = $ptCols && pop_has($ptCols, 'icode') && pop_has($ptCols, 'pttype');
    $ptNameCols = pop_cols($hos, 'pttype');

    $out = [];
    foreach ($rows as $r) {
        $icode = trim((string)($r['icode'] ?? ''));
        if ($icode === '') {
            continue;
        }
        $rightCodes = [];
        $rightNames = [];
        if ($hasPtLink) {
            $icode_esc = mysqli_real_escape_string($hos, $icode);
            $ptRows = pop_query_all($hos, "
                SELECT dp.pttype,
                       " . ($ptNameCols && pop_has($ptNameCols, 'name')
                            ? pop_utf8('pt.name')
                            : "''") . " AS pttype_name
                FROM drugitems_pttype dp
                " . ($ptNameCols ? "LEFT JOIN pttype pt ON pt.pttype = dp.pttype" : '') . "
                WHERE dp.icode = '$icode_esc'
                ORDER BY dp.pttype
                LIMIT 80
            ");
            foreach ($ptRows as $pr) {
                $code = trim((string)($pr['pttype'] ?? ''));
                if ($code === '') {
                    continue;
                }
                $rightCodes[] = $code;
                $nm = pop_clean($pr['pttype_name'] ?? '');
                $rightNames[] = $nm !== '' ? ($code . ' ' . $nm) : $code;
            }
        }
        // มีรายการสิทธิเฉพาะ → เตือนเฉพาะเมื่อสิทธิผู้ป่วยอยู่ในกลุ่มนั้น
        if ($rightCodes && $pttype !== '' && !in_array($pttype, $rightCodes, true)) {
            continue;
        }
        $name = pip_drug_label($r['drug_name'] ?? '', $r['strength'] ?? '', $r['units'] ?? '');
        $out[] = [
            'icode' => $icode,
            'name' => $name,
            'price' => pop_num($r['price'] ?? '0'),
            'must_paid' => 'Y',
            'src' => trim((string)($r['src'] ?? '')),
            'pttype_codes' => $rightCodes,
            'pttype_text' => $rightCodes
                ? implode(', ', $rightNames)
                : 'ชำระทั้งหมด (ไม่ระบุสิทธิ)',
            'scope' => $rightCodes ? 'selected_rights' : 'all_rights',
        ];
    }
    return $out;
}

/**
 * ค้น AN แบบ HOSxP: ใส่ครบ หรือใส่แค่ 5 ตัวท้ายก็ได้
 * คืนค่า AN เต็มจาก ipt (prefer admit อยู่ → ล่าสุด) หรือ '' ถ้าไม่พบ
 */
function pip_resolve_an($hos, $an) {
    $an = trim((string)$an);
    if ($an === '' || !$hos) {
        return '';
    }
    $an_esc = mysqli_real_escape_string($hos, $an);
    $exact = pop_query_one($hos, "SELECT an FROM ipt WHERE an='$an_esc' LIMIT 1");
    if (!empty($exact['an'])) {
        return trim((string)$exact['an']);
    }

    $digits = preg_replace('/\D+/', '', $an);
    if ($digits === '' || strlen($digits) > 8) {
        return '';
    }
    /* เทียบ 5 ตัวท้าย — รองรับพิมพ์สั้นกว่า 5 ตัวด้วย (เช่น 123 → 00123) */
    $tail = substr(str_pad($digits, 5, '0', STR_PAD_LEFT), -5);
    $tail_esc = mysqli_real_escape_string($hos, $tail);
    $dch_null = "IFNULL(NULLIF(TRIM(i.dchdate),''),'0000-00-00') IN ('','0000-00-00')";
    $r = pop_query_one($hos, "
        SELECT i.an
        FROM ipt i
        WHERE RIGHT(i.an, 5) = '$tail_esc'
        ORDER BY ($dch_null) DESC, i.regdate DESC, i.an DESC
        LIMIT 1
    ");
    return trim((string)($r['an'] ?? ''));
}

/** เทียบ AN ตรง หรือ 5 ตัวท้าย (HOSxP-style) */
function pip_an_matches($fullAn, $queryAn) {
    $fullAn = trim((string)$fullAn);
    $queryAn = trim((string)$queryAn);
    if ($fullAn === '' || $queryAn === '') {
        return false;
    }
    if ($fullAn === $queryAn) {
        return true;
    }
    $fullDigits = preg_replace('/\D+/', '', $fullAn);
    $qDigits = preg_replace('/\D+/', '', $queryAn);
    if ($fullDigits === '' || $qDigits === '' || strlen($qDigits) > 8) {
        return false;
    }
    $fullTail = substr(str_pad($fullDigits, 5, '0', STR_PAD_LEFT), -5);
    $qTail = substr(str_pad($qDigits, 5, '0', STR_PAD_LEFT), -5);
    return $fullTail === $qTail;
}

function pip_resolve_admission($hos, $hn, $an = '') {
    $an = trim((string)$an);
    $admissions = pip_fetch_admissions($hos, $hn, 60);
    if (!$admissions) {
        return [null, []];
    }
    if ($an !== '') {
        foreach ($admissions as $a) {
            if (($a['an'] ?? '') === $an) {
                return [$a, $admissions];
            }
        }
        /* fallback: 5 ตัวท้าย — เลือก admit ที่ยังอยู่ก่อน แล้วค่อยล่าสุด */
        $tailHits = [];
        foreach ($admissions as $a) {
            if (pip_an_matches($a['an'] ?? '', $an)) {
                $tailHits[] = $a;
            }
        }
        if ($tailHits) {
            foreach ($tailHits as $a) {
                if (!empty($a['is_active'])) {
                    return [$a, $admissions];
                }
            }
            return [$tailHits[0], $admissions];
        }
    }
    foreach ($admissions as $a) {
        if (!empty($a['is_active'])) {
            return [$a, $admissions];
        }
    }
    return [$admissions[0], $admissions];
}

function pip_fetch_dx($hos, $an) {
    $an = trim((string)$an);
    if ($an === '') {
        return ['code' => '', 'name' => '', 'text' => ''];
    }
    $an_esc = mysqli_real_escape_string($hos, $an);
    $icols = pop_cols($hos, 'iptdiag');
    $icd_cols = pop_cols($hos, 'icd101');
    if (!$icols) {
        $ipt = pop_cols($hos, 'ipt');
        if (pop_has($ipt, 'prediag')) {
            $r = pop_query_one($hos, "SELECT " . pop_utf8('prediag') . " AS prediag FROM ipt WHERE an='$an_esc' LIMIT 1");
            $pre = pop_clean($r['prediag'] ?? '');
            return ['code' => '', 'name' => $pre, 'text' => $pre];
        }
        return ['code' => '', 'name' => '', 'text' => ''];
    }
    $diagtype = pop_has($icols, 'diagtype') ? "ORDER BY CASE WHEN TRIM(IFNULL(d.diagtype,'')) IN ('1','01') THEN 0 ELSE 1 END, d.diagtype" : "ORDER BY 1";
    $sql = "
        SELECT " . pop_utf8('d.icd10') . " AS icd10,
               " . ($icd_cols ? pop_utf8('c.name') : "''") . " AS icd_name
        FROM iptdiag d
        " . ($icd_cols ? "LEFT JOIN icd101 c ON c.code = d.icd10" : '') . "
        WHERE d.an = '$an_esc'
        $diagtype
        LIMIT 5
    ";
    $rows = pop_query_all($hos, $sql);
    if (!$rows) {
        $ipt = pop_cols($hos, 'ipt');
        if (pop_has($ipt, 'prediag')) {
            $r = pop_query_one($hos, "SELECT " . pop_utf8('prediag') . " AS prediag FROM ipt WHERE an='$an_esc' LIMIT 1");
            $pre = pop_clean($r['prediag'] ?? '');
            return ['code' => '', 'name' => $pre, 'text' => $pre];
        }
        return ['code' => '', 'name' => '', 'text' => ''];
    }
    $first = $rows[0];
    $code = pop_clean($first['icd10'] ?? '');
    $name = pop_clean($first['icd_name'] ?? '');
    $text = $code !== '' && $name !== '' ? ($code . ' - ' . $name) : ($code !== '' ? $code : $name);
    return ['code' => $code, 'name' => $name, 'text' => $text];
}

function pip_fetch_orders($hos, $an) {
    $an = trim((string)$an);
    if ($an === '') {
        return [];
    }
    $an_esc = mysqli_real_escape_string($hos, $an);
    $ocols = pop_cols($hos, 'ipt_order_no');
    if (!$ocols) {
        return [];
    }
    $doctor_sql = pop_has($ocols, 'doctor') ? 'ion.doctor' : "''";
    $ward_sql = pop_has($ocols, 'ward') ? 'ion.ward' : "''";
    // ผู้ Key จาก HOSxP — ลำดับ staff ที่มักใช้บันทึก order
    $staff_sql = pip_col_expr($ocols, 'ion', ['staff', 'officer', 'recorder', 'entry_staff', 'order_staff'], "''");
    $item_count = pop_has($ocols, 'item_count') ? 'ion.item_count' : '0';
    $order_no_col = pop_has($ocols, 'order_no') ? 'ion.order_no' : "''";
    $rows = pop_query_all($hos, "
        SELECT $order_no_col AS order_no,
               " . (pop_has($ocols, 'order_type') ? 'ion.order_type' : "''") . " AS order_type,
               " . (pop_has($ocols, 'rxdate') ? 'ion.rxdate' : "NULL") . " AS rxdate,
               " . (pop_has($ocols, 'rxtime') ? 'ion.rxtime' : "''") . " AS rxtime,
               $doctor_sql AS doctor,
               $ward_sql AS ward,
               $staff_sql AS staff,
               $item_count AS item_count,
               " . pop_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . " AS doctor_name,
               " . pop_utf8('IFNULL(NULLIF(ou.name,\'\'), IFNULL(NULLIF(doc2.name,\'\'), \'\'))') . " AS staff_name,
               " . pop_utf8('IFNULL(ou.loginname, \'\')') . " AS staff_login,
               " . pop_utf8('w.name') . " AS ward_name
        FROM ipt_order_no ion
        LEFT JOIN doctor doc ON doc.code = $doctor_sql
        LEFT JOIN ward w ON w.ward = $ward_sql
        LEFT JOIN opduser ou ON ou.loginname = $staff_sql
        LEFT JOIN doctor doc2 ON doc2.code = $staff_sql
        WHERE ion.an = '$an_esc'
        ORDER BY ion.rxdate DESC, ion.rxtime DESC, ion.order_no DESC
        LIMIT 200
    ");

    // fallback ผู้ Key จาก opitemrece.staff ถ้าว่างใน ipt_order_no
    $keyFromItems = [];
    $opcols = pop_cols($hos, 'opitemrece');
    if (pop_has($opcols, 'staff') && pop_has($opcols, 'order_no')) {
        $itemStaff = pop_query_all($hos, "
            SELECT o.order_no, o.staff,
                   " . pop_utf8('IFNULL(ou.name, \'\')') . " AS staff_name
            FROM opitemrece o
            LEFT JOIN opduser ou ON ou.loginname = o.staff
            WHERE o.an = '$an_esc'
              AND TRIM(IFNULL(o.staff,'')) <> ''
            ORDER BY o.item_no ASC
            LIMIT 2000
        ");
        foreach ($itemStaff as $is) {
            $on = trim((string)($is['order_no'] ?? ''));
            if ($on === '' || isset($keyFromItems[$on])) {
                continue;
            }
            $keyFromItems[$on] = [
                'code' => trim((string)($is['staff'] ?? '')),
                'name' => pop_clean($is['staff_name'] ?? ''),
            ];
        }
    }

    $out = [];
    foreach ($rows as $r) {
        $orderNo = trim((string)($r['order_no'] ?? ''));
        if ($orderNo === '') {
            continue;
        }
        $rxdate = substr(trim((string)($r['rxdate'] ?? '')), 0, 10);
        if ($rxdate === '0000-00-00') {
            $rxdate = '';
        }
        $staffName = pop_clean($r['staff_name'] ?? '');
        $staffCode = trim((string)($r['staff'] ?? ''));
        if ($staffCode === '' && isset($keyFromItems[$orderNo])) {
            $staffCode = $keyFromItems[$orderNo]['code'];
            if ($staffName === '') {
                $staffName = $keyFromItems[$orderNo]['name'];
            }
        }
        $keyStaffCode = $staffCode !== '' ? $staffCode : trim((string)($r['staff_login'] ?? ''));
        $keyStaffName = $staffName !== '' ? $staffName : $keyStaffCode;
        $out[] = [
            'order_no' => $orderNo,
            'order_type' => pip_order_type_display($r['order_type'] ?? ''),
            'order_type_raw' => strtoupper(trim((string)($r['order_type'] ?? ''))),
            'rxdate' => $rxdate,
            'rxtime' => pop_fmt_time($r['rxtime'] ?? ''),
            'rxdate_th' => pop_fmt_date_th($rxdate),
            'rxdate_dmy' => pip_fmt_date_dmy($rxdate),
            // แสดง วัน/เดือน/ปี เวลา เช่น 28/09/2026 08:10
            'datetime' => trim(
                ($rxdate !== '' ? pip_fmt_date_dmy($rxdate) : '')
                . ' '
                . pop_fmt_time($r['rxtime'] ?? '')
            ),
            'ward_name' => pop_clean($r['ward_name'] ?? ''),
            'doctor_name' => pop_clean($r['doctor_name'] ?? ''),
            'staff' => $staffCode,
            'staff_name' => $keyStaffName,
            'key_staff' => $keyStaffCode,
            'key_staff_name' => $keyStaffName,
            'dispense_user_id' => 0,
            'dispense_name' => '',
            'dispense_username' => '',
            'dispensed_at' => '',
            'is_dispensed' => 0,
            'item_count' => (int)($r['item_count'] ?? 0),
            'key' => $keyStaffCode !== '' ? $keyStaffCode : $orderNo,
        ];
    }
    return $out;
}

/** ตารางบันทึกผู้จ่าย (THAM SAFE) */
function pip_ensure_dispense_table($con) {
    if (!$con) {
        return false;
    }
    return (bool)@mysqli_query($con, "
        CREATE TABLE IF NOT EXISTS tham_pip_dispense (
            id INT AUTO_INCREMENT PRIMARY KEY,
            an VARCHAR(20) NOT NULL,
            order_no VARCHAR(40) NOT NULL,
            hn VARCHAR(20) NULL,
            dispense_user_id INT NOT NULL DEFAULT 0,
            dispense_username VARCHAR(64) NOT NULL DEFAULT '',
            dispense_name VARCHAR(120) NOT NULL DEFAULT '',
            dispensed_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            UNIQUE KEY uk_an_order (an, order_no),
            KEY idx_an (an),
            KEY idx_hn (hn)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8
    ");
}

function pip_fetch_dispense_map($con, $an) {
    $an = trim((string)$an);
    $out = [];
    if ($an === '' || !$con) {
        return $out;
    }
    pip_ensure_dispense_table($con);
    $an_esc = mysqli_real_escape_string($con, $an);
    $q = @mysqli_query($con, "
        SELECT order_no, dispense_user_id, dispense_username, dispense_name, dispensed_at
        FROM tham_pip_dispense
        WHERE an = '$an_esc'
    ");
    if (!$q) {
        return $out;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $on = trim((string)($r['order_no'] ?? ''));
        if ($on === '') {
            continue;
        }
        $out[$on] = [
            'dispense_user_id' => (int)($r['dispense_user_id'] ?? 0),
            'dispense_username' => trim((string)($r['dispense_username'] ?? '')),
            'dispense_name' => trim((string)($r['dispense_name'] ?? '')),
            'dispensed_at' => trim((string)($r['dispensed_at'] ?? '')),
            'is_dispensed' => 1,
        ];
    }
    return $out;
}

function pip_attach_dispense(array $orders, array $map) {
    foreach ($orders as &$o) {
        $on = trim((string)($o['order_no'] ?? ''));
        if ($on !== '' && isset($map[$on])) {
            $at = (string)($map[$on]['dispensed_at'] ?? '');
            $ts = $at !== '' ? strtotime($at) : false;
            $o['dispense_user_id'] = (int)$map[$on]['dispense_user_id'];
            $o['dispense_username'] = $map[$on]['dispense_username'];
            $o['dispense_name'] = $map[$on]['dispense_name'];
            $o['dispensed_at'] = $at;
            $o['dispensed_at_display'] = $ts ? date('d/m/Y H:i', $ts) : $at;
            $o['is_dispensed'] = 1;
        } else {
            $o['dispense_user_id'] = 0;
            $o['dispense_username'] = '';
            $o['dispense_name'] = '';
            $o['dispensed_at'] = '';
            $o['dispensed_at_display'] = '';
            $o['is_dispensed'] = 0;
        }
    }
    unset($o);
    return $orders;
}

function pip_save_dispense($con, $an, $order_no, $hn = '') {
    $an = trim((string)$an);
    $order_no = trim((string)$order_no);
    $hn = trim((string)$hn);
    if ($an === '' || $order_no === '') {
        return ['ok' => false, 'error' => 'ไม่พบ AN / Order'];
    }
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    pip_ensure_dispense_table($con);
    $uid = (int)($_SESSION['user_id'] ?? 0);
    $uname = trim((string)($_SESSION['username'] ?? ''));
    $fname = trim((string)($_SESSION['full_name'] ?? ''));
    if ($uid <= 0 && $fname === '' && $uname === '') {
        return ['ok' => false, 'error' => 'ไม่พบผู้ใช้ที่ login'];
    }
    $display = $fname !== '' ? $fname : ($uname !== '' ? $uname : ('user#' . $uid));
    $an_esc = mysqli_real_escape_string($con, $an);
    $on_esc = mysqli_real_escape_string($con, $order_no);
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $uname_esc = mysqli_real_escape_string($con, substr($uname, 0, 64));
    $name_esc = mysqli_real_escape_string($con, substr($display, 0, 120));
    $ok = @mysqli_query($con, "
        INSERT INTO tham_pip_dispense
            (an, order_no, hn, dispense_user_id, dispense_username, dispense_name, dispensed_at, updated_at)
        VALUES
            ('$an_esc', '$on_esc', '$hn_esc', $uid, '$uname_esc', '$name_esc', NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            hn = VALUES(hn),
            dispense_user_id = VALUES(dispense_user_id),
            dispense_username = VALUES(dispense_username),
            dispense_name = VALUES(dispense_name),
            dispensed_at = NOW(),
            updated_at = NOW()
    ");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกผู้จ่ายไม่สำเร็จ: ' . mysqli_error($con)];
    }
    $at = date('Y-m-d H:i:s');
    // อ่านค่าจริงจาก DB หลังบันทึก
    $q = @mysqli_query($con, "
        SELECT dispense_user_id, dispense_username, dispense_name, dispensed_at
        FROM tham_pip_dispense
        WHERE an='$an_esc' AND order_no='$on_esc'
        LIMIT 1
    ");
    if ($q && ($row = mysqli_fetch_assoc($q))) {
        $at = trim((string)($row['dispensed_at'] ?? $at));
        $display = trim((string)($row['dispense_name'] ?? $display));
        $uname = trim((string)($row['dispense_username'] ?? $uname));
        $uid = (int)($row['dispense_user_id'] ?? $uid);
    }
    $ts = strtotime($at);
    $displayAt = $ts ? date('d/m/Y H:i', $ts) : $at;
    return [
        'ok' => true,
        'an' => $an,
        'order_no' => $order_no,
        'dispense_user_id' => $uid,
        'dispense_username' => $uname,
        'dispense_name' => $display,
        'dispensed_at' => $at,
        'dispensed_at_display' => $displayAt,
        'is_dispensed' => 1,
    ];
}

function pip_cancel_dispense($con, $an, $order_no) {
    $an = trim((string)$an);
    $order_no = trim((string)$order_no);
    if ($an === '' || $order_no === '') {
        return ['ok' => false, 'error' => 'ไม่พบ AN / Order'];
    }
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    pip_ensure_dispense_table($con);
    $an_esc = mysqli_real_escape_string($con, $an);
    $on_esc = mysqli_real_escape_string($con, $order_no);
    @mysqli_query($con, "DELETE FROM tham_pip_dispense WHERE an='$an_esc' AND order_no='$on_esc'");
    return [
        'ok' => true,
        'an' => $an,
        'order_no' => $order_no,
        'dispense_user_id' => 0,
        'dispense_username' => '',
        'dispense_name' => '',
        'dispensed_at' => '',
        'is_dispensed' => 0,
    ];
}

/** Rx note ต่อใบ Order — โหมด note (บันทึกเท่านั้น) / alert (แจ้งเตือน) */
function pip_ensure_rx_note_table($con) {
    if (!$con) {
        return false;
    }
    return (bool)@mysqli_query($con, "
        CREATE TABLE IF NOT EXISTS tham_pip_rx_note (
            id INT AUTO_INCREMENT PRIMARY KEY,
            an VARCHAR(20) NOT NULL,
            order_no VARCHAR(40) NOT NULL,
            hn VARCHAR(20) NULL,
            note_text VARCHAR(500) NOT NULL DEFAULT '',
            alert_mode VARCHAR(16) NOT NULL DEFAULT 'note',
            updated_user_id INT NOT NULL DEFAULT 0,
            updated_username VARCHAR(64) NOT NULL DEFAULT '',
            updated_name VARCHAR(120) NOT NULL DEFAULT '',
            updated_at DATETIME NOT NULL,
            UNIQUE KEY uk_an_order (an, order_no),
            KEY idx_an (an),
            KEY idx_mode (alert_mode)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8
    ");
}

function pip_fetch_rx_note_map($con, $an) {
    $an = trim((string)$an);
    $out = [];
    if ($an === '' || !$con) {
        return $out;
    }
    pip_ensure_rx_note_table($con);
    $an_esc = mysqli_real_escape_string($con, $an);
    $q = @mysqli_query($con, "
        SELECT order_no, note_text, alert_mode, updated_name, updated_at
        FROM tham_pip_rx_note
        WHERE an = '$an_esc'
    ");
    if (!$q) {
        return $out;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $on = trim((string)($r['order_no'] ?? ''));
        if ($on === '') {
            continue;
        }
        $mode = strtolower(trim((string)($r['alert_mode'] ?? 'note')));
        if ($mode !== 'alert') {
            $mode = 'note';
        }
        $out[$on] = [
            'rx_note' => trim((string)($r['note_text'] ?? '')),
            'rx_note_mode' => $mode,
            'rx_note_updated_name' => trim((string)($r['updated_name'] ?? '')),
            'rx_note_updated_at' => trim((string)($r['updated_at'] ?? '')),
        ];
    }
    return $out;
}

function pip_attach_rx_notes(array $orders, array $map) {
    foreach ($orders as &$o) {
        $on = trim((string)($o['order_no'] ?? ''));
        if ($on !== '' && isset($map[$on])) {
            $o['rx_note'] = $map[$on]['rx_note'];
            $o['rx_note_mode'] = $map[$on]['rx_note_mode'];
            $o['rx_note_updated_name'] = $map[$on]['rx_note_updated_name'];
            $o['rx_note_updated_at'] = $map[$on]['rx_note_updated_at'];
        } else {
            $o['rx_note'] = '';
            $o['rx_note_mode'] = 'note';
            $o['rx_note_updated_name'] = '';
            $o['rx_note_updated_at'] = '';
        }
    }
    unset($o);
    return $orders;
}

function pip_save_rx_note($con, $an, $order_no, $note_text, $alert_mode = 'note', $hn = '') {
    $an = trim((string)$an);
    $order_no = trim((string)$order_no);
    $hn = trim((string)$hn);
    $note_text = trim((string)$note_text);
    $mode = strtolower(trim((string)$alert_mode));
    if ($mode !== 'alert') {
        $mode = 'note';
    }
    if ($an === '' || $order_no === '') {
        return ['ok' => false, 'error' => 'ไม่พบ AN / Order'];
    }
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    pip_ensure_rx_note_table($con);
    $an_esc = mysqli_real_escape_string($con, $an);
    $on_esc = mysqli_real_escape_string($con, $order_no);
    $hn_esc = mysqli_real_escape_string($con, $hn);

    // ว่าง = ลบโน้ต
    if ($note_text === '') {
        @mysqli_query($con, "DELETE FROM tham_pip_rx_note WHERE an='$an_esc' AND order_no='$on_esc'");
        return [
            'ok' => true,
            'an' => $an,
            'order_no' => $order_no,
            'rx_note' => '',
            'rx_note_mode' => 'note',
            'rx_note_updated_name' => '',
            'rx_note_updated_at' => '',
        ];
    }

    $uid = (int)($_SESSION['user_id'] ?? 0);
    $uname = trim((string)($_SESSION['username'] ?? ''));
    $fname = trim((string)($_SESSION['full_name'] ?? ''));
    $display = $fname !== '' ? $fname : ($uname !== '' ? $uname : ('user#' . $uid));
    if (function_exists('mb_substr')) {
        $note_text = mb_substr($note_text, 0, 500, 'UTF-8');
    } else {
        $note_text = substr($note_text, 0, 500);
    }
    $note_esc = mysqli_real_escape_string($con, $note_text);
    $mode_esc = mysqli_real_escape_string($con, $mode);
    $uname_esc = mysqli_real_escape_string($con, substr($uname, 0, 64));
    $name_esc = mysqli_real_escape_string($con, substr($display, 0, 120));
    $ok = @mysqli_query($con, "
        INSERT INTO tham_pip_rx_note
            (an, order_no, hn, note_text, alert_mode, updated_user_id, updated_username, updated_name, updated_at)
        VALUES
            ('$an_esc', '$on_esc', '$hn_esc', '$note_esc', '$mode_esc', $uid, '$uname_esc', '$name_esc', NOW())
        ON DUPLICATE KEY UPDATE
            hn = VALUES(hn),
            note_text = VALUES(note_text),
            alert_mode = VALUES(alert_mode),
            updated_user_id = VALUES(updated_user_id),
            updated_username = VALUES(updated_username),
            updated_name = VALUES(updated_name),
            updated_at = NOW()
    ");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึก Rx note ไม่สำเร็จ: ' . mysqli_error($con)];
    }
    return [
        'ok' => true,
        'an' => $an,
        'order_no' => $order_no,
        'rx_note' => $note_text,
        'rx_note_mode' => $mode,
        'rx_note_updated_name' => $display,
        'rx_note_updated_at' => date('Y-m-d H:i:s'),
    ];
}

function pip_fetch_order_items($hos, $an, $order_no) {
    $an = trim((string)$an);
    $order_no = trim((string)$order_no);
    if ($an === '' || $order_no === '') {
        return [];
    }
    $an_esc = mysqli_real_escape_string($hos, $an);
    $order_esc = mysqli_real_escape_string($hos, $order_no);
    $ocols = pop_cols($hos, 'opitemrece');
    $dcols = pop_cols($hos, 'drugitems');
    $ncols = pop_cols($hos, 'nondrugitems');
    $price = '0';
    if (pop_has($ocols, 'sum_price')) {
        $price = 'IFNULL(o.sum_price,0)';
    } elseif (pop_has($ocols, 'unitprice')) {
        $price = 'IFNULL(o.qty,0) * IFNULL(o.unitprice,0)';
    }
    $dosage = pop_has($dcols, 'dosageform') ? pop_utf8('d.dosageform') : "''";
    $d_strength = pop_has($dcols, 'strength') ? pop_utf8('d.strength') : "''";
    $d_units = pop_has($dcols, 'units') ? pop_utf8('d.units') : "''";
    $d_name = $dcols ? pop_utf8('d.name') : "''";
    $n_name = $ncols ? pop_utf8('nd.name') : "''";
    $n_unit = ($ncols && pop_has($ncols, 'unit')) ? pop_utf8('nd.unit') : "''";
    $method = pip_method_expr('o', 'du', 'sp');
    $duExtra = pip_drugusage_extra_select($hos, 'du');
    $ndJoin = $ncols ? 'LEFT JOIN nondrugitems nd ON nd.icode = o.icode' : '';
    $rows = pop_query_all($hos, "
        SELECT o.icode, o.qty, o.item_no, $price AS line_price,
               " . (pop_has($ocols, 'unitprice') ? 'o.unitprice' : '0') . " AS unitprice,
               $d_name AS drug_name,
               $d_strength AS strength,
               $d_units AS units,
               $dosage AS dosageform,
               $n_name AS nondrug_name,
               $n_unit AS nondrug_unit,
               CASE
                 WHEN d.icode IS NOT NULL THEN 'drug'
                 " . ($ncols ? "WHEN nd.icode IS NOT NULL THEN 'nondrug'" : '') . "
                 ELSE 'other'
               END AS item_kind,
               $method AS usage_text,
               {$duExtra['usage_code']},
               {$duExtra['iperdose']},
               {$duExtra['ccperdose']},
               {$duExtra['iperday']},
               " . pop_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . " AS doctor_name
        FROM opitemrece o
        LEFT JOIN drugitems d ON d.icode = o.icode
        $ndJoin
        LEFT JOIN drugusage du ON du.drugusage = o.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
        LEFT JOIN doctor doc ON doc.code = o.doctor
        WHERE o.an = '$an_esc' AND o.order_no = '$order_esc'
        ORDER BY o.item_no ASC, o.icode ASC
        LIMIT 400
    ");
    $out = [];
    foreach ($rows as $i => $r) {
        $kind = trim((string)($r['item_kind'] ?? 'other'));
        if ($kind === 'drug') {
            $name = pip_drug_label($r['drug_name'] ?? '', $r['strength'] ?? '', $r['units'] ?? '');
        } else {
            $name = pop_clean($r['nondrug_name'] ?? '');
            $nu = pop_clean($r['nondrug_unit'] ?? '');
            if ($name === '') {
                $name = trim((string)($r['icode'] ?? ''));
            } elseif ($nu !== '' && stripos($name, $nu) === false) {
                $name = trim($name . ' ' . $nu);
            }
        }
        $usage = ($kind === 'drug') ? pop_clean($r['usage_text'] ?? '') : '';
        $doseFields = ($kind === 'drug') ? pip_usage_dose_fields($r) : ['usage_code' => '', 'per_dose' => '', 'per_day' => ''];
        $isTabCap = ($kind === 'drug') && pip_is_tab_cap($name, $r['units'] ?? '', $r['dosageform'] ?? '');
        $qtyVal = pop_num($r['qty'] ?? '0');
        $robotMiss = $isTabCap
            && !pip_med_qty_is_zero($qtyVal)
            && ($doseFields['per_dose'] === '' || $doseFields['per_day'] === '');
        $out[] = [
            'seq' => $i + 1,
            'icode' => trim((string)($r['icode'] ?? '')),
            'name' => $name,
            'qty' => $qtyVal,
            'price' => round((float)($r['line_price'] ?? 0), 2),
            'usage' => $usage,
            'usage_code' => $doseFields['usage_code'],
            'per_dose' => $doseFields['per_dose'],
            'per_day' => $doseFields['per_day'],
            'doctor_name' => pop_clean($r['doctor_name'] ?? ''),
            'item_kind' => $kind, // drug | nondrug | other
            'is_drug' => ($kind === 'drug') ? 1 : 0,
            'is_nondrug' => ($kind === 'nondrug') ? 1 : 0,
            'is_injection' => ($kind === 'drug' && pip_is_injection($name, $r['units'] ?? '', $r['dosageform'] ?? '')) ? 1 : 0,
            'is_tab_cap' => $isTabCap ? 1 : 0,
            'robot_missing' => $robotMiss ? 1 : 0,
        ];
    }
    return $out;
}

/** ชื่อวันในสัปดาห์ (0=จันทร์ … 6=อาทิตย์) */
function pip_week_day_names() {
    return ['จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์', 'อาทิตย์'];
}

/** ค่าเริ่มต้น: ดักจับยาสั่งตามวัน → ตั้งจ่ายตามวัน (ล่วงหน้า หรือตรงวันตามข้อยกเว้น) */
function pip_default_day_ahead_settings() {
    return [
        'enabled' => true,
        'lead_days' => 1,
        'parse_usage' => true,
        'alert_if_missing' => true,
        'alert_if_mismatch' => true,
        'only_active' => true,
        'auto_popup' => true, // ตั้งจ่ายตามวัน
        'auto_popup_must_paid' => true,
        'auto_popup_hosxp_note' => true,
        'auto_popup_robot' => true,
        'robot_alert_enabled' => true,
        // ข้อยกเว้น: เข้าเงื่อนไขยาสั่งตามวันแล้ว → ตั้งจ่ายตรงวัน (ไม่เลื่อนล่วงหน้า)
        'exact_day_enabled' => true,
        'exact_day_keywords' => ['ก่อนนอน'],
        // รายการยาจาก HOSxP: {icode, name, units}
        'exact_day_drugs' => [
            ['icode' => '', 'name' => 'warfarin', 'units' => ''],
        ],
    ];
}

/** รายการยาตั้งจ่ายตรงวัน — รองรับทั้ง string เก่า และ object จาก HOSxP */
function pip_normalize_exact_day_drugs($raw, $max = 200) {
    if (is_string($raw)) {
        $parts = preg_split('/[\r\n,;]+/u', $raw);
        $raw = is_array($parts) ? $parts : [];
    }
    if (!is_array($raw)) {
        return [];
    }
    $out = [];
    $seen = [];
    foreach ($raw as $v) {
        $icode = '';
        $name = '';
        $units = '';
        if (is_array($v)) {
            $icode = trim((string)($v['icode'] ?? ''));
            $name = trim((string)($v['name'] ?? $v['match'] ?? ''));
            $units = trim((string)($v['units'] ?? ''));
        } else {
            $name = trim((string)$v);
        }
        if ($icode === '' && $name === '') {
            continue;
        }
        $key = $icode !== ''
            ? ('i:' . strtolower($icode))
            : ('n:' . (function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name)));
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = 1;
        $cut = static function ($s, $n) {
            if (function_exists('mb_substr')) {
                return mb_substr($s, 0, $n, 'UTF-8');
            }
            return substr($s, 0, $n);
        };
        $out[] = [
            'icode' => $cut($icode, 32),
            'name' => $cut($name !== '' ? $name : $icode, 255),
            'units' => $cut($units, 64),
        ];
        if (count($out) >= $max) {
            break;
        }
    }
    return $out;
}

/** แปลงรายการข้อความ (array หรือคั่นด้วยจุลภาค/บรรทัดใหม่) */
function pip_normalize_string_list($raw, $max = 80) {
    $items = [];
    if (is_string($raw)) {
        $parts = preg_split('/[\r\n,;]+/u', $raw);
        $raw = is_array($parts) ? $parts : [];
    }
    if (!is_array($raw)) {
        return [];
    }
    $seen = [];
    foreach ($raw as $v) {
        if (is_array($v)) {
            $v = (string)($v['match'] ?? $v['name'] ?? $v['icode'] ?? '');
        }
        $s = trim((string)$v);
        if ($s === '') {
            continue;
        }
        $key = function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = 1;
        $items[] = function_exists('mb_substr') ? mb_substr($s, 0, 120, 'UTF-8') : substr($s, 0, 120);
        if (count($items) >= $max) {
            break;
        }
    }
    return $items;
}

function pip_ensure_settings_table($con) {
    if (!$con) {
        return false;
    }
    @mysqli_query($con, "
        CREATE TABLE IF NOT EXISTS tham_pip_settings (
            setting_key VARCHAR(64) NOT NULL PRIMARY KEY,
            setting_value MEDIUMTEXT NULL,
            updated_at DATETIME NULL,
            updated_by VARCHAR(64) NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8
    ");
    return true;
}

function pip_normalize_day_ahead_settings(array $raw) {
    $base = pip_default_day_ahead_settings();
    $lead = isset($raw['lead_days']) ? (int)$raw['lead_days'] : $base['lead_days'];
    if ($lead < 1) {
        $lead = 1;
    }
    if ($lead > 6) {
        $lead = 6;
    }
    $exactKw = array_key_exists('exact_day_keywords', $raw)
        ? pip_normalize_string_list($raw['exact_day_keywords'])
        : $base['exact_day_keywords'];
    $exactDrugs = array_key_exists('exact_day_drugs', $raw)
        ? pip_normalize_exact_day_drugs($raw['exact_day_drugs'])
        : pip_normalize_exact_day_drugs($base['exact_day_drugs']);
    return [
        'enabled' => !empty($raw['enabled']),
        'lead_days' => $lead,
        'parse_usage' => array_key_exists('parse_usage', $raw) ? !empty($raw['parse_usage']) : $base['parse_usage'],
        'alert_if_missing' => array_key_exists('alert_if_missing', $raw) ? !empty($raw['alert_if_missing']) : $base['alert_if_missing'],
        'alert_if_mismatch' => array_key_exists('alert_if_mismatch', $raw) ? !empty($raw['alert_if_mismatch']) : $base['alert_if_mismatch'],
        'only_active' => array_key_exists('only_active', $raw) ? !empty($raw['only_active']) : $base['only_active'],
        'auto_popup' => array_key_exists('auto_popup', $raw) ? !empty($raw['auto_popup']) : $base['auto_popup'],
        'auto_popup_must_paid' => array_key_exists('auto_popup_must_paid', $raw)
            ? !empty($raw['auto_popup_must_paid']) : $base['auto_popup_must_paid'],
        'auto_popup_hosxp_note' => array_key_exists('auto_popup_hosxp_note', $raw)
            ? !empty($raw['auto_popup_hosxp_note']) : $base['auto_popup_hosxp_note'],
        'auto_popup_robot' => array_key_exists('auto_popup_robot', $raw)
            ? !empty($raw['auto_popup_robot']) : $base['auto_popup_robot'],
        'robot_alert_enabled' => array_key_exists('robot_alert_enabled', $raw)
            ? !empty($raw['robot_alert_enabled']) : $base['robot_alert_enabled'],
        'exact_day_enabled' => array_key_exists('exact_day_enabled', $raw)
            ? !empty($raw['exact_day_enabled']) : $base['exact_day_enabled'],
        'exact_day_keywords' => $exactKw,
        'exact_day_drugs' => $exactDrugs,
    ];
}

/**
 * ยาที่เข้าเงื่อนไขสั่งตามวันแล้ว ควรตั้งจ่ายตรงวัน (ไม่เลื่อนล่วงหน้า)
 * — จับจากรายการยา (ชื่อ/icode) หรือคำในวิธีใช้ (เช่น ก่อนนอน)
 */
function pip_is_exact_day_dispense(array $it, array $settings, array $adminDays) {
    if (!$adminDays) {
        return false;
    }
    if (empty($settings['exact_day_enabled'])) {
        return false;
    }
    $usage = (string)($it['usage'] ?? '');
    $name = (string)($it['name'] ?? '');
    $icode = trim((string)($it['icode'] ?? ''));
    $blob = function_exists('mb_strtolower')
        ? mb_strtolower($name . ' ' . $icode, 'UTF-8')
        : strtolower($name . ' ' . $icode);
    $usageL = function_exists('mb_strtolower')
        ? mb_strtolower($usage, 'UTF-8')
        : strtolower($usage);

    foreach (($settings['exact_day_drugs'] ?? []) as $m) {
        if (is_array($m)) {
            $mIcode = trim((string)($m['icode'] ?? ''));
            $mName = trim((string)($m['name'] ?? ''));
        } else {
            $mIcode = '';
            $mName = trim((string)$m);
        }
        if ($mIcode === '' && $mName === '') {
            continue;
        }
        if ($mIcode !== '' && $icode !== '' && strcasecmp($icode, $mIcode) === 0) {
            return true;
        }
        $ml = $mName !== ''
            ? (function_exists('mb_strtolower') ? mb_strtolower($mName, 'UTF-8') : strtolower($mName))
            : (function_exists('mb_strtolower') ? mb_strtolower($mIcode, 'UTF-8') : strtolower($mIcode));
        if ($ml !== '' && strpos($blob, $ml) !== false) {
            return true;
        }
    }
    foreach (($settings['exact_day_keywords'] ?? []) as $kw) {
        $kw = trim((string)$kw);
        if ($kw === '') {
            continue;
        }
        $kl = function_exists('mb_strtolower') ? mb_strtolower($kw, 'UTF-8') : strtolower($kw);
        if ($kl !== '' && strpos($usageL, $kl) !== false) {
            return true;
        }
    }
    return false;
}

function pip_ensure_robot_drugs_table($con) {
    if (!$con) {
        return false;
    }
    return (bool)@mysqli_query($con, "
        CREATE TABLE IF NOT EXISTS tham_pip_robot_drugs (
            icode VARCHAR(32) NOT NULL PRIMARY KEY,
            name VARCHAR(255) NULL,
            units VARCHAR(64) NULL,
            dosageform VARCHAR(128) NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            updated_at DATETIME NULL,
            updated_by VARCHAR(64) NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8
    ");
}

/** @return array<string, true> icode => true */
function pip_load_robot_icode_map($con) {
    $map = [];
    if (!$con) {
        return $map;
    }
    pip_ensure_robot_drugs_table($con);
    $q = @mysqli_query($con, "SELECT icode FROM tham_pip_robot_drugs WHERE active=1");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $icode = trim((string)($r['icode'] ?? ''));
            if ($icode !== '') {
                $map[$icode] = true;
            }
        }
    }
    return $map;
}

function pip_robot_drugs_count($con) {
    if (!$con) {
        return 0;
    }
    pip_ensure_robot_drugs_table($con);
    $q = @mysqli_query($con, "SELECT COUNT(*) AS c FROM tham_pip_robot_drugs WHERE active=1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return (int)($r['c'] ?? 0);
    }
    return 0;
}

function pip_list_robot_drugs($con, $q = '') {
    if (!$con) {
        return [];
    }
    pip_ensure_robot_drugs_table($con);
    $sql = "SELECT icode, name, units, dosageform, updated_at, updated_by
            FROM tham_pip_robot_drugs WHERE active=1";
    $q = trim((string)$q);
    if ($q !== '') {
        $esc = mysqli_real_escape_string($con, $q);
        $sql .= " AND (icode LIKE '%$esc%' OR name LIKE '%$esc%' OR units LIKE '%$esc%')";
    }
    $sql .= " ORDER BY name ASC, icode ASC LIMIT 5000";
    $rows = [];
    $res = @mysqli_query($con, $sql);
    if ($res) {
        while ($r = mysqli_fetch_assoc($res)) {
            $rows[] = [
                'icode' => trim((string)($r['icode'] ?? '')),
                'name' => pop_clean($r['name'] ?? ''),
                'units' => pop_clean($r['units'] ?? ''),
                'dosageform' => pop_clean($r['dosageform'] ?? ''),
                'updated_at' => trim((string)($r['updated_at'] ?? '')),
                'updated_by' => trim((string)($r['updated_by'] ?? '')),
            ];
        }
    }
    return $rows;
}

function pip_upsert_robot_drug($con, array $row, $by = '') {
    if (!$con) {
        return false;
    }
    pip_ensure_robot_drugs_table($con);
    $icode = trim((string)($row['icode'] ?? ''));
    if ($icode === '') {
        return false;
    }
    $icode_esc = mysqli_real_escape_string($con, substr($icode, 0, 32));
    $name_esc = mysqli_real_escape_string($con, substr(pop_clean($row['name'] ?? ''), 0, 255));
    $units_esc = mysqli_real_escape_string($con, substr(pop_clean($row['units'] ?? ''), 0, 64));
    $df_esc = mysqli_real_escape_string($con, substr(pop_clean($row['dosageform'] ?? ''), 0, 128));
    $by_esc = mysqli_real_escape_string($con, substr(trim((string)$by), 0, 64));
    return (bool)@mysqli_query($con, "
        INSERT INTO tham_pip_robot_drugs (icode, name, units, dosageform, active, updated_at, updated_by)
        VALUES ('$icode_esc', '$name_esc', '$units_esc', '$df_esc', 1, NOW(), '$by_esc')
        ON DUPLICATE KEY UPDATE
            name = VALUES(name),
            units = VALUES(units),
            dosageform = VALUES(dosageform),
            active = 1,
            updated_at = VALUES(updated_at),
            updated_by = VALUES(updated_by)
    ");
}

function pip_remove_robot_drug($con, $icode, $by = '') {
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    $icode = trim((string)$icode);
    if ($icode === '') {
        return ['ok' => false, 'error' => 'ไม่พบรหัสยา'];
    }
    pip_ensure_robot_drugs_table($con);
    $esc = mysqli_real_escape_string($con, substr($icode, 0, 32));
    $ok = @mysqli_query($con, "DELETE FROM tham_pip_robot_drugs WHERE icode='$esc'");
    if (!$ok) {
        return ['ok' => false, 'error' => 'ลบไม่สำเร็จ: ' . mysqli_error($con)];
    }
    return [
        'ok' => true,
        'icode' => $icode,
        'count' => pip_robot_drugs_count($con),
        'updated_by' => substr(trim((string)$by), 0, 64),
    ];
}

function pip_add_robot_drug($con, $hos, $icode, $by = '') {
    $icode = trim((string)$icode);
    if ($icode === '') {
        return ['ok' => false, 'error' => 'กรุณาระบุรหัสยา'];
    }
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    $row = ['icode' => $icode, 'name' => $icode, 'units' => '', 'dosageform' => ''];
    if ($hos) {
        $esc = mysqli_real_escape_string($hos, $icode);
        $dcols = pop_cols($hos, 'drugitems');
        $r = pop_query_one($hos, "
            SELECT d.icode,
                   " . pop_utf8('d.name') . " AS name,
                   " . (pop_has($dcols, 'strength') ? pop_utf8('d.strength') : "''") . " AS strength,
                   " . (pop_has($dcols, 'units') ? pop_utf8('d.units') : "''") . " AS units,
                   " . (pop_has($dcols, 'dosageform') ? pop_utf8('d.dosageform') : "''") . " AS dosageform
            FROM drugitems d
            WHERE d.icode = '$esc'
            LIMIT 1
        ");
        if ($r) {
            $row = [
                'icode' => trim((string)($r['icode'] ?? $icode)),
                'name' => pip_drug_label($r['name'] ?? '', $r['strength'] ?? '', $r['units'] ?? ''),
                'units' => pop_clean($r['units'] ?? ''),
                'dosageform' => pop_clean($r['dosageform'] ?? ''),
            ];
        }
    }
    if (!pip_upsert_robot_drug($con, $row, $by)) {
        return ['ok' => false, 'error' => 'เพิ่มรายการไม่สำเร็จ'];
    }
    return [
        'ok' => true,
        'item' => $row,
        'count' => pip_robot_drugs_count($con),
    ];
}

/** ดึงยา TAB/CAP จาก HOSxP drugitems */
function pip_fetch_hosxp_tab_cap_drugs($hos) {
    if (!$hos) {
        return [];
    }
    $dcols = pop_cols($hos, 'drugitems');
    if (!$dcols) {
        return [];
    }
    $statusWhere = '';
    if (pop_has($dcols, 'istatus')) {
        $statusWhere = " AND (IFNULL(d.istatus,'Y')='' OR UPPER(TRIM(d.istatus)) IN ('Y','1','A'))";
    }
    $rows = pop_query_all($hos, "
        SELECT d.icode,
               " . pop_utf8('d.name') . " AS name,
               " . (pop_has($dcols, 'strength') ? pop_utf8('d.strength') : "''") . " AS strength,
               " . (pop_has($dcols, 'units') ? pop_utf8('d.units') : "''") . " AS units,
               " . (pop_has($dcols, 'dosageform') ? pop_utf8('d.dosageform') : "''") . " AS dosageform
        FROM drugitems d
        WHERE 1=1 $statusWhere
        ORDER BY d.name ASC
        LIMIT 30000
    ");
    $out = [];
    foreach ($rows as $r) {
        $name = pip_drug_label($r['name'] ?? '', $r['strength'] ?? '', $r['units'] ?? '');
        $units = pop_clean($r['units'] ?? '');
        $df = pop_clean($r['dosageform'] ?? '');
        if (!pip_is_tab_cap($name, $units, $df)) {
            continue;
        }
        $icode = trim((string)($r['icode'] ?? ''));
        if ($icode === '') {
            continue;
        }
        $out[] = [
            'icode' => $icode,
            'name' => $name,
            'units' => $units,
            'dosageform' => $df,
        ];
    }
    return $out;
}

function pip_seed_robot_drugs($con, $hos, $by = '', $replace = false) {
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    if (!$hos) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'];
    }
    pip_ensure_robot_drugs_table($con);
    if ($replace) {
        @mysqli_query($con, "DELETE FROM tham_pip_robot_drugs");
    }
    $list = pip_fetch_hosxp_tab_cap_drugs($hos);
    $n = 0;
    foreach ($list as $row) {
        if (pip_upsert_robot_drug($con, $row, $by)) {
            $n++;
        }
    }
    return [
        'ok' => true,
        'imported' => $n,
        'count' => pip_robot_drugs_count($con),
        'replace' => $replace ? 1 : 0,
    ];
}

/** ค้นหายาใน HOSxP เพื่อเพิ่มเข้ารายการ Robot */
function pip_search_hosxp_drugs_for_robot($hos, $q, $limit = 40) {
    $q = trim((string)$q);
    if ($q === '' || !$hos) {
        return [];
    }
    $dcols = pop_cols($hos, 'drugitems');
    if (!$dcols) {
        return [];
    }
    $esc = mysqli_real_escape_string($hos, $q);
    $like = '%' . $esc . '%';
    $statusWhere = pop_has($dcols, 'istatus')
        ? " AND (IFNULL(d.istatus,'Y')='' OR UPPER(TRIM(d.istatus)) IN ('Y','1','A'))"
        : '';
    $rows = pop_query_all($hos, "
        SELECT d.icode,
               " . pop_utf8('d.name') . " AS name,
               " . (pop_has($dcols, 'strength') ? pop_utf8('d.strength') : "''") . " AS strength,
               " . (pop_has($dcols, 'units') ? pop_utf8('d.units') : "''") . " AS units,
               " . (pop_has($dcols, 'dosageform') ? pop_utf8('d.dosageform') : "''") . " AS dosageform
        FROM drugitems d
        WHERE (d.icode LIKE '$like' OR d.name LIKE '$like'
               " . (pop_has($dcols, 'generic_name') ? " OR d.generic_name LIKE '$like'" : '') . ")
          $statusWhere
        ORDER BY
          (d.icode = '$esc') DESC,
          (d.icode LIKE '$esc%') DESC,
          d.name ASC
        LIMIT " . (int)$limit . "
    ");
    $out = [];
    foreach ($rows as $r) {
        $name = pip_drug_label($r['name'] ?? '', $r['strength'] ?? '', $r['units'] ?? '');
        $out[] = [
            'icode' => trim((string)($r['icode'] ?? '')),
            'name' => $name,
            'units' => pop_clean($r['units'] ?? ''),
            'dosageform' => pop_clean($r['dosageform'] ?? ''),
            'is_tab_cap' => pip_is_tab_cap($name, $r['units'] ?? '', $r['dosageform'] ?? '') ? 1 : 0,
        ];
    }
    return $out;
}

/** qty = 0 → ไม่ต้องแจ้งเตือนไม่เข้า Robot (แม้ไม่มีต่อครั้ง/ต่อวัน) */
function pip_med_qty_is_zero($qty) {
    $s = trim((string)$qty);
    if ($s === '' || $s === '-' || strtolower($s) === 'null') {
        return false;
    }
    if (!is_numeric($s)) {
        return false;
    }
    return abs((float)$s) < 0.0000001;
}

/** ติดธง in_robot / robot_missing ตามรายการยาที่ตั้งค่าใน Robot */
function pip_apply_robot_flags(array $items, array $robotMap) {
    foreach ($items as &$it) {
        $icode = trim((string)($it['icode'] ?? ''));
        $in = ($icode !== '' && isset($robotMap[$icode]));
        $it['in_robot'] = $in ? 1 : 0;
        $perDose = trim((string)($it['per_dose'] ?? ''));
        $perDay = trim((string)($it['per_day'] ?? ''));
        $qtyZero = pip_med_qty_is_zero($it['qty'] ?? '');
        $it['robot_missing'] = (!$qtyZero && $in && ($perDose === '' || $perDay === '')) ? 1 : 0;
    }
    unset($it);
    return $items;
}

/**
 * ยาในรายการ Robot ที่ไม่มี ต่อครั้ง หรือ ต่อวัน — จะไม่เข้า Robot
 * (ข้ามเมื่อ qty = 0)
 * @param array<string,true>|null $robotMap
 * @return array{alerts: array, settings: array}
 */
function pip_detect_robot_missing_alerts(array $meds, array $settings, $robotMap = null) {
    $settings = pip_normalize_day_ahead_settings($settings);
    if (empty($settings['robot_alert_enabled'])) {
        return ['alerts' => [], 'settings' => $settings];
    }
    if (!is_array($robotMap)) {
        $robotMap = [];
    }
    // ยังไม่ได้ตั้งรายการ Robot → ไม่แจ้งเตือน (ให้ไป seed/ตั้งค่าก่อน)
    if (!$robotMap) {
        return ['alerts' => [], 'settings' => $settings];
    }
    $alerts = [];
    foreach ($meds as $it) {
        $icode = trim((string)($it['icode'] ?? ''));
        if ($icode === '' || !isset($robotMap[$icode])) {
            continue;
        }
        if (!empty($settings['only_active']) && !empty($it['is_off'])) {
            continue;
        }
        // qty = 0 ไม่เข้า Robot อยู่แล้ว — ไม่ต้องแจ้งเตือน
        if (pip_med_qty_is_zero($it['qty'] ?? '')) {
            continue;
        }
        $perDose = trim((string)($it['per_dose'] ?? ''));
        $perDay = trim((string)($it['per_day'] ?? ''));
        if ($perDose !== '' && $perDay !== '') {
            continue;
        }
        $miss = [];
        if ($perDose === '') {
            $miss[] = 'ต่อครั้ง';
        }
        if ($perDay === '') {
            $miss[] = 'ต่อวัน';
        }
        $alerts[] = [
            'med_plan_number' => (int)($it['med_plan_number'] ?? 0),
            'icode' => $icode,
            'name' => (string)($it['name'] ?? ''),
            'usage' => (string)($it['usage'] ?? ''),
            'usage_code' => (string)($it['usage_code'] ?? ''),
            'per_dose' => $perDose,
            'per_day' => $perDay,
            'missing' => $miss,
            'message' => 'วิธีใช้ไม่มี ' . implode(' / ', $miss) . ' — จะไม่เข้า Robot',
        ];
    }
    return ['alerts' => $alerts, 'settings' => $settings];
}

function pip_load_day_ahead_settings($con) {
    $out = pip_default_day_ahead_settings();
    if (!$con) {
        return $out;
    }
    pip_ensure_settings_table($con);
    $q = @mysqli_query($con, "SELECT setting_value FROM tham_pip_settings WHERE setting_key='day_ahead' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $decoded = json_decode((string)($r['setting_value'] ?? ''), true);
        if (is_array($decoded)) {
            $out = pip_normalize_day_ahead_settings(array_merge($out, $decoded));
        }
    }
    return $out;
}

function pip_save_day_ahead_settings($con, array $settings, $user = '') {
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    pip_ensure_settings_table($con);
    $norm = pip_normalize_day_ahead_settings($settings);
    $json = mysqli_real_escape_string($con, json_encode($norm, JSON_UNESCAPED_UNICODE));
    $user_esc = mysqli_real_escape_string($con, substr(trim((string)$user), 0, 64));
    $ok = @mysqli_query($con, "
        INSERT INTO tham_pip_settings (setting_key, setting_value, updated_at, updated_by)
        VALUES ('day_ahead', '$json', NOW(), '$user_esc')
        ON DUPLICATE KEY UPDATE
            setting_value = VALUES(setting_value),
            updated_at = VALUES(updated_at),
            updated_by = VALUES(updated_by)
    ");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกตั้งค่าไม่สำเร็จ: ' . mysqli_error($con)];
    }
    return ['ok' => true, 'settings' => $norm];
}

/**
 * Alert Pharma ใน Patient IPD — ค่าเริ่มต้นโมดูลตาม Smart Pharma Settings (IPD)
 * สามารถเพิ่ม/ลดโมดูลแจ้งเตือนได้ในตั้งค่า Patient IPD
 */
function pip_alert_pharma_ensure_sp($con) {
    if (!$con) {
        return false;
    }
    require_once __DIR__ . '/smart_pharma_helper.php';
    sp_ensure_tables($con);
    return true;
}

/** คีย์โมดูลที่เปิดใน Smart Pharma สำหรับ IPD */
function pip_alert_pharma_default_module_keys($con) {
    if (!$con || !pip_alert_pharma_ensure_sp($con)) {
        return [];
    }
    $keys = [];
    foreach (sp_get_modules($con, 'IPD') as $m) {
        $k = trim((string)($m['module_key'] ?? ''));
        if ($k !== '') {
            $keys[] = $k;
        }
    }
    return $keys;
}

/** รายการโมดูลทั้งหมดสำหรับ UI ตั้งค่า (พร้อมสถานะใน Smart Pharma) */
function pip_alert_pharma_available_modules($con) {
    if (!$con || !pip_alert_pharma_ensure_sp($con)) {
        return [];
    }
    $out = [];
    foreach (sp_list_all_modules($con) as $m) {
        $key = trim((string)($m['module_key'] ?? ''));
        if ($key === '') {
            continue;
        }
        $spDefault = !empty($m['enabled']) && !empty($m['enabled_ipd']);
        $out[] = [
            'key' => $key,
            'label' => (string)($m['label_th'] ?? $key),
            'icon' => (string)($m['icon'] ?? ''),
            'color' => (string)($m['color'] ?? ''),
            'sp_enabled' => !empty($m['enabled']),
            'sp_enabled_ipd' => !empty($m['enabled_ipd']),
            'sp_default' => $spDefault,
        ];
    }
    return $out;
}

function pip_default_alert_pharma_settings($con = null) {
    return [
        'enabled' => true,
        // alert_only = เด้งเฉพาะเมื่อไม่ผ่าน · always = ทุกครั้งรวม Pass · off = ไม่เด้ง
        'popup_mode' => 'alert_only',
        'auto_popup' => true,
        'auto_popup_pass' => false,
        'use_smart_pharma_defaults' => true,
        'module_keys' => $con ? pip_alert_pharma_default_module_keys($con) : [],
    ];
}

function pip_normalize_alert_pharma_popup_mode(array $raw, array $base) {
    $mode = trim((string)($raw['popup_mode'] ?? ''));
    if ($mode === 'alert_only' || $mode === 'always' || $mode === 'off') {
        return $mode;
    }
    // รองรับค่าเก่า auto_popup / auto_popup_pass
    $autoAlert = array_key_exists('auto_popup', $raw) ? !empty($raw['auto_popup']) : $base['auto_popup'];
    $autoPass = array_key_exists('auto_popup_pass', $raw) ? !empty($raw['auto_popup_pass']) : $base['auto_popup_pass'];
    if (!$autoAlert && !$autoPass) {
        return 'off';
    }
    if ($autoPass) {
        return 'always';
    }
    return 'alert_only';
}

function pip_normalize_alert_pharma_settings(array $raw, $con = null) {
    $base = pip_default_alert_pharma_settings($con);
    $useDefault = array_key_exists('use_smart_pharma_defaults', $raw)
        ? !empty($raw['use_smart_pharma_defaults'])
        : $base['use_smart_pharma_defaults'];
    $keys = [];
    if ($useDefault) {
        $keys = pip_alert_pharma_default_module_keys($con);
    } elseif (array_key_exists('module_keys', $raw) && is_array($raw['module_keys'])) {
        $seen = [];
        foreach ($raw['module_keys'] as $k) {
            $k = trim((string)$k);
            if ($k === '' || isset($seen[$k]) || (function_exists('sp_is_retired_module') && sp_is_retired_module($k))) {
                continue;
            }
            $seen[$k] = 1;
            $keys[] = $k;
        }
    } else {
        $keys = $base['module_keys'];
    }
    $mode = pip_normalize_alert_pharma_popup_mode($raw, $base);
    return [
        'enabled' => array_key_exists('enabled', $raw) ? !empty($raw['enabled']) : $base['enabled'],
        'popup_mode' => $mode,
        'auto_popup' => ($mode === 'alert_only' || $mode === 'always'),
        'auto_popup_pass' => ($mode === 'always'),
        'use_smart_pharma_defaults' => $useDefault,
        'module_keys' => $keys,
    ];
}

function pip_load_alert_pharma_settings($con) {
    $out = pip_default_alert_pharma_settings($con);
    if (!$con) {
        return $out;
    }
    pip_ensure_settings_table($con);
    $q = @mysqli_query($con, "SELECT setting_value FROM tham_pip_settings WHERE setting_key='alert_pharma' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $decoded = json_decode((string)($r['setting_value'] ?? ''), true);
        if (is_array($decoded)) {
            $out = pip_normalize_alert_pharma_settings(array_merge($out, $decoded), $con);
        }
    }
    return $out;
}

function pip_save_alert_pharma_settings($con, array $settings, $user = '') {
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    pip_ensure_settings_table($con);
    pip_alert_pharma_ensure_sp($con);
    $norm = pip_normalize_alert_pharma_settings($settings, $con);
    // เก็บค่าตามที่ผู้ใช้ตั้ง (ถ้า use defaults ไม่บังคับเก็บ keys ที่ sync แล้วก็ได้ แต่เก็บไว้เพื่อแสดง)
    $json = mysqli_real_escape_string($con, json_encode($norm, JSON_UNESCAPED_UNICODE));
    $user_esc = mysqli_real_escape_string($con, substr(trim((string)$user), 0, 64));
    $ok = @mysqli_query($con, "
        INSERT INTO tham_pip_settings (setting_key, setting_value, updated_at, updated_by)
        VALUES ('alert_pharma', '$json', NOW(), '$user_esc')
        ON DUPLICATE KEY UPDATE
            setting_value = VALUES(setting_value),
            updated_at = VALUES(updated_at),
            updated_by = VALUES(updated_by)
    ");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกตั้งค่า Alert Pharma ไม่สำเร็จ: ' . mysqli_error($con)];
    }
    return [
        'ok' => true,
        'settings' => $norm,
        'available_modules' => pip_alert_pharma_available_modules($con),
    ];
}

/**
 * คัดกรอง Alert Pharma ตาม HN (IPD) สำหรับ Patient IPD
 * @return array{ok:bool,has_alert:bool,alert_count:int,alerts:array,message:string,...}
 */
function pip_run_alert_pharma_screen($con, $hn, $an = '', array $settings = null) {
    $settings = $settings !== null ? pip_normalize_alert_pharma_settings($settings, $con) : pip_load_alert_pharma_settings($con);
    if (empty($settings['enabled'])) {
        return [
            'ok' => true,
            'skipped' => true,
            'has_alert' => false,
            'alert_count' => 0,
            'alerts' => [],
            'module_results' => [],
            'pass_count' => 0,
            'message' => 'ปิดโมดูล Alert Pharma ใน Patient IPD',
        ];
    }
    if (empty($settings['module_keys'])) {
        return [
            'ok' => true,
            'skipped' => true,
            'has_alert' => false,
            'alert_count' => 0,
            'alerts' => [],
            'module_results' => [],
            'pass_count' => 0,
            'message' => 'ยังไม่ได้เลือกโมดูลแจ้งเตือน',
        ];
    }
    if (!pip_alert_pharma_ensure_sp($con)) {
        return ['ok' => false, 'has_alert' => false, 'alert_count' => 0, 'alerts' => [], 'message' => 'โหลด Smart Pharma ไม่สำเร็จ'];
    }
    if (!function_exists('hosxp_connect')) {
        require_once __DIR__ . '/connect.php';
    }
    $hos = hosxp_connect($con);
    if (!$hos) {
        return ['ok' => false, 'has_alert' => false, 'alert_count' => 0, 'alerts' => [], 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'];
    }
    $screen_date = function_exists('sp_today_date') ? sp_today_date() : date('Y-m-d');
    $result = sp_run_screening_hn($con, $hos, 'IPD', $screen_date, $hn, '', $an, [
        'notify' => false,
        'module_keys' => $settings['module_keys'],
    ]);
    mysqli_close($hos);

    if (empty($result['ok'])) {
        // ไม่มียาสั่งวันนี้ / ไม่พบ admit → ไม่ถือเป็น error สำหรับ popup
        return [
            'ok' => true,
            'skipped' => true,
            'has_alert' => false,
            'alert_count' => 0,
            'alerts' => [],
            'module_results' => [],
            'pass_count' => 0,
            'message' => (string)($result['message'] ?? 'คัดกรองไม่สำเร็จ'),
            'screen_error' => (string)($result['message'] ?? ''),
        ];
    }

    $labels = [];
    foreach (($result['modules'] ?? []) as $m) {
        if (!is_array($m)) {
            continue;
        }
        $mk = trim((string)($m['key'] ?? ''));
        if ($mk !== '') {
            $labels[$mk] = (string)($m['label'] ?? $mk);
        }
    }
    $module_results = [];
    $pass_count = 0;
    $patMods = is_array($result['patient']['modules'] ?? null) ? $result['patient']['modules'] : [];
    foreach ($patMods as $mk => $mod) {
        if (!is_array($mod)) {
            continue;
        }
        $st = (string)($mod['status'] ?? 'na');
        if ($st === 'pass') {
            $pass_count++;
        }
        $module_results[] = [
            'module_key' => (string)$mk,
            'module_label' => $labels[$mk] ?? (string)$mk,
            'status' => $st,
            'level' => (string)($mod['level'] ?? ''),
            'summary' => (string)($mod['summary'] ?? ''),
        ];
    }

    return [
        'ok' => true,
        'skipped' => false,
        'has_alert' => !empty($result['has_alert']),
        'alert_count' => (int)($result['alert_count'] ?? 0),
        'alerts' => is_array($result['alerts'] ?? null) ? $result['alerts'] : [],
        'module_results' => $module_results,
        'pass_count' => $pass_count,
        'message' => (string)($result['message'] ?? ''),
        'patient' => $result['patient'] ?? null,
        'modules' => $result['modules'] ?? [],
        'settings' => $settings,
    ];
}

/**
 * ค่า Lab ที่แสดงบนแถบผู้ป่วย — ตั้งช่วงแจ้งเตือน / เปิด-ปิด / เพิ่ม-ลบได้
 * low/high = ขอบเขตปกติ (ว่าง = ไม่ตรวจด้านนั้น); แจ้งเตือนเมื่อค่า < low หรือ > high
 * eGFR ค่าเริ่มต้น low=60 → เตือนเมื่อ < 60
 */
function pip_default_lab_settings() {
    return [
        'labs' => [
            [
                'id' => 'egfr', 'label' => 'eGFR', 'show' => true, 'alert' => true,
                'low' => 60, 'high' => null,
                'match' => 'egfr,ckd-epi,ckd epi',
            ],
            [
                'id' => 'cr', 'label' => 'Cr', 'show' => true, 'alert' => true,
                'low' => 0.6, 'high' => 1.3,
                'match' => 'creatinine,creat,cr,ครีเอตินีน,ครีเอตินิน',
            ],
            [
                'id' => 'k', 'label' => 'K', 'show' => true, 'alert' => true,
                'low' => 3.5, 'high' => 5.0,
                'match' => 'potassium,k+,k,โพแทสเซียม',
            ],
            [
                'id' => 'na', 'label' => 'Na', 'show' => true, 'alert' => true,
                'low' => 135, 'high' => 145,
                'match' => 'sodium,na+,na,โซเดียม',
            ],
            [
                'id' => 'ast', 'label' => 'AST', 'show' => true, 'alert' => true,
                'low' => null, 'high' => 40,
                'match' => 'ast,sgot,aspartate',
            ],
            [
                'id' => 'alt', 'label' => 'ALT', 'show' => true, 'alert' => true,
                'low' => null, 'high' => 40,
                'match' => 'alt,sgpt,alanine',
            ],
            [
                'id' => 'inr', 'label' => 'INR', 'show' => true, 'alert' => true,
                'low' => 0.8, 'high' => 1.2,
                'match' => 'inr,international normalized',
            ],
            [
                'id' => 'bw', 'label' => 'BW', 'show' => true, 'alert' => false,
                'low' => null, 'high' => null,
                'match' => 'bw,body weight,น้ำหนัก',
                'source' => 'opdscreen',
            ],
            // CrCl ไม่ใช่ Lab ตั้งค่า — คำนวณ Cockcroft-Gault จาก Cr + BW + อายุ/เพศ เสมอ
        ],
    ];
}

function pip_lab_bound_or_null($v) {
    if ($v === null || $v === '') {
        return null;
    }
    if (is_string($v) && trim($v) === '') {
        return null;
    }
    if (!is_numeric($v)) {
        return null;
    }
    return (float)$v;
}

function pip_normalize_lab_item(array $raw, $idx = 0) {
    $id = preg_replace('/[^a-z0-9_]/i', '', (string)($raw['id'] ?? ''));
    if ($id === '') {
        $id = 'lab_' . ($idx + 1);
    }
    $id = strtolower(substr($id, 0, 40));
    $label = trim((string)($raw['label'] ?? $id));
    if ($label === '') {
        $label = strtoupper($id);
    }
    $match = trim((string)($raw['match'] ?? $label));
    if ($match === '') {
        $match = $label;
    }
    $source = strtolower(trim((string)($raw['source'] ?? '')));
    if ($source !== 'opdscreen') {
        $source = 'lab';
    }
    $cut = function ($s, $n) {
        if (function_exists('mb_substr')) {
            return mb_substr($s, 0, $n, 'UTF-8');
        }
        return substr($s, 0, $n);
    };
    return [
        'id' => $id,
        'label' => $cut($label, 40),
        'show' => !array_key_exists('show', $raw) || !empty($raw['show']),
        'alert' => !empty($raw['alert']),
        'low' => pip_lab_bound_or_null($raw['low'] ?? null),
        'high' => pip_lab_bound_or_null($raw['high'] ?? null),
        'match' => $cut($match, 200),
        'source' => $source,
    ];
}

function pip_normalize_lab_settings(array $raw) {
    $base = pip_default_lab_settings();
    $list = [];
    $seen = [];
    $src = isset($raw['labs']) && is_array($raw['labs']) ? $raw['labs'] : null;
    if ($src === null && isset($raw[0]) && is_array($raw[0])) {
        $src = $raw;
    }
    if (!is_array($src) || !$src) {
        return $base;
    }
    foreach ($src as $i => $item) {
        if (!is_array($item)) {
            continue;
        }
        $norm = pip_normalize_lab_item($item, (int)$i);
        // CrCl เป็นค่าคำนวณ ไม่เก็บในรายการ Lab ตั้งค่า
        if ($norm['id'] === 'crcl' || ($norm['source'] ?? '') === 'calc') {
            continue;
        }
        $key = $norm['id'];
        $n = 2;
        while (isset($seen[$key])) {
            $key = $norm['id'] . '_' . $n;
            $n++;
        }
        $norm['id'] = $key;
        $seen[$key] = true;
        $list[] = $norm;
        if (count($list) >= 40) {
            break;
        }
    }
    if (!$list) {
        return $base;
    }
    return ['labs' => $list];
}

function pip_load_lab_settings($con) {
    $out = pip_default_lab_settings();
    if (!$con) {
        return $out;
    }
    pip_ensure_settings_table($con);
    $q = @mysqli_query($con, "SELECT setting_value FROM tham_pip_settings WHERE setting_key='lab_strip' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $decoded = json_decode((string)($r['setting_value'] ?? ''), true);
        if (is_array($decoded)) {
            $out = pip_normalize_lab_settings($decoded);
        }
    }
    return $out;
}

/** อายุเป็นปีเต็ม (ใช้คำนวณ CrCl) */
function pip_age_years($birthday, $as_of = '') {
    $birthday = substr(trim((string)$birthday), 0, 10);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $birthday) || $birthday === '0000-00-00') {
        return 0;
    }
    $as_of = substr(trim((string)$as_of), 0, 10);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $as_of)) {
        $as_of = date('Y-m-d');
    }
    try {
        $from = new DateTime($birthday);
        $to = new DateTime($as_of);
        if ($to < $from) {
            return 0;
        }
        return max(0, (int)$from->diff($to)->y);
    } catch (Exception $e) {
        return 0;
    }
}

function pip_fmt_lab_date($iso) {
    $iso = substr(trim((string)$iso), 0, 10);
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $iso, $m) || $iso === '0000-00-00') {
        return '';
    }
    return sprintf('%02d/%02d/%04d', (int)$m[3], (int)$m[2], (int)$m[1]);
}

/**
 * Cockcroft-Gault CrCl (mL/min)
 * ชาย: ((140-age)×BW)/(72×SCr) · หญิง ×0.85
 * @return float|null
 */
function pip_calc_crcl($age, $sex, $weight, $scr) {
    $age = (float)$age;
    $weight = (float)$weight;
    $scr = (float)$scr;
    if ($age <= 0 || $age >= 140 || $weight <= 0 || $scr <= 0) {
        return null;
    }
    $gfr = ((140.0 - $age) * $weight) / (72.0 * $scr);
    $sex = strtoupper(trim((string)$sex));
    if ($sex === '2' || $sex === 'F' || $sex === 'หญิง' || $sex === 'FEMALE') {
        $gfr *= 0.85;
    }
    return round($gfr, 2);
}

/**
 * แนบ CrCl ลง labs strip เสมอ — Cockcroft-Gault จาก Cr(SCr) + BW + อายุ/เพศ
 * BW เลือกค่าล่าสุดระหว่าง HOSxP กับ THAM (dose_calculator_vitals)
 * วาง CrCl ต่อจาก eGFR
 */
function pip_attach_crcl_to_labs(array $labs, array $patient, array $labSettings = null, $as_of = '', $con = null) {
    $scr = '';
    $scrDate = '';
    $hosBw = '';
    $hosBwDate = '';
    foreach (($labs['items'] ?? []) as $it) {
        $id = (string)($it['id'] ?? '');
        if ($id === 'cr' || $id === 'scr') {
            $scr = (string)($it['value'] ?? '');
            $scrDate = (string)($it['date'] ?? '');
        } elseif ($id === 'bw') {
            $hosBw = (string)($it['value'] ?? '');
            $hosBwDate = (string)($it['date'] ?? '');
        }
    }
    if ($scr === '' && !empty($labs['cr'])) {
        $scr = (string)$labs['cr'];
    }
    if ($hosBw === '' && !empty($labs['bw'])) {
        $hosBw = (string)$labs['bw'];
    }
    if ($scrDate === '' && !empty($labs['cr_date'])) {
        $scrDate = (string)$labs['cr_date'];
    }
    if ($hosBwDate === '' && !empty($labs['bw_date'])) {
        $hosBwDate = (string)$labs['bw_date'];
    }

    $thamBw = 0.0;
    $thamAt = '';
    if ($con) {
        require_once __DIR__ . '/dose_calculator_helper.php';
        $saved = dc_get_vitals_override($con, $patient['hn'] ?? '');
        if ($saved && (float)($saved['bw'] ?? 0) > 0) {
            $thamBw = (float)$saved['bw'];
            $thamAt = (string)($saved['updated_at'] ?? '');
        }
    }
    $resolved = function_exists('dc_resolve_latest_bw')
        ? dc_resolve_latest_bw(pip_lab_parse_number($hosBw) ?: 0, $hosBwDate, $thamBw, $thamAt)
        : [
            'bw' => pip_lab_parse_number($hosBw),
            'date' => $hosBwDate,
            'datetime' => $hosBwDate,
            'source' => $hosBw !== '' ? 'hosxp' : '',
            'source_label' => $hosBw !== '' ? 'HOSxP' : '',
        ];

    $age = pip_age_years($patient['birthday'] ?? '', $as_of !== '' ? $as_of : date('Y-m-d'));
    $sex = (string)($patient['sex'] ?? '');
    $scrNum = pip_lab_parse_number($scr);
    $bwNum = isset($resolved['bw']) ? (float)$resolved['bw'] : 0.0;
    if ($bwNum <= 0) {
        $bwNum = 0.0;
    }
    $bwDate = (string)($resolved['date'] ?? '');
    $bwSource = (string)($resolved['source'] ?? '');
    $bwSourceLabel = (string)($resolved['source_label'] ?? '');
    $crcl = pip_calc_crcl($age, $sex, $bwNum, $scrNum);
    $missing = [];
    if ($age <= 0) {
        $missing[] = 'อายุ';
    }
    if ($scrNum === null || $scrNum <= 0) {
        $missing[] = 'SCr';
    }
    if ($bwNum <= 0) {
        $missing[] = 'BW';
    }

    $meta = [
        'formula' => 'cockcroft_gault',
        'age' => $age,
        'sex' => $sex,
        'sex_label' => (string)($patient['sex_label'] ?? ''),
        'scr' => $scrNum,
        'scr_raw' => $scr,
        'scr_date' => $scrDate,
        'scr_date_fmt' => pip_fmt_lab_date($scrDate),
        'bw' => $bwNum > 0 ? $bwNum : null,
        'bw_raw' => $bwNum > 0 ? (string)$bwNum : '',
        'bw_date' => $bwDate,
        'bw_date_fmt' => pip_fmt_lab_date($bwDate),
        'bw_source' => $bwSource,
        'bw_source_label' => $bwSourceLabel,
        'hosxp_bw' => pip_lab_parse_number($hosBw),
        'hosxp_bw_date' => $hosBwDate,
        'hosxp_bw_date_fmt' => pip_fmt_lab_date($hosBwDate),
        'tham_bw' => $thamBw > 0 ? $thamBw : null,
        'tham_bw_date' => $thamAt !== '' ? substr($thamAt, 0, 10) : '',
        'tham_bw_date_fmt' => $thamAt !== '' ? pip_fmt_lab_date(substr($thamAt, 0, 10)) : '',
        'crcl' => $crcl,
        'missing' => $missing,
        'editable' => true,
    ];
    $labs['crcl_meta'] = $meta;
    $labs['crcl'] = $crcl !== null ? (string)$crcl : '';
    if ($bwNum > 0) {
        $labs['bw'] = (string)$bwNum;
        $labs['bw_date'] = $bwDate;
        $labs['bw_source'] = $bwSource;
        $labs['bw_source_label'] = $bwSourceLabel;
    }

    $crclItem = [
        'id' => 'crcl',
        'label' => 'CrCl',
        'value' => $crcl !== null ? (string)$crcl : '—',
        'num' => $crcl,
        'alert' => false,
        'low' => null,
        'high' => null,
        'editable' => true,
        'incomplete' => $crcl === null,
        'date' => $scrDate !== '' ? $scrDate : $bwDate,
        'date_fmt' => pip_fmt_lab_date($scrDate !== '' ? $scrDate : $bwDate),
    ];
    $bwItem = null;
    if ($bwNum > 0) {
        $bwItem = [
            'id' => 'bw',
            'label' => 'BW',
            'value' => (string)$bwNum,
            'num' => $bwNum,
            'alert' => false,
            'low' => null,
            'high' => null,
            'date' => $bwDate,
            'date_fmt' => pip_fmt_lab_date($bwDate),
            'source' => $bwSource,
            'source_label' => $bwSourceLabel,
        ];
    }

    $items = [];
    $crclPlaced = false;
    $bwPlaced = false;
    foreach (($labs['items'] ?? []) as $it) {
        $id = (string)($it['id'] ?? '');
        if ($id === 'crcl') {
            continue;
        }
        if ($id === 'bw') {
            if ($bwItem) {
                $items[] = $bwItem;
                $bwPlaced = true;
            }
            continue;
        }
        $items[] = $it;
        if ($id === 'egfr') {
            $items[] = $crclItem;
            $crclPlaced = true;
        }
    }
    if (!$crclPlaced) {
        // ไม่มี eGFR — แทรกหลัง Cr ถ้ามี ไม่งั้นต้นรายการ
        $tmp = [];
        $done = false;
        foreach ($items as $it) {
            $tmp[] = $it;
            if (!$done && ($it['id'] ?? '') === 'cr') {
                $tmp[] = $crclItem;
                $done = true;
            }
        }
        if (!$done) {
            array_unshift($tmp, $crclItem);
        }
        $items = $tmp;
    }
    if (!$bwPlaced && $bwItem) {
        $items[] = $bwItem;
    }
    $labs['items'] = $items;
    return $labs;
}

function pip_save_lab_settings($con, array $settings, $user = '') {
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    pip_ensure_settings_table($con);
    $norm = pip_normalize_lab_settings($settings);
    $json = mysqli_real_escape_string($con, json_encode($norm, JSON_UNESCAPED_UNICODE));
    $user_esc = mysqli_real_escape_string($con, substr(trim((string)$user), 0, 64));
    $ok = @mysqli_query($con, "
        INSERT INTO tham_pip_settings (setting_key, setting_value, updated_at, updated_by)
        VALUES ('lab_strip', '$json', NOW(), '$user_esc')
        ON DUPLICATE KEY UPDATE
            setting_value = VALUES(setting_value),
            updated_at = VALUES(updated_at),
            updated_by = VALUES(updated_by)
    ");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกตั้งค่า Lab ไม่สำเร็จ: ' . mysqli_error($con)];
    }
    return ['ok' => true, 'lab_settings' => $norm];
}

/** ดึงตัวเลขจากผล lab เช่น "69.86", "4.50 mmol/L", "<0.1" */
function pip_lab_parse_number($val) {
    $s = trim((string)$val);
    if ($s === '') {
        return null;
    }
    $s = str_replace([',', ' '], ['', ''], $s);
    if (preg_match('/([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)/', $s, $m)) {
        return (float)$m[1];
    }
    return null;
}

function pip_lab_match_keywords($blob, $matchCsv) {
    $blob = strtolower(trim((string)$blob));
    if ($blob === '') {
        return false;
    }
    $parts = preg_split('/\s*,\s*/u', (string)$matchCsv);
    if (!$parts) {
        return false;
    }
    foreach ($parts as $kw) {
        $kw = strtolower(trim((string)$kw));
        if ($kw === '') {
            continue;
        }
        // คำสั้นมาก (เช่น na, k) ใช้ word-ish match กันชนชื่ออื่น
        if (strlen($kw) <= 2) {
            if (preg_match('/(?:^|[^a-z0-9])' . preg_quote($kw, '/') . '(?:[^a-z0-9]|$)/u', $blob)) {
                return true;
            }
            continue;
        }
        if (strpos($blob, $kw) !== false) {
            return true;
        }
    }
    return false;
}

function pip_lab_is_alert(array $def, $num) {
    if (empty($def['alert']) || $num === null) {
        return false;
    }
    $low = $def['low'];
    $high = $def['high'];
    if ($low !== null && $num < (float)$low) {
        return true;
    }
    if ($high !== null && $num > (float)$high) {
        return true;
    }
    return false;
}

function pip_lab_row_matches_def(array $def, $name, $code) {
    $id = strtolower((string)($def['id'] ?? ''));
    $blob = strtolower(trim($name . ' ' . $code));
    // กัน creatinine ไปชน egfr / clearance
    if ($id === 'cr' || preg_match('/\bcreat/i', (string)($def['match'] ?? ''))) {
        if (strpos($blob, 'egfr') !== false || strpos($blob, 'clearance') !== false || strpos($blob, 'crcl') !== false) {
            return false;
        }
    }
    if ($id === 'na') {
        // กันชื่อยา/คำอื่นที่มี na ซ้อน
        if (strpos($blob, 'inr') !== false || strpos($blob, 'name') !== false) {
            // ยังให้ผ่านถ้ามี sodium ชัดเจน
            if (strpos($blob, 'sodium') === false && strpos($blob, 'โซเดียม') === false
                && !preg_match('/(?:^|[^a-z0-9])na\+?(?:[^a-z0-9]|$)/u', $blob)) {
                return false;
            }
        }
    }
    return pip_lab_match_keywords($blob, $def['match'] ?? $def['label'] ?? '');
}

/** ความกว้างคอลัมน์ตารางรายการ Order (px) — ค่าเริ่มต้น */
function pip_default_order_col_widths() {
    return [
        'type' => 42,
        'date' => 78,
        'dispense' => 86,
        'dtime' => 78,
        'ward' => 96,
        'key' => 86,
        'ono' => 74,
        'rxnote' => 260,
    ];
}

function pip_normalize_order_col_widths($raw) {
    $base = pip_default_order_col_widths();
    if (!is_array($raw)) {
        return $base;
    }
    $out = $base;
    foreach ($base as $k => $def) {
        if (!isset($raw[$k])) {
            continue;
        }
        $w = (int)$raw[$k];
        if ($w < 36) {
            $w = 36;
        }
        if ($w > 520) {
            $w = 520;
        }
        $out[$k] = $w;
    }
    return $out;
}

function pip_ui_pref_setting_key($userId, $name) {
    $safe = preg_replace('/[^a-z0-9_]/i', '', (string)$name);
    if ($safe === '') {
        $safe = 'pref';
    }
    return 'ui_' . $safe . '_u' . (int)$userId;
}

function pip_load_user_ui_pref($con, $userId, $name) {
    if (!$con || (int)$userId <= 0) {
        return null;
    }
    pip_ensure_settings_table($con);
    $key = mysqli_real_escape_string($con, pip_ui_pref_setting_key($userId, $name));
    $q = @mysqli_query($con, "SELECT setting_value FROM tham_pip_settings WHERE setting_key='$key' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $decoded = json_decode((string)($r['setting_value'] ?? ''), true);
        if (is_array($decoded)) {
            return $decoded;
        }
    }
    return null;
}

function pip_save_user_ui_pref($con, $userId, $name, array $value, $by = '') {
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    $userId = (int)$userId;
    if ($userId <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบผู้ใช้'];
    }
    pip_ensure_settings_table($con);
    $key = mysqli_real_escape_string($con, pip_ui_pref_setting_key($userId, $name));
    $json = mysqli_real_escape_string($con, json_encode($value, JSON_UNESCAPED_UNICODE));
    $user_esc = mysqli_real_escape_string($con, substr(trim((string)$by), 0, 64));
    $ok = @mysqli_query($con, "
        INSERT INTO tham_pip_settings (setting_key, setting_value, updated_at, updated_by)
        VALUES ('$key', '$json', NOW(), '$user_esc')
        ON DUPLICATE KEY UPDATE
            setting_value = VALUES(setting_value),
            updated_at = VALUES(updated_at),
            updated_by = VALUES(updated_by)
    ");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกความกว้างคอลัมน์ไม่สำเร็จ: ' . mysqli_error($con)];
    }
    return ['ok' => true, 'value' => $value];
}

function pip_load_order_col_widths($con, $userId) {
    $saved = pip_load_user_ui_pref($con, $userId, 'order_cols');
    return pip_normalize_order_col_widths(is_array($saved) ? $saved : []);
}

function pip_save_order_col_widths($con, $userId, array $widths, $by = '') {
    $norm = pip_normalize_order_col_widths($widths);
    $res = pip_save_user_ui_pref($con, $userId, 'order_cols', $norm, $by);
    if (!empty($res['ok'])) {
        $res['widths'] = $norm;
    }
    return $res;
}

/** ความกว้างคอลัมน์ตารางยา Continuous/OFF/Oneday (px) — ค่าเริ่มต้น */
function pip_default_med_col_widths() {
    return [
        'num' => 36,
        'name' => 200,
        'usage' => 220,
        'qty' => 44,
        'interval' => 56,
        'per_dose' => 52,
        'per_day' => 52,
        'orderdate' => 78,
        'offdate' => 78,
        'freq' => 64,
        'paydays' => 90,
        'qty_day' => 72,
        'recorder' => 90,
        'off_staff' => 90,
        'pay' => 48,
        'return' => 48,
        'note' => 120,
        'first_upd' => 78,
        'last_upd' => 78,
        'order' => 90,
    ];
}

function pip_normalize_med_col_widths($raw) {
    $base = pip_default_med_col_widths();
    if (!is_array($raw)) {
        return $base;
    }
    $out = $base;
    foreach ($base as $k => $def) {
        if (!isset($raw[$k])) {
            continue;
        }
        $w = (int)$raw[$k];
        if ($w < 32) {
            $w = 32;
        }
        if ($w > 640) {
            $w = 640;
        }
        $out[$k] = $w;
    }
    return $out;
}

function pip_load_med_col_widths($con, $userId) {
    $saved = pip_load_user_ui_pref($con, $userId, 'med_cols');
    return pip_normalize_med_col_widths(is_array($saved) ? $saved : []);
}

function pip_save_med_col_widths($con, $userId, array $widths, $by = '') {
    $norm = pip_normalize_med_col_widths($widths);
    $res = pip_save_user_ui_pref($con, $userId, 'med_cols', $norm, $by);
    if (!empty($res['ok'])) {
        $res['widths'] = $norm;
    }
    return $res;
}

/** Layout แยก zone Patient IPD — left_pct = ความกว้างฝั่งซ้าย (% ของ stage) */
function pip_default_layout() {
    return [
        'left_pct' => 42,
        'orders_pct' => 48,
        'usage_code' => 0, // 0 = วิธีใช้แบบเต็ม (ค่าเริ่มต้น), 1 = แบบ code
        'open_dv_on_irx' => 1, // 1 = คลิก IRx/HME แล้วเปิด Drug Viewer (ต่อ user)
    ];
}

function pip_normalize_layout($raw) {
    $base = pip_default_layout();
    if (!is_array($raw)) {
        return $base;
    }
    $left = isset($raw['left_pct']) ? (float)$raw['left_pct'] : $base['left_pct'];
    if ($left < 22) {
        $left = 22;
    }
    if ($left > 72) {
        $left = 72;
    }
    $orders = isset($raw['orders_pct']) ? (float)$raw['orders_pct'] : $base['orders_pct'];
    if ($orders < 20) {
        $orders = 20;
    }
    if ($orders > 80) {
        $orders = 80;
    }
    // รองรับชื่อเก่าจาก day_ahead
    $openDv = $base['open_dv_on_irx'];
    if (array_key_exists('open_dv_on_irx', $raw)) {
        $openDv = !empty($raw['open_dv_on_irx']) ? 1 : 0;
    } elseif (array_key_exists('open_drug_viewer_on_irx', $raw)) {
        $openDv = !empty($raw['open_drug_viewer_on_irx']) ? 1 : 0;
    }
    return [
        'left_pct' => round($left, 1),
        'orders_pct' => round($orders, 1),
        'usage_code' => !empty($raw['usage_code']) ? 1 : 0,
        'open_dv_on_irx' => $openDv,
    ];
}

/** จัดรูปแบบตัวเลขจาก drugusage.iperdose / iperday */
function pip_fmt_usage_num($v) {
    $v = trim((string)$v);
    if ($v === '' || !is_numeric($v)) {
        return '';
    }
    $n = (float)$v;
    if (abs($n - round($n)) < 0.0001) {
        return (string)(int)round($n);
    }
    return rtrim(rtrim(number_format($n, 3, '.', ''), '0'), '.');
}

/** SQL ดึงวิธีใช้แบบ code / ต่อครั้ง / ต่อวัน จาก drugusage */
function pip_drugusage_extra_select($hos, $du = 'du') {
    $duCols = pop_cols($hos, 'drugusage') ?: [];
    $code = "''";
    if (pop_has($duCols, 'shortlist') && pop_has($duCols, 'code')) {
        $code = "IF(TRIM(IFNULL($du.shortlist,'')) <> '', $du.shortlist, IFNULL($du.code,''))";
    } elseif (pop_has($duCols, 'shortlist')) {
        $code = "IFNULL($du.shortlist,'')";
    } elseif (pop_has($duCols, 'code')) {
        $code = "IFNULL($du.code,'')";
    }
    $iperdose = pop_has($duCols, 'iperdose') ? "IFNULL($du.iperdose,'')" : "''";
    $ccperdose = pop_has($duCols, 'ccperdose') ? "IFNULL($du.ccperdose,'')" : "''";
    $iperday = pop_has($duCols, 'iperday') ? "IFNULL($du.iperday,'')" : "''";
    return [
        'usage_code' => pop_utf8($code) . ' AS usage_code',
        'iperdose' => "$iperdose AS iperdose",
        'ccperdose' => "$ccperdose AS ccperdose",
        'iperday' => "$iperday AS iperday",
    ];
}

function pip_usage_dose_fields(array $r) {
    $code = pop_clean($r['usage_code'] ?? '');
    $perDose = pip_fmt_usage_num($r['iperdose'] ?? '');
    if ($perDose === '') {
        $perDose = pip_fmt_usage_num($r['ccperdose'] ?? '');
    }
    return [
        'usage_code' => $code,
        'per_dose' => $perDose,
        'per_day' => pip_fmt_usage_num($r['iperday'] ?? ''),
    ];
}

function pip_load_layout($con, $userId) {
    $saved = pip_load_user_ui_pref($con, $userId, 'layout');
    return pip_normalize_layout(is_array($saved) ? $saved : []);
}

function pip_save_layout($con, $userId, array $layout, $by = '') {
    $norm = pip_normalize_layout($layout);
    $res = pip_save_user_ui_pref($con, $userId, 'layout', $norm, $by);
    if (!empty($res['ok'])) {
        $res['layout'] = $norm;
    }
    return $res;
}

/** Drug Viewer window UI — ซ่อนรายการซ้าย / ความกว้าง / ซูม ต่อ user */
function pip_default_drug_viewer_ui() {
    return [
        'list_collapsed' => 0,
        'list_width' => 280,
        'zoom' => 1,
    ];
}

function pip_normalize_drug_viewer_ui($raw) {
    $base = pip_default_drug_viewer_ui();
    if (!is_array($raw)) {
        return $base;
    }
    $w = isset($raw['list_width']) ? (int)$raw['list_width'] : $base['list_width'];
    if ($w < 180) {
        $w = 180;
    }
    if ($w > 480) {
        $w = 480;
    }
    $zoom = isset($raw['zoom']) ? (float)$raw['zoom'] : $base['zoom'];
    if ($zoom < 0.5) {
        $zoom = 0.5;
    }
    if ($zoom > 3) {
        $zoom = 3;
    }
    return [
        'list_collapsed' => !empty($raw['list_collapsed']) ? 1 : 0,
        'list_width' => $w,
        'zoom' => round($zoom, 2),
    ];
}

function pip_load_drug_viewer_ui($con, $userId) {
    $saved = pip_load_user_ui_pref($con, $userId, 'drug_viewer');
    return pip_normalize_drug_viewer_ui(is_array($saved) ? $saved : []);
}

function pip_save_drug_viewer_ui($con, $userId, array $ui, $by = '') {
    $norm = pip_normalize_drug_viewer_ui($ui);
    $res = pip_save_user_ui_pref($con, $userId, 'drug_viewer', $norm, $by);
    if (!empty($res['ok'])) {
        $res['ui'] = $norm;
    }
    return $res;
}

function pip_normalize_day_token($d) {
    $d = trim((string)$d);
    if ($d === 'พฤหัส') {
        return 'พฤหัสบดี';
    }
    return $d;
}

/** ขยายช่วงวันแบบ inclusive เช่น จันทร์→ศุกร์ = จันทร์..ศุกร์ */
function pip_expand_day_range($from, $to) {
    $names = pip_week_day_names();
    $idx = array_flip($names);
    $from = pip_normalize_day_token($from);
    $to = pip_normalize_day_token($to);
    if (!isset($idx[$from]) || !isset($idx[$to])) {
        return [];
    }
    $a = (int)$idx[$from];
    $b = (int)$idx[$to];
    $out = [];
    if ($a <= $b) {
        for ($i = $a; $i <= $b; $i++) {
            $out[] = $names[$i];
        }
    } else {
        // เช่น ศุกร์ ถึง จันทร์ → ศุกร์,เสาร์,อาทิตย์,จันทร์
        for ($i = $a; $i <= 6; $i++) {
            $out[] = $names[$i];
        }
        for ($i = 0; $i <= $b; $i++) {
            $out[] = $names[$i];
        }
    }
    return $out;
}

/**
 * ดึงวันให้ยาจากวิธีใช้
 * รองรับ:
 * - ทุกวันจันทร์ / เฉพาะวันพุธ / วันอาทิตย์
 * - ช่วงวัน: จันทร์ ถึง ศุกร์ / จันทร์-ศุกร์ / ทุกวันจันทร์ ถึง ศุกร์
 * - หลายวัน: จันทร์, พุธ / จันทร์ และ พุธ
 */
function pip_parse_usage_admin_days($usage) {
    $usage = trim((string)$usage);
    if ($usage === '') {
        return [];
    }
    $day = '(จันทร์|อังคาร|พุธ|พฤหัสบดี|พฤหัส|ศุกร์|เสาร์|อาทิตย์)';
    $found = [];

    // 1) ช่วงวัน: [ทุกวัน|เฉพาะวัน|วัน] จันทร์ ถึง [วัน] ศุกร์
    $rangePat = '/(?:เฉพาะ\s*วัน|ทุก\s*วัน|วัน)?\s*' . $day
        . '\s*(?:ถึง|-|–|—)\s*(?:วัน\s*)?' . $day . '/u';
    if (preg_match_all($rangePat, $usage, $rm, PREG_SET_ORDER)) {
        foreach ($rm as $m) {
            foreach (pip_expand_day_range($m[1], $m[2]) as $d) {
                $found[] = $d;
            }
        }
        // ตัดช่วงที่จับได้แล้ว กันซ้ำตอนหาวันเดี่ยว
        $usage = preg_replace($rangePat, ' ', $usage);
    }

    // 2) รายการหลายวันหลังคำว่า วัน/ทุกวัน/เฉพาะวัน เช่น วันจันทร์, พุธ และ ศุกร์
    $listPat = '/(?:เฉพาะ\s*วัน|ทุก\s*วัน|วัน)\s*' . $day
        . '((?:\s*(?:,|และ|กับ|\/)\s*(?:วัน\s*)?' . $day . ')+)/u';
    if (preg_match_all($listPat, $usage, $lm, PREG_SET_ORDER)) {
        foreach ($lm as $m) {
            $chunk = $m[0];
            if (preg_match_all('/' . $day . '/u', $chunk, $dm)) {
                foreach ($dm[1] as $d) {
                    $d = pip_normalize_day_token($d);
                    if ($d !== '') {
                        $found[] = $d;
                    }
                }
            }
        }
        $usage = preg_replace($listPat, ' ', $usage);
    }

    // 3) วันเดี่ยวที่เหลือ เช่น ทุกวันพุธ / เฉพาะวันจันทร์
    $singlePat = '/(?:เฉพาะ\s*วัน|ทุก\s*วัน|วัน)\s*' . $day . '/u';
    if (preg_match_all($singlePat, $usage, $sm)) {
        foreach ($sm[1] as $d) {
            $d = pip_normalize_day_token($d);
            if ($d !== '') {
                $found[] = $d;
            }
        }
    }

    // 4) สำรอง: มีชื่อวันหลายตัวคั่นด้วย , / และ โดยไม่มีคำนำหน้า (เช่น "จันทร์, พุธ")
    if (!$found) {
        $loose = '/(?:^|[^\p{L}])' . $day
            . '(?:\s*(?:,|และ|กับ|\/)\s*(?:วัน\s*)?' . $day . ')+/u';
        if (preg_match_all($loose, $usage, $xm, PREG_SET_ORDER)) {
            foreach ($xm as $m) {
                if (preg_match_all('/' . $day . '/u', $m[0], $dm)) {
                    foreach ($dm[1] as $d) {
                        $d = pip_normalize_day_token($d);
                        if ($d !== '') {
                            $found[] = $d;
                        }
                    }
                }
            }
        }
    }

    return pip_week_days_result(1, $found)['days_list'];
}

/** เลื่อนวันย้อนหลัง N วัน (จันทร์ -1 = อาทิตย์) — คงลำดับตามวันให้ยา */
function pip_shift_days_back(array $days, $lead_days) {
    $names = pip_week_day_names();
    $idx = array_flip($names);
    $lead = (int)$lead_days;
    if ($lead < 0) {
        $lead = 0;
    }
    $out = [];
    $seen = [];
    foreach ($days as $d) {
        $d = pip_normalize_day_token($d);
        if (!isset($idx[$d])) {
            continue;
        }
        $i = ((int)$idx[$d] - $lead) % 7;
        if ($i < 0) {
            $i += 7;
        }
        $name = $names[$i];
        if (isset($seen[$name])) {
            continue;
        }
        $seen[$name] = 1;
        $out[] = $name;
    }
    return $out;
}

function pip_days_set_key(array $days) {
    $names = pip_week_day_names();
    $days = array_values(array_unique(array_filter($days)));
    usort($days, static function ($a, $b) use ($names) {
        return array_search($a, $names, true) <=> array_search($b, $names, true);
    });
    return implode(',', $days);
}

/**
 * ตรวจยา Continuous ที่สั่งตามวัน — ตั้งจ่ายล่วงหน้า หรือตรงวัน (ข้อยกเว้น)
 * @return array{alerts: array, settings: array}
 */
function pip_detect_day_ahead_alerts(array $meds, array $settings) {
    $settings = pip_normalize_day_ahead_settings($settings);
    if (empty($settings['enabled'])) {
        return ['alerts' => [], 'settings' => $settings];
    }
    $lead = (int)$settings['lead_days'];
    $alerts = [];
    foreach ($meds as $it) {
        if (!empty($settings['only_active']) && !empty($it['is_off'])) {
            continue;
        }
        $usage = (string)($it['usage'] ?? '');
        $admin = [];
        if (!empty($settings['parse_usage'])) {
            $admin = pip_parse_usage_admin_days($usage);
        }
        if (!$admin) {
            continue; // ไม่ใช่ยาสั่งตามวันในวิธีใช้ — เงื่อนไขเดิมก่อน
        }
        // ข้อยกเว้น: ตั้งจ่ายตรงวัน (ไม่เลื่อน) เช่น warfarin / วิธีใช้มีคำว่าก่อนนอน
        $exact = pip_is_exact_day_dispense($it, $settings, $admin);
        $expected = $exact ? $admin : pip_shift_days_back($admin, $lead);
        $actual = [];
        if (strtoupper((string)($it['week_day_check'] ?? '')) === 'Y') {
            $actual = is_array($it['dispense_days_list'] ?? null) ? $it['dispense_days_list'] : [];
            if (!$actual && !empty($it['dispense_days'])) {
                $parts = preg_split('/\s*,\s*/u', (string)$it['dispense_days']);
                $actual = is_array($parts) ? array_values(array_filter(array_map('trim', $parts))) : [];
            }
        }
        $expKey = pip_days_set_key($expected);
        $actKey = pip_days_set_key($actual);
        $reason = '';
        $msg = '';
        if ($actKey === '') {
            if (empty($settings['alert_if_missing'])) {
                continue;
            }
            $reason = 'missing';
            if ($exact) {
                $msg = 'ยังไม่ได้ตั้ง จ่ายวัน — รายการนี้ตั้งตรงวันให้ยา ('
                    . implode(', ', $expected) . ')';
            } else {
                $msg = 'ยังไม่ได้ตั้ง จ่ายวัน — ควรตั้งเป็นวันก่อนให้ยา '
                    . $lead . ' วัน (' . implode(', ', $expected) . ')';
            }
        } elseif ($actKey !== $expKey) {
            if (empty($settings['alert_if_mismatch'])) {
                continue;
            }
            $reason = 'mismatch';
            if ($exact) {
                $msg = 'จ่ายวันไม่ตรงกับวันให้ยา (ตั้งตรงวัน) '
                    . '(คาดหวัง: ' . implode(', ', $expected)
                    . ' / ที่ตั้ง: ' . implode(', ', $actual) . ')';
            } else {
                $msg = 'จ่ายวันไม่ตรงกับวันออกยาก่อนล่วงหน้า '
                    . $lead . ' วัน (คาดหวัง: ' . implode(', ', $expected)
                    . ' / ที่ตั้ง: ' . implode(', ', $actual) . ')';
            }
        } else {
            continue; // ถูกต้อง
        }
        $alerts[] = [
            'med_plan_number' => (int)($it['med_plan_number'] ?? 0),
            'icode' => (string)($it['icode'] ?? ''),
            'name' => (string)($it['name'] ?? ''),
            'usage' => $usage,
            'admin_days' => implode(', ', $admin),
            'expected_dispense_days' => implode(', ', $expected),
            'actual_dispense_days' => implode(', ', $actual),
            'lead_days' => $exact ? 0 : $lead,
            'exact_day' => $exact,
            'mode' => $exact ? 'exact' : 'ahead',
            'reason' => $reason,
            'message' => $msg,
        ];
    }
    return ['alerts' => $alerts, 'settings' => $settings];
}

/**
 * ดึงวันจ่ายจาก medplan_ipd_week_day
 * week_day_id: 0=จันทร์ … 6=อาทิตย์ (ตามที่ PharMS/HOSxP ใช้)
 * @return array<int, string[]> med_plan_number => ['อาทิตย์', ...]
 */
function pip_fetch_medplan_week_days_map($hos, $an) {
    $an = trim((string)$an);
    if ($an === '' || !$hos) {
        return [];
    }
    $wcols = pop_cols($hos, 'medplan_ipd_week_day');
    if (!$wcols || !pop_has($wcols, 'med_plan_number') || !pop_has($wcols, 'week_day_id')) {
        return [];
    }
    $an_esc = mysqli_real_escape_string($hos, $an);
    $names = ['จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์', 'อาทิตย์'];
    $rows = pop_query_all($hos, "
        SELECT w.med_plan_number, w.week_day_id
        FROM medplan_ipd_week_day w
        INNER JOIN medplan_ipd m ON m.med_plan_number = w.med_plan_number
        WHERE m.an = '$an_esc'
        ORDER BY w.med_plan_number, w.week_day_id
        LIMIT 5000
    ");
    $map = [];
    foreach ($rows as $r) {
        $mpn = (int)($r['med_plan_number'] ?? 0);
        $id = (int)($r['week_day_id'] ?? -1);
        if ($mpn <= 0 || $id < 0 || $id > 6) {
            continue;
        }
        if (!isset($map[$mpn])) {
            $map[$mpn] = [];
        }
        $map[$mpn][$id] = $names[$id];
    }
    foreach ($map as $mpn => $days) {
        ksort($days);
        $map[$mpn] = array_values($days);
    }
    return $map;
}

/** สร้างผลจ่ายวันจากรายชื่อวันไทย */
function pip_week_days_result($enabled, array $found) {
    $names = ['จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์', 'อาทิตย์'];
    $found = array_values(array_unique(array_filter($found)));
    usort($found, static function ($a, $b) use ($names) {
        return array_search($a, $names, true) <=> array_search($b, $names, true);
    });
    return [
        'enabled' => $enabled ? 1 : 0,
        'days' => implode(', ', $found),
        'days_list' => $found,
    ];
}

/** แปลง week_day_list จาก HOSxP → ชื่อวันไทย เช่น จันทร์,พุธ */
function pip_parse_week_days($week_day_check, $week_day_list, array $ids_days = []) {
    $chk = strtoupper(trim((string)$week_day_check));
    if ($chk !== 'Y' && $chk !== '1') {
        return ['enabled' => 0, 'days' => '', 'days_list' => []];
    }
    // แหล่งหลักของ HOSxP ใหม่: ตาราง medplan_ipd_week_day (week_day_list มักว่าง)
    if (!empty($ids_days)) {
        return pip_week_days_result(1, $ids_days);
    }
    $raw = trim((string)$week_day_list);
    $names = ['จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์', 'อาทิตย์'];
    $short = ['จ', 'อ', 'พ', 'พฤ', 'ศ', 'ส', 'อา'];
    $eng = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
    $found = [];

    if ($raw === '') {
        return ['enabled' => 1, 'days' => '', 'days_list' => []];
    }

    // รูปแบบ YNYNYNN / 1010101 (ตำแหน่ง 0=จันทร์ ... 6=อาทิตย์)
    if (preg_match('/^[YN01]{7}$/i', $raw)) {
        for ($i = 0; $i < 7; $i++) {
            $ch = strtoupper($raw[$i]);
            if ($ch === 'Y' || $ch === '1') {
                $found[] = $names[$i];
            }
        }
    } else {
        // แยกด้วย comma / | / ; / space
        $parts = preg_split('/[,|;\s\/]+/u', $raw, -1, PREG_SPLIT_NO_EMPTY);
        foreach ($parts as $p) {
            $p = trim((string)$p);
            if ($p === '') {
                continue;
            }
            $pl = function_exists('mb_strtolower') ? mb_strtolower($p, 'UTF-8') : strtolower($p);
            // ตัวเลข 1-7
            if (preg_match('/^[1-7]$/', $p)) {
                $found[] = $names[((int)$p - 1)];
                continue;
            }
            // 0-6
            if (preg_match('/^[0-6]$/', $p)) {
                $found[] = $names[(int)$p];
                continue;
            }
            foreach ($names as $i => $th) {
                $thl = function_exists('mb_strtolower') ? mb_strtolower($th, 'UTF-8') : strtolower($th);
                if ($pl === $thl || $pl === $short[$i] || $pl === $eng[$i]
                    || strpos($pl, $thl) === 0 || strpos($thl, $pl) === 0) {
                    $found[] = $th;
                    break;
                }
            }
            // พฤหัส แบบย่อ
            if ($pl === 'พฤหัส' || $pl === 'พฤ.') {
                $found[] = 'พฤหัสบดี';
            }
        }
    }

    return pip_week_days_result(1, $found);
}

function pip_fetch_medplan($hos, $an) {
    $an = trim((string)$an);
    if ($an === '') {
        return ['active' => [], 'off' => [], 'all' => []];
    }
    $an_esc = mysqli_real_escape_string($hos, $an);
    $mcols = pop_cols($hos, 'medplan_ipd');
    if (!$mcols) {
        return ['active' => [], 'off' => [], 'all' => []];
    }
    $dcols = pop_cols($hos, 'drugitems');
    $dosage = pop_has($dcols, 'dosageform') ? pop_utf8('d.dosageform') : "''";
    $method = pip_medplan_method_expr('m', 'du', 'sp');
    $off_time = pip_col_expr($mcols, 'm', ['off_time', 'offtime'], "''");
    $orderstatus = pip_col_expr($mcols, 'm', ['orderstatus', 'order_status'], "''");
    $med_no = pop_has($mcols, 'med_plan_number') ? 'm.med_plan_number' : '0';
    // ผู้ Key / ผู้บันทึก จาก staff ใน HOSxP
    $staff_code = pip_col_expr($mcols, 'm', ['staff', 'officer', 'entry_staff'], "''");
    $off_staff = pip_col_expr($mcols, 'm', ['off_staff', 'offstaff', 'stop_staff', 'staff_off'], $staff_code);
    $doctor_code = pip_col_expr($mcols, 'm', ['doctor', 'order_doctor'], "''");
    // F = ให้ทุกกี่วัน
    $freq = pop_has($mcols, 'frequency') ? 'm.frequency' : "''";
    $week_chk = pop_has($mcols, 'week_day_check') ? 'm.week_day_check' : "''";
    $week_list = pop_has($mcols, 'week_day_list') ? 'm.week_day_list' : "''";
    $qty_day = pip_col_expr($mcols, 'm', ['qty_day', 'day_qty', 'perday', 'qty_per_day', 'first_qty'], 'm.qty');
    $note_sql = pop_has($mcols, 'note') ? 'm.note' : "''";
    $first_upd = pop_has($mcols, 'first_update') ? 'm.first_update' : (pop_has($mcols, 'update_datetime') ? 'm.update_datetime' : "''");
    $last_upd = pop_has($mcols, 'last_update') ? 'm.last_update' : (pop_has($mcols, 'update_datetime') ? 'm.update_datetime' : "''");

    // จ่าย = รวม qty จาก opitemrece_medplan / คืน = รวม return_qty จาก medreturn_ipd
    $omCols = pop_cols($hos, 'opitemrece_medplan');
    $mrCols = pop_cols($hos, 'medreturn_ipd');
    $payJoin = '';
    $paySelect = '0 AS pay_qty';
    if ($omCols && pop_has($omCols, 'med_plan_number') && pop_has($omCols, 'qty')) {
        $paySelect = 'IFNULL(pay.pay_qty, 0) AS pay_qty';
        $payJoin = "LEFT JOIN (
            SELECT med_plan_number, SUM(IFNULL(qty,0)) AS pay_qty
            FROM opitemrece_medplan
            WHERE an = '$an_esc'
            GROUP BY med_plan_number
        ) pay ON pay.med_plan_number = $med_no";
    }
    $retJoin = '';
    $retSelect = '0 AS return_qty';
    if ($mrCols && pop_has($mrCols, 'med_plan_number') && pop_has($mrCols, 'return_qty')) {
        $retSelect = 'IFNULL(ret.return_qty, 0) AS return_qty';
        $retJoin = "LEFT JOIN (
            SELECT med_plan_number, SUM(IFNULL(return_qty,0)) AS return_qty
            FROM medreturn_ipd
            WHERE an = '$an_esc'
            GROUP BY med_plan_number
        ) ret ON ret.med_plan_number = $med_no";
    }

    $irxByDate = pip_irx_key_by_date($hos, $an);
    $weekDaysMap = pip_fetch_medplan_week_days_map($hos, $an);
    $duExtra = pip_drugusage_extra_select($hos, 'du');

    $rows = pop_query_all($hos, "
        SELECT $med_no AS med_plan_number, m.icode, m.qty, m.orderdate, m.offdate,
               $off_time AS off_time,
               $orderstatus AS orderstatus,
               $doctor_code AS doctor_code,
               $staff_code AS staff_code,
               $off_staff AS off_staff_code,
               $freq AS frequency,
               $week_chk AS week_day_check,
               $week_list AS week_day_list,
               $qty_day AS qty_day,
               $note_sql AS note,
               $first_upd AS first_update,
               $last_upd AS last_update,
               $paySelect,
               $retSelect,
               " . pop_utf8('d.name') . " AS drug_name,
               " . pop_utf8('d.strength') . " AS strength,
               " . pop_utf8('d.units') . " AS units,
               $dosage AS dosageform,
               $method AS usage_text,
               {$duExtra['usage_code']},
               {$duExtra['iperdose']},
               {$duExtra['ccperdose']},
               {$duExtra['iperday']},
               " . pop_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . " AS doctor_name,
               " . pop_utf8('IFNULL(NULLIF(ou.name,\'\'), \'\')') . " AS staff_name,
               " . pop_utf8('IFNULL(ou_off.name, IFNULL(doc_off.name, \'\'))') . " AS off_staff_name
        FROM medplan_ipd m
        INNER JOIN drugitems d ON d.icode = m.icode
        LEFT JOIN drugusage du ON du.drugusage = m.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = m.sp_use
        LEFT JOIN doctor doc ON doc.code = $doctor_code
        LEFT JOIN opduser ou ON ou.loginname = $staff_code
        LEFT JOIN opduser ou_off ON ou_off.loginname = $off_staff
        LEFT JOIN doctor doc_off ON doc_off.code = $off_staff
        $payJoin
        $retJoin
        WHERE m.an = '$an_esc'
        ORDER BY m.orderdate DESC, $med_no DESC
        LIMIT 800
    ");
    $all = [];
    $active = [];
    $off = [];
    foreach ($rows as $i => $r) {
        $name = pip_drug_label($r['drug_name'] ?? '', $r['strength'] ?? '', $r['units'] ?? '');
        $orderdate = substr(trim((string)($r['orderdate'] ?? '')), 0, 10);
        if ($orderdate === '0000-00-00') {
            $orderdate = '';
        }
        $offdate = substr(trim((string)($r['offdate'] ?? '')), 0, 10);
        if ($offdate === '0000-00-00') {
            $offdate = '';
        }
        // ตั้ง off ล่วงหน้า → ยัง Active จนกว่าจะเลยวันที่ off
        $isOff = pip_med_is_effectively_off($offdate);
        $usage = pop_clean($r['usage_text'] ?? '');
        $interval = pip_extract_interval($usage);
        $freqVal = trim((string)($r['frequency'] ?? ''));
        if ($freqVal === '' || !is_numeric($freqVal)) {
            $fDays = '';
            $fDisplay = '';
        } else {
            $fDays = pop_num($freqVal);
            $fDisplay = $fDays; // F = ให้ทุกกี่วัน (ตัวเลข)
        }
        $mpn = (int)($r['med_plan_number'] ?? 0);
        $week = pip_parse_week_days(
            $r['week_day_check'] ?? '',
            $r['week_day_list'] ?? '',
            $weekDaysMap[$mpn] ?? []
        );
        $staffName = pop_clean($r['staff_name'] ?? '');
        $staffCode = trim((string)($r['staff_code'] ?? ''));
        $doctorName = pop_clean($r['doctor_name'] ?? '');
        $offStaffName = pop_clean($r['off_staff_name'] ?? '');
        $offStaffCode = trim((string)($r['off_staff_code'] ?? ''));
        $firstUpdate = trim((string)($r['first_update'] ?? ''));
        $lastUpdate = trim((string)($r['last_update'] ?? ''));
        if (strpos($firstUpdate, '0000-00-00') === 0) {
            $firstUpdate = '';
        }
        if (strpos($lastUpdate, '0000-00-00') === 0) {
            $lastUpdate = '';
        }
        // ผู้บันทึก = medplan.staff → ถ้าว่าง ใช้ผู้ Key ของ IRx ในวันที่ Last update (แล้วลอง first_update)
        $keyName = $staffName !== '' ? $staffName : '';
        $keyCode = $staffCode;
        $recorderSrc = $keyName !== '' ? 'staff' : '';
        if ($keyName === '') {
            $lastDay = substr($lastUpdate, 0, 10);
            $firstDay = substr($firstUpdate, 0, 10);
            $irx = null;
            if ($lastDay !== '' && isset($irxByDate[$lastDay])) {
                $irx = $irxByDate[$lastDay];
                $recorderSrc = 'irx_last_update';
            } elseif ($firstDay !== '' && isset($irxByDate[$firstDay])) {
                $irx = $irxByDate[$firstDay];
                $recorderSrc = 'irx_first_update';
            }
            if ($irx) {
                $keyCode = $irx['code'];
                $keyName = $irx['name'];
            } else {
                $keyName = $staffCode; // เหลือรหัสถ้ามี
            }
        }
        $stopper = $offStaffName !== '' ? $offStaffName : ($offStaffCode !== '' ? $offStaffCode : '');
        $isInj = pip_is_injection($name, $r['units'] ?? '', $r['dosageform'] ?? '');
        $isTabCap = pip_is_tab_cap($name, $r['units'] ?? '', $r['dosageform'] ?? '');
        $doseFields = pip_usage_dose_fields($r);
        $qtyVal = pop_num($r['qty'] ?? '0');
        $robotMiss = $isTabCap
            && !pip_med_qty_is_zero($qtyVal)
            && ($doseFields['per_dose'] === '' || $doseFields['per_day'] === '');
        $item = [
            'seq' => $i + 1,
            'med_plan_number' => (int)($r['med_plan_number'] ?? 0),
            'icode' => trim((string)($r['icode'] ?? '')),
            'name' => $name,
            'qty' => $qtyVal,
            'qty_day' => pop_num($r['qty_day'] ?? ($r['qty'] ?? '0')),
            'pay_qty' => pop_num($r['pay_qty'] ?? '0'),
            'return_qty' => pop_num($r['return_qty'] ?? '0'),
            'note' => pop_clean($r['note'] ?? ''),
            'usage' => $usage,
            'usage_code' => $doseFields['usage_code'],
            'per_dose' => $doseFields['per_dose'],
            'per_day' => $doseFields['per_day'],
            'is_tab_cap' => $isTabCap ? 1 : 0,
            'robot_missing' => $robotMiss ? 1 : 0,
            'interval' => $interval,
            'orderdate' => $orderdate,
            'orderdate_th' => pop_fmt_date_th($orderdate),
            'orderdate_dmy' => pip_fmt_date_dmy($orderdate),
            'offdate' => $offdate,
            'offdate_th' => pop_fmt_date_th($offdate),
            'offdate_dmy' => pip_fmt_date_dmy($offdate),
            'off_time' => pop_fmt_time($r['off_time'] ?? ''),
            'orderstatus' => trim((string)($r['orderstatus'] ?? '')),
            'f_days' => $fDays,
            'f_flag' => $fDisplay,
            'frequency' => $fDays,
            'week_day_check' => !empty($week['enabled']) ? 'Y' : 'N',
            'week_day_list' => trim((string)($r['week_day_list'] ?? '')),
            'dispense_days' => $week['days'],
            'dispense_days_list' => $week['days_list'],
            'doctor_name' => $doctorName,
            'staff_code' => $staffCode,
            'staff_name' => $keyName,
            'key_staff' => $keyCode,
            'key_staff_name' => $keyName,
            'recorder' => $keyName,
            'recorder_source' => $recorderSrc,
            'off_staff_code' => $offStaffCode,
            'off_staff_name' => $stopper,
            'first_update' => $firstUpdate,
            'first_update_dmy' => pip_fmt_datetime_dmy($firstUpdate),
            'last_update' => $lastUpdate,
            'last_update_dmy' => pip_fmt_datetime_dmy($lastUpdate),
            'is_injection' => $isInj ? 1 : 0,
            'is_off' => $isOff ? 1 : 0,
            'group' => $isInj ? 'injection' : 'other',
        ];
        $all[] = $item;
        if ($isOff) {
            $off[] = $item;
        } else {
            $active[] = $item;
        }
    }
    foreach ([&$active, &$off, &$all] as &$list) {
        $n = 0;
        foreach ($list as &$it) {
            $n++;
            $it['seq'] = $n;
        }
        unset($it);
    }
    unset($list);
    return ['active' => $active, 'off' => $off, 'all' => $all];
}

/**
 * แล็บสำคัญบนแถบผู้ป่วย — ตาม lab_settings (แสดง/เตือน/ช่วงค่า/เพิ่ม-ลบได้)
 * คืนค่า: items[] + คีย์เดิม egfr/cr/k/... เพื่อความเข้ากันได้
 */
function pip_fetch_lab_strip($hos, $hn, $labSettings = null) {
    if (!is_array($labSettings)) {
        $labSettings = pip_default_lab_settings();
    } else {
        $labSettings = pip_normalize_lab_settings($labSettings);
    }
    $defs = $labSettings['labs'] ?? [];
    $values = []; // id => raw string value
    $dates = [];  // id => Y-m-d
    $out = ['items' => []];
    foreach ($defs as $d) {
        if (($d['source'] ?? '') === 'calc') {
            continue;
        }
        $out[$d['id']] = '';
    }

    $in = pop_hn_in($hos, $hn);
    if ($in === '') {
        return $out;
    }

    // CrCl คำนวณเสมอ → ดึง Cr + BW เสมอ (แม้ปิดแสดง BW บนแถบ)
    $needLab = true;
    $needBw = true;
    $needCrcl = true;
    foreach ($defs as $d) {
        if (($d['source'] ?? 'lab') === 'calc' || ($d['id'] ?? '') === 'crcl') {
            continue;
        }
        if (!empty($d['show']) || !empty($d['alert']) || in_array(($d['id'] ?? ''), ['cr', 'bw'], true)) {
            if (($d['source'] ?? 'lab') === 'opdscreen' || $d['id'] === 'bw') {
                $needBw = true;
            } else {
                $needLab = true;
            }
        }
    }

    if ($needLab) {
        $hcols = pop_cols($hos, 'lab_head');
        $ocols = pop_cols($hos, 'lab_order');
        if ($hcols && $ocols) {
            $name_expr = pop_has($ocols, 'lab_items_name_ref')
                ? pop_utf8('IFNULL(NULLIF(o.lab_items_name_ref,\'\'), IFNULL(i.lab_items_name,\'\'))')
                : pop_utf8('IFNULL(i.lab_items_name, \'\')');
            $result_expr = pop_has($ocols, 'lab_order_result')
                ? pop_utf8('o.lab_order_result')
                : "''";
            $date_expr = pop_has($hcols, 'report_date') ? 'h.report_date' : (pop_has($hcols, 'order_date') ? 'h.order_date' : "''");
            $rows = pop_query_all($hos, "
                SELECT $name_expr AS lab_name, $result_expr AS result, o.lab_items_code AS code,
                       $date_expr AS report_date
                FROM lab_head h
                INNER JOIN lab_order o ON o.lab_order_number = h.lab_order_number
                LEFT JOIN lab_items i ON i.lab_items_code = o.lab_items_code
                WHERE h.hn IN ($in)
                  AND o.lab_order_result IS NOT NULL
                  AND TRIM(o.lab_order_result) <> ''
                ORDER BY h.report_date DESC, h.report_time DESC, h.order_date DESC
                LIMIT 200
            ");
            $pending = [];
            $matchDefs = [];
            foreach ($defs as $d) {
                if (($d['source'] ?? 'lab') === 'opdscreen' || ($d['source'] ?? '') === 'calc') {
                    continue;
                }
                $pending[$d['id']] = true;
                $matchDefs[] = $d;
            }
            // ถ้าไม่มีแถว Cr ใน settings แต่ต้องคำนวณ CrCl — ใช้คำค้นเริ่มต้นของ Cr (ไม่บังคับแสดง)
            if (empty($pending['cr']) && $needCrcl) {
                foreach (pip_default_lab_settings()['labs'] as $d0) {
                    if (($d0['id'] ?? '') === 'cr') {
                        $pending['cr'] = true;
                        $matchDefs[] = pip_normalize_lab_item($d0, count($matchDefs));
                        break;
                    }
                }
            }
            foreach ($rows as $r) {
                if (!$pending) {
                    break;
                }
                $name = pop_clean($r['lab_name'] ?? '');
                $code = trim((string)($r['code'] ?? ''));
                $val = pop_clean($r['result'] ?? '');
                if ($val === '') {
                    continue;
                }
                $rd = substr(trim((string)($r['report_date'] ?? '')), 0, 10);
                if ($rd === '0000-00-00') {
                    $rd = '';
                }
                foreach ($matchDefs as $d) {
                    $id = $d['id'];
                    if (empty($pending[$id])) {
                        continue;
                    }
                    if (pip_lab_row_matches_def($d, $name, $code)) {
                        $values[$id] = $val;
                        if ($rd !== '') {
                            $dates[$id] = $rd;
                        }
                        unset($pending[$id]);
                    }
                }
            }
        }
    }

    if ($needBw) {
        $scols = pop_cols($hos, 'opdscreen');
        if (pop_has($scols, 'bw')) {
            $r = pop_query_one($hos, "
                SELECT bw, vstdate FROM opdscreen
                WHERE hn IN ($in) AND bw IS NOT NULL AND bw > 0
                ORDER BY vstdate DESC, vsttime DESC LIMIT 1
            ");
            if ($r && (float)($r['bw'] ?? 0) > 0) {
                $bwVal = pop_num($r['bw']);
                $bwDate = substr(trim((string)($r['vstdate'] ?? '')), 0, 10);
                if ($bwDate === '0000-00-00') {
                    $bwDate = '';
                }
                foreach ($defs as $d) {
                    if (($d['source'] ?? '') === 'opdscreen' || $d['id'] === 'bw') {
                        if (!isset($values[$d['id']])) {
                            $values[$d['id']] = $bwVal;
                            if ($bwDate !== '') {
                                $dates[$d['id']] = $bwDate;
                            }
                        }
                    }
                }
                if (!isset($values['bw'])) {
                    $values['bw'] = $bwVal;
                    if ($bwDate !== '') {
                        $dates['bw'] = $bwDate;
                    }
                }
            }
        }
    }

    foreach ($defs as $d) {
        if (($d['source'] ?? '') === 'calc') {
            continue;
        }
        $id = $d['id'];
        $raw = isset($values[$id]) ? (string)$values[$id] : '';
        $out[$id] = $raw;
        $dt = isset($dates[$id]) ? (string)$dates[$id] : '';
        if ($id === 'cr' || $id === 'scr') {
            $out['cr_date'] = $dt;
        }
        if ($id === 'bw') {
            $out['bw_date'] = $dt;
        }
        if (empty($d['show']) || $raw === '') {
            continue;
        }
        $num = pip_lab_parse_number($raw);
        $alert = pip_lab_is_alert($d, $num);
        $out['items'][] = [
            'id' => $id,
            'label' => $d['label'],
            'value' => $raw,
            'num' => $num,
            'alert' => $alert,
            'low' => $d['low'],
            'high' => $d['high'],
            'date' => $dt,
            'date_fmt' => pip_fmt_lab_date($dt),
        ];
    }
    // เก็บค่าดิบ Cr/BW เสมอ — เพื่อคำนวณ CrCl (แม้ปิดแสดงบนแถบ)
    if (isset($values['cr']) && (string)$values['cr'] !== '') {
        $out['cr'] = (string)$values['cr'];
        $out['cr_date'] = (string)($dates['cr'] ?? ($out['cr_date'] ?? ''));
    }
    if (isset($values['bw']) && (string)$values['bw'] !== '') {
        $out['bw'] = (string)$values['bw'];
        $out['bw_date'] = (string)($dates['bw'] ?? ($out['bw_date'] ?? ''));
    }
    return $out;
}

function pip_fetch_oneday($hos, $an, array $orders) {
    $an = trim((string)$an);
    if ($an === '') {
        return [];
    }
    $an_esc = mysqli_real_escape_string($hos, $an);
    $oneday_nos = [];
    foreach ($orders as $o) {
        if (pip_is_oneday_order_type($o['order_type_raw'] ?? '')) {
            $oneday_nos[] = "'" . mysqli_real_escape_string($hos, $o['order_no']) . "'";
        }
    }
    $ocols = pop_cols($hos, 'opitemrece');
    $dcols = pop_cols($hos, 'drugitems');
    $dosage = pop_has($dcols, 'dosageform') ? pop_utf8('d.dosageform') : "''";
    $method = pip_method_expr('o', 'du', 'sp');
    $where_extra = '';
    if ($oneday_nos) {
        $where_extra = " AND o.order_no IN (" . implode(',', $oneday_nos) . ")";
    } else {
        // fallback: รายการที่ไม่ได้อยู่ใน medplan และไม่ใช่ HME
        $where_extra = "
            AND NOT EXISTS (
                SELECT 1 FROM medplan_ipd m WHERE m.an = o.an AND m.icode = o.icode LIMIT 1
            )
            AND UPPER(TRIM(IFNULL(o.item_type,''))) <> 'H'
        ";
    }
    $rxdate = pop_has($ocols, 'rxdate') ? 'o.rxdate' : 'o.vstdate';
    $duExtra = pip_drugusage_extra_select($hos, 'du');
    $rows = pop_query_all($hos, "
        SELECT o.icode, o.qty, o.item_no, o.order_no,
               $rxdate AS rxdate,
               " . (pop_has($ocols, 'rxtime') ? 'o.rxtime' : "''") . " AS rxtime,
               " . pop_utf8('d.name') . " AS drug_name,
               " . pop_utf8('d.strength') . " AS strength,
               " . pop_utf8('d.units') . " AS units,
               $dosage AS dosageform,
               $method AS usage_text,
               {$duExtra['usage_code']},
               {$duExtra['iperdose']},
               {$duExtra['ccperdose']},
               {$duExtra['iperday']},
               IFNULL(ion.order_type,'') AS order_type
        FROM opitemrece o
        INNER JOIN drugitems d ON d.icode = o.icode
        LEFT JOIN drugusage du ON du.drugusage = o.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
        LEFT JOIN ipt_order_no ion ON ion.order_no = o.order_no
        WHERE o.an = '$an_esc'
          $where_extra
        ORDER BY $rxdate DESC, o.item_no ASC
        LIMIT 400
    ");
    $out = [];
    $seen = [];
    foreach ($rows as $i => $r) {
        $icode = trim((string)($r['icode'] ?? ''));
        $orderNo = trim((string)($r['order_no'] ?? ''));
        $key = $icode . '|' . $orderNo;
        if ($icode === '' || isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $name = pip_drug_label($r['drug_name'] ?? '', $r['strength'] ?? '', $r['units'] ?? '');
        $rx = substr(trim((string)($r['rxdate'] ?? '')), 0, 10);
        if ($rx === '0000-00-00') {
            $rx = '';
        }
        $doseFields = pip_usage_dose_fields($r);
        $isInj = pip_is_injection($name, $r['units'] ?? '', $r['dosageform'] ?? '');
        $isTabCap = pip_is_tab_cap($name, $r['units'] ?? '', $r['dosageform'] ?? '');
        $qtyVal = pop_num($r['qty'] ?? '0');
        $robotMiss = $isTabCap
            && !pip_med_qty_is_zero($qtyVal)
            && ($doseFields['per_dose'] === '' || $doseFields['per_day'] === '');
        $out[] = [
            'seq' => count($out) + 1,
            'icode' => $icode,
            'name' => $name,
            'qty' => $qtyVal,
            'usage' => pop_clean($r['usage_text'] ?? ''),
            'usage_code' => $doseFields['usage_code'],
            'per_dose' => $doseFields['per_dose'],
            'per_day' => $doseFields['per_day'],
            'order_no' => $orderNo,
            'order_type' => pip_order_type_display($r['order_type'] ?? ''),
            'orderdate' => $rx,
            'orderdate_th' => pop_fmt_date_th($rx),
            'orderdate_dmy' => pip_fmt_date_dmy($rx),
            'offdate' => '',
            'offdate_th' => '',
            'offdate_dmy' => '',
            'interval' => pip_extract_interval($r['usage_text'] ?? ''),
            'qty_day' => $qtyVal,
            'med_plan_number' => 0,
            'f_flag' => '',
            'recorder' => '',
            'off_staff_name' => '',
            'last_use' => '',
            'drugusage' => '',
            'sp_use' => '',
            'is_injection' => $isInj ? 1 : 0,
            'is_tab_cap' => $isTabCap ? 1 : 0,
            'robot_missing' => $robotMiss ? 1 : 0,
            'group' => $isInj ? 'injection' : 'other',
        ];
    }
    return $out;
}

function pip_group_meds(array $items) {
    $inj = [];
    $other = [];
    foreach ($items as $it) {
        if (!empty($it['is_injection']) || ($it['group'] ?? '') === 'injection') {
            $inj[] = $it;
        } else {
            $other[] = $it;
        }
    }
    return ['injection' => $inj, 'other' => $other];
}

function pip_lookup($con, $hn = '', $an = '', $prefer = '') {
    $hos = pop_connect($con);
    if (!$hos) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูล HOSxP ได้'];
    }
    $hn = trim((string)$hn);
    $an = trim((string)$an);
    $prefer = strtolower(trim((string)$prefer));
    if ($prefer !== 'hn' && $prefer !== 'an') {
        $prefer = '';
    }

    /*
     * prefer=hn → ค้นด้วย HN (ไม่ให้ AN เก่าทับ)
     * prefer=an หรือมีแค่ AN → ยึด AN (รองรับ 5 ตัวท้ายแบบ HOSxP)
     * ไม่ระบุ prefer แต่มีทั้งคู่ → ยึด AN (พฤติกรรมเดิมเวลาเลือก admit จากรายการ)
     */
    if ($prefer === 'hn') {
        $an = '';
    }
    if ($an !== '' && ($prefer === 'an' || $prefer === '' || $hn === '')) {
        $resolvedAn = pip_resolve_an($hos, $an);
        if ($resolvedAn === '') {
            mysqli_close($hos);
            return ['ok' => false, 'error' => 'ไม่พบ AN นี้ใน HOSxP (ลองใส่ 5 ตัวท้ายหรือ AN เต็ม)'];
        }
        $an = $resolvedAn;
        $an_esc = mysqli_real_escape_string($hos, $an);
        $r = pop_query_one($hos, "SELECT hn FROM ipt WHERE an='$an_esc' LIMIT 1");
        $hnFromAn = trim((string)($r['hn'] ?? ''));
        if ($hnFromAn === '') {
            mysqli_close($hos);
            return ['ok' => false, 'error' => 'ไม่พบ HN ของ AN นี้ใน HOSxP'];
        }
        $hn = $hnFromAn;
    }
    if ($hn === '') {
        mysqli_close($hos);
        return ['ok' => false, 'error' => 'กรุณากรอก HN หรือ AN'];
    }

    $patient = pop_fetch_patient($hos, $hn);
    if (!$patient) {
        mysqli_close($hos);
        return ['ok' => false, 'error' => 'ไม่พบ HN นี้ใน HOSxP'];
    }
    $hn_real = $patient['hn'];
    list($admit, $admissions) = pip_resolve_admission($hos, $hn_real, $an);
    $hosxp_notes = pop_fetch_hosxp_notes($hos, $hn_real);
    $dayAheadSettings = pip_load_day_ahead_settings($con);
    $labSettings = pip_load_lab_settings($con);

    if (!$admit) {
        $allergyEmpty = pop_fetch_allergy($hos, $hn_real);
        $labsEmpty = pip_fetch_lab_strip($hos, $hn_real, $labSettings);
        $labsEmpty = pip_attach_crcl_to_labs($labsEmpty, $patient, $labSettings, date('Y-m-d'), $con);
        mysqli_close($hos);
        return [
            'ok' => true,
            'patient' => $patient,
            'allergy' => $allergyEmpty,
            'labs' => $labsEmpty,
            'lab_settings' => $labSettings,
            'hosxp_notes' => $hosxp_notes,
            'must_paid_drugs' => [],
            'day_ahead_settings' => $dayAheadSettings,
            'day_ahead_alerts' => [],
            'robot_missing_alerts' => [],
            'admission' => null,
            'admissions' => [],
            'dx' => ['code' => '', 'name' => '', 'text' => ''],
            'orders' => [],
            'order_items' => [],
            'medplan' => ['active' => [], 'off' => [], 'all' => []],
            'oneday' => [],
            'groups' => [
                'active' => ['injection' => [], 'other' => []],
                'off' => ['injection' => [], 'other' => []],
                'all' => ['injection' => [], 'other' => []],
                'oneday' => ['injection' => [], 'other' => []],
            ],
            'warning' => 'ไม่พบประวัติ Admit (IPD) ของ HN นี้',
        ];
    }

    $cur_an = $admit['an'];
    $dx = pip_fetch_dx($hos, $cur_an);
    $allergy = pop_fetch_allergy($hos, $hn_real);
    $labs = pip_fetch_lab_strip($hos, $hn_real, $labSettings);
    $as_of_lab = !empty($admit['regdate']) ? $admit['regdate'] : date('Y-m-d');
    $labs = pip_attach_crcl_to_labs($labs, $patient, $labSettings, $as_of_lab, $con);
    $orders = pip_fetch_orders($hos, $cur_an);
    $orders = pip_attach_dispense($orders, pip_fetch_dispense_map($con, $cur_an));
    $orders = pip_attach_rx_notes($orders, pip_fetch_rx_note_map($con, $cur_an));
    $first_order = $orders[0]['order_no'] ?? '';
    $order_items = $first_order !== '' ? pip_fetch_order_items($hos, $cur_an, $first_order) : [];
    $medplan = pip_fetch_medplan($hos, $cur_an);
    $oneday = pip_fetch_oneday($hos, $cur_an, $orders);
    $dayAheadMeds = !empty($dayAheadSettings['only_active']) ? ($medplan['active'] ?? []) : ($medplan['all'] ?? []);
    $dayAhead = pip_detect_day_ahead_alerts($dayAheadMeds, $dayAheadSettings);
    $robotMap = pip_load_robot_icode_map($con);
    // ครั้งแรกที่ยังไม่มีรายการ → ดึง TAB/CAP จาก HOSxP อัตโนมัติ
    if (!$robotMap) {
        $seed = pip_seed_robot_drugs($con, $hos, 'auto-seed', false);
        if (!empty($seed['ok'])) {
            $robotMap = pip_load_robot_icode_map($con);
        }
    }
    $medplan['active'] = pip_apply_robot_flags($medplan['active'] ?? [], $robotMap);
    $medplan['off'] = pip_apply_robot_flags($medplan['off'] ?? [], $robotMap);
    $medplan['all'] = pip_apply_robot_flags($medplan['all'] ?? [], $robotMap);
    $oneday = pip_apply_robot_flags($oneday, $robotMap);
    $order_items = pip_apply_robot_flags($order_items, $robotMap);
    $robotMeds = !empty($dayAheadSettings['only_active']) ? ($medplan['active'] ?? []) : ($medplan['all'] ?? []);
    $robotMiss = pip_detect_robot_missing_alerts($robotMeds, $dayAhead['settings'], $robotMap);
    $mustPaid = pip_fetch_must_paid_drugs($hos, $cur_an, (string)($admit['pttype'] ?? ''));

    $as_of = $admit['regdate'] !== '' ? $admit['regdate'] : date('Y-m-d');
    $patient['age_text'] = pop_age_text($patient['birthday'], $as_of);

    $result = [
        'ok' => true,
        'patient' => $patient,
        'allergy' => $allergy,
        'labs' => $labs,
        'lab_settings' => $labSettings,
        'hosxp_notes' => $hosxp_notes,
        'must_paid_drugs' => $mustPaid,
        'day_ahead_settings' => $dayAhead['settings'],
        'day_ahead_alerts' => $dayAhead['alerts'],
        'robot_missing_alerts' => $robotMiss['alerts'],
        'robot_drugs_count' => count($robotMap),
        'admission' => $admit,
        'admissions' => $admissions,
        'dx' => $dx,
        'orders' => $orders,
        'selected_order_no' => $first_order,
        'order_items' => $order_items,
        'medplan' => $medplan,
        'oneday' => $oneday,
        'groups' => [
            'active' => pip_group_meds($medplan['active']),
            'off' => pip_group_meds($medplan['off']),
            'all' => pip_group_meds($medplan['all']),
            'oneday' => pip_group_meds($oneday),
        ],
        'counts' => [
            'active' => count($medplan['active']),
            'off' => count($medplan['off']),
            'all' => count($medplan['all']),
            'oneday' => count($oneday),
        ],
    ];
    mysqli_close($hos);
    return $result;
}

function pip_order_detail($con, $an, $order_no) {
    $hos = pop_connect($con);
    if (!$hos) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูล HOSxP ได้'];
    }
    $items = pip_fetch_order_items($hos, $an, $order_no);
    $robotMap = pip_load_robot_icode_map($con);
    $items = pip_apply_robot_flags($items, $robotMap);
    mysqli_close($hos);
    return ['ok' => true, 'order_no' => trim((string)$order_no), 'items' => $items];
}
