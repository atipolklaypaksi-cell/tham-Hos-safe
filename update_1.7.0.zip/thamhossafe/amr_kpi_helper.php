<?php
/**
 * KPI AMR — ร้อยละผู้ป่วย community acquired pneumonia ที่ใช้ยากลุ่ม Medium watch (AWaRe)
 *
 * กลุ่มประชากร (ทดลองดึงจาก HOSxP):
 * - CAP ทั้งหมด: IPD ที่มี ICD ปอดอักเสบ (ค่าเริ่มต้น J12–J18) ในช่วงที่เลือก
 * - CAP ชุมชน (นิยามที่ปรึกษา): ไม่มี ICD immunocompromised ในช่วงย้อนหลัง และไม่มี IPD admit ใน 3 เดือนก่อนหน้า
 * - CAP กลุ่มเสี่ยง (AND): มีทั้ง immunocompromised และ admit ใน 3 เดือนก่อนหน้า
 */

function amr_kpi_ensure_tables($con) {
    if (!$con) {
        return false;
    }
    $ok1 = @mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_kpi_setting (
        setting_key VARCHAR(64) NOT NULL PRIMARY KEY,
        setting_value TEXT NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    $ok2 = @mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_kpi_icd (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        category VARCHAR(16) NOT NULL,
        icd_prefix VARCHAR(16) NOT NULL,
        label VARCHAR(255) NOT NULL DEFAULT '',
        active TINYINT(1) NOT NULL DEFAULT 1,
        UNIQUE KEY uq_kpi_icd (category, icd_prefix)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    if (!$ok1 || !$ok2) {
        return false;
    }
    amr_kpi_seed_defaults($con);
    return true;
}

function amr_kpi_default_cap_icd() {
    return [
        ['J12', 'Viral pneumonia'],
        ['J13', 'Pneumonia due to S. pneumoniae'],
        ['J14', 'Pneumonia due to H. influenzae'],
        ['J15', 'Bacterial pneumonia, not elsewhere classified'],
        ['J16', 'Pneumonia due to other infectious organisms'],
        ['J17', 'Pneumonia in diseases classified elsewhere'],
        ['J18', 'Pneumonia, organism unspecified'],
    ];
}

function amr_kpi_default_immuno_icd() {
    return [
        ['B20', 'HIV disease'],
        ['B21', 'HIV with malignant neoplasms'],
        ['B22', 'HIV with other specified diseases'],
        ['B23', 'HIV with other conditions'],
        ['B24', 'Unspecified HIV disease'],
        ['Z21', 'Asymptomatic HIV infection status'],
        ['C81', 'Hodgkin lymphoma'],
        ['C82', 'Follicular lymphoma'],
        ['C83', 'Non-follicular lymphoma'],
        ['C84', 'Mature T/NK-cell lymphoma'],
        ['C85', 'Other/unspecified NHL'],
        ['C86', 'Other specified T/NK-cell lymphoma'],
        ['C88', 'Malignant immunoproliferative diseases'],
        ['C90', 'Multiple myeloma and plasma cell neoplasms'],
        ['C91', 'Lymphoid leukaemia'],
        ['C92', 'Myeloid leukaemia'],
        ['C93', 'Monocytic leukaemia'],
        ['C94', 'Other leukaemias of specified cell type'],
        ['C95', 'Leukaemia of unspecified cell type'],
        ['C96', 'Other/unspecified lymphoid/haematopoietic neoplasms'],
        ['D70', 'Agranulocytosis / neutropenia'],
        ['D80', 'Immunodeficiency with predominantly antibody defects'],
        ['D81', 'Combined immunodeficiencies'],
        ['D82', 'Immunodeficiency associated with other major defects'],
        ['D83', 'Common variable immunodeficiency'],
        ['D84', 'Other immunodeficiencies'],
        ['D89', 'Other disorders involving immune mechanism'],
        ['Z94', 'Transplanted organ and tissue status'],
        ['T86', 'Failure and rejection of transplanted organs and tissues'],
        ['D730', 'Hyposplenism / asplenia'],
        ['Z795', 'Long term (current) use of steroids'],
        ['Z511', 'Encounter for chemotherapy'],
    ];
}

function amr_kpi_seed_defaults($con) {
    $q = @mysqli_query($con, "SELECT COUNT(*) AS n FROM amr_kpi_icd");
    $n = 0;
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $n = (int)$r['n'];
    }
    if ($n === 0) {
        foreach (amr_kpi_default_cap_icd() as $row) {
            amr_kpi_icd_upsert($con, 'cap', $row[0], $row[1], 1);
        }
        foreach (amr_kpi_default_immuno_icd() as $row) {
            amr_kpi_icd_upsert($con, 'immuno', $row[0], $row[1], 1);
        }
    }
    $defaults = [
        'lookback_days' => '730',
        'prior_admit_days' => '90',
        'principal_only' => '0',
    ];
    foreach ($defaults as $k => $v) {
        $k_esc = mysqli_real_escape_string($con, $k);
        $v_esc = mysqli_real_escape_string($con, $v);
        @mysqli_query($con, "INSERT IGNORE INTO amr_kpi_setting (setting_key, setting_value)
            VALUES ('$k_esc', '$v_esc')");
    }
}

function amr_kpi_icd_upsert($con, $category, $prefix, $label = '', $active = 1) {
    $category = $category === 'immuno' ? 'immuno' : 'cap';
    $prefix = strtoupper(preg_replace('/[^A-Z0-9.]/', '', (string)$prefix));
    if ($prefix === '') {
        return false;
    }
    $p_esc = mysqli_real_escape_string($con, $prefix);
    $l_esc = mysqli_real_escape_string($con, trim((string)$label));
    $act = (int)$active ? 1 : 0;
    $sql = "INSERT INTO amr_kpi_icd (category, icd_prefix, label, active)
        VALUES ('$category', '$p_esc', '$l_esc', $act)
        ON DUPLICATE KEY UPDATE label = VALUES(label), active = VALUES(active)";
    return (bool)@mysqli_query($con, $sql);
}

function amr_kpi_settings_get($con) {
    amr_kpi_ensure_tables($con);
    $lookback = 730;
    $prior = 90;
    $principal = 0;
    $q = @mysqli_query($con, "SELECT setting_key, setting_value FROM amr_kpi_setting");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $k = (string)($r['setting_key'] ?? '');
            $v = trim((string)($r['setting_value'] ?? ''));
            if ($k === 'lookback_days') {
                $lookback = max(30, min(1825, (int)$v));
            } elseif ($k === 'prior_admit_days') {
                $prior = max(7, min(365, (int)$v));
            } elseif ($k === 'principal_only') {
                $principal = $v === '1' ? 1 : 0;
            }
        }
    }
    return [
        'lookback_days' => $lookback,
        'prior_admit_days' => $prior,
        'principal_only' => $principal,
        'cap_icd' => amr_kpi_icd_list($con, 'cap'),
        'immuno_icd' => amr_kpi_icd_list($con, 'immuno'),
    ];
}

function amr_kpi_icd_list($con, $category) {
    $category = $category === 'immuno' ? 'immuno' : 'cap';
    $out = [];
    $q = @mysqli_query($con, "SELECT id, category, icd_prefix, label, active
        FROM amr_kpi_icd WHERE category = '$category'
        ORDER BY icd_prefix ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $out[] = [
                'id' => (int)$r['id'],
                'category' => $r['category'],
                'icd_prefix' => (string)$r['icd_prefix'],
                'label' => (string)($r['label'] ?? ''),
                'active' => (int)$r['active'] ? 1 : 0,
            ];
        }
    }
    return $out;
}

function amr_kpi_settings_save($con, array $src) {
    amr_kpi_ensure_tables($con);
    $lookback = max(30, min(1825, (int)($src['lookback_days'] ?? 730)));
    $prior = max(7, min(365, (int)($src['prior_admit_days'] ?? 90)));
    $principal = !empty($src['principal_only']) ? 1 : 0;
    $pairs = [
        'lookback_days' => (string)$lookback,
        'prior_admit_days' => (string)$prior,
        'principal_only' => (string)$principal,
    ];
    foreach ($pairs as $k => $v) {
        $k_esc = mysqli_real_escape_string($con, $k);
        $v_esc = mysqli_real_escape_string($con, $v);
        @mysqli_query($con, "INSERT INTO amr_kpi_setting (setting_key, setting_value)
            VALUES ('$k_esc', '$v_esc')
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    }
    foreach (['cap' => $src['cap_icd'] ?? null, 'immuno' => $src['immuno_icd'] ?? null] as $cat => $rows) {
        if ($rows === null) {
            continue;
        }
        if (!is_array($rows)) {
            $rows = amr_kpi_parse_icd_text((string)$rows);
        }
        $cat_esc = mysqli_real_escape_string($con, $cat);
        @mysqli_query($con, "DELETE FROM amr_kpi_icd WHERE category = '$cat_esc'");
        $seen = [];
        foreach ($rows as $row) {
            if (is_string($row)) {
                $parsed = amr_kpi_parse_icd_text($row);
                $row = $parsed[0] ?? [];
            }
            $prefix = strtoupper(preg_replace('/[^A-Z0-9.]/', '', (string)($row['icd_prefix'] ?? $row['prefix'] ?? '')));
            if ($prefix === '' || isset($seen[$prefix])) {
                continue;
            }
            $seen[$prefix] = true;
            amr_kpi_icd_upsert($con, $cat, $prefix, (string)($row['label'] ?? ''), isset($row['active']) ? (int)$row['active'] : 1);
        }
        if (!$seen) {
            $defaults = $cat === 'immuno' ? amr_kpi_default_immuno_icd() : amr_kpi_default_cap_icd();
            foreach ($defaults as $d) {
                amr_kpi_icd_upsert($con, $cat, $d[0], $d[1], 1);
            }
        }
    }
    return amr_kpi_settings_get($con);
}

function amr_kpi_parse_icd_text($text) {
    $out = [];
    foreach (preg_split('/\r\n|\r|\n/', (string)$text) as $line) {
        $line = trim($line);
        if ($line === '' || strpos($line, '#') === 0) {
            continue;
        }
        $parts = preg_split('/\s*[|;\t]\s*/', $line, 2);
        $prefix = strtoupper(preg_replace('/[^A-Z0-9.]/', '', $parts[0] ?? ''));
        if ($prefix === '') {
            continue;
        }
        $out[] = [
            'icd_prefix' => $prefix,
            'label' => trim((string)($parts[1] ?? '')),
            'active' => 1,
        ];
    }
    return $out;
}

function amr_kpi_active_prefixes(array $rows) {
    $out = [];
    foreach ($rows as $r) {
        if (isset($r['active']) && !(int)$r['active']) {
            continue;
        }
        $p = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)($r['icd_prefix'] ?? '')));
        if ($p !== '') {
            $out[$p] = $p;
        }
    }
    return array_values($out);
}

function amr_kpi_icd_like_sql($hos, $col, array $prefixes) {
    $ors = [];
    foreach ($prefixes as $p) {
        $p = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)$p));
        if ($p === '') {
            continue;
        }
        $esc = mysqli_real_escape_string($hos, $p);
        $ors[] = "REPLACE(UPPER(TRIM($col)), '.', '') LIKE '$esc%'";
    }
    return $ors ? '(' . implode(' OR ', $ors) . ')' : '0';
}

function amr_kpi_icd_matches($code, array $prefixes) {
    $n = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)$code));
    if ($n === '') {
        return false;
    }
    foreach ($prefixes as $p) {
        $p = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)$p));
        if ($p !== '' && strpos($n, $p) === 0) {
            return true;
        }
    }
    return false;
}

function amr_kpi_in_chunks(array $values, $size = 80) {
    $clean = [];
    foreach ($values as $v) {
        $v = trim((string)$v);
        if ($v !== '') {
            $clean[$v] = $v;
        }
    }
    return array_chunk(array_values($clean), max(20, min(200, (int)$size)));
}

function amr_kpi_sql_in($hos, array $values) {
    $esc = [];
    foreach ($values as $v) {
        $v = trim((string)$v);
        if ($v === '') {
            continue;
        }
        $esc[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return $esc ? implode(',', $esc) : "''";
}

function amr_kpi_pct($n, $d, $dp = 1) {
    $n = (int)$n;
    $d = (int)$d;
    if ($d <= 0) {
        return null;
    }
    return round(100.0 * $n / $d, $dp);
}

function amr_kpi_classify_drug($name) {
    if (!function_exists('amr_amass_classify_drug')) {
        $annex = __DIR__ . '/amr_amass_annex.php';
        if (is_file($annex)) {
            require_once $annex;
        }
    }
    if (function_exists('amr_amass_classify_drug')) {
        return amr_amass_classify_drug($name);
    }
    return ['generic' => trim((string)$name), 'type' => 'Antibiotic', 'aware' => 'Unclassified'];
}

/** จัดกลุ่มยาตาม AWaRe จากแผนที่จำแนก (ชื่อ generic / TMT) */
function amr_kpi_aware_catalog() {
    if (!function_exists('amr_amass_aware_map')) {
        $annex = __DIR__ . '/amr_amass_annex.php';
        if (is_file($annex)) {
            require_once $annex;
        }
    }
    $order = ['Access', 'Low watch', 'Medium watch', 'High watch', 'Reserve', 'Unclassified'];
    $out = [];
    foreach ($order as $k) {
        $out[$k] = [];
    }
    if (!function_exists('amr_amass_aware_map')) {
        return $out;
    }
    $seen = [];
    foreach (amr_amass_aware_map() as $generic => $meta) {
        $type = (string)($meta[0] ?? 'Antibiotic');
        $aware = (string)($meta[1] ?? 'Unclassified');
        if ($type !== 'Antibiotic') {
            continue;
        }
        $g = strtolower(trim((string)$generic));
        if ($g === '' || isset($seen[$aware][$g])) {
            continue;
        }
        $seen[$aware][$g] = true;
        if (!isset($out[$aware])) {
            $out[$aware] = [];
        }
        $out[$aware][] = $generic;
    }
    foreach ($out as $k => $list) {
        sort($out[$k], SORT_NATURAL | SORT_FLAG_CASE);
    }
    return $out;
}

/**
 * รายการยาปฏิชีวนะในระบบ (ตั้งค่า amr_sens_atb) จัดกลุ่ม AWaRe ตามชื่อ TMT/generic
 * @return array{by_aware: array, notes: string[]}
 */
function amr_kpi_hospital_atb_by_aware($con) {
    $by = [];
    $notes = [];
    if (!function_exists('amr_sens_atb_list')) {
        if (is_file(__DIR__ . '/amr_sensitivity_helper.php')) {
            require_once __DIR__ . '/amr_sensitivity_helper.php';
        }
    }
    if (!function_exists('amr_sens_atb_list') || !$con) {
        $notes[] = 'ยังไม่มีรายการยาปฏิชีวนะในระบบ (amr_sens_atb) — แสดงเฉพาะแผนที่จำแนก AWaRe';
        return ['by_aware' => $by, 'notes' => $notes];
    }
    $rows = amr_sens_atb_list($con);
    if (!$rows) {
        $notes[] = 'ยังไม่ได้ตั้งค่ารายการยาปฏิชีวนะที่ดึง (หน้า Antibiogram / ATB drugs)';
        return ['by_aware' => $by, 'notes' => $notes];
    }
    foreach ($rows as $r) {
        if (isset($r['active']) && !(int)$r['active']) {
            continue;
        }
        $label = trim((string)($r['drug_name'] ?? ''));
        $gen = trim((string)($r['generic_name'] ?? ''));
        $cls = amr_kpi_classify_drug($label !== '' ? $label : $gen);
        if (($cls['aware'] ?? '') === 'Unclassified' && $gen !== '' && $gen !== $label) {
            $cls = amr_kpi_classify_drug($gen);
        }
        $aware = (string)($cls['aware'] ?? 'Unclassified');
        $name = (string)($cls['generic'] ?? ($gen !== '' ? $gen : $label));
        if ($name === '') {
            $name = $label !== '' ? $label : ('icode ' . ($r['icode'] ?? ''));
        }
        $key = strtolower($name);
        if (!isset($by[$aware][$key])) {
            $by[$aware][$key] = [
                'name' => $name,
                'icode' => (string)($r['icode'] ?? ''),
                'drug_name' => $label,
                'generic_name' => $gen,
            ];
        }
    }
    $ordered = [];
    foreach (['Access', 'Low watch', 'Medium watch', 'High watch', 'Reserve', 'Unclassified'] as $k) {
        if (empty($by[$k])) {
            continue;
        }
        ksort($by[$k], SORT_NATURAL | SORT_FLAG_CASE);
        $ordered[$k] = array_values($by[$k]);
    }
    return ['by_aware' => $ordered, 'notes' => $notes];
}

function amr_kpi_date_ok($d) {
    $d = trim((string)$d);
    return $d !== '' && $d !== '0000-00-00' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $d);
}

function amr_kpi_prior_hit($index_reg, $prev_reg, $prev_dch, $days) {
    if (!amr_kpi_date_ok($index_reg) || !amr_kpi_date_ok($prev_reg)) {
        return false;
    }
    $t0 = strtotime($index_reg . ' 00:00:00');
    $preg = strtotime($prev_reg . ' 00:00:00');
    if ($preg === false || $t0 === false || $preg >= $t0) {
        return false;
    }
    $tmin = $t0 - ((int)$days * 86400);
    if ($preg >= $tmin) {
        return true;
    }
    if (amr_kpi_date_ok($prev_dch)) {
        $pdch = strtotime($prev_dch . ' 00:00:00');
        if ($pdch !== false && $pdch >= $tmin && $pdch < $t0) {
            return true;
        }
    }
    return false;
}

function amr_kpi_fetch_cap_admissions($hos, $start, $end, array $cap_prefixes, $principal_only) {
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $cap_sql = amr_kpi_icd_like_sql($hos, 'id.icd10', $cap_prefixes);
    $diag_filter = $principal_only ? " AND TRIM(IFNULL(id.diagtype,'')) IN ('1','01')" : '';
    $sql = "
        SELECT i.an, i.hn, i.regdate, i.dchdate, i.ward,
               " . amr_sql_utf8("IFNULL(w.name, IFNULL(i.ward, ''))") . " AS ward_name,
               " . amr_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))") . " AS pt_name,
               pt.sex,
               TIMESTAMPDIFF(YEAR, pt.birthday, i.regdate) AS age_y,
               GROUP_CONCAT(DISTINCT TRIM(id.icd10) ORDER BY id.diagtype, id.icd10 SEPARATOR ',') AS cap_icds,
               MIN(id.diagtype) AS cap_diagtype
        FROM ipt i
        INNER JOIN iptdiag id ON id.an = i.an AND $cap_sql $diag_filter
        INNER JOIN patient pt ON pt.hn = i.hn
        LEFT JOIN ward w ON w.ward = i.ward
        WHERE i.regdate BETWEEN '$start_esc' AND '$end_esc'
        GROUP BY i.an, i.hn, i.regdate, i.dchdate, i.ward, w.name, pt.pname, pt.fname, pt.lname, pt.sex, pt.birthday
        ORDER BY i.regdate DESC, i.an DESC
    ";
    $rows = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return ['rows' => [], 'error' => mysqli_error($hos)];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $an = trim((string)($r['an'] ?? ''));
        $hn = trim((string)($r['hn'] ?? ''));
        if ($an === '' || $hn === '') {
            continue;
        }
        $sex = trim((string)($r['sex'] ?? ''));
        if ($sex === '1') {
            $sex = 'ช';
        } elseif ($sex === '2') {
            $sex = 'ญ';
        }
        $rows[] = [
            'an' => $an,
            'hn' => $hn,
            'regdate' => amr_kpi_date_ok($r['regdate'] ?? '') ? $r['regdate'] : '',
            'dchdate' => amr_kpi_date_ok($r['dchdate'] ?? '') ? $r['dchdate'] : '',
            'ward' => (string)($r['ward'] ?? ''),
            'ward_name' => trim((string)($r['ward_name'] ?? '')),
            'pt_name' => trim((string)($r['pt_name'] ?? '')),
            'sex' => $sex,
            'age_y' => (int)($r['age_y'] ?? 0),
            'cap_icds' => trim((string)($r['cap_icds'] ?? '')),
            'cap_diagtype' => trim((string)($r['cap_diagtype'] ?? '')),
        ];
    }
    return ['rows' => $rows, 'error' => ''];
}

function amr_kpi_fetch_prior_admits($hos, array $cases, $prior_days, $start) {
    $hns = [];
    foreach ($cases as $c) {
        $hns[] = $c['hn'];
    }
    $look_start = date('Y-m-d', strtotime($start . ' -' . ((int)$prior_days + 5) . ' days'));
    $by_hn = [];
    foreach (amr_kpi_in_chunks($hns, 100) as $part) {
        $in = amr_kpi_sql_in($hos, $part);
        $ls = mysqli_real_escape_string($hos, $look_start);
        $sql = "
            SELECT an, hn, regdate, dchdate
            FROM ipt
            WHERE hn IN ($in)
              AND regdate >= '$ls'
            ORDER BY hn, regdate
        ";
        $q = @mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $hn = trim((string)($r['hn'] ?? ''));
            $an = trim((string)($r['an'] ?? ''));
            if ($hn === '' || $an === '') {
                continue;
            }
            $by_hn[$hn][] = [
                'an' => $an,
                'regdate' => amr_kpi_date_ok($r['regdate'] ?? '') ? $r['regdate'] : '',
                'dchdate' => amr_kpi_date_ok($r['dchdate'] ?? '') ? $r['dchdate'] : '',
            ];
        }
    }
    $out = [];
    foreach ($cases as $c) {
        $hits = [];
        foreach ($by_hn[$c['hn']] ?? [] as $prev) {
            if ($prev['an'] === $c['an']) {
                continue;
            }
            if (amr_kpi_prior_hit($c['regdate'], $prev['regdate'], $prev['dchdate'], $prior_days)) {
                $hits[] = $prev;
            }
        }
        if ($hits) {
            usort($hits, function ($a, $b) {
                return strcmp($b['regdate'], $a['regdate']);
            });
            $out[$c['an']] = $hits;
        }
    }
    return $out;
}

function amr_kpi_fetch_immuno($hos, array $cases, array $immuno_prefixes, $lookback_days, $start, $end) {
    $hns = [];
    foreach ($cases as $c) {
        $hns[] = $c['hn'];
    }
    $look_start = date('Y-m-d', strtotime($start . ' -' . ((int)$lookback_days + 5) . ' days'));
    $icd_sql = amr_kpi_icd_like_sql($hos, 'id.icd10', $immuno_prefixes);
    $icd_sql_od = amr_kpi_icd_like_sql($hos, 'od.icd10', $immuno_prefixes);
    $by_hn = [];
    $notes = [];
    foreach (amr_kpi_in_chunks($hns, 80) as $part) {
        $in = amr_kpi_sql_in($hos, $part);
        $ls = mysqli_real_escape_string($hos, $look_start);
        $ee = mysqli_real_escape_string($hos, $end);
        $sql_ipd = "
            SELECT i.hn, TRIM(id.icd10) AS icd10, i.regdate AS dx_date, 'IPD' AS src
            FROM ipt i
            INNER JOIN iptdiag id ON id.an = i.an
            WHERE i.hn IN ($in)
              AND i.regdate BETWEEN '$ls' AND '$ee'
              AND $icd_sql
        ";
        $q = @mysqli_query($hos, $sql_ipd);
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $hn = trim((string)($r['hn'] ?? ''));
                if ($hn === '') {
                    continue;
                }
                $by_hn[$hn][] = [
                    'icd10' => trim((string)($r['icd10'] ?? '')),
                    'dx_date' => amr_kpi_date_ok($r['dx_date'] ?? '') ? $r['dx_date'] : '',
                    'src' => 'IPD',
                ];
            }
        } elseif (!$notes) {
            $notes[] = 'IPD immuno: ' . mysqli_error($hos);
        }
        $sql_opd = "
            SELECT o.hn, TRIM(od.icd10) AS icd10, o.vstdate AS dx_date, 'OPD' AS src
            FROM ovst o
            INNER JOIN ovstdiag od ON od.vn = o.vn
            WHERE o.hn IN ($in)
              AND o.vstdate BETWEEN '$ls' AND '$ee'
              AND $icd_sql_od
        ";
        $q2 = @mysqli_query($hos, $sql_opd);
        if ($q2) {
            while ($r = mysqli_fetch_assoc($q2)) {
                $hn = trim((string)($r['hn'] ?? ''));
                if ($hn === '') {
                    continue;
                }
                $by_hn[$hn][] = [
                    'icd10' => trim((string)($r['icd10'] ?? '')),
                    'dx_date' => amr_kpi_date_ok($r['dx_date'] ?? '') ? $r['dx_date'] : '',
                    'src' => 'OPD',
                ];
            }
        } else {
            $notes['opd'] = 'OPD immuno: ' . mysqli_error($hos);
        }
    }
    $out = [];
    foreach ($cases as $c) {
        $t0 = amr_kpi_date_ok($c['regdate']) ? strtotime($c['regdate'] . ' 00:00:00') : false;
        if ($t0 === false) {
            continue;
        }
        $tmin = $t0 - ((int)$lookback_days * 86400);
        $tmax = $t0;
        if (amr_kpi_date_ok($c['dchdate'])) {
            $td = strtotime($c['dchdate'] . ' 00:00:00');
            if ($td !== false && $td > $tmax) {
                $tmax = $td;
            }
        }
        $hits = [];
        $seen = [];
        foreach ($by_hn[$c['hn']] ?? [] as $dx) {
            if (!amr_kpi_icd_matches($dx['icd10'], $immuno_prefixes)) {
                continue;
            }
            $tdx = amr_kpi_date_ok($dx['dx_date']) ? strtotime($dx['dx_date'] . ' 00:00:00') : false;
            if ($tdx === false || $tdx < $tmin || $tdx > $tmax) {
                continue;
            }
            $key = $dx['icd10'] . '|' . $dx['dx_date'] . '|' . $dx['src'];
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $hits[] = $dx;
        }
        if ($hits) {
            $out[$c['an']] = $hits;
        }
    }
    return ['map' => $out, 'notes' => array_values($notes)];
}

function amr_kpi_fetch_atb($hos, $con, array $ans) {
    if (!$hos || !$ans) {
        return [];
    }
    if (!function_exists('amr_sens_atb_icode_sql') && is_file(__DIR__ . '/amr_sensitivity_helper.php')) {
        require_once __DIR__ . '/amr_sensitivity_helper.php';
    }
    $atb_flag = function_exists('amr_sens_atb_icode_sql')
        ? amr_sens_atb_icode_sql($hos, $con, 'd')
        : "UPPER(TRIM(IFNULL(d.antibiotic, ''))) = 'Y'";
    $name_expr = function_exists('hosxp_sql_tmt_drug_name')
        ? hosxp_sql_tmt_drug_name('d', 'tm')
        : amr_sql_utf8("TRIM(CONCAT(IFNULL(NULLIF(d.generic_name,''), d.name), ' ', IFNULL(d.strength,'')))");
    $tmt_join = function_exists('hosxp_sql_tmt_join') ? hosxp_sql_tmt_join('d', 'tm') : '';
    $gen_expr = amr_sql_utf8("IFNULL(d.generic_name, '')");
    $map = [];
    foreach (amr_kpi_in_chunks($ans, 80) as $part) {
        $in = amr_kpi_sql_in($hos, $part);
        $sql = "
            SELECT o.an, o.icode, o.rxdate,
                   $name_expr AS drug_name,
                   $gen_expr AS generic_name
            FROM opitemrece o
            INNER JOIN drugitems d ON d.icode = o.icode
            $tmt_join
            WHERE o.an IN ($in)
              AND IFNULL(o.qty, 0) > 0
              AND $atb_flag
            ORDER BY o.an, o.rxdate, o.icode
        ";
        $q = @mysqli_query($hos, $sql);
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $an = trim((string)($r['an'] ?? ''));
                if ($an === '') {
                    continue;
                }
                $map[$an][] = [
                    'icode' => (string)($r['icode'] ?? ''),
                    'rxdate' => amr_kpi_date_ok($r['rxdate'] ?? '') ? $r['rxdate'] : '',
                    'drug_name' => trim((string)($r['drug_name'] ?? '')),
                    'generic_name' => trim((string)($r['generic_name'] ?? '')),
                    'source' => 'opitemrece',
                ];
            }
        }
        $missing = [];
        foreach ($part as $an) {
            if (empty($map[$an])) {
                $missing[] = $an;
            }
        }
        if (!$missing) {
            continue;
        }
        $in2 = amr_kpi_sql_in($hos, $missing);
        $sql2 = "
            SELECT mp.an, mp.icode, DATE(mp.orderdate) AS rxdate,
                   $name_expr AS drug_name,
                   $gen_expr AS generic_name
            FROM medplan_ipd mp
            INNER JOIN drugitems d ON d.icode = mp.icode
            $tmt_join
            WHERE mp.an IN ($in2)
              AND $atb_flag
            ORDER BY mp.an, mp.orderdate, mp.icode
        ";
        $q2 = @mysqli_query($hos, $sql2);
        if ($q2) {
            while ($r = mysqli_fetch_assoc($q2)) {
                $an = trim((string)($r['an'] ?? ''));
                if ($an === '') {
                    continue;
                }
                $map[$an][] = [
                    'icode' => (string)($r['icode'] ?? ''),
                    'rxdate' => amr_kpi_date_ok($r['rxdate'] ?? '') ? $r['rxdate'] : '',
                    'drug_name' => trim((string)($r['drug_name'] ?? '')),
                    'generic_name' => trim((string)($r['generic_name'] ?? '')),
                    'source' => 'medplan_ipd',
                ];
            }
        }
    }
    return $map;
}

function amr_kpi_pack_atb(array $items) {
    $seen = [];
    $drugs = [];
    $aware_set = [];
    $medium = false;
    $reserve = false;
    $medium_names = [];
    $reserve_names = [];
    foreach ($items as $it) {
        $label = $it['drug_name'] !== '' ? $it['drug_name'] : $it['generic_name'];
        $cls = amr_kpi_classify_drug($label);
        if (($cls['aware'] ?? '') === 'Unclassified' && $it['generic_name'] !== '' && $it['generic_name'] !== $label) {
            $cls = amr_kpi_classify_drug($it['generic_name']);
        }
        $aware = (string)($cls['aware'] ?? 'Unclassified');
        $generic = (string)($cls['generic'] ?? $label);
        $key = strtolower($generic);
        if (!isset($seen[$key])) {
            $seen[$key] = true;
            $drugs[] = [
                'name' => $generic !== '' ? $generic : $label,
                'aware' => $aware,
                'rxdate' => $it['rxdate'],
                'source' => $it['source'],
            ];
        }
        $aware_set[$aware] = ($aware_set[$aware] ?? 0) + 1;
        if ($aware === 'Medium watch') {
            $medium = true;
            $medium_names[$generic] = $generic;
        }
        if ($aware === 'Reserve') {
            $reserve = true;
            $reserve_names[$generic] = $generic;
        }
    }
    return [
        'drugs' => $drugs,
        'drug_text' => implode(', ', array_map(function ($d) {
            return $d['name'] . ' (' . $d['aware'] . ')';
        }, $drugs)),
        'aware_set' => array_keys($aware_set),
        'used_medium_watch' => $medium,
        'used_reserve' => $reserve,
        'medium_watch_drugs' => array_values($medium_names),
        'reserve_drugs' => array_values($reserve_names),
        'atb_n' => count($drugs),
    ];
}

function amr_kpi_official_stats(array $rows, $flag = '') {
    $cap = 0;
    $b = 0;
    $a = 0;
    $reserve = 0;
    foreach ($rows as $r) {
        if ($flag !== '' && empty($r[$flag])) {
            continue;
        }
        $cap++;
        if ((int)($r['atb_n'] ?? 0) <= 0) {
            continue;
        }
        $b++;
        if (!empty($r['used_medium_watch'])) {
            $a++;
        }
        if (!empty($r['used_reserve'])) {
            $reserve++;
        }
    }
    return [
        'cap_n' => $cap,
        'b' => $b,
        'a' => $a,
        'pct' => amr_kpi_pct($a, $b),
        'reserve_n' => $reserve,
        'reserve_pct' => amr_kpi_pct($reserve, $b),
    ];
}

function amr_kpi_cohort_stats(array $rows, $flag) {
    $den = 0;
    $num = 0;
    $reserve_n = 0;
    $atb_b = 0;
    $drugs = [];
    $reserve_drugs = [];
    $aware = [];
    foreach ($rows as $r) {
        if ($flag !== '' && empty($r[$flag])) {
            continue;
        }
        $den++;
        if (!empty($r['used_medium_watch'])) {
            $num++;
        }
        if ((int)($r['atb_n'] ?? 0) > 0) {
            $atb_b++;
            if (!empty($r['used_reserve'])) {
                $reserve_n++;
            }
        } elseif (!empty($r['used_reserve'])) {
            $reserve_n++;
        }
        foreach ($r['medium_watch_drugs'] ?? [] as $d) {
            $drugs[$d] = ($drugs[$d] ?? 0) + 1;
        }
        $reserve_names = $r['reserve_drugs'] ?? [];
        if (!$reserve_names) {
            foreach ($r['drugs'] ?? [] as $d) {
                if (($d['aware'] ?? '') === 'Reserve') {
                    $nm = trim((string)($d['name'] ?? ''));
                    if ($nm !== '') {
                        $reserve_names[] = $nm;
                    }
                }
            }
        }
        foreach ($reserve_names as $d) {
            $d = trim((string)$d);
            if ($d !== '') {
                $reserve_drugs[$d] = ($reserve_drugs[$d] ?? 0) + 1;
            }
        }
        foreach ($r['drugs'] ?? [] as $d) {
            $a = $d['aware'] ?? 'Unclassified';
            $aware[$a] = ($aware[$a] ?? 0) + 1;
        }
    }
    arsort($drugs);
    arsort($reserve_drugs);
    $aware_rows = [];
    foreach (['Access', 'Low watch', 'Medium watch', 'High watch', 'Reserve', 'Unclassified'] as $k) {
        if (!empty($aware[$k])) {
            $aware_rows[] = ['aware' => $k, 'n' => (int)$aware[$k]];
        }
    }
    $mix = [];
    foreach ($drugs as $name => $n) {
        $mix[] = ['name' => $name, 'n' => (int)$n];
        if (count($mix) >= 15) {
            break;
        }
    }
    $reserve_mix = [];
    foreach ($reserve_drugs as $name => $n) {
        $reserve_mix[] = ['name' => $name, 'n' => (int)$n];
        if (count($reserve_mix) >= 15) {
            break;
        }
    }
    $reserve_den = $atb_b > 0 ? $atb_b : $den;
    return [
        'denominator' => $den,
        'numerator' => $num,
        'pct' => amr_kpi_pct($num, $den),
        'reserve_n' => $reserve_n,
        'reserve_b' => $reserve_den,
        'reserve_pct' => amr_kpi_pct($reserve_n, $reserve_den),
        'medium_mix' => $mix,
        'reserve_mix' => $reserve_mix,
        'aware_mix' => $aware_rows,
    ];
}

function amr_kpi_slice_rows(array $rows, $flag, $limit = 400) {
    $out = [];
    foreach ($rows as $r) {
        if ($flag !== '' && empty($r[$flag])) {
            continue;
        }
        $out[] = [
            'hn' => $r['hn'],
            'an' => $r['an'],
            'pt_name' => $r['pt_name'],
            'sex' => $r['sex'],
            'age_y' => $r['age_y'],
            'regdate' => $r['regdate'],
            'dchdate' => $r['dchdate'],
            'ward_name' => $r['ward_name'],
            'cap_icds' => $r['cap_icds'],
            'cap_diagtype' => $r['cap_diagtype'],
            'immuno' => !empty($r['immuno']),
            'immuno_text' => $r['immuno_text'],
            'prior_admit' => !empty($r['prior_admit']),
            'prior_text' => $r['prior_text'],
            'used_medium_watch' => !empty($r['used_medium_watch']),
            'medium_watch_drugs' => $r['medium_watch_drugs'],
            'used_reserve' => !empty($r['used_reserve']),
            'reserve_drugs' => $r['reserve_drugs'] ?? [],
            'drug_text' => $r['drug_text'],
            'atb_n' => $r['atb_n'],
        ];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function amr_kpi_build($con, array $opts) {
    $start = amr_parse_date($opts['start'] ?? '', date('Y-01-01'));
    $end = amr_parse_date($opts['end'] ?? '', date('Y-m-d'));
    if ($start > $end) {
        $tmp = $start;
        $start = $end;
        $end = $tmp;
    }
    $lite = !empty($opts['lite']);
    $include_rows = !$lite;
    if (!$lite && array_key_exists('include_rows', $opts)) {
        $include_rows = !empty($opts['include_rows']);
    }
    $span = (int)floor((strtotime($end) - strtotime($start)) / 86400);
    if ($span > 366) {
        $start = date('Y-m-d', strtotime($end . ' -366 days'));
    }
    $cfg = amr_kpi_settings_get($con);
    if (isset($opts['lookback_days']) && $opts['lookback_days'] !== '' && $opts['lookback_days'] !== null) {
        $cfg['lookback_days'] = max(30, min(1825, (int)$opts['lookback_days']));
    }
    if (isset($opts['prior_admit_days']) && $opts['prior_admit_days'] !== '' && $opts['prior_admit_days'] !== null) {
        $cfg['prior_admit_days'] = max(7, min(365, (int)$opts['prior_admit_days']));
    }
    if (array_key_exists('principal_only', $opts) && $opts['principal_only'] !== null && $opts['principal_only'] !== '') {
        $cfg['principal_only'] = !empty($opts['principal_only']) ? 1 : 0;
    }
    $cap_prefixes = amr_kpi_active_prefixes($cfg['cap_icd']);
    $immuno_prefixes = amr_kpi_active_prefixes($cfg['immuno_icd']);
    if (!$cap_prefixes) {
        return ['error' => 'ยังไม่ได้ตั้งรหัส ICD ของ CAP'];
    }
    if (!function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    }
    $hos = hosxp_connect($con, 180);
    if (!$hos) {
        return ['error' => 'เชื่อมต่อ HOSxP ไม่ได้'];
    }
    if (function_exists('hosxp_set_timeouts')) {
        hosxp_set_timeouts($hos, 180);
    }

    $cap = amr_kpi_fetch_cap_admissions($hos, $start, $end, $cap_prefixes, (bool)$cfg['principal_only']);
    if ($cap['error'] !== '') {
        mysqli_close($hos);
        return ['error' => 'ดึงวินิจฉัยปอดอักเสบไม่สำเร็จ: ' . $cap['error']];
    }
    $cases = $cap['rows'];
    $prior_map = [];
    $immuno = ['map' => [], 'notes' => []];
    if ($cases) {
        $prior_map = amr_kpi_fetch_prior_admits($hos, $cases, (int)$cfg['prior_admit_days'], $start);
        $immuno = amr_kpi_fetch_immuno($hos, $cases, $immuno_prefixes, (int)$cfg['lookback_days'], $start, $end);
    }
    $ans = [];
    foreach ($cases as $c) {
        $ans[] = $c['an'];
    }
    $atb_map = $cases ? amr_kpi_fetch_atb($hos, $con, $ans) : [];
    mysqli_close($hos);

    $rows = [];
    foreach ($cases as $c) {
        $immuno_hits = $immuno['map'][$c['an']] ?? [];
        $prior_hits = $prior_map[$c['an']] ?? [];
        $atb = amr_kpi_pack_atb($atb_map[$c['an']] ?? []);
        $is_immuno = !empty($immuno_hits);
        $is_prior = !empty($prior_hits);
        $immuno_text = [];
        foreach ($immuno_hits as $h) {
            $immuno_text[$h['icd10']] = $h['icd10'] . ($h['dx_date'] !== '' ? ' (' . $h['src'] . ' ' . $h['dx_date'] . ')' : '');
        }
        $prior_text = [];
        foreach (array_slice($prior_hits, 0, 3) as $h) {
            $prior_text[] = 'AN ' . $h['an'] . ' ' . $h['regdate'] . ($h['dchdate'] !== '' ? '–' . $h['dchdate'] : '');
        }
        $row = array_merge($c, $atb, [
            'immuno' => $is_immuno,
            'prior_admit' => $is_prior,
            'community' => !$is_immuno && !$is_prior,
            'risk_and' => $is_immuno && $is_prior,
            'risk_or' => $is_immuno || $is_prior,
            'immuno_only' => $is_immuno && !$is_prior,
            'prior_only' => $is_prior && !$is_immuno,
            'immuno_text' => implode(', ', array_values($immuno_text)),
            'prior_text' => implode('; ', $prior_text),
        ]);
        $rows[] = $row;
    }

    $cohorts = [];
    if (!$lite) {
        $cohorts = [
            'all' => array_merge(['key' => 'all', 'label' => 'CAP ทั้งหมด (IPD ปอดอักเสบ)', 'flag' => ''], amr_kpi_cohort_stats($rows, '')),
            'community' => array_merge(['key' => 'community', 'label' => 'CAP ชุมชน (ไม่ immuno และไม่ admit 3 เดือน)', 'flag' => 'community'], amr_kpi_cohort_stats($rows, 'community')),
            'risk_and' => array_merge(['key' => 'risk_and', 'label' => 'CAP กลุ่มเสี่ยง (immuno และ admit 3 เดือน)', 'flag' => 'risk_and'], amr_kpi_cohort_stats($rows, 'risk_and')),
            'immuno_only' => array_merge(['key' => 'immuno_only', 'label' => 'CAP มี immuno อย่างเดียว', 'flag' => 'immuno_only'], amr_kpi_cohort_stats($rows, 'immuno_only')),
            'prior_only' => array_merge(['key' => 'prior_only', 'label' => 'CAP มี admit 3 เดือนก่อนอย่างเดียว', 'flag' => 'prior_only'], amr_kpi_cohort_stats($rows, 'prior_only')),
            'risk_or' => array_merge(['key' => 'risk_or', 'label' => 'CAP ที่ถูกตัดออกจากตัวชี้วัด (immuno หรือ admit 3 เดือน)', 'flag' => 'risk_or'], amr_kpi_cohort_stats($rows, 'risk_or')),
        ];
    }

    $out = [
        'error' => '',
        'meta' => [
            'start' => $start,
            'end' => $end,
            'lite' => $lite ? 1 : 0,
            'lookback_days' => (int)$cfg['lookback_days'],
            'prior_admit_days' => (int)$cfg['prior_admit_days'],
            'principal_only' => (int)$cfg['principal_only'],
            'cap_prefixes' => $cap_prefixes,
            'immuno_prefixes' => $immuno_prefixes,
            'n_all' => count($rows),
            'row_limit' => 400,
            'notes' => $immuno['notes'],
        ],
        'settings' => $cfg,
        'official' => amr_kpi_official_stats($rows, ''),
        'official_community' => amr_kpi_official_stats($rows, 'community'),
        'official_risk_and' => amr_kpi_official_stats($rows, 'risk_and'),
        'cohorts' => $cohorts,
        'rows_community' => [],
        'rows_risk_and' => [],
        'rows_all' => [],
    ];
    if ($include_rows) {
        $out['rows_community'] = amr_kpi_slice_rows($rows, 'community');
        $out['rows_risk_and'] = amr_kpi_slice_rows($rows, 'risk_and');
        $out['rows_all'] = amr_kpi_slice_rows($rows, '');
    }
    return $out;
}
