<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('hosxp_tmt_drug_helper.php');
include('pediatric_dose_helper.php');
mysqli_set_charset($con, 'utf8');
pdc_ensure_table($con);

$tab = (isset($_GET['tab']) && $_GET['tab'] === 'settings') ? 'settings' : 'calc';
$prefill_hn = isset($_GET['hn']) ? htmlspecialchars((string)$_GET['hn'], ENT_QUOTES, 'UTF-8') : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add_item' || $action === 'edit_item') {
        $drug = function_exists('hosxp_parse_drug_option') ? hosxp_parse_drug_option($_POST['drug'] ?? '') : ['icode' => '', 'name' => ''];
        $id = ($action === 'edit_item') ? (int)($_POST['rule_id'] ?? 0) : 0;
        $name = trim((string)($_POST['drug_name'] ?? ''));
        if ($name === '' && !empty($drug['name'])) {
            $name = $drug['name'];
        }
        $icode = trim((string)($_POST['icode'] ?? ''));
        if ($icode === '' && !empty($drug['icode'])) {
            $icode = $drug['icode'];
        }
        $res = pdc_save_item($con, [
            'icode' => $icode,
            'drug_name' => $name,
            'strength_text' => $_POST['strength_text'] ?? '',
            'category' => $_POST['category'] ?? 'inject',
            'dose_unit' => $_POST['dose_unit'] ?? 'mg_kg_dose',
            'mg_per_kg_min' => $_POST['mg_per_kg_min'] ?? '',
            'mg_per_kg_max' => $_POST['mg_per_kg_max'] ?? '',
            'times_per_day' => $_POST['times_per_day'] ?? '',
            'interval_hours' => $_POST['interval_hours'] ?? '',
            'max_mg_day' => $_POST['max_mg_day'] ?? '',
            'tolerance_pct' => $_POST['tolerance_pct'] ?? '',
            'monitor_exclude_keywords' => $_POST['monitor_exclude_keywords'] ?? '',
            'mg_per_ml' => $_POST['mg_per_ml'] ?? '',
            'mg_per_amp' => $_POST['mg_per_amp'] ?? '',
            'note_text' => $_POST['note_text'] ?? '',
            'sort_order' => $_POST['sort_order'] ?? 100,
            'active' => isset($_POST['active']) ? 1 : 0,
        ], $id);
        if (!empty($res['ok'])) {
            $_SESSION['pdc_msg'] = $res['message'] ?? 'บันทึกเรียบร้อย';
        } else {
            $_SESSION['pdc_error'] = $res['error'] ?? 'บันทึกไม่สำเร็จ';
        }
        header('Location: pediatric_dose_calculator.php?tab=settings');
        exit;
    }
    if ($action === 'import_oral_liquids') {
        $res = pdc_import_catalog_rows($con, pdc_oral_liquid_catalog());
        $_SESSION['pdc_msg'] = 'นำเข้ายาน้ำเด็ก — เพิ่ม ' . (int)$res['inserted'] . ' รายการ (มีอยู่แล้ว ' . (int)$res['skipped'] . ')';
        header('Location: pediatric_dose_calculator.php?tab=settings');
        exit;
    }
    if ($action === 'delete_item') {
        $id = (int)($_POST['rule_id'] ?? 0);
        if ($id > 0) {
            mysqli_query($con, "DELETE FROM pediatric_dose_settings WHERE id=$id");
            $_SESSION['pdc_msg'] = 'ลบรายการยาเรียบร้อย';
        }
        header('Location: pediatric_dose_calculator.php?tab=settings');
        exit;
    }
}

$all_items = pdc_load_items($con, false);
$catalog = [];
foreach ($all_items as $r) {
    if (!empty($r['active'])) {
        $catalog[] = pdc_item_public($r);
    }
}

$flash_msg = $_SESSION['pdc_msg'] ?? '';
$flash_err = $_SESSION['pdc_error'] ?? '';
unset($_SESSION['pdc_msg'], $_SESSION['pdc_error']);
session_write_close();
$catalog_json = json_encode($catalog, JSON_UNESCAPED_UNICODE);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>คำนวณขนาดยาในเด็ก - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/select2.min.css" rel="stylesheet">
    <link href="css/select2-bootstrap-5-theme.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .pdc-patient-box { background: #ecfdf5; border: 1px solid #6ee7b7; border-radius: 10px; }
        .pdc-input-yellow { background: #fff3cd !important; border-color: #ffc107 !important; font-weight: 700; }
        .pdc-times { background: #fee2e2 !important; border-color: #f87171 !important; font-weight: 700; text-align: center; max-width: 4.5rem; }
        .pdc-result { background: #fce7f3; border: 1px solid #f9a8d4; border-radius: 8px; padding: 0.7rem 0.85rem; }
        .pdc-result .val { font-size: 1.15rem; font-weight: 800; color: #9d174d; }
        .pdc-result-green { background: #dcfce7; border-color: #86efac; }
        .pdc-result-green .val { color: #166534; }
        .pdc-result-blue { background: #dbeafe; border-color: #93c5fd; }
        .pdc-result-blue .val { color: #1d4ed8; }
        .pdc-result-orange { background: #ffedd5; border-color: #fdba74; }
        .pdc-result-orange .val { color: #9a3412; }
        .pdc-method { background: #ffedd5; border: 1px solid #fdba74; border-radius: 8px; padding: 0.75rem 1rem; font-weight: 600; }
        tr.pdc-row { cursor: pointer; }
        tr.pdc-row:hover { background: #e0f2fe; }
        tr.pdc-row-picked { background: #dbeafe !important; }
        tr.pdc-capped td.pdc-mgday { color: #b45309; font-weight: 700; }
        .pdc-ml { background: #e0f2fe; }
        #pdcFormCard.edit-mode .card-header { background-color: #0a58ca !important; }
        tr.pdc-editing-row { background-color: #e7f1ff !important; }
        .pdc-tabs .nav-link { font-weight: 700; color: #475569; border: 1px solid transparent; border-radius: 8px 8px 0 0; padding: 0.65rem 1.15rem; }
        .pdc-tabs .nav-link:hover { color: #db2777; background: #fdf2f8; }
        .pdc-tabs .nav-link.active { color: #be185d; background: #fff; border-color: #dee2e6 #dee2e6 #fff; }
        .pdc-filter .btn { font-weight: 700; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-1 text-dark">
                <i class="fas fa-child me-2" style="color:#db2777;"></i>คำนวณขนาดยาในเด็ก
            </h4>
            <p class="text-muted small mb-3">กรอก HN เพื่อดึงน้ำหนักล่าสุด แล้วคำนวณยาน้ำเด็ก (mg/day, mg/dose, mL/dose) ตาม mg/kg — ปรับครั้งต่อวันได้ที่ช่องสีแดง</p>

            <ul class="nav nav-tabs pdc-tabs mb-0" id="pdcTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo $tab === 'calc' ? 'active' : ''; ?>" id="pdc-tab-calc" data-bs-toggle="tab" data-bs-target="#pdc-pane-calc" type="button" role="tab">
                        <i class="fas fa-calculator me-1"></i> คำนวณ
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo $tab === 'settings' ? 'active' : ''; ?>" id="pdc-tab-settings" data-bs-toggle="tab" data-bs-target="#pdc-pane-settings" type="button" role="tab">
                        <i class="fas fa-cogs me-1"></i> ตั้งค่ารายการยา
                    </button>
                </li>
            </ul>
            <div class="tab-content bg-white border border-top-0 p-3 rounded-bottom shadow-sm mb-3">

            <?php if ($flash_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo htmlspecialchars($flash_msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            <?php if ($flash_err): ?>
            <div class="alert alert-danger alert-dismissible fade show"><?php echo htmlspecialchars($flash_err); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <div class="tab-pane fade <?php echo $tab === 'calc' ? 'show active' : ''; ?>" id="pdc-pane-calc" role="tabpanel">
            <div class="card border-0 shadow-sm mb-3 pdc-patient-box">
                <div class="card-body py-3">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">HN <span class="text-danger">*</span></label>
                            <input type="text" id="pdc_hn" class="form-control form-control-lg fw-bold border-success" placeholder="กรอก HN" value="<?php echo $prefill_hn; ?>">
                        </div>
                        <div class="col-md-2">
                            <button type="button" id="pdcBtnLookup" class="btn btn-success btn-lg w-100 fw-bold">
                                <i class="fas fa-search me-1"></i> ค้นหา
                            </button>
                        </div>
                        <div class="col-md-4">
                            <div id="pdcPatientInfo" class="small text-muted">ยังไม่ได้เลือกผู้ป่วย — กรอก HN แล้วกดค้นหา</div>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">น้ำหนักล่าสุด (kg)</label>
                            <input type="number" id="pdc_bw" class="form-control pdc-input-yellow" min="0.1" step="0.1" placeholder="kg">
                            <div class="small text-muted" id="pdcBwHint">ค้นหา HN เพื่อดึงน้ำหนักจาก HOSxP หรือกรอกเอง</div>
                        </div>
                    </div>
                    <div id="pdcMsg" class="mt-2 small" style="display:none;"></div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white fw-bold">
                    <i class="fas fa-pills me-1" style="color:#db2777;"></i> <span id="pdcSelName">เลือกยาจากตาราง</span>
                </div>
                <div class="card-body">
                    <div class="small text-muted mb-2" id="pdcSelMeta">คลิกแถวในตารางเพื่อดูรายละเอียด</div>
                    <div class="row g-2">
                        <div class="col-6 col-lg-3">
                            <div class="pdc-result-orange pdc-result">
                                <div class="small text-muted">mg / วัน</div>
                                <div class="val" id="pdcOutDay">—</div>
                            </div>
                        </div>
                        <div class="col-6 col-lg-3">
                            <div class="pdc-result">
                                <div class="small text-muted">mg / ครั้ง</div>
                                <div class="val" id="pdcOutDose">—</div>
                            </div>
                        </div>
                        <div class="col-6 col-lg-3">
                            <div class="pdc-result pdc-result-green">
                                <div class="small text-muted">mL / ครั้ง</div>
                                <div class="val" id="pdcOutMl">—</div>
                            </div>
                        </div>
                        <div class="col-6 col-lg-3">
                            <div class="pdc-result pdc-result-blue">
                                <div class="small text-muted">Amp/vial / วัน</div>
                                <div class="val" id="pdcOutAmp">—</div>
                            </div>
                        </div>
                    </div>
                    <div class="pdc-method mt-3" id="pdcSuggest">ใส่น้ำหนัก แล้วคลิกยาในตาราง</div>
                </div>
            </div>

            <div class="d-flex flex-wrap gap-2 align-items-center mb-2 pdc-filter">
                <button type="button" class="btn btn-sm btn-outline-secondary pdc-cat" data-cat="">ทั้งหมด</button>
                <button type="button" class="btn btn-sm btn-dark pdc-cat" data-cat="oral">ยาน้ำเด็ก</button>
                <button type="button" class="btn btn-sm btn-outline-secondary pdc-cat" data-cat="inject">ยาฉีด</button>
                <button type="button" class="btn btn-sm btn-outline-secondary pdc-cat" data-cat="other">อื่น ๆ</button>
                <input type="text" id="pdcSearch" class="form-control form-control-sm ms-auto" style="max-width:16rem;" placeholder="ค้นหายา...">
            </div>
            <div class="table-responsive">
                <table class="table table-sm table-bordered table-hover align-middle mb-0">
                    <thead class="table-light text-center small">
                        <tr>
                            <th>ยา</th>
                            <th>ความแรง</th>
                            <th>ช่วงขนาด</th>
                            <th>หน่วย</th>
                            <th>ครั้ง/วัน</th>
                            <th>max mg/วัน</th>
                            <th>mg/วัน</th>
                            <th>mg/ครั้ง</th>
                            <th class="pdc-ml">mL/ครั้ง</th>
                        </tr>
                    </thead>
                    <tbody id="pdcTableBody">
                        <tr><td colspan="9" class="text-center text-muted py-4">ใส่น้ำหนักเพื่อคำนวณทั้งตาราง</td></tr>
                    </tbody>
                </table>
            </div>
            <div class="small text-muted mt-2">ช่องสีแดง = ปรับจำนวนครั้งต่อวันได้ (เช่น ทุก 6 ชม. = 4) โดยไม่ต้องแก้ตั้งค่า</div>
            </div>

            <div class="tab-pane fade <?php echo $tab === 'settings' ? 'show active' : ''; ?>" id="pdc-pane-settings" role="tabpanel">
            <div class="alert alert-info py-2 small mb-3">
                กำหนดช่วง <b>mg/kg</b> ต่อครั้ง หรือต่อวัน และความเข้มข้นของยาน้ำ (เช่น 125 mg/5 mL = 25 mg/mL) เพื่อคำนวณ mL/ครั้ง
                — รายการที่เปิดใช้งานจะถูกดึงไปใช้ใน <a href="monitor_pediatric_dose.php" class="fw-bold">Monitor ยาเด็ก</a> โดยอัตโนมัติ
                — ตั้ง <b>ยอมคลาดเคลื่อน ±%</b> ต่อรายการได้ (ว่างไว้จะใช้ค่าทั้งระบบใน Monitor)
            </div>
            <div class="mb-3">
                <form method="post" class="d-inline" onsubmit="return confirm('นำเข้ายาน้ำเด็กจากตารางคำนวณ (แถวที่ยังไม่มี)?');">
                    <input type="hidden" name="action" value="import_oral_liquids">
                    <button type="submit" class="btn btn-sm btn-outline-primary fw-bold">
                        <i class="fas fa-file-import me-1"></i> นำเข้ายาน้ำเด็กจากตารางคำนวณ
                    </button>
                </form>
                <a href="monitor_pediatric_dose.php" class="btn btn-sm btn-outline-success">
                    <i class="fas fa-child me-1"></i> เปิด Monitor ยาเด็ก
                </a>
            </div>
            <div class="row g-4">
                <div class="col-lg-5">
                    <div class="card shadow-sm border-0" id="pdcFormCard">
                        <div class="card-header text-white fw-bold" style="background:#db2777;">
                            <i class="fas fa-plus-circle me-1"></i> <span id="pdcFormTitle">เพิ่มรายการยา</span>
                        </div>
                        <div class="card-body">
                            <form method="post" id="pdcItemForm">
                                <input type="hidden" name="action" id="pdc_action" value="add_item">
                                <input type="hidden" name="rule_id" id="pdc_rule_id" value="">
                                <input type="hidden" name="icode" id="pdc_icode" value="">
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">ค้นหาจาก HOSxP (ไม่บังคับ)</label>
                                    <select id="pdc_item_drug" class="form-select form-select-sm">
                                        <option value="">ค้นหายา...</option>
                                    </select>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">ชื่อยา <span class="text-danger">*</span></label>
                                    <input type="text" name="drug_name" id="pdc_drug_name" class="form-control form-control-sm" required placeholder="เช่น Amoxicillin 125 mg/5 mL">
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">ความแรง</label>
                                    <input type="text" name="strength_text" id="pdc_strength_text" class="form-control form-control-sm" placeholder="เช่น 1 g/10 mL หรือ 250 mg/5 mL">
                                </div>
                                <div class="row g-2 mb-2">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">หมวด</label>
                                        <select name="category" id="pdc_category" class="form-select form-select-sm">
                                            <option value="oral" selected>ยาน้ำเด็ก</option>
                                            <option value="inject">ยาฉีด</option>
                                            <option value="other">อื่น ๆ</option>
                                        </select>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">หน่วยขนาดยา</label>
                                        <select name="dose_unit" id="pdc_dose_unit" class="form-select form-select-sm">
                                            <option value="mg_kg_dose">mg/kg/dose (ต่อครั้ง)</option>
                                            <option value="mg_kg_day">mg/kg/day (ต่อวัน)</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row g-2 mb-2">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">mg/kg ต่ำสุด</label>
                                        <input type="number" name="mg_per_kg_min" id="pdc_kg_min" class="form-control form-control-sm" min="0" step="0.01" placeholder="เช่น 25">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">mg/kg สูงสุด</label>
                                        <input type="number" name="mg_per_kg_max" id="pdc_kg_max" class="form-control form-control-sm" min="0" step="0.01" placeholder="เช่น 100">
                                    </div>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">ช่วงการให้ยา</label>
                                    <select name="interval_hours" id="pdc_item_interval" class="form-select form-select-sm">
                                        <option value="">กำหนดครั้ง/วันเอง</option>
                                        <option value="4">ทุก 4 ชั่วโมง (×6 /วัน)</option>
                                        <option value="6">ทุก 6 ชั่วโมง (×4 /วัน)</option>
                                        <option value="8">ทุก 8 ชั่วโมง (×3 /วัน)</option>
                                        <option value="12">ทุก 12 ชั่วโมง (×2 /วัน)</option>
                                        <option value="24">ทุก 24 ชั่วโมง (×1 /วัน)</option>
                                    </select>
                                </div>
                                <div class="row g-2 mb-2">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">ครั้งต่อวัน</label>
                                        <input type="number" name="times_per_day" id="pdc_times" class="form-control form-control-sm" min="0.5" step="0.5" value="1">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">max mg/วัน</label>
                                        <input type="number" name="max_mg_day" id="pdc_max_day" class="form-control form-control-sm" min="0" step="0.01" placeholder="ไม่บังคับ">
                                    </div>
                                </div>
                                <div class="row g-2 mb-2">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">ยอมคลาดเคลื่อน ± (%)</label>
                                        <input type="number" name="tolerance_pct" id="pdc_tolerance_pct" class="form-control form-control-sm" min="0" max="100" step="1" placeholder="ว่าง = ใช้ค่าทั้งระบบ">
                                    </div>
                                    <div class="col-6 d-flex align-items-end">
                                        <div class="form-text small mb-1">Monitor ยาเด็ก — ไม่ใส่จะใช้ค่าทั้งระบบ</div>
                                    </div>
                                </div>
                                <div class="row g-2 mb-2">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">mg/mL</label>
                                        <input type="number" name="mg_per_ml" id="pdc_mg_per_ml" class="form-control form-control-sm" min="0" step="0.0001" placeholder="เช่น 100">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">mg ต่อ Amp/vial</label>
                                        <input type="number" name="mg_per_amp" id="pdc_mg_per_amp" class="form-control form-control-sm" min="0" step="0.01" placeholder="เช่น 1000">
                                    </div>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">หมายเหตุ / duration</label>
                                    <input type="text" name="note_text" id="pdc_note" class="form-control form-control-sm" placeholder="เช่น IV every 8 hr">
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">ยกเว้น Monitor เมื่อพบคำ (คั่นด้วย ,)</label>
                                    <input type="text" name="monitor_exclude_keywords" id="pdc_monitor_exclude_keywords" class="form-control form-control-sm" placeholder="เช่น หนองใน, gonorrhea, single dose">
                                    <div class="form-text small">ใช้กับเคส fixed dose ตามโรค — ถ้าพบคำในวิธีใช้/ชื่อยา จะข้ามการแจ้งเตือนรายการนี้</div>
                                </div>
                                <div class="row g-2 mb-2">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">ลำดับแสดง</label>
                                        <input type="number" name="sort_order" id="pdc_sort" class="form-control form-control-sm" value="100">
                                    </div>
                                    <div class="col-6 d-flex align-items-end">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="active" id="pdc_active" checked>
                                            <label class="form-check-label small fw-bold" for="pdc_active">เปิดใช้งาน</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-sm btn-success fw-bold">บันทึก</button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" id="pdcBtnReset">ล้างฟอร์ม</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="mb-2">
                        <input type="text" id="pdcRuleSearch" class="form-control form-control-sm" placeholder="ค้นหายา...">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover border align-middle">
                            <thead class="table-light text-center small">
                                <tr>
                                    <th>ยา</th><th>mg/kg</th><th>หน่วย</th><th>ครั้ง/วัน</th><th>±%</th><th>หมวด</th><th>เปิด</th><th>จัดการ</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (empty($all_items)): ?>
                                <tr><td colspan="8" class="text-center text-muted py-3">ยังไม่มีรายการ</td></tr>
                            <?php else: foreach ($all_items as $r):
                                $pub = pdc_item_public($r);
                                $rule_json = htmlspecialchars(json_encode($pub, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
                            ?>
                                <tr class="pdc-rule-row" data-rule-id="<?php echo (int)$r['id']; ?>">
                                    <td class="small"><b><?php echo htmlspecialchars($r['drug_name']); ?></b>
                                        <?php if (!empty($r['strength_text'])): ?>
                                        <br><span class="text-muted"><?php echo htmlspecialchars($r['strength_text']); ?></span>
                                        <?php endif; ?>
                                        <?php if (!empty($r['monitor_exclude_keywords'])): ?>
                                        <br><span class="badge bg-warning text-dark">ยกเว้น: <?php echo htmlspecialchars($r['monitor_exclude_keywords']); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center small"><?php echo htmlspecialchars(pdc_fmt_range($pub['mg_per_kg_min'], $pub['mg_per_kg_max'])); ?></td>
                                    <td class="text-center small"><?php echo htmlspecialchars(pdc_unit_label($pub['dose_unit'])); ?></td>
                                    <td class="text-center small"><?php echo htmlspecialchars(pdc_interval_label($pub['times_per_day'], $pub['interval_hours'])); ?></td>
                                    <td class="text-center small"><?php
                                        if ($pub['tolerance_pct'] !== null) {
                                            echo '±' . htmlspecialchars(pdc_fmt($pub['tolerance_pct'], 1));
                                        } else {
                                            echo '<span class="text-muted">ทั้งระบบ</span>';
                                        }
                                    ?></td>
                                    <td class="text-center small"><?php echo htmlspecialchars(pdc_category_label($pub['category'])); ?></td>
                                    <td class="text-center"><?php echo !empty($r['active']) ? '<span class="badge bg-success">เปิด</span>' : '<span class="badge bg-secondary">ปิด</span>'; ?></td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-sm btn-outline-primary pdc-btn-edit" data-rule="<?php echo $rule_json; ?>">แก้ไข</button>
                                        <form method="post" class="d-inline" onsubmit="return confirm('ลบรายการนี้?');">
                                            <input type="hidden" name="action" value="delete_item">
                                            <input type="hidden" name="rule_id" value="<?php echo (int)$r['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">ลบ</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            </div>

            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/select2.min.js"></script>
<script>window.PDC_CATALOG = <?php echo $catalog_json ?: '[]'; ?>;</script>
<script src="js/pediatric_dose_calculator.js?v=20260820a"></script>
</body>
</html>
