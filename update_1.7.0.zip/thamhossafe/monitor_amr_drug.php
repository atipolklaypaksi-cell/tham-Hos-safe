<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor AMR Drug — ใช้ยาเหมาะสม / ไม่เหมาะสม</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: #e8f1ec; }
        #content.mad-content {
            background:
                radial-gradient(1000px 380px at 100% -8%, rgba(220,38,38,.10), transparent 55%),
                #e8f1ec;
            min-height: 100vh;
        }
        .mad-hero { display: flex; justify-content: space-between; align-items: flex-end; gap: 16px; flex-wrap: wrap; margin-bottom: 16px; }
        .mad-kicker {
            display: inline-flex; align-items: center; gap: 8px;
            font-size: .75rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase;
            color: #991b1b; background: rgba(220,38,38,.12); border: 1px solid rgba(153,27,27,.15);
            border-radius: 999px; padding: 4px 10px; margin-bottom: 8px;
        }
        .mad-title { font-size: 1.45rem; font-weight: 800; color: #12261c; margin: 0; }
        .mad-sub { color: #5f7468; font-size: .9rem; margin: .2rem 0 0; }
        .mad-panel {
            background: #fff; border: 1px solid #d7e4dc; border-radius: 14px;
            padding: 1rem 1.1rem; box-shadow: 0 8px 24px rgba(18,38,28,.04);
        }
        .mad-kpi { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 14px; }
        .mad-kpi-card {
            background: #fff; border: 1px solid #d7e4dc; border-radius: 12px; padding: .85rem 1rem;
        }
        .mad-kpi-card .lbl { font-size: .75rem; color: #5f7468; font-weight: 700; }
        .mad-kpi-card .num { font-size: 1.7rem; font-weight: 800; line-height: 1.1; color: #12261c; }
        .mad-kpi-card .hint { font-size: .72rem; color: #7a8c84; margin-top: 4px; line-height: 1.3; }
        .mad-kpi-card.is-alert { border-color: #fecaca; background: #fff7f7; }
        .mad-kpi-card.is-alert .num { color: #dc2626; }
        .mad-kpi-card.is-ok { border-color: #bbf7d0; background: #f0fdf4; }
        .mad-kpi-card.is-ok .num { color: #166534; }
        .mad-kpi-card.is-deesc { border-color: #bfdbfe; background: #eff6ff; }
        .mad-kpi-card.is-deesc .num { color: #1d4ed8; }
        .badge-esc { background: #c2410c; color: #fff; font-weight: 800; }
        .badge-deesc { background: #1d4ed8; color: #fff; font-weight: 800; }
        .mad-tabs .nav-link.is-esc.active { color: #c2410c; }
        .mad-tabs .nav-link.is-deesc.active { color: #1d4ed8; }
        .mad-alt { display: block; font-size: .72rem; line-height: 1.3; margin-top: 2px; }
        .mad-alt.de { color: #1d4ed8; }
        .mad-alt.es { color: #c2410c; }
        .mad-share {
            height: 12px; border-radius: 999px; overflow: hidden;
            display: flex; background: #e5eee9; margin-top: 2px;
        }
        .mad-share span { display: block; height: 100%; }
        .mad-share .sh-r { background: #dc2626; }
        .mad-share .sh-i { background: #eab308; }
        .mad-share .sh-s { background: #16a34a; }
        .mad-share-legend { display: flex; gap: 12px; flex-wrap: wrap; font-size: .75rem; color: #5f7468; margin-top: 6px; }
        .mad-share-legend i { display: inline-block; width: 8px; height: 8px; border-radius: 2px; margin-right: 4px; }
        .mad-tabs .nav-link { font-size: .82rem; font-weight: 700; color: #5f7468; }
        .mad-tabs .nav-link.active { color: #146c4a; }
        .mad-tabs .nav-link.is-r.active { color: #991b1b; }
        .badge-r { background: #dc2626; color: #fff; font-weight: 800; }
        .badge-s { background: #16a34a; color: #fff; font-weight: 800; }
        .badge-i { background: #eab308; color: #1c1917; font-weight: 800; }
        .mad-table { font-size: .82rem; margin: 0; }
        .mad-table thead th {
            background: #f6faf8; color: #146c4a; font-weight: 700; white-space: nowrap;
            border-bottom: 1px solid #d7e4dc; position: sticky; top: 0; z-index: 1;
        }
        .mad-table td.mad-date-stale,
        .mad-table td .mad-date-stale {
            color: #dc2626 !important;
            font-weight: 800;
        }
        .badge-r { background: #dc2626; color: #fff; font-weight: 800; }
        .badge-res { background: #fee2e2; color: #991b1b; font-weight: 800; }
        .mad-status { font-size: .82rem; color: #5f7468; }
        .mad-status.is-error { color: #b91c1c; }
        .table-scroll { max-height: 62vh; overflow: auto; }
        .mad-toolbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
        .badge-renal-adj { background: #ffedd5; color: #c2410c; font-weight: 800; }
        .badge-renal-av { background: #dc2626; color: #fff; font-weight: 800; }
        .badge-renal-ok { background: #dcfce7; color: #166534; font-weight: 800; }
        .mad-renal-note { display: block; font-size: .7rem; margin-top: 2px; color: #c2410c; line-height: 1.3; }
        .mad-renal-note.avoid { color: #991b1b; font-weight: 700; }
        #madSound.is-on { background: #dc2626; border-color: #dc2626; color: #fff; }
        .mad-countdown {
            display: inline-flex; align-items: center; gap: 6px;
            font-variant-numeric: tabular-nums; font-weight: 800; font-size: .82rem;
            color: #991b1b; background: #fff; border: 1px solid #fecaca;
            border-radius: 999px; padding: .28rem .7rem; min-width: 7.8rem;
            justify-content: center; white-space: nowrap;
        }
        .mad-countdown.is-soon { background: #fef2f2; animation: mad-count-pulse 1s ease-in-out infinite; }
        .mad-countdown.is-loading { color: #5f7468; border-color: #d7e4dc; background: #f8faf9; animation: none; }
        .mad-countdown.is-alert { background: #dc2626; border-color: #dc2626; color: #fff; animation: none; }
        @keyframes mad-count-pulse {
            0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,.25); }
            50% { box-shadow: 0 0 0 4px rgba(220,38,38,.08); }
        }
        .badge-new { background: #dc2626; color: #fff; font-weight: 800; font-size: .65rem; margin-left: 4px; }
        tr.is-new-case td { background: #fef2f2; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content mad-content">
        <div class="container-fluid py-3">
            <div class="mad-hero">
                <div>
                    <div class="mad-kicker"><i class="fas fa-exclamation-triangle"></i> AMR · Monitor Drug</div>
                    <h1 class="mad-title">Monitor AMR Drug</h1>
                    <p class="mad-sub" id="madSourceHint">เฉพาะผู้ป่วยในที่ยังไม่จำหน่าย — เทียบยาปฏิชีวนะที่กำลังให้ (HOSxP) กับผล AST จาก HOSxP หรือ mLAB ตามการตั้งค่า · <a href="amr_connect.php">เปลี่ยนแหล่งข้อมูล AMR</a></p>
                </div>
                <div class="mad-toolbar">
                    <select id="madSteward" class="form-select form-select-sm" style="width:auto;" title="โหมดประเมิน Escalate / De-escalate">
                        <option value="both" selected>ประเมินทั้ง Escalate และ De-escalate</option>
                        <option value="escalate">ประเมิน Escalate เท่านั้น</option>
                        <option value="deescalate">ประเมิน De-escalate เท่านั้น</option>
                    </select>
                    <div class="d-flex align-items-center gap-1" title="กรองเฉพาะผลที่วันที่รายงานไม่เกินจำนวนวันนี้ (ค่าเริ่มต้น 7 วัน)">
                        <span class="small fw-bold text-nowrap">วันที่รายงานไม่เกิน</span>
                        <input type="number" id="madReportDays" class="form-control form-control-sm" min="1" max="90" value="7" style="width:4.4rem">
                        <span class="small text-nowrap">วัน</span>
                    </div>
                    <select id="madLookback" class="form-select form-select-sm" style="width:auto;" title="หรือกรองผลแล็บที่เพิ่งออก / เฉพาะวันนี้">
                        <option value="days" selected>ใช้จำนวนวันด้านบน</option>
                        <option value="1d">เฉพาะวันนี้</option>
                        <option value="30m">หลังผลแล็บ 30 นาที</option>
                        <option value="1h">หลังผลแล็บ 1 ชั่วโมง</option>
                        <option value="3h">หลังผลแล็บ 3 ชั่วโมง</option>
                    </select>
                    <select id="madRefresh" class="form-select form-select-sm" style="width:auto;" title="Auto refresh">
                        <option value="1">รีเฟรชทุก 1 นาที</option>
                        <option value="3" selected>รีเฟรชทุก 3 นาที</option>
                        <option value="5">รีเฟรชทุก 5 นาที</option>
                        <option value="10">รีเฟรชทุก 10 นาที</option>
                    </select>
                    <span class="mad-countdown is-loading" id="madCountdown" title="นับถอยหลังถึงรีเฟรชครั้งถัดไป">
                        <i class="fas fa-clock"></i>
                        <span id="madCountdownVal">—</span>
                    </span>
                    <button type="button" class="btn btn-outline-danger btn-sm" id="madSound" title="เปิดเสียงเมื่อพบเคสใหม่หลังรีเฟรช">
                        <i class="fas fa-volume-up me-1"></i>เสียง AMR alert
                    </button>
                    <input type="search" id="madQ" class="form-control form-control-sm" placeholder="ค้นหา HN / ชื่อ / หอ / ยา" style="min-width:180px;">
                    <button type="button" class="btn btn-danger btn-sm" id="madReload">
                        <i class="fas fa-sync-alt me-1"></i>โหลดใหม่
                    </button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="madSkipToggle" title="ตั้งคำยกเว้นจากวิธีใช้">
                        <i class="fas fa-ban me-1"></i>ยกเว้นวิธีใช้
                    </button>
                    <a href="amr_sensitivity.php" class="btn btn-outline-success btn-sm">Sen ATB</a>
                </div>
            </div>
            <div class="mad-panel mb-3" id="madSkipPanel" style="display:none;">
                <h2 class="h6 fw-bold mb-2">ไม่ดึงมาประมวลถ้าวิธีใช้มีคำเหล่านี้</h2>
                <p class="small text-muted mb-2">
                    รายการที่วิธีใช้ตรงกับคำ/วลีด้านล่างจะไม่ถูกนำมาประเมินความเหมาะสม (R/S/I, Escalate, De-escalate, ขนาดตามไต)
                    — ค่าเริ่มต้นคือ <strong>ADD PD</strong> เช่น Vancomycin ใส่ PD
                </p>
                <label class="form-label small fw-bold" for="madSkipMethod">คำยกเว้น (บรรทัดละคำหรือวลี)</label>
                <textarea id="madSkipMethod" class="form-control form-control-sm mb-2" rows="4" placeholder="ADD PD"></textarea>
                <div class="d-flex gap-2 align-items-center flex-wrap">
                    <button type="button" class="btn btn-success btn-sm" id="madSkipSave">
                        <i class="fas fa-save me-1"></i>บันทึกคำยกเว้น
                    </button>
                    <span class="small text-muted" id="madSkipHint"></span>
                </div>
            </div>
            <div class="mad-kpi">
                <div class="mad-kpi-card is-alert">
                    <div class="lbl">ร้อยละใช้ยาไม่เหมาะสม</div>
                    <div class="num" id="kpiPctBad">—</div>
                    <div class="hint" id="kpiPctBadHint">คิดจากยาที่จับคู่ผล AST ได้</div>
                </div>
                <div class="mad-kpi-card is-ok">
                    <div class="lbl">ร้อยละใช้ยาเหมาะสม</div>
                    <div class="num" id="kpiPctOk">—</div>
                    <div class="hint" id="kpiPctOkHint">ผลเป็น S</div>
                </div>
                <div class="mad-kpi-card is-alert">
                    <div class="lbl">ไม่เหมาะสม (R)</div>
                    <div class="num" id="kpiAlerts">—</div>
                    <div class="hint" id="kpiPatientsHint">ผู้ป่วย — คน</div>
                </div>
                <div class="mad-kpi-card is-ok">
                    <div class="lbl">เหมาะสม (S)</div>
                    <div class="num" id="kpiOk">—</div>
                    <div class="hint" id="kpiOkPatientsHint">ผู้ป่วย — คน</div>
                </div>
                <div class="mad-kpi-card is-warn">
                    <div class="lbl">ระวัง (I)</div>
                    <div class="num" id="kpiCaution">—</div>
                    <div class="hint">ผล Intermediate</div>
                </div>
                <div class="mad-kpi-card is-alert">
                    <div class="lbl">ควร Escalate</div>
                    <div class="num" id="kpiEsc">—</div>
                    <div class="hint" id="kpiEscHint">ยาปัจจุบัน R/I ต้องเปลี่ยนยา</div>
                </div>
                <div class="mad-kpi-card is-deesc">
                    <div class="lbl">ลดชั้นได้ (De-escalate)</div>
                    <div class="num" id="kpiDeesc">—</div>
                    <div class="hint" id="kpiDeescHint">ยาปัจจุบันผล S และมียาระดับ AWaRe ต่ำกว่า</div>
                </div>
                <div class="mad-kpi-card is-warn">
                    <div class="lbl">ควรปรับขนาดตามไต</div>
                    <div class="num" id="kpiRenalAdj">—</div>
                    <div class="hint" id="kpiRenalAdjHint">จากกฎ Monitor Lab Renal</div>
                </div>
                <div class="mad-kpi-card is-alert">
                    <div class="lbl">ห้ามใช้ตามไต</div>
                    <div class="num" id="kpiRenalAv">—</div>
                    <div class="hint" id="kpiRenalAvHint">hard alert</div>
                </div>
                <div class="mad-kpi-card">
                    <div class="lbl">ยา IPD ที่กำลังให้วันนี้</div>
                    <div class="num" id="kpiAtb">—</div>
                    <div class="hint" id="kpiMatchedHint">จับคู่ AST ช่วง admit — รายการ</div>
                </div>
            </div>
            <div class="mad-panel mb-3">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-1">
                    <h2 class="h6 fw-bold mb-0">สัดส่วนการใช้ยาที่จับคู่ผล AST ได้</h2>
                    <span class="small text-muted" id="kpiShareNote"></span>
                </div>
                <div class="mad-share" id="madShare"><span class="sh-s" style="width:0"></span></div>
                <div class="mad-share-legend">
                    <span><i style="background:#dc2626"></i>ไม่เหมาะสม R</span>
                    <span><i style="background:#eab308"></i>ระวัง I</span>
                    <span><i style="background:#16a34a"></i>เหมาะสม S</span>
                </div>
            </div>
            <div class="mad-panel">
                <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                    <ul class="nav nav-pills mad-tabs" id="madTabs">
                        <li class="nav-item">
                            <button type="button" class="nav-link is-r active" data-mad-tab="r">ไม่เหมาะสม (R) <span class="badge badge-r" id="tabCountR">0</span></button>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="nav-link" data-mad-tab="s">เหมาะสม (S) <span class="badge badge-s" id="tabCountS">0</span></button>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="nav-link" data-mad-tab="i">ระวัง (I) <span class="badge badge-i" id="tabCountI">0</span></button>
                        </li>
                        <li class="nav-item tab-steward tab-esc">
                            <button type="button" class="nav-link is-esc" data-mad-tab="esc">Escalate <span class="badge badge-esc" id="tabCountEsc">0</span></button>
                        </li>
                        <li class="nav-item tab-steward tab-deesc">
                            <button type="button" class="nav-link is-deesc" data-mad-tab="deesc">De-escalate <span class="badge badge-deesc" id="tabCountDeesc">0</span></button>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="nav-link" data-mad-tab="renal">ขนาดยาตามไต <span class="badge badge-renal-adj" id="tabCountRenal">0</span></button>
                        </li>
                    </ul>
                    <span class="mad-status" id="madStatus">กำลังโหลด...</span>
                </div>
                <div class="table-scroll">
                    <table class="table table-sm mad-table">
                        <thead>
                            <tr>
                                <th>หอผู้ป่วย</th>
                                <th>HN</th>
                                <th>AN</th>
                                <th>ชื่อ-สกุล</th>
                                <th>ยาที่กำลังให้</th>
                                <th>วิธีใช้</th>
                                <th>eGFR / ขนาดตามไต</th>
                                <th>SIR</th>
                                <th>ปรับชั้นยา</th>
                                <th>MIC</th>
                                <th>เชื้อ</th>
                                <th>ผลดื้อยา</th>
                                <th>Specimen</th>
                                <th>วันที่รายงาน <span class="fw-normal text-muted">(ล่าสุดก่อน)</span></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="madBody">
                            <tr><td colspan="15" class="mad-empty">กำลังโหลด</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const MAD_API = 'fetch_monitor_amr_drug_api.php';
let lastByTab = { r: [], s: [], i: [], renal: [], esc: [], deesc: [] };
let activeTab = 'r';
let stewardMode = 'both';
let lastNewKeySet = {};
const emptyTabMsg = {
    r: 'ไม่พบยาที่กำลังให้แต่ผลเป็น R',
    s: 'ไม่พบยาที่กำลังให้และผลเป็น S',
    i: 'ไม่พบยาที่กำลังให้และผลเป็น I',
    renal: 'ไม่พบยาที่ต้องปรับหรือห้ามใช้ตามไต',
    esc: 'ไม่พบเคสที่ต้อง Escalate',
    deesc: 'ไม่พบเคสที่ลดชั้นได้ (ยาปัจจุบันต้องผล S และมียาระดับ AWaRe ต่ำกว่าผล S)'
};

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function setStatus(msg, isError) {
    const el = document.getElementById('madStatus');
    el.textContent = msg;
    el.classList.toggle('is-error', !!isError);
}

function setMicroSource(src, label) {
    const el = document.getElementById('madSourceHint');
    if (!el) return;
    const name = label || (src === 'mlab' ? 'mLAB (ตาราง THAM Hos-Safe)' : 'HOSxP lab_head');
    el.innerHTML = 'เฉพาะผู้ป่วยในที่ยังไม่จำหน่าย — เทียบยาปฏิชีวนะที่กำลังให้ (HOSxP) กับผล AST จาก <strong>'
        + esc(name) + '</strong> ช่วง admit นี้เท่านั้น · <a href="amr_connect.php">เปลี่ยนแหล่งข้อมูล AMR</a>';
}

function fmtPct(v) {
    if (v == null || v === '') return '—';
    return Number(v).toFixed(1) + '%';
}

function reportAgeDays(raw) {
    const s = String(raw || '').trim();
    if (!s || s === '—') return null;
    let y = 0, m = 0, d = 0;
    let x = s.match(/(\d{4})-(\d{2})-(\d{2})/);
    if (x) {
        y = Number(x[1]); m = Number(x[2]); d = Number(x[3]);
    } else {
        x = s.match(/(\d{2})[\/\-](\d{2})[\/\-](\d{4})/);
        if (!x) return null;
        d = Number(x[1]); m = Number(x[2]); y = Number(x[3]);
    }
    if (y >= 2400) y -= 543;
    const dt = new Date(y, m - 1, d);
    if (isNaN(dt.getTime())) return null;
    const now = new Date();
    const ny = now.getFullYear() >= 2400 ? now.getFullYear() - 543 : now.getFullYear();
    const a = Date.UTC(ny, now.getMonth(), now.getDate());
    const b = Date.UTC(y, m - 1, d);
    return Math.floor((a - b) / 86400000);
}

function isStaleReport(raw) {
    const days = reportAgeDays(raw);
    return days != null && days > 5;
}

function reportSortKey(raw) {
    const s = String(raw || '').trim();
    const x = s.match(/(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
    if (!x) return 0;
    let y = Number(x[1]);
    if (y >= 2400) y -= 543;
    return y * 1e10 + Number(x[2]) * 1e8 + Number(x[3]) * 1e6
        + Number(x[4] || 0) * 1e4 + Number(x[5] || 0) * 100 + Number(x[6] || 0);
}

function sortRowsByReportDate(rows) {
    return (rows || []).slice().sort(function (a, b) {
        return reportSortKey(b.reportdatetime || b.report_date)
            - reportSortKey(a.reportdatetime || a.report_date);
    });
}

function currentRows() {
    return lastByTab[activeTab] || [];
}

function renalCell(r) {
    const renal = r.renal || {};
    const st = renal.status || '';
    const egfr = renal.egfr != null
        ? ('eGFR ' + renal.egfr + (renal.egfr_date ? ' (' + renal.egfr_date + ')' : ''))
        : 'ไม่มี eGFR';
    const scr = renal.scr != null
        ? ('Cr ' + renal.scr + (renal.scr_date ? ' (' + renal.scr_date + ')' : ''))
        : '';
    const labLine = (renal.lab_type === 'SERUM_CR' && scr)
        ? scr + (renal.egfr != null ? ' · ' + egfr : '')
        : (egfr + (scr ? ' · ' + scr : ''));
    let badge = '<span class="badge badge-renal-ok">ขนาดปกติ</span>';
    let noteCls = '';
    if (st === 'avoid') {
        badge = '<span class="badge badge-renal-av">ห้ามใช้ตามไต</span>';
        noteCls = ' avoid';
    } else if (st === 'adjust') {
        badge = '<span class="badge badge-renal-adj">ควรปรับตามไต</span>';
    } else if (st === 'no_egfr') {
        badge = '<span class="badge bg-secondary">รอ eGFR</span>';
    }
    const msg = renal.msg ? '<span class="mad-renal-note' + noteCls + '">' + esc(renal.msg) + '</span>' : '';
    return '<div class="small fw-bold">' + esc(labLine) + '</div>' + badge + msg;
}

function stewardCell(r) {
    const de = (r.deescalate_to || []).filter(Boolean);
    const es = (r.escalate_to || []).filter(Boolean);
    let html = '';
    if (Number(r.can_deescalate) && de.length) {
        html += '<span class="badge badge-deesc">ลดชั้นได้</span>'
            + '<span class="mad-alt de">' + esc(de.join(', ')) + '</span>';
    }
    if (Number(r.need_escalate)) {
        html += '<span class="badge badge-esc">ควรเปลี่ยนยา</span>'
            + (es.length ? '<span class="mad-alt es">' + esc(es.join(', ')) + '</span>' : '');
    }
    return html || '<span class="text-muted">—</span>';
}

function renderRows(rows) {
    const q = (document.getElementById('madQ').value || '').trim().toLowerCase();
    const show = sortRowsByReportDate(!q ? rows : rows.filter(function (r) {
        return [r.hn, r.an, r.ptname, r.wname, r.drugName, r.ast_drug, r.microtype, r.Specimen,
            (r.renal && r.renal.msg) || '', (r.deescalate_to || []).join(' '), (r.escalate_to || []).join(' ')]
            .join(' ').toLowerCase().indexOf(q) !== -1;
    }));
    const body = document.getElementById('madBody');
    if (!show.length) {
        body.innerHTML = '<tr><td colspan="15" class="mad-empty">'
            + (rows.length ? 'ไม่พบรายการตามคำค้น' : (emptyTabMsg[activeTab] || 'ไม่พบรายการ'))
            + '</td></tr>';
        return;
    }
    body.innerHTML = show.map(function (r) {
        const order = encodeURIComponent(r.lab_order_number || '');
        const hn = encodeURIComponent(r.hn || '');
        const href = 'amr_sensitivity.php?order=' + order + (hn ? ('&hn=' + hn) : '');
        const res = r.result ? '<span class="badge badge-res">' + esc(r.result) + '</span>' : '';
        const sir = String(r.sir || (activeTab === 'renal' ? '' : activeTab) || '').toUpperCase();
        const sirCls = sir === 'S' ? 'badge-s' : (sir === 'I' ? 'badge-i' : (sir === 'R' ? 'badge-r' : ''));
        const sirHtml = sir
            ? '<span class="badge ' + sirCls + '">' + esc(sir) + '</span>'
            : '<span class="text-muted">—</span>';
        const isNew = !!lastNewKeySet[caseKey(r)];
        const dt = r.reportdatetime || r.report_date || '';
        const stale = isStaleReport(dt);
        const dateHtml = stale
            ? '<span class="mad-date-stale" style="color:#dc2626;font-weight:800" title="วันที่รายงานเกิน 5 วัน">' + esc(dt || '—') + '</span>'
            : esc(dt || '—');
        return '<tr' + (isNew ? ' class="is-new-case"' : '') + '>'
            + '<td>' + esc(r.wname) + '</td>'
            + '<td class="fw-bold">' + esc(r.hn)
            + (isNew ? ' <span class="badge badge-new">ใหม่</span>' : '')
            + '</td>'
            + '<td>' + esc(r.an) + '</td>'
            + '<td>' + esc(r.ptname) + '</td>'
            + '<td class="fw-semibold">' + esc(r.drugName)
            + (r.icode ? '<div class="small text-muted">' + esc(r.icode) + '</div>' : '')
            + ((r.aware || r.who_aware || r.class) ? '<div class="small text-muted">'
                + esc([
                    (r.who_aware && r.aware && r.who_aware !== r.aware)
                        ? ('WHO ' + r.who_aware + ' · รพ. ' + r.aware)
                        : (r.aware || r.who_aware || ''),
                    r.class
                ].filter(Boolean).join(' · '))
                + '</div>' : '')
            + '</td>'
            + '<td>' + esc(r.method || '—') + '</td>'
            + '<td>' + renalCell(r) + '</td>'
            + '<td>' + sirHtml + '</td>'
            + '<td>' + stewardCell(r) + '</td>'
            + '<td>' + esc(r.mic || '—') + '</td>'
            + '<td>' + esc(r.microtype || '—') + '</td>'
            + '<td>' + res + '</td>'
            + '<td>' + esc(r.Specimen || '—') + '</td>'
            + '<td class="text-nowrap' + (stale ? ' mad-date-stale' : '') + '">' + dateHtml + '</td>'
            + '<td><a class="btn btn-sm btn-outline-success py-0 px-2 text-nowrap" href="' + href + '">Sen ATB</a></td>'
            + '</tr>';
    }).join('');
}

function renderShare(meta) {
    const nR = Number(meta.alerts || 0);
    const nS = Number(meta.appropriate || 0);
    const nI = Number(meta.caution || 0);
    const tot = nR + nS + nI;
    const w = function (n) { return tot > 0 ? (100 * n / tot) : 0; };
    document.getElementById('madShare').innerHTML =
        '<span class="sh-r" style="width:' + w(nR) + '%"></span>'
        + '<span class="sh-i" style="width:' + w(nI) + '%"></span>'
        + '<span class="sh-s" style="width:' + w(nS) + '%"></span>';
}

function fillSkipKeywords(list) {
    const ta = document.getElementById('madSkipMethod');
    if (!ta) return;
    const rows = Array.isArray(list) ? list : [];
    ta.value = rows.join('\n');
}

function renderMeta(meta) {
    const nR = meta.alerts != null ? meta.alerts : 0;
    const nS = meta.appropriate != null ? meta.appropriate : 0;
    const nI = meta.caution != null ? meta.caution : 0;
    const matched = meta.matched != null ? meta.matched : (nR + nS + nI);
    document.getElementById('kpiPctBad').textContent = fmtPct(meta.pct_inappropriate);
    document.getElementById('kpiPctOk').textContent = fmtPct(meta.pct_appropriate);
    document.getElementById('kpiPctBadHint').textContent = nR + ' จาก ' + matched + ' รายการที่จับคู่ AST ได้';
    document.getElementById('kpiPctOkHint').textContent = nS + ' จาก ' + matched + ' รายการที่จับคู่ AST ได้';
    document.getElementById('kpiAlerts').textContent = String(nR);
    document.getElementById('kpiOk').textContent = String(nS);
    document.getElementById('kpiCaution').textContent = String(nI);
    document.getElementById('kpiRenalAdj').textContent = String(meta.renal_adjust != null ? meta.renal_adjust : 0);
    document.getElementById('kpiRenalAv').textContent = String(meta.renal_avoid != null ? meta.renal_avoid : 0);
    document.getElementById('kpiRenalAdjHint').textContent = 'กฎ Monitor Lab Renal · ผู้ป่วย '
        + (meta.patients_renal != null ? meta.patients_renal : '—') + ' คน';
    document.getElementById('kpiRenalAvHint').textContent = 'hard · จากกฎ Monitor Lab Renal';
    document.getElementById('kpiAtb').textContent = String(meta.atb != null ? meta.atb : '—');
    document.getElementById('kpiPatientsHint').textContent = 'ผู้ป่วย ' + (meta.patients != null ? meta.patients : '—') + ' คน';
    document.getElementById('kpiOkPatientsHint').textContent = 'ผู้ป่วย ' + (meta.patients_ok != null ? meta.patients_ok : '—') + ' คน';
    document.getElementById('kpiMatchedHint').textContent = 'จับคู่ AST ช่วง admit ได้ ' + matched + ' รายการ'
        + (meta.skip_method_count ? (' · ข้ามวิธีใช้ ' + meta.skip_method_count + ' รายการ') : '');
    fillSkipKeywords(meta.skip_method_keywords);
    document.getElementById('tabCountR').textContent = String(nR);
    document.getElementById('tabCountS').textContent = String(nS);
    document.getElementById('tabCountI').textContent = String(nI);
    document.getElementById('tabCountRenal').textContent = String((meta.renal_adjust || 0) + (meta.renal_avoid || 0));
    document.getElementById('kpiEsc').textContent = String(meta.escalate != null ? meta.escalate : 0);
    document.getElementById('kpiDeesc').textContent = String(meta.deescalate != null ? meta.deescalate : 0);
    document.getElementById('kpiEscHint').textContent = 'ผู้ป่วย ' + (meta.patients_escalate != null ? meta.patients_escalate : '—') + ' คน';
    document.getElementById('kpiDeescHint').textContent = 'ยาปัจจุบันผล S · ผู้ป่วย '
        + (meta.patients_deescalate != null ? meta.patients_deescalate : '—') + ' คน';
    document.getElementById('tabCountEsc').textContent = String(meta.escalate != null ? meta.escalate : 0);
    document.getElementById('tabCountDeesc').textContent = String(meta.deescalate != null ? meta.deescalate : 0);
    const ptPct = meta.pct_patient_inappropriate != null
        ? ' · ผู้ป่วยที่มียา R ' + fmtPct(meta.pct_patient_inappropriate)
            + ' (' + (meta.patients || 0) + '/' + (meta.patients_matched || 0) + ' คน)'
        : '';
    document.getElementById('kpiShareNote').textContent =
        'ไม่นับยาที่ยังไม่มีผล AST' + ptPct;
    renderShare(meta);
}

function clearMeta() {
    ['kpiPctBad', 'kpiPctOk', 'kpiAlerts', 'kpiOk', 'kpiCaution', 'kpiAtb', 'kpiRenalAdj', 'kpiRenalAv', 'kpiEsc', 'kpiDeesc'].forEach(function (id) {
        document.getElementById(id).textContent = '—';
    });
    document.getElementById('tabCountR').textContent = '0';
    document.getElementById('tabCountS').textContent = '0';
    document.getElementById('tabCountI').textContent = '0';
    document.getElementById('tabCountRenal').textContent = '0';
    document.getElementById('tabCountEsc').textContent = '0';
    document.getElementById('tabCountDeesc').textContent = '0';
    document.getElementById('madShare').innerHTML = '<span class="sh-s" style="width:0"></span>';
}

function applyStewardTabs(mode) {
    stewardMode = (mode === 'escalate' || mode === 'deescalate') ? mode : 'both';
    const sel = document.getElementById('madSteward');
    if (sel && sel.querySelector('option[value="' + stewardMode + '"]')) sel.value = stewardMode;
    document.querySelectorAll('.tab-esc').forEach(function (el) {
        el.style.display = (stewardMode === 'deescalate') ? 'none' : '';
    });
    document.querySelectorAll('.tab-deesc').forEach(function (el) {
        el.style.display = (stewardMode === 'escalate') ? 'none' : '';
    });
    const escCard = document.getElementById('kpiEsc');
    const deCard = document.getElementById('kpiDeesc');
    if (escCard && escCard.closest('.mad-kpi-card')) {
        escCard.closest('.mad-kpi-card').style.display = (stewardMode === 'deescalate') ? 'none' : '';
    }
    if (deCard && deCard.closest('.mad-kpi-card')) {
        deCard.closest('.mad-kpi-card').style.display = (stewardMode === 'escalate') ? 'none' : '';
    }
    if (activeTab === 'esc' && stewardMode === 'deescalate') {
        setTab('deesc');
    } else if (activeTab === 'deesc' && stewardMode === 'escalate') {
        setTab('esc');
    }
}

function setTab(tab) {
    const allowed = { r: 1, s: 1, i: 1, renal: 1, esc: 1, deesc: 1 };
    if (!allowed[tab]) tab = 'r';
    if (tab === 'esc' && stewardMode === 'deescalate') tab = 'deesc';
    if (tab === 'deesc' && stewardMode === 'escalate') tab = 'esc';
    activeTab = tab;
    document.querySelectorAll('#madTabs [data-mad-tab]').forEach(function (btn) {
        btn.classList.toggle('active', btn.getAttribute('data-mad-tab') === activeTab);
    });
    renderRows(currentRows());
}

async function loadList() {
    const btn = document.getElementById('madReload');
    btn.disabled = true;
    setCountdownLoading();
    setStatus('กำลังประเมิน...');
    try {
        const lookback = currentLookback();
        const res = await fetch(MAD_API + '?action=list&lookback=' + encodeURIComponent(lookback));
        const data = await res.json();
        if (data.status !== 'success') throw new Error(data.message || 'โหลดไม่สำเร็จ');
        setMicroSource(data.source || (data.meta && data.meta.micro_source), data.source_label || (data.meta && data.meta.micro_source_label));
        lastByTab = {
            r: data.rows || [],
            s: data.rows_ok || [],
            i: data.rows_caution || [],
            renal: data.rows_renal || [],
            esc: data.rows_escalate || [],
            deesc: data.rows_deescalate || []
        };
        applyStewardTabs((data.steward && data.steward.mode) || stewardMode);
        const meta = data.meta || {};
        const newKeys = collectCaseKeys();
        const added = countNewCases(prevCaseKeys, newKeys);
        lastNewKeySet = addedKeys(prevCaseKeys, newKeys);
        renderMeta(meta);
        renderRows(currentRows());
        if (added > 0) {
            playAmrAlert(added);
            flashCountdownAlert();
            setStatus('พบเคสใหม่ ' + added + ' รายการ · ไม่เหมาะสม ' + fmtPct(meta.pct_inappropriate)
                + ' · ' + (meta.as_of || ''));
        } else {
            lastNewKeySet = {};
            setStatus('จับคู่ AST ' + (meta.matched || 0) + ' / ยาวันนี้ ' + (meta.atb || 0)
                + ' · ไม่เหมาะสม ' + fmtPct(meta.pct_inappropriate)
                + ' · ' + (meta.as_of || '')
                + (meta.lookback_label ? ' · ' + meta.lookback_label : '')
                + (meta.skip_method_count ? (' · ข้ามวิธีใช้ ' + meta.skip_method_count) : ''));
        }
        prevCaseKeys = newKeys;
    } catch (e) {
        lastByTab = { r: [], s: [], i: [], renal: [], esc: [], deesc: [] };
        lastNewKeySet = {};
        clearMeta();
        document.getElementById('madBody').innerHTML = '<tr><td colspan="15" class="mad-empty">' + esc(e.message || String(e)) + '</td></tr>';
        setStatus(e.message || String(e), true);
    } finally {
        btn.disabled = false;
        scheduleRefresh();
    }
}

const MAD_STORE = 'mad_monitor_opts';
let prevCaseKeys = null;
let refreshTimer = null;
let countdownTimer = null;
let refreshDueAt = 0;
let soundOn = true;
let audioCtx = null;

function currentLookback() {
    const lb = document.getElementById('madLookback');
    const mode = lb ? lb.value : 'days';
    if (mode && mode !== 'days') return mode;
    let n = parseInt((document.getElementById('madReportDays') || {}).value, 10);
    if (!n || n < 1) n = 7;
    if (n > 90) n = 90;
    return n + 'd';
}

function syncReportDaysEnabled() {
    const inp = document.getElementById('madReportDays');
    const lb = document.getElementById('madLookback');
    if (!inp || !lb) return;
    const useDays = !lb.value || lb.value === 'days';
    inp.disabled = !useDays;
}

function loadOpts() {
    try {
        return JSON.parse(localStorage.getItem(MAD_STORE) || '{}') || {};
    } catch (e) {
        return {};
    }
}

function saveOpts() {
    localStorage.setItem(MAD_STORE, JSON.stringify({
        v3: 1,
        lookback: currentLookback(),
        report_days: parseInt((document.getElementById('madReportDays') || {}).value, 10) || 7,
        refresh: document.getElementById('madRefresh').value,
        sound: soundOn ? 1 : 0
    }));
}

function applyOpts() {
    const o = loadOpts();
    const lb = document.getElementById('madLookback');
    const rf = document.getElementById('madRefresh');
    const daysInp = document.getElementById('madReportDays');
    let days = 7;
    const savedLb = String(o.lookback || '');
    if (o.v3) {
        let d = parseInt(o.report_days, 10);
        const dayMatch = savedLb.match(/^(\d+)d$/);
        if (dayMatch) d = parseInt(dayMatch[1], 10);
        if (d && d >= 1 && d <= 90) days = d;
    }
    if (daysInp) daysInp.value = String(days);
    if (lb) {
        if (savedLb === '30m' || savedLb === '1h' || savedLb === '3h' || savedLb === '1d') {
            lb.value = savedLb;
        } else {
            lb.value = 'days';
        }
    }
    syncReportDaysEnabled();
    if (o.refresh && rf.querySelector('option[value="' + o.refresh + '"]')) rf.value = o.refresh;
    else rf.value = '3';
    soundOn = o.sound == null ? true : !!Number(o.sound);
    document.getElementById('madSound').classList.toggle('is-on', soundOn);
}

function refreshIntervalMs() {
    const mins = parseInt(document.getElementById('madRefresh').value, 10) || 3;
    return Math.max(1, mins) * 60 * 1000;
}

function formatCountdown(ms) {
    if (ms < 0) ms = 0;
    const s = Math.ceil(ms / 1000);
    const m = Math.floor(s / 60);
    const r = s % 60;
    return m + ':' + (r < 10 ? '0' : '') + r;
}

function countdownEls() {
    return {
        wrap: document.getElementById('madCountdown'),
        val: document.getElementById('madCountdownVal')
    };
}

function setCountdownLoading() {
    refreshDueAt = 0;
    const els = countdownEls();
    if (!els.wrap || !els.val) return;
    els.wrap.classList.add('is-loading');
    els.wrap.classList.remove('is-soon', 'is-alert');
    els.val.textContent = 'โหลด...';
}

function updateCountdown() {
    const els = countdownEls();
    if (!els.wrap || !els.val) return;
    if (els.wrap.classList.contains('is-alert')) return;
    if (!refreshDueAt) {
        els.wrap.classList.add('is-loading');
        els.wrap.classList.remove('is-soon');
        return;
    }
    const left = refreshDueAt - Date.now();
    els.wrap.classList.remove('is-loading');
    els.wrap.classList.toggle('is-soon', left <= 30000);
    els.val.textContent = formatCountdown(left);
}

function flashCountdownAlert() {
    const els = countdownEls();
    if (!els.wrap || !els.val) return;
    els.wrap.classList.remove('is-loading', 'is-soon');
    els.wrap.classList.add('is-alert');
    els.val.textContent = 'เคสใหม่';
    setTimeout(function () {
        els.wrap.classList.remove('is-alert');
        updateCountdown();
    }, 4000);
}

function caseKey(r) {
    return [r.hn || '', r.an || '', r.icode || '', r.lab_order_number || ''].join('|');
}

function collectCaseKeys() {
    const set = {};
    ['r', 's', 'i', 'esc', 'deesc', 'renal'].forEach(function (tab) {
        (lastByTab[tab] || []).forEach(function (r) {
            set[caseKey(r)] = true;
        });
    });
    return set;
}

function countNewCases(prev, next) {
    if (!prev) return 0;
    let n = 0;
    Object.keys(next || {}).forEach(function (k) {
        if (!prev[k]) n++;
    });
    return n;
}

function addedKeys(prev, next) {
    const out = {};
    if (!prev) return out;
    Object.keys(next || {}).forEach(function (k) {
        if (!prev[k]) out[k] = true;
    });
    return out;
}

function unlockAudio() {
    try {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (audioCtx.state === 'suspended') audioCtx.resume();
    } catch (e) {}
    if (window.speechSynthesis) {
        window.speechSynthesis.getVoices();
    }
}

function playBeepPattern() {
    if (!audioCtx) return;
    const now = audioCtx.currentTime;
    [0, 0.28, 0.56].forEach(function (off, i) {
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.type = 'square';
        o.frequency.value = i === 1 ? 990 : 740;
        g.gain.setValueAtTime(0.0001, now + off);
        g.gain.exponentialRampToValueAtTime(0.22, now + off + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, now + off + 0.2);
        o.connect(g);
        g.connect(audioCtx.destination);
        o.start(now + off);
        o.stop(now + off + 0.22);
    });
}

function playAmrAlert(added) {
    if (!soundOn) return;
    unlockAudio();
    try {
        playBeepPattern();
    } catch (e) {}
    try {
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
            const n = Number(added) || 0;
            const text = n > 0 ? ('พบเคสใหม่ ' + n + ' รายการ') : 'พบเคสใหม่';
            const u = new SpeechSynthesisUtterance(text);
            u.lang = 'th-TH';
            u.rate = 1;
            u.pitch = 1;
            u.volume = 1;
            window.speechSynthesis.speak(u);
        }
    } catch (e) {}
}

function scheduleRefresh() {
    if (refreshTimer) {
        clearTimeout(refreshTimer);
        refreshTimer = null;
    }
    if (countdownTimer) {
        clearInterval(countdownTimer);
        countdownTimer = null;
    }
    const ms = refreshIntervalMs();
    refreshDueAt = Date.now() + ms;
    refreshTimer = setTimeout(loadList, ms);
    updateCountdown();
    countdownTimer = setInterval(updateCountdown, 250);
}

document.getElementById('madReload').addEventListener('click', function () {
    unlockAudio();
    loadList();
});
document.getElementById('madSkipToggle').addEventListener('click', function () {
    const box = document.getElementById('madSkipPanel');
    if (!box) return;
    box.style.display = box.style.display === 'none' ? '' : 'none';
});
document.getElementById('madSkipSave').addEventListener('click', async function () {
    const ta = document.getElementById('madSkipMethod');
    const hint = document.getElementById('madSkipHint');
    const btn = this;
    btn.disabled = true;
    if (hint) hint.textContent = 'กำลังบันทึก...';
    try {
        const res = await fetch(MAD_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'skip_method_save', keywords: ta.value || '' })
        });
        const data = await res.json();
        if (data.status !== 'success') throw new Error(data.message || 'บันทึกไม่สำเร็จ');
        fillSkipKeywords(data.skip_method_keywords || []);
        if (hint) hint.textContent = data.message || 'บันทึกแล้ว';
        prevCaseKeys = null;
        loadList();
    } catch (e) {
        if (hint) hint.textContent = e.message || String(e);
        setStatus(e.message || String(e), true);
    } finally {
        btn.disabled = false;
    }
});
document.getElementById('madLookback').addEventListener('change', function () {
    syncReportDaysEnabled();
    saveOpts();
    prevCaseKeys = null;
    loadList();
});
document.getElementById('madReportDays').addEventListener('change', function () {
    let n = parseInt(this.value, 10);
    if (!n || n < 1) n = 7;
    if (n > 90) n = 90;
    this.value = String(n);
    const lb = document.getElementById('madLookback');
    if (lb) lb.value = 'days';
    syncReportDaysEnabled();
    saveOpts();
    prevCaseKeys = null;
    loadList();
});
document.getElementById('madSteward').addEventListener('change', async function () {
    const mode = this.value || 'both';
    applyStewardTabs(mode);
    try {
        const res = await fetch(MAD_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'steward_mode_save', steward_mode: mode })
        });
        const data = await res.json();
        if (data.status !== 'success') throw new Error(data.message || 'บันทึกโหมดไม่สำเร็จ');
        applyStewardTabs((data.steward && data.steward.mode) || mode);
    } catch (e) {
        setStatus(e.message || String(e), true);
    }
    prevCaseKeys = null;
    loadList();
});
document.getElementById('madRefresh').addEventListener('change', function () {
    saveOpts();
    scheduleRefresh();
});
document.getElementById('madSound').addEventListener('click', function () {
    soundOn = !soundOn;
    this.classList.toggle('is-on', soundOn);
    saveOpts();
    unlockAudio();
    if (soundOn) playAmrAlert(0);
});
document.getElementById('madQ').addEventListener('input', function () { renderRows(currentRows()); });
document.querySelectorAll('#madTabs [data-mad-tab]').forEach(function (btn) {
    btn.addEventListener('click', function () {
        setTab(btn.getAttribute('data-mad-tab'));
    });
});
document.addEventListener('click', unlockAudio);
document.addEventListener('keydown', unlockAudio, { once: true });
applyOpts();
loadList();
</script>
</body>
</html>
