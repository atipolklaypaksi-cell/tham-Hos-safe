<?php
/**
 * AMASS dictionary สำหรับ AMR Dashboard
 * เก็บ mapping เชื้อ / specimen / ผลดื้อยา แทน CASE ที่ฮาร์ดโค้ด
 */

function amr_dict_categories() {
    return [
        'organism' => ['label' => 'ชนิดเชื้อ (microtype)', 'icon' => 'fa-bacteria', 'dashboard' => true],
        'specimen' => ['label' => 'Specimen', 'icon' => 'fa-vial', 'dashboard' => true],
        'result' => ['label' => 'ผลดื้อยา', 'icon' => 'fa-notes-medical', 'dashboard' => true],
        'ward' => ['label' => 'หอผู้ป่วย (AMASS ICU)', 'icon' => 'fa-procedures', 'dashboard' => false],
        'ward_alias' => ['label' => 'ชื่อหอ (ส่งออก AMASS)', 'icon' => 'fa-hospital-alt', 'dashboard' => false],
        'antibiotic' => ['label' => 'ยาปฏิชีวนะ', 'icon' => 'fa-capsules', 'dashboard' => false],
        'variable' => ['label' => 'ชื่อคอลัมน์ AMASS', 'icon' => 'fa-columns', 'dashboard' => false],
        'admission' => ['label' => 'ค่า Admission', 'icon' => 'fa-hospital', 'dashboard' => false],
        'other' => ['label' => 'อื่น ๆ', 'icon' => 'fa-list', 'dashboard' => false],
    ];
}

function amr_dict_files() {
    return [
        'microbiology' => ['label' => 'Microbiology', 'filename' => 'dictionary_for_microbiology_data.xlsx'],
        'admission' => ['label' => 'Hospital admission', 'filename' => 'dictionary_for_hospital_admission_data.xlsx'],
        'drug' => ['label' => 'Drug', 'filename' => 'dictionary_for_drug_data.xlsx'],
        'ward' => ['label' => 'Wards', 'filename' => 'dictionary_for_wards.xlsx'],
        'builtin' => ['label' => 'ค่าเริ่มต้น (HOSxP CASE)', 'filename' => ''],
        'manual' => ['label' => 'เพิ่มเอง', 'filename' => ''],
    ];
}

function amr_dict_variable_keys() {
    static $keys = null;
    if ($keys !== null) {
        return $keys;
    }
    $list = [
        'hospital_number', 'hn', 'an', 'hospital_admission_number',
        'specimen_collection_date', 'specimen_date', 'organism', 'organism_name',
        'specimen_type', 'specimen', 'specimen_code',
        'ast_date', 'date_of_admission', 'date_of_discharge', 'admission_date', 'discharge_date',
        'discharge_status', 'gender', 'sex', 'age', 'age_year', 'age_day',
        'ward', 'ward_name', 'ward_code', 'icu', 'department',
        'hospital_name', 'hospital_code', 'survey_period',
        'antibiotic', 'antibiotic_name', 'drug_name', 'atc_code',
        'ast', 'ast_result', 'mic', 'route', 'dose', 'frequency',
        'department_of_prescribing_doctors',
    ];
    $keys = [];
    foreach ($list as $k) {
        $keys[$k] = true;
    }
    return $keys;
}

function amr_dict_label_map() {
    return [
        'organism_escherichia_coli' => 'E.coli',
        'organism_klebsiella_pneumoniae' => 'K.pneumoniae',
        'organism_klebsiella_spp' => 'Klebsiella species',
        'organism_acinetobacter_baumannii' => 'A.baumannii',
        'organism_acinetobacter_spp' => 'Acinetobacter species',
        'organism_pseudomonas_aeruginosa' => 'P.aeruginosa',
        'organism_staphylococcus_aureus' => 'S.aureus',
        'organism_enterococcus_faecium' => 'Enterococcus faecium',
        'organism_enterococcus_faecalis' => 'Enterococcus faecalis',
        'organism_enterobacter_cloacae' => 'Enterobacter cloacae',
        'organism_enterobacter_spp' => 'Enterobacter cloacae',
        'organism_staphylococcus_epidermidis' => 'Staphylococcus epidermidis',
        'organism_staphylococcus_hominis' => 'Staphylococcus hominis',
        'organism_staphylococcus_haemolyticus' => 'Staphylococcus haemolyticus',
        'organism_proteus_mirabilis' => 'Proteus mirabilis',
        'organism_morganella_morganii' => 'Morganella morganii',
        'organism_no_growth' => 'No growth',
        'blood_specimen' => 'Blood',
        'urine_specimen' => 'Urine',
        'sputum_specimen' => 'Sputum',
        'csf_specimen' => 'CSF',
        'sterile_fluid_specimen' => 'Body Fluid',
        'pus_specimen' => 'Pus',
        'stool_specimen' => 'Stool',
        'genital_specimen' => 'Genital Tract',
        'respiratory_specimen' => 'Sputum',
        'other_specimen' => 'Others Specimen',
        'specimen_blood' => 'Blood',
        'specimen_urine' => 'Urine',
        'specimen_respiratory_tract' => 'Sputum',
        'specimen_stool' => 'Stool',
        'specimen_cerebrospinal_fluid' => 'CSF',
        'specimen_genital_swab' => 'Genital Tract',
        'specimen_others' => 'Others Specimen',
        'icu' => 'ICU',
        'non_icu' => 'non-ICU',
        'non-icu' => 'non-ICU',
    ];
}

function amr_dict_default_label($amass_key, $fallback = '') {
    $k = strtolower(trim((string)$amass_key));
    $map = amr_dict_label_map();
    if (isset($map[$k])) {
        return $map[$k];
    }
    $s = trim((string)$amass_key);
    if ($s === '') {
        return $fallback !== '' ? $fallback : '';
    }
    $s = preg_replace('/^organism_/', '', $s);
    $s = preg_replace('/_specimen$/', '', $s);
    $s = str_replace(['_', '-'], ' ', $s);
    $s = trim(preg_replace('/\s+/', ' ', $s));
    return $s === '' ? $fallback : ucwords($s);
}

function amr_dict_cache($set = null) {
    static $cache = null;
    if ($set !== null) {
        $cache = $set;
    }
    return $cache;
}

function amr_dict_ensure_tables($con) {
    if (!$con) {
        return false;
    }
    mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_dict_rows (
        id INT AUTO_INCREMENT PRIMARY KEY,
        dict_file VARCHAR(40) NOT NULL DEFAULT 'manual',
        category VARCHAR(40) NOT NULL,
        section VARCHAR(40) NOT NULL DEFAULT '',
        amass_key VARCHAR(255) NOT NULL DEFAULT '',
        local_value VARCHAR(512) NOT NULL DEFAULT '',
        display_label VARCHAR(191) NOT NULL DEFAULT '',
        match_mode VARCHAR(20) NOT NULL DEFAULT 'like',
        sort_order INT NOT NULL DEFAULT 0,
        active TINYINT(1) NOT NULL DEFAULT 1,
        source VARCHAR(20) NOT NULL DEFAULT 'manual',
        note VARCHAR(255) NOT NULL DEFAULT '',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_cat_active (category, active, sort_order),
        KEY idx_file (dict_file),
        KEY idx_lookup (dict_file, category, amass_key(80), local_value(80))
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_dict_meta (
        dict_file VARCHAR(40) PRIMARY KEY,
        filename VARCHAR(255) NOT NULL DEFAULT '',
        imported_at DATETIME NULL,
        imported_by VARCHAR(100) NOT NULL DEFAULT '',
        row_count INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    amr_dict_seed_builtin($con);
    if (function_exists('amr_amass_seed_ward_aliases')) {
        amr_amass_seed_ward_aliases($con);
    }
    return true;
}

function amr_dict_builtin_organism() {
    return [
        ['Klebsiella pneumoniae..(CRE_MDR)', 'K.pneumoniae'],
        ['Klebsiella pneumoniae ssp pneumoniae..(MDR)', 'K.pneumoniae'],
        ['Acinetobacter baumannii complex..(MDR)', 'A.baumannii'],
        ['Klebsiella pneumoniae..(MDR)', 'K.pneumoniae'],
        ['Escherichia coli..(CRE_MDR)', 'E.coli'],
        ['Escherichia coli..(MDR)', 'E.coli'],
        ['Pseudomonas aeruginosa..(MDR)', 'P.aeruginosa'],
        ['Klebsiella species..(MDR)', 'Klebsiella species'],
        ['Enterococcus faecium..(VRE)', 'Enterococcus faecium'],
        ['Staphylococcus aureus..(MRSA_VRSA)', 'S.aureus'],
        ['Staphylococcus aureus..(MRSA)', 'S.aureus'],
        ['Acinetobacter baumannii complex..(CRAB_MDR)', 'A.baumannii'],
        ['Acinetobacter baumannii..(CRAB_MDR)', 'A.baumannii'],
        ['Staphylococcus hominis ssp hominis..(MRSE)', 'Staphylococcus hominis'],
        ['Pseudomonas aeruginosa..(CRPA_MDR)', 'P.aeruginosa'],
        ['Staphylococcus epidermidis..(MRSE)', 'Staphylococcus epidermidis'],
        ['Staphylococcus hominis..(MRSE)', 'Staphylococcus hominis'],
        ['Staphylococcus haemolyticus..(MRSE)', 'Staphylococcus haemolyticus'],
        ['Staphylococcus saprophyticus..(MRSE)', 'Staphylococcus saprophyticus'],
        ['Klebsiella pneumoniae ssp pneumoniae..(CRE_MDR)', 'K.pneumoniae'],
        ['Acinetobacter baumannii..(MDR)', 'A.baumannii'],
        ['Staphylococcus hominis_..(MRSE)', 'Staphylococcus hominis'],
        ['Stap. haemolyticus(Inducible Clindamycin Resistance)..(MRSE)', 'Staphylococcus haemolyticus'],
        ['Stap. capitis(Inducible Clindamycin Resistance)..(MRSE)', 'Staphylococcus capitis'],
        ['Klebsiella(Enterobacter) aerogenes..(MDR)', 'Klebsiella aerogenes'],
        ['Achromobacter xylosoxidans..(MDR)', 'Achromobacter xylosoxidans'],
        ['Enterobacter cloacae..(CRE_MDR)', 'Enterobacter cloacae'],
        ['Staphylococcus cohnii ssp urealyticus..(MRSE)', 'Staphylococcus cohnii'],
        ['Staphylococcus cohnii..(MRSE)', 'Staphylococcus cohnii'],
        ['Staphylococcus capitis..(MRSE)', 'Staphylococcus capitis'],
        ['Staphylococcus caprae..(MRSE)', 'Staphylococcus caprae'],
        ['Staphylococcus warneri_..(MRSE)', 'Staphylococcus warneri'],
        ['Ralstonia pickettii..(MDR)', 'Ralstonia pickettii'],
        ['Stap. epidermidis(Inducible Clindamycin Resistance)..(MRSE', 'Staphylococcus epidermidis'],
        ['Stap. hominis (Inducible Clindamycin Resistance)..(MRSE)', 'Staphylococcus hominis'],
        ['Acinetobacter haemolyticus..(MDR)', 'Acinetobacter haemolyticus'],
        ['Pseudomonas aeruginosa..(CRPA)', 'P.aeruginosa'],
        ['Klebsiella species..(CRE_MDR)', 'Klebsiella species'],
        ['Sphingomonas paucimobilis..(MDR)', 'Sphingomonas paucimobilis'],
        ['Staphylococcus auricularis..(MRSE)', 'Staphylococcus auricularis'],
        ['Staphylococcus hominis subsp. hominis_..(MRSE)', 'Staphylococcus hominis'],
        ['Staphylococcus haemolyticus_..(MRSE)', 'Staphylococcus haemolyticus'],
        ['Citrobacter freundii..(CRE_MDR)', 'Citrobacter freundii'],
        ['Staphylococcus warneri..(MRSE)', 'Staphylococcus warneri'],
        ['Acinetobacter species..(MDR)', 'Acinetobacter species'],
        ['Acinetobacter lwoffii..(MDR', 'Acinetobacter lwoffii'],
        ['Enterobacter cloacae complex..(CRE_MDR)', 'Enterobacter cloacae'],
        ['Pseudomonas stutzeri..(MDR)', 'Pseudomonas stutzeri'],
        ['Staphylococcus sciuri..(MRSE)', 'Staphylococcus sciuri'],
        ['Staphylococcus kloosii..(MRSE)', 'Staphylococcus kloosii'],
        ['Enterococcus faecalis..(VRE', 'Enterococcus faecalis'],
        ['Staphylococcus epidermidis_..(MRSE)', 'Staphylococcus epidermidis'],
        ['Enterobacter cloacae complex..(MDR)', 'Enterobacter cloacae'],
        ['Ochrobactrum anthropi..(MDR)', 'Ochrobactrum anthropi'],
        ['Staphylococcus xylosus_..(MRSE)', 'Staphylococcus xylosus'],
        ['Kleb.pneumoniae (ESBL-producing strain)', 'K.pneumoniae'],
        ['Moraxella species..(MDR)', 'Moraxella species'],
        ['Salmonella serogroup C..(MDR)', 'Salmonella serogroup C'],
        ['Staphylococcus xylosus..(MRSE)', 'Staphylococcus xylosus'],
        ['Enterobacter cloacae..(MDR)', 'Enterobacter cloacae'],
        ['Aeromonas veronii bv sobria..(MDR', 'Aeromonas veronii'],
        ['Staphylococcus Coagulase-negative..(MRSE)', 'Staphylococcus Coagulase-negative'],
        ['Staphylococcus kloosii_..(MRSE)', 'Staphylococcus kloosii'],
        ['E.coli (ESBL-producing strain)..(MDR)', 'E.coli'],
        ['Stap. warneri(Inducible Clindamycin Resistance)..(MRSE)', 'Staphylococcus warneri'],
        ['Stap. sciuri(Inducible Clindamycin Resistance)..(MRSE)', 'Staphylococcus sciuri'],
        ['Morganella morganii..(MDR)', 'Morganella morganii'],
        ['Stap. saprophyticus(Inducible Clindamycin Resistance)..(MRSE)', 'Staphylococcus saprophyticus'],
        ['Staphylococcus aureus (Inducible Clindamycin Resistance)..(MRSA)', 'S.aureus'],
        ['Staphylococcus aureus_..(MRSA', 'S.aureus'],
        ['E.coli (ESBL-producing strain)', 'E.coli'],
        ['Brevundimonas diminuta/vesicularis..(MDR)', 'Brevundimonas diminuta'],
        ['Elizabethkingia meningoseptica..(MDR)', 'Elizabethkingia meningoseptica'],
        ['Proteus mirabilis..(MDR)', 'Proteus mirabilis'],
        ['Staphylococcus arlettae..(MRSE)', 'Staphylococcus arlettae'],
        ['Moraxella group..(MDR)', 'Moraxella group'],
        ['Coag.Neg. Staphylococci_..(MRSE)', 'Coag.Neg. Staphylococci'],
        ['Staphylococcus gallinarum..(MRSE)', 'Staphylococcus gallinarum'],
        ['Pseudomonas species..(MDR)', 'Pseudomonas species'],
        ['Morganella morganii ssp morganii..(MDR)', 'Morganella morganii'],
        ['Proteus mirabilis..(CRE_MDR)', 'Proteus mirabilis'],
        ['Klebsiella(Enterobacter) aerogenes..(CRE_MDR)', 'Klebsiella aerogenes'],
        ['Providencia stuartii..(CRE_MDR)', 'Providencia stuartii'],
        ['Pseudomonas putida..(MDR)', 'Pseudomonas putida'],
        ['Staphylococcus saprophyticus_..(MRSE)', 'Staphylococcus saprophyticus'],
        ['Acinetobacter baumannii complex..(CRAB)', 'A.baumannii'],
        ['Acinetobacter junii..(MDR)', 'Acinetobacter junii'],
        ['Staphylococcus saccharolyticus..(MRSE)', 'Staphylococcus saccharolyticus'],
        ['Acinetobacter baumannii..(CRAB)', 'A.baumannii'],
        ['Acinetobacter baumannii (CRAB_MDR)', 'A.baumannii'],
        ['Pseudomonas aeruginosa..', 'P.aeruginosa'],
    ];
}

function amr_dict_builtin_result() {
    return [
        ['(MRSA_VRSA)', 'MRSA_VRSA'],
        ['(CRE_MDR)', 'CRE_MDR'],
        ['vre', 'VRE'],
        ['(mrsa)', 'MRSA'],
        ['(MRSE)', 'MRSE'],
        ['esbl', 'ESBL'],
        ['(CRAB_MDR)', 'CRAB_MDR'],
        ['(MDR)', 'MDR'],
        ['(CRPA)', 'CRPA'],
        ['(CRPA_MDR', 'CRPA_MDR'],
        ['(CRAB)', 'CRAB'],
    ];
}

function amr_dict_builtin_specimen() {
    return [
        ['Urine (MSU,Void)', 'Urine'],
        ['SPECIMEN: Sputum', 'Sputum'],
        ['Sputum', 'Sputum'],
        ['Pus (site ??)', 'Pus'],
        ['Stool', 'Stool'],
        ['Others Specimen', 'Others Specimen'],
        ['CSF (Cerebrospinal Fluid)', 'CSF'],
        ['Blood-Hemoculture', 'Blood'],
        ['TISSUE', 'TISSUE'],
        ['Peritoneal Dialysis - PD', 'Peritoneal Dialysis'],
        ['Catheter', 'Catheter'],
        ['Genital Tract', 'Genital Tract'],
        ['Ascitic Fluid', 'Ascitic Fluid'],
        ['Ear(PUS)', 'Ear(PUS)'],
        ['Ankle', 'Ankle'],
        ['Others Source', 'Others Specimen'],
        ['Body Fluid', 'Body Fluid'],
        ['Eye', 'Eye'],
        ['C-Line', 'C-Line'],
        ['Calcaneus', 'Calcaneus'],
        ['Peritoneal Dialysis', 'Peritoneal Dialysis'],
        ['T-Tube', 'T-Tube'],
        ['Ventricle', 'Ventricle'],
        ['Bile', 'Bile'],
        ['Cervix', 'Cervix'],
        ['Joint - Synovial Fluid', 'Joint - Synovial Fluid'],
        ['Pleural Fluid', 'Pleural Fluid'],
    ];
}

function amr_dict_seed_builtin($con, $force = false) {
    if (!$force) {
        $q = mysqli_query($con, 'SELECT COUNT(*) AS c FROM amr_dict_rows');
        $row = $q ? mysqli_fetch_assoc($q) : null;
        if ($row && (int)$row['c'] > 0) {
            return true;
        }
    }
    $sets = [
        'organism' => amr_dict_builtin_organism(),
        'result' => amr_dict_builtin_result(),
        'specimen' => amr_dict_builtin_specimen(),
    ];
    $stmt = mysqli_prepare($con, "INSERT INTO amr_dict_rows
        (dict_file, category, section, amass_key, local_value, display_label, match_mode, sort_order, active, source)
        VALUES ('builtin', ?, '', ?, ?, ?, 'like', ?, 1, 'builtin')");
    if (!$stmt) {
        return false;
    }
    foreach ($sets as $cat => $rows) {
        if ($force) {
            mysqli_query($con, "DELETE FROM amr_dict_rows WHERE source = 'builtin' AND category = '" . mysqli_real_escape_string($con, $cat) . "'");
        }
        $i = 0;
        foreach ($rows as $pair) {
            $i += 10;
            $amass = $pair[1];
            $local = $pair[0];
            $label = $pair[1];
            $order = $i;
            mysqli_stmt_bind_param($stmt, 'ssssi', $cat, $amass, $local, $label, $order);
            mysqli_stmt_execute($stmt);
        }
    }
    mysqli_stmt_close($stmt);
    return true;
}

function amr_dict_prime($con) {
    amr_dict_ensure_tables($con);
    $cache = ['organism' => [], 'specimen' => [], 'result' => [], 'ward' => [], 'antibiotic' => []];
    $q = mysqli_query($con, "SELECT category, amass_key, local_value, display_label, match_mode, sort_order, source
        FROM amr_dict_rows
        WHERE active = 1 AND category IN ('organism','specimen','result','ward','antibiotic')
        ORDER BY sort_order ASC, CHAR_LENGTH(local_value) DESC, id ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cat = $r['category'];
            if (!isset($cache[$cat])) {
                $cache[$cat] = [];
            }
            $cache[$cat][] = $r;
        }
    }
    amr_dict_cache($cache);
    return $cache;
}

function amr_dict_rows_for($category) {
    $cache = amr_dict_cache();
    if (!is_array($cache) || empty($cache[$category])) {
        return [];
    }
    return $cache[$category];
}

function amr_dict_like_pattern($local, $mode) {
    $s = trim((string)$local);
    if ($s === '') {
        return '';
    }
    $mode = strtolower(trim((string)$mode));
    $has_star = strpos($s, '*') !== false;
    if ($mode === 'wildcard' || $has_star) {
        $s = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $s);
        $s = str_replace('*', '%', $s);
        return $s;
    }
    if ($mode === 'exact') {
        return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $s);
    }
    $s = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $s);
    return '%' . $s . '%';
}

function amr_dict_is_amass_specimen_row($r) {
    $amass = strtolower(trim((string)($r['amass_key'] ?? '')));
    $label = trim((string)($r['display_label'] ?? ''));
    $source = strtolower(trim((string)($r['source'] ?? '')));
    if ($source === 'import' && (strpos($amass, 'specimen_') === 0 || preg_match('/^Specimen\s+/i', $label))) {
        return true;
    }
    if (strpos($amass, 'specimen_') === 0) {
        return true;
    }
    if (preg_match('/^Specimen\s+/i', $label)) {
        return true;
    }
    return false;
}

function amr_dict_hospital_specimen_label($amass_key, $display_label, $fallback = '') {
    $label = trim((string)$display_label);
    $mapped = amr_dict_default_label($amass_key, '');
    $amass = strtolower(trim((string)$amass_key));
    $is_amass = ($amass !== '' && strpos($amass, 'specimen_') === 0)
        || preg_match('/^Specimen\s+/i', $label);
    if ($is_amass && $mapped !== '' && !preg_match('/^Specimen\s+/i', $mapped)) {
        return $mapped;
    }
    if ($label !== '') {
        return $label;
    }
    if ($mapped !== '') {
        return $mapped;
    }
    return $fallback;
}

function amr_dict_match_text($category, $text, $else = '') {
    $text = (string)$text;
    if ($text === '') {
        return $else;
    }
    foreach (amr_dict_rows_for($category) as $r) {
        $local = trim((string)($r['local_value'] ?? ''));
        if ($local === '') {
            continue;
        }
        if ($category === 'specimen' && amr_dict_is_amass_specimen_row($r)) {
            continue;
        }
        $mode = strtolower(trim((string)($r['match_mode'] ?? 'like')));
        $ok = false;
        if ($mode === 'exact') {
            $ok = strcasecmp($text, $local) === 0;
        } elseif ($mode === 'wildcard' || strpos($local, '*') !== false) {
            $pat = '/^' . str_replace('\\*', '.*', preg_quote($local, '/')) . '$/i';
            $ok = (bool)@preg_match($pat, $text);
        } else {
            $ok = stripos($text, $local) !== false;
        }
        if (!$ok) {
            continue;
        }
        $label = trim((string)($r['display_label'] ?? ''));
        if ($category === 'specimen') {
            $label = amr_dict_hospital_specimen_label($r['amass_key'] ?? '', $label, $local);
        } elseif ($label === '') {
            $label = amr_dict_default_label($r['amass_key'] ?? '', $local);
        }
        return $label !== '' ? $label : $else;
    }
    return $else;
}

function amr_dict_sql_escape($mysqli, $value) {
    if ($mysqli) {
        return mysqli_real_escape_string($mysqli, (string)$value);
    }
    return addslashes((string)$value);
}

function amr_dict_sql_case($category, $col, $else_sql, $esc_mysqli = null) {
    $rows = amr_dict_rows_for($category);
    if (empty($rows)) {
        return '';
    }
    $sql = "CASE\n";
    $n = 0;
    foreach ($rows as $r) {
        $pattern = amr_dict_like_pattern($r['local_value'] ?? '', $r['match_mode'] ?? 'like');
        if ($pattern === '') {
            continue;
        }
        if ($category === 'specimen' && amr_dict_is_amass_specimen_row($r)) {
            continue;
        }
        $label = trim((string)($r['display_label'] ?? ''));
        if ($category === 'specimen') {
            $label = amr_dict_hospital_specimen_label($r['amass_key'] ?? '', $label, $r['local_value'] ?? '');
        } elseif ($label === '') {
            $label = amr_dict_default_label($r['amass_key'] ?? '', $r['local_value'] ?? '');
        }
        if ($label === '') {
            continue;
        }
        $p = amr_dict_sql_escape($esc_mysqli, $pattern);
        $l = amr_dict_sql_escape($esc_mysqli, $label);
        $sql .= "    WHEN $col LIKE '$p' THEN '$l'\n";
        $n++;
    }
    if ($n === 0) {
        return '';
    }
    $sql .= "    ELSE $else_sql\nEND";
    return $sql;
}

function amr_dict_sql_regexp($category, $esc_mysqli = null) {
    $rows = amr_dict_rows_for($category);
    if (empty($rows)) {
        return '';
    }
    $parts = [];
    $seen = [];
    foreach ($rows as $r) {
        $token = trim((string)($r['local_value'] ?? ''));
        $token = str_replace(['*', '%'], '', $token);
        $token = trim($token);
        if ($token === '') {
            continue;
        }
        $key = strtolower($token);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $escaped = preg_replace('/([.\\[\\]*+?(){}^$|\\\\])/', '\\\\$1', $token);
        $parts[] = '(' . $escaped . ')';
    }
    if (empty($parts)) {
        return '';
    }
    $expr = implode('|', $parts);
    return amr_dict_sql_escape($esc_mysqli, $expr);
}

function amr_dict_labels($con, $category) {
    amr_dict_ensure_tables($con);
    $out = [];
    $cat = mysqli_real_escape_string($con, $category);
    $q = mysqli_query($con, "SELECT DISTINCT display_label FROM amr_dict_rows
        WHERE category = '$cat' AND active = 1 AND display_label <> ''
        ORDER BY display_label");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $out[] = $r['display_label'];
        }
    }
    return $out;
}

function amr_dict_guess_file($filename) {
    $n = strtolower((string)$filename);
    if (strpos($n, 'dictionary_for_microbiology') !== false || (strpos($n, 'microbiology') !== false && strpos($n, 'dictionary') !== false)) {
        return 'microbiology';
    }
    if (strpos($n, 'dictionary_for_hospital') !== false || (strpos($n, 'admission') !== false && strpos($n, 'dictionary') !== false)) {
        return 'admission';
    }
    if (strpos($n, 'dictionary_for_drug') !== false || (strpos($n, 'drug') !== false && strpos($n, 'dictionary') !== false)) {
        return 'drug';
    }
    if (strpos($n, 'dictionary_for_ward') !== false || (strpos($n, 'ward') !== false && strpos($n, 'dictionary') !== false)) {
        return 'ward';
    }
    return '';
}

function amr_dict_is_data_file($filename) {
    $n = strtolower((string)$filename);
    if (strpos($n, 'dictionary') !== false) {
        return false;
    }
    return (bool)preg_match('/(microbiology_data|hospital_admission_data|drug_data)\.(xlsx|xls|csv)$/', $n);
}

function amr_dict_infer_category($dict_file, $section_num, $amass_key) {
    $k = strtolower(trim((string)$amass_key));
    if ($k === '') {
        return 'other';
    }
    if (strpos($k, 'organism_') === 0) {
        return 'organism';
    }
    if (preg_match('/specimen/', $k)) {
        return 'specimen';
    }
    if (preg_match('/^(mrsa|vre|esbl|mdr|cre|crab|crpa|mrse|mrsa_vrsa|cre_mdr|crab_mdr|crpa_mdr)$/i', $k)) {
        return 'result';
    }
    $vars = amr_dict_variable_keys();
    if ($section_num === 1 || isset($vars[$k])) {
        return 'variable';
    }
    if (in_array($section_num, [2, 8, 10], true)) {
        return 'antibiotic';
    }
    if ($dict_file === 'ward') {
        return 'ward';
    }
    if ($dict_file === 'admission') {
        return 'admission';
    }
    if ($dict_file === 'drug') {
        return 'antibiotic';
    }
    return 'other';
}

function amr_dict_parse_sheet(array $rows, $dict_file) {
    $out = [];
    $section = '';
    $section_num = 0;
    $order = 0;
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $a = trim((string)($row[0] ?? ''));
        $b = trim((string)($row[1] ?? ''));
        $c = trim((string)($row[2] ?? ''));
        if ($a === '' && $b === '') {
            continue;
        }
        if (preg_match('/\[section[_\s-]*(\d+)\]/i', $a, $m) || preg_match('/\[section[_\s-]*(\d+)\]/i', $b, $m)) {
            $section_num = (int)$m[1];
            $section = 'section_' . str_pad((string)$section_num, 2, '0', STR_PAD_LEFT);
            continue;
        }
        if (preg_match('/^(variable names|data values|antibiotics|amass|standard value|your hospital)/i', $a)) {
            continue;
        }
        if (stripos($a, 'used in AMASS') !== false || stripos($a, 'used in your') !== false) {
            continue;
        }
        if ($a === '' || $b === '') {
            continue;
        }
        $cat = amr_dict_infer_category($dict_file, $section_num, $a);
        $order += 10;
        $mode = (strpos($b, '*') !== false) ? 'wildcard' : 'like';
        if ($cat === 'variable') {
            $mode = 'exact';
        }
        $out[] = [
            'dict_file' => $dict_file,
            'category' => $cat,
            'section' => $section,
            'amass_key' => $a,
            'local_value' => $b,
            'display_label' => amr_dict_default_label($a, $b),
            'match_mode' => $mode,
            'sort_order' => $order,
            'note' => $c,
            'source' => 'import',
        ];
    }
    return $out;
}

function amr_dict_parse_workbook(array $sheets, $dict_file) {
    $all = [];
    foreach ($sheets as $sheet) {
        $rows = [];
        if (isset($sheet['rows']) && is_array($sheet['rows'])) {
            $rows = $sheet['rows'];
        } elseif (is_array($sheet) && isset($sheet[0]) && is_array($sheet[0])) {
            $rows = $sheet;
        }
        foreach (amr_dict_parse_sheet($rows, $dict_file) as $item) {
            $all[] = $item;
        }
    }
    return $all;
}

function amr_dict_import($con, array $items, $dict_file, $filename, $user_name, $mode = 'merge') {
    amr_dict_ensure_tables($con);
    $dict_file = amr_dict_normalize_file($dict_file);
    if ($mode === 'replace_file') {
        $esc = mysqli_real_escape_string($con, $dict_file);
        mysqli_query($con, "DELETE FROM amr_dict_rows WHERE dict_file = '$esc' AND source = 'import'");
    }
    return amr_dict_import_fallback($con, $items, $dict_file, $filename, $user_name);
}

function amr_dict_import_fallback($con, array $items, $dict_file, $filename, $user_name) {
    $inserted = 0;
    $updated = 0;
    $skipped = 0;
    $by_cat = [];
    foreach ($items as $it) {
        $cat = amr_dict_normalize_category($it['category'] ?? 'other');
        $amass = trim((string)($it['amass_key'] ?? ''));
        $local = trim((string)($it['local_value'] ?? ''));
        if ($amass === '' || $local === '') {
            $skipped++;
            continue;
        }
        $label = trim((string)($it['display_label'] ?? ''));
        if ($label === '') {
            $label = amr_dict_default_label($amass, $local);
        }
        $section = substr(trim((string)($it['section'] ?? '')), 0, 40);
        $mode_m = amr_dict_normalize_match($it['match_mode'] ?? 'like');
        $order = (int)($it['sort_order'] ?? 0);
        $note = substr(trim((string)($it['note'] ?? '')), 0, 255);

        $esc_f = mysqli_real_escape_string($con, $dict_file);
        $esc_c = mysqli_real_escape_string($con, $cat);
        $esc_a = mysqli_real_escape_string($con, $amass);
        $esc_l = mysqli_real_escape_string($con, $local);
        $q = mysqli_query($con, "SELECT id FROM amr_dict_rows
            WHERE dict_file = '$esc_f' AND category = '$esc_c'
              AND amass_key = '$esc_a' AND local_value = '$esc_l'
              AND source = 'import'
            LIMIT 1");
        $exist = ($q && ($row = mysqli_fetch_assoc($q))) ? (int)$row['id'] : 0;
        if ($exist) {
            $esc_lab = mysqli_real_escape_string($con, $label);
            $esc_m = mysqli_real_escape_string($con, $mode_m);
            $esc_s = mysqli_real_escape_string($con, $section);
            $esc_n = mysqli_real_escape_string($con, $note);
            mysqli_query($con, "UPDATE amr_dict_rows SET
                display_label = '$esc_lab', match_mode = '$esc_m', sort_order = $order,
                section = '$esc_s', note = '$esc_n', active = 1
                WHERE id = $exist");
            $updated++;
        } else {
            $esc_lab = mysqli_real_escape_string($con, $label);
            $esc_m = mysqli_real_escape_string($con, $mode_m);
            $esc_s = mysqli_real_escape_string($con, $section);
            $esc_n = mysqli_real_escape_string($con, $note);
            $ok = mysqli_query($con, "INSERT INTO amr_dict_rows
                (dict_file, category, section, amass_key, local_value, display_label, match_mode, sort_order, active, source, note)
                VALUES ('$esc_f', '$esc_c', '$esc_s', '$esc_a', '$esc_l', '$esc_lab', '$esc_m', $order, 1, 'import', '$esc_n')");
            if ($ok) {
                $inserted++;
            } else {
                $skipped++;
                continue;
            }
        }
        if (!isset($by_cat[$cat])) {
            $by_cat[$cat] = 0;
        }
        $by_cat[$cat]++;
    }
    amr_dict_touch_meta($con, $dict_file, $filename, $user_name, $inserted + $updated);
    amr_dict_prime($con);
    return [
        'ok' => true,
        'inserted' => $inserted,
        'updated' => $updated,
        'skipped' => $skipped,
        'by_category' => $by_cat,
        'total' => $inserted + $updated,
    ];
}

function amr_dict_touch_meta($con, $dict_file, $filename, $user_name, $count) {
    $f = mysqli_real_escape_string($con, $dict_file);
    $n = mysqli_real_escape_string($con, substr((string)$filename, 0, 255));
    $u = mysqli_real_escape_string($con, substr((string)$user_name, 0, 100));
    $c = (int)$count;
    mysqli_query($con, "INSERT INTO amr_dict_meta (dict_file, filename, imported_at, imported_by, row_count)
        VALUES ('$f', '$n', NOW(), '$u', $c)
        ON DUPLICATE KEY UPDATE filename = VALUES(filename), imported_at = NOW(),
            imported_by = VALUES(imported_by), row_count = VALUES(row_count)");
}

function amr_dict_normalize_file($file) {
    $file = strtolower(trim((string)$file));
    $ok = ['microbiology', 'admission', 'drug', 'ward', 'builtin', 'manual'];
    return in_array($file, $ok, true) ? $file : 'manual';
}

function amr_dict_normalize_category($cat) {
    $cat = strtolower(trim((string)$cat));
    $ok = array_keys(amr_dict_categories());
    return in_array($cat, $ok, true) ? $cat : 'other';
}

function amr_dict_normalize_match($mode) {
    $mode = strtolower(trim((string)$mode));
    if ($mode === 'exact' || $mode === 'wildcard') {
        return $mode;
    }
    return 'like';
}

function amr_dict_list($con, $category, $q = '', $include_inactive = true) {
    amr_dict_ensure_tables($con);
    $cat = mysqli_real_escape_string($con, amr_dict_normalize_category($category));
    $where = "category = '$cat'";
    if (!$include_inactive) {
        $where .= ' AND active = 1';
    }
    $q = trim((string)$q);
    if ($q !== '') {
        $esc = mysqli_real_escape_string($con, $q);
        $where .= " AND (amass_key LIKE '%$esc%' OR local_value LIKE '%$esc%' OR display_label LIKE '%$esc%')";
    }
    $rows = [];
    $res = mysqli_query($con, "SELECT * FROM amr_dict_rows WHERE $where ORDER BY active DESC, sort_order ASC, id ASC");
    if ($res) {
        while ($r = mysqli_fetch_assoc($res)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function amr_dict_counts($con) {
    amr_dict_ensure_tables($con);
    $out = [];
    foreach (array_keys(amr_dict_categories()) as $cat) {
        $out[$cat] = ['total' => 0, 'active' => 0];
    }
    $q = mysqli_query($con, "SELECT category, COUNT(*) AS t, SUM(active = 1) AS a FROM amr_dict_rows GROUP BY category");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cat = $r['category'];
            $out[$cat] = ['total' => (int)$r['t'], 'active' => (int)$r['a']];
        }
    }
    $meta = [];
    $qm = mysqli_query($con, 'SELECT * FROM amr_dict_meta');
    if ($qm) {
        while ($r = mysqli_fetch_assoc($qm)) {
            $meta[$r['dict_file']] = $r;
        }
    }
    return ['counts' => $out, 'meta' => $meta];
}

function amr_dict_save_row($con, array $input) {
    amr_dict_ensure_tables($con);
    $id = (int)($input['id'] ?? 0);
    $cat = amr_dict_normalize_category($input['category'] ?? 'other');
    $amass = trim((string)($input['amass_key'] ?? ''));
    $local = trim((string)($input['local_value'] ?? ''));
    $label = trim((string)($input['display_label'] ?? ''));
    $mode = amr_dict_normalize_match($input['match_mode'] ?? 'like');
    $order = (int)($input['sort_order'] ?? 0);
    $active = isset($input['active']) ? ((int)$input['active'] ? 1 : 0) : 1;
    $note = substr(trim((string)($input['note'] ?? '')), 0, 255);
    $file = amr_dict_normalize_file($input['dict_file'] ?? 'manual');
    if ($label === '') {
        $label = amr_dict_default_label($amass, $local);
    }
    if ($local === '') {
        return ['ok' => false, 'error' => 'กรุณากรอกค่าในข้อมูลโรงพยาบาล (local value)'];
    }
    $esc = function ($v) use ($con) {
        return mysqli_real_escape_string($con, (string)$v);
    };
    if ($id > 0) {
        $ok = mysqli_query($con, "UPDATE amr_dict_rows SET
            category = '" . $esc($cat) . "',
            amass_key = '" . $esc($amass) . "',
            local_value = '" . $esc($local) . "',
            display_label = '" . $esc($label) . "',
            match_mode = '" . $esc($mode) . "',
            sort_order = $order,
            active = $active,
            note = '" . $esc($note) . "'
            WHERE id = $id");
        return $ok ? ['ok' => true, 'id' => $id] : ['ok' => false, 'error' => mysqli_error($con)];
    }
    if ($file === 'builtin') {
        $file = 'manual';
    }
    $ok = mysqli_query($con, "INSERT INTO amr_dict_rows
        (dict_file, category, section, amass_key, local_value, display_label, match_mode, sort_order, active, source, note)
        VALUES ('" . $esc($file) . "', '" . $esc($cat) . "', '', '" . $esc($amass) . "', '" . $esc($local) . "',
            '" . $esc($label) . "', '" . $esc($mode) . "', $order, $active, 'manual', '" . $esc($note) . "')");
    if (!$ok) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    return ['ok' => true, 'id' => (int)mysqli_insert_id($con)];
}

function amr_dict_delete_row($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "DELETE FROM amr_dict_rows WHERE id = $id");
}

function amr_dict_toggle($con, $id, $active) {
    $id = (int)$id;
    $active = $active ? 1 : 0;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "UPDATE amr_dict_rows SET active = $active WHERE id = $id");
}

function amr_dict_delete_source($con, $category, $source = 'builtin') {
    amr_dict_ensure_tables($con);
    $cat = mysqli_real_escape_string($con, amr_dict_normalize_category($category));
    $src = mysqli_real_escape_string($con, $source === 'import' ? 'import' : ($source === 'manual' ? 'manual' : 'builtin'));
    $q = mysqli_query($con, "SELECT COUNT(*) AS c FROM amr_dict_rows WHERE category = '$cat' AND source = '$src'");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    $count = (int)($row['c'] ?? 0);
    if ($count <= 0) {
        return ['ok' => true, 'deleted' => 0];
    }
    $ok = mysqli_query($con, "DELETE FROM amr_dict_rows WHERE category = '$cat' AND source = '$src'");
    if (!$ok) {
        return ['ok' => false, 'error' => mysqli_error($con), 'deleted' => 0];
    }
    amr_dict_prime($con);
    return ['ok' => true, 'deleted' => $count];
}

function amr_dict_reset_builtin($con) {
    amr_dict_ensure_tables($con);
    mysqli_query($con, "DELETE FROM amr_dict_rows WHERE source = 'builtin'");
    amr_dict_seed_builtin($con, true);
    amr_dict_prime($con);
    return true;
}
