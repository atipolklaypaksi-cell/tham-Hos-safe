<?php
/**
 * ดึง DBF ย้อนหลังตาม lookback แล้วเทียบกับ HOSxP
 * CLI: php amr_mlab_backfill_cli.php
 */
ini_set('display_errors', 1);
error_reporting(E_ALL);
set_time_limit(0);
ini_set('memory_limit', '1024M');

if (php_sapi_name() !== 'cli') {
    fwrite(STDERR, "CLI only\n");
    exit(1);
}

include __DIR__ . '/connect.php';
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
require_once __DIR__ . '/amr_helper.php';
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_mlab_helper.php';
mysqli_set_charset($con, 'utf8');
amr_mlab_ensure_tables($con);
if (function_exists('amr_dict_ensure_tables')) {
    amr_dict_ensure_tables($con);
    amr_dict_prime($con);
}

$cfg = amr_mlab_get_config($con);
$local = amr_mlab_local_data_dir();
amr_mlab_cfg_put($con, 'amr_mlab_dbf_path', $local);
amr_mlab_cfg_put($con, 'amr_mlab_smb_share', 'C');
amr_mlab_cfg_put($con, 'amr_mlab_smb_remote', 'MLAB/DATA');
$cfg['dbf_path'] = $local;
$cfg['smb_share'] = 'C';
$cfg['smb_remote'] = 'MLAB/DATA';

$end = date('Y-m-d');
$start = date('Y-m-d', strtotime('-365 days'));
echo "period $start .. $end\n";
echo "pull+sync...\n";
mysqli_query($con, 'TRUNCATE TABLE amr_mlab_ast');
mysqli_query($con, 'TRUNCATE TABLE amr_mlab_lab');
$t0 = microtime(true);
$sync = amr_mlab_sync($con, true);
$sync['elapsed_sec'] = round(microtime(true) - $t0, 1);
echo json_encode($sync, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;

$re_sql = function_exists('amr_sql_amr_regexp') ? amr_sql_amr_regexp($con) : 'MDR|MRSA|ESBL|CRE|VRE|CRAB|CRPA';
$mlab = [
    'labs' => 0,
    'with_organism' => 0,
    'amr_cases' => 0,
    'keys' => [],
    'hn_date' => [],
];
$q = mysqli_query($con, "SELECT lab_key, hn, order_date, organism,
        IF(IFNULL(result_text,'') REGEXP '$re_sql', 1, 0) AS is_amr
    FROM amr_mlab_lab
    WHERE COALESCE(order_date, report_date) BETWEEN '$start' AND '$end'");
while ($q && ($r = mysqli_fetch_assoc($q))) {
    $mlab['labs']++;
    if (trim((string)$r['organism']) !== '') {
        $mlab['with_organism']++;
    }
    if ((int)$r['is_amr'] === 1) {
        $mlab['amr_cases']++;
    }
    $k = trim((string)$r['lab_key']);
    if ($k !== '') {
        $mlab['keys'][$k] = true;
    }
    $hn = preg_replace('/\D+/', '', (string)$r['hn']);
    $d = substr((string)$r['order_date'], 0, 10);
    if ($hn !== '' && $d !== '') {
        $mlab['hn_date'][$hn . '|' . $d] = true;
    }
}
$mlab_keys = array_keys($mlab['keys']);
$mlab_out = [
    'labs' => $mlab['labs'],
    'with_organism' => $mlab['with_organism'],
    'amr_cases' => $mlab['amr_cases'],
    'unique_lab_keys' => count($mlab_keys),
];
echo "mlab " . json_encode($mlab_out, JSON_UNESCAPED_UNICODE) . PHP_EOL;

$hos = hosxp_connect($con, 180);
if (!$hos) {
    echo json_encode(['hosxp' => 'connect_failed'], JSON_UNESCAPED_UNICODE) . PHP_EOL;
    exit(0);
}
hosxp_extend_read_timeout($hos, 180);
$amr_re = amr_sql_amr_regexp($hos);
$start_esc = mysqli_real_escape_string($hos, $start);
$end_esc = mysqli_real_escape_string($hos, $end);

$hosxp = [
    'lab_head_all' => 0,
    'lab_head_ipd' => 0,
    'amr_ipd' => 0,
    'overlap_lab_key' => 0,
    'overlap_hn_date' => 0,
    'amr_in_mlab_keys' => 0,
    'mlab_keys_found_in_hosxp' => 0,
    'mlab_keys_missing_in_hosxp' => 0,
];
$q = mysqli_query($hos, "SELECT COUNT(*) AS n FROM lab_head WHERE order_date BETWEEN '$start_esc' AND '$end_esc'");
if ($q && ($r = mysqli_fetch_assoc($q))) {
    $hosxp['lab_head_all'] = (int)$r['n'];
}
$q = mysqli_query($hos, "SELECT COUNT(DISTINCT lab_order_number) AS n FROM lab_head
    WHERE department='IPD' AND order_date BETWEEN '$start_esc' AND '$end_esc'");
if ($q && ($r = mysqli_fetch_assoc($q))) {
    $hosxp['lab_head_ipd'] = (int)$r['n'];
}
$q = mysqli_query($hos, "SELECT COUNT(DISTINCT lab_order_number) AS n FROM lab_head
    WHERE department='IPD' AND order_date BETWEEN '$start_esc' AND '$end_esc'
      AND result_rtf REGEXP '$amr_re'");
if ($q && ($r = mysqli_fetch_assoc($q))) {
    $hosxp['amr_ipd'] = (int)$r['n'];
}

$found_keys = [];
foreach (array_chunk($mlab_keys, 700) as $chunk) {
    $in = [];
    foreach ($chunk as $k) {
        $in[] = "'" . mysqli_real_escape_string($hos, $k) . "'";
    }
    $sql = "SELECT lab_order_number, hn, order_date, department,
                IF(department='IPD' AND result_rtf REGEXP '$amr_re', 1, 0) AS is_amr
            FROM lab_head WHERE lab_order_number IN (" . implode(',', $in) . ")";
    $q = mysqli_query($hos, $sql);
    while ($q && ($r = mysqli_fetch_assoc($q))) {
        $found_keys[(string)$r['lab_order_number']] = true;
        $hosxp['mlab_keys_found_in_hosxp']++;
        if ((int)$r['is_amr'] === 1) {
            $hosxp['amr_in_mlab_keys']++;
        }
    }
}
$hosxp['mlab_keys_found_in_hosxp'] = count($found_keys);
$hosxp['mlab_keys_missing_in_hosxp'] = max(0, count($mlab_keys) - count($found_keys));
$hosxp['overlap_lab_key'] = count($found_keys);

$q = mysqli_query($hos, "SELECT hn, order_date FROM lab_head
    WHERE department='IPD' AND order_date BETWEEN '$start_esc' AND '$end_esc'
      AND result_rtf REGEXP '$amr_re'");
$hn_overlap = 0;
while ($q && ($r = mysqli_fetch_assoc($q))) {
    $hn = preg_replace('/\D+/', '', (string)$r['hn']);
    $d = substr((string)$r['order_date'], 0, 10);
    if ($hn !== '' && isset($mlab['hn_date'][$hn . '|' . $d])) {
        $hn_overlap++;
    }
}
$hosxp['overlap_hn_date_amr_ipd'] = $hn_overlap;
mysqli_close($hos);

$pct = function ($a, $b) {
    if ($b <= 0) {
        return 'n/a';
    }
    return round(100.0 * $a / $b, 1) . '%';
};

$summary = [
    'period' => [$start, $end],
    'mlab_dbf' => $mlab_out,
    'hosxp' => $hosxp,
    'compare' => [
        'mlab_labs_found_in_hosxp' => $hosxp['mlab_keys_found_in_hosxp'] . ' / ' . $mlab_out['unique_lab_keys']
            . ' (' . $pct($hosxp['mlab_keys_found_in_hosxp'], $mlab_out['unique_lab_keys']) . ')',
        'mlab_labs_missing_in_hosxp' => $hosxp['mlab_keys_missing_in_hosxp'],
        'hosxp_amr_ipd' => $hosxp['amr_ipd'],
        'mlab_amr_text' => $mlab_out['amr_cases'],
        'hosxp_amr_ipd_also_in_mlab_by_hn_date' => $hosxp['overlap_hn_date_amr_ipd'],
    ],
];
echo json_encode($summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
