<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/user_unit_helper.php';
require_once __DIR__ . '/allergy_followup_helper.php';
mysqli_set_charset($con, 'utf8');
af_ensure_tables($con);

$can_assess = af_can_assess();
$unit_ward = trim((string)($_SESSION['unit_ward'] ?? ''));
$scope_ward = af_user_ward_scope();
$ward_locked = ($scope_ward !== '');
$prefill_hn = trim((string)($_GET['hn'] ?? ''));
$prefill_detail = trim((string)($_GET['detail'] ?? ''));
$dash_start = date('Y-m-d', strtotime('-30 days'));
$dash_end = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แจ้งเคสแพ้ยา - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        :root { --af-rose: #be123c; --af-dark: #9f1239; --af-soft: #fff1f2; }
        .af-hero {
            background: linear-gradient(135deg, #9f1239 0%, #e11d48 55%, #fb7185 100%);
            color: #fff; border-radius: 12px; padding: 1.15rem 1.4rem;
            box-shadow: 0 8px 24px rgba(190, 18, 60, 0.25);
        }
        .af-drop {
            border: 2px dashed #fda4af; border-radius: 12px; background: var(--af-soft);
            padding: 1.25rem; text-align: center; cursor: pointer;
        }
        .af-drop.drag { background: #ffe4e6; border-color: #e11d48; }
        .af-preview { width: 88px; height: 88px; object-fit: cover; border-radius: 8px; }
        .btn-af { background: var(--af-rose); color: #fff; border: 0; }
        .btn-af:hover { background: var(--af-dark); color: #fff; }
        .btn-mic { border-color: #fda4af; color: #be123c; }
        .btn-mic.listening, .btn-mic.busy { background: #be123c; color: #fff; animation: micPulse 1s ease-in-out infinite; }
        @keyframes micPulse { 50% { opacity: 0.7; } }
        .af-sr-file { position: absolute; width: 1px; height: 1px; opacity: 0; overflow: hidden; }
        .kpi-card { border-radius: 12px; border: none; box-shadow: 0 4px 15px rgba(0,0,0,0.05); cursor: pointer; transition: transform 0.15s; }
        .kpi-card:hover { transform: translateY(-2px); }
        .kpi-card.active-kpi { outline: 2px solid var(--af-rose); }
        .kpi-icon { width: 44px; height: 44px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 18px; }
        .time-badge { font-family: ui-monospace, monospace; font-size: 12px; background: #e9ecef; padding: 3px 7px; border-radius: 4px; color: #333; white-space: nowrap; }
        .af-stepper { display: flex; gap: 0; flex-wrap: wrap; }
        .af-step { flex: 1; min-width: 110px; text-align: center; padding: 0.5rem 0.35rem; font-size: 0.78rem; font-weight: 700; background: #f3f4f6; color: #6b7280; border: 1px solid #e5e7eb; }
        .af-step:first-child { border-radius: 8px 0 0 8px; }
        .af-step:last-child { border-radius: 0 8px 8px 0; }
        .af-step.done { background: #dcfce7; color: #166534; }
        .af-step.current { background: #be123c; color: #fff; }
        .af-tl { border-left: 3px solid #fda4af; margin-left: 8px; padding-left: 14px; }
        .af-tl-item { position: relative; margin-bottom: 0.75rem; }
        .af-tl-item::before { content: ''; position: absolute; left: -19px; top: 6px; width: 9px; height: 9px; border-radius: 50%; background: #be123c; }
        .af-dash thead th { font-size: 0.78rem; font-weight: 700; background: #f8fafc; color: #334155; white-space: nowrap; }
        .af-hn { font-weight: 700; color: #be123c; font-variant-numeric: tabular-nums; }
        .af-person { font-weight: 600; color: #0f172a; }
        tr.af-new { background: #fff1f2; }
        .badge-pending { background: #fef3c7; color: #92400e; }
        .badge-allergy { background: #fee2e2; color: #991b1b; }
        .badge-monitor { background: #dbeafe; color: #1e40af; }
        .badge-ok { background: #dcfce7; color: #166534; }
        .badge-adr { background: #ffedd5; color: #9a3412; }
        .badge-hist { background: #f3e8ff; color: #6b21a8; }
        .af-recv { border: 1px dashed #cbd5e1; border-radius: 8px; background: #f8fafc; padding: 0.5rem 0.7rem; }
        .af-recv-item { padding: 0.15rem 0; }
        .af-recv-item + .af-recv-item { border-top: 1px solid #e2e8f0; }
        .af-case-tabbar {
            background: #fff1f2;
            padding: 0 1rem;
            border-bottom: 1px solid #fecdd3;
        }
        .af-case-tabs { border-bottom: 0; }
        .af-case-tabs .nav-link {
            font-weight: 700; font-size: 0.9rem; color: #9f1239;
            border: 1px solid transparent; border-bottom: 0;
            border-radius: 8px 8px 0 0; padding: 0.55rem 1.1rem;
        }
        .af-case-tabs .nav-link:hover { color: #be123c; background: #ffe4e6; }
        .af-case-tabs .nav-link.active {
            color: #be123c; background: #fff;
            border-color: #fecdd3 #fecdd3 #fff;
        }
        .af-xfer-box {
            border: 1px solid #bfdbfe; border-radius: 10px; background: #f8fbff;
            padding: 0.9rem 1rem;
        }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="af-hero mb-4">
                <div class="small opacity-75 mb-1"><i class="fas fa-allergies me-1"></i>ระบบแพ้ยา</div>
                <h4 class="fw-bold mb-1"><i class="fas fa-camera me-2"></i>แจ้งเคสแพ้ยา</h4>
                <small>ส่งรูปอาการและรายละเอียดจากหอผู้ป่วย ให้เภสัชกรประเมินในสมุดติดตาม</small>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <form id="afReportForm">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">HN</label>
                                <div class="input-group input-group-sm">
                                    <input type="text" class="form-control" id="rep_hn" inputmode="numeric" placeholder="เช่น 411831" value="<?= htmlspecialchars($prefill_hn, ENT_QUOTES, 'UTF-8') ?>">
                                    <button class="btn btn-outline-secondary" type="button" id="btnLookupHn"><i class="fas fa-search"></i></button>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <label class="form-label fw-bold small">ชื่อ-สกุล</label>
                                <input type="text" class="form-control form-control-sm" id="rep_ptname" placeholder="ดึงอัตโนมัติจาก HN">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold small">WARD</label>
                                <input type="text" class="form-control form-control-sm" id="rep_ward" list="afWardList" placeholder="ดึงจากหอที่ admit ปัจจุบัน">
                                <div class="form-text" id="repWardHint">กรอก HN แล้วระบบจะดึงหอที่ผู้ป่วย admit อยู่</div>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">วันที่แจ้ง</label>
                                <input type="date" class="form-control form-control-sm" id="rep_date" value="<?= date('Y-m-d') ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">เวลาแจ้ง</label>
                                <input type="time" class="form-control form-control-sm" id="rep_time" value="<?= date('H:i') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">ช่องทางผู้รับแจ้ง</label>
                                <select class="form-select form-select-sm" id="rep_channel">
                                    <option value="webapp" selected>เว็บแอป (พยาบาล)</option>
                                    <option value="line_pharmacy">ไลน์ห้องยา</option>
                                    <option value="line_mr">ไลน์ MR</option>
                                    <option value="phone">โทรศัพท์</option>
                                    <option value="other">อื่นๆ</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <div class="d-flex justify-content-between align-items-center gap-2 mb-1">
                                    <label class="form-label fw-bold small mb-0">รายละเอียดข้อมูลจากหอผู้ป่วย</label>
                                    <button type="button" class="btn btn-sm btn-outline-danger btn-mic" id="btnVoiceDetail" title="พูดแล้วแปลงเป็นข้อความ">
                                        <i class="fas fa-microphone me-1"></i> พิมพ์ด้วยเสียง
                                    </button>
                                    <input type="file" id="rep_voice_file" class="af-sr-file" accept="audio/*" capture>
                                </div>
                                <textarea class="form-control form-control-sm" id="rep_detail" rows="3" placeholder="เช่น ผื่นคันหลังได้ยา TLD, ประวัติแพ้ Ibuprofen จาก รพ.อื่น — หรือกดพิมพ์ด้วยเสียง"><?= htmlspecialchars($prefill_detail, ENT_QUOTES, 'UTF-8') ?></textarea>
                                <div class="form-text" id="voiceHint">เข้าหน้านี้แล้วเริ่มฟังอัตโนมัติ — พูดภาษาไทยได้เลย เมื่อพูดจบกดหยุด ระบบจะแปลงข้อความทันที</div>
                            </div>
                            <div class="col-12" id="afAllergyHint"></div>
                            <div class="col-12">
                                <label class="form-label fw-bold small">รูปอาการ / หลักฐาน</label>
                                <div class="af-drop" id="afDrop">
                                    <i class="fas fa-images fa-2x text-danger mb-2"></i>
                                    <div class="fw-bold">แตะเพื่อเลือกจากคลังรูปในมือถือ</div>
                                    <div class="small text-muted">JPG / PNG / WEBP สูงสุด 8 ไฟล์ · ระบบย่อรูปให้อัตโนมัติก่อนส่ง</div>
                                    <input type="file" id="rep_photos" accept="image/*" multiple hidden>
                                    <input type="file" id="rep_photos_camera" accept="image/*" capture="environment" hidden>
                                </div>
                                <div class="d-flex flex-wrap gap-2 mt-2">
                                    <button type="button" class="btn btn-outline-danger btn-sm fw-bold" id="btnPickGallery">
                                        <i class="fas fa-images me-1"></i>เลือกจากคลังรูป
                                    </button>
                                    <button type="button" class="btn btn-outline-secondary btn-sm" id="btnPickCamera">
                                        <i class="fas fa-camera me-1"></i>ถ่ายรูป
                                    </button>
                                </div>
                                <div class="d-flex flex-wrap gap-2 mt-2" id="afPreview"></div>
                            </div>
                        </div>
                        <div class="mt-3 d-flex gap-2 flex-wrap">
                            <button type="submit" class="btn btn-af fw-bold" id="btnSubmitReport">
                                <i class="fas fa-paper-plane me-1"></i> ส่งเคสให้เภสัช
                            </button>
                            <button type="reset" class="btn btn-outline-secondary" id="btnResetReport">ล้างฟอร์ม</button>
                        </div>
                        <div class="small text-muted mt-2">เมื่อแนบรูป ระบบจะแจ้งเตือนเภสัชที่เมนู <b>Smart Pharma → ตั้งค่าโมดูล</b></div>
                    </form>
                </div>
            </div>

            <div class="mt-4" id="repDash">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
                    <div>
                        <h5 class="fw-bold mb-0"><i class="fas fa-chart-line me-2 text-danger"></i>สรุปสถานะที่แจ้ง</h5>
                        <div class="small text-muted">ติดตามขั้นตอน: แจ้งแพ้ยา → เภสัชรับเคส → ติดตาม → ปิดเคส</div>
                        <?php if ($ward_locked): ?>
                        <div class="small text-danger mt-1"><i class="fas fa-filter me-1"></i>แสดงเคสที่ผู้ป่วยนอนอยู่ที่หอ <b><?= htmlspecialchars($scope_ward, ENT_QUOTES, 'UTF-8') ?></b> ตอนนี้ หรือเคยอยู่หอนี้ใน AN ปัจจุบัน และเคสที่ผู้แจ้งสังกัดหอนี้</div>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="btnDashReload"><i class="fas fa-sync me-1"></i>รีเฟรช</button>
                </div>
                <div class="af-stepper mb-3" id="repStepLegend">
                    <div class="af-step current">1. แจ้งแพ้ยา</div>
                    <div class="af-step">2. เภสัชรับเคส</div>
                    <div class="af-step">3. ติดตาม</div>
                    <div class="af-step">4. ปิดเคส</div>
                </div>
                <div class="card border-0 shadow-sm mb-3">
                    <div class="card-body py-2">
                        <div class="row g-2 align-items-end">
                            <div class="col-6 col-md-2">
                                <label class="form-label small mb-0">จากวันที่</label>
                                <input type="date" class="form-control form-control-sm" id="dash_start" value="<?= htmlspecialchars($dash_start, ENT_QUOTES, 'UTF-8') ?>">
                            </div>
                            <div class="col-6 col-md-2">
                                <label class="form-label small mb-0">ถึงวันที่</label>
                                <input type="date" class="form-control form-control-sm" id="dash_end" value="<?= htmlspecialchars($dash_end, ENT_QUOTES, 'UTF-8') ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small mb-0">ค้นหา HN / ชื่อ</label>
                                <input type="text" class="form-control form-control-sm" id="dash_q" placeholder="HN, ชื่อผู้ป่วย...">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small mb-0">WARD</label>
                                <select class="form-select form-select-sm" id="dash_ward" <?= $ward_locked ? 'disabled' : '' ?>>
                                    <?php if ($ward_locked): ?>
                                    <option value="<?= htmlspecialchars($scope_ward, ENT_QUOTES, 'UTF-8') ?>" selected><?= htmlspecialchars($scope_ward, ENT_QUOTES, 'UTF-8') ?></option>
                                    <?php else: ?>
                                    <option value="">ทั้งหมด</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-af btn-sm fw-bold w-100" id="btnDashSearch"><i class="fas fa-search me-1"></i>ค้นหา</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row g-3 mb-3" id="afKpiRow">
                    <div class="col-6 col-lg">
                        <div class="card kpi-card bg-white p-3 h-100" data-stage="all">
                            <div class="d-flex align-items-center">
                                <div class="kpi-icon bg-light text-dark me-2"><i class="fas fa-list"></i></div>
                                <div>
                                    <div class="small text-muted fw-bold">ทั้งหมด</div>
                                    <div class="fs-3 fw-bold mb-0" id="kpi_total">0</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg">
                        <div class="card kpi-card bg-white p-3 h-100 border-start border-4 border-secondary" data-stage="reported">
                            <div class="d-flex align-items-center">
                                <div class="kpi-icon bg-secondary bg-opacity-25 text-secondary me-2"><i class="fas fa-bell"></i></div>
                                <div>
                                    <div class="small text-muted fw-bold">รอเภสัชรับเคส</div>
                                    <div class="fs-3 fw-bold text-secondary mb-0" id="kpi_reported">0</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg">
                        <div class="card kpi-card bg-white p-3 h-100 border-start border-4 border-info" data-stage="acknowledged">
                            <div class="d-flex align-items-center">
                                <div class="kpi-icon bg-info bg-opacity-25 text-info me-2"><i class="fas fa-user-check"></i></div>
                                <div>
                                    <div class="small text-muted fw-bold">เภสัชรับเคสแล้ว</div>
                                    <div class="fs-3 fw-bold text-info mb-0" id="kpi_acknowledged">0</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg">
                        <div class="card kpi-card bg-white p-3 h-100 border-start border-4 border-warning" data-stage="following">
                            <div class="d-flex align-items-center">
                                <div class="kpi-icon bg-warning bg-opacity-25 text-warning me-2"><i class="fas fa-stethoscope"></i></div>
                                <div>
                                    <div class="small text-muted fw-bold">กำลังติดตาม</div>
                                    <div class="fs-3 fw-bold text-warning mb-0" id="kpi_following">0</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg">
                        <div class="card kpi-card bg-white p-3 h-100 border-start border-4 border-success" data-stage="closed">
                            <div class="d-flex align-items-center">
                                <div class="kpi-icon bg-success bg-opacity-25 text-success me-2"><i class="fas fa-flag-checkered"></i></div>
                                <div>
                                    <div class="small text-muted fw-bold">ปิดเคส</div>
                                    <div class="fs-3 fw-bold text-success mb-0" id="kpi_closed">0</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card border-0 shadow-sm">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm align-middle mb-0 af-dash">
                            <thead>
                                <tr>
                                    <th>วันที่แจ้ง</th>
                                    <th>HN</th>
                                    <th>ชื่อ-สกุล</th>
                                    <th>WARD</th>
                                    <th>ผู้แจ้ง</th>
                                    <th>ขั้นตอน</th>
                                    <th>เวลารับเคส</th>
                                    <th>ติดตาม</th>
                                    <th>ปิดเคส</th>
                                    <th>สรุปผล</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="afDashTbody">
                                <tr><td colspan="11" class="text-center text-muted py-4">กำลังโหลด...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="afCaseModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h5 class="modal-title fw-bold">ขั้นตอนเคส <span id="mdTitle" class="text-muted fw-normal"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="af-case-tabbar">
                <ul class="nav nav-tabs af-case-tabs" id="afCaseTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="tabBtnAssess" data-bs-toggle="tab" data-bs-target="#afTabAssess" type="button" role="tab">
                            <i class="fas fa-list-ol me-1"></i>ขั้นตอน
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="tabBtnTransfer" data-bs-toggle="tab" data-bs-target="#afTabTransfer" type="button" role="tab">
                            <i class="fas fa-share me-1"></i>ส่งต่อเคส
                        </button>
                    </li>
                </ul>
            </div>
            <div class="modal-body">
                <input type="hidden" id="md_id">
                <div class="af-stepper mb-3" id="mdStepper"></div>
                <div class="tab-content">
                <div class="tab-pane fade show active" id="afTabAssess" role="tabpanel">
                <div class="row g-2 small mb-3">
                    <div class="col-md-4"><b>HN:</b> <span id="md_hn"></span></div>
                    <div class="col-md-8"><b>ชื่อ:</b> <span id="md_ptname"></span></div>
                    <div class="col-md-6"><b>WARD:</b> <span id="md_ward"></span></div>
                    <div class="col-md-6"><b>ผู้แจ้ง:</b> <span id="md_reporter"></span></div>
                    <div class="col-12"><b>รายละเอียด:</b> <div id="md_detail" class="text-muted"></div></div>
                    <div class="col-12"><b>ผู้รับเคส:</b> <span id="md_ack_display">ยังไม่มีผู้รับเคส</span></div>
                </div>
                <?php if ($can_assess): ?>
                <div class="border rounded p-2 mb-3 bg-light" id="mdStatusBox">
                    <div class="small fw-bold mb-2 text-danger"><i class="fas fa-edit me-1"></i>แก้ไขสถานะ</div>
                    <input type="hidden" id="md_ack_id">
                    <input type="hidden" id="md_ack_name">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-8">
                            <label class="form-label small mb-0">สถานะ</label>
                            <select class="form-select form-select-sm" id="md_stage">
                                <option value="reported">แจ้งแพ้ยา</option>
                                <option value="acknowledged">เภสัชรับเคส</option>
                                <option value="following">ติดตาม</option>
                                <option value="closed">ปิดเคส</option>
                            </select>
                        </div>
                        <div class="col-md-4 d-grid">
                            <button type="button" class="btn btn-outline-danger btn-sm fw-bold" id="btnSaveStatus">
                                <i class="fas fa-save me-1"></i>บันทึกสถานะ
                            </button>
                        </div>
                    </div>
                    <div class="form-text">เปลี่ยนผู้รับเคสได้ที่แท็บ <b>ส่งต่อเคส</b></div>
                </div>
                <?php endif; ?>
                <div class="small fw-bold mb-2">ไทม์ไลน์</div>
                <div id="mdTimeline" class="af-tl small"></div>
                </div>
                <div class="tab-pane fade" id="afTabTransfer" role="tabpanel">
                    <div class="af-xfer-box mb-3">
                        <div class="small fw-bold text-primary mb-2"><i class="fas fa-share me-1"></i>ส่งต่อผู้รับเคส</div>
                        <div class="small mb-2">ผู้รับเคสปัจจุบัน (คนล่าสุดที่รับเคส): <b id="xfer_from_name">-</b></div>
                        <input type="hidden" id="xfer_case_id">
                        <label class="form-label small fw-bold mb-1">ส่งต่อไปยังเภสัชกร</label>
                        <select class="form-select form-select-sm" id="xfer_pick_user"></select>
                        <label class="form-label small fw-bold mb-1 mt-2">เหตุผลการส่งต่อ (ถ้ามี)</label>
                        <textarea class="form-control form-control-sm" id="xfer_note" rows="2" placeholder="เช่น เวรต่อ, เจ้าของวอร์ด"></textarea>
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mt-2">
                            <div class="form-text mb-0">ระบบจะเก็บประวัติผู้รับเคสเดิมและผู้รับใหม่ทุกครั้งที่ส่งต่อ</div>
                            <?php if ($can_assess): ?>
                            <button type="button" class="btn btn-primary btn-sm fw-bold" id="btnTransferConfirm">
                                <i class="fas fa-check me-1"></i>ยืนยันส่งต่อ
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="small fw-bold mb-2">ประวัติผู้รับเคส / ส่งต่อ</div>
                    <div id="mdReceiverHistory" class="small mb-2"></div>
                </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-danger btn-sm" id="btnDeleteCase"><i class="fas fa-trash-alt me-1"></i>ลบเคส</button>
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิด</button>
                <?php if ($can_assess): ?>
                <button type="button" class="btn btn-info btn-sm fw-bold text-white" id="btnAck"><i class="fas fa-user-check me-1"></i> รับเคส</button>
                <a class="btn btn-af btn-sm fw-bold" id="btnOpenFollowup" href="allergy_followup.php">ไปประเมินในสมุดติดตาม</a>
                <?php else: ?>
                <a class="btn btn-af btn-sm fw-bold" id="btnOpenFollowup" href="allergy_followup.php">ดูในสมุดติดตาม</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<datalist id="afWardList"></datalist>

<div class="modal fade" id="afAckModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h6 class="modal-title fw-bold mb-0"><i class="fas fa-user-check me-1 text-info"></i>รับเคส</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="ack_case_id">
                <label class="form-label small fw-bold mb-1">ผู้รับเคส (เภสัชกร)</label>
                <select class="form-select form-select-sm" id="ack_pick_user"></select>
                <div class="form-text">ค่าเริ่มต้น = ผู้ที่ login อยู่ สามารถเลือกเภสัชกรคนอื่นได้</div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="button" class="btn btn-info btn-sm fw-bold text-white" id="btnAckConfirm">
                    <i class="fas fa-check me-1"></i>ยืนยันรับเคส
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="afTlEditModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h6 class="modal-title fw-bold mb-0">แก้ไขข้อความไทม์ไลน์</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="tl_edit_id">
                <div class="small text-muted mb-1" id="tl_edit_label"></div>
                <textarea class="form-control form-control-sm" id="tl_edit_note" rows="6" placeholder="ข้อความในไทม์ไลน์"></textarea>
                <div class="form-text">แก้ไขได้แม้เคสปิดแล้ว</div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="button" class="btn btn-af btn-sm fw-bold" id="btnTlEditSave"><i class="fas fa-save me-1"></i>บันทึก</button>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/af_photo_compress.js"></script>
<script>
const AF_PREFILL_HN = <?= json_encode($prefill_hn, JSON_UNESCAPED_UNICODE) ?>;
const AF_CAN_ASSESS = <?= $can_assess ? 'true' : 'false' ?>;
const AF_USER_ID = <?= (int)($_SESSION['user_id'] ?? 0) ?>;
const AF_USER_NAME = <?= json_encode(trim((string)($_SESSION['full_name'] ?? '')), JSON_UNESCAPED_UNICODE) ?>;
const AF_UNIT_WARD = <?= json_encode($unit_ward, JSON_UNESCAPED_UNICODE) ?>;
const AF_WARD_LOCKED = <?= $ward_locked ? 'true' : 'false' ?>;
const AF_SCOPE_WARD = <?= json_encode($scope_ward, JSON_UNESCAPED_UNICODE) ?>;
let afPharmacists = [];
let afTimelineById = {};
let afTlEditModal = null;
let afAckModal = null;
let afAckBaseline = '';
let afLastFilledId = 0;
let afFiles = [];
let voiceRec = null;
let voiceListening = false;
let voiceBusy = false;
let voicePrefix = '';
let voicePreferNative = false;
let mediaRec = null;
let mediaStream = null;
let mediaChunks = [];
let mediaRecording = false;
let voiceStarting = false;
let voiceAutoTried = false;
let voiceGestureRetry = null;
let dashStage = 'all';
let highlightId = 0;
let afModal = null;
const STAGE_CLASS = {
    reported: 'bg-secondary',
    acknowledged: 'bg-info text-dark',
    following: 'bg-warning text-dark',
    closed: 'bg-success'
};
const SUM_CLASS = {
    '': 'badge-pending', allergy: 'badge-allergy', monitor: 'badge-monitor',
    not_allergy: 'badge-ok', adr_type_a: 'badge-adr', existing_history: 'badge-hist',
    unclosed: 'badge-pending'
};

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function setWardHint(text, admitted) {
    const el = document.getElementById('repWardHint');
    if (!el) return;
    el.textContent = text;
    el.classList.toggle('text-success', !!admitted);
    el.classList.toggle('text-warning', admitted === false);
}

function applyAdmitWard(p) {
    const ward = (p && p.ward) ? String(p.ward).trim() : '';
    $('#rep_ward').val(ward);
    if (ward) {
        setWardHint('ดึงจากหอที่ผู้ป่วย admit อยู่: ' + ward, true);
    } else {
        setWardHint('ไม่พบการ admit ปัจจุบัน — กรอกหอผู้ป่วยเองได้', false);
    }
}

function loadMeta() {
    return fetch('fetch_allergy_followup_api.php?action=meta', { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') return;
            const wdl = document.getElementById('afWardList');
            if (wdl) wdl.innerHTML = (data.wards || []).map(w => '<option value="' + esc(w) + '">').join('');
            fillWardSelect('#dash_ward', data.wards || []);
            afPharmacists = data.pharmacists || [];
            fillAckUserSelect('#ack_pick_user', AF_USER_ID, AF_USER_NAME);
            fillAckUserSelect('#xfer_pick_user', 0, '');
        });
}

function latestReceiver(c) {
    if (!c) return { id: 0, name: '' };
    const id = parseInt(c.receiver_user_id || c.ack_by || c.owner_user_id || 0, 10);
    const name = String(c.receiver_name || c.ack_by_name || c.owner_name || '').trim();
    return { id: id, name: name };
}

function showCaseTab(name) {
    const target = name === 'Transfer' ? '#afTabTransfer' : '#afTabAssess';
    const btn = document.querySelector('#afCaseTabs [data-bs-target="' + target + '"]');
    if (btn && window.bootstrap && bootstrap.Tab) {
        bootstrap.Tab.getOrCreateInstance(btn).show();
    }
}

function fillReceiverDisplay(c) {
    const recv = latestReceiver(c);
    $('#md_ack_id').val(recv.id || '');
    $('#md_ack_name').val(recv.name || '');
    $('#md_ack_display').text(recv.name || 'ยังไม่มีผู้รับเคส');
    $('#xfer_from_name').text(recv.name || 'ยังไม่มีผู้รับเคส');
    if (c && c.id) $('#xfer_case_id').val(c.id);
    afAckBaseline = String(recv.id || 0) + '|' + String(recv.name || '');
}

function ackSignature(sel) {
    const a = selectedAckPayload(sel);
    return String(a.ack_user_id || 0) + '|' + String(a.ack_by_name || '');
}

function pharmacistOptionValue(p) {
    const pid = parseInt(p && p.id, 10) || 0;
    const pname = String((p && p.name) || '').trim();
    return pid > 0 ? ('u:' + pid) : ('n:' + pname);
}

function isAckPlaceholderName(name) {
    const n = String(name || '').trim();
    return n === '' || n.indexOf('เลือกผู้รับเคส') >= 0;
}

function appendAckOption(sel, p) {
    const pid = parseInt(p && p.id, 10) || 0;
    const pname = String((p && p.name) || '').trim();
    if (!pname && pid <= 0) return null;
    const opt = document.createElement('option');
    opt.value = pharmacistOptionValue({ id: pid, name: pname });
    opt.text = pname;
    opt.setAttribute('data-id', String(pid));
    opt.setAttribute('data-name', pname);
    sel.appendChild(opt);
    return opt;
}

function fillAckUserSelect(sel, selectedId, selectedName) {
    const $s = $(sel);
    const el = $s.get(0);
    if (!el) return;
    const list = (afPharmacists || []).slice();
    const sid = parseInt(selectedId || 0, 10);
    const sname = String(selectedName || '').trim();
    const isXfer = el.id === 'xfer_pick_user';
    $s.data('filling', true);
    if (AF_USER_ID > 0 && !list.some(p => parseInt(p.id, 10) === AF_USER_ID)) {
        list.unshift({ id: AF_USER_ID, name: AF_USER_NAME || ('User #' + AF_USER_ID) });
    }
    if (sid > 0 && !list.some(p => parseInt(p.id, 10) === sid)) {
        list.unshift({ id: sid, name: sname || ('User #' + sid) });
    }
    if (sname && !list.some(p => String(p.name).trim() === sname)) {
        list.unshift({ id: sid || 0, name: sname });
    }
    el.innerHTML = '';
    if (isXfer) {
        const ph = document.createElement('option');
        ph.value = '__none__';
        ph.text = '— เลือกผู้รับเคส —';
        el.appendChild(ph);
        const shift = document.createElement('option');
        shift.value = '__shift__';
        shift.setAttribute('data-id', '0');
        shift.setAttribute('data-name', 'ส่งต่อเวร (ไม่ระบุชื่อ)');
        shift.text = 'ส่งต่อให้เวรถัดไป (ไม่ระบุชื่อ)';
        el.appendChild(shift);
    }
    list.forEach(p => appendAckOption(el, p));
    if (!isXfer && !el.options.length) {
        appendAckOption(el, { id: AF_USER_ID, name: AF_USER_NAME || 'ผู้ใช้ปัจจุบัน' });
    }
    let picked = -1;
    if (sid > 0) {
        for (let i = 0; i < el.options.length; i++) {
            if (parseInt(el.options[i].getAttribute('data-id') || '0', 10) === sid) { picked = i; break; }
        }
    }
    if (picked < 0 && sname && !isXfer) {
        for (let i = 0; i < el.options.length; i++) {
            if (String(el.options[i].getAttribute('data-name') || el.options[i].text || '').trim() === sname) {
                picked = i; break;
            }
        }
    }
    if (picked < 0 && !isXfer && AF_USER_ID > 0) {
        for (let i = 0; i < el.options.length; i++) {
            if (parseInt(el.options[i].getAttribute('data-id') || '0', 10) === AF_USER_ID) { picked = i; break; }
        }
    }
    el.selectedIndex = picked >= 0 ? picked : 0;
    $s.data('filling', false);
    if (isXfer && picked < 0) $s.removeData('last-pick');
}

function optionAckPayload(opt) {
    if (!opt) return { ack_user_id: 0, ack_by_name: '' };
    const raw = String(opt.value || '').trim();
    let name = String(opt.getAttribute('data-name') || opt.text || '').replace(/\s+/g, ' ').trim();
    if (raw.indexOf('n:') === 0 && !name) name = raw.slice(2).trim();
    if (raw === '__none__' || isAckPlaceholderName(name)) {
        return { ack_user_id: 0, ack_by_name: '' };
    }
    if (raw === '__shift__') {
        return { ack_user_id: 0, ack_by_name: 'ส่งต่อเวร (ไม่ระบุชื่อ)', to_shift: true };
    }
    let id = parseInt(opt.getAttribute('data-id') || '0', 10) || 0;
    if (raw.indexOf('u:') === 0) {
        id = parseInt(raw.slice(2), 10) || id;
    } else if (raw.indexOf('n:') === 0) {
        id = 0;
    } else if (raw !== '') {
        id = parseInt(raw, 10) || id;
    }
    return { ack_user_id: id, ack_by_name: name };
}

function selectedAckPayload(sel) {
    const $s = (sel && sel.jquery) ? sel : $(sel || '#xfer_pick_user');
    const el = $s.get(0);
    if (!el || !el.options) return { ack_user_id: 0, ack_by_name: '' };
    const wasDisabled = !!el.disabled;
    if (wasDisabled) el.disabled = false;
    const opt = (el.selectedOptions && el.selectedOptions[0])
        || (el.selectedIndex >= 0 ? el.options[el.selectedIndex] : null)
        || $s.find('option:selected').get(0);
    let payload = optionAckPayload(opt);
    if (!payload.ack_by_name) {
        const cached = $s.data('last-pick');
        if (cached && cached.ack_by_name) payload = cached;
    }
    if (wasDisabled) el.disabled = true;
    return payload;
}

function fillWardSelect(sel, wards) {
    const $s = $(sel);
    if (!$s.length) return;
    if (AF_WARD_LOCKED && AF_SCOPE_WARD) {
        $s.prop('disabled', true);
        $s.html('<option value="' + esc(AF_SCOPE_WARD) + '">' + esc(AF_SCOPE_WARD) + '</option>');
        $s.val(AF_SCOPE_WARD);
        return;
    }
    const cur = $s.val() || AF_UNIT_WARD || '';
    let html = '<option value="">ทั้งหมด</option>';
    (wards || []).forEach(w => {
        html += '<option value="' + esc(w) + '">' + esc(w) + '</option>';
    });
    if (cur && !(wards || []).some(w => w === cur)) {
        html += '<option value="' + esc(cur) + '">' + esc(cur) + '</option>';
    }
    $s.html(html);
    if (cur) $s.val(cur);
}

function fmtDate(iso) {
    if (!iso) return '-';
    const p = String(iso).split('-');
    if (p.length !== 3) return iso;
    return p[2] + '/' + p[1] + '/' + p[0];
}

function timeCell(txt) {
    return txt ? '<span class="time-badge">' + esc(txt) + '</span>' : '<span class="text-muted">-</span>';
}

function stageBadge(c) {
    const st = c.workflow_stage || 'reported';
    const cls = STAGE_CLASS[st] || 'bg-secondary';
    return '<span class="badge ' + cls + '">' + esc(c.workflow_label || 'แจ้งแพ้ยา') + '</span>';
}

function summaryBadge(code, label) {
    if (!code) return '<span class="text-muted">รอสรุป</span>';
    const cls = SUM_CLASS[code] || 'badge-pending';
    return '<span class="badge ' + cls + '">' + esc(label || code) + '</span>';
}

function renderStepper(c) {
    const st = c.workflow_stage || 'reported';
    const order = ['reported', 'acknowledged', 'following', 'closed'];
    const labels = {
        reported: 'แจ้งแพ้ยา',
        acknowledged: 'เภสัชรับเคส',
        following: (c.followup_count > 0 ? 'ติดตามครั้งที่ ' + c.followup_count : 'ติดตาม'),
        closed: 'ปิดเคส'
    };
    const idx = Math.max(0, order.indexOf(st));
    return order.map((k, i) => {
        let cls = 'af-step';
        if (i < idx) cls += ' done';
        else if (i === idx) cls += ' current';
        return '<div class="' + cls + '">' + esc(labels[k]) + '</div>';
    }).join('');
}

function renderReceiverHistory(c) {
    const events = (c && c.events) ? c.events : [];
    const rows = events.filter(ev => ev.event_type === 'acknowledged' || ev.event_type === 'transferred');
    if (!rows.length) {
        const cur = (c && (c.receiver_name || c.ack_by_name || c.owner_name)) ? (c.receiver_name || c.ack_by_name || c.owner_name) : '';
        if (!cur) return '<div class="text-muted">ยังไม่มีผู้รับเคส</div>';
        return '<div class="af-recv"><div class="af-recv-item">ผู้รับเคสปัจจุบัน: <b>' + esc(cur) + '</b>'
            + (c.ack_at_fmt ? ' <span class="text-muted">· ' + esc(c.ack_at_fmt) + '</span>' : '') + '</div></div>';
    }
    return '<div class="af-recv">' + rows.map(ev => {
        const note = (ev.note_display || ev.note || '').trim();
        return '<div class="af-recv-item"><b>' + esc(ev.label || '') + '</b>'
            + ' <span class="text-muted">' + esc(ev.created_at_fmt || '') + '</span>'
            + (ev.actor_name ? ' · ' + esc(ev.actor_name) : '')
            + (note ? '<div class="text-muted">' + esc(note).replace(/\n/g, '<br>') + '</div>' : '')
            + '</div>';
    }).join('') + '</div>';
}

function keepParentCaseModal() {
    if ($('#afCaseModal').hasClass('show')) {
        document.body.classList.add('modal-open');
    }
}

function renderTimeline(events) {
    if (!events || !events.length) {
        return '<div class="text-muted">ยังไม่มีบันทึกขั้นตอน</div>';
    }
    afTimelineById = {};
    return events.map(ev => {
        const eid = parseInt(ev.id || 0, 10);
        if (eid > 0) afTimelineById[eid] = ev;
        const showNote = ev.note_display || ev.note || '';
        const noteHtml = showNote ? esc(showNote).replace(/\n/g, '<br>') : '';
        const editBtn = (AF_CAN_ASSESS && eid > 0)
            ? ' <button type="button" class="btn btn-outline-secondary btn-sm py-0 px-1 btn-edit-tl" data-id="' + eid + '" title="แก้ไขข้อความไทม์ไลน์"><i class="fas fa-pen"></i></button>'
            : '';
        return '<div class="af-tl-item" data-event-id="' + eid + '">'
            + '<div class="fw-bold d-flex justify-content-between align-items-start gap-2">'
            + '<span>' + esc(ev.label) + ' <span class="text-muted fw-normal">' + esc(ev.created_at_fmt || ev.created_at || '') + '</span></span>'
            + editBtn
            + '</div>'
            + '<div>' + esc(ev.actor_name || '') + (noteHtml ? ' — <span class="af-tl-note">' + noteHtml + '</span>' : '') + '</div>'
            + '</div>';
    }).join('');
}

function openTimelineEditor(eventId) {
    eventId = parseInt(eventId, 10);
    if (!eventId || !AF_CAN_ASSESS) return;
    const ev = afTimelineById[eventId];
    if (!ev) { alert('ไม่พบรายการไทม์ไลน์'); return; }
    $('#tl_edit_id').val(eventId);
    $('#tl_edit_label').text((ev.label || '') + (ev.created_at_fmt ? ' · ' + ev.created_at_fmt : ''));
    $('#tl_edit_note').val(ev.note || '');
    if (!afTlEditModal && document.getElementById('afTlEditModal')) {
        afTlEditModal = new bootstrap.Modal(document.getElementById('afTlEditModal'));
    }
    if (afTlEditModal) afTlEditModal.show();
}

function saveTimelineEditor() {
    const eventId = parseInt($('#tl_edit_id').val() || 0, 10);
    if (!eventId) return;
    const note = $('#tl_edit_note').val();
    fetch('fetch_allergy_followup_api.php?action=update_event', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event_id: eventId, note: note })
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'success') { alert(data.message || 'บันทึกไทม์ไลน์ไม่สำเร็จ'); return; }
        if (afTlEditModal) afTlEditModal.hide();
        if (data.case) {
            applyCaseToModal(data.case);
            $('#mdTimeline').html(renderTimeline(data.case.events || []));
            if (data.case.ward_detail != null) $('#md_detail').text(data.case.ward_detail || '-');
        }
        loadDashboard();
    })
    .catch(() => alert('บันทึกไทม์ไลน์ไม่สำเร็จ'));
}

function dashQuery() {
    return new URLSearchParams({
        action: 'dashboard',
        start_date: $('#dash_start').val(),
        end_date: $('#dash_end').val(),
        q: $('#dash_q').val(),
        ward: $('#dash_ward').val() || '',
        workflow_stage: dashStage,
        exclude_import: '1'
    });
}

function loadDashboard() {
    fetch('fetch_allergy_followup_api.php?' + dashQuery().toString(), { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') {
                $('#afDashTbody').html('<tr><td colspan="11" class="text-center text-danger py-3">โหลดไม่สำเร็จ</td></tr>');
                return;
            }
            const c = data.counts || {};
            $('#kpi_total').text(c.total || 0);
            $('#kpi_reported').text(c.reported || 0);
            $('#kpi_acknowledged').text(c.acknowledged || 0);
            $('#kpi_following').text(c.following || 0);
            $('#kpi_closed').text(c.closed || 0);
            document.querySelectorAll('#afKpiRow .kpi-card').forEach(el => {
                el.classList.toggle('active-kpi', el.getAttribute('data-stage') === dashStage);
            });
            const rows = data.cases || [];
            if (!rows.length) {
                $('#afDashTbody').html('<tr><td colspan="11" class="text-center text-muted py-4">ยังไม่มีเคสในช่วงที่เลือก</td></tr>');
                return;
            }
            $('#afDashTbody').html(rows.map(renderDashRow).join(''));
        });
}

function canDeleteCase(c) {
    if (AF_CAN_ASSESS) return true;
    const uid = AF_USER_ID || 0;
    return uid > 0 && uid === parseInt(c.reporter_user_id || 0, 10);
}

function renderDashRow(c) {
    const fu = (c.followup_count || 0) > 0
        ? timeCell(c.last_followup_at_fmt) + '<div class="small text-muted">ครั้งที่ ' + c.followup_count + '</div>'
        : '<span class="text-muted">-</span>';
    const ack = c.ack_at_fmt
        ? timeCell(c.ack_at_fmt) + (c.ack_by_name ? '<div class="small text-muted">' + esc(c.ack_by_name) + '</div>' : '')
        : '<span class="text-muted">รอรับเคส</span>';
    const closed = c.closed_at_fmt
        ? timeCell(c.closed_at_fmt) + (c.closed_by_name ? '<div class="small text-muted">' + esc(c.closed_by_name) + '</div>' : '')
        : '<span class="text-muted">-</span>';
    const hi = (highlightId && c.id === highlightId) ? ' af-new' : '';
    let actBtns = '';
    if (AF_CAN_ASSESS && (c.workflow_stage || 'reported') === 'reported') {
        actBtns += '<button type="button" class="btn btn-info btn-sm text-white fw-bold btn-ack-row mb-1" data-id="' + c.id + '">รับเคส</button> ';
    }
    if (canDeleteCase(c)) {
        actBtns += '<button type="button" class="btn btn-outline-danger btn-sm btn-del-row" data-id="' + c.id + '" title="ลบเคส"><i class="fas fa-trash-alt"></i></button>';
    }
    return '<tr class="af-row' + hi + '" data-id="' + c.id + '" style="cursor:pointer">'
        + '<td class="text-nowrap">' + esc(fmtDate(c.case_date)) + '<div class="small text-muted">' + esc(c.notify_time || '') + '</div></td>'
        + '<td class="text-nowrap af-hn">' + esc(c.hn_display) + '</td>'
        + '<td class="af-person">' + esc(c.ptname) + '</td>'
        + '<td>' + esc(c.ward) + '</td>'
        + '<td class="af-person">' + esc(c.reporter_name || c.channel_label || '-') + '</td>'
        + '<td>' + stageBadge(c) + '</td>'
        + '<td>' + ack + '</td>'
        + '<td>' + fu + '</td>'
        + '<td>' + closed + '</td>'
        + '<td>' + summaryBadge(c.summary_result, c.summary_label) + '</td>'
        + '<td class="text-nowrap">' + (actBtns || '<span class="text-muted">-</span>') + '</td>'
        + '</tr>';
}

function openCase(id) {
    fetch('fetch_allergy_followup_api.php?action=get&id=' + id, { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') { alert(data.message || 'ไม่พบเคส'); return; }
            const c = data.case;
            $('#md_id').val(c.id);
            $('#mdTitle').text('#' + c.id);
            $('#md_hn').text(c.hn_display || c.hn || '-');
            $('#md_ptname').text(c.ptname || '-');
            $('#md_ward').text(c.ward || '-');
            $('#md_reporter').text(c.reporter_name || c.channel_label || '-');
            $('#md_detail').text(c.ward_detail || '-');
            $('#btnOpenFollowup').attr('href', 'allergy_followup.php?open=' + encodeURIComponent(c.id));
            applyCaseToModal(c);
            if (afModal) afModal.show();
        });
}

function applyCaseToModal(c) {
    if (!c) return;
    const sameCase = parseInt(c.id, 10) === parseInt(afLastFilledId, 10);
    $('#mdStepper').html(renderStepper(c));
    $('#mdTimeline').html(renderTimeline(c.events || []));
    $('#mdReceiverHistory').html(renderReceiverHistory(c));
    fillReceiverDisplay(c);
    const stage = c.workflow_stage || 'reported';
    const closed = stage === 'closed';
    const waiting = stage === 'reported';
    $('#btnAck').toggle(AF_CAN_ASSESS && waiting);
    $('#btnDeleteCase').toggle(canDeleteCase(c));
    $('#xfer_pick_user, #xfer_note, #btnTransferConfirm').prop('disabled', !AF_CAN_ASSESS || closed);
    if (AF_CAN_ASSESS) {
        $('#md_stage').val(stage);
        $('#mdStatusBox').show();
    }
    afLastFilledId = parseInt(c.id, 10) || 0;
    if (!sameCase) showCaseTab('Assess');
}

function saveCaseStatus() {
    const id = parseInt($('#md_id').val() || 0, 10);
    if (!id) return;
    const stage = $('#md_stage').val() || 'reported';
    const parts = String(afAckBaseline || '').split('|');
    const ack = {
        ack_user_id: parseInt(parts[0] || 0, 10),
        ack_by_name: parts.slice(1).join('|')
    };
    if (!confirm('บันทึกสถานะเป็น "' + ($('#md_stage option:selected').text() || stage) + '"'
        + (stage !== 'reported' ? ('\nผู้รับเคส: ' + (ack.ack_by_name || '-')) : '') + ' ?')) {
        return;
    }
    fetch('fetch_allergy_followup_api.php?action=update_workflow', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            id: id,
            workflow_stage: stage,
            ack_user_id: ack.ack_user_id,
            ack_by_name: ack.ack_by_name
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'success') { alert(data.message || 'บันทึกสถานะไม่สำเร็จ'); return; }
        highlightId = id;
        applyCaseToModal(data.case);
        loadDashboard();
        alert('บันทึกสถานะแล้ว');
    })
    .catch(() => alert('บันทึกสถานะไม่สำเร็จ'));
}

function deleteCase(id) {
    id = parseInt(id, 10);
    if (!id) return;
    const confirmText = prompt("คำเตือน: คุณกำลังจะลบเคสแพ้ยาออกจากระบบ\n\nพิมพ์คำว่า 'delete' เพื่อยืนยัน:");
    if (confirmText === null) return;
    if (confirmText !== 'delete') {
        if (confirmText !== '') alert("พิมพ์คำว่า 'delete' ไม่ถูกต้อง ข้อมูลจะไม่ถูกลบ");
        return;
    }
    fetch('fetch_allergy_followup_api.php?action=delete_case', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id, confirm: 'delete' })
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'success') { alert(data.message || 'ลบเคสไม่สำเร็จ'); return; }
        if (afModal) afModal.hide();
        highlightId = 0;
        loadDashboard();
        alert('ลบเคสแล้ว');
    })
    .catch(() => alert('ลบเคสไม่สำเร็จ'));
}

function ackCase(id) {
    id = parseInt(id, 10);
    if (!id || !AF_CAN_ASSESS) return;
    $('#ack_case_id').val(id);
    fillAckUserSelect('#ack_pick_user', AF_USER_ID, AF_USER_NAME);
    if (!afAckModal && document.getElementById('afAckModal')) {
        afAckModal = new bootstrap.Modal(document.getElementById('afAckModal'));
    }
    if (afAckModal) afAckModal.show();
}

function confirmAckCase() {
    const id = parseInt($('#ack_case_id').val() || 0, 10);
    if (!id) return;
    const ack = selectedAckPayload('#ack_pick_user');
    const who = ack.ack_by_name || AF_USER_NAME || 'ผู้ใช้ปัจจุบัน';
    fetch('fetch_allergy_followup_api.php?action=ack', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            id: id,
            ack_user_id: ack.ack_user_id || AF_USER_ID,
            ack_by_name: who
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'success') { alert(data.message || 'รับเคสไม่สำเร็จ'); return; }
        if (afAckModal) afAckModal.hide();
        highlightId = id;
        loadDashboard();
        if (data.case) {
            if ($('#md_id').val() == String(id)) applyCaseToModal(data.case);
        }
    })
    .catch(() => alert('รับเคสไม่สำเร็จ'));
}

function currentCaseReceiverName() {
    return String($('#md_ack_name').val() || '').trim() || 'ยังไม่มีผู้รับเคส';
}

function confirmTransferCase() {
    const id = parseInt($('#xfer_case_id').val() || $('#md_id').val() || 0, 10);
    if (!id) return;
    const $pick = $('#xfer_pick_user');
    $pick.prop('disabled', false);
    let ack = selectedAckPayload($pick);
    if (!ack.ack_by_name && $pick.data('last-pick') && $pick.data('last-pick').ack_by_name) {
        ack = $pick.data('last-pick');
    }
    if (!ack.ack_by_name) { alert('กรุณาเลือกผู้รับเคส'); return; }
    const toShift = !!ack.to_shift || ack.ack_by_name === 'ส่งต่อเวร (ไม่ระบุชื่อ)';
    fetch('fetch_allergy_followup_api.php?action=transfer', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            id: id,
            ack_user_id: toShift ? '__shift__' : (ack.ack_user_id || 0),
            ack_by_name: ack.ack_by_name,
            to_user_id: toShift ? '__shift__' : (ack.ack_user_id || 0),
            to_name: ack.ack_by_name,
            note: $('#xfer_note').val()
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'success') { alert(data.message || 'ส่งต่อเคสไม่สำเร็จ'); return; }
        highlightId = id;
        if (data.case) applyCaseToModal(data.case);
        showCaseTab('Transfer');
        fillAckUserSelect('#xfer_pick_user', 0, '');
        $('#xfer_note').val('');
        loadDashboard();
    })
    .catch(() => alert('ส่งต่อเคสไม่สำเร็จ'));
}

function resetReportForm() {
    const form = document.getElementById('afReportForm');
    if (form) form.reset();
    $('#rep_date').val(new Date().toISOString().slice(0, 10));
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    $('#rep_time').val(hh + ':' + mm);
    afFiles = [];
    renderPreviews();
    $('#afAllergyHint').html('');
    setWardHint('กรอก HN แล้วระบบจะดึงหอที่ผู้ป่วย admit อยู่');
}

function lookupHn() {
    const hn = $('#rep_hn').val().trim();
    if (!hn) return;
    fetch('fetch_allergy_followup_api.php?action=lookup_hn&hn=' + encodeURIComponent(hn), { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') {
                $('#rep_ward').val('');
                setWardHint('ไม่พบผู้ป่วยใน HOSxP — กรอกหอผู้ป่วยเองได้', false);
                $('#afAllergyHint').html('<div class="alert alert-warning py-2 mb-0 small">ไม่พบผู้ป่วยใน HOSxP — กรอกชื่อเองได้</div>');
                return;
            }
            const p = data.patient;
            $('#rep_ptname').val(p.full_name || '');
            applyAdmitWard(p);
            let html = '';
            if ((p.allergies || []).length) {
                html = '<div class="alert alert-danger py-2 mb-0 small"><b>ประวัติแพ้ใน HOSxP:</b> '
                    + p.allergies.map(a => esc(a.agent) + (a.symptom ? ' (' + esc(a.symptom) + ')' : '')).join(' · ')
                    + '</div>';
            } else {
                html = '<div class="alert alert-success py-2 mb-0 small">ไม่พบประวัติแพ้ยาใน HOSxP</div>';
            }
            $('#afAllergyHint').html(html);
        });
}

function voiceDefaultHint() {
    return 'เข้าหน้านี้แล้วเริ่มฟังอัตโนมัติ — พูดภาษาไทยได้เลย เมื่อพูดจบกดหยุด ระบบจะแปลงข้อความทันที';
}

function setVoiceHint(text) {
    const hint = document.getElementById('voiceHint');
    if (hint) hint.textContent = text;
}

function setVoiceBtnState(mode) {
    const btn = document.getElementById('btnVoiceDetail');
    if (!btn) return;
    btn.classList.toggle('listening', mode === 'listen');
    btn.classList.toggle('busy', mode === 'busy');
    btn.disabled = mode === 'busy';
    if (mode === 'listen') {
        btn.innerHTML = '<i class="fas fa-stop me-1"></i> กำลังอัด... กดหยุด';
    } else if (mode === 'busy') {
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังแปลงเสียง...';
    } else {
        btn.innerHTML = '<i class="fas fa-microphone me-1"></i> พิมพ์ด้วยเสียง';
    }
}

function appendVoiceText(text) {
    const piece = String(text || '').trim();
    if (!piece) return;
    const ta = document.getElementById('rep_detail');
    if (!ta) return;
    let cur = ta.value || '';
    if (cur && !/\s$/.test(cur)) cur += ' ';
    ta.value = cur + piece;
    ta.dispatchEvent(new Event('input', { bubbles: true }));
}

function canUseLiveSpeech() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    return !!SR && window.isSecureContext && !voicePreferNative;
}

function canUseMediaRecorder() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);
}

function disarmVoiceGestureRetry() {
    if (!voiceGestureRetry) return;
    document.removeEventListener('pointerdown', voiceGestureRetry, true);
    document.removeEventListener('touchstart', voiceGestureRetry, true);
    voiceGestureRetry = null;
}

function armVoiceGestureRetry() {
    if (voiceGestureRetry) return;
    voiceGestureRetry = function(e) {
        if (e && e.target && e.target.closest && e.target.closest('#btnVoiceDetail')) return;
        disarmVoiceGestureRetry();
        if (mediaRecording || voiceListening || voiceBusy || voiceStarting) return;
        startBestVoice(false);
    };
    document.addEventListener('pointerdown', voiceGestureRetry, true);
    document.addEventListener('touchstart', voiceGestureRetry, true);
}

function pickRecorderMime() {
    if (!window.MediaRecorder) return '';
    const cands = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/aac', 'audio/ogg;codecs=opus'];
    for (let i = 0; i < cands.length; i++) {
        try {
            if (MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(cands[i])) return cands[i];
        } catch (err) {}
    }
    return '';
}

function stopMediaTracks() {
    if (mediaStream) {
        try {
            mediaStream.getTracks().forEach(function(t) { t.stop(); });
        } catch (err) {}
        mediaStream = null;
    }
}

function stopLiveSpeech() {
    voiceListening = false;
    if (voiceRec) {
        try { voiceRec.stop(); } catch (err) {}
        voiceRec = null;
    }
}

function stopAllVoice(skipTranscribe) {
    voiceStarting = false;
    stopLiveSpeech();
    if (mediaRec && mediaRec.state && mediaRec.state !== 'inactive') {
        if (skipTranscribe) {
            mediaRec.onstop = function() { stopMediaTracks(); };
        }
        try { mediaRec.stop(); } catch (err) { stopMediaTracks(); }
    } else {
        stopMediaTracks();
    }
    mediaRecording = false;
}

function startLiveSpeech() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const btn = document.getElementById('btnVoiceDetail');
    if (!SR || !btn) return false;
    stopLiveSpeech();
    const rec = new SR();
    rec.lang = 'th-TH';
    rec.continuous = true;
    rec.interimResults = true;
    rec.maxAlternatives = 1;
    rec.onstart = function() {
        disarmVoiceGestureRetry();
        voiceListening = true;
        voicePrefix = $('#rep_detail').val();
        if (voicePrefix && !/\s$/.test(voicePrefix)) voicePrefix += ' ';
        setVoiceBtnState('listen');
        setVoiceHint('กำลังฟังเสียงภาษาไทย... พูดได้เลย กดหยุดเมื่อจบ');
    };
    rec.onresult = function(e) {
        let out = voicePrefix;
        for (let i = 0; i < e.results.length; i++) {
            out += e.results[i][0].transcript;
        }
        $('#rep_detail').val(out);
    };
    rec.onerror = function(e) {
        const err = e && e.error ? e.error : '';
        if (err === 'aborted') return;
        if (err === 'no-speech') {
            setVoiceHint('ไม่ได้ยินเสียง — พูดต่อได้เลย หรือกดหยุดเมื่อจบ');
            return;
        }
        voicePreferNative = true;
        voiceListening = false;
        if (err === 'not-allowed') {
            setVoiceHint('เบราว์เซอร์ยังไม่ให้ใช้ไมค์ — อนุญาตไมค์แล้วพูดได้เลย');
        } else {
            setVoiceHint('ฟังเสียงสดใช้ไม่ได้ — กำลังสลับไปอัดในหน้าเว็บ');
            startInPageRecording();
        }
    };
    rec.onend = function() {
        const keep = voiceListening;
        voiceRec = null;
        if (keep && !voiceBusy && !mediaRecording) {
            try {
                startLiveSpeech();
                return;
            } catch (err) {}
        }
        voiceListening = false;
        if (!voiceBusy && !mediaRecording) {
            setVoiceBtnState('idle');
            const hint = document.getElementById('voiceHint');
            if (hint && hint.textContent.indexOf('กำลังฟัง') === 0) setVoiceHint(voiceDefaultHint());
        }
    };
    voiceRec = rec;
    try {
        rec.start();
        return true;
    } catch (err) {
        voiceRec = null;
        voicePreferNative = true;
        return false;
    }
}

function startInPageRecording() {
    if (!canUseMediaRecorder() || voiceBusy || mediaRecording || voiceStarting) return Promise.resolve(false);
    voiceStarting = true;
    stopLiveSpeech();
    setVoiceHint('กำลังเปิดไมค์...');
    return navigator.mediaDevices.getUserMedia({ audio: true, video: false }).then(function(stream) {
        if (!voiceStarting) {
            try { stream.getTracks().forEach(function(t) { t.stop(); }); } catch (err) {}
            return false;
        }
        mediaStream = stream;
        mediaChunks = [];
        const mime = pickRecorderMime();
        let rec;
        try {
            rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
        } catch (err) {
            rec = new MediaRecorder(stream);
        }
        rec.ondataavailable = function(e) {
            if (e.data && e.data.size) mediaChunks.push(e.data);
        };
        rec.onstop = function() {
            mediaRecording = false;
            mediaRec = null;
            const type = (mime || (mediaChunks[0] && mediaChunks[0].type) || 'audio/webm');
            const blob = new Blob(mediaChunks, { type: type });
            mediaChunks = [];
            stopMediaTracks();
            if (blob.size < 800) {
                setVoiceBtnState('idle');
                setVoiceHint('ยังไม่มีเสียงที่อัดได้ — กดพิมพ์ด้วยเสียงเพื่อเริ่มใหม่');
                return;
            }
            const ext = type.indexOf('mp4') >= 0 ? 'm4a' : (type.indexOf('ogg') >= 0 ? 'ogg' : 'webm');
            transcribeVoiceFile(new File([blob], 'voice.' + ext, { type: type }));
        };
        rec.onerror = function() {
            mediaRecording = false;
            stopMediaTracks();
            setVoiceBtnState('idle');
            setVoiceHint('อัดเสียงไม่สำเร็จ — กดพิมพ์ด้วยเสียงเพื่อลองใหม่');
        };
        mediaRec = rec;
        try {
            rec.start(1000);
        } catch (err) {
            rec.start();
        }
        voiceStarting = false;
        mediaRecording = true;
        disarmVoiceGestureRetry();
        setVoiceBtnState('listen');
        setVoiceHint('กำลังอัดเสียง... พูดได้เลย กดหยุดเมื่อจบ ระบบจะแปลงข้อความทันที');
        return true;
    }).catch(function(err) {
        voiceStarting = false;
        const name = err && err.name ? err.name : '';
        if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
            setVoiceHint('กรุณาอนุญาตไมค์ของเบราว์เซอร์ แล้วพูดได้เลย');
        } else if (name === 'NotFoundError') {
            setVoiceHint('ไม่พบไมโครโฟนบนเครื่องนี้');
        } else {
            setVoiceHint('เปิดไมค์ไม่ได้ — กดพิมพ์ด้วยเสียงเพื่ออัดจากโทรศัพท์');
        }
        setVoiceBtnState('idle');
        return false;
    });
}

function stopInPageRecordingAndDone() {
    if (!mediaRec || !mediaRecording) {
        stopLiveSpeech();
        setVoiceBtnState(voiceBusy ? 'busy' : 'idle');
        return;
    }
    setVoiceHint('หยุดอัดแล้ว — กำลังแปลงเป็นข้อความ...');
    try { mediaRec.stop(); } catch (err) {
        stopMediaTracks();
        mediaRecording = false;
        setVoiceBtnState('idle');
    }
}

function openNativeRecorder() {
    const input = document.getElementById('rep_voice_file');
    if (!input) return;
    setVoiceHint('อัดเสียงแล้วกดบันทึก/ใช้ไฟล์นี้ เพื่อแปลงเป็นข้อความ');
    input.click();
}

function startBestVoice(allowNative) {
    if (voiceBusy || voiceListening || mediaRecording || voiceStarting) return;
    if (canUseMediaRecorder()) {
        startInPageRecording().then(function(ok) {
            if (ok || mediaRecording) return;
            if (canUseLiveSpeech() && startLiveSpeech()) return;
            if (allowNative) openNativeRecorder();
        });
        return;
    }
    if (canUseLiveSpeech()) {
        if (startLiveSpeech()) return;
    }
    if (allowNative) openNativeRecorder();
}

function tryAutoStartVoice() {
    if (voiceAutoTried || voiceBusy || voiceListening || mediaRecording || voiceStarting) return;
    voiceAutoTried = true;
    startBestVoice(false);
    armVoiceGestureRetry();
}

function encodeWavFromBuffer(audioBuffer) {
    const sampleRate = 16000;
    const duration = audioBuffer.duration || 0;
    const frames = Math.max(1, Math.ceil(duration * sampleRate));
    const Offline = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (Offline) {
        try {
            const ctx = new Offline(1, frames, sampleRate);
            const src = ctx.createBufferSource();
            src.buffer = audioBuffer;
            src.connect(ctx.destination);
            src.start(0);
            return ctx.startRendering().then(function(rendered) {
                const data = rendered.numberOfChannels > 1 ? mixDown(rendered) : rendered.getChannelData(0);
                const rate = rendered.sampleRate || sampleRate;
                const samples = rate === sampleRate ? data : resampleLinear(data, rate, sampleRate);
                return floatToWavBlob(samples, sampleRate);
            });
        } catch (err) { /* fallback below */ }
    }
    const data = audioBuffer.numberOfChannels > 1 ? mixDown(audioBuffer) : audioBuffer.getChannelData(0);
    return Promise.resolve(floatToWavBlob(resampleLinear(data, audioBuffer.sampleRate, sampleRate), sampleRate));
}

function mixDown(buf) {
    const n = buf.length;
    const out = new Float32Array(n);
    const ch = buf.numberOfChannels;
    for (let c = 0; c < ch; c++) {
        const d = buf.getChannelData(c);
        for (let i = 0; i < n; i++) out[i] += d[i] / ch;
    }
    return out;
}

function resampleLinear(input, fromRate, toRate) {
    if (fromRate === toRate) return input;
    const ratio = fromRate / toRate;
    const n = Math.max(1, Math.round(input.length / ratio));
    const out = new Float32Array(n);
    for (let i = 0; i < n; i++) {
        const x = i * ratio;
        const i0 = Math.floor(x);
        const i1 = Math.min(i0 + 1, input.length - 1);
        const t = x - i0;
        out[i] = input[i0] * (1 - t) + input[i1] * t;
    }
    return out;
}

function floatToWavBlob(samples, sampleRate) {
    const n = samples.length;
    const buffer = new ArrayBuffer(44 + n * 2);
    const view = new DataView(buffer);
    function writeStr(off, s) {
        for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i));
    }
    writeStr(0, 'RIFF');
    view.setUint32(4, 36 + n * 2, true);
    writeStr(8, 'WAVE');
    writeStr(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeStr(36, 'data');
    view.setUint32(40, n * 2, true);
    let off = 44;
    for (let i = 0; i < n; i++) {
        let s = Math.max(-1, Math.min(1, samples[i]));
        view.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        off += 2;
    }
    return new Blob([buffer], { type: 'audio/wav' });
}

function audioFileToWav(file) {
    return file.arrayBuffer().then(function(buf) {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return Promise.reject(new Error('no-audio-ctx'));
        const ctx = new Ctx();
        const copy = buf.slice(0);
        return new Promise(function(resolve, reject) {
            let settled = false;
            function ok(decoded) { if (!settled) { settled = true; resolve(decoded); } }
            function fail(err) { if (!settled) { settled = true; reject(err || new Error('decode')); } }
            const p = ctx.decodeAudioData(copy, ok, fail);
            if (p && typeof p.then === 'function') p.then(ok, fail);
        }).then(function(audioBuffer) {
            try { ctx.close(); } catch (err) {}
            return encodeWavFromBuffer(audioBuffer);
        });
    });
}

function transcribeVoiceFile(file) {
    if (voiceBusy) return;
    voiceBusy = true;
    setVoiceBtnState('busy');
    setVoiceHint('กำลังแปลงเสียงเป็นข้อความ...');
    audioFileToWav(file)
        .then(function(wav) {
            if (wav.size > 1800000) {
                return Promise.reject(new Error('too-large'));
            }
            const fd = new FormData();
            fd.append('audio', wav, 'voice.wav');
            return fetch('fetch_allergy_stt_api.php', { method: 'POST', body: fd, credentials: 'same-origin' });
        })
        .then(function(r) {
            return r.text().then(function(t) {
                try { return JSON.parse(t); }
                catch (err) { return { status: 'error', message: 'เซิร์ฟเวอร์แปลงเสียงไม่สำเร็จ' }; }
            });
        })
        .then(function(data) {
            if (!data || data.status !== 'success') {
                setVoiceHint((data && data.message) ? data.message : 'แปลงเสียงไม่สำเร็จ ลองอัดใหม่');
                return;
            }
            appendVoiceText(data.text);
            setVoiceHint('แปลงเสียงแล้ว — กดปุ่มอีกครั้งถ้าต้องการพูดเพิ่ม');
        })
        .catch(function() {
            setVoiceHint('แปลงไฟล์เสียงไม่ได้ ลองอัดใหม่เป็นคลิปสั้นๆ');
        })
        .then(function() {
            voiceBusy = false;
            setVoiceBtnState('idle');
        });
}

function setupVoiceInput() {
    const btn = document.getElementById('btnVoiceDetail');
    const input = document.getElementById('rep_voice_file');
    if (!btn || !input) return;
    if (!window.isSecureContext) voicePreferNative = true;
    input.addEventListener('change', function() {
        const file = this.files && this.files[0];
        this.value = '';
        if (file) transcribeVoiceFile(file);
    });
    btn.addEventListener('click', function() {
        if (voiceBusy) return;
        if (mediaRecording) {
            stopInPageRecordingAndDone();
            return;
        }
        if (voiceListening) {
            voiceListening = false;
            stopLiveSpeech();
            setVoiceBtnState('idle');
            setVoiceHint('หยุดฟังแล้ว — ข้อความอยู่ในช่องรายละเอียด');
            return;
        }
        startBestVoice(true);
    });
    tryAutoStartVoice();
    document.addEventListener('visibilitychange', function() {
        if (document.visibilityState === 'visible' && !voiceAutoTried) {
            tryAutoStartVoice();
        }
    });
    window.addEventListener('pagehide', function() {
        stopAllVoice(true);
    });
}

function renderPreviews() {
    const box = document.getElementById('afPreview');
    box.innerHTML = '';
    afFiles.forEach((f, i) => {
        const url = URL.createObjectURL(f);
        const wrap = document.createElement('div');
        wrap.className = 'position-relative';
        wrap.innerHTML = '<img class="af-preview" src="' + url + '"><button type="button" class="btn btn-sm btn-danger position-absolute top-0 end-0 py-0 px-1" data-i="' + i + '">&times;</button>';
        wrap.querySelector('button').onclick = function() {
            afFiles.splice(parseInt(this.getAttribute('data-i'), 10), 1);
            renderPreviews();
        };
        box.appendChild(wrap);
    });
}

function compressImage(file, maxSide, quality) {
    if (typeof afCompressImage === 'function') {
        return afCompressImage(file);
    }
    return Promise.resolve(file);
}

async function addFiles(list) {
    const incoming = Array.from(list || []);
    for (let i = 0; i < incoming.length; i++) {
        if (afFiles.length >= 8) break;
        try {
            const compressed = typeof afCompressImage === 'function'
                ? await afCompressImage(incoming[i])
                : incoming[i];
            if (compressed) afFiles.push(compressed);
        } catch (err) {
            alert((err && err.message) ? err.message : 'แนบรูปนี้ไม่ได้');
        }
    }
    renderPreviews();
}

async function parseJsonResponse(res) {
    const text = await res.text();
    let data = null;
    try {
        data = text ? JSON.parse(text) : null;
    } catch (err) {
        const hint = res.status ? ('HTTP ' + res.status) : 'ตอบกลับไม่ใช่ JSON';
        throw new Error(text && text.length < 180 ? text : ('ส่งไม่สำเร็จ (' + hint + ')'));
    }
    if (!data) throw new Error('ส่งไม่สำเร็จ (ไม่มีข้อมูลตอบกลับ)');
    return data;
}

$(function() {
    if (document.getElementById('afCaseModal')) {
        afModal = new bootstrap.Modal(document.getElementById('afCaseModal'));
    }
    setupVoiceInput();
    const openCaseId = parseInt(new URLSearchParams(location.search).get('case') || '0', 10);
    loadMeta().then(function() {
        if (AF_PREFILL_HN) lookupHn();
        loadDashboard();
        if (openCaseId > 0) openCase(openCaseId);
    });

    $('#btnLookupHn').on('click', lookupHn);
    $('#rep_hn').on('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); lookupHn(); } });
    $('#rep_hn').on('blur', function() { if (this.value.trim()) lookupHn(); });

    const drop = document.getElementById('afDrop');
    const fileIn = document.getElementById('rep_photos');
    const camIn = document.getElementById('rep_photos_camera');
    drop.addEventListener('click', () => fileIn.click());
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('drag'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('drag'));
    drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('drag'); addFiles(e.dataTransfer.files); });
    fileIn.addEventListener('change', function() { addFiles(this.files); this.value = ''; });
    if (camIn) {
        camIn.addEventListener('change', function() { addFiles(this.files); this.value = ''; });
    }
    const btnGal = document.getElementById('btnPickGallery');
    const btnCam = document.getElementById('btnPickCamera');
    if (btnGal) btnGal.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); fileIn.click(); });
    if (btnCam) btnCam.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); if (camIn) camIn.click(); });

    $('#btnResetReport').on('click', function() {
        stopAllVoice(true);
        setVoiceBtnState('idle');
        setVoiceHint(voiceDefaultHint());
        resetReportForm();
    });

    $('#btnDashReload, #btnDashSearch').on('click', loadDashboard);
    $('#dash_q').on('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); loadDashboard(); } });
    $('#afKpiRow').on('click', '.kpi-card', function() {
        dashStage = this.getAttribute('data-stage') || 'all';
        loadDashboard();
    });
    $('#afDashTbody').on('click', 'tr.af-row', function(e) {
        if ($(e.target).closest('.btn-ack-row, .btn-del-row').length) return;
        const id = parseInt(this.getAttribute('data-id'), 10);
        if (id) openCase(id);
    });
    $('#afDashTbody').on('click', '.btn-ack-row', function(e) {
        e.preventDefault();
        e.stopPropagation();
        ackCase(this.getAttribute('data-id'));
    });
    $('#afDashTbody').on('click', '.btn-del-row', function(e) {
        e.preventDefault();
        e.stopPropagation();
        deleteCase(this.getAttribute('data-id'));
    });
    $('#btnAck').on('click', function() { ackCase($('#md_id').val()); });
    $('#btnAckConfirm').on('click', confirmAckCase);
    $('#btnTransferConfirm').on('click', confirmTransferCase);
    $(document).on('change', '#xfer_pick_user, #ack_pick_user', function() {
        const $el = $(this);
        if ($el.data('filling')) return;
        const p = selectedAckPayload($el);
        if (p.ack_by_name) $el.data('last-pick', p);
    });
    $('#tabBtnTransfer').on('shown.bs.tab', function() {
        const id = $('#md_id').val();
        if (id) {
            $('#xfer_case_id').val(id);
            $('#xfer_from_name').text(currentCaseReceiverName());
        }
    });
    $('#afAckModal').on('hidden.bs.modal', keepParentCaseModal);
    $('#btnSaveStatus').on('click', saveCaseStatus);
    $('#btnDeleteCase').on('click', function() { deleteCase($('#md_id').val()); });
    $('#mdTimeline').on('click', '.btn-edit-tl', function(e) {
        e.preventDefault();
        e.stopPropagation();
        openTimelineEditor(this.getAttribute('data-id'));
    });
    $('#btnTlEditSave').on('click', saveTimelineEditor);
    setInterval(loadDashboard, 45000);

    $('#afReportForm').on('submit', async function(e) {
        e.preventDefault();
        const hn = $('#rep_hn').val().trim();
        const ptname = $('#rep_ptname').val().trim();
        if (!hn && !ptname) {
            alert('กรุณาระบุ HN หรือชื่อผู้ป่วย');
            return;
        }
        const btn = $('#btnSubmitReport').prop('disabled', true);
        try {
            // บันทึกเคสก่อนโดยไม่แนบรูป — กันรูปใหญ่ทำให้ request ทั้งก้อนพัง
            const fd = new FormData();
            fd.append('action', 'save');
            fd.append('hn', hn);
            fd.append('ptname', ptname);
            fd.append('ward', $('#rep_ward').val().trim());
            fd.append('ward_detail', $('#rep_detail').val().trim());
            fd.append('channel', $('#rep_channel').val());
            fd.append('case_date', $('#rep_date').val());
            fd.append('notify_time', $('#rep_time').val());
            const saveRes = await fetch('fetch_allergy_followup_api.php?action=save', {
                method: 'POST', credentials: 'same-origin', body: fd
            });
            const data = await parseJsonResponse(saveRes);
            if (data.status !== 'success') {
                throw new Error(data.message || 'ส่งไม่สำเร็จ');
            }
            const caseId = data.case && data.case.id ? data.case.id : (data.id || 0);
            let photoErr = '';
            if (afFiles.length && caseId) {
                const pfd = new FormData();
                pfd.append('action', 'upload_photos');
                pfd.append('case_id', String(caseId));
                pfd.append('photo_kind', 'nurse');
                afFiles.forEach(f => pfd.append('photos[]', f));
                try {
                    const photoRes = await fetch('fetch_allergy_followup_api.php?action=upload_photos', {
                        method: 'POST', credentials: 'same-origin', body: pfd
                    });
                    const pdata = await parseJsonResponse(photoRes);
                    if (pdata.status !== 'success') {
                        photoErr = pdata.message || 'เคสบันทึกแล้ว แต่ส่งรูปไม่สำเร็จ';
                    }
                } catch (photoEx) {
                    photoErr = 'เคสบันทึกแล้ว แต่ส่งรูปไม่สำเร็จ' + (photoEx && photoEx.message ? (' — ' + photoEx.message) : '');
                }
            }
            let msg = (afFiles.length && !photoErr)
                ? 'ส่งเคสและรูปแล้ว เภสัชจะได้รับการแจ้งเตือน'
                : 'บันทึกเคสแล้ว รอเภสัชรับเคส';
            if (photoErr) msg += '\n' + photoErr;
            alert(msg);
            highlightId = caseId;
            resetReportForm();
            loadDashboard();
            const dash = document.getElementById('repDash');
            if (dash) dash.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } catch (err) {
            alert((err && err.message) ? err.message : 'ส่งไม่สำเร็จ');
        } finally {
            btn.prop('disabled', false);
        }
    });
});
</script>
</body>
</html>
