<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/patient_ipd_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
tham_menu_ensure_page_access('patient_ipd.php');
$prefill_hn = htmlspecialchars(trim((string)($_GET['hn'] ?? '')), ENT_QUOTES, 'UTF-8');
$prefill_an = htmlspecialchars(trim((string)($_GET['an'] ?? '')), ENT_QUOTES, 'UTF-8');
$user_name = htmlspecialchars((string)($_SESSION['full_name'] ?? ''), ENT_QUOTES, 'UTF-8');
$can_smart_drug = tham_menu_can('pharm_care.smart_drug') || (($_SESSION['role'] ?? '') === 'admin');
$can_smart_lab = tham_menu_can('pharm_care.smart_lab') || (($_SESSION['role'] ?? '') === 'admin');
$can_patient_opd = tham_menu_can('pharm_care.patient_opd') || (($_SESSION['role'] ?? '') === 'admin');
$can_drug_refer = tham_menu_can('network_drug.refer') || (($_SESSION['role'] ?? '') === 'admin');
$can_med_error = tham_menu_can('pharm_care.med_error') || (($_SESSION['role'] ?? '') === 'admin');
$is_admin = (($_SESSION['role'] ?? '') === 'admin');
$can_mg_ml = tham_menu_can('dose_calc.mg_ml') || tham_menu_can('dose_calc.hub') || $is_admin;
$can_warfarin = tham_menu_can('dose_calc.warfarin') || tham_menu_can('dose_calc.hub') || $is_admin;
$can_peds_dose = tham_menu_can('dose_calc.pediatric') || tham_menu_can('dose_calc.hub') || $is_admin;
$emr_hn_qs = $prefill_hn !== '' ? ('?hn=' . rawurlencode(html_entity_decode($prefill_hn, ENT_QUOTES, 'UTF-8'))) : '';
$pip_uid = (int)($_SESSION['user_id'] ?? 0);
$pip_order_col_widths = pip_load_order_col_widths($con, $pip_uid);
$pip_med_col_widths = pip_load_med_col_widths($con, $pip_uid);
$pip_layout = pip_load_layout($con, $pip_uid);
// ค่าเริ่มต้นทุกคน = เปิด Drug Viewer อัตโนมัติ (ถ้ายังไม่เคยตั้งเอง)
$pip_layout_raw = pip_load_user_ui_pref($con, $pip_uid, 'layout');
if (!is_array($pip_layout_raw) || !array_key_exists('open_dv_on_irx', $pip_layout_raw)) {
    $pip_layout['open_dv_on_irx'] = 1;
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Patient IPD - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        html, body { height: 100%; margin: 0; overflow: hidden; }
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: #dce3e8; color: #1f2a30; font-size: 12.5px; }
        .pip-shell { height: 100vh; display: flex; flex-direction: column; min-height: 0; }
        .pip-chrome {
            flex: 0 0 auto; min-height: 46px; display: flex; align-items: center; gap: 10px;
            padding: 0 12px; background: linear-gradient(180deg, #f7fafc 0%, #e8eef2 100%);
            border-bottom: 1px solid #b8c6ce; flex-wrap: nowrap; overflow: hidden;
        }
        .pip-back {
            color: #5a7380; text-decoration: none; width: 30px; height: 30px;
            display: inline-flex; align-items: center; justify-content: center; border-radius: 6px;
        }
        .pip-back:hover { background: #e2eef3; color: #0aa2c0; }
        .pip-brand { font-weight: 800; font-size: 1.15rem; color: #0aa2c0; white-space: nowrap; }
        .pip-search { display: flex; align-items: center; gap: 5px; }
        .pip-search .pip-field {
            display: inline-flex; align-items: center; gap: 4px;
        }
        .pip-search .pip-field > span {
            font-weight: 800; font-size: 12px; color: #355; white-space: nowrap;
        }
        .pip-search input {
            height: 30px; width: 140px; font-weight: 700; border: 1px solid #b8c9d2;
            border-radius: 5px; padding: 0 8px; background: #fff;
        }
        .pip-search button {
            height: 30px; border: 0; border-radius: 5px; background: #0aa2c0; color: #fff;
            font-weight: 700; padding: 0 10px;
        }
        .pip-emr-links { display: flex; gap: 5px; }
        .pip-emr-link {
            display: inline-flex; align-items: center; gap: 4px; height: 30px; padding: 0 9px;
            border-radius: 5px; text-decoration: none; font-weight: 800; font-size: 11.5px;
            border: 1px solid #c5e4ec; background: #e8f7fb; color: #0b7285; white-space: nowrap;
            cursor: pointer;
        }
        .pip-emr-link:hover { background: #d4eef5; color: #085d6c; }
        button.pip-emr-link { font-family: inherit; }
        .pip-emr-link.is-dv { border-color: #c7d2fe; background: #eef2ff; color: #3730a3; }
        .pip-emr-link.is-dv:hover { background: #e0e7ff; color: #312e81; }
        .pip-dv-modal {
            position: fixed; inset: 0; background: rgba(15, 23, 42, .55);
            display: none; align-items: center; justify-content: center; z-index: 72;
        }
        .pip-dv-box {
            width: min(1180px, calc(100% - 28px)); height: min(88vh, 860px);
            background: #fff; border-radius: 12px; box-shadow: 0 18px 50px rgba(15, 23, 42, .35);
            display: flex; flex-direction: column; overflow: hidden; border: 1px solid #c7d2fe;
        }
        .pip-dv-head {
            display: flex; align-items: center; justify-content: space-between; gap: 10px;
            padding: 10px 14px; background: linear-gradient(90deg, #312e81, #0f766e);
            color: #fff; flex: 0 0 auto;
        }
        .pip-dv-head h6 { margin: 0; font-weight: 800; font-size: 1.05rem; }
        .pip-dv-head .meta { font-size: 12px; opacity: .9; }
        .pip-dv-x {
            border: 0; background: rgba(255,255,255,.18); color: #fff; width: 32px; height: 32px;
            border-radius: 8px; font-size: 1.25rem; line-height: 1; cursor: pointer;
        }
        .pip-dv-x:hover { background: rgba(255,255,255,.3); }
        .pip-dv-body { flex: 1; min-height: 0; display: flex; }
        .pip-dv-list {
            flex: 0 0 340px; max-width: 42%; border-right: 1px solid #e2e8f0;
            display: flex; flex-direction: column; min-height: 0; background: #f8fafc;
        }
        .pip-dv-list-tools {
            flex: 0 0 auto; padding: 8px; border-bottom: 1px solid #e2e8f0;
            display: flex; gap: 6px; align-items: center; flex-wrap: wrap;
        }
        .pip-dv-list-tools select {
            border: 1px solid #cbd5e1; border-radius: 6px; padding: 4px 8px; font-size: 12px;
        }
        .pip-dv-list-body { flex: 1; min-height: 0; overflow: auto; }
        .pip-dv-item {
            width: 100%; border: 0; border-bottom: 1px solid #e2e8f0; background: #fff;
            text-align: left; padding: 8px 10px; cursor: pointer; display: block; font-family: inherit;
        }
        .pip-dv-item:hover { background: #eef2ff; }
        .pip-dv-item.active { background: #e0e7ff; box-shadow: inset 3px 0 0 #4f46e5; }
        .pip-dv-item .t1 { font-weight: 800; font-size: 12.5px; color: #1e293b; }
        .pip-dv-item .t2 { font-size: 11.5px; color: #475569; margin-top: 2px; }
        .pip-dv-item .t3 { font-size: 11px; color: #64748b; margin-top: 2px; display: flex; gap: 6px; flex-wrap: wrap; }
        .pip-dv-badge {
            display: inline-block; padding: 0 6px; border-radius: 999px; font-size: 10.5px; font-weight: 700;
            background: #e2e8f0; color: #334155;
        }
        .pip-dv-badge.urgent { background: #fee2e2; color: #b91c1c; }
        .pip-dv-badge.home { background: #dbeafe; color: #1d4ed8; }
        .pip-dv-badge.paid { background: #dcfce7; color: #166534; }
        .pip-dv-view { flex: 1; min-width: 0; display: flex; flex-direction: column; background: #0f172a; }
        .pip-dv-view-bar {
            flex: 0 0 auto; display: flex; align-items: center; justify-content: space-between;
            gap: 8px; padding: 6px 10px; background: #1e293b; color: #e2e8f0; font-size: 12px;
        }
        .pip-dv-view-bar a, .pip-dv-view-bar button {
            border: 1px solid #475569; background: #334155; color: #f8fafc; border-radius: 6px;
            padding: 3px 10px; font-size: 12px; font-weight: 700; text-decoration: none; cursor: pointer;
        }
        .pip-dv-frame { flex: 1; min-height: 0; border: 0; width: 100%; background: #111827; }
        .pip-dv-empty {
            flex: 1; display: flex; align-items: center; justify-content: center;
            color: #94a3b8; font-weight: 700; padding: 24px; text-align: center;
        }
        .pip-status { color: #5a7380; flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .pip-chrome-right { margin-left: auto; font-weight: 700; color: #355; white-space: nowrap; }
        .pip-ptbar {
            flex: 0 0 auto; display: flex; align-items: center; gap: 14px; flex-wrap: wrap;
            padding: 6px 12px; background: #fff; border-bottom: 1px solid #c5d5dc;
            font-size: 12.5px; min-height: 36px;
        }
        .pip-ptbar .k { color: #5a7380; font-weight: 700; }
        .pip-ptbar .v { font-weight: 800; color: #17323d; margin-right: 4px; }
        .pip-ptbar .name { color: #0aa2c0; font-size: 1.05rem; }
        .pip-ptbar .pttype-v { color: #6d28d9; font-weight: 800; }
        .pip-ptbar .dx { color: #c0392b; font-weight: 800; }
        .pip-ptbar .chip {
            display: inline-block; padding: 1px 7px; border-radius: 4px; font-size: 11px; font-weight: 700;
        }
        .chip-al { background: #f8d7da; color: #842029; }
        .chip-ok { background: #d1e7dd; color: #0f5132; }
        .chip-active { background: #cff4fc; color: #055160; }
        .chip-dch { background: #e2e3e5; color: #41464b; }
        .pip-labbox {
            display: inline-flex; gap: 10px; align-items: center; flex-wrap: wrap;
            background: #fff8db; border: 1px solid #f0e0a0; border-radius: 4px;
            padding: 2px 8px; font-weight: 800; color: #5a4500; font-size: 12px;
        }
        .pip-labbox b { color: #0b7285; }
        .pip-labbox .pip-lab-alert,
        .pip-labbox b.pip-lab-alert {
            color: #c62828 !important; font-weight: 900 !important;
        }
        .pip-labbox .pip-crcl-link {
            color: #0b7285; cursor: pointer; text-decoration: underline dotted;
            text-underline-offset: 2px;
        }
        .pip-labbox .pip-crcl-link:hover { color: #c62828; }
        .pip-labbox .pip-crcl-edited { color: #b45309 !important; }
        .pip-crcl-modal {
            display: none; position: fixed; inset: 0; z-index: 12000;
            background: rgba(15, 23, 42, 0.45); align-items: center; justify-content: center;
            padding: 16px;
        }
        .pip-crcl-box {
            width: min(520px, 100%); background: #fff; border-radius: 10px;
            box-shadow: 0 18px 50px rgba(0,0,0,.28); overflow: hidden;
            font-family: 'Sarabun', Tahoma, sans-serif;
        }
        .pip-crcl-box .hd {
            background: linear-gradient(180deg, #e3f2fd, #bbdefb); padding: 10px 14px;
            font-weight: 800; color: #0d47a1; display: flex; justify-content: space-between; align-items: center;
        }
        .pip-crcl-box .bd { padding: 14px 16px; }
        .pip-crcl-formula {
            font-size: 13px; font-weight: 700; color: #1e293b; line-height: 1.7;
            background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px 12px;
        }
        .pip-crcl-formula input, .pip-crcl-formula select {
            width: 72px; display: inline-block; margin: 0 2px; text-align: center;
            font-weight: 800; border: 1px solid #90caf9; border-radius: 4px; padding: 2px 4px;
            background: #fffde7;
        }
        .pip-crcl-formula input.pip-crcl-scr { background: #e3f2fd; }
        .pip-crcl-formula .pip-crcl-result {
            width: 90px; background: #fff59d; border-color: #fbc02d; font-size: 15px;
        }
        .pip-crcl-note { color: #c62828; font-size: 12px; font-weight: 700; margin-top: 8px; }
        .pip-crcl-dates { font-size: 12px; color: #475569; margin-top: 8px; line-height: 1.5; }
        .pip-crcl-actions { display: flex; gap: 8px; justify-content: flex-end; margin-top: 12px; flex-wrap: wrap; }
        .pip-crcl-actions .pip-btn.primary { background: #1565c0; color: #fff; border-color: #0d47a1; }
        .pip-table tr.row-inj td { background: #eaf7ee; }
        .pip-table tr.row-other td { background: #f3eef9; }
        .pip-table tr.row-inj:hover td { background: #dcf0e2; }
        .pip-table tr.row-other:hover td { background: #ebe3f5; }
        .pip-table td.num, .pip-table th.num { text-align: center; white-space: nowrap; }
        .pip-table td.code { font-family: Consolas, monospace; font-size: 11px; color: #355; white-space: nowrap; }
        .pip-tab .badge-n {
            display: inline-block; min-width: 18px; padding: 0 5px; margin-left: 4px;
            border-radius: 9px; background: #0aa2c0; color: #fff; font-size: 10px; font-weight: 800;
        }
        .pip-tab[data-med="off"] .badge-n { background: #c0392b; }
        .pip-stage { flex: 1; min-height: 0; display: flex; background: #eceff2; }
        .pip-empty {
            flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;
            color: #8a9aa3; gap: 8px; background: #f5f7f9;
        }
        .pip-left {
            width: 42%; min-width: 280px; max-width: none; flex: 0 0 auto;
            display: flex; flex-direction: column; min-height: 0;
            background: #f4f6f8;
        }
        .pip-v-split {
            flex: 0 0 6px; width: 6px; cursor: col-resize; position: relative; z-index: 4;
            background: #c5d5dc; border-left: 1px solid #b8c6ce; border-right: 1px solid #b8c6ce;
            touch-action: none;
        }
        .pip-v-split:hover,
        body.pip-layout-resizing .pip-v-split {
            background: #0aa2c0;
        }
        .pip-v-split::after {
            content: ''; position: absolute; top: 50%; left: 50%;
            width: 2px; height: 36px; margin: -18px 0 0 -1px;
            border-radius: 1px; background: rgba(255,255,255,.55);
            pointer-events: none;
        }
        body.pip-layout-resizing { cursor: col-resize !important; user-select: none !important; }
        .pip-right { flex: 1; min-width: 240px; display: flex; flex-direction: column; min-height: 0; background: #f4f6f8; }
        .pip-tabs {
            display: flex; gap: 0; flex: 0 0 auto; background: #e4eaee;
            border-bottom: 1px solid #b8c6ce; overflow-x: auto;
        }
        .pip-tab {
            border: 0; background: transparent; padding: 7px 12px; font-weight: 700;
            color: #4a6570; border-right: 1px solid #c9d4db; white-space: nowrap; cursor: pointer;
        }
        .pip-tab:hover { background: #eef3f6; }
        .pip-tab.active {
            background: #fff; color: #0b7285; border-bottom: 2px solid #0aa2c0; margin-bottom: -1px;
        }
        .pip-pane { flex: 1; min-height: 0; display: none; flex-direction: column; background: #fff; }
        .pip-pane.active { display: flex; }
        .pip-split { flex: 1; min-height: 0; display: flex; flex-direction: column; }
        .pip-orders { flex: 0 0 48%; min-height: 120px; display: flex; flex-direction: column; border-bottom: 1px solid #c5d5dc; }
        .pip-items { flex: 1; min-height: 100px; display: flex; flex-direction: column; }
        .pip-order-toolbar {
            flex: 0 0 auto; display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
            padding: 4px 8px; background: #eef4f7; border-bottom: 1px solid #d0dde4;
        }
        .pip-order-mode {
            display: inline-flex; border: 1px solid #b8c6ce; border-radius: 5px; overflow: hidden; background: #fff;
        }
        .pip-order-mode button {
            border: 0; background: transparent; padding: 3px 12px; font-weight: 800; font-size: 11.5px;
            color: #4a6570; cursor: pointer; border-right: 1px solid #d0dde4;
        }
        .pip-order-mode button:last-child { border-right: 0; }
        .pip-order-mode button.active { background: #0aa2c0; color: #fff; }
        .pip-order-mode button .n {
            display: inline-block; min-width: 16px; margin-left: 3px; padding: 0 4px;
            border-radius: 8px; background: rgba(255,255,255,.25); font-size: 10px;
        }
        .pip-order-mode button:not(.active) .n { background: #c5dbe3; color: #0b7285; }
        .pip-order-checks {
            display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap; font-weight: 700; font-size: 11.5px;
        }
        .pip-order-checks label {
            display: inline-flex; align-items: center; gap: 3px; cursor: pointer;
            padding: 1px 6px; border-radius: 4px; border: 1px solid #c5d5dc; background: #fff; user-select: none;
        }
        .pip-order-checks label.on { background: #e8f7fb; border-color: #0aa2c0; color: #0b7285; }
        .pip-order-checks label.hme-only { background: #fff3cd; border-color: #e0c36a; color: #856404; }
        .pip-order-checks input { margin: 0; accent-color: #0aa2c0; }
        .pip-order-meta { margin-left: auto; color: #5a7380; font-size: 11px; font-weight: 700; white-space: nowrap; }
        .pip-item-filter {
            display: inline-flex; align-items: center; gap: 4px; cursor: pointer; user-select: none;
            font-size: 11px; font-weight: 700; color: #0b7285; background: #fff; border: 1px solid #9fd3de;
            border-radius: 4px; padding: 1px 7px; white-space: nowrap;
        }
        .pip-item-filter input { margin: 0; accent-color: #0aa2c0; }
        .pip-item-filter.on { background: #e8f7fb; }
        .pip-sec-toggles { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; justify-content: flex-end; }
        .pip-switch {
            display: inline-flex; align-items: center; gap: 6px; cursor: pointer; user-select: none;
            font-size: 11px; font-weight: 700; color: #5a7380; background: #fff; border: 1px solid #c5d5dc;
            border-radius: 999px; padding: 2px 8px 2px 4px; white-space: nowrap;
        }
        .pip-switch input { position: absolute; opacity: 0; width: 0; height: 0; }
        .pip-switch-track {
            position: relative; width: 30px; height: 16px; border-radius: 999px;
            background: #cbd5e1; flex: 0 0 auto; transition: background .18s ease;
        }
        .pip-switch-knob {
            position: absolute; top: 2px; left: 2px; width: 12px; height: 12px; border-radius: 50%;
            background: #fff; box-shadow: 0 1px 2px rgba(0,0,0,.2); transition: transform .18s ease;
        }
        .pip-switch.on { color: #3730a3; background: #eef2ff; border-color: #a5b4fc; }
        .pip-switch.on .pip-switch-track { background: #6366f1; }
        .pip-switch.on .pip-switch-knob { transform: translateX(14px); }
        .pip-switch-txt { line-height: 1.1; }
        .pip-kind-nd {
            display: inline-block; margin-right: 4px; padding: 0 5px; border-radius: 3px;
            background: #eceff1; color: #455a64; font-size: 10px; font-weight: 800;
        }
        .pip-table tr.row-nondrug td { background: #fafbfc; }
        .pip-order-table,
        #medTable.pip-med-table { table-layout: fixed; width: 100%; }
        .pip-order-table th,
        #medTable.pip-med-table th {
            position: sticky; top: 0; z-index: 1; overflow: hidden; text-overflow: ellipsis;
        }
        .pip-order-table th .col-resize-handle,
        #medTable.pip-med-table th .col-resize-handle {
            position: absolute; right: 0; top: 0; width: 7px; height: 100%;
            cursor: col-resize; user-select: none; z-index: 3;
            /* เส้นบางๆ เห็นตลอด — ลากได้ที่ขอบคอลัมน์ */
            background: linear-gradient(to right, transparent 0, transparent 2px, #94a3b8 2px, #94a3b8 3px, transparent 3px);
        }
        .pip-order-table th .col-resize-handle:hover,
        #medTable.pip-med-table th .col-resize-handle:hover,
        body.pip-col-resizing .pip-order-table th .col-resize-handle.is-active,
        body.pip-col-resizing #medTable.pip-med-table th .col-resize-handle.is-active {
            background: linear-gradient(to right, transparent 0, transparent 1px, #0aa2c0 1px, #0aa2c0 4px, transparent 4px);
        }
        /* เส้นแบ่งคอลัมน์บางๆ ในหัวตารางยา */
        #medTable.pip-med-table th {
            border-right: 1px solid #c5d0d8;
            box-sizing: border-box;
        }
        #medTable.pip-med-table th:last-child { border-right: 0; }
        #medTable.pip-med-table td {
            border-right: 1px solid #e8eef2;
        }
        #medTable.pip-med-table td:last-child { border-right: 0; }
        #medTable.pip-med-table tr.grp-inj th,
        #medTable.pip-med-table tr.grp-other th { border-right: 0; }
        body.pip-col-resizing { cursor: col-resize !important; user-select: none !important; }
        #medTable.pip-med-table td {
            overflow: hidden; text-overflow: ellipsis;
        }
        .pip-order-table td.rx-note-td { padding: 4px 6px; overflow: hidden; }
        .pip-order-table td.dt-split {
            white-space: nowrap; line-height: 1.25;
            padding-top: 5px; padding-bottom: 5px; overflow: hidden;
        }
        .pip-order-table td.dt-split .dt-date { display: block; font-weight: 700; }
        .pip-order-table td.dt-split .dt-time { display: block; color: #5a7380; font-size: 11px; font-weight: 600; }
        .pip-order-table tr.selected td.dt-split .dt-time { color: #0b7285; }
        .pip-order-table th.col-person,
        .pip-order-table td.col-person {
            font-size: 10px; font-weight: 600; line-height: 1.25;
            white-space: normal; word-break: break-word; overflow: hidden;
        }
        .pip-order-table td.col-person.dispense-ok { font-weight: 700; font-size: 10px; }
        .pip-order-table td.col-person.dispense-default { font-weight: 600; font-size: 10px; }
        .pip-order-table td.col-ward {
            font-size: 11px; white-space: normal; word-break: break-word; overflow: hidden;
        }
        .pip-order-table td.code { font-size: 11px; overflow: hidden; text-overflow: ellipsis; }
        .rx-note-box {
            display: flex; flex-direction: column; gap: 4px;
            border: 1px solid #c5d5dc; border-radius: 5px; padding: 6px; background: #fff;
            min-height: 64px;
        }
        .rx-note-box.is-alert {
            background: #e53935; border-color: #b71c1c; color: #fff;
        }
        .rx-note-box.is-alert .rx-note-mode,
        .rx-note-box.is-alert .rx-note-text {
            background: transparent; color: #fff; border-color: rgba(255,255,255,.55);
        }
        .rx-note-box.is-alert .rx-note-text::placeholder { color: rgba(255,255,255,.75); }
        .rx-note-box.is-alert .rx-note-mode option { color: #243038; background: #fff; }
        .rx-note-mode {
            font-size: 11px; font-weight: 700; border: 1px solid #c5d5dc; border-radius: 4px;
            padding: 3px 6px; width: 100%; background: #f8fafb; color: #355;
        }
        .rx-note-text {
            font-size: 12px; font-weight: 600; border: 1px solid #c5d5dc; border-radius: 4px;
            padding: 6px 8px; width: 100%; min-height: 32px; box-sizing: border-box;
            background: #fff; color: #243038;
        }
        .rx-note-box.is-saving { opacity: .7; }
        .pip-table-wrap { overflow: auto; flex: 1; min-height: 0; }
        .pip-table { width: 100%; border-collapse: collapse; margin: 0; font-size: 12px; }
        .pip-table th {
            position: sticky; top: 0; z-index: 1; background: #e8eef2; font-weight: 800;
            padding: 5px 6px; border-bottom: 1px solid #c5d5dc; white-space: nowrap; text-align: left;
        }
        .pip-table td { padding: 4px 6px; border-bottom: 1px solid #edf1f4; vertical-align: top; }
        .pip-table tr:hover td { background: #f3fafc; }
        .pip-table tr.selected td { background: #d9f0f6; }
        .pip-table .muted { color: #8a9aa3; }
        .pip-sec {
            background: #dff4f8; color: #0b7285; font-weight: 800; font-size: 12px;
            padding: 5px 10px; border-bottom: 1px solid #c5e4ec; flex: 0 0 auto;
        }
        .grp-inj th { background: #8fd19e !important; color: #0f3d1a; text-align: left; }
        .grp-other th { background: #b39ddb !important; color: #2e1a47; text-align: left; }
        .pip-foot {
            flex: 0 0 auto; display: flex; flex-wrap: wrap; gap: 5px; align-items: center;
            padding: 6px 8px; background: #e8eef2; border-top: 1px solid #b8c6ce;
        }
        .pip-btn {
            border: 1px solid #b0c0c8; background: linear-gradient(180deg, #fff, #e9eef2);
            color: #243038; border-radius: 4px; padding: 4px 9px; font-weight: 700; font-size: 11.5px;
            text-decoration: none; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;
        }
        .pip-btn:hover { background: #eef6f8; color: #0aa2c0; }
        .pip-btn:disabled, .pip-btn.is-disabled {
            opacity: .55; cursor: not-allowed; pointer-events: none;
        }
        .pip-btn.danger { background: linear-gradient(180deg, #ff8a80, #e53935); color: #fff; border-color: #c62828; }
        .pip-btn.primary { background: linear-gradient(180deg, #ffb74d, #fb8c00); color: #fff; border-color: #ef6c00; }
        .pip-btn.primary:not(:disabled):not(.is-disabled):hover { filter: brightness(1.05); }
        .pip-btn.note-hosxp {
            background: linear-gradient(180deg, #ff8a80, #e53935); color: #fff; border-color: #c62828;
        }
        .pip-btn.note-hosxp:hover { filter: brightness(1.05); color: #fff; }
        .pip-btn.note-hosxp .n {
            display: inline-block; min-width: 16px; padding: 0 4px; margin-left: 2px;
            border-radius: 8px; background: rgba(255,255,255,.25); font-size: 10px; text-align: center;
        }
        .pip-note-modal {
            position: fixed; inset: 0; background: rgba(20, 40, 48, .45);
            display: none; align-items: center; justify-content: center; z-index: 60;
        }
        .pip-note-box {
            width: min(860px, calc(100% - 40px)); max-height: min(78vh, 640px);
            background: #fff; border-radius: 12px; box-shadow: 0 16px 48px rgba(15, 40, 48, .28);
            display: flex; flex-direction: column; min-height: 0; overflow: hidden;
        }
        .pip-note-head {
            display: flex; align-items: center; justify-content: space-between;
            padding: 12px 16px 8px; flex: 0 0 auto;
        }
        .pip-note-head h6 { margin: 0; font-weight: 800; font-size: 1.05rem; color: #c62828; }
        .pip-note-x {
            border: 0; background: transparent; color: #6c757d; font-size: 1.3rem;
            line-height: 1; cursor: pointer; padding: 0 4px;
        }
        .pip-note-body { overflow: auto; padding: 0 12px 14px; min-height: 0; }
        .pip-note-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .pip-note-table th {
            background: #e7f1fb; color: #1b4f72; font-weight: 800; text-align: center;
            padding: 8px 10px; border-bottom: 1px solid #d0e4f5; white-space: nowrap;
        }
        .pip-note-table td { padding: 10px; border-bottom: 1px solid #eef2f4; vertical-align: top; }
        .pip-note-table tr:last-child td { border-bottom: 0; }
        .pip-note-text { white-space: pre-wrap; word-break: break-word; color: #243038; }
        .pip-note-staff, .pip-note-date, .pip-note-exp { text-align: center; white-space: nowrap; color: #355; }
        .pip-note-empty { text-align: center; color: #8a9aa3; padding: 28px 12px; }
        .pip-allergy-modal {
            position: fixed; inset: 0; background: rgba(20, 40, 48, .5);
            display: none; align-items: center; justify-content: center; z-index: 65;
        }
        .pip-allergy-box {
            width: min(960px, calc(100% - 36px)); max-height: min(80vh, 680px);
            background: #fff; border-radius: 8px; box-shadow: 0 16px 48px rgba(120, 0, 0, .28);
            display: flex; flex-direction: column; min-height: 0; overflow: hidden;
            border: 2px solid #c62828;
        }
        .pip-allergy-head {
            background: #e53935; color: #fff; font-weight: 800; font-size: 1.05rem;
            padding: 10px 14px; display: flex; align-items: center; justify-content: space-between;
        }
        .pip-allergy-head .x {
            border: 0; background: transparent; color: #fff; font-size: 1.35rem;
            line-height: 1; cursor: pointer; padding: 0 4px;
        }
        .pip-allergy-body { overflow: auto; padding: 0; min-height: 0; }
        .pip-allergy-table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
        .pip-allergy-table th {
            background: #ffebee; color: #b71c1c; font-weight: 800; text-align: center;
            padding: 8px 8px; border-bottom: 1px solid #ffcdd2; white-space: nowrap;
        }
        .pip-allergy-table td {
            padding: 8px; border-bottom: 1px solid #f3e5e5; vertical-align: top;
        }
        .pip-allergy-table tr:last-child td { border-bottom: 0; }
        .pip-allergy-table .agent { font-weight: 800; color: #b71c1c; }
        .pip-allergy-empty { text-align: center; color: #8a9aa3; padding: 28px 12px; }
        .pip-ptbar .chip-al { cursor: pointer; }
        .pip-ptbar .chip-al:hover { filter: brightness(1.05); }
        .pip-chrome .pip-tools { display: inline-flex; align-items: center; gap: 6px; margin-left: 6px; }
        .pip-btn.warn-ahead {
            background: linear-gradient(180deg, #ffe082, #ffb300); color: #4e342e; border-color: #f9a825;
        }
        .pip-btn.warn-ahead .n {
            display: inline-block; min-width: 16px; padding: 0 4px; margin-left: 2px;
            border-radius: 8px; background: rgba(0,0,0,.12); font-size: 10px; text-align: center;
        }
        @keyframes pip-alert-blink {
            0%, 100% { opacity: 1; filter: brightness(1); box-shadow: none; }
            50% { opacity: .55; filter: brightness(1.15); box-shadow: 0 0 0 2px rgba(255,255,255,.35); }
        }
        .pip-btn.must-paid.is-blink,
        .pip-btn.warn-ahead.is-blink,
        .pip-btn.warn-robot.is-blink,
        .pip-btn.warn-pharma.is-blink {
            animation: pip-alert-blink 1.1s ease-in-out infinite;
        }
        @media (prefers-reduced-motion: reduce) {
            .pip-btn.must-paid.is-blink,
            .pip-btn.warn-ahead.is-blink,
            .pip-btn.warn-robot.is-blink,
            .pip-btn.warn-pharma.is-blink { animation: none; outline: 2px solid #c62828; }
        }
        .pip-btn.warn-pharma {
            background: linear-gradient(180deg, #80cbc4, #0d9488); color: #fff; border-color: #0f766e;
        }
        .pip-btn.warn-pharma .n {
            display: inline-block; min-width: 16px; padding: 0 4px; margin-left: 2px;
            border-radius: 8px; background: rgba(255,255,255,.28); font-size: 10px; text-align: center;
        }
        .pip-btn.warn-robot {
            background: linear-gradient(180deg, #ef9a9a, #e53935); color: #fff; border-color: #c62828;
        }
        .pip-btn.warn-robot .n {
            display: inline-block; min-width: 16px; padding: 0 4px; margin-left: 2px;
            border-radius: 8px; background: rgba(255,255,255,.28); font-size: 10px; text-align: center;
        }
        .pip-table tr.row-robot-miss td { background: #ffebee !important; }
        .pip-table tr.row-robot-miss:hover td { background: #ffcdd2 !important; }
        .pip-table td.cell-miss {
            color: #b71c1c; font-weight: 800; background: #ffcdd2 !important;
        }
        .pip-table td.cell-off-today {
            background: #fff59d !important;
            font-weight: 700;
            color: #5d4037;
        }
        .pip-pharma-modal {
            position: fixed; inset: 0; background: rgba(20, 40, 48, .5);
            display: none; align-items: center; justify-content: center; z-index: 67;
        }
        .pip-pharma-box {
            width: min(720px, calc(100% - 36px)); max-height: min(80vh, 680px);
            background: #fff; border-radius: 12px; box-shadow: 0 16px 48px rgba(15, 80, 72, .28);
            display: flex; flex-direction: column; overflow: hidden; border: 2px solid #0d9488;
        }
        .pip-pharma-head {
            display: flex; align-items: center; justify-content: space-between;
            padding: 12px 16px; border-bottom: 1px solid #99f6e4; background: #ecfdf5; flex: 0 0 auto;
        }
        .pip-pharma-head h6 { margin: 0; font-weight: 800; color: #0f766e; }
        .pip-pharma-body { overflow: auto; padding: 12px 14px; min-height: 0; }
        .pip-pharma-card {
            border-radius: 8px; padding: 10px 12px; margin-bottom: 8px; font-size: 13px;
        }
        .pip-pharma-card.hard { background: #fef2f2; border: 1px solid #fca5a5; }
        .pip-pharma-card.soft { background: #fffbeb; border: 1px solid #fcd34d; }
        .pip-pharma-card .ttl { font-weight: 800; margin-bottom: 4px; }
        .pip-btn.warn-pharma.is-pass {
            background: linear-gradient(180deg, #34d399, #059669); color: #fff; border-color: #047857;
        }
        .pip-pass-modal {
            position: fixed; inset: 0; background: rgba(6, 30, 28, .55);
            display: none; align-items: center; justify-content: center; z-index: 67;
            backdrop-filter: blur(4px);
        }
        .pip-pass-box {
            width: min(560px, calc(100% - 36px)); max-height: min(82vh, 720px);
            border-radius: 20px; overflow: hidden;
            background: linear-gradient(165deg, #042f2e 0%, #0f766e 42%, #14b8a6 100%);
            box-shadow: 0 24px 64px rgba(4, 47, 46, .45), 0 0 0 1px rgba(255,255,255,.12) inset;
            display: flex; flex-direction: column; color: #ecfdf5;
            animation: pip-pass-in .38s cubic-bezier(.2,.8,.2,1);
        }
        @keyframes pip-pass-in {
            from { opacity: 0; transform: translateY(16px) scale(.96); }
            to { opacity: 1; transform: none; }
        }
        .pip-pass-hero {
            text-align: center; padding: 28px 24px 12px; position: relative;
        }
        .pip-pass-hero .x {
            position: absolute; top: 12px; right: 14px; border: 0; background: transparent;
            color: rgba(255,255,255,.75); font-size: 1.4rem; cursor: pointer; line-height: 1;
        }
        .pip-pass-hero .x:hover { color: #fff; }
        .pip-pass-check {
            width: 72px; height: 72px; margin: 0 auto 14px; border-radius: 50%;
            background: radial-gradient(circle at 30% 30%, #6ee7b7, #10b981 60%, #047857);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 10px 28px rgba(16, 185, 129, .45), 0 0 0 6px rgba(255,255,255,.12);
            animation: pip-pass-pop .45s cubic-bezier(.2,.9,.2,1) .08s both;
        }
        .pip-pass-check i { font-size: 1.85rem; color: #fff; }
        @keyframes pip-pass-pop {
            from { transform: scale(.6); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .pip-pass-hero .eyebrow {
            font-size: 11px; font-weight: 800; letter-spacing: .14em; text-transform: uppercase;
            color: rgba(236,253,245,.72); margin-bottom: 6px;
        }
        .pip-pass-hero h6 {
            margin: 0; font-size: 1.45rem; font-weight: 800; letter-spacing: -.02em; color: #fff;
        }
        .pip-pass-hero .sub {
            margin-top: 6px; font-size: 13px; color: rgba(236,253,245,.82); font-weight: 600;
        }
        .pip-pass-body {
            margin: 8px 16px 0; padding: 14px; border-radius: 14px;
            background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.14);
            overflow: auto; min-height: 0; max-height: min(42vh, 360px);
        }
        .pip-pass-grid {
            display: grid; grid-template-columns: 1fr 1fr; gap: 8px;
        }
        @media (max-width: 520px) {
            .pip-pass-grid { grid-template-columns: 1fr; }
        }
        .pip-pass-chip {
            display: flex; align-items: flex-start; gap: 8px;
            padding: 10px 10px; border-radius: 12px;
            background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.1);
            animation: pip-pass-chip .35s ease both;
        }
        .pip-pass-chip:nth-child(1) { animation-delay: .05s; }
        .pip-pass-chip:nth-child(2) { animation-delay: .1s; }
        .pip-pass-chip:nth-child(3) { animation-delay: .15s; }
        .pip-pass-chip:nth-child(4) { animation-delay: .2s; }
        .pip-pass-chip:nth-child(5) { animation-delay: .25s; }
        .pip-pass-chip:nth-child(6) { animation-delay: .3s; }
        @keyframes pip-pass-chip {
            from { opacity: 0; transform: translateY(6px); }
            to { opacity: 1; transform: none; }
        }
        .pip-pass-chip .ico {
            width: 26px; height: 26px; border-radius: 50%; flex: 0 0 auto;
            display: flex; align-items: center; justify-content: center;
            background: #34d399; color: #064e3b; font-size: 12px;
        }
        .pip-pass-chip.na .ico { background: rgba(255,255,255,.22); color: rgba(255,255,255,.75); }
        .pip-pass-chip .lbl { font-weight: 800; font-size: 12.5px; color: #fff; line-height: 1.25; }
        .pip-pass-chip .sum { font-size: 11px; color: rgba(236,253,245,.72); margin-top: 2px; }
        .pip-pass-foot {
            display: flex; justify-content: space-between; align-items: center; gap: 8px;
            padding: 14px 16px 16px;
        }
        .pip-pass-foot .pip-btn {
            border-color: rgba(255,255,255,.35); color: #042f2e; background: #fff; font-weight: 800;
        }
        .pip-pass-foot .pip-btn.ghost {
            background: transparent; color: #ecfdf5; border-color: rgba(255,255,255,.35);
        }
        .pip-pass-foot .pip-btn.primary {
            background: linear-gradient(180deg, #f0fdf4, #a7f3d0); border-color: #6ee7b7; color: #064e3b;
        }
        @media (prefers-reduced-motion: reduce) {
            .pip-pass-box, .pip-pass-check, .pip-pass-chip { animation: none; }
        }
        .pip-ap-mod-list {
            max-height: 220px; overflow: auto; border: 1px solid #c5d5dc; border-radius: 6px;
            padding: 6px 8px; background: #f8fafc;
        }
        .pip-ap-mod-list label {
            display: flex; align-items: center; gap: 8px; padding: 4px 2px;
            font-size: 12.5px; font-weight: 600; cursor: pointer;
        }
        .pip-ap-mod-list label .sp-tag {
            font-size: 10px; font-weight: 700; color: #0f766e; background: #ccfbf1;
            border-radius: 4px; padding: 1px 6px; margin-left: auto;
        }
        .pip-ap-mod-list.is-locked label { opacity: .75; cursor: default; }
        .pip-robot-modal {
            position: fixed; inset: 0; background: rgba(20, 40, 48, .5);
            display: none; align-items: center; justify-content: center; z-index: 68;
        }
        .pip-robot-box {
            width: min(920px, calc(100% - 36px)); max-height: min(80vh, 680px);
            background: #fff; border-radius: 12px; box-shadow: 0 16px 48px rgba(120, 20, 20, .28);
            display: flex; flex-direction: column; overflow: hidden; border: 2px solid #e53935;
        }
        .pip-robot-head {
            display: flex; align-items: center; justify-content: space-between;
            padding: 12px 16px; border-bottom: 1px solid #ffcdd2; background: #ffebee; flex: 0 0 auto;
        }
        .pip-robot-head h6 { margin: 0; font-weight: 800; font-size: 1.05rem; color: #b71c1c; }
        .pip-robot-body { overflow: auto; min-height: 0; }
        .pip-robot-table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
        .pip-robot-table th {
            background: #ffcdd2; color: #7f1d1d; font-weight: 800; text-align: left;
            padding: 8px; border-bottom: 1px solid #ef9a9a; white-space: nowrap;
        }
        .pip-robot-table td { padding: 8px; border-bottom: 1px solid #fce4ec; vertical-align: top; }
        .pip-settings-body .sec-title {
            font-weight: 800; color: #0b7285; margin: 14px 0 8px; padding-top: 8px;
            border-top: 1px solid #e4eef2;
        }
        .pip-settings-body .sec-title:first-child { margin-top: 0; padding-top: 0; border-top: 0; }
        .pip-settings-modal, .pip-ahead-modal {
            position: fixed; inset: 0; background: rgba(20, 40, 48, .45);
            display: none; align-items: center; justify-content: center; z-index: 70;
        }
        .pip-settings-box {
            width: min(880px, calc(100% - 36px)); max-height: min(90vh, 860px);
            background: #fff; border-radius: 12px; box-shadow: 0 16px 48px rgba(15, 40, 48, .28);
            display: flex; flex-direction: column; overflow: hidden;
        }
        .pip-lab-cfg {
            border: 1px solid #d0dde4; border-radius: 6px; overflow: auto; max-height: 280px;
            background: #fafcfd; margin-bottom: 8px;
        }
        .pip-lab-cfg table { width: 100%; border-collapse: collapse; font-size: 11.5px; }
        .pip-lab-cfg th {
            position: sticky; top: 0; background: #e8eef2; font-weight: 800; text-align: left;
            padding: 5px 6px; border-bottom: 1px solid #c5d5dc; white-space: nowrap;
        }
        .pip-lab-cfg td { padding: 4px 5px; border-bottom: 1px solid #edf1f4; vertical-align: middle; }
        .pip-lab-cfg input[type="text"],
        .pip-lab-cfg input[type="number"] {
            width: 100%; min-width: 0; border: 1px solid #b8c6ce; border-radius: 4px;
            padding: 3px 5px; font-weight: 600; font-size: 11.5px;
        }
        .pip-lab-cfg input.lab-low, .pip-lab-cfg input.lab-high { width: 64px; }
        .pip-lab-cfg .btn-x {
            border: 0; background: #ffebee; color: #c62828; font-weight: 800; border-radius: 4px;
            padding: 2px 7px; cursor: pointer; font-size: 11px;
        }
        .pip-lab-cfg .btn-x:hover { background: #ffcdd2; }
        .pip-lab-add {
            display: flex; flex-wrap: wrap; gap: 6px; align-items: center; margin-top: 6px;
        }
        .pip-lab-add input[type="text"],
        .pip-lab-add input[type="number"] {
            border: 1px solid #b8c6ce; border-radius: 6px; padding: 5px 8px; font-weight: 600; font-size: 12px;
        }
        .pip-lab-add input.lab-add-label { width: 90px; }
        .pip-lab-add input.lab-add-match { flex: 1; min-width: 140px; }
        .pip-lab-add input.lab-add-bound { width: 70px; }
        .pip-robot-tools {
            display: flex; flex-wrap: wrap; gap: 6px; align-items: center; margin: 8px 0;
        }
        .pip-robot-tools input[type="text"] {
            flex: 1; min-width: 160px; border: 1px solid #b8c6ce; border-radius: 6px;
            padding: 5px 8px; font-weight: 600; font-size: 12px;
        }
        .pip-robot-list {
            max-height: 220px; overflow: auto; border: 1px solid #d0dde4; border-radius: 6px;
            background: #fafcfd;
        }
        .pip-robot-list table { width: 100%; border-collapse: collapse; font-size: 11.5px; }
        .pip-robot-list th {
            position: sticky; top: 0; background: #e8eef2; font-weight: 800; text-align: left;
            padding: 5px 6px; border-bottom: 1px solid #c5d5dc;
        }
        .pip-robot-list td { padding: 4px 6px; border-bottom: 1px solid #edf1f4; vertical-align: top; }
        .pip-robot-list .btn-x {
            border: 0; background: #ffebee; color: #c62828; font-weight: 800; border-radius: 4px;
            padding: 2px 7px; cursor: pointer; font-size: 11px;
        }
        .pip-robot-list .btn-x:hover { background: #ffcdd2; }
        .pip-robot-search-hit {
            max-height: 140px; overflow: auto; border: 1px solid #d0dde4; border-radius: 6px;
            margin-top: 6px; background: #fff; display: none;
        }
        .pip-robot-search-hit button {
            display: block; width: 100%; text-align: left; border: 0; border-bottom: 1px solid #edf1f4;
            background: #fff; padding: 6px 8px; cursor: pointer; font-size: 11.5px;
        }
        .pip-robot-search-hit button:hover { background: #e8f7fb; }
        .pip-robot-meta { font-size: 11.5px; color: #5a7380; font-weight: 700; }
        .pip-settings-head, .pip-ahead-head {
            display: flex; align-items: center; justify-content: space-between;
            padding: 12px 16px; border-bottom: 1px solid #e4eef2; flex: 0 0 auto;
        }
        .pip-settings-head h6, .pip-ahead-head h6 { margin: 0; font-weight: 800; font-size: 1.05rem; color: #0b7285; }
        .pip-ahead-head { background: #fff8e1; border-bottom-color: #ffe082; }
        .pip-ahead-head h6 { color: #e65100; }
        .pip-settings-body { padding: 14px 16px; overflow: auto; font-size: 13px; }
        .pip-settings-body label.pip-set-check {
            display: flex; align-items: center; gap: 8px; margin-bottom: 10px; cursor: pointer;
            font-weight: 600; color: #243038; line-height: 1.35;
        }
        .pip-settings-body label.pip-set-check input[type="checkbox"] {
            flex: 0 0 auto; width: 16px; height: 16px; margin: 0;
            accent-color: #0aa2c0; vertical-align: middle;
        }
        .pip-settings-body .pip-set-radios {
            display: flex; flex-direction: column; gap: 8px; margin: 0 0 10px;
        }
        .pip-settings-body label.pip-set-radio {
            display: flex; align-items: flex-start; gap: 8px; cursor: pointer;
            font-weight: 600; color: #243038; line-height: 1.35;
        }
        .pip-settings-body label.pip-set-radio input[type="radio"] {
            flex: 0 0 auto; width: 16px; height: 16px; margin: 2px 0 0;
            accent-color: #0aa2c0;
        }
        .pip-settings-body label.pip-set-radio .rd-main { font-weight: 700; }
        .pip-settings-body label.pip-set-radio .rd-sub {
            display: block; font-size: 11.5px; font-weight: 500; color: #5a7380; margin-top: 1px;
        }
        .pip-settings-body .hint { color: #5a7380; font-size: 11.5px; font-weight: 500; margin: -4px 0 12px 24px; }
        .pip-settings-body .field { margin-bottom: 12px; }
        .pip-settings-body .field > span { display: block; font-weight: 700; margin-bottom: 4px; }
        .pip-settings-body input[type="number"] {
            width: 80px; border: 1px solid #b8c6ce; border-radius: 6px; padding: 5px 8px; font-weight: 700;
        }
        .pip-ahead-box {
            width: min(920px, calc(100% - 36px)); max-height: min(80vh, 680px);
            background: #fff; border-radius: 12px; box-shadow: 0 16px 48px rgba(120, 80, 0, .28);
            display: flex; flex-direction: column; overflow: hidden; border: 2px solid #ffb300;
        }
        .pip-ahead-body { overflow: auto; min-height: 0; }
        .pip-ahead-table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
        .pip-ahead-table th {
            background: #fff3cd; color: #7a4e00; font-weight: 800; text-align: left;
            padding: 8px; border-bottom: 1px solid #ffe082; white-space: nowrap;
        }
        .pip-ahead-table td { padding: 8px; border-bottom: 1px solid #f3eee0; vertical-align: top; }
        .pip-ahead-table .exp { color: #0f766e; font-weight: 800; }
        .pip-ahead-table .act-miss { color: #c62828; font-weight: 800; }
        .pip-ahead-table .act-bad { color: #e65100; font-weight: 800; }
        .pip-btn.must-paid {
            background: linear-gradient(180deg, #ffcc80, #fb8c00); color: #fff; border-color: #ef6c00;
        }
        .pip-btn.must-paid .n {
            display: inline-block; min-width: 16px; padding: 0 4px; margin-left: 2px;
            border-radius: 8px; background: rgba(255,255,255,.28); font-size: 10px; text-align: center;
        }
        .pip-must-modal {
            position: fixed; inset: 0; background: rgba(20, 40, 48, .5);
            display: none; align-items: center; justify-content: center; z-index: 66;
        }
        .pip-must-box {
            width: min(900px, calc(100% - 36px)); max-height: min(80vh, 680px);
            background: #fff; border-radius: 10px; box-shadow: 0 16px 48px rgba(120, 60, 0, .28);
            display: flex; flex-direction: column; overflow: hidden; border: 2px solid #ef6c00;
        }
        .pip-must-head {
            background: #ef6c00; color: #fff; font-weight: 800; font-size: 1.05rem;
            padding: 10px 14px; display: flex; align-items: center; justify-content: space-between;
        }
        .pip-must-head .x {
            border: 0; background: transparent; color: #fff; font-size: 1.35rem;
            line-height: 1; cursor: pointer; padding: 0 4px;
        }
        .pip-must-body { overflow: auto; min-height: 0; }
        .pip-must-table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
        .pip-must-table th {
            background: #fff3e0; color: #e65100; font-weight: 800; text-align: left;
            padding: 8px; border-bottom: 1px solid #ffe0b2; white-space: nowrap;
        }
        .pip-must-table td { padding: 8px; border-bottom: 1px solid #f5ebe0; vertical-align: top; }
        .pip-must-table .name { font-weight: 800; color: #bf360c; }
        .pip-toast {
            position: fixed; right: 16px; bottom: 16px; z-index: 50;
            background: #17323d; color: #fff; padding: 10px 14px; border-radius: 8px;
            font-weight: 700; font-size: 12.5px; box-shadow: 0 6px 20px rgba(0,0,0,.2);
            display: none; max-width: 360px;
        }
        .pip-toast.ok { background: #0f766e; }
        .pip-toast.err { background: #b91c1c; }
        .pip-table td.dispense-ok { color: #0f766e; font-weight: 800; }
        .pip-table td.dispense-default { color: #0aa2c0; font-weight: 700; }
        .pip-table td.dispense-empty { color: #adb5bd; }
        .pip-order-table td.dispense-ok.col-person,
        .pip-order-table td.dispense-default.col-person { font-weight: 700; }
        .pip-admit-list { max-height: 100%; overflow: auto; }
        .pip-admit-list button {
            display: block; width: 100%; text-align: left; border: 0; border-bottom: 1px solid #e4eef2;
            background: #fff; padding: 8px 10px; cursor: pointer;
        }
        .pip-admit-list button:hover { background: #f3fafc; }
        .pip-admit-list button.active { background: #d9f0f6; }
        .pip-admit-list .an { font-weight: 800; color: #0b7285; }
        .pip-admit-list .meta { color: #5a7380; font-size: 11.5px; }
        @media (max-width: 1100px) {
            .pip-chrome-right, .pip-status { display: none; }
        }
        @media (max-width: 820px) {
            .pip-stage { flex-direction: column; }
            .pip-v-split { display: none; }
            .pip-left { width: 100% !important; max-width: none; flex: 0 0 45%; border-right: 0; border-bottom: 1px solid #b8c6ce; }
        }
    </style>
</head>
<body>
<div class="pip-shell">
    <div class="pip-chrome">
        <a class="pip-back" href="home.php" title="กลับหน้าหลัก"><i class="fas fa-arrow-left"></i></a>
        <div class="pip-brand">Patient IPD</div>
        <form id="pipForm" class="pip-search">
            <label class="pip-field" for="pipHn">
                <span>HN</span>
                <input type="text" id="pipHn" value="<?php echo $prefill_hn; ?>" placeholder="เลข HN" autocomplete="off">
            </label>
            <label class="pip-field" for="pipAn">
                <span>AN</span>
                <input type="text" id="pipAn" value="<?php echo $prefill_an; ?>" placeholder="เต็ม / 5 ตัวท้าย" autocomplete="off" title="ใส่ AN เต็ม หรือแค่ 5 ตัวท้ายแบบ HOSxP">
            </label>
            <button type="submit"><i class="fas fa-search me-1"></i>ค้นหา</button>
        </form>
        <nav class="pip-emr-links" aria-label="Patient EMR">
            <?php if ($can_patient_opd) { ?>
            <a class="pip-emr-link pip-companion" id="linkPatientOpd" href="patient_opd.php<?php echo $emr_hn_qs; ?>" data-companion="med_hist" title="เปิดในหน้าต่างใหม่"><i class="fas fa-user-injured"></i> Patient OPD</a>
            <?php } ?>
            <button type="button" class="pip-emr-link is-dv" id="linkDrugViewer" title="เปิด Drug Viewer บนจอ 2 (แนวตั้ง · หมุนอัตโนมัติ)"><i class="fas fa-file-medical"></i> Drug Viewer</button>
            <?php if ($can_smart_drug) { ?>
            <a class="pip-emr-link pip-companion" id="linkSmartDrug" href="smart_drug.php<?php echo $emr_hn_qs; ?>" data-companion="smart_drug" title="เปิดในหน้าต่างใหม่"><i class="fas fa-pills"></i> Smart Drug</a>
            <?php } ?>
            <?php if ($can_smart_lab) { ?>
            <a class="pip-emr-link pip-companion" id="linkSmartLab" href="smart_lab.php<?php echo $emr_hn_qs; ?>" data-companion="smart_lab" title="เปิดในหน้าต่างใหม่"><i class="fas fa-vials"></i> Smart Lab</a>
            <?php } ?>
        </nav>
        <div class="pip-status" id="pipStatus"></div>
        <div class="pip-tools">
            <button type="button" class="pip-btn must-paid" id="btnMustPaidAlert" title="ยาที่ต้องชำระเงิน (ใช้สิทธิไม่ได้)" disabled>
                ต้องชำระเงิน <span class="n" id="mustPaidCnt">0</span>
            </button>
            <button type="button" class="pip-btn warn-pharma" id="btnAlertPharma" title="Alert Pharma — คัดกรองตาม HN" disabled>
                Alert Pharma <span class="n" id="alertPharmaCnt">0</span>
            </button>
            <button type="button" class="pip-btn warn-ahead" id="btnDayAheadAlert" title="แจ้งเตือนตั้งจ่ายตามวัน" disabled>
                ตั้งจ่ายตามวัน <span class="n" id="dayAheadCnt">0</span>
            </button>
            <button type="button" class="pip-btn warn-robot" id="btnRobotAlert" title="TAB/CAP ที่ไม่มีต่อครั้ง/ต่อวัน — จะไม่เข้า Robot" disabled>
                ไม่เข้า Robot <span class="n" id="robotMissCnt">0</span>
            </button>
            <button type="button" class="pip-btn" id="btnPipSettings" title="ตั้งค่า Patient IPD">
                <i class="fas fa-cog"></i> ตั้งค่า
            </button>
        </div>
        <div class="pip-chrome-right"><i class="fas fa-user-circle me-1"></i><?php echo $user_name; ?></div>
    </div>

    <div class="pip-ptbar" id="pipPtBar" style="display:none;"></div>

    <div class="pip-stage" id="pipPlaceholder">
        <div class="pip-empty">
            <i class="fas fa-procedures fa-3x"></i>
            <div id="pipEmptyMsg">กรอก HN หรือ AN (ใส่แค่ 5 ตัวท้ายได้) แล้วกดค้นหา เพื่อดู Medication Profile ผู้ป่วยใน (คล้าย PharMS)</div>
        </div>
    </div>

    <div class="pip-stage" id="pipMain" style="display:none;">
        <div class="pip-left" id="pipLeft">
            <div class="pip-tabs" id="leftTabs">
                <button type="button" class="pip-tab active" data-pane="main">หน้าหลัก</button>
                <button type="button" class="pip-tab" data-pane="admit">ข้อมูลทั่วไป</button>
                <button type="button" class="pip-tab" data-pane="mr">MR</button>
            </div>
            <div class="pip-pane active" id="pane-main">
                <div class="pip-split">
                    <div class="pip-orders">
                        <div class="pip-sec" style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
                            <span>รายการ Order</span>
                            <div class="pip-sec-toggles">
                                <label class="pip-item-filter" title="ติ๊ก = แสดงเฉพาะยาในทุกรายการ Order (ซ่อน Non-drug)">
                                    <input type="checkbox" id="chkOrderDrugOnly"> เฉพาะยา
                                </label>
                                <label class="pip-switch" id="lblOpenDvOnIrx" title="เปิด = คลิก Order ประเภท IRx / HME แล้วเปิด Drug Viewer อัตโนมัติ (จำตาม user · ค่าเริ่มต้นเปิด)">
                                    <input type="checkbox" id="chkOpenDvOnIrx">
                                    <span class="pip-switch-track"><span class="pip-switch-knob"></span></span>
                                    <span class="pip-switch-txt">เปิด Drug Viewer อัตโนมัติ</span>
                                </label>
                            </div>
                        </div>
                        <div class="pip-order-toolbar">
                            <div class="pip-order-mode" id="orderModeTabs" role="tablist" aria-label="โหมด Order">
                                <button type="button" class="active" data-mode="all">All <span class="n" id="orderCntAll">0</span></button>
                                <button type="button" data-mode="hme">HME <span class="n" id="orderCntHme">0</span></button>
                            </div>
                            <div class="pip-order-checks" id="orderTypeChecks" title="ติ๊กเลือกประเภท Order ที่ต้องการดู"></div>
                            <div class="pip-order-meta" id="orderFilterMeta"></div>
                        </div>
                        <div class="pip-table-wrap">
                            <table class="pip-table pip-order-table" id="pipOrderTable">
                                <colgroup id="pipOrderCols">
                                    <col data-col="type">
                                    <col data-col="date">
                                    <col data-col="dispense">
                                    <col data-col="dtime">
                                    <col data-col="ward">
                                    <col data-col="key">
                                    <col data-col="ono">
                                    <col data-col="rxnote">
                                </colgroup>
                                <thead>
                                    <tr>
                                        <th data-col="type" title="ลากขอบขวาเพื่อปรับความกว้าง">Type<span class="col-resize-handle"></span></th>
                                        <th data-col="date" title="ลากขอบขวาเพื่อปรับความกว้าง">วันที่<span class="col-resize-handle"></span></th>
                                        <th data-col="dispense" class="col-person" title="ลากขอบขวาเพื่อปรับความกว้าง">ผู้จ่าย<span class="col-resize-handle"></span></th>
                                        <th data-col="dtime" title="ลากขอบขวาเพื่อปรับความกว้าง">เวลาจ่าย<span class="col-resize-handle"></span></th>
                                        <th data-col="ward" title="ลากขอบขวาเพื่อปรับความกว้าง">Ward<span class="col-resize-handle"></span></th>
                                        <th data-col="key" class="col-person" title="ลากขอบขวาเพื่อปรับความกว้าง">ผู้ Key<span class="col-resize-handle"></span></th>
                                        <th data-col="ono" title="ลากขอบขวาเพื่อปรับความกว้าง">Order_no<span class="col-resize-handle"></span></th>
                                        <th data-col="rxnote" class="rx-note-th" title="บันทึกข้อความต่อใบ Order — ลากขอบขวาเพื่อปรับความกว้าง">Rx note<span class="col-resize-handle"></span></th>
                                    </tr>
                                </thead>
                                <tbody id="pipOrderBody"></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="pip-items">
                        <div class="pip-sec" style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
                            <span>รายการใน Order ที่เลือก</span>
                            <label class="pip-item-filter" id="lblOrderUsageCode" title="เปิด = วิธีใช้แบบ code จาก HOSxP · ปิด = วิธีใช้แบบเต็ม (ค่าเริ่มต้น)">
                                <input type="checkbox" id="chkOrderUsageCode"> วิธีใช้แบบ code
                            </label>
                        </div>
                        <div class="pip-table-wrap">
                            <table class="pip-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>รายการ</th>
                                        <th>วิธีใช้</th>
                                        <th>Qty</th>
                                        <th>ราคา</th>
                                        <th>รหัส</th>
                                    </tr>
                                </thead>
                                <tbody id="pipItemBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pip-pane" id="pane-admit">
                <div class="pip-sec">ประวัติ Admit</div>
                <div class="pip-admit-list" id="pipAdmitList"></div>
            </div>
            <div class="pip-pane" id="pane-mr">
                <div class="pip-sec">Allergy / บันทึก</div>
                <div class="pip-table-wrap" style="padding:10px;" id="pipMrBox"></div>
            </div>
            <div class="pip-foot" id="pipLeftFoot">
                <?php if ($can_med_error) { ?>
                <a class="pip-btn pip-companion" id="btnConsult" href="med_error.php" data-companion="consult" title="เปิด Consult ในหน้าต่างใหม่ (คู่กับ Patient IPD)"><i class="fas fa-comments"></i> Consult</a>
                <?php } else { ?>
                <button type="button" class="pip-btn is-disabled" disabled>Consult</button>
                <?php } ?>
                <a class="pip-btn pip-companion" id="btnCalc" href="dose_calculator.php" data-companion="calc" title="เปิดเครื่องคำนวณในหน้าต่างใหม่"><i class="fas fa-calculator"></i> คำนวณ</a>
                <?php if ($can_mg_ml) { ?>
                <a class="pip-btn pip-companion" id="btnMgMl" href="mg_ml_calculator.php<?php echo $emr_hn_qs; ?>" data-companion="mg_ml" title="เปิด mg to mL ในหน้าต่างใหม่"><i class="fas fa-flask"></i> mg to mL</a>
                <?php } ?>
                <?php if ($can_warfarin) { ?>
                <a class="pip-btn pip-companion" id="btnWarfarin" href="warfarin_calculator.php<?php echo $emr_hn_qs; ?>" data-companion="warfarin" title="เปิด Warfarin ในหน้าต่างใหม่"><i class="fas fa-tint"></i> Warfarin</a>
                <?php } ?>
                <?php if ($can_peds_dose) { ?>
                <a class="pip-btn pip-companion" id="btnPedsDose" href="pediatric_dose_calculator.php<?php echo $emr_hn_qs; ?>" data-companion="peds_dose" title="เปิดคำนวณยาเด็กในหน้าต่างใหม่"><i class="fas fa-child"></i> ยาเด็ก</a>
                <?php } ?>
                <?php if ($can_smart_lab) { ?>
                <a class="pip-btn pip-companion" id="btnDrugLab" href="smart_lab.php<?php echo $emr_hn_qs; ?>" data-companion="smart_lab" title="เปิด Smart Lab ในหน้าต่างใหม่">Smart Lab</a>
                <?php } ?>
                <?php if ($can_smart_drug) { ?>
                <a class="pip-btn pip-companion" id="btnLabSmart" href="smart_drug.php<?php echo $emr_hn_qs; ?>" data-companion="smart_drug" title="เปิด Smart Drug ในหน้าต่างใหม่">Smart Drug</a>
                <?php } ?>
                <?php if ($can_patient_opd) { ?>
                <a class="pip-btn pip-companion" id="btnMedHist" href="patient_opd.php<?php echo $emr_hn_qs; ?>" data-companion="med_hist" title="เปิด Patient OPD ในหน้าต่างใหม่">Patient OPD</a>
                <?php } ?>
                <?php if ($can_drug_refer) { ?>
                <a class="pip-btn pip-companion" id="btnDrugRefer" href="drug_refer.php<?php echo $emr_hn_qs; ?>" data-companion="drug_refer" title="เปิด Refer ยาผู้ป่วยในหน้าต่างใหม่"><i class="fas fa-exchange-alt"></i> Drug Refer</a>
                <?php } ?>
                <button type="button" class="pip-btn" id="btnDrugViewer" title="เปิด Drug Viewer บนจอ 2 (แนวตั้ง · หมุนอัตโนมัติ)"><i class="fas fa-file-medical"></i> Drug Viewer</button>
                <button type="button" class="pip-btn note-hosxp" id="btnHosxpNotes" title="Note จากระบบ HOSxP">
                    Note_Hosxp <span class="n" id="noteHosxpCnt">0</span>
                </button>
                <button type="button" class="pip-btn primary" id="btnDispenseSave" title="บันทึกผู้จ่ายของ Order ที่เลือก (F9)">บันทึกจ่าย [F9]</button>
                <button type="button" class="pip-btn danger" id="btnDispenseCancel" title="ยกเลิกผู้จ่ายของ Order ที่เลือก">ยกเลิกจ่าย</button>
            </div>
        </div>

        <div class="pip-v-split" id="pipVSplit" title="ลากเพื่อปรับความกว้าง zone ซ้าย/ขวา" role="separator" aria-orientation="vertical"></div>

        <div class="pip-right" id="pipRight">
            <div class="pip-tabs" id="rightTabs">
                <button type="button" class="pip-tab active" data-med="active">รายการยา Continuous (Active)</button>
                <button type="button" class="pip-tab" data-med="off">รายการยา OFF Continuous</button>
                <button type="button" class="pip-tab" data-med="all">รายการยา Continuous ทั้งหมด</button>
                <button type="button" class="pip-tab" data-med="oneday">รายการยา Oneday ทั้งหมด</button>
                <button type="button" class="pip-tab" data-med="profile">Profile</button>
            </div>
            <div class="pip-pane active" id="medPane">
                <div class="pip-sec" style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
                    <span id="medSecTitle">รายการยา Continuous (Active)</span>
                    <label class="pip-item-filter" id="lblUsageCode" title="เปิด = แสดงวิธีใช้แบบ code จาก HOSxP (เช่น 11ht) · ปิด = วิธีใช้แบบเต็ม (ค่าเริ่มต้น)">
                        <input type="checkbox" id="chkUsageCode"> วิธีใช้แบบ code
                    </label>
                </div>
                <div class="pip-table-wrap">
                    <table class="pip-table pip-med-table" id="medTable">
                        <colgroup id="pipMedCols"></colgroup>
                        <thead id="pipMedHead"></thead>
                        <tbody id="pipMedBody"></tbody>
                    </table>
                </div>
            </div>
            <div class="pip-foot">
                <button type="button" class="pip-btn is-disabled" disabled>ส่งคืน Ward</button>
                <button type="button" class="pip-btn" id="btnProfileTab">Drug Profile</button>
                <?php if ($can_smart_drug) { ?>
                <a class="pip-btn pip-companion" id="btnReport" href="smart_drug.php<?php echo $emr_hn_qs; ?>" data-companion="smart_drug" title="เปิด Smart Drug ในหน้าต่างใหม่">รายงาน</a>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<div class="pip-allergy-modal" id="pipAllergyAlert">
    <div class="pip-allergy-box">
        <div class="pip-allergy-head">
            <span>Alert Drug Allergy</span>
            <button type="button" class="x" id="pipAllergyAlertX" aria-label="ปิด">&times;</button>
        </div>
        <div class="pip-allergy-body" id="pipAllergyAlertBody"></div>
        <div class="pip-foot" style="justify-content:flex-end;background:#fff;border-top:1px solid #ffcdd2;">
            <button type="button" class="pip-btn danger" id="pipAllergyAlertClose">ปิด</button>
        </div>
    </div>
</div>
<div class="pip-note-modal" id="pipHosxpNotes">
    <div class="pip-note-box">
        <div class="pip-note-head">
            <h6>NOTE จาก HOSxp</h6>
            <button type="button" class="pip-note-x" id="pipHosxpNotesX" aria-label="ปิด">&times;</button>
        </div>
        <div class="pip-note-body" id="pipHosxpNotesBody"></div>
        <div class="pip-foot" style="justify-content:flex-end;background:#fff;border-top:1px solid #eef2f4;">
            <button type="button" class="pip-btn" id="pipHosxpNotesClose">CLOSE</button>
        </div>
    </div>
</div>
<div class="pip-dv-modal" id="pipDrugViewer" aria-hidden="true">
    <div class="pip-dv-box">
        <div class="pip-dv-head">
            <div>
                <h6><i class="fas fa-file-medical me-1"></i>Drug Viewer — ใบยาสแกน</h6>
                <div class="meta" id="pipDvMeta">—</div>
            </div>
            <button type="button" class="pip-dv-x" id="pipDrugViewerX" aria-label="ปิด">&times;</button>
        </div>
        <div class="pip-dv-body">
            <div class="pip-dv-list">
                <div class="pip-dv-list-tools">
                    <select id="pipDvTypeFilter" title="กรองประเภท">
                        <option value="">ทุกประเภท</option>
                        <option value="1">ยาเร่งด่วน</option>
                        <option value="2">ยาปกติ</option>
                        <option value="3">ยากลับบ้าน</option>
                    </select>
                    <span class="small text-muted" id="pipDvCount">0 รายการ</span>
                </div>
                <div class="pip-dv-list-body" id="pipDvList"><div class="pip-dv-empty">กำลังโหลด…</div></div>
            </div>
            <div class="pip-dv-view" id="pipDvView">
                <div class="pip-dv-view-bar">
                    <span id="pipDvViewTitle">เลือกใบสแกนทางซ้าย</span>
                    <span>
                        <a href="#" id="pipDvOpenTab" target="_blank" rel="noopener" style="display:none;">เปิดแท็บใหม่</a>
                        <button type="button" id="pipDvCloseBtn">ปิด</button>
                    </span>
                </div>
                <div class="pip-dv-empty" id="pipDvViewEmpty">เลือกใบยาสแกนจากรายการทางซ้ายเพื่อดูไฟล์ PDF</div>
                <iframe class="pip-dv-frame" id="pipDvFrame" title="Drug Viewer scan" style="display:none;"></iframe>
            </div>
        </div>
    </div>
</div>
<div class="pip-must-modal" id="pipMustPaidAlert">
    <div class="pip-must-box">
        <div class="pip-must-head">
            <span><i class="fas fa-coins me-1"></i>Alert: รายการที่ต้องชำระเงิน (ใช้สิทธิไม่ได้)</span>
            <button type="button" class="x" id="pipMustPaidAlertX" aria-label="ปิด">&times;</button>
        </div>
        <div style="padding:8px 12px;font-size:12.5px;color:#6d4c41;background:#fff8e1;">
            พบยาที่ติ๊กใน HOSxP ว่า <b>รายการที่ต้องชำระเงิน (ใช้สิทธิไม่ได้)</b> — โปรดแจ้งผู้ป่วย/ตรวจสอบก่อนจ่าย
        </div>
        <div class="pip-must-body" id="pipMustPaidAlertBody"></div>
        <div class="pip-foot" style="justify-content:flex-end;background:#fff;border-top:1px solid #ffe0b2;">
            <button type="button" class="pip-btn primary" id="pipMustPaidAlertClose">รับทราบ</button>
        </div>
    </div>
</div>
<div class="pip-pharma-modal" id="pipAlertPharma">
    <div class="pip-pharma-box">
        <div class="pip-pharma-head">
            <h6><i class="fas fa-user-shield me-1"></i>แจ้งเตือน: Alert Pharma</h6>
            <button type="button" class="pip-note-x" id="pipAlertPharmaX" aria-label="ปิด">&times;</button>
        </div>
        <div class="pip-pharma-body" id="pipAlertPharmaBody"></div>
        <div class="pip-foot" style="justify-content:space-between;background:#ecfdf5;border-top:1px solid #99f6e4;">
            <div style="display:flex;gap:6px;">
                <button type="button" class="pip-btn" id="pipAlertPharmaOpenSettings"><i class="fas fa-cog"></i> ตั้งค่า</button>
                <a class="pip-btn" id="pipAlertPharmaOpenSp" href="smart_pharma_interventions.php" target="_blank" rel="noopener">
                    <i class="fas fa-notes-medical"></i> Intervention
                </a>
            </div>
            <button type="button" class="pip-btn primary" id="pipAlertPharmaClose">รับทราบ</button>
        </div>
    </div>
</div>
<div class="pip-pass-modal" id="pipAlertPharmaPass">
    <div class="pip-pass-box">
        <div class="pip-pass-hero">
            <button type="button" class="x" id="pipAlertPharmaPassX" aria-label="ปิด">&times;</button>
            <div class="pip-pass-check"><i class="fas fa-check"></i></div>
            <div class="eyebrow">Smart Pharma</div>
            <h6>Smart Pharma Pass</h6>
            <div class="sub" id="pipAlertPharmaPassSub">คัดกรองผ่าน — ไม่พบ Alert</div>
        </div>
        <div class="pip-pass-body" id="pipAlertPharmaPassBody"></div>
        <div class="pip-pass-foot">
            <button type="button" class="pip-btn ghost" id="pipAlertPharmaPassSettings"><i class="fas fa-cog"></i> ตั้งค่า</button>
            <button type="button" class="pip-btn primary" id="pipAlertPharmaPassClose">รับทราบ</button>
        </div>
    </div>
</div>
<div class="pip-ahead-modal" id="pipDayAheadAlert">
    <div class="pip-ahead-box">
        <div class="pip-ahead-head">
            <h6><i class="fas fa-exclamation-triangle me-1"></i>แจ้งเตือน: ตั้งจ่ายตามวัน</h6>
            <button type="button" class="pip-note-x" id="pipDayAheadAlertX" aria-label="ปิด">&times;</button>
        </div>
        <div class="pip-ahead-body" id="pipDayAheadAlertBody"></div>
        <div class="pip-foot" style="justify-content:space-between;background:#fffaf0;border-top:1px solid #ffe082;">
            <button type="button" class="pip-btn" id="pipDayAheadOpenSettings"><i class="fas fa-cog"></i> ตั้งค่า</button>
            <button type="button" class="pip-btn primary" id="pipDayAheadAlertClose">รับทราบ</button>
        </div>
    </div>
</div>
<div class="pip-robot-modal" id="pipRobotAlert">
    <div class="pip-robot-box">
        <div class="pip-robot-head">
            <h6><i class="fas fa-robot me-1"></i>แจ้งเตือน: จะไม่เข้า Robot</h6>
            <button type="button" class="pip-note-x" id="pipRobotAlertX" aria-label="ปิด">&times;</button>
        </div>
        <div class="pip-robot-body" id="pipRobotAlertBody"></div>
        <div class="pip-foot" style="justify-content:space-between;background:#fff5f5;border-top:1px solid #ffcdd2;">
            <button type="button" class="pip-btn" id="pipRobotOpenSettings"><i class="fas fa-cog"></i> ตั้งค่า</button>
            <button type="button" class="pip-btn primary" id="pipRobotAlertClose">รับทราบ</button>
        </div>
    </div>
</div>
<div class="pip-settings-modal" id="pipSettingsModal">
    <div class="pip-settings-box">
        <div class="pip-settings-head">
            <h6><i class="fas fa-cog me-1"></i>ตั้งค่า Patient IPD</h6>
            <button type="button" class="pip-note-x" id="pipSettingsX" aria-label="ปิด">&times;</button>
        </div>
        <div class="pip-settings-body">
            <div class="sec-title">เด้ง Popup อัตโนมัติเมื่อพบรายการ</div>
            <label class="pip-set-check"><input type="checkbox" id="setPopupMustPaid"> ต้องชำระเงิน</label>
            <label class="pip-set-check"><input type="checkbox" id="setPopupHosxpNote"> Note_HOSxP</label>
            <label class="pip-set-check"><input type="checkbox" id="setAheadAutoPopup"> ตั้งจ่ายตามวัน</label>
            <label class="pip-set-check"><input type="checkbox" id="setPopupRobot"> ไม่เข้า Robot (TAB/CAP ไม่มีต่อครั้ง/ต่อวัน)</label>
            <div class="hint">ปิดรายการใด = ยังแสดงปุ่มนับจำนวนด้านบน แต่ไม่เด้ง Popup อัตโนมัติ · Alert Pharma ตั้งด้านล่างแยก</div>

            <div class="sec-title">Drug Viewer <span style="font-weight:600;color:#64748b;font-size:11px;">(จำตาม user · ไม่ผูกเครื่อง)</span></div>
            <label class="pip-set-check"><input type="checkbox" id="setOpenDvOnIrx"> คลิก Order ประเภท IRx / HME แล้วเปิด Drug Viewer เสมอ</label>
            <div class="hint">เปิด = เมื่อเลือกแถว Type IRx หรือ HME จะเปิดหน้าต่าง Drug Viewer (จอ 2) อัตโนมัติ · ปิดได้จากสวิตช์ «เปิด Drug Viewer อัตโนมัติ» ข้าง เฉพาะยา ด้วย · ค่าเริ่มต้นเปิด · จำตาม user แต่ละคน</div>

            <div class="sec-title">Alert Pharma (คัดกรองตาม HN)</div>
            <label class="pip-set-check"><input type="checkbox" id="setAlertPharmaEnabled"> เปิดคัดกรอง Alert Pharma ทุกครั้งที่เลือก HN</label>
            <div class="hint">ใช้ตรรกะเดียวกับเมนู คัดกรองตาม HN (Smart Pharma) · ประเภท IPD</div>
            <div class="field">
                <span>เด้ง Popup หลังคัดกรอง</span>
                <div class="pip-set-radios">
                    <label class="pip-set-radio">
                        <input type="radio" name="setAlertPharmaPopupMode" value="alert_only">
                        <span>
                            <span class="rd-main">เฉพาะเมื่อไม่ผ่าน (มี Alert)</span>
                            <span class="rd-sub">แนะนำ — แสดงเฉพาะโมดูลที่ไม่ผ่าน · ผ่านทุกโมดูลไม่เด้ง</span>
                        </span>
                    </label>
                    <label class="pip-set-radio">
                        <input type="radio" name="setAlertPharmaPopupMode" value="always">
                        <span>
                            <span class="rd-main">ทุกครั้ง (ผ่าน และ ไม่ผ่าน)</span>
                            <span class="rd-sub">ผ่านทุกโมดูล = เด้ง Smart Pharma Pass · ไม่ผ่าน = เด้งรายการ Alert</span>
                        </span>
                    </label>
                    <label class="pip-set-radio">
                        <input type="radio" name="setAlertPharmaPopupMode" value="off">
                        <span>
                            <span class="rd-main">ไม่เด้งอัตโนมัติ</span>
                            <span class="rd-sub">ยังคัดกรองและกดปุ่ม Alert Pharma ดูผลได้</span>
                        </span>
                    </label>
                </div>
            </div>
            <label class="pip-set-check"><input type="checkbox" id="setAlertPharmaUseDefault"> ใช้โมดูลตาม Smart Pharma Settings (ค่าเริ่มต้น)</label>
            <div class="hint">เปิด = ตามโมดูลที่เปิดใน smart_pharma_settings (IPD) · ปิด = เลือกเพิ่ม/ลดโมดูลแจ้งเตือนด้านล่างเอง</div>
            <div class="field">
                <span>โมดูลที่ใช้แจ้งเตือน</span>
                <div class="pip-ap-mod-list" id="alertPharmaModList"></div>
                <div style="margin-top:6px;">
                    <button type="button" class="pip-btn" id="btnAlertPharmaResetMods" title="รีเซ็ตรายการตาม Smart Pharma Settings">
                        <i class="fas fa-undo"></i> รีเซ็ตตาม Smart Pharma
                    </button>
                </div>
            </div>

            <div class="sec-title">ตั้งจ่ายตามวัน</div>
            <label class="pip-set-check"><input type="checkbox" id="setAheadEnabled"> เปิดระบบดักจับอัตโนมัติ</label>
            <div class="hint">ตรวจยาที่สั่งใช้ตามวัน (เช่น จันทร์ถึงศุกร์ / จันทร์,พุธ / ทุกวันพุธ) แล้วเทียบกับคอลัมน์ จ่ายวัน — ค่าเริ่มต้นตั้งจ่ายล่วงหน้า</div>
            <div class="field">
                <span>ออกยาก่อนล่วงหน้า (วัน)</span>
                <input type="number" id="setAheadLead" min="1" max="6" value="1">
                <div class="hint" style="margin-left:0;">เช่น จันทร์ถึงศุกร์ + ล่วงหน้า 1 วัน → จ่ายวัน = อาทิตย์,จันทร์,อังคาร,พุธ,พฤหัส · จันทร์,พุธ → อาทิตย์,อังคาร</div>
            </div>
            <label class="pip-set-check"><input type="checkbox" id="setAheadParseUsage"> อ่านวันให้ยาจากวิธีใช้</label>
            <div class="hint">จับคำว่า เฉพาะวัน / ทุกวัน / วัน… ในวิธีใช้ (ต้องเข้าเงื่อนไขนี้ก่อน แล้วค่อยดูข้อยกเว้นด้านล่าง)</div>
            <label class="pip-set-check"><input type="checkbox" id="setAheadMissing"> แจ้งเตือนเมื่อยังไม่ได้ตั้ง จ่ายวัน</label>
            <label class="pip-set-check"><input type="checkbox" id="setAheadMismatch"> แจ้งเตือนเมื่อ จ่ายวัน ไม่ตรงกับที่ควรตั้ง</label>
            <label class="pip-set-check"><input type="checkbox" id="setAheadOnlyActive"> ตรวจเฉพาะ Continuous (Active)</label>

            <div class="sec-title" style="border-top:0;margin-top:8px;">ข้อยกเว้น — ตั้งจ่ายตรงวัน (ไม่เลื่อนล่วงหน้า)</div>
            <label class="pip-set-check"><input type="checkbox" id="setExactDayEnabled"> เปิดข้อยกเว้นตั้งจ่ายตรงวัน</label>
            <div class="hint">ใช้เมื่อเข้าเงื่อนไขยาสั่งตามวันแล้ว และตรงรายการยาหรือมีคำในวิธีใช้ด้านล่าง — เช่น Warfarin กินทุกวันจันทร์ถึงศุกร์ ก่อนนอน → จ่ายวัน = จันทร์ถึงศุกร์</div>
            <div class="field">
                <span>คำในวิธีใช้ (คั่นด้วยจุลภาคหรือขึ้นบรรทัดใหม่)</span>
                <textarea id="setExactDayKeywords" rows="2" style="width:100%;border:1px solid #b8c6ce;border-radius:6px;padding:6px 8px;font-weight:600;font-size:12px;" placeholder="เช่น ก่อนนอน"></textarea>
            </div>
            <div class="field">
                <span>รายการยาที่ตั้งจ่ายตรงวัน (จาก HOSxP)</span>
                <div class="pip-robot-meta">รายการ: <b id="exactDayDrugCount">0</b> รายการ</div>
                <div class="pip-robot-tools">
                    <input type="text" id="exactDayDrugFilter" placeholder="กรองรายการที่ตั้งไว้ (รหัส/ชื่อ)...">
                </div>
                <div class="pip-robot-list" id="exactDayDrugList">
                    <div class="muted" style="padding:10px;text-align:center;">ยังไม่มีรายการ</div>
                </div>
                <div class="pip-robot-tools" style="margin-top:8px;">
                    <input type="text" id="exactDayDrugAddQ" placeholder="ค้นหาเพิ่มยาจาก HOSxP (รหัส/ชื่อ)...">
                    <button type="button" class="pip-btn primary" id="btnExactDaySearchAdd"><i class="fas fa-search"></i> ค้นหา</button>
                </div>
                <div class="pip-robot-search-hit" id="exactDayDrugSearchHit"></div>
                <div class="hint" style="margin-left:0;">จับตามรหัส icode เป็นหลัก หรือชื่อยา — เพิ่มจาก HOSxP แล้วกดบันทึก</div>
            </div>

            <div class="sec-title">ไม่เข้า Robot</div>
            <label class="pip-set-check"><input type="checkbox" id="setRobotEnabled"> เปิดระบบดักจับยาใน Robot ที่ไม่มีต่อครั้ง/ต่อวัน</label>
            <div class="hint">แจ้งเตือนเฉพาะรายการที่ตั้งไว้ด้านล่าง — ยาต้องมีค่า ต่อครั้ง และ ต่อวัน จากวิธีใช้ HOSxP · ไม่แจ้งเมื่อ qty = 0</div>
            <div class="pip-robot-meta">รายการยาใน Robot: <b id="robotDrugCount">0</b> รายการ</div>
            <div class="pip-robot-tools">
                <button type="button" class="pip-btn" id="btnRobotSeed" title="ดึงยา TAB/CAP ทั้งหมดจาก HOSxP เข้ามาในรายการ (ไม่ลบของเดิม)">
                    <i class="fas fa-download"></i> ดึง TAB/CAP ทั้งหมด
                </button>
                <button type="button" class="pip-btn danger" id="btnRobotReseed" title="ล้างรายการแล้วดึง TAB/CAP ใหม่ทั้งหมด">
                    ล้างแล้วดึงใหม่
                </button>
            </div>
            <div class="pip-robot-tools">
                <input type="text" id="robotDrugFilter" placeholder="กรองรายการที่ตั้งไว้ (รหัส/ชื่อ)...">
            </div>
            <div class="pip-robot-list" id="robotDrugList">
                <div class="muted" style="padding:10px;text-align:center;">กำลังโหลด...</div>
            </div>
            <div class="pip-robot-tools" style="margin-top:10px;">
                <input type="text" id="robotDrugAddQ" placeholder="ค้นหาเพิ่มยาจาก HOSxP (รหัส/ชื่อ)...">
                <button type="button" class="pip-btn primary" id="btnRobotSearchAdd"><i class="fas fa-search"></i> ค้นหา</button>
            </div>
            <div class="pip-robot-search-hit" id="robotDrugSearchHit"></div>

            <div class="sec-title">ค่า Lab บนแถบผู้ป่วย</div>
            <div class="hint" style="margin-left:0;">แสดงค่าล่าสุดจาก HOSxP · ค่า &lt; ต่ำ หรือ &gt; สูง = ตัวแดงหนา (eGFR เตือนเมื่อ &lt; 60 เป็นค่าเริ่มต้น) · คำค้นคั่นด้วยจุลภาค · <b>CrCl</b> คำนวณอัตโนมัติจาก Cr + BW + อายุ/เพศ (ไม่ต้องตั้งในตารางนี้) — ตั้งคำค้น SCr ที่แถว <b>Cr</b> · คลิก CrCl บนแถบเพื่อแก้ค่าได้</div>
            <div class="pip-lab-cfg" id="labCfgList"></div>
            <div class="pip-lab-add">
                <input type="text" class="lab-add-label" id="labAddLabel" placeholder="ชื่อ เช่น Mg">
                <input type="text" class="lab-add-match" id="labAddMatch" placeholder="คำค้น เช่น magnesium,mg">
                <input type="number" class="lab-add-bound" id="labAddLow" step="any" placeholder="ต่ำ">
                <input type="number" class="lab-add-bound" id="labAddHigh" step="any" placeholder="สูง">
                <button type="button" class="pip-btn primary" id="btnLabAdd"><i class="fas fa-plus"></i> เพิ่ม Lab</button>
            </div>
        </div>
        <div class="pip-foot" style="justify-content:flex-end;background:#fff;border-top:1px solid #e4eef2;">
            <button type="button" class="pip-btn" id="pipSettingsCancel">ยกเลิก</button>
            <button type="button" class="pip-btn primary" id="pipSettingsSave">บันทึก</button>
        </div>
    </div>
</div>
<div class="pip-toast" id="pipToast"></div>

<div class="pip-crcl-modal" id="pipCrclModal" aria-hidden="true">
    <div class="pip-crcl-box">
        <div class="hd">
            <span><i class="fas fa-calculator me-1"></i>คำนวณ CrCl (Cockcroft-Gault)</span>
            <button type="button" class="pip-btn" id="pipCrclClose" style="padding:2px 8px;">ปิด</button>
        </div>
        <div class="bd">
            <div class="pip-crcl-formula">
                <div>
                    (<span style="color:#1565c0;">140</span> − Age
                    <input type="number" id="crclAge" min="1" max="120" step="1">)
                    × Weight(kg)
                    <input type="number" id="crclBw" min="0" step="0.1">
                    ×
                    <select id="crclSex">
                        <option value="1">ชาย (×1)</option>
                        <option value="2">หญิง (×0.85)</option>
                    </select>
                </div>
                <div style="margin:4px 0;border-top:1px solid #cbd5e1;"></div>
                <div>
                    72 × SCr
                    <input type="number" class="pip-crcl-scr" id="crclScr" min="0" step="0.01">
                    &nbsp;→&nbsp;
                    <button type="button" class="pip-btn primary" id="btnCrclCalc" style="padding:4px 12px;">คำนวณ เลย!!!</button>
                </div>
                <div style="margin-top:8px;">
                    Creatinine Clearance =
                    <input type="text" class="pip-crcl-result" id="crclResult" readonly>
                    <span style="font-weight:600;color:#64748b;"> mL/min</span>
                </div>
            </div>
            <div class="pip-crcl-note">ให้ตรวจสอบน้ำหนักตัวผู้ป่วยอีกครั้งว่าเป็นน้ำหนักจริงหรือไม่</div>
            <div class="pip-crcl-note" style="color:#1565c0;">คำนวณ CrCl ดึงน้ำหนักและ SCr ล่าสุด (HOSxP กับ THAM อย่างที่ใหม่กว่า) — ปรับเลขได้ · กดใช้ค่า = บันทึก BW เข้า THAM ด้วย</div>
            <div class="pip-crcl-dates" id="crclDates"></div>
            <div class="pip-crcl-actions">
                <button type="button" class="pip-btn" id="btnCrclReset">คืนค่าจากฐานข้อมูล</button>
                <button type="button" class="pip-btn primary" id="btnCrclApply">บันทึกน้ำหนัก + ใช้บนแถบ Lab</button>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/emr_prefetch_cache.js"></script>
<script>
const PIP_CAN_SMART_DRUG = <?php echo $can_smart_drug ? 'true' : 'false'; ?>;
const PIP_CAN_SMART_LAB = <?php echo $can_smart_lab ? 'true' : 'false'; ?>;
</script>
<script>
const PREFILL = {
    hn: <?php echo json_encode(html_entity_decode($prefill_hn, ENT_QUOTES, 'UTF-8'), JSON_UNESCAPED_UNICODE); ?>,
    an: <?php echo json_encode(html_entity_decode($prefill_an, ENT_QUOTES, 'UTF-8'), JSON_UNESCAPED_UNICODE); ?>
};
const CURRENT_USER = <?php echo json_encode([
    'id' => (int)($_SESSION['user_id'] ?? 0),
    'username' => (string)($_SESSION['username'] ?? ''),
    'full_name' => (string)($_SESSION['full_name'] ?? ''),
], JSON_UNESCAPED_UNICODE); ?>;
const ORDER_COL_KEYS = ['type', 'date', 'dispense', 'dtime', 'ward', 'key', 'ono', 'rxnote'];
let ORDER_COL_WIDTHS = <?php echo json_encode($pip_order_col_widths, JSON_UNESCAPED_UNICODE); ?>;
let orderColSaveTimer = null;
const MED_COL_KEYS_CONT = ['num','name','usage','qty','interval','per_dose','per_day','orderdate','offdate','freq','paydays','recorder','pay','return','note','first_upd','last_upd'];
const MED_COL_KEYS_OFF = ['num','name','usage','qty','per_dose','per_day','orderdate','offdate','freq','paydays','qty_day','pay','return','off_staff','recorder'];
const MED_COL_KEYS_ONEDAY = ['num','name','usage','qty','interval','per_dose','per_day','orderdate','order'];
const MED_COL_KEYS_ALL = ['num','name','usage','qty','interval','per_dose','per_day','orderdate','offdate','freq','paydays','qty_day','recorder','off_staff','pay','return','note','first_upd','last_upd','order'];
let MED_COL_WIDTHS = <?php echo json_encode($pip_med_col_widths, JSON_UNESCAPED_UNICODE); ?>;
let medColSaveTimer = null;
let LAYOUT = <?php echo json_encode($pip_layout, JSON_UNESCAPED_UNICODE); ?>;
let layoutSaveTimer = null;
/** false = วิธีใช้แบบเต็ม (ค่าเริ่มต้น), true = แบบ code จาก HOSxP */
let USAGE_CODE_MODE = !!(LAYOUT && Number(LAYOUT.usage_code));
let STATE = null;
let selectedOrderNo = '';
let medView = 'active';
let orderMode = 'all'; // all | hme
let orderTypeChecked = { ATO: true, BCH: true, IRX: true, HME: true };
const ORDER_TYPE_DEFAULTS = ['ATO', 'BCH', 'IRX', 'HME'];
/** false = แสดงทั้ง drug + non-drug (ค่าเริ่มต้น), true = เฉพาะยา */
let orderDrugOnly = false;
let lastNoteHn = '';
let lastAllergyHn = '';
let lastMustPaidHn = '';
let lastAlertPharmaHn = '';
let lastAlertPharmaPassHn = '';
let lastDayAheadHn = '';
let lastRobotHn = '';
let DAY_AHEAD_SETTINGS = {
    enabled: true,
    lead_days: 1,
    parse_usage: true,
    alert_if_missing: true,
    alert_if_mismatch: true,
    only_active: true,
    auto_popup: true,
    auto_popup_must_paid: true,
    auto_popup_hosxp_note: true,
    auto_popup_robot: true,
    robot_alert_enabled: true,
    exact_day_enabled: true,
    exact_day_keywords: ['ก่อนนอน'],
    exact_day_drugs: [{ icode: '', name: 'warfarin', units: '' }]
};
/** รายการยาตั้งจ่ายตรงวัน (แก้ในตั้งค่า ก่อนบันทึก) */
let EXACT_DAY_DRUGS_EDIT = [];
/** รายการ Lab ที่แสดง/เตือนบนแถบผู้ป่วย (แก้ในตั้งค่า) */
let LAB_SETTINGS = { labs: [] };
let LAB_SETTINGS_EDIT = [];
/** บริบท CrCl จากเซิร์ฟเวอร์ + ค่าที่ผู้ใช้แก้ในหน้านี้ */
let CRCL_CTX = null;
let CRCL_OVERRIDE = null;
let ALERT_PHARMA_SETTINGS = {
    enabled: true,
    popup_mode: 'alert_only',
    auto_popup: true,
    auto_popup_pass: false,
    use_smart_pharma_defaults: true,
    module_keys: []
};
let ALERT_PHARMA_MODULES = [];
let ALERT_PHARMA_RESULT = { has_alert: false, alert_count: 0, alerts: [], module_results: [], pass_count: 0 };
let alertPharmaPending = null;
let alertPharmaSeq = 0;

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function money(n) {
    const x = Number(n || 0);
    return x.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function updateEmrLinks(hn) {
    const qs = hn ? ('?hn=' + encodeURIComponent(hn)) : '';
    ['linkPatientOpd', 'linkSmartDrug', 'linkSmartLab', 'btnDrugLab', 'btnLabSmart', 'btnMedHist', 'btnDrugRefer', 'btnReport', 'btnCalc', 'btnMgMl', 'btnWarfarin', 'btnPedsDose'].forEach(function (id) {
        const el = document.getElementById(id);
        if (!el || !el.getAttribute('href')) return;
        const base = el.getAttribute('href').split('?')[0];
        el.setAttribute('href', base + qs);
    });
    const consult = document.getElementById('btnConsult');
    if (consult && hn) {
        consult.setAttribute('href', 'med_error.php?hn=' + encodeURIComponent(hn));
    } else if (consult && !hn) {
        consult.setAttribute('href', 'med_error.php');
    }
}

/** หลังค้น HN/AN — เตรียม Smart Drug + Smart Lab ไว้ใน cache (พื้นหลัง) */
let _pipPrefetchTimer = null;
function prefetchEmrCompanions(hn) {
    hn = String(hn || '').trim();
    if (!hn) return;
    if (!(PIP_CAN_SMART_DRUG || PIP_CAN_SMART_LAB)) return;
    if (!window.EmrPrefetchCache || typeof EmrPrefetchCache.prefetchFromIpd !== 'function') return;
    // debounce กันค้นซ้ำเร็วๆ
    if (_pipPrefetchTimer) clearTimeout(_pipPrefetchTimer);
    _pipPrefetchTimer = setTimeout(function () {
        _pipPrefetchTimer = null;
        runPrefetchEmrCompanions(hn);
    }, 150);
}
function runPrefetchEmrCompanions(hn) {
    EmrPrefetchCache.prefetchFromIpd(hn, {
        canDrug: !!PIP_CAN_SMART_DRUG,
        canLab: !!PIP_CAN_SMART_LAB,
        onStatus: function (msg) {
            if (!msg) return;
            const $st = $('#pipStatus');
            const cur = $st.text() || '';
            $st.attr('title', cur + (cur ? ' · ' : '') + msg);
            ['linkSmartDrug', 'linkSmartLab', 'btnLabSmart', 'btnDrugLab'].forEach(function (id) {
                const el = document.getElementById(id);
                if (el) el.title = (el.getAttribute('data-base-title') || el.title || '') + ' — ' + msg;
            });
        }
    });
}
// เก็บ title เดิมของปุ่ม companion
['linkSmartDrug', 'linkSmartLab', 'btnLabSmart', 'btnDrugLab'].forEach(function (id) {
    const el = document.getElementById(id);
    if (el && !el.getAttribute('data-base-title')) {
        el.setAttribute('data-base-title', el.title || '');
    }
});

/** เปิดเมนูประกอบข้ามหน้าต่าง — ไม่แทนที่ Patient IPD; พยายามวางข้างจอ/จอ 2 */
function openCompanionWindow(url, name) {
    const winName = 'pip_' + String(name || 'tool').replace(/[^a-z0-9_]/gi, '_');
    const w = Math.min(1280, Math.max(900, Math.floor((screen.availWidth || 1200) * 0.55)));
    const h = Math.min(960, Math.max(700, Math.floor((screen.availHeight || 800) * 0.9)));
    const curLeft = (typeof window.screenX === 'number') ? window.screenX : (window.screenLeft || 0);
    const curTop = (typeof window.screenY === 'number') ? window.screenY : (window.screenTop || 0);
    const curW = window.outerWidth || w;
    const gap = 8;
    let left = curLeft + curW + gap;
    let top = Math.max(0, curTop);

    // ถ้ามีจอซ้าย (availLeft < 0) หรือวางขวาไม่พอ — วางซ้ายของหน้าต่างปัจจุบัน
    const screenRight = (typeof screen.availLeft === 'number' ? screen.availLeft : 0) + (screen.availWidth || screen.width || 1920);
    if (left + w > screenRight + 40) {
        left = Math.max(
            (typeof screen.availLeft === 'number' ? screen.availLeft : 0),
            curLeft - w - gap
        );
    }

    // Screen Details API (Chrome) — วางบนจออื่นถ้ามี
    tryPlaceOnOtherScreen(url, winName, w, h).then(function (placed) {
        if (placed) return;
        const feat = [
            'noopener=yes', 'noreferrer=yes',
            'width=' + w, 'height=' + h,
            'left=' + Math.round(left), 'top=' + Math.round(top),
            'resizable=yes', 'scrollbars=yes'
        ].join(',');
        const win = window.open(url, winName, feat);
        if (!win) {
            // ถูกบล็อก pop-up → แท็บใหม่
            window.open(url, '_blank', 'noopener,noreferrer');
        } else {
            try { win.focus(); } catch (e) {}
        }
    });
    return false;
}

function tryPlaceOnOtherScreen(url, winName, w, h) {
    return new Promise(function (resolve) {
        if (!window.getScreenDetails) {
            resolve(false);
            return;
        }
        window.getScreenDetails().then(function (details) {
            const screens = details.screens || [];
            if (screens.length < 2) {
                resolve(false);
                return;
            }
            const curCx = (typeof window.screenX === 'number' ? window.screenX : 0) + ((window.outerWidth || w) / 2);
            const curCy = (typeof window.screenY === 'number' ? window.screenY : 0) + ((window.outerHeight || h) / 2);
            let current = screens[0];
            let other = null;
            screens.forEach(function (s) {
                if (curCx >= s.left && curCx < s.left + s.width && curCy >= s.top && curCy < s.top + s.height) {
                    current = s;
                }
            });
            screens.forEach(function (s) {
                if (s !== current && !other) other = s;
            });
            if (!other) {
                resolve(false);
                return;
            }
            const left = Math.round(other.availLeft + Math.max(0, (other.availWidth - w) / 2));
            const top = Math.round(other.availTop + Math.max(0, (other.availHeight - h) / 2));
            const feat = [
                'noopener=yes', 'noreferrer=yes',
                'width=' + w, 'height=' + h,
                'left=' + left, 'top=' + top,
                'resizable=yes', 'scrollbars=yes'
            ].join(',');
            const win = window.open(url, winName, feat);
            if (!win) {
                resolve(false);
                return;
            }
            try { win.focus(); } catch (e) {}
            resolve(true);
        }).catch(function () { resolve(false); });
    });
}

function renderPtBar(data) {
    const p = data.patient || {};
    const a = data.admission || {};
    const dx = data.dx || {};
    const al = data.allergy || {};
    const labs = data.labs || {};
    let html = '';
    html += '<span><span class="k">AN</span> <span class="v">' + esc(a.an || '-') + '</span></span>';
    html += '<span><span class="k">HN</span> <span class="v">' + esc(p.hn_display || p.hn || '-') + '</span></span>';
    html += '<span><span class="k">Ward</span> <span class="v">' + esc(a.ward_name || '-') + '</span></span>';
    html += '<span class="name">' + esc(p.full_name || '-') + '</span>';
    html += '<span><span class="k">สิทธิ</span> <span class="v pttype-v">' + esc(a.pttype_name || '-') + '</span></span>';
    html += '<span><span class="k">อายุ</span> <span class="v">' + esc(p.age_text || '-') + '</span></span>';
    html += '<span><span class="k">Admit</span> <span class="v">' + esc(a.regdate || '-') + (a.regtime ? (' ' + esc(a.regtime)) : '') + '</span></span>';
    if (a.is_active) html += '<span class="chip chip-active">Admit อยู่</span>';
    else if (a.dchdate) html += '<span class="chip chip-dch">จำหน่าย ' + esc(a.dchdate) + '</span>';
    if (al.has_allergy) html += '<span class="chip chip-al" title="คลิกดู Alert Drug Allergy">แพ้ยา: ' + esc(al.text || '') + '</span>';
    else html += '<span class="chip chip-ok">ไม่แพ้ยา</span>';
    if (dx.text) html += '<span><span class="k">CC</span> <span class="dx">' + esc(dx.text) + '</span></span>';
    const labHtml = formatLabStripHtml(labs);
    if (labHtml) html += '<span class="pip-labbox">' + labHtml + '</span>';
    $('#pipPtBar').html(html).show();
}

function formatLabStripHtml(labs) {
    labs = labs || {};
    const bits = [];
    const crclMeta = labs.crcl_meta || CRCL_CTX;
    let crclVal = (CRCL_OVERRIDE && CRCL_OVERRIDE.crcl != null)
        ? CRCL_OVERRIDE.crcl
        : (labs.crcl || (crclMeta && crclMeta.crcl != null ? crclMeta.crcl : ''));
    if (crclVal === '' || crclVal == null) crclVal = '—';
    let sawCrcl = false;
    // บังคับลำดับ CrCl ต่อจาก eGFR บน client
    if (Array.isArray(labs.items) && labs.items.length) {
        const ordered = [];
        let crclIt = null;
        labs.items.forEach(function (it) {
            if (it && it.id === 'crcl') crclIt = it;
            else if (it) ordered.push(it);
        });
        if (crclIt) {
            let placed = false;
            const withCrcl = [];
            ordered.forEach(function (it) {
                withCrcl.push(it);
                if (!placed && it.id === 'egfr') {
                    withCrcl.push(crclIt);
                    placed = true;
                }
            });
            if (!placed) {
                let afterCr = false;
                const tmp = [];
                withCrcl.forEach(function (it) {
                    tmp.push(it);
                    if (!afterCr && it.id === 'cr') {
                        tmp.push(crclIt);
                        afterCr = true;
                    }
                });
                labs.items = afterCr ? tmp : [crclIt].concat(withCrcl);
            } else {
                labs.items = withCrcl;
            }
        }
    }
    if (Array.isArray(labs.items) && labs.items.length) {
        labs.items.forEach(function (it) {
            if (!it) return;
            if (it.id === 'crcl') {
                sawCrcl = true;
                const v = (CRCL_OVERRIDE && CRCL_OVERRIDE.crcl != null)
                    ? CRCL_OVERRIDE.crcl
                    : (it.value != null && it.value !== '' ? it.value : crclVal);
                const edited = !!(CRCL_OVERRIDE && CRCL_OVERRIDE.edited);
                const incomplete = (v === '—' || v === '' || v == null);
                const cls = ' class="pip-crcl-link' + (edited ? ' pip-crcl-edited' : '') + '"';
                const tip = incomplete
                    ? ' title="ยังคำนวณไม่ได้ (ขาด BW/SCr) — คลิกเพื่อใส่ค่า"'
                    : (edited
                        ? ' title="CrCl ที่แก้แล้ว — คลิกแก้ไข / ดูวันที่ดึงค่า"'
                        : ' title="คลิกแก้ไข SCr / BW / อายุ / เพศ"');
                bits.push(esc(it.label || 'CrCl') + ' = <b' + cls + tip + ' data-pip-crcl="1">' + esc(String(v)) + '</b>');
                return;
            }
            if (!it.value) return;
            const cls = it.alert ? ' class="pip-lab-alert"' : '';
            let tip = '';
            if (it.alert) {
                const parts = [];
                if (it.low != null && it.low !== '') parts.push('ต่ำ ' + it.low);
                if (it.high != null && it.high !== '') parts.push('สูง ' + it.high);
                tip = parts.length ? (' title="นอกช่วงปกติ (' + esc(parts.join(' / ')) + ')"') : ' title="นอกช่วงปกติ"';
            }
            let label = it.label || it.id;
            let valHtml = esc(it.value);
            if (it.id === 'bw') {
                const src = it.source_label || labs.bw_source_label
                    || (crclMeta && crclMeta.bw_source_label) || '';
                if (src) {
                    tip = tip || (' title="BW จาก ' + esc(src) + '"');
                    valHtml = esc(it.value) + '<small style="font-weight:700;color:#64748b;"> (' + esc(src) + ')</small>';
                }
            }
            bits.push(esc(label) + ' = <b' + cls + tip + '>' + valHtml + '</b>');
        });
        if (!sawCrcl) {
            const edited = !!(CRCL_OVERRIDE && CRCL_OVERRIDE.edited);
            bits.push('CrCl = <b class="pip-crcl-link' + (edited ? ' pip-crcl-edited' : '') + '" data-pip-crcl="1" title="คลิกแก้ไขค่าคำนวณ">' + esc(String(crclVal)) + '</b>');
        }
        return bits.join(' &nbsp;|&nbsp; ');
    }
    // fallback คีย์เดิม — CrCl ต่อจาก eGFR
    [['egfr', 'eGFR'], ['crcl', 'CrCl'], ['cr', 'Cr'], ['k', 'K'], ['na', 'Na'], ['ast', 'AST'], ['alt', 'ALT'], ['inr', 'INR'], ['bw', 'BW']].forEach(function (pair) {
        if (pair[0] === 'crcl') {
            bits.push('CrCl = <b class="pip-crcl-link" data-pip-crcl="1" title="คลิกแก้ไขค่าคำนวณ">' + esc(String(crclVal)) + '</b>');
            return;
        }
        if (!labs[pair[0]]) return;
        let extra = '';
        if (pair[0] === 'bw' && labs.bw_source_label) {
            extra = ' <small style="font-weight:700;color:#64748b;">(' + esc(labs.bw_source_label) + ')</small>';
        }
        bits.push(pair[1] + ' = <b>' + esc(labs[pair[0]]) + extra + '</b>');
    });
    return bits.join(' &nbsp;|&nbsp; ');
}

function calcCrclClient(age, sex, bw, scr) {
    age = parseFloat(age); bw = parseFloat(bw); scr = parseFloat(scr);
    if (!(age > 0) || !(age < 140) || !(bw > 0) || !(scr > 0)) return null;
    let gfr = ((140 - age) * bw) / (72 * scr);
    const s = String(sex || '');
    if (s === '2' || s.toUpperCase() === 'F') gfr *= 0.85;
    return Math.round(gfr * 100) / 100;
}

function crclDateLines(meta, override) {
    meta = meta || {};
    override = override || {};
    const scrDb = meta.scr_raw != null && meta.scr_raw !== '' ? meta.scr_raw : meta.scr;
    const bwDb = meta.bw_raw != null && meta.bw_raw !== '' ? meta.bw_raw : meta.bw;
    const scrDate = meta.scr_date_fmt || '';
    const bwDate = meta.bw_date_fmt || '';
    let html = '';
    html += '<div><b>SCr จากฐานข้อมูล:</b> ' + esc(scrDb != null && scrDb !== '' ? String(scrDb) : '-')
        + (scrDate ? (' <span style="color:#0d47a1;">(วันที่ดึง ' + esc(scrDate) + ')</span>') : ' <span class="muted">(ไม่พบวันที่รายงาน)</span>')
        + '</div>';
    const bwSrc = meta.bw_source_label || '';
    html += '<div><b>BW จากฐานข้อมูล:</b> ' + esc(bwDb != null && bwDb !== '' ? String(bwDb) : '-')
        + (bwSrc ? (' <span style="color:#0f766e;font-weight:800;">(จาก ' + esc(bwSrc) + ')</span>') : '')
        + (bwDate ? (' <span style="color:#0d47a1;">(วันที่ดึง ' + esc(bwDate) + ')</span>') : ' <span class="muted">(ไม่พบวันที่)</span>')
        + '</div>';
    if (meta.hosxp_bw || meta.tham_bw) {
        const bits = [];
        if (meta.hosxp_bw) {
            bits.push('HOSxP ' + esc(String(meta.hosxp_bw))
                + (meta.hosxp_bw_date_fmt ? (' @ ' + esc(meta.hosxp_bw_date_fmt)) : ''));
        }
        if (meta.tham_bw) {
            bits.push('THAM ' + esc(String(meta.tham_bw))
                + (meta.tham_bw_date_fmt ? (' @ ' + esc(meta.tham_bw_date_fmt)) : ''));
        }
        if (bits.length) {
            html += '<div class="muted" style="font-size:11.5px;">เปรียบเทียบ: ' + bits.join(' · ') + ' — ใช้ค่าที่ใหม่กว่า</div>';
        }
    }
    if (override.edited) {
        html += '<div style="color:#b45309;font-weight:800;margin-top:4px;">กำลังใช้ค่าที่แก้ไขแล้วในหน้านี้'
            + (override.scr != null ? (' · SCr=' + esc(String(override.scr))) : '')
            + (override.bw != null ? (' · BW=' + esc(String(override.bw))) : '')
            + '</div>';
    }
    if (Array.isArray(meta.missing) && meta.missing.length && !override.edited) {
        html += '<div style="color:#c62828;font-weight:800;margin-top:4px;">ยังขาดค่า: '
            + esc(meta.missing.join(', ')) + ' — กรอกแล้วกดใช้ค่านี้บนแถบ Lab</div>';
    }
    return html;
}

function fillCrclModal() {
    const meta = CRCL_CTX || {};
    const ovr = CRCL_OVERRIDE || {};
    const age = ovr.age != null ? ovr.age : (meta.age || '');
    const sex = ovr.sex != null ? ovr.sex : (meta.sex || '1');
    const bw = ovr.bw != null ? ovr.bw : (meta.bw || meta.bw_raw || '');
    const scr = ovr.scr != null ? ovr.scr : (meta.scr || meta.scr_raw || '');
    $('#crclAge').val(age !== '' && age != null ? age : '');
    $('#crclSex').val((String(sex) === '2' || String(sex).toUpperCase() === 'F') ? '2' : '1');
    $('#crclBw').val(bw !== '' && bw != null ? bw : '');
    $('#crclScr').val(scr !== '' && scr != null ? scr : '');
    const crcl = calcCrclClient($('#crclAge').val(), $('#crclSex').val(), $('#crclBw').val(), $('#crclScr').val());
    $('#crclResult').val(crcl != null ? crcl : '');
    $('#crclDates').html(crclDateLines(meta, ovr));
}

function openCrclModal() {
    if (!CRCL_CTX && STATE && STATE.labs) {
        CRCL_CTX = STATE.labs.crcl_meta || null;
    }
    if (!CRCL_CTX) {
        // สร้างบริบทขั้นต่ำจากแถบ Lab / ผู้ป่วย เพื่อให้แก้ BW/SCr ได้เสมอ
        const p = (STATE && STATE.patient) || {};
        const labs = (STATE && STATE.labs) || {};
        let age = 0;
        if (p.birthday) {
            const b = new Date(String(p.birthday).slice(0, 10) + 'T00:00:00');
            const n = new Date();
            age = Math.max(0, n.getFullYear() - b.getFullYear());
        }
        CRCL_CTX = {
            age: age,
            sex: p.sex || '1',
            sex_label: p.sex_label || '',
            scr: labs.cr || '',
            scr_raw: labs.cr || '',
            scr_date_fmt: '',
            bw: labs.bw || '',
            bw_raw: labs.bw || '',
            bw_date_fmt: '',
            crcl: null,
            editable: true
        };
    }
    fillCrclModal();
    $('#pipCrclModal').css('display', 'flex').attr('aria-hidden', 'false');
}

function closeCrclModal() {
    $('#pipCrclModal').hide().attr('aria-hidden', 'true');
}

function applyCrclToStrip() {
    const age = parseFloat($('#crclAge').val());
    const sex = $('#crclSex').val();
    const bw = parseFloat($('#crclBw').val());
    const scr = parseFloat($('#crclScr').val());
    const crcl = calcCrclClient(age, sex, bw, scr);
    if (crcl == null) {
        toast('กรุณากรอก Age / BW / SCr ให้ครบและถูกต้อง', 'err');
        return;
    }
    const meta = CRCL_CTX || {};
    const dbScr = parseFloat(meta.scr || meta.scr_raw);
    const dbBw = parseFloat(meta.bw || meta.bw_raw);
    const dbAge = parseFloat(meta.age);
    const dbSex = String(meta.sex || '1') === '2' ? '2' : '1';
    const edited = !(dbScr === scr && dbBw === bw && dbAge === age && dbSex === String(sex));
    CRCL_OVERRIDE = {
        age: age, sex: sex, bw: bw, scr: scr, crcl: crcl, edited: edited
    };
    $('#crclResult').val(crcl);

    function paintStrip(opts) {
        opts = opts || {};
        const savedOk = !!opts.savedOk;
        const bwSourceLabel = opts.bwSourceLabel || (savedOk ? 'THAM' : ((meta && meta.bw_source_label) || ''));
        const bwSource = opts.bwSource || (savedOk ? 'tham' : ((meta && meta.bw_source) || ''));
        if (STATE && STATE.labs) {
            STATE.labs.crcl = String(crcl);
            STATE.labs.bw = String(bw);
            if (bwSource) STATE.labs.bw_source = bwSource;
            if (bwSourceLabel) STATE.labs.bw_source_label = bwSourceLabel;
            if (!STATE.labs.crcl_meta) STATE.labs.crcl_meta = {};
            STATE.labs.crcl_meta.bw = bw;
            STATE.labs.crcl_meta.bw_raw = String(bw);
            if (bwSource) STATE.labs.crcl_meta.bw_source = bwSource;
            if (bwSourceLabel) STATE.labs.crcl_meta.bw_source_label = bwSourceLabel;
            if (savedOk) STATE.labs.crcl_meta.tham_bw = bw;
            STATE.labs.crcl_meta.crcl = crcl;
            CRCL_CTX = STATE.labs.crcl_meta;
            if (Array.isArray(STATE.labs.items)) {
                let foundCrcl = false;
                let foundBw = false;
                STATE.labs.items.forEach(function (it) {
                    if (!it) return;
                    if (it.id === 'crcl') { it.value = String(crcl); it.num = crcl; foundCrcl = true; }
                    if (it.id === 'bw') {
                        it.value = String(bw); it.num = bw;
                        if (bwSource) it.source = bwSource;
                        if (bwSourceLabel) it.source_label = bwSourceLabel;
                        foundBw = true;
                    }
                });
                if (!foundCrcl) {
                    let egfrIdx = -1;
                    STATE.labs.items.forEach(function (it, idx) {
                        if (it && it.id === 'egfr') egfrIdx = idx;
                    });
                    const crclIt = { id: 'crcl', label: 'CrCl', value: String(crcl), num: crcl, editable: true };
                    if (egfrIdx >= 0) STATE.labs.items.splice(egfrIdx + 1, 0, crclIt);
                    else STATE.labs.items.push(crclIt);
                }
                if (!foundBw) {
                    STATE.labs.items.push({
                        id: 'bw', label: 'BW', value: String(bw), num: bw,
                        source: bwSource || 'tham', source_label: bwSourceLabel || 'THAM'
                    });
                }
            }
            renderPtBar(STATE);
        }
        closeCrclModal();
        if (opts.silent) return;
        if (savedOk) {
            toast(edited
                ? 'บันทึกน้ำหนักใน THAM แล้ว และใช้ CrCl บนแถบ Lab'
                : 'บันทึกน้ำหนักใน THAM แล้ว', 'ok');
        } else {
            toast(edited ? 'ใช้ CrCl ที่แก้ไขแล้วบนแถบ Lab' : 'ใช้ CrCl บนแถบ Lab', 'ok');
        }
    }

    const hn = ((STATE && STATE.patient) || {}).hn
        || ((STATE && STATE.patient) || {}).hn_display
        || $('#pipHn').val() || '';
    const ptname = ((STATE && STATE.patient) || {}).ptname || '';
    if (!(bw > 0) || !String(hn).trim()) {
        paintStrip({ savedOk: false });
        return;
    }
    $('#btnCrclApply').prop('disabled', true);
    fetch('fetch_patient_ipd_api.php?action=save_bw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
            action: 'save_bw',
            hn: String(hn).trim(),
            bw: bw,
            ptname: ptname,
            source_module: 'patient_ipd_crcl'
        })
    }).then(function (r) { return r.json(); }).then(function (res) {
        $('#btnCrclApply').prop('disabled', false);
        if (!res || !res.ok) {
            toast((res && res.error) || 'บันทึกน้ำหนักไม่สำเร็จ — ยังใช้ค่าบนแถบ Lab', 'err');
            paintStrip({ savedOk: false, silent: true });
            return;
        }
        paintStrip({
            savedOk: true,
            bwSource: res.source || 'tham',
            bwSourceLabel: res.source_label || 'THAM'
        });
    }).catch(function () {
        $('#btnCrclApply').prop('disabled', false);
        toast('บันทึกน้ำหนักไม่สำเร็จ — ยังใช้ค่าบนแถบ Lab', 'err');
        paintStrip({ savedOk: false, silent: true });
    });
}

function normOrderType(o) {
    const raw = String((o && (o.order_type_raw || o.order_type)) || '').toUpperCase().trim();
    if (raw === 'IRX') return 'IRX';
    if (raw === 'HME') return 'HME';
    return raw || 'OTHER';
}

function orderTypeLabel(t) {
    if (t === 'IRX') return 'IRx';
    if (t === 'OTHER') return 'อื่นๆ';
    return t;
}

function collectOrderTypes(orders) {
    const set = {};
    ORDER_TYPE_DEFAULTS.forEach(function (t) { set[t] = true; });
    (orders || []).forEach(function (o) {
        const t = normOrderType(o);
        if (t) set[t] = true;
    });
    const preferred = ['ATO', 'BCH', 'IRX', 'HME'];
    const rest = Object.keys(set).filter(function (t) { return preferred.indexOf(t) < 0; }).sort();
    return preferred.filter(function (t) { return set[t]; }).concat(rest);
}

function countOrdersByMode(orders) {
    let all = 0, hme = 0;
    (orders || []).forEach(function (o) {
        const t = normOrderType(o);
        if (t === 'HME') hme += 1;
        else all += 1;
    });
    return { all: all, hme: hme, total: (orders || []).length };
}

function filteredOrders() {
    const orders = (STATE && STATE.orders) || [];
    if (orderMode === 'hme') {
        return orders.filter(function (o) { return normOrderType(o) === 'HME'; });
    }
    // All = ทุกประเภทที่ติ๊ก (ยกเว้นโหมด HME แยกแท็บ) — รวม HME ได้ถ้าติ๊ก HME
    return orders.filter(function (o) {
        const t = normOrderType(o);
        if (orderTypeChecked[t] === true) return true;
        if (t === 'OTHER' && orderTypeChecked.OTHER === true) return true;
        // ประเภทใหม่ที่ยังไม่เคยตั้งค่า → แสดงเป็นค่าเริ่มต้น (รวม HME)
        if (orderTypeChecked[t] === undefined) return true;
        return false;
    });
}

function renderOrderTypeChecks(orders) {
    const types = collectOrderTypes(orders);
    let html = '';
    types.forEach(function (t) {
        if (orderMode === 'hme' && t !== 'HME') return;
        if (orderTypeChecked[t] === undefined) {
            orderTypeChecked[t] = true;
        }
        const checked = !!orderTypeChecked[t];
        const cls = (checked ? ' on' : '') + (t === 'HME' ? ' hme-only' : '');
        html += '<label class="' + cls.trim() + '">'
            + '<input type="checkbox" data-otype="' + esc(t) + '"' + (checked ? ' checked' : '') + '>'
            + esc(orderTypeLabel(t))
            + '</label>';
    });
    if (orderMode === 'hme') {
        html = '<label class="hme-only on"><input type="checkbox" checked disabled> HME</label>';
    }
    $('#orderTypeChecks').html(html || '<span class="muted">ไม่มีประเภท Order</span>');
}

function applyOrderFilter(opts) {
    opts = opts || {};
    const list = filteredOrders();
    const counts = countOrdersByMode((STATE && STATE.orders) || []);
    $('#orderCntAll').text(counts.all);
    $('#orderCntHme').text(counts.hme);
    $('#orderModeTabs button').removeClass('active');
    $('#orderModeTabs button[data-mode="' + orderMode + '"]').addClass('active');
    renderOrderTypeChecks((STATE && STATE.orders) || []);
    $('#orderFilterMeta').text(list.length + ' / ' + ((STATE && STATE.orders) || []).length + ' รายการ');

    let keep = orderNoStr(selectedOrderNo);
    const still = list.some(function (o) { return orderNoStr(o.order_no) === keep; });
    if (!still) {
        keep = list.length ? orderNoStr(list[0].order_no) : '';
        selectedOrderNo = keep;
    } else {
        selectedOrderNo = keep;
    }
    renderOrders(list, selectedOrderNo);
    if (opts.reloadItems !== false) {
        if (selectedOrderNo) {
            if (opts.forceLoad || !still) {
                loadOrderItems(selectedOrderNo);
            }
        } else {
            $('#pipItemBody').html('<tr><td colspan="6" class="muted" style="text-align:center;padding:16px;">ไม่มี Order ตามตัวกรอง</td></tr>');
        }
    }
}

function toast(msg, kind) {
    const $el = $('#pipToast');
    $el.removeClass('ok err').addClass(kind === 'err' ? 'err' : 'ok').text(msg).fadeIn(120);
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { $el.fadeOut(200); }, 2500);
}

function orderNoStr(v) {
    return String(v == null ? '' : v).trim();
}

function findOrder(orderNo) {
    const want = orderNoStr(orderNo);
    if (!want) return null;
    const list = (STATE && STATE.orders) || [];
    for (let i = 0; i < list.length; i++) {
        if (orderNoStr(list[i].order_no) === want) return list[i];
    }
    return null;
}

function fmtDispenseTime(raw) {
    const s = String(raw || '').trim();
    if (!s) return '';
    // Y-m-d H:i:s → d/m/Y H:i
    const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
    if (m) return m[3] + '/' + m[2] + '/' + m[1] + ' ' + m[4] + ':' + m[5];
    return s;
}

function patchOrderDispense(orderNo, info) {
    const o = findOrder(orderNo);
    if (!o) return;
    o.dispense_user_id = info.dispense_user_id || 0;
    o.dispense_username = info.dispense_username || '';
    o.dispense_name = info.dispense_name || '';
    o.dispensed_at = info.dispensed_at || '';
    o.dispensed_at_display = info.dispensed_at_display || fmtDispenseTime(info.dispensed_at || '');
    o.is_dispensed = info.is_dispensed ? 1 : 0;
}

function updateDispenseButtons() {
    selectedOrderNo = orderNoStr(selectedOrderNo);
    const o = findOrder(selectedOrderNo);
    const hasOrder = !!(STATE && STATE.admission && selectedOrderNo && o);
    const $save = $('#btnDispenseSave');
    const $cancel = $('#btnDispenseCancel');
    $save.prop('disabled', !hasOrder).toggleClass('is-disabled', !hasOrder);
    const canCancel = hasOrder && !!o.is_dispensed;
    $cancel.prop('disabled', !canCancel).toggleClass('is-disabled', !canCancel);
    if (hasOrder) {
        $save.attr('title', 'บันทึกผู้จ่าย Order ' + selectedOrderNo + ' เป็น ' + defaultDispenserName() + ' (F9)');
    } else {
        $save.attr('title', 'เลือก Order จากตารางก่อน แล้วกดบันทึกจ่าย / F9');
    }
}

function defaultDispenserName() {
    return (CURRENT_USER && (CURRENT_USER.full_name || CURRENT_USER.username)) || 'ผู้ใช้ปัจจุบัน';
}

/** แยกวันที่กับเวลาเป็น 2 บรรทัด เช่น 08/10/2026 + 12:59 */
function splitDateTimeHtml(raw, emptyText, extraClass) {
    const cls = ('dt-split num' + (extraClass ? (' ' + extraClass) : '')).trim();
    const s = String(raw == null ? '' : raw).trim();
    if (!s) {
        return '<td class="' + cls + ' muted">' + esc(emptyText || '-') + '</td>';
    }
    // d/m/Y H:i[:s] | Y-m-d H:i[:s]
    let m = s.match(/^(\d{1,2}\/\d{1,2}\/\d{2,4})\s+(\d{1,2}:\d{2}(?::\d{2})?)/);
    if (!m) m = s.match(/^(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2}(?::\d{2})?)/);
    if (m) {
        const tm = m[2].length > 5 ? m[2].slice(0, 5) : m[2];
        return '<td class="' + cls + '" title="' + esc(s) + '">'
            + '<span class="dt-date">' + esc(m[1]) + '</span>'
            + '<span class="dt-time">' + esc(tm) + '</span>'
            + '</td>';
    }
    if (/^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(s) || /^\d{4}-\d{2}-\d{2}$/.test(s)) {
        return '<td class="' + cls + '"><span class="dt-date">' + esc(s) + '</span></td>';
    }
    return '<td class="' + cls + '">' + esc(s) + '</td>';
}

function orderDateTimeRaw(o) {
    if (o.datetime) return String(o.datetime);
    const d = o.rxdate_dmy || o.rxdate || '';
    const t = o.rxtime || '';
    return (d + (t ? (' ' + t) : '')).trim();
}

function rxNoteCellHtml(o) {
    const on = orderNoStr(o.order_no);
    const mode = (o.rx_note_mode === 'alert') ? 'alert' : 'note';
    const text = o.rx_note || '';
    const isAlert = mode === 'alert' && String(text).trim() !== '';
    const title = o.rx_note_updated_name
        ? ('อัปเดตโดย ' + o.rx_note_updated_name + (o.rx_note_updated_at ? (' · ' + o.rx_note_updated_at) : ''))
        : 'พิมพ์ Rx note แล้วเลือกโหมด';
    return '<td class="rx-note-td" title="' + esc(title) + '">'
        + '<div class="rx-note-box' + (isAlert ? ' is-alert' : '') + '" data-order="' + esc(on) + '">'
        + '<select class="rx-note-mode" data-order="' + esc(on) + '">'
        + '<option value="note"' + (mode === 'note' ? ' selected' : '') + '>บันทึกเท่านั้น</option>'
        + '<option value="alert"' + (mode === 'alert' ? ' selected' : '') + '>แจ้งเตือน</option>'
        + '</select>'
        + '<input type="text" class="rx-note-text" data-order="' + esc(on) + '" maxlength="500"'
        + ' placeholder="พิมพ์ Rx note..." value="' + esc(text) + '">'
        + '</div></td>';
}

function patchOrderRxNote(orderNo, info) {
    const o = findOrder(orderNo);
    if (!o) return;
    o.rx_note = info.rx_note || '';
    o.rx_note_mode = info.rx_note_mode === 'alert' ? 'alert' : 'note';
    o.rx_note_updated_name = info.rx_note_updated_name || '';
    o.rx_note_updated_at = info.rx_note_updated_at || '';
}

function saveRxNote(orderNo, opts) {
    opts = opts || {};
    orderNo = orderNoStr(orderNo);
    if (!STATE || !STATE.admission || !orderNo) return;
    const $box = $('.rx-note-box').filter(function () {
        return orderNoStr($(this).attr('data-order')) === orderNo;
    });
    const mode = opts.mode != null
        ? opts.mode
        : (($box.find('.rx-note-mode').val() === 'alert') ? 'alert' : 'note');
    const text = opts.text != null
        ? String(opts.text)
        : String($box.find('.rx-note-text').val() || '');
    const an = orderNoStr(STATE.admission.an);
    const hn = (STATE.patient && (STATE.patient.hn_display || STATE.patient.hn)) || '';
    $box.addClass('is-saving');
    fetch('fetch_patient_ipd_api.php?action=rx_note_save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'rx_note_save',
            an: an,
            order_no: orderNo,
            hn: hn,
            rx_note: text,
            rx_note_mode: mode
        })
    })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            $box.removeClass('is-saving');
            if (!data || !data.ok) {
                toast((data && data.error) || 'บันทึก Rx note ไม่สำเร็จ', 'err');
                return;
            }
            patchOrderRxNote(orderNo, data);
            const hasAlert = data.rx_note_mode === 'alert' && String(data.rx_note || '').trim() !== '';
            $box.toggleClass('is-alert', hasAlert);
            $box.find('.rx-note-mode').val(data.rx_note_mode === 'alert' ? 'alert' : 'note');
            $box.find('.rx-note-text').val(data.rx_note || '');
        })
        .catch(function () {
            $box.removeClass('is-saving');
            toast('บันทึก Rx note ไม่สำเร็จ', 'err');
        });
}

function renderOrders(orders, selected) {
    selected = orderNoStr(selected);
    selectedOrderNo = selected;
    if (!orders || !orders.length) {
        const msg = orderMode === 'hme'
            ? 'ไม่มี Order ประเภท HME'
            : 'ไม่มี Order ตามประเภทที่ติ๊ก';
        $('#pipOrderBody').html('<tr><td colspan="8" class="muted" style="text-align:center;padding:16px;">' + msg + '</td></tr>');
        updateDispenseButtons();
        return;
    }
    const defaultName = defaultDispenserName();
    let html = '';
    orders.forEach(function (o) {
        const on = orderNoStr(o.order_no);
        const sel = (on === selected) ? ' selected' : '';
        let dispenser;
        let dispenseTime;
        if (o.is_dispensed) {
            const t = o.dispensed_at_display || fmtDispenseTime(o.dispensed_at);
            dispenser = '<td class="col-person dispense-ok" title="' + esc(o.dispense_name || o.dispense_username || defaultName) + '">'
                + esc(o.dispense_name || o.dispense_username || defaultName) + '</td>';
            dispenseTime = splitDateTimeHtml(t, '-', 'dispense-ok');
        } else if (on === selected) {
            dispenser = '<td class="col-person dispense-default" title="ค่าเริ่มต้นจากผู้ Login — กดบันทึกจ่าย/F9">'
                + esc(defaultName) + '</td>';
            dispenseTime = '<td class="dt-split num dispense-default">รอบันทึก</td>';
        } else {
            dispenser = '<td class="col-person dispense-empty">-</td>';
            dispenseTime = '<td class="dt-split num dispense-empty">-</td>';
        }
        const keyName = o.key_staff_name || o.staff_name || o.key_staff || o.staff || '';
        const keyCode = o.key_staff || o.staff || '';
        const otype = String(o.order_type || o.order_type_raw || '');
        html += '<tr class="order-row' + sel + '" data-order="' + esc(on) + '" data-otype="' + esc(otype) + '">'
            + '<td><b>' + esc(o.order_type) + '</b></td>'
            + splitDateTimeHtml(orderDateTimeRaw(o), '-')
            + dispenser
            + dispenseTime
            + '<td class="col-ward" title="' + esc(o.ward_name || '') + '">' + esc(o.ward_name) + '</td>'
            + '<td class="col-person" title="' + esc(keyName || keyCode) + '">' + esc(keyName) + '</td>'
            + '<td class="code">' + esc(on) + '</td>'
            + rxNoteCellHtml(o)
            + '</tr>';
    });
    $('#pipOrderBody').html(html);
    updateDispenseButtons();
}

function orderColStorageKey() {
    return 'tham_pip_order_cols_u' + String((CURRENT_USER && CURRENT_USER.id) || 0);
}

function applyOrderColWidths(widths) {
    ORDER_COL_WIDTHS = Object.assign({}, ORDER_COL_WIDTHS || {}, widths || {});
    ORDER_COL_KEYS.forEach(function (k) {
        const w = parseInt(ORDER_COL_WIDTHS[k], 10);
        if (!w || w < 36) return;
        $('#pipOrderCols col[data-col="' + k + '"]').css('width', w + 'px');
    });
}

function readOrderColWidthsFromDom() {
    const out = {};
    ORDER_COL_KEYS.forEach(function (k) {
        const el = document.querySelector('#pipOrderCols col[data-col="' + k + '"]');
        if (!el) return;
        const w = Math.round(el.getBoundingClientRect().width || parseInt(el.style.width, 10) || 0);
        if (w >= 36) out[k] = w;
    });
    return out;
}

function persistOrderColWidths(widths) {
    const norm = Object.assign({}, ORDER_COL_WIDTHS || {}, widths || {});
    ORDER_COL_WIDTHS = norm;
    try { localStorage.setItem(orderColStorageKey(), JSON.stringify(norm)); } catch (e) {}
    if (orderColSaveTimer) clearTimeout(orderColSaveTimer);
    orderColSaveTimer = setTimeout(function () {
        fetch('fetch_patient_ipd_api.php?action=order_cols_save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'order_cols_save', widths: norm })
        }).catch(function () {});
    }, 400);
}

function layoutStorageKey() {
    return 'tham_pip_layout_u' + String((CURRENT_USER && CURRENT_USER.id) || 0);
}

function applyLayout(layout) {
    LAYOUT = Object.assign({}, LAYOUT || {}, layout || {});
    const leftPct = parseFloat(LAYOUT.left_pct);
    if (leftPct >= 22 && leftPct <= 72) {
        $('#pipLeft').css('width', leftPct + '%');
    }
    const ordersPct = parseFloat(LAYOUT.orders_pct);
    if (ordersPct >= 20 && ordersPct <= 80) {
        $('.pip-orders').css('flex', '0 0 ' + ordersPct + '%');
    }
    USAGE_CODE_MODE = !!Number(LAYOUT.usage_code);
    $('#chkUsageCode, #chkOrderUsageCode').prop('checked', USAGE_CODE_MODE);
    $('#lblUsageCode, #lblOrderUsageCode').toggleClass('on', USAGE_CODE_MODE);
    syncOpenDvOnIrxUi(LAYOUT.open_dv_on_irx !== 0 && LAYOUT.open_dv_on_irx !== '0' && LAYOUT.open_dv_on_irx !== false);
}

function syncOpenDvOnIrxUi(on) {
    const enabled = !!on;
    LAYOUT = Object.assign({}, LAYOUT || {}, { open_dv_on_irx: enabled ? 1 : 0 });
    $('#chkOpenDvOnIrx, #setOpenDvOnIrx').prop('checked', enabled);
    $('#lblOpenDvOnIrx').toggleClass('on', enabled);
}

function setOpenDvOnIrx(on, opts) {
    opts = opts || {};
    syncOpenDvOnIrxUi(on);
    if (!opts.skipPersist) {
        persistLayout({ open_dv_on_irx: LAYOUT.open_dv_on_irx });
    }
}

function persistLayout(partial) {
    LAYOUT = Object.assign({}, LAYOUT || {}, partial || {});
    try { localStorage.setItem(layoutStorageKey(), JSON.stringify(LAYOUT)); } catch (e) {}
    if (layoutSaveTimer) clearTimeout(layoutSaveTimer);
    layoutSaveTimer = setTimeout(function () {
        fetch('fetch_patient_ipd_api.php?action=layout_save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'layout_save', layout: LAYOUT })
        }).catch(function () {});
    }, 400);
}

function initLayoutResize() {
    applyLayout(LAYOUT);
    try { localStorage.setItem(layoutStorageKey(), JSON.stringify(LAYOUT)); } catch (e) {}

    const split = document.getElementById('pipVSplit');
    const stage = document.getElementById('pipMain');
    const left = document.getElementById('pipLeft');
    if (!split || !stage || !left) return;

    split.addEventListener('mousedown', function (e) {
        if (window.matchMedia && window.matchMedia('(max-width: 820px)').matches) return;
        e.preventDefault();
        const stageRect = stage.getBoundingClientRect();
        const stageW = stageRect.width || 1;
        $('body').addClass('pip-layout-resizing');

        function onMove(ev) {
            let pct = ((ev.clientX - stageRect.left) / stageW) * 100;
            if (pct < 22) pct = 22;
            if (pct > 72) pct = 72;
            left.style.width = pct.toFixed(1) + '%';
            LAYOUT.left_pct = Math.round(pct * 10) / 10;
        }
        function onUp() {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            $('body').removeClass('pip-layout-resizing');
            persistLayout({ left_pct: LAYOUT.left_pct });
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    });
}

function initOrderColResize() {
    applyOrderColWidths(ORDER_COL_WIDTHS);
    try { localStorage.setItem(orderColStorageKey(), JSON.stringify(ORDER_COL_WIDTHS)); } catch (e) {}

    const $table = $('#pipOrderTable');
    $table.on('mousedown', '.col-resize-handle', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const $th = $(this).closest('th');
        const colKey = String($th.attr('data-col') || '');
        if (!colKey) return;
        const $col = $('#pipOrderCols col[data-col="' + colKey + '"]');
        if (!$col.length) return;
        const startX = e.clientX;
        const startW = Math.round($col[0].getBoundingClientRect().width || parseInt($col.css('width'), 10) || 80);
        const $handle = $(this).addClass('is-active');
        $('body').addClass('pip-col-resizing');

        function onMove(ev) {
            const next = Math.max(36, Math.min(520, startW + (ev.clientX - startX)));
            $col.css('width', next + 'px');
            ORDER_COL_WIDTHS[colKey] = next;
        }
        function onUp() {
            $(document).off('mousemove.pipCol', onMove).off('mouseup.pipCol', onUp);
            $handle.removeClass('is-active');
            $('body').removeClass('pip-col-resizing');
            persistOrderColWidths(readOrderColWidthsFromDom());
        }
        $(document).on('mousemove.pipCol', onMove).on('mouseup.pipCol', onUp);
    });
}

function medColKeysForView(view) {
    if (view === 'off') return MED_COL_KEYS_OFF.slice();
    if (view === 'oneday') return MED_COL_KEYS_ONEDAY.slice();
    return MED_COL_KEYS_CONT.slice();
}

function medTh(col, label, extraClass, title) {
    const cls = extraClass ? (' class="' + extraClass + '"') : '';
    const tip = title
        ? (' title="' + esc(title) + ' — ลากขอบขวาเพื่อปรับความกว้าง"')
        : ' title="ลากขอบขวาเพื่อปรับความกว้าง"';
    return '<th data-col="' + esc(col) + '"' + cls + tip + '>' + label + '<span class="col-resize-handle"></span></th>';
}

function buildMedColgroup(view) {
    const keys = medColKeysForView(view);
    let html = '';
    keys.forEach(function (k) {
        const w = parseInt((MED_COL_WIDTHS && MED_COL_WIDTHS[k]) || 0, 10) || 60;
        html += '<col data-col="' + esc(k) + '" style="width:' + w + 'px">';
    });
    $('#pipMedCols').html(html);
}

function applyMedColWidths(widths) {
    MED_COL_WIDTHS = Object.assign({}, MED_COL_WIDTHS || {}, widths || {});
    MED_COL_KEYS_ALL.forEach(function (k) {
        const w = parseInt(MED_COL_WIDTHS[k], 10);
        if (!w || w < 32) return;
        $('#pipMedCols col[data-col="' + k + '"]').css('width', w + 'px');
    });
}

function readMedColWidthsFromDom() {
    const out = Object.assign({}, MED_COL_WIDTHS || {});
    $('#pipMedCols col[data-col]').each(function () {
        const k = String($(this).attr('data-col') || '');
        if (!k) return;
        const w = Math.round(this.getBoundingClientRect().width || parseInt(this.style.width, 10) || 0);
        if (w >= 32) out[k] = w;
    });
    return out;
}

function persistMedColWidths(widths) {
    const norm = Object.assign({}, MED_COL_WIDTHS || {}, widths || {});
    MED_COL_WIDTHS = norm;
    if (medColSaveTimer) clearTimeout(medColSaveTimer);
    medColSaveTimer = setTimeout(function () {
        fetch('fetch_patient_ipd_api.php?action=med_cols_save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ action: 'med_cols_save', widths: norm })
        }).catch(function () {});
    }, 400);
}

function initMedColResize() {
    applyMedColWidths(MED_COL_WIDTHS);
    const $table = $('#medTable');
    $table.on('mousedown', '.col-resize-handle', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const $th = $(this).closest('th');
        const colKey = String($th.attr('data-col') || '');
        if (!colKey) return;
        const $col = $('#pipMedCols col[data-col="' + colKey + '"]');
        if (!$col.length) return;
        const startX = e.clientX;
        const startW = Math.round($col[0].getBoundingClientRect().width || parseInt($col.css('width'), 10) || 80);
        const $handle = $(this).addClass('is-active');
        $('body').addClass('pip-col-resizing');

        function onMove(ev) {
            const next = Math.max(32, Math.min(640, startW + (ev.clientX - startX)));
            $col.css('width', next + 'px');
            MED_COL_WIDTHS[colKey] = next;
        }
        function onUp() {
            $(document).off('mousemove.pipMedCol', onMove).off('mouseup.pipMedCol', onUp);
            $handle.removeClass('is-active');
            $('body').removeClass('pip-col-resizing');
            persistMedColWidths(readMedColWidthsFromDom());
        }
        $(document).on('mousemove.pipMedCol', onMove).on('mouseup.pipMedCol', onUp);
    });
}

function saveDispense() {
    selectedOrderNo = orderNoStr(selectedOrderNo);
    if (!STATE || !STATE.admission || !selectedOrderNo) {
        toast('กรุณาคลิกเลือก Order ก่อน แล้วกดบันทึกจ่าย', 'err');
        return;
    }
    const o = findOrder(selectedOrderNo);
    if (!o) {
        toast('ไม่พบ Order ที่เลือก — คลิกแถว Order อีกครั้ง', 'err');
        return;
    }
    const an = orderNoStr(STATE.admission.an);
    const hn = orderNoStr((STATE.patient && STATE.patient.hn) || '');
    $('#btnDispenseSave').prop('disabled', true).addClass('is-disabled');
    fetch('fetch_patient_ipd_api.php?action=dispense_save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'dispense_save',
            an: an,
            hn: hn,
            order_no: selectedOrderNo
        })
    })
        .then(function (r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.json();
        })
        .then(function (data) {
            if (!data || !data.ok) {
                toast((data && data.error) ? data.error : 'บันทึกผู้จ่ายไม่สำเร็จ', 'err');
                updateDispenseButtons();
                return;
            }
            patchOrderDispense(selectedOrderNo, data);
            renderOrders(filteredOrders(), selectedOrderNo);
            const t = data.dispensed_at_display || fmtDispenseTime(data.dispensed_at);
            toast('บันทึกจ่ายแล้ว: ' + (data.dispense_name || defaultDispenserName()) + (t ? (' · ' + t) : ''), 'ok');
        })
        .catch(function (err) {
            toast('เชื่อมต่อไม่สำเร็จ' + (err && err.message ? (' (' + err.message + ')') : ''), 'err');
            updateDispenseButtons();
        });
}

function cancelDispense() {
    selectedOrderNo = orderNoStr(selectedOrderNo);
    if (!STATE || !STATE.admission || !selectedOrderNo) {
        toast('กรุณาคลิกเลือก Order ก่อน', 'err');
        return;
    }
    const o = findOrder(selectedOrderNo);
    if (!o || !o.is_dispensed) {
        toast('Order นี้ยังไม่ได้บันทึกผู้จ่าย', 'err');
        return;
    }
    $('#btnDispenseCancel').prop('disabled', true).addClass('is-disabled');
    fetch('fetch_patient_ipd_api.php?action=dispense_cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'dispense_cancel',
            an: orderNoStr(STATE.admission.an),
            order_no: selectedOrderNo
        })
    })
        .then(function (r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.json();
        })
        .then(function (data) {
            if (!data || !data.ok) {
                toast((data && data.error) ? data.error : 'ยกเลิกจ่ายไม่สำเร็จ', 'err');
                updateDispenseButtons();
                return;
            }
            patchOrderDispense(selectedOrderNo, data);
            renderOrders(filteredOrders(), selectedOrderNo);
            toast('ยกเลิกผู้จ่ายแล้ว', 'ok');
        })
        .catch(function () {
            toast('เชื่อมต่อไม่สำเร็จ', 'err');
            updateDispenseButtons();
        });
}

function filteredOrderItems(items) {
    items = items || [];
    if (!orderDrugOnly) return items;
    return items.filter(function (it) {
        if (it.is_drug === 1 || it.item_kind === 'drug') return true;
        // รายการเก่าที่ยังไม่มี item_kind → ถือเป็นยา
        if (it.item_kind == null && it.is_nondrug == null) return true;
        return false;
    });
}

function renderItems(items) {
    const all = items || [];
    const list = filteredOrderItems(all);
    $('#chkOrderDrugOnly').prop('checked', !!orderDrugOnly)
        .closest('label').toggleClass('on', !!orderDrugOnly);
    $('#chkOrderUsageCode').prop('checked', USAGE_CODE_MODE)
        .closest('label').toggleClass('on', USAGE_CODE_MODE);
    if (!all.length) {
        $('#pipItemBody').html('<tr><td colspan="6" class="muted" style="text-align:center;padding:16px;">ไม่มีรายการใน Order นี้</td></tr>');
        return;
    }
    if (!list.length) {
        $('#pipItemBody').html('<tr><td colspan="6" class="muted" style="text-align:center;padding:16px;">ไม่มีรายการยาใน Order นี้ (มี Non-drug ' + all.length + ' รายการ)</td></tr>');
        return;
    }
    let html = '';
    let n = 0;
    list.forEach(function (it) {
        n += 1;
        const kind = it.item_kind || (it.is_nondrug ? 'nondrug' : 'drug');
        let cls = kind === 'nondrug' ? 'row-nondrug' : (it.is_injection ? 'row-inj' : 'row-other');
        if (it.robot_missing) cls += ' row-robot-miss';
        const badge = kind === 'nondrug' ? '<span class="pip-kind-nd">Non-drug</span>' : '';
        const usageTxt = medUsageText(it);
        const usageTitle = USAGE_CODE_MODE
            ? (it.usage || it.usage_code || '')
            : (it.usage_code || it.usage || '');
        html += '<tr class="' + cls + '">'
            + '<td class="num">' + n + '</td>'
            + '<td>' + badge + esc(it.name) + '</td>'
            + '<td title="' + esc(usageTitle) + '">' + esc(usageTxt) + '</td>'
            + '<td class="num">' + esc(it.qty) + '</td>'
            + '<td class="num">' + money(it.price) + '</td>'
            + '<td class="code">' + esc(it.icode) + '</td>'
            + '</tr>';
    });
    $('#pipItemBody').html(html);
}

function medUsageText(it) {
    if (USAGE_CODE_MODE) {
        const code = String(it.usage_code || '').trim();
        if (code) return code;
    }
    return it.usage || '';
}

function medHeadHtml(view) {
    if (view === 'off') {
        return '<tr>'
            + medTh('num', '#', 'num')
            + medTh('name', 'ชื่อยา')
            + medTh('usage', 'วิธีใช้', '', USAGE_CODE_MODE ? 'วิธีใช้แบบ code จาก HOSxP' : 'วิธีใช้แบบเต็ม')
            + medTh('qty', 'qty', 'num')
            + medTh('per_dose', 'ต่อครั้ง', 'num', 'ต่อครั้ง จาก drugusage.iperdose')
            + medTh('per_day', 'ต่อวัน', 'num', 'ต่อวัน จาก drugusage.iperday')
            + medTh('orderdate', 'วันที่สั่ง', 'num')
            + medTh('offdate', 'วันที่ off', 'num')
            + medTh('freq', 'ให้ทุก(วัน)', 'num', 'ให้ทุกกี่วัน (จาก HOSxP frequency)')
            + medTh('paydays', 'จ่ายวัน')
            + medTh('qty_day', 'จำนวนสั่ง/วัน', 'num')
            + medTh('pay', 'จ่าย', 'num', 'จำนวนจ่ายสะสม (opitemrece_medplan)')
            + medTh('return', 'คืน', 'num', 'จำนวนคืนสะสม (medreturn_ipd)')
            + medTh('off_staff', 'ผู้หยุดยา')
            + medTh('recorder', 'ผู้บันทึก')
            + '</tr>';
    }
    if (view === 'oneday') {
        return '<tr>'
            + medTh('num', '#', 'num')
            + medTh('name', 'ชื่อยา')
            + medTh('usage', 'วิธีใช้')
            + medTh('qty', 'qty', 'num')
            + medTh('interval', 'Interval', 'num')
            + medTh('per_dose', 'ต่อครั้ง', 'num', 'ต่อครั้ง จาก drugusage.iperdose')
            + medTh('per_day', 'ต่อวัน', 'num', 'ต่อวัน จาก drugusage.iperday')
            + medTh('orderdate', 'วันที่สั่ง', 'num')
            + medTh('order', 'Order')
            + '</tr>';
    }
    // Continuous Active / All / Profile
    return '<tr>'
        + medTh('num', '#', 'num')
        + medTh('name', 'ชื่อยา')
        + medTh('usage', 'วิธีใช้', '', USAGE_CODE_MODE ? 'วิธีใช้แบบ code จาก HOSxP' : 'วิธีใช้แบบเต็ม')
        + medTh('qty', 'qty', 'num')
        + medTh('interval', 'Interval', 'num')
        + medTh('per_dose', 'ต่อครั้ง', 'num', 'ต่อครั้ง จาก drugusage.iperdose')
        + medTh('per_day', 'ต่อวัน', 'num', 'ต่อวัน จาก drugusage.iperday')
        + medTh('orderdate', 'วันที่สั่ง', 'num')
        + medTh('offdate', 'วันที่หยุด', 'num', 'วันที่หยุดยา (offdate ใน HOSxP)')
        + medTh('freq', 'ให้ทุก(วัน)', 'num', 'ให้ทุกกี่วัน (จาก HOSxP frequency)')
        + medTh('paydays', 'จ่ายวัน', '', 'วันจ่ายยาตามที่กำหนด (week_day_check)')
        + medTh('recorder', 'ผู้บันทึก', '', 'ผู้ Key จาก medplan.staff หรือผู้ Key IRx ในวันที่ Last update')
        + medTh('pay', 'จ่าย', 'num', 'จำนวนจ่ายสะสม (opitemrece_medplan)')
        + medTh('return', 'คืน', 'num', 'จำนวนคืนสะสม (medreturn_ipd)')
        + medTh('note', 'note')
        + medTh('first_upd', 'บันทึกวันที่', 'num', 'first_update')
        + medTh('last_upd', 'Last update', 'num', 'last_update')
        + '</tr>';
}

function doseCellHtml(val, warnMiss) {
    const v = (val == null || val === '') ? '' : String(val);
    if (warnMiss && v === '') {
        return '<td class="num cell-miss" title="ยาใน Robot ต้องมีค่า — จะไม่เข้า Robot">-</td>';
    }
    return '<td class="num">' + esc(v) + '</td>';
}

function isOffdateToday(offdate) {
    const d = String(offdate || '').trim().slice(0, 10);
    if (!d || d === '0000-00-00') return false;
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return d === (y + '-' + m + '-' + day);
}

function medRowHtml(it, view, n) {
    let cls = it.is_injection ? 'row-inj' : 'row-other';
    if (it.robot_missing) cls += ' row-robot-miss';
    const start = it.orderdate_dmy || it.orderdate || '';
    const stop = it.offdate_dmy || it.offdate || '';
    const fVal = (it.f_flag != null && it.f_flag !== '') ? it.f_flag : (it.frequency || it.f_days || '');
    const payDays = it.dispense_days || '';
    const recorder = it.key_staff_name || it.recorder || it.staff_name || '';
    const usageTxt = medUsageText(it);
    const usageTitle = USAGE_CODE_MODE
        ? (it.usage || it.usage_code || '')
        : (it.usage_code || it.usage || '');
    const warnDoseMiss = !!it.robot_missing;
    const recTitle = (it.recorder_source === 'irx_last_update' || it.recorder_source === 'irx_first_update')
        ? ('จากผู้ Key IRx · ' + (it.key_staff || ''))
        : (it.key_staff || it.staff_code || '');
    if (view === 'off') {
        return '<tr class="' + cls + '">'
            + '<td class="num">' + n + '</td>'
            + '<td><b>' + esc(it.name) + '</b></td>'
            + '<td title="' + esc(usageTitle) + '">' + esc(usageTxt) + '</td>'
            + '<td class="num">' + esc(it.qty) + '</td>'
            + doseCellHtml(it.per_dose, warnDoseMiss)
            + doseCellHtml(it.per_day, warnDoseMiss)
            + '<td class="num">' + esc(start) + '</td>'
            + '<td class="num">' + esc(stop) + (it.off_time ? (' ' + esc(it.off_time)) : '') + '</td>'
            + '<td class="num" title="ให้ทุก ' + esc(fVal) + ' วัน">' + esc(fVal) + '</td>'
            + '<td>' + esc(payDays) + '</td>'
            + '<td class="num">' + esc(it.qty_day || it.qty || '') + '</td>'
            + '<td class="num">' + esc(it.pay_qty != null ? it.pay_qty : '') + '</td>'
            + '<td class="num">' + esc(it.return_qty != null ? it.return_qty : '') + '</td>'
            + '<td>' + esc(it.off_staff_name || '') + '</td>'
            + '<td title="' + esc(recTitle) + '">' + esc(recorder) + '</td>'
            + '</tr>';
    }
    if (view === 'oneday') {
        return '<tr class="' + cls + '">'
            + '<td class="num">' + n + '</td>'
            + '<td><b>' + esc(it.name) + '</b></td>'
            + '<td title="' + esc(usageTitle) + '">' + esc(usageTxt) + '</td>'
            + '<td class="num">' + esc(it.qty) + '</td>'
            + '<td class="num">' + esc(it.interval || '') + '</td>'
            + doseCellHtml(it.per_dose, warnDoseMiss)
            + doseCellHtml(it.per_day, warnDoseMiss)
            + '<td class="num">' + esc(start) + '</td>'
            + '<td class="code">' + esc(it.order_type || '') + ' ' + esc(it.order_no || '') + '</td>'
            + '</tr>';
    }
    const stopToday = (view === 'active' && isOffdateToday(it.offdate));
    const stopTd = stopToday
        ? '<td class="num cell-off-today" title="วันที่หยุดตรงกับวันนี้">' + esc(stop) + '</td>'
        : '<td class="num">' + esc(stop) + '</td>';
    return '<tr class="' + cls + '">'
        + '<td class="num">' + n + '</td>'
        + '<td><b>' + esc(it.name) + '</b></td>'
        + '<td title="' + esc(usageTitle) + '">' + esc(usageTxt) + '</td>'
        + '<td class="num">' + esc(it.qty) + '</td>'
        + '<td class="num">' + esc(it.interval || '') + '</td>'
        + doseCellHtml(it.per_dose, warnDoseMiss)
        + doseCellHtml(it.per_day, warnDoseMiss)
        + '<td class="num">' + esc(start) + '</td>'
        + stopTd
        + '<td class="num" title="ให้ทุก ' + esc(fVal) + ' วัน">' + esc(fVal) + '</td>'
        + '<td title="' + (it.week_day_check === 'Y' ? 'เปิดใช้วันจ่ายยาตามที่กำหนด' : '') + '">' + esc(payDays) + '</td>'
        + '<td title="' + esc(recTitle) + '">' + esc(recorder) + '</td>'
        + '<td class="num">' + esc(it.pay_qty != null ? it.pay_qty : '') + '</td>'
        + '<td class="num">' + esc(it.return_qty != null ? it.return_qty : '') + '</td>'
        + '<td>' + esc(it.note || '') + '</td>'
        + '<td class="num">' + esc(it.first_update_dmy || '') + '</td>'
        + '<td class="num">' + esc(it.last_update_dmy || '') + '</td>'
        + '</tr>';
}

function renderMedRows(groups, view) {
    view = view || medView;
    const inj = (groups && groups.injection) || [];
    const other = (groups && groups.other) || [];
    const colSpan = (view === 'off') ? 15 : (view === 'oneday' ? 9 : 17);
    buildMedColgroup(view);
    $('#pipMedHead').html(medHeadHtml(view));
    applyMedColWidths(MED_COL_WIDTHS);
    if (!inj.length && !other.length) {
        $('#pipMedBody').html('<tr><td colspan="' + colSpan + '" class="muted" style="text-align:center;padding:18px;">ไม่มีรายการยา</td></tr>');
        return;
    }
    let html = '';
    let n = 0;
    function block(title, cls, rows) {
        if (!rows.length) return;
        html += '<tr class="' + cls + '"><th colspan="' + colSpan + '">' + esc(title) + ' (' + rows.length + ')</th></tr>';
        rows.forEach(function (it) {
            n += 1;
            html += medRowHtml(it, view, n);
        });
    }
    block('Injection Form', 'grp-inj', inj);
    block('Other Form', 'grp-other', other);
    $('#pipMedBody').html(html);
}

function updateTabCounts() {
    const c = (STATE && STATE.counts) || {};
    const map = {
        active: c.active,
        off: c.off,
        all: c.all,
        oneday: c.oneday,
        profile: c.active
    };
    $('#rightTabs .pip-tab').each(function () {
        const key = $(this).data('med');
        $(this).find('.badge-n').remove();
        const n = map[key];
        if (n != null && n !== '') {
            $(this).append('<span class="badge-n">' + n + '</span>');
        }
    });
}

function setMedView(view) {
    medView = view || 'active';
    $('#rightTabs .pip-tab').removeClass('active');
    $('#rightTabs .pip-tab[data-med="' + medView + '"]').addClass('active');
    const titles = {
        active: 'รายการยา Continuous (Active)',
        off: 'รายการยา OFF Continuous',
        all: 'รายการยา Continuous ทั้งหมด',
        oneday: 'รายการยา Oneday ทั้งหมด',
        profile: 'Drug Profile (Active Continuous)'
    };
    $('#medSecTitle').text(titles[medView] || titles.active);
    if (!STATE) {
        renderMedRows({ injection: [], other: [] }, medView);
        return;
    }
    const key = medView === 'profile' ? 'active' : medView;
    const groups = (STATE.groups && STATE.groups[key]) || { injection: [], other: [] };
    renderMedRows(groups, medView === 'profile' ? 'active' : medView);
}

function renderAdmits(list, currentAn) {
    if (!list || !list.length) {
        $('#pipAdmitList').html('<div class="muted p-3">ไม่มีประวัติ Admit</div>');
        return;
    }
    let html = '';
    list.forEach(function (a) {
        const cls = a.an === currentAn ? ' active' : '';
        html += '<button type="button" class="admit-row' + cls + '" data-an="' + esc(a.an) + '">'
            + '<div class="an">AN ' + esc(a.an) + (a.is_active ? ' · Admit อยู่' : '') + '</div>'
            + '<div class="meta">' + esc(a.regdate) + (a.regtime ? (' ' + esc(a.regtime)) : '')
            + ' · ' + esc(a.ward_name || '-')
            + (a.dchdate ? (' · จำหน่าย ' + esc(a.dchdate)) : '')
            + '</div></button>';
    });
    $('#pipAdmitList').html(html);
}

function renderMr(data) {
    const al = data.allergy || {};
    const a = data.admission || {};
    const p = data.patient || {};
    let html = '<div style="line-height:1.6">';
    html += '<div><b>ผู้ป่วย:</b> ' + esc(p.full_name || '-') + '</div>';
    html += '<div><b>HN:</b> ' + esc(p.hn_display || p.hn || '-') + ' &nbsp; <b>AN:</b> ' + esc(a.an || '-') + '</div>';
    html += '<div><b>Ward:</b> ' + esc(a.ward_name || '-') + '</div>';
    html += '<div><b>แพทย์ Admit:</b> ' + esc(a.doctor_name || '-') + '</div>';
    html += '<div><b>สิทธิ์:</b> ' + esc(a.pttype_name || '-') + '</div>';
    html += '<div style="margin-top:8px;"><b>แพ้ยา:</b> '
        + (al.has_allergy ? ('<span style="color:#c0392b;font-weight:800;">' + esc(al.text || '-') + '</span>') : 'ไม่แพ้ยา')
        + '</div>';
    if (data.dx && data.dx.text) {
        html += '<div style="margin-top:8px;"><b>CC/Dx:</b> <span style="color:#c0392b;font-weight:800;">' + esc(data.dx.text) + '</span></div>';
    }
    const labHtml = formatLabStripHtml(data.labs || {});
    if (labHtml) {
        html += '<div style="margin-top:8px;" class="pip-labbox">' + labHtml + '</div>';
    }
    html += '</div>';
    $('#pipMrBox').html(html);
}

function renderHosxpNotes(notes) {
    const body = document.getElementById('pipHosxpNotesBody');
    if (!body) return;
    if (!notes || !notes.length) {
        body.innerHTML = '<div class="pip-note-empty">ไม่มี Note จากระบบ HOSxP</div>';
        return;
    }
    let html = '<table class="pip-note-table"><thead><tr>'
        + '<th>plain_text</th><th>note_staff</th><th>note_datetime</th><th>has_expired</th>'
        + '</tr></thead><tbody>';
    notes.forEach(function (n) {
        const staff = esc(n.note_staff || n.staff || '')
            + (n.staff_name ? '<br><small>' + esc(n.staff_name) + '</small>' : '');
        const dt = n.note_datetime_be || n.note_date_be || '';
        const exp = n.expire_date_be || (n.has_expired ? 'Y' : '');
        html += '<tr>'
            + '<td class="pip-note-text">' + esc(n.plain_text || n.text || '') + '</td>'
            + '<td class="pip-note-staff">' + staff + '</td>'
            + '<td class="pip-note-date">' + esc(dt) + '</td>'
            + '<td class="pip-note-exp">' + esc(exp) + '</td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    body.innerHTML = html;
}

function openHosxpNotes() {
    renderHosxpNotes((STATE && STATE.hosxp_notes) || []);
    $('#pipHosxpNotes').css('display', 'flex');
}

function syncHosxpNotesBtn(data) {
    const notes = (data && data.hosxp_notes) || [];
    $('#noteHosxpCnt').text(notes.length);
    $('#btnHosxpNotes').toggleClass('is-disabled', !notes.length)
        .prop('disabled', !notes.length)
        .attr('title', notes.length ? ('Note จาก HOSxP (' + notes.length + ')') : 'ไม่มี Note จาก HOSxP');
}

let DV_ITEMS = [];
let DV_ACTIVE_ID = 0;

function currentPatientIds() {
    const hn = ((STATE && STATE.patient && (STATE.patient.hn_display || STATE.patient.hn)) || $('#pipHn').val() || '').toString().trim();
    const an = ((STATE && STATE.patient && (STATE.patient.an_display || STATE.patient.an)) || $('#pipAn').val() || '').toString().trim();
    return { hn: hn, an: an };
}

function dvTypeBadge(it) {
    const t = String(it.scr_type || '');
    const name = esc(it.type_name || '');
    if (t === '1') return '<span class="pip-dv-badge urgent">' + name + '</span>';
    if (t === '3') return '<span class="pip-dv-badge home">' + name + '</span>';
    return '<span class="pip-dv-badge">' + name + '</span>';
}

function renderDrugViewerList() {
    const typeF = String($('#pipDvTypeFilter').val() || '');
    const items = DV_ITEMS.filter(function (it) {
        return !typeF || String(it.scr_type) === typeF;
    });
    $('#pipDvCount').text(items.length + ' รายการ');
    const box = document.getElementById('pipDvList');
    if (!box) return;
    if (!items.length) {
        box.innerHTML = '<div class="pip-dv-empty">ไม่พบใบยาสแกน</div>';
        return;
    }
    box.innerHTML = items.map(function (it) {
        const active = Number(it.id) === Number(DV_ACTIVE_ID) ? ' active' : '';
        const payCls = String(it.pay) === '1' ? ' paid' : '';
        return '<button type="button" class="pip-dv-item' + active + '" data-id="' + Number(it.id) + '">'
            + '<div class="t1">' + esc(it.datescan || '-') + '</div>'
            + '<div class="t2">' + esc(it.ward_name || it.ward || '-') + (it.user_name ? (' · ' + esc(it.user_name)) : '') + '</div>'
            + '<div class="t3">' + dvTypeBadge(it)
            + '<span class="pip-dv-badge' + payCls + '">' + esc(it.pay_label || '') + '</span>'
            + (it.note ? ('<span class="pip-dv-badge">' + esc(it.note) + '</span>') : '')
            + '</div></button>';
    }).join('');
}

function showDrugViewerScan(id) {
    id = Number(id) || 0;
    DV_ACTIVE_ID = id;
    renderDrugViewerList();
    const it = DV_ITEMS.find(function (x) { return Number(x.id) === id; });
    const url = 'fetch_patient_ipd_api.php?action=drug_viewer_image&id=' + id;
    if (!it || !it.has_image) {
        $('#pipDvFrame').hide().attr('src', 'about:blank');
        $('#pipDvViewEmpty').show().text('ไม่มีไฟล์สแกนสำหรับรายการนี้');
        $('#pipDvViewTitle').text('—');
        $('#pipDvOpenTab').hide();
        return;
    }
    $('#pipDvViewEmpty').hide();
    $('#pipDvFrame').show().attr('src', url);
    $('#pipDvViewTitle').text((it.type_name || 'สแกน') + ' · ' + (it.datescan || ''));
    $('#pipDvOpenTab').attr('href', url).show();
}

function closeDrugViewer() {
    $('#pipDrugViewer').hide().attr('aria-hidden', 'true');
    $('#pipDvFrame').attr('src', 'about:blank').hide();
    $('#pipDvViewEmpty').show().text('เลือกใบยาสแกนจากรายการทางซ้ายเพื่อดูไฟล์ PDF');
    DV_ACTIVE_ID = 0;
}

/** เวลา IRx จาก order → 'YYYY-MM-DD HH:MM:SS' (สแกน Drug Viewer มักมาก่อนเวลา key ใน HOSxP) */
function orderRxAtIso(o) {
    if (!o) return '';
    const d = String(o.rxdate || '').slice(0, 10);
    let t = String(o.rxtime || '').trim();
    function pad(n) { return String(n).padStart(2, '0'); }
    if (/^\d{4}-\d{2}-\d{2}$/.test(d)) {
        if (!t) t = '23:59:59';
        else if (/^\d{1,2}:\d{2}$/.test(t)) t = pad(t.split(':')[0]) + ':' + t.split(':')[1] + ':00';
        else if (/^\d{1,2}:\d{2}:\d{2}$/.test(t)) {
            const p = t.split(':');
            t = pad(p[0]) + ':' + p[1] + ':' + p[2];
        }
        return d + ' ' + t;
    }
    const raw = orderDateTimeRaw(o);
    const m = String(raw).match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if (m) {
        return m[3] + '-' + pad(m[2]) + '-' + pad(m[1]) + ' ' + pad(m[4]) + ':' + m[5] + ':' + pad(m[6] || 0);
    }
    return '';
}

function pickScanForRxAtLocal(items, rxAt) {
    const list = items || [];
    if (!list.length) return null;
    const m = String(rxAt || '').match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if (!m) return list[0];
    const target = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)).getTime();
    const day = m[1] + '-' + m[2] + '-' + m[3];
    const sameDay = list.filter(function (it) { return String(it.datescan || '').slice(0, 10) === day; });
    const pool = sameDay.length ? sameDay : list;
    let bestBefore = null, bestBeforeDiff = Infinity, bestAny = null, bestAnyDiff = Infinity;
    pool.forEach(function (it) {
        const sm = String(it.datescan || '').match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/);
        if (!sm) return;
        const t = new Date(+sm[1], +sm[2] - 1, +sm[3], +sm[4], +sm[5], +(sm[6] || 0)).getTime();
        const diff = Math.abs(target - t);
        if (diff < bestAnyDiff) { bestAnyDiff = diff; bestAny = it; }
        if (t <= target && (target - t) < bestBeforeDiff) { bestBeforeDiff = target - t; bestBefore = it; }
    });
    return bestBefore || bestAny || list[0];
}

function openDrugViewerModalFallback(ids, opts) {
    opts = opts || {};
    let meta = 'HN ' + (ids.hn || '-') + ' · AN ' + (ids.an || '-');
    if (opts.rxAt) meta += ' · จับคู่ IRx ' + opts.rxAt;
    $('#pipDvMeta').text(meta);
    $('#pipDvList').html('<div class="pip-dv-empty">กำลังโหลด…</div>');
    $('#pipDvCount').text('…');
    $('#pipDvFrame').hide().attr('src', 'about:blank');
    $('#pipDvViewEmpty').show().text('เลือกใบยาสแกนจากรายการทางซ้ายเพื่อดูไฟล์ PDF');
    $('#pipDvOpenTab').hide();
    $('#pipDrugViewer').css('display', 'flex').attr('aria-hidden', 'false');
    const qs = new URLSearchParams({ action: 'drug_viewer_scans', hn: ids.hn, an: ids.an, limit: '100' });
    fetch('fetch_patient_ipd_api.php?' + qs.toString(), { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data || !data.ok) {
                DV_ITEMS = [];
                $('#pipDvList').html('<div class="pip-dv-empty">' + esc((data && data.message) || 'โหลดไม่สำเร็จ') + '</div>');
                $('#pipDvCount').text('0 รายการ');
                return;
            }
            DV_ITEMS = data.items || [];
            renderDrugViewerList();
            let pick = null;
            if (opts.rxAt) pick = pickScanForRxAtLocal(DV_ITEMS, opts.rxAt);
            if (!pick && DV_ITEMS.length) pick = DV_ITEMS[0];
            if (pick) showDrugViewerScan(pick.id);
        })
        .catch(function () {
            DV_ITEMS = [];
            $('#pipDvList').html('<div class="pip-dv-empty">เชื่อมต่อ Drug Viewer ไม่สำเร็จ</div>');
            $('#pipDvCount').text('0 รายการ');
        });
}

let DV_OPEN_TS = 0;
let DV_WIN_REF = null;

/** อ่านพิกัด Drug Viewer ที่เครื่องนี้เคยบันทึกไว้ (localStorage) */
function drugViewerReadSavedGeom() {
    try {
        if (!window.localStorage) return null;
        const left = parseInt(localStorage.getItem('drugViewer_left'), 10);
        const top = parseInt(localStorage.getItem('drugViewer_top'), 10);
        const width = parseInt(localStorage.getItem('drugViewer_width'), 10);
        const height = parseInt(localStorage.getItem('drugViewer_height'), 10);
        if (![left, top, width, height].every(function (n) { return Number.isFinite(n); })) {
            return null;
        }
        if (width < 300 || height < 300 || width > 8000 || height > 8000) {
            return null;
        }
        return {
            left: Math.round(left),
            top: Math.round(top),
            width: Math.round(width),
            height: Math.round(height)
        };
    } catch (e) {
        return null;
    }
}

/**
 * พิกัดเริ่มต้นเมื่อยังไม่เคยบันทึก
 * - จอ 2 ทางซ้าย: screen.availLeft < 0 → left = availLeft
 * - จอ 2 ทางขวา: left = screen.width
 * - จอเดียว: เปิดชิดขวาของจอหลัก (ไม่ดีดนอกจอ / ไม่ error)
 */
function drugViewerDefaultGeom() {
    let availLeft = 0;
    let availTop = 0;
    let availW = 1280;
    let availH = 900;
    let primaryW = 1280;
    try {
        availLeft = (typeof screen.availLeft === 'number') ? screen.availLeft : 0;
        availTop = (typeof screen.availTop === 'number') ? screen.availTop : 0;
        availW = screen.availWidth || screen.width || 1280;
        availH = screen.availHeight || window.innerHeight || 900;
        primaryW = screen.width || availW;
    } catch (e) {}

    let left;
    let top = 0;
    let width = 1024;
    let height = Math.max(600, availH);

    if (availLeft < 0) {
        left = availLeft;
    } else {
        left = primaryW;
    }

    // จอเดียว: ไม่มีพื้นที่ desktop เลยขอบจอหลัก → เปิดชิดขวาบนจอหลัก
    const desktopRight = availLeft + availW;
    const seemsDual = (availLeft < 0) || (desktopRight > primaryW + 80);
    if (!seemsDual) {
        width = Math.min(1024, Math.max(480, Math.floor(availW * 0.48)));
        height = Math.max(600, availH - 24);
        left = Math.round(availLeft + Math.max(0, availW - width - 8));
        top = availTop;
    } else {
        width = Math.min(Math.max(480, width), 2400);
        height = Math.min(Math.max(600, height), 4000);
    }

    return {
        left: Math.round(left),
        top: Math.round(top),
        width: Math.round(width),
        height: Math.round(height)
    };
}

function drugViewerResolveGeom() {
    return drugViewerReadSavedGeom() || drugViewerDefaultGeom();
}

function placeDrugViewerWin(win, geom) {
    if (!win || !geom) return;
    try {
        if (typeof win.moveTo === 'function') win.moveTo(geom.left, geom.top);
        if (typeof win.resizeTo === 'function') win.resizeTo(geom.width, geom.height);
        win.focus();
    } catch (e) {
        // cross-origin / ถูก browser จำกัด — ไม่ throw ออกนอก
    }
}

/** เปิดหน้าต่าง Drug Viewer เพียง 1 อัน — จำพิกัดจอ 2 ต่อเครื่องผ่าน localStorage */
function openDrugViewerPopup(url) {
    closeDrugViewer(); // ปิด modal ในหน้าเดิมถ้าค้างอยู่
    const geom = drugViewerResolveGeom();
    const feat = [
        'width=' + geom.width,
        'height=' + geom.height,
        'left=' + geom.left,
        'top=' + geom.top,
        'resizable=yes',
        'scrollbars=yes'
    ].join(',');
    let win = null;
    try {
        win = window.open(url, 'pip_drug_viewer', feat);
    } catch (e) {
        win = null;
    }
    if (!win) {
        return false;
    }
    DV_WIN_REF = win;
    // ตัด reference กลับมาหน้าหลัก — ลดความเสี่ยง scripting ข้ามหน้าต่าง
    try { win.opener = null; } catch (e) {}
    try {
        // ถ้าหน้าต่างเดิมเปิดอยู่และ URL ต่าง (เช่น rx_at คนละเวลา) → รีโหลดเพื่อจับคู่ใบสแกนใหม่
        const abs = new URL(url, window.location.href).href;
        if (String(win.location.href || '') !== abs) {
            win.location.href = url;
        }
    } catch (e) {
        try { win.location.href = url; } catch (e2) {}
    }
    placeDrugViewerWin(win, geom);
    return true;
}

function openDrugViewer(opts) {
    opts = opts || {};
    const ids = currentPatientIds();
    if (!ids.hn && !ids.an) {
        alert('กรุณาค้นหาผู้ป่วยก่อน (HN/AN)');
        return;
    }
    const qs = new URLSearchParams();
    if (ids.hn) qs.set('hn', ids.hn);
    if (ids.an) qs.set('an', ids.an);
    if (opts.rxAt) qs.set('rx_at', opts.rxAt);
    if (opts.orderNo) qs.set('order_no', opts.orderNo);
    const url = 'drug_viewer_win.php?' + qs.toString();
    // กันดับเบิลคลิกเฉพาะ URL เดิม — ถ้าเปลี่ยนเวลา IRx ให้เปิด/รีโหลดได้
    const now = Date.now();
    if (now - DV_OPEN_TS < 500 && DV_WIN_REF && !DV_WIN_REF.closed) {
        try {
            if (String(DV_WIN_REF.location.href || '').indexOf(url) >= 0) return;
        } catch (e) {}
    }
    DV_OPEN_TS = now;
    const ok = openDrugViewerPopup(url);
    if (!ok) {
        openDrugViewerModalFallback(ids, opts);
    }
}

function renderAllergyAlert(items) {
    const body = document.getElementById('pipAllergyAlertBody');
    if (!body) return;
    if (!items || !items.length) {
        body.innerHTML = '<div class="pip-allergy-empty">ไม่มีประวัติแพ้ยา</div>';
        return;
    }
    let html = '<table class="pip-allergy-table"><thead><tr>'
        + '<th>วันที่บันทึก</th><th>รายการที่แพ้</th><th>อาการที่แพ้</th>'
        + '<th>Note</th><th>ระดับ</th><th>ผู้บันทึก</th>'
        + '</tr></thead><tbody>';
    items.forEach(function (it) {
        html += '<tr>'
            + '<td class="num">' + esc(it.report_date_dmy || it.report_date_be || it.report_date || '') + '</td>'
            + '<td class="agent">' + esc(it.agent || '') + '</td>'
            + '<td>' + esc(it.symptom || '') + '</td>'
            + '<td>' + esc(it.note || '') + '</td>'
            + '<td>' + esc(it.level || '') + '</td>'
            + '<td class="num">' + esc(it.reporter || '') + '</td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    body.innerHTML = html;
}

function openAllergyAlert() {
    const al = (STATE && STATE.allergy) || {};
    renderAllergyAlert(al.items || []);
    $('#pipAllergyAlert').css('display', 'flex');
}

function syncDayAheadBtn(data) {
    const alerts = (data && data.day_ahead_alerts) || [];
    const n = alerts.length;
    $('#dayAheadCnt').text(n);
    $('#btnDayAheadAlert').prop('disabled', !n)
        .toggleClass('is-disabled', !n)
        .toggleClass('is-blink', n > 0)
        .attr('title', n ? ('พบ ' + n + ' รายการที่จ่ายวันยังไม่ครบ/ไม่ตรง') : 'ไม่พบรายการแจ้งเตือนตั้งจ่ายตามวัน');
}

function syncRobotBtn(data) {
    const alerts = (data && data.robot_missing_alerts) || [];
    const n = alerts.length;
    $('#robotMissCnt').text(n);
    $('#btnRobotAlert').prop('disabled', !n)
        .toggleClass('is-disabled', !n)
        .toggleClass('is-blink', n > 0)
        .attr('title', n
            ? ('พบ ' + n + ' รายการ TAB/CAP ที่ไม่มีต่อครั้ง/ต่อวัน — จะไม่เข้า Robot')
            : 'ไม่พบรายการที่ไม่เข้า Robot');
}

function renderRobotAlert(alerts) {
    const body = document.getElementById('pipRobotAlertBody');
    if (!body) return;
    if (!alerts || !alerts.length) {
        body.innerHTML = '<div class="pip-note-empty">ไม่มีรายการ</div>';
        return;
    }
    let html = '<div style="padding:8px 12px;font-size:12.5px;color:#5a7380;">'
        + 'รายการที่ตั้งไว้ใน <b>ยาใน Robot</b> ต้องมี <b>ต่อครั้ง</b> และ <b>ต่อวัน</b> จากวิธีใช้ HOSxP '
        + '— ถ้าไม่มีจะ<b style="color:#b71c1c;">ไม่เข้า Robot</b></div>';
    html += '<table class="pip-robot-table"><thead><tr>'
        + '<th>ชื่อยา</th><th>วิธีใช้</th><th class="num">ต่อครั้ง</th><th class="num">ต่อวัน</th><th>รายละเอียด</th>'
        + '</tr></thead><tbody>';
    alerts.forEach(function (a) {
        html += '<tr>'
            + '<td><b>' + esc(a.name || '') + '</b></td>'
            + '<td>' + esc(a.usage || a.usage_code || '') + '</td>'
            + '<td class="num' + (!a.per_dose ? ' cell-miss' : '') + '">' + esc(a.per_dose || '-') + '</td>'
            + '<td class="num' + (!a.per_day ? ' cell-miss' : '') + '">' + esc(a.per_day || '-') + '</td>'
            + '<td>' + esc(a.message || '') + '</td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    body.innerHTML = html;
}

function openRobotAlert() {
    renderRobotAlert((STATE && STATE.robot_missing_alerts) || []);
    $('#pipRobotAlert').css('display', 'flex');
}

function syncAlertPharmaBtn(result) {
    const alerts = (result && result.alerts) || [];
    const n = alerts.length || (result && result.alert_count) || 0;
    const has = !!(result && result.has_alert && n);
    const passed = !!(result && !result.skipped && !has && ((result.module_results || []).length || result.pass_count));
    const passN = (result && result.pass_count) || 0;
    const $btn = $('#btnAlertPharma');
    // ตัวเลขบนปุ่ม = จำนวน Alert เท่านั้น (ไม่นับโมดูลที่ผ่าน)
    $('#alertPharmaCnt').text(n);
    if (has) {
        $btn.prop('disabled', false)
            .toggleClass('is-disabled', false)
            .toggleClass('is-blink', true)
            .toggleClass('is-pass', false)
            .attr('title', 'พบ Alert Pharma ' + n + ' รายการ');
        if (STATE) {
            const cur = String($('#pipStatus').text() || '');
            if (cur && cur.indexOf('Alert Pharma') < 0) {
                $('#pipStatus').text(cur + ' · Alert Pharma ' + n);
            }
        }
        return;
    }
    if (passed) {
        $btn.prop('disabled', false)
            .toggleClass('is-disabled', false)
            .toggleClass('is-blink', false)
            .toggleClass('is-pass', true)
            .attr('title', 'Smart Pharma Pass — ผ่าน ' + passN + ' โมดูล (Alert 0)');
        return;
    }
    $btn.prop('disabled', true)
        .toggleClass('is-disabled', true)
        .toggleClass('is-blink', false)
        .toggleClass('is-pass', false)
        .attr('title', 'ไม่พบ Alert Pharma');
}

function renderAlertPharmaAlert(result) {
    const body = document.getElementById('pipAlertPharmaBody');
    if (!body) return;
    const alerts = (result && result.alerts) || [];
    if (!alerts.length) {
        body.innerHTML = '<div class="pip-note-empty">ไม่พบ Alert</div>';
        return;
    }
    let html = '<div style="padding:0 0 8px;font-size:12.5px;color:#5a7380;">'
        + 'คัดกรองตาม HN (Smart Pharma · IPD) — พบ <b style="color:#b71c1c;">' + alerts.length + '</b> รายการ</div>';
    alerts.forEach(function (a) {
        const hard = String(a.level || '').toLowerCase() === 'hard';
        html += '<div class="pip-pharma-card ' + (hard ? 'hard' : 'soft') + '">'
            + '<div class="ttl">' + (hard ? '🔴 ' : '🟡 ')
            + esc(a.module_label || a.module_key || '')
            + ' <span class="badge" style="background:' + (hard ? '#ef5350;color:#fff' : '#ffca28;color:#4e342e')
            + ';font-size:10px;font-weight:800;padding:2px 6px;border-radius:4px;">'
            + esc((a.level || '').toUpperCase()) + '</span></div>'
            + '<div>' + esc(a.summary || '') + '</div>'
            + '</div>';
    });
    body.innerHTML = html;
}

function openAlertPharmaAlert() {
    renderAlertPharmaAlert(ALERT_PHARMA_RESULT);
    $('#pipAlertPharma').css('display', 'flex');
}

function renderAlertPharmaPass(result) {
    const body = document.getElementById('pipAlertPharmaPassBody');
    const sub = document.getElementById('pipAlertPharmaPassSub');
    if (!body) return;
    const mods = (result && result.module_results) || [];
    const passMods = mods.filter(function (m) { return m.status === 'pass'; });
    const otherMods = mods.filter(function (m) { return m.status !== 'pass'; });
    const passN = passMods.length || (result && result.pass_count) || 0;
    if (sub) {
        sub.textContent = passN
            ? ('คัดกรองผ่าน · ' + passN + ' โมดูล')
            : 'คัดกรองผ่าน — ไม่พบ Alert';
    }
    if (!mods.length) {
        body.innerHTML = '<div style="text-align:center;padding:18px;color:rgba(236,253,245,.8);font-weight:700;">ไม่มีรายละเอียดโมดูล</div>';
        return;
    }
    let html = '<div class="pip-pass-grid">';
    passMods.forEach(function (m) {
        html += '<div class="pip-pass-chip">'
            + '<div class="ico"><i class="fas fa-check"></i></div>'
            + '<div><div class="lbl">' + esc(m.module_label || m.module_key || '') + '</div>'
            + (m.summary ? '<div class="sum">' + esc(m.summary) + '</div>' : '')
            + '</div></div>';
    });
    otherMods.forEach(function (m) {
        html += '<div class="pip-pass-chip na">'
            + '<div class="ico"><i class="fas fa-minus"></i></div>'
            + '<div><div class="lbl">' + esc(m.module_label || m.module_key || '') + '</div>'
            + '<div class="sum">' + esc(m.summary || 'ไม่เกี่ยวข้อง') + '</div>'
            + '</div></div>';
    });
    html += '</div>';
    body.innerHTML = html;
}

function openAlertPharmaPass() {
    renderAlertPharmaPass(ALERT_PHARMA_RESULT);
    $('#pipAlertPharmaPass').css('display', 'flex');
}

function runAlertPharmaScreen(data) {
    const seq = ++alertPharmaSeq;
    ALERT_PHARMA_RESULT = { has_alert: false, alert_count: 0, alerts: [], module_results: [], pass_count: 0 };
    syncAlertPharmaBtn(ALERT_PHARMA_RESULT);
    const settings = ALERT_PHARMA_SETTINGS || {};
    if (settings.enabled === false) {
        alertPharmaPending = Promise.resolve(ALERT_PHARMA_RESULT);
        return alertPharmaPending;
    }
    const hn = (data && data.patient && (data.patient.hn || data.patient.hn_display)) || $('#pipHn').val() || '';
    const an = (data && data.admission && data.admission.an) || $('#pipAn').val() || '';
    if (!String(hn).trim()) {
        alertPharmaPending = Promise.resolve(ALERT_PHARMA_RESULT);
        return alertPharmaPending;
    }
    const qs = new URLSearchParams({
        action: 'alert_pharma_screen',
        hn: String(hn).trim(),
        an: String(an).trim()
    });
    alertPharmaPending = fetch('fetch_patient_ipd_api.php?' + qs.toString())
        .then(function (r) { return r.json(); })
        .then(function (res) {
            if (seq !== alertPharmaSeq) return ALERT_PHARMA_RESULT;
            if (!res || !res.ok) {
                ALERT_PHARMA_RESULT = { has_alert: false, alert_count: 0, alerts: [] };
            } else {
                ALERT_PHARMA_RESULT = res;
                if (res.settings) ALERT_PHARMA_SETTINGS = res.settings;
            }
            syncAlertPharmaBtn(ALERT_PHARMA_RESULT);
            return ALERT_PHARMA_RESULT;
        })
        .catch(function () {
            if (seq !== alertPharmaSeq) return ALERT_PHARMA_RESULT;
            ALERT_PHARMA_RESULT = { has_alert: false, alert_count: 0, alerts: [] };
            syncAlertPharmaBtn(ALERT_PHARMA_RESULT);
            return ALERT_PHARMA_RESULT;
        });
    return alertPharmaPending;
}

function renderDayAheadAlert(alerts) {
    const body = document.getElementById('pipDayAheadAlertBody');
    if (!body) return;
    if (!alerts || !alerts.length) {
        body.innerHTML = '<div class="pip-note-empty">ไม่พบรายการที่ต้องแจ้งเตือน</div>';
        return;
    }
    const lead = (DAY_AHEAD_SETTINGS && DAY_AHEAD_SETTINGS.lead_days) || 1;
    let html = '<div style="padding:8px 12px;font-size:12.5px;color:#5a7380;">'
        + 'ยาที่สั่งใช้ตามวัน — ค่าเริ่มต้นตั้ง <b>จ่ายวัน</b> ล่วงหน้า <b>' + esc(lead) + '</b> วัน'
        + ' (เช่น จันทร์ถึงศุกร์ → อาทิตย์…พฤหัส) · ข้อยกเว้นบางรายการตั้ง <b>ตรงวันให้ยา</b></div>';
    html += '<table class="pip-ahead-table"><thead><tr>'
        + '<th>ชื่อยา</th><th>โหมด</th><th>วันให้ยา (จากวิธีใช้)</th><th>จ่ายวันที่ควรตั้ง</th><th>จ่ายวันปัจจุบัน</th><th>รายละเอียด</th>'
        + '</tr></thead><tbody>';
    alerts.forEach(function (a) {
        const actCls = a.reason === 'missing' ? 'act-miss' : 'act-bad';
        const actTxt = a.actual_dispense_days || '(ยังไม่ตั้ง)';
        const exact = !!a.exact_day || a.mode === 'exact';
        const mode = exact
            ? '<span class="badge" style="background:#e3f2fd;color:#0d47a1;font-weight:800;">ตรงวัน</span>'
            : '<span class="badge" style="background:#fff3e0;color:#e65100;font-weight:800;">ล่วงหน้า</span>';
        html += '<tr>'
            + '<td><b>' + esc(a.name || '') + '</b><div class="muted" style="font-size:11px;">' + esc(a.usage || '') + '</div></td>'
            + '<td>' + mode + '</td>'
            + '<td>' + esc(a.admin_days || '') + '</td>'
            + '<td class="exp">' + esc(a.expected_dispense_days || '') + '</td>'
            + '<td class="' + actCls + '">' + esc(actTxt) + '</td>'
            + '<td>' + esc(a.message || '') + '</td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    body.innerHTML = html;
}

function openDayAheadAlert() {
    renderDayAheadAlert((STATE && STATE.day_ahead_alerts) || []);
    $('#pipDayAheadAlert').css('display', 'flex');
}

function listToTextarea(list) {
    return (Array.isArray(list) ? list : []).join('\n');
}

function renderAlertPharmaModList() {
    const box = document.getElementById('alertPharmaModList');
    if (!box) return;
    const useDef = !!$('#setAlertPharmaUseDefault').prop('checked');
    const selected = {};
    (ALERT_PHARMA_SETTINGS.module_keys || []).forEach(function (k) { selected[k] = true; });
    const mods = ALERT_PHARMA_MODULES || [];
    if (!mods.length) {
        box.innerHTML = '<div class="muted" style="padding:8px;text-align:center;">ยังไม่มีโมดูลจาก Smart Pharma</div>';
        box.classList.toggle('is-locked', useDef);
        return;
    }
    let html = '';
    mods.forEach(function (m) {
        const key = m.key || '';
        const checked = useDef ? !!m.sp_default : !!selected[key];
        html += '<label>'
            + '<input type="checkbox" class="ap-mod-cb" value="' + esc(key) + '"'
            + (checked ? ' checked' : '')
            + (useDef ? ' disabled' : '') + '>'
            + '<span>' + esc(m.label || key) + '</span>'
            + (m.sp_default ? '<span class="sp-tag">SP</span>' : '')
            + '</label>';
    });
    box.innerHTML = html;
    box.classList.toggle('is-locked', useDef);
}

function alertPharmaPopupModeFromSettings(s) {
    s = s || {};
    if (s.popup_mode === 'alert_only' || s.popup_mode === 'always' || s.popup_mode === 'off') {
        return s.popup_mode;
    }
    if (s.auto_popup === false && s.auto_popup_pass === false) return 'off';
    if (s.auto_popup_pass) return 'always';
    return 'alert_only';
}

function fillAlertPharmaSettingsForm(ap, mods) {
    if (ap) ALERT_PHARMA_SETTINGS = ap;
    if (mods) ALERT_PHARMA_MODULES = mods;
    const s = ALERT_PHARMA_SETTINGS || {};
    $('#setAlertPharmaEnabled').prop('checked', s.enabled !== false);
    const mode = alertPharmaPopupModeFromSettings(s);
    $('input[name="setAlertPharmaPopupMode"][value="' + mode + '"]').prop('checked', true);
    $('#setAlertPharmaUseDefault').prop('checked', s.use_smart_pharma_defaults !== false);
    renderAlertPharmaModList();
}

function readAlertPharmaSettingsForm() {
    const useDef = !!$('#setAlertPharmaUseDefault').prop('checked');
    const keys = [];
    if (!useDef) {
        $('#alertPharmaModList .ap-mod-cb:checked').each(function () {
            const k = String($(this).val() || '').trim();
            if (k) keys.push(k);
        });
    } else {
        (ALERT_PHARMA_MODULES || []).forEach(function (m) {
            if (m.sp_default && m.key) keys.push(m.key);
        });
    }
    const mode = String($('input[name="setAlertPharmaPopupMode"]:checked').val() || 'alert_only');
    return {
        enabled: !!$('#setAlertPharmaEnabled').prop('checked'),
        popup_mode: mode,
        auto_popup: (mode === 'alert_only' || mode === 'always'),
        auto_popup_pass: (mode === 'always'),
        use_smart_pharma_defaults: useDef,
        module_keys: keys
    };
}

function fillSettingsForm(s) {
    s = s || DAY_AHEAD_SETTINGS || {};
    $('#setAheadEnabled').prop('checked', !!s.enabled);
    $('#setAheadLead').val(s.lead_days != null ? s.lead_days : 1);
    $('#setAheadParseUsage').prop('checked', s.parse_usage !== false);
    $('#setAheadMissing').prop('checked', s.alert_if_missing !== false);
    $('#setAheadMismatch').prop('checked', s.alert_if_mismatch !== false);
    $('#setAheadOnlyActive').prop('checked', s.only_active !== false);
    $('#setAheadAutoPopup').prop('checked', s.auto_popup !== false);
    $('#setPopupMustPaid').prop('checked', s.auto_popup_must_paid !== false);
    $('#setPopupHosxpNote').prop('checked', s.auto_popup_hosxp_note !== false);
    $('#setPopupRobot').prop('checked', s.auto_popup_robot !== false);
    $('#setRobotEnabled').prop('checked', s.robot_alert_enabled !== false);
    $('#setOpenDvOnIrx').prop('checked', !!(LAYOUT && Number(LAYOUT.open_dv_on_irx)));
    $('#setExactDayEnabled').prop('checked', s.exact_day_enabled !== false);
    $('#setExactDayKeywords').val(listToTextarea(s.exact_day_keywords != null ? s.exact_day_keywords : ['ก่อนนอน']));
    EXACT_DAY_DRUGS_EDIT = normalizeExactDayDrugsEdit(s.exact_day_drugs);
    renderExactDayDrugList();
    $('#exactDayDrugSearchHit').hide().empty();
    $('#exactDayDrugAddQ').val('');
    $('#exactDayDrugFilter').val('');
    LAB_SETTINGS_EDIT = JSON.parse(JSON.stringify((LAB_SETTINGS && LAB_SETTINGS.labs) || []))
        .filter(function (it) { return it && it.id !== 'crcl' && it.source !== 'calc'; });
    renderLabSettingsEditor();
    fillAlertPharmaSettingsForm(ALERT_PHARMA_SETTINGS, ALERT_PHARMA_MODULES);
}

function normalizeExactDayDrugsEdit(list) {
    const out = [];
    const seen = {};
    (Array.isArray(list) ? list : []).forEach(function (it) {
        let icode = '';
        let name = '';
        let units = '';
        if (it && typeof it === 'object') {
            icode = String(it.icode || '').trim();
            name = String(it.name || '').trim();
            units = String(it.units || '').trim();
        } else {
            name = String(it || '').trim();
        }
        if (!icode && !name) return;
        const key = icode ? ('i:' + icode.toLowerCase()) : ('n:' + name.toLowerCase());
        if (seen[key]) return;
        seen[key] = 1;
        out.push({ icode: icode, name: name || icode, units: units });
    });
    return out;
}

function renderExactDayDrugList(filter) {
    const q = String(filter == null ? ($('#exactDayDrugFilter').val() || '') : filter).trim().toLowerCase();
    let list = EXACT_DAY_DRUGS_EDIT || [];
    if (q) {
        list = list.filter(function (it) {
            return String(it.icode || '').toLowerCase().indexOf(q) >= 0
                || String(it.name || '').toLowerCase().indexOf(q) >= 0
                || String(it.units || '').toLowerCase().indexOf(q) >= 0;
        });
    }
    $('#exactDayDrugCount').text((EXACT_DAY_DRUGS_EDIT || []).length);
    if (!list.length) {
        $('#exactDayDrugList').html('<div class="muted" style="padding:10px;text-align:center;">'
            + ((EXACT_DAY_DRUGS_EDIT || []).length ? 'ไม่พบรายการตามคำกรอง' : 'ยังไม่มีรายการ — ค้นหาจาก HOSxP ด้านล่าง')
            + '</div>');
        return;
    }
    let html = '<table><thead><tr><th>รหัส</th><th>ชื่อยา</th><th>หน่วย</th><th></th></tr></thead><tbody>';
    list.forEach(function (it, idx) {
        const realIdx = (EXACT_DAY_DRUGS_EDIT || []).indexOf(it);
        const delKey = realIdx >= 0 ? realIdx : idx;
        html += '<tr>'
            + '<td class="code">' + esc(it.icode || '—') + '</td>'
            + '<td>' + esc(it.name || '') + '</td>'
            + '<td>' + esc(it.units || '') + '</td>'
            + '<td><button type="button" class="btn-x exact-day-del" data-idx="' + delKey + '" title="ลบออกจากรายการ">ลบ</button></td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    $('#exactDayDrugList').html(html);
}

function addExactDayDrugFromHosxp(it) {
    const icode = String((it && it.icode) || '').trim();
    const name = String((it && it.name) || '').trim();
    const units = String((it && it.units) || '').trim();
    if (!icode && !name) return;
    const key = icode ? ('i:' + icode.toLowerCase()) : ('n:' + name.toLowerCase());
    const exists = (EXACT_DAY_DRUGS_EDIT || []).some(function (x) {
        const k = x.icode ? ('i:' + String(x.icode).toLowerCase()) : ('n:' + String(x.name || '').toLowerCase());
        return k === key;
    });
    if (exists) {
        toast('มีรายการนี้แล้ว', 'err');
        return;
    }
    EXACT_DAY_DRUGS_EDIT.push({ icode: icode, name: name || icode, units: units });
    renderExactDayDrugList();
    toast('เพิ่ม ' + (icode || name) + ' แล้ว (อย่าลืมกดบันทึก)', 'ok');
}

function labBoundInputVal(v) {
    return (v === null || v === undefined || v === '') ? '' : v;
}

function renderLabSettingsEditor() {
    // กรอง CrCl ออก — เป็นค่าคำนวณ ไม่ให้ตั้งในตาราง Lab
    LAB_SETTINGS_EDIT = (LAB_SETTINGS_EDIT || []).filter(function (it) {
        return it && it.id !== 'crcl' && it.source !== 'calc';
    });
    const list = LAB_SETTINGS_EDIT || [];
    if (!list.length) {
        $('#labCfgList').html('<div class="muted" style="padding:10px;text-align:center;">ยังไม่มี Lab — กดเพิ่มด้านล่าง</div>');
        return;
    }
    let html = '<table><thead><tr>'
        + '<th>แสดง</th><th>เตือน</th><th>ชื่อ</th><th>คำค้น (HOSxP)</th><th>ต่ำ</th><th>สูง</th><th></th>'
        + '</tr></thead><tbody>';
    list.forEach(function (it, idx) {
        html += '<tr data-idx="' + idx + '">'
            + '<td style="text-align:center;"><input type="checkbox" class="lab-show"' + (it.show !== false ? ' checked' : '') + '></td>'
            + '<td style="text-align:center;"><input type="checkbox" class="lab-alert"' + (it.alert ? ' checked' : '') + '></td>'
            + '<td><input type="text" class="lab-label" value="' + esc(it.label || '') + '"></td>'
            + '<td><input type="text" class="lab-match" value="' + esc(it.match || '') + '" title="คั่นด้วยจุลภาค — แถว Cr ใช้เป็น SCr คำนวณ CrCl"></td>'
            + '<td><input type="number" step="any" class="lab-low" value="' + esc(labBoundInputVal(it.low)) + '"></td>'
            + '<td><input type="number" step="any" class="lab-high" value="' + esc(labBoundInputVal(it.high)) + '"></td>'
            + '<td><button type="button" class="btn-x lab-del" data-idx="' + idx + '">ลบ</button></td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    $('#labCfgList').html(html);
}

function syncLabSettingsEditFromDom() {
    const rows = $('#labCfgList tbody tr');
    rows.each(function () {
        const idx = parseInt($(this).attr('data-idx'), 10);
        if (isNaN(idx) || !LAB_SETTINGS_EDIT[idx]) return;
        const it = LAB_SETTINGS_EDIT[idx];
        it.show = !!$(this).find('.lab-show').prop('checked');
        it.alert = !!$(this).find('.lab-alert').prop('checked');
        it.label = String($(this).find('.lab-label').val() || '').trim() || it.id;
        it.match = String($(this).find('.lab-match').val() || '').trim() || it.label;
        const lowRaw = String($(this).find('.lab-low').val() || '').trim();
        const highRaw = String($(this).find('.lab-high').val() || '').trim();
        it.low = lowRaw === '' ? null : Number(lowRaw);
        it.high = highRaw === '' ? null : Number(highRaw);
        if (it.low !== null && isNaN(it.low)) it.low = null;
        if (it.high !== null && isNaN(it.high)) it.high = null;
    });
}

function readLabSettingsForm() {
    syncLabSettingsEditFromDom();
    return {
        labs: LAB_SETTINGS_EDIT.filter(function (it) {
            return it && it.id !== 'crcl' && it.source !== 'calc';
        }).slice()
    };
}

function slugLabId(label) {
    let s = String(label || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
    if (!s) s = 'lab';
    s = s.substring(0, 24);
    let id = s;
    let n = 2;
    const used = {};
    (LAB_SETTINGS_EDIT || []).forEach(function (it) { used[it.id] = true; });
    while (used[id]) {
        id = s + '_' + n;
        n++;
    }
    return id;
}

function readSettingsForm() {
    return {
        enabled: !!$('#setAheadEnabled').prop('checked'),
        lead_days: parseInt($('#setAheadLead').val(), 10) || 1,
        parse_usage: !!$('#setAheadParseUsage').prop('checked'),
        alert_if_missing: !!$('#setAheadMissing').prop('checked'),
        alert_if_mismatch: !!$('#setAheadMismatch').prop('checked'),
        only_active: !!$('#setAheadOnlyActive').prop('checked'),
        auto_popup: !!$('#setAheadAutoPopup').prop('checked'),
        auto_popup_must_paid: !!$('#setPopupMustPaid').prop('checked'),
        auto_popup_hosxp_note: !!$('#setPopupHosxpNote').prop('checked'),
        auto_popup_robot: !!$('#setPopupRobot').prop('checked'),
        robot_alert_enabled: !!$('#setRobotEnabled').prop('checked'),
        exact_day_enabled: !!$('#setExactDayEnabled').prop('checked'),
        exact_day_keywords: String($('#setExactDayKeywords').val() || ''),
        exact_day_drugs: (EXACT_DAY_DRUGS_EDIT || []).slice()
    };
}

let ROBOT_DRUG_CACHE = [];

function renderRobotDrugList(items, filter) {
    ROBOT_DRUG_CACHE = items || [];
    const q = String(filter == null ? ($('#robotDrugFilter').val() || '') : filter).trim().toLowerCase();
    let list = ROBOT_DRUG_CACHE;
    if (q) {
        list = list.filter(function (it) {
            return String(it.icode || '').toLowerCase().indexOf(q) >= 0
                || String(it.name || '').toLowerCase().indexOf(q) >= 0
                || String(it.units || '').toLowerCase().indexOf(q) >= 0;
        });
    }
    $('#robotDrugCount').text(ROBOT_DRUG_CACHE.length);
    if (!list.length) {
        $('#robotDrugList').html('<div class="muted" style="padding:10px;text-align:center;">'
            + (ROBOT_DRUG_CACHE.length ? 'ไม่พบรายการตามคำกรอง' : 'ยังไม่มีรายการ — กด “ดึง TAB/CAP ทั้งหมด”')
            + '</div>');
        return;
    }
    let html = '<table><thead><tr><th>รหัส</th><th>ชื่อยา</th><th>หน่วย</th><th></th></tr></thead><tbody>';
    list.forEach(function (it) {
        html += '<tr data-icode="' + esc(it.icode) + '">'
            + '<td class="code">' + esc(it.icode) + '</td>'
            + '<td>' + esc(it.name || '') + '</td>'
            + '<td>' + esc(it.units || '') + '</td>'
            + '<td><button type="button" class="btn-x robot-del" data-icode="' + esc(it.icode) + '" title="ลบออกจากรายการ Robot">ลบ</button></td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    $('#robotDrugList').html(html);
}

function loadRobotDrugList() {
    $('#robotDrugList').html('<div class="muted" style="padding:10px;text-align:center;">กำลังโหลด...</div>');
    return fetch('fetch_patient_ipd_api.php?action=robot_drugs_list')
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data || !data.ok) {
                $('#robotDrugList').html('<div class="muted" style="padding:10px;color:#c62828;">โหลดรายการไม่สำเร็จ</div>');
                return;
            }
            renderRobotDrugList(data.items || []);
        })
        .catch(function () {
            $('#robotDrugList').html('<div class="muted" style="padding:10px;color:#c62828;">โหลดรายการไม่สำเร็จ</div>');
        });
}

function reloadPatientAfterRobotChange() {
    const hn = $('#pipHn').val();
    const an = $('#pipAn').val();
    if (hn || an) {
        lastRobotHn = '';
        lookup({ hn: hn, an: an });
    }
}

function seedRobotDrugs(replace) {
    const msg = replace
        ? 'ล้างรายการยาใน Robot ทั้งหมด แล้วดึง TAB/CAP จาก HOSxP ใหม่?'
        : 'ดึงยา TAB/CAP ทั้งหมดจาก HOSxP เข้ามาในรายการ Robot? (ของเดิมยังอยู่)';
    if (!window.confirm(msg)) return;
    const $btns = $('#btnRobotSeed, #btnRobotReseed').prop('disabled', true);
    toast('กำลังดึงรายการจาก HOSxP...', 'ok');
    fetch('fetch_patient_ipd_api.php?action=robot_drugs_seed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'robot_drugs_seed', replace: !!replace })
    })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            $btns.prop('disabled', false);
            if (!data || !data.ok) {
                toast((data && data.error) || 'ดึงรายการไม่สำเร็จ', 'err');
                return;
            }
            toast('นำเข้า ' + (data.imported || 0) + ' รายการ (รวม ' + (data.count || 0) + ')', 'ok');
            loadRobotDrugList().then(function () { reloadPatientAfterRobotChange(); });
        })
        .catch(function () {
            $btns.prop('disabled', false);
            toast('ดึงรายการไม่สำเร็จ', 'err');
        });
}

let OPEN_DV_SETTINGS_SNAP = null;

function openPipSettings() {
    OPEN_DV_SETTINGS_SNAP = !!(LAYOUT && Number(LAYOUT.open_dv_on_irx));
    $('#robotDrugSearchHit').hide().empty();
    $('#robotDrugAddQ').val('');
    $('#robotDrugFilter').val('');
    $('#labAddLabel').val('');
    $('#labAddMatch').val('');
    $('#labAddLow').val('');
    $('#labAddHigh').val('');
    fillSettingsForm(DAY_AHEAD_SETTINGS);
    $('#pipSettingsModal').css('display', 'flex');
    loadRobotDrugList();
    fetch('fetch_patient_ipd_api.php?action=settings_get')
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data || !data.ok) return;
            if (data.settings) DAY_AHEAD_SETTINGS = data.settings;
            if (data.lab_settings) LAB_SETTINGS = data.lab_settings;
            if (data.alert_pharma) ALERT_PHARMA_SETTINGS = data.alert_pharma;
            if (data.alert_pharma_modules) ALERT_PHARMA_MODULES = data.alert_pharma_modules;
            fillSettingsForm(DAY_AHEAD_SETTINGS);
        })
        .catch(function () {});
}

function closePipSettings(opts) {
    opts = opts || {};
    if (opts.revertDv && OPEN_DV_SETTINGS_SNAP !== null) {
        syncOpenDvOnIrxUi(OPEN_DV_SETTINGS_SNAP);
    }
    OPEN_DV_SETTINGS_SNAP = null;
    $('#pipSettingsModal').hide();
}

function syncMustPaidBtn(data) {
    const items = (data && data.must_paid_drugs) || [];
    const n = items.length;
    $('#mustPaidCnt').text(n);
    $('#btnMustPaidAlert').prop('disabled', !n)
        .toggleClass('is-disabled', !n)
        .toggleClass('is-blink', n > 0)
        .attr('title', n ? ('พบ ' + n + ' รายการที่ต้องชำระเงิน') : 'ไม่มียาที่ต้องชำระเงิน (ใช้สิทธิไม่ได้)');
}

function renderMustPaidAlert(items) {
    const body = document.getElementById('pipMustPaidAlertBody');
    if (!body) return;
    if (!items || !items.length) {
        body.innerHTML = '<div class="pip-note-empty">ไม่มีรายการที่ต้องชำระเงิน</div>';
        return;
    }
    let html = '<table class="pip-must-table"><thead><tr>'
        + '<th>icode</th><th>ชื่อยา</th><th class="num">ราคา</th><th>สิทธิที่ต้องชำระ</th>'
        + '</tr></thead><tbody>';
    items.forEach(function (it) {
        html += '<tr>'
            + '<td class="code">' + esc(it.icode || '') + '</td>'
            + '<td class="name">' + esc(it.name || '') + '</td>'
            + '<td class="num">' + esc(money(it.price)) + '</td>'
            + '<td>' + esc(it.pttype_text || 'ชำระทั้งหมด') + '</td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    body.innerHTML = html;
}

function openMustPaidAlert() {
    renderMustPaidAlert((STATE && STATE.must_paid_drugs) || []);
    $('#pipMustPaidAlert').css('display', 'flex');
}

function maybeOpenPendingRobot() {
    if (!STATE) return;
    const alerts = STATE.robot_missing_alerts || [];
    const hn = (STATE.patient && (STATE.patient.hn_display || STATE.patient.hn)) || '';
    const auto = !(DAY_AHEAD_SETTINGS && DAY_AHEAD_SETTINGS.auto_popup_robot === false);
    if (auto && alerts.length && hn && hn !== lastRobotHn) {
        lastRobotHn = hn;
        openRobotAlert();
    }
}

function maybeOpenPendingDayAhead() {
    if (!STATE) return;
    const alerts = STATE.day_ahead_alerts || [];
    const hn = (STATE.patient && (STATE.patient.hn_display || STATE.patient.hn)) || '';
    const auto = !(DAY_AHEAD_SETTINGS && DAY_AHEAD_SETTINGS.auto_popup === false);
    if (auto && alerts.length && hn && hn !== lastDayAheadHn) {
        lastDayAheadHn = hn;
        openDayAheadAlert();
        return;
    }
    maybeOpenPendingRobot();
}

function maybeOpenPendingNotes() {
    if (!STATE) return;
    const notes = STATE.hosxp_notes || [];
    const hn = (STATE.patient && (STATE.patient.hn_display || STATE.patient.hn)) || '';
    const auto = !(DAY_AHEAD_SETTINGS && DAY_AHEAD_SETTINGS.auto_popup_hosxp_note === false);
    if (auto && notes.length && hn && hn !== lastNoteHn) {
        lastNoteHn = hn;
        openHosxpNotes();
        return;
    }
    maybeOpenPendingDayAhead();
}

function maybeOpenPendingMustPaid() {
    if (!STATE) return;
    const items = STATE.must_paid_drugs || [];
    const hn = (STATE.patient && (STATE.patient.hn_display || STATE.patient.hn)) || '';
    const auto = !(DAY_AHEAD_SETTINGS && DAY_AHEAD_SETTINGS.auto_popup_must_paid === false);
    if (auto && items.length && hn && hn !== lastMustPaidHn) {
        lastMustPaidHn = hn;
        openMustPaidAlert();
        return;
    }
    maybeOpenPendingNotes();
}

function maybeOpenPendingAlertPharma() {
    if (!STATE) return;
    const hn = (STATE.patient && (STATE.patient.hn_display || STATE.patient.hn)) || '';
    const mode = alertPharmaPopupModeFromSettings(ALERT_PHARMA_SETTINGS);
    const autoAlert = (mode === 'alert_only' || mode === 'always');
    const autoPass = (mode === 'always');
    const finish = function () {
        const res = ALERT_PHARMA_RESULT || {};
        const n = (res.alerts || []).length || res.alert_count || 0;
        // ไม่ผ่าน → เด้งรายการ Alert (โหมด alert_only / always)
        if (autoAlert && res.has_alert && n && hn && hn !== lastAlertPharmaHn) {
            lastAlertPharmaHn = hn;
            openAlertPharmaAlert();
            return;
        }
        // ผ่านทุกโมดูล → เด้ง Pass เฉพาะโหมด always
        const passed = !res.skipped && !res.has_alert && ((res.module_results || []).length || res.pass_count);
        if (autoPass && passed && hn && hn !== lastAlertPharmaPassHn) {
            lastAlertPharmaPassHn = hn;
            openAlertPharmaPass();
            return;
        }
        maybeOpenPendingMustPaid();
    };
    if (alertPharmaPending) {
        alertPharmaPending.then(finish).catch(finish);
        return;
    }
    finish();
}

function closeAllergyAlert() {
    $('#pipAllergyAlert').hide();
    maybeOpenPendingAlertPharma();
}

function closeAlertPharmaAlert() {
    $('#pipAlertPharma').hide();
    maybeOpenPendingMustPaid();
}

function closeAlertPharmaPass() {
    $('#pipAlertPharmaPass').hide();
    maybeOpenPendingMustPaid();
}

function closeMustPaidAlert() {
    $('#pipMustPaidAlert').hide();
    maybeOpenPendingNotes();
}

function closeHosxpNotes() {
    $('#pipHosxpNotes').hide();
    maybeOpenPendingDayAhead();
}

function closeDayAheadAlert() {
    $('#pipDayAheadAlert').hide();
    maybeOpenPendingRobot();
}

function closeRobotAlert() {
    $('#pipRobotAlert').hide();
}

function showData(data) {
    STATE = data;
    selectedOrderNo = orderNoStr(data.selected_order_no || '');
    if (data.day_ahead_settings) {
        DAY_AHEAD_SETTINGS = data.day_ahead_settings;
    }
    if (data.lab_settings) {
        LAB_SETTINGS = data.lab_settings;
    }
    const nextHn = (data.patient && (data.patient.hn || data.patient.hn_display)) || '';
    const prevHn = (CRCL_CTX && CRCL_CTX._hn) || '';
    CRCL_CTX = (data.labs && data.labs.crcl_meta) ? Object.assign({}, data.labs.crcl_meta, { _hn: nextHn }) : null;
    if (String(nextHn) !== String(prevHn)) {
        CRCL_OVERRIDE = null;
    }
    // บังคับ order_no เป็น string ทั้งชุด กันเทียบหาไม่เจอ
    if (STATE.orders) {
        STATE.orders.forEach(function (o) {
            o.order_no = orderNoStr(o.order_no);
            if (o.is_dispensed && o.dispensed_at && !o.dispensed_at_display) {
                o.dispensed_at_display = fmtDispenseTime(o.dispensed_at);
            }
        });
    }
    $('#pipPlaceholder').hide();
    $('#pipMain').show();
    renderPtBar(data);
    renderItems(data.order_items || []);
    applyOrderFilter({ reloadItems: true, forceLoad: false });
    renderAdmits(data.admissions || [], (data.admission && data.admission.an) || '');
    renderMr(data);
    updateTabCounts();
    setMedView(medView);
    syncHosxpNotesBtn(data);
    syncMustPaidBtn(data);
    syncDayAheadBtn(data);
    syncRobotBtn(data);
    runAlertPharmaScreen(data);
    const hn = (data.patient && (data.patient.hn_display || data.patient.hn)) || '';
    const hnRaw = data.patient ? data.patient.hn : '';
    updateEmrLinks(hnRaw || '');
    prefetchEmrCompanions(hnRaw || hn);
    let st = 'HN ' + hn;
    if (data.admission && data.admission.an) st += ' · AN ' + data.admission.an;
    const c = data.counts || {};
    if (c.active != null) st += ' · Active ' + c.active;
    if (c.off != null) st += ' · OFF ' + c.off;
    const mustN = (data.must_paid_drugs || []).length;
    if (mustN) st += ' · ต้องชำระเงิน ' + mustN;
    const aheadN = (data.day_ahead_alerts || []).length;
    if (aheadN) st += ' · ตั้งจ่ายตามวัน ' + aheadN;
    const robotN = (data.robot_missing_alerts || []).length;
    if (robotN) st += ' · ไม่เข้า Robot ' + robotN;
    if (data.warning) st += ' · ' + data.warning;
    $('#pipStatus').text(st);
    const al = data.allergy || {};
    // แพ้ยา → Alert Pharma → ต้องชำระเงิน → Note → ตั้งจ่ายตามวัน → ไม่เข้า Robot
    if (al.has_allergy && (al.items || []).length && hn && hn !== lastAllergyHn) {
        lastAllergyHn = hn;
        openAllergyAlert();
    } else {
        maybeOpenPendingAlertPharma();
    }
}

/** ช่องที่ผู้ใช้โฟกัส/พิมพ์ล่าสุด — ใช้ตัดสินว่าจะค้นด้วย HN หรือ AN */
let lastSearchField = '';

function lookup(opts) {
    opts = opts || {};
    let hn = (opts.hn != null ? opts.hn : $('#pipHn').val()).toString().trim();
    let an = (opts.an != null ? opts.an : $('#pipAn').val()).toString().trim();
    // prefer: 'hn' | 'an' — ค้นตามช่องที่กด ไม่ให้ค่าอีกช่องค้างทับ
    const prefer = String(opts.prefer || '').toLowerCase();
    if (prefer === 'hn') {
        an = '';
    } else if (prefer === 'an') {
        hn = '';
    }
    if (!hn && !an) {
        $('#pipEmptyMsg').html('<span class="text-danger">กรุณากรอก HN หรือ AN</span>');
        return;
    }
    $('#pipStatus').html('<i class="fas fa-spinner fa-spin me-1"></i>กำลังโหลด...');
    const qs = new URLSearchParams();
    if (hn) qs.set('hn', hn);
    if (an) qs.set('an', an);
    if (prefer === 'hn' || prefer === 'an') qs.set('prefer', prefer);
    fetch('fetch_patient_ipd_api.php?' + qs.toString())
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data || !data.ok) {
                const err = (data && data.error) ? data.error : 'โหลดไม่สำเร็จ';
                $('#pipStatus').html('<span class="text-danger">' + esc(err) + '</span>');
                $('#pipEmptyMsg').html('<span class="text-danger">' + esc(err) + '</span>');
                $('#pipMain').hide();
                $('#pipPlaceholder').show();
                $('#pipPtBar').hide();
                return;
            }
            if (data.patient) {
                $('#pipHn').val(data.patient.hn_display || data.patient.hn || hn);
            }
            if (data.admission && data.admission.an) {
                $('#pipAn').val(data.admission.an);
            } else if (prefer === 'hn') {
                // ค้นด้วย HN แล้วไม่พบ admit — ล้าง AN เก่าไม่ให้ค้าง
                $('#pipAn').val('');
            }
            const url = new URL(window.location.href);
            if (data.patient && data.patient.hn) url.searchParams.set('hn', data.patient.hn);
            else url.searchParams.delete('hn');
            if (data.admission && data.admission.an) url.searchParams.set('an', data.admission.an);
            else url.searchParams.delete('an');
            window.history.replaceState({}, '', url);
            showData(data);
        })
        .catch(function () {
            $('#pipStatus').html('<span class="text-danger">เชื่อมต่อไม่สำเร็จ</span>');
            $('#pipEmptyMsg').html('<span class="text-danger">เชื่อมต่อไม่สำเร็จ</span>');
        });
}

function resolveSearchPrefer() {
    if (lastSearchField === 'hn' || lastSearchField === 'an') {
        return lastSearchField;
    }
    const hn = ($('#pipHn').val() || '').toString().trim();
    const an = ($('#pipAn').val() || '').toString().trim();
    const curHn = (STATE && STATE.patient && (STATE.patient.hn || STATE.patient.hn_display) || '').toString().trim();
    const curAn = (STATE && STATE.admission && STATE.admission.an || '').toString().trim();
    const norm = function (v) { return String(v || '').replace(/^0+/, '') || '0'; };
    if (hn && curHn && norm(hn) !== norm(curHn)) return 'hn';
    if (an && curAn && norm(an) !== norm(curAn)) return 'an';
    if (an && !hn) return 'an';
    if (hn && !an) return 'hn';
    return an ? 'an' : 'hn';
}

function runSearchFromForm() {
    const prefer = resolveSearchPrefer();
    const hn = ($('#pipHn').val() || '').toString().trim();
    const an = ($('#pipAn').val() || '').toString().trim();
    if (prefer === 'hn') {
        lookup({ hn: hn, an: '', prefer: 'hn' });
    } else {
        lookup({ hn: '', an: an, prefer: 'an' });
    }
}

function loadOrderItems(orderNo) {
    orderNo = orderNoStr(orderNo);
    if (!STATE || !STATE.admission || !orderNo) return;
    selectedOrderNo = orderNo;
    renderOrders(filteredOrders(), selectedOrderNo);
    $('#pipItemBody').html('<tr><td colspan="6" class="muted" style="text-align:center;padding:12px;"><i class="fas fa-spinner fa-spin"></i></td></tr>');
    const qs = new URLSearchParams({
        action: 'order_items',
        an: orderNoStr(STATE.admission.an),
        order_no: orderNo
    });
    fetch('fetch_patient_ipd_api.php?' + qs.toString())
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data || !data.ok) {
                $('#pipItemBody').html('<tr><td colspan="6" class="muted" style="text-align:center;padding:12px;">โหลดรายการไม่สำเร็จ</td></tr>');
                return;
            }
            STATE.order_items = data.items || [];
            STATE.selected_order_no = orderNo;
            renderItems(STATE.order_items);
            updateDispenseButtons();
        });
}

$('#pipHn').on('focus input', function () { lastSearchField = 'hn'; });
$('#pipAn').on('focus input', function () { lastSearchField = 'an'; });
$('#pipHn, #pipAn').on('keydown', function (e) {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    lastSearchField = (this.id === 'pipAn') ? 'an' : 'hn';
    runSearchFromForm();
});

$('#pipForm').on('submit', function (e) {
    e.preventDefault();
    runSearchFromForm();
});

$('#leftTabs').on('click', '.pip-tab', function () {
    const pane = $(this).data('pane');
    $('#leftTabs .pip-tab').removeClass('active');
    $(this).addClass('active');
    $('#pane-main, #pane-admit, #pane-mr').removeClass('active');
    $('#pane-' + pane).addClass('active');
});

$('#orderModeTabs').on('click', 'button', function () {
    const mode = $(this).data('mode') || 'all';
    if (mode === orderMode) return;
    orderMode = mode;
    if (orderMode === 'all' && orderTypeChecked.HME === undefined) {
        orderTypeChecked.HME = true;
    }
    applyOrderFilter({ reloadItems: true, forceLoad: true });
});

$('#orderTypeChecks').on('change', 'input[type="checkbox"]', function () {
    const t = String($(this).data('otype') || '').toUpperCase();
    if (!t || $(this).prop('disabled')) return;
    orderTypeChecked[t] = !!$(this).prop('checked');
    $(this).closest('label').toggleClass('on', !!orderTypeChecked[t]);
    applyOrderFilter({ reloadItems: true, forceLoad: true });
});

$('#chkOrderDrugOnly').on('change', function () {
    orderDrugOnly = !!$(this).prop('checked');
    $(this).closest('label').toggleClass('on', orderDrugOnly);
    renderItems((STATE && STATE.order_items) || []);
});

$('#chkOpenDvOnIrx').on('change', function () {
    setOpenDvOnIrx(!!$(this).prop('checked'));
});
$('#setOpenDvOnIrx').on('change', function () {
    // ใน modal แค่ sync UI — บันทึกเมื่อกดบันทึกตั้งค่า
    syncOpenDvOnIrxUi(!!$(this).prop('checked'));
});

function setUsageCodeMode(on) {
    USAGE_CODE_MODE = !!on;
    $('#chkUsageCode, #chkOrderUsageCode').prop('checked', USAGE_CODE_MODE);
    $('#lblUsageCode, #lblOrderUsageCode').toggleClass('on', USAGE_CODE_MODE);
    persistLayout({ usage_code: USAGE_CODE_MODE ? 1 : 0 });
    setMedView(medView);
    renderItems((STATE && STATE.order_items) || []);
}
$('#chkUsageCode, #chkOrderUsageCode').on('change', function () {
    setUsageCodeMode($(this).prop('checked'));
});

$('#btnHosxpNotes').on('click', function (e) {
    e.preventDefault();
    if ($(this).prop('disabled')) return;
    openHosxpNotes();
});
$('#linkDrugViewer, #btnDrugViewer').on('click', function (e) {
    e.preventDefault();
    openDrugViewer();
});
$('#pipDrugViewerX, #pipDvCloseBtn').on('click', function () {
    closeDrugViewer();
});
$('#pipDrugViewer').on('click', function (e) {
    if (e.target === this) closeDrugViewer();
});
$('#pipDvTypeFilter').on('change', function () {
    renderDrugViewerList();
});
$('#pipDvList').on('click', '.pip-dv-item', function () {
    showDrugViewerScan($(this).data('id'));
});
$('#pipHosxpNotesX, #pipHosxpNotesClose').on('click', function () {
    closeHosxpNotes();
});
$('#pipHosxpNotes').on('click', function (e) {
    if (e.target === this) closeHosxpNotes();
});
$('#pipAllergyAlertX, #pipAllergyAlertClose').on('click', function () {
    closeAllergyAlert();
});
$('#pipAllergyAlert').on('click', function (e) {
    if (e.target === this) closeAllergyAlert();
});
$(document).on('click', '#pipPtBar .chip-al', function (e) {
    e.preventDefault();
    if (STATE && STATE.allergy && STATE.allergy.has_allergy) {
        openAllergyAlert();
    }
});
$('#btnMustPaidAlert').on('click', function (e) {
    e.preventDefault();
    if ($(this).prop('disabled')) return;
    openMustPaidAlert();
});
$('#pipMustPaidAlertX, #pipMustPaidAlertClose').on('click', function () {
    closeMustPaidAlert();
});
$('#pipMustPaidAlert').on('click', function (e) {
    if (e.target === this) closeMustPaidAlert();
});
$('#btnAlertPharma').on('click', function (e) {
    e.preventDefault();
    if ($(this).prop('disabled')) return;
    const res = ALERT_PHARMA_RESULT || {};
    if (res.has_alert && (res.alerts || []).length) {
        openAlertPharmaAlert();
    } else {
        openAlertPharmaPass();
    }
});
$('#pipAlertPharmaX, #pipAlertPharmaClose').on('click', function () {
    closeAlertPharmaAlert();
});
$('#pipAlertPharma').on('click', function (e) {
    if (e.target === this) closeAlertPharmaAlert();
});
$('#pipAlertPharmaOpenSettings').on('click', function () {
    closeAlertPharmaAlert();
    openPipSettings();
});
$('#pipAlertPharmaPassX, #pipAlertPharmaPassClose').on('click', function () {
    closeAlertPharmaPass();
});
$('#pipAlertPharmaPass').on('click', function (e) {
    if (e.target === this) closeAlertPharmaPass();
});
$('#pipAlertPharmaPassSettings').on('click', function () {
    closeAlertPharmaPass();
    openPipSettings();
});
$('#setAlertPharmaUseDefault').on('change', function () {
    if ($(this).prop('checked')) {
        ALERT_PHARMA_SETTINGS.module_keys = (ALERT_PHARMA_MODULES || [])
            .filter(function (m) { return m.sp_default; })
            .map(function (m) { return m.key; });
    }
    renderAlertPharmaModList();
});
$('#btnAlertPharmaResetMods').on('click', function () {
    $('#setAlertPharmaUseDefault').prop('checked', true);
    ALERT_PHARMA_SETTINGS.use_smart_pharma_defaults = true;
    ALERT_PHARMA_SETTINGS.module_keys = (ALERT_PHARMA_MODULES || [])
        .filter(function (m) { return m.sp_default; })
        .map(function (m) { return m.key; });
    renderAlertPharmaModList();
});
$('#btnDayAheadAlert').on('click', function (e) {
    e.preventDefault();
    if ($(this).prop('disabled')) return;
    openDayAheadAlert();
});
$('#pipDayAheadAlertX, #pipDayAheadAlertClose').on('click', function () {
    closeDayAheadAlert();
});
$('#pipDayAheadAlert').on('click', function (e) {
    if (e.target === this) closeDayAheadAlert();
});
$('#pipDayAheadOpenSettings').on('click', function () {
    closeDayAheadAlert();
    openPipSettings();
});
$('#btnRobotAlert').on('click', function (e) {
    e.preventDefault();
    if ($(this).prop('disabled')) return;
    openRobotAlert();
});
$('#pipRobotAlertX, #pipRobotAlertClose').on('click', function () {
    closeRobotAlert();
});
$('#pipRobotAlert').on('click', function (e) {
    if (e.target === this) closeRobotAlert();
});
$('#pipRobotOpenSettings').on('click', function () {
    closeRobotAlert();
    openPipSettings();
});
$(document).on('click', 'a.pip-companion', function (e) {
    e.preventDefault();
    const url = this.getAttribute('href');
    if (!url || url === '#') return false;
    const name = this.getAttribute('data-companion') || this.id || 'tool';
    openCompanionWindow(url, name);
    return false;
});

$('#btnPipSettings').on('click', function (e) {
    e.preventDefault();
    openPipSettings();
});
$('#pipSettingsX, #pipSettingsCancel').on('click', function () {
    closePipSettings({ revertDv: true });
});
$('#pipSettingsModal').on('click', function (e) {
    if (e.target === this) closePipSettings({ revertDv: true });
});
$('#btnRobotSeed').on('click', function () { seedRobotDrugs(false); });
$('#btnRobotReseed').on('click', function () { seedRobotDrugs(true); });
$('#robotDrugFilter').on('input', function () {
    renderRobotDrugList(ROBOT_DRUG_CACHE, $(this).val());
});
$(document).on('click', '.robot-del', function (e) {
    e.preventDefault();
    const icode = String($(this).attr('data-icode') || '');
    if (!icode) return;
    if (!window.confirm('ลบ ' + icode + ' ออกจากรายการ Robot?')) return;
    const $btn = $(this).prop('disabled', true);
    fetch('fetch_patient_ipd_api.php?action=robot_drugs_remove', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'robot_drugs_remove', icode: icode })
    })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data || !data.ok) {
                $btn.prop('disabled', false);
                toast((data && data.error) || 'ลบไม่สำเร็จ', 'err');
                return;
            }
            toast('ลบ ' + icode + ' แล้ว', 'ok');
            loadRobotDrugList().then(function () { reloadPatientAfterRobotChange(); });
        })
        .catch(function () {
            $btn.prop('disabled', false);
            toast('ลบไม่สำเร็จ', 'err');
        });
});
function runRobotDrugSearch() {
    const q = String($('#robotDrugAddQ').val() || '').trim();
    if (q.length < 1) {
        toast('พิมพ์รหัสหรือชื่อยาเพื่อค้นหา', 'err');
        return;
    }
    const $box = $('#robotDrugSearchHit').show().html('<div class="muted" style="padding:8px;">กำลังค้นหา...</div>');
    fetch('fetch_patient_ipd_api.php?action=robot_drugs_search&q=' + encodeURIComponent(q))
        .then(function (r) { return r.json(); })
        .then(function (data) {
            const items = (data && data.items) || [];
            if (!items.length) {
                $box.html('<div class="muted" style="padding:8px;">ไม่พบยา</div>');
                return;
            }
            let html = '';
            items.forEach(function (it) {
                html += '<button type="button" class="robot-add-hit" data-icode="' + esc(it.icode) + '">'
                    + '<b>' + esc(it.icode) + '</b> — ' + esc(it.name || '')
                    + (it.units ? (' <span class="muted">(' + esc(it.units) + ')</span>') : '')
                    + (it.is_tab_cap ? '' : ' <span class="muted">[ไม่ใช่ TAB/CAP]</span>')
                    + '</button>';
            });
            $box.html(html);
        })
        .catch(function () {
            $box.html('<div class="muted" style="padding:8px;color:#c62828;">ค้นหาไม่สำเร็จ</div>');
        });
}
$('#btnRobotSearchAdd').on('click', function () { runRobotDrugSearch(); });
$('#robotDrugAddQ').on('keydown', function (e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        runRobotDrugSearch();
    }
});
$(document).on('click', '.robot-add-hit', function (e) {
    e.preventDefault();
    const icode = String($(this).attr('data-icode') || '');
    if (!icode) return;
    fetch('fetch_patient_ipd_api.php?action=robot_drugs_add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'robot_drugs_add', icode: icode })
    })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data || !data.ok) {
                toast((data && data.error) || 'เพิ่มไม่สำเร็จ', 'err');
                return;
            }
            toast('เพิ่ม ' + icode + ' แล้ว', 'ok');
            $('#robotDrugSearchHit').hide().empty();
            $('#robotDrugAddQ').val('');
            loadRobotDrugList().then(function () { reloadPatientAfterRobotChange(); });
        })
        .catch(function () { toast('เพิ่มไม่สำเร็จ', 'err'); });
});

$('#exactDayDrugFilter').on('input', function () {
    renderExactDayDrugList($(this).val());
});
$(document).on('click', '.exact-day-del', function (e) {
    e.preventDefault();
    const idx = parseInt($(this).attr('data-idx'), 10);
    if (isNaN(idx) || idx < 0) return;
    EXACT_DAY_DRUGS_EDIT.splice(idx, 1);
    renderExactDayDrugList();
});
function runExactDayDrugSearch() {
    const q = String($('#exactDayDrugAddQ').val() || '').trim();
    if (q.length < 1) {
        toast('พิมพ์รหัสหรือชื่อยาเพื่อค้นหา', 'err');
        return;
    }
    const $box = $('#exactDayDrugSearchHit').show().html('<div class="muted" style="padding:8px;">กำลังค้นหา...</div>');
    fetch('fetch_patient_ipd_api.php?action=robot_drugs_search&q=' + encodeURIComponent(q))
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data || !data.ok) {
                $box.html('<div class="muted" style="padding:8px;color:#c62828;">'
                    + esc((data && data.error) || 'ค้นหาไม่สำเร็จ') + '</div>');
                return;
            }
            const items = data.items || [];
            if (!items.length) {
                $box.html('<div class="muted" style="padding:8px;">ไม่พบยาใน HOSxP</div>');
                return;
            }
            let html = '';
            items.forEach(function (it) {
                html += '<button type="button" class="exact-day-add-hit"'
                    + ' data-icode="' + esc(it.icode || '') + '"'
                    + ' data-name="' + esc(it.name || '') + '"'
                    + ' data-units="' + esc(it.units || '') + '">'
                    + '<b>' + esc(it.icode || '') + '</b> — ' + esc(it.name || '')
                    + (it.units ? (' <span class="muted">(' + esc(it.units) + ')</span>') : '')
                    + '</button>';
            });
            $box.html(html);
        })
        .catch(function () {
            $box.html('<div class="muted" style="padding:8px;color:#c62828;">ค้นหาไม่สำเร็จ</div>');
        });
}
$('#btnExactDaySearchAdd').on('click', function () { runExactDayDrugSearch(); });
$('#exactDayDrugAddQ').on('keydown', function (e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        runExactDayDrugSearch();
    }
});
$(document).on('click', '.exact-day-add-hit', function (e) {
    e.preventDefault();
    addExactDayDrugFromHosxp({
        icode: $(this).attr('data-icode') || '',
        name: $(this).attr('data-name') || '',
        units: $(this).attr('data-units') || ''
    });
    $('#exactDayDrugSearchHit').hide().empty();
    $('#exactDayDrugAddQ').val('');
});

$('#labCfgList').on('click', '.lab-del', function () {
    syncLabSettingsEditFromDom();
    const idx = parseInt($(this).attr('data-idx'), 10);
    if (isNaN(idx)) return;
    LAB_SETTINGS_EDIT.splice(idx, 1);
    renderLabSettingsEditor();
});
$('#btnLabAdd').on('click', function () {
    syncLabSettingsEditFromDom();
    const label = String($('#labAddLabel').val() || '').trim();
    if (!label) {
        toast('กรุณาระบุชื่อ Lab', 'err');
        return;
    }
    let match = String($('#labAddMatch').val() || '').trim();
    if (!match) match = label;
    const lowRaw = String($('#labAddLow').val() || '').trim();
    const highRaw = String($('#labAddHigh').val() || '').trim();
    const low = lowRaw === '' ? null : Number(lowRaw);
    const high = highRaw === '' ? null : Number(highRaw);
    LAB_SETTINGS_EDIT.push({
        id: slugLabId(label),
        label: label,
        match: match,
        show: true,
        alert: true,
        low: (low !== null && !isNaN(low)) ? low : null,
        high: (high !== null && !isNaN(high)) ? high : null,
        source: 'lab'
    });
    $('#labAddLabel').val('');
    $('#labAddMatch').val('');
    $('#labAddLow').val('');
    $('#labAddHigh').val('');
    renderLabSettingsEditor();
});

$('#pipSettingsSave').on('click', function () {
    const settings = readSettingsForm();
    const lab_settings = readLabSettingsForm();
    const alert_pharma = readAlertPharmaSettingsForm();
    // Drug Viewer auto-open = per user (layout) ไม่ใช่ตั้งค่าร่วมทั้งระบบ
    setOpenDvOnIrx(!!$('#setOpenDvOnIrx').prop('checked'));
    OPEN_DV_SETTINGS_SNAP = null;
    const $btn = $('#pipSettingsSave').prop('disabled', true);
    fetch('fetch_patient_ipd_api.php?action=settings_save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'settings_save',
            settings: settings,
            lab_settings: lab_settings,
            alert_pharma: alert_pharma
        })
    })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            $btn.prop('disabled', false);
            if (!data || !data.ok) {
                toast((data && data.error) || 'บันทึกตั้งค่าไม่สำเร็จ', 'err');
                return;
            }
            DAY_AHEAD_SETTINGS = data.settings || settings;
            if (data.lab_settings) LAB_SETTINGS = data.lab_settings;
            else LAB_SETTINGS = lab_settings;
            if (data.alert_pharma) ALERT_PHARMA_SETTINGS = data.alert_pharma;
            else ALERT_PHARMA_SETTINGS = alert_pharma;
            if (data.alert_pharma_modules) ALERT_PHARMA_MODULES = data.alert_pharma_modules;
            closePipSettings();
            toast('บันทึกตั้งค่าแล้ว', 'ok');
            lastDayAheadHn = '';
            lastMustPaidHn = '';
            lastRobotHn = '';
            lastAlertPharmaHn = '';
            lastAlertPharmaPassHn = '';
            // โหลดผู้ป่วยใหม่เพื่อให้ alerts ตามค่าที่ตั้ง
            const hn = $('#pipHn').val();
            const an = $('#pipAn').val();
            if (hn || an) {
                lookup({ hn: hn, an: an });
            }
        })
        .catch(function () {
            $btn.prop('disabled', false);
            toast('บันทึกตั้งค่าไม่สำเร็จ', 'err');
        });
});

$('#btnDispenseSave').on('click', function (e) {
    e.preventDefault();
    e.stopPropagation();
    if ($(this).hasClass('is-disabled') || $(this).prop('disabled')) {
        toast('กรุณาคลิกเลือก Order จากตารางก่อน แล้วกดบันทึกจ่าย', 'err');
        return;
    }
    saveDispense();
});
$('#btnDispenseCancel').on('click', function (e) {
    e.preventDefault();
    e.stopPropagation();
    if ($(this).hasClass('is-disabled') || $(this).prop('disabled')) {
        toast('ยังไม่มีรายการที่บันทึกจ่าย', 'err');
        return;
    }
    cancelDispense();
});

$(document).on('keydown', function (e) {
    if (e.key !== 'F9' && e.keyCode !== 120) return;
    const tag = (e.target && e.target.tagName) ? e.target.tagName.toLowerCase() : '';
    if (tag === 'input' || tag === 'textarea' || tag === 'select' || (e.target && e.target.isContentEditable)) {
        // อนุญาต F9 แม้โฟกัสที่ search ก็ได้ เพราะเป็น hotkey หลัก
    }
    e.preventDefault();
    if (!$('#pipMain').is(':visible')) return;
    if ($('#btnDispenseSave').prop('disabled')) {
        toast('กรุณาเลือก Order ก่อนบันทึกจ่าย', 'err');
        return;
    }
    saveDispense();
});

$('#rightTabs').on('click', '.pip-tab', function () {
    setMedView($(this).data('med'));
});

$('#btnProfileTab').on('click', function () {
    setMedView('profile');
});

function isIrxOrderType(otype) {
    const t = String(otype || '').toUpperCase().replace(/\s+/g, '');
    return t === 'IRX' || t.indexOf('IRX') === 0;
}

function isHmeOrderType(otype) {
    const t = String(otype || '').toUpperCase().replace(/\s+/g, '');
    return t === 'HME' || t.indexOf('HME') === 0;
}

/** IRx หรือ HME — ประเภทที่เปิด Drug Viewer อัตโนมัติเมื่อเลือกแถว */
function isAutoDrugViewerOrderType(otype) {
    return isIrxOrderType(otype) || isHmeOrderType(otype);
}

function shouldOpenDrugViewerOnIrx() {
    if (LAYOUT && (LAYOUT.open_dv_on_irx === 0 || LAYOUT.open_dv_on_irx === '0' || LAYOUT.open_dv_on_irx === false)) {
        return false;
    }
    return true;
}

$(document).on('click', '.order-row', function (e) {
    if ($(e.target).closest('.rx-note-box, .rx-note-td').length) return;
    // ใช้ attr แทน data() — กัน jQuery แปลง order_no ตัวเลขเป็น Number แล้วหาไม่เจอ
    const orderNo = orderNoStr($(this).attr('data-order'));
    if (!orderNo) return;
    loadOrderItems(orderNo);
    const otype = $(this).attr('data-otype') || '';
    if (shouldOpenDrugViewerOnIrx() && isAutoDrugViewerOrderType(otype) && typeof openDrugViewer === 'function') {
        const o = findOrder(orderNo);
        openDrugViewer({
            orderNo: orderNo,
            rxAt: orderRxAtIso(o)
        });
    }
});

$(document).on('click mousedown', '.rx-note-box, .rx-note-td', function (e) {
    e.stopPropagation();
});

$(document).on('change', '.rx-note-mode', function (e) {
    e.stopPropagation();
    const orderNo = orderNoStr($(this).attr('data-order'));
    const mode = ($(this).val() === 'alert') ? 'alert' : 'note';
    const $box = $(this).closest('.rx-note-box');
    const text = String($box.find('.rx-note-text').val() || '');
    $box.toggleClass('is-alert', mode === 'alert' && text.trim() !== '');
    saveRxNote(orderNo, { mode: mode, text: text });
});

$(document).on('blur', '.rx-note-text', function () {
    const orderNo = orderNoStr($(this).attr('data-order'));
    const $box = $(this).closest('.rx-note-box');
    const mode = ($box.find('.rx-note-mode').val() === 'alert') ? 'alert' : 'note';
    const text = String($(this).val() || '');
    const o = findOrder(orderNo);
    const prev = o ? String(o.rx_note || '') : '';
    const prevMode = o ? (o.rx_note_mode === 'alert' ? 'alert' : 'note') : 'note';
    if (text === prev && mode === prevMode) {
        $box.toggleClass('is-alert', mode === 'alert' && text.trim() !== '');
        return;
    }
    $box.toggleClass('is-alert', mode === 'alert' && text.trim() !== '');
    saveRxNote(orderNo, { mode: mode, text: text });
});

$(document).on('keydown', '.rx-note-text', function (e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        $(this).blur();
    }
});

$(document).on('click', '.admit-row', function () {
    const an = orderNoStr($(this).attr('data-an'));
    const hn = (STATE && STATE.patient && STATE.patient.hn) || $('#pipHn').val();
    $('#pipAn').val(an);
    lookup({ hn: hn, an: an });
});

$(document).on('click', '[data-pip-crcl="1"]', function (e) {
    e.preventDefault();
    e.stopPropagation();
    openCrclModal();
});
$('#pipCrclClose').on('click', closeCrclModal);
$('#pipCrclModal').on('click', function (e) {
    if (e.target === this) closeCrclModal();
});
$('#btnCrclCalc').on('click', function () {
    const crcl = calcCrclClient($('#crclAge').val(), $('#crclSex').val(), $('#crclBw').val(), $('#crclScr').val());
    $('#crclResult').val(crcl != null ? crcl : '');
    if (crcl == null) toast('กรุณากรอก Age / BW / SCr ให้ครบ', 'err');
});
$('#crclAge, #crclBw, #crclScr, #crclSex').on('input change', function () {
    const crcl = calcCrclClient($('#crclAge').val(), $('#crclSex').val(), $('#crclBw').val(), $('#crclScr').val());
    $('#crclResult').val(crcl != null ? crcl : '');
});
$('#btnCrclApply').on('click', applyCrclToStrip);
$('#btnCrclReset').on('click', function () {
    CRCL_OVERRIDE = null;
    fillCrclModal();
    if (STATE && STATE.labs && CRCL_CTX && CRCL_CTX.crcl != null) {
        STATE.labs.crcl = String(CRCL_CTX.crcl);
        if (Array.isArray(STATE.labs.items)) {
            STATE.labs.items.forEach(function (it) {
                if (it && it.id === 'crcl') {
                    it.value = String(CRCL_CTX.crcl);
                    it.num = CRCL_CTX.crcl;
                }
            });
        }
        renderPtBar(STATE);
    }
    toast('คืนค่า SCr / BW / CrCl จากฐานข้อมูลแล้ว', 'ok');
});

initOrderColResize();
initMedColResize();
initLayoutResize();

fetch('fetch_patient_ipd_api.php?action=settings_get')
    .then(function (r) { return r.json(); })
    .then(function (data) {
        if (!data || !data.ok) return;
        if (data.settings) DAY_AHEAD_SETTINGS = data.settings;
        if (data.lab_settings) LAB_SETTINGS = data.lab_settings;
        if (data.alert_pharma) ALERT_PHARMA_SETTINGS = data.alert_pharma;
        if (data.alert_pharma_modules) ALERT_PHARMA_MODULES = data.alert_pharma_modules;
    })
    .catch(function () {})
    .finally(function () {
        if (PREFILL.hn || PREFILL.an) {
            lookup({ hn: PREFILL.hn, an: PREFILL.an });
        }
    });
</script>
</body>
</html>
