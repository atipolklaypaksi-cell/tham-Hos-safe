<?php
/**
 * การตั้งค่า Spot Map — ใช้ได้ทุก รพ. (แจกจ่ายไฟล์นี้พร้อมโปรแกรม)
 * ค่าเริ่มต้น: โหลดหลัง deployment_map_local.php (ถ้ามี) เพื่อให้เซิร์ฟเวอร์กลาง override ได้
 */
if (!defined('THAM_DEPLOYMENT_MAP_URL')) {
    define('THAM_DEPLOYMENT_MAP_URL', 'http://61.7.167.197/thamhossafe/map_dashboard.php');
}

/**
 * เปิดเมนู "สร้าง License" ใน Admin
 * ค่าเริ่มต้นสำหรับ รพ. = false
 * เซิร์ฟเวอร์กลางให้สร้าง deployment_map_local.php แล้วตั้งเป็น true (โหลดก่อนไฟล์นี้)
 */
if (!defined('THAM_LICENSE_ADMIN_ENABLED')) {
    define('THAM_LICENSE_ADMIN_ENABLED', false);
}
