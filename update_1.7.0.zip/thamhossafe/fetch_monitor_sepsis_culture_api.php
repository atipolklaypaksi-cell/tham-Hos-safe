<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/amr_helper.php');
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_sensitivity_helper.php';
require_once __DIR__ . '/amr_mlab_helper.php';
require_once __DIR__ . '/monitor_amr_drug_helper.php';
require_once __DIR__ . '/monitor_sepsis_culture_helper.php';
mysqli_set_charset($con, 'utf8');
set_time_limit(90);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

amr_dict_ensure_tables($con);
amr_dict_prime($con);

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = [];
}
$src = array_merge($_GET, $input);
$action = trim((string)($src['action'] ?? 'list'));

function msc_json(array $payload) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'gram_cover_get') {
    msc_json([
        'status' => 'success',
        'rows' => msc_gram_cover_list($con, false),
        'groups' => msc_gram_cover_groups(),
    ]);
}

if ($action === 'gram_cover_save') {
    $rows = $src['rows'] ?? [];
    if (!is_array($rows)) {
        $rows = [];
    }
    $saved = msc_gram_cover_save($con, $rows);
    if (($saved['error'] ?? '') !== '') {
        msc_json(['status' => 'error', 'message' => $saved['error']]);
    }
    msc_json([
        'status' => 'success',
        'message' => 'บันทึกตารางความครอบคลุมแล้ว',
        'rows' => $saved['rows'] ?? [],
        'groups' => msc_gram_cover_groups(),
    ]);
}

if ($action === 'gram_cover_reset') {
    $saved = msc_gram_cover_reset($con);
    if (($saved['error'] ?? '') !== '') {
        msc_json(['status' => 'error', 'message' => $saved['error']]);
    }
    msc_json([
        'status' => 'success',
        'message' => 'คืนค่าความครอบคลุมตามมาตรฐานแล้ว',
        'rows' => $saved['rows'] ?? [],
        'groups' => msc_gram_cover_groups(),
    ]);
}

$hos = hosxp_connect($con, 90);
if (!$hos) {
    msc_json(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้']);
}
hosxp_extend_read_timeout($hos, 90);

if ($action === 'list') {
    $t0 = microtime(true);
    $scan = msc_scan($con, $hos, $src['lookback'] ?? '7d');
    if (($scan['error'] ?? '') !== '') {
        msc_json(['status' => 'error', 'message' => $scan['error']]);
    }
    $meta = $scan['meta'] ?? [];
    $meta['elapsed_ms'] = (int)round((microtime(true) - $t0) * 1000);
    $meta['data_source_label'] = (($meta['source'] ?? '') === 'mlab')
        ? 'mLAB (ตาราง THAM Hos-Safe) + ยาจาก HOSxP'
        : 'HOSxP';
    msc_json([
        'status' => 'success',
        'rows' => $scan['rows'] ?? [],
        'meta' => $meta,
    ]);
}

msc_json(['status' => 'error', 'message' => 'unknown action']);
