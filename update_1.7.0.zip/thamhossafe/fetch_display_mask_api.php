<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/display_mask_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}

$can = tham_menu_can('admin.display_mask')
    || tham_menu_can('admin.hosxp')
    || (($_SESSION['role'] ?? '') === 'admin');
if (!$can) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
    exit;
}

session_write_close();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST ?: [];
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'list'));

if ($action === 'list') {
    echo json_encode([
        'status' => 'success',
        'message_text' => dm_mask_message(),
        'scopes' => dm_scopes(),
        'items' => dm_get_rules($con),
        'lab_items' => dm_get_rules($con, 'lab'),
        'drug_items' => dm_get_rules($con, 'drug'),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'search_drug') {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 15) : null;
    if (!$hos) {
        echo json_encode(['status' => 'error', 'message' => 'เชื่อมต่อ HOSxP ไม่ได้', 'items' => []], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $items = hosxp_search_drugs_tmt($hos, $input['q'] ?? $_GET['q'] ?? '', 25);
    @mysqli_close($hos);
    echo json_encode(['status' => 'success', 'items' => $items], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'add') {
    $res = dm_add_rule($con, $input);
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['message'] ?? '',
        'items' => dm_get_rules($con),
        'lab_items' => dm_get_rules($con, 'lab'),
        'drug_items' => dm_get_rules($con, 'drug'),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'update') {
    $res = dm_update_rule($con, $input['id'] ?? 0, $input);
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['message'] ?? '',
        'items' => dm_get_rules($con),
        'lab_items' => dm_get_rules($con, 'lab'),
        'drug_items' => dm_get_rules($con, 'drug'),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'delete') {
    $ok = dm_delete_rule($con, $input['id'] ?? 0);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'message' => $ok ? '' : 'ลบไม่สำเร็จ',
        'items' => dm_get_rules($con),
        'lab_items' => dm_get_rules($con, 'lab'),
        'drug_items' => dm_get_rules($con, 'drug'),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'ไม่รู้จักคำสั่ง'], JSON_UNESCAPED_UNICODE);
