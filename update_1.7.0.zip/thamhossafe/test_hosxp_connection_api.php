<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) {
    $data = [];
}

$host = isset($data['h_host']) ? trim($data['h_host']) : '';
$db = isset($data['h_db']) ? trim($data['h_db']) : '';
$user = isset($data['h_user']) ? trim($data['h_user']) : '';
$pass = isset($data['h_pass']) ? $data['h_pass'] : '';
$port = isset($data['h_port']) ? (int)$data['h_port'] : 3306;
$source = isset($data['source']) ? trim((string)$data['source']) : '';

if ($port <= 0) {
    $port = 3306;
}

if ($source === 'master' && ($pass === '' || $pass === '********')) {
    include('connect.php');
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    mysqli_set_charset($con, 'utf8');
    $saved = hosxp_load_master_config($con);
    if ($host === '') {
        $host = trim((string)($saved['h_master_host'] ?? ''));
    }
    if ($db === '') {
        $db = trim((string)($saved['h_master_db'] ?? ''));
    }
    if ($user === '') {
        $user = trim((string)($saved['h_master_user'] ?? ''));
    }
    $pass = (string)($saved['h_master_pass'] ?? '');
    if (empty($data['h_port']) && !empty($saved['h_master_port'])) {
        $port = (int)$saved['h_master_port'];
        if ($port <= 0) {
            $port = 3306;
        }
    }
}

if (empty($host) || empty($db) || empty($user)) {
    echo json_encode(['status' => 'warning', 'message' => 'กรุณากรอก Host, Database Name และ Username ให้ครบถ้วน']);
    exit;
}

// PHP 8.1+ โยน mysqli_sql_exception เมื่อเชื่อมต่อล้มเหลว — ต้องปิด report mode
mysqli_report(MYSQLI_REPORT_OFF);

$test_conn = @mysqli_connect($host, $user, $pass, $db, $port);

if ($test_conn) {
    $label = $source === 'master' ? 'HOSxP master' : 'HOSxP';
    $ver = '';
    $dbn = '';
    $tc = 0;
    $qv = @mysqli_query($test_conn, 'SELECT DATABASE() AS db, VERSION() AS ver');
    if ($qv && ($r = mysqli_fetch_assoc($qv))) {
        $ver = (string)($r['ver'] ?? '');
        $dbn = (string)($r['db'] ?? '');
    }
    $qt = @mysqli_query($test_conn, 'SHOW TABLES');
    $tc = $qt ? (int)mysqli_num_rows($qt) : 0;
    mysqli_close($test_conn);
    $msg = 'เชื่อมต่อฐานข้อมูล ' . $label . ' สำเร็จพร้อมใช้งาน';
    if ($dbn !== '') {
        $msg .= ' · ฐาน ' . $dbn;
    }
    if ($ver !== '') {
        $msg .= ' · ' . $ver;
    }
    if ($tc > 0) {
        $msg .= ' · ตาราง ' . number_format($tc);
    }
    echo json_encode(['status' => 'success', 'message' => $msg]);
} else {
    $error_msg = mysqli_connect_error() ?: 'ไม่สามารถเชื่อมต่อได้';
    echo json_encode(['status' => 'error', 'message' => 'เชื่อมต่อล้มเหลว: ' . $error_msg]);
}
