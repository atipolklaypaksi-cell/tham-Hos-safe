<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
require_once __DIR__ . '/rational_lab_use_helper.php';
$default_end = date('Y-m-d');
$default_start = date('Y-m-d', strtotime('-6 days'));
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>รายงาน SMC / นอกเวลา</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .smc-stat-card { border: 0; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,.06); }
        .smc-stat-card .stat-value { font-size: 1.35rem; font-weight: 700; }
        .smc-table thead { background: #0369a1; color: #fff; }
        #summaryChartWrap { position: relative; height: 280px; }
        #summaryChartStats {
            position: absolute; top: 6px; right: 10px; z-index: 2;
            font-size: .78rem; line-height: 1.35; color: #475569;
            background: rgba(255,255,255,.88); border: 1px solid #e2e8f0;
            border-radius: 6px; padding: 6px 10px; pointer-events: none; text-align: right;
        }
        #summaryChartStats .stat-avg strong { color: #0369a1; }
        #summaryChartStats .stat-max strong { color: #dc2626; }
        #summaryChartStats .stat-min strong { color: #2563eb; }
        #pointChartWrap, #doctorChartWrap, #pharmacistChartWrap { position: relative; min-height: 240px; height: 320px; }
        .badge-drug { background: #198754; }
        .badge-nodrug { background: #94a3b8; }
        .mode-tabs .nav-link { cursor: pointer; font-size: .9rem; }
        .mode-tabs .nav-link.active { background: #0369a1; color: #fff; }
        #depListBox {
            max-height: 180px; overflow: auto; border: 1px solid #dee2e6;
            border-radius: 6px; background: #fff; padding: .4rem .6rem;
        }
        #depListBox .form-check { margin-bottom: .15rem; }
        #depListBox .shift-tag { font-size: .65rem; }
        .detail-sort-th { cursor: pointer; user-select: none; white-space: nowrap; }
        .detail-sort-th:hover { background: rgba(255,255,255,.12); }
        .detail-sort-th .sort-icon { opacity: .45; font-size: .65rem; margin-left: 2px; }
        .detail-sort-th.sort-asc .sort-icon,
        .detail-sort-th.sort-desc .sort-icon { opacity: 1; }
        .detail-sort-th.sort-asc .sort-icon::after { content: '▲'; }
        .detail-sort-th.sort-desc .sort-icon::after { content: '▼'; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-1 text-dark">
                <i class="fas fa-clinic-medical me-2" style="color:#0369a1;"></i>
                รายงานผู้ป่วยคลินิก SMC / นอกเวลา
            </h4>
            <p class="text-muted small mb-3">
                นับผู้ป่วยตามจุดรับบริการ พร้อมแยกจำนวนที่รับยาจริง — โหลดสรุปก่อน แล้วค่อยดึงรายละเอียดแยก
            </p>

            <div class="bg-white border rounded shadow-sm p-3 mb-3">
                <ul class="nav nav-pills mode-tabs mb-3" id="modeTabs">
                    <li class="nav-item">
                        <button type="button" class="nav-link active" data-mode="shift4h" id="tabShift4h">
                            <i class="fas fa-clock me-1"></i> เวร 4 ชั่วโมง
                        </button>
                    </li>
                    <li class="nav-item">
                        <button type="button" class="nav-link" data-mode="custom" id="tabCustom">
                            <i class="fas fa-list me-1"></i> เลือกจุดรับบริการเอง
                        </button>
                    </li>
                </ul>

                <div id="shiftHint" class="alert alert-light border py-2 small mb-3">
                    โหมด <strong>เวร 4 ชั่วโมง</strong> เลือกจุดอัตโนมัติ และแยกกลุ่ม
                    <span class="badge bg-danger">SI</span> = ตึกฉุกเฉิน / ตึกอุบัติเหตุ / ตึก ER / เวชศาสตร์ฟื้นฟู &nbsp;
                    <span class="badge bg-primary">SO</span> = อื่นๆ ในเวร (เช่น SMC, OPD นอกเวลา)
                    <br>
                    <strong>เวลา:</strong> คลินิกทั่วไป = <strong>ทั้งวัน (ไม่จำกัดเวลา)</strong>
                    &nbsp;|&nbsp; <strong>ตึกอุบัติเหตุ / ห้องตรวจ เวชศาสตร์ฟื้นฟู</strong> = ตามเวลาลงข้อมูลยา (หรือเวลา visit) เริ่มต้น <strong>16:30–20:30</strong>
                </div>

                <div class="row g-2 align-items-end">
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">ตั้งแต่</label>
                        <input type="text" id="filterStart" class="form-control form-control-sm" value="<?php echo htmlspecialchars($default_start); ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">ถึง</label>
                        <input type="text" id="filterEnd" class="form-control form-control-sm" value="<?php echo htmlspecialchars($default_end); ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">เวลาลงยา (อุบัติเหตุ/ฟื้นฟู)</label>
                        <input type="time" id="filterTimeStart" class="form-control form-control-sm" value="16:30">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">ถึงเวลา</label>
                        <input type="time" id="filterTimeEnd" class="form-control form-control-sm" value="20:30">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">สรุปแยกตาม</label>
                        <div class="btn-group btn-group-sm w-100" role="group">
                            <input type="radio" class="btn-check" name="granularity" id="granDay" value="day" checked>
                            <label class="btn btn-outline-secondary" for="granDay">วัน</label>
                            <input type="radio" class="btn-check" name="granularity" id="granMonth" value="month">
                            <label class="btn btn-outline-secondary" for="granMonth">เดือน</label>
                            <input type="radio" class="btn-check" name="granularity" id="granYear" value="year">
                            <label class="btn btn-outline-secondary" for="granYear">ปี</label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-sm fw-bold text-white w-100" style="background:#0369a1;" id="btnLoad" onclick="loadSmcReport()">
                            <i class="fas fa-sync-alt me-1"></i> โหลดสรุป
                        </button>
                    </div>
                </div>

                <div class="row g-2 mt-2">
                    <div class="col-md-8">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <label class="form-label small fw-bold mb-0">จุดรับบริการ</label>
                            <span class="small text-muted" id="depSelectedCount"></span>
                            <input type="search" id="depSearch" class="form-control form-control-sm ms-auto" style="max-width:220px;" placeholder="ค้นหาจุดบริการ...">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="selectShiftDeps()">เลือกเวร 4 ชม.</button>
                            <button type="button" class="btn btn-sm btn-outline-danger" onclick="selectSiDeps()">SI</button>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="selectSoDeps()">SO</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="clearDepSelection()">ล้าง</button>
                        </div>
                        <div id="depListBox">
                            <div class="text-muted small py-2">กำลังโหลดจุดรับบริการ...</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold mb-1">แพทย์ (ว่าง = ทั้งหมด)</label>
                        <select id="filterDoctor" class="form-select form-select-sm" multiple size="6"></select>
                        <div class="mt-1">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="setQuickRange('week')">7 วันล่าสุด</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="setQuickRange('month')">เดือนนี้</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="clearDoctorFilter()">ล้างแพทย์</button>
                        </div>
                    </div>
                </div>
            </div>

            <div id="metaBox" class="alert alert-info py-2 small d-none mb-3"></div>
            <div id="progressBox" class="d-none mb-3">
                <div class="d-flex justify-content-between small mb-1">
                    <span id="progressLabel">กำลังโหลด...</span>
                    <span id="progressPct">0%</span>
                </div>
                <div class="progress" style="height: 8px;">
                    <div id="progressBar" class="progress-bar progress-bar-striped progress-bar-animated" style="width:0%; background:#0369a1;"></div>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-md-2 col-6">
                    <div class="card smc-stat-card p-3">
                        <div class="text-muted small">ผู้ป่วยทั้งหมด (VN)</div>
                        <div class="stat-value text-dark" id="sumVisits">—</div>
                    </div>
                </div>
                <div class="col-md-2 col-6">
                    <div class="card smc-stat-card p-3">
                        <div class="text-muted small">รับยาจริง (VN)</div>
                        <div class="stat-value text-success" id="sumDrugVisits">—</div>
                        <div class="small text-muted" id="sumDrugPct"></div>
                    </div>
                </div>
                <div class="col-md-2 col-6">
                    <div class="card smc-stat-card p-3">
                        <div class="text-muted small">ไม่มียา (VN)</div>
                        <div class="stat-value text-secondary" id="sumNoDrug">—</div>
                    </div>
                </div>
                <div class="col-md-2 col-6">
                    <div class="card smc-stat-card p-3">
                        <div class="text-muted small">รายการยา</div>
                        <div class="stat-value text-dark" id="sumItems">—</div>
                    </div>
                </div>
                <div class="col-md-2 col-6">
                    <div class="card smc-stat-card p-3">
                        <div class="text-muted small">ชำระแล้ว (&gt;0)</div>
                        <div class="stat-value text-danger" id="sumMustPay">—</div>
                        <div class="small text-muted" id="sumMustPayPct"></div>
                    </div>
                </div>
                <div class="col-md-2 col-6">
                    <div class="card smc-stat-card p-3">
                        <div class="text-muted small">ไม่ได้ชำระ (=0)</div>
                        <div class="stat-value" style="color:#0369a1;" id="sumNoPay">—</div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white fw-bold"><i class="fas fa-chart-bar me-1 text-secondary"></i> สรุปตามช่วง</div>
                <div class="card-body"><div id="summaryChartWrap"><div id="summaryChartStats" class="d-none"></div><canvas id="summaryChart"></canvas></div></div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle smc-table">
                        <thead class="text-center small">
                            <tr>
                                <th id="periodHeader">วัน</th>
                                <th>ผู้ป่วย (VN)</th>
                                <th>รับยาจริง</th>
                                <th>ไม่มียา</th>
                                <th>ชำระแล้ว</th>
                                <th>ไม่ได้ชำระ</th>
                                <th>รายการยา</th>
                                <th>% รับยา</th>
                            </tr>
                        </thead>
                        <tbody id="periodTbody"><tr><td colspan="8" class="text-center py-4 text-muted">กดโหลดสรุป</td></tr></tbody>
                    </table>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white fw-bold d-flex"><span><i class="fas fa-hospital me-1 text-secondary"></i> สรุปแยกตามจุดรับบริการ <span class="fw-normal text-muted small">(ตาม checkbox ที่เลือก)</span></span><span class="small text-muted ms-auto" id="pointChartHint"></span></div>
                <div class="card-body"><div id="pointChartWrap"><canvas id="pointChart"></canvas></div></div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle smc-table">
                        <thead class="text-center small">
                            <tr>
                                <th class="text-start">กลุ่ม</th>
                                <th class="text-start">จุดรับบริการ</th>
                                <th>ผู้ป่วย</th>
                                <th>รับยาจริง</th>
                                <th>รายการยา</th>
                                <th>% รับยา</th>
                                <th>สัดส่วน</th>
                            </tr>
                        </thead>
                        <tbody id="pointTbody"><tr><td colspan="7" class="text-center py-4 text-muted">กดโหลดสรุป</td></tr></tbody>
                    </table>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white fw-bold d-flex"><span><i class="fas fa-user-md me-1 text-secondary"></i> สรุปแยกตามแพทย์</span><span class="small text-muted ms-auto" id="doctorChartHint"></span></div>
                <div class="card-body"><div id="doctorChartWrap"><canvas id="doctorChart"></canvas></div></div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle smc-table">
                        <thead class="text-center small">
                            <tr>
                                <th class="text-start">แพทย์</th>
                                <th>ผู้ป่วย</th>
                                <th>รับยาจริง</th>
                                <th>รายการยา</th>
                                <th>% รับยา</th>
                            </tr>
                        </thead>
                        <tbody id="doctorTbody"><tr><td colspan="5" class="text-center py-4 text-muted">กดโหลดสรุป</td></tr></tbody>
                    </table>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white fw-bold d-flex">
                    <span><i class="fas fa-user-nurse me-1 text-secondary"></i> สรุปแยกตามเภสัชกรผู้จ่ายยา</span>
                    <span class="small text-muted ms-auto" id="pharmacistChartHint"></span>
                </div>
                <div class="card-body"><div id="pharmacistChartWrap"><canvas id="pharmacistChart"></canvas></div></div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle smc-table">
                        <thead class="text-center small">
                            <tr>
                                <th class="text-start">เภสัชกรผู้จ่ายยา</th>
                                <th>Visit มียา</th>
                                <th>ผู้ป่วย (HN)</th>
                                <th>รายการยา</th>
                                <th>มูลค่า</th>
                                <th>สัดส่วนรายการ</th>
                            </tr>
                        </thead>
                        <tbody id="pharmacistTbody"><tr><td colspan="6" class="text-center py-4 text-muted">กดโหลดสรุป</td></tr></tbody>
                    </table>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white fw-bold d-flex flex-wrap align-items-center gap-2">
                    <span><i class="fas fa-list me-1 text-secondary"></i> รายละเอียด Visit</span>
                    <button type="button" class="btn btn-sm btn-outline-primary" id="btnLoadDetail" disabled onclick="loadSmcDetails()">
                        <i class="fas fa-download me-1"></i> โหลดรายละเอียด
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-success ms-auto" id="btnExportExcel" disabled onclick="exportExcel()">
                        <i class="fas fa-file-excel me-1"></i> ส่งออก Excel
                    </button>
                </div>
                <div class="px-3 pt-2 pb-0 border-bottom">
                    <div class="row g-2">
                        <div class="col-md-8">
                            <input type="search" id="detailSearch" class="form-control form-control-sm" placeholder="ค้นหาชื่อ HN / จุดบริการ / แพทย์..." autocomplete="off">
                        </div>
                        <div class="col-md-4">
                            <select id="detailDrugFilter" class="form-select form-select-sm">
                                <option value="all">ทั้งหมด</option>
                                <option value="drug">รับยาจริงเท่านั้น</option>
                                <option value="nodrug">ไม่มียาเท่านั้น</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-sm table-hover mb-0 align-middle" style="font-size:.85rem;">
                        <thead class="table-light text-center small" id="detailThead">
                            <tr>
                                <th>ลำดับ</th>
                                <th class="detail-sort-th" data-sort-key="visit_date">วันที่<span class="sort-icon"></span></th>
                                <th class="detail-sort-th" data-sort-key="visit_time">เวลา<span class="sort-icon"></span></th>
                                <th class="detail-sort-th text-start" data-sort-key="patient_name">ชื่อ-นามสกุล<span class="sort-icon"></span></th>
                                <th class="detail-sort-th" data-sort-key="hn">HN<span class="sort-icon"></span></th>
                                <th class="detail-sort-th" data-sort-key="vn">VN<span class="sort-icon"></span></th>
                                <th class="detail-sort-th text-start" data-sort-key="dept_name">จุดรับบริการ<span class="sort-icon"></span></th>
                                <th class="detail-sort-th text-start" data-sort-key="doctor_name">แพทย์<span class="sort-icon"></span></th>
                                <th class="detail-sort-th text-start" data-sort-key="pharmacist_names">เภสัชกรผู้จ่าย<span class="sort-icon"></span></th>
                                <th class="detail-sort-th" data-sort-key="has_drug">สถานะยา<span class="sort-icon"></span></th>
                                <th class="detail-sort-th" data-sort-key="must_pay">การชำระเงิน<span class="sort-icon"></span></th>
                                <th class="detail-sort-th" data-sort-key="drug_item_count">รายการยา<span class="sort-icon"></span></th>
                            </tr>
                        </thead>
                        <tbody id="detailTbody">
                            <tr><td colspan="12" class="text-center py-4 text-muted">โหลดสรุปก่อน แล้วกด «โหลดรายละเอียด»</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/flatpickr.min.js"></script>
<script src="js/chart.min.js"></script>
<script src="https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"></script>
<script>
const SMC_API = 'fetch_smc_clinic_report_api.php';
const CHART_COLORS = ['#0369a1', '#198754', '#64748b', '#f59e0b', '#ef4444', '#8b5cf6', '#14b8a6', '#f97316'];
let fpStart = null, fpEnd = null;
let summaryChart = null, pointChart = null, doctorChart = null, pharmacistChart = null;
let detailRows = [];
let detailSortKey = 'visit_date';
let detailSortDir = 'asc';
let currentReport = null;
let allDepartments = [];
let shift4hCodes = [];
let siCodes = [];
let soCodes = [];
let selectedDepSet = new Set();
let currentMode = 'shift4h';

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function qs(obj) {
    return Object.keys(obj).filter(k => obj[k] !== '' && obj[k] != null)
        .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(obj[k])).join('&');
}

async function fetchJson(url) {
    const r = await fetch(url, { credentials: 'same-origin' });
    const text = await r.text();
    try { return JSON.parse(text); } catch (e) {
        if (/504|Gateway Time-out/i.test(text)) {
            throw new Error('หมดเวลาโหลด (504) — ลองช่วงวันที่สั้นลง เช่น 7 วัน');
        }
        throw new Error(text ? text.substring(0, 200) : ('HTTP ' + r.status));
    }
}

function getGranularity() {
    return $('input[name="granularity"]:checked').val() || 'day';
}
function granularityLabel(g) {
    if (g === 'year') return 'ปี';
    if (g === 'month') return 'เดือน';
    return 'วัน';
}

function setQuickRange(mode) {
    const end = new Date();
    let start = new Date(end);
    if (mode === 'week') start.setDate(end.getDate() - 6);
    else start = new Date(end.getFullYear(), end.getMonth(), 1);
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    if (fpStart) fpStart.setDate(fmt(start), true); else $('#filterStart').val(fmt(start));
    if (fpEnd) fpEnd.setDate(fmt(end), true); else $('#filterEnd').val(fmt(end));
}

function clearDoctorFilter() { $('#filterDoctor').val([]); }

function getSelectedDoctors() {
    const vals = $('#filterDoctor').val();
    return (vals && vals.length) ? vals.join(',') : '';
}

function getSelectedDepCodes() {
    return Array.from(selectedDepSet);
}

function updateDepSelectedCount() {
    const n = selectedDepSet.size;
    $('#depSelectedCount').text('เลือกแล้ว ' + n + ' จุด' + (allDepartments.length ? ' / ทั้งหมด ' + allDepartments.length : ''));
}

function renderDepList() {
    const q = ($('#depSearch').val() || '').trim().toLowerCase();
    let html = '';
    allDepartments.forEach(d => {
        const blob = (d.dep_name + ' ' + d.dep_code).toLowerCase();
        if (q && blob.indexOf(q) === -1) return;
        const checked = selectedDepSet.has(d.dep_code) ? ' checked' : '';
        let tag = '';
        if (d.shift_group === 'si') tag = '<span class="badge bg-danger shift-tag ms-1">SI</span>';
        else if (d.shift_group === 'so') tag = '<span class="badge bg-primary shift-tag ms-1">SO</span>';
        html += '<div class="form-check">'
            + '<input class="form-check-input dep-check" type="checkbox" value="' + esc(d.dep_code) + '" id="dep_' + esc(d.dep_code) + '"' + checked + '>'
            + '<label class="form-check-label small" for="dep_' + esc(d.dep_code) + '">'
            + esc(d.dep_name) + ' <span class="text-muted">(' + esc(d.dep_code) + ')</span>' + tag
            + '</label></div>';
    });
    $('#depListBox').html(html || '<div class="text-muted small py-2">ไม่พบจุดบริการ</div>');
    updateDepSelectedCount();
}

function selectShiftDeps() {
    selectedDepSet = new Set(shift4hCodes);
    renderDepList();
}

function selectSiDeps() {
    selectedDepSet = new Set(siCodes);
    renderDepList();
}

function selectSoDeps() {
    selectedDepSet = new Set(soCodes);
    renderDepList();
}

function clearDepSelection() {
    selectedDepSet = new Set();
    renderDepList();
}

function applyMode(mode) {
    currentMode = mode === 'custom' ? 'custom' : 'shift4h';
    $('#modeTabs .nav-link').removeClass('active');
    $('#modeTabs .nav-link[data-mode="' + currentMode + '"]').addClass('active');
    if (currentMode === 'shift4h') {
        $('#shiftHint').removeClass('d-none');
        $('#filterTimeStart').val('16:30');
        $('#filterTimeEnd').val('20:30');
        selectShiftDeps();
    } else {
        $('#shiftHint').addClass('d-none');
    }
}

function getReportParams(action, startDate, endDate) {
    const deps = getSelectedDepCodes();
    return {
        action: action || 'summary',
        mode: currentMode,
        start_date: startDate || $('#filterStart').val(),
        end_date: endDate || $('#filterEnd').val(),
        time_start: $('#filterTimeStart').val() || '16:30',
        time_end: $('#filterTimeEnd').val() || '20:30',
        // โหลดเป็นรายวันแล้วรวมฝั่ง client — เร็วและกัน 504
        granularity: 'day',
        dep_codes: deps.join(','),
        doctor: getSelectedDoctors(),
    };
}

function parseYmd(s) {
    const p = String(s || '').split('-').map(Number);
    if (p.length < 3 || !p[0]) return null;
    return new Date(p[0], p[1] - 1, p[2]);
}

function fmtYmd(d) {
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/** แบ่งช่วงวันที่เป็นชิ้นสั้นๆ (ค่าเริ่มต้น 1 วัน/ชิ้น) */
function splitDateChunks(startStr, endStr, chunkDays) {
    chunkDays = Math.max(1, parseInt(chunkDays, 10) || 1);
    const start = parseYmd(startStr);
    const end = parseYmd(endStr);
    if (!start || !end || start > end) return [];
    const chunks = [];
    let cur = new Date(start.getTime());
    while (cur <= end) {
        const chunkEnd = new Date(cur.getTime());
        chunkEnd.setDate(chunkEnd.getDate() + chunkDays - 1);
        if (chunkEnd > end) chunkEnd.setTime(end.getTime());
        chunks.push({ start: fmtYmd(cur), end: fmtYmd(chunkEnd) });
        cur = new Date(chunkEnd.getTime());
        cur.setDate(cur.getDate() + 1);
    }
    return chunks;
}

async function mapPool(items, concurrency, workerFn, onProgress) {
    const results = new Array(items.length);
    let next = 0;
    let done = 0;
    async function worker() {
        while (true) {
            const idx = next++;
            if (idx >= items.length) return;
            results[idx] = await workerFn(items[idx], idx);
            done++;
            if (onProgress) onProgress(done, items.length, items[idx]);
        }
    }
    const n = Math.max(1, Math.min(concurrency, items.length));
    await Promise.all(Array.from({ length: n }, () => worker()));
    return results;
}

function showProgress(done, total, label) {
    const pct = total > 0 ? Math.round((done / total) * 100) : 0;
    $('#progressBox').removeClass('d-none');
    $('#progressBar').css('width', pct + '%');
    $('#progressPct').text(pct + '%');
    $('#progressLabel').text(label || ('โหลดแล้ว ' + done + '/' + total + ' ช่วง'));
}

function hideProgress() {
    $('#progressBox').addClass('d-none');
    $('#progressBar').css('width', '0%');
}

function fmtNum(n) {
    return Number(n || 0).toLocaleString('en-US');
}

function fmtMoney(n) {
    return Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function enrichMetrics(row) {
    const visit = Number(row.visit_count || 0);
    const drugVisit = Number(row.drug_visit_count || 0);
    const noDrug = Math.max(0, visit - drugVisit);
    const pct = visit > 0 ? (drugVisit * 100 / visit) : 0;
    const mustPay = Number(row.must_pay_count || 0);
    const noPay = Number(row.no_pay_count != null ? row.no_pay_count : Math.max(0, visit - mustPay));
    const mustPct = visit > 0 ? (mustPay * 100 / visit) : 0;
    row.no_drug_visit_count = noDrug;
    row.drug_visit_pct = pct;
    row.must_pay_count = mustPay;
    row.no_pay_count = noPay;
    row.must_pay_pct = mustPct;
    row.visit_count_display = fmtNum(visit);
    row.patient_count_display = fmtNum(row.patient_count || 0);
    row.drug_visit_count_display = fmtNum(drugVisit);
    row.drug_patient_count_display = fmtNum(row.drug_patient_count || 0);
    row.no_drug_visit_count_display = fmtNum(noDrug);
    row.drug_item_count_display = fmtNum(row.drug_item_count || 0);
    row.drug_total_price_display = fmtMoney(row.drug_total_price || 0);
    row.drug_visit_pct_display = pct.toFixed(1) + '%';
    row.must_pay_count_display = fmtNum(mustPay);
    row.no_pay_count_display = fmtNum(noPay);
    row.must_pay_pct_display = mustPct.toFixed(1) + '%';
    return row;
}

function mergeMetricMaps(map, rows, keyFn) {
    (rows || []).forEach(r => {
        const key = keyFn(r);
        if (!map[key]) {
            map[key] = Object.assign({}, r, {
                visit_count: 0,
                patient_count: 0,
                drug_visit_count: 0,
                drug_patient_count: 0,
                drug_item_count: 0,
                drug_total_price: 0,
                must_pay_count: 0,
                no_pay_count: 0,
            });
        }
        const t = map[key];
        t.visit_count += Number(r.visit_count || 0);
        t.patient_count += Number(r.patient_count || 0);
        t.drug_visit_count += Number(r.drug_visit_count || 0);
        t.drug_patient_count += Number(r.drug_patient_count || 0);
        t.drug_item_count += Number(r.drug_item_count || 0);
        t.drug_total_price += Number(r.drug_total_price || 0);
        t.must_pay_count += Number(r.must_pay_count || 0);
        t.no_pay_count += Number(r.no_pay_count || 0);
    });
}

function finalizeMetricMap(map, sortKey) {
    const rows = Object.keys(map).map(k => enrichMetrics(map[k]));
    const totalVisits = rows.reduce((s, r) => s + Number(r.visit_count || 0), 0);
    rows.forEach(r => {
        const pct = totalVisits > 0 ? (Number(r.visit_count || 0) * 100 / totalVisits) : 0;
        r.pct_share = pct;
        r.pct_share_display = pct.toFixed(1) + '%';
    });
    rows.sort((a, b) => Number(b[sortKey] || 0) - Number(a[sortKey] || 0));
    return rows;
}

/** รวมผลจากหลายช่วงวัน + rollup ตาม granularity ที่เลือกบน UI */
function mergeChunkReports(chunkReports, granularity) {
    const periodMap = {};
    const pointMap = {};
    const doctorMap = {};
    const pharmacistMap = {};
    let elapsed = 0;
    let periodLabel = '';

    chunkReports.forEach(rep => {
        if (!rep || rep.status !== 'success') return;
        elapsed += Number((rep.meta && rep.meta.elapsed_ms) || 0);
        if (!periodLabel && rep.period && rep.period.label) periodLabel = rep.period.label;
        mergeMetricMaps(periodMap, rep.periods || [], r => r.period_key || r.period_label);
        mergeMetricMaps(pointMap, rep.service_points || [], r => (r.dept_code || '') + '|' + (r.dept_name || ''));
        mergeMetricMaps(doctorMap, rep.doctors || [], r => (r.doctor_code || '') + '|' + (r.doctor_name || ''));
        mergeMetricMaps(pharmacistMap, rep.pharmacists || [], r => (r.pharmacist_code || '') + '|' + (r.pharmacist_name || ''));
    });

    let periods = finalizeMetricMap(periodMap, 'period_key');
    periods.sort((a, b) => String(a.period_key).localeCompare(String(b.period_key)));

    if (granularity === 'month' || granularity === 'year') {
        const rolled = {};
        periods.forEach(r => {
            const key = granularity === 'year'
                ? String(r.period_key || '').substring(0, 4)
                : String(r.period_key || '').substring(0, 7);
            if (!key) return;
            if (!rolled[key]) {
                rolled[key] = {
                    period_key: key,
                    period_label: key,
                    visit_count: 0,
                    patient_count: 0,
                    drug_visit_count: 0,
                    drug_patient_count: 0,
                    drug_item_count: 0,
                    drug_total_price: 0,
                };
            }
            const t = rolled[key];
            t.visit_count += Number(r.visit_count || 0);
            t.patient_count += Number(r.patient_count || 0);
            t.drug_visit_count += Number(r.drug_visit_count || 0);
            t.drug_patient_count += Number(r.drug_patient_count || 0);
            t.drug_item_count += Number(r.drug_item_count || 0);
            t.drug_total_price += Number(r.drug_total_price || 0);
            t.must_pay_count = (t.must_pay_count || 0) + Number(r.must_pay_count || 0);
            t.no_pay_count = (t.no_pay_count || 0) + Number(r.no_pay_count || 0);
        });
        periods = Object.keys(rolled).sort().map(k => enrichMetrics(rolled[k]));
    }

    const summary = enrichMetrics({
        visit_count: periods.reduce((s, r) => s + Number(r.visit_count || 0), 0),
        patient_count: periods.reduce((s, r) => s + Number(r.patient_count || 0), 0),
        drug_visit_count: periods.reduce((s, r) => s + Number(r.drug_visit_count || 0), 0),
        drug_patient_count: periods.reduce((s, r) => s + Number(r.drug_patient_count || 0), 0),
        drug_item_count: periods.reduce((s, r) => s + Number(r.drug_item_count || 0), 0),
        drug_total_price: periods.reduce((s, r) => s + Number(r.drug_total_price || 0), 0),
        must_pay_count: periods.reduce((s, r) => s + Number(r.must_pay_count || 0), 0),
        no_pay_count: periods.reduce((s, r) => s + Number(r.no_pay_count || 0), 0),
        period_count: periods.length,
    });

    return {
        status: 'success',
        period: { label: ($('#filterStart').val() || '') + ' ถึง ' + ($('#filterEnd').val() || ''), start_date: $('#filterStart').val(), end_date: $('#filterEnd').val() },
        granularity: granularity,
        summary: summary,
        periods: periods,
        service_points: padServicePointsToSelected(finalizeMetricMap(pointMap, 'visit_count')),
        doctors: finalizeMetricMap(doctorMap, 'visit_count').slice(0, 200),
        pharmacists: (function() {
            const rows = finalizeMetricMap(pharmacistMap, 'drug_item_count');
            const totalItems = rows.reduce((s, r) => s + Number(r.drug_item_count || 0), 0);
            rows.forEach(r => {
                const pct = totalItems > 0 ? (Number(r.drug_item_count || 0) * 100 / totalItems) : 0;
                r.pct_share = pct;
                r.pct_share_display = pct.toFixed(1) + '%';
            });
            return rows.slice(0, 200);
        })(),
        details: [],
        filters: {
            mode: currentMode,
            dep_count: getSelectedDepCodes().length,
            time_label: ($('#filterTimeStart').val() || '16:30') + '–' + ($('#filterTimeEnd').val() || '20:30') + ' (อุบัติเหตุ/ฟื้นฟู)',
        },
        meta: {
            chunked: true,
            chunk_count: chunkReports.length,
            elapsed_ms: elapsed,
            drug_definition: 'รับยาจริง = มีรายการใน drugitems ของ visit นั้น (qty>0 และ sum_price>0)',
        },
    };
}

function getFilteredDetails() {
    const q = ($('#detailSearch').val() || '').trim().toLowerCase();
    const drugMode = $('#detailDrugFilter').val() || 'all';
    return detailRows.filter(r => {
        if (drugMode === 'drug' && !r.has_drug) return false;
        if (drugMode === 'nodrug' && r.has_drug) return false;
        if (!q) return true;
        const blob = [r.patient_name, r.hn, r.vn, r.dept_name, r.service_group, r.doctor_name, r.pharmacist_names, r.has_drug_label, r.pay_status, r.pttype_name].join(' ').toLowerCase();
        return blob.indexOf(q) !== -1;
    });
}

function getDetailSortValue(row, key) {
    switch (key) {
        case 'visit_date':
            return String(row.visit_date || row.visit_date_display || '');
        case 'visit_time':
            return String(row.visit_time || '');
        case 'patient_name':
            return String(row.patient_name || '');
        case 'hn':
            return String(row.hn || '');
        case 'vn':
            return String(row.vn || '');
        case 'dept_name':
            return String(row.dept_name || '');
        case 'doctor_name':
            return String(row.doctor_name || '');
        case 'pharmacist_names':
            return String(row.pharmacist_names || '');
        case 'has_drug':
            return row.has_drug ? 1 : 0;
        case 'must_pay':
            return row.must_pay ? 1 : 0;
        case 'drug_item_count':
            return Number(row.drug_item_count || 0);
        default:
            return '';
    }
}

function compareDetailSort(a, b, key, dir) {
    const mul = dir === 'desc' ? -1 : 1;
    const va = getDetailSortValue(a, key);
    const vb = getDetailSortValue(b, key);
    if (typeof va === 'number' && typeof vb === 'number') {
        return (va - vb) * mul;
    }
    return String(va).localeCompare(String(vb), 'th', { numeric: true, sensitivity: 'base' }) * mul;
}

function getSortedFilteredDetails() {
    const rows = getFilteredDetails().slice();
    if (!detailSortKey) return rows;
    rows.sort((a, b) => {
        const c = compareDetailSort(a, b, detailSortKey, detailSortDir);
        if (c !== 0) return c;
        const d = compareDetailSort(a, b, 'visit_date', 'asc');
        if (d !== 0) return d;
        const t = compareDetailSort(a, b, 'visit_time', 'asc');
        if (t !== 0) return t;
        return compareDetailSort(a, b, 'vn', 'asc');
    });
    return rows;
}

function updateDetailSortHeaders() {
    $('.detail-sort-th').each(function() {
        const key = $(this).data('sort-key');
        $(this).removeClass('sort-asc sort-desc');
        if (key && key === detailSortKey) {
            $(this).addClass(detailSortDir === 'asc' ? 'sort-asc' : 'sort-desc');
        }
    });
}

function refreshDetailTable() {
    $('#detailTbody').html(renderDetailRows(getSortedFilteredDetails()));
    updateDetailSortHeaders();
}

function renderPeriodRows(rows) {
    if (!rows || !rows.length) return '<tr><td colspan="8" class="text-center py-4 text-muted">ไม่มีข้อมูล</td></tr>';
    return rows.map(r => '<tr>'
        + '<td class="text-center fw-bold">' + esc(r.period_label) + '</td>'
        + '<td class="text-center">' + esc(r.visit_count_display) + '</td>'
        + '<td class="text-center text-success">' + esc(r.drug_visit_count_display) + '</td>'
        + '<td class="text-center text-secondary">' + esc(r.no_drug_visit_count_display) + '</td>'
        + '<td class="text-center text-danger">' + esc(r.must_pay_count_display || '0') + '</td>'
        + '<td class="text-center" style="color:#0369a1;">' + esc(r.no_pay_count_display || '0') + '</td>'
        + '<td class="text-center">' + esc(r.drug_item_count_display) + '</td>'
        + '<td class="text-center">' + esc(r.drug_visit_pct_display) + '</td>'
        + '</tr>').join('');
}

/** เติมแถวให้ครบทุกจุดที่ติ๊ก checkbox (รวมจำนวน 0) */
function padServicePointsToSelected(rows) {
    const byCode = {};
    (rows || []).forEach(r => {
        const code = String(r.dept_code || '').trim();
        if (code) byCode[code] = r;
    });
    const depByCode = {};
    (allDepartments || []).forEach(d => { depByCode[d.dep_code] = d; });

    const selectedSet = new Set(getSelectedDepCodes());
    const orderedCodes = [];
    (allDepartments || []).forEach(d => {
        if (selectedSet.has(d.dep_code)) orderedCodes.push(d.dep_code);
    });
    getSelectedDepCodes().forEach(c => {
        if (!orderedCodes.includes(c)) orderedCodes.push(c);
    });

    const out = orderedCodes.map(code => {
        const dep = depByCode[code] || {};
        const group = (dep.shift_group === 'si' || dep.is_si) ? 'SI'
            : (dep.shift_group === 'so' || dep.is_so) ? 'SO'
            : 'SO';
        const existing = byCode[code];
        if (existing) {
            return enrichMetrics(Object.assign({}, existing, {
                dept_code: code,
                dept_name: dep.dep_name || existing.dept_name || code,
                service_group: existing.service_group || group,
            }));
        }
        return enrichMetrics({
            service_group: group,
            dept_code: code,
            dept_name: dep.dep_name || code || 'ไม่ระบุ',
            visit_count: 0,
            patient_count: 0,
            drug_visit_count: 0,
            drug_patient_count: 0,
            drug_item_count: 0,
            drug_total_price: 0,
            must_pay_count: 0,
            no_pay_count: 0,
        });
    });

    const totalVisits = out.reduce((s, r) => s + Number(r.visit_count || 0), 0);
    out.forEach(r => {
        const pct = totalVisits > 0 ? (Number(r.visit_count || 0) * 100 / totalVisits) : 0;
        r.pct_share = pct;
        r.pct_share_display = pct.toFixed(1) + '%';
        r.chart_label = r.dept_name + (r.dept_code ? ' (' + r.dept_code + ')' : '');
    });

    // เรียง: มีผู้ป่วยก่อน ภายในกลุ่ม SI/SO — แต่ยังครบทุก checkbox
    out.sort((a, b) => {
        const ga = a.service_group === 'SI' ? 0 : 1;
        const gb = b.service_group === 'SI' ? 0 : 1;
        if (ga !== gb) return ga - gb;
        const dv = Number(b.visit_count || 0) - Number(a.visit_count || 0);
        if (dv !== 0) return dv;
        return String(a.dept_name || '').localeCompare(String(b.dept_name || ''), 'th');
    });
    return out;
}

function renderPointRows(rows) {
    if (!rows || !rows.length) return '<tr><td colspan="7" class="text-center py-4 text-muted">ไม่มีข้อมูล</td></tr>';
    return rows.map(r => {
        const g = String(r.service_group || '');
        let gBadge = esc(g);
        if (g === 'SI') gBadge = '<span class="badge bg-danger">SI</span>';
        else if (g === 'SO') gBadge = '<span class="badge bg-primary">SO</span>';
        const name = esc(r.dept_name || '—')
            + (r.dept_code ? ' <span class="text-muted small">(' + esc(r.dept_code) + ')</span>' : '');
        const zeroCls = Number(r.visit_count || 0) === 0 ? ' text-muted' : '';
        return '<tr class="' + zeroCls.trim() + '">'
            + '<td class="text-start">' + gBadge + '</td>'
            + '<td class="text-start fw-bold">' + name + '</td>'
            + '<td class="text-center">' + esc(r.visit_count_display) + '</td>'
            + '<td class="text-center text-success">' + esc(r.drug_visit_count_display) + '</td>'
            + '<td class="text-center">' + esc(r.drug_item_count_display) + '</td>'
            + '<td class="text-center">' + esc(r.drug_visit_pct_display) + '</td>'
            + '<td class="text-center">' + esc(r.pct_share_display || '0%') + '</td>'
            + '</tr>';
    }).join('');
}

function renderDoctorRows(rows) {
    if (!rows || !rows.length) return '<tr><td colspan="5" class="text-center py-4 text-muted">ไม่มีข้อมูล</td></tr>';
    return rows.map(r => '<tr>'
        + '<td class="text-start fw-bold">' + esc(r.doctor_name)
        + (r.doctor_code ? ' <span class="text-muted small">(' + esc(r.doctor_code) + ')</span>' : '') + '</td>'
        + '<td class="text-center">' + esc(r.visit_count_display) + '</td>'
        + '<td class="text-center text-success">' + esc(r.drug_visit_count_display) + '</td>'
        + '<td class="text-center">' + esc(r.drug_item_count_display) + '</td>'
        + '<td class="text-center">' + esc(r.drug_visit_pct_display) + '</td>'
        + '</tr>').join('');
}

function renderPharmacistRows(rows) {
    if (!rows || !rows.length) return '<tr><td colspan="6" class="text-center py-4 text-muted">ไม่มีข้อมูล</td></tr>';
    return rows.map(r => '<tr>'
        + '<td class="text-start fw-bold">' + esc(r.pharmacist_name || 'ไม่ระบุ')
        + (r.pharmacist_code ? ' <span class="text-muted small">(' + esc(r.pharmacist_code) + ')</span>' : '') + '</td>'
        + '<td class="text-center text-success">' + esc(r.drug_visit_count_display || r.visit_count_display) + '</td>'
        + '<td class="text-center">' + esc(r.patient_count_display) + '</td>'
        + '<td class="text-center">' + esc(r.drug_item_count_display) + '</td>'
        + '<td class="text-end">' + esc(r.drug_total_price_display) + '</td>'
        + '<td class="text-center">' + esc(r.pct_share_display || '0%') + '</td>'
        + '</tr>').join('');
}

function renderDetailRows(rows) {
    if (!rows || !rows.length) {
        const emptyMsg = detailRows.length ? 'ไม่พบรายการที่ค้นหา' : 'ยังไม่ได้โหลดรายละเอียด';
        return '<tr><td colspan="12" class="text-center py-4 text-muted">' + emptyMsg + '</td></tr>';
    }
    return rows.map((r, i) => {
        const badge = r.has_drug ? '<span class="badge badge-drug">มียา</span>' : '<span class="badge badge-nodrug">ไม่มียา</span>';
        const payBadge = r.must_pay
            ? '<span class="badge bg-danger">ชำระแล้ว' + (r.paid_money_display ? ' ' + esc(r.paid_money_display) : '') + '</span>'
            : '<span class="badge bg-secondary">ไม่ได้ชำระ</span>';
        return '<tr>'
            + '<td class="text-center">' + (i + 1) + '</td>'
            + '<td class="text-center">' + esc(r.visit_date_display) + '</td>'
            + '<td class="text-center">' + esc(r.visit_time || '—') + '</td>'
            + '<td>' + esc(r.patient_name || '—') + '</td>'
            + '<td class="text-center"><code>' + esc(r.hn || '—') + '</code></td>'
            + '<td class="text-center"><code>' + esc(r.vn || '—') + '</code></td>'
            + '<td>' + esc(r.dept_name || '—') + '</td>'
            + '<td>' + esc(r.doctor_name || '—') + '</td>'
            + '<td>' + esc(r.pharmacist_names || (r.has_drug ? '—' : '')) + '</td>'
            + '<td class="text-center">' + badge + '</td>'
            + '<td class="text-center">' + payBadge + '</td>'
            + '<td class="text-center">' + esc(r.drug_item_count_display) + '</td>'
            + '</tr>';
    }).join('');
}

function formatChartStat(n) {
    const v = Number(n);
    if (!isFinite(v)) return '—';
    if (Math.abs(v - Math.round(v)) < 0.05) return String(Math.round(v));
    return v.toFixed(1);
}

function updateSummaryChartStats(values) {
    const el = document.getElementById('summaryChartStats');
    if (!el) return;
    const nums = (values || []).map(Number).filter(v => isFinite(v));
    if (!nums.length) { el.classList.add('d-none'); el.innerHTML = ''; return; }
    const min = Math.min.apply(null, nums);
    const max = Math.max.apply(null, nums);
    const avg = nums.reduce((a, b) => a + b, 0) / nums.length;
    el.innerHTML =
        '<div class="stat-line stat-avg">Avg <strong>' + formatChartStat(avg) + '</strong></div>' +
        '<div class="stat-line stat-max">Max <strong>' + formatChartStat(max) + '</strong></div>' +
        '<div class="stat-line stat-min">Min <strong>' + formatChartStat(min) + '</strong></div>';
    el.classList.remove('d-none');
}

function palette(n) {
    const out = [];
    for (let i = 0; i < n; i++) out.push(CHART_COLORS[i % CHART_COLORS.length]);
    return out;
}

function renderSummaryChart(rows) {
    const ctx = document.getElementById('summaryChart');
    if (!ctx || typeof Chart === 'undefined') return;
    if (summaryChart) { summaryChart.destroy(); summaryChart = null; }
    if (!rows || !rows.length) return;
    const visits = rows.map(r => Number(r.visit_count) || 0);
    const drugs = rows.map(r => Number(r.drug_visit_count) || 0);
    updateSummaryChartStats(visits);
    summaryChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: rows.map(r => r.period_label),
            datasets: [
                { label: 'ผู้ป่วยทั้งหมด', data: visits, backgroundColor: '#0369a1', borderRadius: 4 },
                { label: 'รับยาจริง', data: drugs, backgroundColor: '#198754', borderRadius: 4 },
            ]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            layout: { padding: { top: 8, right: 88 } },
            plugins: { legend: { display: true, position: 'top' } },
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
        }
    });
}

function renderHBarChart(canvasId, wrapId, hintId, rows, labelKey, getChart, setChart, opts) {
    opts = opts || {};
    const ctx = document.getElementById(canvasId);
    if (!ctx || typeof Chart === 'undefined') return;
    const old = getChart();
    if (old) { old.destroy(); setChart(null); }
    if (!rows || !rows.length) {
        $(hintId).text('');
        $(wrapId).css('height', '240px');
        return;
    }
    const limit = opts.limit != null ? opts.limit : 20;
    const top = limit <= 0 ? rows.slice() : rows.slice(0, limit);
    const rowH = opts.rowHeight || 26;
    const maxH = opts.maxHeight || 640;
    $(wrapId).css('height', Math.max(240, Math.min(maxH, 40 + top.length * rowH)) + 'px');
    const hint = opts.hint != null
        ? opts.hint
        : (rows.length > top.length ? ('Top ' + top.length + '/' + rows.length) : (rows.length + ' รายการ'));
    $(hintId).text(hint);
    setChart(new Chart(ctx, {
        type: 'bar',
        data: {
            labels: top.map(r => r[labelKey] || r.dept_name || ''),
            datasets: [{ label: 'ผู้ป่วย (VN)', data: top.map(r => Number(r.visit_count) || 0), backgroundColor: palette(top.length), borderRadius: 4 }]
        },
        options: {
            indexAxis: 'y', responsive: true, maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        afterLabel: function(c) {
                            const row = top[c.dataIndex];
                            if (!row) return '';
                            return ['รับยาจริง: ' + (row.drug_visit_count_display || 0), 'รายการยา: ' + (row.drug_item_count_display || 0)];
                        }
                    }
                }
            },
            scales: { x: { beginAtZero: true, ticks: { precision: 0 } }, y: { ticks: { autoSkip: false } } }
        }
    }));
}

function populateDoctorSelect(doctors) {
    const prev = $('#filterDoctor').val() || [];
    const $sel = $('#filterDoctor');
    $sel.empty();
    (doctors || []).forEach(d => {
        if (!d.doctor_code) return;
        const label = (d.doctor_name || d.doctor_code) + ' (' + (d.visit_count || 0) + ')';
        $sel.append($('<option></option>').attr('value', d.doctor_code).text(label));
    });
    if (prev.length) $sel.val(prev);
}

async function loadDepartments() {
    const data = await fetchJson(SMC_API + '?action=departments');
    if (data.status !== 'success') throw new Error(data.message || 'โหลดจุดบริการไม่สำเร็จ');
    allDepartments = data.departments || [];
    shift4hCodes = data.shift4h_codes || allDepartments.filter(d => d.is_shift4h).map(d => d.dep_code);
    siCodes = data.si_codes || allDepartments.filter(d => d.shift_group === 'si' || d.is_si).map(d => d.dep_code);
    soCodes = data.so_codes || allDepartments.filter(d => d.shift_group === 'so' || d.is_so).map(d => d.dep_code);
    renderDepList();
    applyMode('shift4h');
}

function exportExcel() {
    const rows = getSortedFilteredDetails();
    if (!rows.length || typeof XLSX === 'undefined') {
        alert(rows.length ? 'ไม่สามารถโหลดไลบรารี Excel ได้' : 'ไม่มีข้อมูลสำหรับส่งออก');
        return;
    }
    const headers = ['ลำดับ','วันที่','เวลา','ชื่อ-นามสกุล','HN','VN','กลุ่ม','จุดรับบริการ','แพทย์','เภสัชกรผู้จ่าย','สถานะยา','การชำระเงิน','ชำระแล้ว','สิทธิ์','รายการยา','มูลค่ายา'];
    const data = rows.map((r, i) => [
        i + 1, r.visit_date_display || '', r.visit_time || '', r.patient_name || '', r.hn || '', r.vn || '',
        r.service_group || '', r.dept_name || '', r.doctor_name || '', r.pharmacist_names || '', r.has_drug_label || '',
        r.pay_status || '', r.paid_money || 0, r.pttype_name || '', r.drug_item_count || 0, r.drug_total_price || 0
    ]);
    const ws = XLSX.utils.aoa_to_sheet([headers].concat(data));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'SMC AfterHours');
    XLSX.writeFile(wb, 'smc_afterhours_' + ($('#filterStart').val() || '') + '_' + ($('#filterEnd').val() || '') + '.xlsx');
}

async function loadSmcReport() {
    const deps = getSelectedDepCodes();
    if (!deps.length) {
        alert('กรุณาเลือกจุดรับบริการอย่างน้อย 1 จุด');
        return;
    }
    const start = $('#filterStart').val();
    const end = $('#filterEnd').val();
    const chunks = splitDateChunks(start, end, 1);
    if (!chunks.length) {
        alert('ช่วงวันที่ไม่ถูกต้อง');
        return;
    }

    $('#btnLoad').prop('disabled', true);
    $('#btnLoadDetail').prop('disabled', true);
    $('#btnExportExcel').prop('disabled', true);
    detailRows = [];
    $('#detailTbody').html('<tr><td colspan="12" class="text-center py-4 text-muted">โหลดสรุปก่อน แล้วกด «โหลดรายละเอียด»</td></tr>');
    $('#periodTbody,#pointTbody,#doctorTbody,#pharmacistTbody').html('<tr><td colspan="7" class="text-center py-3 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังโหลดแบบแบ่งช่วง...</td></tr>');
    showProgress(0, chunks.length, 'เตรียมโหลด ' + chunks.length + ' วัน (ขนานสูงสุด 3 ช่วง)');

    try {
        const gran = getGranularity();
        const t0 = performance.now();
        const reports = await mapPool(chunks, 3, async (chunk) => {
            const data = await fetchJson(SMC_API + '?' + qs(getReportParams('summary', chunk.start, chunk.end)));
            if (data.status !== 'success') {
                throw new Error((data.message || 'โหลดไม่สำเร็จ') + ' [' + chunk.start + ']');
            }
            return data;
        }, (done, total, chunk) => {
            showProgress(done, total, 'โหลดสรุป ' + done + '/' + total + (chunk ? ' (ถึง ' + chunk.end + ')' : ''));
        });

        const data = mergeChunkReports(reports, gran);
        data.meta.wall_ms = Math.round(performance.now() - t0);
        currentReport = data;
        const sum = data.summary || {};

        $('#sumVisits').text(sum.visit_count_display || '0');
        $('#sumDrugVisits').text(sum.drug_visit_count_display || '0');
        $('#sumDrugPct').text(sum.drug_visit_pct_display ? ('คิดเป็น ' + sum.drug_visit_pct_display) : '');
        $('#sumNoDrug').text(sum.no_drug_visit_count_display || '0');
        $('#sumItems').text(sum.drug_item_count_display || '0');
        $('#sumMustPay').text(sum.must_pay_count_display || '0');
        $('#sumMustPayPct').text(sum.must_pay_pct_display ? ('คิดเป็น ' + sum.must_pay_pct_display) : '');
        $('#sumNoPay').text(sum.no_pay_count_display || '0');

        $('#periodHeader').text(granularityLabel(gran));
        $('#periodTbody').html(renderPeriodRows(data.periods || []));
        $('#pointTbody').html(renderPointRows(data.service_points || []));
        $('#doctorTbody').html(renderDoctorRows(data.doctors || []));
        $('#pharmacistTbody').html(renderPharmacistRows(data.pharmacists || []));
        populateDoctorSelect(data.doctors || []);
        renderSummaryChart(data.periods || []);
        const points = data.service_points || [];
        renderHBarChart('pointChart', '#pointChartWrap', '#pointChartHint', points, 'chart_label', () => pointChart, c => { pointChart = c; }, {
            limit: 0,
            rowHeight: 28,
            maxHeight: 900,
            hint: points.length + ' จุดที่เลือก',
        });
        renderHBarChart('doctorChart', '#doctorChartWrap', '#doctorChartHint', data.doctors || [], 'doctor_name', () => doctorChart, c => { doctorChart = c; });
        renderHBarChart('pharmacistChart', '#pharmacistChartWrap', '#pharmacistChartHint', data.pharmacists || [], 'pharmacist_name', () => pharmacistChart, c => { pharmacistChart = c; });

        const meta = data.meta || {};
        const filters = data.filters || {};
        let metaHtml = '<i class="fas fa-info-circle me-1"></i>ช่วง: ' + esc((data.period && data.period.label) || '');
        metaHtml += ' | เวลา ' + esc(filters.time_label || '');
        metaHtml += ' | จุดบริการ ' + esc(filters.dep_count || deps.length) + ' จุด';
        metaHtml += ' | แบ่ง ' + esc(meta.chunk_count || chunks.length) + ' วัน โหลดขนาน';
        if (meta.wall_ms != null) metaHtml += ' | ใช้เวลา ' + (meta.wall_ms / 1000).toFixed(2) + ' วินาที';
        $('#metaBox').removeClass('d-none alert-danger').addClass('alert-info').html(metaHtml);
        $('#btnLoadDetail').prop('disabled', false);
    } catch (err) {
        const msg = esc(err.message || 'เกิดข้อผิดพลาด');
        $('#sumVisits,#sumDrugVisits,#sumNoDrug,#sumItems,#sumMustPay,#sumNoPay').text('0');
        $('#sumDrugPct,#sumMustPayPct').text('');
        $('#periodTbody,#pointTbody,#doctorTbody,#pharmacistTbody').html('<tr><td colspan="7" class="text-center text-danger py-3">' + msg + '</td></tr>');
        $('#metaBox').removeClass('d-none alert-info').addClass('alert-danger').html('<i class="fas fa-exclamation-circle me-1"></i>' + msg);
        if (summaryChart) { summaryChart.destroy(); summaryChart = null; }
        if (pointChart) { pointChart.destroy(); pointChart = null; }
        if (doctorChart) { doctorChart.destroy(); doctorChart = null; }
        if (pharmacistChart) { pharmacistChart.destroy(); pharmacistChart = null; }
    } finally {
        hideProgress();
        $('#btnLoad').prop('disabled', false);
    }
}

async function loadSmcDetails() {
    if (!getSelectedDepCodes().length) {
        alert('กรุณาเลือกจุดรับบริการอย่างน้อย 1 จุด');
        return;
    }
    const chunks = splitDateChunks($('#filterStart').val(), $('#filterEnd').val(), 1);
    if (!chunks.length) {
        alert('ช่วงวันที่ไม่ถูกต้อง');
        return;
    }

    $('#btnLoadDetail').prop('disabled', true);
    $('#detailTbody').html('<tr><td colspan="12" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังโหลดรายละเอียดแบบแบ่งช่วง...</td></tr>');
    showProgress(0, chunks.length, 'เตรียมโหลดรายละเอียด ' + chunks.length + ' วัน');

    try {
        const parts = await mapPool(chunks, 2, async (chunk) => {
            const data = await fetchJson(SMC_API + '?' + qs(getReportParams('details', chunk.start, chunk.end)));
            if (data.status !== 'success') {
                throw new Error((data.message || 'โหลดรายละเอียดไม่สำเร็จ') + ' [' + chunk.start + ']');
            }
            return data.details || [];
        }, (done, total, chunk) => {
            showProgress(done, total, 'รายละเอียด ' + done + '/' + total + (chunk ? ' (ถึง ' + chunk.end + ')' : ''));
        });

        detailRows = [];
        parts.forEach(rows => { detailRows = detailRows.concat(rows || []); });
        // จำกัดแสดงผลถ้ามากเกินไป
        const maxRows = 5000;
        let truncated = false;
        if (detailRows.length > maxRows) {
            detailRows = detailRows.slice(0, maxRows);
            truncated = true;
        }
        $('#detailSearch').val('');
        $('#detailDrugFilter').val('all');
        detailSortKey = 'visit_date';
        detailSortDir = 'asc';
        refreshDetailTable();
        $('#btnExportExcel').prop('disabled', !detailRows.length);

        let extra = ' | รายละเอียด ' + detailRows.length + ' แถว (แบ่ง ' + chunks.length + ' วัน)';
        if (truncated) extra += ' แสดงสูงสุด ' + maxRows;
        const box = $('#metaBox');
        if (box.hasClass('alert-info')) box.append(esc(extra));
    } catch (err) {
        $('#detailTbody').html('<tr><td colspan="12" class="text-center text-danger py-4">' + esc(err.message || 'เกิดข้อผิดพลาด') + '</td></tr>');
        $('#btnExportExcel').prop('disabled', true);
    } finally {
        hideProgress();
        $('#btnLoadDetail').prop('disabled', false);
    }
}

$(function() {
    if (typeof flatpickr !== 'undefined') {
        fpStart = flatpickr('#filterStart', { dateFormat: 'Y-m-d' });
        fpEnd = flatpickr('#filterEnd', { dateFormat: 'Y-m-d' });
    }
    $('#modeTabs').on('click', '.nav-link', function() {
        applyMode($(this).data('mode'));
    });
    $(document).on('change', '.dep-check', function() {
        if (this.checked) selectedDepSet.add(this.value);
        else selectedDepSet.delete(this.value);
        updateDepSelectedCount();
    });
    $(document).on('input', '#depSearch', renderDepList);
    $(document).on('click', '.detail-sort-th[data-sort-key]', function() {
        const key = String($(this).data('sort-key') || '');
        if (!key || !detailRows.length) return;
        if (detailSortKey === key) {
            detailSortDir = detailSortDir === 'asc' ? 'desc' : 'asc';
        } else {
            detailSortKey = key;
            detailSortDir = 'asc';
        }
        refreshDetailTable();
    });
    $(document).on('input change', '#detailSearch, #detailDrugFilter', function() {
        refreshDetailTable();
    });
    $(document).on('change', 'input[name="granularity"]', function() {
        if (currentReport) loadSmcReport();
    });
    loadDepartments().catch(err => {
        $('#depListBox').html('<div class="text-danger small py-2">' + esc(err.message || 'โหลดจุดบริการไม่สำเร็จ') + '</div>');
    });
});
</script>
</body>
</html>
