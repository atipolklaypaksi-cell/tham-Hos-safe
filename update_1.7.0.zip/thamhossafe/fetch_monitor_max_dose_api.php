<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_mg_ml_helper.php');
include(__DIR__ . '/monitor_max_dose_helper.php');
mysqli_set_charset($con, 'utf8');
set_time_limit(180);

function mmdd_api_req($key, $default = '') {
    if (isset($_POST[$key]) && (is_string($_POST[$key]) || is_numeric($_POST[$key]))) {
        return trim((string)$_POST[$key]);
    }
    if (isset($_GET[$key]) && (is_string($_GET[$key]) || is_numeric($_GET[$key]))) {
        return trim((string)$_GET[$key]);
    }
    return $default;
}

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

$start_date = mmdd_api_req('start_date', date('Y-m-d', strtotime('-3 days')));
$end_date = mmdd_api_req('end_date', date('Y-m-d'));
$recent_minutes = (int)mmdd_api_req('recent_minutes', '0');

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-3 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if (strtotime($start_date) > strtotime($end_date)) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}
if ($recent_minutes < 0) {
    $recent_minutes = 0;
}
if ($recent_minutes > 1440) {
    $recent_minutes = 1440;
}

$rule_ids = [];
$rule_ids_raw = mmdd_api_req('rule_ids', '');
if ($rule_ids_raw !== '') {
    foreach (explode(',', $rule_ids_raw) as $rid) {
        $rid = (int)trim($rid);
        if ($rid > 0) {
            $rule_ids[] = $rid;
        }
    }
}

$rules = mmdd_load_active_rules($con, $rule_ids);
if (empty($rules)) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'meta' => [
            'message' => 'ยังไม่มีกฎที่เปิดใช้งาน — ไปที่แท็บตั้งค่า',
            'rule_count' => 0,
        ],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}

$rule_by_icode = [];
foreach ($rules as $rule) {
    $ic = trim($rule['icode'] ?? '');
    if ($ic === '') {
        continue;
    }
    $rule_by_icode[$ic][] = $rule;
}

if (empty($rule_by_icode)) {
    mysqli_close($hos);
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'meta' => ['rule_count' => 0],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$t0 = microtime(true);
$hn_raw = function_exists('monitor_req_hn') ? monitor_req_hn() : mmdd_api_req('hn', '');
$order_rows = mmgml_fetch_orders_lean($hos, array_keys($rule_by_icode), $start_date, $end_date, $recent_minutes, 8000, $hn_raw);
$order_rows = mmgml_enrich_monitor_orders($hos, $order_rows, [
    'drug' => true,
    'method' => true,
    'patient' => false,
    'ward' => false,
]);

$duration_icodes = [];
foreach ($rule_by_icode as $ic => $rs) {
    if (mmdd_icode_needs_duration($rs)) {
        $duration_icodes[$ic] = true;
    }
}
$lookback = mmdd_duration_lookback_days($rules);
$duration_cache = ['_lookback' => $lookback];
if ($lookback > 0 && $duration_icodes && $order_rows) {
    $pairs = [];
    foreach ($order_rows as $row) {
        $icode = trim((string)($row['icode'] ?? ''));
        $hn = trim((string)($row['hn'] ?? ''));
        if ($hn === '' || $icode === '' || empty($duration_icodes[$icode])) {
            continue;
        }
        $pairs[$hn . '|' . $icode] = true;
    }
    if ($pairs) {
        mmdd_prefetch_rx_dates($hos, array_keys($pairs), $end_date, $lookback, $duration_cache);
    }
}

$hard_alerts = [];
$soft_alerts = [];
$seen = [];
$orders_scanned = 0;

foreach ($order_rows as $row) {
    $orders_scanned++;
    $icode = trim($row['icode'] ?? '');
    $matched_rules = $rule_by_icode[$icode] ?? [];
    if (empty($matched_rules)) {
        continue;
    }

    $method = trim(preg_replace('/\s+/u', ' ', $row['method'] ?? ''));
    $dose_parsed = hosxp_parse_drug_daily_dose_mg([
        'qty' => $row['qty'],
        'strength' => $row['strength'] ?? '',
        'units' => $row['units'] ?? '',
        'method' => $method,
    ]);
    $daily_mg = isset($dose_parsed['mg_dose']) ? (float)$dose_parsed['mg_dose'] : null;
    $daily_mg_display = di_format_daily_mg_display([
        'qty' => $row['qty'],
        'strength' => $row['strength'] ?? '',
        'units' => $row['units'] ?? '',
        'method' => $method,
    ]);

    $rxdate = trim((string)($row['rxdate'] ?? ''));
    $consecutive_days = (!empty($duration_icodes[$icode]) && $rxdate !== '')
        ? mmdd_consecutive_days($hos, $row['hn'] ?? '', $icode, $rxdate, $duration_cache)
        : 0;

    foreach ($matched_rules as $rule) {
        $reasons = mmdd_build_trigger_reasons($rule, $daily_mg, $consecutive_days);
        if (empty($reasons)) {
            continue;
        }

        $dedupe = implode('|', [
            $row['hn'] ?? '',
            $row['vstdate'] ?? '',
            $row['vn'] ?? '',
            $row['an'] ?? '',
            $icode,
            $row['item_no'] ?? '',
            (int)$rule['id'],
            implode(',', $reasons),
        ]);
        if (isset($seen[$dedupe])) {
            continue;
        }
        $seen[$dedupe] = true;

        $level = mmdd_alert_level($rule);
        $rx_date_fmt = !empty($row['rxdate']) ? date('d/m/Y', strtotime($row['rxdate'])) : '-';
        $rx_time_fmt = di_format_time(monitor_lab_normalize_hosxp_time($row['rxtime'] ?? ''));

        $type_patient = $row['type_patient'] ?? 'OPD';
        $ward_name = trim($row['ward_name'] ?? '');
        $bedno = trim($row['bedno'] ?? '');
        if ($type_patient === 'OPD') {
            $ward_display = 'ผู้ป่วยนอก';
        } else {
            $ward_display = trim($ward_name . ($ward_name && $bedno ? ' / ' : '') . $bedno);
            if ($ward_display === '') {
                $ward_display = '-';
            }
        }

        $alert = [
            'rule_id' => (int)$rule['id'],
            'hn' => ltrim($row['hn'] ?? '', '0'),
            'hn_full' => $row['hn'] ?? '',
            'ptname' => trim($row['ptname'] ?? ''),
            'type_patient' => $type_patient,
            'vstdate' => $row['vstdate'] ?? '',
            'vn' => $row['vn'] ?? '',
            'an' => $row['an'] ?? '',
            'item_no' => $row['item_no'] ?? '',
            'rxdate' => $rxdate,
            'order_date' => $rx_date_fmt,
            'order_time' => $rx_time_fmt,
            'drug_name' => trim($row['drug_name'] ?? ($rule['drug_name'] ?? '')),
            'icode' => $icode,
            'method' => $method,
            'qty' => $row['qty'] ?? '',
            'strength' => trim($row['strength'] ?? ''),
            'daily_mg' => $daily_mg,
            'daily_mg_display' => $daily_mg_display,
            'max_dose_mg_per_day' => (float)($rule['max_dose_mg_per_day'] ?? 0),
            'consecutive_days' => $consecutive_days,
            'max_duration_days' => (int)($rule['max_duration_days'] ?? 0),
            'trigger_reasons' => $reasons,
            'ward_display' => $ward_display,
            'alert_level' => $level,
            'alert_message' => mmdd_default_alert_message($rule, $reasons, $daily_mg, $consecutive_days),
            'detail_text' => trim($rule['detail_text'] ?? ''),
        ];

        if ($level === 'hard') {
            $hard_alerts[] = $alert;
        } else {
            $soft_alerts[] = $alert;
        }
    }
}

if ($hard_alerts || $soft_alerts) {
    $seed = [];
    $seen_seed = [];
    foreach (array_merge($hard_alerts, $soft_alerts) as $a) {
        $hk = trim((string)($a['hn_full'] ?? $a['hn'] ?? '')) . '|' . trim((string)($a['an'] ?? ''));
        if (isset($seen_seed[$hk])) {
            continue;
        }
        $seen_seed[$hk] = true;
        $seed[] = [
            'hn' => $a['hn_full'] ?? $a['hn'] ?? '',
            'an' => $a['an'] ?? '',
            'vn' => $a['vn'] ?? '',
            'icode' => '',
        ];
    }
    $seed = mmgml_enrich_monitor_orders($hos, $seed, [
        'drug' => false,
        'method' => false,
        'patient' => true,
        'ward' => true,
    ]);
    $pt_by_hn = [];
    $ward_by_an = [];
    $bed_by_an = [];
    foreach ($seed as $s) {
        $hn = trim((string)($s['hn'] ?? ''));
        if ($hn !== '') {
            $pt_by_hn[$hn] = trim((string)($s['ptname'] ?? ''));
            $pt_by_hn[ltrim($hn, '0')] = $pt_by_hn[$hn];
        }
        $an = trim((string)($s['an'] ?? ''));
        if ($an !== '') {
            $ward_by_an[$an] = trim((string)($s['ward_name'] ?? ''));
            $bed_by_an[$an] = trim((string)($s['bedno'] ?? ''));
        }
    }
    foreach ([&$hard_alerts, &$soft_alerts] as &$list) {
        foreach ($list as &$a) {
            $hn = trim((string)($a['hn_full'] ?? $a['hn'] ?? ''));
            if ($hn !== '' && isset($pt_by_hn[$hn])) {
                $a['ptname'] = $pt_by_hn[$hn];
            } elseif ($hn !== '' && isset($pt_by_hn[ltrim($hn, '0')])) {
                $a['ptname'] = $pt_by_hn[ltrim($hn, '0')];
            }
            $type_patient = $a['type_patient'] ?? 'OPD';
            $an = trim((string)($a['an'] ?? ''));
            $ward_name = $an !== '' ? ($ward_by_an[$an] ?? '') : '';
            $bedno = $an !== '' ? ($bed_by_an[$an] ?? '') : '';
            if ($type_patient === 'OPD') {
                $a['ward_display'] = 'ผู้ป่วยนอก';
            } else {
                $ward_display = trim($ward_name . ($ward_name && $bedno ? ' / ' : '') . $bedno);
                $a['ward_display'] = $ward_display !== '' ? $ward_display : '-';
            }
        }
        unset($a);
    }
    unset($list);
}

$elapsed = (int)round((microtime(true) - $t0) * 1000);
mysqli_close($hos);
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';

ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'status' => 'success',
    'hard_alerts' => sp_alert_mute_filter_rows($con, $hard_alerts),
    'soft_alerts' => sp_alert_mute_filter_rows($con, $soft_alerts),
    'meta' => [
        'rule_count' => count($rules),
        'hard_count' => count($hard_alerts),
        'soft_count' => count($soft_alerts),
        'orders_scanned' => $orders_scanned,
        'start_date' => $start_date,
        'end_date' => $end_date,
        'recent_minutes' => $recent_minutes,
        'elapsed_ms' => $elapsed,
        'truncated' => ($orders_scanned >= 8000),
    ],
], JSON_UNESCAPED_UNICODE);
