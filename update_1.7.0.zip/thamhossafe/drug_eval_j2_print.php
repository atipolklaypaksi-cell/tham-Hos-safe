<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/drug_eval_j2_helper.php';
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('drug_eval.j2')) {
    echo "<script>alert('คุณไม่มีสิทธิ์เข้าหน้าประเมินยา จ2'); window.location='home.php';</script>";
    exit;
}
dej2_ensure($con);
$row = dej2_get($con, (int)($_GET['id'] ?? 0));
if (!$row) {
    echo 'ไม่พบแบบประเมิน';
    exit;
}
$form = dej2_form($row['form_id']);
if (!$form) {
    echo 'ไม่พบแบบฟอร์มของยานี้';
    exit;
}
$phase = (($row['phase'] ?? '') === 'cont') ? 'cont' : 'first';
$edit = 'drug_eval_j2.php?hn=' . rawurlencode($row['hn'])
    . '&form=' . rawurlencode($row['form_id'])
    . '&icode=' . rawurlencode($row['icode'])
    . '&phase=' . rawurlencode($phase)
    . '&sheet=' . (int)$row['id'];
$when = $row['updated_at'] ?: $row['created_at'];
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title><?= dej2_h($form['doc_title']) ?> — <?= dej2_h(dej2_phase_label($phase)) ?></title>
    <style>
        <?= dej2_css() ?>
        body{margin:0;background:#eef1f4;font-family:Tahoma,sans-serif}
        .bar{display:flex;gap:8px;justify-content:center;padding:12px;background:#fff;border-bottom:1px solid #e5e7eb;position:sticky;top:0}
        .bar a,.bar button{font:inherit;padding:8px 14px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;text-decoration:none;color:#111;cursor:pointer}
        .bar .go{background:#0f766e;color:#fff;border-color:#0f766e}
        .foot{width:210mm;max-width:100%;margin:8px auto 24px;color:#666;font-size:12px}
        @page{size:A4 portrait;margin:12mm}
        @media print{
            body{background:#fff}
            .bar,.foot{display:none}
        }
    </style>
</head>
<body>
<div class="bar">
    <button class="go" type="button" onclick="window.print()">พิมพ์ หรือบันทึกเป็น PDF</button>
    <a href="<?= dej2_h($edit) ?>">แก้ไข</a>
    <a href="drug_eval_j2.php?hn=<?= rawurlencode($row['hn']) ?>">กลับไปเลือกยา</a>
</div>
<?php dej2_render_sheet($form, $phase, $row['answers'], (string)$row['drug_name'], true); ?>
<p class="foot">บันทึกโดย <?= dej2_h($row['evaluator']) ?> · <?= dej2_h($when) ?></p>
</body>
</html>
