<?php
/**
 * Smart Drug — Med Post-op: ดึงยา Continuous (Active) แบบเดียวกับ patient_ipd
 * ใช้ได้เฉพาะผู้ป่วยที่กำลัง Admit อยู่เท่านั้น
 */
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['ok' => false, 'error' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/patient_ipd_helper.php';

if (empty($_SESSION['menu_permissions_loaded']) && isset($con)) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}

$role = (string)($_SESSION['role'] ?? '');
if (!tham_menu_can('pharm_care.smart_drug') && $role !== 'admin') {
    echo json_encode(['ok' => false, 'error' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
    exit;
}

session_write_close();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = array_merge($_GET, $_POST);
}

$action = trim((string)($input['action'] ?? 'active_meds'));
$hn = trim((string)($input['hn'] ?? ''));
$an = trim((string)($input['an'] ?? ''));

if ($action !== 'active_meds' && $action !== 'admit_list') {
    echo json_encode(['ok' => false, 'error' => 'action ไม่รองรับ'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($an === '' && $hn === '') {
    echo json_encode(['ok' => false, 'error' => 'กรุณาระบุ AN หรือ HN'], JSON_UNESCAPED_UNICODE);
    exit;
}

$prefer = $an !== '' ? 'an' : 'hn';
$lookup = pip_lookup($con, $hn, $an, $prefer);
if (empty($lookup['ok'])) {
    echo json_encode([
        'ok' => false,
        'error' => $lookup['error'] ?? 'ดึงข้อมูลไม่สำเร็จ',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$admit = $lookup['admission'] ?? null;
$admissions = is_array($lookup['admissions'] ?? null) ? $lookup['admissions'] : [];
$activeAdmits = [];
foreach ($admissions as $a) {
    if (!empty($a['is_active']) && !empty($a['an'])) {
        $activeAdmits[] = [
            'an' => (string)$a['an'],
            'ward_name' => (string)($a['ward_name'] ?? ''),
            'regdate' => (string)($a['regdate'] ?? ''),
            'regtime' => (string)($a['regtime'] ?? ''),
            'is_active' => 1,
        ];
    }
}
// ถ้า admission ปัจจุบัน active แต่ไม่อยู่ใน list (บาง path) — ใส่เพิ่ม
if ($admit && !empty($admit['is_active']) && !empty($admit['an'])) {
    $found = false;
    foreach ($activeAdmits as $aa) {
        if ($aa['an'] === (string)$admit['an']) {
            $found = true;
            break;
        }
    }
    if (!$found) {
        array_unshift($activeAdmits, [
            'an' => (string)$admit['an'],
            'ward_name' => (string)($admit['ward_name'] ?? ''),
            'regdate' => (string)($admit['regdate'] ?? ''),
            'regtime' => (string)($admit['regtime'] ?? ''),
            'is_active' => 1,
        ]);
    }
}

if ($action === 'admit_list') {
    echo json_encode([
        'ok' => true,
        'hn' => (string)(($lookup['patient']['hn'] ?? $hn)),
        'patient' => [
            'full_name' => (string)(($lookup['patient']['full_name'] ?? '')),
            'age_text' => (string)(($lookup['patient']['age_text'] ?? '')),
            'age_y' => $lookup['patient']['age_y'] ?? null,
            'sex' => (string)(($lookup['patient']['sex'] ?? '')),
        ],
        'allergy' => [
            'has_allergy' => !empty($lookup['allergy']['has_allergy']),
            'text' => (string)(($lookup['allergy']['text'] ?? '')),
        ],
        'admissions' => $activeAdmits,
        'count' => count($activeAdmits),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if (!$admit || empty($admit['is_active'])) {
    echo json_encode([
        'ok' => false,
        'error' => 'Med Post-op ใช้ได้เฉพาะผู้ป่วยที่กำลัง Admit อยู่เท่านั้น'
            . (count($activeAdmits) ? ' — มี AN ที่ Admit อยู่: ' . implode(', ', array_column($activeAdmits, 'an')) : ''),
        'admissions' => $activeAdmits,
        'require_admit' => true,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ถ้าขอ AN ที่ไม่ใช่ admit ปัจจุบัน — ปฏิเสธ
if ($an !== '' && (string)$admit['an'] !== $an && !empty($admit['is_active'])) {
    // pip_lookup ด้วย prefer=an ควรได้ AN นั้น — ถ้าไม่ active จะเข้าเงื่อนไขด้านบนแล้ว
}

$groups = $lookup['groups']['active'] ?? ['injection' => [], 'other' => []];
$patient = $lookup['patient'] ?? [];
$allergy = $lookup['allergy'] ?? [];

$flat = [];
foreach (['injection', 'other'] as $gkey) {
    foreach (($groups[$gkey] ?? []) as $it) {
        $flat[] = [
            'med_plan_number' => (int)($it['med_plan_number'] ?? 0),
            'icode' => (string)($it['icode'] ?? ''),
            'name' => (string)($it['name'] ?? ''),
            'usage' => (string)($it['usage'] ?? ''),
            'qty' => $it['qty'] ?? '',
            'orderdate' => (string)($it['orderdate'] ?? ''),
            'orderdate_th' => (string)($it['orderdate_th'] ?? ''),
            'orderdate_dmy' => (string)($it['orderdate_dmy'] ?? ''),
            'offdate' => (string)($it['offdate'] ?? ''),
            'offdate_th' => (string)($it['offdate_th'] ?? ''),
            'offdate_dmy' => (string)($it['offdate_dmy'] ?? ''),
            'group' => (string)($it['group'] ?? $gkey),
            'is_injection' => !empty($it['is_injection']) ? 1 : 0,
            'note' => (string)($it['note'] ?? ''),
        ];
    }
}

echo json_encode([
    'ok' => true,
    'hn' => (string)($patient['hn'] ?? $hn),
    'an' => (string)($admit['an'] ?? $an),
    'patient' => [
        'full_name' => (string)($patient['full_name'] ?? ''),
        'age_text' => (string)($patient['age_text'] ?? ''),
        'age_y' => $patient['age_y'] ?? null,
        'sex' => (string)($patient['sex'] ?? ''),
    ],
    'admission' => [
        'an' => (string)($admit['an'] ?? ''),
        'ward_name' => (string)($admit['ward_name'] ?? ''),
        'regdate' => (string)($admit['regdate'] ?? ''),
        'regtime' => (string)($admit['regtime'] ?? ''),
        'pttype' => (string)($admit['pttype'] ?? ''),
        'pttype_name' => (string)($admit['pttype_name'] ?? ''),
        'is_active' => !empty($admit['is_active']) ? 1 : 0,
    ],
    'admissions' => $activeAdmits,
    'allergy' => [
        'has_allergy' => !empty($allergy['has_allergy']),
        'text' => (string)($allergy['text'] ?? ''),
    ],
    'count' => count($flat),
    'meds' => $flat,
    'groups' => $groups,
    'warning' => (string)($lookup['warning'] ?? ''),
], JSON_UNESCAPED_UNICODE);
