<?php
/**
 * Monitor Antibiotic — ดักจับการใช้ยาปฏิชีวนะฉีด (IPD) นานเกินเกณฑ์
 */

function mab_default_config() {
    return [
        'min_duration_days' => 10,
        'filter_mode' => 'group',
        'pharmacology_group1' => '24',
        'dosage_form' => 'Injection',
        'order_lookback_days' => 30,
        'recent_rx_days' => 2,
        'exclude_method_regex' => 'PD|HD',
        'reply_wait_days' => 3,
        'alert_level' => 'soft',
        'monitor_active' => 1,
    ];
}

function mab_ensure_tables($con) {
    // สร้าง/อัปเกรดทีละตาราง — รองรับกรณีมี config เก่าแล้วเพิ่มตารางใหม่
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_antibiotic.sql');
    if ($sql !== false && trim($sql) !== '') {
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
            if ($stmt === '') {
                continue;
            }
            // ข้าม INSERT ที่ต้องมีคอลัมน์ใหม่ จนกว่าจะ ALTER เสร็จ
            if (stripos($stmt, 'INSERT') === 0) {
                continue;
            }
            @mysqli_query($con, $stmt);
        }
    }
    mab_ensure_config_columns($con);

    // seed config + default group หลังมีคอลัมน์ครบ
    @mysqli_query($con, "INSERT IGNORE INTO monitor_antibiotic_config (
            id, min_duration_days, filter_mode, pharmacology_group1, dosage_form,
            order_lookback_days, recent_rx_days, exclude_method_regex, reply_wait_days, monitor_active
        ) VALUES (1, 10, 'group', '24', 'Injection', 30, 2, 'PD|HD', 3, 1)");
    mab_seed_default_group($con);
    return true;
}

function mab_ensure_config_columns($con) {
    $q = mysqli_query($con, "SHOW COLUMNS FROM monitor_antibiotic_config LIKE 'filter_mode'");
    if (!$q || mysqli_num_rows($q) === 0) {
        @mysqli_query($con, "ALTER TABLE monitor_antibiotic_config
            ADD COLUMN filter_mode VARCHAR(20) NOT NULL DEFAULT 'group'
            AFTER min_duration_days");
    }
    $q2 = mysqli_query($con, "SHOW COLUMNS FROM monitor_antibiotic_config LIKE 'reply_wait_days'");
    if (!$q2 || mysqli_num_rows($q2) === 0) {
        @mysqli_query($con, "ALTER TABLE monitor_antibiotic_config
            ADD COLUMN reply_wait_days INT NOT NULL DEFAULT 3
            AFTER exclude_method_regex");
    }
    $q3 = mysqli_query($con, "SHOW COLUMNS FROM monitor_antibiotic_config LIKE 'alert_level'");
    if (!$q3 || mysqli_num_rows($q3) === 0) {
        @mysqli_query($con, "ALTER TABLE monitor_antibiotic_config
            ADD COLUMN alert_level VARCHAR(10) NOT NULL DEFAULT 'soft'
            AFTER reply_wait_days");
    } else {
        @mysqli_query($con, "ALTER TABLE monitor_antibiotic_config
            MODIFY COLUMN alert_level VARCHAR(10) NOT NULL DEFAULT 'soft'");
    }
    $q4 = mysqli_query($con, "SHOW COLUMNS FROM monitor_antibiotic_drugs LIKE 'alert_level'");
    if (!$q4 || mysqli_num_rows($q4) === 0) {
        @mysqli_query($con, "ALTER TABLE monitor_antibiotic_drugs
            ADD COLUMN alert_level VARCHAR(10) NOT NULL DEFAULT 'soft'
            AFTER active");
        @mysqli_query($con, "UPDATE monitor_antibiotic_config SET alert_level='soft' WHERE id=1");
    }
}

function mab_seed_default_group($con) {
    $q = mysqli_query($con, 'SELECT COUNT(*) AS c FROM monitor_antibiotic_groups');
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if ($row && (int)$row['c'] === 0) {
        mysqli_query($con, "INSERT IGNORE INTO monitor_antibiotic_groups
            (pharmacology_group_id, pharmacology_group_name, active)
            VALUES ('24', 'ANTIBIOTICS', 1)");
    }
}

function mab_normalize_filter_mode($mode) {
    $mode = strtolower(trim((string)$mode));
    if ($mode === 'drugs') {
        return 'drugs';
    }
    if ($mode === 'flag' || $mode === 'antibiotic' || $mode === 'antibiotic_flag') {
        return 'flag';
    }
    return 'group';
}

function mab_normalize_alert_level($level) {
    return strtolower(trim((string)$level)) === 'hard' ? 'hard' : 'soft';
}

function mab_alert_badge_html($level) {
    if (mab_normalize_alert_level($level) === 'hard') {
        return '<span class="badge bg-danger">Hard Alert</span>';
    }
    return '<span class="badge bg-warning text-dark">Soft Alert</span>';
}

function mab_drug_alert_map($con) {
    $map = [];
    foreach (mab_list_drugs($con, false) as $d) {
        $icode = trim((string)($d['icode'] ?? ''));
        if ($icode !== '') {
            $map[$icode] = mab_normalize_alert_level($d['alert_level'] ?? 'soft');
        }
    }
    return $map;
}

function mab_apply_item_alert_levels(array $items, $default_level, array $drug_map) {
    $fallback = mab_normalize_alert_level($default_level);
    foreach ($items as &$it) {
        $icode = trim((string)($it['icode'] ?? ''));
        $it['alert_level'] = ($icode !== '' && isset($drug_map[$icode]))
            ? $drug_map[$icode]
            : $fallback;
    }
    unset($it);
    return $items;
}

function mab_set_drug_alert_level($con, $id, $level) {
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    $lvl = mab_normalize_alert_level($level);
    return (bool)mysqli_query($con, "UPDATE monitor_antibiotic_drugs SET alert_level='$lvl' WHERE id=$id");
}

function mab_get_config($con) {
    mab_ensure_tables($con);
    $cfg = mab_default_config();
    $q = mysqli_query($con, 'SELECT * FROM monitor_antibiotic_config WHERE id = 1 LIMIT 1');
    if ($q && ($row = mysqli_fetch_assoc($q))) {
        $cfg['min_duration_days'] = max(1, (int)($row['min_duration_days'] ?? $cfg['min_duration_days']));
        $cfg['filter_mode'] = mab_normalize_filter_mode($row['filter_mode'] ?? $cfg['filter_mode']);
        $cfg['pharmacology_group1'] = trim((string)($row['pharmacology_group1'] ?? $cfg['pharmacology_group1']));
        $cfg['dosage_form'] = trim((string)($row['dosage_form'] ?? $cfg['dosage_form']));
        $cfg['order_lookback_days'] = max(1, (int)($row['order_lookback_days'] ?? $cfg['order_lookback_days']));
        $cfg['recent_rx_days'] = max(1, (int)($row['recent_rx_days'] ?? $cfg['recent_rx_days']));
        $cfg['exclude_method_regex'] = trim((string)($row['exclude_method_regex'] ?? $cfg['exclude_method_regex']));
        $cfg['reply_wait_days'] = max(1, (int)($row['reply_wait_days'] ?? $cfg['reply_wait_days']));
        $cfg['alert_level'] = mab_normalize_alert_level($row['alert_level'] ?? $cfg['alert_level']);
        $cfg['monitor_active'] = !empty($row['monitor_active']) ? 1 : 0;
    }
    if ($cfg['pharmacology_group1'] === '') {
        $cfg['pharmacology_group1'] = '24';
    }
    if ($cfg['dosage_form'] === '') {
        $cfg['dosage_form'] = 'Injection';
    }
    return $cfg;
}

function mab_save_config($con, array $input) {
    mab_ensure_tables($con);
    $cfg = mab_default_config();
    $min_duration = max(1, (int)($input['min_duration_days'] ?? $cfg['min_duration_days']));
    $filter_mode = mab_normalize_filter_mode($input['filter_mode'] ?? $cfg['filter_mode']);
    $dosage = trim((string)($input['dosage_form'] ?? $cfg['dosage_form']));
    $lookback = max(1, (int)($input['order_lookback_days'] ?? $cfg['order_lookback_days']));
    $recent_rx = max(1, (int)($input['recent_rx_days'] ?? $cfg['recent_rx_days']));
    $exclude = trim((string)($input['exclude_method_regex'] ?? $cfg['exclude_method_regex']));
    $reply_wait = max(1, (int)($input['reply_wait_days'] ?? $cfg['reply_wait_days']));
    $alert_level = mab_normalize_alert_level($input['alert_level'] ?? $cfg['alert_level']);
    $active = !empty($input['monitor_active']) ? 1 : 0;

    if ($dosage === '') {
        $dosage = 'Injection';
    }

    // บันทึกกลุ่มที่เลือก → sync pharmacology_group1 เป็น comma list
    $group_ids = $input['group_ids'] ?? null;
    if (is_array($group_ids)) {
        mab_save_selected_groups($con, $group_ids, $input['group_names'] ?? []);
    }
    $selected = mab_get_selected_groups($con, true);
    $pharm = implode(',', array_column($selected, 'pharmacology_group_id'));
    if ($pharm === '') {
        $pharm = trim((string)($input['pharmacology_group1'] ?? $cfg['pharmacology_group1']));
    }
    if ($pharm === '') {
        $pharm = '24';
    }

    $mode_esc = mysqli_real_escape_string($con, $filter_mode);
    $pharm_esc = mysqli_real_escape_string($con, $pharm);
    $dosage_esc = mysqli_real_escape_string($con, $dosage);
    $exclude_esc = mysqli_real_escape_string($con, $exclude);

    $sql = "INSERT INTO monitor_antibiotic_config (
            id, min_duration_days, filter_mode, pharmacology_group1, dosage_form,
            order_lookback_days, recent_rx_days, exclude_method_regex, reply_wait_days, alert_level, monitor_active
        ) VALUES (
            1, $min_duration, '$mode_esc', '$pharm_esc', '$dosage_esc',
            $lookback, $recent_rx, '$exclude_esc', $reply_wait, '$alert_level', $active
        )
        ON DUPLICATE KEY UPDATE
            min_duration_days = VALUES(min_duration_days),
            filter_mode = VALUES(filter_mode),
            pharmacology_group1 = VALUES(pharmacology_group1),
            dosage_form = VALUES(dosage_form),
            order_lookback_days = VALUES(order_lookback_days),
            recent_rx_days = VALUES(recent_rx_days),
            exclude_method_regex = VALUES(exclude_method_regex),
            reply_wait_days = VALUES(reply_wait_days),
            alert_level = VALUES(alert_level),
            monitor_active = VALUES(monitor_active)";
    return (bool)mysqli_query($con, $sql);
}

function mab_get_selected_groups($con, $active_only = false) {
    mab_ensure_tables($con);
    $sql = 'SELECT * FROM monitor_antibiotic_groups';
    if ($active_only) {
        $sql .= ' WHERE active = 1';
    }
    $sql .= ' ORDER BY CAST(pharmacology_group_id AS UNSIGNED) ASC, pharmacology_group_id ASC';
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function mab_save_selected_groups($con, array $group_ids, array $group_names = []) {
    mab_ensure_tables($con);
    $ids = [];
    foreach ($group_ids as $gid) {
        $gid = trim((string)$gid);
        if ($gid !== '') {
            $ids[$gid] = true;
        }
    }
    mysqli_query($con, 'UPDATE monitor_antibiotic_groups SET active = 0');
    foreach (array_keys($ids) as $gid) {
        $name = trim((string)($group_names[$gid] ?? ''));
        $gid_esc = mysqli_real_escape_string($con, $gid);
        $name_esc = mysqli_real_escape_string($con, $name);
        $chk = mysqli_query($con, "SELECT id FROM monitor_antibiotic_groups WHERE pharmacology_group_id = '$gid_esc' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            $set_name = $name !== '' ? ", pharmacology_group_name = '$name_esc'" : '';
            mysqli_query($con, "UPDATE monitor_antibiotic_groups SET active = 1$set_name WHERE pharmacology_group_id = '$gid_esc'");
        } else {
            mysqli_query($con, "INSERT INTO monitor_antibiotic_groups
                (pharmacology_group_id, pharmacology_group_name, active)
                VALUES ('$gid_esc', '$name_esc', 1)");
        }
    }
    return true;
}

function mab_list_drugs($con, $active_only = false) {
    mab_ensure_tables($con);
    $sql = 'SELECT * FROM monitor_antibiotic_drugs';
    if ($active_only) {
        $sql .= ' WHERE active = 1';
    }
    $sql .= ' ORDER BY drug_name ASC, icode ASC';
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function mab_add_drug($con, array $drug) {
    mab_ensure_tables($con);
    $icode = trim((string)($drug['icode'] ?? ''));
    if ($icode === '') {
        return ['ok' => false, 'error' => 'ไม่พบ icode'];
    }
    $name = trim((string)($drug['drug_name'] ?? $drug['name'] ?? ''));
    $generic = trim((string)($drug['generic_name'] ?? ''));
    $dosage = trim((string)($drug['dosageform'] ?? ''));
    $pg = trim((string)($drug['pharmacology_group1'] ?? ''));

    $lvl = mab_normalize_alert_level($drug['alert_level'] ?? 'soft');
    $icode_esc = mysqli_real_escape_string($con, $icode);
    $name_esc = mysqli_real_escape_string($con, $name);
    $generic_esc = mysqli_real_escape_string($con, $generic);
    $dosage_esc = mysqli_real_escape_string($con, $dosage);
    $pg_esc = mysqli_real_escape_string($con, $pg);

    $sql = "INSERT INTO monitor_antibiotic_drugs
            (icode, drug_name, generic_name, dosageform, pharmacology_group1, active, alert_level)
        VALUES ('$icode_esc', '$name_esc', '$generic_esc', '$dosage_esc', '$pg_esc', 1, '$lvl')
        ON DUPLICATE KEY UPDATE
            drug_name = VALUES(drug_name),
            generic_name = VALUES(generic_name),
            dosageform = VALUES(dosageform),
            pharmacology_group1 = VALUES(pharmacology_group1),
            active = 1";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    return ['ok' => true, 'message' => 'เพิ่มยาเรียบร้อย'];
}

function mab_delete_drug($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "DELETE FROM monitor_antibiotic_drugs WHERE id = $id");
}

function mab_set_drug_active($con, $id, $active) {
    $id = (int)$id;
    $active = $active ? 1 : 0;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "UPDATE monitor_antibiotic_drugs SET active = $active WHERE id = $id");
}

function mab_clear_drugs($con) {
    return (bool)mysqli_query($con, 'DELETE FROM monitor_antibiotic_drugs');
}

/** ดึงกลุ่มเภสัชวิทยาจาก HOSxP (พร้อมนับยา Injection) */
function mab_fetch_hosxp_pharmacology_groups($hos, $dosage_form = 'Injection') {
    if (!$hos) {
        return [];
    }
    $dosage_esc = mysqli_real_escape_string($hos, $dosage_form);
    $sql = "
        SELECT
            CAST(d.pharmacology_group1 AS CHAR) AS pharmacology_group_id,
            IFNULL(
                CAST(CONVERT(pg.pharmacology_group_name USING utf8) AS CHAR),
                CONCAT('กลุ่ม ', CAST(d.pharmacology_group1 AS CHAR))
            ) AS pharmacology_group_name,
            COUNT(d.icode) AS drug_count
        FROM drugitems d
        LEFT JOIN pharmacology_group pg
            ON pg.pharmacology_group_id = d.pharmacology_group1
        WHERE d.pharmacology_group1 IS NOT NULL
          AND CAST(d.pharmacology_group1 AS CHAR) <> ''
          AND UPPER(TRIM(d.dosageform)) = UPPER(TRIM('$dosage_esc'))
        GROUP BY d.pharmacology_group1, pg.pharmacology_group_name
        ORDER BY drug_count DESC, CAST(d.pharmacology_group1 AS UNSIGNED) ASC";
    $q = @mysqli_query($hos, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'pharmacology_group_id' => (string)$r['pharmacology_group_id'],
                'pharmacology_group_name' => trim((string)$r['pharmacology_group_name']),
                'drug_count' => (int)$r['drug_count'],
            ];
        }
    }
    return $rows;
}

/** ดึงรายการยา Injection ตามกลุ่มเภสัชวิทยาจาก HOSxP */
function mab_fetch_hosxp_drugs_by_groups($hos, array $group_ids, $dosage_form = 'Injection') {
    if (!$hos || empty($group_ids)) {
        return [];
    }
    $ids = [];
    foreach ($group_ids as $gid) {
        $gid = trim((string)$gid);
        if ($gid !== '') {
            $ids[] = "'" . mysqli_real_escape_string($hos, $gid) . "'";
        }
    }
    if (empty($ids)) {
        return [];
    }
    $dosage_esc = mysqli_real_escape_string($hos, $dosage_form);
    $in = implode(',', $ids);
    $sql = "
        SELECT
            d.icode,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
            CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
            IFNULL(d.dosageform, '') AS dosageform,
            CAST(d.pharmacology_group1 AS CHAR) AS pharmacology_group1,
            CAST(CONVERT(IFNULL(pg.pharmacology_group_name, '') USING utf8) AS CHAR) AS pharmacology_group_name
        FROM drugitems d
        LEFT JOIN pharmacology_group pg ON pg.pharmacology_group_id = d.pharmacology_group1
        WHERE CAST(d.pharmacology_group1 AS CHAR) IN ($in)
          AND UPPER(TRIM(d.dosageform)) = UPPER(TRIM('$dosage_esc'))
        ORDER BY d.name ASC";
    $q = @mysqli_query($hos, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

/** ดึงรายการยาที่ติ๊ก "ยาปฏิชีวนะ" ใน HOSxP (drugitems.antibiotic = Y) */
function mab_fetch_hosxp_drugs_by_antibiotic_flag($hos, $dosage_form = 'Injection') {
    if (!$hos) {
        return [];
    }
    $dosage_esc = mysqli_real_escape_string($hos, $dosage_form);
    $sql = "
        SELECT
            d.icode,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
            CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
            IFNULL(d.dosageform, '') AS dosageform,
            CAST(IFNULL(d.pharmacology_group1, '') AS CHAR) AS pharmacology_group1,
            IFNULL(d.antibiotic, '') AS antibiotic
        FROM drugitems d
        WHERE UPPER(TRIM(IFNULL(d.antibiotic, ''))) = 'Y'
          AND UPPER(TRIM(d.dosageform)) = UPPER(TRIM('$dosage_esc'))
        ORDER BY d.name ASC";
    $q = @mysqli_query($hos, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function mab_count_hosxp_antibiotic_flag($hos, $dosage_form = 'Injection') {
    if (!$hos) {
        return 0;
    }
    $dosage_esc = mysqli_real_escape_string($hos, $dosage_form);
    $sql = "
        SELECT COUNT(*) AS c
        FROM drugitems d
        WHERE UPPER(TRIM(IFNULL(d.antibiotic, ''))) = 'Y'
          AND UPPER(TRIM(d.dosageform)) = UPPER(TRIM('$dosage_esc'))";
    $q = @mysqli_query($hos, $sql);
    if (!$q || !($row = mysqli_fetch_assoc($q))) {
        return 0;
    }
    return (int)($row['c'] ?? 0);
}

function mab_import_drugs_bulk($con, array $drugs) {
    if (empty($drugs)) {
        return ['ok' => false, 'error' => 'ไม่พบยาที่จะนำเข้า', 'inserted' => 0, 'updated' => 0, 'total' => 0];
    }
    $inserted = 0;
    $updated = 0;
    foreach ($drugs as $d) {
        $icode = trim((string)($d['icode'] ?? ''));
        if ($icode === '') {
            continue;
        }
        $icode_esc = mysqli_real_escape_string($con, $icode);
        $exists = mysqli_query($con, "SELECT id FROM monitor_antibiotic_drugs WHERE icode = '$icode_esc' LIMIT 1");
        $had = $exists && mysqli_num_rows($exists) > 0;
        $res = mab_add_drug($con, $d);
        if (!empty($res['ok'])) {
            if ($had) {
                $updated++;
            } else {
                $inserted++;
            }
        }
    }
    return [
        'ok' => true,
        'inserted' => $inserted,
        'updated' => $updated,
        'total' => count($drugs),
        'message' => 'นำเข้า ' . count($drugs) . ' รายการ (เพิ่ม ' . $inserted . ' · อัปเดต ' . $updated . ')',
    ];
}

function mab_import_drugs_from_antibiotic_flag($con, $hos, $dosage_form = null) {
    $cfg = mab_get_config($con);
    if ($dosage_form === null || $dosage_form === '') {
        $dosage_form = $cfg['dosage_form'];
    }
    $drugs = mab_fetch_hosxp_drugs_by_antibiotic_flag($hos, $dosage_form);
    if (empty($drugs)) {
        return ['ok' => false, 'error' => 'ไม่พบยาที่ติ๊ก ยาปฏิชีวนะ ใน HOSxP', 'inserted' => 0, 'updated' => 0];
    }
    return mab_import_drugs_bulk($con, $drugs);
}

/** ดึงรายละเอียดยา 1 รายการจาก HOSxP ตาม icode */
function mab_fetch_hosxp_drug_by_icode($hos, $icode) {
    if (!$hos) {
        return null;
    }
    $icode = trim((string)$icode);
    if ($icode === '') {
        return null;
    }
    $icode_esc = mysqli_real_escape_string($hos, $icode);
    $sql = "
        SELECT
            d.icode,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
            CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
            IFNULL(d.dosageform, '') AS dosageform,
            CAST(IFNULL(d.pharmacology_group1,'') AS CHAR) AS pharmacology_group1
        FROM drugitems d
        WHERE d.icode = '$icode_esc'
        LIMIT 1";
    $q = @mysqli_query($hos, $sql);
    if (!$q || !($row = mysqli_fetch_assoc($q))) {
        return null;
    }
    return $row;
}

function mab_import_drugs_from_groups($con, $hos, array $group_ids = null, $dosage_form = null) {
    $cfg = mab_get_config($con);
    if ($dosage_form === null || $dosage_form === '') {
        $dosage_form = $cfg['dosage_form'];
    }
    if ($group_ids === null) {
        $group_ids = array_column(mab_get_selected_groups($con, true), 'pharmacology_group_id');
    }
    if (empty($group_ids)) {
        return ['ok' => false, 'error' => 'ยังไม่ได้เลือกกลุ่มเภสัชวิทยา', 'inserted' => 0, 'updated' => 0];
    }
    $drugs = mab_fetch_hosxp_drugs_by_groups($hos, $group_ids, $dosage_form);
    if (empty($drugs)) {
        return ['ok' => false, 'error' => 'ไม่พบยาในกลุ่มที่เลือก', 'inserted' => 0, 'updated' => 0];
    }
    return mab_import_drugs_bulk($con, $drugs);
}

function mab_sql_method_expr() {
    return "IF(mp.sp_use = '' OR mp.sp_use IS NULL,
        CONCAT(IFNULL(du.name1,''), ' ', IFNULL(du.name2,''), ' ', IFNULL(du.name3,'')),
        CONCAT(IFNULL(sp.name1,''), ' ', IFNULL(sp.name2,''), ' ', IFNULL(sp.name3,'')))";
}

function mab_normalize_row(array $row) {
    foreach (['ptname', 'wname', 'drug', 'method'] as $k) {
        if (isset($row[$k]) && is_string($row[$k])) {
            $row[$k] = trim(preg_replace('/\s+/', ' ', $row[$k]));
        }
    }
    if (isset($row['wname']) && $row['wname'] === '') {
        $row['wname'] = '(ไม่ระบุ Ward)';
    }
    $row['duration'] = (int)($row['duration'] ?? 0);
    $row['qty'] = (float)($row['qty'] ?? 0);
    if (!empty($row['firstday'])) {
        $row['firstday'] = substr((string)$row['firstday'], 0, 10);
    }
    return $row;
}

function mab_method_excluded($method, $regex) {
    $regex = trim((string)$regex);
    if ($regex === '') {
        return false;
    }
    $method = trim((string)$method);
    if ($method === '') {
        return false;
    }
    return @preg_match('/' . str_replace('/', '\\/', $regex) . '/iu', $method) === 1;
}

function mab_resolve_filter($con, array $config) {
    $mode = mab_normalize_filter_mode($config['filter_mode'] ?? 'group');
    $group_ids = array_column(mab_get_selected_groups($con, true), 'pharmacology_group_id');
    if (empty($group_ids)) {
        $pharm = trim((string)($config['pharmacology_group1'] ?? '24'));
        $group_ids = array_values(array_filter(array_map('trim', preg_split('/[,;]+/', $pharm))));
    }
    if (empty($group_ids)) {
        $group_ids = ['24'];
    }
    $icodes = [];
    if ($mode === 'drugs') {
        foreach (mab_list_drugs($con, true) as $d) {
            $icode = trim((string)($d['icode'] ?? ''));
            if ($icode !== '') {
                $icodes[] = $icode;
            }
        }
    }
    return [
        'mode' => $mode,
        'group_ids' => $group_ids,
        'icodes' => $icodes,
    ];
}

function mab_fetch_cases($hos, array $config, array $filter = null) {
    if (!$hos) {
        return ['items' => [], 'error' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'];
    }

    $min_days = max(1, (int)($config['min_duration_days'] ?? 10));
    $lookback = max(1, (int)($config['order_lookback_days'] ?? 30));
    $recent_rx = max(1, (int)($config['recent_rx_days'] ?? 2));
    $dosage = trim((string)($config['dosage_form'] ?? 'Injection'));
    $exclude_regex = trim((string)($config['exclude_method_regex'] ?? 'PD|HD'));
    $mode = $filter['mode'] ?? 'group';
    $group_ids = $filter['group_ids'] ?? ['24'];
    $icodes = $filter['icodes'] ?? [];

    if ($mode === 'drugs') {
        if (empty($icodes)) {
            return ['items' => [], 'error' => ''];
        }
        $drug_in = implode(',', array_map(static function ($v) use ($hos) {
            return "'" . mysqli_real_escape_string($hos, $v) . "'";
        }, $icodes));
        $drug_filter_sql = "mp.icode IN ($drug_in)";
    } elseif ($mode === 'flag') {
        $dosage_esc = mysqli_real_escape_string($hos, $dosage);
        $drug_filter_sql = "UPPER(TRIM(IFNULL(d2.antibiotic, ''))) = 'Y'
          AND UPPER(TRIM(d2.dosageform)) = UPPER(TRIM('$dosage_esc'))";
    } else {
        $pharm_in = implode(',', array_map(static function ($v) use ($hos) {
            return "'" . mysqli_real_escape_string($hos, $v) . "'";
        }, $group_ids));
        $drug_filter_sql = "CAST(d2.pharmacology_group1 AS CHAR) IN ($pharm_in)
          AND UPPER(TRIM(d2.dosageform)) = UPPER(TRIM('" . mysqli_real_escape_string($hos, $dosage) . "'))";
    }

    $method_expr = mab_sql_method_expr();

    $an_clause = '';
    $an_list = (is_array($filter) && isset($filter['an_list']) && is_array($filter['an_list']))
        ? $filter['an_list'] : [];
    if (is_array($an_list) && !empty($an_list)) {
        $ans = [];
        foreach ($an_list as $an) {
            $an = trim((string)$an);
            if ($an !== '') {
                $ans[] = "'" . mysqli_real_escape_string($hos, $an) . "'";
            }
        }
        $ans = array_values(array_unique($ans));
        if (!empty($ans)) {
            $an_clause = ' AND i.an IN (' . implode(',', $ans) . ')';
        }
    }
    $hn_clause = '';
    $hn_list = (is_array($filter) && isset($filter['hn_list']) && is_array($filter['hn_list']))
        ? $filter['hn_list'] : [];
    if (!empty($hn_list)) {
        if (function_exists('monitor_hn_sql_clause')) {
            $hn_clause = monitor_hn_sql_clause($hos, $hn_list, 'o.hn');
        }
    }

    $sql = "
        SELECT
            mp.med_plan_number,
            o.hn,
            i.an,
            mp.icode,
            CAST(CONVERT(CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,'')) USING utf8) AS CHAR) AS ptname,
            CAST(CONVERT(IFNULL(w.name,'') USING utf8) AS CHAR) AS wname,
            CAST(CONVERT(IFNULL(d2.name,'') USING utf8) AS CHAR) AS drug,
            $method_expr AS method,
            mp.qty,
            mp.orderdate AS firstday,
            CONCAT(MAX(o.rxdate), ' ', MAX(o.rxtime)) AS rxdatetime,
            DATEDIFF(NOW(), mp.orderdate) AS duration
        FROM opitemrece o
        INNER JOIN ipt i ON i.an = o.an AND i.dchdate IS NULL
        INNER JOIN patient pt ON pt.hn = o.hn
        LEFT JOIN ward w ON w.ward = i.ward
        INNER JOIN medplan_ipd mp ON mp.an = o.an AND mp.offdate IS NULL AND mp.qty > 0
        INNER JOIN drugitems d2 ON d2.icode = mp.icode
        LEFT JOIN drugusage du ON du.drugusage = mp.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = mp.sp_use
        WHERE mp.orderdate BETWEEN SUBDATE(NOW(), INTERVAL $lookback DAY) AND NOW()
          AND UNIX_TIMESTAMP(CONCAT(o.rxdate, ' ', o.rxtime))
              BETWEEN UNIX_TIMESTAMP(SUBDATE(NOW(), INTERVAL $recent_rx DAY)) AND UNIX_TIMESTAMP(NOW())
          AND ($drug_filter_sql)
          AND o.rxdate >= i.regdate
          $an_clause
          $hn_clause
        GROUP BY
            mp.med_plan_number, mp.orderdate, mp.offdate,
            o.hn, i.an, mp.icode,
            pt.pname, pt.fname, pt.lname,
            w.name, d2.name, mp.qty,
            mp.sp_use, du.name1, du.name2, du.name3,
            sp.name1, sp.name2, sp.name3
        HAVING duration > $min_days
        ORDER BY wname ASC, o.hn ASC, drug ASC";

    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return ['items' => [], 'error' => mysqli_error($hos)];
    }

    $items = [];
    while ($row = mysqli_fetch_assoc($q)) {
        $row = mab_normalize_row($row);
        if (mab_method_excluded($row['method'] ?? '', $exclude_regex)) {
            continue;
        }
        $items[] = $row;
    }

    return ['items' => $items, 'error' => ''];
}

function mab_build_summary(array $items) {
    $ward_patients = [];
    $ward_cases = [];
    $patients = [];

    foreach ($items as $it) {
        $hn = (string)($it['hn'] ?? '');
        $ward = (string)($it['wname'] ?? '(ไม่ระบุ Ward)');
        if ($hn !== '') {
            $patients[$hn] = true;
            if (!isset($ward_patients[$ward])) {
                $ward_patients[$ward] = [];
            }
            $ward_patients[$ward][$hn] = true;
        }
        if (!isset($ward_cases[$ward])) {
            $ward_cases[$ward] = 0;
        }
        $ward_cases[$ward]++;
    }

    $ward_summary = [];
    foreach ($ward_patients as $ward => $hn_map) {
        $ward_summary[] = [
            'wname' => $ward,
            'patient_count' => count($hn_map),
            'case_count' => (int)($ward_cases[$ward] ?? 0),
        ];
    }
    usort($ward_summary, static function ($a, $b) {
        $cmp = ($b['patient_count'] <=> $a['patient_count']);
        if ($cmp !== 0) {
            return $cmp;
        }
        return strcmp($a['wname'], $b['wname']);
    });

    return [
        'total_cases' => count($items),
        'total_patients' => count($patients),
        'ward_summary' => $ward_summary,
    ];
}

function mab_scan($con, $hos, array $override = []) {
    require_once __DIR__ . '/monitor_antibiotic_consult_helper.php';
    $an_list = [];
    if (isset($override['an_list']) && is_array($override['an_list'])) {
        $an_list = $override['an_list'];
        unset($override['an_list']);
    }
    $hn_list = [];
    if (isset($override['hn_list']) && is_array($override['hn_list'])) {
        $hn_list = $override['hn_list'];
        unset($override['hn_list']);
    }
    if (isset($override['hn']) && trim((string)$override['hn']) !== '') {
        $hn_list[] = trim((string)$override['hn']);
        unset($override['hn']);
    }
    $attach_consults = !array_key_exists('attach_consults', $override) || !empty($override['attach_consults']);
    unset($override['attach_consults']);
    $config = array_merge(mab_get_config($con), $override);
    if (empty($config['monitor_active'])) {
        return [
            'items' => [],
            'summary' => mab_build_summary([]),
            'config' => $config,
            'meta' => ['disabled' => true],
        ];
    }

    $filter = mab_resolve_filter($con, $config);
    if (!empty($an_list)) {
        $filter['an_list'] = $an_list;
    }
    if (!empty($hn_list)) {
        $filter['hn_list'] = $hn_list;
    }
    $fetch = mab_fetch_cases($hos, $config, $filter);
    $items = $fetch['items'] ?? [];
    $items = mab_apply_item_alert_levels(
        $items,
        $config['alert_level'] ?? 'soft',
        mab_drug_alert_map($con)
    );
    $status_counts = ['waiting' => 0, 'in_progress' => 0, 'closed' => 0];
    if ($attach_consults) {
        list($items, $status_counts) = mab_attach_consults_to_items($con, $items, (int)$config['reply_wait_days']);
    }
    $summary = mab_build_summary($items);
    $summary['consult_status'] = $status_counts;
    $hard_n = 0;
    $soft_n = 0;
    foreach ($items as $it) {
        if (($it['alert_level'] ?? 'soft') === 'hard') {
            $hard_n++;
        } else {
            $soft_n++;
        }
    }
    $summary['hard_count'] = $hard_n;
    $summary['soft_count'] = $soft_n;
    return [
        'items' => $items,
        'summary' => $summary,
        'config' => $config,
        'meta' => [
            'disabled' => false,
            'error' => $fetch['error'] ?? '',
            'generated_at' => date('Y-m-d H:i:s'),
            'filter_mode' => $filter['mode'],
            'group_ids' => $filter['group_ids'],
            'drug_count' => count($filter['icodes']),
        ],
    ];
}
