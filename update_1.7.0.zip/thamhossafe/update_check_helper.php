<?php
/**
 * ตรวจสอบอัปเดตจาก GitHub + เลื่อนการเตือน (snooze)
 * ออกแบบให้ปลอดภัยตอน offline: timeout สั้น + cache ความล้มเหลว
 */

if (!defined('THAM_UPDATE_VERSION_URL')) {
    define(
        'THAM_UPDATE_VERSION_URL',
        'https://raw.githubusercontent.com/atipolklaypaksi-cell/tham-Hos-safe/main/version.json'
    );
}

/** เวลาเชื่อมต่อสูงสุด (วินาที) — กันค้างตอนไม่มีเน็ต */
if (!defined('THAM_UPDATE_CONNECT_TIMEOUT')) {
    define('THAM_UPDATE_CONNECT_TIMEOUT', 2);
}
if (!defined('THAM_UPDATE_TOTAL_TIMEOUT')) {
    define('THAM_UPDATE_TOTAL_TIMEOUT', 3);
}
/** cache ผลสำเร็จ */
if (!defined('THAM_UPDATE_CACHE_OK_SECONDS')) {
    define('THAM_UPDATE_CACHE_OK_SECONDS', 6 * 3600);
}
/** cache ตอน offline/ล้มเหลว — ไม่ยิงซ้ำทุกหน้า */
if (!defined('THAM_UPDATE_CACHE_FAIL_SECONDS')) {
    define('THAM_UPDATE_CACHE_FAIL_SECONDS', 3600);
}

function tham_update_config_get($con, $name, $default = null) {
    $name_esc = mysqli_real_escape_string($con, $name);
    $q = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = '$name_esc' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return $r['config_value'];
    }
    return $default;
}

function tham_update_config_set($con, $name, $value) {
    $name_esc = mysqli_real_escape_string($con, $name);
    $value_esc = mysqli_real_escape_string($con, (string)$value);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name = '$name_esc' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value = '$value_esc' WHERE config_name = '$name_esc'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$name_esc', '$value_esc')");
}

/** เปิด/ปิดเช็คอัตโนมัติตอนเปิดโปรแกรม (ค่าเริ่มต้น: เปิด) */
function tham_update_auto_check_enabled($con) {
    $v = tham_update_config_get($con, 'update_auto_check', '1');
    return $v === null || $v === '' || $v === '1' || $v === 'true' || $v === 'on';
}

function tham_update_set_auto_check($con, $enabled) {
    return tham_update_config_set($con, 'update_auto_check', $enabled ? '1' : '0');
}

function tham_update_snooze_key($user_id) {
    return 'update_snooze_until_' . (int)$user_id;
}

function tham_update_is_snoozed($con, $user_id) {
    $until = tham_update_config_get($con, tham_update_snooze_key($user_id), '');
    if ($until === '' || $until === null) {
        return false;
    }
    $ts = strtotime($until);
    return $ts !== false && $ts > time();
}

function tham_update_snooze_until($con, $user_id) {
    return tham_update_config_get($con, tham_update_snooze_key($user_id), null);
}

function tham_update_set_snooze($con, $user_id, $days) {
    $days = (int)$days;
    if (!in_array($days, [7, 30], true)) {
        return false;
    }
    $until = date('Y-m-d H:i:s', time() + ($days * 86400));
    return tham_update_config_set($con, tham_update_snooze_key($user_id), $until) ? $until : false;
}

function tham_update_clear_snooze($con, $user_id) {
    return tham_update_config_set($con, tham_update_snooze_key($user_id), '');
}

function tham_update_cache_age_seconds(array $cache) {
    if (empty($cache['checked_at'])) {
        return null;
    }
    $ts = strtotime($cache['checked_at']);
    if ($ts === false) {
        return null;
    }
    return time() - $ts;
}

/**
 * ดึงเวอร์ชันล่าสุดจาก GitHub
 * - สำเร็จ: cache 6 ชม.
 * - ล้มเหลว/offline: cache 1 ชม. เพื่อไม่ให้ทุกหน้าไปรอ timeout
 */
function tham_update_fetch_remote($con, $force = false) {
    $cache_raw = tham_update_config_get($con, 'update_remote_cache', '');
    if (!$force && $cache_raw !== '') {
        $cache = json_decode($cache_raw, true);
        if (is_array($cache) && !empty($cache['checked_at'])) {
            $age = tham_update_cache_age_seconds($cache);
            if ($age !== null && $age >= 0) {
                if (!empty($cache['ok']) && !empty($cache['latest_version']) && $age < THAM_UPDATE_CACHE_OK_SECONDS) {
                    return $cache;
                }
                if (empty($cache['ok']) && $age < THAM_UPDATE_CACHE_FAIL_SECONDS) {
                    return $cache;
                }
            }
        }
    }

    $result = [
        'ok' => false,
        'latest_version' => null,
        'download_url' => '',
        'update_details' => '',
        'release_date' => '',
        'checked_at' => date('Y-m-d H:i:s'),
        'error' => null,
        'offline' => false,
    ];

    $json_data = false;
    $http = 0;
    $cerr = '';

    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, THAM_UPDATE_VERSION_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, THAM_UPDATE_CONNECT_TIMEOUT);
        curl_setopt($ch, CURLOPT_TIMEOUT, THAM_UPDATE_TOTAL_TIMEOUT);
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'THAM-HosSafe-Updater');
        $json_data = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $cerr = curl_error($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create([
            'http' => [
                'timeout' => THAM_UPDATE_TOTAL_TIMEOUT,
                'header' => "User-Agent: THAM-HosSafe-Updater\r\n",
                'ignore_errors' => true,
            ],
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
            ],
        ]);
        $json_data = @file_get_contents(THAM_UPDATE_VERSION_URL, false, $ctx);
        if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
            $http = (int)$m[1];
        } elseif ($json_data !== false) {
            $http = 200;
        }
        if ($json_data === false) {
            $cerr = 'network unavailable';
        }
    }

    if ($json_data === false || $http !== 200 || $json_data === '') {
        $result['error'] = $cerr !== '' ? $cerr : ('HTTP ' . $http);
        $result['offline'] = true;
        // จำว่า offline ชั่วคราว — หน้าถัดไปไม่ต้องรอ timeout ซ้ำ
        tham_update_config_set($con, 'update_remote_cache', json_encode($result, JSON_UNESCAPED_UNICODE));
        return $result;
    }

    $remote = json_decode($json_data, true);
    if (!is_array($remote) || empty($remote['latest_version'])) {
        $result['error'] = 'รูปแบบ version.json ไม่ถูกต้อง';
        tham_update_config_set($con, 'update_remote_cache', json_encode($result, JSON_UNESCAPED_UNICODE));
        return $result;
    }

    $result['ok'] = true;
    $result['offline'] = false;
    $result['latest_version'] = trim((string)$remote['latest_version']);
    $result['download_url'] = trim((string)($remote['download_url'] ?? ''));
    $result['update_details'] = trim((string)($remote['update_details'] ?? ''));
    $result['release_date'] = trim((string)($remote['release_date'] ?? ''));

    tham_update_config_set($con, 'update_remote_cache', json_encode($result, JSON_UNESCAPED_UNICODE));
    return $result;
}

function tham_update_check_status($con, $user_id, $force = false) {
    require_once __DIR__ . '/version.php';

    $local = APP_VERSION;
    $auto = tham_update_auto_check_enabled($con);
    $snoozed = tham_update_is_snoozed($con, $user_id);
    $snooze_until = tham_update_snooze_until($con, $user_id);

    if (!$auto && !$force) {
        return [
            'status' => 'success',
            'local_version' => $local,
            'remote_version' => $local,
            'has_update' => false,
            'show_prompt' => false,
            'snoozed' => $snoozed,
            'snooze_until' => $snooze_until,
            'update_details' => '',
            'download_url' => '',
            'release_date' => '',
            'checked_at' => date('Y-m-d H:i:s'),
            'remote_ok' => false,
            'offline' => false,
            'auto_check' => false,
            'skipped' => true,
            'error' => null,
            'upgrade_url' => 'upgrade.php',
        ];
    }

    $remote = tham_update_fetch_remote($con, $force);
    $remote_version = $remote['ok'] ? $remote['latest_version'] : $local;
    $has_update = $remote['ok'] && version_compare($local, $remote_version, '<');

    return [
        'status' => 'success',
        'local_version' => $local,
        'remote_version' => $remote_version,
        'has_update' => $has_update,
        'show_prompt' => $has_update && !$snoozed,
        'snoozed' => $snoozed,
        'snooze_until' => $snooze_until,
        'update_details' => $remote['update_details'] ?? '',
        'download_url' => $remote['download_url'] ?? '',
        'release_date' => $remote['release_date'] ?? '',
        'checked_at' => $remote['checked_at'] ?? date('Y-m-d H:i:s'),
        'remote_ok' => !empty($remote['ok']),
        'offline' => !empty($remote['offline']),
        'auto_check' => $auto,
        'skipped' => false,
        'error' => $remote['error'] ?? null,
        'upgrade_url' => 'upgrade.php',
    ];
}
