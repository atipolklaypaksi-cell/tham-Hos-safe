<?php
/**
 * แจ้งเตือนเคสแพ้ยารอรับ — สิทธิ์เปิด/ปิดตามบทบาทได้ที่ allergy_alert_settings.php
 */

function af_alert_default_allowed_roles() {
    return ['pharmacist', 'pharmacy_technician'];
}

function af_alert_ensure_access_table($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    @mysqli_query($con, "CREATE TABLE IF NOT EXISTS allergy_alert_role_access (
        role VARCHAR(40) NOT NULL PRIMARY KEY,
        allowed TINYINT(1) NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    $q = @mysqli_query($con, "SELECT COUNT(*) AS c FROM allergy_alert_role_access");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if ((int)($row['c'] ?? 0) === 0) {
        foreach (af_alert_default_allowed_roles() as $role) {
            $esc = mysqli_real_escape_string($con, $role);
            @mysqli_query($con, "INSERT INTO allergy_alert_role_access (role, allowed) VALUES ('$esc', 1)");
        }
    }
    $ready = true;
    return true;
}

function af_alert_get_role_access($con) {
    if (!function_exists('tham_menu_role_labels')) {
        require_once __DIR__ . '/menu_permissions_helper.php';
    }
    af_alert_ensure_access_table($con);
    $labels = tham_menu_role_labels();
    $defaults = array_fill_keys(af_alert_default_allowed_roles(), 1);
    $map = [];
    foreach (array_keys($labels) as $role) {
        $map[$role] = !empty($defaults[$role]) ? 1 : 0;
    }
    $q = mysqli_query($con, "SELECT role, allowed FROM allergy_alert_role_access");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $role = strtolower(trim((string)($r['role'] ?? '')));
            if ($role !== '' && array_key_exists($role, $map)) {
                $map[$role] = !empty($r['allowed']) ? 1 : 0;
            }
        }
    }
    return $map;
}

function af_alert_save_role_access($con, array $allowed_map) {
    af_alert_ensure_access_table($con);
    if (!function_exists('tham_menu_role_labels')) {
        require_once __DIR__ . '/menu_permissions_helper.php';
    }
    $valid = array_keys(tham_menu_role_labels());
    foreach ($valid as $role) {
        $on = !empty($allowed_map[$role]) ? 1 : 0;
        $esc = mysqli_real_escape_string($con, $role);
        $sql = "INSERT INTO allergy_alert_role_access (role, allowed) VALUES ('$esc', $on)
                ON DUPLICATE KEY UPDATE allowed=$on";
        if (!mysqli_query($con, $sql)) {
            return ['ok' => false, 'error' => 'บันทึกสิทธิ์ไม่สำเร็จ'];
        }
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION['af_alert_role_access'] = af_alert_get_role_access($con);
    }
    return ['ok' => true, 'roles' => af_alert_get_role_access($con)];
}

function af_alert_user_eligible($con = null, $role = null) {
    $role = strtolower(trim((string)($role !== null ? $role : ($_SESSION['role'] ?? ''))));
    if ($role === '') {
        return false;
    }
    $role_ok = false;
    if ($con) {
        $map = af_alert_get_role_access($con);
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION['af_alert_role_access'] = $map;
        }
        $role_ok = !empty($map[$role]);
    } else {
        $map = (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['af_alert_role_access']) && is_array($_SESSION['af_alert_role_access']))
            ? $_SESSION['af_alert_role_access']
            : array_fill_keys(af_alert_default_allowed_roles(), 1);
        $role_ok = !empty($map[$role]);
    }
    if (!$role_ok) {
        return false;
    }
    return af_alert_workplace_ok($con);
}

function af_alert_dispense_rooms() {
    return [
        'opd' => 'ห้องจ่ายยาผู้ป่วยนอก',
        'ipd' => 'ห้องจ่ายยาผู้ป่วยใน',
    ];
}

function af_alert_default_room_config() {
    return [
        'room_opd' => 1,
        'room_ipd' => 1,
    ];
}

function af_alert_ensure_room_config($con) {
    if (!$con) {
        return true;
    }
    static $ready = false;
    if ($ready) {
        return true;
    }
    foreach (af_alert_default_room_config() as $name => $val) {
        $key = 'af_alert_' . $name;
        $esc = mysqli_real_escape_string($con, $key);
        $q = @mysqli_query($con, "SELECT 1 FROM sys_config WHERE config_name='$esc' LIMIT 1");
        if (!$q || mysqli_num_rows($q) === 0) {
            $v = mysqli_real_escape_string($con, (string)(int)$val);
            @mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$esc', '$v')");
        }
    }
    $ready = true;
    return true;
}

function af_alert_get_room_config($con) {
    $cfg = af_alert_default_room_config();
    if (!$con) {
        return $cfg;
    }
    af_alert_ensure_room_config($con);
    $keys = [];
    foreach (array_keys($cfg) as $name) {
        $keys[] = "'" . mysqli_real_escape_string($con, 'af_alert_' . $name) . "'";
    }
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN (" . implode(',', $keys) . ")");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $name = preg_replace('/^af_alert_/', '', (string)($r['config_name'] ?? ''));
            if ($name !== '' && array_key_exists($name, $cfg)) {
                $cfg[$name] = !empty($r['config_value']) ? 1 : 0;
            }
        }
    }
    return $cfg;
}

function af_alert_save_room_config($con, array $src) {
    af_alert_ensure_room_config($con);
    $cfg = af_alert_get_room_config($con);
    foreach (array_keys(af_alert_default_room_config()) as $name) {
        if (isset($src[$name])) {
            $cfg[$name] = !empty($src[$name]) ? 1 : 0;
        }
    }
    foreach ($cfg as $name => $val) {
        $key = mysqli_real_escape_string($con, 'af_alert_' . $name);
        $v = mysqli_real_escape_string($con, (string)(int)$val);
        $ok = mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$key', '$v')
            ON DUPLICATE KEY UPDATE config_value='$v'");
        if (!$ok) {
            return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ'];
        }
    }
    return ['ok' => true, 'rooms' => $cfg];
}

function af_alert_workplace_ok($con = null) {
    $cfg = $con ? af_alert_get_room_config($con) : af_alert_default_room_config();
    $opd_on = !empty($cfg['room_opd']);
    $ipd_on = !empty($cfg['room_ipd']);
    if (!$opd_on && !$ipd_on) {
        return true;
    }
    $room = strtolower(trim((string)($_SESSION['dispense_room'] ?? '')));
    if ($room === '') {
        return true;
    }
    if ($room === 'opd') {
        return $opd_on;
    }
    if ($room === 'ipd') {
        return $ipd_on;
    }
    return true;
}

function af_alert_can_manage_access($role = null) {
    $role = strtolower(trim((string)($role !== null ? $role : ($_SESSION['role'] ?? ''))));
    return $role === 'admin';
}

function af_alert_can_manage_settings($con = null, $role = null) {
    $role = strtolower(trim((string)($role !== null ? $role : ($_SESSION['role'] ?? ''))));
    if ($role === 'admin') {
        return true;
    }
    if (function_exists('tham_menu_can') && tham_menu_can('allergy_alert_settings')) {
        return true;
    }
    return af_alert_user_eligible($con, $role);
}

function af_alert_intro_styles() {
    return [
        'hospital' => 'ระฆังโรงพยาบาล (แนะนำ)',
        'chime' => 'กระดิ่ง 2 โทน',
        'page' => 'เพจเจอร์ 3 จังหวะ',
        'fanfare' => 'อะคอร์ดสั้นเร้าใจ',
        'siren' => 'ไซเรนเร่งด่วน',
    ];
}

function af_alert_default_settings() {
    return [
        'enabled' => 1,
        'sound_enabled' => 1,
        'banner_enabled' => 1,
        'interval_min' => 5,
        'speech_text' => 'New Drug Allergy Case',
        'intro_style' => 'hospital',
    ];
}

function af_alert_ensure_table($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $sql = "CREATE TABLE IF NOT EXISTS allergy_alert_user_settings (
        user_id INT NOT NULL PRIMARY KEY,
        enabled TINYINT(1) NOT NULL DEFAULT 1,
        sound_enabled TINYINT(1) NOT NULL DEFAULT 1,
        banner_enabled TINYINT(1) NOT NULL DEFAULT 1,
        interval_min INT NOT NULL DEFAULT 5,
        speech_text VARCHAR(120) NOT NULL DEFAULT 'New Drug Allergy Case',
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8";
    @mysqli_query($con, $sql);
    $cq = @mysqli_query($con, "SHOW COLUMNS FROM allergy_alert_user_settings LIKE 'intro_style'");
    if (!$cq || mysqli_num_rows($cq) === 0) {
        @mysqli_query($con, "ALTER TABLE allergy_alert_user_settings ADD COLUMN intro_style VARCHAR(20) NOT NULL DEFAULT 'hospital' AFTER speech_text");
    }
    $ready = true;
    return true;
}

function af_alert_normalize_settings(array $row) {
    $def = af_alert_default_settings();
    $interval = (int)($row['interval_min'] ?? $def['interval_min']);
    if ($interval < 1) {
        $interval = 1;
    }
    if ($interval > 30) {
        $interval = 30;
    }
    $speech = trim((string)($row['speech_text'] ?? $def['speech_text']));
    if ($speech === '') {
        $speech = $def['speech_text'];
    }
    if (function_exists('mb_substr')) {
        $speech = mb_substr($speech, 0, 120, 'UTF-8');
    } else {
        $speech = substr($speech, 0, 120);
    }
    $styles = af_alert_intro_styles();
    $intro = trim((string)($row['intro_style'] ?? $def['intro_style']));
    if (!isset($styles[$intro])) {
        $intro = $def['intro_style'];
    }
    return [
        'enabled' => !empty($row['enabled']) ? 1 : 0,
        'sound_enabled' => !empty($row['sound_enabled']) ? 1 : 0,
        'banner_enabled' => !empty($row['banner_enabled']) ? 1 : 0,
        'interval_min' => $interval,
        'speech_text' => $speech,
        'intro_style' => $intro,
    ];
}

function af_alert_get_settings($con, $user_id) {
    af_alert_ensure_table($con);
    $user_id = (int)$user_id;
    if ($user_id <= 0) {
        return af_alert_default_settings();
    }
    $q = mysqli_query($con, "SELECT enabled, sound_enabled, banner_enabled, interval_min, speech_text, intro_style
        FROM allergy_alert_user_settings WHERE user_id=$user_id LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return af_alert_default_settings();
    }
    return af_alert_normalize_settings($row);
}

function af_alert_save_settings($con, $user_id, array $data) {
    af_alert_ensure_table($con);
    $user_id = (int)$user_id;
    if ($user_id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบผู้ใช้'];
    }
    $norm = af_alert_normalize_settings(array_merge(af_alert_default_settings(), $data));
    $speech = mysqli_real_escape_string($con, $norm['speech_text']);
    $intro = mysqli_real_escape_string($con, $norm['intro_style']);
    $sql = "INSERT INTO allergy_alert_user_settings
            (user_id, enabled, sound_enabled, banner_enabled, interval_min, speech_text, intro_style)
            VALUES ($user_id, {$norm['enabled']}, {$norm['sound_enabled']}, {$norm['banner_enabled']},
                    {$norm['interval_min']}, '$speech', '$intro')
            ON DUPLICATE KEY UPDATE
                enabled={$norm['enabled']},
                sound_enabled={$norm['sound_enabled']},
                banner_enabled={$norm['banner_enabled']},
                interval_min={$norm['interval_min']},
                speech_text='$speech',
                intro_style='$intro'";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ'];
    }
    return ['ok' => true, 'settings' => $norm];
}

function af_alert_pending_cases($con, $limit = 12) {
    $limit = max(1, min(30, (int)$limit));
    if (!function_exists('sp_poll_cache_get')) {
        require_once __DIR__ . '/smart_pharma_backup_helper.php';
    }
    list($cached, $cache_fp) = sp_poll_cache_get('af_pending_' . $limit, 8);
    if ($cached !== null) {
        return $cached;
    }
    if (!function_exists('af_ensure_tables')) {
        require_once __DIR__ . '/allergy_followup_helper.php';
    }
    af_ensure_tables($con);
    $sql = "SELECT id, hn, ptname, ward, case_date, notify_time, created_at
            FROM allergy_followup_cases
            WHERE (workflow_stage='reported' OR workflow_stage IS NULL OR workflow_stage='')
              AND IFNULL(import_key,'') = ''
            ORDER BY id DESC
            LIMIT $limit";
    $q = @mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $hn = function_exists('af_hn_display')
                ? af_hn_display($r['hn'] ?? '')
                : trim((string)($r['hn'] ?? ''));
            $rows[] = [
                'id' => (int)$r['id'],
                'hn' => $hn,
                'ptname' => trim((string)($r['ptname'] ?? '')),
                'ward' => trim((string)($r['ward'] ?? '')),
                'case_date' => (string)($r['case_date'] ?? ''),
                'notify_time' => substr((string)($r['notify_time'] ?? ''), 0, 5),
                'created_at' => (string)($r['created_at'] ?? ''),
                'open_url' => 'allergy_followup.php?open=' . (int)$r['id'],
            ];
        }
    }
    $count = count($rows);
    $cq = @mysqli_query($con, "SELECT COUNT(*) AS c FROM allergy_followup_cases
        WHERE (workflow_stage='reported' OR workflow_stage IS NULL OR workflow_stage='')
          AND IFNULL(import_key,'') = ''");
    if ($cq && ($cr = mysqli_fetch_assoc($cq))) {
        $count = (int)($cr['c'] ?? $count);
    }
    $pending_out = ['count' => $count, 'cases' => $rows];
    if (isset($cache_fp) && is_resource($cache_fp)) {
        sp_poll_cache_put($cache_fp, $pending_out);
    }
    return $pending_out;
}
