<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
session_write_close();
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/smc_clinic_report_helper.php');
mysqli_set_charset($con, 'utf8');
set_time_limit(240);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

$action = isset($_GET['action']) ? trim($_GET['action']) : 'summary';
$start_date = isset($_GET['start_date']) ? trim($_GET['start_date']) : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? trim($_GET['end_date']) : date('Y-m-d');
$granularity = smc_normalize_granularity($_GET['granularity'] ?? 'day');
$options = [
    'mode' => smc_normalize_mode($_GET['mode'] ?? 'shift4h'),
    'doctor_codes' => smc_normalize_doctor_codes($_GET['doctor'] ?? ($_GET['doctor_code'] ?? '')),
    'service_groups' => smc_normalize_service_groups($_GET['service_groups'] ?? ''),
    'dep_codes' => smc_normalize_dep_codes($_GET['dep_codes'] ?? ($_GET['dep_code'] ?? '')),
    'time_start' => smc_normalize_time($_GET['time_start'] ?? '16:00', '16:00:00'),
    'time_end' => smc_normalize_time($_GET['time_end'] ?? '21:00', '21:00:00'),
];

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}

hosxp_extend_read_timeout($hos, 180);

if ($action === 'departments') {
    $deps = smc_fetch_departments($hos);
    mysqli_close($hos);
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    if (($deps['error'] ?? '') !== '') {
        echo json_encode(['status' => 'error', 'message' => $deps['error']], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'departments' => $deps['rows'],
        'shift4h_codes' => $deps['shift4h_codes'],
        'si_codes' => $deps['si_codes'] ?? [],
        'so_codes' => $deps['so_codes'] ?? [],
        'meta' => ['elapsed_ms' => $deps['elapsed_ms'] ?? 0],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'summary' || $action === 'report') {
    $include_detail = ($action === 'report') && (!isset($_GET['include_detail']) || $_GET['include_detail'] !== '0');
    // summary action = ไม่ดึงรายละเอียด เพื่อลดเวลา/กัน 504
    if ($action === 'summary') {
        $include_detail = false;
    }
    $report = smc_build_report($hos, $start_date, $end_date, $granularity, $include_detail, $options);
    mysqli_close($hos);
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($report, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'details') {
    $period = rlu_parse_period($start_date, $end_date);
    $options = smc_prepare_options($hos, $period['start_date'], $period['end_date'], $options);
    if (empty($options['resolved_dep_codes'])) {
        mysqli_close($hos);
        ob_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบจุดรับบริการที่เลือก'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $detail = smc_fetch_detail_rows($hos, $period['start_date'], $period['end_date'], $options);
    mysqli_close($hos);
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    if (($detail['error'] ?? '') !== '') {
        echo json_encode(['status' => 'error', 'message' => $detail['error']], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'period' => $period,
        'details' => $detail['rows'],
        'meta' => [
            'detail_truncated' => !empty($detail['truncated']),
            'detail_limit' => (int)($detail['limit'] ?? 0),
            'elapsed_ms' => (int)($detail['elapsed_ms'] ?? 0),
        ],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

mysqli_close($hos);
ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
exit;
