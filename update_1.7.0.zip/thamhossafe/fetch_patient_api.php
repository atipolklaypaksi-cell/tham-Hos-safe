<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'unauthorized']);
    exit;
}

include('connect.php');
session_write_close();
require_once __DIR__ . '/med_error_helper.php';
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
mysqli_set_charset($con, 'utf8');

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? ''));
if ($action === 'search_doctor') {
    $term = trim((string)($_GET['q'] ?? $_POST['q'] ?? $_GET['term'] ?? ''));
    $hos = hosxp_connect($con);
    if (!$hos) {
        echo json_encode(['status' => 'error', 'message' => 'เชื่อมต่อ HOSxP ไม่สำเร็จ', 'results' => []], JSON_UNESCAPED_UNICODE);
        exit;
    }
    mysqli_set_charset($hos, 'utf8');
    $results = med_error_search_hosxp_doctors($hos, $term, 40);
    mysqli_close($hos);
    foreach ($results as &$row) {
        $group = med_error_lookup_doctor_group($con, $row['code'] ?? '', $row['name'] ?? '');
        $row['group'] = $group;
        $row['group_label'] = med_error_doctor_group_label($group);
    }
    unset($row);
    echo json_encode(['status' => 'success', 'results' => $results], JSON_UNESCAPED_UNICODE);
    exit;
}

$hn = isset($_GET['hn']) ? trim((string)$_GET['hn']) : '';
$date = isset($_GET['date']) ? trim((string)$_GET['date']) : '';
if ($date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    $date = '';
}
if ($hn === '') {
    echo json_encode(['status' => 'not_found', 'consult_history' => []]);
    exit;
}

$consults = med_error_fetch_consult_history($con, $hn);
$pt = med_error_fetch_patient_from_hosxp($con, $hn, $date);
if (!$pt) {
    echo json_encode([
        'status' => 'not_found',
        'consult_history' => $consults,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$doc_code = trim((string)($pt['order_doctor_code'] ?? ''));
$doc_name = trim((string)($pt['order_doctor_name'] ?? ''));
$doc_group = med_error_lookup_doctor_group($con, $doc_code, $doc_name);

echo json_encode([
    'status' => 'success',
    'hn' => $pt['hn'],
    'pname' => $pt['pname'],
    'fname' => $pt['fname'],
    'lname' => $pt['lname'],
    'full_name' => $pt['full_name'],
    'an' => $pt['an'] ?? '',
    'vn' => $pt['vn'] ?? '',
    'suggested_type' => $pt['suggested_type'] ?? '',
    'ward_name' => $pt['ward_name'] ?? '',
    'has_an' => !empty($pt['has_an']),
    'has_vn' => !empty($pt['has_vn']),
    'visit_rooms' => $pt['visit_rooms'] ?? [],
    'preferred_room' => $pt['preferred_room'] ?? '',
    'order_doctor_code' => $doc_code,
    'order_doctor_name' => $doc_name,
    'order_doctor_group' => $doc_group,
    'order_doctor_group_label' => med_error_doctor_group_label($doc_group),
    'pharmacy_ipd' => med_error_pharmacy_ipd(),
    'pharmacy_opd' => med_error_pharmacy_opd(),
    'consult_history' => $consults,
], JSON_UNESCAPED_UNICODE);
