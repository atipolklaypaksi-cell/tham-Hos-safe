<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('monitor_lab_consult_helper.php');
mysqli_set_charset($con, 'utf8');
mlc_ensure_tables($con);

$ids = [];
if (!empty($_GET['ids'])) {
    foreach (preg_split('/[,\s]+/', (string)$_GET['ids']) as $p) {
        $n = (int)$p;
        if ($n > 0) {
            $ids[$n] = true;
        }
    }
}
$id_one = (int)($_GET['id'] ?? 0);
if ($id_one > 0) {
    $ids[$id_one] = true;
}
$ids = array_keys($ids);

$rows = [];
foreach ($ids as $id) {
    $row = mlc_get_consult($con, $id);
    if ($row) {
        mlc_mark_printed($con, $id);
        $rows[] = mlc_format_consult_row($row);
    }
}
if (empty($rows)) {
    die('ไม่พบใบปรึกษา — กรุณาเริ่ม Consult จากหน้ารายงาน Monitor Lab ก่อน');
}

$primary = $rows[0];
$organ = $primary['organ'] ?? 'renal';
$visit_type = (trim((string)($primary['an'] ?? '')) !== '' && trim((string)$primary['an']) !== '0') ? 'IPD' : 'OPD';
$organ_label = $organ === 'hepatic' ? 'Monitor Lab ตับ' : ($organ === 'other' ? 'Monitor Lab อื่นๆ' : 'Monitor Lab ไต');
$topic = $organ === 'hepatic'
    ? 'เรื่อง การปรับขนาดยาตามค่าการทำงานของตับ'
    : ($organ === 'other' ? 'เรื่อง การปรับขนาดยาตามผล Lab' : 'เรื่อง การปรับขนาดยาตามค่าการทำงานของไต (eGFR / CrCl)');
$print_date = date('d/m/Y H:i');
$pharm_name = '';
foreach ($rows as $r) {
    if (trim((string)$r['pharmacist_name']) !== '') {
        $pharm_name = $r['pharmacist_name'];
        break;
    }
}
$reply_wait = (int)($primary['reply_wait_days'] ?? 0);
$reply_due = '';
foreach ($rows as $r) {
    if (($r['status'] ?? '') === 'in_progress' && !empty($r['reply_due_at'])) {
        $reply_due = $r['reply_due_at'];
        $reply_wait = (int)$r['reply_wait_days'];
        break;
    }
}
$note = '';
foreach ($rows as $r) {
    if (trim((string)$r['consult_note']) !== '') {
        $note = $r['consult_note'];
        break;
    }
}
$outcome = mlc_parse_consult_outcome($note);
$note_display = $outcome['key'] === 'other' ? '' : $outcome['extra'];
if ($outcome['key'] === '' && $outcome['extra'] === '' && $note !== '') {
    $note_display = $note;
}
$back = $organ === 'hepatic' ? 'monitor_lab_hepatic.php' : ($organ === 'other' ? 'monitor_lab_other.php' : 'monitor_lab_renal.php');
$lab_col = $organ === 'hepatic' ? 'ค่าตับ' : ($organ === 'other' ? 'ผล Lab' : 'ค่าไต');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ใบปรึกษาแพทย์ — <?php echo htmlspecialchars($organ_label); ?></title>
    <style>
        @page { size: A4 portrait; margin: 10mm 12mm; }
        * { box-sizing: border-box; }
        body { font-family: 'Sarabun', Tahoma, sans-serif; font-size: 11.5px; color: #111; background: #fff; margin: 0; line-height: 1.35; }
        .sheet { width: 100%; max-width: 190mm; margin: 0 auto; padding: 8px 4px; }
        .print-header { border-bottom: 2px solid #0d6efd; margin-bottom: 8px; padding-bottom: 6px; text-align: center; }
        .print-header .brand { font-size: 11px; color: #64748b; }
        .print-header h1 { margin: 2px 0; font-size: 18px; font-weight: 800; color: #0b5ed7; }
        .print-header .sub { font-size: 12px; font-weight: 700; }
        .print-header .meta { font-size: 10.5px; margin-top: 2px; }
        .badge-st { display: inline-block; border: 1px solid #64748b; border-radius: 3px; padding: 1px 6px; font-size: 10px; }
        .info-grid { width: 100%; border-collapse: collapse; margin-bottom: 6px; }
        .info-grid td { padding: 2px 4px; vertical-align: top; }
        .info-grid .lbl { font-weight: 700; width: 88px; color: #334155; white-space: nowrap; }
        .drug-table { width: 100%; border-collapse: collapse; margin: 6px 0 8px; font-size: 11px; }
        .drug-table th, .drug-table td { border: 1px solid #334155; padding: 4px 5px; vertical-align: top; }
        .drug-table th { background: #e8f4fd; text-align: center; font-weight: 700; }
        .drug-table td.num { text-align: center; white-space: nowrap; }
        .drug-table td.lab-cell { text-align: left; font-size: 10.5px; line-height: 1.4; min-width: 210px; }
        .lab-head { font-weight: 800; margin-top: 3px; }
        .lab-head:first-child { margin-top: 0; }
        .lab-line { font-size: 10.5px; }
        .box { border: 1px solid #334155; border-radius: 4px; padding: 6px 8px; margin-top: 6px; }
        .box-title { font-weight: 700; margin-bottom: 3px; color: #0d6efd; font-size: 11.5px; }
        .doctor-box { min-height: 72px; }
        .doctor-lines { margin-top: 8px; }
        .doctor-lines div { border-bottom: 1px dotted #64748b; height: 18px; margin-top: 2px; }
        .sign-row { display: flex; justify-content: space-between; gap: 16px; margin-top: 14px; }
        .sign-box { flex: 1; text-align: center; font-size: 11px; }
        .sign-line { margin-top: 28px; border-top: 1px solid #333; padding-top: 4px; }
        .hint { font-size: 10px; color: #475569; }
        @media print {
            .no-print { display: none !important; }
            body { margin: 0; }
            .sheet { padding: 0; max-width: none; }
            a { color: inherit; text-decoration: none; }
        }
        @media screen {
            body { background: #e2e8f0; padding: 16px; }
            .sheet { background: #fff; box-shadow: 0 1px 8px rgba(0,0,0,.12); padding: 14px 18px; min-height: 260mm; }
        }
    </style>
</head>
<body>
<div class="sheet">
    <div class="no-print" style="margin-bottom:10px;">
        <button onclick="window.print()" style="padding:6px 12px;font-weight:700;">พิมพ์</button>
        <button onclick="window.close()" style="padding:6px 12px;">ปิด</button>
        <a href="<?php echo htmlspecialchars($back); ?>" style="margin-left:8px;">กลับรายงาน</a>
        <span class="hint" style="margin-left:12px;">แนะนำ: กระดาษ A4 · แนวตั้ง · ขนาด 100%</span>
    </div>

    <div class="print-header">
        <div class="brand">THAM Hos-Safe · <?php echo htmlspecialchars($organ_label); ?></div>
        <h1>ใบปรึกษาแพทย์</h1>
        <div class="sub"><?php echo htmlspecialchars($topic); ?></div>
        <div class="meta">
            สถานะ: <span class="badge-st"><?php echo htmlspecialchars($primary['status_label']); ?></span>
            · วันที่พิมพ์ <?php echo htmlspecialchars($print_date); ?>
            · รายการยา <?php echo count($rows); ?> รายการ
        </div>
    </div>

    <table class="info-grid">
        <tr>
            <td class="lbl">HN</td>
            <td><strong><?php echo htmlspecialchars($primary['hn']); ?></strong>
                (<?php echo htmlspecialchars($visit_type); ?>)</td>
            <td class="lbl">AN / VN</td>
            <td><?php echo htmlspecialchars(trim($primary['an'] . ' / ' . $primary['vn'], ' /')); ?></td>
        </tr>
        <tr>
            <td class="lbl">ชื่อผู้ป่วย</td>
            <td colspan="3"><?php echo htmlspecialchars($primary['ptname']); ?></td>
        </tr>
        <?php if (trim((string)$primary['ward_name']) !== ''): ?>
        <tr>
            <td class="lbl">Ward</td>
            <td colspan="3"><?php echo htmlspecialchars($primary['ward_name']); ?></td>
        </tr>
        <?php endif; ?>
        <tr>
            <td class="lbl">เภสัชกร</td>
            <td colspan="3"><strong><?php echo htmlspecialchars($pharm_name !== '' ? $pharm_name : '-'); ?></strong></td>
        </tr>
        <tr>
            <td class="lbl">รอตอบกลับ</td>
            <td colspan="3">
                <?php if ($reply_wait <= 0): ?>
                <strong>ทันที</strong>
                <?php else: ?>
                <?php echo (int)$reply_wait; ?> วัน<?php echo $reply_due !== '' ? ' (ถึง ' . htmlspecialchars($reply_due) . ')' : ''; ?>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <table class="drug-table">
        <thead>
            <tr>
                <th style="width:28px;">#</th>
                <th>ยา / วิธีใช้</th>
                <th><?php echo htmlspecialchars($lab_col); ?></th>
                <th>เงื่อนไข / คำแนะนำ</th>
                <th style="width:108px;">วันที่สั่ง</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $i => $r): ?>
            <tr>
                <td class="num"><?php echo $i + 1; ?></td>
                <td>
                    <strong><?php echo htmlspecialchars($r['drug_name']); ?></strong>
                    <?php if ($r['icode'] !== ''): ?>
                    <span class="hint">(<?php echo htmlspecialchars($r['icode']); ?>)</span>
                    <?php endif; ?>
                    <div class="hint"><?php echo htmlspecialchars($r['method_text']); ?></div>
                    <?php if ($r['actual_dose'] !== ''): ?>
                    <div class="hint">สั่งใช้: <?php echo htmlspecialchars($r['actual_dose']); ?></div>
                    <?php endif; ?>
                </td>
                <td class="lab-cell">
                    <?php echo mlc_lab_value_print_html($r['lab_type'], $r['lab_value']); ?>
                </td>
                <td>
                    <?php echo htmlspecialchars($r['warning_msg']); ?>
                    <?php if ($r['recommended_dose'] !== '' && $r['recommended_dose'] !== '-'): ?>
                    <div class="hint">แนะนำ: <?php echo htmlspecialchars($r['recommended_dose']); ?></div>
                    <?php endif; ?>
                </td>
                <td class="num">
                    <?php echo htmlspecialchars($r['order_date']); ?>
                    <div><?php echo htmlspecialchars($r['order_time']); ?></div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (trim((string)$note_display) !== ''): ?>
    <div class="box">
        <div class="box-title">หมายเหตุจากเภสัชกร</div>
        <div><?php echo nl2br(htmlspecialchars($note_display)); ?></div>
    </div>
    <?php endif; ?>

    <div class="box doctor-box">
        <div class="box-title">ผลการปรึกษา / คำสั่งแพทย์</div>
        <div class="hint">
            <?php echo mlc_consult_outcome_checked_html($note); ?>
        </div>
        <div class="doctor-lines">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <div class="sign-row">
        <div class="sign-box">
            <div class="sign-line">
                เภสัชกรผู้ Consult<br>
                (<?php echo htmlspecialchars($pharm_name !== '' ? $pharm_name : '................................'); ?>)<br>
                วันที่ ....../....../..........
            </div>
        </div>
        <div class="sign-box">
            <div class="sign-line">
                แพทย์ผู้รับปรึกษา<br>
                (................................................)<br>
                วันที่ ....../....../..........
            </div>
        </div>
    </div>
</div>
<script>
window.addEventListener('load', function() {
    if (location.search.indexOf('autoprint=1') >= 0) {
        setTimeout(function() { window.print(); }, 250);
    }
});
</script>
</body>
</html>
