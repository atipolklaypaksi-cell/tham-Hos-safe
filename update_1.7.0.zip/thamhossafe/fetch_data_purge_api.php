<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['ok' => false, 'error' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/data_purge_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
$role = (string)($_SESSION['role'] ?? '');
if ($role !== 'admin') {
    echo json_encode(['ok' => false, 'error' => 'เฉพาะ Admin เท่านั้น'], JSON_UNESCAPED_UNICODE);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = array_merge($_GET, $_POST);
}
$action = trim((string)($input['action'] ?? 'summary'));
$userId = (int)$_SESSION['user_id'];
$userName = trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin'));

if ($action === 'summary') {
    session_write_close();
    dp_ensure_tables($con);
    echo json_encode([
        'ok' => true,
        'groups' => dp_group_counts($con),
        'batches' => dp_list_batches($con, true),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'purge') {
    $confirm = trim((string)($input['confirm'] ?? ''));
    if ($confirm !== 'delete') {
        echo json_encode(['ok' => false, 'error' => 'พิมพ์คำว่า delete เพื่อยืนยัน'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $groups = $input['groups'] ?? [];
    if (!is_array($groups)) {
        $groups = [];
    }
    $note = trim((string)($input['note'] ?? ''));
    session_write_close();
    $res = dp_purge_groups($con, $groups, $userId, $userName, $note);
    if (!empty($res['ok'])) {
        $res['groups_summary'] = dp_group_counts($con);
        $res['batches'] = dp_list_batches($con, true);
    }
    echo json_encode($res, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'restore') {
    $batchId = (int)($input['batch_id'] ?? 0);
    if ($batchId <= 0) {
        echo json_encode(['ok' => false, 'error' => 'ไม่พบ batch'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    session_write_close();
    $res = dp_restore_batch($con, $batchId, $userId);
    if (!empty($res['ok'])) {
        $res['groups_summary'] = dp_group_counts($con);
        $res['batches'] = dp_list_batches($con, true);
    }
    echo json_encode($res, JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'action ไม่รองรับ'], JSON_UNESCAPED_UNICODE);
