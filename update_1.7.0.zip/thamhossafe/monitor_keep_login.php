<?php
/**
 * ต่ออายุ Login ของเครื่องที่เปิด keep_login
 * เรียกจาก db_connect.php และ login.php เท่านั้น ไม่ใช้ auto_prepend
 * ใช้ได้เฉพาะ Local Web (LAN ในโรงพยาบาล) — ป้องกันการโจมตีจากภายนอก
 */

if (!function_exists('tham_is_local_web_request') && is_file(__DIR__ . '/local_web_helper.php')) {
    require_once __DIR__ . '/local_web_helper.php';
}

function tham_keep_login_map() {
    static $map = null;
    if ($map !== null) {
        return $map;
    }
    $map = [];
    $file = __DIR__ . '/storage/keep_login_machines.json';
    if (!is_file($file)) {
        return $map;
    }
    $raw = json_decode((string)@file_get_contents($file), true);
    if (is_array($raw) && isset($raw['ips']) && is_array($raw['ips'])) {
        $map = $raw['ips'];
    }
    return $map;
}

function tham_keep_login_client_ip() {
    return trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
}

function tham_keep_login_entry() {
    $ip = tham_keep_login_client_ip();
    if ($ip === '') {
        return null;
    }
    $map = tham_keep_login_map();
    return (isset($map[$ip]) && is_array($map[$ip])) ? $map[$ip] : null;
}

function tham_keep_login_cookie_path() {
    $dir = str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/')));
    $dir = rtrim($dir, '/');
    return $dir === '' ? '/' : $dir;
}

function tham_keep_login_refresh_cookie() {
    if (headers_sent() || session_status() !== PHP_SESSION_ACTIVE) {
        return;
    }
    $life = 86400 * 30;
    setcookie(session_name(), session_id(), [
        'expires' => time() + $life,
        'path' => tham_keep_login_cookie_path(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function tham_keep_login_remember_user($userId) {
    $userId = (int)$userId;
    $ip = tham_keep_login_client_ip();
    if ($userId <= 0 || $ip === '') {
        return;
    }
    $file = __DIR__ . '/storage/keep_login_machines.json';
    $raw = is_file($file) ? json_decode((string)@file_get_contents($file), true) : null;
    if (!is_array($raw) || !isset($raw['ips'][$ip]) || !is_array($raw['ips'][$ip])) {
        return;
    }
    if ((int)($raw['ips'][$ip]['user_id'] ?? 0) === $userId) {
        return;
    }
    $raw['ips'][$ip]['user_id'] = $userId;
    @file_put_contents($file, json_encode($raw, JSON_UNESCAPED_UNICODE), LOCK_EX);
}

function tham_keep_login_touch() {
    if (session_status() !== PHP_SESSION_ACTIVE || !tham_keep_login_entry()) {
        return;
    }
    // Login ค้างใช้ได้เฉพาะ Local Web
    if (function_exists('tham_is_local_web_request') && !tham_is_local_web_request()) {
        return;
    }
    $_SESSION['keep_login_machine'] = 1;
    $uid = (int)($_SESSION['user_id'] ?? 0);
    if ($uid > 0) {
        tham_keep_login_remember_user($uid);
        tham_keep_login_refresh_cookie();
    }
}

function tham_keep_login_restore($con) {
    if (!$con || session_status() !== PHP_SESSION_ACTIVE || !empty($_SESSION['user_id'])) {
        return false;
    }
    // Login ค้างใช้ได้เฉพาะ Local Web
    if (function_exists('tham_is_local_web_request') && !tham_is_local_web_request()) {
        return false;
    }
    $entry = tham_keep_login_entry();
    $want = (int)($entry['user_id'] ?? 0);
    if ($want <= 0) {
        return false;
    }
    $q = @mysqli_query($con, "SELECT id, username, full_name, role, auth_source, local_web_only FROM users WHERE id=$want LIMIT 1");
    if (!$q) {
        // คอลัมน์ยังไม่มี — fallback
        $q = @mysqli_query($con, "SELECT id, username, full_name, role, auth_source FROM users WHERE id=$want LIMIT 1");
    }
    $user = $q ? mysqli_fetch_assoc($q) : null;
    if (!$user) {
        return false;
    }
    if (function_exists('tham_users_ensure_local_web_column')) {
        tham_users_ensure_local_web_column($con);
    }
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['username'] = (string)$user['username'];
    $_SESSION['full_name'] = (string)$user['full_name'];
    $_SESSION['role'] = (string)$user['role'];
    $_SESSION['auth_source'] = (string)($user['auth_source'] ?? 'local');
    $_SESSION['local_web_only'] = (int)($user['local_web_only'] ?? 0) === 1 ? 1 : 0;
    $_SESSION['keep_login_machine'] = 1;
    if (!function_exists('tham_menu_load_session_permissions')) {
        require_once __DIR__ . '/menu_permissions_helper.php';
    }
    tham_menu_load_session_permissions($con, (int)$user['id'], (string)$user['role']);
    tham_keep_login_refresh_cookie();
    return true;
}
