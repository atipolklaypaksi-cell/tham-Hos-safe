<?php
/**
 * สิทธิ์เข้าถึงเมนู — กำหนดตาม Role (กลุ่ม) หรือรายคน
 */

function tham_menu_registry() {
    static $registry = null;
    if ($registry !== null) {
        return $registry;
    }
    $registry = [
        'home' => [
            'label' => 'หน้าหลัก',
            'icon' => 'fas fa-home',
            'pages' => ['home.php'],
        ],
        'group_safety' => [
            'label' => 'จัดการความปลอดภัยยา',
            'icon' => 'fas fa-shield-alt',
            'group' => true,
            'children' => [
                'safety.interaction' => ['label' => 'Monitor Interaction', 'pages' => ['monitor_drug_interaction.php', 'monitor_drug_interaction_print.php', 'monitor_drug_interaction_consult_print.php', 'fetch_drug_interaction_api.php', 'fetch_monitor_drug_interaction_consult_api.php']],
                'safety.lab_renal' => ['label' => 'Monitor Lab ไต', 'pages' => ['monitor_lab.php', 'monitor_lab_renal.php']],
                'safety.lab_hepatic' => ['label' => 'Monitor Lab ตับ', 'pages' => ['monitor_lab_hepatic.php']],
                'safety.lab_other' => ['label' => 'Monitor Lab อื่นๆ', 'pages' => ['monitor_lab_other.php']],
                'safety.hla' => ['label' => 'Monitor ยีนแพ้ยา HLA', 'pages' => ['monitor_hla.php']],
                'safety.drug_usage' => ['label' => 'Monitor วิธีใช้ยา', 'pages' => ['monitor_drug_usage.php']],
                'safety.max_dose' => ['label' => 'Monitor Max Dose/Duration', 'pages' => ['monitor_max_dose.php']],
                'safety.warfarin' => ['label' => 'Monitor Warfarin', 'pages' => ['monitor_warfarin.php']],
                'safety.mg_ml' => ['label' => 'Monitor mg. to mL.', 'pages' => ['monitor_mg_ml.php']],
                'safety.pediatric' => ['label' => 'Monitor ยาเด็ก', 'pages' => ['monitor_pediatric_dose.php']],
                'safety.dose_calculator' => ['label' => 'Monitor เครื่องคำนวณยา', 'pages' => ['monitor_dose_calculator.php', 'fetch_monitor_dose_calculator_api.php']],
                'safety.antibiotic' => ['label' => 'Monitor Antibiotic', 'pages' => ['monitor_antibiotic.php']],
                'safety.home_med' => ['label' => 'Monitor ยากลับบ้าน IPD', 'pages' => ['monitor_home_med.php', 'fetch_monitor_home_med_api.php']],
                'safety.opd_dup' => ['label' => 'Monitor ยาเหลือ OPD', 'pages' => ['monitor_opd_dup.php', 'fetch_monitor_opd_dup_api.php', 'fetch_monitor_opd_dup_consult_api.php', 'monitor_opd_dup_consult_print.php']],
                'safety.dup_therapy' => ['label' => 'Monitor คู่ยาซ้ำซ้อน', 'pages' => ['monitor_dup_therapy.php', 'fetch_monitor_dup_therapy_api.php']],
                'safety.opd_qty' => ['label' => 'Monitor จำนวนสั่งยา (OPD)', 'pages' => ['monitor_opd_order_qty.php']],
                'safety.drug_allergy' => ['label' => 'Monitor Drug Allergy', 'pages' => ['monitor_drug_allergy.php']],
            ],
        ],
        'group_smart_pharma' => [
            'label' => 'Smart Pharma',
            'icon' => 'fas fa-user-shield',
            'group' => true,
            'children' => [
                'smart_pharma.opd' => ['label' => 'ผู้ป่วยนอก (OPD)', 'pages' => ['smart_pharma_opd.php']],
                'smart_pharma.ipd' => ['label' => 'ผู้ป่วยใน (IPD)', 'pages' => ['smart_pharma_ipd.php']],
                'smart_pharma.interventions' => ['label' => 'Intervention Log', 'pages' => ['smart_pharma_interventions.php']],
                'smart_pharma.intervention_report' => ['label' => 'Intervention Report', 'pages' => ['smart_pharma_intervention_report.php', 'smart_pharma_intervention_consult_print.php']],
                'smart_pharma.settings' => ['label' => 'ตั้งค่าโมดูล', 'pages' => ['smart_pharma_settings.php', 'fetch_smart_pharma_backup_api.php']],
                'smart_pharma.screen_hn' => ['label' => 'คัดกรองตาม HN', 'pages' => ['smart_pharma_screen_hn.php']],
                'smart_pharma.notifications' => ['label' => 'แจ้งเตือน Alert', 'pages' => ['smart_pharma_notifications.php', 'smart_pharma_telegram.php', 'smart_pharma_webhook.php']],
            ],
        ],
        'group_controlled_drug' => [
            'label' => 'บริหารยาเสพติด/วัตถุออกฤทธิ์',
            'icon' => 'fas fa-capsules',
            'group' => true,
            'children' => [
                'controlled_drug.narcotic' => ['label' => 'จ่ายยา (ยาเสพติด)', 'pages' => ['controlled_drug_narcotic.php', 'controlled_drug_register_narcotic.php', 'controlled_drug_settings_narcotic.php', 'controlled_drug_rooms.php', 'controlled_drug_rooms_narcotic.php']],
                'controlled_drug.psychotropic' => ['label' => 'จ่ายยา (วัตถุออกฤทธิ์)', 'pages' => ['controlled_drug_psychotropic.php', 'controlled_drug_register_psychotropic.php', 'controlled_drug_settings_psychotropic.php', 'controlled_drug_rooms.php', 'controlled_drug_rooms_psychotropic.php']],
            ],
        ],
        'group_amr' => [
            'label' => 'AMR',
            'icon' => 'fas fa-bacteria',
            'group' => true,
            'children' => [
                'amr.dashboard' => [
                    'label' => 'Dashboard เชื้อดื้อยา',
                    'pages' => ['amr_dashboard.php', 'fetch_amr_api.php'],
                ],
                'amr.sensitivity' => [
                    'label' => 'CDSS for Antibiotic',
                    'pages' => [
                        'amr_sensitivity.php',
                        'fetch_amr_sensitivity_api.php',
                        'amr_cdss_consult_print.php',
                        'fetch_amr_cdss_consult_api.php',
                    ],
                ],
                'amr.monitor_drug' => [
                    'label' => 'Monitor AMR Drug',
                    'pages' => ['monitor_amr_drug.php', 'fetch_monitor_amr_drug_api.php'],
                ],
                'amr.monitor_sepsis' => [
                    'label' => 'Monitor Sepsis by score',
                    'pages' => ['monitor_sepsis.php', 'fetch_monitor_sepsis_api.php'],
                ],
                'amr.monitor_sepsis_culture' => [
                    'label' => 'Monitor Sepsis by culture',
                    'pages' => ['monitor_sepsis_culture.php', 'fetch_monitor_sepsis_culture_api.php'],
                ],
                'amr.amass' => [
                    'label' => 'Dashboard AMASS',
                    'pages' => ['amr_amass_dashboard.php', 'amr_amass_print.php', 'amr_amass_file.php', 'fetch_amr_amass_api.php'],
                ],
                'amr.antibiogram' => [
                    'label' => 'Antibiogram',
                    'pages' => ['amr_antibiogram.php', 'fetch_amr_antibiogram_api.php'],
                ],
                'amr.kpi' => [
                    'label' => 'KPI AMR',
                    'pages' => ['amr_kpi.php', 'fetch_amr_kpi_api.php'],
                ],
                'amr.settings' => [
                    'label' => 'ตั้งค่า Dictionary',
                    'pages' => ['amr_settings.php', 'fetch_amr_dict_api.php', 'fetch_amr_amass_api.php'],
                ],
            ],
        ],
        'group_pharm_care' => [
            'label' => 'Patient EMR',
            'icon' => 'fas fa-stethoscope',
            'group' => true,
            'children' => [
                'pharm_care.smart_drug' => ['label' => 'ระบบ Smart Drug', 'pages' => ['smart_drug.php', 'smart_drug_chronic.php', 'fetch_smart_drug_chronic_api.php', 'fetch_smart_drug_tmt_except_api.php', 'fetch_smart_drug_medrecon_api.php', 'fetch_smart_drug_postop_api.php']],
                'pharm_care.smart_lab' => ['label' => 'ระบบ Smart Lab', 'pages' => ['smart_lab.php', 'fetch_smart_lab_api.php']],
                'pharm_care.patient_opd' => [
                    'label' => 'Patient OPD',
                    'pages' => ['patient_opd.php', 'fetch_patient_opd_api.php', 'hapysure_sso.php'],
                ],
                'pharm_care.patient_ipd' => [
                    'label' => 'Patient IPD',
                    'pages' => ['patient_ipd.php', 'fetch_patient_ipd_api.php', 'drug_viewer_win.php'],
                ],
                'pharm_care.med_recon_discharge' => [
                    'label' => 'Med Reconcile ยากลับบ้าน',
                    'pages' => ['med_reconcile_discharge.php', 'fetch_med_reconcile_discharge_api.php', 'med_recon_history.php'],
                ],
            ],
        ],
        'group_med_error' => [
            'label' => 'Med error/Consult',
            'icon' => 'fas fa-exclamation-triangle',
            'group' => true,
            'children' => [
                'pharm_care.med_error' => [
                    'label' => 'Med error/Consult',
                    'pages' => [
                        'med_error.php',
                        'save_med_error.php',
                        'delete_med_error.php',
                        'action_error_type.php',
                        'export_med_error_excel.php',
                        'export_med_error_pdf.php',
                        'fetch_patient_api.php',
                        'fetch_med_error_drugs_api.php',
                        'fetch_robot_api.php',
                    ],
                ],
                'pharm_care.med_error_report' => [
                    'label' => 'รายงาน ME/Consult',
                    'pages' => ['report_med_error.php'],
                ],
            ],
        ],
        'group_allergy_system' => [
            'label' => 'ระบบแพ้ยา',
            'icon' => 'fas fa-allergies',
            'group' => true,
            'children' => [
                'allergy_report' => [
                    'label' => 'แจ้งเคสแพ้ยา',
                    'pages' => ['allergy_report.php', 'fetch_allergy_stt_api.php'],
                ],
                'allergy_followup' => [
                    'label' => 'ติดตามการแพ้ยา',
                    'pages' => ['allergy_followup.php', 'allergy_followup_photo.php', 'fetch_allergy_followup_api.php'],
                ],
                'allergy_history' => [
                    'label' => 'ประวัติแพ้ยาใน รพ.',
                    'pages' => ['allergy_history.php'],
                ],
                'allergy_eval_dashboard' => [
                    'label' => 'Dashboard การประเมินแพ้ยา',
                    'pages' => ['allergy_eval_dashboard.php', 'fetch_allergy_eval_dashboard_api.php'],
                ],
                'allergy_alert_settings' => [
                    'label' => 'ตั้งค่าแจ้งเตือนแพ้ยา',
                    'pages' => ['allergy_alert_settings.php'],
                ],
            ],
        ],
        'group_drug_center' => [
            'label' => 'Drugs Center (PHR)',
            'icon' => 'fas fa-cloud',
            'group' => true,
            'children' => [
                'drug_center.med_reconcile' => [
                    'label' => 'Med Reconcile (PHR)',
                    'pages' => ['dc_med_reconcile.php'],
                ],
                'drug_center.check_all' => [
                    'label' => 'Check Drug All',
                    'pages' => ['dc_check_drug_all.php'],
                ],
            ],
        ],
        'group_dose_calc' => [
            'label' => 'ระบบช่วยคำนวณ',
            'icon' => 'fas fa-calculator',
            'group' => true,
            'children' => [
                'dose_calc.hub' => ['label' => 'เครื่องคำนวณยา', 'pages' => ['dose_calculator.php']],
                'dose_calc.warfarin' => ['label' => 'คำนวณยา Warfarin', 'pages' => ['warfarin_calculator.php']],
                'dose_calc.mg_ml' => ['label' => 'คำนวณ mg → mL', 'pages' => ['mg_ml_calculator.php']],
                'dose_calc.pediatric' => ['label' => 'คำนวณขนาดยาในเด็ก', 'pages' => ['pediatric_dose_calculator.php']],
            ],
        ],
        'drug_eval.j2' => [
            'label' => 'ประเมินยา จ2',
            'icon' => 'fas fa-clipboard-list',
            'pages' => ['drug_eval_j2.php', 'drug_eval_j2_print.php'],
        ],
        'group_network_drug' => [
            'label' => 'บัญชียาเครือข่าย',
            'icon' => 'fas fa-network-wired',
            'group' => true,
            'children' => [
                'network_drug.upload' => ['label' => 'Upload ไฟล์', 'pages' => ['network_drug_upload.php']],
                'network_drug.list' => ['label' => 'รายการบัญชียาเครือข่าย', 'pages' => ['network_drug_list.php']],
                'network_drug.refer' => ['label' => 'Refer ยาผู้ป่วย', 'pages' => ['drug_refer.php', 'drug_refer_print.php']],
                'network_drug.refer_district' => ['label' => 'Refer ยาแยกเขต', 'pages' => ['drug_refer_district.php']],
                'network_drug.refer_appointment' => ['label' => 'Refer ยาแยกตามวันนัด', 'pages' => ['drug_refer_appointment.php']],
                'network_drug.monitor_refer_back' => ['label' => 'Monitor Refer Back', 'pages' => [
                    'monitor_refer_back.php',
                    'monitor_refer_back_opd.php',
                    'monitor_refer_back_ipd.php',
                    'monitor_refer_back_interventions.php',
                    'monitor_refer_back_settings.php',
                ]],
            ],
        ],
        'invc.stock' => [
            'label' => 'ระบบ INVC',
            'icon' => 'fas fa-boxes',
            'pages' => ['invc_stock.php', 'fetch_invc_stock_api.php'],
        ],
        'group_dashboard_report' => [
            'label' => 'Dashboard รายงาน',
            'icon' => 'fas fa-file-alt',
            'group' => true,
            'children' => [
                'rational_lab.dashboard' => [
                    'label' => 'Rational Lab Use',
                    'pages' => ['rational_lab_use_dashboard.php', 'rational_lab_use.php'],
                ],
                'rational_lab.report' => [
                    'label' => 'รายงานการใช้แยกหมวด',
                    'pages' => ['report_dashboard.php'],
                ],
                'report.postal_drug' => [
                    'label' => 'รายงานการรับยา ปณ.',
                    'pages' => ['report_postal_drug.php'],
                ],
                'report.smc_clinic' => [
                    'label' => 'รายงาน SMC / นอกเวลา',
                    'pages' => ['report_smc_clinic.php'],
                ],
            ],
        ],
        'deployment.map' => [
            'label' => 'รพ.ที่ใช้ THAM Hos-Safe',
            'icon' => 'fas fa-map-marked-alt',
            'pages' => [],
        ],
        'agent.download' => [
            'label' => 'ดาวน์โหลด Alert Agent',
            'icon' => 'fas fa-download',
            'pages' => ['alert_agent.php', 'alert_agent_file.php'],
        ],
        'group_admin' => [
            'label' => 'ตั้งค่าระบบ',
            'icon' => 'fas fa-cog',
            'group' => true,
            'children' => [
                'admin.hosxp' => ['label' => 'เชื่อมต่อ HOSxP', 'pages' => ['hosxp_setting.php']],
                'admin.hosxp_master' => ['label' => 'เชื่อมต่อ HOSxP master', 'pages' => ['hosxp_master_setting.php', 'save_hosxp_master_config.php']],
                'admin.integrations_hub' => [
                    'label' => 'เปิด/ปิดการเชื่อมต่อ',
                    'pages' => ['integrations_hub.php', 'fetch_integrations_hub_api.php'],
                ],
                'admin.data_purge' => [
                    'label' => 'ล้างข้อมูลปฏิบัติการ',
                    'pages' => ['data_purge_admin.php', 'fetch_data_purge_api.php'],
                ],
                'admin.alert_pipelines' => ['label' => 'Alert pipelines', 'pages' => ['alert_settings.php', 'fetch_tham_alert_api.php', 'cron_tham_alert.php']],
                'admin.alert_agents' => ['label' => 'เครื่อง Alert Agent', 'pages' => ['alert_agent_machines.php']],
                'admin.hosoffice' => ['label' => 'เชื่อมต่อ HOSoffice', 'pages' => ['hosoffice_setting.php', 'fetch_hosoffice_api.php']],
                'admin.jhcis' => ['label' => 'เชื่อมต่อ JHCIS PCC', 'pages' => ['jhcis_setting.php', 'fetch_jhcis_api.php']],
                'admin.drug_viewer' => ['label' => 'เชื่อมต่อ Drug Viewer', 'pages' => ['drug_viewer_setting.php', 'fetch_drug_viewer_api.php']],
                'admin.robot' => ['label' => 'เชื่อมต่อ Robot OPD', 'pages' => ['robot_setting.php', 'fetch_robot_api.php']],
                'admin.hapysure' => ['label' => 'เชื่อมต่อ HAPYsure', 'pages' => ['hapysure_setting.php']],
                'admin.provider_id' => [
                    'label' => 'ตั้งค่า Provider ID',
                    'pages' => ['provider_id_setting.php'],
                ],
                'admin.invc' => ['label' => 'เชื่อมต่อ INVC', 'pages' => ['invc_setting.php', 'fetch_invc_api.php']],
                'admin.hospital_ds' => ['label' => 'เชื่อมต่อรพ. ต่างๆ', 'pages' => ['hospital_connect.php', 'hospital_explore.php', 'fetch_hospital_connect_api.php']],
                'admin.amr_connect' => ['label' => 'เชื่อมต่อ AMR', 'pages' => ['amr_connect.php', 'fetch_amr_connect_api.php', 'cron_amr_mlab_sync.php']],
                'admin.warfarin_guideline' => ['label' => 'Guideline Warfarin', 'pages' => ['warfarin_guideline_setting.php']],
                'admin.display_mask' => [
                    'label' => 'ตั้งค่าแสดงยา และ Lab',
                    'pages' => ['display_mask_setting.php', 'fetch_display_mask_api.php'],
                ],
                'admin.users' => ['label' => 'จัดการผู้ใช้งาน', 'pages' => ['users.php', 'user_access_log.php']],
                'admin.menu_permissions' => ['label' => 'สิทธิ์เข้าถึงเมนู', 'pages' => ['menu_permissions.php']],
                'admin.upgrade' => ['label' => 'อัปเกรดระบบ', 'pages' => ['upgrade.php', 'do_update.php', 'backup_db.php']],
                'admin.server_health' => ['label' => 'Monitor เซิร์ฟเวอร์', 'pages' => ['server_health.php', 'fetch_server_health_api.php']],
                'admin.license' => ['label' => 'สร้าง License', 'pages' => ['admin_generate_key.php']],
            ],
        ],
    ];
    return $registry;
}

function tham_menu_registry_groups() {
    $groups = [];
    foreach (tham_menu_registry() as $groupKey => $item) {
        if (!empty($item['group']) && !empty($item['children'])) {
            $children = [];
            foreach ($item['children'] as $childKey => $child) {
                $children[] = ['key' => $childKey, 'label' => $child['label']];
            }
            $groups[] = [
                'key' => $groupKey,
                'label' => $item['label'],
                'children' => $children,
            ];
        } else {
            $groups[] = [
                'key' => $groupKey,
                'label' => $item['label'],
                'children' => [['key' => $groupKey, 'label' => $item['label']]],
            ];
        }
    }
    return $groups;
}

function tham_menu_all_keys() {
    $keys = [];
    foreach (tham_menu_registry() as $key => $item) {
        if (!empty($item['group']) && !empty($item['children'])) {
            foreach ($item['children'] as $childKey => $child) {
                $keys[] = $childKey;
            }
        } else {
            $keys[] = $key;
        }
    }
    return $keys;
}

function tham_menu_page_map() {
    static $map = null;
    if ($map !== null) {
        return $map;
    }
    $map = [];
    foreach (tham_menu_registry() as $key => $item) {
        if (!empty($item['group']) && !empty($item['children'])) {
            foreach ($item['children'] as $childKey => $child) {
                foreach ($child['pages'] ?? [] as $page) {
                    $map[$page] = $childKey;
                }
            }
        } else {
            foreach ($item['pages'] ?? [] as $page) {
                $map[$page] = $key;
            }
        }
    }
  // หน้าที่ไม่ต้องตรวจ (login, logout)
    return $map;
}

function tham_menu_builtin_role_labels() {
    return [
        'admin' => 'ผู้ดูแลระบบ',
        'pharmacist' => 'เภสัชกร',
        'doctor' => 'แพทย์',
        'nurse' => 'พยาบาล',
        'pharmacy_technician' => 'เจ้าพนักงานเภสัชกรรม',
        'medical_technologist' => 'นักเทคนิคการแพทย์',
        'general_staff' => 'เจ้าหน้าที่ทั่วไป',
    ];
}

/** @param mysqli|null $con */
function tham_menu_role_labels($con = null) {
    $labels = tham_menu_builtin_role_labels();
    if ($con === null && isset($GLOBALS['con']) && $GLOBALS['con']) {
        $con = $GLOBALS['con'];
    }
    if (!$con) {
        return $labels;
    }
    tham_menu_ensure_tables($con);
    $q = @mysqli_query($con, 'SELECT role_key, label FROM menu_custom_roles ORDER BY label ASC');
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $key = trim((string)($row['role_key'] ?? ''));
            $label = trim((string)($row['label'] ?? ''));
            if ($key === '' || $key === 'admin' || isset($labels[$key])) {
                continue;
            }
            $labels[$key] = $label !== '' ? $label : $key;
        }
    }
    return $labels;
}

function tham_menu_role_exists($con, $role) {
    $role = trim((string)$role);
    if ($role === '') {
        return false;
    }
    $labels = tham_menu_role_labels($con);
    return isset($labels[$role]);
}

function tham_menu_is_builtin_role($role) {
    return isset(tham_menu_builtin_role_labels()[trim((string)$role)]);
}

function tham_menu_normalize_role_key($key) {
    $key = strtolower(trim((string)$key));
    $key = preg_replace('/[^a-z0-9_]+/', '_', $key);
    $key = trim($key, '_');
    if (strlen($key) > 50) {
        $key = substr($key, 0, 50);
    }
    return $key;
}

/**
 * @return array{ok:bool,error?:string,role_key?:string,label?:string}
 */
function tham_menu_add_custom_role($con, $role_key, $label) {
    tham_menu_ensure_tables($con);
    $label = trim((string)$label);
    $role_key = tham_menu_normalize_role_key($role_key);
    if ($role_key === '') {
        $role_key = 'custom_' . substr(bin2hex(random_bytes(4)), 0, 8);
    }
    if (!preg_match('/^[a-z][a-z0-9_]{1,49}$/', $role_key)) {
        return ['ok' => false, 'error' => 'รหัสกลุ่มต้องขึ้นต้นด้วย a-z และใช้ได้เฉพาะ a-z 0-9 _ (2–50 ตัว)'];
    }
    if ($role_key === 'admin' || tham_menu_is_builtin_role($role_key)) {
        return ['ok' => false, 'error' => 'รหัสนี้เป็นกลุ่มมาตรฐานของระบบ ใช้ชื่ออื่น'];
    }
    if ($label === '') {
        return ['ok' => false, 'error' => 'กรุณาระบุชื่อกลุ่มสิทธิ์'];
    }
    if (function_exists('mb_strlen') && mb_strlen($label, 'UTF-8') > 120) {
        $label = mb_substr($label, 0, 120, 'UTF-8');
    } elseif (strlen($label) > 360) {
        $label = substr($label, 0, 360);
    }
    $escKey = mysqli_real_escape_string($con, $role_key);
    $escLabel = mysqli_real_escape_string($con, $label);
    $chk = mysqli_query($con, "SELECT role_key FROM menu_custom_roles WHERE role_key = '$escKey' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return ['ok' => false, 'error' => 'มีรหัสกลุ่มนี้อยู่แล้ว'];
    }
    if (!mysqli_query($con, "INSERT INTO menu_custom_roles (role_key, label) VALUES ('$escKey', '$escLabel')")) {
        return ['ok' => false, 'error' => 'บันทึกกลุ่มไม่สำเร็จ'];
    }
    return ['ok' => true, 'role_key' => $role_key, 'label' => $label];
}

/**
 * @return array{ok:bool,error?:string}
 */
function tham_menu_delete_custom_role($con, $role_key) {
    tham_menu_ensure_tables($con);
    $role_key = tham_menu_normalize_role_key($role_key);
    if ($role_key === '' || tham_menu_is_builtin_role($role_key)) {
        return ['ok' => false, 'error' => 'ลบกลุ่มมาตรฐานของระบบไม่ได้'];
    }
    $esc = mysqli_real_escape_string($con, $role_key);
    $chk = mysqli_query($con, "SELECT role_key FROM menu_custom_roles WHERE role_key = '$esc' LIMIT 1");
    if (!$chk || mysqli_num_rows($chk) === 0) {
        return ['ok' => false, 'error' => 'ไม่พบกลุ่มสิทธิ์นี้'];
    }
    $uq = mysqli_query($con, "SELECT COUNT(*) AS c FROM users WHERE role = '$esc'");
    $cnt = ($uq && ($r = mysqli_fetch_assoc($uq))) ? (int)$r['c'] : 0;
    if ($cnt > 0) {
        return ['ok' => false, 'error' => "มีผู้ใช้ $cnt คนใช้กลุ่มนี้ — เปลี่ยน Role ที่จัดการผู้ใช้งานก่อน"];
    }
    mysqli_query($con, "DELETE FROM role_menu_permissions WHERE role = '$esc'");
    if (!mysqli_query($con, "DELETE FROM menu_custom_roles WHERE role_key = '$esc'")) {
        return ['ok' => false, 'error' => 'ลบกลุ่มไม่สำเร็จ'];
    }
    return ['ok' => true];
}

function tham_menu_ensure_tables($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/menu_permissions.sql');
    if ($sql === false) {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '') {
            @mysqli_query($con, $stmt);
        }
    }
    @mysqli_query($con, "CREATE TABLE IF NOT EXISTS menu_custom_roles (
        role_key VARCHAR(50) NOT NULL,
        label VARCHAR(120) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (role_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    $q = mysqli_query($con, "SHOW COLUMNS FROM users LIKE 'use_custom_menus'");
    if ($q && mysqli_num_rows($q) === 0) {
        mysqli_query($con, "ALTER TABLE users ADD COLUMN use_custom_menus TINYINT(1) NOT NULL DEFAULT 0");
    }
    $ready = true;
    return true;
}

function tham_menu_fetch_role_permissions($con, $role) {
    tham_menu_ensure_tables($con);
    $role = mysqli_real_escape_string($con, $role);
    $q = mysqli_query($con, "SELECT menu_key FROM role_menu_permissions WHERE role = '$role'");
    $keys = [];
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $keys[] = $row['menu_key'];
        }
    }
    return $keys;
}

function tham_menu_fetch_user_permissions($con, $user_id) {
    tham_menu_ensure_tables($con);
    $user_id = (int)$user_id;
    $q = mysqli_query($con, "SELECT menu_key FROM user_menu_permissions WHERE user_id = $user_id");
    $keys = [];
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $keys[] = $row['menu_key'];
        }
    }
    return $keys;
}

function tham_menu_user_uses_custom($con, $user_id) {
    tham_menu_ensure_tables($con);
    $user_id = (int)$user_id;
    $q = mysqli_query($con, "SELECT use_custom_menus FROM users WHERE id = $user_id LIMIT 1");
    if ($q && ($row = mysqli_fetch_assoc($q))) {
        return (int)($row['use_custom_menus'] ?? 0) === 1;
    }
    return false;
}

function tham_menu_resolve_allowed_keys($con, $user_id, $role) {
    if ($role === 'admin') {
        return tham_menu_all_keys();
    }
    if (tham_menu_user_uses_custom($con, $user_id)) {
        $custom = tham_menu_fetch_user_permissions($con, $user_id);
        if (!empty($custom)) {
            return tham_menu_expand_report_aliases($custom);
        }
    }
    $roleKeys = tham_menu_fetch_role_permissions($con, $role);
    if (empty($roleKeys)) {
        return tham_menu_all_keys();
    }
    return tham_menu_expand_report_aliases($roleKeys);
}

/**
 * เติมสิทธิ์ที่ควรมีอัตโนมัติ:
 * - home = หน้าหลัก ทุกคนที่ล็อกอินต้องเข้าได้
 * - agent.download = ดาวน์โหลดโปรแกรมแจ้งเตือนที่เครื่อง ทุกสิทธิ์เข้าได้
 * - ผู้ที่มีรายงานเดิม ได้สิทธิ์รายงานรับยาปณ. และคลินิก SMC ด้วย
 */
function tham_menu_expand_report_aliases(array $keys) {
    if (!in_array('home', $keys, true)) {
        array_unshift($keys, 'home');
    }
    if (!in_array('agent.download', $keys, true)) {
        $keys[] = 'agent.download';
    }
    if (in_array('admin.hosxp', $keys, true) && !in_array('admin.hosxp_master', $keys, true)) {
        $keys[] = 'admin.hosxp_master';
    }
    if ((in_array('admin.hosxp', $keys, true) || in_array('admin.hosxp_master', $keys, true)) && !in_array('admin.alert_pipelines', $keys, true)) {
        $keys[] = 'admin.alert_pipelines';
    }
    if ((in_array('admin.hosxp', $keys, true) || in_array('admin.alert_pipelines', $keys, true)) && !in_array('admin.alert_agents', $keys, true)) {
        $keys[] = 'admin.alert_agents';
    }
    if (in_array('admin.hosxp', $keys, true) && !in_array('admin.jhcis', $keys, true)) {
        $keys[] = 'admin.jhcis';
    }
    if (in_array('admin.hosxp', $keys, true) && !in_array('admin.drug_viewer', $keys, true)) {
        $keys[] = 'admin.drug_viewer';
    }
    if (in_array('admin.hosxp', $keys, true) && !in_array('admin.robot', $keys, true)) {
        $keys[] = 'admin.robot';
    }
    if ((in_array('admin.hosxp', $keys, true) || in_array('admin.robot', $keys, true)) && !in_array('admin.hapysure', $keys, true)) {
        $keys[] = 'admin.hapysure';
    }
    if ((in_array('admin.hosxp', $keys, true) || in_array('admin.hapysure', $keys, true)) && !in_array('admin.provider_id', $keys, true)) {
        $keys[] = 'admin.provider_id';
    }
    if (in_array('admin.hosxp', $keys, true) && !in_array('admin.display_mask', $keys, true)) {
        $keys[] = 'admin.display_mask';
    }
    if (in_array('rational_lab.report', $keys, true) && !in_array('report.postal_drug', $keys, true)) {
        $keys[] = 'report.postal_drug';
    }
    if (in_array('rational_lab.report', $keys, true) && !in_array('report.smc_clinic', $keys, true)) {
        $keys[] = 'report.smc_clinic';
    }
    if (in_array('dose_calc.hub', $keys, true) && !in_array('dose_calc.warfarin', $keys, true)) {
        $keys[] = 'dose_calc.warfarin';
    }
    if (in_array('dose_calc.hub', $keys, true) && !in_array('dose_calc.mg_ml', $keys, true)) {
        $keys[] = 'dose_calc.mg_ml';
    }
    if (in_array('dose_calc.hub', $keys, true) && !in_array('dose_calc.pediatric', $keys, true)) {
        $keys[] = 'dose_calc.pediatric';
    }
    if (!in_array('safety.pediatric', $keys, true)
        && (in_array('safety.mg_ml', $keys, true) || in_array('dose_calc.pediatric', $keys, true))) {
        $keys[] = 'safety.pediatric';
    }
    if (!in_array('safety.dose_calculator', $keys, true)
        && (in_array('dose_calc.hub', $keys, true)
            || in_array('safety.mg_ml', $keys, true)
            || in_array('safety.pediatric', $keys, true))) {
        $keys[] = 'safety.dose_calculator';
    }
    if (!in_array('safety.antibiotic', $keys, true)
        && (in_array('safety.max_dose', $keys, true) || in_array('safety.warfarin', $keys, true))) {
        $keys[] = 'safety.antibiotic';
    }
    if (!in_array('safety.home_med', $keys, true)
        && (in_array('safety.opd_qty', $keys, true)
            || in_array('safety.antibiotic', $keys, true)
            || in_array('safety.max_dose', $keys, true))) {
        $keys[] = 'safety.home_med';
    }
    if (!in_array('safety.opd_dup', $keys, true)
        && (in_array('safety.home_med', $keys, true)
            || in_array('safety.opd_qty', $keys, true))) {
        $keys[] = 'safety.opd_dup';
    }
    if (!in_array('safety.dup_therapy', $keys, true)
        && (in_array('safety.interaction', $keys, true)
            || in_array('safety.max_dose', $keys, true)
            || in_array('safety.opd_dup', $keys, true))) {
        $keys[] = 'safety.dup_therapy';
    }
    if (!in_array('pharm_care.med_error', $keys, true)
        && (in_array('pharm_care.smart_drug', $keys, true)
            || in_array('pharm_care.smart_lab', $keys, true))) {
        $keys[] = 'pharm_care.med_error';
    }
    if (!in_array('pharm_care.med_error_report', $keys, true)
        && in_array('pharm_care.med_error', $keys, true)) {
        $keys[] = 'pharm_care.med_error_report';
    }
    if (!in_array('pharm_care.med_recon_discharge', $keys, true)
        && in_array('pharm_care.smart_drug', $keys, true)) {
        $keys[] = 'pharm_care.med_recon_discharge';
    }
    if (!in_array('pharm_care.patient_opd', $keys, true)
        && (in_array('pharm_care.smart_lab', $keys, true)
            || in_array('pharm_care.smart_drug', $keys, true))) {
        $keys[] = 'pharm_care.patient_opd';
    }
    if (!in_array('pharm_care.patient_ipd', $keys, true)
        && (in_array('pharm_care.patient_opd', $keys, true)
            || in_array('pharm_care.smart_lab', $keys, true)
            || in_array('pharm_care.smart_drug', $keys, true))) {
        $keys[] = 'pharm_care.patient_ipd';
    }
    if (!in_array('amr.dashboard', $keys, true)
        && (in_array('safety.antibiotic', $keys, true)
            || in_array('rational_lab.dashboard', $keys, true))) {
        $keys[] = 'amr.dashboard';
    }
    if (!in_array('amr.settings', $keys, true)
        && in_array('amr.dashboard', $keys, true)) {
        $keys[] = 'amr.settings';
    }
    if (!in_array('amr.amass', $keys, true)
        && (in_array('amr.dashboard', $keys, true) || in_array('amr.settings', $keys, true))) {
        $keys[] = 'amr.amass';
    }
    if (!in_array('amr.antibiogram', $keys, true)
        && (in_array('amr.dashboard', $keys, true) || in_array('amr.amass', $keys, true))) {
        $keys[] = 'amr.antibiogram';
    }
    if (!in_array('amr.kpi', $keys, true)
        && (in_array('amr.antibiogram', $keys, true) || in_array('amr.dashboard', $keys, true))) {
        $keys[] = 'amr.kpi';
    }
    if (!in_array('amr.sensitivity', $keys, true)
        && (in_array('amr.dashboard', $keys, true) || in_array('amr.amass', $keys, true))) {
        $keys[] = 'amr.sensitivity';
    }
    if (!in_array('amr.monitor_drug', $keys, true)
        && (in_array('amr.sensitivity', $keys, true) || in_array('amr.dashboard', $keys, true))) {
        $keys[] = 'amr.monitor_drug';
    }
    if (!in_array('amr.monitor_sepsis', $keys, true)
        && (in_array('amr.monitor_drug', $keys, true) || in_array('amr.dashboard', $keys, true))) {
        $keys[] = 'amr.monitor_sepsis';
    }
    if (!in_array('amr.monitor_sepsis_culture', $keys, true)
        && (in_array('amr.monitor_sepsis', $keys, true)
            || in_array('amr.monitor_drug', $keys, true)
            || in_array('amr.dashboard', $keys, true))) {
        $keys[] = 'amr.monitor_sepsis_culture';
    }
    if (!in_array('allergy_followup', $keys, true)
        && (in_array('safety.drug_allergy', $keys, true)
            || in_array('smart_pharma.settings', $keys, true)
            || in_array('pharm_care.med_error', $keys, true)
            || in_array('allergy_history', $keys, true)
            || in_array('allergy_report', $keys, true))) {
        $keys[] = 'allergy_followup';
    }
    if (!in_array('allergy_report', $keys, true)
        && (in_array('allergy_followup', $keys, true)
            || in_array('allergy_history', $keys, true)
            || in_array('safety.drug_allergy', $keys, true))) {
        $keys[] = 'allergy_report';
    }
    if (!in_array('allergy_history', $keys, true)
        && (in_array('allergy_followup', $keys, true)
            || in_array('safety.drug_allergy', $keys, true))) {
        $keys[] = 'allergy_history';
    }
    if (!in_array('allergy_eval_dashboard', $keys, true)
        && (in_array('allergy_followup', $keys, true)
            || in_array('allergy_history', $keys, true)
            || in_array('allergy_report', $keys, true))) {
        $keys[] = 'allergy_eval_dashboard';
    }
    if (!in_array('smart_pharma.intervention_report', $keys, true)
        && (in_array('smart_pharma.interventions', $keys, true)
            || in_array('smart_pharma.opd', $keys, true)
            || in_array('smart_pharma.ipd', $keys, true))) {
        $keys[] = 'smart_pharma.intervention_report';
    }
    $role = strtolower(trim((string)($_SESSION['role'] ?? '')));
    $role_granted = in_array($role, ['pharmacist', 'pharmacy_technician', 'admin'], true);
    if (!$role_granted && isset($_SESSION['af_alert_role_access']) && is_array($_SESSION['af_alert_role_access'])) {
        $role_granted = !empty($_SESSION['af_alert_role_access'][$role]);
    }
    if ($role_granted
        && !in_array('allergy_alert_settings', $keys, true)
        && (in_array('allergy_followup', $keys, true) || in_array('allergy_report', $keys, true))) {
        $keys[] = 'allergy_alert_settings';
    }
    if ((in_array('admin.invc', $keys, true) || in_array($role, ['pharmacist', 'pharmacy_technician', 'admin'], true))
        && !in_array('invc.stock', $keys, true)) {
        $keys[] = 'invc.stock';
    }
    return $keys;
}

function tham_menu_sync_invc_stock_permission($con) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    tham_menu_ensure_tables($con);
    $roles = ['pharmacist', 'pharmacy_technician'];
    $q = mysqli_query($con, "SELECT DISTINCT role FROM role_menu_permissions WHERE menu_key = 'admin.invc'");
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $role = (string)($row['role'] ?? '');
            if ($role !== '' && !in_array($role, $roles, true)) {
                $roles[] = $role;
            }
        }
    }
    foreach ($roles as $role) {
        $role_esc = mysqli_real_escape_string($con, $role);
        if ($role_esc === '') {
            continue;
        }
        $has_any = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role_esc' LIMIT 1");
        if (!$has_any || mysqli_num_rows($has_any) === 0) {
            continue;
        }
        $chk = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role_esc' AND menu_key='invc.stock' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) === 0) {
            mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role_esc', 'invc.stock')");
        }
    }
}

function tham_menu_load_session_permissions($con, $user_id, $role) {
    $allowed = tham_menu_resolve_allowed_keys($con, $user_id, $role);
    $_SESSION['allowed_menus'] = $allowed;
    $_SESSION['menu_permissions_loaded'] = true;
    $_SESSION['use_custom_menus'] = tham_menu_user_uses_custom($con, $user_id) ? 1 : 0;
}

function tham_menu_can($menu_key) {
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    if (($_SESSION['role'] ?? '') === 'admin') {
        return true;
    }
    $allowed = $_SESSION['allowed_menus'] ?? null;
    if ($allowed === null) {
        return true;
    }
    $allowed = tham_menu_expand_report_aliases($allowed);
    $_SESSION['allowed_menus'] = $allowed;
    return in_array($menu_key, $allowed, true);
}

/**
 * sync สิทธิ์พื้นฐาน/รายงานที่ขาดใน DB
 * - home ให้ทุก role / ทุกคนที่ถูกกำหนดเมนูรายคน
 * - report.postal_drug / report.smc_clinic ให้ผู้ที่มีรายงานการใช้แยกหมวดอยู่แล้ว
 */
function tham_menu_sync_postal_drug_permission($con) {
    tham_menu_ensure_tables($con);

    // เติม home + หน้าดาวน์โหลด Agent ให้ role / ผู้ใช้ที่มีเมนูอย่างน้อย 1 รายการ
    $base_keys = ['home', 'agent.download'];
    $roles = mysqli_query($con, "SELECT DISTINCT role FROM role_menu_permissions");
    if ($roles) {
        while ($row = mysqli_fetch_assoc($roles)) {
            $role = mysqli_real_escape_string($con, $row['role'] ?? '');
            if ($role === '') {
                continue;
            }
            foreach ($base_keys as $base_key) {
                $mk = mysqli_real_escape_string($con, $base_key);
                $chk = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role' AND menu_key='$mk' LIMIT 1");
                if ($chk && mysqli_num_rows($chk) === 0) {
                    mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role', '$mk')");
                }
            }
        }
    }
    $users = mysqli_query($con, "SELECT DISTINCT user_id FROM user_menu_permissions");
    if ($users) {
        while ($row = mysqli_fetch_assoc($users)) {
            $uid = (int)($row['user_id'] ?? 0);
            if ($uid <= 0) {
                continue;
            }
            foreach ($base_keys as $base_key) {
                $mk = mysqli_real_escape_string($con, $base_key);
                $chk = mysqli_query($con, "SELECT 1 FROM user_menu_permissions WHERE user_id=$uid AND menu_key='$mk' LIMIT 1");
                if ($chk && mysqli_num_rows($chk) === 0) {
                    mysqli_query($con, "INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ($uid, '$mk')");
                }
            }
        }
    }

    $extra_keys = ['report.postal_drug', 'report.smc_clinic'];
    $q = mysqli_query($con, "SELECT DISTINCT role FROM role_menu_permissions WHERE menu_key = 'rational_lab.report'");
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $role = mysqli_real_escape_string($con, $row['role'] ?? '');
            if ($role === '') {
                continue;
            }
            foreach ($extra_keys as $menu_key) {
                $mk = mysqli_real_escape_string($con, $menu_key);
                $chk = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role' AND menu_key='$mk' LIMIT 1");
                if ($chk && mysqli_num_rows($chk) > 0) {
                    continue;
                }
                mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role', '$mk')");
            }
        }
    }
    $uq = mysqli_query($con, "SELECT DISTINCT user_id FROM user_menu_permissions WHERE menu_key = 'rational_lab.report'");
    if (!$uq) {
        return;
    }
    while ($row = mysqli_fetch_assoc($uq)) {
        $uid = (int)($row['user_id'] ?? 0);
        if ($uid <= 0) {
            continue;
        }
        foreach ($extra_keys as $menu_key) {
            $mk = mysqli_real_escape_string($con, $menu_key);
            $chk = mysqli_query($con, "SELECT 1 FROM user_menu_permissions WHERE user_id=$uid AND menu_key='$mk' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) > 0) {
                continue;
            }
            mysqli_query($con, "INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ($uid, '$mk')");
        }
    }
}

function tham_menu_sync_patient_opd_permission($con) {
    tham_menu_ensure_tables($con);
    $src_keys = "'pharm_care.smart_lab','pharm_care.smart_drug'";
    $dst = 'pharm_care.patient_opd';
    $dst_esc = mysqli_real_escape_string($con, $dst);
    $q = mysqli_query($con, "SELECT DISTINCT role FROM role_menu_permissions WHERE menu_key IN ($src_keys)");
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $role = mysqli_real_escape_string($con, $row['role'] ?? '');
            if ($role === '') {
                continue;
            }
            $chk = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role' AND menu_key='$dst_esc' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) === 0) {
                mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role', '$dst_esc')");
            }
        }
    }
    $uq = mysqli_query($con, "SELECT DISTINCT user_id FROM user_menu_permissions WHERE menu_key IN ($src_keys)");
    if ($uq) {
        while ($row = mysqli_fetch_assoc($uq)) {
            $uid = (int)($row['user_id'] ?? 0);
            if ($uid <= 0) {
                continue;
            }
            $chk = mysqli_query($con, "SELECT 1 FROM user_menu_permissions WHERE user_id=$uid AND menu_key='$dst_esc' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) === 0) {
                mysqli_query($con, "INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ($uid, '$dst_esc')");
            }
        }
    }
}

function tham_menu_sync_patient_ipd_permission($con) {
    tham_menu_ensure_tables($con);
    $src_keys = "'pharm_care.patient_opd','pharm_care.smart_lab','pharm_care.smart_drug'";
    $dst = 'pharm_care.patient_ipd';
    $dst_esc = mysqli_real_escape_string($con, $dst);
    $q = mysqli_query($con, "SELECT DISTINCT role FROM role_menu_permissions WHERE menu_key IN ($src_keys)");
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $role = mysqli_real_escape_string($con, $row['role'] ?? '');
            if ($role === '') {
                continue;
            }
            $chk = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role' AND menu_key='$dst_esc' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) === 0) {
                mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role', '$dst_esc')");
            }
        }
    }
    $uq = mysqli_query($con, "SELECT DISTINCT user_id FROM user_menu_permissions WHERE menu_key IN ($src_keys)");
    if ($uq) {
        while ($row = mysqli_fetch_assoc($uq)) {
            $uid = (int)($row['user_id'] ?? 0);
            if ($uid <= 0) {
                continue;
            }
            $chk = mysqli_query($con, "SELECT 1 FROM user_menu_permissions WHERE user_id=$uid AND menu_key='$dst_esc' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) === 0) {
                mysqli_query($con, "INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ($uid, '$dst_esc')");
            }
        }
    }
}

function tham_menu_sync_med_error_report_permission($con) {
    tham_menu_ensure_tables($con);
    $src = 'pharm_care.med_error';
    $dst = 'pharm_care.med_error_report';
    $src_esc = mysqli_real_escape_string($con, $src);
    $dst_esc = mysqli_real_escape_string($con, $dst);
    $q = mysqli_query($con, "SELECT DISTINCT role FROM role_menu_permissions WHERE menu_key='$src_esc'");
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $role = mysqli_real_escape_string($con, $row['role'] ?? '');
            if ($role === '') {
                continue;
            }
            $chk = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role' AND menu_key='$dst_esc' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) === 0) {
                mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role', '$dst_esc')");
            }
        }
    }
    $uq = mysqli_query($con, "SELECT DISTINCT user_id FROM user_menu_permissions WHERE menu_key='$src_esc'");
    if ($uq) {
        while ($row = mysqli_fetch_assoc($uq)) {
            $uid = (int)($row['user_id'] ?? 0);
            if ($uid <= 0) {
                continue;
            }
            $chk = mysqli_query($con, "SELECT 1 FROM user_menu_permissions WHERE user_id=$uid AND menu_key='$dst_esc' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) === 0) {
                mysqli_query($con, "INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ($uid, '$dst_esc')");
            }
        }
    }
}

function tham_menu_sync_allergy_followup_permission($con) {
    tham_menu_ensure_tables($con);
    $roles = ['nurse', 'pharmacist', 'pharmacy_technician'];
    foreach ($roles as $role) {
        $role_esc = mysqli_real_escape_string($con, $role);
        $exists = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role_esc' LIMIT 1");
        if (!$exists || mysqli_num_rows($exists) === 0) {
            continue;
        }
        $chk = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role_esc' AND menu_key='allergy_followup' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) === 0) {
            mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role_esc', 'allergy_followup')");
        }
        $chkR = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role_esc' AND menu_key='allergy_report' LIMIT 1");
        if ($chkR && mysqli_num_rows($chkR) === 0) {
            mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role_esc', 'allergy_report')");
        }
        $chk2 = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role_esc' AND menu_key='allergy_history' LIMIT 1");
        if ($chk2 && mysqli_num_rows($chk2) === 0) {
            mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role_esc', 'allergy_history')");
        }
        $chkD = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role_esc' AND menu_key='allergy_eval_dashboard' LIMIT 1");
        if ($chkD && mysqli_num_rows($chkD) === 0) {
            mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role_esc', 'allergy_eval_dashboard')");
        }
        if (in_array($role, ['pharmacist', 'pharmacy_technician'], true)) {
            $chkA = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role_esc' AND menu_key='allergy_alert_settings' LIMIT 1");
            if ($chkA && mysqli_num_rows($chkA) === 0) {
                mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role_esc', 'allergy_alert_settings')");
            }
        }
    }
    $q = mysqli_query($con, "SELECT DISTINCT role FROM role_menu_permissions WHERE menu_key IN ('safety.drug_allergy','smart_pharma.settings','pharm_care.med_error')");
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $role = mysqli_real_escape_string($con, $row['role'] ?? '');
            if ($role === '') {
                continue;
            }
            $chk = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role' AND menu_key='allergy_followup' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) === 0) {
                mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role', 'allergy_followup')");
            }
            $chkR = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role' AND menu_key='allergy_report' LIMIT 1");
            if ($chkR && mysqli_num_rows($chkR) === 0) {
                mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role', 'allergy_report')");
            }
            $chk2 = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role' AND menu_key='allergy_history' LIMIT 1");
            if ($chk2 && mysqli_num_rows($chk2) === 0) {
                mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role', 'allergy_history')");
            }
            $chkD = mysqli_query($con, "SELECT 1 FROM role_menu_permissions WHERE role='$role' AND menu_key='allergy_eval_dashboard' LIMIT 1");
            if ($chkD && mysqli_num_rows($chkD) === 0) {
                mysqli_query($con, "INSERT INTO role_menu_permissions (role, menu_key) VALUES ('$role', 'allergy_eval_dashboard')");
            }
        }
    }
    $uq = mysqli_query($con, "SELECT DISTINCT user_id FROM user_menu_permissions WHERE menu_key IN ('safety.drug_allergy','smart_pharma.settings','pharm_care.med_error')");
    if ($uq) {
        while ($row = mysqli_fetch_assoc($uq)) {
            $uid = (int)($row['user_id'] ?? 0);
            if ($uid <= 0) {
                continue;
            }
            $chk = mysqli_query($con, "SELECT 1 FROM user_menu_permissions WHERE user_id=$uid AND menu_key='allergy_followup' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) === 0) {
                mysqli_query($con, "INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ($uid, 'allergy_followup')");
            }
            $chkR = mysqli_query($con, "SELECT 1 FROM user_menu_permissions WHERE user_id=$uid AND menu_key='allergy_report' LIMIT 1");
            if ($chkR && mysqli_num_rows($chkR) === 0) {
                mysqli_query($con, "INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ($uid, 'allergy_report')");
            }
            $chk2 = mysqli_query($con, "SELECT 1 FROM user_menu_permissions WHERE user_id=$uid AND menu_key='allergy_history' LIMIT 1");
            if ($chk2 && mysqli_num_rows($chk2) === 0) {
                mysqli_query($con, "INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ($uid, 'allergy_history')");
            }
            $chkD = mysqli_query($con, "SELECT 1 FROM user_menu_permissions WHERE user_id=$uid AND menu_key='allergy_eval_dashboard' LIMIT 1");
            if ($chkD && mysqli_num_rows($chkD) === 0) {
                mysqli_query($con, "INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ($uid, 'allergy_eval_dashboard')");
            }
        }
    }
    $uqA = mysqli_query($con, "SELECT DISTINCT u.id
        FROM users u
        INNER JOIN user_menu_permissions um ON um.user_id = u.id
        WHERE u.role IN ('pharmacist','pharmacy_technician')
          AND um.menu_key IN ('allergy_followup','allergy_report')");
    if ($uqA) {
        while ($row = mysqli_fetch_assoc($uqA)) {
            $uid = (int)($row['id'] ?? 0);
            if ($uid <= 0) {
                continue;
            }
            $chkA = mysqli_query($con, "SELECT 1 FROM user_menu_permissions WHERE user_id=$uid AND menu_key='allergy_alert_settings' LIMIT 1");
            if ($chkA && mysqli_num_rows($chkA) === 0) {
                mysqli_query($con, "INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ($uid, 'allergy_alert_settings')");
            }
        }
    }
}

function tham_menu_group_visible($group_key) {
    $registry = tham_menu_registry();
    if (!isset($registry[$group_key]['children'])) {
        return tham_menu_can($group_key);
    }
    foreach ($registry[$group_key]['children'] as $childKey => $child) {
        if (tham_menu_can($childKey)) {
            return true;
        }
    }
    return false;
}

function tham_menu_ensure_page_access($page) {
    if (!isset($_SESSION['user_id'])) {
        return;
    }
    // หน้าหลัก/auth เข้าได้เสมอเมื่อล็อกอินแล้ว
    $skip = ['login.php', 'logout.php', 'index.php', 'home.php', 'oauth_callback.php', 'alert_agent.php', 'alert_agent_file.php', 'cron_tham_alert.php'];
    if (in_array($page, $skip, true)) {
        return;
    }
    if (($_SESSION['role'] ?? '') === 'admin') {
        return;
    }
    if ($page === 'smart_pharma_intervention_consult_print.php') {
        foreach ((array)($_SESSION['allowed_menus'] ?? []) as $menu_key) {
            if (strpos((string)$menu_key, 'safety.') === 0) {
                return;
            }
        }
    }
    $map = tham_menu_page_map();
    if (!isset($map[$page])) {
        return;
    }
    $menu_key = $map[$page];
    if (!tham_menu_can($menu_key)) {
        if (!headers_sent()) {
            header('Content-Type: text/html; charset=utf-8');
        }
        echo '<!DOCTYPE html><html lang="th"><head><meta charset="UTF-8"><title>ไม่มีสิทธิ์</title></head><body style="font-family:Tahoma,sans-serif;padding:40px;text-align:center;">';
        echo '<h3>ไม่มีสิทธิ์เข้าถึงหน้านี้</h3>';
        echo '<p>กรุณาติดต่อผู้ดูแลระบบเพื่อขอสิทธิ์เมนู</p>';
        echo '<a href="home.php">กลับหน้าหลัก</a></body></html>';
        exit;
    }
}

function tham_menu_save_role_permissions($con, $role, array $menu_keys) {
    tham_menu_ensure_tables($con);
    $role = mysqli_real_escape_string($con, $role);
    $valid = array_flip(tham_menu_all_keys());
    $values = [];
    $seen = [];
    foreach ($menu_keys as $key) {
        $key = trim((string)$key);
        if ($key === '' || !isset($valid[$key]) || isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $k = mysqli_real_escape_string($con, $key);
        $values[] = "('$role', '$k')";
    }
    mysqli_begin_transaction($con);
    if (!mysqli_query($con, "DELETE FROM role_menu_permissions WHERE role = '$role'")) {
        mysqli_rollback($con);
        return false;
    }
    if (!empty($values)) {
        $sql = 'INSERT INTO role_menu_permissions (role, menu_key) VALUES ' . implode(',', $values);
        if (!mysqli_query($con, $sql)) {
            mysqli_rollback($con);
            return false;
        }
    }
    mysqli_commit($con);
    tham_menu_follow_role_if_snapshot($con, $role);
    return true;
}

/**
 * คนที่เคยถูกบันทึกสิทธิ์รายคนเป็นสำเนาของตำแหน่ง (ไม่มีเมนูเกินกว่ากลุ่ม)
 * และยังใกล้เคียงชุดปัจจุบัน ให้กลับไปใช้ตาม Role
 * คนที่ถูกตัดเมนูไว้ชัดเจนยังคงสิทธิ์เฉพาะรายคน
 */
function tham_menu_follow_role_if_snapshot($con, $role) {
    tham_menu_ensure_tables($con);
    $roleKeys = tham_menu_fetch_role_permissions($con, $role);
    $nRole = count($roleKeys);
    if ($nRole === 0) {
        return;
    }
    $roleSet = array_flip($roleKeys);
    $roleEsc = mysqli_real_escape_string($con, $role);
    $q = mysqli_query($con, "SELECT id FROM users WHERE role = '$roleEsc' AND use_custom_menus = 1");
    if (!$q) {
        return;
    }
    while ($u = mysqli_fetch_assoc($q)) {
        $uid = (int)$u['id'];
        $keys = tham_menu_fetch_user_permissions($con, $uid);
        if (!$keys) {
            continue;
        }
        $extra = false;
        foreach ($keys as $key) {
            if (!isset($roleSet[$key])) {
                $extra = true;
                break;
            }
        }
        if ($extra || count($keys) < $nRole - 8) {
            continue;
        }
        mysqli_query($con, "DELETE FROM user_menu_permissions WHERE user_id = $uid");
        mysqli_query($con, "UPDATE users SET use_custom_menus = 0 WHERE id = $uid");
    }
}

function tham_menu_save_user_permissions($con, $user_id, $use_custom, array $menu_keys) {
    tham_menu_ensure_tables($con);
    $user_id = (int)$user_id;
    $use_custom = $use_custom ? 1 : 0;
    mysqli_begin_transaction($con);
    if (!mysqli_query($con, "UPDATE users SET use_custom_menus = $use_custom WHERE id = $user_id")) {
        mysqli_rollback($con);
        return false;
    }
    if (!mysqli_query($con, "DELETE FROM user_menu_permissions WHERE user_id = $user_id")) {
        mysqli_rollback($con);
        return false;
    }
    if ($use_custom) {
        $valid = array_flip(tham_menu_all_keys());
        $values = [];
        $seen = [];
        foreach ($menu_keys as $key) {
            $key = trim((string)$key);
            if ($key === '' || !isset($valid[$key]) || isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $k = mysqli_real_escape_string($con, $key);
            $values[] = "($user_id, '$k')";
        }
        if (!empty($values)) {
            $sql = 'INSERT INTO user_menu_permissions (user_id, menu_key) VALUES ' . implode(',', $values);
            if (!mysqli_query($con, $sql)) {
                mysqli_rollback($con);
                return false;
            }
        }
    }
    mysqli_commit($con);
    return true;
}
