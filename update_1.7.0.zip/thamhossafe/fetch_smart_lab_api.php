<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

set_time_limit(180);
include('connect.php');
require_once __DIR__ . '/smart_lab_helper.php';
mysqli_set_charset($con, 'utf8');
session_write_close();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST ?: [];
}

$hn = isset($input['hn']) ? trim((string)$input['hn']) : '';
if ($hn === '') {
    echo smart_lab_json(['status' => 'error', 'message' => 'กรุณาระบุ HN']);
    exit;
}
if (is_numeric($hn) && strlen($hn) < 9) {
    $hn = str_pad($hn, 9, '0', STR_PAD_LEFT);
}

$months = hds_lookback_months($input['months'] ?? 12, 12);
$include_network = !isset($input['include_network']) || $input['include_network'] === true
    || $input['include_network'] === 1 || $input['include_network'] === '1';

// เชื่อม HOSxP
$config = [];
$q_conf = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ('h_host','h_user','h_pass','h_db')");
if ($q_conf) {
    while ($r = mysqli_fetch_assoc($q_conf)) {
        $config[$r['config_name']] = $r['config_value'];
    }
}
mysqli_report(MYSQLI_REPORT_OFF);
$hos_con = mysqli_init();
mysqli_options($hos_con, MYSQLI_OPT_CONNECT_TIMEOUT, 3);
$ok = @mysqli_real_connect(
    $hos_con,
    $config['h_host'] ?? '',
    $config['h_user'] ?? '',
    $config['h_pass'] ?? '',
    $config['h_db'] ?? 'hos'
);
if (!$ok || !$hos_con) {
    echo smart_lab_json(['status' => 'error', 'message' => 'เชื่อมต่อ HOSxP ไม่ได้']);
    exit;
}
mysqli_set_charset($hos_con, 'utf8');

try {
    $payload = smart_lab_fetch_bundle($hos_con, $con, $hn, $months, $include_network);
    echo smart_lab_json($payload);
} catch (Throwable $e) {
    echo smart_lab_json(['status' => 'error', 'message' => 'ดึงข้อมูลไม่สำเร็จ: ' . $e->getMessage()]);
}
@mysqli_close($hos_con);
