<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('hosxp_tmt_drug_helper.php');
include('monitor_home_med_helper.php');
mysqli_set_charset($con, 'utf8');

mhm_ensure_tables($con);

$default_start = date('Y-m-d', strtotime('-3 days'));
$default_end = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_config') {
    $ok = mhm_save_config($con, [
        'lookback_days' => $_POST['lookback_days'] ?? 90,
        'match_mode' => $_POST['match_mode'] ?? 'icode_or_tmt',
        'min_remaining_days' => $_POST['min_remaining_days'] ?? 1,
        'include_unknown_remaining' => isset($_POST['include_unknown_remaining']) ? 1 : 0,
        'exclude_prn' => isset($_POST['exclude_prn']) ? 1 : 0,
        'alert_level_remaining' => $_POST['alert_level_remaining'] ?? 'soft',
        'alert_level_unknown' => $_POST['alert_level_unknown'] ?? 'soft',
        'exclude_icodes' => $_POST['exclude_icodes'] ?? '',
        'monitor_active' => isset($_POST['monitor_active']) ? 1 : 0,
        'hide_low_remaining' => isset($_POST['hide_low_remaining']) ? 1 : 0,
        'hide_low_remaining_days' => $_POST['hide_low_remaining_days'] ?? 20,
        'hide_short_hme' => isset($_POST['hide_short_hme']) ? 1 : 0,
        'hide_short_hme_days' => $_POST['hide_short_hme_days'] ?? 14,
        'unitprice_exception' => $_POST['unitprice_exception'] ?? 100,
    ]);
    if ($ok && is_file(__DIR__ . '/smart_pharma_alert_log_helper.php')) {
        require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
        if (function_exists('sp_monitor_settings_changed')) {
            sp_monitor_settings_changed($con, 'home_med');
        }
    }
    $_SESSION['mhm_msg'] = $ok ? 'บันทึกการตั้งค่า Monitor ยากลับบ้าน IPD เรียบร้อย' : ('บันทึกไม่สำเร็จ: ' . mysqli_error($con));
    header('Location: monitor_home_med.php?tab=settings');
    exit;
}

$config = mhm_get_config($con);
$tab = (isset($_GET['tab']) && $_GET['tab'] === 'settings') ? 'settings' : 'monitor';
$flash_msg = $_SESSION['mhm_msg'] ?? '';
$flash_err = $_SESSION['mhm_error'] ?? '';
unset($_SESSION['mhm_msg'], $_SESSION['mhm_error']);
session_write_close();

$exclude_text = implode("\n", $config['exclude_icodes']);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor ยากลับบ้าน IPD - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .section-hard .table thead { background-color: #dc3545 !important; color: #fff !important; }
        .section-soft .table thead { background-color: #fd7e14 !important; color: #fff !important; }
        .mhm-range-btn.active { background-color: #c2410c !important; border-color: #c2410c !important; color: #fff !important; }
        .mhm-dup { background: #fff7ed; border-left: 3px solid #ea580c; padding: 4px 8px; border-radius: 4px; }
        .mhm-remain { font-weight: 700; color: #b91c1c; }
        .mhm-appt-days { font-weight: 700; color: #0369a1; }
        .mhm-appt-list { display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
        .mhm-appt-list .badge { font-weight: 600; white-space: normal; text-align: left; }
        .mhm-patient { border: 1px solid #e5e7eb; border-radius: 10px; margin-bottom: 12px; overflow: hidden; background: #fff; }
        .mhm-patient.has-prior { border-color: #fdba74; }
        .mhm-pt-head { display: flex; flex-wrap: wrap; gap: 8px 16px; align-items: center; padding: 10px 14px; background: #fff7ed; border-bottom: 1px solid #fed7aa; }
        .mhm-patient:not(.has-prior) .mhm-pt-head { background: #f8fafc; border-bottom-color: #e2e8f0; }
        .mhm-pt-hn { font-size: 1.05rem; color: #9a3412; }
        .mhm-prior-mark { display: inline-flex; align-items: center; gap: 4px; background: #ea580c; color: #fff; font-weight: 700; font-size: 0.75rem; padding: 2px 8px; border-radius: 999px; }
        .mhm-prior-hme { display: inline-flex; align-items: center; gap: 4px; background: #4f46e5; color: #fff; font-weight: 700; font-size: 0.75rem; padding: 2px 8px; border-radius: 999px; }
        .mhm-drug-table { margin: 0; }
        .mhm-drug-table th { font-size: 0.75rem; background: #f1f5f9; }
        .mhm-drug-row.prior td { background: #fff7ed; }
        .mhm-alert-card { border: 2px solid #e2e8f0; border-radius: 10px; padding: 0.7rem 0.85rem; cursor: pointer; height: 100%; }
        .mhm-alert-card.active-soft { border-color: #ca8a04; background: #fffbeb; }
        .mhm-alert-card.active-hard { border-color: #dc2626; background: #fef2f2; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-2 text-dark">
                <i class="fas fa-home me-2" style="color:#c2410c;"></i>
                Monitor ยากลับบ้าน IPD <span class="badge bg-secondary">HME</span>
            </h4>
            <p class="text-muted small mb-4">
                ตรวจคนไข้ <b>IPD ที่มียาประเภท HME</b> เทียบกับยาที่ได้จาก <b>OPD ก่อน admit</b>
                และ <b>HME จาก IPD ครั้งก่อน</b> ที่ admit ใหม่เกิดก่อนวันนัด และยาเดิมยังเหลือ
                — จัดกลุ่มราย HN แสดงยา HME ทั้งหมด และติดสัญลักษณ์รายการที่เคยได้ก่อน admit
            </p>

            <?php if ($flash_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo htmlspecialchars($flash_msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            <?php if ($flash_err): ?>
            <div class="alert alert-danger alert-dismissible fade show"><?php echo htmlspecialchars($flash_err); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <ul class="nav nav-tabs fw-bold" role="tablist">
                <li class="nav-item">
                    <button class="nav-link <?php echo $tab === 'monitor' ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#monitor" type="button">
                        <i class="fas fa-desktop me-1"></i> รายการเฝ้าระวัง
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link <?php echo $tab === 'settings' ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#settings" type="button">
                        <i class="fas fa-cogs me-1"></i> ตั้งค่า
                    </button>
                </li>
            </ul>

            <div class="tab-content bg-white border border-top-0 p-4 rounded-bottom shadow-sm">
                <div class="tab-pane fade <?php echo $tab === 'monitor' ? 'show active' : ''; ?>" id="monitor">
                    <div class="filter-box p-3 mb-3">
                        <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-filter me-2"></i>วันที่สั่งยา HME</h6>
                        <div class="row g-2 align-items-end">
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ตั้งแต่</label>
                                <input type="text" id="filter_start" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_start); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ถึงวันที่</label>
                                <input type="text" id="filter_end" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_end); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">HN (ไม่บังคับ)</label>
                                <input type="text" id="filter_hn" class="form-control form-control-sm bg-white" placeholder="ทุก HN" autocomplete="off">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-sm fw-bold text-white w-100 shadow-sm" style="background:#c2410c;" id="btnFetchMHM" onclick="fetchMHMData()">
                                    <i class="fas fa-sync-alt me-1"></i> ประมวลผล
                                </button>
                            </div>
                        </div>
                        <div class="row g-2 mt-2 align-items-center">
                            <div class="col-auto"><label class="form-label small fw-bold mb-0 text-secondary">ช่วงเร็ว:</label></div>
                            <div class="col">
                                <div class="btn-group btn-group-sm flex-wrap">
                                    <button type="button" class="btn btn-outline-secondary fw-bold mhm-range-btn" data-days="1" onclick="setMHMDateRange(1)">วันนี้</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mhm-range-btn active" data-days="3" onclick="setMHMDateRange(3)">3 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mhm-range-btn" data-days="7" onclick="setMHMDateRange(7)">7 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mhm-range-btn" data-days="30" onclick="setMHMDateRange(30)">30 วัน</button>
                                </div>
                            </div>
                        </div>
                        <div id="hnFocusBanner" class="alert alert-warning py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                        <div id="reportMeta" class="alert alert-info py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                    </div>

                    <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
                        <span class="small fw-bold text-muted me-1">แสดง:</span>
                        <div class="btn-group btn-group-sm" role="group">
                            <button type="button" class="btn btn-outline-secondary active fw-bold" data-mhm-filter="all" onclick="setMHMFilter('all', this)">ทั้งหมด <span id="mhmCountAll" class="badge bg-secondary">0</span></button>
                            <button type="button" class="btn btn-outline-warning fw-bold" data-mhm-filter="prior" onclick="setMHMFilter('prior', this)">เคยได้ก่อน admit <span id="mhmCountPrior" class="badge bg-warning text-dark">0</span></button>
                            <button type="button" class="btn btn-outline-danger fw-bold" data-mhm-filter="hard" onclick="setMHMFilter('hard', this)">Hard Alert <span id="mhmCountHard" class="badge bg-danger">0</span></button>
                            <button type="button" class="btn btn-outline-warning fw-bold" data-mhm-filter="soft" onclick="setMHMFilter('soft', this)">Soft Alert <span id="mhmCountSoft" class="badge bg-warning text-dark">0</span></button>
                        </div>
                        <div class="mhm-legend small text-muted ms-2">
                            <span class="mhm-prior-mark"><i class="fas fa-history"></i> เคยได้ OPD</span>
                            = จ่ายจาก OPD ก่อนวัน admit
                            · <span class="mhm-prior-hme"><i class="fas fa-procedures"></i> เคยได้ HME IPD</span>
                            = HME จาก IPD ครั้งก่อน และ admit ใหม่เกิดก่อนวันนัด
                            · คอลัมน์ <b>ถึงวันนัด</b> = จำนวนวันหลังจากวันที่ได้ HME ถึงแต่ละวันนัดข้างหน้า (ดึงทุกนัด)
                        </div>
                    </div>
                    <div id="mhmPatients">
                        <div class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</div>
                    </div>
                </div>

                <div class="tab-pane fade <?php echo $tab === 'settings' ? 'show active' : ''; ?>" id="settings">
                    <form method="post" class="row g-4">
                        <input type="hidden" name="action" value="save_config">
                        <div class="col-lg-7">
                            <div class="card shadow-sm border-0">
                                <div class="card-header text-white fw-bold" style="background:#c2410c;">
                                    <i class="fas fa-sliders-h me-1"></i> เกณฑ์ตรวจยาซ้ำ HME
                                </div>
                                <div class="card-body">
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" name="monitor_active" id="mhm_active" <?php echo !empty($config['monitor_active']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label fw-bold" for="mhm_active">เปิดใช้งาน Monitor</label>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">ย้อนหลังดูยาก่อน admit (วัน)</label>
                                        <input type="number" name="lookback_days" class="form-control form-control-sm" min="7" max="365" value="<?php echo (int)$config['lookback_days']; ?>">
                                        <div class="form-text">เช่น 90 = ดูใบยา OPD และ HME จาก IPD ครั้งก่อน ภายใน 90 วันก่อนวัน admit</div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">วิธีจับคู่ยา</label>
                                        <select name="match_mode" class="form-select form-select-sm">
                                            <option value="icode_or_tmt" <?php echo $config['match_mode'] === 'icode_or_tmt' ? 'selected' : ''; ?>>icode เดียวกัน หรือชื่อ TMT (ตัวยา+ความแรง) เดียวกัน</option>
                                            <option value="icode" <?php echo $config['match_mode'] === 'icode' ? 'selected' : ''; ?>>เฉพาะ icode เดียวกัน</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">แจ้งเตือนเมื่อยาเดิมเหลืออย่างน้อย (วัน)</label>
                                        <input type="number" name="min_remaining_days" class="form-control form-control-sm" min="0" max="180" value="<?php echo (int)$config['min_remaining_days']; ?>">
                                        <div class="form-text">คำนวณจากจำนวนจ่ายเดิม ÷ ปริมาณต่อวัน ตามวิธีใช้ แล้วหักจำนวนวันถึงวัน admit</div>
                                    </div>
                                    <?php
                                    $lvl_rem = mhm_normalize_alert_level($config['alert_level_remaining'] ?? 'soft');
                                    $lvl_unk = mhm_normalize_alert_level($config['alert_level_unknown'] ?? 'soft');
                                    ?>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">ระดับเมื่อมียาเหลือ ณ วัน admit <span class="text-muted fw-normal">(ค่าเริ่มต้น Soft Alert)</span></label>
                                        <div class="row g-2">
                                            <div class="col-6">
                                                <label class="mhm-alert-card d-block <?php echo $lvl_rem !== 'hard' ? 'active-soft' : ''; ?>">
                                                    <div class="form-check mb-0">
                                                        <input class="form-check-input" type="radio" name="alert_level_remaining" id="mhm_rem_soft" value="soft" <?php echo $lvl_rem !== 'hard' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label small" for="mhm_rem_soft">
                                                            <span class="badge bg-warning text-dark">Soft Alert</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-text small mb-0">เตือนสีเหลือง ไม่บล็อก</div>
                                                </label>
                                            </div>
                                            <div class="col-6">
                                                <label class="mhm-alert-card d-block <?php echo $lvl_rem === 'hard' ? 'active-hard' : ''; ?>">
                                                    <div class="form-check mb-0">
                                                        <input class="form-check-input" type="radio" name="alert_level_remaining" id="mhm_rem_hard" value="hard" <?php echo $lvl_rem === 'hard' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label small" for="mhm_rem_hard">
                                                            <span class="badge bg-danger">Hard Alert</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-text small mb-0">เตือนระดับสูง สีแดง</div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">ระดับเมื่อคำนวณวันที่เหลือไม่ได้ <span class="text-muted fw-normal">(ค่าเริ่มต้น Soft Alert)</span></label>
                                        <div class="row g-2">
                                            <div class="col-6">
                                                <label class="mhm-alert-card d-block <?php echo $lvl_unk !== 'hard' ? 'active-soft' : ''; ?>">
                                                    <div class="form-check mb-0">
                                                        <input class="form-check-input" type="radio" name="alert_level_unknown" id="mhm_unk_soft" value="soft" <?php echo $lvl_unk !== 'hard' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label small" for="mhm_unk_soft">
                                                            <span class="badge bg-warning text-dark">Soft Alert</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-text small mb-0">เตือนสีเหลือง ไม่บล็อก</div>
                                                </label>
                                            </div>
                                            <div class="col-6">
                                                <label class="mhm-alert-card d-block <?php echo $lvl_unk === 'hard' ? 'active-hard' : ''; ?>">
                                                    <div class="form-check mb-0">
                                                        <input class="form-check-input" type="radio" name="alert_level_unknown" id="mhm_unk_hard" value="hard" <?php echo $lvl_unk === 'hard' ? 'checked' : ''; ?>>
                                                        <label class="form-check-label small" for="mhm_unk_hard">
                                                            <span class="badge bg-danger">Hard Alert</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-text small mb-0">เตือนระดับสูง สีแดง</div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" name="include_unknown_remaining" id="mhm_unk" <?php echo !empty($config['include_unknown_remaining']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small" for="mhm_unk">แจ้งเตือนแม้คำนวณวันที่เหลือไม่ได้ (วิธีใช้ PRN / ไม่ชัด)</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="checkbox" name="exclude_prn" id="mhm_prn" <?php echo !empty($config['exclude_prn']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small" for="mhm_prn">ข้ามยาเดิมที่วิธีใช้เป็น PRN / ตามอาการ</label>
                                    </div>
                                    <hr class="my-3">
                                    <div class="fw-bold small mb-2">ตัดยาเดิมที่เหลือ ณ วัน admit น้อยเกินไป</div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" name="hide_low_remaining" id="mhm_hide_low" <?php echo !empty($config['hide_low_remaining']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small" for="mhm_hide_low">ไม่นับยาเดิมที่เหลือ ณ admit <strong>น้อยกว่าเกณฑ์</strong> และไม่ดึงเคสถ้าไม่มียาเดิมเหลือพอ</label>
                                    </div>
                                    <div class="row g-2 mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label small fw-bold">เกณฑ์วันที่เหลือ ณ admit (วัน)</label>
                                            <input type="number" name="hide_low_remaining_days" class="form-control form-control-sm" min="0" max="365" value="<?php echo (int)$config['hide_low_remaining_days']; ?>">
                                            <div class="form-text">ค่าเริ่มต้น 20 วัน — เช่น เหลือ 1 วัน จะไม่ขึ้นว่าเคยได้ก่อน admit</div>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label small fw-bold">มูลค่ายาเดิมที่เหลือต่อใบสั่งไม่น้อยกว่า (บาท)</label>
                                            <input type="number" name="unitprice_exception" class="form-control form-control-sm" min="0" step="0.01" value="<?php echo htmlspecialchars(number_format((float)$config['unitprice_exception'], 2, '.', '')); ?>">
                                            <div class="form-text">ค่าเริ่มต้น 100 บาท — ดึงเมื่อยาเดิมที่ยังเหลือของใบสั่งเดียวกัน รวมกันไม่น้อยกว่านี้ ตั้ง 0 = ดึงทุกใบ</div>
                                        </div>
                                    </div>
                                    <div class="fw-bold small mb-2">ตัดรายการที่สั่ง HME จำนวนวันน้อย</div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" name="hide_short_hme" id="mhm_hide_short" <?php echo !empty($config['hide_short_hme']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small" for="mhm_hide_short">ซ่อนรายการที่จำนวนวัน HME <strong>น้อยกว่าเกณฑ์</strong></label>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">เกณฑ์จำนวนวัน HME (วัน)</label>
                                        <input type="number" name="hide_short_hme_days" class="form-control form-control-sm" min="0" max="365" value="<?php echo (int)$config['hide_short_hme_days']; ?>">
                                        <div class="form-text">ค่าเริ่มต้น 14 วัน — คำนวณจากจำนวนจ่าย HME ÷ ปริมาณต่อวัน ถ้าคำนวณไม่ได้ใช้จำนวนวันถึงวันนัด</div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">icode ที่ไม่ต้องตรวจ (หนึ่งบรรทัดต่อรายการ)</label>
                                        <textarea name="exclude_icodes" class="form-control form-control-sm" rows="4" placeholder="เช่น ยาฉีด / ยา PRN ที่ไม่เกี่ยวกับยากลับบ้าน"><?php echo htmlspecialchars($exclude_text); ?></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-sm text-white fw-bold" style="background:#c2410c;">
                                        <i class="fas fa-save me-1"></i> บันทึกการตั้งค่า
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="alert alert-light border small">
                                <div class="fw-bold mb-2"><i class="fas fa-info-circle me-1 text-warning"></i> เงื่อนไขการตรวจ</div>
                                <ol class="mb-0 ps-3">
                                    <li>คนไข้เป็น <b>IPD</b> และมีใบยาประเภท <b>HME</b> (ยากลับบ้าน)</li>
                                    <li>ดึงยา OPD ของ HN เดียวกัน ที่จ่าย <b>ก่อนหรือในวัน admit</b> ภายในช่วงย้อนหลังที่ตั้ง</li>
                                    <li>ดึงยา HME จาก <b>IPD ครั้งก่อน</b> (คนละ AN) เมื่อ admit ครั้งนี้อยู่ก่อนวันนัดที่จองไว้ตั้งแต่ครั้งก่อน และวันนัดนั้นอยู่หลังวันที่ได้ HME ครั้งก่อน</li>
                                    <li>จับคู่ยาซ้ำด้วย icode หรือชื่อ TMT</li>
                                    <li>ถ้ายาเดิมยังเหลือ ณ วัน admit จะแจ้งเตือนเพื่อไม่ให้จ่าย HME ซ้ำ</li>
                                    <li>ไม่ดึงรายการที่ยาเหลือ ณ admit <b>ติดลบ</b> หรือ <b>คำนวณประวัติ/วิธีใช้ไม่ได้</b></li>
                                    <li>ไม่ดึงคนไข้ที่ยา HME <b>ทั้งหมดไม่พบใน OPD หรือ HME IPD ก่อน admit</b></li>
                                    <li>ดึงเมื่อมูลค่า<b>ยาเดิมที่เหลือ</b>ของใบสั่งเดียวกัน (จำนวนที่เหลือ × ราคา) รวมกัน <b>ไม่น้อยกว่า</b>ที่ตั้ง (ค่าเริ่มต้น 100 บาท) ตั้ง 0 = ดึงทุกใบ</li>
                                    <li>ตัดยาเดิมที่เหลือ ณ admit <b>น้อยกว่าเกณฑ์</b> (ค่าเริ่มต้น 20 วัน) ไม่นับว่าเคยได้ก่อน admit</li>
                                    <li>ตัดรายการที่สั่ง HME <b>น้อยกว่าเกณฑ์วัน</b> (ค่าเริ่มต้น 14 วัน)</li>
                                    <li>ระดับเตือนค่าเริ่มต้นเป็น <b>Soft Alert</b> ทั้งกรณีมียาเหลือและคำนวณวันที่เหลือไม่ได้ — เปลี่ยนเป็น Hard ได้ที่การ์ดด้านซ้าย</li>
                                </ol>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/monitor_hn_filter.js"></script>
<script src="js/flatpickr.min.js"></script>
<script>
let fpStart, fpEnd;

function mhmEsc(s) {
    if (s == null) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

$(function() {
    if (typeof flatpickr !== 'undefined') {
        fpStart = flatpickr('#filter_start', { dateFormat: 'Y-m-d' });
        fpEnd = flatpickr('#filter_end', { dateFormat: 'Y-m-d' });
    }
    $(document).on('change', 'input[name="alert_level_remaining"], input[name="alert_level_unknown"]', function() {
        const wrap = $(this).closest('.row');
        wrap.find('.mhm-alert-card').removeClass('active-soft active-hard');
        $(this).closest('.mhm-alert-card').addClass(this.value === 'hard' ? 'active-hard' : 'active-soft');
    });
    monitorInitHnFilter({
        clearHref: 'monitor_home_med.php',
        fetchFn: fetchMHMData,
        autofetch: fetchMHMData
    });
});

function setMHMDateRange(days) {
    const end = new Date();
    const start = new Date();
    if (days <= 1) {
        start.setHours(0,0,0,0);
    } else {
        start.setDate(end.getDate() - (days - 1));
    }
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    if (fpStart) fpStart.setDate(fmt(start), true); else $('#filter_start').val(fmt(start));
    if (fpEnd) fpEnd.setDate(fmt(end), true); else $('#filter_end').val(fmt(end));
    $('.mhm-range-btn').removeClass('active');
    $('.mhm-range-btn[data-days="' + days + '"]').addClass('active');
}

function mhmDaysBetween(from, to) {
    if (!from || !to) return null;
    const a = Date.parse(String(from).slice(0, 10) + 'T00:00:00');
    const b = Date.parse(String(to).slice(0, 10) + 'T00:00:00');
    if (isNaN(a) || isNaN(b)) return null;
    return Math.round((b - a) / 86400000);
}
function mhmDaysText(days) {
    if (days === null || days === undefined || days === '') return '';
    const n = parseInt(days, 10);
    if (isNaN(n)) return '';
    if (n < 0) return 'นัดก่อนได้ยา ' + Math.abs(n) + ' วัน';
    if (n === 0) return 'วันเดียวกับวันนัด';
    return n + ' วัน';
}
function mhmApptDaysFromOrder(orderDate, a) {
    const date = a && (a.date || '');
    if (date && orderDate) return mhmDaysBetween(orderDate, date);
    if (a && a.days !== undefined && a.days !== null && a.days !== '') {
        const n = parseInt(a.days, 10);
        return isNaN(n) ? null : n;
    }
    return null;
}
function mhmKeepFutureAppt(orderDate, a) {
    const days = mhmApptDaysFromOrder(orderDate, a);
    return days === null || days > 0;
}
function mhmLatestHmeDate(p) {
    let max = '';
    (p.admissions || []).forEach(function(adm) {
        (adm.drugs || []).forEach(function(d) {
            const hd = String(d.hme_date || '').slice(0, 10);
            if (hd && hd > max) max = hd;
        });
    });
    return max;
}

function mhmPatientAppointments(p) {
    if (p && p.appointments && p.appointments.length) return p.appointments;
    if (p && p.next_appointment) {
        return [{
            date: p.next_appointment,
            date_fmt: p.next_appointment_fmt || '',
            time: p.next_appointment_time || '',
            clinic: p.next_appointment_clinic || '',
            doctor: p.next_appointment_doctor || ''
        }];
    }
    return [];
}

function renderMHMDrug(d, appointments, p, adm) {
    const prior = !!d.prior_opd;
    const fromHme = prior && d.prior_source === 'ipd_hme';
    const mark = fromHme
        ? '<span class="mhm-prior-hme"><i class="fas fa-procedures"></i> เคยได้ HME IPD</span>'
        : (prior
            ? '<span class="mhm-prior-mark"><i class="fas fa-history"></i> เคยได้ OPD</span>'
            : '<span class="text-muted small">—</span>');
    const hmeWhen = d.hme_time
        ? mhmEsc(d.hme_date_fmt) + ' <span class="text-dark">' + mhmEsc(d.hme_time) + '</span>'
        : mhmEsc(d.hme_date_fmt || '-');
    const remain = prior
        ? ('<div class="mhm-remain">' + mhmEsc(d.remaining_text || '-') + '</div>'
            + (d.alert_level === 'hard' ? '<span class="badge bg-danger">Hard Alert</span>'
                : (d.alert_level === 'soft' ? '<span class="badge bg-warning text-dark">Soft Alert</span>' : '')))
        : (d.remaining_ignored
            ? '<div class="text-muted small">' + mhmEsc(d.remaining_text || '-') + '</div>'
            : '<span class="text-muted">—</span>');
    const priorRef = fromHme
        ? ((d.prior_an ? ' · AN ' + mhmEsc(d.prior_an) : '')
            + (d.prior_appt_fmt ? ' · นัด ' + mhmEsc(d.prior_appt_fmt) + ' · re-admit ก่อนวันนัด' : ''))
        : (d.opd_vn ? ' · VN ' + mhmEsc(d.opd_vn) : '');
    const opd = prior
        ? ('<div><b>' + mhmEsc(d.opd_drug_name || d.hme_drug_name) + '</b></div>'
            + '<div class="small text-muted">' + (fromHme ? 'HME IPD จ่าย ' : 'จ่าย ') + mhmEsc(d.opd_date_fmt || '-')
            + (d.opd_qty ? ' · qty ' + mhmEsc(d.opd_qty) : '')
            + priorRef + '</div>'
            + '<div class="small">' + mhmEsc(d.opd_method || '-') + '</div>'
            + (d.match_label ? '<span class="badge bg-light text-dark border">' + mhmEsc(d.match_label) + '</span>' : ''))
        : (d.remaining_ignored
            ? '<span class="text-muted small">ยาเดิมเหลือน้อยกว่าเกณฑ์ — ไม่นับ</span>'
            : '<span class="text-muted small">ไม่พบใน OPD หรือ HME IPD ก่อน admit</span>');
    const list = (appointments && appointments.length) ? appointments : (d.appointment_days || []);
    let apptDays = '';
    list.forEach(function(a) {
        const date = a.date || '';
        const days = date ? mhmDaysBetween(d.hme_date, date) : a.days;
        if (days !== null && days !== undefined && days !== '' && parseInt(days, 10) <= 0) return;
        const txt = mhmDaysText(days);
        if (!txt) return;
        apptDays += '<div class="mb-1">'
            + '<div class="mhm-appt-days">' + mhmEsc(txt) + '</div>'
            + '<div class="small text-muted">' + mhmEsc(a.date_fmt || date) + '</div>'
            + '</div>';
    });
    if (!apptDays) apptDays = '<span class="text-muted">—</span>';
    return '<tr class="' + (prior ? 'prior' : '') + '">'
        + '<td class="text-center">' + mark + '</td>'
        + '<td><div class="fw-bold">' + mhmEsc(d.hme_drug_name) + '</div>'
        + '<div class="small text-muted">icode: ' + mhmEsc(d.hme_icode)
        + (d.hme_qty ? ' · qty ' + mhmEsc(d.hme_qty) : '') + '</div>'
        + '<div class="small">' + mhmEsc(d.hme_method || '-') + '</div></td>'
        + '<td class="small text-nowrap">' + hmeWhen + '</td>'
        + '<td class="small">' + apptDays + '</td>'
        + '<td class="small">' + opd + '</td>'
        + '<td class="small">' + remain
        + (prior && window.MonIv ? MonIv.btn({
            hn: (p && (p.hn_full || p.hn)) || '',
            ptname: (p && p.ptname) || '',
            an: (adm && adm.an) || d.prior_an || '',
            vn: d.opd_vn || '',
            type_patient: 'IPD',
            drug_name: d.hme_drug_name || '',
            alert_level: d.alert_level || 'soft',
            vstdate: d.hme_date || '',
            ward_name: (adm && (adm.ward_display || adm.ward_name)) || '',
            alert_summary: d.remaining_text || d.alert_message || ''
        }) : '')
        + '</td>'
        + '</tr>';
}

function renderMHMApptBadges(p, latestHme) {
    const list = mhmPatientAppointments(p).filter(function(a) { return mhmKeepFutureAppt(latestHme, a); });
    if (!list.length) {
        return '<span class="badge bg-light text-muted border">ไม่มีวันนัดข้างหน้า</span>';
    }
    let html = '<div class="mhm-appt-list">';
    list.forEach(function(a) {
        let t = mhmEsc(a.date_fmt || a.date || '');
        if (a.time) t += ' ' + mhmEsc(a.time);
        if (a.clinic) t += ' · ' + mhmEsc(a.clinic);
        if (a.doctor) t += ' · ' + mhmEsc(a.doctor);
        const days = a.date && latestHme ? mhmDaysBetween(latestHme, a.date) : a.days;
        let extra = '';
        if (days !== null && days !== undefined && days !== '' && parseInt(days, 10) > 0) {
            extra = ' · อีก ' + parseInt(days, 10) + ' วัน';
        }
        html += '<span class="badge bg-info text-dark"><i class="fas fa-calendar-alt me-1"></i>นัด ' + t + extra + '</span>';
    });
    html += '</div>';
    return html;
}

function mhmSkipUnusable(d) {
    if (!d || !d.prior_opd) return false;
    if (d.remaining_days === null || d.remaining_days === '' || typeof d.remaining_days === 'undefined') return true;
    const n = parseInt(d.remaining_days, 10);
    return !isNaN(n) && n < 0;
}

function renderMHMPatient(p) {
    const ads = p.admissions || [];
    const appointments = mhmPatientAppointments(p);
    let body = '';
    let shown = 0;
    ads.forEach(function(adm) {
        const drugs = (adm.drugs || []).filter(function(d) { return !mhmSkipUnusable(d); });
        if (!drugs.length) return;
        shown += drugs.length;
        if (ads.length > 1) {
            body += '<div class="px-3 pt-2 small text-muted"><b>AN ' + mhmEsc(adm.an) + '</b>'
                + ' · Admit ' + mhmEsc(adm.admit_date_fmt)
                + ' · ' + mhmEsc(adm.ward_display || '-') + '</div>';
        }
        body += '<div class="table-responsive"><table class="table table-sm align-middle mhm-drug-table mb-0">'
            + '<thead><tr>'
            + '<th width="11%">สัญลักษณ์</th>'
            + '<th>ยา HME</th><th width="13%">สั่ง HME</th>'
            + '<th width="14%">ถึงวันนัด</th>'
            + '<th>ยาก่อน admit</th><th width="12%">เหลือ ณ admit</th>'
            + '</tr></thead><tbody>';
        drugs.forEach(function(d) { body += renderMHMDrug(d, appointments, p, adm); });
        body += '</tbody></table></div>';
    });
    if (!shown) return '';
    const hasPrior = (p.admissions || []).some(function(adm) {
        return (adm.drugs || []).some(function(d) { return d.prior_opd && !mhmSkipUnusable(d); });
    });
    if (!hasPrior) return '';
    const first = ads[0] || {};
    const cls = p.prior_count > 0 ? 'mhm-patient has-prior' : 'mhm-patient';
    const latestHme = p.hme_latest_date || mhmLatestHmeDate(p);
    const apptHtml = renderMHMApptBadges(p, latestHme);
    return '<div class="' + cls + '" data-hn="' + mhmEsc(p.hn) + '">'
        + '<div class="mhm-pt-head">'
        + '<div><span class="mhm-pt-hn fw-bold">HN ' + mhmEsc(p.hn) + '</span>'
        + ' <span class="ms-1">' + mhmEsc(p.ptname) + '</span></div>'
        + '<div class="small text-muted">AN ' + mhmEsc(first.an || '-')
        + ' · Admit ' + mhmEsc(first.admit_date_fmt || '-')
        + ' · ' + mhmEsc(first.ward_display || '-') + '</div>'
        + apptHtml
        + '<div class="ms-auto d-flex flex-wrap gap-1">'
        + '<span class="badge bg-secondary">HME ' + (p.drug_count || 0) + '</span>'
        + (p.prior_opd_count ? '<span class="badge" style="background:#ea580c;">เคยได้ OPD ' + p.prior_opd_count + '</span>' : '')
        + (p.prior_hme_count ? '<span class="badge" style="background:#4f46e5;">เคยได้ HME IPD ' + p.prior_hme_count + '</span>' : '')
        + (p.hard_count ? '<span class="badge bg-danger">Hard Alert ' + p.hard_count + '</span>' : '')
        + (p.soft_count ? '<span class="badge bg-warning text-dark">Soft Alert ' + p.soft_count + '</span>' : '')
        + '</div></div>'
        + body
        + '</div>';
}

function mhmMergePatients(into, add) {
    const map = {};
    (into || []).forEach(function(p) { map[String(p.hn || '')] = p; });
    (add || []).forEach(function(p) {
        const hn = String(p.hn || '');
        if (!map[hn]) {
            const copy = JSON.parse(JSON.stringify(p));
            (copy.admissions || []).forEach(function(a) {
                a.drugs = (a.drugs || []).filter(function(d) { return !mhmSkipUnusable(d); });
            });
            copy.admissions = (copy.admissions || []).filter(function(a) { return (a.drugs || []).length; });
            if (!copy.admissions.length) return;
            let priorN = 0;
            copy.admissions.forEach(function(a) {
                (a.drugs || []).forEach(function(d) { if (d.prior_opd) priorN++; });
            });
            if (!priorN) return;
            map[hn] = copy;
            return;
        }
        const cur = map[hn];
        if (!cur.ptname && p.ptname) cur.ptname = p.ptname;
        const mergedAppt = {};
        mhmPatientAppointments(cur).concat(mhmPatientAppointments(p)).forEach(function(a) {
            const k = String(a.date || '') + '|' + String(a.time || '') + '|' + String(a.clinic || '');
            if (a.date && (!mergedAppt[k] || (!mergedAppt[k].doctor && a.doctor))) mergedAppt[k] = a;
        });
        cur.appointments = Object.keys(mergedAppt).map(function(k) { return mergedAppt[k]; })
            .sort(function(a, b) { return String(a.date).localeCompare(String(b.date)); });
        if (cur.appointments.length) {
            const first = cur.appointments[0];
            cur.next_appointment = first.date;
            cur.next_appointment_fmt = first.date_fmt || cur.next_appointment_fmt;
            cur.next_appointment_time = first.time || '';
            cur.next_appointment_clinic = first.clinic || '';
            cur.next_appointment_doctor = first.doctor || '';
        }
        if (p.hme_latest_date && (!cur.hme_latest_date || p.hme_latest_date > cur.hme_latest_date)) {
            cur.hme_latest_date = p.hme_latest_date;
        }
        const admMap = {};
        (cur.admissions || []).forEach(function(a) { admMap[String(a.an || '')] = a; });
        (p.admissions || []).forEach(function(a) {
            const an = String(a.an || '');
            if (!admMap[an]) {
                admMap[an] = JSON.parse(JSON.stringify(a));
                return;
            }
            const drugs = {};
            (admMap[an].drugs || []).forEach(function(d) {
                drugs[String(d.hme_icode || d.hme_drug_name)] = d;
            });
            (a.drugs || []).forEach(function(d) {
                const k = String(d.hme_icode || d.hme_drug_name);
                const prev = drugs[k];
                if (!prev || (d.hme_date || '') > (prev.hme_date || '') || (d.prior_opd && !prev.prior_opd)) {
                    drugs[k] = d;
                }
            });
            admMap[an].drugs = Object.keys(drugs).map(function(k) { return drugs[k]; })
                .filter(function(d) { return !mhmSkipUnusable(d); });
        });
        cur.admissions = Object.keys(admMap).map(function(k) { return admMap[k]; })
            .filter(function(a) {
                a.drugs = (a.drugs || []).filter(function(d) { return !mhmSkipUnusable(d); });
                return a.drugs.length > 0;
            });
        let prior = 0, priorOpd = 0, priorHme = 0, hardN = 0, softN = 0, drugN = 0;
        cur.admissions.forEach(function(a) {
            (a.drugs || []).forEach(function(d) {
                if (mhmSkipUnusable(d)) return;
                drugN++;
                if (d.prior_opd) {
                    prior++;
                    if (d.prior_source === 'ipd_hme') priorHme++;
                    else priorOpd++;
                }
                if (d.alert_level === 'hard') hardN++;
                else if (d.alert_level === 'soft') softN++;
            });
        });
        cur.drug_count = drugN;
        cur.prior_count = prior;
        cur.prior_opd_count = priorOpd;
        cur.prior_hme_count = priorHme;
        cur.hard_count = hardN;
        cur.soft_count = softN;
    });
    const list = Object.keys(map).map(function(k) { return map[k]; })
        .filter(function(p) { return (p.prior_count || 0) > 0; });
    list.sort(function(a, b) {
        if ((b.prior_count || 0) !== (a.prior_count || 0)) return (b.prior_count || 0) - (a.prior_count || 0);
        return String(a.hn).localeCompare(String(b.hn), undefined, { numeric: true });
    });
    return list;
}

let lastMHMPatients = [];
let currentMHMFilter = 'all';

function setMHMFilter(filter, btn) {
    currentMHMFilter = filter || 'all';
    $('[data-mhm-filter]').removeClass('active');
    if (btn) $(btn).addClass('active');
    mhmPaint(lastMHMPatients, '');
}

function mhmPaint(patients, metaHtml) {
    lastMHMPatients = patients || [];
    const all = lastMHMPatients;
    const priorPts = all.filter(function(p) { return (p.prior_count || 0) > 0; });
    const hardPts = all.filter(function(p) { return (p.hard_count || 0) > 0; });
    const softPts = all.filter(function(p) { return (p.soft_count || 0) > 0; });
    const hardN = all.reduce(function(s, p) { return s + (p.hard_count || 0); }, 0);
    const softN = all.reduce(function(s, p) { return s + (p.soft_count || 0); }, 0);
    $('#mhmCountAll').text(all.length);
    $('#mhmCountPrior').text(priorPts.length);
    $('#mhmCountHard').text(hardN);
    $('#mhmCountSoft').text(softN);
    if (metaHtml) {
        $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info').html(metaHtml);
    }
    let shown = all;
    if (currentMHMFilter === 'prior') shown = priorPts;
    else if (currentMHMFilter === 'hard') shown = hardPts;
    else if (currentMHMFilter === 'soft') shown = softPts;
    if (!shown.length) {
        $('#mhmPatients').html('<div class="text-center py-4 text-muted">ไม่พบรายการในช่วงเวลานี้</div>');
        return;
    }
    $('#mhmPatients').html(shown.map(renderMHMPatient).join(''));
}

function mhmFriendlyError(text, status) {
    const raw = String(text || '');
    if (status === 504 || /504|Gateway Time-out/i.test(raw)) {
        return 'ประมวลผลนานเกินกำหนด (504) — ระบบจะตรวจทีละวัน กรุณากดประมวลผลอีกครั้ง หรือย่อช่วงวันที่';
    }
    if (status === 502 || /Bad Gateway/i.test(raw)) {
        return 'เซิร์ฟเวอร์ไม่ตอบ (502) — ลองใหม่ในอีกสักครู่';
    }
    const stripped = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    return (stripped || ('HTTP ' + status)).substring(0, 240);
}

function mhmDatesInRange(start, end) {
    const out = [];
    const a = new Date(start + 'T00:00:00');
    const b = new Date(end + 'T00:00:00');
    if (isNaN(a.getTime()) || isNaN(b.getTime()) || a > b) return out;
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    const cur = new Date(a);
    while (cur <= b) {
        out.push(fmt(cur));
        cur.setDate(cur.getDate() + 1);
    }
    return out;
}

let mhmAbort = null;
let mhmFetchGen = 0;

async function fetchMHMData() {
    const start = $('#filter_start').val();
    const end = $('#filter_end').val();
    const days = mhmDatesInRange(start, end);
    if (!days.length) {
        alert('กรุณาเลือกช่วงวันที่ให้ถูกต้อง');
        return;
    }
    const gen = ++mhmFetchGen;
    if (mhmAbort) {
        try { mhmAbort.abort(); } catch (e) {}
    }
    const ac = new AbortController();
    mhmAbort = ac;

    $('#btnFetchMHM').prop('disabled', true);
    $('#mhmPatients').html('<div class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังประมวลผลทีละวัน...</div>');
    $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info')
        .html('<i class="fas fa-spinner fa-spin me-1"></i> เริ่มตรวจ 0/' + days.length + ' วัน');

    let patients = [];
    let hmeOrders = 0;
    let priorDrugs = 0;
    let hiddenLow = 0;
    let hiddenShort = 0;
    const failed = [];
    const t0 = Date.now();

    try {
        for (let i = 0; i < days.length; i++) {
            if (gen !== mhmFetchGen) return;
            const day = days[i];
            const qs = new URLSearchParams({ start_date: day, end_date: day });
            monitorAppendHn(qs);
            const r = await fetch('fetch_monitor_home_med_api.php?' + qs.toString(), {
                credentials: 'same-origin',
                signal: ac.signal
            });
            const text = await r.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                throw new Error(mhmFriendlyError(text, r.status));
            }
            if (data.status !== 'success') {
                failed.push(day + ' — ' + (data.message || 'ไม่สำเร็จ'));
            } else {
                patients = mhmMergePatients(patients, data.patients || []);
                const m = data.meta || {};
                hmeOrders += m.hme_orders || 0;
                priorDrugs += m.prior_drug_count || 0;
                hiddenLow += m.hidden_low_remaining || 0;
                hiddenShort += m.hidden_short_hme || 0;
            }
            const sec = ((Date.now() - t0) / 1000).toFixed(1);
            const priorPts = patients.filter(function(p) { return (p.prior_count || 0) > 0; }).length;
            $('#reportMeta').html('<i class="fas fa-info-circle me-1"></i> ตรวจแล้ว ' + (i + 1) + '/' + days.length
                + ' วัน (' + day + ') | คนไข้: ' + patients.length
                + ' | เคยได้ก่อน admit: ' + priorPts
                + ' | HME: ' + hmeOrders
                + (hiddenLow ? (' | ซ่อนยาเหลือน้อย: ' + hiddenLow) : '')
                + (hiddenShort ? (' | ซ่อน HME สั้น: ' + hiddenShort) : '')
                + ' | ' + sec + ' วินาที');
            if (patients.length) {
                mhmPaint(patients, '');
            }
        }
    } catch (err) {
        if (err && err.name === 'AbortError') return;
        $('#btnFetchMHM').prop('disabled', false);
        $('#mhmPatients').html('<div class="text-center text-danger py-4">' + mhmEsc(err.message || 'เชื่อมต่อ API ไม่สำเร็จ') + '</div>');
        $('#reportMeta').removeClass('alert-info').addClass('alert-danger').removeClass('d-none')
            .html('<i class="fas fa-times-circle me-1"></i> ' + mhmEsc(err.message || 'ไม่สำเร็จ'));
        return;
    }

    if (gen !== mhmFetchGen) return;
    $('#btnFetchMHM').prop('disabled', false);
    const sec = ((Date.now() - t0) / 1000).toFixed(1);
    const priorPts = patients.filter(function(p) { return (p.prior_count || 0) > 0; }).length;
    const hardN = patients.reduce(function(s, p) { return s + (p.hard_count || 0); }, 0);
    const softN = patients.reduce(function(s, p) { return s + (p.soft_count || 0); }, 0);
    let metaHtml = '<i class="fas fa-info-circle me-1"></i> คนไข้: ' + patients.length
        + ' | เคยได้ก่อน admit: ' + priorPts
        + ' | ยา HME: ' + hmeOrders
        + ' | Hard Alert: ' + hardN
        + ' | Soft Alert: ' + softN
        + (hiddenLow ? (' | ซ่อนเคสยาเหลือน้อย: ' + hiddenLow) : '')
        + (hiddenShort ? (' | ซ่อน HME สั้น: ' + hiddenShort) : '')
        + ' | ตรวจ ' + days.length + ' วัน | ' + sec + ' วินาที';
    if (failed.length) {
        metaHtml += ' | <span class="text-danger">ไม่สำเร็จ ' + failed.length + ' วัน</span>'
            + '<div class="small fw-normal mt-1">' + failed.map(mhmEsc).join('<br>') + '</div>';
    }
    mhmPaint(patients, metaHtml);
    if (failed.length) {
        $('#reportMeta').removeClass('alert-info').addClass('alert-danger');
    }
}
</script>
<?php
$mon_iv_module = 'home_med';
$mon_iv_title = 'ยากลับบ้าน';
include __DIR__ . '/monitor_intervention_ui.php';
?>
</body>
</html>
