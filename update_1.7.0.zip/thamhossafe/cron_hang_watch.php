<?php
/**
 * จับหลักฐานตอนเว็บค้าง — รันจาก crontab ทุก 1 นาที (CLI ไม่ผ่าน Apache)
 * ไม่ต่อ HOSxP และไม่ใช้ session เพื่อไม่ให้ค้างตามเว็บ
 *
 * crontab:
 * * * * * * /usr/bin/php /home/co-scph/employee/public/thamhossafe/cron_hang_watch.php >> /home/co-scph/employee/public/thamhossafe/logs/hang_watch/cron.log 2>&1
 */
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'CLI only';
    exit(1);
}

set_time_limit(25);
ini_set('memory_limit', '64M');
require_once __DIR__ . '/server_health_helper.php';

$dir = sh_hang_dir();
if (!is_dir($dir)) {
    @mkdir($dir, 0775, true);
}

$lock = fopen($dir . '/watch.lock', 'c+');
if ($lock && !flock($lock, LOCK_EX | LOCK_NB)) {
    echo json_encode(['status' => 'skipped', 'message' => 'already running'], JSON_UNESCAPED_UNICODE) . PHP_EOL;
    exit(0);
}

$snap = sh_hang_watch_collect();
sh_hang_watch_save($snap);

if ($lock) {
    flock($lock, LOCK_UN);
    fclose($lock);
}

echo json_encode([
    'status' => !empty($snap['hang']) ? 'hang' : 'ok',
    'at' => $snap['at'] ?? '',
    'reasons' => $snap['reasons'] ?? [],
    'web_ms' => $snap['web']['ms'] ?? null,
], JSON_UNESCAPED_UNICODE) . PHP_EOL;
