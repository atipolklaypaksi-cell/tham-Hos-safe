<?php
/**
 * Smart Pharma — Tuya Cloud OpenAPI (สั่งเปิดอุปกรณ์ Smart Life โดยไม่ใช้ IFTTT)
 *
 * ปลายทางเก็บเป็น tuya://REGION/DEVICE_ID?code=switch_1
 * Secret เก็บเป็น ACCESS_ID:ACCESS_SECRET
 */

function sp_tuya_truncate($text, $max_len = 200) {
    $text = (string)$text;
    if (strlen($text) <= $max_len) {
        return $text;
    }
    return substr($text, 0, $max_len - 3) . '...';
}

function sp_tuya_region_hosts() {
    return [
        'cn' => 'https://openapi.tuya.com',
        'us' => 'https://openapi.tuyaus.com',
        'eu' => 'https://openapi.tuyaeu.com',
        'in' => 'https://openapi.tuyain.com',
        'we' => 'https://openapi-weaz.tuyaeu.com',
    ];
}

function sp_tuya_region_host($region) {
    $region = strtolower(trim((string)$region));
    $hosts = sp_tuya_region_hosts();
    return $hosts[$region] ?? $hosts['us'];
}

function sp_webhook_is_tuya($url) {
    return (bool)preg_match('#^tuya://#i', trim((string)$url));
}

function sp_tuya_empty_sha256() {
    return 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
}

function sp_tuya_parse_endpoint($url) {
    $url = trim((string)$url);
    if (!preg_match('#^tuya://([a-z]{2})/([A-Za-z0-9_-]+)(?:\?(.*))?$#i', $url, $m)) {
        return null;
    }
    $region = strtolower($m[1]);
    if (!isset(sp_tuya_region_hosts()[$region])) {
        return null;
    }
    $device_id = $m[2];
    $code = 'switch_1';
    if (!empty($m[3])) {
        parse_str($m[3], $q);
        $qcode = trim((string)($q['code'] ?? ''));
        if ($qcode !== '' && preg_match('/^[A-Za-z0-9_]+$/', $qcode)) {
            $code = $qcode;
        }
    }
    return [
        'region' => $region,
        'device_id' => $device_id,
        'code' => $code,
    ];
}

function sp_tuya_parse_secret($secret) {
    $secret = trim((string)$secret);
    $pos = strpos($secret, ':');
    if ($pos === false || $pos < 1 || $pos >= strlen($secret) - 1) {
        return null;
    }
    $access_id = trim(substr($secret, 0, $pos));
    $access_secret = trim(substr($secret, $pos + 1));
    if ($access_id === '' || $access_secret === '') {
        return null;
    }
    return [
        'access_id' => $access_id,
        'access_secret' => $access_secret,
    ];
}

function sp_tuya_build_url($region, $device_id, $code = 'switch_1') {
    $region = strtolower(trim((string)$region));
    $device_id = trim((string)$device_id);
    $code = trim((string)$code);
    if ($code === '') {
        $code = 'switch_1';
    }
    return 'tuya://' . $region . '/' . $device_id . '?code=' . rawurlencode($code);
}

function sp_tuya_sign($access_id, $access_secret, $t, $string_to_sign, $access_token = '') {
    $str = $access_id . ($access_token !== '' ? $access_token : '') . $t . $string_to_sign;
    return strtoupper(hash_hmac('sha256', $str, $access_secret));
}

function sp_tuya_http($host, $method, $path_query, $body, $access_id, $access_secret, $access_token = '') {
    $method = strtoupper($method);
    $body = (string)$body;
    $content_sha = $body === '' ? sp_tuya_empty_sha256() : hash('sha256', $body);
    $string_to_sign = $method . "\n" . $content_sha . "\n" . "\n" . $path_query;
    $t = (string)round(microtime(true) * 1000);
    $sign = sp_tuya_sign($access_id, $access_secret, $t, $string_to_sign, $access_token);
    $url = rtrim($host, '/') . $path_query;
    $headers = [
        'client_id: ' . $access_id,
        't: ' . $t,
        'sign_method: HMAC-SHA256',
        'sign: ' . $sign,
        'User-Agent: THAM-SmartPharma-Tuya/1.0',
    ];
    if ($access_token !== '') {
        $headers[] = 'access_token: ' . $access_token;
    }
    if ($method === 'POST' || $method === 'PUT') {
        $headers[] = 'Content-Type: application/json';
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $opts = [
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 15,
        ];
        if ($method === 'POST') {
            $opts[CURLOPT_POST] = true;
            $opts[CURLOPT_POSTFIELDS] = $body;
        } elseif ($method !== 'GET') {
            $opts[CURLOPT_CUSTOMREQUEST] = $method;
            $opts[CURLOPT_POSTFIELDS] = $body;
        }
        curl_setopt_array($ch, $opts);
        $resp = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($resp === false) {
            return ['ok' => false, 'error' => $err ?: 'curl failed', 'http_code' => $code];
        }
        return ['ok' => true, 'http_code' => $code, 'body' => (string)$resp];
    }

    $header_str = implode("\r\n", $headers) . "\r\n";
    $http = [
        'method' => $method,
        'header' => $header_str,
        'timeout' => 15,
        'ignore_errors' => true,
    ];
    if ($method !== 'GET') {
        $http['content'] = $body;
    }
    $ctx = stream_context_create(['http' => $http]);
    $resp = @file_get_contents($url, false, $ctx);
    if ($resp === false) {
        return ['ok' => false, 'error' => 'HTTP request failed'];
    }
    return ['ok' => true, 'http_code' => 200, 'body' => (string)$resp];
}

function sp_tuya_decode_result(array $http) {
    if (empty($http['ok'])) {
        return $http;
    }
    $json = json_decode((string)($http['body'] ?? ''), true);
    if (!is_array($json)) {
        return ['ok' => false, 'error' => 'Tuya ตอบกลับไม่ใช่ JSON', 'http_code' => $http['http_code'] ?? 0, 'body' => sp_tuya_truncate((string)($http['body'] ?? ''), 200)];
    }
    if (empty($json['success'])) {
        $msg = trim((string)($json['msg'] ?? $json['message'] ?? ''));
        $code = $json['code'] ?? '';
        $err = $msg !== '' ? $msg : 'Tuya API ไม่สำเร็จ';
        if ($code !== '' && $code !== null) {
            $err .= ' (code ' . $code . ')';
        }
        return ['ok' => false, 'error' => $err, 'http_code' => $http['http_code'] ?? 0, 'tuya_code' => $code];
    }
    return ['ok' => true, 'http_code' => $http['http_code'] ?? 200, 'result' => $json['result'] ?? null];
}

function sp_tuya_token_cache_path($region, $access_id) {
    return rtrim(sys_get_temp_dir(), '/') . '/tham_tuya_' . hash('sha256', strtolower($region) . '|' . $access_id) . '.json';
}

function sp_tuya_token_cache_get($region, $access_id) {
    $path = sp_tuya_token_cache_path($region, $access_id);
    if (!is_readable($path)) {
        return '';
    }
    $raw = @file_get_contents($path);
    $data = $raw ? json_decode($raw, true) : null;
    if (!is_array($data)) {
        return '';
    }
    $token = trim((string)($data['access_token'] ?? ''));
    $exp = (int)($data['expire_at'] ?? 0);
    if ($token === '' || $exp < (time() + 60)) {
        return '';
    }
    return $token;
}

function sp_tuya_token_cache_put($region, $access_id, $token, $ttl) {
    $ttl = max(60, (int)$ttl);
    $path = sp_tuya_token_cache_path($region, $access_id);
    @file_put_contents($path, json_encode([
        'access_token' => $token,
        'expire_at' => time() + $ttl,
    ]), LOCK_EX);
}

function sp_tuya_get_token($region, $access_id, $access_secret) {
    static $mem = [];
    $key = strtolower($region) . '|' . $access_id;
    if (!empty($mem[$key]) && $mem[$key]['exp'] > time() + 30) {
        return ['ok' => true, 'access_token' => $mem[$key]['token']];
    }
    $cached = sp_tuya_token_cache_get($region, $access_id);
    if ($cached !== '') {
        $mem[$key] = ['token' => $cached, 'exp' => time() + 300];
        return ['ok' => true, 'access_token' => $cached];
    }
    $host = sp_tuya_region_host($region);
    $http = sp_tuya_http($host, 'GET', '/v1.0/token?grant_type=1', '', $access_id, $access_secret, '');
    $decoded = sp_tuya_decode_result($http);
    if (empty($decoded['ok'])) {
        return $decoded;
    }
    $result = is_array($decoded['result'] ?? null) ? $decoded['result'] : [];
    $token = trim((string)($result['access_token'] ?? ''));
    if ($token === '') {
        return ['ok' => false, 'error' => 'Tuya ไม่คืน access_token'];
    }
    $ttl = (int)($result['expire_time'] ?? 7200);
    if ($ttl > 120) {
        $ttl -= 90;
    }
    sp_tuya_token_cache_put($region, $access_id, $token, $ttl);
    $mem[$key] = ['token' => $token, 'exp' => time() + $ttl];
    return ['ok' => true, 'access_token' => $token];
}

function sp_tuya_send_command($region, $device_id, $access_id, $access_secret, $code, $value) {
    $tok = sp_tuya_get_token($region, $access_id, $access_secret);
    if (empty($tok['ok'])) {
        return $tok;
    }
    $body = json_encode([
        'commands' => [
            ['code' => $code, 'value' => $value],
        ],
    ], JSON_UNESCAPED_UNICODE);
    $host = sp_tuya_region_host($region);
    $path = '/v1.0/devices/' . rawurlencode($device_id) . '/commands';
    $http = sp_tuya_http($host, 'POST', $path, $body, $access_id, $access_secret, $tok['access_token']);
    return sp_tuya_decode_result($http);
}

/**
 * เปิดสวิตช์อุปกรณ์เมื่อมี Alert (เทียบเท่า IFTTT Smart Life — Turn on)
 *
 * @return array{ok:bool, error?:string, http_code?:int}
 */
function sp_tuya_turn_on($url, $secret) {
    $ep = sp_tuya_parse_endpoint($url);
    if (!$ep) {
        return ['ok' => false, 'error' => 'URL Tuya ไม่ถูกต้อง — ใช้ tuya://us/DEVICE_ID'];
    }
    $keys = sp_tuya_parse_secret($secret);
    if (!$keys) {
        return ['ok' => false, 'error' => 'ใส่ Access ID และ Access Secret คั่นด้วยเครื่องหมาย :'];
    }
    $send = sp_tuya_send_command(
        $ep['region'],
        $ep['device_id'],
        $keys['access_id'],
        $keys['access_secret'],
        $ep['code'],
        true
    );
    if (!empty($send['ok'])) {
        return ['ok' => true, 'http_code' => $send['http_code'] ?? 200];
    }
    return $send;
}
