<?php
/**
 * Monitor จำนวนสั่งยา OPD — เปรียบเทียบ qty กับวันนัดครั้งต่อไป (oapp)
 */

require_once __DIR__ . '/moq_method_helper.php';

function moq_default_excess_pills() {
    return 10;
}

function moq_default_shortage_pills() {
    return 0;
}

function moq_rule_type($type) {
    return ($type === 'continuous') ? 'continuous' : 'drug';
}

function moq_is_continuous_rule(array $rule) {
    return moq_rule_type($rule['rule_type'] ?? 'drug') === 'continuous';
}

function moq_continuous_rule_icode() {
    return '*';
}

function moq_continuous_rule_label() {
    return 'ยาใช้ต่อเนื่อง (HOSxP)';
}

function moq_upgrade_schema($con) {
    if (!moq_ensure_table($con)) {
        return false;
    }
    $migrations = [
        'rule_type' => __DIR__ . '/sql/monitor_opd_order_qty_group.sql',
        'exclude_icodes' => __DIR__ . '/sql/monitor_opd_order_qty_exclude.sql',
        'shortage_pills_allowed' => __DIR__ . '/sql/monitor_opd_order_qty_shortage.sql',
        'monitor_scope' => __DIR__ . '/sql/monitor_opd_order_qty_scope.sql',
    ];
    foreach ($migrations as $column => $file) {
        $q = mysqli_query($con, "SHOW COLUMNS FROM monitor_opd_order_qty_settings LIKE '" . mysqli_real_escape_string($con, $column) . "'");
        if ($q && mysqli_num_rows($q) > 0) {
            continue;
        }
        $sql = @file_get_contents($file);
        if ($sql === false || trim($sql) === '') {
            return false;
        }
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
            if ($stmt !== '' && !mysqli_query($con, $stmt)) {
                return false;
            }
        }
    }
    moq_ensure_config($con);
    return true;
}

function moq_ensure_config($con) {
    $q = mysqli_query($con, "SHOW TABLES LIKE 'monitor_opd_order_qty_config'");
    if ($q && mysqli_num_rows($q) > 0) {
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_opd_order_qty_config.sql');
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '' && !mysqli_query($con, $stmt)) {
            return false;
        }
    }
    return true;
}

function moq_default_config() {
    return [
        'min_excess_value' => 0.0,
    ];
}

function moq_load_config($con) {
    moq_ensure_config($con);
    $cfg = moq_default_config();
    $q = mysqli_query($con, 'SELECT * FROM monitor_opd_order_qty_config WHERE id = 1 LIMIT 1');
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return $cfg;
    }
    $cfg['min_excess_value'] = max(0, (float)($row['min_excess_value'] ?? 0));
    return $cfg;
}

function moq_save_config($con, array $in) {
    moq_ensure_config($con);
    $min = max(0, (float)($in['min_excess_value'] ?? 0));
    $sql = "INSERT INTO monitor_opd_order_qty_config (id, min_excess_value)
            VALUES (1, $min)
            ON DUPLICATE KEY UPDATE min_excess_value = VALUES(min_excess_value)";
    return (bool)mysqli_query($con, $sql);
}

function moq_rx_group_key($hn, $vn, $rxdate = '') {
    $hn = trim((string)$hn);
    $vn = trim((string)$vn);
    if ($vn !== '') {
        return $hn . '|vn|' . $vn;
    }
    return $hn . '|date|' . substr(trim((string)$rxdate), 0, 10);
}

/**
 * กรองยาเกินตามมูลค่ารวมทั้งใบสั่งยา (ต่อ VN)
 *
 * @return array{0:array,1:array,2:int} hard, soft, skipped_count
 */
function moq_filter_alert_lists_by_rx_excess(array $hard, array $soft, $min_excess_value) {
    $min = (float)$min_excess_value;
    if ($min <= 0) {
        return [$hard, $soft, 0];
    }
    $sum = [];
    foreach (array_merge($hard, $soft) as $a) {
        if (($a['alert_type'] ?? '') !== 'excess') {
            continue;
        }
        $k = moq_rx_group_key($a['hn_full'] ?? $a['hn'] ?? '', $a['vn'] ?? '', $a['vstdate'] ?? $a['order_date'] ?? '');
        $sum[$k] = ($sum[$k] ?? 0) + (float)($a['excess_value'] ?? 0);
    }
    $skipped = 0;
    $keep = function ($list) use ($sum, $min, &$skipped) {
        $out = [];
        foreach ($list as $a) {
            if (($a['alert_type'] ?? '') === 'excess') {
                $k = moq_rx_group_key($a['hn_full'] ?? $a['hn'] ?? '', $a['vn'] ?? '', $a['vstdate'] ?? $a['order_date'] ?? '');
                $total = (float)($sum[$k] ?? 0);
                if ($total < $min) {
                    $skipped++;
                    continue;
                }
                $a['rx_excess_value'] = round($total, 2);
            }
            $out[] = $a;
        }
        return $out;
    };
    return [$keep($hard), $keep($soft), $skipped];
}

function moq_ensure_table($con) {
    $q = mysqli_query($con, "SHOW TABLES LIKE 'monitor_opd_order_qty_settings'");
    if ($q && mysqli_num_rows($q) > 0) {
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_opd_order_qty.sql');
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '' && !mysqli_query($con, $stmt)) {
            return false;
        }
    }
    return true;
}

function moq_monitor_scope($scope) {
    $scope = strtolower(trim((string)$scope));
    if ($scope === 'excess' || $scope === 'shortage') {
        return $scope;
    }
    return 'both';
}

function moq_scope_watches_shortage($scope) {
    $s = moq_monitor_scope($scope);
    return $s === 'both' || $s === 'shortage';
}

function moq_scope_watches_excess($scope) {
    $s = moq_monitor_scope($scope);
    return $s === 'both' || $s === 'excess';
}

function moq_monitor_scope_label($scope) {
    switch (moq_monitor_scope($scope)) {
        case 'excess':
            return 'เฉพาะยาเกิน';
        case 'shortage':
            return 'เฉพาะยาขาด';
        default:
            return 'ยาเกินและยาขาด';
    }
}

function moq_monitor_scope_badge_html($scope) {
    switch (moq_monitor_scope($scope)) {
        case 'excess':
            return '<span class="badge bg-info text-dark">เฉพาะเกิน</span>';
        case 'shortage':
            return '<span class="badge bg-warning text-dark">เฉพาะขาด</span>';
        default:
            return '<span class="badge bg-secondary">ทั้งสอง</span>';
    }
}

function moq_alert_level($level) {
    return ($level === 'soft') ? 'soft' : 'hard';
}

function moq_alert_badge_html($level) {
    if ($level === 'hard') {
        return '<span class="badge bg-danger">Hard</span>';
    }
    return '<span class="badge bg-warning text-dark">Soft</span>';
}

function moq_load_active_rules($con, array $rule_ids = []) {
    moq_upgrade_schema($con);
    $rules = [];
    $q = mysqli_query($con, "SELECT * FROM monitor_opd_order_qty_settings WHERE active = 1 ORDER BY rule_type DESC, drug_name ASC");
    if (!$q) {
        return $rules;
    }
    $filter = [];
    foreach ($rule_ids as $rid) {
        $rid = (int)$rid;
        if ($rid > 0) {
            $filter[$rid] = true;
        }
    }
    while ($row = mysqli_fetch_assoc($q)) {
        if (!empty($filter) && !isset($filter[(int)$row['id']])) {
            continue;
        }
        if (moq_is_continuous_rule($row)) {
            $rules[] = $row;
            continue;
        }
        $icode = trim($row['icode'] ?? '');
        if ($icode === '') {
            continue;
        }
        $rules[] = $row;
    }
    return $rules;
}

/**
 * ยาที่ติ๊ก "ยาใช้ต่อเนื่อง" ใน HOSxP (drugitems.continuous = Y)
 *
 * @return array<int, array{icode:string, name:string}>
 */
function moq_fetch_continuous_drugs($hos) {
    $list = [];
    if (!$hos) {
        return $list;
    }
    $sql = "SELECT d.icode,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS name_local
        FROM drugitems d
        WHERE d.istatus = 'Y'
          AND d.continuous = 'Y'
          AND d.icode IS NOT NULL
          AND TRIM(d.icode) <> ''
        ORDER BY name_local ASC";
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return $list;
    }
    while ($row = mysqli_fetch_assoc($q)) {
        $icode = trim((string)($row['icode'] ?? ''));
        if ($icode === '') {
            continue;
        }
        $list[] = [
            'icode' => $icode,
            'name' => trim((string)($row['name_local'] ?? '')),
        ];
    }
    return $list;
}

function moq_count_continuous_drugs($hos) {
    return count(moq_fetch_continuous_drugs($hos));
}

/**
 * @return string[]
 */
function moq_parse_exclude_icodes($raw) {
    if (is_array($raw)) {
        $list = $raw;
    } else {
        $raw = trim((string)$raw);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        $list = is_array($decoded) ? $decoded : explode(',', $raw);
    }
    $out = [];
    foreach ($list as $icode) {
        $icode = trim((string)$icode);
        if ($icode !== '') {
            $out[$icode] = true;
        }
    }
    return array_keys($out);
}

/**
 * @return array<string, bool>
 */
function moq_get_rule_exclude_set(array $rule) {
    $set = [];
    foreach (moq_parse_exclude_icodes($rule['exclude_icodes'] ?? '') as $icode) {
        $set[$icode] = true;
    }
    return $set;
}

/**
 * @param string[] $icodes
 */
function moq_encode_exclude_icodes(array $icodes) {
    return json_encode(moq_parse_exclude_icodes($icodes), JSON_UNESCAPED_UNICODE);
}

function moq_count_continuous_for_rule($hos, array $rule) {
    if (!moq_is_continuous_rule($rule)) {
        return 0;
    }
    $exclude = moq_get_rule_exclude_set($rule);
    $count = 0;
    foreach (moq_fetch_continuous_drugs($hos) as $drug) {
        $ic = trim($drug['icode'] ?? '');
        if ($ic !== '' && !isset($exclude[$ic])) {
            $count++;
        }
    }
    return $count;
}

function moq_build_continuous_drug_options_html(array $drugs) {
    $html = '';
    foreach ($drugs as $d) {
        $icode = trim($d['icode'] ?? '');
        if ($icode === '') {
            continue;
        }
        $name = trim($d['name'] ?? '');
        $label = htmlspecialchars($name !== '' ? $name : $icode, ENT_QUOTES, 'UTF-8');
        $label .= ' (' . htmlspecialchars($icode, ENT_QUOTES, 'UTF-8') . ')';
        $html .= '<option value="' . htmlspecialchars($icode, ENT_QUOTES, 'UTF-8') . '">' . $label . '</option>';
    }
    return $html;
}

/**
 * สร้าง map icode => กฎที่ใช้ (กฎยาเดี่ยวชนะกฎกลุ่มยาใช้ต่อเนื่อง)
 *
 * @return array{0: array<string, array<int, array>>, 1: string[]}
 */
function moq_build_rule_map_by_icode($hos, array $rules) {
    $rule_by_icode = [];
    $icode_list = [];

    foreach ($rules as $rule) {
        if (moq_is_continuous_rule($rule)) {
            continue;
        }
        $ic = trim($rule['icode'] ?? '');
        if ($ic === '') {
            continue;
        }
        if (!isset($rule_by_icode[$ic])) {
            $rule_by_icode[$ic] = [];
            $icode_list[] = "'" . mysqli_real_escape_string($hos, $ic) . "'";
        }
        $rule_by_icode[$ic][] = $rule;
    }

    foreach ($rules as $rule) {
        if (!moq_is_continuous_rule($rule)) {
            continue;
        }
        $exclude = moq_get_rule_exclude_set($rule);
        foreach (moq_fetch_continuous_drugs($hos) as $drug) {
            $ic = trim($drug['icode'] ?? '');
            if ($ic === '' || isset($rule_by_icode[$ic]) || isset($exclude[$ic])) {
                continue;
            }
            $rule_by_icode[$ic] = [$rule];
            $icode_list[] = "'" . mysqli_real_escape_string($hos, $ic) . "'";
        }
    }

    return [$rule_by_icode, $icode_list];
}

/** จำนวนวันที่ต้องมียา (นับรวมวันนัด) */
function moq_days_needed_until_appointment($order_date, $nextdate) {
    $order_date = trim((string)$order_date);
    $nextdate = trim((string)$nextdate);
    if ($order_date === '' || $nextdate === '' || $nextdate === '0000-00-00') {
        return null;
    }
    $order_ts = strtotime($order_date);
    $next_ts = strtotime($nextdate);
    if (!$order_ts || !$next_ts || $next_ts < $order_ts) {
        return null;
    }
    return max(1, (int)floor(($next_ts - $order_ts) / 86400) + 1);
}

/**
 * @return array{status:string, days_needed?:int, coverage_days?:int, coverage_end?:string, daily_units?:float|null, pills_needed?:float|null, min_qty_required?:float|null, max_qty_allowed?:float|null, excess_pills_allowed?:int, shortage_pills_allowed?:int}
 */
function moq_evaluate_order($qty, $method, $units, $order_date, $nextdate, $excess_pills = 10, $shortage_pills = 0, $con = null, $scope = 'both') {
    $days_needed = moq_days_needed_until_appointment($order_date, $nextdate);
    if ($days_needed === null) {
        return ['status' => 'skip'];
    }

    $qty = (float)$qty;
    $method = trim((string)$method);
    $units = trim((string)$units);
    $excess_days = max(0, (int)$excess_pills);
    $shortage_days = max(0, (int)$shortage_pills);

    if ($con) {
        $analysis = moq_method_analyze($con, $method, $qty, $units, $order_date, $nextdate);
        if (($analysis['status'] ?? '') === 'skip') {
            return [
                'status' => 'skip',
                'skip_reason' => $analysis['skip_reason'] ?? 'ข้ามตามนิยามวิธีใช้',
                'usage_mode' => $analysis['usage']['mode'] ?? 'skip',
                'usage_label' => $analysis['usage']['label'] ?? '',
            ];
        }
        if (($analysis['status'] ?? '') === 'ok') {
            $coverage_days = (int)($analysis['coverage_days'] ?? 1);
            $coverage_end = $analysis['coverage_end'] ?? di_period_end_date($order_date, $coverage_days);
            $daily = $analysis['daily_units'] ?? null;
            $pills_needed = $analysis['units_needed'] ?? null;
        } else {
            $coverage_days = di_calculate_coverage_days($qty, $method, $units);
            $coverage_end = di_period_end_date($order_date, $coverage_days);
            $daily = di_parse_daily_dose($method);
            $pills_needed = ($daily !== null && $daily > 0) ? $daily * $days_needed : null;
        }
    } else {
        $coverage_days = di_calculate_coverage_days($qty, $method, $units);
        $coverage_end = di_period_end_date($order_date, $coverage_days);
        $daily = di_parse_daily_dose($method);
        $pills_needed = ($daily !== null && $daily > 0) ? $daily * $days_needed : null;
    }

    if ($pills_needed === null && $daily !== null && $daily > 0) {
        $pills_needed = $daily * $days_needed;
    }

    $min_qty_required = null;
    $max_qty_allowed = null;
    $max_days_allowed = $days_needed + $excess_days;
    $min_days_required = max(0, $days_needed - $shortage_days);
    $excess = ($coverage_days > $max_days_allowed);
    $shortage = ($coverage_days < $min_days_required);
    if ($pills_needed !== null && $pills_needed > 0 && $days_needed > 0) {
        $per_day = (float)$pills_needed / (float)$days_needed;
        $min_qty_required = max(0, $per_day * $min_days_required);
        $max_qty_allowed = $per_day * $max_days_allowed;
    }

    $scope = moq_monitor_scope($scope);
    if ($shortage && !moq_scope_watches_shortage($scope)) {
        $shortage = false;
    }
    if ($excess && !moq_scope_watches_excess($scope)) {
        $excess = false;
    }

    $base = [
        'days_needed' => $days_needed,
        'coverage_days' => $coverage_days,
        'coverage_end' => $coverage_end,
        'daily_units' => $daily,
        'pills_needed' => $pills_needed,
        'min_qty_required' => $min_qty_required,
        'max_qty_allowed' => $max_qty_allowed,
        'min_days_required' => $min_days_required,
        'max_days_allowed' => $max_days_allowed,
        'excess_pills_allowed' => $excess_days,
        'shortage_pills_allowed' => $shortage_days,
    ];

    if ($shortage) {
        return array_merge($base, ['status' => 'shortage']);
    }
    if ($excess) {
        return array_merge($base, ['status' => 'excess']);
    }
    return array_merge($base, ['status' => 'ok']);
}

function moq_format_date_th($date) {
    $ts = strtotime((string)$date);
    if (!$ts) {
        return (string)$date;
    }
    return date('d/m/', $ts) . ((int)date('Y', $ts) + 543);
}

function moq_format_appt_time($t) {
    if (function_exists('monitor_lab_normalize_hosxp_time') && function_exists('di_format_time')) {
        return trim((string)di_format_time(monitor_lab_normalize_hosxp_time($t)));
    }
    $t = trim((string)$t);
    if ($t === '' || $t === '00:00:00' || $t === '00:00' || $t === '0000') {
        return '';
    }
    if (preg_match('/^(\d{1,2}):(\d{2})(?::\d{2})?$/', $t, $m)) {
        return sprintf('%02d:%02d', (int)$m[1], (int)$m[2]);
    }
    if (preg_match('/^(\d{2})(\d{2})$/', $t, $m)) {
        return $m[1] . ':' . $m[2];
    }
    return $t;
}

function moq_format_date_dmy($date) {
    $date = substr(trim((string)$date), 0, 10);
    if ($date === '' || $date === '0000-00-00') {
        return '';
    }
    $ts = strtotime($date);
    return $ts ? date('d/m/Y', $ts) : $date;
}

function moq_format_appointment_item(array $a, $order_date = '') {
    $date = substr(trim((string)($a['nextdate'] ?? $a['date'] ?? '')), 0, 10);
    $clinic = trim((string)($a['clinic_name'] ?? ''));
    if ($clinic === '') {
        $clinic = trim((string)($a['clinic'] ?? ''));
    }
    $doctor = trim((string)($a['doctor_name'] ?? ''));
    if ($doctor === '') {
        $doctor = trim((string)($a['doctor'] ?? ''));
    }
    $order_date = substr(trim((string)$order_date), 0, 10);
    $days = null;
    if ($order_date !== '' && $date !== '' && $date !== '0000-00-00') {
        $a_ts = strtotime($order_date);
        $b_ts = strtotime($date);
        if ($a_ts && $b_ts) {
            $days = (int)round(($b_ts - $a_ts) / 86400);
        }
    }
    return [
        'date' => $date,
        'date_fmt' => moq_format_date_dmy($date),
        'time' => moq_format_appt_time($a['nexttime'] ?? $a['time'] ?? ''),
        'clinic' => $clinic,
        'doctor' => $doctor,
        'vstdate' => substr(trim((string)($a['vstdate'] ?? '')), 0, 10),
        'days' => $days,
    ];
}

/** นัดที่สั่งใน visit นั้น (vstdate = วันที่สั่งยา) และอยู่หลังวันสั่ง — สำหรับแสดงผลแบบ Monitor ยาเหลือ OPD */
function moq_appointments_for_display(array $appointments, $order_date) {
    $order_date = substr(trim((string)$order_date), 0, 10);
    $out = [];
    $seen = [];
    foreach ($appointments as $ap) {
        if (!is_array($ap)) {
            continue;
        }
        $item = moq_format_appointment_item($ap, $order_date);
        if ($item['date'] === '' || $item['date'] === '0000-00-00') {
            continue;
        }
        $vd = $item['vstdate'];
        if ($order_date !== '' && $vd !== '' && $vd !== $order_date) {
            continue;
        }
        if ($item['days'] !== null && $item['days'] <= 0) {
            continue;
        }
        $k = $item['vstdate'] . '|' . $item['date'] . '|' . $item['time'] . '|' . $item['clinic'] . '|' . $item['doctor'];
        if (isset($seen[$k])) {
            continue;
        }
        $seen[$k] = true;
        $out[] = $item;
    }
    usort($out, function ($a, $b) {
        $c = strcmp((string)$a['date'], (string)$b['date']);
        return $c !== 0 ? $c : strcmp((string)($a['time'] ?? ''), (string)($b['time'] ?? ''));
    });
    return $out;
}

function moq_default_shortage_message(array $rule, array $eval, $nextdate) {
    $custom = trim((string)($rule['alert_message_shortage'] ?? ''));
    if ($custom !== '') {
        return $custom;
    }
    $parts = [];
    $parts[] = 'ยาไม่พอถึงวันนัด ' . moq_format_date_th($nextdate);
    if (!empty($eval['coverage_days']) && !empty($eval['days_needed'])) {
        $parts[] = 'ยาพอ ' . (int)$eval['coverage_days'] . ' วัน ต้องการ ' . (int)$eval['days_needed'] . ' วัน';
    }
    if ($eval['pills_needed'] !== null) {
        $parts[] = 'ต้องการ ' . rtrim(rtrim(number_format((float)$eval['pills_needed'], 2, '.', ''), '0'), '.') . ' หน่วย';
    }
    $short_allow = (int)($eval['shortage_pills_allowed'] ?? moq_default_shortage_pills());
    if ($short_allow > 0) {
        $min_days = $eval['min_days_required'] ?? null;
        if ($min_days !== null && $min_days !== '') {
            $parts[] = 'ขาดได้ ' . $short_allow . ' วัน (ขั้นต่ำ ' . (int)$min_days . ' วัน)';
        } else {
            $parts[] = 'ขาดได้ ' . $short_allow . ' วัน';
        }
    }
    return implode(' — ', $parts);
}

function moq_default_excess_message(array $rule, array $eval, $nextdate) {
    $custom = trim((string)($rule['alert_message_excess'] ?? ''));
    if ($custom !== '') {
        return $custom;
    }
    $allow = (int)($eval['excess_pills_allowed'] ?? moq_default_excess_pills());
    $parts = [];
    $parts[] = 'ยาเกินวันนัด ' . moq_format_date_th($nextdate) . ' มากกว่าที่อนุโลม (' . $allow . ' วัน)';
    if (isset($eval['max_days_allowed']) && $eval['max_days_allowed'] !== null && $eval['max_days_allowed'] !== '') {
        $parts[] = 'สูงสุดที่อนุโลม ' . (int)$eval['max_days_allowed'] . ' วัน';
    }
    if (isset($eval['excess_days']) && $eval['excess_days'] !== null && (int)$eval['excess_days'] > 0) {
        $parts[] = 'เกิน ' . (int)$eval['excess_days'] . ' วัน';
    }
    if (isset($eval['excess_qty']) && $eval['excess_qty'] !== null && (float)$eval['excess_qty'] > 0) {
        $parts[] = 'เกิน ' . rtrim(rtrim(number_format((float)$eval['excess_qty'], 2, '.', ''), '0'), '.') . ' หน่วย';
    }
    if (isset($eval['excess_value']) && $eval['excess_value'] !== null && (float)$eval['excess_value'] > 0) {
        $parts[] = 'มูลค่า ' . number_format((float)$eval['excess_value'], 2) . ' บาท';
    }
    return implode(' — ', $parts);
}

function moq_attach_excess_value(array $eval, $qty, $unitprice) {
    $unitprice = max(0, (float)$unitprice);
    $qty = (float)$qty;
    $eval['unitprice'] = $unitprice;
    $need = $eval['pills_needed'] ?? null;
    if ($need === null || $need === '') {
        $daily = $eval['daily_units'] ?? null;
        $days = $eval['days_needed'] ?? null;
        if ($daily !== null && $daily !== '' && (float)$daily > 0 && $days !== null && $days !== '') {
            $need = (float)$daily * (float)$days;
        }
    }
    if ($need === null || $need === '') {
        $eval['excess_qty'] = null;
        $eval['excess_days'] = null;
        $eval['excess_value'] = null;
        return $eval;
    }
    $ex = max(0, $qty - (float)$need);
    $eval['excess_qty'] = $ex;
    $cov = $eval['coverage_days'] ?? null;
    $dn = $eval['days_needed'] ?? null;
    $eval['excess_days'] = ($cov !== null && $cov !== '' && $dn !== null && $dn !== '')
        ? max(0, (int)$cov - (int)$dn)
        : null;
    $eval['excess_value'] = round($ex * $unitprice, 2);
    return $eval;
}

function moq_hn_keys($hn) {
    if (function_exists('mhm_hn_variants')) {
        return mhm_hn_variants($hn);
    }
    $hn = trim((string)$hn);
    if ($hn === '') {
        return [];
    }
    $trim = ltrim($hn, '0');
    if ($trim === '') {
        $trim = '0';
    }
    return array_values(array_unique([$hn, $trim, str_pad($trim, 9, '0', STR_PAD_LEFT)]));
}

function moq_lookup_hn_appointments(array $by_hn, $hn) {
    foreach (moq_hn_keys($hn) as $k) {
        if (!empty($by_hn[$k]) && is_array($by_hn[$k])) {
            return $by_hn[$k];
        }
    }
    return [];
}

/**
 * นัดจากตาราง oapp ตาม HN ในช่วงวันที่มา (vstdate)
 *
 * @return array<string, array<int, array>>
 */
function moq_fetch_appointments_by_hn($hos, array $hn_list, $min_vstdate, $max_vstdate) {
    $out = [];
    $keys = [];
    foreach ($hn_list as $hn) {
        foreach (moq_hn_keys($hn) as $v) {
            $keys[$v] = true;
        }
    }
    $hn_list = array_keys($keys);
    if (empty($hn_list) || !$hos) {
        return $out;
    }
    $min_esc = mysqli_real_escape_string($hos, $min_vstdate);
    $max_esc = mysqli_real_escape_string($hos, $max_vstdate);
    foreach (array_chunk($hn_list, 40) as $chunk) {
        $in = [];
        foreach ($chunk as $hn) {
            $in[] = "'" . mysqli_real_escape_string($hos, $hn) . "'";
        }
        if (empty($in)) {
            continue;
        }
        $sql_doc = "SELECT o.oapp_id, o.hn, o.vn, o.vstdate, o.nextdate, o.nexttime, o.clinic, o.doctor,
                CAST(CONVERT(IFNULL(c.name,'') USING utf8) AS CHAR) AS clinic_name,
                CAST(CONVERT(IFNULL(doc.name,'') USING utf8) AS CHAR) AS doctor_name
            FROM oapp o
            LEFT JOIN clinic c ON c.clinic = o.clinic
            LEFT JOIN doctor doc ON doc.code = o.doctor
            WHERE o.hn IN (" . implode(',', $in) . ")
              AND o.vstdate BETWEEN '$min_esc' AND '$max_esc'
              AND o.nextdate IS NOT NULL
              AND o.nextdate <> '0000-00-00'
              AND o.nextdate >= o.vstdate
            ORDER BY o.hn ASC, o.vstdate ASC, o.nextdate DESC, o.oapp_id DESC";
        $sql_plain = "SELECT o.oapp_id, o.hn, o.vn, o.vstdate, o.nextdate, o.nexttime, o.clinic, '' AS doctor,
                CAST(CONVERT(IFNULL(c.name,'') USING utf8) AS CHAR) AS clinic_name,
                '' AS doctor_name
            FROM oapp o
            LEFT JOIN clinic c ON c.clinic = o.clinic
            WHERE o.hn IN (" . implode(',', $in) . ")
              AND o.vstdate BETWEEN '$min_esc' AND '$max_esc'
              AND o.nextdate IS NOT NULL
              AND o.nextdate <> '0000-00-00'
              AND o.nextdate >= o.vstdate
            ORDER BY o.hn ASC, o.vstdate ASC, o.nextdate DESC, o.oapp_id DESC";
        $q = mysqli_query($hos, $sql_doc);
        if (!$q) {
            $q = mysqli_query($hos, $sql_plain);
        }
        if (!$q) {
            continue;
        }
        while ($row = mysqli_fetch_assoc($q)) {
            $item = [
                'oapp_id' => (int)($row['oapp_id'] ?? 0),
                'hn' => trim((string)($row['hn'] ?? '')),
                'vn' => trim((string)($row['vn'] ?? '')),
                'vstdate' => trim((string)($row['vstdate'] ?? '')),
                'nextdate' => trim((string)($row['nextdate'] ?? '')),
                'nexttime' => trim((string)($row['nexttime'] ?? '')),
                'clinic' => trim((string)($row['clinic'] ?? '')),
                'clinic_name' => trim((string)($row['clinic_name'] ?? '')),
                'doctor' => trim((string)($row['doctor'] ?? '')),
                'doctor_name' => trim((string)($row['doctor_name'] ?? '')),
            ];
            foreach (moq_hn_keys($item['hn']) as $hk) {
                $out[$hk][] = $item;
            }
        }
    }
    return $out;
}

/**
 * ใช้วันนัดจาก visit ที่วันที่มา = วันที่สั่งยา แล้วเลือกวันนัดที่ไกลที่สุด
 * (ไม่ใช่นัดคิวใกล้ ๆ เช่น ไตเทียม ที่ทำให้ยาเหลือบ้านถูกตีว่าเกิน)
 */
function moq_filter_appointments_for_order(array $appointments, $order_date) {
    $order_date = substr(trim((string)$order_date), 0, 10);
    if ($order_date === '' || empty($appointments)) {
        return [];
    }
    $order_ts = strtotime($order_date);
    if (!$order_ts) {
        return [];
    }
    $same_day = [];
    foreach ($appointments as $ap) {
        $nd = substr(trim((string)($ap['nextdate'] ?? '')), 0, 10);
        if ($nd === '' || $nd === '0000-00-00') {
            continue;
        }
        $nd_ts = strtotime($nd);
        if (!$nd_ts || $nd_ts < $order_ts) {
            continue;
        }
        $vd = substr(trim((string)($ap['vstdate'] ?? '')), 0, 10);
        if ($vd === $order_date) {
            $same_day[] = $ap;
        }
    }
    $pool = $same_day;
    if (empty($pool)) {
        return [];
    }
    usort($pool, function ($a, $b) {
        $cmp = strcmp((string)($b['nextdate'] ?? ''), (string)($a['nextdate'] ?? ''));
        if ($cmp !== 0) {
            return $cmp;
        }
        return ((int)($b['oapp_id'] ?? 0)) <=> ((int)($a['oapp_id'] ?? 0));
    });
    $best = substr(trim((string)($pool[0]['nextdate'] ?? '')), 0, 10);
    $picked = [];
    $seen = [];
    foreach ($pool as $ap) {
        $nd = substr(trim((string)($ap['nextdate'] ?? '')), 0, 10);
        if ($nd !== $best) {
            continue;
        }
        $id = (int)($ap['oapp_id'] ?? 0);
        $k = $id > 0 ? ('id:' . $id) : ($nd . '|' . ($ap['nexttime'] ?? '') . '|' . ($ap['vn'] ?? ''));
        if (isset($seen[$k])) {
            continue;
        }
        $seen[$k] = true;
        $picked[] = $ap;
    }
    return $picked;
}

/**
 * @return array<string, array{nextdate:string, nexttime:string, oapp_id:int}>
 */
function moq_fetch_appointments_by_vn($hos, array $vn_list) {
    $out = [];
    if (empty($vn_list)) {
        return $out;
    }
    $in = [];
    foreach (array_unique($vn_list) as $vn) {
        $vn = trim((string)$vn);
        if ($vn !== '') {
            $in[] = "'" . mysqli_real_escape_string($hos, $vn) . "'";
        }
    }
    if (empty($in)) {
        return $out;
    }
    $sql_doc = "SELECT o.oapp_id, o.vn, o.vstdate, o.nextdate, o.nexttime, o.clinic, o.doctor,
            CAST(CONVERT(IFNULL(c.name,'') USING utf8) AS CHAR) AS clinic_name,
            CAST(CONVERT(IFNULL(doc.name,'') USING utf8) AS CHAR) AS doctor_name
        FROM oapp o
        LEFT JOIN clinic c ON c.clinic = o.clinic
        LEFT JOIN doctor doc ON doc.code = o.doctor
        WHERE o.vn IN (" . implode(',', $in) . ")
          AND o.nextdate IS NOT NULL
          AND o.nextdate <> '0000-00-00'
        ORDER BY o.vn ASC, o.nextdate DESC, o.oapp_id DESC";
    $sql_plain = "SELECT o.oapp_id, o.vn, o.vstdate, o.nextdate, o.nexttime, o.clinic, '' AS doctor,
            CAST(CONVERT(IFNULL(c.name,'') USING utf8) AS CHAR) AS clinic_name,
            '' AS doctor_name
        FROM oapp o
        LEFT JOIN clinic c ON c.clinic = o.clinic
        WHERE o.vn IN (" . implode(',', $in) . ")
          AND o.nextdate IS NOT NULL
          AND o.nextdate <> '0000-00-00'
        ORDER BY o.vn ASC, o.nextdate DESC, o.oapp_id DESC";
    $q = mysqli_query($hos, $sql_doc);
    if (!$q) {
        $q = mysqli_query($hos, $sql_plain);
    }
    if (!$q) {
        return $out;
    }
    while ($row = mysqli_fetch_assoc($q)) {
        $vn = trim((string)($row['vn'] ?? ''));
        if ($vn === '') {
            continue;
        }
        if (!isset($out[$vn])) {
            $out[$vn] = [];
        }
        $out[$vn][] = [
            'oapp_id' => (int)($row['oapp_id'] ?? 0),
            'vstdate' => trim((string)($row['vstdate'] ?? '')),
            'nextdate' => trim((string)($row['nextdate'] ?? '')),
            'nexttime' => trim((string)($row['nexttime'] ?? '')),
            'clinic' => trim((string)($row['clinic'] ?? '')),
            'clinic_name' => trim((string)($row['clinic_name'] ?? '')),
            'doctor' => trim((string)($row['doctor'] ?? '')),
            'doctor_name' => trim((string)($row['doctor_name'] ?? '')),
        ];
    }
    return $out;
}

/**
 * ตรวจทุกวันนัดใน visit — ถ้าวันใดวันหนึ่ง qty เพียงพอ (status ok) ไม่แจ้งเตือน
 *
 * @return array{status:string, appointment?:array, eval?:array}
 */
function moq_evaluate_order_against_appointments($qty, $method, $units, $order_date, array $appointments, $excess_pills = 10, $shortage_pills = 0, $con = null, $scope = 'both') {
    $order_date = trim((string)$order_date);
    if ($order_date === '' || empty($appointments)) {
        return ['status' => 'skip'];
    }
    $appointments = moq_filter_appointments_for_order($appointments, $order_date);
    $order_ts = strtotime($order_date);
    if (!$order_ts) {
        return ['status' => 'skip'];
    }

    $valid = [];
    foreach ($appointments as $ap) {
        $nd = trim((string)($ap['nextdate'] ?? ''));
        if ($nd === '' || $nd === '0000-00-00') {
            continue;
        }
        $nd_ts = strtotime($nd);
        if (!$nd_ts || $nd_ts < $order_ts) {
            continue;
        }
        $valid[] = $ap;
    }
    if (empty($valid)) {
        return ['status' => 'skip'];
    }

    usort($valid, function ($a, $b) {
        $cmp = strcmp($a['nextdate'], $b['nextdate']);
        if ($cmp !== 0) {
            return $cmp;
        }
        return ($a['oapp_id'] ?? 0) <=> ($b['oapp_id'] ?? 0);
    });

    $evals = [];
    foreach ($valid as $ap) {
        $ev = moq_evaluate_order($qty, $method, $units, $order_date, $ap['nextdate'], $excess_pills, $shortage_pills, $con, $scope);
        $ev['_appointment'] = $ap;
        $evals[] = $ev;
        if (($ev['status'] ?? '') === 'skip') {
            unset($ev['_appointment']);
            return [
                'status' => 'skip',
                'eval' => $ev,
            ];
        }
        if (($ev['status'] ?? '') === 'ok') {
            unset($ev['_appointment']);
            return [
                'status' => 'ok',
                'appointment' => $ap,
                'eval' => $ev,
            ];
        }
    }

    foreach ($evals as $ev) {
        if (($ev['status'] ?? '') === 'shortage') {
            $ap = $ev['_appointment'];
            unset($ev['_appointment']);
            return [
                'status' => 'shortage',
                'appointment' => $ap,
                'eval' => $ev,
            ];
        }
    }
    foreach ($evals as $ev) {
        if (($ev['status'] ?? '') === 'excess') {
            $ap = $ev['_appointment'];
            unset($ev['_appointment']);
            return [
                'status' => 'excess',
                'appointment' => $ap,
                'eval' => $ev,
            ];
        }
    }

    return ['status' => 'skip'];
}

/**
 * @deprecated ใช้ moq_evaluate_order_against_appointments แทน
 */
function moq_pick_appointment_for_order(array $appointments, $order_date) {
    $order_date = trim((string)$order_date);
    if ($order_date === '' || empty($appointments)) {
        return null;
    }
    $order_ts = strtotime($order_date);
    if (!$order_ts) {
        return null;
    }
    $best = null;
    foreach ($appointments as $ap) {
        $nd = trim((string)($ap['nextdate'] ?? ''));
        if ($nd === '' || $nd === '0000-00-00') {
            continue;
        }
        $nd_ts = strtotime($nd);
        if (!$nd_ts || $nd_ts < $order_ts) {
            continue;
        }
        if ($best === null || $nd_ts > strtotime($best['nextdate'])) {
            $best = $ap;
        }
    }
    return $best;
}
