<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

include('connect.php');
require_once __DIR__ . '/hospital_ds_helper.php';
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
require_once __DIR__ . '/jhcis_helper.php';
session_write_close();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_GET;
}

$action = trim((string)($input['action'] ?? 'context'));
if ($action === 'history_report') {
    echo json_encode(sd_mr_hist_report($con, $input), JSON_UNESCAPED_UNICODE);
    exit;
}
if ($action === 'history_update') {
    echo json_encode(sd_mr_hist_update($con, $input), JSON_UNESCAPED_UNICODE);
    exit;
}

$con_hosxp = function_exists('hosxp_connect') ? @hosxp_connect($con, 15) : null;
if (!$con_hosxp) {
    $q_config = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ('h_host', 'h_user', 'h_pass', 'h_db')");
    $config = [];
    if ($q_config) {
        while ($r = mysqli_fetch_assoc($q_config)) {
            $config[$r['config_name']] = $r['config_value'];
        }
    }
    if (empty($config['h_host']) || empty($config['h_user']) || empty($config['h_db'])) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบการตั้งค่า HOSxP']);
        exit;
    }
    $con_hosxp = @mysqli_connect($config['h_host'], $config['h_user'], $config['h_pass'] ?? '', $config['h_db']);
}
if (!$con_hosxp) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้']);
    exit;
}
@mysqli_set_charset($con_hosxp, 'utf8');

function sd_mr_fold_key($text) {
    $t = trim((string)$text);
    $t = preg_replace('/\s+/u', ' ', $t);
    if (function_exists('mb_strtolower')) {
        return mb_strtolower($t, 'UTF-8');
    }
    return strtolower($t);
}

function sd_mr_allergy_with_symptom($agent, $symptom) {
    $agent = trim((string)$agent);
    $symptom = trim(preg_replace('/\s+/u', ' ', (string)$symptom));
    if ($agent === '') {
        return '';
    }
    if ($symptom === '') {
        return $agent;
    }
    $fold_a = function_exists('mb_strtolower') ? mb_strtolower($agent, 'UTF-8') : strtolower($agent);
    $fold_s = function_exists('mb_strtolower') ? mb_strtolower($symptom, 'UTF-8') : strtolower($symptom);
    if ($fold_s === $fold_a) {
        return $agent;
    }
    return $agent . ' (อาการ: ' . $symptom . ')';
}

function sd_mr_merge_allergy(array $local_agents, array $extra_rows) {
    $agents = [];
    $seen = [];
    foreach ($local_agents as $agent) {
        $agent = trim((string)$agent);
        $key = sd_mr_fold_key(preg_replace('/\s*\(อาการ:.*$/u', '', $agent));
        if ($agent === '' || $key === '' || isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $agents[] = $agent;
    }
    $grouped = [];
    foreach ($extra_rows as $row) {
        $agent = trim((string)($row['agent'] ?? ''));
        $key = sd_mr_fold_key($agent);
        if ($agent === '' || $key === '' || isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $place = trim((string)($row['hospital_name'] ?? ''));
        if ($place === '') {
            $place = (($row['source_kind'] ?? '') === 'jhcis') ? 'JHCIS' : 'รพ.เครือข่าย';
        }
        if (!isset($grouped[$place])) {
            $grouped[$place] = [];
        }
        $grouped[$place][] = sd_mr_allergy_with_symptom($agent, $row['symptom'] ?? '');
    }
    $chunks = $agents;
    foreach ($grouped as $place => $names) {
        $chunks[] = implode(', ', $names) . ' (' . $place . ')';
    }
    return [
        'agents' => $chunks,
        'text' => implode(', ', $chunks),
    ];
}

function sd_mr_utf8($expr) {
    return "CAST(CONVERT($expr USING utf8) AS CHAR)";
}

function sd_mr_hn_variants($hn) {
    $hn = trim((string)$hn);
    if ($hn === '') {
        return [];
    }
    if (is_numeric($hn)) {
        $pad = str_pad($hn, 9, '0', STR_PAD_LEFT);
        $l = ltrim($hn, '0');
        return array_values(array_unique([$pad, $l === '' ? '0' : $l]));
    }
    return [$hn];
}

function sd_mr_hn_in($con, $hn) {
    $parts = [];
    foreach (sd_mr_hn_variants($hn) as $v) {
        $parts[] = "'" . mysqli_real_escape_string($con, $v) . "'";
    }
    return implode(',', $parts);
}

function sd_mr_fmt_appt_display($nextdate, $nexttime, $clinic_name = '', $doctor_name = '', $hospital_name = '') {
    $nextdate = substr(trim((string)$nextdate), 0, 10);
    if ($nextdate === '' || $nextdate === '0000-00-00') {
        return '';
    }
    $ts = strtotime($nextdate);
    if ($ts === false) {
        return $nextdate;
    }
    $s = date('d/m/', $ts) . (((int)date('Y', $ts)) + 543);
    $t = substr(trim((string)$nexttime), 0, 5);
    if ($t !== '' && $t !== '00:00') {
        $s .= ' ' . $t;
    }
    $clinic = trim((string)$clinic_name);
    $doctor = trim((string)$doctor_name);
    if ($clinic !== '') {
        $s .= ' · ' . $clinic;
    }
    if ($doctor !== '') {
        $s .= ' · ' . $doctor;
    }
    $place = trim((string)$hospital_name);
    if ($place !== '') {
        $s .= ' · ' . $place;
    }
    return $s;
}

function sd_mr_fetch_oapp_rows($con, $where, $order, $limit = 20) {
    $limit = max(1, min(40, (int)$limit));
    $select = "o.nextdate, o.nexttime, o.clinic, "
        . sd_mr_utf8("IFNULL(c.name,'')") . " AS clinic_name, "
        . sd_mr_utf8("IFNULL(doc.name,'')") . " AS doctor_name";
    $q = @mysqli_query($con, "
        SELECT $select
        FROM oapp o
        LEFT JOIN clinic c ON c.clinic = o.clinic
        LEFT JOIN doctor doc ON doc.code = o.doctor
        WHERE $where
        ORDER BY $order
        LIMIT $limit
    ");
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    if ($rows) {
        return $rows;
    }
    $q = @mysqli_query($con, "
        SELECT o.nextdate, o.nexttime, o.clinic, '' AS clinic_name, '' AS doctor_name
        FROM oapp o
        WHERE $where
        ORDER BY $order
        LIMIT $limit
    ");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function sd_mr_hist_ensure($con) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    mysqli_query($con, "CREATE TABLE IF NOT EXISTS smart_drug_medrecon_history (
        id INT NOT NULL AUTO_INCREMENT,
        hn VARCHAR(20) NOT NULL,
        hn_norm VARCHAR(20) NOT NULL,
        vn VARCHAR(30) NOT NULL DEFAULT '',
        an VARCHAR(30) NOT NULL DEFAULT '',
        patient_name VARCHAR(255) NOT NULL DEFAULT '',
        drug_count INT NOT NULL DEFAULT 0,
        fingerprint CHAR(32) NOT NULL DEFAULT '',
        saved_by INT DEFAULT NULL,
        saved_name VARCHAR(150) NOT NULL DEFAULT '',
        saved_at DATETIME NOT NULL,
        payload MEDIUMTEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_hn_saved (hn_norm, saved_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function sd_mr_hist_norm($hn) {
    $hn = trim((string)$hn);
    if ($hn !== '' && ctype_digit($hn)) {
        $hn = ltrim($hn, '0');
        return $hn === '' ? '0' : $hn;
    }
    return $hn;
}

function sd_mr_hist_th($dt) {
    $dt = trim((string)$dt);
    if ($dt === '' || strpos($dt, '0000-00-00') === 0) {
        return '';
    }
    $ts = strtotime($dt);
    if ($ts === false) {
        return $dt;
    }
    $out = date('d/m/', $ts) . ((int)date('Y', $ts) + 543);
    $hm = date('H:i', $ts);
    if ($hm !== '00:00') {
        $out .= ' ' . $hm;
    }
    return $out;
}

function sd_mr_hist_fingerprint(array $payload) {
    $parts = [
        trim((string)($payload['vn'] ?? '')),
        trim((string)($payload['an'] ?? '')),
    ];
    foreach (($payload['rows'] ?? []) as $row) {
        if (!is_array($row)) {
            continue;
        }
        $name = trim((string)($row['drug_name'] ?? $row['drug_text'] ?? ''));
        if ($name === '') {
            continue;
        }
        $parts[] = $name . '|' . trim((string)($row['method'] ?? '')) . '|' . trim((string)($row['qty'] ?? ''));
    }
    return md5(implode("\n", $parts));
}

function sd_mr_hist_list($con, $con_hosxp, $hn) {
    sd_mr_hist_ensure($con);
    $norm = sd_mr_hist_norm($hn);
    if ($norm === '') {
        return [];
    }
    $items = [];
    $esc = mysqli_real_escape_string($con, $norm);
    $q = mysqli_query($con, "SELECT id, hn, vn, an, patient_name, drug_count, saved_name, saved_at
        FROM smart_drug_medrecon_history
        WHERE hn_norm = '$esc'
        ORDER BY saved_at DESC, id DESC
        LIMIT 40");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $items[] = [
                'id' => 'local:' . (int)$r['id'],
                'source' => 'smart_drug',
                'source_label' => 'Smart Drug',
                'vn' => (string)$r['vn'],
                'an' => (string)$r['an'],
                'patient_name' => (string)$r['patient_name'],
                'drug_count' => (int)$r['drug_count'],
                'saved_name' => (string)$r['saved_name'],
                'saved_at' => (string)$r['saved_at'],
                'saved_at_th' => sd_mr_hist_th($r['saved_at']),
            ];
        }
    }
    if ($con_hosxp) {
        $in = sd_mr_hn_in($con_hosxp, $hn);
        if ($in !== '') {
            $sql = "SELECT mr.medication_reconciliation_id, mr.an, mr.note,
                    i.regdate, i.vn,
                    (SELECT COUNT(*) FROM medication_reconciliation_detail d
                        WHERE d.medication_reconciliation_id = mr.medication_reconciliation_id) AS drug_count,
                    (SELECT MAX(d.first_entry_date) FROM medication_reconciliation_detail d
                        WHERE d.medication_reconciliation_id = mr.medication_reconciliation_id) AS entry_at
                FROM medication_reconciliation mr
                INNER JOIN ipt i ON i.an = mr.an
                WHERE i.hn IN ($in)
                ORDER BY COALESCE(
                    (SELECT MAX(d2.first_entry_date) FROM medication_reconciliation_detail d2
                        WHERE d2.medication_reconciliation_id = mr.medication_reconciliation_id),
                    i.regdate
                ) DESC
                LIMIT 20";
            $qh = @mysqli_query($con_hosxp, $sql);
            if ($qh) {
                while ($r = mysqli_fetch_assoc($qh)) {
                    $when = trim((string)($r['entry_at'] ?? ''));
                    if ($when === '' || strpos($when, '0000-00-00') === 0) {
                        $when = trim((string)($r['regdate'] ?? '')) . ' 00:00:00';
                    }
                    $items[] = [
                        'id' => 'hosxp:' . (int)$r['medication_reconciliation_id'],
                        'source' => 'hosxp',
                        'source_label' => 'HOSxP',
                        'vn' => (string)($r['vn'] ?? ''),
                        'an' => (string)($r['an'] ?? ''),
                        'patient_name' => '',
                        'drug_count' => (int)($r['drug_count'] ?? 0),
                        'saved_name' => '',
                        'saved_at' => $when,
                        'saved_at_th' => sd_mr_hist_th($when),
                        'note' => trim((string)($r['note'] ?? '')),
                    ];
                }
            }
        }
    }
    usort($items, function ($a, $b) {
        return strcmp((string)($b['saved_at'] ?? ''), (string)($a['saved_at'] ?? ''));
    });
    return $items;
}

function sd_mr_hist_resolve_an(array $head, array $payload) {
    $an = trim((string)($head['an'] ?? ''));
    if ($an !== '') {
        return $an;
    }
    foreach (($payload['rows'] ?? []) as $drug) {
        if (!is_array($drug)) {
            continue;
        }
        $a = trim((string)($drug['an'] ?? ''));
        if ($a !== '') {
            return $a;
        }
        $vk = (string)($drug['visit_key'] ?? '');
        if (preg_match('/:ipd:([^:]+)$/', $vk, $m)) {
            return $m[1];
        }
    }
    $vn = trim((string)($head['vn'] ?? $payload['vn'] ?? ''));
    if (preg_match('/^\d{8,10}$/', $vn)) {
        return $vn;
    }
    return '';
}

/** VN ของครั้งที่ทำ Med Recon — ไม่ใช้เลขที่เป็น AN และไม่ใช้ VN ของยาที่ดึงมาจาก Visit อื่น */
function sd_mr_hist_resolve_vn(array $head, array $payload, $an) {
    $an = trim((string)$an);
    $cands = [
        trim((string)($head['vn'] ?? '')),
        trim((string)($payload['vn'] ?? '')),
    ];
    foreach ($cands as $vn) {
        if ($vn === '' || $vn === $an) {
            continue;
        }
        if (preg_match('/^\d{11,}$/', $vn)) {
            return $vn;
        }
    }
    if ($an === '') {
        foreach ($cands as $vn) {
            if ($vn !== '') {
                return $vn;
            }
        }
    }
    return '';
}

function sd_mr_hist_visit_match($q, $an, $vn, array $head, array $payload) {
    $q = trim((string)$q);
    if ($q === '') {
        return true;
    }
    $hay = [
        $an,
        $vn,
        $head['vn'] ?? '',
        $head['an'] ?? '',
        $payload['vn'] ?? '',
        $payload['an'] ?? '',
    ];
    foreach (($payload['rows'] ?? []) as $drug) {
        if (!is_array($drug)) {
            continue;
        }
        $hay[] = $drug['vn'] ?? '';
        $hay[] = $drug['an'] ?? '';
        $vk = (string)($drug['visit_key'] ?? '');
        if (preg_match('/:(?:ipd|opd):([^:]+)$/', $vk, $m)) {
            $hay[] = $m[1];
        }
    }
    foreach ($hay as $h) {
        $h = trim((string)$h);
        if ($h !== '' && stripos($h, $q) !== false) {
            return true;
        }
    }
    return false;
}

function sd_mr_hist_cut($text, $max) {
    $text = trim((string)$text);
    $max = max(1, (int)$max);
    if (function_exists('mb_substr')) {
        return mb_substr($text, 0, $max, 'UTF-8');
    }
    return substr($text, 0, $max);
}

function sd_mr_hist_position($role, $entryposition) {
    $role = trim((string)$role);
    if (!function_exists('tham_menu_role_labels')) {
        require_once __DIR__ . '/menu_permissions_helper.php';
    }
    $labels = function_exists('tham_menu_role_labels') ? tham_menu_role_labels() : [];
    if ($role !== '' && isset($labels[$role])) {
        return ['key' => $role, 'label' => $labels[$role]];
    }
    $ep = trim(preg_replace('/\s+/u', ' ', (string)$entryposition));
    if ($ep !== '') {
        return ['key' => 'ep:' . $ep, 'label' => $ep];
    }
    if ($role !== '') {
        return ['key' => $role, 'label' => $role];
    }
    return ['key' => '__none__', 'label' => 'ไม่ระบุตำแหน่ง'];
}

/** แผนกของ VN จาก ovst ของโรงพยาบาล — คืน map vn => ชื่อแผนก */
function sd_mr_hist_vn_departments($con, array $vn_list) {
    $map = [];
    $vn_list = array_values(array_unique(array_filter(array_map(function ($v) {
        return trim((string)$v);
    }, $vn_list))));
    if (!$vn_list || !function_exists('hosxp_connect')) {
        return $map;
    }
    $hos = @hosxp_connect($con, 15);
    if (!$hos) {
        return $map;
    }
    $dep = sd_mr_utf8("IFNULL(kd.department,'')");
    $sp = sd_mr_utf8("IFNULL(sp.name,'')");
    foreach (array_chunk($vn_list, 40) as $chunk) {
        $in = [];
        foreach ($chunk as $vn) {
            $in[] = "'" . mysqli_real_escape_string($hos, $vn) . "'";
        }
        if (!$in) {
            continue;
        }
        $sql = "SELECT o.vn, $dep AS department_name, $sp AS spclty_name
            FROM ovst o
            LEFT JOIN kskdepartment kd ON kd.depcode = o.main_dep
            LEFT JOIN spclty sp ON sp.spclty = o.spclty
            WHERE o.vn IN (" . implode(',', $in) . ")";
        $q = @mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($row = mysqli_fetch_assoc($q)) {
            $vn = trim((string)($row['vn'] ?? ''));
            $name = trim((string)($row['department_name'] ?? ''));
            if ($name === '') {
                $name = trim((string)($row['spclty_name'] ?? ''));
            }
            if ($vn !== '' && $name !== '') {
                $map[$vn] = $name;
            }
        }
    }
    return $map;
}

function sd_mr_hist_report($con, array $input) {
    sd_mr_hist_ensure($con);
    $date_from = trim((string)($input['date_from'] ?? ''));
    $date_to = trim((string)($input['date_to'] ?? ''));
    $has_from = preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from) === 1;
    $has_to = preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to) === 1;
    $days = isset($input['days']) ? (int)$input['days'] : 30;
    if (!in_array($days, [7, 30, 90, 365, 0], true)) {
        $days = 30;
    }
    if ($has_from && $has_to && $date_from > $date_to) {
        $swap = $date_from;
        $date_from = $date_to;
        $date_to = $swap;
    }
    $q = trim((string)($input['q'] ?? ''));
    $an_q = trim((string)($input['an'] ?? ''));
    $staff_q = trim((string)($input['staff'] ?? ''));
    $position_q = trim((string)($input['position'] ?? ''));
    $kind = trim((string)($input['kind'] ?? 'all'));
    if (!in_array($kind, ['all', 'added', 'visit'], true)) {
        $kind = 'all';
    }
    $group_by = trim((string)($input['group'] ?? 'an'));
    if (!in_array($group_by, ['an', 'staff', 'position'], true)) {
        $group_by = 'an';
    }

    $date_where = '1=1';
    if ($has_from || $has_to) {
        if (!$has_from) {
            $date_from = '2000-01-01';
        }
        if (!$has_to) {
            $date_to = date('Y-m-d');
        }
        $from_esc = mysqli_real_escape_string($con, $date_from);
        $to_esc = mysqli_real_escape_string($con, $date_to);
        $date_where .= " AND saved_at >= '$from_esc 00:00:00' AND saved_at <= '$to_esc 23:59:59'";
    } elseif ($days > 0) {
        $date_where .= ' AND saved_at >= DATE_SUB(NOW(), INTERVAL ' . $days . ' DAY)';
        $date_from = date('Y-m-d', strtotime('-' . $days . ' days'));
        $date_to = date('Y-m-d');
    } else {
        $date_from = '';
        $date_to = '';
    }
    $where = $date_where;
    if ($q !== '') {
        $esc = mysqli_real_escape_string($con, $q);
        $norm = mysqli_real_escape_string($con, sd_mr_hist_norm($q));
        $where .= " AND (hn LIKE '%$esc%' OR hn_norm = '$norm' OR patient_name LIKE '%$esc%')";
    }
    if ($staff_q !== '') {
        $where .= " AND h.saved_name = '" . mysqli_real_escape_string($con, $staff_q) . "'";
    }
    if ($position_q === '__none__') {
        $where .= " AND (u.role IS NULL OR u.role = '') AND (u.entryposition IS NULL OR TRIM(u.entryposition) = '')";
    } elseif ($position_q !== '') {
        if (strpos($position_q, 'ep:') === 0) {
            $ep_esc = mysqli_real_escape_string($con, substr($position_q, 3));
            $where .= " AND TRIM(u.entryposition) = '$ep_esc'";
        } else {
            $where .= " AND u.role = '" . mysqli_real_escape_string($con, $position_q) . "'";
        }
    }

    $staff = [];
    $qs = mysqli_query($con, "SELECT DISTINCT h.saved_name FROM smart_drug_medrecon_history h WHERE h.saved_name <> '' AND $date_where ORDER BY h.saved_name ASC");
    if ($qs) {
        while ($r = mysqli_fetch_assoc($qs)) {
            $name = trim((string)$r['saved_name']);
            if ($name !== '') {
                $staff[] = $name;
            }
        }
    }

    $positions = [];
    $qp = mysqli_query($con, "SELECT DISTINCT u.role, u.entryposition
        FROM smart_drug_medrecon_history h
        LEFT JOIN users u ON u.id = h.saved_by
        WHERE $date_where");
    if ($qp) {
        while ($r = mysqli_fetch_assoc($qp)) {
            $pos = sd_mr_hist_position($r['role'] ?? '', $r['entryposition'] ?? '');
            $positions[$pos['key']] = $pos['label'];
        }
    }
    asort($positions);

    $sql = "SELECT h.id, h.hn, h.vn, h.an, h.patient_name, h.saved_name, h.saved_at, h.payload,
            u.role AS user_role, u.entryposition
        FROM smart_drug_medrecon_history h
        LEFT JOIN users u ON u.id = h.saved_by
        WHERE $where
        ORDER BY h.saved_at DESC, h.id DESC
        LIMIT 1000";
    $qr = mysqli_query($con, $sql);
    $items = [];
    if ($qr) {
        while ($r = mysqli_fetch_assoc($qr)) {
            $payload = json_decode((string)($r['payload'] ?? ''), true);
            if (!is_array($payload)) {
                $payload = [];
            }
            $an = sd_mr_hist_resolve_an($r, $payload);
            $visit_vn = sd_mr_hist_resolve_vn($r, $payload, $an);
            if (!sd_mr_hist_visit_match($an_q, $an, $visit_vn, $r, $payload)) {
                continue;
            }
            $visit_rows = [];
            $added_rows = [];
            foreach (($payload['rows'] ?? []) as $drug) {
                if (!is_array($drug)) {
                    continue;
                }
                $name = trim((string)($drug['drug_name'] ?? $drug['drug_text'] ?? ''));
                if ($name === '') {
                    continue;
                }
                $packed = [
                    'drug_name' => $name,
                    'method' => trim((string)($drug['method'] ?? '')),
                    'qty' => (string)($drug['qty'] ?? ''),
                    'units' => trim((string)($drug['units'] ?? '')),
                    'order_date' => trim((string)($drug['order_date'] ?? '')),
                    'hospital_name' => trim((string)($drug['hospital_name'] ?? '')),
                    'vn' => trim((string)($drug['vn'] ?? '')),
                    'visit_key' => trim((string)($drug['visit_key'] ?? '')),
                ];
                if (!empty($drug['is_manual'])) {
                    $added_rows[] = $packed;
                } else {
                    $visit_rows[] = $packed;
                }
            }
            $added_n = count($added_rows);
            $visit_n = count($visit_rows);
            if ($kind === 'added' && $added_n < 1) {
                continue;
            }
            if ($kind === 'visit' && $added_n > 0) {
                continue;
            }
            $pos = sd_mr_hist_position($r['user_role'] ?? '', $r['entryposition'] ?? '');
            $items[] = [
                'id' => (int)$r['id'],
                'hn' => (string)($r['hn'] ?? ''),
                'patient_name' => trim((string)($r['patient_name'] ?? $payload['patient_name'] ?? '')),
                'an' => $an,
                'vn' => $visit_vn,
                'ward' => trim((string)($payload['ward'] ?? '')),
                'service_date' => trim((string)($payload['service_date'] ?? '')),
                'saved_name' => trim((string)($r['saved_name'] ?? '')),
                'position_key' => $pos['key'],
                'position_label' => $pos['label'],
                'saved_at' => (string)($r['saved_at'] ?? ''),
                'saved_at_th' => sd_mr_hist_th($r['saved_at'] ?? ''),
                'visit_count' => $visit_n,
                'added_count' => $added_n,
                'visit_rows' => $visit_rows,
                'added_rows' => $added_rows,
            ];
        }
    }

    $vn_for_dep = [];
    foreach ($items as $it) {
        if ($it['an'] === '' && $it['vn'] !== '') {
            $vn_for_dep[$it['vn']] = true;
        }
    }
    $dep_map = sd_mr_hist_vn_departments($con, array_keys($vn_for_dep));
    foreach ($items as &$it) {
        $it['department'] = '';
        if ($it['an'] === '' && $it['vn'] !== '') {
            $it['department'] = $dep_map[$it['vn']] ?? '';
            if ($it['department'] === '' && $it['ward'] !== '') {
                $it['department'] = $it['ward'];
            }
        }
    }
    unset($it);

    $groups = [];
    foreach ($items as $it) {
        if ($group_by === 'staff') {
            $key = $it['saved_name'] !== '' ? $it['saved_name'] : 'ไม่ระบุผู้ทำ';
            $label = $key;
        } elseif ($group_by === 'position') {
            $key = 'pos:' . $it['position_key'];
            $label = $it['position_label'];
        } elseif ($it['an'] !== '') {
            $key = 'an:' . $it['an'];
            $label = 'AN ' . $it['an'];
        } elseif ($it['vn'] !== '') {
            $key = 'vn:' . $it['vn'];
            $label = 'VN ' . $it['vn'];
        } else {
            $key = 'id:' . $it['id'];
            $label = 'ไม่ระบุ AN / VN';
        }
        if (!isset($groups[$key])) {
            $groups[$key] = [
                'key' => $key,
                'label' => $label,
                'an' => $group_by === 'an' ? $it['an'] : '',
                'latest' => $it['saved_at'],
                'latest_th' => $it['saved_at_th'],
                'patient_name' => $it['patient_name'],
                'hn' => $it['hn'],
                'ward' => $it['ward'],
                'items' => [],
            ];
        }
        $groups[$key]['items'][] = $it;
        if ($it['saved_at'] > $groups[$key]['latest']) {
            $groups[$key]['latest'] = $it['saved_at'];
            $groups[$key]['latest_th'] = $it['saved_at_th'];
            $groups[$key]['patient_name'] = $it['patient_name'];
            $groups[$key]['hn'] = $it['hn'];
            $groups[$key]['ward'] = $it['ward'];
        }
    }
    $group_list = array_values($groups);
    usort($group_list, function ($a, $b) {
        return strcmp((string)$b['latest'], (string)$a['latest']);
    });

    $added_rows = 0;
    $visit_rows = 0;
    $with_added = 0;
    $visit_only = 0;
    $an_set = [];
    $vn_set = [];
    $hn_set = [];
    $hn_an = [];
    $hn_vn = [];
    $by_staff = [];
    $by_day = [];
    $by_ward = [];
    $by_department = [];
    $by_position = [];
    foreach ($items as $it) {
        $added_rows += $it['added_count'];
        $visit_rows += $it['visit_count'];
        if ($it['added_count'] > 0) {
            $with_added++;
        } else {
            $visit_only++;
        }
        if ($it['an'] !== '') {
            $an_set[$it['an']] = true;
        }
        if ($it['vn'] !== '') {
            $vn_set[$it['vn']] = true;
        }
        $hn_key = sd_mr_hist_norm($it['hn'] ?? '');
        if ($hn_key !== '') {
            $hn_set[$hn_key] = true;
            if ($it['an'] !== '') {
                $hn_an[$hn_key] = true;
            }
            if ($it['vn'] !== '') {
                $hn_vn[$hn_key] = true;
            }
        }
        $who = $it['saved_name'] !== '' ? $it['saved_name'] : 'ไม่ระบุผู้ทำ';
        if (!isset($by_staff[$who])) {
            $by_staff[$who] = [
                'name' => $who,
                'position' => $it['position_label'],
                'cases' => 0,
                'added_cases' => 0,
                'visit_rows' => 0,
                'added_rows' => 0,
                'patients' => [],
            ];
        }
        $by_staff[$who]['cases']++;
        $by_staff[$who]['visit_rows'] += $it['visit_count'];
        $by_staff[$who]['added_rows'] += $it['added_count'];
        if ($it['added_count'] > 0) {
            $by_staff[$who]['added_cases']++;
        }
        if ($hn_key !== '') {
            $by_staff[$who]['patients'][$hn_key] = true;
        }
        $day = substr((string)$it['saved_at'], 0, 10);
        if ($day !== '') {
            if (!isset($by_day[$day])) {
                $by_day[$day] = ['date' => $day, 'cases' => 0, 'added_cases' => 0];
            }
            $by_day[$day]['cases']++;
            if ($it['added_count'] > 0) {
                $by_day[$day]['added_cases']++;
            }
        }
        if ($it['an'] !== '') {
            $ward = $it['ward'] !== '' ? $it['ward'] : 'ไม่ระบุหอ';
            if (!isset($by_ward[$ward])) {
                $by_ward[$ward] = ['name' => $ward, 'cases' => 0];
            }
            $by_ward[$ward]['cases']++;
        } elseif ($it['vn'] !== '') {
            $dep = trim((string)($it['department'] ?? ''));
            if ($dep === '') {
                $dep = 'ไม่ระบุแผนก';
            }
            if (!isset($by_department[$dep])) {
                $by_department[$dep] = ['name' => $dep, 'cases' => 0];
            }
            $by_department[$dep]['cases']++;
        }
        $pkey = $it['position_key'];
        if (!isset($by_position[$pkey])) {
            $by_position[$pkey] = [
                'key' => $pkey,
                'name' => $it['position_label'],
                'cases' => 0,
                'added_cases' => 0,
                'patients' => [],
                'staff' => [],
            ];
        }
        $by_position[$pkey]['cases']++;
        if ($it['added_count'] > 0) {
            $by_position[$pkey]['added_cases']++;
        }
        if ($hn_key !== '') {
            $by_position[$pkey]['patients'][$hn_key] = true;
        }
        $by_position[$pkey]['staff'][$who] = true;
    }
    $staff_rows = array_values($by_staff);
    foreach ($staff_rows as &$sr) {
        $sr['patients'] = count($sr['patients']);
    }
    unset($sr);
    usort($staff_rows, function ($a, $b) {
        if ((int)$b['cases'] !== (int)$a['cases']) {
            return (int)$b['cases'] - (int)$a['cases'];
        }
        return strcmp((string)$a['name'], (string)$b['name']);
    });
    $day_rows = array_values($by_day);
    usort($day_rows, function ($a, $b) {
        return strcmp((string)$a['date'], (string)$b['date']);
    });
    $ward_rows = array_values($by_ward);
    usort($ward_rows, function ($a, $b) {
        return (int)$b['cases'] - (int)$a['cases'];
    });
    $department_rows = array_values($by_department);
    usort($department_rows, function ($a, $b) {
        return (int)$b['cases'] - (int)$a['cases'];
    });
    $position_rows = array_values($by_position);
    foreach ($position_rows as &$pr) {
        $pr['patients'] = count($pr['patients']);
        $pr['staff'] = count($pr['staff']);
    }
    unset($pr);
    usort($position_rows, function ($a, $b) {
        if ((int)$b['cases'] !== (int)$a['cases']) {
            return (int)$b['cases'] - (int)$a['cases'];
        }
        return strcmp((string)$a['name'], (string)$b['name']);
    });
    $position_opts = [];
    foreach ($positions as $pkey => $plabel) {
        $position_opts[] = ['key' => $pkey, 'label' => $plabel];
    }

    return [
        'status' => 'success',
        'staff' => $staff,
        'positions' => $position_opts,
        'days' => $days,
        'date_from' => $date_from,
        'date_to' => $date_to,
        'group' => $group_by,
        'summary' => [
            'records' => count($items),
            'groups' => count($group_list),
            'ans' => count($an_set),
            'vns' => count($vn_set),
            'patients' => count($hn_an) + count($hn_vn),
            'patients_unique' => count($hn_set),
            'patients_an' => count($hn_an),
            'patients_vn' => count($hn_vn),
            'staff' => count($staff_rows),
            'positions' => count($position_rows),
            'with_added' => $with_added,
            'visit_only' => $visit_only,
            'added_rows' => $added_rows,
            'visit_rows' => $visit_rows,
        ],
        'dashboard' => [
            'by_staff' => $staff_rows,
            'by_day' => $day_rows,
            'by_ward' => array_slice($ward_rows, 0, 8),
            'by_department' => array_slice($department_rows, 0, 8),
            'by_position' => $position_rows,
        ],
        'groups' => $group_list,
    ];
}

function sd_mr_hist_update($con, array $input) {
    sd_mr_hist_ensure($con);
    $raw = trim((string)($input['id'] ?? ''));
    if (strpos($raw, 'local:') === 0) {
        $raw = substr($raw, 6);
    }
    $nid = (int)$raw;
    if ($nid <= 0) {
        return ['status' => 'error', 'message' => 'ไม่พบประวัติ'];
    }
    $q = mysqli_query($con, "SELECT id, hn, vn, an, saved_name, payload
        FROM smart_drug_medrecon_history WHERE id=$nid LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return ['status' => 'error', 'message' => 'ไม่พบประวัติที่จะแก้ไข'];
    }
    $payload = json_decode((string)($row['payload'] ?? ''), true);
    if (!is_array($payload)) {
        $payload = [];
    }
    $in = $input['fields'] ?? [];
    if (!is_array($in)) {
        $in = [];
    }
    foreach (['patient_name', 'ward', 'note_mr', 'service_date'] as $k) {
        if (array_key_exists($k, $in)) {
            $payload[$k] = trim((string)$in[$k]);
        }
    }
    $hn = trim((string)($in['hn'] ?? $payload['hn'] ?? $row['hn'] ?? ''));
    if ($hn === '') {
        return ['status' => 'error', 'message' => 'กรุณาระบุ HN'];
    }
    $payload['hn'] = $hn;
    $an = trim((string)($in['an'] ?? ''));
    $old_an = sd_mr_hist_resolve_an($row, $payload);
    $vn = trim((string)($payload['vn'] ?? $row['vn'] ?? ''));
    if ($an !== '') {
        $payload['an'] = $an;
        if ($vn === '' || $vn === $old_an || preg_match('/^\d{8,10}$/', $vn)) {
            $vn = $an;
            $payload['vn'] = $an;
        }
    }
    $rows_in = $in['rows'] ?? null;
    if (!is_array($rows_in)) {
        return ['status' => 'error', 'message' => 'ไม่มีรายการยา'];
    }
    $old_rows = (isset($payload['rows']) && is_array($payload['rows'])) ? $payload['rows'] : [];
    $new_rows = [];
    foreach ($rows_in as $i => $drug) {
        if (!is_array($drug)) {
            continue;
        }
        $name = trim((string)($drug['drug_name'] ?? ''));
        if ($name === '') {
            continue;
        }
        $src = isset($drug['src_index']) ? (int)$drug['src_index'] : -1;
        $base = ($src >= 0 && isset($old_rows[$src]) && is_array($old_rows[$src])) ? $old_rows[$src] : [];
        $method = trim((string)($drug['method'] ?? ''));
        $base['drug_name'] = $name;
        $base['method'] = $method;
        $base['drug_text'] = $method !== '' ? ($name . "\n" . $method) : $name;
        $base['qty'] = trim((string)($drug['qty'] ?? ''));
        $base['units'] = trim((string)($drug['units'] ?? ''));
        $base['order_date'] = trim((string)($drug['order_date'] ?? ''));
        $base['hospital_name'] = trim((string)($drug['hospital_name'] ?? ''));
        $base['is_manual'] = !empty($drug['is_manual']);
        $new_rows[] = $base;
    }
    if (!$new_rows) {
        return ['status' => 'error', 'message' => 'ต้องมีรายการยาอย่างน้อย 1 รายการ'];
    }
    $payload['rows'] = $new_rows;
    $saved_name = trim((string)($in['saved_name'] ?? $row['saved_name'] ?? ''));
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($json === false || strlen($json) > 900000) {
        return ['status' => 'error', 'message' => 'บันทึกข้อมูลไม่ได้'];
    }
    $fp = sd_mr_hist_fingerprint($payload);
    $norm = sd_mr_hist_norm($hn);
    $an_save = $an !== '' ? $an : trim((string)($row['an'] ?? ''));
    $esc = function ($v) use ($con) {
        return mysqli_real_escape_string($con, (string)$v);
    };
    $ok = mysqli_query($con, "UPDATE smart_drug_medrecon_history SET
        hn='" . $esc(sd_mr_hist_cut($hn, 20)) . "',
        hn_norm='" . $esc($norm) . "',
        vn='" . $esc(sd_mr_hist_cut($vn, 30)) . "',
        an='" . $esc(sd_mr_hist_cut($an_save, 30)) . "',
        patient_name='" . $esc(sd_mr_hist_cut($payload['patient_name'] ?? '', 255)) . "',
        drug_count=" . count($new_rows) . ",
        fingerprint='" . $esc($fp) . "',
        saved_name='" . $esc(sd_mr_hist_cut($saved_name, 150)) . "',
        payload='" . $esc($json) . "'
        WHERE id=$nid LIMIT 1");
    if (!$ok) {
        return ['status' => 'error', 'message' => 'แก้ไขประวัติไม่สำเร็จ'];
    }
    return ['status' => 'success', 'id' => $nid];
}

if ($action === 'history_list') {
    $hn = trim((string)($input['hn'] ?? ''));
    $items = sd_mr_hist_list($con, $con_hosxp, $hn);
    echo json_encode([
        'status' => 'success',
        'items' => $items,
        'latest' => $items[0] ?? null,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'history_get') {
    $id = trim((string)($input['id'] ?? ''));
    if (strpos($id, 'local:') === 0) {
        sd_mr_hist_ensure($con);
        $nid = (int)substr($id, 6);
        $q = mysqli_query($con, "SELECT payload, saved_at, saved_name FROM smart_drug_medrecon_history WHERE id=$nid LIMIT 1");
        $row = $q ? mysqli_fetch_assoc($q) : null;
        if (!$row) {
            echo json_encode(['status' => 'error', 'message' => 'ไม่พบประวัติ']);
            exit;
        }
        $payload = json_decode((string)$row['payload'], true);
        if (!is_array($payload)) {
            $payload = [];
        }
        echo json_encode([
            'status' => 'success',
            'source' => 'smart_drug',
            'saved_at_th' => sd_mr_hist_th($row['saved_at']),
            'saved_name' => (string)$row['saved_name'],
            'payload' => $payload,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (strpos($id, 'hosxp:') === 0 && $con_hosxp) {
        $nid = (int)substr($id, 6);
        $q = @mysqli_query($con_hosxp, "SELECT mr.an, mr.note, i.hn, i.vn, i.regdate,
                p.pname, p.fname, p.lname
            FROM medication_reconciliation mr
            INNER JOIN ipt i ON i.an = mr.an
            LEFT JOIN patient p ON p.hn = i.hn
            WHERE mr.medication_reconciliation_id = $nid
            LIMIT 1");
        $head = $q ? mysqli_fetch_assoc($q) : null;
        if (!$head) {
            echo json_encode(['status' => 'error', 'message' => 'ไม่พบประวัติ HOSxP']);
            exit;
        }
        $rows = [];
        $qd = @mysqli_query($con_hosxp, "SELECT medication_name, usage_name, qty, last_receive_date, receive_location, first_entry_date
            FROM medication_reconciliation_detail
            WHERE medication_reconciliation_id = $nid
            ORDER BY medication_reconciliation_detail_id ASC");
        $latest = '';
        if ($qd) {
            while ($d = mysqli_fetch_assoc($qd)) {
                $entry = trim((string)($d['first_entry_date'] ?? ''));
                if ($entry !== '' && $entry > $latest) {
                    $latest = $entry;
                }
                $rows[] = [
                    'drug_name' => trim((string)($d['medication_name'] ?? '')),
                    'method' => trim((string)($d['usage_name'] ?? '')),
                    'qty' => (string)($d['qty'] ?? ''),
                    'order_date' => sd_mr_hist_th($d['last_receive_date'] ?? ''),
                    'hospital_name' => trim((string)($d['receive_location'] ?? '')),
                ];
            }
        }
        $name = trim(trim((string)($head['pname'] ?? '')) . trim((string)($head['fname'] ?? '')) . ' ' . trim((string)($head['lname'] ?? '')));
        echo json_encode([
            'status' => 'success',
            'source' => 'hosxp',
            'saved_at_th' => sd_mr_hist_th($latest !== '' ? $latest : ($head['regdate'] ?? '')),
            'saved_name' => '',
            'payload' => [
                'patient_name' => $name,
                'hn' => (string)($head['hn'] ?? ''),
                'vn' => trim((string)($head['vn'] ?? '') . ' ' . (string)($head['an'] ?? '')),
                'an' => (string)($head['an'] ?? ''),
                'note_mr' => trim((string)($head['note'] ?? '')),
                'rows' => $rows,
            ],
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode(['status' => 'error', 'message' => 'ไม่พบประวัติ']);
    exit;
}

if ($action === 'history_delete') {
    sd_mr_hist_ensure($con);
    $confirm = trim((string)($input['confirm'] ?? ''));
    if ($confirm !== 'delete') {
        echo json_encode(['status' => 'error', 'message' => 'ต้องพิมพ์ delete เพื่อยืนยัน']);
        exit;
    }
    $id = trim((string)($input['id'] ?? ''));
    if (strpos($id, 'local:') !== 0) {
        echo json_encode(['status' => 'error', 'message' => 'ลบได้เฉพาะประวัติที่บันทึกจาก Smart Drug']);
        exit;
    }
    $nid = (int)substr($id, 6);
    if ($nid <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบประวัติ']);
        exit;
    }
    $ok = mysqli_query($con, "DELETE FROM smart_drug_medrecon_history WHERE id=$nid LIMIT 1");
    if (!$ok || mysqli_affected_rows($con) < 1) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบประวัติที่จะลบ']);
        exit;
    }
    echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'history_save') {
    sd_mr_hist_ensure($con);
    $payload = $input['payload'] ?? null;
    if (!is_array($payload)) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีข้อมูลใบ Med Reconciliation']);
        exit;
    }
    $hn = trim((string)($payload['hn'] ?? $input['hn'] ?? ''));
    $norm = sd_mr_hist_norm($hn);
    if ($norm === '') {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบ HN']);
        exit;
    }
    $rows = [];
    foreach (($payload['rows'] ?? []) as $row) {
        if (!is_array($row)) {
            continue;
        }
        $name = trim((string)($row['drug_name'] ?? $row['drug_text'] ?? ''));
        if ($name === '') {
            continue;
        }
        $rows[] = $row;
    }
    if (!$rows) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีรายการยา']);
        exit;
    }
    $payload['rows'] = $rows;
    $payload['hn'] = $hn;
    $fp = sd_mr_hist_fingerprint($payload);
    $esc_norm = mysqli_real_escape_string($con, $norm);
    $esc_fp = mysqli_real_escape_string($con, $fp);
    $edit_id = trim((string)($input['id'] ?? ''));
    if (strpos($edit_id, 'local:') === 0) {
        $nid = (int)substr($edit_id, 6);
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
        if ($json === false || strlen($json) > 900000) {
            echo json_encode(['status' => 'error', 'message' => 'ข้อมูลใหญ่เกินไป']);
            exit;
        }
        $vn = mb_substr(trim((string)($payload['vn'] ?? '')), 0, 30);
        $an = mb_substr(trim((string)($payload['an'] ?? '')), 0, 30);
        $pname = mb_substr(trim((string)($payload['patient_name'] ?? '')), 0, 255);
        $sname = mb_substr(trim((string)($_SESSION['full_name'] ?? $payload['pharmacist_name'] ?? '')), 0, 150);
        $saved_at = date('Y-m-d H:i:s');
        $own = mysqli_query($con, "SELECT id FROM smart_drug_medrecon_history WHERE id=$nid AND hn_norm='$esc_norm' LIMIT 1");
        if (!$own || !mysqli_fetch_assoc($own)) {
            echo json_encode(['status' => 'error', 'message' => 'ไม่พบประวัติที่จะแก้ไข']);
            exit;
        }
        $ok = mysqli_query($con, "UPDATE smart_drug_medrecon_history SET
            vn='" . mysqli_real_escape_string($con, $vn) . "',
            an='" . mysqli_real_escape_string($con, $an) . "',
            patient_name='" . mysqli_real_escape_string($con, $pname) . "',
            drug_count=" . count($rows) . ",
            fingerprint='$esc_fp',
            saved_name='" . mysqli_real_escape_string($con, $sname) . "',
            saved_at='" . mysqli_real_escape_string($con, $saved_at) . "',
            payload='" . mysqli_real_escape_string($con, $json) . "'
            WHERE id=$nid AND hn_norm='$esc_norm' LIMIT 1");
        if (!$ok) {
            echo json_encode(['status' => 'error', 'message' => 'แก้ไขประวัติไม่สำเร็จ']);
            exit;
        }
        echo json_encode([
            'status' => 'success',
            'id' => 'local:' . $nid,
            'updated' => true,
            'saved_at_th' => sd_mr_hist_th($saved_at),
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $dup = mysqli_query($con, "SELECT id, saved_at FROM smart_drug_medrecon_history
        WHERE hn_norm='$esc_norm' AND fingerprint='$esc_fp'
        ORDER BY id DESC LIMIT 1");
    if ($dup && ($exist = mysqli_fetch_assoc($dup))) {
        echo json_encode([
            'status' => 'success',
            'id' => 'local:' . (int)$exist['id'],
            'duplicate' => true,
            'saved_at_th' => sd_mr_hist_th($exist['saved_at']),
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $saved_raw = trim((string)($input['saved_at'] ?? ''));
    $ts = $saved_raw !== '' ? strtotime($saved_raw) : false;
    $saved_at = ($ts && $ts > 0) ? date('Y-m-d H:i:s', $ts) : date('Y-m-d H:i:s');
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($json === false || strlen($json) > 900000) {
        echo json_encode(['status' => 'error', 'message' => 'ข้อมูลใหญ่เกินไป']);
        exit;
    }
    $vn = mb_substr(trim((string)($payload['vn'] ?? '')), 0, 30);
    $an = mb_substr(trim((string)($payload['an'] ?? '')), 0, 30);
    $pname = mb_substr(trim((string)($payload['patient_name'] ?? '')), 0, 255);
    $sname = mb_substr(trim((string)($_SESSION['full_name'] ?? $payload['pharmacist_name'] ?? '')), 0, 150);
    $uid = (int)($_SESSION['user_id'] ?? 0);
    $uid_sql = $uid > 0 ? (string)$uid : 'NULL';
    $ok = mysqli_query($con, "INSERT INTO smart_drug_medrecon_history
        (hn, hn_norm, vn, an, patient_name, drug_count, fingerprint, saved_by, saved_name, saved_at, payload)
        VALUES (
            '" . mysqli_real_escape_string($con, mb_substr($hn, 0, 20)) . "',
            '$esc_norm',
            '" . mysqli_real_escape_string($con, $vn) . "',
            '" . mysqli_real_escape_string($con, $an) . "',
            '" . mysqli_real_escape_string($con, $pname) . "',
            " . count($rows) . ",
            '$esc_fp',
            $uid_sql,
            '" . mysqli_real_escape_string($con, $sname) . "',
            '" . mysqli_real_escape_string($con, $saved_at) . "',
            '" . mysqli_real_escape_string($con, $json) . "'
        )");
    if (!$ok) {
        echo json_encode(['status' => 'error', 'message' => 'บันทึกประวัติไม่สำเร็จ']);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'id' => 'local:' . (int)mysqli_insert_id($con),
        'saved_at_th' => sd_mr_hist_th($saved_at),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ค้นหาแพทย์จากตาราง doctor ใน HOSxP
if ($action === 'search_doctor') {
    $term = trim((string)($input['q'] ?? $input['term'] ?? ''));
    $results = [];
    if ($term !== '') {
        $esc = mysqli_real_escape_string($con_hosxp, $term);
        $like = '%' . $esc . '%';
        $sql = "
            SELECT doc.code,
                   " . sd_mr_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . " AS doctor_name
            FROM doctor doc
            WHERE doc.name LIKE '$like'
               OR doc.code LIKE '$like'
               OR CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,'')) LIKE '$like'
            ORDER BY doc.name ASC
            LIMIT 40
        ";
        $q = @mysqli_query($con_hosxp, $sql);
        if (!$q) {
            $q = @mysqli_query($con_hosxp, "
                SELECT code, name AS doctor_name
                FROM doctor
                WHERE name LIKE '$like' OR code LIKE '$like'
                ORDER BY name ASC
                LIMIT 40
            ");
        }
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $name = trim((string)($r['doctor_name'] ?? ''));
                $code = trim((string)($r['code'] ?? ''));
                if ($name === '') {
                    continue;
                }
                $results[] = [
                    'code' => $code,
                    'name' => $name,
                    'text' => $name . ($code !== '' ? ' (' . $code . ')' : ''),
                ];
            }
        }
    }
    mysqli_close($con_hosxp);
    echo json_encode(['status' => 'success', 'results' => $results], JSON_UNESCAPED_UNICODE);
    exit;
}

// ค้นหายา + วิธีใช้จาก HOSxP
if ($action === 'search_drug') {
    $term = trim((string)($input['q'] ?? $input['term'] ?? ''));
    $hn_for_usage = trim((string)($input['hn'] ?? ''));
    $results = [];
    if ($term !== '') {
        $drugs = function_exists('hosxp_search_drugs_tmt')
            ? hosxp_search_drugs_tmt($con_hosxp, $term, 30)
            : [];
        foreach ($drugs as $d) {
            $icode = trim((string)($d['icode'] ?? ''));
            if ($icode === '') {
                continue;
            }
            $icode_esc = mysqli_real_escape_string($con_hosxp, $icode);
            $strength = '';
            $units = '';
            $method = '';
            $last_qty = '';

            $qd = @mysqli_query($con_hosxp, "
                SELECT
                    CAST(CONVERT(IFNULL(d.strength,'') USING utf8) AS CHAR) AS strength,
                    CAST(CONVERT(IFNULL(d.units,'') USING utf8) AS CHAR) AS units,
                    CAST(CONVERT(CONCAT(IFNULL(du.name1,''), ' ', IFNULL(du.name2,''), ' ', IFNULL(du.name3,'')) USING utf8) AS CHAR) AS method_default
                FROM drugitems d
                LEFT JOIN drugusage du ON du.drugusage = d.drugusage
                WHERE d.icode = '$icode_esc'
                LIMIT 1
            ");
            if ($qd && ($dr = mysqli_fetch_assoc($qd))) {
                $strength = trim((string)($dr['strength'] ?? ''));
                $units = trim((string)($dr['units'] ?? ''));
                $method = trim(preg_replace('/\s+/', ' ', (string)($dr['method_default'] ?? '')));
            }

            // ถ้ามี HN — ใช้วิธีใช้ล่าสุดของผู้ป่วยรายนี้ก่อน
            if ($hn_for_usage !== '') {
                $hn_in = sd_mr_hn_in($con_hosxp, $hn_for_usage);
                if ($hn_in !== '') {
                    $last_qty = '';
                    $qm = @mysqli_query($con_hosxp, "
                        SELECT CAST(CONVERT(
                            IF(o.sp_use <> '' AND o.sp_use IS NOT NULL,
                               CONCAT(IFNULL(sp.name1,''), ' ', IFNULL(sp.name2,''), ' ', IFNULL(sp.name3,'')),
                               CONCAT(IFNULL(du.name1,''), ' ', IFNULL(du.name2,''), ' ', IFNULL(du.name3,''))
                            ) USING utf8
                        ) AS CHAR) AS method,
                        o.qty
                        FROM opitemrece o
                        LEFT JOIN drugusage du ON du.drugusage = o.drugusage
                        LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
                        WHERE o.hn IN ($hn_in) AND o.icode = '$icode_esc'
                        ORDER BY o.vstdate DESC, o.vsttime DESC
                        LIMIT 1
                    ");
                    if ($qm && ($mr = mysqli_fetch_assoc($qm))) {
                        $m2 = trim(preg_replace('/\s+/', ' ', (string)($mr['method'] ?? '')));
                        if ($m2 !== '') {
                            $method = $m2;
                        }
                        if (isset($mr['qty']) && $mr['qty'] !== '' && $mr['qty'] !== null) {
                            $last_qty = $mr['qty'];
                        }
                    }
                }
            }

            $name_tmt = trim((string)($d['name_tmt'] ?? ''));
            $name_local = trim((string)($d['name_local'] ?? ''));
            $display = $name_tmt !== '' ? $name_tmt : $name_local;
            if ($strength !== '' && stripos($display, $strength) === false) {
                $display = trim($display . ' ' . $strength);
            }
            if ($units !== '' && stripos($display, $units) === false) {
                $display = trim($display . ' ' . $units);
            }
            $label = $name_local !== '' ? $name_local : $display;
            if ($name_tmt !== '' && $name_tmt !== $name_local) {
                $label .= ' — ' . $name_tmt;
            }
            $label .= ' (icode: ' . $icode . ')';

            $results[] = [
                'icode' => $icode,
                'name' => $display,
                'name_local' => $name_local,
                'name_tmt' => $name_tmt,
                'strength' => $strength,
                'units' => $units,
                'method' => $method,
                'qty' => $last_qty,
                'text' => $label,
            ];
        }
    }
    mysqli_close($con_hosxp);
    echo json_encode(['status' => 'success', 'results' => $results], JSON_UNESCAPED_UNICODE);
    exit;
}

// ค้นรหัสวิธีใช้ HOSxP (drugusage.code) เช่น 13pt
if ($action === 'search_usage') {
    $term = trim((string)($input['q'] ?? $input['term'] ?? ''));
    $term = preg_replace('/\s+/u', ' ', $term);
    $results = [];
    if ($term !== '') {
        $esc = mysqli_real_escape_string($con_hosxp, $term);
        $like = str_replace(['%', '_'], ['\\%', '\\_'], $esc);
        $utf = function ($expr) {
            return "CAST(CONVERT(IFNULL($expr,'') USING utf8) AS CHAR)";
        };
        $sql = "
            SELECT du.drugusage,
                   " . $utf('du.code') . " AS code,
                   " . $utf('du.name1') . " AS name1,
                   " . $utf('du.name2') . " AS name2,
                   " . $utf('du.name3') . " AS name3,
                   IFNULL(du.status,'') AS status
            FROM drugusage du
            WHERE du.code LIKE '$like%'
               OR du.shortlist LIKE '$like%'
               OR du.code LIKE '%$like%'
               OR du.name1 LIKE '%$like%'
               OR du.name2 LIKE '%$like%'
               OR du.name3 LIKE '%$like%'
            ORDER BY
                (LOWER(TRIM(du.code)) = LOWER('$esc')) DESC,
                (du.code LIKE '$like%') DESC,
                (IFNULL(du.status,'') = 'Y') DESC,
                CHAR_LENGTH(du.code) ASC,
                du.code ASC
            LIMIT 20
        ";
        $q = @mysqli_query($con_hosxp, $sql);
        if ($q) {
            $seen = [];
            while ($r = mysqli_fetch_assoc($q)) {
                $lines = [];
                foreach (['name1', 'name2', 'name3'] as $k) {
                    $line = trim(preg_replace('/\s+/u', ' ', (string)($r[$k] ?? '')));
                    if ($line !== '') {
                        $lines[] = $line;
                    }
                }
                $text = trim(implode(' ', $lines));
                $code = trim((string)($r['code'] ?? ''));
                if ($code === '') {
                    $code = trim((string)($r['drugusage'] ?? ''));
                }
                if ($text === '' || $code === '') {
                    continue;
                }
                $dedupe = $code . '|' . $text;
                if (isset($seen[$dedupe])) {
                    continue;
                }
                $seen[$dedupe] = true;
                $results[] = [
                    'code' => $code,
                    'drugusage' => trim((string)($r['drugusage'] ?? '')),
                    'text' => $text,
                    'active' => (($r['status'] ?? '') === 'Y'),
                ];
            }
        }
    }
    mysqli_close($con_hosxp);
    echo json_encode(['status' => 'success', 'results' => $results], JSON_UNESCAPED_UNICODE);
    exit;
}

$hn = trim((string)($input['hn'] ?? ''));
$an = trim((string)($input['an'] ?? ''));
$vn = trim((string)($input['vn'] ?? ''));

if ($hn === '' && $an === '' && $vn === '') {
    mysqli_close($con_hosxp);
    echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ HN, AN หรือ VN']);
    exit;
}

/** ชื่อหอจาก ipt.ward (โรงพยาบาลนี้ iptadm ไม่มีคอลัมน์ ward) */
function sd_mr_ward_select_sql() {
    return sd_mr_utf8("IFNULL(w.name, '')") . ' AS ward_name';
}

function sd_mr_ward_joins_sql() {
    return "
        LEFT JOIN ward w ON w.ward = i.ward
    ";
}

if ($hn === '' && $an !== '') {
    $an_esc = mysqli_real_escape_string($con_hosxp, $an);
    $qh = @mysqli_query($con_hosxp, "SELECT hn FROM ipt WHERE an='$an_esc' LIMIT 1");
    if ($qh && ($hr = mysqli_fetch_assoc($qh))) {
        $hn = trim($hr['hn'] ?? '');
    }
}
if ($hn === '' && $vn !== '') {
    $vn_esc = mysqli_real_escape_string($con_hosxp, $vn);
    $qv = @mysqli_query($con_hosxp, "SELECT hn FROM ovst WHERE vn='$vn_esc' LIMIT 1");
    if ($qv && ($vr = mysqli_fetch_assoc($qv))) {
        $hn = trim($vr['hn'] ?? '');
    }
}

$hn_sql = sd_mr_hn_in($con_hosxp, $hn);
if ($hn_sql === '') {
    mysqli_close($con_hosxp);
    echo json_encode(['status' => 'error', 'message' => 'ไม่พบ HN']);
    exit;
}

$patient = null;
$sql_p = "
    SELECT p.hn, p.cid, p.sex, p.birthday,
           TIMESTAMPDIFF(YEAR, p.birthday, CURDATE()) AS age_y,
           " . sd_mr_utf8('p.pname') . " AS pname,
           " . sd_mr_utf8('p.fname') . " AS fname,
           " . sd_mr_utf8('p.lname') . " AS lname
    FROM patient p
    WHERE p.hn IN ($hn_sql)
    LIMIT 1
";
$qp = @mysqli_query($con_hosxp, $sql_p);
if ($qp && ($p = mysqli_fetch_assoc($qp))) {
    $sex_raw = trim((string)($p['sex'] ?? ''));
    $sex = ($sex_raw === '1' || strcasecmp($sex_raw, 'M') === 0) ? 'M'
        : (($sex_raw === '2' || strcasecmp($sex_raw, 'F') === 0) ? 'F' : '');
    $birthday = trim((string)($p['birthday'] ?? ''));
    if ($birthday === '0000-00-00') {
        $birthday = '';
    }
    $patient = [
        'hn' => $p['hn'],
        'cid' => preg_replace('/\D+/', '', (string)($p['cid'] ?? '')),
        'pname' => trim($p['pname'] ?? ''),
        'fname' => trim($p['fname'] ?? ''),
        'lname' => trim($p['lname'] ?? ''),
        'full_name' => trim(($p['pname'] ?? '') . ($p['fname'] ?? '') . ' ' . ($p['lname'] ?? '')),
        'sex' => $sex,
        'birthday' => $birthday,
        'age_y' => isset($p['age_y']) ? (int)$p['age_y'] : null,
    ];
    $hn = $p['hn'];
}

// ประวัติแพ้ยาจาก HOSxP
$allergy_agents = [];
$sql_al = "
    SELECT " . sd_mr_utf8("IFNULL(agent,'')") . " AS agent,
           " . sd_mr_utf8("IFNULL(symptom,'')") . " AS symptom,
           report_date
    FROM opd_allergy
    WHERE hn IN ($hn_sql)
    ORDER BY report_date DESC
    LIMIT 30
";
$qa = @mysqli_query($con_hosxp, $sql_al);
if (!$qa) {
    // fallback ไม่ใช้ CONVERT
    $qa = @mysqli_query($con_hosxp, "
        SELECT agent, symptom, report_date
        FROM opd_allergy
        WHERE hn IN ($hn_sql)
        ORDER BY report_date DESC
        LIMIT 30
    ");
}
if ($qa) {
    while ($ar = mysqli_fetch_assoc($qa)) {
        $agent = trim((string)($ar['agent'] ?? ''));
        if ($agent === '' || preg_match('/^(NKA|NKDA|ไม่มี|ไม่แพ้|none)$/iu', $agent)) {
            continue;
        }
        $label = sd_mr_allergy_with_symptom($agent, $ar['symptom'] ?? '');
        if (!in_array($label, $allergy_agents, true)) {
            $allergy_agents[] = $label;
        }
    }
}
$allergy_text = implode(', ', $allergy_agents);
$has_allergy = $allergy_text !== '';

$patient_cid = is_array($patient) ? preg_replace('/\D+/', '', (string)($patient['cid'] ?? '')) : '';
$allergy_extra = [];
if (function_exists('hds_fetch_allergy_network')) {
    try {
        $net = hds_fetch_allergy_network($con, hds_hn_variants($hn), $patient_cid);
        foreach ($net['rows'] ?? [] as $row) {
            if (is_array($row)) {
                $allergy_extra[] = $row;
            }
        }
    } catch (Throwable $e) {
    }
}
if (function_exists('jhcis_fetch_allergy') && strlen($patient_cid) === 13) {
    try {
        $jhcis_al = jhcis_fetch_allergy($con, $patient_cid);
        foreach ($jhcis_al['rows'] ?? [] as $row) {
            if (is_array($row)) {
                $allergy_extra[] = $row;
            }
        }
    } catch (Throwable $e) {
    }
}
if ($allergy_extra) {
    $merged = sd_mr_merge_allergy($allergy_agents, $allergy_extra);
    $allergy_agents = $merged['agents'];
    $allergy_text = $merged['text'];
    $has_allergy = $allergy_text !== '';
}

$visit = [
    'an' => $an,
    'vn' => $vn,
    'visit_type' => '',
    'doctor_code' => '',
    'doctor_name' => '',
    'ward_name' => '',
    'department_name' => '',
    'service_date' => '',
    'service_time' => '',
    'admit_date' => '',
    'admit_time' => '',
];

$ward_sel = sd_mr_ward_select_sql();
$ward_join = sd_mr_ward_joins_sql();
$doc_name = sd_mr_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . ' AS doctor_name';
$sp_name = sd_mr_utf8("IFNULL(sp.name,'')") . ' AS department_name';

function sd_mr_fill_ipd_row(array &$visit, array $row, &$patient) {
    $visit['visit_type'] = 'ipd';
    $visit['an'] = $row['an'] ?? ($visit['an'] ?? '');
    $visit['doctor_code'] = trim($row['admdoctor'] ?? '');
    $visit['doctor_name'] = trim($row['doctor_name'] ?? '');
    $visit['ward_name'] = trim($row['ward_name'] ?? '');
    $visit['department_name'] = trim($row['department_name'] ?? '');
    $visit['admit_date'] = (($row['regdate'] ?? '') !== '0000-00-00') ? ($row['regdate'] ?? '') : '';
    $visit['admit_time'] = substr(trim((string)($row['regtime'] ?? '')), 0, 8);
    $visit['service_date'] = $visit['admit_date'];
    $visit['service_time'] = $visit['admit_time'];
    if ($patient && empty($patient['hn']) && !empty($row['hn'])) {
        $patient['hn'] = $row['hn'];
    }
}

if ($an !== '') {
    $an_esc = mysqli_real_escape_string($con_hosxp, $an);
    $sql_i = "
        SELECT i.an, i.hn, i.regdate, i.regtime, i.admdoctor,
               $doc_name,
               $ward_sel,
               $sp_name
        FROM ipt i
        LEFT JOIN doctor doc ON doc.code = i.admdoctor
        $ward_join
        LEFT JOIN spclty sp ON sp.spclty = i.spclty
        WHERE i.an = '$an_esc'
        LIMIT 1
    ";
    $qi = @mysqli_query($con_hosxp, $sql_i);
    if (!$qi) {
        // ไม่มี regtime / spclty ในบางระบบ
        $sql_i = "
            SELECT i.an, i.hn, i.regdate, '' AS regtime, i.admdoctor,
                   $doc_name,
                   $ward_sel,
                   '' AS department_name
            FROM ipt i
            LEFT JOIN doctor doc ON doc.code = i.admdoctor
            $ward_join
            WHERE i.an = '$an_esc'
            LIMIT 1
        ";
        $qi = @mysqli_query($con_hosxp, $sql_i);
    }
    if ($qi && ($row = mysqli_fetch_assoc($qi))) {
        sd_mr_fill_ipd_row($visit, $row, $patient);
    }
} elseif ($vn !== '') {
    $vn_esc = mysqli_real_escape_string($con_hosxp, $vn);
    $kd_name = sd_mr_utf8("IFNULL(kd.department,'')") . ' AS department_name';
    $spn = sd_mr_utf8("IFNULL(sp.name,'')") . ' AS spclty_name';
    $qv = @mysqli_query($con_hosxp, "
        SELECT o.vn, o.hn, o.vstdate, o.vsttime, o.doctor,
               $doc_name,
               $kd_name,
               $spn
        FROM ovst o
        LEFT JOIN doctor doc ON doc.code = o.doctor
        LEFT JOIN kskdepartment kd ON kd.depcode = o.main_dep
        LEFT JOIN spclty sp ON sp.spclty = o.spclty
        WHERE o.vn = '$vn_esc'
        LIMIT 1
    ");
    if ($qv && ($row = mysqli_fetch_assoc($qv))) {
        $visit['visit_type'] = 'opd';
        $visit['vn'] = $row['vn'];
        $visit['doctor_code'] = trim($row['doctor'] ?? '');
        $visit['doctor_name'] = trim($row['doctor_name'] ?? '');
        $visit['department_name'] = trim($row['department_name'] ?? '') ?: trim($row['spclty_name'] ?? '');
        $visit['service_date'] = (($row['vstdate'] ?? '') !== '0000-00-00') ? ($row['vstdate'] ?? '') : '';
        $visit['service_time'] = substr(trim((string)($row['vsttime'] ?? '')), 0, 8);
        $visit['admit_date'] = $visit['service_date'];
        $visit['admit_time'] = $visit['service_time'];
        if ($patient && empty($patient['hn']) && !empty($row['hn'])) {
            $patient['hn'] = $row['hn'];
        }
    }

    // ถ้ามี IPD ค้าง admit ของ HN เดียวกัน ให้ดึงหอผู้ป่วยมาด้วย
    if ($visit['ward_name'] === '') {
        $qa2 = @mysqli_query($con_hosxp, "
            SELECT i.an, i.hn, i.regdate, i.regtime, i.admdoctor,
                   $doc_name,
                   $ward_sel,
                   $sp_name
            FROM ipt i
            LEFT JOIN doctor doc ON doc.code = i.admdoctor
            $ward_join
            LEFT JOIN spclty sp ON sp.spclty = i.spclty
            WHERE i.hn IN ($hn_sql)
              AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00')
            ORDER BY i.regdate DESC, i.an DESC
            LIMIT 1
        ");
        if ($qa2 && ($row = mysqli_fetch_assoc($qa2))) {
            $ward = trim($row['ward_name'] ?? '');
            if ($ward !== '') {
                $visit['ward_name'] = $ward;
            }
            if ($visit['doctor_name'] === '' && trim($row['doctor_name'] ?? '') !== '') {
                $visit['doctor_name'] = trim($row['doctor_name']);
                $visit['doctor_code'] = trim($row['admdoctor'] ?? '');
            }
            if ($visit['department_name'] === '' && trim($row['department_name'] ?? '') !== '') {
                $visit['department_name'] = trim($row['department_name']);
            }
        }
    }
} else {
    $qa2 = @mysqli_query($con_hosxp, "
        SELECT i.an, i.hn, i.regdate, i.regtime, i.admdoctor,
               $doc_name,
               $ward_sel,
               $sp_name
        FROM ipt i
        LEFT JOIN doctor doc ON doc.code = i.admdoctor
        $ward_join
        LEFT JOIN spclty sp ON sp.spclty = i.spclty
        WHERE i.hn IN ($hn_sql)
          AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00')
        ORDER BY i.regdate DESC, i.an DESC
        LIMIT 1
    ");
    if ($qa2 && ($row = mysqli_fetch_assoc($qa2))) {
        sd_mr_fill_ipd_row($visit, $row, $patient);
    }
}

// หอผู้ป่วยจาก IPD ปัจจุบัน (ยังไม่จำหน่าย) — ใช้เป็นหลักเสมอ
$current_ipd = [
    'an' => '',
    'ward_name' => '',
    'doctor_name' => '',
    'doctor_code' => '',
    'admit_date' => '',
    'admit_time' => '',
];
$qcur = @mysqli_query($con_hosxp, "
    SELECT i.an, i.hn, i.regdate, i.regtime, i.admdoctor,
           $doc_name,
           $ward_sel
    FROM ipt i
    LEFT JOIN doctor doc ON doc.code = i.admdoctor
    $ward_join
    WHERE i.hn IN ($hn_sql)
      AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00')
    ORDER BY i.regdate DESC, i.an DESC
    LIMIT 1
");
if ($qcur && ($cr = mysqli_fetch_assoc($qcur))) {
    $current_ipd['an'] = trim($cr['an'] ?? '');
    $current_ipd['ward_name'] = trim($cr['ward_name'] ?? '');
    $current_ipd['doctor_name'] = trim($cr['doctor_name'] ?? '');
    $current_ipd['doctor_code'] = trim($cr['admdoctor'] ?? '');
    $current_ipd['admit_date'] = (($cr['regdate'] ?? '') !== '0000-00-00') ? ($cr['regdate'] ?? '') : '';
    $current_ipd['admit_time'] = substr(trim((string)($cr['regtime'] ?? '')), 0, 8);
    if ($current_ipd['ward_name'] !== '') {
        $visit['ward_name'] = $current_ipd['ward_name'];
    }
    if ($visit['doctor_name'] === '' && $current_ipd['doctor_name'] !== '') {
        $visit['doctor_name'] = $current_ipd['doctor_name'];
        $visit['doctor_code'] = $current_ipd['doctor_code'];
    }
    if ($visit['admit_date'] === '' && $current_ipd['admit_date'] !== '') {
        $visit['admit_date'] = $current_ipd['admit_date'];
        $visit['admit_time'] = $current_ipd['admit_time'];
        $visit['service_date'] = $current_ipd['admit_date'];
        $visit['service_time'] = $current_ipd['admit_time'];
    }
    if ($visit['an'] === '' && $current_ipd['an'] !== '') {
        $visit['an'] = $current_ipd['an'];
        if ($visit['visit_type'] === '') {
            $visit['visit_type'] = 'ipd';
        }
    }
}

// ถ้ายังไม่มีหอ — ลองดึงจาก IPD ล่าสุดของ HN (รวมที่จำหน่ายแล้ว)
if ($visit['ward_name'] === '' && $hn_sql !== '') {
    $qw = @mysqli_query($con_hosxp, "
        SELECT $ward_sel
        FROM ipt i
        $ward_join
        WHERE i.hn IN ($hn_sql)
        ORDER BY i.regdate DESC, i.an DESC
        LIMIT 1
    ");
    if ($qw && ($wr = mysqli_fetch_assoc($qw))) {
        $visit['ward_name'] = trim($wr['ward_name'] ?? '');
    }
}

$today = date('Y-m-d');
$today_esc = mysqli_real_escape_string($con_hosxp, $today);
$local_appt_place = 'รพ.สมเด็จพระยุพราชสระแก้ว';
foreach (hds_catalog() as $cat) {
    if (($cat['code'] ?? '') === 'scph') {
        $n = trim((string)($cat['name'] ?? ''));
        if ($n !== '') {
            $local_appt_place = $n;
        }
        break;
    }
}
$appointments = [];
if ($hn_sql !== '') {
    $appt_rows = sd_mr_fetch_oapp_rows(
        $con_hosxp,
        "o.hn IN ($hn_sql)
         AND o.nextdate IS NOT NULL
         AND o.nextdate <> '0000-00-00'
         AND o.nextdate > '$today_esc'",
        'o.nextdate ASC, o.nexttime ASC',
        20
    );
    $seen = [];
    foreach ($appt_rows as $r) {
        $nd = substr(trim((string)($r['nextdate'] ?? '')), 0, 10);
        if ($nd === '' || $nd === '0000-00-00' || $nd <= $today) {
            continue;
        }
        $nt = substr(trim((string)($r['nexttime'] ?? '')), 0, 8);
        $cn = trim((string)($r['clinic_name'] ?? ''));
        $dn = trim((string)($r['doctor_name'] ?? ''));
        $cl = trim((string)($r['clinic'] ?? ''));
        $disp = sd_mr_fmt_appt_display($nd, $nt, $cn, $dn, $local_appt_place);
        if ($disp === '') {
            continue;
        }
        $key = $nd . '|' . substr($nt, 0, 5) . '|' . $cn . '|' . $cl;
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $appointments[] = [
            'nextdate' => $nd,
            'nexttime' => $nt,
            'clinic' => $cl,
            'clinic_name' => $cn,
            'doctor_name' => $dn,
            'hospital_name' => $local_appt_place,
            'display' => $disp,
        ];
    }
}
$visit_appointments = [];
if ($hn_sql !== '') {
    $va_sql = "
        SELECT o.vn, IFNULL(o.an,'') AS an, o.vstdate, o.nextdate, o.nexttime,
               " . sd_mr_utf8("IFNULL(c.name,'')") . " AS clinic_name,
               " . sd_mr_utf8("IFNULL(doc.name,'')") . " AS doctor_name
        FROM oapp o
        LEFT JOIN clinic c ON c.clinic = o.clinic
        LEFT JOIN doctor doc ON doc.code = o.doctor
        WHERE o.hn IN ($hn_sql)
          AND o.vstdate IS NOT NULL AND o.vstdate <> '0000-00-00'
          AND o.nextdate IS NOT NULL AND o.nextdate <> '0000-00-00'
        ORDER BY o.vstdate DESC, o.nextdate ASC
        LIMIT 500
    ";
    $qv = @mysqli_query($con_hosxp, $va_sql);
    if (!$qv) {
        $qv = @mysqli_query($con_hosxp, "
            SELECT o.vn, '' AS an, o.vstdate, o.nextdate, o.nexttime, '' AS clinic_name, '' AS doctor_name
            FROM oapp o
            WHERE o.hn IN ($hn_sql)
              AND o.vstdate IS NOT NULL AND o.vstdate <> '0000-00-00'
              AND o.nextdate IS NOT NULL AND o.nextdate <> '0000-00-00'
            ORDER BY o.vstdate DESC, o.nextdate ASC
            LIMIT 500
        ");
    }
    if ($qv) {
        while ($r = mysqli_fetch_assoc($qv)) {
            $vd = substr(trim((string)($r['vstdate'] ?? '')), 0, 10);
            $nd = substr(trim((string)($r['nextdate'] ?? '')), 0, 10);
            if ($vd === '' || $vd === '0000-00-00' || $nd === '' || $nd === '0000-00-00') {
                continue;
            }
            $visit_appointments[] = [
                'vn' => trim((string)($r['vn'] ?? '')),
                'an' => trim((string)($r['an'] ?? '')),
                'vstdate' => $vd,
                'nextdate' => $nd,
                'nexttime' => substr(trim((string)($r['nexttime'] ?? '')), 0, 8),
                'clinic_name' => trim((string)($r['clinic_name'] ?? '')),
                'doctor_name' => trim((string)($r['doctor_name'] ?? '')),
                'hospital_code' => 'local',
                'hospital_name' => $local_appt_place,
            ];
        }
    }
}

$external_appts = [];
if (function_exists('hds_fetch_appointment_network')) {
    try {
        $net_ap = hds_fetch_appointment_network($con, hds_hn_variants($hn), $patient_cid);
        foreach ($net_ap['rows'] ?? [] as $row) {
            if (is_array($row)) {
                $external_appts[] = $row;
            }
        }
    } catch (Throwable $e) {
    }
}
if (function_exists('jhcis_fetch_appointments') && strlen($patient_cid) === 13) {
    try {
        $jhcis_ap = jhcis_fetch_appointments($con, $patient_cid);
        foreach ($jhcis_ap['rows'] ?? [] as $row) {
            if (is_array($row)) {
                $external_appts[] = $row;
            }
        }
    } catch (Throwable $e) {
    }
}
$appt_seen = [];
foreach ($appointments as $a) {
    $appt_seen[($a['nextdate'] ?? '') . '|' . substr((string)($a['nexttime'] ?? ''), 0, 5) . '|' . ($a['clinic_name'] ?? '') . '|local'] = true;
}
foreach ($external_appts as $row) {
    $nd = substr(trim((string)($row['nextdate'] ?? '')), 0, 10);
    $vd = substr(trim((string)($row['vstdate'] ?? '')), 0, 10);
    if ($nd === '' || $nd === '0000-00-00') {
        continue;
    }
    $place = trim((string)($row['hospital_name'] ?? ''));
    $code = trim((string)($row['hospital_code'] ?? ''));
    if ($code === '') {
        $code = 'network';
    }
    $visit_appointments[] = [
        'vn' => trim((string)($row['vn'] ?? '')),
        'an' => trim((string)($row['an'] ?? '')),
        'vstdate' => $vd,
        'nextdate' => $nd,
        'nexttime' => substr(trim((string)($row['nexttime'] ?? '')), 0, 8),
        'clinic_name' => trim((string)($row['clinic_name'] ?? '')),
        'doctor_name' => trim((string)($row['doctor_name'] ?? '')),
        'hospital_code' => $code,
        'hospital_name' => $place,
    ];
    if ($nd <= $today) {
        continue;
    }
    $cn = trim((string)($row['clinic_name'] ?? ''));
    $dn = trim((string)($row['doctor_name'] ?? ''));
    $disp = sd_mr_fmt_appt_display($nd, $row['nexttime'] ?? '', $cn, $dn, $place);
    $key = $nd . '|' . substr(trim((string)($row['nexttime'] ?? '')), 0, 5) . '|' . $cn . '|' . $code;
    if ($disp === '' || isset($appt_seen[$key])) {
        continue;
    }
    $appt_seen[$key] = true;
    $appointments[] = [
        'nextdate' => $nd,
        'nexttime' => substr(trim((string)($row['nexttime'] ?? '')), 0, 8),
        'clinic' => '',
        'clinic_name' => $cn,
        'doctor_name' => $dn,
        'hospital_name' => $place,
        'display' => $disp,
    ];
}
usort($appointments, function ($a, $b) {
    return strcmp((string)($a['nextdate'] ?? ''), (string)($b['nextdate'] ?? ''));
});

$first = $appointments[0] ?? null;
$appointment = [
    'nextdate' => $first['nextdate'] ?? '',
    'nexttime' => $first['nexttime'] ?? '',
    'clinic' => $first['clinic'] ?? '',
    'clinic_name' => $first['clinic_name'] ?? '',
    'display' => implode("\n", array_column($appointments, 'display')),
    'items' => $appointments,
];

$hospital_name = 'โรงพยาบาลสมเด็จพระยุพราชสระแก้ว';
foreach (hds_catalog() as $cat) {
    if (($cat['code'] ?? '') === 'scph') {
        $n = trim((string)($cat['name'] ?? ''));
        if ($n !== '') {
            $hospital_name = (strpos($n, 'โรงพยาบาล') === 0) ? $n : ('โรงพยาบาล' . preg_replace('/^รพ\./u', '', $n));
        }
        break;
    }
}

mysqli_close($con_hosxp);

if (!$patient) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่พบข้อมูลผู้ป่วย']);
    exit;
}

echo json_encode([
    'status' => 'success',
    'patient' => $patient,
    'visit' => $visit,
    'current_ipd' => $current_ipd,
    'allergy' => [
        'has_allergy' => $has_allergy,
        'text' => $has_allergy ? $allergy_text : 'ไม่แพ้ยา(HOSxP)',
        'agents' => $allergy_agents,
        'label_no_allergy' => 'ไม่แพ้ยา(HOSxP)',
    ],
    'hospital_name' => $hospital_name,
    'appointment' => $appointment,
    'appointments' => $appointments,
    'visit_appointments' => $visit_appointments,
], JSON_UNESCAPED_UNICODE);
