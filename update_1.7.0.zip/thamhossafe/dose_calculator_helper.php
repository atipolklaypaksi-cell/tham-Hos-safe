<?php
/**
 * ระบบช่วยคำนวณยา — บันทึก BW/ส่วนสูง และผลคำนวณ เพื่อใช้กับ Monitor อื่น
 */

function dc_hn_key($hn) {
    $hn = ltrim(trim((string)$hn), '0');
    return $hn === '' ? '0' : $hn;
}

function dc_hn_variants($hn) {
    $hn = trim((string)$hn);
    $out = [];
    if ($hn === '') {
        return $out;
    }
    $out[] = $hn;
    $key = dc_hn_key($hn);
    if ($key !== $hn) {
        $out[] = $key;
    }
    if (ctype_digit($key) && strlen($key) < 9) {
        $out[] = str_pad($key, 9, '0', STR_PAD_LEFT);
    }
    return array_values(array_unique($out));
}

function dc_ensure_tables($con) {
    $q = mysqli_query($con, "SHOW TABLES LIKE 'dose_calculator_vitals'");
    if ($q && mysqli_num_rows($q) > 0) {
        $q2 = mysqli_query($con, "SHOW TABLES LIKE 'dose_calculator_logs'");
        return $q2 && mysqli_num_rows($q2) > 0;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/dose_calculator.sql');
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '' && !mysqli_query($con, $stmt)) {
            return false;
        }
    }
    return true;
}

function dc_pct_change($from, $to) {
    $from = (float)$from;
    $to = (float)$to;
    if ($from <= 0) {
        return $to > 0 ? 100.0 : 0.0;
    }
    return abs($to - $from) / $from * 100.0;
}

function dc_needs_confirm($bw_source, $bw_used, $height_source, $height_used, $threshold_pct = 10.0) {
    $need = false;
    $reasons = [];
    if ($bw_source !== null && (float)$bw_source > 0 && $bw_used !== null && (float)$bw_used > 0) {
        $p = dc_pct_change($bw_source, $bw_used);
        if ($p > $threshold_pct) {
            $need = true;
            $reasons[] = 'น้ำหนักเปลี่ยน ' . round($p, 1) . '% (' . $bw_source . ' → ' . $bw_used . ' kg)';
        }
    }
    if ($height_source !== null && (float)$height_source > 0 && $height_used !== null && (float)$height_used > 0) {
        $p = dc_pct_change($height_source, $height_used);
        if ($p > $threshold_pct) {
            $need = true;
            $reasons[] = 'ส่วนสูงเปลี่ยน ' . round($p, 1) . '% (' . $height_source . ' → ' . $height_used . ' cm)';
        }
    }
    return ['need' => $need, 'reasons' => $reasons];
}

/**
 * ดึงผู้ป่วย + vitals ล่าสุดจาก HOSxP
 */
function dc_lookup_patient($hos, $con, $hn_raw) {
    $variants = dc_hn_variants($hn_raw);
    if (!$hos || empty($variants)) {
        return ['ok' => false, 'error' => 'กรุณาระบุ HN'];
    }

    $in = "'" . implode("','", array_map(function ($h) use ($hos) {
        return mysqli_real_escape_string($hos, $h);
    }, $variants)) . "'";

    $pt = null;
    $q = mysqli_query($hos, "SELECT hn, birthday, sex,
        CONCAT(IFNULL(pname,''), IFNULL(fname,''), ' ', IFNULL(lname,'')) AS ptname
        FROM patient WHERE hn IN ($in) LIMIT 1");
    if ($q && ($row = mysqli_fetch_assoc($q))) {
        $pt = $row;
    }
    if (!$pt) {
        return ['ok' => false, 'error' => 'ไม่พบ HN ใน HOSxP'];
    }

    $sys = [];
    $q_cfg = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ('h_tbl_vital','h_fld_bw','h_fld_height')");
    if ($q_cfg) {
        while ($r = mysqli_fetch_assoc($q_cfg)) {
            $sys[$r['config_name']] = $r['config_value'];
        }
    }
    $tbl = preg_replace('/[^a-zA-Z0-9_]/', '', $sys['h_tbl_vital'] ?? 'opdscreen') ?: 'opdscreen';
    $fld_bw = preg_replace('/[^a-zA-Z0-9_]/', '', $sys['h_fld_bw'] ?? 'bw') ?: 'bw';
    $fld_height = preg_replace('/[^a-zA-Z0-9_]/', '', $sys['h_fld_height'] ?? 'height') ?: 'height';

    $hn_esc = mysqli_real_escape_string($hos, $pt['hn']);
    $bw = null;
    $height = null;
    $vstdate = null;
    $sql_v = "SELECT $fld_bw AS bw, $fld_height AS height, vstdate
        FROM $tbl
        WHERE hn = '$hn_esc' AND $fld_bw > 0
        ORDER BY vstdate DESC, vsttime DESC
        LIMIT 1";
    $qv = mysqli_query($hos, $sql_v);
    if ($qv && ($vr = mysqli_fetch_assoc($qv))) {
        $bw = (float)$vr['bw'] > 0 ? (float)$vr['bw'] : null;
        $height = (float)$vr['height'] > 0 ? (float)$vr['height'] : null;
        $vstdate = $vr['vstdate'] ?? null;
    }

    $hn_key = dc_hn_key($pt['hn']);
    $saved = dc_get_vitals_override($con, $hn_key);
    $birthday = trim((string)($pt['birthday'] ?? ''));
    $age = null;
    if ($birthday !== '' && $birthday !== '0000-00-00') {
        $age_y = monitor_lab_patient_age_years($birthday, date('Y-m-d'));
        if ($age_y >= 0) {
            $age = (int)$age_y;
        }
    }

    $sex_raw = trim((string)($pt['sex'] ?? ''));
    $sex = null; // 'M' | 'F'
    if ($sex_raw === '1' || strtoupper($sex_raw) === 'M') {
        $sex = 'M';
    } elseif ($sex_raw === '2' || strtoupper($sex_raw) === 'F') {
        $sex = 'F';
    }

    $resolved = dc_resolve_latest_bw(
        $bw !== null ? $bw : 0,
        $vstdate,
        ($saved && (float)($saved['bw'] ?? 0) > 0) ? (float)$saved['bw'] : 0,
        ($saved && !empty($saved['updated_at'])) ? (string)$saved['updated_at'] : ''
    );

    return [
        'ok' => true,
        'hn' => $pt['hn'],
        'hn_key' => $hn_key,
        'ptname' => trim($pt['ptname'] ?? ''),
        'birthday' => ($birthday !== '' && $birthday !== '0000-00-00') ? $birthday : null,
        'age' => $age,
        'sex' => $sex,
        'bw' => $bw,
        'height' => $height,
        'vstdate' => $vstdate,
        'saved' => $saved,
        'bw_resolved' => $resolved['bw'],
        'bw_resolved_date' => $resolved['datetime'] ?: $resolved['date'],
        'bw_source' => $resolved['source'],
        'bw_source_label' => $resolved['source_label'],
    ];
}

function dc_get_vitals_override($con, $hn_key) {
    dc_ensure_tables($con);
    $hn_key = dc_hn_key($hn_key);
    $esc = mysqli_real_escape_string($con, $hn_key);
    $q = mysqli_query($con, "SELECT * FROM dose_calculator_vitals WHERE hn_key='$esc' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return $r;
    }
    return null;
}

/**
 * ดึง override หลาย HN — คืน [hn_key => ['bw'=>..., 'height'=>..., 'updated_at'=>..., 'source'=>'calculator']]
 */
function dc_prefetch_vitals_overrides($con, array $hn_list) {
    dc_ensure_tables($con);
    $map = [];
    $keys = [];
    foreach ($hn_list as $hn) {
        $k = dc_hn_key($hn);
        if ($k !== '') {
            $keys[$k] = true;
        }
    }
    if (empty($keys)) {
        return $map;
    }
    $in = "'" . implode("','", array_map(function ($k) use ($con) {
        return mysqli_real_escape_string($con, $k);
    }, array_keys($keys))) . "'";
    $q = mysqli_query($con, "SELECT hn_key, bw, height, updated_at, confirmed_change FROM dose_calculator_vitals WHERE hn_key IN ($in)");
    if (!$q) {
        return $map;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $map[$r['hn_key']] = [
            'bw' => (float)$r['bw'],
            'height' => isset($r['height']) && $r['height'] !== null && (float)$r['height'] > 0 ? (float)$r['height'] : null,
            'updated_at' => $r['updated_at'] ?? null,
            'confirmed_change' => !empty($r['confirmed_change']),
            'source' => 'calculator',
        ];
    }
    return $map;
}

/**
 * เลือกน้ำหนักล่าสุดระหว่าง HOSxP กับ THAM (dose_calculator_vitals)
 * @return array{bw:?float,date:?string,datetime:?string,source:string,source_label:string}
 */
function dc_resolve_latest_bw($hos_bw, $hos_date, $tham_bw, $tham_updated_at) {
    $hos_bw = (float)$hos_bw;
    $tham_bw = (float)$tham_bw;
    $hos_date = substr(trim((string)$hos_date), 0, 10);
    if ($hos_date === '0000-00-00') {
        $hos_date = '';
    }
    $tham_updated_at = trim((string)$tham_updated_at);
    $hos_ts = ($hos_date !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $hos_date))
        ? (int)strtotime($hos_date . ' 00:00:00') : 0;
    $tham_ts = $tham_updated_at !== '' ? (int)(strtotime($tham_updated_at) ?: 0) : 0;
    $has_hos = $hos_bw > 0;
    $has_tham = $tham_bw > 0;

    if ($has_hos && $has_tham) {
        // ใหม่กว่าชนะ · วันเดียวกันให้ THAM (มีเวลา) ชนะถ้าอัปเดตวันนั้น
        if ($tham_ts >= $hos_ts) {
            return [
                'bw' => $tham_bw,
                'date' => substr($tham_updated_at, 0, 10),
                'datetime' => $tham_updated_at,
                'source' => 'tham',
                'source_label' => 'THAM',
            ];
        }
        return [
            'bw' => $hos_bw,
            'date' => $hos_date,
            'datetime' => $hos_date,
            'source' => 'hosxp',
            'source_label' => 'HOSxP',
        ];
    }
    if ($has_tham) {
        return [
            'bw' => $tham_bw,
            'date' => $tham_updated_at !== '' ? substr($tham_updated_at, 0, 10) : null,
            'datetime' => $tham_updated_at !== '' ? $tham_updated_at : null,
            'source' => 'tham',
            'source_label' => 'THAM',
        ];
    }
    if ($has_hos) {
        return [
            'bw' => $hos_bw,
            'date' => $hos_date !== '' ? $hos_date : null,
            'datetime' => $hos_date !== '' ? $hos_date : null,
            'source' => 'hosxp',
            'source_label' => 'HOSxP',
        ];
    }
    return [
        'bw' => null,
        'date' => null,
        'datetime' => null,
        'source' => '',
        'source_label' => '',
    ];
}

/**
 * รวมน้ำหนักจาก THAM/เครื่องคำนวณ กับ HOSxP — ใช้ค่าที่ใหม่กว่า
 * @return array{bw:?float,vstdate:?string,stale:bool,source:string,source_label?:string}
 */
function dc_merge_weight_override(array $weight_info, array $overrides, $hn) {
    $key = dc_hn_key($hn);
    $hos_bw = (float)($weight_info['bw'] ?? 0);
    $hos_date = (string)($weight_info['vstdate'] ?? '');
    $tham_bw = 0.0;
    $tham_at = '';
    if ($key !== '' && !empty($overrides[$key]['bw']) && (float)$overrides[$key]['bw'] > 0) {
        $tham_bw = (float)$overrides[$key]['bw'];
        $tham_at = (string)($overrides[$key]['updated_at'] ?? '');
    }
    $resolved = dc_resolve_latest_bw($hos_bw, $hos_date, $tham_bw, $tham_at);
    if ($resolved['bw'] === null || (float)$resolved['bw'] <= 0) {
        if (!isset($weight_info['source'])) {
            $weight_info['source'] = 'hosxp';
        }
        return $weight_info;
    }
    return [
        'bw' => (float)$resolved['bw'],
        'vstdate' => $resolved['date'] ?: ($weight_info['vstdate'] ?? null),
        'stale' => false,
        'source' => $resolved['source'] === 'tham' ? 'calculator' : 'hosxp',
        'source_label' => $resolved['source_label'],
    ];
}

/**
 * บันทึกน้ำหนักลง THAM (dose_calculator_vitals) โดยไม่ต้องมีผลคำนวณยา
 */
function dc_save_vitals_bw($con, array $data) {
    dc_ensure_tables($con);
    $hn = trim((string)($data['hn'] ?? ''));
    $hn_key = dc_hn_key($hn !== '' ? $hn : ($data['hn_key'] ?? ''));
    if ($hn_key === '' || ($hn_key === '0' && $hn === '')) {
        return ['ok' => false, 'error' => 'ไม่พบ HN'];
    }
    if ($hn === '') {
        $hn = $hn_key;
    }
    $bw = (float)($data['bw'] ?? $data['bw_used'] ?? 0);
    if ($bw <= 0 || $bw > 500) {
        return ['ok' => false, 'error' => 'กรุณาระบุน้ำหนักที่ถูกต้อง (kg)'];
    }
    $height = isset($data['height']) && $data['height'] !== '' && $data['height'] !== null
        ? (float)$data['height'] : null;
    if ($height !== null && $height <= 0) {
        $height = null;
    }
    $ptname = mysqli_real_escape_string($con, trim((string)($data['ptname'] ?? '')));
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $hn_key_esc = mysqli_real_escape_string($con, $hn_key);
    $sql_ht = $height !== null ? (string)$height : 'NULL';
    $uid = (int)($data['user_id'] ?? ($_SESSION['user_id'] ?? 0));
    $uname = mysqli_real_escape_string($con, trim((string)($data['user_name'] ?? ($_SESSION['full_name'] ?? ''))));
    $note = trim((string)($data['note'] ?? $data['source_module'] ?? 'manual'));
    // เก็บ module ไว้ใน confirmed_change ไม่ได้ — ใช้ vitals อย่างเดียว
    $sql = "INSERT INTO dose_calculator_vitals
        (hn, hn_key, ptname, bw, height, bw_source, height_source, vitals_vstdate, confirmed_change, updated_by, updated_by_name)
        VALUES ('$hn_esc', '$hn_key_esc', '$ptname', $bw, $sql_ht, NULL, NULL, CURDATE(), 0, "
        . ($uid > 0 ? $uid : 'NULL') . ", '$uname')
        ON DUPLICATE KEY UPDATE
            hn=VALUES(hn), ptname=IF(VALUES(ptname)='', ptname, VALUES(ptname)),
            bw=VALUES(bw), height=COALESCE(VALUES(height), height),
            vitals_vstdate=CURDATE(),
            updated_by=VALUES(updated_by), updated_by_name=VALUES(updated_by_name),
            updated_at=CURRENT_TIMESTAMP";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => 'บันทึกน้ำหนักไม่สำเร็จ: ' . mysqli_error($con)];
    }
    return [
        'ok' => true,
        'message' => 'บันทึกน้ำหนักใน THAM แล้ว',
        'bw' => $bw,
        'source' => 'tham',
        'source_label' => 'THAM',
        'note' => $note,
        'updated_at' => date('Y-m-d H:i:s'),
    ];
}

function dc_save_calculation($con, array $data) {
    dc_ensure_tables($con);
    $hn = trim((string)($data['hn'] ?? ''));
    $hn_key = dc_hn_key($hn !== '' ? $hn : ($data['hn_key'] ?? ''));
    if ($hn_key === '' || ($hn_key === '0' && $hn === '')) {
        return ['ok' => false, 'error' => 'ไม่พบ HN'];
    }
    if ($hn === '') {
        $hn = $hn_key;
    }

    $calc_type = preg_replace('/[^a-z0-9_]/', '', strtolower((string)($data['calc_type'] ?? '')));
    $allowed = ['methylpred', 'rtpa_stemi', 'rtpa_stroke', 'tnk_stroke', 'tnk_stemi', 'bolus', 'midazolam', 'midazolam_hr', 'fentanyl', 'dobutamine', 'dopamine', 'norepinephrine', 'cisatracurium', 'adrenaline', 'calcium_glu', 'alprostadil', 'indomethacin', 'nac', 'lbw', 'iloprost', 'kcl', 'ntg', 'arv_ped', 'tb'];
    if (!in_array($calc_type, $allowed, true)) {
        return ['ok' => false, 'error' => 'ประเภทการคำนวณไม่ถูกต้อง'];
    }

    $bw_used = (float)($data['bw_used'] ?? 0);
    if ($bw_used <= 0) {
        return ['ok' => false, 'error' => 'กรุณาระบุน้ำหนัก'];
    }

    $bw_source = isset($data['bw_source']) && $data['bw_source'] !== '' && $data['bw_source'] !== null
        ? (float)$data['bw_source'] : null;
    $height_source = isset($data['height_source']) && $data['height_source'] !== '' && $data['height_source'] !== null
        ? (float)$data['height_source'] : null;
    $height_used = isset($data['height_used']) && $data['height_used'] !== '' && $data['height_used'] !== null
        ? (float)$data['height_used'] : null;
    if ($height_used !== null && $height_used <= 0) {
        $height_used = null;
    }

    $check = dc_needs_confirm($bw_source, $bw_used, $height_source, $height_used, 10.0);
    $confirmed = !empty($data['confirmed_change']);
    if ($check['need'] && !$confirmed) {
        return [
            'ok' => false,
            'need_confirm' => true,
            'reasons' => $check['reasons'],
            'error' => 'น้ำหนัก/ส่วนสูงเปลี่ยนแปลงมากกว่า 10% — กรุณายืนยัน',
        ];
    }

    $inputs_raw = is_array($data['inputs'] ?? null) ? $data['inputs'] : [];
    $age_source = isset($data['age_source']) && $data['age_source'] !== '' && $data['age_source'] !== null
        ? (int)$data['age_source'] : null;
    $age_used = isset($inputs_raw['age']) && $inputs_raw['age'] !== '' && $inputs_raw['age'] !== null
        ? (int)$inputs_raw['age'] : null;
    $age_confirmed = !empty($data['age_confirmed']);
    if ($age_source !== null && $age_used !== null && $age_used !== $age_source && !$age_confirmed) {
        return [
            'ok' => false,
            'need_age_confirm' => true,
            'error' => 'แก้ไขอายุจากค่า HOSxP — กรุณาพิมพ์ confirm เพื่อยืนยัน',
        ];
    }

    $ptname = mysqli_real_escape_string($con, trim((string)($data['ptname'] ?? '')));
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $hn_key_esc = mysqli_real_escape_string($con, $hn_key);
    $sql_bw_src = $bw_source !== null ? (string)$bw_source : 'NULL';
    $sql_ht_src = $height_source !== null ? (string)$height_source : 'NULL';
    $sql_ht = $height_used !== null ? (string)$height_used : 'NULL';
    $vst = trim((string)($data['vitals_vstdate'] ?? ''));
    $sql_vst = preg_match('/^\d{4}-\d{2}-\d{2}$/', $vst) ? "'" . mysqli_real_escape_string($con, $vst) . "'" : 'NULL';
    $conf = ($check['need'] && $confirmed) ? 1 : 0;
    $uid = (int)($data['user_id'] ?? 0);
    $uname = mysqli_real_escape_string($con, trim((string)($data['user_name'] ?? '')));
    $inputs = mysqli_real_escape_string($con, json_encode($data['inputs'] ?? new stdClass(), JSON_UNESCAPED_UNICODE));
    $result = mysqli_real_escape_string($con, json_encode($data['result'] ?? new stdClass(), JSON_UNESCAPED_UNICODE));

    $sql_vitals = "INSERT INTO dose_calculator_vitals
        (hn, hn_key, ptname, bw, height, bw_source, height_source, vitals_vstdate, confirmed_change, updated_by, updated_by_name)
        VALUES ('$hn_esc', '$hn_key_esc', '$ptname', $bw_used, $sql_ht, $sql_bw_src, $sql_ht_src, $sql_vst, $conf, " . ($uid > 0 ? $uid : 'NULL') . ", '$uname')
        ON DUPLICATE KEY UPDATE
            hn=VALUES(hn), ptname=VALUES(ptname), bw=VALUES(bw), height=VALUES(height),
            bw_source=VALUES(bw_source), height_source=VALUES(height_source),
            vitals_vstdate=VALUES(vitals_vstdate), confirmed_change=VALUES(confirmed_change),
            updated_by=VALUES(updated_by), updated_by_name=VALUES(updated_by_name), updated_at=CURRENT_TIMESTAMP";
    if (!mysqli_query($con, $sql_vitals)) {
        return ['ok' => false, 'error' => 'บันทึกน้ำหนักไม่สำเร็จ: ' . mysqli_error($con)];
    }

    $sql_log = "INSERT INTO dose_calculator_logs
        (hn, hn_key, ptname, calc_type, bw_source, height_source, bw_used, height_used, vitals_vstdate,
         confirmed_change, inputs_json, result_json, created_by, created_by_name)
        VALUES ('$hn_esc', '$hn_key_esc', '$ptname', '$calc_type', $sql_bw_src, $sql_ht_src, $bw_used, $sql_ht, $sql_vst,
         $conf, '$inputs', '$result', " . ($uid > 0 ? $uid : 'NULL') . ", '$uname')";
    if (!mysqli_query($con, $sql_log)) {
        return ['ok' => false, 'error' => 'บันทึกผลคำนวณไม่สำเร็จ: ' . mysqli_error($con)];
    }

    return [
        'ok' => true,
        'message' => 'บันทึกแล้ว — น้ำหนักจะถูกใช้ใน Monitor mg → mL และโมดูลที่เกี่ยวข้อง',
        'log_id' => (int)mysqli_insert_id($con),
        'confirmed_change' => (bool)$conf,
    ];
}
