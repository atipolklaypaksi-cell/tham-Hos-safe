<?php
/**
 * ผล Sensitivity และ ATB — จาก lab_head.result_rtf / medplan_ipd / eGFR / ward snapshot
 */

function amr_sens_clean_q($value) {
    $s = trim((string)$value);
    $s = str_replace(["'", '"', ' '], '', $s);
    $s = ltrim($s, '0');
    return $s;
}

function amr_sens_clean_rtf($raw) {
    $s = (string)$raw;
    if ($s === '') {
        return '';
    }
    $s = str_replace('/ APPROVED', "\n APPROVED", $s);
    $s = str_replace(['\\par', '\\line', '\\tab'], ["\n", "\n", "\t"], $s);
    $s = preg_replace('/\\\\[a-zA-Z]+\-?\d*[ ]?/', '', $s);
    $s = str_replace(['{', '}'], '', $s);
    $s = preg_replace("/\\r\\n?/", "\n", $s);
    $s = preg_replace("/[ \\t]+\\n/", "\n", $s);
    $s = preg_replace("/\\n{3,}/", "\n\n", $s);
    return trim($s);
}

function amr_sens_sql_result_text() {
    return "CAST(CONVERT(SUBSTR(REPLACE(REPLACE(lh.result_rtf, '/ APPROVED', '\\n APPROVED'), '\\\\par', '\\n'), 151) USING utf8) AS CHAR)";
}

function amr_sens_is_no_growth($text) {
    $u = strtoupper((string)$text);
    if (preg_match('/NO\s*GROWTH/', $u)) {
        return true;
    }
    if (preg_match('/NO\s+ORGANISM|STERILE\s+AFTER|NO\s+ISOLATE/', $u)) {
        return true;
    }
    if (preg_match('/ไม่พบเชื้อ|ไม่มีเชื้อ|ไม่พบการเจริญ/', (string)$text)) {
        return true;
    }
    return false;
}

function amr_sens_ast_skip_token($drug) {
    static $skip = [
        'LAB', 'CFU', 'SIR', 'MIC', 'MLAB', 'VERSION', 'APPROVED', 'SPECIMEN', 'ANTIBIOTIC',
        'ANTIBIOTICS', 'RESULT', 'URINE', 'BLOOD', 'CULTURE', 'AEROBIC', 'VOID', 'MSU',
        'ORGANISM', 'RELEASE', 'REPORTED', 'POSITIVE', 'NEGATIVE', 'SUSCEPTIBLE',
        'INTERMEDIATE', 'RESISTANT', 'NONSUSCEPTIBLE', 'NSS', 'NO', 'THE', 'AND', 'FOR',
        'WITH', 'POS', 'NEG', 'DATE', 'TIME', 'NAME', 'WARD', 'PRICE', 'BAHT',
        'DAY', 'DAYS', 'THIS', 'THI', 'AFTER', 'WEEK', 'WEEKS', 'HOUR', 'HOURS',
        'GROWTH', 'GROW', 'FOUND', 'ISOLATE', 'COLONY', 'COLONIES', 'SPP', 'SSP',
        'CRPA', 'CRAB', 'MRSA', 'MRSE', 'VRE', 'ESBL', 'CRE', 'NDM', 'KPC', 'OXA',
        'ML', 'CFU', 'PNEUMONIAE', 'AERUGINOSA', 'BAUMANNII', 'FAECALIS', 'FAECIUM',
        'AUREUS', 'COMPLEX', 'SPECIES', 'IDENTIFICATION', 'HEMOCULTURE', 'STOOL',
    ];
    return in_array($drug, $skip, true);
}

function amr_sens_ast_is_organism($drug) {
    $d = strtoupper((string)$drug);
    $prefixes = [
        'PSEUDOMON', 'KLEBSIELL', 'ESCHERICH', 'STAPHYLOC', 'STREPTOCO', 'ACINETOBA',
        'ENTEROCOC', 'ENTEROBAC', 'AERUGINOS', 'PNEUMONIA', 'BAUMANNII', 'AEROMONAS',
        'HAEMOPHIL', 'CANDIDA', 'ASPERGILL', 'PROTEUS', 'SERRATIA', 'MORGANELL',
        'CITROBACT', 'SALMONELL', 'SHIGELLA', 'BURKHOLDE', 'STENOTROP', 'ACHROMOBA',
        'RALSTONIA', 'STAP', 'ECOLI',
    ];
    foreach ($prefixes as $p) {
        if (strpos($d, $p) === 0) {
            return true;
        }
    }
    return false;
}

function amr_sens_ast_class_map() {
    return [
        'Beta-lactam/BLI' => [
            'AMOXICILLIN/CLAVULANATE', 'AMOXICIL/CLAV', 'AMOXICILL/CLAV',
            'AMPICILLIN/SULBACTAM', 'PIPERACILLIN/TAZOBACTAM', 'PIPERACI/TAZO',
            'CEFOPERAZONE/SULBACTAM', 'CEFOPERA/SULB', 'TICARCILLIN/CLAV',
            'CEFTAZIDIME/AVIBACTAM', 'CEFTAZID/AVIB',
        ],
        'Aminoglycosides' => ['AMIKACIN', 'GENTAMICIN', 'NETILMICIN', 'TOBRAMYCIN', 'STREPTOMYCIN'],
        'Penicillins' => ['AMPICILLIN', 'AMOXICILLIN', 'PENICILLIN', 'CLOXACILLIN', 'OXACILLIN', 'BENZATHINE PENICILLIN'],
        'Cephalosporins' => [
            'CEFAZOLIN', 'CEPHALEXIN', 'CEFALEXIN', 'CEFUROXIME', 'CEFOXITIN',
            'CEFOTAXIME', 'CEFTRIAXONE', 'CEFTAZIDIME', 'CEFEPIME', 'CEFOPERAZONE',
        ],
        'Carbapenems' => ['IMIPENEM', 'MEROPENEM', 'ERTAPENEM', 'DORIPENEM'],
        'Fluoroquinolones' => ['CIPROFLOXACIN', 'LEVOFLOXACIN', 'MOXIFLOXACIN', 'OFLOXACIN', 'NORFLOXACIN', 'GATIFLOXACIN'],
        'Macrolides/Lincosamides' => ['ERYTHROMYCIN', 'AZITHROMYCIN', 'CLARITHROMYCIN', 'CLINDAMYCIN'],
        'Others' => [
            'VANCOMYCIN', 'TEICOPLANIN', 'LINEZOLID', 'COLISTIN', 'POLYMYXIN', 'FOSFOMYCIN',
            'NITROFURANTOIN', 'NITROFURANTO', 'TRIMETHOPRIM/SULFA', 'SULFAMETHOXAZOLE/TMP',
            'CO-TRIMOXAZOLE',
            'TETRACYCLINE', 'DOXYCYCLINE', 'CHLORAMPHENICOL', 'METRONIDAZOLE', 'RIFAMPICIN',
        ],
    ];
}

function amr_sens_ast_is_known($drug) {
    $d = strtoupper((string)$drug);
    foreach (amr_sens_ast_class_map() as $list) {
        if (in_array($d, $list, true)) {
            return true;
        }
    }
    foreach (amr_sens_ast_class_map() as $list) {
        foreach ($list as $item) {
            if (strlen($item) >= 6 && (strpos($d, $item) === 0 || strpos($item, $d) === 0)) {
                return true;
            }
        }
    }
    return (bool)preg_match('/^(CEF|CIPRO|LEVO|MOXI|OFL|NORFL|AMI[K]?|GENTA|TOBRA|NETIL|MERO|IMI|ERTA|DORI|VANCO|TEICO|COLIS|POLYMY|NITROF|PIPER|AMOX|AMPIC|CLIND|AZITH|CLARITH|ERYTH|FOSFO|TIGE|AZTRE|SULFA|TRIMETH|TETRA|DOXY|CHLORAM|METRO|RIFAM|LINEZ|OXAC|CLOX|PENIC)/', $d);
}

function amr_sens_ast_brand_aliases() {
    return [
        'AMOXICILLINCLAVULANATE' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXYCILLINCLAVULANATE' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXICILLINCLAVULANIC' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXYCILLINCLAVULANIC' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXYCILLINCLAV' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXICILLINCLAV' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXICILCLAV' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXICILLCLAV' => 'AMOXICILLIN/CLAVULANATE',
        'COAMOXICLAV' => 'AMOXICILLIN/CLAVULANATE',
        'COAMOXYCLAV' => 'AMOXICILLIN/CLAVULANATE',
        'AMOKSIKLAV' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXYCLAV' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXICLAV' => 'AMOXICILLIN/CLAVULANATE',
        'AUGMENTIN' => 'AMOXICILLIN/CLAVULANATE',
        'CLAVULIN' => 'AMOXICILLIN/CLAVULANATE',
    ];
}

function amr_sens_ast_expand_name($drug) {
    $d = strtoupper(trim((string)$drug));
    $d = preg_replace('/^\([^)]*\)\s*/', '', $d);
    $d = preg_replace('/\s+/', ' ', $d);
    $map = [
        'NITROFURANTO' => 'NITROFURANTOIN',
        'AMOXICIL/CLAV' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXICILL/CLAV' => 'AMOXICILLIN/CLAVULANATE',
        'AUGMENTIN' => 'AMOXICILLIN/CLAVULANATE',
        'PIPERACI/TAZO' => 'PIPERACILLIN/TAZOBACTAM',
        'PIPERACILLIN/TAZOBAC' => 'PIPERACILLIN/TAZOBACTAM',
        'CEFOPERA/SULB' => 'CEFOPERAZONE/SULBACTAM',
        'CEFOPERAZONE/SULBAC' => 'CEFOPERAZONE/SULBACTAM',
        'AMOXICILLIN/CLAVU' => 'AMOXICILLIN/CLAVULANATE',
        'AMOXICILLIN/CLAVU.' => 'AMOXICILLIN/CLAVULANATE',
        'CEFTAZID/AVIB' => 'CEFTAZIDIME/AVIBACTAM',
        'TRIMETH/SULFA' => 'TRIMETHOPRIM/SULFA',
        'TRIMETHO/SULFA' => 'TRIMETHOPRIM/SULFA',
        'TRIMETHO/SULFA.' => 'TRIMETHOPRIM/SULFA',
        'SULFAMETHOXAZ' => 'TRIMETHOPRIM/SULFA',
        'BENZATHINE PEN' => 'BENZATHINE PENICILLIN',
        'CO-TRIMOXAZOLE' => 'TRIMETHOPRIM/SULFA',
        'COTRIMOXAZOLE' => 'TRIMETHOPRIM/SULFA',
        'BACTRIM' => 'TRIMETHOPRIM/SULFA',
        'SXT' => 'TRIMETHOPRIM/SULFA',
        'TMP/SMX' => 'TRIMETHOPRIM/SULFA',
        'TMP-SMX' => 'TRIMETHOPRIM/SULFA',
        'SULFAMETHOXAZOLE/TMP' => 'TRIMETHOPRIM/SULFA',
    ];
    if (isset($map[$d])) {
        return $map[$d];
    }
    $norm = amr_sens_ast_norm($d);
    if (isset($map[$norm])) {
        return $map[$norm];
    }
    $brands = amr_sens_ast_brand_aliases();
    if (isset($brands[$norm])) {
        return $brands[$norm];
    }
    $best = '';
    $canon = $d;
    foreach ($brands as $alias => $target) {
        if (strlen($alias) < 6) {
            continue;
        }
        if (strpos($norm, $alias) !== false && strlen($alias) > strlen($best)) {
            $best = $alias;
            $canon = $target;
        }
    }
    if ($best !== '') {
        return $canon;
    }
    if (strpos($norm, 'AMOX') !== false && strpos($norm, 'CLAV') !== false) {
        return 'AMOXICILLIN/CLAVULANATE';
    }
    $aliases = [
        'COTRIMOXAZOLE' => 'TRIMETHOPRIM/SULFA',
        'COTRIMOXAZOL' => 'TRIMETHOPRIM/SULFA',
        'BACTRIM' => 'TRIMETHOPRIM/SULFA',
        'SEPTRIN' => 'TRIMETHOPRIM/SULFA',
        'TMPSMX' => 'TRIMETHOPRIM/SULFA',
        'TMPSMZ' => 'TRIMETHOPRIM/SULFA',
        'TRIMETHOPRIMSULFAMETHOXAZOLE' => 'TRIMETHOPRIM/SULFA',
        'TRIMETHOPRIMSULFA' => 'TRIMETHOPRIM/SULFA',
        'SULFAMETHOXAZOLETRIMETHOPRIM' => 'TRIMETHOPRIM/SULFA',
        'SULFAMETHOXAZOLETMP' => 'TRIMETHOPRIM/SULFA',
        'SULFAMETHOXAZOLE' => 'TRIMETHOPRIM/SULFA',
    ];
    if (isset($aliases[$norm])) {
        return $aliases[$norm];
    }
    $best = '';
    $canon = $d;
    foreach ($aliases as $alias => $target) {
        if (strlen($alias) < 6) {
            continue;
        }
        if (strpos($norm, $alias) !== false && strlen($alias) > strlen($best)) {
            $best = $alias;
            $canon = $target;
        }
    }
    return $canon;
}

function amr_sens_ast_norm($s) {
    return preg_replace('/[^A-Z0-9]/', '', strtoupper((string)$s));
}

function amr_sens_ast_matches_atb($ast_drug, $atb_name) {
    $canon_a = amr_sens_ast_expand_name($ast_drug);
    $canon_b = amr_sens_ast_expand_name($atb_name);
    if ($canon_a !== '' && $canon_a === $canon_b) {
        return true;
    }
    $d = amr_sens_ast_norm($ast_drug);
    $n = amr_sens_ast_norm($atb_name);
    if (strlen($d) < 4 || strlen($n) < 4) {
        return false;
    }
    $a = substr($d, 0, 8);
    $b = substr($n, 0, 8);
    if (strpos($n, $a) !== false || strpos($d, $b) !== false
        || strpos($n, $d) !== false || strpos($d, $n) !== false) {
        return true;
    }
    $dn = amr_sens_ast_norm($canon_a);
    $nn = amr_sens_ast_norm($canon_b);
    return strlen($dn) >= 6 && strlen($nn) >= 6 && $dn === $nn;
}

function amr_sens_aware_builtin() {
    /* WHO AWaRe classification 2023 — ไม่ถูกทับด้วยค่าของโรงพยาบาล */
    return [
        'AMIKACIN' => 'Access', 'GENTAMICIN' => 'Access', 'TOBRAMYCIN' => 'Access',
        'AMPICILLIN' => 'Access', 'AMOXICILLIN' => 'Access', 'AMOXICILLIN/CLAVULANATE' => 'Access',
        'CEFAZOLIN' => 'Access', 'CEFALEXIN' => 'Access', 'CEPHALEXIN' => 'Access',
        'CLOXACILLIN' => 'Access', 'OXACILLIN' => 'Access', 'PENICILLIN' => 'Access',
        'CLINDAMYCIN' => 'Access',
        'NITROFURANTOIN' => 'Access', 'METRONIDAZOLE' => 'Access',
        'DOXYCYCLINE' => 'Access', 'TETRACYCLINE' => 'Access',
        'TRIMETHOPRIM/SULFA' => 'Access', 'SULFAMETHOXAZOLE/TMP' => 'Access',
        'CO-TRIMOXAZOLE' => 'Access', 'CHLORAMPHENICOL' => 'Access',
        'CEFTRIAXONE' => 'Watch', 'CEFOTAXIME' => 'Watch', 'CEFTAZIDIME' => 'Watch',
        'CEFEPIME' => 'Watch', 'CEFUROXIME' => 'Watch', 'CEFIXIME' => 'Watch', 'CEFOXITIN' => 'Watch',
        'CIPROFLOXACIN' => 'Watch', 'LEVOFLOXACIN' => 'Watch', 'MOXIFLOXACIN' => 'Watch',
        'OFLOXACIN' => 'Watch', 'NORFLOXACIN' => 'Watch',
        'PIPERACILLIN/TAZOBACTAM' => 'Watch', 'VANCOMYCIN' => 'Watch', 'TEICOPLANIN' => 'Watch',
        'IMIPENEM' => 'Watch', 'MEROPENEM' => 'Watch', 'ERTAPENEM' => 'Watch', 'DORIPENEM' => 'Watch',
        'CEFOPERAZONE/SULBACTAM' => 'Watch', 'CEFOPERAZONE' => 'Watch',
        'AZITHROMYCIN' => 'Watch', 'CLARITHROMYCIN' => 'Watch', 'ERYTHROMYCIN' => 'Watch',
        'AMPICILLIN/SULBACTAM' => 'Watch',
        'COLISTIN' => 'Reserve', 'POLYMYXIN' => 'Reserve', 'CEFTAZIDIME/AVIBACTAM' => 'Reserve',
        'FOSFOMYCIN' => 'Reserve', 'LINEZOLID' => 'Reserve', 'TIGECYCLINE' => 'Reserve',
        'AZTREONAM' => 'Reserve',
    ];
}

function amr_sens_drug_level_cache($map = false) {
    static $cache = null;
    if ($map !== false) {
        $cache = is_array($map) ? $map : [];
    }
    return is_array($cache) ? $cache : [];
}

function amr_sens_drug_level_normalize_key($drug) {
    $d = strtoupper(trim((string)$drug));
    $d = preg_replace('/\s+/', ' ', $d);
    return $d;
}

function amr_sens_drug_level_lookup($drug) {
    $d = amr_sens_ast_expand_name(amr_sens_drug_level_normalize_key($drug));
    $map = amr_sens_drug_level_cache();
    if ($d !== '' && isset($map[$d])) {
        return $map[$d];
    }
    $best = null;
    $best_len = 0;
    $norm = amr_sens_ast_norm($d);
    foreach ($map as $k => $row) {
        $k = (string)$k;
        $kl = strlen($k);
        if ($kl < 6) {
            continue;
        }
        $hit = ($d === $k)
            || strpos($d, $k) === 0
            || strpos($k, $d) === 0;
        if (!$hit && $norm !== '') {
            $kn = amr_sens_ast_norm($k);
            if (strlen($kn) >= 6 && (strpos($norm, $kn) !== false || strpos($kn, $norm) !== false)) {
                $hit = true;
                $kl = strlen($kn);
            }
        }
        if ($hit && $kl > $best_len) {
            $best = $row;
            $best_len = $kl;
        }
    }
    return $best;
}

function amr_sens_ast_meta_base($drug) {
    $d = amr_sens_ast_expand_name(strtoupper(trim((string)$drug)));
    $classes = amr_sens_ast_class_map();
    $aware = amr_sens_aware_builtin();
    $class = 'Others';
    $best = 0;
    foreach ($classes as $name => $list) {
        foreach ($list as $item) {
            if ($d === $item && strlen($item) > $best) {
                $class = $name;
                $best = strlen($item);
            }
        }
    }
    if ($best === 0) {
        foreach ($classes as $name => $list) {
            foreach ($list as $item) {
                if (strlen($item) < 6) {
                    continue;
                }
                if ((strpos($d, $item) === 0 || strpos($item, $d) === 0) && strlen($item) > $best) {
                    $class = $name;
                    $best = strlen($item);
                }
            }
        }
    }
    $aw = $aware[$d] ?? 'Unclassified';
    if ($aw === 'Unclassified') {
        foreach ($aware as $k => $v) {
            if (strlen($k) >= 6 && (strpos($d, $k) === 0 || strpos($k, $d) === 0)) {
                $aw = $v;
                break;
            }
        }
    }
    return ['class' => $class, 'aware' => $aw];
}

function amr_sens_ast_meta($drug) {
    $base = amr_sens_ast_meta_base($drug);
    $who = (string)($base['aware'] ?? 'Unclassified');
    $hosp = $who;
    $over = amr_sens_drug_level_lookup($drug);
    if ($over) {
        if (!empty($over['aware'])) {
            $hosp = (string)$over['aware'];
        }
        if (!empty($over['class'])) {
            $base['class'] = $over['class'];
        }
    }
    $base['who_aware'] = $who;
    $base['aware'] = $hosp;
    $base['aware_custom'] = ($hosp !== '' && $who !== '' && $hosp !== $who);
    return $base;
}

function amr_sens_ast_better($old, $new) {
    $rank = ['S' => 4, 'I' => 3, 'R' => 3, 'N' => 1];
    $a = $rank[$old['sir']] ?? 0;
    $b = $rank[$new['sir']] ?? 0;
    if ($b !== $a) {
        return $b > $a;
    }
    $mic_old = ($old['mic'] !== '' && $old['mic'] !== '-');
    $mic_new = ($new['mic'] !== '' && $new['mic'] !== '-');
    return $mic_new && !$mic_old;
}

function amr_sens_parse_ast($text) {
    if (amr_sens_is_no_growth($text)) {
        return [];
    }
    $found = [];
    $lines = preg_split("/\\n/", (string)$text);
    $re = '/([A-Z][A-Z0-9][A-Z0-9\/\-]{1,24})(?![A-Z0-9])\.{0,24}\s*(?:((?:[<>]=?\s*)?(?:\d+(?:\.\d+)?(?:\s*\/\s*\d+(?:\.\d+)?)?)|-)\s+)?([SIRN])(?![A-Z])/';
    foreach ($lines as $line) {
        $line = strtoupper(trim($line));
        if ($line === '' || strlen($line) < 4) {
            continue;
        }
        if (strpos($line, 'S=SUSCEPTIBLE') !== false || strpos($line, 'MLAB VERSION') !== false) {
            continue;
        }
        if (strpos($line, '-----') !== false && (strpos($line, 'MIC') !== false || strpos($line, 'ANTIBIOTIC') !== false)) {
            continue;
        }
        if (preg_match('/\b(NO GROWTH|CFU\/|PNEUMONIAE|AERUGINOSA|BAUMANNII|PSEUDOMONAS|KLEBSIELLA|ESCHERICHIA|STAPHYLOCOCCUS|ACINETOBACTER|ENTEROCOCCUS|AEROMONAS)\b/', $line)
            && !preg_match('/\b(AMIKACIN|CEFTAZIDIME|CIPROFLOXACIN|MEROPENEM|CEFEPIME|GENTAMICIN)\b/', $line)) {
            continue;
        }
        if (!preg_match_all($re, $line, $m, PREG_SET_ORDER)) {
            continue;
        }
        foreach ($m as $hit) {
            $drug = amr_sens_ast_expand_name(rtrim($hit[1], '.-'));
            if ($drug === '' || amr_sens_ast_skip_token($drug) || amr_sens_ast_is_organism($drug) || strlen($drug) < 4) {
                continue;
            }
            if ($drug === 'MIC' || $drug === 'SIR' || strpos($drug, '---') !== false) {
                continue;
            }
            $mic = str_replace(' ', '', (string)($hit[2] ?? ''));
            $sir = strtoupper($hit[3]);
            if (!in_array($sir, ['S', 'I', 'R', 'N'], true)) {
                continue;
            }
            $has_mic = ($mic !== '' && $mic !== '-');
            if (!amr_sens_ast_is_known($drug) && !$has_mic) {
                continue;
            }
            if (!amr_sens_ast_is_known($drug) && $has_mic && strlen($drug) < 6) {
                continue;
            }
            $row = [
                'drug' => $drug,
                'mic' => $mic,
                'sir' => $sir,
            ];
            if (!isset($found[$drug]) || amr_sens_ast_better($found[$drug], $row)) {
                $found[$drug] = $row;
            }
        }
    }
    $rows = [];
    foreach ($found as $row) {
        $meta = amr_sens_ast_meta($row['drug']);
        $row['label'] = $row['drug'];
        $row['class'] = $meta['class'];
        $row['aware'] = $meta['aware'];
        $row['who_aware'] = $meta['who_aware'];
        $row['aware_custom'] = !empty($meta['aware_custom']) ? 1 : 0;
        $row['tested'] = in_array($row['sir'], ['S', 'I', 'R'], true);
        $rows[] = $row;
    }
    return $rows;
}

function amr_sens_ast_from_mlab(array $raw) {
    $found = [];
    foreach ($raw as $a) {
        $drug = rtrim(trim((string)($a['drug'] ?? '')), '.');
        $sir = strtoupper(substr(trim((string)($a['sir'] ?? '')), 0, 1));
        if ($drug === '' || !in_array($sir, ['S', 'I', 'R'], true)) {
            continue;
        }
        $canon = amr_sens_ast_expand_name($drug);
        if ($canon === '') {
            $canon = strtoupper($drug);
        }
        $mic = trim((string)($a['mic'] ?? ''));
        if ($mic === '' && trim((string)($a['zone'] ?? '')) !== '') {
            $mic = trim((string)$a['zone']);
        }
        $row = [
            'drug' => $canon,
            'mic' => $mic,
            'sir' => $sir,
        ];
        if (!isset($found[$canon]) || amr_sens_ast_better($found[$canon], $row)) {
            $found[$canon] = $row;
        }
    }
    $rows = [];
    foreach ($found as $row) {
        $meta = amr_sens_ast_meta($row['drug']);
        $row['label'] = $row['drug'];
        $row['class'] = $meta['class'];
        $row['aware'] = $meta['aware'];
        $row['who_aware'] = $meta['who_aware'];
        $row['aware_custom'] = !empty($meta['aware_custom']) ? 1 : 0;
        $row['tested'] = true;
        $rows[] = $row;
    }
    return $rows;
}

function amr_sens_expand_organism_short($name) {
    $n = trim((string)$name);
    $map = [
        'E.coli' => 'Escherichia coli',
        'E.COLI' => 'Escherichia coli',
        'K.pneumoniae' => 'Klebsiella pneumoniae',
        'A.baumannii' => 'Acinetobacter baumannii',
        'P.aeruginosa' => 'Pseudomonas aeruginosa',
        'S.aureus' => 'Staphylococcus aureus',
    ];
    foreach ($map as $short => $full) {
        if (strcasecmp($n, $short) === 0) {
            return $full;
        }
    }
    return $n;
}

function amr_sens_format_organism_label($raw, $phenotype = '') {
    $s = trim(preg_replace('/\s+/', ' ', (string)$raw));
    $s = preg_replace('/^\d+[.)]\s*/', '', $s);
    $s = preg_replace('/\s+NOTE:.*$/i', '', $s);
    $pheno = '';
    if (preg_match('/\.{0,2}\((CRE_MDR|CRAB_MDR|CRPA_MDR|MRSA_VRSA|MDR|MRSA|MRSE|VRE|ESBL|CRE|CRAB|CRPA)\)\.?$/i', $s, $m)) {
        $pheno = strtoupper($m[1]);
        $s = trim(preg_replace('/\.{0,2}\(' . preg_quote($m[1], '/') . '\)\.?$/i', '', $s));
    }
    $s = rtrim($s, '._ ');
    $s = amr_sens_expand_organism_short($s);
    if ($pheno === '') {
        $pheno = strtoupper(trim((string)$phenotype));
    }
    if ($s === '' || strcasecmp($s, 'อื่นๆ') === 0 || preg_match('/no\s*growth/i', $s)) {
        return '';
    }
    if ($pheno !== '' && stripos($s, '(' . $pheno . ')') === false) {
        return $s . ' (' . $pheno . ')';
    }
    return $s;
}

function amr_sens_organism_from_text($text) {
    $text = (string)$text;
    if (preg_match('/CULTURE:\s*(?:\d+\.\s*)?([^\n]+)/i', $text, $m)) {
        $org = trim($m[1]);
        $org = preg_replace('/\s+NOTE:.*$/i', '', $org);
        if ($org !== '') {
            return $org;
        }
    }
    foreach (preg_split("/\n/", $text) as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        if (!preg_match('/\.{0,2}\((CRE_MDR|CRAB_MDR|CRPA_MDR|MRSA_VRSA|MDR|MRSA|MRSE|VRE|ESBL|CRE|CRAB|CRPA)\)/i', $line)
            && !preg_match('/\b(Escherichia|Klebsiella|Pseudomonas|Acinetobacter|Staphylococcus|Enterococcus|Enterobacter|Proteus|Streptococcus|coli|pneumoniae|aureus|baumannii|aeruginosa)\b/i', $line)
        ) {
            continue;
        }
        if (preg_match('/\b(AMIKACIN|CEFTRIAXONE|MEROPENEM|SPECIMEN|GRAM STAIN|ANTIBIOTIC)\b/i', $line)) {
            continue;
        }
        return $line;
    }
    return '';
}

function amr_sens_organism_label($text, array $header = []) {
    $raw = amr_sens_organism_from_text($text);
    $pheno = trim((string)($header['result'] ?? ''));
    if ($raw === '') {
        $raw = trim((string)($header['microtype'] ?? ''));
    }
    return amr_sens_format_organism_label($raw, $pheno);
}

function amr_sens_list_scope($scope) {
    $scope = strtolower(trim((string)$scope));
    if (!in_array($scope, ['growth', 'resistant', 'all'], true)) {
        return 'resistant';
    }
    return $scope;
}

function amr_sens_fetch_list($hos, $q, $start, $end, $scope = 'resistant') {
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $scope = amr_sens_list_scope($scope);
    $q_raw = trim((string)$q);
    $q_num = preg_replace('/\D+/', '', $q_raw);
    $culture = "(lh.result_rtf LIKE '%MIC%' OR lh.result_rtf LIKE '%SIR%' OR lh.result_rtf LIKE '%APPROVED%' OR lh.result_rtf LIKE '%Culture%')";
    $date_sql = "(lh.report_date BETWEEN '$start_esc' AND '$end_esc' AND lh.report_date > '0000-00-00')";
    $where = [
        "lh.result_rtf IS NOT NULL",
        "TRIM(lh.result_rtf) <> ''",
    ];
    if ($q_num !== '') {
        $q_esc = mysqli_real_escape_string($hos, $q_num);
        $hn_trim = mysqli_real_escape_string($hos, ltrim($q_num, '0'));
        $id_match = "(CAST(lh.lab_order_number AS CHAR) = '$q_esc'
            OR CAST(lh.hn AS CHAR) = '$q_esc'
            OR CAST(lh.vn AS CHAR) = '$q_esc'
            OR CAST(i.hn AS CHAR) = '$q_esc'
            OR CAST(i.an AS CHAR) = '$q_esc'
            OR TRIM(LEADING '0' FROM CAST(lh.hn AS CHAR)) = '$hn_trim'
            OR TRIM(LEADING '0' FROM CAST(i.hn AS CHAR)) = '$hn_trim')";
        $where[] = "(CAST(lh.lab_order_number AS CHAR) = '$q_esc' OR ($culture AND $id_match AND $date_sql))";
    } else {
        $where[] = $date_sql;
        $where[] = $culture;
        if ($q_raw !== '') {
            $like = '%' . mysqli_real_escape_string($hos, $q_raw) . '%';
            $where[] = amr_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))") . " LIKE '$like'";
        }
    }

    $microtype_sql = function_exists('amr_sql_microtype_case')
        ? amr_sql_microtype_case('lh.result_rtf', $hos)
        : "' '";
    $result_sql = function_exists('amr_sql_result_case')
        ? amr_sql_result_case('lh.result_rtf', $hos)
        : "''";
    $specimen_sql = function_exists('amr_sql_specimen_case')
        ? amr_sql_specimen_case('lh.result_rtf', $hos)
        : "''";

    $having = [];
    if ($scope === 'growth' || $scope === 'resistant') {
        $having[] = "LOWER(IFNULL(microtype, '')) NOT LIKE '%no growth%'"
            . " AND IFNULL(microtype, '') NOT LIKE '%ไม่พบเชื้อ%'";
    }
    if ($scope === 'resistant') {
        $having[] = "TRIM(IFNULL(result, '')) <> ''";
    }
    $having_sql = $having ? ('HAVING ' . implode(' AND ', $having)) : '';

    $sql = "
        SELECT
            lh.lab_order_number,
            MAX(CONCAT(lh.order_date, ' ', IFNULL(lh.order_time, ''))) AS ordertime,
            MAX(CONCAT(IFNULL(lh.report_date, ''), ' ', IFNULL(lh.report_time, ''))) AS reportdatetime,
            MAX(COALESCE(NULLIF(i.hn, ''), lh.hn)) AS hn,
            MAX(COALESCE(i.an, lh.vn)) AS an,
            MAX(" . amr_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))") . ") AS ptname,
            MAX(" . amr_sql_utf8("IFNULL(w.name, IFNULL(w1.name, ''))") . ") AS Wname,
            MAX($microtype_sql) AS microtype,
            MAX($result_sql) AS result,
            MAX($specimen_sql) AS Specimen
        FROM lab_head lh
        LEFT JOIN ipt i ON i.an = lh.vn
        LEFT JOIN patient pt ON pt.hn = COALESCE(NULLIF(i.hn, ''), lh.hn)
        LEFT JOIN ward w ON w.ward = i.ward
        LEFT JOIN ward_admit_snapshot wa ON wa.an = i.an AND wa.snap_date = lh.order_date
        LEFT JOIN ward w1 ON w1.ward = wa.ward
        WHERE " . implode("\n          AND ", $where) . "
        GROUP BY lh.lab_order_number
        $having_sql
        ORDER BY MAX(lh.report_date) DESC, MAX(lh.report_time) DESC, MAX(lh.order_date) DESC
        LIMIT 80
    ";
    $out = [];
    $qres = mysqli_query($hos, $sql);
    if (!$qres) {
        return ['error' => mysqli_error($hos), 'rows' => []];
    }
    while ($r = mysqli_fetch_assoc($qres)) {
        $out[] = $r;
    }
    return ['error' => '', 'rows' => $out];
}

function amr_sens_fetch_result_text($hos, $order_number) {
    $esc = mysqli_real_escape_string($hos, (string)$order_number);
    $sql = "SELECT " . amr_sens_sql_result_text() . " AS rst
            FROM lab_head lh
            WHERE lh.lab_order_number = '$esc'
            LIMIT 1";
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return '';
    }
    $r = mysqli_fetch_assoc($q);
    $text = amr_sens_clean_rtf($r['rst'] ?? '');
    if (strlen($text) >= 40) {
        return $text;
    }
    $sql2 = "SELECT CAST(CONVERT(lh.result_rtf USING utf8) AS CHAR) AS rst
             FROM lab_head lh
             WHERE lh.lab_order_number = '$esc'
             LIMIT 1";
    $q2 = mysqli_query($hos, $sql2);
    if ($q2 && ($r2 = mysqli_fetch_assoc($q2))) {
        $full = amr_sens_clean_rtf($r2['rst'] ?? '');
        if (strlen($full) > strlen($text)) {
            return $full;
        }
    }
    return $text;
}

function amr_sens_fetch_header($hos, $order_number) {
    $esc = mysqli_real_escape_string($hos, (string)$order_number);
    $microtype_sql = function_exists('amr_sql_microtype_case')
        ? amr_sql_microtype_case('lh.result_rtf', $hos)
        : "''";
    $result_sql = function_exists('amr_sql_result_case')
        ? amr_sql_result_case('lh.result_rtf', $hos)
        : "''";
    $sql = "
        SELECT
            lh.lab_order_number,
            CONCAT(lh.order_date, ' ', IFNULL(lh.order_time, '')) AS ordertime,
            CONCAT(IFNULL(lh.report_date, ''), ' ', IFNULL(lh.report_time, '')) AS reportdatetime,
            COALESCE(NULLIF(i.hn, ''), lh.hn) AS hn,
            COALESCE(i.an, lh.vn) AS an,
            lh.vn,
            " . amr_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))") . " AS ptname,
            " . amr_sql_utf8("IFNULL(w.name, '')") . " AS Wname,
            $microtype_sql AS microtype,
            $result_sql AS result
        FROM lab_head lh
        LEFT JOIN ipt i ON i.an = lh.vn
        LEFT JOIN patient pt ON pt.hn = COALESCE(NULLIF(i.hn, ''), lh.hn)
        LEFT JOIN ward w ON w.ward = i.ward
        WHERE lh.lab_order_number = '$esc'
        LIMIT 1
    ";
    $q = mysqli_query($hos, $sql);
    $row = ($q && ($r = mysqli_fetch_assoc($q))) ? $r : [];
    if (!$row) {
        return [];
    }
    return amr_sens_fill_header_an($hos, $row);
}

function amr_sens_hn_in_sql($hos, $hn) {
    $raw = preg_replace('/\D+/', '', (string)$hn);
    if ($raw === '') {
        return '';
    }
    $padded = str_pad($raw, 9, '0', STR_PAD_LEFT);
    $trim = ltrim($raw, '0');
    if ($trim === '') {
        $trim = '0';
    }
    $vals = array_unique([$padded, $trim, $raw]);
    $out = [];
    foreach ($vals as $v) {
        $out[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return implode(',', $out);
}

function amr_sens_ipt_an_exists($hos, $an) {
    $an = preg_replace('/\D+/', '', (string)$an);
    if ($an === '' || !$hos) {
        return false;
    }
    $esc = mysqli_real_escape_string($hos, $an);
    $q = @mysqli_query($hos, "SELECT an FROM ipt WHERE an = '$esc' LIMIT 1");
    return $q && (bool)mysqli_fetch_assoc($q);
}

function amr_sens_open_an_for_hn($hos, $hn) {
    $hn_in = amr_sens_hn_in_sql($hos, $hn);
    if ($hn_in === '' || !$hos) {
        return '';
    }
    $sql = "SELECT an FROM ipt
        WHERE hn IN ($hn_in)
          AND (dchdate IS NULL OR dchdate = '0000-00-00')
        ORDER BY regdate DESC, an DESC
        LIMIT 1";
    $q = @mysqli_query($hos, $sql);
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return preg_replace('/\D+/', '', (string)$r['an']);
    }
    return '';
}

function amr_sens_resolve_an($hos, $hn, $vn) {
    $open = amr_sens_open_an_for_hn($hos, $hn);
    if ($open !== '') {
        return $open;
    }
    $vn = preg_replace('/\D+/', '', (string)$vn);
    if ($vn !== '' && amr_sens_ipt_an_exists($hos, $vn)) {
        return $vn;
    }
    return $vn;
}

function amr_sens_fill_header_an($hos, array $header) {
    $hn = (string)($header['hn'] ?? '');
    $vn = (string)($header['vn'] ?? $header['an'] ?? '');
    $an = amr_sens_resolve_an($hos, $hn, $vn);
    if ($an !== '') {
        $header['an'] = $an;
    }
    if ($an !== '' && trim((string)($header['Wname'] ?? '')) === '') {
        $esc = mysqli_real_escape_string($hos, $an);
        $q = @mysqli_query($hos, "SELECT CAST(CONVERT(IFNULL(w.name,'') USING utf8) AS CHAR) AS wname
            FROM ipt i
            LEFT JOIN ward w ON w.ward = i.ward
            WHERE i.an = '$esc'
            LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            $header['Wname'] = (string)($r['wname'] ?? '');
        }
    }
    return $header;
}

function amr_sens_egfr_codes($hos, $con = null) {
    $codes = [];
    if ($con) {
        $cfg = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = 'h_code_ckd_epi' LIMIT 1");
        if ($cfg && ($row = mysqli_fetch_assoc($cfg))) {
            foreach (preg_split('/\s*,\s*/', (string)$row['config_value']) as $c) {
                $c = trim($c);
                if ($c !== '') {
                    $codes[] = $c;
                }
            }
        }
    }
    return $codes;
}

function amr_sens_is_egfr_lab($code, $name, array $egfr_codes) {
    $c = trim((string)$code);
    if ($c !== '' && in_array($c, $egfr_codes, true)) {
        return true;
    }
    $u = strtoupper((string)$name);
    return (strpos($u, 'EGFR') !== false || strpos($u, 'CKD-EPI') !== false || strpos($u, 'CKD EPI') !== false);
}

function amr_sens_lab_dt_sql() {
    return "CONCAT(
        IF(lh.report_date IS NULL OR lh.report_date = '0000-00-00', lh.order_date, lh.report_date),
        ' ',
        IFNULL(NULLIF(lh.report_time, ''), IFNULL(lh.order_time, ''))
    )";
}

function amr_sens_fetch_lab_options($hos, $hn, $con = null) {
    $hn_in = amr_sens_hn_in_sql($hos, $hn);
    if ($hn_in === '') {
        return [];
    }
    $egfr_codes = amr_sens_egfr_codes($hos, $con);
    $name_sql = amr_sql_utf8("IFNULL(NULLIF(i.lab_items_name, ''), IFNULL(lo.lab_items_name_ref, ''))");
    $sql = "
        SELECT lo.lab_items_code AS lab_code,
               MAX($name_sql) AS lab_name,
               MAX(" . amr_sql_utf8("IFNULL(i.lab_items_normal_value, '')") . ") AS normal_value,
               MAX(" . amr_sens_lab_dt_sql() . ") AS last_time
        FROM lab_head lh
        INNER JOIN lab_order lo ON lo.lab_order_number = lh.lab_order_number
        LEFT JOIN lab_items i ON i.lab_items_code = lo.lab_items_code
        WHERE lh.hn IN ($hn_in)
          AND lo.lab_order_result IS NOT NULL
          AND TRIM(lo.lab_order_result) <> ''
          AND lh.order_date >= DATE_SUB(CURDATE(), INTERVAL 18 MONTH)
        GROUP BY lo.lab_items_code
        ORDER BY last_time DESC
        LIMIT 80
    ";
    $rows = [];
    $q = mysqli_query($hos, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $code = trim((string)($r['lab_code'] ?? ''));
            $name = trim((string)($r['lab_name'] ?? ''));
            if ($code === '') {
                continue;
            }
            $is_egfr = amr_sens_is_egfr_lab($code, $name, $egfr_codes);
            $u = strtoupper($name);
            $pri = $is_egfr ? 0 : 9;
            if (preg_match('/CREAT|CR\\b|ครีเอต/', $u)) {
                $pri = min($pri, 1);
            }
            if (preg_match('/\\bBUN\\b|ยูเรีย/', $u)) {
                $pri = min($pri, 2);
            }
            $rows[] = [
                'lab_code' => $code,
                'lab_name' => $name !== '' ? $name : $code,
                'normal_value' => trim((string)($r['normal_value'] ?? '')),
                'is_egfr' => $is_egfr ? 1 : 0,
                'priority' => $pri,
            ];
        }
    }
    usort($rows, static function ($a, $b) {
        if ($a['priority'] !== $b['priority']) {
            return $a['priority'] <=> $b['priority'];
        }
        return strcasecmp($a['lab_name'], $b['lab_name']);
    });
    array_unshift($rows, [
        'lab_code' => 'egfr',
        'lab_name' => 'eGFR (CKD-EPI) — ค่าเริ่มต้น',
        'normal_value' => '',
        'is_egfr' => 1,
        'priority' => -1,
    ]);
    return $rows;
}

function amr_sens_fetch_lab_history($hos, $hn, $lab_code = 'egfr', $con = null) {
    $hn_in = amr_sens_hn_in_sql($hos, $hn);
    if ($hn_in === '') {
        return [];
    }
    $lab_code = trim((string)$lab_code);
    if ($lab_code === '') {
        $lab_code = 'egfr';
    }
    $egfr_codes = amr_sens_egfr_codes($hos, $con);
    $name_sql = amr_sql_utf8("IFNULL(NULLIF(i.lab_items_name, ''), IFNULL(lo.lab_items_name_ref, ''))");
    $value_sql = amr_sql_utf8("IFNULL(lo.lab_order_result, '')");
    $normal_sql = amr_sql_utf8("IFNULL(i.lab_items_normal_value, '')");
    if ($lab_code === 'egfr') {
        $code_in = [];
        foreach ($egfr_codes as $c) {
            $code_in[] = "'" . mysqli_real_escape_string($hos, $c) . "'";
        }
        $code_sql = $code_in ? ('lo.lab_items_code IN (' . implode(',', $code_in) . ') OR ') : '';
        $filter = "($code_sql $name_sql LIKE '%eGFR%' OR $name_sql LIKE '%CKD-EPI%' OR $name_sql LIKE '%CKD EPI%')";
    } else {
        $esc = mysqli_real_escape_string($hos, preg_replace('/[^A-Za-z0-9._\\-]/', '', $lab_code));
        if ($esc === '') {
            return [];
        }
        $filter = "lo.lab_items_code = '$esc'";
    }
    $sql = "
        SELECT " . amr_sens_lab_dt_sql() . " AS reporttime,
               $value_sql AS value,
               $name_sql AS lab_name,
               $normal_sql AS normal_value,
               lo.lab_items_code AS lab_code
        FROM lab_head lh
        INNER JOIN lab_order lo ON lo.lab_order_number = lh.lab_order_number
        LEFT JOIN lab_items i ON i.lab_items_code = lo.lab_items_code
        WHERE lh.hn IN ($hn_in)
          AND lo.lab_order_result IS NOT NULL
          AND TRIM(lo.lab_order_result) <> ''
          AND $filter
        ORDER BY lh.report_date DESC, lh.report_time DESC, lh.order_date DESC, lh.order_time DESC
        LIMIT 30
    ";
    $out = [];
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return $out;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $out[] = $r;
    }
    return $out;
}

function amr_sens_fetch_kidney($hos, $hn, $con = null) {
    return amr_sens_fetch_lab_history($hos, $hn, 'egfr', $con);
}

function amr_sens_atb_ensure($con) {
    if (!$con) {
        return false;
    }
    return (bool)@mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_sens_atb_drugs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        icode VARCHAR(24) NOT NULL,
        drug_name VARCHAR(255) NOT NULL DEFAULT '',
        generic_name VARCHAR(255) NOT NULL DEFAULT '',
        dosageform VARCHAR(80) NOT NULL DEFAULT '',
        active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_icode (icode)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
}

function amr_sens_atb_list($con) {
    amr_sens_atb_ensure($con);
    $rows = [];
    $q = @mysqli_query($con, "SELECT id, icode, drug_name, generic_name, dosageform, active
        FROM amr_sens_atb_drugs ORDER BY drug_name ASC, icode ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function amr_sens_atb_active_icodes($con) {
    $codes = [];
    foreach (amr_sens_atb_list($con) as $r) {
        if (!empty($r['active']) && trim((string)($r['icode'] ?? '')) !== '') {
            $codes[] = trim((string)$r['icode']);
        }
    }
    return $codes;
}

function amr_sens_atb_icode_sql($hos, $con, $alias = 'd') {
    $codes = $con ? amr_sens_atb_active_icodes($con) : [];
    if ($codes) {
        $in = [];
        foreach ($codes as $c) {
            $in[] = "'" . mysqli_real_escape_string($hos, $c) . "'";
        }
        return "$alias.icode IN (" . implode(',', $in) . ")";
    }
    return "UPPER(TRIM(IFNULL($alias.antibiotic, ''))) = 'Y'";
}

function amr_sens_atb_add($con, array $drug) {
    amr_sens_atb_ensure($con);
    $icode = trim((string)($drug['icode'] ?? ''));
    if ($icode === '') {
        return ['ok' => false, 'error' => 'ไม่พบ icode'];
    }
    $icode_esc = mysqli_real_escape_string($con, $icode);
    $name_esc = mysqli_real_escape_string($con, trim((string)($drug['drug_name'] ?? $drug['name'] ?? '')));
    $generic_esc = mysqli_real_escape_string($con, trim((string)($drug['generic_name'] ?? '')));
    $dosage_esc = mysqli_real_escape_string($con, trim((string)($drug['dosageform'] ?? '')));
    $sql = "INSERT INTO amr_sens_atb_drugs (icode, drug_name, generic_name, dosageform, active)
        VALUES ('$icode_esc', '$name_esc', '$generic_esc', '$dosage_esc', 1)
        ON DUPLICATE KEY UPDATE
            drug_name = VALUES(drug_name),
            generic_name = VALUES(generic_name),
            dosageform = VALUES(dosageform),
            active = 1";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    return ['ok' => true];
}

function amr_sens_atb_delete($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "DELETE FROM amr_sens_atb_drugs WHERE id = $id");
}

function amr_sens_atb_import_flag($con, $hos) {
    if (!$hos) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้', 'inserted' => 0];
    }
    amr_sens_atb_ensure($con);
    $sql = "
        SELECT d.icode,
               CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
               CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
               IFNULL(d.dosageform, '') AS dosageform
        FROM drugitems d
        WHERE UPPER(TRIM(IFNULL(d.antibiotic, ''))) = 'Y'
        ORDER BY d.name ASC
        LIMIT 800
    ";
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return ['ok' => false, 'error' => mysqli_error($hos), 'inserted' => 0];
    }
    $n = 0;
    while ($r = mysqli_fetch_assoc($q)) {
        $res = amr_sens_atb_add($con, $r);
        if (!empty($res['ok'])) {
            $n++;
        }
    }
    return ['ok' => true, 'inserted' => $n];
}

function amr_sens_atb_method_sql($alias = 'o') {
    return "TRIM(IF($alias.sp_use <> '' AND $alias.sp_use IS NOT NULL,
        CONCAT(IFNULL(sp.name1,''), ' ', IFNULL(sp.name2,''), ' ', IFNULL(sp.name3,'')),
        CONCAT(IFNULL(du.name1,''), ' ', IFNULL(du.name2,''), ' ', IFNULL(du.name3,''))
    ))";
}

function amr_sens_fetch_atb($hos, $an, $hn = '', $con = null) {
    $an_esc = mysqli_real_escape_string($hos, preg_replace('/\D+/', '', (string)$an));
    if ($an_esc === '' || !amr_sens_ipt_an_exists($hos, $an_esc)) {
        $open = amr_sens_open_an_for_hn($hos, $hn);
        if ($open !== '') {
            $an_esc = mysqli_real_escape_string($hos, $open);
        }
    }
    $hn_in = amr_sens_hn_in_sql($hos, $hn);
    $drug = amr_sql_utf8("TRIM(CONCAT(IFNULL(NULLIF(d.name,''), IFNULL(d.generic_name,'')), ' ', IFNULL(d.strength,'')))");
    $ptname = amr_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))");
    $atb_flag = amr_sens_atb_icode_sql($hos, $con, 'd');
    $method = amr_sens_atb_method_sql('o');
    $where = [];
    if ($an_esc !== '') {
        $where[] = "o.an = '$an_esc'";
    } elseif ($hn_in !== '') {
        $where[] = "o.hn IN ($hn_in)";
    } else {
        return [];
    }
    $sql = "
        SELECT CONCAT(o.rxdate, ' ', IFNULL(o.rxtime, '')) AS rxtime,
               DATE_FORMAT(o.rxdate, '%Y-%m-%d') AS rxdate,
               IFNULL(o.rxtime, '') AS rxtime_raw,
               o.hn,
               o.an,
               o.icode,
               $ptname AS ptname,
               $drug AS drugName,
               IFNULL(o.qty, '') AS qty,
               CAST(CONVERT(IFNULL(d.units, '') USING utf8) AS CHAR) AS units,
               CAST(CONVERT(IFNULL(d.strength, '') USING utf8) AS CHAR) AS strength,
               CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
               CAST(CONVERT($method USING utf8) AS CHAR) AS method,
               'opitemrece' AS source,
               '' AS offdate
        FROM opitemrece o
        INNER JOIN drugitems d ON d.icode = o.icode AND $atb_flag
        LEFT JOIN drugusage du ON du.drugusage = o.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
        LEFT JOIN patient pt ON pt.hn = o.hn
        WHERE " . implode(' AND ', $where) . "
          AND o.qty > 0
        ORDER BY o.rxdate DESC, o.rxtime DESC, o.item_no DESC
        LIMIT 200
    ";
    $out = [];
    $q = mysqli_query($hos, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $r['drugName'] = trim((string)($r['drugName'] ?? ''));
            $r['method'] = trim(preg_replace('/\\s+/u', ' ', (string)($r['method'] ?? '')));
            $out[] = $r;
        }
    }
    if ($out || $an_esc === '') {
        return $out;
    }
    $method_m = "TRIM(IF(m.sp_use <> '' AND m.sp_use IS NOT NULL,
        CONCAT(IFNULL(sp.name1,''), ' ', IFNULL(sp.name2,''), ' ', IFNULL(sp.name3,'')),
        CONCAT(IFNULL(du.name1,''), ' ', IFNULL(du.name2,''), ' ', IFNULL(du.name3,''))
    ))";
    $sql2 = "
        SELECT CONCAT(m.orderdate, '') AS rxtime,
               DATE_FORMAT(m.orderdate, '%Y-%m-%d') AS rxdate,
               '' AS rxtime_raw,
               i.hn,
               m.an,
               m.icode,
               $ptname AS ptname,
               $drug AS drugName,
               IFNULL(m.qty, '') AS qty,
               CAST(CONVERT(IFNULL(d.units, '') USING utf8) AS CHAR) AS units,
               CAST(CONVERT(IFNULL(d.strength, '') USING utf8) AS CHAR) AS strength,
               CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
               CAST(CONVERT($method_m USING utf8) AS CHAR) AS method,
               'medplan_ipd' AS source,
               DATE_FORMAT(m.offdate, '%Y-%m-%d') AS offdate
        FROM medplan_ipd m
        INNER JOIN drugitems d ON d.icode = m.icode AND $atb_flag
        LEFT JOIN drugusage du ON du.drugusage = m.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = m.sp_use
        LEFT JOIN ipt i ON i.an = m.an
        LEFT JOIN patient pt ON pt.hn = i.hn
        WHERE m.an = '$an_esc'
        ORDER BY m.orderdate DESC, m.med_plan_number DESC
        LIMIT 80
    ";
    $q2 = mysqli_query($hos, $sql2);
    if ($q2) {
        while ($r = mysqli_fetch_assoc($q2)) {
            $r['drugName'] = trim((string)($r['drugName'] ?? ''));
            $r['method'] = trim(preg_replace('/\\s+/u', ' ', (string)($r['method'] ?? '')));
            $out[] = $r;
        }
    }
    return $out;
}

function amr_sens_offdate_empty($offdate) {
    $d = trim((string)$offdate);
    return $d === '' || $d === '0000-00-00' || $d === '0000-00-00 00:00:00';
}

function amr_sens_fetch_atb_current($hos, $an, $hn = '', $con = null) {
    $an_esc = mysqli_real_escape_string($hos, preg_replace('/\D+/', '', (string)$an));
    if ($an_esc === '' || !amr_sens_ipt_an_exists($hos, $an_esc)) {
        $open = amr_sens_open_an_for_hn($hos, $hn);
        if ($open !== '') {
            $an_esc = mysqli_real_escape_string($hos, $open);
        }
    }
    $hn_in = amr_sens_hn_in_sql($hos, $hn);
    $drug = amr_sql_utf8("TRIM(CONCAT(IFNULL(NULLIF(d.name,''), IFNULL(d.generic_name,'')), ' ', IFNULL(d.strength,'')))");
    $atb_flag = amr_sens_atb_icode_sql($hos, $con, 'd');
    $today = date('Y-m-d');
    $out = [];
    if ($an_esc !== '') {
        $sql = "
            SELECT mp.icode,
                   $drug AS drugName,
                   CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
                   DATE_FORMAT(mp.orderdate, '%Y-%m-%d') AS orderdate
            FROM medplan_ipd mp
            INNER JOIN drugitems d ON d.icode = mp.icode AND $atb_flag
            INNER JOIN opitemrece o ON o.an = mp.an
                AND o.icode = mp.icode
                AND o.rxdate = '$today'
                AND o.qty > 0
            WHERE mp.an = '$an_esc'
              AND (mp.offdate IS NULL OR mp.offdate = '0000-00-00')
              AND mp.qty > 0
            GROUP BY mp.icode, d.name, d.generic_name, d.strength, mp.orderdate
        ";
        $q = @mysqli_query($hos, $sql);
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $r['drugName'] = trim((string)($r['drugName'] ?? ''));
                $r['on_now'] = 1;
                $out[] = $r;
            }
        }
    }
    if ($out || $hn_in === '') {
        return $out;
    }
    $sql = "
        SELECT o.icode,
               $drug AS drugName,
               CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
               DATE_FORMAT(o.rxdate, '%Y-%m-%d') AS orderdate
        FROM opitemrece o
        INNER JOIN drugitems d ON d.icode = o.icode AND $atb_flag
        WHERE o.hn IN ($hn_in)
          AND o.rxdate = '$today'
          AND o.qty > 0
        GROUP BY o.icode, d.name, d.generic_name, d.strength, o.rxdate
    ";
    $q = @mysqli_query($hos, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $r['drugName'] = trim((string)($r['drugName'] ?? ''));
            $r['on_now'] = 1;
            $out[] = $r;
        }
    }
    return $out;
}

function amr_sens_fetch_atb_active($hos, $an, $hn = '', $con = null) {
    $an_esc = mysqli_real_escape_string($hos, preg_replace('/\D+/', '', (string)$an));
    if ($an_esc === '' || !amr_sens_ipt_an_exists($hos, $an_esc)) {
        $open = amr_sens_open_an_for_hn($hos, $hn);
        if ($open !== '') {
            $an_esc = mysqli_real_escape_string($hos, $open);
        }
    }
    $drug = amr_sql_utf8("TRIM(CONCAT(IFNULL(NULLIF(d.name,''), IFNULL(d.generic_name,'')), ' ', IFNULL(d.strength,'')))");
    $atb_flag = amr_sens_atb_icode_sql($hos, $con, 'd');
    $out = [];
    if ($an_esc === '') {
        return amr_sens_fetch_atb_current($hos, $an, $hn, $con);
    }
    $sql = "
        SELECT mp.icode,
               $drug AS drugName,
               CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
               DATE_FORMAT(mp.orderdate, '%Y-%m-%d') AS orderdate
        FROM medplan_ipd mp
        INNER JOIN drugitems d ON d.icode = mp.icode AND $atb_flag
        WHERE mp.an = '$an_esc'
          AND (mp.offdate IS NULL OR mp.offdate = '0000-00-00')
          AND mp.qty > 0
        GROUP BY mp.icode, d.name, d.generic_name, d.strength, mp.orderdate
    ";
    $q = @mysqli_query($hos, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $r['drugName'] = trim((string)($r['drugName'] ?? ''));
            $out[] = $r;
        }
    }
    return $out;
}

function amr_sens_mark_atb_on_now(array $atb, array $current, array $active = []) {
    $now = [];
    foreach ($current as $c) {
        $ic = trim((string)($c['icode'] ?? ''));
        if ($ic !== '') {
            $now[$ic] = true;
        }
    }
    $act = [];
    foreach ($active as $c) {
        $ic = trim((string)($c['icode'] ?? ''));
        if ($ic !== '') {
            $act[$ic] = true;
        }
    }
    if (!$act) {
        $act = $now;
    }
    foreach ($atb as &$row) {
        $ic = trim((string)($row['icode'] ?? ''));
        $row['on_now'] = ($ic !== '' && !empty($now[$ic])) ? 1 : 0;
        $row['on_active'] = ($ic !== '' && !empty($act[$ic])) ? 1 : 0;
    }
    unset($row);
    return $atb;
}

function amr_sens_parse_lab_num($value) {
    if (preg_match('/-?\d+(?:\.\d+)?/', (string)$value, $m)) {
        return (float)$m[0];
    }
    return null;
}

function amr_sens_kidney_for_order(array $kidney, $when) {
    $when_ts = strtotime((string)$when) ?: 0;
    $best_before = null;
    $latest = null;
    foreach ($kidney as $row) {
        $val = amr_sens_parse_lab_num($row['value'] ?? '');
        if ($val === null || $val <= 0) {
            continue;
        }
        $ts = strtotime((string)($row['reporttime'] ?? '')) ?: 0;
        $item = [
            'val' => $val,
            'date' => substr((string)($row['reporttime'] ?? ''), 0, 10),
            'raw' => trim((string)($row['value'] ?? '')),
            'ts' => $ts,
        ];
        if ($latest === null || $ts > ($latest['ts'] ?? 0)) {
            $latest = $item;
        }
        if ($when_ts && $ts && $ts > $when_ts) {
            continue;
        }
        if ($best_before === null || $ts > ($best_before['ts'] ?? 0)) {
            $best_before = $item;
        }
    }
    return $best_before ?: $latest;
}

function amr_sens_load_renal_rule_map($con) {
    $map = [];
    if (!$con) {
        return $map;
    }
    foreach ([
        'ensure_drug_safety_rules_hosxp_columns',
        'ensure_drug_safety_rules_alert_level_column',
        'ensure_drug_safety_rules_patient_extra_columns',
        'ensure_drug_safety_rules_duration_columns',
        'ensure_drug_safety_rules_dose_per_admin_columns',
        'ensure_drug_safety_rules_exempt_method_columns',
    ] as $fn) {
        if (function_exists($fn)) {
            $fn($con);
        }
    }
    $q = @mysqli_query($con, "SELECT * FROM drug_safety_rules
        WHERE active_status = 1
          AND lab_type IN ('CKD_EPI', 'GFR', 'SERUM_CR')
          AND drug_icode IS NOT NULL AND TRIM(drug_icode) <> ''");
    if (!$q) {
        return $map;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $icode = trim((string)($r['drug_icode'] ?? ''));
        if ($icode === '') {
            continue;
        }
        $map[$icode][] = $r;
    }
    return $map;
}

function amr_sens_catalog_rules_for_drug($drug_name, $generic_name = '') {
    return [];
}

function amr_sens_rule_lab_value(array $rule, array $labs) {
    $t = strtoupper(trim((string)($rule['lab_type'] ?? 'CKD_EPI')));
    if ($t === 'SERUM_CR' || $t === 'SCR') {
        return (float)($labs['SERUM_CR'] ?? 0);
    }
    if ($t === 'GFR') {
        $gfr = (float)($labs['GFR'] ?? 0);
        return $gfr > 0 ? $gfr : (float)($labs['CKD_EPI'] ?? 0);
    }
    $egfr = (float)($labs['CKD_EPI'] ?? 0);
    return $egfr > 0 ? $egfr : (float)($labs['GFR'] ?? 0);
}

function amr_sens_labs_from_egfr($egfr) {
    if (is_array($egfr)) {
        return $egfr;
    }
    $v = (float)$egfr;
    return ['CKD_EPI' => $v, 'GFR' => $v, 'SERUM_CR' => 0];
}

function amr_sens_pick_renal_rule(array $rules, $labs, array $order = []) {
    $labs = amr_sens_labs_from_egfr($labs);
    if (!$rules) {
        return null;
    }
    if (function_exists('monitor_lab_should_exempt_method_from_rules')
        && monitor_lab_should_exempt_method_from_rules($rules, $order['method'] ?? '')) {
        return null;
    }
    $age = (float)($order['age'] ?? 0);
    $weight = (float)($order['weight'] ?? $order['bw'] ?? 0);
    $best = null;
    $best_score = -1;
    foreach ($rules as $rule) {
        $val = amr_sens_rule_lab_value($rule, $labs);
        $min = (float)($rule['min_val'] ?? 0);
        $max = (float)($rule['max_val'] ?? 0);
        if ($val <= 0 || $val < $min || $val > $max) {
            continue;
        }
        if (function_exists('monitor_lab_match_patient_extra')
            && !monitor_lab_match_patient_extra($rule, $age, $weight)) {
            continue;
        }
        if (function_exists('monitor_lab_order_dose_conditions_match')
            && !monitor_lab_order_dose_conditions_match($rule, $order)) {
            continue;
        }
        if (function_exists('monitor_lab_duration_check')) {
            $dur = monitor_lab_duration_check($rule, $order['method'] ?? '');
            if (!empty($dur['skip_alert'])) {
                continue;
            }
        }
        if (!empty($rule['first_order_only'])) {
            if (!array_key_exists('is_first_order', $order) || empty($order['is_first_order'])) {
                continue;
            }
        }
        $level = function_exists('monitor_lab_alert_level_from_rule')
            ? monitor_lab_alert_level_from_rule($rule)
            : ((($rule['alert_level'] ?? '') === 'hard' || ($rule['action_type'] ?? '') === 'omit') ? 'hard' : 'soft');
        $span = max(0.01, $max - $min);
        $score = ($level === 'hard' ? 1000 : 0) + (100 / $span);
        if ($score > $best_score) {
            $best_score = $score;
            $rule['_level'] = $level;
            $rule['_lab_value'] = $val;
            $best = $rule;
        }
    }
    return $best;
}

function amr_sens_annotate_atb_renal($con, array $atb, array $kidney) {
    if (!$atb) {
        return $atb;
    }
    $rule_map = amr_sens_load_renal_rule_map($con);
    foreach ($atb as &$row) {
        $row['renal_alert'] = null;
        $lab = amr_sens_kidney_for_order($kidney, $row['rxtime'] ?? $row['rxdate'] ?? '');
        if (!$lab) {
            continue;
        }
        $icode = trim((string)($row['icode'] ?? ''));
        $rules = ($icode !== '' && !empty($rule_map[$icode])) ? $rule_map[$icode] : [];
        $hit = amr_sens_pick_renal_rule($rules, (float)$lab['val'], $row);
        if (!$hit) {
            continue;
        }
        $min = rtrim(rtrim(number_format((float)($hit['min_val'] ?? 0), 2, '.', ''), '0'), '.');
        $max = rtrim(rtrim(number_format((float)($hit['max_val'] ?? 0), 2, '.', ''), '0'), '.');
        $row['renal_alert'] = [
            'level' => ($hit['_level'] ?? 'soft') === 'hard' ? 'hard' : 'soft',
            'msg' => trim((string)($hit['suggestion_msg'] ?? '')),
            'lab_type' => (string)($hit['lab_type'] ?? 'CKD_EPI'),
            'lab_value' => $lab['val'],
            'lab_date' => $lab['date'],
            'range' => $min . '–' . $max,
        ];
    }
    unset($row);
    return $atb;
}

function amr_sens_fetch_wards($hos, $an) {
    $an_esc = mysqli_real_escape_string($hos, preg_replace('/\D+/', '', (string)$an));
    if ($an_esc === '') {
        return [];
    }
    $sql = "
        SELECT wa.an,
               wa.snap_date,
               " . amr_sql_utf8("IFNULL(w.name, '')") . " AS Wname
        FROM ward_admit_snapshot wa
        LEFT JOIN ward w ON w.ward = wa.ward
        WHERE wa.an = '$an_esc'
        ORDER BY wa.snap_date DESC
        LIMIT 40
    ";
    $out = [];
    $q = mysqli_query($hos, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $out[] = $r;
        }
    }
    if ($out) {
        return $out;
    }
    $sql2 = "
        SELECT i.an,
               i.regdate AS snap_date,
               " . amr_sql_utf8("IFNULL(w.name, '')") . " AS Wname
        FROM ipt i
        LEFT JOIN ward w ON w.ward = i.ward
        WHERE i.an = '$an_esc'
        LIMIT 1
    ";
    $q2 = mysqli_query($hos, $sql2);
    if ($q2) {
        while ($r = mysqli_fetch_assoc($q2)) {
            $out[] = $r;
        }
    }
    return $out;
}

function amr_sens_sir_for_atb_name(array $ast, $name) {
    $best = null;
    $best_len = 0;
    foreach ($ast as $a) {
        $sir = strtoupper((string)($a['sir'] ?? ''));
        if (!in_array($sir, ['S', 'I', 'R'], true)) {
            continue;
        }
        $drug = (string)($a['drug'] ?? '');
        if (!amr_sens_ast_matches_atb($drug, $name)) {
            continue;
        }
        $len = strlen(amr_sens_ast_norm($drug));
        if ($len >= $best_len) {
            $best_len = $len;
            $a['sir'] = $sir;
            $best = $a;
        }
    }
    return $best;
}

function amr_sens_renal_advice_for_name($con, $name, $egfr, $icode = '', array $order = [], array $rule_map = null) {
    $labs = amr_sens_labs_from_egfr($egfr);
    if (!empty($order['labs']) && is_array($order['labs'])) {
        $labs = array_merge($labs, $order['labs']);
    }
    $egfr_val = (float)($labs['CKD_EPI'] ?? 0);
    $rules = [];
    if ($icode !== '') {
        if ($rule_map === null && $con) {
            $rule_map = amr_sens_load_renal_rule_map($con);
        }
        $rules = $rule_map[$icode] ?? [];
    }
    if (!$rules) {
        if ($egfr_val <= 0 && (float)($labs['SERUM_CR'] ?? 0) <= 0) {
            return ['status' => 'no_egfr', 'level' => '', 'msg' => 'ไม่มีผล eGFR สำหรับประเมินขนาดยา'];
        }
        return ['status' => 'ok', 'level' => '', 'msg' => ''];
    }
    if ($egfr_val <= 0 && (float)($labs['SERUM_CR'] ?? 0) <= 0 && (float)($labs['GFR'] ?? 0) <= 0) {
        return ['status' => 'no_egfr', 'level' => '', 'msg' => 'ไม่มีผล eGFR สำหรับประเมินขนาดยา'];
    }
    $egfr_txt = $egfr_val > 0
        ? rtrim(rtrim(number_format($egfr_val, 2, '.', ''), '0'), '.')
        : '';
    $hit = amr_sens_pick_renal_rule($rules, $labs, $order);
    if (!$hit) {
        return [
            'status' => 'ok',
            'level' => '',
            'msg' => $egfr_txt !== '' ? ('ไม่เข้าเงื่อนไข Monitor Lab Renal ที่ eGFR ' . $egfr_txt) : 'ไม่เข้าเงื่อนไข Monitor Lab Renal',
        ];
    }
    $level = (($hit['_level'] ?? 'soft') === 'hard') ? 'hard' : 'soft';
    return [
        'status' => $level === 'hard' ? 'avoid' : 'adjust',
        'level' => $level,
        'msg' => trim((string)($hit['suggestion_msg'] ?? '')),
        'lab_type' => (string)($hit['lab_type'] ?? 'CKD_EPI'),
    ];
}

function amr_sens_cdss_config_ensure($con) {
    if (!$con) {
        return false;
    }
    $ok = @mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_cdss_config (
        config_key VARCHAR(64) NOT NULL,
        config_value TEXT NOT NULL,
        updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (config_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    if ($ok) {
        static $widened = false;
        if (!$widened) {
            $widened = true;
            $q = @mysqli_query($con, "SHOW COLUMNS FROM amr_cdss_config LIKE 'config_value'");
            $col = $q ? mysqli_fetch_assoc($q) : null;
            $type = strtolower((string)($col['Type'] ?? ''));
            if ($type !== '' && strpos($type, 'varchar') !== false) {
                @mysqli_query($con, "ALTER TABLE amr_cdss_config MODIFY config_value TEXT NOT NULL");
            }
        }
    }
    return (bool)$ok;
}

function amr_sens_steward_mode_normalize($raw) {
    $s = strtolower(trim((string)$raw));
    $s = str_replace(['-', ' '], '_', $s);
    if ($s === 'escalate' || $s === 'up') {
        return 'escalate';
    }
    if (in_array($s, ['deescalate', 'de_escalate', 'down'], true)) {
        return 'deescalate';
    }
    return 'both';
}

function amr_sens_steward_mode($con) {
    if (!amr_sens_cdss_config_ensure($con)) {
        return 'both';
    }
    $q = @mysqli_query($con, "SELECT config_value FROM amr_cdss_config WHERE config_key = 'steward_mode' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return amr_sens_steward_mode_normalize($r['config_value'] ?? 'both');
    }
    return 'both';
}

function amr_sens_steward_mode_save($con, $mode) {
    $mode = amr_sens_steward_mode_normalize($mode);
    if (!amr_sens_cdss_config_ensure($con)) {
        return $mode;
    }
    $esc = mysqli_real_escape_string($con, $mode);
    @mysqli_query($con, "INSERT INTO amr_cdss_config (config_key, config_value)
        VALUES ('steward_mode', '$esc')
        ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)");
    return $mode;
}

function amr_sens_steward_mode_meta($mode = 'both') {
    $mode = amr_sens_steward_mode_normalize($mode);
    $labels = [
        'both' => 'ทั้ง Escalate และ De-escalate',
        'escalate' => 'Escalate — ยาปัจจุบัน R/I ต้องเปลี่ยนไปใช้ยาผล S',
        'deescalate' => 'De-escalate — ยาปัจจุบันผล S แล้วลดไปใช้ยาที่ระดับ รพ. ต่ำกว่า',
    ];
    return [
        'mode' => $mode,
        'label' => $labels[$mode],
        'options' => [
            ['value' => 'both', 'label' => 'ทั้งสอง (ค่าเริ่มต้น)'],
            ['value' => 'escalate', 'label' => 'Escalate เท่านั้น'],
            ['value' => 'deescalate', 'label' => 'De-escalate เท่านั้น'],
        ],
    ];
}

function amr_sens_steward_score($aware, $class, array $ranks) {
    $ar = (int)($ranks['aware'][$aware] ?? 90);
    $cr = (int)($ranks['class'][$class] ?? 90);
    return ($ar * 100) + $cr;
}

function amr_sens_steward_score_for_name($name, array $ranks) {
    $meta = amr_sens_ast_meta($name);
    return amr_sens_steward_score($meta['aware'] ?? '', $meta['class'] ?? '', $ranks);
}

function amr_sens_steward_action($current_score, $candidate_score) {
    if ($current_score === null) {
        return 'start';
    }
    $cur_aw = intdiv((int)$current_score, 100);
    $cand_aw = intdiv((int)$candidate_score, 100);
    if ($cand_aw < $cur_aw) {
        return 'deescalate';
    }
    if ($cand_aw > $cur_aw) {
        return 'escalate';
    }
    return 'same';
}

function amr_sens_s_alts_for_current(array $ast, $current_name, array $ranks, $current_sir = '') {
    $cur_score = amr_sens_steward_score_for_name($current_name, $ranks);
    $sir = strtoupper(trim((string)$current_sir));
    $must_change = ($sir === 'R' || $sir === 'I');
    $de = [];
    $es = [];
    $same = [];
    foreach ($ast as $a) {
        if (strtoupper((string)($a['sir'] ?? '')) !== 'S') {
            continue;
        }
        $drug = trim((string)($a['drug'] ?? ''));
        if ($drug === '' || amr_sens_ast_matches_atb($drug, $current_name)) {
            continue;
        }
        $score = amr_sens_steward_score($a['aware'] ?? '', $a['class'] ?? '', $ranks);
        $row = [
            'drug' => $drug,
            'mic' => $a['mic'] ?? '',
            'class' => $a['class'] ?? '',
            'aware' => $a['aware'] ?? '',
            'who_aware' => $a['who_aware'] ?? '',
            'score' => $score,
        ];
        if ($must_change) {
            $es[] = $row;
            continue;
        }
        $act = amr_sens_steward_action($cur_score, $score);
        if ($act === 'deescalate') {
            $de[] = $row;
        } elseif ($act === 'escalate') {
            $es[] = $row;
        } else {
            $same[] = $row;
        }
    }
    $sort = static function ($a, $b) {
        if ($a['score'] !== $b['score']) {
            return $a['score'] - $b['score'];
        }
        return strcmp((string)$a['drug'], (string)$b['drug']);
    };
    usort($de, $sort);
    usort($es, $sort);
    usort($same, $sort);
    return [
        'current_score' => $cur_score,
        'deescalate' => $de,
        'escalate' => $es,
        'same' => $same,
    ];
}

function amr_sens_build_therapy_summary($con, array $ast, array $atb_current, array $atb, array $kidney, $no_growth = false, $organism = '') {
    $lab = amr_sens_kidney_for_order($kidney, date('Y-m-d H:i:s'));
    $egfr = (float)($lab['val'] ?? 0);
    $egfr_date = (string)($lab['date'] ?? '');
    $rule_map = amr_sens_load_renal_rule_map($con);

    $current_src = $atb_current;
    if (!$current_src) {
        $current_src = [];
        foreach ($atb as $r) {
            if (!empty($r['on_now']) || !empty($r['on_active'])) {
                $current_src[] = $r;
            }
        }
    }
    $uniq = [];
    foreach ($current_src as $r) {
        $ic = trim((string)($r['icode'] ?? ''));
        $key = $ic !== '' ? $ic : trim((string)($r['drugName'] ?? ''));
        if ($key === '' || isset($uniq[$key])) {
            continue;
        }
        $uniq[$key] = $r;
    }

    $ranks = amr_sens_rec_rank_maps($con);
    $mode = amr_sens_steward_mode($con);
    $current = [];
    $has_r = false;
    $has_i = false;
    $has_s = false;
    $has_u = false;
    $can_deescalate = false;
    $need_escalate = false;
    foreach ($uniq as $r) {
        $name = trim((string)($r['drugName'] ?? $r['generic_name'] ?? ''));
        $hit = amr_sens_sir_for_atb_name($ast, $name);
        if (!$hit && trim((string)($r['generic_name'] ?? '')) !== '') {
            $hit = amr_sens_sir_for_atb_name($ast, $r['generic_name']);
        }
        $sir = strtoupper((string)($hit['sir'] ?? ''));
        $renal = amr_sens_renal_advice_for_name($con, $name, $egfr, (string)($r['icode'] ?? ''), $r, $rule_map);
        if ($sir === 'R') {
            $has_r = true;
            $fit = 'inappropriate';
        } elseif ($sir === 'S') {
            $has_s = true;
            $fit = 'appropriate';
        } elseif ($sir === 'I') {
            $has_i = true;
            $fit = 'caution';
        } else {
            $has_u = true;
            $fit = 'unknown';
        }
        $alts = ($sir === 'S' || $sir === 'I' || $sir === 'R')
            ? amr_sens_s_alts_for_current($ast, $name, $ranks, $sir)
            : ['deescalate' => [], 'escalate' => [], 'same' => []];
        $row_can_de = ($sir === 'S') && !empty($alts['deescalate']);
        $row_need_es = ($sir === 'R' || $sir === 'I');
        if ($row_can_de) {
            $can_deescalate = true;
        }
        if ($row_need_es) {
            $need_escalate = true;
        }
        $steward = 'ok';
        if ($row_need_es && $row_can_de) {
            $steward = 'both';
        } elseif ($row_need_es) {
            $steward = 'escalate';
        } elseif ($row_can_de) {
            $steward = 'deescalate';
        } elseif ($sir === '' || $sir === 'N') {
            $steward = 'unknown';
        }
        $pick = static function (array $list, $n = 3) {
            $out = [];
            foreach (array_slice($list, 0, $n) as $x) {
                $out[] = $x['drug'];
            }
            return $out;
        };
        $current[] = [
            'drugName' => $name,
            'icode' => $r['icode'] ?? '',
            'method' => $r['method'] ?? '',
            'sir' => $sir,
            'mic' => $hit['mic'] ?? '',
            'fit' => $fit,
            'renal' => $renal,
            'aware' => ($hit['aware'] ?? '') !== '' ? $hit['aware'] : (amr_sens_ast_meta($name)['aware'] ?? ''),
            'who_aware' => ($hit['who_aware'] ?? '') !== '' ? $hit['who_aware'] : (amr_sens_ast_meta($name)['who_aware'] ?? ''),
            'class' => ($hit['class'] ?? '') !== '' ? $hit['class'] : (amr_sens_ast_meta($name)['class'] ?? ''),
            'steward' => $steward,
            'can_deescalate' => $row_can_de ? 1 : 0,
            'need_escalate' => $row_need_es ? 1 : 0,
            'deescalate_to' => $pick($alts['deescalate']),
            'escalate_to' => $pick($alts['escalate']),
        ];
    }

    $want_es = ($mode === 'escalate' || $mode === 'both');
    $want_de = ($mode === 'deescalate' || $mode === 'both');
    if ($no_growth) {
        $verdict = 'no_growth';
        $title = 'ไม่พบเชื้อ — ไม่มีผล AST ให้ประเมินความเหมาะสมของยา';
    } elseif (!$ast) {
        $verdict = 'no_ast';
        $title = 'ยังไม่มีผล Sensitivity สำหรับประเมิน';
    } elseif (!$current) {
        $verdict = 'no_current';
        $title = 'วันนี้ไม่มียาปฏิชีวนะที่กำลังให้';
    } elseif ($has_r) {
        $verdict = 'inappropriate';
        if ($can_deescalate && $want_de) {
            $title = 'ไม่เหมาะสม (R) — ควรเปลี่ยนยา และมีทางลดชั้นได้';
        } elseif ($want_es) {
            $title = 'ไม่เหมาะสม — กำลังให้ยาที่ผลเป็น R ควร Escalate';
        } else {
            $title = 'ไม่เหมาะสม — กำลังให้ยาที่ผลเป็น R';
        }
    } elseif ($has_i && !$has_s) {
        $verdict = 'caution';
        $title = $can_deescalate && $want_de
            ? 'ใช้ด้วยความระวัง (I) และมีทางลดชั้นได้'
            : 'ใช้ด้วยความระวัง — ยาที่กำลังให้ผลเป็น I';
    } elseif ($can_deescalate && $want_de && $has_s) {
        $verdict = 'deescalate';
        $title = 'สามารถ De-escalate — มียาระดับ AWaRe ต่ำกว่าที่ผลเป็น S';
    } elseif ($has_s) {
        $verdict = 'appropriate';
        $title = 'เหมาะสม — ยาที่กำลังให้ผลเป็น S';
    } else {
        $verdict = 'unknown';
        $title = 'ยังจับคู่ผล AST กับยาที่กำลังให้ไม่ได้';
    }
    $organism = trim((string)$organism);
    if ($organism !== '' && $verdict !== 'no_growth') {
        $title .= ' — ' . $organism;
    }

    $aware_rank = $ranks['aware'];
    $class_rank = $ranks['class'];
    $cur_score = null;
    $cur_inadequate = $has_r || $has_i;
    foreach ($current as $c) {
        if (($c['sir'] ?? '') === '' || ($c['sir'] ?? '') === 'N') {
            continue;
        }
        $sc = amr_sens_steward_score($c['aware'] ?? '', $c['class'] ?? '', $ranks);
        if ($cur_score === null || $sc > $cur_score) {
            $cur_score = $sc;
        }
    }
    $recs = [];
    $avoid = [];
    foreach ($ast as $a) {
        if (strtoupper((string)($a['sir'] ?? '')) !== 'S') {
            continue;
        }
        $drug = trim((string)($a['drug'] ?? ''));
        if ($drug === '') {
            continue;
        }
        $on = false;
        foreach ($current as $c) {
            if (amr_sens_ast_matches_atb($drug, $c['drugName'])) {
                $on = true;
                break;
            }
        }
        $renal = amr_sens_renal_advice_for_name($con, $drug, $egfr, '', [], $rule_map);
        $score = amr_sens_steward_score($a['aware'] ?? '', $a['class'] ?? '', $ranks);
        $action = amr_sens_steward_action($cur_score, $score);
        if ($on) {
            $action = 'continue';
        } elseif ($cur_inadequate && $action === 'deescalate') {
            $action = 'escalate';
        }
        $row = [
            'drug' => $drug,
            'mic' => $a['mic'] ?? '',
            'class' => $a['class'] ?? '',
            'aware' => $a['aware'] ?? '',
            'who_aware' => $a['who_aware'] ?? '',
            'on_now' => $on ? 1 : 0,
            'renal' => $renal,
            'action' => $action,
            'score' => $score,
        ];
        if (($renal['status'] ?? '') === 'avoid') {
            $avoid[] = $row;
            continue;
        }
        $keep = false;
        if ($cur_score === null) {
            $keep = true;
        } elseif ($action === 'continue') {
            $keep = false;
        } elseif ($action === 'deescalate') {
            $keep = $want_de;
        } elseif ($action === 'escalate') {
            $keep = $want_es && $cur_inadequate;
        } elseif ($action === 'same') {
            $keep = $mode === 'both' || ($want_es && $cur_inadequate);
        }
        if ($keep) {
            $recs[] = $row;
        }
    }
    if ($cur_inadequate && $want_es) {
        $has_es = false;
        foreach ($recs as $row) {
            if (($row['action'] ?? '') === 'escalate') {
                $has_es = true;
                break;
            }
        }
        if (!$has_es) {
            foreach ($ast as $a) {
                if (strtoupper((string)($a['sir'] ?? '')) !== 'S') {
                    continue;
                }
                $drug = trim((string)($a['drug'] ?? ''));
                if ($drug === '') {
                    continue;
                }
                $already = false;
                foreach ($recs as $row) {
                    if (strcasecmp((string)$row['drug'], $drug) === 0) {
                        $already = true;
                        break;
                    }
                }
                if ($already) {
                    continue;
                }
                $on = false;
                foreach ($current as $c) {
                    if (amr_sens_ast_matches_atb($drug, $c['drugName'])) {
                        $on = true;
                        break;
                    }
                }
                if ($on) {
                    continue;
                }
                $renal = amr_sens_renal_advice_for_name($con, $drug, $egfr, '', [], $rule_map);
                if (($renal['status'] ?? '') === 'avoid') {
                    continue;
                }
                $recs[] = [
                    'drug' => $drug,
                    'mic' => $a['mic'] ?? '',
                    'class' => $a['class'] ?? '',
                    'aware' => $a['aware'] ?? '',
                    'who_aware' => $a['who_aware'] ?? '',
                    'on_now' => 0,
                    'renal' => $renal,
                    'action' => 'escalate',
                    'score' => amr_sens_steward_score($a['aware'] ?? '', $a['class'] ?? '', $ranks),
                ];
            }
        }
    }
    usort($recs, static function ($a, $b) use ($aware_rank, $class_rank) {
        $order = ['deescalate' => 0, 'continue' => 1, 'same' => 2, 'start' => 3, 'escalate' => 4];
        $oa = $order[$a['action'] ?? ''] ?? 5;
        $ob = $order[$b['action'] ?? ''] ?? 5;
        if ($oa !== $ob) {
            return $oa - $ob;
        }
        $ra = $aware_rank[$a['aware'] ?? ''] ?? 90;
        $rb = $aware_rank[$b['aware'] ?? ''] ?? 90;
        if ($ra !== $rb) {
            return $ra - $rb;
        }
        $ca = $class_rank[$a['class'] ?? ''] ?? 90;
        $cb = $class_rank[$b['class'] ?? ''] ?? 90;
        if ($ca !== $cb) {
            return $ca - $cb;
        }
        return strcmp((string)$a['drug'], (string)$b['drug']);
    });
    foreach ($recs as $i => $row) {
        $recs[$i]['rank'] = $i + 1;
        unset($recs[$i]['score']);
    }

    return [
        'verdict' => $verdict,
        'title' => $title,
        'organism' => $organism,
        'egfr' => $egfr > 0 ? $egfr : null,
        'egfr_date' => $egfr_date,
        'current' => $current,
        'recommend' => array_slice($recs, 0, 12),
        'recommend_deescalate' => array_slice(array_values(array_filter($recs, static function ($r) {
            return ($r['action'] ?? '') === 'deescalate';
        })), 0, 8),
        'recommend_escalate' => array_slice(array_values(array_filter($recs, static function ($r) {
            return ($r['action'] ?? '') === 'escalate';
        })), 0, 8),
        'avoid_renal' => array_slice($avoid, 0, 6),
        'steward_mode' => $mode,
        'can_deescalate' => $can_deescalate ? 1 : 0,
        'need_escalate' => $need_escalate ? 1 : 0,
    ];
}

function amr_sens_rec_rank_defaults() {
    return [
        'aware' => [
            ['item_key' => 'Access', 'label' => 'Access — ใช้ก่อน (ระดับ รพ. สำหรับลดชั้น)', 'sort_order' => 1],
            ['item_key' => 'Watch', 'label' => 'Watch — ใช้เมื่อจำเป็น (ระดับ รพ.)', 'sort_order' => 2],
            ['item_key' => 'Reserve', 'label' => 'Reserve — สงวนไว้ (ระดับ รพ.)', 'sort_order' => 3],
            ['item_key' => 'Unclassified', 'label' => 'ยังไม่จัดระดับ รพ.', 'sort_order' => 4],
        ],
        'class' => [
            ['item_key' => 'Penicillins', 'label' => 'Penicillins (narrow spectrum)', 'sort_order' => 1],
            ['item_key' => 'Macrolides/Lincosamides', 'label' => 'Macrolides / Lincosamides', 'sort_order' => 2],
            ['item_key' => 'Aminoglycosides', 'label' => 'Aminoglycosides', 'sort_order' => 3],
            ['item_key' => 'Others', 'label' => 'Others (TMP/SMX, Metro, Vanco ตาม AWaRe)', 'sort_order' => 4],
            ['item_key' => 'Cephalosporins', 'label' => 'Cephalosporins', 'sort_order' => 5],
            ['item_key' => 'Fluoroquinolones', 'label' => 'Fluoroquinolones', 'sort_order' => 6],
            ['item_key' => 'Beta-lactam/BLI', 'label' => 'Beta-lactam / BLI', 'sort_order' => 7],
            ['item_key' => 'Carbapenems', 'label' => 'Carbapenems — สงวนไว้ท้ายสุด', 'sort_order' => 8],
        ],
    ];
}

function amr_sens_rec_rank_ensure($con) {
    if (!$con) {
        return false;
    }
    $ok = @mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_cdss_rec_rank (
        id INT AUTO_INCREMENT PRIMARY KEY,
        kind VARCHAR(16) NOT NULL,
        item_key VARCHAR(80) NOT NULL,
        label VARCHAR(180) NOT NULL DEFAULT '',
        sort_order INT NOT NULL DEFAULT 1,
        UNIQUE KEY uk_kind_item (kind, item_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    if (!$ok) {
        return false;
    }
    $q = @mysqli_query($con, "SELECT COUNT(*) AS n FROM amr_cdss_rec_rank");
    $n = 0;
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $n = (int)$r['n'];
    }
    if ($n > 0) {
        return true;
    }
    foreach (amr_sens_rec_rank_defaults() as $kind => $rows) {
        foreach ($rows as $row) {
            amr_sens_rec_rank_upsert($con, $kind, $row['item_key'], $row['label'], (int)$row['sort_order']);
        }
    }
    return true;
}

function amr_sens_rec_rank_upsert($con, $kind, $key, $label, $order) {
    $kind_esc = mysqli_real_escape_string($con, $kind);
    $key_esc = mysqli_real_escape_string($con, $key);
    $label_esc = mysqli_real_escape_string($con, $label);
    $order = (int)$order;
    @mysqli_query($con, "INSERT INTO amr_cdss_rec_rank (kind, item_key, label, sort_order)
        VALUES ('$kind_esc', '$key_esc', '$label_esc', $order)
        ON DUPLICATE KEY UPDATE label = VALUES(label), sort_order = VALUES(sort_order)");
}

function amr_sens_rec_rank_fill_kind($kind, array $rows) {
    $defaults = amr_sens_rec_rank_defaults()[$kind] ?? [];
    $have = [];
    foreach ($rows as $r) {
        $key = trim((string)($r['item_key'] ?? ''));
        if ($key === '' || isset($have[$key])) {
            continue;
        }
        $have[$key] = [
            'item_key' => $key,
            'label' => (string)($r['label'] ?? $key),
            'sort_order' => (int)($r['sort_order'] ?? (count($have) + 1)),
        ];
    }
    $max = 0;
    foreach ($have as $r) {
        if ($r['sort_order'] > $max) {
            $max = $r['sort_order'];
        }
    }
    foreach ($defaults as $row) {
        if (isset($have[$row['item_key']])) {
            $have[$row['item_key']]['label'] = $row['label'];
            continue;
        }
        $max++;
        $have[$row['item_key']] = [
            'item_key' => $row['item_key'],
            'label' => $row['label'],
            'sort_order' => $max,
        ];
    }
    $out = array_values($have);
    usort($out, static function ($a, $b) {
        if ($a['sort_order'] !== $b['sort_order']) {
            return $a['sort_order'] - $b['sort_order'];
        }
        return strcmp($a['item_key'], $b['item_key']);
    });
    foreach ($out as $i => $row) {
        $out[$i]['sort_order'] = $i + 1;
    }
    return $out;
}

function amr_sens_rec_rank_list($con) {
    amr_sens_rec_rank_ensure($con);
    $raw = ['aware' => [], 'class' => []];
    if ($con) {
        $q = @mysqli_query($con, "SELECT kind, item_key, label, sort_order
            FROM amr_cdss_rec_rank ORDER BY kind ASC, sort_order ASC, item_key ASC");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $kind = $r['kind'] === 'class' ? 'class' : 'aware';
                $raw[$kind][] = [
                    'item_key' => $r['item_key'],
                    'label' => $r['label'],
                    'sort_order' => (int)$r['sort_order'],
                ];
            }
        }
    }
    return [
        'aware' => amr_sens_rec_rank_fill_kind('aware', $raw['aware']),
        'class' => amr_sens_rec_rank_fill_kind('class', $raw['class']),
    ];
}

function amr_sens_rec_rank_maps($con) {
    $list = amr_sens_rec_rank_list($con);
    $aware = [];
    $class = [];
    foreach ($list['aware'] as $r) {
        $aware[$r['item_key']] = (int)$r['sort_order'];
    }
    foreach ($list['class'] as $r) {
        $class[$r['item_key']] = (int)$r['sort_order'];
    }
    if (!$aware) {
        $aware = ['Access' => 1, 'Watch' => 2, 'Reserve' => 3, 'Unclassified' => 4];
    }
    return ['aware' => $aware, 'class' => $class];
}

function amr_sens_rec_rank_keys_from_input(array $list) {
    $out = [];
    foreach ($list as $item) {
        if (is_array($item)) {
            $key = trim((string)($item['item_key'] ?? $item['key'] ?? ''));
        } else {
            $key = trim((string)$item);
        }
        if ($key === '' || in_array($key, $out, true)) {
            continue;
        }
        $out[] = $key;
    }
    return $out;
}

function amr_sens_rec_rank_save($con, array $aware, array $class) {
    amr_sens_rec_rank_ensure($con);
    $current = amr_sens_rec_rank_list($con);
    $aware_keys = amr_sens_rec_rank_keys_from_input($aware);
    $class_keys = amr_sens_rec_rank_keys_from_input($class);
    if (!$aware_keys) {
        $aware_keys = array_column($current['aware'], 'item_key');
    }
    if (!$class_keys) {
        $class_keys = array_column($current['class'], 'item_key');
    }
    $aware_rows = [];
    foreach ($aware_keys as $i => $key) {
        $aware_rows[] = ['item_key' => $key, 'label' => '', 'sort_order' => $i + 1];
    }
    $class_rows = [];
    foreach ($class_keys as $i => $key) {
        $class_rows[] = ['item_key' => $key, 'label' => '', 'sort_order' => $i + 1];
    }
    $aware_rows = amr_sens_rec_rank_fill_kind('aware', $aware_rows);
    $class_rows = amr_sens_rec_rank_fill_kind('class', $class_rows);
    foreach ($aware_rows as $row) {
        amr_sens_rec_rank_upsert($con, 'aware', $row['item_key'], $row['label'], (int)$row['sort_order']);
    }
    foreach ($class_rows as $row) {
        amr_sens_rec_rank_upsert($con, 'class', $row['item_key'], $row['label'], (int)$row['sort_order']);
    }
    return amr_sens_rec_rank_list($con);
}

function amr_sens_rec_rank_reset($con) {
    amr_sens_rec_rank_ensure($con);
    @mysqli_query($con, "DELETE FROM amr_cdss_rec_rank");
    foreach (amr_sens_rec_rank_defaults() as $kind => $rows) {
        foreach ($rows as $row) {
            amr_sens_rec_rank_upsert($con, $kind, $row['item_key'], $row['label'], (int)$row['sort_order']);
        }
    }
    return amr_sens_rec_rank_list($con);
}

function amr_sens_drug_level_defaults() {
    $out = [];
    $seen = [];
    foreach (amr_sens_aware_builtin() as $key => $aware) {
        $seen[$key] = true;
        $base = amr_sens_ast_meta_base($key);
        $out[] = [
            'drug_key' => $key,
            'label' => $key,
            'aware' => $aware,
            'who_aware' => $aware,
            'class' => $base['class'],
        ];
    }
    foreach (amr_sens_ast_class_map() as $class => $list) {
        foreach ($list as $key) {
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $base = amr_sens_ast_meta_base($key);
            $out[] = [
                'drug_key' => $key,
                'label' => $key,
                'aware' => $base['aware'],
                'who_aware' => $base['aware'],
                'class' => $class,
            ];
        }
    }
    usort($out, static function ($a, $b) {
        $order = ['Access' => 1, 'Watch' => 2, 'Reserve' => 3, 'Unclassified' => 4];
        $oa = $order[$a['aware']] ?? 9;
        $ob = $order[$b['aware']] ?? 9;
        if ($oa !== $ob) {
            return $oa - $ob;
        }
        return strcmp($a['drug_key'], $b['drug_key']);
    });
    return $out;
}

function amr_sens_drug_level_ensure($con) {
    if (!$con) {
        return false;
    }
    $ok = @mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_cdss_drug_level (
        drug_key VARCHAR(80) NOT NULL,
        label VARCHAR(120) NOT NULL DEFAULT '',
        aware VARCHAR(24) NOT NULL DEFAULT 'Unclassified',
        class VARCHAR(80) NOT NULL DEFAULT '',
        updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (drug_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    if (!$ok) {
        return false;
    }
    $have = [];
    $q = @mysqli_query($con, "SELECT drug_key FROM amr_cdss_drug_level");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $have[strtoupper((string)$r['drug_key'])] = true;
        }
    }
    foreach (amr_sens_drug_level_defaults() as $row) {
        $key = strtoupper($row['drug_key']);
        if (isset($have[$key])) {
            continue;
        }
        amr_sens_drug_level_upsert($con, $key, $row['label'], $row['aware'], $row['class']);
    }
    return true;
}

function amr_sens_drug_level_upsert($con, $key, $label, $aware, $class) {
    $key = amr_sens_drug_level_normalize_key($key);
    if ($key === '' || !$con) {
        return false;
    }
    $aware = amr_sens_drug_level_normalize_aware($aware);
    $class = trim((string)$class);
    if ($class === '') {
        $class = (string)(amr_sens_ast_meta_base($key)['class'] ?? '');
    }
    $label = trim((string)$label);
    if ($label === '') {
        $label = $key;
    }
    $k = mysqli_real_escape_string($con, $key);
    $l = mysqli_real_escape_string($con, $label);
    $a = mysqli_real_escape_string($con, $aware);
    $c = mysqli_real_escape_string($con, $class);
    return (bool)@mysqli_query($con, "INSERT INTO amr_cdss_drug_level (drug_key, label, aware, class)
        VALUES ('$k', '$l', '$a', '$c')
        ON DUPLICATE KEY UPDATE label = VALUES(label), aware = VALUES(aware), class = VALUES(class)");
}

function amr_sens_drug_level_normalize_aware($raw) {
    $s = strtolower(trim((string)$raw));
    if ($s === 'access' || $s === 'พื้นฐาน' || $s === 'basic') {
        return 'Access';
    }
    if ($s === 'watch') {
        return 'Watch';
    }
    if ($s === 'reserve') {
        return 'Reserve';
    }
    return 'Unclassified';
}

function amr_sens_drug_level_list($con) {
    amr_sens_drug_level_ensure($con);
    $out = [];
    if ($con) {
        $q = @mysqli_query($con, "SELECT drug_key, label, aware, class FROM amr_cdss_drug_level ORDER BY aware ASC, drug_key ASC");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $out[] = [
                    'drug_key' => strtoupper((string)$r['drug_key']),
                    'label' => (string)($r['label'] !== '' ? $r['label'] : $r['drug_key']),
                    'aware' => amr_sens_drug_level_normalize_aware($r['aware']),
                    'who_aware' => (string)(amr_sens_ast_meta_base((string)$r['drug_key'])['aware'] ?? 'Unclassified'),
                    'class' => (string)($r['class'] ?? ''),
                ];
            }
        }
    }
    if (!$out) {
        $out = amr_sens_drug_level_defaults();
    }
    $order = ['Access' => 1, 'Watch' => 2, 'Reserve' => 3, 'Unclassified' => 4];
    usort($out, static function ($a, $b) use ($order) {
        $oa = $order[$a['aware']] ?? 9;
        $ob = $order[$b['aware']] ?? 9;
        if ($oa !== $ob) {
            return $oa - $ob;
        }
        return strcmp($a['drug_key'], $b['drug_key']);
    });
    return $out;
}

function amr_sens_drug_level_map_from_list(array $rows) {
    $map = [];
    foreach ($rows as $r) {
        $key = amr_sens_drug_level_normalize_key($r['drug_key'] ?? '');
        if ($key === '') {
            continue;
        }
        $map[$key] = [
            'aware' => amr_sens_drug_level_normalize_aware($r['aware'] ?? ''),
            'class' => trim((string)($r['class'] ?? '')),
            'label' => (string)($r['label'] ?? $key),
        ];
    }
    return $map;
}

function amr_sens_drug_level_prime($con) {
    $list = amr_sens_drug_level_list($con);
    amr_sens_drug_level_cache(amr_sens_drug_level_map_from_list($list));
    return $list;
}

function amr_sens_drug_level_save($con, array $rows) {
    amr_sens_drug_level_ensure($con);
    foreach ($rows as $r) {
        if (!is_array($r)) {
            continue;
        }
        $key = amr_sens_drug_level_normalize_key($r['drug_key'] ?? $r['drug'] ?? '');
        if ($key === '') {
            continue;
        }
        amr_sens_drug_level_upsert(
            $con,
            $key,
            $r['label'] ?? $key,
            $r['aware'] ?? 'Unclassified',
            $r['class'] ?? ''
        );
    }
    return amr_sens_drug_level_prime($con);
}

function amr_sens_drug_level_reset($con) {
    amr_sens_drug_level_ensure($con);
    @mysqli_query($con, "DELETE FROM amr_cdss_drug_level");
    foreach (amr_sens_drug_level_defaults() as $row) {
        amr_sens_drug_level_upsert($con, $row['drug_key'], $row['label'], $row['aware'], $row['class']);
    }
    return amr_sens_drug_level_prime($con);
}

