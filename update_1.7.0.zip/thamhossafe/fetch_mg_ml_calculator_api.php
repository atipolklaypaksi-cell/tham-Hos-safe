<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_mg_ml_helper.php');
include(__DIR__ . '/dose_calculator_helper.php');
mysqli_set_charset($con, 'utf8');
mmgml_ensure_table($con);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? 'lookup'));
$raw = file_get_contents('php://input');
$body = [];
if ($raw !== false && $raw !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
        if (!empty($body['action'])) {
            $action = trim((string)$body['action']);
        }
    }
}
$hn = trim((string)($_GET['hn'] ?? $_POST['hn'] ?? ($body['hn'] ?? '')));
$days = (int)($_GET['days'] ?? $_POST['days'] ?? ($body['days'] ?? 14));
if ($days < 1) {
    $days = 14;
}
if ($days > 90) {
    $days = 90;
}

header('Content-Type: application/json; charset=utf-8');

if ($action === 'save_bw') {
    $payload = !empty($body) ? $body : $_POST;
    $payload['hn'] = trim((string)($payload['hn'] ?? $hn));
    $payload['user_id'] = (int)($_SESSION['user_id'] ?? 0);
    $payload['user_name'] = (string)($_SESSION['full_name'] ?? '');
    $payload['source_module'] = trim((string)($payload['source_module'] ?? 'mg_ml_calculator'));
    $res = dc_save_vitals_bw($con, $payload);
    ob_clean();
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกน้ำหนักไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'message' => $res['message'] ?? 'บันทึกน้ำหนักแล้ว',
        'bw' => $res['bw'] ?? null,
        'source' => $res['source'] ?? 'tham',
        'source_label' => $res['source_label'] ?? 'THAM',
        'updated_at' => $res['updated_at'] ?? null,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$rules = mmgml_load_active_rules($con);
$catalog = [];
foreach ($rules as $rule) {
    $item = mmgml_rule_for_calculator($rule);
    if ($item['mg_per_ml'] > 0 && $item['icode'] !== '') {
        $catalog[] = $item;
    }
}

if ($action !== 'lookup') {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
    exit;
}

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}

$pt = dc_lookup_patient($hos, $con, $hn);
if (empty($pt['ok'])) {
    mysqli_close($hos);
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => $pt['error'] ?? 'ไม่พบ HN'], JSON_UNESCAPED_UNICODE);
    exit;
}

$bw = isset($pt['bw_resolved']) ? $pt['bw_resolved'] : null;
if ($bw !== null && (float)$bw <= 0) {
    $bw = null;
}
$bw_source = (string)($pt['bw_source'] ?? '');
$bw_source_label = (string)($pt['bw_source_label'] ?? '');
$bw_date = $pt['bw_resolved_date'] ?? ($pt['vstdate'] ?? null);
if ($bw_source === 'tham') {
    $bw_source = 'calculator';
}

$orders = [];
$icodes = [];
$rule_by = mmgml_build_rule_map_by_icode($rules);
foreach (array_keys($rule_by) as $ic) {
    $icodes[] = $ic;
}

if (!empty($icodes)) {
    $variants = function_exists('dc_hn_variants') ? dc_hn_variants($pt['hn']) : [$pt['hn']];
    $raw_orders = mmgml_fetch_orders_for_hn($hos, $variants, $icodes, $days, 300);
    foreach ($raw_orders as $row) {
        $icode = trim((string)($row['icode'] ?? ''));
        $matched = $rule_by[$icode] ?? [];
        if (!$matched) {
            continue;
        }
        $method = trim(preg_replace('/\s+/u', ' ', (string)($row['method'] ?? '')));
        $qty = isset($row['qty']) ? (float)$row['qty'] : null;
        $rx_date = !empty($row['rxdate']) ? $row['rxdate'] : ($row['vstdate'] ?? '');
        $rx_time = '';
        if (function_exists('di_format_time') && function_exists('monitor_lab_normalize_hosxp_time')) {
            $rx_time = di_format_time(monitor_lab_normalize_hosxp_time($row['rxtime'] ?? ''));
        } else {
            $rx_time = trim((string)($row['rxtime'] ?? ''));
        }
        $type_patient = $row['type_patient'] ?? ((trim((string)($row['vn'] ?? '')) === '') ? 'IPD' : 'OPD');
        $ward = trim((string)($row['ward_name'] ?? ''));
        $bedno = trim((string)($row['bedno'] ?? ''));
        if ($type_patient === 'OPD') {
            $ward_display = 'ผู้ป่วยนอก';
        } else {
            $ward_display = trim($ward . ($ward && $bedno ? ' / ' : '') . $bedno);
            if ($ward_display === '') {
                $ward_display = '-';
            }
        }

        foreach ($matched as $rule) {
            $eval = mmgml_evaluate_order($rule, $method, [
                'qty' => $qty,
                'weight_kg' => $bw,
                'drug_name' => trim((string)($row['drug_name'] ?? '')),
            ]);
            $dose_src = mmgml_usage_for_drug($method, $rule, ['drug_name' => trim((string)($row['drug_name'] ?? ''))]);
            $dose_mg = $eval['dose_mg'] ?? mmgml_extract_dose_mg_for_ml($dose_src !== '' ? $dose_src : $method);
            $stated_ml = $eval['stated_ml'] ?? mmgml_extract_ml_from_usage($dose_src !== '' ? $dose_src : $method);
            $mg_per_ml = isset($eval['mg_per_ml']) ? (float)$eval['mg_per_ml'] : (float)($rule['mg_per_ml'] ?? 0);
            $calc = mmgml_calc_volume($dose_mg, $mg_per_ml, $rule['mg_per_amp'] ?? null);
            $expected_ml = $eval['expected_ml'] ?? $calc['ml'];
            $mix_label = trim((string)($eval['mix_label'] ?? ''));
            $orders[] = [
                'rule_id' => (int)$rule['id'],
                'icode' => $icode,
                'drug_name' => trim((string)($row['drug_name'] ?? ($rule['drug_name'] ?? ''))),
                'strength_text' => trim((string)($rule['strength_text'] ?? '')),
                'mg_per_ml' => $mg_per_ml,
                'mg_per_amp' => isset($rule['mg_per_amp']) && $rule['mg_per_amp'] !== '' ? (float)$rule['mg_per_amp'] : null,
                'method' => $method,
                'qty' => $qty,
                'type_patient' => $type_patient,
                'ward_display' => $ward_display,
                'rxdate' => $rx_date,
                'order_date' => $rx_date ? date('d/m/Y', strtotime($rx_date)) : '-',
                'order_time' => $rx_time,
                'dose_mg' => $dose_mg !== null ? (float)$dose_mg : null,
                'stated_ml' => $stated_ml !== null ? (float)$stated_ml : null,
                'expected_ml' => $expected_ml !== null ? (float)$expected_ml : null,
                'expected_amp' => $calc['amp'],
                'dose_mg_display' => $dose_mg !== null ? mmgml_format_mg($dose_mg) . ' mg' : '—',
                'stated_ml_display' => $stated_ml !== null ? mmgml_format_ml($stated_ml) . ' mL' : '—',
                'expected_ml_display' => $expected_ml !== null ? mmgml_format_ml($expected_ml) . ' mL' : '—',
                'mg_per_ml_display' => mmgml_format_mg($mg_per_ml) . ' mg/mL' . ($mix_label !== '' ? ' (' . $mix_label . ')' : ''),
            ];
        }
    }
}

mysqli_close($hos);
ob_clean();
echo json_encode([
    'status' => 'success',
    'patient' => [
        'hn' => $pt['hn'],
        'ptname' => $pt['ptname'] ?? '',
        'bw' => $bw,
        'bw_source' => $bw_source,
        'bw_source_label' => $bw_source_label,
        'bw_date' => $bw_date,
        'height' => $pt['height'] ?? null,
        'vstdate' => $pt['vstdate'] ?? null,
        'age' => $pt['age'] ?? null,
    ],
    'catalog' => $catalog,
    'orders' => $orders,
    'meta' => [
        'days' => $days,
        'rule_count' => count($catalog),
        'order_count' => count($orders),
    ],
], JSON_UNESCAPED_UNICODE);
