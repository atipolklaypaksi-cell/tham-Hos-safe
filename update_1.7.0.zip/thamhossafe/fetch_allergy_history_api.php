<?php
ini_set('display_errors', 0);
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
require_once __DIR__ . '/allergy_history_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('allergy_history') && !tham_menu_can('allergy_followup')) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';
$flags = JSON_UNESCAPED_UNICODE;

$start = trim((string)($_GET['start_date'] ?? date('Y-01-01')));
$end = trim((string)($_GET['end_date'] ?? date('Y-m-d')));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start)) {
    $start = date('Y-01-01');
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
    $end = date('Y-m-d');
}
if ($start > $end) {
    $tmp = $start;
    $start = $end;
    $end = $tmp;
}

$hos = hosxp_connect($con, 90);
if (!$hos) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], $flags);
    exit;
}

if ($action === 'meta') {
    echo json_encode([
        'status' => 'success',
        'true_types' => ah_true_types(),
        'hosname' => ah_hospital_name($con, $hos),
    ], $flags);
    mysqli_close($hos);
    exit;
}

$filters = [
    'start_date' => $start,
    'end_date' => $end,
    'q' => $_GET['q'] ?? '',
    'severe_only' => !empty($_GET['severe_only']),
    'true_type' => $_GET['true_type'] ?? '',
    'unique_cid' => !empty($_GET['unique_cid']),
    'limit' => 2000,
];

$res = ah_fetch_rows($hos, $filters);
$hosname = ah_hospital_name($con, $hos);
mysqli_close($hos);

if (empty($res['ok'])) {
    echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'ดึงข้อมูลไม่สำเร็จ'], $flags);
    exit;
}

$rows = $res['rows'];
$summary = ah_summarize($rows);

if ($action === 'export') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="allergy_history_' . $start . '_' . $end . '.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
    fputcsv($out, ['HN', 'CID', 'ชื่อ-สกุล', 'วันที่รายงาน', 'ยาที่แพ้', 'อาการ', 'อาการรุนแรง', 'ความรุนแรง', 'ความสัมพันธ์', 'แหล่งข้อมูล', 'ผู้ประเมิน', 'ความสมบูรณ์', 'ขาด', 'Preventable', 'การเตือน', 'คำเตือน', 'หมายเหตุ', 'ที่อยู่', 'รพ.']);
    foreach ($rows as $r) {
        fputcsv($out, [
            $r['hn_display'] ?? '',
            $r['cid'] ?? '',
            $r['fullname'] ?? '',
            $r['report_date'] ?? '',
            $r['agent'] ?? '',
            $r['symptom'] ?? '',
            $r['true_symptom'] ?? '',
            $r['seriousness_name'] ?? '',
            $r['relation_name'] ?? '',
            $r['source_name'] ?? '',
            $r['evaluator_name'] ?? ($r['reporter_name'] ?? ''),
            $r['completeness_label'] ?? '',
            implode(', ', (array)($r['missing_fields'] ?? [])),
            $r['preventable_label'] ?? '',
            $r['alert_label'] ?? '',
            implode('; ', (array)($r['warnings'] ?? [])),
            $r['note'] ?? '',
            $r['fulladdress'] ?? '',
            $hosname,
        ]);
    }
    fclose($out);
    exit;
}

echo json_encode([
    'status' => 'success',
    'hosname' => $hosname,
    'summary' => $summary,
    'rows' => $rows,
], $flags);
