<?php
/**
 * แบนเนอร์ + เสียงแจ้งเตือนเคสแพ้ยารอรับ — ตามสิทธิ์บทบาทที่เปิดไว้
 */
if (!isset($_SESSION['user_id'])) {
    return;
}
require_once __DIR__ . '/allergy_alert_helper.php';
$af_alert_con = isset($con) ? $con : null;
if (!$af_alert_con) {
    return;
}
if (!af_alert_user_eligible($af_alert_con)) {
    return;
}
?>
<style>
#afAlertBanner {
    display: none;
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    width: 100% !important;
    max-width: none !important;
    margin: 0 !important;
    z-index: 2147483000 !important;
    box-sizing: border-box;
}
#afAlertBanner.is-on {
    display: block !important;
}
#afAlertBanner .af-alert-banner-inner {
    display: flex;
    align-items: center;
    gap: 12px;
    width: 100%;
    min-height: 56px;
    padding: 10px 18px;
    color: #fff;
    background: #dc2626;
    border: 4px solid #fecaca;
    box-shadow: 0 6px 0 #7f1d1d;
    animation: afBannerFlash 0.8s linear infinite;
}
#afAlertBanner .af-alert-banner-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: rgba(255,255,255,0.25);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    flex-shrink: 0;
}
#afAlertBanner .af-alert-banner-body { flex: 1; min-width: 0; }
#afAlertBanner .af-alert-banner-title {
    font-weight: 800;
    font-size: 1.2rem;
    line-height: 1.25;
}
#afAlertBanner .af-alert-banner-meta {
    font-size: 0.9rem;
    opacity: 0.95;
}
#afAlertBanner .af-alert-banner-actions {
    display: flex;
    gap: 8px;
    flex-shrink: 0;
    flex-wrap: wrap;
}
#afAlertBanner .af-alert-open {
    background: #fff !important;
    color: #b91c1c !important;
    font-weight: 800;
    border: 0;
}
#afAlertBanner .af-alert-banner-close {
    background: transparent;
    border: 0;
    color: #fff;
    font-size: 1.7rem;
    line-height: 1;
    padding: 0 6px;
}
body.af-alert-banner-on { padding-top: 72px !important; }
@keyframes afBannerFlash {
    0%, 49% { background: #dc2626; border-color: #fecaca; }
    50%, 100% { background: #7f1d1d; border-color: #f87171; }
}
</style>
<div id="afAlertBanner" class="af-alert-banner" aria-live="assertive" aria-hidden="true">
    <div class="af-alert-banner-inner">
        <div class="af-alert-banner-icon"><i class="fas fa-allergies"></i></div>
        <div class="af-alert-banner-body">
            <div class="af-alert-banner-title">
                <i class="fas fa-exclamation-triangle me-1"></i>
                เคสแพ้ยารอรับ <span id="afAlertCount">0</span> รายการ — ยังไม่ได้กดรับเคส
            </div>
            <div class="af-alert-banner-meta" id="afAlertMeta"></div>
        </div>
        <div class="af-alert-banner-actions">
            <a href="allergy_followup.php" class="btn btn-sm fw-bold af-alert-open">เปิดรับเคส</a>
            <button type="button" class="btn btn-sm btn-outline-light" id="afAlertUnlock">เปิดเสียง</button>
        </div>
        <button type="button" class="af-alert-banner-close" id="afAlertHide" title="ซ่อนแบนเนอร์รอบนี้">&times;</button>
    </div>
</div>
<script src="js/allergy_alert_notifier.js?v=4"></script>
