<?php
/**
 * CDSS for Antibiotic — Consult / ใบปรึกษาแพทย์ + ประวัติ
 * เคสยาไม่เหมาะสม (ผล R) ต่อผล Sensitivity
 */

function acc_consult_statuses() {
    return [
        'waiting' => 'รอ Consult',
        'in_progress' => 'รอตอบกลับ',
        'closed' => 'ปิด Consult',
    ];
}

function acc_consult_normalize_status($status) {
    $s = trim((string)$status);
    if ($s === 'in_progress' || $s === 'progress' || $s === 'consulting') {
        return 'in_progress';
    }
    if ($s === 'closed' || $s === 'done' || $s === 'resolved') {
        return 'closed';
    }
    return 'waiting';
}

function acc_consult_status_label($status) {
    $map = acc_consult_statuses();
    $status = acc_consult_normalize_status($status);
    return isset($map[$status]) ? $map[$status] : $status;
}

function acc_ensure_tables($con) {
    $sql = @file_get_contents(__DIR__ . '/sql/amr_cdss_consults.sql');
    if ($sql !== false && trim($sql) !== '') {
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
            if ($stmt === '') {
                continue;
            }
            @mysqli_query($con, $stmt);
        }
    }
    $chk = @mysqli_query($con, "SHOW TABLES LIKE 'amr_cdss_consults'");
    return $chk && mysqli_num_rows($chk) > 0;
}

function acc_normalize_reply_wait_days($days) {
    return max(0, min(30, (int)$days));
}

function acc_get_reply_wait_days($con) {
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='amr_cdss_reply_wait_days' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return acc_normalize_reply_wait_days($r['config_value']);
    }
    @mysqli_query($con, "INSERT IGNORE INTO sys_config (config_name, config_value) VALUES ('amr_cdss_reply_wait_days', '0')");
    return 0;
}

function acc_hn_variants($hn) {
    $raw = preg_replace('/\D+/', '', (string)$hn);
    $out = [];
    $trim_full = trim((string)$hn);
    if ($trim_full !== '') {
        $out[] = $trim_full;
    }
    if ($raw === '') {
        return array_values(array_unique($out));
    }
    $padded = str_pad($raw, 9, '0', STR_PAD_LEFT);
    $trim = ltrim($raw, '0');
    if ($trim === '') {
        $trim = '0';
    }
    foreach ([$padded, $trim, $raw] as $v) {
        $out[] = $v;
    }
    return array_values(array_unique($out));
}

function acc_hn_in_sql($con, $hn) {
    $vals = [];
    foreach (acc_hn_variants($hn) as $v) {
        $vals[] = "'" . mysqli_real_escape_string($con, $v) . "'";
    }
    return $vals ? implode(',', $vals) : "''";
}

function acc_list_pharmacists($con, $prefer_user_id = 0) {
    require_once __DIR__ . '/opduser_auth_helper.php';
    return tham_list_consult_pharmacists($con, $prefer_user_id);
}

function acc_resolve_pharmacist($con, $user_id, $fallback_name = '') {
    $user_id = (int)$user_id;
    if ($user_id > 0) {
        $q = mysqli_query($con, "SELECT id, full_name, username FROM users WHERE id = $user_id LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            $name = trim((string)($r['full_name'] ?? ''));
            if ($name === '') {
                $name = trim((string)($r['username'] ?? ''));
            }
            return ['id' => (int)$r['id'], 'name' => $name];
        }
    }
    return ['id' => 0, 'name' => trim((string)$fallback_name)];
}

function acc_decode_json($raw) {
    if (is_array($raw)) {
        return $raw;
    }
    $s = trim((string)$raw);
    if ($s === '') {
        return [];
    }
    $arr = json_decode($s, true);
    return is_array($arr) ? $arr : [];
}

function acc_encode_json($data) {
    if (!is_array($data)) {
        return '[]';
    }
    $json = json_encode($data, JSON_UNESCAPED_UNICODE);
    return $json !== false ? $json : '[]';
}

function acc_first_r_drug(array $drugs) {
    foreach ($drugs as $d) {
        if (!is_array($d)) {
            continue;
        }
        $sir = strtoupper((string)($d['sir'] ?? ''));
        $fit = (string)($d['fit'] ?? '');
        if ($sir === 'R' || $fit === 'inappropriate') {
            return $d;
        }
    }
    return is_array($drugs[0] ?? null) ? $drugs[0] : [];
}

function acc_build_default_note(array $case) {
    $org = trim((string)($case['organism'] ?? ''));
    $pheno = trim((string)($case['phenotype'] ?? ''));
    $spec = trim((string)($case['specimen'] ?? ''));
    $drugs = $case['current_drugs'] ?? [];
    if (!is_array($drugs)) {
        $drugs = acc_decode_json($drugs);
    }
    $recs = $case['recommend'] ?? [];
    if (!is_array($recs)) {
        $recs = acc_decode_json($recs);
    }
    $r_lines = [];
    foreach ($drugs as $d) {
        if (!is_array($d)) {
            continue;
        }
        $sir = strtoupper((string)($d['sir'] ?? ''));
        $fit = (string)($d['fit'] ?? '');
        if ($sir !== 'R' && $fit !== 'inappropriate') {
            continue;
        }
        $line = trim((string)($d['drugName'] ?? $d['drug'] ?? ''));
        if ($line === '') {
            continue;
        }
        if ($sir !== '') {
            $line .= ' (ผล ' . $sir . ')';
        }
        if (!empty($d['mic'])) {
            $line .= ' MIC ' . $d['mic'];
        }
        $r_lines[] = $line;
    }
    $rec_names = [];
    foreach ($recs as $r) {
        if (!is_array($r)) {
            continue;
        }
        $n = trim((string)($r['drug'] ?? $r['drugName'] ?? ''));
        if ($n !== '' && !in_array($n, $rec_names, true)) {
            $rec_names[] = $n;
        }
        if (count($rec_names) >= 8) {
            break;
        }
    }
    $lines = ['พบยาไม่เหมาะสมต่อผล Sensitivity (กำลังให้ยาที่ผลเป็น R) ควร Escalate'];
    if ($org !== '') {
        $lines[] = 'เชื้อ: ' . $org . ($pheno !== '' && stripos($org, $pheno) === false ? ' (' . $pheno . ')' : '');
    }
    if ($spec !== '') {
        $lines[] = 'Specimen: ' . $spec;
    }
    if ($r_lines) {
        $lines[] = 'ยาที่ไม่เหมาะสม: ' . implode('; ', $r_lines);
    }
    if ($rec_names) {
        $lines[] = 'ยาที่แนะนำ (ผล S): ' . implode(', ', $rec_names);
    }
    $egfr = trim((string)($case['egfr'] ?? ''));
    if ($egfr !== '') {
        $egfr_date = trim((string)($case['egfr_date'] ?? ''));
        $lines[] = 'eGFR ล่าสุด ' . $egfr . ($egfr_date !== '' ? ' (' . $egfr_date . ')' : '');
    }
    return implode("\n", $lines);
}

function acc_get_consult($con, $id) {
    acc_ensure_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM amr_cdss_consults WHERE id = $id LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function acc_find_by_order($con, $order) {
    acc_ensure_tables($con);
    $order = preg_replace('/\D+/', '', (string)$order);
    if ($order === '') {
        return null;
    }
    $esc = mysqli_real_escape_string($con, $order);
    $q = mysqli_query($con, "SELECT * FROM amr_cdss_consults WHERE lab_order_number = '$esc' LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function acc_format_consult_row(array $r) {
    $status = acc_consult_normalize_status($r['status'] ?? 'waiting');
    $current = acc_decode_json($r['current_drugs_json'] ?? '[]');
    $recs = acc_decode_json($r['recommend_json'] ?? '[]');
    return [
        'id' => (int)($r['id'] ?? 0),
        'lab_order_number' => (string)($r['lab_order_number'] ?? ''),
        'hn' => (string)($r['hn'] ?? ''),
        'an' => (string)($r['an'] ?? ''),
        'vn' => (string)($r['vn'] ?? ''),
        'ptname' => (string)($r['ptname'] ?? ''),
        'ward_name' => (string)($r['ward_name'] ?? ''),
        'specimen' => (string)($r['specimen'] ?? ''),
        'organism' => (string)($r['organism'] ?? ''),
        'phenotype' => (string)($r['phenotype'] ?? ''),
        'report_date' => (string)($r['report_date'] ?? ''),
        'verdict' => (string)($r['verdict'] ?? ''),
        'verdict_title' => (string)($r['verdict_title'] ?? ''),
        'drug_name' => (string)($r['drug_name'] ?? ''),
        'icode' => (string)($r['icode'] ?? ''),
        'egfr' => (string)($r['egfr'] ?? ''),
        'egfr_date' => (string)($r['egfr_date'] ?? ''),
        'current_drugs' => $current,
        'recommend' => $recs,
        'avoid_renal' => acc_decode_json($r['avoid_renal_json'] ?? '[]'),
        'status' => $status,
        'status_label' => acc_consult_status_label($status),
        'pharmacist_user_id' => (int)($r['pharmacist_user_id'] ?? 0),
        'pharmacist_name' => (string)($r['pharmacist_name'] ?? ''),
        'consult_note' => (string)($r['consult_note'] ?? ''),
        'doctor_reply' => (string)($r['doctor_reply'] ?? ''),
        'reply_wait_days' => (int)($r['reply_wait_days'] ?? 0),
        'reply_due_at' => (string)($r['reply_due_at'] ?? ''),
        'started_at' => (string)($r['started_at'] ?? ''),
        'closed_at' => (string)($r['closed_at'] ?? ''),
        'printed_at' => (string)($r['printed_at'] ?? ''),
        'created_at' => (string)($r['created_at'] ?? ''),
        'updated_at' => (string)($r['updated_at'] ?? ''),
        'print_url' => 'amr_cdss_consult_print.php?id=' . (int)($r['id'] ?? 0),
    ];
}

function acc_upsert_from_case($con, array $case, array $extra = []) {
    acc_ensure_tables($con);
    $order = preg_replace('/\D+/', '', (string)($case['lab_order_number'] ?? $case['order'] ?? ''));
    $hn = trim((string)($case['hn'] ?? ''));
    if ($order === '' || $hn === '') {
        return ['ok' => false, 'error' => 'ข้อมูลเคสไม่ครบ (HN / lab order)'];
    }
    $drugs = $case['current_drugs'] ?? [];
    if (!is_array($drugs)) {
        $drugs = acc_decode_json($drugs);
    }
    $recs = $case['recommend'] ?? [];
    if (!is_array($recs)) {
        $recs = acc_decode_json($recs);
    }
    $avoid = $case['avoid_renal'] ?? [];
    if (!is_array($avoid)) {
        $avoid = acc_decode_json($avoid);
    }
    $first = acc_first_r_drug($drugs);
    $drug_name = trim((string)($case['drug_name'] ?? $first['drugName'] ?? $first['drug'] ?? ''));
    $icode = trim((string)($case['icode'] ?? $first['icode'] ?? ''));

    $order_esc = mysqli_real_escape_string($con, $order);
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $an = mysqli_real_escape_string($con, trim((string)($case['an'] ?? '')));
    $vn = mysqli_real_escape_string($con, trim((string)($case['vn'] ?? '')));
    $ptname = mysqli_real_escape_string($con, trim((string)($case['ptname'] ?? '')));
    $ward = mysqli_real_escape_string($con, trim((string)($case['ward_name'] ?? $case['Wname'] ?? $case['wname'] ?? '')));
    $spec = mysqli_real_escape_string($con, trim((string)($case['specimen'] ?? $case['Specimen'] ?? '')));
    $org = mysqli_real_escape_string($con, trim((string)($case['organism'] ?? '')));
    $pheno = mysqli_real_escape_string($con, trim((string)($case['phenotype'] ?? $case['result'] ?? '')));
    $report = mysqli_real_escape_string($con, trim((string)($case['report_date'] ?? $case['reportdatetime'] ?? '')));
    $verdict = mysqli_real_escape_string($con, trim((string)($case['verdict'] ?? 'inappropriate')));
    $title = mysqli_real_escape_string($con, trim((string)($case['verdict_title'] ?? $case['title'] ?? '')));
    $drug_esc = mysqli_real_escape_string($con, $drug_name);
    $icode_esc = mysqli_real_escape_string($con, $icode);
    $egfr = mysqli_real_escape_string($con, (string)($case['egfr'] ?? ''));
    $egfr_date = mysqli_real_escape_string($con, trim((string)($case['egfr_date'] ?? '')));
    $cur_json = mysqli_real_escape_string($con, acc_encode_json($drugs));
    $rec_json = mysqli_real_escape_string($con, acc_encode_json($recs));
    $avoid_json = mysqli_real_escape_string($con, acc_encode_json($avoid));
    $updated_by = (int)($extra['updated_by'] ?? $extra['created_by'] ?? 0);
    $created_by = (int)($extra['created_by'] ?? $updated_by);

    $set = "hn='$hn_esc', an='$an', vn='$vn', ptname='$ptname', ward_name='$ward',
        specimen='$spec', organism='$org', phenotype='$pheno', report_date='$report',
        verdict='$verdict', verdict_title='$title', drug_name='$drug_esc', icode='$icode_esc',
        egfr='$egfr', egfr_date='$egfr_date',
        current_drugs_json='$cur_json', recommend_json='$rec_json', avoid_renal_json='$avoid_json',
        updated_by=" . ($updated_by > 0 ? $updated_by : 'NULL');

    $existing = acc_find_by_order($con, $order);
    if ($existing) {
        $id = (int)$existing['id'];
        if (!mysqli_query($con, "UPDATE amr_cdss_consults SET $set WHERE id=$id")) {
            return ['ok' => false, 'error' => mysqli_error($con)];
        }
        return ['ok' => true, 'id' => $id, 'row' => acc_get_consult($con, $id)];
    }
    $sql = "INSERT INTO amr_cdss_consults
        (lab_order_number, hn, an, vn, ptname, ward_name, specimen, organism, phenotype, report_date,
         verdict, verdict_title, drug_name, icode, egfr, egfr_date,
         current_drugs_json, recommend_json, avoid_renal_json, status, created_by, updated_by)
        VALUES ('$order_esc', '$hn_esc', '$an', '$vn', '$ptname', '$ward', '$spec', '$org', '$pheno', '$report',
            '$verdict', '$title', '$drug_esc', '$icode_esc', '$egfr', '$egfr_date',
            '$cur_json', '$rec_json', '$avoid_json', 'waiting',
            " . ($created_by > 0 ? $created_by : 'NULL') . ",
            " . ($updated_by > 0 ? $updated_by : 'NULL') . ")";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $id = (int)mysqli_insert_id($con);
    return ['ok' => true, 'id' => $id, 'row' => acc_get_consult($con, $id)];
}

function acc_start_consult($con, array $case, $pharmacist_user_id, $pharmacist_name, $note, $actor_user_id, $reply_wait_days = null, $actor_name = '') {
    $up = acc_upsert_from_case($con, $case, [
        'created_by' => $actor_user_id,
        'updated_by' => $actor_user_id,
    ]);
    if (empty($up['ok'])) {
        return $up;
    }
    $id = (int)$up['id'];
    $before = acc_get_consult($con, $id);
    $pharm = acc_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name);
    $wait = acc_normalize_reply_wait_days($reply_wait_days !== null ? $reply_wait_days : acc_get_reply_wait_days($con));
    $note = trim((string)$note);
    if ($note === '') {
        $note = acc_build_default_note($case);
    }
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $note_esc = mysqli_real_escape_string($con, $note);
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $due_sql = $wait <= 0 ? 'NULL' : "DATE_ADD(NOW(), INTERVAL $wait DAY)";
    $sql = "UPDATE amr_cdss_consults SET
        status='in_progress',
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'NULL') . ",
        pharmacist_name='$name_esc',
        consult_note='$note_esc',
        reply_wait_days=$wait,
        reply_due_at=$due_sql,
        closed_at=NULL,
        started_at=IFNULL(started_at, NOW()),
        printed_at=NOW(),
        updated_by=$actor
        WHERE id=$id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $row = acc_get_consult($con, $id);
    acc_log_history($con, [
        'consult_id' => $id,
        'row' => $row,
        'action_key' => 'start',
        'action_label' => 'เริ่ม Consult + พิมพ์ใบปรึกษา',
        'status_before' => $before['status'] ?? 'waiting',
        'status_after' => 'in_progress',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'reply_due_at' => $row['reply_due_at'] ?? null,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
        'meta' => ['reply_wait_days' => $wait],
    ]);
    return [
        'ok' => true,
        'id' => $id,
        'consult' => acc_format_consult_row($row),
        'print_url' => 'amr_cdss_consult_print.php?id=' . $id,
        'message' => 'เริ่ม Consult แล้ว — รอตอบกลับ' . ($wait <= 0 ? 'ทันที' : ('ภายใน ' . $wait . ' วัน')),
    ];
}

function acc_reprint($con, $consult_id, $actor_user_id, $actor_name = '') {
    $consult_id = (int)$consult_id;
    $row = acc_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $actor = (int)$actor_user_id;
    mysqli_query($con, "UPDATE amr_cdss_consults SET printed_at=NOW(), updated_by=" . ($actor > 0 ? $actor : 'NULL') . " WHERE id=$consult_id");
    $after = acc_get_consult($con, $consult_id);
    acc_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'reprint',
        'action_label' => 'พิมพ์ใบปรึกษาอีกครั้ง',
        'status_before' => $row['status'] ?? '',
        'status_after' => $after['status'] ?? '',
        'pharmacist_name' => $row['pharmacist_name'] ?? '',
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return [
        'ok' => true,
        'id' => $consult_id,
        'consult' => acc_format_consult_row($after),
        'print_url' => 'amr_cdss_consult_print.php?id=' . $consult_id,
        'message' => 'เปิดใบปรึกษาแล้ว',
    ];
}

function acc_close_consult($con, $consult_id, $note, $doctor_reply, $actor_user_id, $actor_name = '', $pharmacist_user_id = 0, $pharmacist_name = '') {
    $consult_id = (int)$consult_id;
    $row = acc_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $pharm = acc_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name !== '' ? $pharmacist_name : ($row['pharmacist_name'] ?? ''));
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $reply_esc = mysqli_real_escape_string($con, trim((string)$doctor_reply));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $sql = "UPDATE amr_cdss_consults SET
        status='closed',
        closed_at=NOW(),
        reply_due_at=NULL,
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'pharmacist_user_id') . ",
        pharmacist_name=IF('$name_esc'='', pharmacist_name, '$name_esc'),
        consult_note=IF('$note_esc'='', consult_note, '$note_esc'),
        doctor_reply=IF('$reply_esc'='', doctor_reply, '$reply_esc'),
        updated_by=$actor
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = acc_get_consult($con, $consult_id);
    acc_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'close',
        'action_label' => 'ปิดการ Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => 'closed',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'doctor_reply' => $doctor_reply,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => acc_format_consult_row($after), 'message' => 'ปิด Consult แล้ว'];
}

function acc_save_result($con, $consult_id, $note, $doctor_reply, $actor_user_id, $actor_name = '', $pharmacist_user_id = 0, $pharmacist_name = '') {
    $consult_id = (int)$consult_id;
    $row = acc_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $pharm = acc_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $reply_esc = mysqli_real_escape_string($con, trim((string)$doctor_reply));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $sql = "UPDATE amr_cdss_consults SET
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'pharmacist_user_id') . ",
        pharmacist_name=IF('$name_esc'='', pharmacist_name, '$name_esc'),
        consult_note=IF('$note_esc'='', consult_note, '$note_esc'),
        doctor_reply=IF('$reply_esc'='', doctor_reply, '$reply_esc'),
        updated_by=$actor
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = acc_get_consult($con, $consult_id);
    acc_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'save_result',
        'action_label' => 'บันทึกผล Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => $after['status'] ?? '',
        'pharmacist_name' => $pharm['name'] !== '' ? $pharm['name'] : ($row['pharmacist_name'] ?? ''),
        'note_text' => $note,
        'doctor_reply' => $doctor_reply,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => acc_format_consult_row($after), 'message' => 'บันทึกผล Consult เรียบร้อย'];
}

function acc_reset_waiting($con, $consult_id, $actor_user_id, $note = '', $actor_name = '') {
    $consult_id = (int)$consult_id;
    $row = acc_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $note_sql = $note_esc !== '' ? ", consult_note='$note_esc'" : '';
    $actor = (int)$actor_user_id;
    $sql = "UPDATE amr_cdss_consults SET
        status='waiting', reply_due_at=NULL, closed_at=NULL, updated_by=$actor
        $note_sql
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = acc_get_consult($con, $consult_id);
    acc_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'reset',
        'action_label' => 'ตั้งเป็นรอ Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => 'waiting',
        'note_text' => $note,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => acc_format_consult_row($after), 'message' => 'ตั้งเป็นรอ Consult แล้ว'];
}

function acc_mark_printed($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "UPDATE amr_cdss_consults SET printed_at=NOW() WHERE id=$id");
}

function acc_log_history($con, array $data) {
    acc_ensure_tables($con);
    $row = $data['row'] ?? [];
    $consult_id = (int)($data['consult_id'] ?? ($row['id'] ?? 0));
    $order = mysqli_real_escape_string($con, (string)($row['lab_order_number'] ?? ''));
    $hn = mysqli_real_escape_string($con, (string)($row['hn'] ?? ''));
    $an = mysqli_real_escape_string($con, (string)($row['an'] ?? ''));
    $org = mysqli_real_escape_string($con, (string)($row['organism'] ?? ''));
    $drug = mysqli_real_escape_string($con, (string)($row['drug_name'] ?? ''));
    $action_key = mysqli_real_escape_string($con, (string)($data['action_key'] ?? ''));
    $action_label = mysqli_real_escape_string($con, (string)($data['action_label'] ?? $action_key));
    $sb = mysqli_real_escape_string($con, (string)($data['status_before'] ?? ''));
    $sa = mysqli_real_escape_string($con, (string)($data['status_after'] ?? ''));
    $pharm = mysqli_real_escape_string($con, (string)($data['pharmacist_name'] ?? ($row['pharmacist_name'] ?? '')));
    $note = mysqli_real_escape_string($con, (string)($data['note_text'] ?? ''));
    $reply = mysqli_real_escape_string($con, (string)($data['doctor_reply'] ?? ''));
    $reply_due = !empty($data['reply_due_at'])
        ? "'" . mysqli_real_escape_string($con, (string)$data['reply_due_at']) . "'"
        : 'NULL';
    $meta = '';
    if (!empty($data['meta']) && is_array($data['meta'])) {
        $meta = mysqli_real_escape_string($con, json_encode($data['meta'], JSON_UNESCAPED_UNICODE));
    }
    $actor_id = (int)($data['actor_user_id'] ?? 0);
    $actor_name = mysqli_real_escape_string($con, (string)($data['actor_name'] ?? ''));
    $sql = "INSERT INTO amr_cdss_consult_history
        (consult_id, lab_order_number, hn, an, organism, drug_name, action_key, action_label,
         status_before, status_after, pharmacist_name, note_text, doctor_reply, reply_due_at, meta_json,
         actor_user_id, actor_name)
        VALUES
        ($consult_id, '$order', '$hn', '$an', '$org', '$drug', '$action_key', '$action_label',
         '$sb', '$sa', '$pharm', '$note', '$reply', $reply_due, " . ($meta !== '' ? "'$meta'" : 'NULL') . ",
         " . ($actor_id > 0 ? $actor_id : 'NULL') . ", '$actor_name')";
    return (bool)@mysqli_query($con, $sql);
}

function acc_list_consults($con, array $opts = []) {
    acc_ensure_tables($con);
    $where = ['1=1'];
    if (!empty($opts['hn'])) {
        $where[] = 'hn IN (' . acc_hn_in_sql($con, $opts['hn']) . ')';
    }
    if (!empty($opts['an'])) {
        $where[] = "an='" . mysqli_real_escape_string($con, preg_replace('/\D+/', '', (string)$opts['an'])) . "'";
    }
    if (!empty($opts['lab_order_number'])) {
        $where[] = "lab_order_number='" . mysqli_real_escape_string($con, preg_replace('/\D+/', '', (string)$opts['lab_order_number'])) . "'";
    }
    $limit = max(1, min(200, (int)($opts['limit'] ?? 50)));
    $sql = 'SELECT * FROM amr_cdss_consults WHERE ' . implode(' AND ', $where)
        . ' ORDER BY updated_at DESC, id DESC LIMIT ' . $limit;
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = acc_format_consult_row($r);
        }
    }
    return $rows;
}

function acc_list_history($con, array $opts = []) {
    acc_ensure_tables($con);
    $where = ['1=1'];
    if (!empty($opts['consult_id'])) {
        $where[] = 'consult_id=' . (int)$opts['consult_id'];
    }
    if (!empty($opts['hn'])) {
        $where[] = 'hn IN (' . acc_hn_in_sql($con, $opts['hn']) . ')';
    }
    if (!empty($opts['lab_order_number'])) {
        $where[] = "lab_order_number='" . mysqli_real_escape_string($con, preg_replace('/\D+/', '', (string)$opts['lab_order_number'])) . "'";
    }
    $limit = max(1, min(500, (int)($opts['limit'] ?? 100)));
    $sql = 'SELECT * FROM amr_cdss_consult_history WHERE ' . implode(' AND ', $where)
        . ' ORDER BY created_at DESC, id DESC LIMIT ' . $limit;
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'id' => (int)$r['id'],
                'consult_id' => (int)$r['consult_id'],
                'created_at' => $r['created_at'],
                'lab_order_number' => $r['lab_order_number'],
                'hn' => $r['hn'],
                'an' => $r['an'],
                'organism' => $r['organism'],
                'drug_name' => $r['drug_name'],
                'action_key' => $r['action_key'],
                'action_label' => $r['action_label'],
                'status_before' => $r['status_before'],
                'status_after' => $r['status_after'],
                'status_before_label' => acc_consult_status_label($r['status_before']),
                'status_after_label' => acc_consult_status_label($r['status_after']),
                'pharmacist_name' => $r['pharmacist_name'],
                'note_text' => $r['note_text'],
                'doctor_reply' => $r['doctor_reply'],
                'reply_due_at' => $r['reply_due_at'],
                'actor_name' => $r['actor_name'],
            ];
        }
    }
    return $rows;
}
