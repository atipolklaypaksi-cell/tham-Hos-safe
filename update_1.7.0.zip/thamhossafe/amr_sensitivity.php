<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
$default_end = date('Y-m-d');
$default_start = date('Y-m-d', strtotime('-6 days'));
$pre_order = preg_replace('/\D+/', '', (string)($_GET['order'] ?? $_GET['orderNumber'] ?? ''));
$pre_q = trim((string)($_GET['q'] ?? $_GET['hn'] ?? $_GET['an'] ?? ''));
if ($pre_q === '' && $pre_order !== '') {
    $pre_q = $pre_order;
}
$pre_start = trim((string)($_GET['start_date'] ?? $_GET['start'] ?? ''));
$pre_end = trim((string)($_GET['end_date'] ?? $_GET['end'] ?? ''));
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $pre_start)) {
    $default_start = $pre_start;
}
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $pre_end)) {
    $default_end = $pre_end;
}
$pre_scope = strtolower(trim((string)($_GET['scope'] ?? '')));
if (!in_array($pre_scope, ['resistant', 'growth', 'all'], true)) {
    $pre_scope = 'resistant';
}
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>CDSS for Antibiotic — THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: #e8f1ec; }
        #content.sens-content {
            background:
                radial-gradient(1000px 380px at 100% -8%, rgba(20,184,166,.12), transparent 55%),
                #e8f1ec;
            min-height: 100vh;
        }
        .sens-hero {
            display: flex; justify-content: space-between; align-items: flex-end;
            gap: 16px; flex-wrap: wrap; margin-bottom: 16px;
        }
        .sens-kicker {
            display: inline-flex; align-items: center; gap: 8px;
            font-size: .75rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase;
            color: #0f766e; background: rgba(20,184,166,.12); border: 1px solid rgba(15,118,110,.15);
            border-radius: 999px; padding: 4px 10px; margin-bottom: 8px;
        }
        .sens-title { font-size: 1.45rem; font-weight: 800; color: #12261c; margin: 0; }
        .sens-sub { color: #5f7468; font-size: .9rem; margin: .2rem 0 0; }
        .sens-panel {
            background: #fff; border: 1px solid #d7e4dc; border-radius: 14px;
            padding: 1rem 1.1rem; box-shadow: 0 8px 24px rgba(18,38,28,.04);
        }
        .sens-panel h2 { font-size: .95rem; font-weight: 800; margin: 0 0 .15rem; color: #12261c; }
        .sens-panel .desc { font-size: .78rem; color: #5f7468; margin: 0 0 .7rem; }
        .sens-side { display: flex; flex-direction: column; gap: 12px; }
        #sensAst { max-height: min(70vh, 720px); overflow: auto; padding-right: 4px; }
        .sens-table { font-size: .8rem; margin: 0; }
        .sens-table thead th {
            background: #f6faf8; color: #146c4a; font-weight: 700; white-space: nowrap;
            border-bottom: 1px solid #d7e4dc; position: sticky; top: 0; z-index: 1;
        }
        .sens-table tbody tr { cursor: pointer; }
        .sens-table tbody tr:hover { background: #f5fbf8; }
        .sens-table tbody tr.is-active { background: #e7f8ee; outline: 1px solid #74b49b; }
        .sens-empty { color: #7a8c84; text-align: center; padding: 1.4rem .5rem; }
        .sens-rtf {
            font-family: ui-monospace, Consolas, "Courier New", monospace;
            font-size: 12px; line-height: 1.35; white-space: pre;
            overflow: auto; background: #12171a; color: #d8e4dc;
            padding: 1rem; border-radius: 10px; min-height: 220px; max-height: 62vh;
        }
        .sens-table td.sens-date-stale,
        .sens-date-stale {
            color: #dc2626 !important;
            font-weight: 800;
        }
        .sens-rtf .report-date-stale { color: #f87171; font-weight: 800; }
        .sir { display: inline-flex; align-items: center; gap: 6px; border-radius: 999px;
            padding: 3px 8px; font-size: .72rem; font-weight: 800; margin: 0 6px 6px 0; }
        .sir-s { background: #dcfce7; color: #166534; }
        .sir-i { background: #fef3c7; color: #92400e; }
        .sir-r, .sir-n { background: #fee2e2; color: #991b1b; }
        .badge-res { background: #fee2e2; color: #991b1b; font-weight: 800; }
        .badge-ok { background: #dcfce7; color: #166534; font-weight: 800; }
        .sens-status { font-size: .82rem; color: #5f7468; }
        .sens-status.is-error { color: #b91c1c; }
        .table-scroll { max-height: 260px; overflow: auto; }
        .table-scroll-lg { max-height: 220px; overflow: auto; }
        .table-scroll-deep { max-height: 420px; overflow: auto; }
        .ast-filter .btn { font-size: .75rem; font-weight: 700; }
        .ast-pick {
            background: #f0faf5; border: 1px solid #9ad0b8; border-radius: 10px;
            padding: .55rem .75rem; font-size: .85rem; margin-bottom: .7rem;
        }
        .ast-pick strong { color: #146c4a; }
        .ast-group-title {
            font-size: .72rem; font-weight: 800; color: #0f766e; letter-spacing: .04em;
            text-transform: uppercase; margin: .7rem 0 .4rem;
        }
        .ast-sir-head { display: flex; align-items: center; gap: 8px; text-transform: none; letter-spacing: 0; font-size: .8rem; }
        .ast-sir-head-s { color: #166534; }
        .ast-sir-head-i { color: #92400e; }
        .ast-sir-head-r { color: #991b1b; }
        .ast-sir-head-n { color: #64748b; }
        .ast-slots {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(142px, 1fr));
            gap: 8px;
        }
        .ast-slot {
            border: 1px solid #d7e4dc; border-radius: 10px; background: #fff;
            padding: .5rem .6rem .55rem; text-align: left; cursor: pointer;
            min-height: 88px; width: 100%;
        }
        .ast-slot:hover { background: #f5fbf8; }
        .ast-slot.is-pick { outline: 2px solid #0f766e; box-shadow: 0 0 0 3px rgba(15,118,110,.16); }
        .ast-slot.is-onatb { box-shadow: none; }
        .ast-slot.sir-s { border-top: 4px solid #16a34a; }
        .ast-slot.sir-i { border-top: 4px solid #d97706; }
        .ast-slot.sir-r { border-top: 4px solid #dc2626; }
        .ast-slot.sir-n { border-top: 4px solid #94a3b8; opacity: .72; }
        .ast-slot .ast-letter { font-size: 1.25rem; font-weight: 800; line-height: 1; }
        .ast-slot.sir-s .ast-letter { color: #166534; }
        .ast-slot.sir-i .ast-letter { color: #92400e; }
        .ast-slot.sir-r .ast-letter { color: #991b1b; }
        .ast-slot.sir-n .ast-letter { color: #64748b; }
        .ast-slot .ast-drug { display: block; font-size: .72rem; font-weight: 800; margin-top: 4px; line-height: 1.2; word-break: break-word; }
        .ast-slot .ast-mic { display: block; font-size: .7rem; color: #5f7468; font-variant-numeric: tabular-nums; }
        .ast-slot .ast-meta { display: block; font-size: .65rem; color: #7a8c84; }
        .ast-onatb {
            display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
            border-radius: 8px; padding: .6rem .8rem; margin-bottom: .5rem;
            font-size: .88rem; font-weight: 800; letter-spacing: .01em; line-height: 1.35;
        }
        .ast-onatb-r { background: #dc2626; color: #fff; box-shadow: 0 0 0 2px #991b1b inset; }
        .ast-onatb-s { background: #16a34a; color: #fff; }
        .ast-onatb-i { background: #eab308; color: #1c1917; }
        .ast-onatb .ast-onatb-sir {
            display: inline-flex; align-items: center; justify-content: center;
            min-width: 1.6rem; height: 1.6rem; border-radius: 6px;
            background: rgba(255,255,255,.22); font-size: 1rem;
        }
        .ast-onatb-i .ast-onatb-sir { background: rgba(0,0,0,.12); }
        .ast-slot.is-onatb.sir-r {
            background: #dc2626; border-color: #991b1b; color: #fff;
        }
        .ast-slot.is-onatb.sir-r .ast-letter,
        .ast-slot.is-onatb.sir-r .ast-drug,
        .ast-slot.is-onatb.sir-r .ast-mic,
        .ast-slot.is-onatb.sir-r .ast-meta { color: #fff; }
        .ast-slot.is-onatb.sir-s {
            background: #16a34a; border-color: #15803d; color: #fff;
        }
        .ast-slot.is-onatb.sir-s .ast-letter,
        .ast-slot.is-onatb.sir-s .ast-drug,
        .ast-slot.is-onatb.sir-s .ast-mic,
        .ast-slot.is-onatb.sir-s .ast-meta { color: #fff; }
        .ast-slot.is-onatb.sir-i {
            background: #eab308; border-color: #ca8a04; color: #1c1917;
        }
        .ast-slot.is-onatb.sir-i .ast-letter,
        .ast-slot.is-onatb.sir-i .ast-drug,
        .ast-slot.is-onatb.sir-i .ast-mic,
        .ast-slot.is-onatb.sir-i .ast-meta { color: #1c1917; }
        .ast-empty-ng {
            background: #f8faf9; border: 1px dashed #b7c9bf; border-radius: 10px;
            padding: .9rem .85rem; color: #3f574c; font-size: .88rem; line-height: 1.45;
        }
        .ast-empty-ng strong { color: #146c4a; }
        .sens-summary {
            border-radius: 16px; padding: 0; margin-bottom: 16px; overflow: hidden;
            border: 3px solid #94a3b8; background: #fff;
            box-shadow: 0 10px 28px rgba(18,38,28,.10);
        }
        .sens-summary.is-ok { border-color: #16a34a; }
        .sens-summary.is-bad { border-color: #dc2626; box-shadow: 0 12px 32px rgba(220,38,38,.22); }
        .sens-summary.is-warn { border-color: #d97706; }
        .sens-summary.is-deesc { border-color: #2563eb; }
        .sens-summary.is-muted { border-color: #94a3b8; }
        .sens-summary .sum-head {
            display: flex; align-items: center; gap: 14px; flex-wrap: wrap;
            padding: .85rem 1.15rem; color: #fff; font-weight: 800;
        }
        .sens-summary.is-ok .sum-head { background: #16a34a; }
        .sens-summary.is-bad .sum-head { background: #dc2626; }
        .sens-summary.is-warn .sum-head { background: #d97706; }
        .sens-summary.is-muted .sum-head { background: #475569; }
        .sum-head .sum-ico {
            width: 2.4rem; height: 2.4rem; border-radius: 10px;
            display: inline-flex; align-items: center; justify-content: center;
            background: rgba(255,255,255,.2); font-size: 1.25rem; flex: 0 0 auto;
        }
        .sum-head h2 { font-size: 1.28rem; font-weight: 800; margin: 0; color: #fff; line-height: 1.25; flex: 1; min-width: 12rem; }
        .sum-head .sum-actions {
            margin-left: auto; display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
        }
        .sum-head .sum-badge {
            background: #fff; color: inherit;
            border-radius: 999px; padding: .28rem .85rem; font-size: .82rem; font-weight: 800;
            letter-spacing: .04em;
        }
        .sum-consult-btn {
            background: rgba(255,255,255,.16); border: 1px solid #fff; color: #fff;
            font-weight: 800; font-size: .76rem; border-radius: 999px;
            padding: .28rem .75rem; cursor: pointer; line-height: 1.2;
        }
        .sum-consult-btn:hover { background: #fff; }
        .sens-summary.is-bad .sum-consult-btn:hover { color: #991b1b; }
        .sens-summary.is-warn .sum-consult-btn:hover { color: #92400e; }
        .sum-consult-st {
            font-size: .72rem; font-weight: 700; background: rgba(255,255,255,.22);
            border-radius: 999px; padding: .2rem .55rem;
        }
        .sens-summary.is-ok .sum-badge { color: #166534; }
        .sens-summary.is-bad .sum-badge { color: #991b1b; }
        .sens-summary.is-warn .sum-badge { color: #92400e; }
        .sens-summary.is-muted .sum-badge { color: #334155; }
        .sens-summary .sum-body { padding: .9rem 1.15rem 1.05rem; }
        .sens-summary.is-ok .sum-body { background: #ecfdf3; }
        .sens-summary.is-bad .sum-body { background: #fee2e2; }
        .sens-summary.is-warn .sum-body { background: #fef3c7; }
        .sens-summary.is-muted .sum-body { background: #f1f5f9; }
        .sens-summary .sum-egfr {
            font-size: .88rem; font-weight: 700; color: #334155;
            background: rgba(255,255,255,.72); border-radius: 8px;
            padding: .4rem .65rem; margin-bottom: .75rem; display: inline-block;
        }
        .sens-summary .sum-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        @media (max-width: 900px) { .sens-summary .sum-grid { grid-template-columns: 1fr; } }
        .sens-summary .sum-col h3 {
            font-size: .8rem; font-weight: 800; color: #12261c; margin: 0 0 .45rem;
            text-transform: uppercase; letter-spacing: .04em;
        }
        .sum-item { background: #fff; border: 2px solid #e5eee9; border-radius: 10px; padding: .65rem .8rem; margin-bottom: .45rem; }
        .sum-item .nm { font-weight: 800; font-size: .92rem; }
        .sum-item .meta { font-size: .78rem; color: #5f7468; margin-top: 2px; }
        .sum-item.fit-bad { border-color: #dc2626; background: #fff; box-shadow: 0 0 0 1px #dc2626 inset; }
        .sum-item.fit-ok { border-color: #16a34a; background: #fff; }
        .sum-item.fit-warn { border-color: #d97706; }
        .sum-dose { font-size: .78rem; font-weight: 700; margin-top: 4px; color: #0f766e; }
        .sum-dose.adjust { color: #c2410c; }
        .sum-dose.avoid { color: #991b1b; }
        .sens-toolbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: .65rem; }
        .sens-toolbar .form-select { font-size: .8rem; max-width: 320px; }
        .sens-toolbar .btn { font-size: .75rem; font-weight: 700; }
        .clickable-drug { cursor: pointer; color: #0f766e; font-weight: 800; }
        .clickable-drug:hover { text-decoration: underline; }
        .icode-badge { font-size: .65rem; font-weight: 600; color: #5f7468; background: #f4f8f6; border: 1px solid #d7e4dc; border-radius: 6px; padding: 1px 6px; }
        .atb-timeline { overflow-x: auto; overflow-y: visible; max-height: none; padding: .35rem 0 .55rem; }
        .atb-tl-row { display: flex; gap: 8px; align-items: center; margin-bottom: 8px; min-width: max-content; }
        .atb-tl-name { width: 140px; flex: 0 0 140px; font-size: .72rem; font-weight: 800; color: #146c4a; }
        .atb-tl-bars { display: flex; gap: 6px; }
        .atb-tl-cell { text-align: center; }
        .atb-dose {
            display: inline-flex; align-items: center; justify-content: center;
            min-width: 36px; height: 28px; padding: 0 8px; border-radius: 6px;
            background: #0ea5e9; color: #fff; font-weight: 800; font-size: .78rem;
        }
        .atb-dose.sir-s { background: #16a34a; color: #fff; }
        .atb-dose.sir-i { background: #eab308; color: #1c1917; }
        .atb-dose.sir-r { background: #dc2626; color: #fff; }
        .atb-tl-name.sir-s { color: #166534; }
        .atb-tl-name.sir-i { color: #92400e; }
        .atb-tl-name.sir-r { color: #991b1b; }
        .atb-legend { font-size: .7rem; color: #5f7468; margin: 0 0 .45rem; display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
        .atb-legend i { display: inline-block; width: 10px; height: 10px; border-radius: 3px; margin-right: 4px; vertical-align: -1px; }
        .atb-legend .lg-s { background: #16a34a; }
        .atb-legend .lg-i { background: #eab308; }
        .atb-legend .lg-r { background: #dc2626; }
        .atb-legend .lg-u { background: #0ea5e9; }
        .atb-legend .lg-renal-s { background: #f97316; }
        .atb-legend .lg-renal-h { background: #7f1d1d; }
        .atb-renal {
            border-radius: 8px; padding: .55rem .75rem; margin-bottom: .45rem;
            font-size: .82rem; font-weight: 700; line-height: 1.4;
        }
        .atb-renal-hard { background: #dc2626; color: #fff; }
        .atb-renal-soft { background: #fff7ed; color: #9a3412; border: 1px solid #fdba74; }
        .atb-renal small { display: block; font-weight: 600; margin-top: 2px; opacity: .92; }
        .atb-renal-note { display: block; margin-top: 4px; font-size: .72rem; font-weight: 700; line-height: 1.35; }
        .atb-renal-note.hard { color: #991b1b; }
        .atb-renal-note.soft { color: #c2410c; }
        .atb-tl-name.renal-hard { color: #7f1d1d; }
        .atb-tl-name.renal-soft { color: #c2410c; }
        .renal-chip {
            display: inline-flex; align-items: center; justify-content: center;
            height: 1.2rem; padding: 0 6px; border-radius: 4px; font-size: .62rem;
            font-weight: 800; margin-left: 6px;
        }
        .renal-chip.hard { background: #7f1d1d; color: #fff; }
        .renal-chip.soft { background: #f97316; color: #fff; }
        .onnow-chip {
            display: inline-flex; align-items: center; justify-content: center;
            height: 1.2rem; padding: 0 6px; border-radius: 4px; font-size: .62rem;
            font-weight: 800; margin-left: 6px; background: #0f766e; color: #fff;
        }
        .sir-chip { display: inline-flex; align-items: center; justify-content: center; min-width: 1.2rem; height: 1.2rem; border-radius: 4px; font-size: .65rem; font-weight: 800; margin-left: 6px; }
        .sir-chip.sir-s { background: #16a34a; color: #fff; }
        .sir-chip.sir-i { background: #eab308; color: #1c1917; }
        .sir-chip.sir-r { background: #dc2626; color: #fff; }
        .sir-chip.sir-u { background: #0ea5e9; color: #fff; }
        .sens-search-hits {
            position: absolute; left: 0; right: 0; top: 100%; z-index: 20;
            background: #fff; border: 1px solid #d7e4dc; border-radius: 8px;
            max-height: 240px; overflow: auto; box-shadow: 0 8px 20px rgba(18,38,28,.1);
        }
        .sens-search-hits button {
            display: block; width: 100%; text-align: left; border: 0; background: #fff;
            padding: .45rem .7rem; font-size: .8rem; border-bottom: 1px solid #eef4f0;
        }
        .sens-search-hits button:hover { background: #f5fbf8; }
        .atb-tl-cell small { display: block; font-size: .62rem; color: #7a8c84; margin-top: 2px; }
        .sens-chart-wrap { height: 200px; margin-bottom: .4rem; }
        .sens-table tbody tr.no-pointer { cursor: default; }
        .badge-res { background: #fee2e2; color: #991b1b; font-weight: 800; }
        .badge-ok { background: #dcfce7; color: #166534; font-weight: 800; }
        .sens-status { font-size: .82rem; color: #5f7468; }
        .sens-status.is-error { color: #b91c1c; }
        .sum-item .rank-chip {
            display: inline-flex; align-items: center; justify-content: center;
            min-width: 1.35rem; height: 1.35rem; border-radius: 999px;
            background: #166534; color: #fff; font-size: .68rem; font-weight: 800;
            margin-right: 6px; vertical-align: 1px;
        }
        .sens-summary .sum-col h3 small {
            display: block; font-weight: 500; color: #5f7468; font-size: .72rem; margin-top: 2px;
        }
        .rank-row {
            display: flex; align-items: center; gap: 8px;
            background: #fff; border: 1px solid #d7e4dc; border-radius: 8px;
            padding: .45rem .6rem; margin-bottom: .4rem;
        }
        .rank-num {
            width: 1.6rem; height: 1.6rem; border-radius: 50%; flex: 0 0 auto;
            background: #166534; color: #fff; font-weight: 800;
            display: inline-flex; align-items: center; justify-content: center; font-size: .75rem;
        }
        .rank-label { flex: 1; font-size: .82rem; line-height: 1.3; }
        .rank-btns { display: flex; flex-direction: column; gap: 2px; }
        .rank-btns button {
            border: 0; background: #eef6f1; width: 1.55rem; height: 1.15rem;
            border-radius: 4px; color: #166534; line-height: 1; padding: 0;
        }
        .rank-btns button:hover { background: #d8eee2; }
        .sens-summary.is-deesc .sum-badge { color: #1d4ed8; }
        .sens-summary.is-deesc .sum-body { background: #eff6ff; }
        .sens-summary.is-deesc .sum-head { background: #1d4ed8; }
        .steward-opt {
            display: inline-flex; align-items: center; gap: 6px;
            font-size: .85rem; font-weight: 700; color: #146c4a;
            background: #fff; border: 1px solid #d7e4dc; border-radius: 999px;
            padding: .35rem .75rem; cursor: pointer;
        }
        .steward-opt:has(input:checked),
        .steward-opt.is-on { background: #dcfce7; border-color: #86efac; }
        .action-chip {
            display: inline-flex; align-items: center; justify-content: center;
            height: 1.2rem; padding: 0 6px; border-radius: 4px; font-size: .62rem;
            font-weight: 800; margin-left: 6px;
        }
        .action-chip.deescalate { background: #1d4ed8; color: #fff; }
        .action-chip.escalate { background: #c2410c; color: #fff; }
        .action-chip.same { background: #64748b; color: #fff; }
        .action-chip.continue { background: #0f766e; color: #fff; }
        .action-chip.start { background: #166534; color: #fff; }
        .sum-item.fit-deesc { border-color: #2563eb; }
        .rank-btns button:disabled { opacity: .35; }
        .aware-pill {
            display: inline-block; font-size: .68rem; font-weight: 700;
            padding: 1px 7px; border-radius: 999px; margin: 0 3px 2px 0; white-space: nowrap;
        }
        .aware-pill.who { background: #e8eef2; color: #334155; }
        .aware-pill.hosp { background: #d1fae5; color: #065f46; }
        .aware-pill.diff { background: #fef3c7; color: #92400e; }
        .split-callout {
            display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 12px;
        }
        @media (max-width: 768px) { .split-callout { grid-template-columns: 1fr; } }
        .split-box { border-radius: 12px; padding: 10px 12px; font-size: .82rem; line-height: 1.45; }
        .split-box.who { background: #f1f5f9; border: 1px solid #cbd5e1; }
        .split-box.hosp { background: #ecfdf5; border: 1px solid #a7f3d0; }
        .split-box .k { font-size: .72rem; font-weight: 800; letter-spacing: .04em; text-transform: uppercase; margin-bottom: 4px; }
        .drug-level-table tr.is-diff td { background: #fffbeb; }
        .who-lock { font-size: .8rem; font-weight: 700; color: #475569; }
        .steward-opt input { margin: 0; }
        .drug-level-table { font-size: .82rem; }
        .drug-level-table th { white-space: nowrap; }
        .drug-level-table td { vertical-align: middle; }
        .drug-level-table select {
            font-size: .8rem; min-width: 9.5rem;
        }
        .drug-level-key { font-weight: 700; color: #14532d; }
        .drug-level-class { color: #5f7468; font-size: .75rem; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content sens-content">
        <div class="container-fluid py-3">
            <div class="sens-hero">
                <div>
                    <div class="sens-kicker"><i class="fas fa-vial"></i> AMR · IC Status</div>
                    <h1 class="sens-title">CDSS for Antibiotic</h1>
                    <p class="sens-sub" id="sensSourceHint">ผลเพาะเชื้อ / AST จาก HOSxP หรือ mLAB ตามการตั้งค่าเชื่อมต่อ AMR — ประวัติยาปฏิชีวนะและ eGFR จาก HOSxP · <a href="amr_connect.php">เปลี่ยนแหล่งข้อมูล</a></p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-success btn-sm" id="btnAtbSettings">
                        <i class="fas fa-cog me-1"></i>ตั้งค่ารายการยา
                    </button>
                    <button type="button" class="btn btn-outline-success btn-sm" id="btnRecRank">
                        <i class="fas fa-sort-amount-down me-1"></i>ตั้งค่าลำดับยาแนะนำ / Escalate–De-escalate
                    </button>
                    <a href="amr_dashboard.php" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-chart-area me-1"></i>Dashboard เชื้อดื้อยา
                    </a>
                </div>
            </div>

            <div class="sens-panel mb-3" id="sensAtbSettings" style="display:none;">
                <h2>ตั้งค่ารายการยา Antibiotic</h2>
                <p class="desc mb-2">เพิ่ม/ลบยาที่ใช้ในแผง <strong>การได้รับยาปฏิชีวนะ</strong> — ถ้ายังไม่มีรายการ ระบบจะใช้ยาที่ติ๊ก Antibiotic ใน HOSxP</p>
                <div class="row g-2 align-items-end mb-2">
                    <div class="col-md-7 position-relative">
                        <label class="form-label small mb-1">ค้นหาและเพิ่มยาจาก HOSxP</label>
                        <input type="search" id="sensAtbSearch" class="form-control" placeholder="พิมพ์ชื่อยา หรือ icode" autocomplete="off">
                        <div id="sensAtbSearchHits" class="sens-search-hits" style="display:none;"></div>
                    </div>
                    <div class="col-md-5 d-flex gap-2">
                        <button type="button" class="btn btn-outline-success btn-sm" id="btnAtbImportFlag">
                            <i class="fas fa-download me-1"></i>ดึงยาที่ติ๊ก Antibiotic
                        </button>
                    </div>
                </div>
                <div class="small text-muted mb-2" id="sensAtbSetHint"></div>
                <div class="table-scroll">
                    <table class="table table-sm sens-table mb-0">
                        <thead>
                            <tr>
                                <th>ยา</th>
                                <th>generic</th>
                                <th>icode</th>
                                <th>รูปแบบ</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="sensAtbSetBody">
                            <tr><td colspan="5" class="sens-empty">กำลังโหลด...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="sens-panel mb-3" id="sensRecRank" style="display:none;">
                <h2>ลำดับยาที่แนะนำ — ตามหลักป้องกันเชื้อดื้อยา</h2>
                <div class="split-callout">
                    <div class="split-box who">
                        <div class="k">AWaRe ตาม WHO</div>
                        มาตรฐานสากล Access / Watch / Reserve — <strong>อ่านอย่างเดียว ไม่แก้ในระบบนี้</strong>
                        เช่น Ceftazidime และ Ceftriaxone = <strong>Watch</strong>
                    </div>
                    <div class="split-box hosp">
                        <div class="k">ระดับ รพ. สำหรับ Escalate / De-escalate</div>
                        ค่าที่โรงพยาบาลกำหนดเองเพื่อจัดลำดับยาแนะนำ — <strong>ปรับได้รายตัวยา</strong>
                        เช่น Ceftazidime เป็น Watch ตาม WHO แต่ รพ. อาจตั้งเป็น <strong>Access</strong>
                    </div>
                </div>
                <p class="desc mb-2">
                    ยาที่ผลเป็น <strong>S</strong> จะเรียงตาม <strong>ระดับ รพ.</strong> (Access → Watch → Reserve)
                    แล้วตาม <strong>กลุ่มยา</strong> จาก spectrum แคบไปกว้าง — Carbapenems อยู่ท้ายสุดตามหลัก stewardship
                </p>
                <div class="row g-3">
                    <div class="col-md-6">
                        <h3 class="h6 mb-2">1) ลำดับระดับ รพ. (Escalate / De-escalate)</h3>
                        <p class="desc mb-2">ชื่อ Access / Watch / Reserve ใช้เป็นขั้นของโรงพยาบาล ไม่ใช่การแก้ค่า WHO</p>
                        <div id="sensRankAware"></div>
                    </div>
                    <div class="col-md-6">
                        <h3 class="h6 mb-2">2) กลุ่มยา (เมื่อระดับ รพ. เท่ากัน)</h3>
                        <div id="sensRankClass"></div>
                    </div>
                </div>
                <div class="mt-3 p-3" style="background:#f6faf8;border:1px solid #d7e4dc;border-radius:10px;">
                    <h3 class="h6 mb-2">3) โหมดประเมินความเหมาะสม</h3>
                    <p class="desc mb-2 mb-md-3">
                        <strong>Escalate</strong> = ยาปัจจุบันไม่ครอบคลุม (R/I) จึงต้องเปลี่ยนไปใช้ยาที่มีผล S
                        · <strong>De-escalate</strong> = ยาปัจจุบันผล S แล้วลดไปใช้ยาที่ <strong>ระดับ รพ.</strong> ต่ำกว่า (เช่น Watch → Access) ที่มีผล S
                        · ค่าเริ่มต้นคือ <strong>ทั้งสอง</strong> — ใช้ร่วมกับ Monitor AMR Drug
                    </p>
                    <div class="d-flex flex-wrap gap-3" id="sensStewardModes">
                        <label class="steward-opt">
                            <input type="radio" name="sensStewardMode" value="both" checked>
                            <span>ทั้งสอง</span>
                        </label>
                        <label class="steward-opt">
                            <input type="radio" name="sensStewardMode" value="escalate">
                            <span>Escalate เท่านั้น</span>
                        </label>
                        <label class="steward-opt">
                            <input type="radio" name="sensStewardMode" value="deescalate">
                            <span>De-escalate เท่านั้น</span>
                        </label>
                    </div>
                </div>
                <div class="mt-3 p-3" style="background:#f6faf8;border:1px solid #d7e4dc;border-radius:10px;">
                    <h3 class="h6 mb-2">4) ระดับรายตัวยา — WHO กับ รพ. แยกคอลัมน์</h3>
                    <p class="desc mb-2">
                        คอลัมน์ <strong>AWaRe WHO</strong> ล็อกตามมาตรฐาน
                        · คอลัมน์ <strong>ระดับ รพ.</strong> ใช้จัด Escalate / De-escalate ทั้ง CDSS และ Monitor AMR Drug
                        · แถวสีเหลือง = ค่า รพ. ไม่ตรงกับ WHO (ตั้งใจของโรงพยาบาล)
                    </p>
                    <div class="row g-2 align-items-end mb-2">
                        <div class="col-md-5">
                            <label class="form-label small mb-1" for="sensDrugLevelQ">ค้นหาชื่อยา</label>
                            <input type="search" id="sensDrugLevelQ" class="form-control form-control-sm"
                                   placeholder="เช่น CEFTRIAXONE">
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small mb-1" for="sensDrugLevelAdd">เพิ่มชื่อยา AST</label>
                            <input type="text" id="sensDrugLevelAdd" class="form-control form-control-sm"
                                   placeholder="พิมพ์ชื่อ generic ตามผลแล็บ">
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-outline-success btn-sm w-100" id="btnDrugLevelAdd">
                                เพิ่มยา
                            </button>
                        </div>
                    </div>
                    <div class="table-scroll" style="max-height: 22rem;">
                        <table class="table table-sm sens-table drug-level-table mb-0">
                            <thead>
                                <tr>
                                    <th>ยา (ผล AST)</th>
                                    <th>กลุ่มยา</th>
                                    <th>AWaRe WHO</th>
                                    <th>ระดับ รพ. (Escalate / De-escalate)</th>
                                </tr>
                            </thead>
                            <tbody id="sensDrugLevelBody">
                                <tr><td colspan="4" class="sens-empty">เปิดแผงนี้เพื่อโหลดรายการยา</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="d-flex gap-2 mt-2 flex-wrap">
                    <button type="button" class="btn btn-success btn-sm" id="btnRecRankSave">
                        <i class="fas fa-save me-1"></i>บันทึกลำดับ ระดับยา และโหมดประเมิน
                    </button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="btnRecRankReset">
                        คืนค่าลำดับเริ่มต้น
                    </button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="btnDrugLevelReset">
                        คืนระดับ รพ. ให้ตรงกับ WHO
                    </button>
                    <span class="small text-muted align-self-center" id="sensRankHint"></span>
                </div>
            </div>

            <div class="sens-panel mb-3">
                <form id="sensForm" class="row g-2 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label small mb-1">ค้นหา HN / AN / Lab order / ชื่อ</label>
                        <input type="search" id="sensQ" class="form-control" placeholder="เช่น HN, AN หรือ lab order"
                               value="<?= htmlspecialchars($pre_q, ENT_QUOTES, 'UTF-8') ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-1">วันที่รายงาน จาก</label>
                        <input type="date" id="sensStart" class="form-control" value="<?= htmlspecialchars($default_start) ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-1">ถึงวันที่รายงาน</label>
                        <input type="date" id="sensEnd" class="form-control" value="<?= htmlspecialchars($default_end) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small mb-1">ขอบเขตผลเพาะเชื้อ</label>
                        <select id="sensScope" class="form-select">
                            <option value="resistant"<?= $pre_scope === 'resistant' ? ' selected' : '' ?>>เชื้อดื้อยา (result ไม่ว่าง)</option>
                            <option value="growth"<?= $pre_scope === 'growth' ? ' selected' : '' ?>>พบเชื้อ (ไม่รวม No growth)</option>
                            <option value="all"<?= $pre_scope === 'all' ? ' selected' : '' ?>>ทั้งหมด รวม No growth</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-success" id="btnSearch">
                            <i class="fas fa-search me-1"></i>ค้นหา
                        </button>
                    </div>
                    <div class="col-12">
                        <span class="sens-status" id="sensStatus">กรองตามวันที่รายงาน — ค่าเริ่มต้นเชื้อดื้อยา</span>
                    </div>
                </form>
            </div>

            <div class="sens-panel mb-3">
                <h2>Sensitivity All</h2>
                <p class="desc">รายการตาม <strong>วันที่รายงาน (reportdatetime)</strong> — ค่าเริ่มต้นคือเชื้อดื้อยา (result ไม่ว่าง)</p>
                <div class="table-scroll-lg">
                    <table class="table table-sm sens-table">
                        <thead>
                            <tr>
                                <th>ordertime</th>
                                <th>reportdatetime</th>
                                <th>hn</th>
                                <th>an</th>
                                <th>ptname</th>
                                <th>Wname</th>
                                <th>microtype</th>
                                <th>result</th>
                                <th>Specimen</th>
                            </tr>
                        </thead>
                        <tbody id="sensListBody">
                            <tr><td colspan="9" class="sens-empty">รอค้นหา</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div id="sensSummary" class="sens-summary" style="display:none;"></div>

            <div class="row g-3 mb-3 align-items-start">
                <div class="col-lg-6">
                    <div class="sens-panel">
                        <h2>Result Text</h2>
                        <p class="desc" id="sensHeaderHint">ข้อความผลแล็บรูปแบบรายงานเพาะเชื้อ (SPECIMEN / CULTURE / AST · สั่ง / รายงาน)</p>
                        <pre class="sens-rtf mb-0" id="sensRtf">เลือกแถวจากตารางด้านบน</pre>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="sens-panel">
                        <h2>Antibiogram (SIR)</h2>
                        <p class="desc">ค่าเริ่มต้นแสดงทั้งหมดที่มีผล เรียง S → I → R — กำลังให้ = วันนี้และ medplan ยังไม่ off</p>
                        <div id="sensAst">—</div>
                    </div>
                </div>
            </div>
            <div class="row g-3 mb-3 align-items-start">
                <div class="col-lg-6">
                    <div class="sens-panel">
                        <h2>ประวัติการทำงานของไต</h2>
                        <p class="desc">ค่าเริ่มต้น eGFR — เลือก lab อื่นได้แบบ Smart Lab</p>
                        <div class="sens-toolbar">
                            <select id="sensLabCode" class="form-select form-select-sm">
                                <option value="egfr">eGFR (CKD-EPI) — ค่าเริ่มต้น</option>
                            </select>
                            <a id="sensLabLink" class="btn btn-outline-success btn-sm" href="smart_lab.php" target="_blank" rel="noopener">Smart Lab</a>
                        </div>
                        <div class="sens-chart-wrap" id="sensLabChartWrap" style="display:none;">
                            <canvas id="sensLabChart"></canvas>
                        </div>
                        <div class="table-scroll table-scroll-deep">
                            <table class="table table-sm sens-table">
                                <thead><tr><th>reporttime</th><th>value</th><th>ค่าอ้างอิง</th></tr></thead>
                                <tbody id="sensKidney"><tr><td colspan="3" class="sens-empty">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="sens-panel">
                        <h2>การได้รับยาปฏิชีวนะ</h2>
                        <p class="desc">ค่าเริ่มต้นแสดงยาที่ใช้ปัจจุบัน (medplan ยังไม่ off) — เลือกดูยาปฏิชีวนะทั้งหมดได้</p>
                        <div class="sens-toolbar">
                            <select id="sensAtbFilter" class="form-select form-select-sm">
                                <option value="current" selected>ยาที่ใช้ปัจจุบัน</option>
                                <option value="all">ยาปฏิชีวนะทั้งหมด</option>
                            </select>
                            <a id="sensDrugLink" class="btn btn-outline-success btn-sm" href="smart_drug.php" target="_blank" rel="noopener">Smart Drug</a>
                            <a class="btn btn-outline-warning btn-sm" href="monitor_lab_renal.php" target="_blank" rel="noopener">Monitor Lab Renal</a>
                        </div>
                        <div id="sensAtbRenal"></div>
                        <div id="sensAtbTimeline" class="atb-timeline"></div>
                        <div class="table-scroll table-scroll-deep">
                            <table class="table table-sm sens-table">
                                <thead><tr><th>rxtime</th><th>รายการยา (icode)</th><th>จำนวน</th><th>วิธีใช้</th></tr></thead>
                                <tbody id="sensAtb"><tr><td colspan="4" class="sens-empty">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="accConsultModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold"><i class="fas fa-file-medical me-2 text-danger"></i>Consult / ใบปรึกษาแพทย์ — ยาไม่เหมาะสม</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="small text-muted mb-2" id="accConsultCaseInfo"></div>
                    <div class="border rounded p-2 mb-3 bg-light small" id="accDrugPreview"></div>
                    <div class="row g-2">
                        <div class="col-md-8">
                            <label class="form-label small fw-bold">เภสัชกรที่ Consult</label>
                            <select id="accPharmacist" class="form-select form-select-sm"></select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">รอตอบกลับ</label>
                            <select id="accReplyWait" class="form-select form-select-sm">
                                <option value="0">ทันที</option>
                                <option value="1">1 วัน</option>
                                <option value="2">2 วัน</option>
                                <option value="3">3 วัน</option>
                                <option value="5">5 วัน</option>
                                <option value="7">7 วัน</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">หมายเหตุจากเภสัชกร</label>
                            <textarea id="accConsultNote" class="form-control form-control-sm" rows="4" placeholder="ประเด็นปรึกษา เช่น ยาปัจจุบันผล R ควรเปลี่ยนยา"></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">ผล / ความเห็นแพทย์</label>
                            <textarea id="accDoctorReply" class="form-control form-control-sm" rows="2" placeholder="บันทึกเมื่อแพทย์ตอบกลับ"></textarea>
                        </div>
                    </div>
                    <div id="accConsultMsg" class="alert mt-3 mb-0 py-2 small d-none"></div>
                </div>
                <div class="modal-footer flex-wrap">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิดหน้าต่าง</button>
                    <button type="button" class="btn btn-outline-info btn-sm fw-bold" id="accBtnHistory">
                        <i class="fas fa-history me-1"></i> เปิดดูประวัติ
                    </button>
                    <button type="button" class="btn btn-outline-warning btn-sm fw-bold" id="accBtnReset">ตั้งเป็นรอ Consult</button>
                    <button type="button" class="btn btn-warning btn-sm fw-bold text-dark" id="accBtnSave">บันทึกผล Consult</button>
                    <button type="button" class="btn btn-outline-success btn-sm fw-bold" id="accBtnClose">ปิดการ Consult</button>
                    <button type="button" class="btn btn-danger btn-sm fw-bold" id="accBtnStart">
                        <i class="fas fa-print me-1"></i> เริ่ม Consult + พิมพ์ใบปรึกษา
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="accHistoryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold"><i class="fas fa-history me-2 text-info"></i>ประวัติการปรึกษาแพทย์ — CDSS</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="small text-muted mb-2" id="accHistoryInfo"></div>
                    <h6 class="fw-bold">ใบปรึกษาของผู้ป่วยรายนี้</h6>
                    <div class="table-responsive mb-3">
                        <table class="table table-sm table-bordered table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>อัปเดต</th>
                                    <th>Order</th>
                                    <th>เชื้อ</th>
                                    <th>ยาไม่เหมาะสม</th>
                                    <th>สถานะ</th>
                                    <th>เภสัชกร</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="accHistoryConsults">
                                <tr><td colspan="7" class="text-center text-muted py-3">ยังไม่มีประวัติ</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <h6 class="fw-bold">บันทึกการดำเนินการ</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>เวลา</th>
                                    <th>Order</th>
                                    <th>การกระทำ</th>
                                    <th>สถานะ</th>
                                    <th>ผู้ทำ</th>
                                    <th>หมายเหตุ</th>
                                </tr>
                            </thead>
                            <tbody id="accHistoryLog">
                                <tr><td colspan="6" class="text-center text-muted py-3">ยังไม่มีประวัติ</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/chart.min.js"></script>
<script>
const SENS_API = 'fetch_amr_sensitivity_api.php';
const ACC_API = 'fetch_amr_cdss_consult_api.php';
let autoOrder = <?= json_encode($pre_order) ?>;
let autoOpenFirst = <?= json_encode($pre_q !== '' && $pre_order === '') ?>;
let activeOrder = '';
let astRows = [];
let astFilter = 'tested';
let astPick = '';
let astNoGrowth = false;
let currentAtb = [];
let currentAtbNow = [];
let currentHn = '';
let currentLabCode = 'egfr';
let atbFilter = 'current';
let labChart = null;
let lastDetail = null;
let lastSpecimen = '';
let accCurrentConsult = null;
let accPharmacistsLoaded = false;
let accConsultModal = null;
let accHistoryModal = null;
let accDefaultWait = 0;

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function setStatus(msg, isError) {
    const el = document.getElementById('sensStatus');
    el.textContent = msg;
    el.classList.toggle('is-error', !!isError);
}

function emptyRow(cols, msg) {
    return '<tr><td colspan="' + cols + '" class="sens-empty">' + esc(msg) + '</td></tr>';
}

function setSourceLabel(src, label) {
    const el = document.getElementById('sensSourceHint');
    if (!el) return;
    const name = label || (src === 'mlab' ? 'mLAB (ตาราง THAM Hos-Safe)' : 'HOSxP lab_head');
    el.innerHTML = 'ผลเพาะเชื้อ / AST จาก <strong>' + esc(name) + '</strong> — ประวัติยาปฏิชีวนะและ eGFR จาก HOSxP · <a href="amr_connect.php">เปลี่ยนแหล่งข้อมูล</a>';
}

async function fetchJson(url, opt) {
    const res = await fetch(url, opt);
    const data = await res.json();
    if (!res.ok && !data) throw new Error('HTTP ' + res.status);
    return data;
}

function sirClass(sir) {
    const s = String(sir || '').toUpperCase();
    if (s === 'S') return 'sir-s';
    if (s === 'I') return 'sir-i';
    if (s === 'N') return 'sir-n';
    return 'sir-r';
}

function renderList(rows) {
    const body = document.getElementById('sensListBody');
    if (!rows.length) {
        body.innerHTML = emptyRow(9, 'ไม่พบผล Sensitivity ในเงื่อนไขนี้');
        return;
    }
    body.innerHTML = rows.map(r => {
        const order = String(r.lab_order_number || '');
        const res = r.result
            ? '<span class="badge badge-res">' + esc(r.result) + '</span>'
            : '';
        return '<tr data-order="' + esc(order) + '" data-specimen="' + esc(r.Specimen || '') + '"'
            + (order === activeOrder ? ' class="is-active"' : '') + '>'
            + '<td>' + esc(r.ordertime) + '</td>'
            + '<td class="text-nowrap' + (isStaleReport(r.reportdatetime) ? ' sens-date-stale' : '') + '"'
            + (isStaleReport(r.reportdatetime) ? ' style="color:#dc2626;font-weight:800"' : '') + '>'
            + esc(r.reportdatetime) + '</td>'
            + '<td class="fw-bold">' + esc(r.hn) + '</td>'
            + '<td>' + esc(r.an) + '</td>'
            + '<td>' + esc(r.ptname) + '</td>'
            + '<td>' + esc(r.Wname) + '</td>'
            + '<td class="fw-semibold">' + esc(r.microtype) + '</td>'
            + '<td>' + res + '</td>'
            + '<td>' + esc(r.Specimen) + '</td>'
            + '</tr>';
    }).join('');
    body.querySelectorAll('tr[data-order]').forEach(tr => {
        tr.addEventListener('click', () => loadDetail(tr.getAttribute('data-order')));
    });
}

function reportAgeDays(raw) {
    const s = String(raw || '').trim();
    if (!s || s === '—') return null;
    let y = 0, m = 0, d = 0;
    let x = s.match(/(\d{4})-(\d{2})-(\d{2})/);
    if (x) {
        y = Number(x[1]); m = Number(x[2]); d = Number(x[3]);
    } else {
        x = s.match(/(\d{2})[\/\-](\d{2})[\/\-](\d{4})/);
        if (!x) return null;
        d = Number(x[1]); m = Number(x[2]); y = Number(x[3]);
    }
    const dt = new Date(y, m - 1, d);
    if (isNaN(dt.getTime())) return null;
    const now = new Date();
    const a = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate());
    const b = Date.UTC(y, m - 1, d);
    return Math.floor((a - b) / 86400000);
}

function isStaleReport(raw) {
    const days = reportAgeDays(raw);
    return days != null && days > 5;
}

function astNorm(s) {
    return String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function astExpandName(name) {
    const u = String(name || '').toUpperCase().replace(/^\([^)]*\)\s*/, '').replace(/\s+/g, ' ').trim();
    const exact = {
        'NITROFURANTO': 'NITROFURANTOIN',
        'AMOXICIL/CLAV': 'AMOXICILLIN/CLAVULANATE',
        'AMOXICILL/CLAV': 'AMOXICILLIN/CLAVULANATE',
        'AUGMENTIN': 'AMOXICILLIN/CLAVULANATE'
    };
    if (exact[u]) return exact[u];
    const n = astNorm(u);
    const brands = [
        ['AMOXICILLINCLAVULANATE', 'AMOXICILLIN/CLAVULANATE'],
        ['AMOXYCILLINCLAVULANATE', 'AMOXICILLIN/CLAVULANATE'],
        ['AMOXICILLINCLAVULANIC', 'AMOXICILLIN/CLAVULANATE'],
        ['AMOXYCILLINCLAVULANIC', 'AMOXICILLIN/CLAVULANATE'],
        ['AMOXYCILLINCLAV', 'AMOXICILLIN/CLAVULANATE'],
        ['AMOXICILLINCLAV', 'AMOXICILLIN/CLAVULANATE'],
        ['AMOXICILCLAV', 'AMOXICILLIN/CLAVULANATE'],
        ['AMOXICILLCLAV', 'AMOXICILLIN/CLAVULANATE'],
        ['COAMOXICLAV', 'AMOXICILLIN/CLAVULANATE'],
        ['COAMOXYCLAV', 'AMOXICILLIN/CLAVULANATE'],
        ['AMOKSIKLAV', 'AMOXICILLIN/CLAVULANATE'],
        ['AMOXYCLAV', 'AMOXICILLIN/CLAVULANATE'],
        ['AMOXICLAV', 'AMOXICILLIN/CLAVULANATE'],
        ['AUGMENTIN', 'AMOXICILLIN/CLAVULANATE'],
        ['CLAVULIN', 'AMOXICILLIN/CLAVULANATE']
    ];
    let best = u;
    let bestLen = 0;
    brands.forEach(function (p) {
        if (n.indexOf(p[0]) >= 0 && p[0].length > bestLen) {
            bestLen = p[0].length;
            best = p[1];
        }
    });
    if (bestLen === 0 && n.indexOf('AMOX') >= 0 && n.indexOf('CLAV') >= 0) {
        return 'AMOXICILLIN/CLAVULANATE';
    }
    return best;
}

function astNamesMatch(a, b) {
    const ca = astExpandName(a);
    const cb = astExpandName(b);
    if (ca && cb && ca === cb) return true;
    const na = astNorm(ca), nb = astNorm(cb);
    if (na.length >= 6 && nb.length >= 6 && na === nb) return true;
    const da = astNorm(a), db = astNorm(b);
    if (da.length < 4 || db.length < 4) return false;
    return db.indexOf(da.slice(0, 8)) >= 0 || da.indexOf(db.slice(0, 8)) >= 0
        || db.indexOf(da) >= 0 || da.indexOf(db) >= 0;
}

function atbOnDrug(drug) {
    const pool = currentAtbNow.length ? currentAtbNow : [];
    return pool.some(function (r) {
        return astNamesMatch(drug, r.drugName) || astNamesMatch(drug, r.generic_name || '');
    });
}

function astSirForAtb(drugName) {
    if (!astRows.length) return '';
    let best = '';
    let bestLen = 0;
    astRows.forEach(function (a) {
        const sir = String(a.sir || '').toUpperCase();
        if (sir !== 'S' && sir !== 'I' && sir !== 'R') return;
        if (!astNamesMatch(a.drug, drugName)) return;
        const dlen = astNorm(astExpandName(a.drug)).length;
        if (dlen >= bestLen) {
            best = sir;
            bestLen = dlen;
        }
    });
    return best;
}

function sirChip(sir) {
    const s = String(sir || '').toUpperCase();
    if (s === 'S' || s === 'I' || s === 'R') {
        return '<span class="sir-chip sir-' + s.toLowerCase() + '">' + s + '</span>';
    }
    return '<span class="sir-chip sir-u">?</span>';
}

function renderAst() {
    const host = document.getElementById('sensAst');
    if (astNoGrowth) {
        host.innerHTML = '<div class="ast-empty-ng"><strong>ไม่พบเชื้อ (No Growth)</strong>'
            + '<div>ไม่มีผล Sensitivity / Antibiogram เพราะไม่พบเชื้อให้ทดสอบยา</div></div>';
        return;
    }
    if (!astRows.length) {
        host.innerHTML = '—';
        return;
    }
    const counts = { S: 0, I: 0, R: 0, N: 0 };
    astRows.forEach(function (a) { counts[a.sir] = (counts[a.sir] || 0) + 1; });
    const picked = astRows.filter(function (a) { return a.drug === astPick; })[0] || null;
    const classOrder = ['Penicillins', 'Beta-lactam/BLI', 'Cephalosporins', 'Carbapenems',
        'Fluoroquinolones', 'Aminoglycosides', 'Macrolides/Lincosamides', 'Others'];
    const sirRank = { S: 0, I: 1, R: 2, N: 3 };
    const show = astRows.filter(function (a) {
        if (astFilter === 'tested') return a.sir === 'S' || a.sir === 'I' || a.sir === 'R';
        if (astFilter === 'usable') return a.sir === 'S' || a.sir === 'I';
        if (astFilter === 'all') return true;
        return a.sir === astFilter;
    }).sort(function (a, b) {
        const sr = (sirRank[a.sir] ?? 9) - (sirRank[b.sir] ?? 9);
        if (sr !== 0) return sr;
        const ca = classOrder.indexOf(a.class);
        const cb = classOrder.indexOf(b.class);
        const ci = (ca < 0 ? 99 : ca) - (cb < 0 ? 99 : cb);
        if (ci !== 0) return ci;
        return String(a.drug || '').localeCompare(String(b.drug || ''));
    });
    const onAtb = { R: [], I: [], S: [] };
    astRows.forEach(function (a) {
        if ((a.sir === 'R' || a.sir === 'I' || a.sir === 'S') && atbOnDrug(a.drug)) {
            onAtb[a.sir].push(a);
        }
    });
    let html = '<div class="ast-filter btn-group btn-group-sm mb-2" role="group">';
    [
        ['tested', 'ทั้งหมด (' + ((counts.S || 0) + (counts.I || 0) + (counts.R || 0)) + ')'],
        ['usable', 'ใช้ได้ S/I (' + ((counts.S || 0) + (counts.I || 0)) + ')'],
        ['S', 'S ' + (counts.S || 0)],
        ['I', 'I ' + (counts.I || 0)],
        ['R', 'R ' + (counts.R || 0)],
        ['N', 'ไม่ได้ตรวจ ' + (counts.N || 0)],
        ['all', 'รวมไม่มีผล']
    ].forEach(function (x) {
        html += '<button type="button" class="btn ' + (astFilter === x[0] ? 'btn-success' : 'btn-outline-success')
            + '" data-ast-filter="' + x[0] + '">' + esc(x[1]) + '</button>';
    });
    html += '</div>';
    html += '<div class="ast-pick">' + (picked
        ? ('เลือกใช้: <strong>' + esc(picked.drug) + '</strong> · ' + esc(picked.sir)
            + (picked.mic ? ' · MIC ' + esc(picked.mic) : '')
            + (picked.aware ? ' · ' + esc(picked.aware) : ''))
        : 'คลิกช่องยาเพื่อเลือก Antibiotic สำหรับพิจารณาใช้ต่อ') + '</div>';
    [
        ['R', 'ยาที่กำลังให้วันนี้แต่ผลเป็น R', 'fas fa-exclamation-triangle'],
        ['I', 'ยาที่กำลังให้วันนี้ ผลเป็น I', 'fas fa-exclamation-circle'],
        ['S', 'ยาที่กำลังให้วันนี้ ผลเป็น S', 'fas fa-check-circle']
    ].forEach(function (x) {
        const list = onAtb[x[0]] || [];
        if (!list.length) return;
        html += '<div class="ast-onatb ast-onatb-' + x[0].toLowerCase() + '">'
            + '<span class="ast-onatb-sir">' + x[0] + '</span>'
            + '<span><i class="' + x[2] + ' me-1"></i>' + x[1] + ': '
            + list.map(function (a) { return esc(a.drug); }).join(', ')
            + '</span></div>';
    });
    if (!show.length) {
        html += '<p class="small text-muted mb-0">ไม่มีรายการในตัวกรองนี้</p>';
        host.innerHTML = html;
        bindAst();
        return;
    }
    const sirLabels = { S: 'S · Susceptible', I: 'I · Intermediate', R: 'R · Resistant', N: 'ไม่ได้ตรวจ' };
    const astSlot = function (a) {
        const on = atbOnDrug(a.drug);
        return '<button type="button" class="ast-slot ' + sirClass(a.sir)
            + (astPick === a.drug ? ' is-pick' : '')
            + (on ? ' is-onatb' : '')
            + '" data-ast-drug="' + esc(a.drug) + '">'
            + '<span class="ast-letter">' + esc(a.sir) + '</span>'
            + '<span class="ast-drug">' + esc(a.drug) + '</span>'
            + '<span class="ast-mic">' + (a.mic ? ('MIC ' + esc(a.mic)) : '—') + '</span>'
            + '<span class="ast-meta">' + awarePills(a.who_aware, a.aware) + (on ? ' · กำลังให้' : '') + '</span>'
            + '</button>';
    };
    ['S', 'I', 'R', 'N'].forEach(function (sir) {
        const rows = show.filter(function (a) { return a.sir === sir; });
        if (!rows.length) return;
        html += '<div class="ast-group-title ast-sir-head ast-sir-head-' + sir.toLowerCase() + '">' + sirLabels[sir] + '</div>';
        const groups = {};
        rows.forEach(function (a) {
            const g = a.class || 'Others';
            if (!groups[g]) groups[g] = [];
            groups[g].push(a);
        });
        classOrder.concat(Object.keys(groups)).filter(function (g, i, arr) {
            return groups[g] && arr.indexOf(g) === i;
        }).forEach(function (g) {
            html += '<div class="ast-group-title">' + esc(g) + '</div><div class="ast-slots">';
            groups[g].forEach(function (a) { html += astSlot(a); });
            html += '</div>';
        });
    });
    host.innerHTML = html;
    bindAst();
}

function bindAst() {
    document.querySelectorAll('[data-ast-filter]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            astFilter = btn.getAttribute('data-ast-filter') || 'tested';
            renderAst();
        });
    });
    document.querySelectorAll('[data-ast-drug]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const drug = btn.getAttribute('data-ast-drug') || '';
            astPick = astPick === drug ? '' : drug;
            renderAst();
        });
    });
}

function renderKidney(rows, labCode) {
    const host = document.getElementById('sensKidney');
    currentLabCode = labCode || 'egfr';
    if (!rows.length) {
        host.innerHTML = emptyRow(3, currentLabCode === 'egfr' ? 'ไม่พบ eGFR' : 'ไม่พบผล lab นี้');
        drawLabChart([]);
        return;
    }
    host.innerHTML = rows.map(r => '<tr class="no-pointer"><td>' + esc(r.reporttime) + '</td><td class="fw-bold">'
        + esc(r.value) + '</td><td>' + esc(r.normal_value || r.lab_name || '') + '</td></tr>').join('');
    drawLabChart(rows);
}

function drawLabChart(rows) {
    const wrap = document.getElementById('sensLabChartWrap');
    const canvas = document.getElementById('sensLabChart');
    if (labChart) {
        labChart.destroy();
        labChart = null;
    }
    const points = [];
    (rows || []).slice().reverse().forEach(function (r) {
        const raw = String(r.value || '').replace(/,/g, '');
        const n = parseFloat(raw.replace(/[^0-9.\-]/g, ''));
        if (!isNaN(n) && /[0-9]/.test(raw)) {
            points.push({ x: r.reporttime, y: n });
        }
    });
    if (!points.length || typeof Chart === 'undefined') {
        wrap.style.display = 'none';
        return;
    }
    wrap.style.display = '';
    labChart = new Chart(canvas.getContext('2d'), {
        type: 'line',
        data: {
            labels: points.map(p => p.x),
            datasets: [{
                data: points.map(p => p.y),
                borderColor: '#0f766e',
                backgroundColor: 'rgba(20,184,166,.15)',
                fill: true,
                tension: .25,
                pointRadius: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { ticks: { maxTicksLimit: 5, font: { size: 10 } }, grid: { display: false } },
                y: { ticks: { font: { size: 10 } } }
            }
        }
    });
}

function fillLabOptions(options, selected) {
    const sel = document.getElementById('sensLabCode');
    const opts = options && options.length ? options : [{ lab_code: 'egfr', lab_name: 'eGFR (CKD-EPI) — ค่าเริ่มต้น' }];
    sel.innerHTML = opts.map(o => '<option value="' + esc(o.lab_code) + '"'
        + ((o.lab_code === selected) ? ' selected' : '') + '>' + esc(o.lab_name) + '</option>').join('');
}

function fmtQty(q, unit) {
    if (q === '' || q == null) return '—';
    return esc(q) + (unit ? ' <span class="text-muted">' + esc(unit) + '</span>' : '');
}

function renalChip(alert) {
    if (!alert) return '';
    const lvl = alert.level === 'hard' ? 'hard' : 'soft';
    return '<span class="renal-chip ' + lvl + '">' + (lvl === 'hard' ? 'ห้ามใช้ตามไต' : 'ปรับตามไต') + '</span>';
}

function renalNote(alert) {
    if (!alert) return '';
    const lvl = alert.level === 'hard' ? 'hard' : 'soft';
    const lab = (alert.lab_value != null && alert.lab_value !== '')
        ? ' · eGFR ' + alert.lab_value + (alert.lab_date ? ' (' + alert.lab_date + ')' : '')
        : '';
    return '<span class="atb-renal-note ' + lvl + '">' + esc(alert.msg || '') + esc(lab) + '</span>';
}

function renalWorst(rows) {
    const byDrug = {};
    (rows || []).forEach(function (r) {
        const a = r.renal_alert;
        if (!a) return;
        const n = (r.drugName || r.icode || '').trim();
        if (!n) return;
        const prev = byDrug[n];
        if (!prev || (a.level === 'hard' && prev.level !== 'hard')) {
            byDrug[n] = Object.assign({ drugName: n }, a);
        }
    });
    return Object.keys(byDrug).map(function (n) { return byDrug[n]; });
}

function renderAtbRenal(rows) {
    const host = document.getElementById('sensAtbRenal');
    const alerts = renalWorst(rows);
    if (!alerts.length) {
        host.innerHTML = '';
        return;
    }
    host.innerHTML = alerts.map(function (a) {
        const lvl = a.level === 'hard' ? 'hard' : 'soft';
        const title = lvl === 'hard' ? 'ห้ามใช้ตามการทำงานของไต' : 'ควรปรับขนาดยาตามการทำงานของไต';
        const lab = (a.lab_value != null && a.lab_value !== '')
            ? 'eGFR ' + a.lab_value + (a.lab_date ? ' (' + a.lab_date + ')' : '')
            : '';
        return '<div class="atb-renal atb-renal-' + lvl + '">'
            + esc(title) + ' — ' + esc(a.drugName)
            + '<small>' + esc(a.msg || '') + (lab ? ' · ' + esc(lab) : '') + '</small>'
            + '</div>';
    }).join('');
}

function isAtbCurrentRow(r) {
    return Number(r.on_active) || Number(r.on_now);
}

function renderAtb() {
    const host = document.getElementById('sensAtb');
    const tl = document.getElementById('sensAtbTimeline');
    const sel = document.getElementById('sensAtbFilter');
    const names = [];
    currentAtb.forEach(function (r) {
        const n = (r.drugName || '').trim();
        if (n && names.indexOf(n) < 0) names.push(n);
    });
    const prev = atbFilter;
    sel.innerHTML = '<option value="current">ยาที่ใช้ปัจจุบัน</option>'
        + '<option value="all">ยาปฏิชีวนะทั้งหมด</option>'
        + names.map(n => '<option value="' + esc(n) + '">' + esc(n) + '</option>').join('');
    if (prev && (prev === 'current' || prev === 'all' || names.indexOf(prev) >= 0)) {
        sel.value = prev;
        atbFilter = prev;
    } else {
        atbFilter = 'current';
        sel.value = 'current';
    }
    const rows = currentAtb.filter(function (r) {
        if (atbFilter === 'current') return isAtbCurrentRow(r);
        if (atbFilter === 'all') return true;
        return (r.drugName || '') === atbFilter;
    });
    renderAtbRenal(rows);
    if (!rows.length) {
        host.innerHTML = emptyRow(4, atbFilter === 'current' ? 'ไม่พบยาที่ใช้ปัจจุบัน — เลือกดูยาปฏิชีวนะทั้งหมดได้' : 'ไม่พบยาปฏิชีวนะ');
        tl.innerHTML = '';
        tl.style.minHeight = '';
        return;
    }
    host.innerHTML = rows.map(function (r) {
        const sir = astSirForAtb(r.drugName);
        return '<tr class="no-pointer"><td>' + esc(r.rxtime) + '</td><td>'
            + '<span class="clickable-drug" data-atb-drug="' + esc(r.drugName) + '">' + esc(r.drugName) + '</span>'
            + sirChip(sir)
            + renalChip(r.renal_alert)
            + (Number(r.on_now) ? '<span class="onnow-chip">กำลังให้</span>' : '')
            + (r.icode ? '<div><span class="icode-badge">' + esc(r.icode) + '</span></div>' : '')
            + '</td><td class="fw-bold">' + fmtQty(r.qty, r.units) + '</td><td>'
            + esc(r.method || '—')
            + renalNote(r.renal_alert)
            + '</td></tr>';
    }).join('');
    host.querySelectorAll('[data-atb-drug]').forEach(function (el) {
        el.addEventListener('click', function () {
            atbFilter = el.getAttribute('data-atb-drug') || 'all';
            renderAtb();
        });
    });
    const byDrug = {};
    rows.slice().reverse().forEach(function (r) {
        const n = (r.drugName || '').trim() || '-';
        if (!byDrug[n]) byDrug[n] = [];
        byDrug[n].push(r);
    });
    let html = '<div class="atb-legend">'
        + '<span><i class="lg-s"></i>S เขียว</span>'
        + '<span><i class="lg-i"></i>I เหลือง</span>'
        + '<span><i class="lg-r"></i>R แดง</span>'
        + '<span><i class="lg-u"></i>ไม่ทราบ ฟ้า</span>'
        + '<span><i class="lg-renal-s"></i>ปรับตามไต</span>'
        + '<span><i class="lg-renal-h"></i>ห้ามใช้ตามไต</span>'
        + '</div>';
    Object.keys(byDrug).forEach(function (name) {
        const sir = astSirForAtb(name);
        const renal = (byDrug[name].find(function (r) { return r.renal_alert; }) || {}).renal_alert;
        const renalCls = renal ? (' renal-' + (renal.level === 'hard' ? 'hard' : 'soft')) : '';
        const doseCls = 'atb-dose' + (sir ? ' sir-' + sir.toLowerCase() : '');
        const nameCls = 'atb-tl-name' + (sir ? ' sir-' + sir.toLowerCase() : '') + renalCls;
        const cells = {};
        byDrug[name].forEach(function (r) {
            const d = (r.rxdate || String(r.rxtime || '').slice(0, 10));
            const q = parseFloat(r.qty);
            cells[d] = (cells[d] || 0) + (isNaN(q) ? 0 : q);
        });
        html += '<div class="atb-tl-row"><div class="' + nameCls + '">' + esc(name) + '</div><div class="atb-tl-bars">';
        Object.keys(cells).sort().forEach(function (d) {
            const short = d.length >= 10 ? d.slice(8, 10) + '/' + d.slice(5, 7) : d;
            html += '<div class="atb-tl-cell"><span class="' + doseCls + '">' + esc(cells[d]) + '</span><small>' + esc(short) + '</small></div>';
        });
        html += '</div></div>';
    });
    tl.innerHTML = html;
    const nItems = Object.keys(byDrug).length;
    tl.style.minHeight = (32 + nItems * 48) + 'px';
}

function renderSummary(sum) {
    const host = document.getElementById('sensSummary');
    if (!sum) {
        host.style.display = 'none';
        host.innerHTML = '';
        return;
    }
    const mapCls = {
        appropriate: 'is-ok',
        inappropriate: 'is-bad',
        caution: 'is-warn',
        deescalate: 'is-deesc',
        no_current: 'is-muted',
        no_ast: 'is-muted',
        no_growth: 'is-muted',
        unknown: 'is-muted'
    };
    const fitCls = { appropriate: 'fit-ok', inappropriate: 'fit-bad', caution: 'fit-warn', unknown: '', deescalate: 'fit-deesc' };
    const fitLabel = { appropriate: 'เหมาะสม (S)', inappropriate: 'ไม่เหมาะสม (R)', caution: 'ระวัง (I)', unknown: 'ยังไม่มีผล AST' };
    const badge = {
        appropriate: 'เหมาะสม',
        inappropriate: 'ไม่เหมาะสม',
        caution: 'ใช้ด้วยความระวัง',
        deescalate: 'ลดชั้นได้',
        no_current: 'ไม่มียาปัจจุบัน',
        no_ast: 'ไม่มีผล AST',
        no_growth: 'ไม่พบเชื้อ',
        unknown: 'ยังไม่ประเมิน'
    };
    const ico = {
        appropriate: 'fa-check-circle',
        inappropriate: 'fa-exclamation-triangle',
        caution: 'fa-exclamation-circle',
        deescalate: 'fa-level-down-alt',
        no_current: 'fa-info-circle',
        no_ast: 'fa-info-circle',
        no_growth: 'fa-info-circle',
        unknown: 'fa-question-circle'
    };
    const actionLabel = {
        deescalate: 'ลดชั้น',
        escalate: 'เปลี่ยนยา',
        same: 'กลุ่มเดียวกัน',
        continue: 'กำลังให้',
        start: 'เริ่มยา'
    };
    host.className = 'sens-summary ' + (mapCls[sum.verdict] || 'is-muted');
    host.style.display = '';
    const egfr = (sum.egfr != null)
        ? 'eGFR ล่าสุด ' + sum.egfr + (sum.egfr_date ? ' (' + sum.egfr_date + ')' : '') + ' — ใช้ประกอบแนะนำขนาดยา'
        : 'ยังไม่มี eGFR สำหรับประเมินขนาดยา';
    const current = sum.current || [];
    const recs = sum.recommend || [];
    const avoid = sum.avoid_renal || [];
    const mode = (sum.steward_mode || 'both');
    const modeHint = mode === 'escalate'
        ? 'โหมด Escalate — แนะนำยากลุ่มสูงกว่าเมื่อยาปัจจุบันเป็น R/I'
        : (mode === 'deescalate'
            ? 'โหมด De-escalate — แนะนำยาที่ระดับ รพ. ต่ำกว่าที่มีผล S'
            : 'โหมดทั้งสอง — Escalate เมื่อยาปัจจุบันเป็น R/I และ De-escalate เมื่อยาปัจจุบันผล S และมียาระดับ รพ. ต่ำกว่า');
    let curHtml = current.length
        ? current.map(function (c) {
            const renal = c.renal || {};
            const doseCls = renal.status === 'adjust' || renal.status === 'avoid' ? renal.status : '';
            const st = c.steward || '';
            const wantDe = mode !== 'escalate';
            const wantEs = mode !== 'deescalate';
            let stChip = '';
            if (wantDe && (st === 'deescalate' || st === 'both' || Number(c.can_deescalate))) {
                stChip += '<span class="action-chip deescalate">ลดชั้นได้</span>';
            }
            if (wantEs && (st === 'escalate' || st === 'both' || Number(c.need_escalate))) {
                stChip += '<span class="action-chip escalate">ควรเปลี่ยนยา</span>';
            }
            const toDe = wantDe ? (c.deescalate_to || []).filter(Boolean) : [];
            const toEs = wantEs ? (c.escalate_to || []).filter(Boolean) : [];
            let toHtml = '';
            if (toDe.length) toHtml += '<div class="meta">ลดชั้นได้ → ' + esc(toDe.join(', ')) + '</div>';
            if (toEs.length && (c.sir === 'R' || c.sir === 'I')) {
                toHtml += '<div class="meta">เปลี่ยนเป็น → ' + esc(toEs.join(', ')) + '</div>';
            }
            return '<div class="sum-item ' + (fitCls[c.fit] || '') + '">'
                + '<div class="nm">' + esc(c.drugName) + ' <span class="sir-chip sir-' + (c.sir || 'u').toLowerCase() + '">'
                + esc(c.sir || '?') + '</span>' + stChip + '</div>'
                + '<div class="meta">' + esc(fitLabel[c.fit] || '')
                + (c.aware || c.who_aware ? ' · ' : '') + awarePills(c.who_aware, c.aware)
                + (c.class ? ' · ' + esc(c.class) : '')
                + (c.method ? ' · ' + esc(c.method) : '')
                + (c.mic ? ' · MIC ' + esc(c.mic) : '') + '</div>'
                + toHtml
                + (renal.msg ? '<div class="sum-dose ' + doseCls + '">' + esc(renal.msg) + '</div>' : '')
                + '</div>';
        }).join('')
        : '<div class="small text-muted">ไม่มีรายการยาปัจจุบัน</div>';
    let recHtml = recs.length
        ? recs.map(function (r, i) {
            const renal = r.renal || {};
            const doseCls = renal.status === 'adjust' || renal.status === 'avoid' ? renal.status : '';
            const act = r.action || '';
            const actChip = act && actionLabel[act]
                ? '<span class="action-chip ' + act + '">' + esc(actionLabel[act]) + '</span>'
                : '';
            const itemCls = act === 'escalate' ? 'fit-warn' : (act === 'deescalate' ? 'fit-deesc' : 'fit-ok');
            return '<div class="sum-item ' + itemCls + '">'
                + '<div class="nm"><span class="rank-chip">' + esc(r.rank || (i + 1)) + '</span>' + esc(r.drug)
                + (Number(r.on_now) ? '<span class="onnow-chip">กำลังให้</span>' : '')
                + actChip
                + '</div>'
                + '<div class="meta">S' + (r.mic ? ' · MIC ' + esc(r.mic) : '')
                + (r.aware || r.who_aware ? ' · ' : '') + awarePills(r.who_aware, r.aware)
                + (r.class ? ' · ' + esc(r.class) : '') + '</div>'
                + (renal.msg ? '<div class="sum-dose ' + doseCls + '">' + esc(renal.msg) + '</div>' : '')
                + '</div>';
        }).join('')
        : '<div class="small text-muted">ไม่มียาที่เข้าเงื่อนไขโหมดประเมิน (ผลเป็น S)</div>';
    if (avoid.length) {
        recHtml += '<div class="small text-muted mt-2 mb-1">ผลเป็น S แต่ไม่แนะนำตามไต</div>'
            + avoid.map(function (r) {
                return '<div class="sum-item fit-bad"><div class="nm">' + esc(r.drug) + '</div>'
                    + '<div class="sum-dose avoid">' + esc((r.renal && r.renal.msg) || '') + '</div></div>';
            }).join('');
    }
    const canConsult = sum.verdict === 'inappropriate'
        || current.some(function (c) { return c.fit === 'inappropriate' || c.sir === 'R'; });
    const st = accCurrentConsult || {};
    let actions = '<span class="sum-badge">' + esc(badge[sum.verdict] || '') + '</span>';
    if (canConsult) {
        actions = '<div class="sum-actions">'
            + (st.status_label ? '<span class="sum-consult-st">' + esc(st.status_label) + '</span>' : '')
            + '<button type="button" class="sum-consult-btn" id="accBtnOpenConsult"><i class="fas fa-print me-1"></i>พิมพ์ใบปรึกษาแพทย์</button>'
            + '<button type="button" class="sum-consult-btn" id="accBtnOpenHistory"><i class="fas fa-history me-1"></i>ประวัติการปรึกษา</button>'
            + '<span class="sum-badge">' + esc(badge[sum.verdict] || '') + '</span>'
            + '</div>';
    }
    host.innerHTML = '<div class="sum-head">'
        + '<span class="sum-ico"><i class="fas ' + (ico[sum.verdict] || 'fa-info-circle') + '"></i></span>'
        + '<h2>' + esc(sum.title || '') + '</h2>'
        + actions
        + '</div>'
        + '<div class="sum-body">'
        + '<div class="sum-egfr">' + esc(egfr) + '</div>'
        + '<div class="small text-muted mb-2">' + esc(modeHint) + '</div>'
        + '<div class="sum-grid">'
        + '<div class="sum-col"><h3>ยาที่กำลังให้</h3>' + curHtml + '</div>'
        + '<div class="sum-col"><h3>แนะนำยาที่เหมาะสม + ขนาดตามไต'
        + '<small>ลดชั้น = ยาปัจจุบันผล S และมียาระดับ รพ. ต่ำกว่าผล S · เปลี่ยนยา = ยาปัจจุบันเป็น R/I</small></h3>' + recHtml + '</div>'
        + '</div></div>';
    const btnC = document.getElementById('accBtnOpenConsult');
    const btnH = document.getElementById('accBtnOpenHistory');
    if (btnC) btnC.addEventListener('click', function (e) { e.preventDefault(); accOpenConsult(); });
    if (btnH) btnH.addEventListener('click', function (e) { e.preventDefault(); accOpenHistory(); });
}

function fmtSensWhen(raw) {
    const s = String(raw || '').trim();
    if (!s) return '';
    const m = s.match(/(\d{4}-\d{2}-\d{2})(?:[ T]+(\S+))?/);
    if (!m) return s;
    let t = '';
    if (m[2]) {
        const dig = String(m[2]).replace(/\D/g, '');
        if (dig.length >= 4) t = dig.slice(0, 2) + ':' + dig.slice(2, 4);
        else {
            const hm = String(m[2]).match(/(\d{1,2}:\d{2})/);
            if (hm) t = hm[1];
        }
    }
    return t ? (m[1] + ' ' + t) : m[1];
}

function setSensRtf(text, reportDt) {
    const el = document.getElementById('sensRtf');
    if (!el) return;
    const raw = String(text || '');
    let html = esc(raw);
    html = html.replace(
        /(RELEASED\s*:\s*|ORDERED\s*:\s*)(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?)/gi,
        function (_, p, d) {
            return p + (isStaleReport(d) || isStaleReport(reportDt)
                ? ('<span class="report-date-stale">' + d + '</span>')
                : d);
        }
    );
    el.innerHTML = html;
}

function renderTables(detail) {
    lastDetail = detail || null;
    const h = detail.header || {};
    currentHn = String(h.hn || '');
    const specEl = document.querySelector('#sensListBody tr.is-active');
    lastSpecimen = specEl ? (specEl.getAttribute('data-specimen') || '') : lastSpecimen;
    const staleOrd = isStaleReport(h.ordertime);
    const staleRep = isStaleReport(h.reportdatetime);
    const hintBits = [esc(h.ptname || ''), 'HN ' + esc(h.hn || ''), 'AN ' + esc(h.an || ''), 'order ' + esc(h.lab_order_number || '')]
        .filter(function (x) { return x && x !== 'HN ' && x !== 'AN ' && x !== 'order '; });
    const orderShow = fmtSensWhen(h.ordertime);
    const reportShow = fmtSensWhen(h.reportdatetime);
    if (orderShow) {
        hintBits.push(staleOrd
            ? ('<span class="sens-date-stale">สั่ง ' + esc(orderShow) + '</span>')
            : ('สั่ง ' + esc(orderShow)));
    }
    if (reportShow) {
        hintBits.push(staleRep
            ? ('<span class="sens-date-stale">รายงาน ' + esc(reportShow) + '</span>')
            : ('รายงาน ' + esc(reportShow)));
    }
    document.getElementById('sensHeaderHint').innerHTML = hintBits.join(' · ');
    setSensRtf(detail.result_text || '(ไม่มีข้อความผล)', h.reportdatetime || '');
    astRows = detail.ast || [];
    astPick = '';
    astNoGrowth = !!detail.no_growth || /no\s*growth/i.test(String(h.microtype || ''));
    currentAtb = detail.atb || [];
    currentAtbNow = detail.atb_current || [];
    atbFilter = 'current';
    renderAst();
    fillLabOptions(detail.lab_options || [], detail.lab_code || 'egfr');
    renderKidney(detail.kidney || [], detail.lab_code || 'egfr');
    const labHref = currentHn ? ('smart_lab.php?hn=' + encodeURIComponent(currentHn)) : 'smart_lab.php';
    const drugHref = currentHn ? ('smart_drug.php?hn=' + encodeURIComponent(currentHn)) : 'smart_drug.php';
    document.getElementById('sensLabLink').href = labHref;
    document.getElementById('sensDrugLink').href = drugHref;
    renderAtb();
    renderSummary(detail.summary || null);
}

async function searchList() {
    const btn = document.getElementById('btnSearch');
    btn.disabled = true;
    setStatus('กำลังค้นหา...');
    try {
        const scope = document.getElementById('sensScope').value || 'resistant';
        const q = new URLSearchParams({
            action: 'search',
            q: document.getElementById('sensQ').value.trim(),
            start_date: document.getElementById('sensStart').value,
            end_date: document.getElementById('sensEnd').value,
            scope: scope
        });
        const data = await fetchJson(SENS_API + '?' + q.toString());
        if (data.status !== 'success') throw new Error(data.message || 'ค้นหาไม่สำเร็จ');
        setSourceLabel(data.source, data.source_label);
        const rows = data.rows || [];
        renderList(rows);
        const scopeLabel = scope === 'resistant'
            ? 'เชื้อดื้อยา'
            : (scope === 'all' ? 'ทั้งหมด' : 'ไม่รวม No growth');
        setStatus('พบ ' + rows.length + ' รายการ · ' + scopeLabel + ' · ตามวันที่รายงาน');
        if (autoOrder && rows.some(r => String(r.lab_order_number) === autoOrder)) {
            await loadDetail(autoOrder);
            autoOrder = '';
        } else if (rows.length === 1) {
            await loadDetail(String(rows[0].lab_order_number || ''));
        }
        return rows;
    } catch (e) {
        setStatus(e.message || String(e), true);
        document.getElementById('sensListBody').innerHTML = emptyRow(9, e.message || 'ค้นหาไม่สำเร็จ');
        return [];
    } finally {
        btn.disabled = false;
    }
}

function accDefaultNote() {
    const h = (lastDetail && lastDetail.header) || {};
    const sum = (lastDetail && lastDetail.summary) || {};
    const current = sum.current || [];
    const recs = sum.recommend || [];
    const rLines = [];
    current.forEach(function (c) {
        if (c.fit !== 'inappropriate' && c.sir !== 'R') return;
        let line = c.drugName || '';
        if (c.sir) line += ' (ผล ' + c.sir + ')';
        if (c.mic) line += ' MIC ' + c.mic;
        if (line) rLines.push(line);
    });
    const recNames = recs.map(function (r) { return r.drug || r.drugName; }).filter(Boolean).slice(0, 8);
    const lines = ['พบยาไม่เหมาะสมต่อผล Sensitivity (กำลังให้ยาที่ผลเป็น R) ควร Escalate'];
    if (sum.organism) lines.push('เชื้อ: ' + sum.organism);
    if (lastSpecimen) lines.push('Specimen: ' + lastSpecimen);
    if (rLines.length) lines.push('ยาที่ไม่เหมาะสม: ' + rLines.join('; '));
    if (recNames.length) lines.push('ยาที่แนะนำ (ผล S): ' + recNames.join(', '));
    if (sum.egfr != null) {
        lines.push('eGFR ล่าสุด ' + sum.egfr + (sum.egfr_date ? ' (' + sum.egfr_date + ')' : ''));
    }
    return lines.join('\n');
}

function accBuildPayload() {
    const h = (lastDetail && lastDetail.header) || {};
    const sum = (lastDetail && lastDetail.summary) || {};
    const current = (sum.current || []).map(function (c) {
        return {
            drugName: c.drugName || '',
            icode: c.icode || '',
            method: c.method || '',
            sir: c.sir || '',
            mic: c.mic || '',
            fit: c.fit || '',
            aware: c.aware || '',
            class: c.class || ''
        };
    });
    const recs = (sum.recommend || []).map(function (r) {
        return {
            drug: r.drug || r.drugName || '',
            mic: r.mic || '',
            aware: r.aware || '',
            class: r.class || '',
            action: r.action || '',
            renal: r.renal || {}
        };
    });
    return {
        consult_id: accCurrentConsult && accCurrentConsult.id ? accCurrentConsult.id : 0,
        lab_order_number: h.lab_order_number || activeOrder,
        hn: h.hn || currentHn,
        an: h.an || '',
        vn: h.vn || '',
        ptname: h.ptname || '',
        ward_name: h.Wname || h.wname || '',
        specimen: lastSpecimen || '',
        organism: sum.organism || h.microtype || '',
        phenotype: h.result || '',
        report_date: h.reportdatetime || '',
        verdict: sum.verdict || '',
        verdict_title: sum.title || '',
        egfr: sum.egfr != null ? String(sum.egfr) : '',
        egfr_date: sum.egfr_date || '',
        current_drugs: current,
        recommend: recs,
        avoid_renal: sum.avoid_renal || []
    };
}

function accShowMsg(ok, msg) {
    const el = document.getElementById('accConsultMsg');
    if (!el) return;
    el.className = 'alert mt-3 mb-0 py-2 small ' + (ok ? 'alert-success' : 'alert-danger');
    el.textContent = msg || '';
}

function accApplyConsult(c) {
    accCurrentConsult = c || null;
    if (lastDetail && lastDetail.summary) renderSummary(lastDetail.summary);
}

async function accRefreshConsult() {
    if (!activeOrder) {
        accCurrentConsult = null;
        return;
    }
    try {
        const data = await fetchJson(ACC_API + '?action=get&order=' + encodeURIComponent(activeOrder));
        accCurrentConsult = (data && data.consult) ? data.consult : null;
        if (lastDetail && lastDetail.summary) renderSummary(lastDetail.summary);
    } catch (e) {
        accCurrentConsult = null;
    }
}

async function accEnsurePharmacists() {
    if (accPharmacistsLoaded) return;
    const data = await fetchJson(ACC_API + '?action=pharmacists');
    const sel = document.getElementById('accPharmacist');
    const list = (data && data.pharmacists) || [];
    sel.innerHTML = list.map(function (p) {
        const name = (p.full_name || p.username || '').trim();
        const pos = String(p.entryposition || '').trim();
        const label = pos ? (name + ' (' + pos + ')') : name;
        return '<option value="' + esc(p.id) + '">' + esc(label) + '</option>';
    }).join('') || '<option value="">— ไม่พบผู้ใช้ตำแหน่งเภสัชกร —</option>';
    accDefaultWait = (data && data.reply_wait_days != null) ? Number(data.reply_wait_days) : 0;
    const waitEl = document.getElementById('accReplyWait');
    if (waitEl.querySelector('option[value="' + accDefaultWait + '"]')) {
        waitEl.value = String(accDefaultWait);
    }
    if (data && data.current_user_id && sel.querySelector('option[value="' + data.current_user_id + '"]')) {
        sel.value = String(data.current_user_id);
    }
    accPharmacistsLoaded = true;
}

function accFillFormFromConsult(c) {
    c = c || {};
    document.getElementById('accConsultNote').value = c.consult_note || accDefaultNote();
    document.getElementById('accDoctorReply').value = c.doctor_reply || '';
    if (c.reply_wait_days != null && document.getElementById('accReplyWait').querySelector('option[value="' + c.reply_wait_days + '"]')) {
        document.getElementById('accReplyWait').value = String(c.reply_wait_days);
    }
    const sel = document.getElementById('accPharmacist');
    if (c.pharmacist_user_id && sel.querySelector('option[value="' + c.pharmacist_user_id + '"]')) {
        sel.value = String(c.pharmacist_user_id);
    }
}

async function accOpenConsult() {
    if (!lastDetail || !lastDetail.summary) {
        alert('กรุณาเลือกผล Sensitivity ก่อน');
        return;
    }
    const sum = lastDetail.summary;
    const can = sum.verdict === 'inappropriate' || (sum.current || []).some(function (c) {
        return c.fit === 'inappropriate' || c.sir === 'R';
    });
    if (!can) {
        alert('ใบปรึกษานี้ใช้เมื่อยาปัจจุบันผลเป็น R (ไม่เหมาะสม)');
        return;
    }
    await accEnsurePharmacists();
    const h = lastDetail.header || {};
    const rDrugs = (sum.current || []).filter(function (c) {
        return c.fit === 'inappropriate' || c.sir === 'R';
    });
    document.getElementById('accConsultCaseInfo').innerHTML =
        '<b>' + esc(h.ptname || '') + '</b> · HN ' + esc(h.hn || '') + ' · AN ' + esc(h.an || '')
        + '<br>Order ' + esc(h.lab_order_number || activeOrder)
        + (sum.organism ? ' · ' + esc(sum.organism) : '')
        + (lastSpecimen ? ' · ' + esc(lastSpecimen) : '');
    document.getElementById('accDrugPreview').innerHTML = rDrugs.length
        ? rDrugs.map(function (c) {
            return '<div><b>' + esc(c.drugName) + '</b> <span class="badge bg-danger">' + esc(c.sir || 'R') + '</span>'
                + (c.mic ? ' MIC ' + esc(c.mic) : '')
                + (c.method ? ' · ' + esc(c.method) : '') + '</div>';
        }).join('')
        : '<div class="text-muted">ไม่พบยาผล R</div>';
    accFillFormFromConsult(accCurrentConsult);
    document.getElementById('accConsultMsg').className = 'alert mt-3 mb-0 py-2 small d-none';
    if (!accConsultModal) accConsultModal = new bootstrap.Modal(document.getElementById('accConsultModal'));
    accConsultModal.show();
}

function accPharmacistName() {
    const sel = document.getElementById('accPharmacist');
    const opt = sel.options[sel.selectedIndex];
    return opt ? opt.textContent.replace(/\s*\([^)]*\)\s*$/, '').trim() : '';
}

function accPost(action) {
    const payload = accBuildPayload();
    const body = new URLSearchParams();
    body.append('action', action);
    body.append('payload_json', JSON.stringify(payload));
    body.append('pharmacist_user_id', document.getElementById('accPharmacist').value || '');
    body.append('pharmacist_name', accPharmacistName());
    body.append('consult_note', document.getElementById('accConsultNote').value);
    body.append('doctor_reply', document.getElementById('accDoctorReply').value);
    body.append('reply_wait_days', document.getElementById('accReplyWait').value || '0');
    return fetch(ACC_API, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString()
    }).then(function (r) { return r.json(); });
}

function accOpenPrint(url) {
    if (!url) return;
    window.open(url + (url.indexOf('?') >= 0 ? '&' : '?') + 'autoprint=1', '_blank');
}

async function accOpenHistory() {
    const hn = currentHn || ((lastDetail && lastDetail.header && lastDetail.header.hn) || '');
    if (!hn && !activeOrder) {
        alert('กรุณาเลือกผล Sensitivity ก่อน');
        return;
    }
    const q = new URLSearchParams({
        action: 'history',
        hn: hn,
        order: activeOrder,
        all_hn: '1',
        limit: '100'
    });
    document.getElementById('accHistoryInfo').textContent = 'กำลังโหลดประวัติ HN ' + hn + ' ...';
    if (!accHistoryModal) accHistoryModal = new bootstrap.Modal(document.getElementById('accHistoryModal'));
    accHistoryModal.show();
    try {
        const data = await fetchJson(ACC_API + '?' + q.toString());
        const consults = (data && data.consults) || [];
        const hist = (data && data.history) || [];
        document.getElementById('accHistoryInfo').textContent =
            'HN ' + hn + (activeOrder ? ' · order ' + activeOrder : '')
            + ' · ใบปรึกษา ' + consults.length + ' รายการ · บันทึก ' + hist.length + ' รายการ';
        const cBody = document.getElementById('accHistoryConsults');
        cBody.innerHTML = consults.length
            ? consults.map(function (c) {
                const same = String(c.lab_order_number) === String(activeOrder);
                return '<tr' + (same ? ' class="table-warning"' : '') + '>'
                    + '<td>' + esc(c.updated_at || c.created_at || '') + '</td>'
                    + '<td>' + esc(c.lab_order_number) + '</td>'
                    + '<td>' + esc(c.organism || '') + '</td>'
                    + '<td>' + esc(c.drug_name || '') + '</td>'
                    + '<td>' + esc(c.status_label || '') + '</td>'
                    + '<td>' + esc(c.pharmacist_name || '') + '</td>'
                    + '<td><button type="button" class="btn btn-sm btn-outline-danger acc-hist-print" data-id="'
                    + esc(c.id) + '">พิมพ์</button></td></tr>';
            }).join('')
            : '<tr><td colspan="7" class="text-center text-muted py-3">ยังไม่มีใบปรึกษา</td></tr>';
        cBody.querySelectorAll('.acc-hist-print').forEach(function (btn) {
            btn.addEventListener('click', function () {
                window.open('amr_cdss_consult_print.php?id=' + encodeURIComponent(btn.getAttribute('data-id')), '_blank');
            });
        });
        const lBody = document.getElementById('accHistoryLog');
        lBody.innerHTML = hist.length
            ? hist.map(function (r) {
                const st = (r.status_before_label || r.status_before || '')
                    + ((r.status_after_label || r.status_after) ? ' → ' + (r.status_after_label || r.status_after) : '');
                const note = [r.note_text, r.doctor_reply].filter(Boolean).join(' / ');
                return '<tr>'
                    + '<td>' + esc(r.created_at || '') + '</td>'
                    + '<td>' + esc(r.lab_order_number || '') + '</td>'
                    + '<td>' + esc(r.action_label || r.action_key || '') + '</td>'
                    + '<td>' + esc(st) + '</td>'
                    + '<td>' + esc(r.actor_name || r.pharmacist_name || '') + '</td>'
                    + '<td>' + esc(note) + '</td></tr>';
            }).join('')
            : '<tr><td colspan="6" class="text-center text-muted py-3">ยังไม่มีบันทึก</td></tr>';
    } catch (e) {
        document.getElementById('accHistoryInfo').textContent = e.message || String(e);
    }
}

async function loadDetail(order) {
    if (!order) return;
    activeOrder = order;
    document.querySelectorAll('#sensListBody tr[data-order]').forEach(tr => {
        tr.classList.toggle('is-active', tr.getAttribute('data-order') === order);
    });
    setStatus('กำลังโหลด order ' + order + '...');
    try {
        const data = await fetchJson(SENS_API + '?action=detail&order=' + encodeURIComponent(order));
        if (data.status !== 'success') throw new Error(data.message || 'โหลดผลไม่สำเร็จ');
        setSourceLabel(data.source, data.source_label);
        renderTables(data);
        await accRefreshConsult();
        const h = data.header || {};
        setStatus((h.ptname || '') + (h.result ? ' · ' + h.result : '') + ' · order ' + order);
        if (history.replaceState) {
            history.replaceState(null, '', 'amr_sensitivity.php?order=' + encodeURIComponent(order));
        }
    } catch (e) {
        setStatus(e.message || String(e), true);
        document.getElementById('sensRtf').textContent = e.message || 'โหลดผลไม่สำเร็จ';
    }
}

document.getElementById('accBtnHistory').addEventListener('click', accOpenHistory);
document.getElementById('accBtnStart').addEventListener('click', function () {
    accPost('start').then(function (res) {
        if (res.status !== 'success') {
            accShowMsg(false, res.message || 'ไม่สำเร็จ');
            return;
        }
        accShowMsg(true, res.message || 'เริ่ม Consult แล้ว');
        if (res.consult) accApplyConsult(res.consult);
        accOpenPrint(res.print_url);
    }).catch(function (e) { accShowMsg(false, String(e)); });
});
document.getElementById('accBtnSave').addEventListener('click', function () {
    accPost('save_result').then(function (res) {
        accShowMsg(res.status === 'success', res.message || '');
        if (res.consult) accApplyConsult(res.consult);
    }).catch(function (e) { accShowMsg(false, String(e)); });
});
document.getElementById('accBtnClose').addEventListener('click', function () {
    if (!confirm('ปิดการ Consult รายการนี้?')) return;
    accPost('close').then(function (res) {
        accShowMsg(res.status === 'success', res.message || '');
        if (res.consult) accApplyConsult(res.consult);
    }).catch(function (e) { accShowMsg(false, String(e)); });
});
document.getElementById('accBtnReset').addEventListener('click', function () {
    accPost('reset_waiting').then(function (res) {
        accShowMsg(res.status === 'success', res.message || '');
        if (res.consult) accApplyConsult(res.consult);
    }).catch(function (e) { accShowMsg(false, String(e)); });
});

document.getElementById('sensForm').addEventListener('submit', function (e) {
    e.preventDefault();
    searchList();
});

document.getElementById('sensLabCode').addEventListener('change', async function () {
    const code = this.value || 'egfr';
    if (!currentHn) return;
    try {
        const data = await fetchJson(SENS_API + '?action=lab_history&hn=' + encodeURIComponent(currentHn)
            + '&lab_code=' + encodeURIComponent(code));
        if (data.status !== 'success') throw new Error(data.message || 'โหลด lab ไม่สำเร็จ');
        renderKidney(data.rows || [], data.lab_code || code);
    } catch (e) {
        document.getElementById('sensKidney').innerHTML = emptyRow(3, e.message || 'โหลด lab ไม่สำเร็จ');
        drawLabChart([]);
    }
});

document.getElementById('sensAtbFilter').addEventListener('change', function () {
    atbFilter = this.value || 'current';
    renderAtb();
});

function renderAtbSettings(rows, usingCustom) {
    const body = document.getElementById('sensAtbSetBody');
    const hint = document.getElementById('sensAtbSetHint');
    hint.textContent = usingCustom
        ? 'ใช้รายการที่ตั้งค่าไว้ ' + (rows || []).length + ' รายการ'
        : 'ยังไม่มีรายการตั้งค่า — กำลังใช้ยาที่ติ๊ก Antibiotic ใน HOSxP';
    if (!(rows || []).length) {
        body.innerHTML = emptyRow(5, 'ยังไม่มีรายการ — ค้นหาเพื่อเพิ่ม หรือดึงยาที่ติ๊ก Antibiotic');
        return;
    }
    body.innerHTML = rows.map(function (r) {
        return '<tr class="no-pointer"><td class="fw-bold">' + esc(r.drug_name) + '</td><td>'
            + esc(r.generic_name) + '</td><td>' + esc(r.icode) + '</td><td>'
            + esc(r.dosageform) + '</td><td><button type="button" class="btn btn-sm btn-outline-danger" data-atb-del="'
            + esc(r.id) + '">ลบ</button></td></tr>';
    }).join('');
    body.querySelectorAll('[data-atb-del]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (!confirm('ลบยานี้ออกจากรายการ?')) return;
            fetchJson(SENS_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'atb_drug_delete', id: btn.getAttribute('data-atb-del') })
            }).then(function (data) {
                if (data.status !== 'success') throw new Error(data.message || 'ลบไม่สำเร็จ');
                renderAtbSettings(data.rows || [], !!data.using_custom);
            }).catch(function (e) { alert(e.message || String(e)); });
        });
    });
}

async function loadAtbSettings() {
    const data = await fetchJson(SENS_API + '?action=atb_drugs');
    if (data.status !== 'success') throw new Error(data.message || 'โหลดรายการยาไม่สำเร็จ');
    renderAtbSettings(data.rows || [], !!data.using_custom);
}

document.getElementById('btnAtbSettings').addEventListener('click', function () {
    const box = document.getElementById('sensAtbSettings');
    const show = box.style.display === 'none';
    box.style.display = show ? '' : 'none';
    if (show) {
        loadAtbSettings().catch(function (e) {
            document.getElementById('sensAtbSetBody').innerHTML = emptyRow(5, e.message || 'โหลดไม่สำเร็จ');
        });
    }
});

let atbSearchTimer = null;
document.getElementById('sensAtbSearch').addEventListener('input', function () {
    const q = this.value.trim();
    const hits = document.getElementById('sensAtbSearchHits');
    clearTimeout(atbSearchTimer);
    if (q.length < 2) {
        hits.style.display = 'none';
        hits.innerHTML = '';
        return;
    }
    atbSearchTimer = setTimeout(async function () {
        try {
            const data = await fetchJson('fetch_hosxp_drugs_select_api.php?q=' + encodeURIComponent(q));
            const rows = data.results || [];
            if (!rows.length) {
                hits.innerHTML = '<div class="px-2 py-2 text-muted small">ไม่พบยา</div>';
                hits.style.display = '';
                return;
            }
            hits.innerHTML = rows.map(function (r) {
                return '<button type="button" data-drug-id="' + esc(r.id) + '">' + esc(r.text) + '</button>';
            }).join('');
            hits.style.display = '';
            hits.querySelectorAll('[data-drug-id]').forEach(function (btn) {
                btn.addEventListener('click', async function () {
                    try {
                        const data = await fetchJson(SENS_API, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'atb_drug_add', drug: btn.getAttribute('data-drug-id') })
                        });
                        if (data.status !== 'success') throw new Error(data.message || 'เพิ่มไม่สำเร็จ');
                        document.getElementById('sensAtbSearch').value = '';
                        hits.style.display = 'none';
                        renderAtbSettings(data.rows || [], !!data.using_custom);
                    } catch (e) {
                        alert(e.message || String(e));
                    }
                });
            });
        } catch (e) {
            hits.innerHTML = '<div class="px-2 py-2 text-danger small">' + esc(e.message || 'ค้นหาไม่สำเร็จ') + '</div>';
            hits.style.display = '';
        }
    }, 250);
});

document.getElementById('btnAtbImportFlag').addEventListener('click', async function () {
    if (!confirm('นำเข้ายาที่ติ๊ก Antibiotic จาก HOSxP เข้าสู่รายการตั้งค่า?')) return;
    this.disabled = true;
    try {
        const data = await fetchJson(SENS_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'atb_drug_import_flag' })
        });
        if (data.status !== 'success') throw new Error(data.message || 'นำเข้าไม่สำเร็จ');
        renderAtbSettings(data.rows || [], !!data.using_custom);
        alert(data.message || 'นำเข้าเรียบร้อย');
    } catch (e) {
        alert(e.message || String(e));
    } finally {
        this.disabled = false;
    }
});

let recRankState = { aware: [], class: [] };
let drugLevelState = [];
const AWARE_LEVELS = [
    { value: 'Access', label: 'Access — ใช้ก่อน' },
    { value: 'Watch', label: 'Watch — ใช้เมื่อจำเป็น' },
    { value: 'Reserve', label: 'Reserve — สงวนไว้' },
    { value: 'Unclassified', label: 'ยังไม่จัดระดับ รพ.' }
];

function awarePills(who, hosp) {
    who = who || '';
    hosp = hosp || '';
    let html = '';
    if (who) html += '<span class="aware-pill who" title="AWaRe ตามมาตรฐาน WHO 2023">WHO ' + esc(who) + '</span>';
    if (hosp) {
        const diff = who && hosp !== who;
        html += '<span class="aware-pill hosp' + (diff ? ' diff' : '') + '" title="ระดับโรงพยาบาลสำหรับ Escalate / De-escalate">รพ. ' + esc(hosp) + '</span>';
    }
    return html;
}

function renderRankKind(kind) {
    const host = document.getElementById(kind === 'class' ? 'sensRankClass' : 'sensRankAware');
    const rows = recRankState[kind] || [];
    host.innerHTML = rows.map(function (r, i) {
        return '<div class="rank-row">'
            + '<span class="rank-num">' + (i + 1) + '</span>'
            + '<span class="rank-label">' + esc(r.label || r.item_key) + '</span>'
            + '<div class="rank-btns">'
            + '<button type="button" data-rank-kind="' + kind + '" data-rank-i="' + i + '" data-rank-dir="-1"'
            + (i === 0 ? ' disabled' : '') + '><i class="fas fa-chevron-up"></i></button>'
            + '<button type="button" data-rank-kind="' + kind + '" data-rank-i="' + i + '" data-rank-dir="1"'
            + (i === rows.length - 1 ? ' disabled' : '') + '><i class="fas fa-chevron-down"></i></button>'
            + '</div></div>';
    }).join('');
    host.querySelectorAll('[data-rank-kind]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const k = btn.getAttribute('data-rank-kind');
            const i = parseInt(btn.getAttribute('data-rank-i'), 10);
            const dir = parseInt(btn.getAttribute('data-rank-dir'), 10);
            const list = recRankState[k] || [];
            const j = i + dir;
            if (j < 0 || j >= list.length) return;
            const tmp = list[i];
            list[i] = list[j];
            list[j] = tmp;
            renderRankKind(k);
        });
    });
}

function applyRecRanks(ranks) {
    recRankState = {
        aware: (ranks && ranks.aware) || [],
        class: (ranks && ranks.class) || []
    };
    renderRankKind('aware');
    renderRankKind('class');
}

function renderDrugLevels() {
    const host = document.getElementById('sensDrugLevelBody');
    if (!host) return;
    const q = ((document.getElementById('sensDrugLevelQ') || {}).value || '').trim().toUpperCase();
    const rows = (drugLevelState || []).filter(function (r) {
        if (!q) return true;
        const hay = ((r.drug_key || '') + ' ' + (r.label || '') + ' ' + (r.class || '') + ' ' + (r.aware || '') + ' ' + (r.who_aware || '')).toUpperCase();
        return hay.indexOf(q) !== -1;
    });
    if (!rows.length) {
        host.innerHTML = '<tr><td colspan="4" class="sens-empty">'
            + (drugLevelState.length ? 'ไม่พบยาตามคำค้น' : 'ยังไม่มีรายการยา')
            + '</td></tr>';
        return;
    }
    host.innerHTML = rows.map(function (r) {
        const key = r.drug_key || '';
        const who = r.who_aware || 'Unclassified';
        const hosp = r.aware || 'Unclassified';
        const diff = who !== hosp;
        const opts = AWARE_LEVELS.map(function (o) {
            return '<option value="' + o.value + '"'
                + (hosp === o.value ? ' selected' : '') + '>'
                + o.label + '</option>';
        }).join('');
        return '<tr class="' + (diff ? 'is-diff' : '') + '">'
            + '<td><div class="drug-level-key">' + esc(r.label || key) + '</div></td>'
            + '<td><span class="drug-level-class">' + esc(r.class || '—') + '</span></td>'
            + '<td><span class="who-lock">WHO ' + esc(who) + '</span></td>'
            + '<td><select class="form-select form-select-sm" data-drug-level="' + esc(key) + '">'
            + opts + '</select>'
            + (diff ? '<div class="small text-muted mt-1">ต่างจาก WHO</div>' : '')
            + '</td>'
            + '</tr>';
    }).join('');
    host.querySelectorAll('[data-drug-level]').forEach(function (sel) {
        sel.addEventListener('change', function () {
            const key = sel.getAttribute('data-drug-level');
            drugLevelState.forEach(function (row) {
                if (row.drug_key === key) row.aware = sel.value;
            });
        });
    });
}

function applyDrugLevels(rows) {
    drugLevelState = Array.isArray(rows) ? rows.map(function (r) {
        return {
            drug_key: String(r.drug_key || '').toUpperCase(),
            label: r.label || r.drug_key || '',
            aware: r.aware || 'Unclassified',
            who_aware: r.who_aware || r.aware || 'Unclassified',
            class: r.class || ''
        };
    }) : [];
    renderDrugLevels();
}

function addDrugLevelRow() {
    const input = document.getElementById('sensDrugLevelAdd');
    const raw = ((input && input.value) || '').trim().toUpperCase().replace(/\s+/g, ' ');
    if (!raw) {
        alert('พิมพ์ชื่อยาตามผล AST เช่น CEFTRIAXONE');
        return;
    }
    const found = drugLevelState.filter(function (r) { return r.drug_key === raw; })[0];
    if (found) {
        document.getElementById('sensDrugLevelQ').value = raw;
        renderDrugLevels();
        input.value = '';
        return;
    }
    drugLevelState.unshift({
        drug_key: raw,
        label: raw,
        aware: 'Unclassified',
        who_aware: 'Unclassified',
        class: 'Others'
    });
    document.getElementById('sensDrugLevelQ').value = raw;
    if (input) input.value = '';
    renderDrugLevels();
}

async function loadRecRanks() {
    const data = await fetchJson(SENS_API + '?action=rec_rank');
    if (data.status !== 'success') throw new Error(data.message || 'โหลดลำดับไม่สำเร็จ');
    applyRecRanks(data.ranks || {});
    applyDrugLevels(data.drug_levels || []);
    applyStewardMode((data.steward && data.steward.mode) || 'both');
    document.getElementById('sensRankHint').textContent = 'ปรับลำดับ/ระดับยา แล้วกดบันทึก — มีผลกับยาที่แนะนำทันที';
}

function currentStewardMode() {
    const el = document.querySelector('input[name="sensStewardMode"]:checked');
    return (el && el.value) || 'both';
}

function applyStewardMode(mode) {
    const want = mode === 'escalate' || mode === 'deescalate' ? mode : 'both';
    document.querySelectorAll('input[name="sensStewardMode"]').forEach(function (el) {
        el.checked = el.value === want;
        if (el.closest('.steward-opt')) el.closest('.steward-opt').classList.toggle('is-on', el.checked);
    });
}

document.getElementById('btnRecRank').addEventListener('click', function () {
    const box = document.getElementById('sensRecRank');
    const show = box.style.display === 'none';
    box.style.display = show ? '' : 'none';
    if (show) {
        loadRecRanks().catch(function (e) {
            document.getElementById('sensRankHint').textContent = e.message || 'โหลดไม่สำเร็จ';
        });
    }
});

document.getElementById('btnRecRankSave').addEventListener('click', async function () {
    this.disabled = true;
    try {
        const data = await fetchJson(SENS_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'rec_rank_save',
                aware: recRankState.aware.map(function (r) { return r.item_key; }),
                class: recRankState.class.map(function (r) { return r.item_key; }),
                steward_mode: currentStewardMode(),
                drug_levels: drugLevelState
            })
        });
        if (data.status !== 'success') throw new Error(data.message || 'บันทึกไม่สำเร็จ');
        applyRecRanks(data.ranks || recRankState);
        applyDrugLevels(data.drug_levels || drugLevelState);
        applyStewardMode((data.steward && data.steward.mode) || currentStewardMode());
        document.getElementById('sensRankHint').textContent = data.message || 'บันทึกแล้ว';
        if (activeOrder) await loadDetail(activeOrder);
    } catch (e) {
        alert(e.message || String(e));
    } finally {
        this.disabled = false;
    }
});

document.querySelectorAll('input[name="sensStewardMode"]').forEach(function (el) {
    el.addEventListener('change', function () {
        applyStewardMode(currentStewardMode());
    });
});

document.getElementById('btnRecRankReset').addEventListener('click', async function () {
    if (!confirm('คืนลำดับเริ่มต้น Access → Watch → Reserve และ Carbapenems ท้ายสุด?')) return;
    this.disabled = true;
    try {
        const data = await fetchJson(SENS_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'rec_rank_reset' })
        });
        if (data.status !== 'success') throw new Error(data.message || 'คืนค่าไม่สำเร็จ');
        applyRecRanks(data.ranks || {});
        applyDrugLevels(data.drug_levels || drugLevelState);
        applyStewardMode((data.steward && data.steward.mode) || currentStewardMode());
        document.getElementById('sensRankHint').textContent = data.message || 'คืนค่าแล้ว';
        if (activeOrder) await loadDetail(activeOrder);
    } catch (e) {
        alert(e.message || String(e));
    } finally {
        this.disabled = false;
    }
});

document.getElementById('sensDrugLevelQ').addEventListener('input', renderDrugLevels);
document.getElementById('btnDrugLevelAdd').addEventListener('click', addDrugLevelRow);
document.getElementById('sensDrugLevelAdd').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        addDrugLevelRow();
    }
});

document.getElementById('btnDrugLevelReset').addEventListener('click', async function () {
    if (!confirm('คืนระดับ รพ. ทุกรายการให้ตรงกับ AWaRe ของ WHO?\nค่าที่โรงพยาบาลตั้งเอง (เช่น Ceftazidime = Access) จะถูกล้าง')) return;
    this.disabled = true;
    try {
        const data = await fetchJson(SENS_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'drug_level_reset' })
        });
        if (data.status !== 'success') throw new Error(data.message || 'คืนค่าไม่สำเร็จ');
        applyDrugLevels(data.drug_levels || []);
        document.getElementById('sensRankHint').textContent = data.message || 'คืนค่าระดับยาแล้ว';
        if (activeOrder) await loadDetail(activeOrder);
    } catch (e) {
        alert(e.message || String(e));
    } finally {
        this.disabled = false;
    }
});

if (autoOrder || document.getElementById('sensQ').value.trim()) {
    const want = autoOrder;
    searchList().then(rows => {
        if (want && !(rows || []).some(r => String(r.lab_order_number) === want)) {
            loadDetail(want);
        } else if (!want && autoOpenFirst && rows && rows.length) {
            loadDetail(String(rows[0].lab_order_number));
        }
    });
} else {
    searchList();
}
</script>
</body>
</html>
