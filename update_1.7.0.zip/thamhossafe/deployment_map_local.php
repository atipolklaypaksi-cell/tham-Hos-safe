<?php
/**
 * Override เฉพาะเซิร์ฟเวอร์กลาง — ไฟล์นี้ไม่แจกจ่าย / ไม่ขึ้น GitHub
 * ต้องโหลดก่อน deployment_map_config.php
 */
if (!defined('THAM_DEPLOYMENT_MAP_URL')) {
    define('THAM_DEPLOYMENT_MAP_URL', 'http://61.7.167.197/thamhossafe/map_dashboard.php');
}
if (!defined('THAM_LICENSE_ADMIN_ENABLED')) {
    define('THAM_LICENSE_ADMIN_ENABLED', true);
}
