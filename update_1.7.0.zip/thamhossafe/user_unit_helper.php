<?php
/**
 * หน่วยงานของผู้ใช้ (หอผู้ป่วย) — บังคับระบุเมื่อเป็นพยาบาล/ผู้ช่วย/นักวิชาการสาธารณสุข
 */

function tham_user_ensure_unit_schema($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $cq = @mysqli_query($con, "SHOW COLUMNS FROM users LIKE 'unit_ward'");
    if (!$cq || mysqli_num_rows($cq) === 0) {
        @mysqli_query($con, "ALTER TABLE users ADD COLUMN unit_ward VARCHAR(120) NULL DEFAULT NULL AFTER entryposition");
    }
    $cq2 = @mysqli_query($con, "SHOW COLUMNS FROM users LIKE 'dispense_room'");
    if (!$cq2 || mysqli_num_rows($cq2) === 0) {
        @mysqli_query($con, "ALTER TABLE users ADD COLUMN dispense_room VARCHAR(10) NULL DEFAULT NULL AFTER unit_ward");
    }
    $ready = true;
    return true;
}

function tham_user_pos_lower($s) {
    $s = trim((string)$s);
    if ($s === '') {
        return '';
    }
    return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
}

function tham_user_pos_has($haystack, $needle) {
    if ($haystack === '' || $needle === '') {
        return false;
    }
    if (function_exists('mb_strpos')) {
        return mb_strpos($haystack, $needle) !== false;
    }
    return strpos($haystack, $needle) !== false;
}

function tham_user_norm_position($s) {
    if (function_exists('tham_opduser_norm_position')) {
        return tham_opduser_norm_position($s);
    }
    $s = str_replace(["\r", "\n", "\0"], '', (string)$s);
    $s = trim($s);
    $s = preg_replace('/[ \t\xA0]+/u', ' ', $s);
    return trim((string)$s);
}

function tham_user_requires_unit($role = null, $entryposition = null) {
    $role = $role !== null ? trim((string)$role) : (string)($_SESSION['role'] ?? '');
    if (in_array($role, ['admin', 'pharmacist', 'doctor', 'pharmacy_technician'], true)) {
        return false;
    }
    if ($role === 'nurse') {
        return true;
    }
    $pos = $entryposition !== null
        ? (string)$entryposition
        : (string)($_SESSION['entryposition'] ?? '');
    $pos = tham_user_norm_position($pos);
    $low = tham_user_pos_lower($pos);
    if ($low === '') {
        return false;
    }
    $needles = [
        'ผู้ช่วยพยาบาล',
        'ผู้ช่วยเหลือคนไข้',
        'พนักงานช่วยการพยาบาล',
        'พนักงานช่วยเหลือคนไข้',
        'พยาบาล',
        'นักวิชาการสาธารณสุข',
        'นักวิชาการสาธารณะสุข',
    ];
    foreach ($needles as $n) {
        if (tham_user_pos_has($low, tham_user_pos_lower($n))) {
            return true;
        }
    }
    return false;
}

function tham_user_list_wards($con) {
    $names = [];
    if (!function_exists('af_list_wards') && is_file(__DIR__ . '/allergy_followup_helper.php')) {
        require_once __DIR__ . '/allergy_followup_helper.php';
    }
    if (function_exists('af_list_wards')) {
        $from = af_list_wards($con);
        if (is_array($from)) {
            $names = array_merge($names, $from);
        }
    } elseif (function_exists('af_default_wards')) {
        $names = array_merge($names, af_default_wards());
    }
    foreach (tham_user_load_extra_wards($con) as $w) {
        $names[] = $w;
    }
    if ($con) {
        $q = @mysqli_query($con, "SELECT DISTINCT TRIM(unit_ward) AS w FROM users
            WHERE unit_ward IS NOT NULL AND TRIM(unit_ward) <> ''");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $names[] = trim((string)($r['w'] ?? ''));
            }
        }
    }
    return tham_user_merge_ward_names($names);
}

function tham_user_load_extra_wards($con) {
    if (!$con) {
        return [];
    }
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='tham_extra_wards' LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    $raw = trim((string)($row['config_value'] ?? ''));
    if ($raw === '') {
        return [];
    }
    $arr = json_decode($raw, true);
    if (!is_array($arr)) {
        return [];
    }
    $out = [];
    foreach ($arr as $w) {
        $w = trim((string)$w);
        if ($w !== '') {
            $out[] = $w;
        }
    }
    return $out;
}

function tham_user_add_extra_ward($con, $name) {
    $name = trim(preg_replace('/\s+/', ' ', (string)$name));
    if ($name === '' || !$con) {
        return false;
    }
    $list = tham_user_load_extra_wards($con);
    $key = tham_user_ward_norm_key($name);
    foreach ($list as $w) {
        if (tham_user_ward_norm_key($w) === $key) {
            return true;
        }
    }
    $list[] = $name;
    $json = json_encode(array_values($list), JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return false;
    }
    $esc = mysqli_real_escape_string($con, $json);
    $chk = @mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='tham_extra_wards' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$esc' WHERE config_name='tham_extra_wards'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('tham_extra_wards', '$esc')");
}

function tham_user_merge_ward_names(array $names) {
    $by_key = [];
    foreach ($names as $n) {
        $n = trim((string)$n);
        if ($n === '') {
            continue;
        }
        $key = tham_user_ward_norm_key($n);
        if ($key === '') {
            $key = tham_user_pos_lower($n);
        }
        if (!isset($by_key[$key])) {
            $by_key[$key] = $n;
            continue;
        }
        $old = $by_key[$key];
        $old_has = tham_user_pos_has(tham_user_pos_lower($old), 'หอผู้ป่วย');
        $new_has = tham_user_pos_has(tham_user_pos_lower($n), 'หอผู้ป่วย');
        $old_len = function_exists('mb_strlen') ? mb_strlen($old, 'UTF-8') : strlen($old);
        $new_len = function_exists('mb_strlen') ? mb_strlen($n, 'UTF-8') : strlen($n);
        if ($new_has && !$old_has) {
            $by_key[$key] = $n;
        } elseif ($new_len > $old_len && !($old_has && !$new_has)) {
            $by_key[$key] = $n;
        }
    }
    $out = array_values($by_key);
    natcasesort($out);
    return array_values($out);
}

function tham_user_ward_norm_key($s) {
    $s = trim((string)$s);
    if ($s === '') {
        return '';
    }
    $s = tham_user_pos_lower($s);
    $s = preg_replace('/[\s\-_.,\/\\\\()]+/u', '', $s);
    $s = preg_replace('/^(หอผู้ป่วยใน|หอผู้ป่วย|หอ)/u', '', $s);
    return (string)$s;
}

function tham_user_ward_similarity($a, $b) {
    $akey = tham_user_ward_norm_key($a);
    $bkey = tham_user_ward_norm_key($b);
    if ($akey === '' || $bkey === '') {
        return 0.0;
    }
    if ($akey === $bkey) {
        return 100.0;
    }
    $alen = function_exists('mb_strlen') ? mb_strlen($akey, 'UTF-8') : strlen($akey);
    $blen = function_exists('mb_strlen') ? mb_strlen($bkey, 'UTF-8') : strlen($bkey);
    $has = function_exists('mb_strpos')
        ? (mb_strpos($bkey, $akey) !== false || mb_strpos($akey, $bkey) !== false)
        : (strpos($bkey, $akey) !== false || strpos($akey, $bkey) !== false);
    if ($has) {
        $shorter = min($alen, $blen);
        $longer = max(1, max($alen, $blen));
        return 80.0 + (20.0 * ($shorter / $longer));
    }
    similar_text($akey, $bkey, $pct);
    return (float)$pct;
}

function tham_user_similar_wards($typed, array $wards, $min_score = 60.0) {
    $typed = trim((string)$typed);
    $out = [];
    if ($typed === '') {
        return $out;
    }
    $tkey = tham_user_ward_norm_key($typed);
    foreach ($wards as $w) {
        $w = trim((string)$w);
        if ($w === '') {
            continue;
        }
        $score = tham_user_ward_similarity($typed, $w);
        $wkey = tham_user_ward_norm_key($w);
        $contain = ($tkey !== '' && $wkey !== '' && (
            (function_exists('mb_strpos') ? mb_strpos($wkey, $tkey) !== false : strpos($wkey, $tkey) !== false)
            || (function_exists('mb_strpos') ? mb_strpos($tkey, $wkey) !== false : strpos($tkey, $wkey) !== false)
        ));
        if (!$contain && $score < 75.0) {
            continue;
        }
        if ($score < $min_score) {
            continue;
        }
        if ($tkey !== '' && $tkey === tham_user_ward_norm_key($w)) {
            continue;
        }
        $out[] = ['name' => $w, 'score' => $score];
    }
    usort($out, function ($a, $b) {
        if ($a['score'] === $b['score']) {
            return strcmp($a['name'], $b['name']);
        }
        return ($a['score'] > $b['score']) ? -1 : 1;
    });
    return $out;
}

function tham_user_match_ward($typed, array $wards) {
    $typed = trim((string)$typed);
    if ($typed === '' || !$wards) {
        return '';
    }
    $tkey = tham_user_ward_norm_key($typed);
    $tlow = tham_user_pos_lower($typed);
    $best = '';
    $best_score = 0.0;
    foreach ($wards as $w) {
        $w = trim((string)$w);
        if ($w === '') {
            continue;
        }
        $wlow = tham_user_pos_lower($w);
        $wkey = tham_user_ward_norm_key($w);
        if ($tlow === $wlow || ($tkey !== '' && $tkey === $wkey)) {
            return $w;
        }
        $score = tham_user_ward_similarity($typed, $w);
        if ($score > $best_score) {
            $best_score = $score;
            $best = $w;
        }
    }
    return $best_score >= 55.0 ? $best : '';
}

function tham_user_load_unit_session($con, $user_id = 0) {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return;
    }
    $user_id = $user_id > 0 ? (int)$user_id : (int)($_SESSION['user_id'] ?? 0);
    if ($user_id <= 0) {
        return;
    }
    tham_user_ensure_unit_schema($con);
    $q = mysqli_query($con, "SELECT role, entryposition, unit_ward, dispense_room FROM users WHERE id=" . $user_id . " LIMIT 1");
    if (!$q) {
        $q = mysqli_query($con, "SELECT role, entryposition, unit_ward FROM users WHERE id=" . $user_id . " LIMIT 1");
    }
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return;
    }
    $_SESSION['role'] = (string)($row['role'] ?? ($_SESSION['role'] ?? ''));
    $_SESSION['entryposition'] = trim((string)($row['entryposition'] ?? ''));
    $_SESSION['unit_ward'] = trim((string)($row['unit_ward'] ?? ''));
    if (!isset($_SESSION['dispense_room']) || trim((string)$_SESSION['dispense_room']) === '') {
        $_SESSION['dispense_room'] = strtolower(trim((string)($row['dispense_room'] ?? '')));
    }
}

function tham_user_sees_all_wards($role = null, $entryposition = null) {
    return !tham_user_requires_unit($role, $entryposition);
}

function tham_user_scoped_ward($role = null, $entryposition = null) {
    if (tham_user_sees_all_wards($role, $entryposition)) {
        return '';
    }
    return trim((string)($_SESSION['unit_ward'] ?? ''));
}

function tham_user_must_select_unit($con = null) {
    if (session_status() !== PHP_SESSION_ACTIVE || empty($_SESSION['user_id'])) {
        return false;
    }
    if (!isset($_SESSION['unit_ward']) && $con) {
        tham_user_load_unit_session($con, (int)$_SESSION['user_id']);
    }
    $unit = trim((string)($_SESSION['unit_ward'] ?? ''));
    return tham_user_requires_unit() && $unit === '';
}

function tham_user_set_unit($con, $user_id, $ward, $allow_new = false) {
    tham_user_ensure_unit_schema($con);
    $user_id = (int)$user_id;
    $ward = trim(preg_replace('/\s+/', ' ', (string)$ward));
    if ($user_id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบผู้ใช้'];
    }
    if ($ward === '' || $ward === '__new__') {
        return ['ok' => false, 'error' => 'กรุณาเลือกหน่วยงาน'];
    }
    $wards = tham_user_list_wards($con);
    $in_list = false;
    foreach ($wards as $w) {
        if (trim((string)$w) === $ward) {
            $in_list = true;
            break;
        }
    }
    $matched = $wards ? tham_user_match_ward($ward, $wards) : '';
    $exact_key = ($matched !== '' && tham_user_ward_norm_key($matched) === tham_user_ward_norm_key($ward));
    if ($in_list) {
        // keep posted official name
    } elseif ($exact_key) {
        $ward = $matched;
    } elseif (!$allow_new && $matched !== '') {
        $ward = $matched;
    } elseif (!$allow_new && !$in_list) {
        return ['ok' => false, 'error' => 'กรุณาเลือกหอผู้ป่วยจากรายการ หรือเพิ่มชื่อใหม่'];
    }
    if (function_exists('mb_strlen') ? mb_strlen($ward, 'UTF-8') > 120 : strlen($ward) > 120) {
        return ['ok' => false, 'error' => 'ชื่อหน่วยงานยาวเกินไป'];
    }
    if ($allow_new && !$in_list && !$exact_key) {
        tham_user_add_extra_ward($con, $ward);
    }
    $esc = mysqli_real_escape_string($con, $ward);
    $ok = mysqli_query($con, "UPDATE users SET unit_ward='$esc' WHERE id=$user_id");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ'];
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION['unit_ward'] = $ward;
    }
    return ['ok' => true, 'unit_ward' => $ward];
}

function tham_user_unit_skip_page($page) {
    $page = strtolower((string)$page);
    $skip = [
        'login.php', 'logout.php', 'oauth_callback.php', 'select_unit.php', 'select_dispense.php',
        'index.php', 'check_license.php',
    ];
    if (in_array($page, $skip, true)) {
        return true;
    }
    if (substr($page, -8) === '_api.php') {
        return true;
    }
    foreach (['fetch_', 'save_', 'export_', 'action_', 'delete_'] as $p) {
        if (strpos($page, $p) === 0) {
            return true;
        }
    }
    return false;
}

function tham_user_unit_gate($con) {
    if (php_sapi_name() === 'cli') {
        return;
    }
    if (session_status() !== PHP_SESSION_ACTIVE || empty($_SESSION['user_id'])) {
        return;
    }
    if (headers_sent()) {
        return;
    }
    $page = basename((string)($_SERVER['PHP_SELF'] ?? ''));
    if (tham_user_unit_skip_page($page)) {
        return;
    }
    tham_user_load_unit_session($con, (int)$_SESSION['user_id']);
    if (tham_user_must_select_unit($con)) {
        header('Location: select_unit.php');
        exit;
    }
    if (is_file(__DIR__ . '/smart_pharma_backup_helper.php')) {
        require_once __DIR__ . '/smart_pharma_backup_helper.php';
        sp_backup_gate($con);
    }
}

function tham_user_normalize_stored_unit($con, $user_id = 0) {
    if (!$con) {
        return;
    }
    $user_id = $user_id > 0 ? (int)$user_id : (int)($_SESSION['user_id'] ?? 0);
    $current = trim((string)($_SESSION['unit_ward'] ?? ''));
    if ($user_id <= 0 || $current === '') {
        return;
    }
    $wards = tham_user_list_wards($con);
    if (!$wards) {
        return;
    }
    foreach ($wards as $w) {
        if (trim((string)$w) === $current) {
            return;
        }
    }
    $matched = tham_user_match_ward($current, $wards);
    if ($matched !== '' && $matched !== $current) {
        tham_user_set_unit($con, $user_id, $matched);
    }
}

/**
 * อนุญาตเฉพาะ path ในแอป เช่น smart_drug.php?hn=xxx (กัน open redirect)
 */
function tham_sanitize_return_url($url) {
    $url = trim((string)$url);
    if ($url === '') {
        return '';
    }
    if (preg_match('#^(https?:)?//#i', $url) || strpos($url, "\n") !== false || strpos($url, "\r") !== false) {
        return '';
    }
    if (strpos($url, '..') !== false) {
        return '';
    }
    $url = ltrim($url, '/');
    if (!preg_match('#^[A-Za-z0-9_\-./]+\.php(?:\?[A-Za-z0-9_\-=&%.+]*)?$#', $url)) {
        return '';
    }
    return $url;
}

function tham_login_return_url_set($url) {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        @session_start();
    }
    $safe = tham_sanitize_return_url($url);
    if ($safe !== '') {
        $_SESSION['login_return_url'] = $safe;
    } else {
        unset($_SESSION['login_return_url']);
    }
    return $safe;
}

function tham_login_return_url_peek() {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return '';
    }
    return tham_sanitize_return_url($_SESSION['login_return_url'] ?? '');
}

function tham_login_return_url_consume() {
    $u = tham_login_return_url_peek();
    unset($_SESSION['login_return_url']);
    return $u;
}

function tham_user_post_login_redirect($con) {
    tham_user_load_unit_session($con, (int)($_SESSION['user_id'] ?? 0));
    // มี return URL (เช่น จาก smart_drug Drug Center) = กลับหน้าเดิมแบบ seamless ข้ามยืนยันห้องจ่าย
    $seamless = (tham_login_return_url_peek() !== '');
    if (!$seamless) {
        unset($_SESSION['dispense_room_confirmed']);
        $_SESSION['sp_bk_ui_epoch'] = time();
    }
    if (!tham_user_must_select_unit($con)) {
        tham_user_normalize_stored_unit($con, (int)($_SESSION['user_id'] ?? 0));
    }
    if (tham_user_must_select_unit($con)) {
        header('Location: select_unit.php');
        exit;
    }
    if (!$seamless && is_file(__DIR__ . '/smart_pharma_backup_helper.php')) {
        require_once __DIR__ . '/smart_pharma_backup_helper.php';
        if (sp_backup_must_confirm($con)) {
            header('Location: select_dispense.php');
            exit;
        }
    }
    $back = tham_login_return_url_consume();
    if ($back !== '') {
        header('Location: ' . $back);
        exit;
    }
    header('Location: home.php');
    exit;
}
