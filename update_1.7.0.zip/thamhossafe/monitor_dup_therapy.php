<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('hosxp_tmt_drug_helper.php');
include('monitor_dup_therapy_helper.php');
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
mysqli_set_charset($con, 'utf8');

mdt_ensure_table($con);

$default_start = date('Y-m-d', strtotime('-3 days'));
$default_end = date('Y-m-d');
$focus_date = trim((string)($_GET['date'] ?? $_GET['start'] ?? ''));
$focus_end = trim((string)($_GET['end'] ?? ''));
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $focus_date)) {
    $default_start = $focus_date;
    $default_end = preg_match('/^\d{4}-\d{2}-\d{2}$/', $focus_end) ? $focus_end : $focus_date;
}

function mdt_esc($con, $v) {
    return mysqli_real_escape_string($con, $v ?? '');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save_mdt') {
        $id = (int)($_POST['rule_id'] ?? 0);
        $group = mdt_esc($con, trim((string)($_POST['group_name'] ?? '')));
        $picks_a = mdt_parse_posted_drug_options($_POST['drugs_a'] ?? []);
        $picks_b = mdt_parse_posted_drug_options($_POST['drugs_b'] ?? []);
        $hos_save = hosxp_connect($con);
        if ($hos_save) {
            $ra = mdt_refresh_pick_names($hos_save, $picks_a);
            $rb = mdt_refresh_pick_names($hos_save, $picks_b);
            if (!empty($ra)) {
                $picks_a = $ra;
            }
            if (!empty($rb)) {
                $picks_b = $rb;
            }
            mysqli_close($hos_save);
        }
        $mode = (($_POST['match_mode'] ?? '') === 'class') ? 'class' : 'pair';
        $la = mdt_esc($con, mdt_side_label_from_picks($picks_a));
        $lb = mdt_esc($con, mdt_side_label_from_picks($picks_b));
        if ($mode === 'class' && $lb === '') {
            $lb = mdt_esc($con, 'ชนิดอื่นในกลุ่มเดียวกัน');
        }
        $pa = mdt_esc($con, mdt_encode_drug_picks($picks_a));
        $pb = mdt_esc($con, mdt_encode_drug_picks($picks_b));
        $lvl = (($_POST['alert_level'] ?? '') === 'soft') ? 'soft' : 'hard';
        $msg = mdt_esc($con, trim((string)($_POST['alert_message'] ?? '')));
        $det = mdt_esc($con, trim((string)($_POST['detail_text'] ?? '')));
        $active = isset($_POST['active']) ? 1 : 0;
        $overlap = [];
        $set_a = [];
        foreach ($picks_a as $p) {
            $set_a[$p['icode']] = true;
        }
        foreach ($picks_b as $p) {
            if (isset($set_a[$p['icode']])) {
                $overlap[] = $p['icode'];
            }
        }
        $all_ic = [];
        foreach (array_merge($picks_a, $picks_b) as $p) {
            $ic = trim((string)($p['icode'] ?? ''));
            if ($ic !== '') {
                $all_ic[$ic] = true;
            }
        }
        $err = '';
        if ($mode === 'class') {
            if (count($all_ic) < 2) {
                $err = 'โหมดกลุ่มเดียวกัน กรุณาเลือกยาจากคลังอย่างน้อย 2 รายการ';
            }
        } elseif (empty($picks_a) || empty($picks_b)) {
            $err = 'กรุณาเลือกยาจากคลัง รพ. (TMT) อย่างน้อยฝั่งละ 1 รายการ';
        } elseif ($la === '' || $lb === '') {
            $err = 'ไม่พบชื่อ TMT ของยาที่เลือก — ลองค้นหาและเลือกใหม่';
        } elseif (!empty($overlap)) {
            $err = 'icode ซ้ำทั้งสองฝั่ง: ' . implode(', ', $overlap) . ' — ยาตัวเดียวกันห้ามอยู่ทั้งฝั่ง A และ B';
        }
        if ($err !== '') {
            $_SESSION['mdt_error'] = $err;
        } elseif ($id > 0) {
            $ok = mysqli_query($con, "UPDATE monitor_dup_therapy_settings SET
                group_name='$group', label_a='$la', label_b='$lb',
                picks_a='$pa', picks_b='$pb', match_mode='$mode',
                alert_level='$lvl', alert_message='$msg', detail_text='$det', active=$active
                WHERE id=$id");
            if ($ok) {
                $_SESSION['mdt_msg'] = 'บันทึกกฎเรียบร้อย — คัดกรองเฉพาะยาที่เลือกจากคลัง รพ.';
                if (function_exists('sp_monitor_settings_changed')) {
                    sp_monitor_settings_changed($con, 'dup_therapy');
                }
            } else {
                $_SESSION['mdt_error'] = 'บันทึกไม่สำเร็จ: ' . mysqli_error($con);
            }
        } else {
            $rkey = 'custom_' . substr(md5($la . '|' . $lb . '|' . microtime(true)), 0, 12);
            $rkey_esc = mdt_esc($con, $rkey);
            $ok = mysqli_query($con, "INSERT INTO monitor_dup_therapy_settings
                (rule_key, group_name, label_a, label_b, keys_a, keys_b, exclude_a, exclude_b, picks_a, picks_b, match_mode, alert_level, alert_message, detail_text, active, is_seed, sort_order)
                VALUES ('$rkey_esc', '$group', '$la', '$lb', '[]', '[]', '[]', '[]', '$pa', '$pb', '$mode', '$lvl', '$msg', '$det', $active, 0, 200)");
            if ($ok) {
                $_SESSION['mdt_msg'] = 'เพิ่มกฎคู่ยาซ้ำซ้อนเรียบร้อย';
                if (function_exists('sp_monitor_settings_changed')) {
                    sp_monitor_settings_changed($con, 'dup_therapy');
                }
            } else {
                $_SESSION['mdt_error'] = 'เพิ่มไม่สำเร็จ: ' . mysqli_error($con);
            }
        }
        header('Location: monitor_dup_therapy.php?tab=settings');
        exit;
    }
    if ($action === 'delete_mdt') {
        $id = (int)($_POST['del_id'] ?? 0);
        if ($id > 0) {
            $row = null;
            $q = mysqli_query($con, "SELECT id, rule_key, label_a, label_b, picks_a, picks_b FROM monitor_dup_therapy_settings WHERE id=$id LIMIT 1");
            if ($q) {
                $row = mysqli_fetch_assoc($q);
            }
            if ($row) {
                $row = mdt_normalize_rule_row($row);
                mysqli_query($con, "DELETE FROM monitor_dup_therapy_settings WHERE id=$id");
                if (mysqli_affected_rows($con) > 0) {
                    mdt_remember_deleted_rule_key($con, $row['rule_key'] ?? '');
                    if (function_exists('sp_monitor_settings_changed')) {
                        sp_monitor_settings_changed($con, 'dup_therapy');
                    }
                    $_SESSION['mdt_msg'] = 'ลบกฎเรียบร้อย: ' . mdt_pair_label($row);
                } else {
                    $_SESSION['mdt_error'] = 'ลบไม่สำเร็จ';
                }
            } else {
                $_SESSION['mdt_error'] = 'ไม่พบกฎที่ต้องการลบ';
            }
        }
        header('Location: monitor_dup_therapy.php?tab=settings');
        exit;
    }
    if ($action === 'save_mdt_filter') {
        $ok = mdt_save_filter_config($con, [
            'skip_ipd_off' => !empty($_POST['skip_ipd_off']),
            'skip_method_keywords' => trim((string)($_POST['skip_method_keywords'] ?? 'hold, ทันที')),
        ]);
        if ($ok) {
            $_SESSION['mdt_msg'] = 'บันทึกตัวกรองส่วนกลางเรียบร้อย — มีผลกับยาทุกกฎ (Monitor และ Smart Pharma)';
            if (function_exists('sp_monitor_settings_changed')) {
                sp_monitor_settings_changed($con, 'dup_therapy');
            }
        } else {
            $_SESSION['mdt_error'] = 'บันทึกตัวกรองไม่สำเร็จ';
        }
        header('Location: monitor_dup_therapy.php?tab=settings');
        exit;
    }
}

$all_rules = mdt_load_rules($con, false);
$mdt_filter = mdt_get_filter_config($con);
$monitor_rules = [];
foreach ($all_rules as $r) {
    if (!empty($r['active'])) {
        $monitor_rules[] = $r;
    }
}

$tab = (isset($_GET['tab']) && $_GET['tab'] === 'settings') ? 'settings' : 'monitor';
$flash_msg = $_SESSION['mdt_msg'] ?? '';
$flash_err = $_SESSION['mdt_error'] ?? '';
unset($_SESSION['mdt_msg'], $_SESSION['mdt_error']);

$con_hosxp = ($tab === 'settings') ? hosxp_connect($con) : null;
foreach ($all_rules as &$mdt_rule_row) {
    $mdt_rule_row['_form_a'] = mdt_rule_form_drugs($con_hosxp, $mdt_rule_row, 'a');
    $mdt_rule_row['_form_b'] = mdt_rule_form_drugs($con_hosxp, $mdt_rule_row, 'b');
}
unset($mdt_rule_row);
if ($con_hosxp) {
    mysqli_close($con_hosxp);
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor คู่ยาซ้ำซ้อน - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/select2.min.css" rel="stylesheet">
    <link href="css/select2-bootstrap-5-theme.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .section-hard .table thead { background-color: #dc3545 !important; color: #fff !important; }
        .section-soft .table thead { background-color: #fd7e14 !important; color: #fff !important; }
        .mdt-range-btn.active { background-color: #4338ca !important; border-color: #4338ca !important; color: #fff !important; }
        .mdt-editing-row { outline: 2px solid #4338ca; }
        #mdtFormCard.edit-mode .card-header { background: #3730a3 !important; }
        #mdtFormCard .select2-container { width: 100% !important; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-3">
                <div>
                    <h4 class="fw-bold mb-1"><i class="fas fa-layer-group me-2 text-primary"></i>Monitor คู่ยาซ้ำซ้อน</h4>
                    <p class="text-muted small mb-0">ตรวจ Therapeutic Duplication ในวันเดียวกัน จากยาในคลัง รพ. ที่ผูก TMT (TPU) เช่น Paracetamol เดี่ยว + สูตรผสม — ดึงใบยาครั้งเดียวแล้วจับคู่ทุกกฎ</p>
                </div>
            </div>

            <?php if ($flash_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo htmlspecialchars($flash_msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            <?php if ($flash_err): ?>
            <div class="alert alert-danger alert-dismissible fade show"><?php echo htmlspecialchars($flash_err); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <ul class="nav nav-tabs fw-bold" role="tablist">
                <li class="nav-item">
                    <button class="nav-link <?php echo $tab === 'monitor' ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#monitor" type="button">
                        <i class="fas fa-desktop me-1"></i> รายการเฝ้าระวัง
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link <?php echo $tab === 'settings' ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#settings" type="button">
                        <i class="fas fa-cogs me-1"></i> ตั้งค่ากฎคู่ยาซ้ำซ้อน
                    </button>
                </li>
            </ul>

            <div class="tab-content bg-white border border-top-0 p-4 rounded-bottom shadow-sm">
                <div class="tab-pane fade <?php echo $tab === 'monitor' ? 'show active' : ''; ?>" id="monitor">
                    <div class="filter-box p-3 mb-3">
                        <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-filter me-2"></i>ตัวกรองรายงาน</h6>
                        <div class="row g-2 align-items-end">
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">วันที่สั่งยา ตั้งแต่</label>
                                <input type="text" id="filter_start" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_start); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ถึงวันที่</label>
                                <input type="text" id="filter_end" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_end); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">HN (ไม่บังคับ)</label>
                                <input type="text" id="filter_hn" class="form-control form-control-sm bg-white" placeholder="ทุก HN" autocomplete="off">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-sm fw-bold text-white w-100 shadow-sm" style="background:#4338ca;" id="btnFetchMDT" onclick="fetchMDTData()">
                                    <i class="fas fa-sync-alt me-1"></i> ประมวลผล
                                </button>
                            </div>
                        </div>
                        <div class="row g-2 mt-2 align-items-center">
                            <div class="col-auto"><label class="form-label small fw-bold mb-0 text-secondary">ช่วงเร็ว:</label></div>
                            <div class="col">
                                <div class="btn-group btn-group-sm flex-wrap">
                                    <button type="button" class="btn btn-outline-secondary fw-bold mdt-range-btn" data-days="1" onclick="setMDTDateRange(1)">วันนี้</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mdt-range-btn active" data-days="3" onclick="setMDTDateRange(3)">3 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mdt-range-btn" data-days="7" onclick="setMDTDateRange(7)">7 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mdt-range-btn" data-days="15" onclick="setMDTDateRange(15)">15 วัน</button>
                                </div>
                            </div>
                        </div>
                        <div class="small text-muted mt-2"><i class="fas fa-info-circle me-1"></i> ตรวจทุกกฎที่เลือกในคำสั่งเดียว — แนะนำเริ่มที่ <b>3 วัน</b> · ยาที่วิธีใช้มีคำว่า <b>hold</b> หรือ <b>ทันที</b> จะถูกตัดออก · เปิดจาก Smart Pharma จะกรองตาม HN</div>
                        <div id="hnFocusBanner" class="alert alert-warning py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                        <div id="reportMeta" class="alert alert-info py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                    </div>

                    <div class="border rounded p-3 mb-3">
                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                            <label class="form-label fw-bold small mb-0">
                                <i class="fas fa-filter me-1 text-primary"></i> เลือกคู่ยาที่ต้องการรายงาน
                            </label>
                            <div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-outline-primary fw-bold" onclick="mdtSelectAll(true)">เลือกทั้งหมด</button>
                                <button type="button" class="btn btn-outline-secondary fw-bold" onclick="mdtSelectAll(false)">ยกเลิกทั้งหมด</button>
                            </div>
                        </div>
                        <?php if (empty($monitor_rules)): ?>
                        <div class="small text-muted">ยังไม่มีกฎที่เปิดใช้งาน — ไปที่แท็บ <b>ตั้งค่ากฎ</b></div>
                        <?php else: ?>
                        <div class="row g-2">
                            <?php foreach ($monitor_rules as $mr):
                                $lvl = mdt_alert_level($mr);
                                $badge = $lvl === 'hard'
                                    ? '<span class="badge bg-danger ms-1">Hard</span>'
                                    : '<span class="badge bg-warning text-dark ms-1">Soft</span>';
                            ?>
                            <div class="col-md-6 col-xl-4">
                                <div class="form-check border rounded px-2 py-1 bg-white h-100">
                                    <input class="form-check-input mdt-rule-cb" type="checkbox" value="<?php echo (int)$mr['id']; ?>"
                                           data-label="<?php echo htmlspecialchars(mdt_pair_label($mr), ENT_QUOTES, 'UTF-8'); ?>"
                                           id="mdt_rule_cb_<?php echo (int)$mr['id']; ?>" checked>
                                    <label class="form-check-label small" for="mdt_rule_cb_<?php echo (int)$mr['id']; ?>">
                                        <span class="fw-bold text-dark"><?php echo htmlspecialchars(mdt_pair_label($mr)); ?></span>
                                        <?php echo $badge; ?>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($mr['group_name']); ?></small>
                                    </label>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="section-hard mb-4">
                        <h6 class="fw-bold text-danger mb-2"><i class="fas fa-exclamation-circle me-2"></i>Hard Alert <span id="hardCount" class="badge bg-danger">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small">
                                    <tr>
                                        <th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th>
                                        <th>วันที่สั่ง</th><th class="text-start">ยา A</th><th class="text-start">ยา B</th>
                                        <th>หอผู้ป่วย</th><th class="text-start">ข้อความแจ้งเตือน</th>
                                    </tr>
                                </thead>
                                <tbody id="hardTbody"><tr><td colspan="8" class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="section-soft mb-2">
                        <h6 class="fw-bold text-warning mb-2"><i class="fas fa-exclamation-triangle me-2"></i>Soft Alert <span id="softCount" class="badge bg-warning text-dark">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small">
                                    <tr>
                                        <th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th>
                                        <th>วันที่สั่ง</th><th class="text-start">ยา A</th><th class="text-start">ยา B</th>
                                        <th>หอผู้ป่วย</th><th class="text-start">ข้อความแจ้งเตือน</th>
                                    </tr>
                                </thead>
                                <tbody id="softTbody"><tr><td colspan="8" class="text-center py-4 text-muted">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade <?php echo $tab === 'settings' ? 'show active' : ''; ?>" id="settings">
                    <div class="alert alert-info py-2 px-3 small mb-3">
                        <i class="fas fa-info-circle me-1"></i>
                        เลือกยาจาก <b>คลัง HOSxP ที่เปิดใช้</b> เท่านั้น ชื่อที่แสดงมาจาก TMT (TPU) — พิมพ์ชื่อยา, icode หรือรหัส TMT เพื่อค้นหา
                        กฎตัวอย่างเดิมถ้ายังไม่ล็อก icode ให้กด <b>แก้</b> ตรวจรายการแล้วกดบันทึก
                    </div>
                    <div class="card shadow-sm border-0 mb-4">
                        <div class="card-header fw-bold text-white" style="background:#0f766e;">
                            <i class="fas fa-filter me-1"></i> ตัวกรองที่ใช้กับยาทั้งหมด
                        </div>
                        <div class="card-body">
                            <form method="post" class="row g-3 align-items-end">
                                <input type="hidden" name="action" value="save_mdt_filter">
                                <div class="col-md-4">
                                    <div class="form-check form-switch mt-1">
                                        <input class="form-check-input" type="checkbox" name="skip_ipd_off" id="mdt_skip_ipd_off" value="1"
                                            <?php echo !empty($mdt_filter['skip_ipd_off']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small fw-bold" for="mdt_skip_ipd_off">ตัดยา IPD ที่ Medplan off แล้ว</label>
                                    </div>
                                    <div class="form-text">ดูวันที่หยุดใน Medplan ของผู้ป่วยใน — ถ้า off แล้วไม่นำมาแจ้งซ้ำซ้อน</div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold mb-1">คำในวิธีใช้ที่ให้ตัดออก (ข้อยกเว้น)</label>
                                    <textarea name="skip_method_keywords" class="form-control form-control-sm" rows="2"
                                        placeholder="hold, ทันที"><?php echo htmlspecialchars($mdt_filter['skip_method_keywords'] ?? 'hold, ทันที'); ?></textarea>
                                    <div class="form-text">คั่นด้วยจุลภาคหรือขึ้นบรรทัดใหม่ เช่น <code>hold, ทันที</code> — ถ้าวิธีใช้มีคำเหล่านี้จะไม่นับเป็นยาซ้ำซ้อน (ทั้ง OPD และ IPD ทุกกฎ)</div>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-sm fw-bold text-white w-100" style="background:#0f766e;">
                                        <i class="fas fa-save me-1"></i> บันทึกตัวกรอง
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="row g-4">
                        <div class="col-lg-5">
                            <div class="card shadow-sm border-0" id="mdtFormCard">
                                <div class="card-header text-white fw-bold" style="background:#4338ca;">
                                    <i class="fas fa-plus-circle me-1"></i> <span id="mdtFormTitle">เพิ่ม / แก้ไขกฎคู่ยาซ้ำซ้อน</span>
                                </div>
                                <div class="card-body">
                                    <form method="post" id="mdtForm">
                                        <input type="hidden" name="action" value="save_mdt">
                                        <input type="hidden" name="rule_id" id="mdt_rule_id" value="">
                                        <div class="mb-2">
                                            <label class="form-label small fw-bold">กลุ่มยา</label>
                                            <input type="text" name="group_name" id="mdt_group" class="form-control form-control-sm" placeholder="เช่น กลุ่มยาแก้ปวดลดไข้">
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small fw-bold">ยาฝั่ง A จากคลัง รพ. (TMT)</label>
                                            <select name="drugs_a[]" id="mdt_drugs_a" class="form-select form-select-sm" multiple></select>
                                            <div id="mdt_tmt_preview_a" class="small text-secondary mt-1"></div>
                                            <div class="form-text">ค้นจากชื่อยา, icode หรือรหัส TMT (TPU) — ชื่อคู่ยาดึงจาก TMT อัตโนมัติ</div>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small fw-bold">ยาฝั่ง B จากคลัง รพ. (TMT) — ซ้ำซ้อนกับ A</label>
                                            <select name="drugs_b[]" id="mdt_drugs_b" class="form-select form-select-sm" multiple></select>
                                            <div id="mdt_tmt_preview_b" class="small text-secondary mt-1"></div>
                                            <div class="form-text">เลือกได้หลายรายการ เช่น สูตรผสม / ยาคนละชนิดในกลุ่มเดียวกัน</div>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small fw-bold">วิธีจับคู่</label>
                                            <select name="match_mode" id="mdt_match_mode" class="form-select form-select-sm">
                                                <option value="pair">ฝั่ง A กับฝั่ง B</option>
                                                <option value="class">ทุกคู่ในกลุ่มเดียวกัน (ยา ≥ 2 รายการ)</option>
                                            </select>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small fw-bold">ระดับแจ้งเตือน</label>
                                            <select name="alert_level" id="mdt_alert_level" class="form-select form-select-sm">
                                                <option value="hard">Hard Alert</option>
                                                <option value="soft">Soft Alert</option>
                                            </select>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small fw-bold">ข้อความแจ้งเตือน</label>
                                            <input type="text" name="alert_message" id="mdt_alert_message" class="form-control form-control-sm">
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small fw-bold">รายละเอียด (สาเหตุ / ความเสี่ยง)</label>
                                            <textarea name="detail_text" id="mdt_detail_text" class="form-control form-control-sm" rows="4"></textarea>
                                        </div>
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="checkbox" name="active" id="mdt_active" checked>
                                            <label class="form-check-label small" for="mdt_active">เปิดใช้งาน</label>
                                        </div>
                                        <div class="d-flex gap-2">
                                            <button type="submit" class="btn btn-sm text-white fw-bold" style="background:#4338ca;">
                                                <i class="fas fa-save me-1"></i> บันทึก
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="resetMDTForm()">ล้างฟอร์ม</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-list me-1"></i>กฎที่ตั้งไว้</h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-hover border align-middle">
                                    <thead class="table-light text-center small">
                                        <tr>
                                            <th>คู่ยา</th><th>กลุ่ม</th><th>Alert</th><th>เปิด</th><th>จัดการ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if (empty($all_rules)): ?>
                                        <tr><td colspan="5" class="text-center text-muted py-3">ยังไม่มีกฎ</td></tr>
                                    <?php else: foreach ($all_rules as $r):
                                        $n_a = count($r['picks_a'] ?? []);
                                        $n_b = count($r['picks_b'] ?? []);
                                        $is_class = mdt_match_mode($r) === 'class';
                                        $locked = $is_class ? (($n_a + $n_b) >= 2) : ($n_a > 0 && $n_b > 0);
                                        $display = $r;
                                        if (empty($display['picks_a']) && !empty($r['_form_a'])) {
                                            $display['picks_a'] = $r['_form_a'];
                                        }
                                        if (empty($display['picks_b']) && !empty($r['_form_b'])) {
                                            $display['picks_b'] = $r['_form_b'];
                                        }
                                        $rule_json = htmlspecialchars(json_encode([
                                            'id' => (int)$r['id'],
                                            'group_name' => $r['group_name'],
                                            'pair_label' => mdt_pair_label($display),
                                            'drugs_a' => $r['_form_a'] ?? [],
                                            'drugs_b' => $r['_form_b'] ?? [],
                                            'match_mode' => mdt_match_mode($r),
                                            'alert_level' => $r['alert_level'],
                                            'alert_message' => $r['alert_message'] ?? '',
                                            'detail_text' => $r['detail_text'] ?? '',
                                            'active' => (int)$r['active'],
                                            'is_seed' => (int)$r['is_seed'],
                                        ], JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
                                    ?>
                                        <tr class="mdt-rule-row" data-rule-id="<?php echo (int)$r['id']; ?>">
                                            <td class="small text-start">
                                                <b><?php echo htmlspecialchars(mdt_pair_label($display)); ?></b>
                                                <?php if (!empty($r['is_seed'])): ?><span class="badge bg-light text-dark border ms-1">ตัวอย่าง</span><?php endif; ?>
                                                <div class="text-muted" style="font-size:11px;">
                                                    <?php if ($locked): ?>
                                                        คลัง รพ. A <?php echo (int)$n_a; ?> รายการ · B <?php echo (int)$n_b; ?> รายการ
                                                    <?php else: ?>
                                                        ยังไม่ได้ล็อก icode — กดแก้แล้วบันทึกเพื่อเลือกจากคลัง รพ.
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td class="small"><?php echo htmlspecialchars($r['group_name']); ?></td>
                                            <td class="text-center"><?php echo mdt_alert_level($r) === 'hard' ? '<span class="badge bg-danger">Hard</span>' : '<span class="badge bg-warning text-dark">Soft</span>'; ?></td>
                                            <td class="text-center"><?php echo !empty($r['active']) ? '<span class="text-success">เปิด</span>' : '<span class="text-muted">ปิด</span>'; ?></td>
                                            <td class="text-center text-nowrap">
                                                <button type="button" class="btn btn-sm btn-outline-primary py-0 mdt-btn-edit" data-rule="<?php echo $rule_json; ?>">แก้</button>
                                                <form method="post" class="d-inline" onsubmit="return confirm(<?php echo htmlspecialchars(json_encode('ลบกฎนี้?\n' . mdt_pair_label($display), JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8'); ?>);">
                                                    <input type="hidden" name="action" value="delete_mdt">
                                                    <input type="hidden" name="del_id" value="<?php echo (int)$r['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger py-0">ลบ</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/monitor_hn_filter.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/flatpickr.min.js"></script>
<script>
let fpStart, fpEnd, mdtFetchGen = 0, mdtAbortCtl = null;

function mdtEsc(s) {
    if (s == null) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function mdtNormHn(s) {
    const d = String(s || '').replace(/\D+/g, '').replace(/^0+/, '');
    return d === '' ? '0' : d;
}
function mdtFocusHn() {
    if (typeof monitorFilterHn === 'function') {
        const typed = monitorFilterHn();
        if (typed) return typed;
    }
    return String(new URLSearchParams(location.search).get('hn') || '').trim();
}
$(function() {
    initMdtDrugSelects();
    if (typeof flatpickr !== 'undefined') {
        fpStart = flatpickr('#filter_start', { dateFormat: 'Y-m-d' });
        fpEnd = flatpickr('#filter_end', { dateFormat: 'Y-m-d' });
    }
    $('button[data-bs-target="#settings"]').on('shown.bs.tab', function() {
        initMdtDrugSelects();
    });
    $(document).on('click', '.mdt-btn-edit', function() {
        let rule = $(this).data('rule');
        if (typeof rule === 'string') {
            try { rule = JSON.parse(rule); } catch (e) { return; }
        }
        if (!rule || !rule.id) return;
        setMdtEditMode(rule);
    });
    $('#mdtForm').on('submit', function() {
        const mode = $('#mdt_match_mode').val();
        const a = $('#mdt_drugs_a').val() || [];
        const b = $('#mdt_drugs_b').val() || [];
        if (mode === 'class') {
            const n = {};
            a.concat(b).forEach(function(v) { if (v) n[String(v).split('|')[0]] = true; });
            if (Object.keys(n).length < 2) {
                alert('โหมดกลุ่มเดียวกัน กรุณาเลือกยาอย่างน้อย 2 รายการ');
                return false;
            }
            return true;
        }
        if (!a.length || !b.length) {
            alert('กรุณาเลือกยาจากคลัง รพ. ทั้งฝั่ง A และฝั่ง B');
            return false;
        }
        return true;
    });
    $('#mdt_drugs_a, #mdt_drugs_b').on('change', mdtUpdateTmtPreview);
    monitorInitHnFilter({
        clearHref: 'monitor_dup_therapy.php',
        fetchFn: fetchMDTData,
        autofetch: fetchMDTData
    });
});
function mdtSelectAll(on) { $('.mdt-rule-cb').prop('checked', !!on); }
function mdtBuildJobs() {
    const jobs = [];
    $('.mdt-rule-cb:checked').each(function() {
        jobs.push({ ruleId: String($(this).val()), label: String($(this).data('label') || $(this).val()) });
    });
    return jobs;
}
function setMDTDateRange(days) {
    const end = new Date();
    const start = new Date();
    if (days <= 1) start.setHours(0,0,0,0);
    else start.setDate(end.getDate() - (days - 1));
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    if (fpStart) fpStart.setDate(fmt(start), true); else $('#filter_start').val(fmt(start));
    if (fpEnd) fpEnd.setDate(fmt(end), true); else $('#filter_end').val(fmt(end));
    $('.mdt-range-btn').removeClass('active');
    $('.mdt-range-btn[data-days="' + days + '"]').addClass('active');
}
function renderMDTRow(item) {
    const when = item.order_time
        ? item.order_date + ' <span class="text-dark">' + mdtEsc(item.order_time) + '</span>'
        : mdtEsc(item.order_date);
    let detail = item.detail_text ? '<div class="text-muted small mt-1">' + mdtEsc(item.detail_text).replace(/\n/g, '<br>') + '</div>' : '';
    return '<tr data-hn="' + mdtEsc(item.hn_full || item.hn) + '">'
        + '<td class="text-center fw-bold">' + mdtEsc(item.hn) + '</td>'
        + '<td class="text-center"><span class="badge ' + (item.type_patient === 'IPD' ? 'bg-secondary' : 'bg-info text-dark') + '">' + mdtEsc(item.type_patient) + '</span></td>'
        + '<td>' + mdtEsc(item.ptname) + '</td>'
        + '<td class="text-center small">' + when + '</td>'
        + '<td class="text-start small"><b>' + mdtEsc(item.drugs_a) + '</b>'
        + (item.method_a ? '<br><span class="text-muted">' + mdtEsc(item.method_a) + '</span>' : '') + '</td>'
        + '<td class="text-start small"><b>' + mdtEsc(item.drugs_b) + '</b>'
        + (item.method_b ? '<br><span class="text-muted">' + mdtEsc(item.method_b) + '</span>' : '') + '</td>'
        + '<td class="text-center small">' + mdtEsc(item.ward_display || '-') + '</td>'
        + '<td class="text-start small text-danger fw-bold">' + mdtEsc(item.alert_message) + detail
        + (window.MonIv ? MonIv.btn(item, item.alert_message || '') : '')
        + '</td>'
        + '</tr>';
}
function mdtAlertKey(item) {
    return [item.hn_full || item.hn, item.rxdate, item.rule_id, item.drugs_a, item.drugs_b].join('|');
}
function mdtPushUnique(agg, kind, item) {
    const key = mdtAlertKey(item);
    if (agg.seen[key]) return;
    agg.seen[key] = true;
    agg[kind].push(item);
}
function mdtFilterByFocusHn(items) {
    const hn = mdtFocusHn();
    const want = mdtNormHn(hn);
    if (!hn || want === '0') return items || [];
    return (items || []).filter(function(item) {
        return mdtNormHn(item.hn) === want || mdtNormHn(item.hn_full) === want;
    });
}
function mdtPaint(hard, soft, isFinal) {
    const hn = mdtFocusHn();
    hard = mdtFilterByFocusHn(hard);
    soft = mdtFilterByFocusHn(soft);
    $('#hardCount').text(hard.length);
    $('#softCount').text(soft.length);
    const emptyHard = hn ? ('ไม่พบ Hard Alert ของ HN ' + mdtEsc(hn) + ' ในช่วงนี้') : 'ไม่พบ Hard Alert';
    const emptySoft = hn ? ('ไม่พบ Soft Alert ของ HN ' + mdtEsc(hn) + ' ในช่วงนี้') : 'ไม่พบ Soft Alert';
    if (hard.length === 0) {
        $('#hardTbody').html(isFinal
            ? '<tr><td colspan="8" class="text-center py-4 text-success fw-bold"><i class="fas fa-check-circle me-2"></i>' + emptyHard + '</td></tr>'
            : '<tr><td colspan="8" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังตรวจ...</td></tr>');
    } else {
        $('#hardTbody').html(hard.map(renderMDTRow).join(''));
    }
    if (soft.length === 0) {
        $('#softTbody').html(isFinal
            ? '<tr><td colspan="8" class="text-center py-4 text-muted">' + emptySoft + '</td></tr>'
            : '<tr><td colspan="8" class="text-center py-4 text-muted">กำลังตรวจ...</td></tr>');
    } else {
        $('#softTbody').html(soft.map(renderMDTRow).join(''));
    }
}
async function mdtPostJob(ruleIds, startDate, endDate, signal) {
    const body = { start_date: startDate, end_date: endDate, rule_ids: Array.isArray(ruleIds) ? ruleIds.join(',') : String(ruleIds) };
    const hn = mdtFocusHn();
    if (hn) body.hn = hn;
    const r = await fetch('fetch_monitor_dup_therapy_api.php', {
        method: 'POST', credentials: 'same-origin', signal: signal,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams(body)
    });
    const text = await r.text();
    let data;
    try { data = JSON.parse(text); } catch (e) {
        throw new Error((text || ('HTTP ' + r.status)).replace(/<[^>]+>/g,' ').substring(0, 240));
    }
    if (!r.ok && data.status !== 'success') throw new Error(data.message || ('HTTP ' + r.status));
    return data;
}
async function fetchMDTData() {
    const jobs = mdtBuildJobs();
    if (jobs.length === 0) { alert('กรุณาเลือกอย่างน้อย 1 คู่ยา'); return; }
    const startDate = $('#filter_start').val();
    const endDate = $('#filter_end').val();
    const gen = ++mdtFetchGen;
    if (mdtAbortCtl) { try { mdtAbortCtl.abort(); } catch (e) {} }
    const ac = new AbortController();
    mdtAbortCtl = ac;
    $('#btnFetchMDT').prop('disabled', true);
    $('#hardTbody').html('<tr><td colspan="8" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังดึงใบยาแล้วจับคู่ ' + jobs.length + ' กฎ...</td></tr>');
    $('#softTbody').html('<tr><td colspan="8" class="text-center py-4 text-muted">—</td></tr>');
    $('#hardCount, #softCount').text(0);
    $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info')
        .html('<i class="fas fa-spinner fa-spin me-1"></i> กำลังตรวจ ' + jobs.length + ' กฎ ในคำสั่งเดียว');
    const t0 = Date.now();
    function metaHtml(data, err) {
        const sec = ((Date.now() - t0) / 1000).toFixed(1);
        const m = (data && data.meta) || {};
        const hardN = (data && data.hard_alerts) ? data.hard_alerts.length : 0;
        const softN = (data && data.soft_alerts) ? data.soft_alerts.length : 0;
        let html = '<i class="fas fa-info-circle me-1"></i> ตรวจแล้ว ' + jobs.length + '/' + jobs.length
            + ' กฎ | Hard: ' + hardN + ' | Soft: ' + softN + ' | ' + sec + ' วินาที';
        if (m.orders_scanned) html += ' | ใบยา ' + m.orders_scanned;
        if (m.skipped_off || m.skipped_keyword) {
            html += ' | ตัดออก';
            if (m.skipped_off) html += ' Medplan off ' + m.skipped_off;
            if (m.skipped_off && m.skipped_keyword) html += ' ·';
            if (m.skipped_keyword) html += ' วิธีใช้ ' + m.skipped_keyword;
        }
        if (m.truncated) html += ' <span class="text-danger">(ถึงขีดจำกัด — ย่อช่วงวันที่)</span>';
        if (err) html += ' | <span class="text-danger">' + mdtEsc(err) + '</span>';
        return html;
    }
    try {
        const data = await mdtPostJob(jobs.map(function(j) { return j.ruleId; }), startDate, endDate, ac.signal);
        if (gen !== mdtFetchGen) return;
        if (data.status !== 'success') throw new Error(data.message || 'เกิดข้อผิดพลาด');
        mdtPaint(data.hard_alerts || [], data.soft_alerts || [], true);
        $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info').html(metaHtml(data));
    } catch (err) {
        if (err && err.name === 'AbortError') return;
        if (gen !== mdtFetchGen) return;
        $('#hardTbody').html('<tr><td colspan="8" class="text-center text-danger py-4">' + mdtEsc(err.message || 'เชื่อมต่อ API ไม่สำเร็จ') + '</td></tr>');
        $('#reportMeta').removeClass('d-none alert-info').addClass('alert-danger').html(metaHtml(null, err.message || 'เชื่อมต่อไม่สำเร็จ'));
    }
    if (gen !== mdtFetchGen) return;
    $('#btnFetchMDT').prop('disabled', false);
}
function resetMDTForm() {
    $('#mdtFormCard').removeClass('edit-mode');
    $('#mdtFormTitle').text('เพิ่ม / แก้ไขกฎคู่ยาซ้ำซ้อน');
    $('#mdt_rule_id').val('');
    $('#mdt_group, #mdt_alert_message, #mdt_detail_text').val('');
    $('#mdt_alert_level').val('hard');
    $('#mdt_match_mode').val('pair');
    $('#mdt_active').prop('checked', true);
    mdtSetDrugSelect($('#mdt_drugs_a'), []);
    mdtSetDrugSelect($('#mdt_drugs_b'), []);
    mdtUpdateTmtPreview();
    $('.mdt-rule-row').removeClass('mdt-editing-row');
}
function initMdtDrugSelects() {
    ['#mdt_drugs_a', '#mdt_drugs_b'].forEach(function(sel) {
        const $sel = $(sel);
        if (!$sel.length) return;
        if ($sel.hasClass('select2-hidden-accessible')) {
            $sel.select2('destroy');
        }
        $sel.select2({
            theme: 'bootstrap-5',
            width: '100%',
            dropdownParent: $('#mdtFormCard'),
            placeholder: 'พิมพ์ชื่อยา, icode หรือรหัส TMT...',
            allowClear: true,
            closeOnSelect: false,
            minimumInputLength: 1,
            ajax: {
                url: 'fetch_hosxp_drugs_select_api.php',
                dataType: 'json',
                delay: 250,
                data: function(params) { return { q: params.term || '' }; },
                processResults: function(data) { return { results: data.results || [] }; }
            }
        });
    });
}
function mdtSetDrugSelect($sel, items) {
    $sel.find('option').remove();
    (items || []).forEach(function(it) {
        const id = it.id || ((it.icode || '') + '|' + (it.name || ''));
        const text = it.text || it.name || id;
        if (!id) return;
        $sel.append(new Option(text, id, true, true));
    });
    $sel.trigger('change');
}
function mdtTmtNamesFromSelect($sel) {
    const names = [];
    const seen = {};
    $sel.find('option:selected').each(function() {
        const val = String($(this).val() || '');
        const pipe = val.indexOf('|');
        let name = pipe >= 0 ? val.slice(pipe + 1) : String($(this).text() || '');
        name = name.replace(/\s*\(icode:.*?\)\s*$/i, '').replace(/\s*\[TMT\s+[^\]]+\]\s*$/i, '').trim();
        if (!name || seen[name]) return;
        seen[name] = true;
        names.push(name);
    });
    return names;
}
function mdtUpdateTmtPreview() {
    const a = mdtTmtNamesFromSelect($('#mdt_drugs_a'));
    const b = mdtTmtNamesFromSelect($('#mdt_drugs_b'));
    $('#mdt_tmt_preview_a').html(a.length ? ('<b>TMT:</b> ' + a.map(mdtEsc).join(' / ')) : '');
    $('#mdt_tmt_preview_b').html(b.length ? ('<b>TMT:</b> ' + b.map(mdtEsc).join(' / ')) : '');
    if ($('#mdt_rule_id').val()) {
        const left = a.length ? a[0] + (a.length > 1 ? ' ฯลฯ' : '') : 'ฝั่ง A';
        const right = b.length ? b[0] + (b.length > 1 ? ' ฯลฯ' : '') : 'ฝั่ง B';
        $('#mdtFormTitle').text('แก้ไข: ' + left + ' + ' + right);
    }
}
function setMdtEditMode(rule) {
    $('.mdt-rule-row').removeClass('mdt-editing-row');
    $('tr.mdt-rule-row[data-rule-id="' + rule.id + '"]').addClass('mdt-editing-row');
    $('#mdtFormCard').addClass('edit-mode');
    $('#mdtFormTitle').text('แก้ไข: ' + (rule.pair_label || 'กฎคู่ยาซ้ำซ้อน'));
    $('#mdt_rule_id').val(rule.id);
    $('#mdt_group').val(rule.group_name || '');
    mdtSetDrugSelect($('#mdt_drugs_a'), rule.drugs_a || []);
    mdtSetDrugSelect($('#mdt_drugs_b'), rule.drugs_b || []);
    mdtUpdateTmtPreview();
    $('#mdt_match_mode').val(rule.match_mode === 'class' ? 'class' : 'pair');
    $('#mdt_alert_level').val(rule.alert_level === 'soft' ? 'soft' : 'hard');
    $('#mdt_alert_message').val(rule.alert_message || '');
    $('#mdt_detail_text').val(rule.detail_text || '');
    $('#mdt_active').prop('checked', !!rule.active);
    const pane = document.getElementById('mdtFormCard');
    if (pane && pane.scrollIntoView) pane.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
</script>
<?php
$mon_iv_module = 'dup_therapy';
$mon_iv_title = 'คู่ยาซ้ำซ้อน';
include __DIR__ . '/monitor_intervention_ui.php';
?>
</body>
</html>
