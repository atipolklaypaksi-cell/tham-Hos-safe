<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('monitor_warfarin_helper.php');
mysqli_set_charset($con, 'utf8');

mwf_ensure_tables($con);

$default_start = date('Y-m-d', strtotime('-7 days'));
$default_end = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

                if ($action === 'save_config') {
        $ok = mwf_save_config($con, [
            'default_protocol_id' => $_POST['default_protocol_id'] ?? 'inr_2_3',
            'inr_assess_max_days' => (int)($_POST['inr_assess_max_days'] ?? 5),
            'monitor_active' => isset($_POST['monitor_active']) ? 1 : 0,
            'monitor_scope' => $_POST['monitor_scope'] ?? 'all',
        ]);
        if (isset($_POST['inr_max_age_months'])) {
            wf_inr_save_max_age_months($con, (int)$_POST['inr_max_age_months']);
        }
        $_SESSION['mwf_msg'] = $ok ? 'บันทึกการตั้งค่าทั่วไปเรียบร้อย' : ('บันทึกไม่สำเร็จ: ' . mysqli_error($con));
        header('Location: monitor_warfarin.php?tab=settings');
        exit;
    }

    if ($action === 'save_rules') {
        $ids = $_POST['rule_id'] ?? [];
        if (!is_array($ids)) {
            $ids = [];
        }
        $updated = 0;
        foreach ($ids as $id) {
            $id = (int)$id;
            if ($id <= 0) {
                continue;
            }
            $lvl = (($_POST['alert_level'][$id] ?? '') === 'soft') ? 'soft' : 'hard';
            $msg = mysqli_real_escape_string($con, trim((string)($_POST['alert_message'][$id] ?? '')));
            $active = isset($_POST['rule_active'][$id]) ? 1 : 0;
            $lvl_esc = mysqli_real_escape_string($con, $lvl);
            if (mysqli_query($con, "UPDATE monitor_warfarin_alert_rules
                SET alert_level='$lvl_esc', alert_message='$msg', active=$active WHERE id=$id")) {
                $updated++;
            }
        }
        $_SESSION['mwf_msg'] = 'บันทึกกฎแจ้งเตือน ' . $updated . ' รายการเรียบร้อย';
        require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
        sp_monitor_settings_changed($con, 'warfarin');
        header('Location: monitor_warfarin.php?tab=settings');
        exit;
    }
}

$config = mwf_get_config($con);
$inr_max_age_months = wf_inr_max_age_months($con);
$rules = mwf_load_alert_rules($con, false);
$guidelines = wf_guideline_load($con);
$protocols = $guidelines['protocols'] ?? [];

$tab = (isset($_GET['tab']) && $_GET['tab'] === 'settings') ? 'settings' : 'dashboard';
$flash_msg = $_SESSION['mwf_msg'] ?? '';
$flash_err = $_SESSION['mwf_error'] ?? '';
unset($_SESSION['mwf_msg'], $_SESSION['mwf_error']);
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor Warfarin - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .mwf-card { border-radius: 10px; border: 1px solid #e2e8f0; padding: 1rem 1.1rem; }
        .mwf-card .num { font-size: 1.75rem; font-weight: 800; line-height: 1.1; }
        .mwf-ok { background: #f0fdf4; border-color: #86efac; }
        .mwf-ok .num { color: #166534; }
        .mwf-bad { background: #fef2f2; border-color: #fca5a5; }
        .mwf-bad .num { color: #b91c1c; }
        .mwf-other { background: #fffbeb; border-color: #fcd34d; }
        .mwf-other .num { color: #92400e; }
        .section-hard .table thead { background-color: #dc3545 !important; color: #fff !important; }
        .section-soft .table thead { background-color: #fd7e14 !important; color: #fff !important; }
        .mwf-range-btn.active { background-color: #0f766e !important; border-color: #0f766e !important; color: #fff !important; }
        .mwf-scope-btn.active { background-color: #0f766e !important; border-color: #0f766e !important; color: #fff !important; }
        .btn-outline-teal { color: #0f766e; border-color: #0f766e; }
        .btn-outline-teal:hover { background: #0f766e; color: #fff; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-2 text-dark">
                <i class="fas fa-heartbeat me-2" style="color:#0f766e;"></i>
                Monitor Warfarin
            </h4>
            <p class="text-muted small mb-4">
                เฝ้าระวังความเหมาะสมของการปรับขนาด Warfarin ตาม Guideline + INR —
                แจ้งเตือนเมื่อพบ <b>ไม่สอดคล้อง</b> (ตั้งค่าได้) และดู Dashboard สรุปผล
            </p>

            <?php if ($flash_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo htmlspecialchars($flash_msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            <?php if ($flash_err): ?>
            <div class="alert alert-danger alert-dismissible fade show"><?php echo htmlspecialchars($flash_err); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <ul class="nav nav-tabs fw-bold" role="tablist">
                <li class="nav-item">
                    <button class="nav-link <?php echo $tab === 'dashboard' ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#dashboard" type="button">
                        <i class="fas fa-chart-pie me-1"></i> Dashboard / แจ้งเตือน
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link <?php echo $tab === 'settings' ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#settings" type="button">
                        <i class="fas fa-cogs me-1"></i> ตั้งค่าการแจ้งเตือน
                    </button>
                </li>
            </ul>

            <div class="tab-content bg-white border border-top-0 p-4 rounded-bottom shadow-sm">
                <div class="tab-pane fade <?php echo $tab === 'dashboard' ? 'show active' : ''; ?>" id="dashboard">
                    <div class="filter-box p-3 mb-3">
                        <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-filter me-2"></i>ตัวกรองรายงาน</h6>
                        <div class="row g-2 align-items-end">
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">วันที่สั่งยา ตั้งแต่</label>
                                <input type="text" id="filter_start" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_start); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ถึงวันที่</label>
                                <input type="text" id="filter_end" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_end); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">Monitor</label>
                                <select id="filter_scope" class="form-select form-select-sm">
                                    <option value="all" <?php echo ($config['monitor_scope'] ?? 'all') === 'all' ? 'selected' : ''; ?>>ทั้งหมด</option>
                                    <option value="opd" <?php echo ($config['monitor_scope'] ?? '') === 'opd' ? 'selected' : ''; ?>>OPD</option>
                                    <option value="ipd" <?php echo ($config['monitor_scope'] ?? '') === 'ipd' ? 'selected' : ''; ?>>IPD</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold mb-1">Guideline (ถ้าไม่ระบุใช้ตาม HN)</label>
                                <select id="filter_protocol" class="form-select form-select-sm">
                                    <option value="">— ตามที่บันทึกต่อ HN / ค่าเริ่มต้น —</option>
                                    <?php foreach ($protocols as $p): ?>
                                    <option value="<?php echo htmlspecialchars($p['id']); ?>"><?php echo htmlspecialchars($p['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">HN (ไม่บังคับ)</label>
                                <input type="text" id="filter_hn" class="form-control form-control-sm bg-white" placeholder="ทุก HN" autocomplete="off">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-sm fw-bold text-white w-100 shadow-sm" style="background:#0f766e;" id="btnFetchMwf" onclick="fetchMwfData()">
                                    <i class="fas fa-sync-alt me-1"></i> ประมวลผล
                                </button>
                            </div>
                        </div>
                        <div class="row g-2 mt-2 align-items-center">
                            <div class="col-auto"><label class="form-label small fw-bold mb-0 text-secondary">ช่วงเร็ว:</label></div>
                            <div class="col">
                                <div class="btn-group btn-group-sm flex-wrap">
                                    <button type="button" class="btn btn-outline-secondary fw-bold mwf-range-btn" data-days="1" onclick="setMwfDateRange(1)">วันนี้</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mwf-range-btn" data-days="3" onclick="setMwfDateRange(3)">3 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mwf-range-btn active" data-days="7" onclick="setMwfDateRange(7)">7 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mwf-range-btn" data-days="30" onclick="setMwfDateRange(30)">30 วัน</button>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-outline-teal fw-bold mwf-scope-btn" data-scope="all" onclick="setMwfScope('all')">ทั้งหมด</button>
                                    <button type="button" class="btn btn-outline-info fw-bold mwf-scope-btn" data-scope="opd" onclick="setMwfScope('opd')">OPD</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mwf-scope-btn" data-scope="ipd" onclick="setMwfScope('ipd')">IPD</button>
                                </div>
                            </div>
                        </div>
                        <div id="hnFocusBanner" class="alert alert-warning py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                        <div id="mwfMeta" class="alert alert-info py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <div class="mwf-card mwf-ok">
                                <div class="small fw-bold text-success">เหมาะสม</div>
                                <div class="num" id="sumOk">0</div>
                                <div class="small text-muted">สอดคล้อง guideline</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mwf-card mwf-bad">
                                <div class="small fw-bold text-danger">ไม่สอดคล้อง</div>
                                <div class="num" id="sumBad">0</div>
                                <div class="small text-muted">ทิศทาง/% ไม่ตรง guideline</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mwf-card mwf-other">
                                <div class="small fw-bold text-warning">อื่นๆ</div>
                                <div class="num" id="sumOther">0</div>
                                <div class="small text-muted">ค่อนข้างเหมาะสม / ประเมินไม่ได้ / เริ่มต้น</div>
                            </div>
                        </div>
                    </div>

                    <div class="section-hard mb-4">
                        <h6 class="fw-bold text-danger mb-2"><i class="fas fa-exclamation-circle me-2"></i>Hard Alert <span id="hardCount" class="badge bg-danger">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-sm table-hover align-middle border mb-0">
                                <thead class="text-center small">
                                    <tr>
                                        <th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th><th>วันที่</th>
                                        <th>mg/สัปดาห์</th><th>INR</th><th>ปรับ %</th>
                                        <th>สรุป</th><th class="text-start">ข้อความแจ้งเตือน</th><th></th>
                                    </tr>
                                </thead>
                                <tbody id="hardBody"><tr><td colspan="10" class="text-center text-muted">กดประมวลผลเพื่อดูผล</td></tr></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="section-soft mb-4">
                        <h6 class="fw-bold text-warning mb-2"><i class="fas fa-exclamation-triangle me-2"></i>Soft Alert <span id="softCount" class="badge bg-warning text-dark">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-sm table-hover align-middle border mb-0">
                                <thead class="text-center small">
                                    <tr>
                                        <th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th><th>วันที่</th>
                                        <th>mg/สัปดาห์</th><th>INR</th><th>ปรับ %</th>
                                        <th>สรุป</th><th class="text-start">ข้อความแจ้งเตือน</th><th></th>
                                    </tr>
                                </thead>
                                <tbody id="softBody"><tr><td colspan="10" class="text-center text-muted">กดประมวลผลเพื่อดูผล</td></tr></tbody>
                            </table>
                        </div>
                    </div>

                    <h6 class="fw-bold mb-2"><i class="fas fa-list me-1"></i>รายการทั้งหมดในช่วงวันที่</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered align-middle mb-0">
                            <thead class="table-light text-center small">
                                <tr>
                                    <th>วันที่</th><th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th>
                                    <th>mg/สัปดาห์</th><th>INR</th><th>ปรับ %</th>
                                    <th>กลุ่ม</th><th>สรุป</th><th class="text-start">รายละเอียด</th><th></th>
                                </tr>
                            </thead>
                            <tbody id="dashBody"><tr><td colspan="11" class="text-center text-muted">กดประมวลผลเพื่อดูผล</td></tr></tbody>
                        </table>
                    </div>
                </div>

                <div class="tab-pane fade <?php echo $tab === 'settings' ? 'show active' : ''; ?>" id="settings">
                    <form method="post" class="mb-4 border rounded p-3 bg-light">
                        <input type="hidden" name="action" value="save_config">
                        <h6 class="fw-bold mb-3"><i class="fas fa-sliders-h me-1"></i>ตั้งค่าทั่วไป</h6>
                        <div class="row g-3 align-items-end">
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">เปิดใช้ Monitor</label>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="monitor_active" id="monitor_active" <?php echo !empty($config['monitor_active']) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="monitor_active">เปิดการสแกน/แจ้งเตือน</label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">Monitor กลุ่มผู้ป่วย</label>
                                <select name="monitor_scope" class="form-select form-select-sm">
                                    <option value="all" <?php echo ($config['monitor_scope'] ?? 'all') === 'all' ? 'selected' : ''; ?>>ทั้งหมด (OPD + IPD)</option>
                                    <option value="opd" <?php echo ($config['monitor_scope'] ?? '') === 'opd' ? 'selected' : ''; ?>>OPD เท่านั้น</option>
                                    <option value="ipd" <?php echo ($config['monitor_scope'] ?? '') === 'ipd' ? 'selected' : ''; ?>>IPD เท่านั้น</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">Guideline เริ่มต้น</label>
                                <select name="default_protocol_id" class="form-select form-select-sm">
                                    <?php foreach ($protocols as $p): ?>
                                    <option value="<?php echo htmlspecialchars($p['id']); ?>" <?php echo ($config['default_protocol_id'] === $p['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($p['name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label fw-bold small">อนุโลม INR ก่อนหน้า (วัน)</label>
                                <input type="number" name="inr_assess_max_days" class="form-control form-control-sm" min="0" max="30"
                                       value="<?php echo (int)$config['inr_assess_max_days']; ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold small">ผล INR ใช้ประเมินได้ไม่เกิน (เดือน)</label>
                                <input type="number" name="inr_max_age_months" class="form-control form-control-sm" min="1" max="60"
                                       value="<?php echo (int)$inr_max_age_months; ?>">
                                <div class="form-text">นานกว่านี้ = ประเมินไม่ได้ (ค่าเริ่มต้น 6)</div>
                            </div>
                            <div class="col-md-1">
                                <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">บันทึก</button>
                            </div>
                        </div>
                    </form>

                    <form method="post">
                        <input type="hidden" name="action" value="save_rules">
                        <h6 class="fw-bold mb-3"><i class="fas fa-bell me-1"></i>กฎการแจ้งเตือน</h6>
                        <p class="small text-muted">เลือกสถานะที่ต้องการให้แจ้งเตือน เช่น เปิดเฉพาะ <b>ไม่สอดคล้อง</b> เป็น Hard Alert</p>
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle bg-white">
                                <thead class="table-light text-center">
                                    <tr>
                                        <th>เปิดใช้</th>
                                        <th>สถานะ</th>
                                        <th>ระดับแจ้งเตือน</th>
                                        <th class="text-start">ข้อความแจ้งเตือน</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($rules as $rule):
                                    $rid = (int)$rule['id'];
                                ?>
                                    <tr>
                                        <td class="text-center">
                                            <input type="hidden" name="rule_id[]" value="<?php echo $rid; ?>">
                                            <input class="form-check-input" type="checkbox" name="rule_active[<?php echo $rid; ?>]" value="1"
                                                   <?php echo !empty($rule['active']) ? 'checked' : ''; ?>>
                                        </td>
                                        <td class="fw-bold text-center"><?php echo htmlspecialchars($rule['label_th']); ?>
                                            <div class="small text-muted"><?php echo htmlspecialchars($rule['verdict']); ?></div>
                                        </td>
                                        <td>
                                            <select name="alert_level[<?php echo $rid; ?>]" class="form-select form-select-sm">
                                                <option value="hard" <?php echo mwf_alert_level($rule) === 'hard' ? 'selected' : ''; ?>>Hard</option>
                                                <option value="soft" <?php echo mwf_alert_level($rule) === 'soft' ? 'selected' : ''; ?>>Soft</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" name="alert_message[<?php echo $rid; ?>]" class="form-control form-control-sm"
                                                   value="<?php echo htmlspecialchars((string)($rule['alert_message'] ?? '')); ?>">
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <button type="submit" class="btn btn-success fw-bold"><i class="fas fa-save me-1"></i>บันทึกกฎแจ้งเตือน</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/monitor_hn_filter.js"></script>
<script src="js/flatpickr.min.js"></script>
<script>
(function () {
    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
    function fmtPct(p) {
        if (p == null || isNaN(p)) return '—';
        var n = Math.round(p * 10) / 10;
        return (n > 0 ? '+' : '') + n + '%';
    }
    function badge(label, cls) {
        return '<span class="badge text-bg-' + esc(cls || 'secondary') + '">' + esc(label || '—') + '</span>';
    }
    function typeBadge(t) {
        t = t || 'OPD';
        var cls = t === 'IPD' ? 'bg-secondary' : 'bg-info text-dark';
        return '<span class="badge ' + cls + '">' + esc(t) + '</span>';
    }
    function dateTimeCell(r) {
        var html = esc(r.date_th || r.date || '—');
        if (r.time_hm) {
            html += '<div class="small text-muted">' + esc(r.time_hm) + '</div>';
        }
        return html;
    }
    function alertRows(list) {
        if (!list || !list.length) {
            return '<tr><td colspan="10" class="text-center text-muted">ไม่มีรายการ</td></tr>';
        }
        return list.map(function (r) {
            return '<tr>' +
                '<td class="text-center fw-bold">' + esc(r.hn) + '</td>' +
                '<td class="text-center">' + typeBadge(r.type_patient) + '</td>' +
                '<td class="small">' + esc(r.ptname || '—') + '</td>' +
                '<td class="text-center">' + dateTimeCell(r) + '</td>' +
                '<td class="text-center fw-bold">' + (r.mg_week != null ? esc(String(r.mg_week)) : '—') + '</td>' +
                '<td class="text-center">' + (r.inr != null ? esc(String(r.inr)) : '—') +
                (r.inr_date_th ? '<div class="small text-muted">' + esc(r.inr_date_th) + '</div>' : '') +
                (r.inr_stale ? '<div class="small text-danger">นานเกิน</div>' : '') + '</td>' +
                '<td class="text-center">' + fmtPct(r.pct_change) + '</td>' +
                '<td class="text-center">' + badge(r.assess_label, r.assess_badge) + '</td>' +
                '<td class="small text-start">' + esc(r.alert_message || r.assess_detail || '') + '</td>' +
                '<td class="text-center"><a class="btn btn-sm btn-outline-primary py-0" href="' + esc(r.calculator_url) + '" target="_blank">เปิด</a>' +
                (window.MonIv ? MonIv.btn(Object.assign({}, r, { drug_name: r.drug_name || 'Warfarin', vstdate: r.date || r.vstdate || '', alert_summary: r.alert_message || r.assess_detail || '' })) : '') +
                '</td>' +
                '</tr>';
        }).join('');
    }
    function dashRows(list) {
        if (!list || !list.length) {
            return '<tr><td colspan="11" class="text-center text-muted">ไม่มีรายการ</td></tr>';
        }
        return list.map(function (r) {
            var bucketCls = r.bucket === 'ok' ? 'success' : (r.bucket === 'mismatch' ? 'danger' : 'warning');
            return '<tr>' +
                '<td class="text-center">' + dateTimeCell(r) + '</td>' +
                '<td class="text-center fw-bold">' + esc(r.hn) + '</td>' +
                '<td class="text-center">' + typeBadge(r.type_patient) + '</td>' +
                '<td class="small">' + esc(r.ptname || '—') + '</td>' +
                '<td class="text-center fw-bold">' + (r.mg_week != null ? esc(String(r.mg_week)) : '—') + '</td>' +
                '<td class="text-center">' + (r.inr != null ? esc(String(r.inr)) : '—') +
                (r.inr_stale ? '<div class="small text-danger">นานเกิน</div>' : '') + '</td>' +
                '<td class="text-center">' + fmtPct(r.pct_change) + '</td>' +
                '<td class="text-center">' + badge(r.bucket_label, bucketCls) + '</td>' +
                '<td class="text-center">' + badge(r.assess_label, r.assess_badge) + '</td>' +
                '<td class="small">' + esc(r.assess_detail || '') + '</td>' +
                '<td class="text-center"><a class="btn btn-sm btn-outline-primary py-0" href="' + esc(r.calculator_url) + '" target="_blank">เปิด</a>' +
                (window.MonIv && r.bucket !== 'ok' ? MonIv.btn(Object.assign({}, r, { drug_name: r.drug_name || 'Warfarin', vstdate: r.date || r.vstdate || '', alert_summary: r.assess_detail || r.alert_message || r.bucket_label || '' })) : '') +
                '</td>' +
                '</tr>';
        }).join('');
    }

    window.setMwfScope = function (scope) {
        var sel = document.getElementById('filter_scope');
        if (sel) sel.value = scope;
        document.querySelectorAll('.mwf-scope-btn').forEach(function (b) {
            b.classList.toggle('active', b.getAttribute('data-scope') === scope);
        });
    };

    window.setMwfDateRange = function (days) {
        var end = new Date();
        var start = new Date();
        start.setDate(end.getDate() - (days - 1));
        function ymd(d) {
            var m = (d.getMonth() + 1); m = m < 10 ? '0' + m : '' + m;
            var day = d.getDate(); day = day < 10 ? '0' + day : '' + day;
            return d.getFullYear() + '-' + m + '-' + day;
        }
        document.getElementById('filter_start').value = ymd(start);
        document.getElementById('filter_end').value = ymd(end);
        document.querySelectorAll('.mwf-range-btn').forEach(function (b) {
            b.classList.toggle('active', String(b.getAttribute('data-days')) === String(days));
        });
    };

    var MWF_BATCH = 3;
    var MWF_PARALLEL = 3;
    var mwfFetchGen = 0;
    var mwfAbort = null;

    function mwfChunk(arr, size) {
        var out = [];
        for (var i = 0; i < arr.length; i += size) {
            out.push(arr.slice(i, i + size));
        }
        return out;
    }
    function mwfDaysBetween(start, end) {
        var out = [];
        var a = String(start || '').slice(0, 10);
        var b = String(end || '').slice(0, 10);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(a) || !/^\d{4}-\d{2}-\d{2}$/.test(b)) return out;
        var d = new Date(a + 'T00:00:00');
        var last = new Date(b + 'T00:00:00');
        if (d > last) { var tmp = d; d = last; last = tmp; }
        var guard = 0;
        while (d <= last && guard < 400) {
            var m = d.getMonth() + 1; m = m < 10 ? '0' + m : '' + m;
            var day = d.getDate(); day = day < 10 ? '0' + day : '' + day;
            out.push(d.getFullYear() + '-' + m + '-' + day);
            d.setDate(d.getDate() + 1);
            guard++;
        }
        return out;
    }
    function mwfRowKey(r) {
        return [r.hn, r.date, r.time, r.source, r.mg_week].join('|');
    }
    function mwfSortLatest(list) {
        list.sort(function (a, b) {
            var c = String(b.date || '').localeCompare(String(a.date || ''));
            if (c) return c;
            c = String(b.time || '').localeCompare(String(a.time || ''));
            if (c) return c;
            return String(a.hn || '').localeCompare(String(b.hn || ''));
        });
        return list;
    }
    function mwfMergePart(agg, part) {
        function add(src, dest, seen) {
            (src || []).forEach(function (r) {
                var k = mwfRowKey(r);
                if (seen[k]) return;
                seen[k] = 1;
                dest.push(r);
            });
        }
        add(part.dashboard, agg.dashboard, agg.seenDash);
        add(part.hard_alerts, agg.hard, agg.seenHard);
        add(part.soft_alerts, agg.soft, agg.seenSoft);
    }
    function mwfRecount(dash) {
        var s = { ok: 0, mismatch: 0, other: 0, total: 0 };
        (dash || []).forEach(function (r) {
            var b = r.bucket === 'ok' || r.bucket === 'mismatch' ? r.bucket : 'other';
            s[b]++;
            s.total++;
        });
        return s;
    }
    function mwfEmptyPart() {
        return { dashboard: [], hard_alerts: [], soft_alerts: [] };
    }
    function mwfPaint(agg) {
        mwfSortLatest(agg.dashboard);
        mwfSortLatest(agg.hard);
        mwfSortLatest(agg.soft);
        var s = mwfRecount(agg.dashboard);
        document.getElementById('sumOk').textContent = s.ok;
        document.getElementById('sumBad').textContent = s.mismatch;
        document.getElementById('sumOther').textContent = s.other;
        document.getElementById('hardCount').textContent = agg.hard.length;
        document.getElementById('softCount').textContent = agg.soft.length;
        document.getElementById('hardBody').innerHTML = alertRows(agg.hard);
        document.getElementById('softBody').innerHTML = alertRows(agg.soft);
        document.getElementById('dashBody').innerHTML = dashRows(agg.dashboard);
        return s;
    }
    function mwfLoadingRows(msg) {
        document.getElementById('hardBody').innerHTML = '<tr><td colspan="10" class="text-center text-muted py-3"><i class="fas fa-spinner fa-spin me-2"></i>' + esc(msg) + '</td></tr>';
        document.getElementById('softBody').innerHTML = '<tr><td colspan="10" class="text-center text-muted py-3"><i class="fas fa-spinner fa-spin me-2"></i>' + esc(msg) + '</td></tr>';
        document.getElementById('dashBody').innerHTML = '<tr><td colspan="11" class="text-center text-muted py-3"><i class="fas fa-spinner fa-spin me-2"></i>' + esc(msg) + '</td></tr>';
        document.getElementById('sumOk').textContent = 0;
        document.getElementById('sumBad').textContent = 0;
        document.getElementById('sumOther').textContent = 0;
        document.getElementById('hardCount').textContent = 0;
        document.getElementById('softCount').textContent = 0;
    }

    async function mwfFetchJson(url, opts) {
        opts = opts || {};
        var waitMs = opts.timeoutMs || 0;
        delete opts.timeoutMs;
        var local = new AbortController();
        var parent = opts.signal;
        var onParent = function () { local.abort(); };
        if (parent) {
            if (parent.aborted) local.abort();
            else parent.addEventListener('abort', onParent);
        }
        var timer = null;
        if (waitMs > 0) {
            timer = setTimeout(function () { local.abort(); }, waitMs);
        }
        opts.signal = local.signal;
        try {
            var r = await fetch(url, opts);
            var text = await r.text();
            var data = null;
            try { data = text ? JSON.parse(text) : null; } catch (e) { data = null; }
            if (!data || data.status !== 'success') {
                var err = new Error(mwfFriendlyError(data && data.message, r.status, text));
                err.status = r.status;
                throw err;
            }
            return data;
        } finally {
            if (timer) clearTimeout(timer);
            if (parent) parent.removeEventListener('abort', onParent);
        }
    }

    window.fetchMwfData = async function () {
        var start = document.getElementById('filter_start').value;
        var end = document.getElementById('filter_end').value;
        var proto = document.getElementById('filter_protocol').value;
        var scope = document.getElementById('filter_scope').value || 'all';
        var meta = document.getElementById('mwfMeta');
        var btn = document.getElementById('btnFetchMwf');
        var gen = ++mwfFetchGen;
        if (mwfAbort) {
            try { mwfAbort.abort(); } catch (e) {}
        }
        var ac = new AbortController();
        mwfAbort = ac;

        meta.classList.remove('d-none');
        meta.className = 'alert alert-info py-2 px-3 mt-2 mb-0 small fw-bold';
        meta.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังดึงรายชื่อ HN... อย่าปิดหน้านี้';
        btn.disabled = true;
        setMwfScope(scope);
        mwfLoadingRows('กำลังดึงรายชื่อผู้ป่วย...');

        function stillActive() {
            return gen === mwfFetchGen;
        }

        try {
            var days = mwfDaysBetween(start, end);
            if (!days.length) days = [start];
            var focusHn = (typeof monitorFilterHn === 'function') ? monitorFilterHn() : '';
            var hnMap = {};
            var listMeta = {};
            var hnFailed = [];
            if (focusHn) {
                hnMap[focusHn] = 1;
            } else {
            meta.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังดึงรายชื่อ HN ทีละวัน (' + days.length + ' วัน, พร้อมกัน 3)...';
            var hnNext = 0;
            var hnWorkers = Math.min(3, days.length);
            async function hnWorker() {
                while (hnNext < days.length) {
                    if (!stillActive()) return;
                    var day = days[hnNext++];
                    try {
                        var part = await mwfFetchJson(
                            'fetch_monitor_warfarin_api.php?' +
                            'start_date=' + encodeURIComponent(day) +
                            '&end_date=' + encodeURIComponent(day) +
                            '&scope=' + encodeURIComponent(scope) +
                            (proto ? '&protocol_id=' + encodeURIComponent(proto) : '') +
                            '&mode=hns',
                            { credentials: 'same-origin', signal: ac.signal, timeoutMs: 20000 }
                        );
                        (part.hns || []).forEach(function (h) { if (h) hnMap[h] = 1; });
                        if (part.meta) listMeta = part.meta;
                    } catch (e) {
                        if (e && e.name === 'AbortError' && ac.signal.aborted) throw e;
                        hnFailed.push(day);
                    }
                }
            }
            await Promise.all(Array.from({ length: hnWorkers }, hnWorker));
            if (!stillActive()) return;
            }

            var hns = Object.keys(hnMap);
            if (listMeta.message && !hns.length) {
                btn.disabled = false;
                meta.className = 'alert alert-warning py-2 px-3 mt-2 mb-0 small fw-bold';
                meta.textContent = listMeta.message;
                mwfPaint({ dashboard: [], hard: [], soft: [], seenDash: {}, seenHard: {}, seenSoft: {} });
                return;
            }
            if (!hns.length) {
                btn.disabled = false;
                meta.className = hnFailed.length ? 'alert alert-danger py-2 px-3 mt-2 mb-0 small fw-bold' : 'alert alert-success py-2 px-3 mt-2 mb-0 small fw-bold';
                meta.textContent = hnFailed.length
                    ? 'ดึงรายชื่อ HN ไม่สำเร็จ — ลองกดประมวลผลอีกครั้ง'
                    : ('Monitor: ' + (listMeta.scope_label || scope) + ' · ไม่พบ HN ที่สั่ง Warfarin ในช่วงนี้');
                mwfPaint({ dashboard: [], hard: [], soft: [], seenDash: {}, seenHard: {}, seenSoft: {} });
                return;
            }

            var chunks = mwfChunk(hns, MWF_BATCH);
            var workers = Math.min(MWF_PARALLEL, chunks.length);
            var agg = { dashboard: [], hard: [], soft: [], seenDash: {}, seenHard: {}, seenSoft: {} };
            var failed = [];
            var doneHn = 0;
            var t0 = Date.now();

            function updateMeta(isFinal) {
                if (!stillActive()) return;
                var sec = ((Date.now() - t0) / 1000).toFixed(1);
                var s = mwfRecount(agg.dashboard);
                var html = '<i class="fas fa-' + (isFinal ? 'check-circle' : 'spinner fa-spin') + ' me-1"></i> ' +
                    'ประมวลผล ' + doneHn + '/' + hns.length + ' HN' +
                    ' · พร้อมกัน ' + workers + ' ชุด (ชุดละไม่เกิน ' + MWF_BATCH + ' HN)' +
                    ' · รายการ ' + s.total +
                    ' · Hard ' + agg.hard.length +
                    ' · Soft ' + agg.soft.length +
                    ' · ' + sec + ' วินาที';
                if (hns.length >= 400) html += ' <span class="text-danger">(ถึงขีดจำกัด 400 HN — ย่อช่วงวันที่)</span>';
                if (failed.length) html += ' · <span class="text-danger">ไม่สำเร็จ ' + failed.length + ' HN</span>';
                if (isFinal && failed.length) {
                    html += '<div class="small fw-normal mt-1">ข้าม HN: ' + failed.map(function (h) { return esc(h); }).join(', ') + '</div>';
                }
                meta.className = 'alert py-2 px-3 mt-2 mb-0 small fw-bold ' +
                    (isFinal && failed.length ? 'alert-warning' : (isFinal ? 'alert-success' : 'alert-info'));
                meta.innerHTML = html;
            }

            async function fetchScan(chunk) {
                var body = new URLSearchParams({
                    mode: 'scan',
                    start_date: start,
                    end_date: end,
                    scope: scope,
                    protocol_id: proto || '',
                    hns: chunk.join(',')
                });
                return mwfFetchJson('fetch_monitor_warfarin_api.php', {
                    method: 'POST',
                    credentials: 'same-origin',
                    signal: ac.signal,
                    timeoutMs: chunk.length <= 1 ? 45000 : 25000,
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString()
                });
            }

            async function runChunk(chunk) {
                try {
                    return await fetchScan(chunk);
                } catch (e) {
                    if (e && e.name === 'AbortError' && ac.signal.aborted) throw e;
                    if (chunk.length <= 1) {
                        failed.push(chunk[0]);
                        return mwfEmptyPart();
                    }
                    var mid = Math.ceil(chunk.length / 2);
                    var a = await runChunk(chunk.slice(0, mid));
                    var b = await runChunk(chunk.slice(mid));
                    return {
                        dashboard: (a.dashboard || []).concat(b.dashboard || []),
                        hard_alerts: (a.hard_alerts || []).concat(b.hard_alerts || []),
                        soft_alerts: (a.soft_alerts || []).concat(b.soft_alerts || [])
                    };
                }
            }

            updateMeta(false);
            meta.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> พบ ' + hns.length +
                ' HN — กำลังประมวลผลคู่ขนาน ' + workers + ' ชุด... อย่าปิดหน้านี้';

            var next = 0;
            async function worker() {
                while (next < chunks.length) {
                    if (!stillActive()) return;
                    var chunk = chunks[next++];
                    var part = await runChunk(chunk);
                    if (!stillActive()) return;
                    mwfMergePart(agg, part);
                    doneHn += chunk.length;
                    mwfPaint(agg);
                    updateMeta(false);
                }
            }

            await Promise.all(Array.from({ length: workers }, worker));
            if (!stillActive()) return;
            mwfPaint(agg);
            updateMeta(true);
            if (!failed.length) {
                var s = mwfRecount(agg.dashboard);
                meta.className = 'alert alert-success py-2 px-3 mt-2 mb-0 small fw-bold';
                meta.textContent = 'Monitor: ' + (listMeta.scope_label || scope) +
                    ' · พบ HN ' + hns.length + ' · รายการ ' + s.total +
                    ' · Hard ' + agg.hard.length + ' · Soft ' + agg.soft.length +
                    ' · ' + ((Date.now() - t0) / 1000).toFixed(1) + ' วินาที';
            }
        } catch (err) {
            if (err && err.name === 'AbortError') return;
            if (!stillActive()) return;
            meta.className = 'alert alert-danger py-2 px-3 mt-2 mb-0 small fw-bold';
            meta.textContent = mwfFriendlyError(err && err.message, err && err.status, '');
            document.getElementById('hardBody').innerHTML = '<tr><td colspan="10" class="text-center text-danger">ประมวลผลไม่สำเร็จ</td></tr>';
            document.getElementById('softBody').innerHTML = '<tr><td colspan="10" class="text-center text-danger">ประมวลผลไม่สำเร็จ</td></tr>';
            document.getElementById('dashBody').innerHTML = '<tr><td colspan="11" class="text-center text-danger">ประมวลผลไม่สำเร็จ</td></tr>';
        } finally {
            if (stillActive()) btn.disabled = false;
        }
    };

    function mwfFriendlyError(message, status, raw) {
        var text = String(message || raw || '');
        if (status === 504 || /504|Gateway Time-out/i.test(text)) {
            return 'ประมวลผลนานเกินกำหนด — ลองย่อช่วงวันที่ (เช่น วันนี้ หรือ 3 วัน) แล้วกดประมวลผลอีกครั้ง';
        }
        if (status === 502 || /Bad Gateway/i.test(text)) {
            return 'เซิร์ฟเวอร์ไม่ตอบ (502) — ลองใหม่ในอีกสักครู่';
        }
        if (/Unexpected token|JSON|Failed to fetch|NetworkError/i.test(text)) {
            return 'ประมวลผลไม่สำเร็จหรือใช้เวลานานเกินไป — ย่อช่วงวันที่แล้วกดประมวลผลอีกครั้ง';
        }
        var stripped = text.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        return (stripped || 'ประมวลผลไม่สำเร็จ').substring(0, 240);
    }

    document.addEventListener('DOMContentLoaded', function () {
        if (window.flatpickr) {
            flatpickr('#filter_start', { dateFormat: 'Y-m-d' });
            flatpickr('#filter_end', { dateFormat: 'Y-m-d' });
        }
        var scopeSel = document.getElementById('filter_scope');
        if (scopeSel) {
            setMwfScope(scopeSel.value || 'all');
            scopeSel.addEventListener('change', function () { setMwfScope(scopeSel.value); });
        }
        monitorInitHnFilter({
            clearHref: 'monitor_warfarin.php',
            fetchFn: function () { if (typeof fetchMwfData === 'function') fetchMwfData(); },
            autofetch: function () { if (typeof fetchMwfData === 'function') fetchMwfData(); }
        });
    });
})();
</script>
<?php
$mon_iv_module = 'warfarin';
$mon_iv_title = 'Warfarin';
include __DIR__ . '/monitor_intervention_ui.php';
?>
</body>
</html>
