<?php
/**
 * Helper: ดึงรายการยา HOSxP พร้อมชื่อจาก TMT (tmt_tpu_code)
 */

function hosxp_load_config($con) {
    $hos_cfg = [];
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ('h_host', 'h_user', 'h_pass', 'h_db')");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $hos_cfg[$r['config_name']] = $r['config_value'];
        }
    }
    return $hos_cfg;
}

function hosxp_master_config_keys() {
    return ['h_master_host', 'h_master_port', 'h_master_db', 'h_master_user', 'h_master_pass'];
}

function hosxp_load_master_config($con) {
    $cfg = [
        'h_master_host' => '',
        'h_master_port' => '3306',
        'h_master_db' => 'hos',
        'h_master_user' => '',
        'h_master_pass' => '',
    ];
    $keys = "'" . implode("','", hosxp_master_config_keys()) . "'";
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ($keys)");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cfg[$r['config_name']] = (string)$r['config_value'];
        }
    }
    if (trim($cfg['h_master_port']) === '') {
        $cfg['h_master_port'] = '3306';
    }
    if (trim($cfg['h_master_db']) === '') {
        $cfg['h_master_db'] = 'hos';
    }
    return $cfg;
}

function hosxp_master_configured($con) {
    $cfg = hosxp_load_master_config($con);
    return trim((string)$cfg['h_master_host']) !== ''
        && trim((string)$cfg['h_master_user']) !== ''
        && trim((string)$cfg['h_master_db']) !== '';
}

function hosxp_mysqli_connect($host, $user, $pass, $db, $port = 3306, $read_timeout = 120) {
    $host = trim((string)$host);
    $user = trim((string)$user);
    $db = trim((string)$db);
    $port = (int)$port;
    if ($port <= 0) {
        $port = 3306;
    }
    if ($host === '' || $user === '' || $db === '') {
        return null;
    }
    mysqli_report(MYSQLI_REPORT_OFF);
    $c = mysqli_init();
    if (!$c) {
        return null;
    }
    $read_timeout = max(30, min(900, (int)$read_timeout));
    mysqli_options($c, MYSQLI_OPT_CONNECT_TIMEOUT, 8);
    if (defined('MYSQLI_OPT_READ_TIMEOUT')) {
        mysqli_options($c, MYSQLI_OPT_READ_TIMEOUT, $read_timeout);
    }
    $ok = @mysqli_real_connect($c, $host, $user, (string)$pass, $db, $port);
    if (!$ok) {
        return null;
    }
    mysqli_set_charset($c, 'utf8');
    return $c;
}

function hosxp_connect($con, $read_timeout = 120) {
    $cfg = hosxp_load_config($con);
    return hosxp_mysqli_connect(
        $cfg['h_host'] ?? '',
        $cfg['h_user'] ?? '',
        $cfg['h_pass'] ?? '',
        $cfg['h_db'] ?? '',
        3306,
        $read_timeout
    );
}

/** ต่อ HOSxP master — สำรองไว้ดึงรายการเฉพาะที่คิวรีเบา เพื่อไม่ให้เซิร์ฟเวอร์หลักค้าง */
function hosxp_connect_master($con, $read_timeout = 30) {
    $cfg = hosxp_load_master_config($con);
    return hosxp_mysqli_connect(
        $cfg['h_master_host'] ?? '',
        $cfg['h_master_user'] ?? '',
        $cfg['h_master_pass'] ?? '',
        $cfg['h_master_db'] ?? '',
        (int)($cfg['h_master_port'] ?? 3306),
        $read_timeout
    );
}

function hosxp_write_config_keys() {
    return ['h_write_user', 'h_write_pass'];
}

function hosxp_load_write_config($con) {
    $cfg = [
        'h_write_user' => '',
        'h_write_pass' => '',
    ];
    $keys = "'" . implode("','", hosxp_write_config_keys()) . "'";
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ($keys)");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cfg[$r['config_name']] = (string)$r['config_value'];
        }
    }
    return $cfg;
}

/** ต่อ HOSxP เพื่อบันทึก (เช่น แก้จำนวนยา) — ใช้บัญชีเขียนถ้ามี ไม่เช่นนั้นใช้ master */
function hosxp_connect_write($con, $read_timeout = 20) {
    $write = hosxp_load_write_config($con);
    $user = trim((string)($write['h_write_user'] ?? ''));
    if ($user === '') {
        return hosxp_connect_master($con, $read_timeout);
    }
    $master = hosxp_load_master_config($con);
    $host = trim((string)($master['h_master_host'] ?? ''));
    $db = trim((string)($master['h_master_db'] ?? 'hos'));
    $port = (int)($master['h_master_port'] ?? 3306);
    if ($host === '') {
        $pri = hosxp_load_config($con);
        $host = trim((string)($pri['h_host'] ?? ''));
        if ($db === '') {
            $db = trim((string)($pri['h_db'] ?? 'hos'));
        }
    }
    return hosxp_mysqli_connect(
        $host,
        $user,
        (string)($write['h_write_pass'] ?? ''),
        $db !== '' ? $db : 'hos',
        $port,
        $read_timeout
    );
}

function hosxp_connection_alive($hos) {
    if (!$hos) {
        return false;
    }
    try {
        return (bool)@mysqli_ping($hos);
    } catch (Throwable $e) {
        return false;
    }
}

/** ต่อ HOSxP ใหม่ถ้า connection หลุด (กันคิวรีช้าแล้ว MySQL server has gone away) */
function hosxp_ensure_connection($con, &$hos, $read_timeout = 600) {
    if (hosxp_connection_alive($hos)) {
        return $hos;
    }
    if ($hos) {
        try {
            @mysqli_close($hos);
        } catch (Throwable $e) {
            // already closed
        }
        $hos = null;
    }
    $hos = hosxp_connect($con, $read_timeout);
    if ($hos) {
        hosxp_extend_read_timeout($hos, $read_timeout);
    }
    return $hos;
}

function hosxp_extend_read_timeout($hos, $seconds = 180) {
    if (!$hos) {
        return;
    }
    $seconds = max(30, min(900, (int)$seconds));
    @mysqli_query($hos, 'SET SESSION max_statement_time = ' . $seconds);
    @mysqli_query($hos, 'SET SESSION wait_timeout = ' . $seconds);
    @mysqli_query($hos, 'SET SESSION net_read_timeout = ' . $seconds);
    @mysqli_query($hos, 'SET SESSION net_write_timeout = ' . $seconds);
}

function hosxp_sql_tmt_drug_name($d = 'd', $tm = 'tm') {
    return "CAST(CONVERT(COALESCE(NULLIF(TRIM(CONCAT(IFNULL($tm.active_ingredient, ''), ' ', IFNULL($tm.strength, ''))), ''), $d.name) USING utf8) AS CHAR)";
}

function hosxp_sql_tmt_join($d = 'd', $tm = 'tm') {
    return "LEFT JOIN tmt_tpu_code $tm ON $d.tpu_code_list = $tm.tpu_code";
}

/** strength จาก TMT ก่อน ถ้าไม่มีใช้ drugitems.strength */
function hosxp_sql_tmt_strength($d = 'd', $tm = 'tm') {
    return "COALESCE(NULLIF(TRIM($tm.strength), ''), $d.strength)";
}

function hosxp_search_drugs_tmt($con_hosxp, $term = '', $limit = 30) {
    $tmt_expr = hosxp_sql_tmt_drug_name('d', 'tm');
    $where = "d.istatus = 'Y' AND d.icode IS NOT NULL AND TRIM(d.icode) <> ''";
    $term = trim($term);
    if ($term !== '') {
        $t_esc = mysqli_real_escape_string($con_hosxp, $term);
        $where .= " AND (d.icode LIKE '%$t_esc%' OR d.name LIKE '%$t_esc%' OR $tmt_expr LIKE '%$t_esc%'"
            . " OR IFNULL(d.tpu_code_list,'') LIKE '%$t_esc%'"
            . " OR IFNULL(tm.tpu_code,'') LIKE '%$t_esc%'"
            . " OR IFNULL(tm.active_ingredient,'') LIKE '%$t_esc%')";
    }
    $limit = max(1, min(50, (int)$limit));
    $sql = "
        SELECT d.icode,
               CAST(CONVERT(d.name USING utf8) AS CHAR) AS name_local,
               $tmt_expr AS name_tmt,
               TRIM(IFNULL(d.tpu_code_list,'')) AS tpu_code
        FROM drugitems d
        " . hosxp_sql_tmt_join('d', 'tm') . "
        WHERE $where
        ORDER BY name_local ASC
        LIMIT $limit
    ";
    $list = [];
    $q = mysqli_query($con_hosxp, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $local = trim($r['name_local'] ?? '');
            $tmt = trim($r['name_tmt'] ?? '');
            if ($tmt === '') {
                $tmt = $local;
            }
            $list[] = [
                'icode' => trim($r['icode']),
                'name_local' => $local,
                'name_tmt' => $tmt,
                'tpu_code' => trim($r['tpu_code'] ?? ''),
            ];
        }
    }
    return $list;
}

function hosxp_fetch_active_drugs_tmt($con_hosxp) {
    // แคชรายการยา — ตรวจจับการเปลี่ยนแปลงด้วย fingerprint (count + max update)
    $fp = hosxp_drugitems_fingerprint($con_hosxp);
    $cache_key = 'hosxp_drugs_tmt_' . $fp;
    if (function_exists('sp_cache_get')) {
        $cached = sp_cache_get($cache_key, 3600);
        if (is_array($cached)) {
            return $cached;
        }
    } else {
        $dir = rtrim(sys_get_temp_dir(), '/\\') . '/tham_sp_cache';
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        $file = $dir . '/' . hash('sha256', $cache_key) . '.cache';
        if (is_file($file)) {
            $entry = @unserialize((string)@file_get_contents($file));
            if (is_array($entry) && (time() - (int)($entry['t'] ?? 0) <= 3600) && is_array($entry['data'] ?? null)) {
                return $entry['data'];
            }
        }
    }

    $tmt_expr = hosxp_sql_tmt_drug_name('d', 'tm');
    $sql = "
        SELECT d.icode,
               CAST(CONVERT(d.name USING utf8) AS CHAR) AS name_local,
               $tmt_expr AS name_tmt
        FROM drugitems d
        " . hosxp_sql_tmt_join('d', 'tm') . "
        WHERE d.istatus = 'Y'
          AND d.icode IS NOT NULL
          AND TRIM(d.icode) <> ''
        ORDER BY name_local ASC
    ";
    $list = [];
    $q = mysqli_query($con_hosxp, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $local = trim($r['name_local'] ?? '');
            $tmt = trim($r['name_tmt'] ?? '');
            if ($tmt === '') {
                $tmt = $local;
            }
            $list[] = [
                'icode' => trim($r['icode']),
                'name_local' => $local,
                'name_tmt' => $tmt,
            ];
        }
    }

    if (function_exists('sp_cache_set')) {
        sp_cache_set($cache_key, $list, 3600);
    } else {
        $dir = rtrim(sys_get_temp_dir(), '/\\') . '/tham_sp_cache';
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        $file = $dir . '/' . hash('sha256', $cache_key) . '.cache';
        @file_put_contents($file, serialize(['t' => time(), 'data' => $list]), LOCK_EX);
    }
    return $list;
}

/**
 * Fingerprint ของ drugitems ใน HOSxP — เปลี่ยนเมื่อมีแก้/เพิ่มยา
 * ลองคอลัมน์ lastupdate / update_datetime / modify_datetime ตามที่มีจริง
 */
function hosxp_drugitems_fingerprint($con_hosxp) {
    static $cached_fp = null;
    if ($cached_fp !== null) {
        return $cached_fp;
    }
    $ts_expr = '0';
    $col_q = @mysqli_query(
        $con_hosxp,
        "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = 'drugitems'
           AND COLUMN_NAME IN ('lastupdate','update_datetime','modify_datetime','last_update')
         LIMIT 1"
    );
    if ($col_q && ($cr = mysqli_fetch_assoc($col_q))) {
        $col = preg_replace('/[^a-z0-9_]/i', '', (string)($cr['COLUMN_NAME'] ?? ''));
        if ($col !== '') {
            $ts_expr = "COALESCE(MAX(UNIX_TIMESTAMP(d.`$col`)), 0)";
        }
    }
    $sql = "SELECT COUNT(*) AS c, $ts_expr AS m FROM drugitems d WHERE d.istatus = 'Y'";
    $q = @mysqli_query($con_hosxp, $sql);
    $c = 0;
    $m = 0;
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $c = (int)($r['c'] ?? 0);
        $m = (int)($r['m'] ?? 0);
    }
    $cached_fp = $c . '_' . $m;
    return $cached_fp;
}

function hosxp_build_drug_options_html($drugs, $placeholder) {
    $html = "<option value=''>" . htmlspecialchars($placeholder, ENT_QUOTES, 'UTF-8') . "</option>";
    foreach ($drugs as $d) {
        $icode = $d['icode'];
        $local = $d['name_local'];
        $tmt = $d['name_tmt'];
        $val = htmlspecialchars($icode . '|' . $tmt, ENT_QUOTES, 'UTF-8');
        $label = htmlspecialchars($local, ENT_QUOTES, 'UTF-8');
        if ($tmt !== '' && $tmt !== $local) {
            $label .= ' — ' . htmlspecialchars($tmt, ENT_QUOTES, 'UTF-8');
        }
        $label .= ' (icode: ' . htmlspecialchars($icode, ENT_QUOTES, 'UTF-8') . ')';
        $html .= "<option value=\"{$val}\">{$label}</option>";
    }
    return $html;
}

function hosxp_parse_lab_option($val) {
    $val = trim((string)$val);
    if ($val === '') {
        return ['code' => '', 'name' => ''];
    }
    $parts = explode('|', $val, 2);
    return [
        'code' => trim($parts[0]),
        'name' => trim($parts[1] ?? ''),
    ];
}

function hosxp_search_lab_items($con_hosxp, $term = '', $limit = 40) {
    $limit = max(1, min(80, (int)$limit));
    $where = "lab_items_code IS NOT NULL AND TRIM(lab_items_code) <> ''";
    $term = trim($term);
    if ($term !== '') {
        $t_esc = mysqli_real_escape_string($con_hosxp, $term);
        $where .= " AND (lab_items_code LIKE '%$t_esc%' OR lab_items_name LIKE '%$t_esc%')";
    }
    $sql = "
        SELECT lab_items_code,
               CAST(CONVERT(lab_items_name USING utf8) AS CHAR) AS lab_items_name
        FROM lab_items
        WHERE $where
        ORDER BY lab_items_name ASC
        LIMIT $limit
    ";
    $list = [];
    $q = mysqli_query($con_hosxp, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $code = trim($r['lab_items_code'] ?? '');
            if ($code === '') {
                continue;
            }
            $list[] = [
                'code' => $code,
                'name' => trim($r['lab_items_name'] ?? ''),
            ];
        }
    }
    return $list;
}

/** ตรวจเงื่อนไข Lab แบบข้อความ/ตัวเลข — ใช้ร่วม Monitor UA และ Monitor Lab อื่นๆ */
function monitor_lab_match_condition($cond_type, $cond_val, $lab_result) {
    $cond_type = trim((string)$cond_type);
    $cond_val = trim((string)$cond_val);
    $lab_result = trim((string)$lab_result);
    if ($cond_type === '' || $cond_type === 'range' || $lab_result === '') {
        return false;
    }
    if ($cond_type === 'regex') {
        return @preg_match('/' . $cond_val . '/i', $lab_result) === 1;
    }
    if ($cond_type === 'contains') {
        return stripos($lab_result, $cond_val) !== false;
    }
    if ($cond_type === 'less_than') {
        return floatval($lab_result) < floatval($cond_val);
    }
    if ($cond_type === 'greater_than') {
        return floatval($lab_result) > floatval($cond_val);
    }
    return false;
}

function monitor_lab_condition_type_label($type) {
    $labels = [
        'range' => 'ช่วงตัวเลข',
        'regex' => 'Regex (ข้อความ)',
        'contains' => 'มีคำว่า... (Text)',
        'less_than' => 'น้อยกว่า <',
        'greater_than' => 'มากกว่า >',
    ];
    return $labels[$type] ?? $type;
}

function monitor_lab_alert_level_from_rule($rule) {
    if (!empty($rule['alert_level']) && in_array($rule['alert_level'], ['hard', 'soft'], true)) {
        return $rule['alert_level'];
    }
    if (($rule['action_type'] ?? '') === 'omit') {
        return 'hard';
    }
    return 'soft';
}

function monitor_lab_patient_type($an, $vn = '') {
    $an = trim((string)$an);
    if ($an !== '' && $an !== '0') {
        return 'IPD';
    }
    return 'OPD';
}

function monitor_lab_patient_age_years($dob, $ref_date) {
    $dob = trim((string)$dob);
    $ref_date = trim((string)$ref_date);
    if ($dob === '' || $dob === '0000-00-00' || $ref_date === '' || $ref_date === '0000-00-00') {
        return 0;
    }
    try {
        return (new DateTime($ref_date))->diff(new DateTime($dob))->y;
    } catch (Exception $e) {
        return 0;
    }
}

function monitor_lab_match_patient_extra(array $rule, $age, $weight) {
    $use_age = !empty($rule['use_age_condition']);
    $use_weight = !empty($rule['use_weight_condition']);
    if (!$use_age && !$use_weight) {
        return true;
    }
    $age_ok = false;
    $weight_ok = false;
    if ($use_age) {
        $age_min = isset($rule['age_min']) && $rule['age_min'] !== '' && $rule['age_min'] !== null
            ? (float)$rule['age_min'] : 0;
        $age_max = isset($rule['age_max']) && $rule['age_max'] !== '' && $rule['age_max'] !== null
            ? (float)$rule['age_max'] : PHP_FLOAT_MAX;
        if ($age > 0 && $age >= $age_min && $age <= $age_max) {
            $age_ok = true;
        }
    }
    if ($use_weight) {
        $weight_min = isset($rule['weight_min']) && $rule['weight_min'] !== '' && $rule['weight_min'] !== null
            ? (float)$rule['weight_min'] : 0;
        $weight_max = isset($rule['weight_max']) && $rule['weight_max'] !== '' && $rule['weight_max'] !== null
            ? (float)$rule['weight_max'] : PHP_FLOAT_MAX;
        if ($weight > 0 && $weight >= $weight_min && $weight <= $weight_max) {
            $weight_ok = true;
        }
    }
    if ($use_age && $use_weight) {
        return $age_ok || $weight_ok;
    }
    if ($use_age) {
        return $age_ok;
    }
    return $weight_ok;
}

function monitor_lab_patient_extra_display(array $rule, $age, $weight) {
    $parts = [];
    if (!empty($rule['use_age_condition']) && $age > 0) {
        $parts[] = 'อายุ ' . $age . ' ปี';
    }
    if (!empty($rule['use_weight_condition']) && $weight > 0) {
        $parts[] = 'นน. ' . round($weight, 1) . ' kg';
    }
    return implode(' · ', $parts);
}

function ensure_drug_safety_rules_duration_columns($con) {
    static $done = false;
    if ($done) {
        return true;
    }
    $chk = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'use_duration_condition'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $done = true;
        return true;
    }

    $after = 'dose_unit';
    $w = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'weight_max'");
    if ($w && mysqli_num_rows($w) > 0) {
        $after = 'weight_max';
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE drug_safety_rules
                ADD COLUMN use_duration_condition TINYINT(1) NOT NULL DEFAULT 0 AFTER `$after`,
                ADD COLUMN duration_min DECIMAL(10,2) NULL DEFAULT NULL AFTER use_duration_condition,
                ADD COLUMN duration_max DECIMAL(10,2) NULL DEFAULT NULL AFTER duration_min"
        );
        if (!$altered) {
            return false;
        }
        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'use_duration_condition'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function hosxp_format_interval_hours($hours) {
    if ($hours === null || $hours <= 0) {
        return '-';
    }
    $h = (float)$hours;
    if (abs($h - round($h)) < 0.05) {
        return 'q ' . (int)round($h) . ' ชม.';
    }
    return 'q ' . rtrim(rtrim(number_format($h, 2, '.', ''), '0'), '.') . ' ชม.';
}

function hosxp_format_interval_range($min, $max) {
    $min = (float)$min;
    $max = (float)$max;
    $has_max = $max < (PHP_FLOAT_MAX / 2);
    if ($has_max && abs($min - $max) < 0.05) {
        return hosxp_format_interval_hours($min);
    }
    if (!$has_max) {
        return '≥ ' . hosxp_format_interval_hours($min);
    }
    if ($min <= 0) {
        return '≤ ' . hosxp_format_interval_hours($max);
    }
    return hosxp_format_interval_hours($min) . ' – ' . hosxp_format_interval_hours($max);
}

/**
 * ช่วงให้ยาจริง (ชั่วโมง) จากวิธีใช้ HOSxP เช่น q48h, ทุก 48 ชั่วโมง, วันละ 1 ครั้ง
 */
function hosxp_parse_interval_hours($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return null;
    }
    if (preg_match('/\b(?:stat|asap|now)\b/iu', $m)
        || preg_match('/ครั้งเดียว|ทันที|ฉุกเฉิน/u', $m)
    ) {
        return null;
    }
    if (preg_match('/วันเว้นวัน/u', $m) || preg_match('/\b(?:qod|q\.o\.d\.)\b/i', $m)) {
        return 48.0;
    }
    if (preg_match('/ทุก\s*(\d+(?:\.\d+)?)\s*วัน/ui', $m, $iv)
        || preg_match('/every\s*(\d+(?:\.\d+)?)\s*days?\b/i', $m, $iv)
        || preg_match('/\bq\s*\.?\s*(\d+(?:\.\d+)?)\s*d(?:ays?)?\b/i', $m, $iv)
    ) {
        $days = (float)$iv[1];
        if ($days > 0) {
            return $days * 24.0;
        }
    }
    if (preg_match('/ทุก\s*(\d+(?:\.\d+)?)\s*(?:ชั่วโมง|ชม\.?|hr|hrs?|hours?)\b/ui', $m, $iv)
        || preg_match('/\bq\s*\.?\s*(\d+(?:\.\d+)?)\s*(?:h|hr|hrs?|hours?|ชม\.?)\b/i', $m, $iv)
        || preg_match('/every\s*(\d+(?:\.\d+)?)\s*(?:h|hr|hrs?|hours?)\b/i', $m, $iv)
    ) {
        $hours = (float)$iv[1];
        if ($hours > 0) {
            return $hours;
        }
    }
    if (preg_match('/วันละ\s*(\d+(?:\.\d+)?)\s*ครั้ง/ui', $m, $tp)) {
        $n = (float)$tp[1];
        if ($n > 0) {
            return 24.0 / $n;
        }
    }
    if (preg_match('/\b(qid|q\.i\.d\.)/i', $m)) {
        return 6.0;
    }
    if (preg_match('/\b(tid|t\.i\.d\.)/i', $m)) {
        return 8.0;
    }
    if (preg_match('/\b(bid|b\.i\.d\.)/i', $m)) {
        return 12.0;
    }
    if (preg_match('/\b(od|qd|q\.d\.|hs|h\.s\.)\b/i', $m)) {
        return 24.0;
    }
    $meal_count = hosxp_usage_meal_slot_count($m);
    return $meal_count > 0 ? (24.0 / (float)$meal_count) : null;
}

/**
 * ตรวจช่วงให้ยาของกฎ Lab
 * skip_alert = เปิดเงื่อนไขแล้วช่วงให้ยาจริงอยู่ในเกณฑ์ (ไม่ต้องเตือน)
 */
function monitor_lab_duration_check(array $rule, $method) {
    $enabled = !empty($rule['use_duration_condition']);
    $result = [
        'enabled' => $enabled,
        'ok' => true,
        'skip_alert' => false,
        'actual_hours' => null,
        'min' => null,
        'max' => null,
        'actual_text' => '',
        'recommended_text' => '',
        'fail_text' => '',
    ];
    if (!$enabled) {
        return $result;
    }
    $min = isset($rule['duration_min']) && $rule['duration_min'] !== '' && $rule['duration_min'] !== null
        ? (float)$rule['duration_min'] : 0;
    $max = isset($rule['duration_max']) && $rule['duration_max'] !== '' && $rule['duration_max'] !== null
        ? (float)$rule['duration_max'] : PHP_FLOAT_MAX;
    $result['min'] = $min;
    $result['max'] = $max;
    $result['recommended_text'] = hosxp_format_interval_range($min, $max);
    $hours = hosxp_parse_interval_hours($method);
    $result['actual_hours'] = $hours;
    $result['actual_text'] = hosxp_format_interval_hours($hours);
    if ($hours === null || $hours <= 0) {
        $result['ok'] = false;
        $result['fail_text'] = 'ไม่ผ่าน (อ่านช่วงให้ยาจากวิธีใช้ไม่ได้ — ควรเป็น ' . $result['recommended_text'] . ')';
        return $result;
    }
    if ($hours < $min || $hours > $max) {
        $result['ok'] = false;
        $result['fail_text'] = 'ไม่ผ่าน (ช่วงให้ยา ' . $result['actual_text'] . ' ควรเป็น ' . $result['recommended_text'] . ')';
        return $result;
    }
    $result['skip_alert'] = true;
    return $result;
}

function ensure_drug_safety_rules_dose_per_admin_columns($con) {
    static $done = false;
    if ($done) {
        return true;
    }
    $chk = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'use_dose_per_admin_condition'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $done = true;
        return true;
    }

    $after = 'dose_unit';
    $u = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'dose_unit'");
    if (!$u || mysqli_num_rows($u) === 0) {
        $after = 'dose_max';
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE drug_safety_rules
                ADD COLUMN use_dose_per_admin_condition TINYINT(1) NOT NULL DEFAULT 0
                    COMMENT '1=ใช้ช่วงขนาดยาต่อครั้ง (mg/ครั้ง)' AFTER `$after`,
                ADD COLUMN dose_per_admin_min DECIMAL(12,2) NULL DEFAULT NULL
                    COMMENT 'mg ต่อครั้ง ต่ำสุด' AFTER use_dose_per_admin_condition,
                ADD COLUMN dose_per_admin_max DECIMAL(12,2) NULL DEFAULT NULL
                    COMMENT 'mg ต่อครั้ง สูงสุด' AFTER dose_per_admin_min"
        );
        if (!$altered) {
            return false;
        }
        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'use_dose_per_admin_condition'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function ensure_drug_safety_rules_exempt_method_columns($con) {
    static $done = false;
    if ($done) {
        return true;
    }
    $chk = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'exempt_method_patterns'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $col = mysqli_fetch_assoc($chk);
        $type = strtolower((string)($col['Type'] ?? ''));
        if (strpos($type, 'varchar') !== false) {
            $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
            @mysqli_query($con, "ALTER TABLE drug_safety_rules MODIFY COLUMN exempt_method_patterns TEXT NULL
                COMMENT 'คำในวิธีใช้ที่ยกเว้นการเตือน คั่นด้วยจุลภาคหรือขึ้นบรรทัดใหม่'");
            mysqli_report($prev_mode);
        }
        $done = true;
        return true;
    }

    $after = 'suggestion_msg';
    $d = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'duration_max'");
    if ($d && mysqli_num_rows($d) > 0) {
        $after = 'duration_max';
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE drug_safety_rules
                ADD COLUMN exempt_method_patterns TEXT NULL
                COMMENT 'คำในวิธีใช้ที่ยกเว้นการเตือน คั่นด้วยจุลภาคหรือขึ้นบรรทัดใหม่'
                AFTER `$after`"
        );
        if (!$altered) {
            return false;
        }
        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'exempt_method_patterns'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function ensure_drug_safety_rules_first_order_columns($con) {
    static $done = false;
    if ($done) {
        return true;
    }
    $chk = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'first_order_only'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $done = true;
        return true;
    }

    $after = 'exempt_method_patterns';
    $e = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'exempt_method_patterns'");
    if (!$e || mysqli_num_rows($e) === 0) {
        $d = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'duration_max'");
        $after = ($d && mysqli_num_rows($d) > 0) ? 'duration_max' : 'suggestion_msg';
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE drug_safety_rules
                ADD COLUMN first_order_only TINYINT(1) NOT NULL DEFAULT 0
                    COMMENT '1=เตือนเฉพาะการสั่งยาครั้งแรก (ห้ามเริ่มยา)' AFTER `$after`,
                ADD COLUMN first_order_lookback_days INT NOT NULL DEFAULT 0
                    COMMENT '0=เคยมีใบยาใดๆ มาก่อนถือว่ากินต่อ; >0=ไม่มีใบยาในช่วงนี้ถือว่าเริ่มใหม่' AFTER first_order_only"
        );
        if (!$altered) {
            return false;
        }
        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'first_order_only'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function monitor_lab_hn_key($hn) {
    $t = ltrim((string)$hn, '0');
    return $t === '' ? '0' : $t;
}

function monitor_lab_first_order_map_key($hn, $icode) {
    return monitor_lab_hn_key($hn) . '|' . trim((string)$icode);
}

function monitor_lab_hn_list_sql_in($hos, array $hns) {
    $vars = [];
    foreach ($hns as $hn) {
        $trimmed = ltrim((string)$hn, '0');
        if ($trimmed === '') {
            $trimmed = '0';
        }
        $vars[str_pad($trimmed, 9, '0', STR_PAD_LEFT)] = true;
        $vars[$trimmed] = true;
    }
    if (empty($vars)) {
        return "''";
    }
    $esc = [];
    foreach (array_keys($vars) as $v) {
        $esc[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return implode(',', $esc);
}

/**
 * Prefetch วันที่สั่งยาครั้งแรก (และรายการวันที่ในช่วง lookback) ต่อ HN+icode
 * @return array<string, array{first_date:string, dates:array}>
 */
function monitor_lab_prefetch_first_orders($hos, array $hns, array $icodes, $end_date, $lookback_days = 0, $range_start = null) {
    $out = [];
    $hns = array_values(array_filter(array_map('strval', $hns)));
    $icode_esc = [];
    foreach ($icodes as $ic) {
        $ic = trim((string)$ic);
        if ($ic !== '') {
            $icode_esc[] = "'" . mysqli_real_escape_string($hos, $ic) . "'";
        }
    }
    if (empty($hns) || empty($icode_esc)) {
        return $out;
    }
    $hn_in = monitor_lab_hn_list_sql_in($hos, $hns);
    $icode_in = implode(',', $icode_esc);
    $end_esc = mysqli_real_escape_string($hos, $end_date);
    $date_expr = "COALESCE(NULLIF(o.rxdate,'0000-00-00'), NULLIF(o.vstdate,'0000-00-00'))";

    $q = mysqli_query(
        $hos,
        "SELECT o.hn, o.icode, MIN($date_expr) AS first_date
         FROM opitemrece o
         WHERE o.icode IN ($icode_in)
           AND o.hn IN ($hn_in)
           AND o.qty > 0
           AND $date_expr IS NOT NULL
           AND $date_expr <= '$end_esc'
         GROUP BY o.hn, o.icode"
    );
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $key = monitor_lab_first_order_map_key($r['hn'], $r['icode']);
            $out[$key] = [
                'first_date' => trim((string)($r['first_date'] ?? '')),
                'dates' => [],
            ];
        }
    }

    $lookback_days = (int)$lookback_days;
    if ($lookback_days > 0 && !empty($out)) {
        $anchor = trim((string)($range_start ?: $end_date));
        if ($anchor === '' || $anchor === '0000-00-00') {
            $anchor = $end_date;
        }
        $start = date('Y-m-d', strtotime($anchor . ' -' . $lookback_days . ' days'));
        $start_esc = mysqli_real_escape_string($hos, $start);
        $q2 = mysqli_query(
            $hos,
            "SELECT DISTINCT o.hn, o.icode, $date_expr AS od
             FROM opitemrece o
             WHERE o.icode IN ($icode_in)
               AND o.hn IN ($hn_in)
               AND o.qty > 0
               AND $date_expr IS NOT NULL
               AND $date_expr >= '$start_esc'
               AND $date_expr <= '$end_esc'"
        );
        if ($q2) {
            while ($r = mysqli_fetch_assoc($q2)) {
                $key = monitor_lab_first_order_map_key($r['hn'], $r['icode']);
                $od = trim((string)($r['od'] ?? ''));
                if ($od === '' || !isset($out[$key])) {
                    continue;
                }
                $out[$key]['dates'][$od] = true;
            }
        }
    }
    return $out;
}

/**
 * ตรวจกฎ first_order_only
 * skip_alert=true เมื่อผู้ป่วยเคยได้รับยานี้มาแล้ว (กินต่อได้ ไม่ใช่การเริ่มยา)
 */
function monitor_lab_first_order_check(array $rule, array $first_map, $hn, $icode, $order_date, $order_time = '') {
    unset($order_time);
    $empty = ['enabled' => false, 'is_first' => true, 'skip_alert' => false, 'text' => ''];
    if (empty($rule['first_order_only'])) {
        return $empty;
    }
    $order_date = trim((string)$order_date);
    if ($order_date === '' || $order_date === '0000-00-00') {
        return ['enabled' => true, 'is_first' => true, 'skip_alert' => false, 'text' => ''];
    }
    $key = monitor_lab_first_order_map_key($hn, $icode);
    $row = $first_map[$key] ?? null;
    $lookback = max(0, (int)($rule['first_order_lookback_days'] ?? 0));

    if ($lookback > 0) {
        $window_start = date('Y-m-d', strtotime($order_date . ' -' . $lookback . ' days'));
        $has_prior = false;
        foreach (array_keys($row['dates'] ?? []) as $od) {
            if ($od < $order_date && $od >= $window_start) {
                $has_prior = true;
                break;
            }
        }
        if ($has_prior) {
            return [
                'enabled' => true,
                'is_first' => false,
                'skip_alert' => true,
                'text' => 'กินยามาแล้ว (มีใบยาก่อนหน้าภายใน ' . $lookback . ' วัน) — ไม่ใช่การเริ่มยาครั้งแรก',
            ];
        }
        return ['enabled' => true, 'is_first' => true, 'skip_alert' => false, 'text' => ''];
    }

    $first_date = trim((string)($row['first_date'] ?? ''));
    if ($first_date === '' || $first_date >= $order_date) {
        return ['enabled' => true, 'is_first' => true, 'skip_alert' => false, 'text' => ''];
    }
    return [
        'enabled' => true,
        'is_first' => false,
        'skip_alert' => true,
        'text' => 'กินยามาแล้ว (ใบยาครั้งแรก ' . date('d/m/Y', strtotime($first_date)) . ') — ไม่ใช่การเริ่มยาครั้งแรก',
    ];
}

/** คืนคำที่ยกเว้นที่เจอในวิธีใช้ หรือ '' ถ้าไม่เข้าข้อยกเว้น */
function monitor_lab_match_exempt_method($method, $patterns_str) {
    $method = trim((string)$method);
    $patterns_str = trim((string)$patterns_str);
    if ($method === '' || $patterns_str === '') {
        return '';
    }
    $parts = preg_split('/[,;|\n]+/u', $patterns_str);
    if (!$parts) {
        return '';
    }
    foreach ($parts as $p) {
        $p = trim($p);
        if ($p === '') {
            continue;
        }
        $escaped = preg_quote($p, '/');
        $escaped = preg_replace('/\\\\\s+/u', '\\s*', $escaped);
        $escaped = str_replace(' ', '\\s*', $escaped);
        if (@preg_match('/' . $escaped . '/iu', $method)) {
            return $p;
        }
    }
    return '';
}

function monitor_lab_should_exempt_method(array $rule, $method) {
    return monitor_lab_match_exempt_method($method, $rule['exempt_method_patterns'] ?? '') !== '';
}

/** รวมคำยกเว้นจากทุกกฎของยาเดียวกัน (icode เดียวกัน) */
function monitor_lab_normalize_exempt_patterns($raw) {
    $parts = preg_split('/[,;|\n]+/u', (string)$raw);
    if (!$parts) {
        return '';
    }
    $out = [];
    $seen = [];
    foreach ($parts as $p) {
        $p = trim((string)$p);
        if ($p === '') {
            continue;
        }
        $key = function_exists('mb_strtolower') ? mb_strtolower($p, 'UTF-8') : strtolower($p);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = $p;
    }
    return implode(', ', $out);
}

function monitor_lab_sync_exempt_patterns($con, $icode, $patterns) {
    $icode = trim((string)$icode);
    if ($icode === '' || !ensure_drug_safety_rules_exempt_method_columns($con)) {
        return false;
    }
    $patterns = monitor_lab_normalize_exempt_patterns($patterns);
    $icode_esc = mysqli_real_escape_string($con, $icode);
    $sql_val = $patterns !== ''
        ? "'" . mysqli_real_escape_string($con, $patterns) . "'"
        : 'NULL';
    return (bool)mysqli_query($con, "UPDATE drug_safety_rules SET exempt_method_patterns=$sql_val WHERE drug_icode='$icode_esc'");
}

function monitor_lab_collect_exempt_patterns(array $rules) {
    $chunks = [];
    $seen = [];
    foreach ($rules as $rule) {
        $s = trim((string)($rule['exempt_method_patterns'] ?? ''));
        if ($s === '' || isset($seen[$s])) {
            continue;
        }
        $seen[$s] = true;
        $chunks[] = $s;
    }
    return monitor_lab_normalize_exempt_patterns(implode(', ', $chunks));
}

function monitor_lab_match_exempt_method_from_rules($method, array $rules) {
    return monitor_lab_match_exempt_method($method, monitor_lab_collect_exempt_patterns($rules));
}

function monitor_lab_should_exempt_method_from_rules(array $rules, $method) {
    return monitor_lab_match_exempt_method_from_rules($method, $rules) !== '';
}

function ensure_drug_safety_rules_alert_level_column($con) {
    static $done = false;
    if ($done) {
        return true;
    }
    $chk = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'alert_level'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $done = true;
        return true;
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE drug_safety_rules
                ADD COLUMN alert_level VARCHAR(8) NOT NULL DEFAULT 'soft' COMMENT 'hard | soft'
                AFTER suggestion_msg"
        );
        if (!$altered) {
            return false;
        }

        mysqli_query(
            $con,
            "UPDATE drug_safety_rules
             SET alert_level = IF(action_type = 'omit', 'hard', 'soft')
             WHERE alert_level IS NULL OR TRIM(alert_level) = ''"
        );

        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'alert_level'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function ensure_drug_safety_rules_hosxp_columns($con) {
    static $done = false;
    if ($done) {
        return true;
    }
    $chk = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'drug_icode'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $done = true;
        return true;
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE drug_safety_rules
                ADD COLUMN drug_icode VARCHAR(20) NULL DEFAULT NULL,
                ADD COLUMN drug_name VARCHAR(255) NULL DEFAULT NULL"
        );
        if (!$altered) {
            return false;
        }

        mysqli_query(
            $con,
            "UPDATE drug_safety_rules r
             INNER JOIN drugitems d ON r.drug_id = d.id
             SET r.drug_icode = d.icode,
                 r.drug_name = d.name
             WHERE (r.drug_icode IS NULL OR TRIM(r.drug_icode) = '')
               AND d.icode IS NOT NULL
               AND TRIM(d.icode) <> ''"
        );

        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'drug_icode'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function ensure_drug_safety_rules_lab_condition_columns($con) {
    static $done = false;
    if ($done) {
        return true;
    }
    $chk = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'lab_condition_type'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $done = true;
        return true;
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE drug_safety_rules
                ADD COLUMN lab_condition_type VARCHAR(32) NOT NULL DEFAULT 'range' AFTER lab_items_name,
                ADD COLUMN lab_condition_value VARCHAR(255) NULL DEFAULT NULL AFTER lab_condition_type"
        );
        if (!$altered) {
            return false;
        }
        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'lab_condition_type'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function ensure_drug_safety_rules_lab_items_columns($con) {
    static $done = false;
    if ($done) {
        return true;
    }
    $chk = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'lab_items_code'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $done = true;
        return true;
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE drug_safety_rules
                ADD COLUMN lab_items_code VARCHAR(20) NULL DEFAULT NULL AFTER lab_type,
                ADD COLUMN lab_items_name VARCHAR(255) NULL DEFAULT NULL AFTER lab_items_code"
        );
        if (!$altered) {
            return false;
        }
        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'lab_items_code'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function ensure_drug_safety_rules_patient_extra_columns($con) {
    static $done = false;
    if ($done) {
        return true;
    }
    $chk = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'use_age_condition'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $done = true;
        return true;
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE drug_safety_rules
                ADD COLUMN use_age_condition TINYINT(1) NOT NULL DEFAULT 0 AFTER dose_unit,
                ADD COLUMN age_min DECIMAL(10,2) NULL DEFAULT NULL AFTER use_age_condition,
                ADD COLUMN age_max DECIMAL(10,2) NULL DEFAULT NULL AFTER age_min,
                ADD COLUMN use_weight_condition TINYINT(1) NOT NULL DEFAULT 0 AFTER age_max,
                ADD COLUMN weight_min DECIMAL(10,2) NULL DEFAULT NULL AFTER use_weight_condition,
                ADD COLUMN weight_max DECIMAL(10,2) NULL DEFAULT NULL AFTER weight_min"
        );
        if (!$altered) {
            return false;
        }
        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM drug_safety_rules LIKE 'use_age_condition'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function ensure_di_pdf_columns($con) {
    $chk = mysqli_query($con, "SHOW COLUMNS FROM monitor_drug_interaction_settings LIKE 'pdf_onset'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return true;
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE monitor_drug_interaction_settings
                ADD COLUMN pdf_onset VARCHAR(32) NOT NULL DEFAULT '' COMMENT 'Rapid / Delayed / Not specified' AFTER detail_text,
                ADD COLUMN pdf_severity VARCHAR(32) NOT NULL DEFAULT '' COMMENT 'Contraindicated / Major / Moderate' AFTER pdf_onset,
                ADD COLUMN pdf_documentation VARCHAR(32) NOT NULL DEFAULT '' COMMENT 'Excellent / Good / Fair / Poor' AFTER pdf_severity,
                ADD COLUMN pdf_reference TEXT NULL AFTER pdf_documentation"
        );
        if (!$altered) {
            return false;
        }
        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM monitor_drug_interaction_settings LIKE 'pdf_onset'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function di_pdf_onset_options() {
    return [
        '' => '- ไม่ระบุ -',
        'Rapid' => 'Rapid',
        'Delayed' => 'Delayed',
        'Not specified' => 'Not specified',
    ];
}

function di_pdf_severity_options() {
    return [
        '' => '- ตามระดับ Alert -',
        'Contraindicated' => 'Contraindicated',
        'Major' => 'Major',
        'Moderate' => 'Moderate',
        'Minor' => 'Minor',
    ];
}

function di_pdf_documentation_options() {
    return [
        '' => '- ไม่ระบุ -',
        'Excellent' => 'Excellent',
        'Good' => 'Good',
        'Fair' => 'Fair',
        'Poor' => 'Poor',
    ];
}

function di_pdf_severity_label($row) {
    $v = trim((string)($row['pdf_severity'] ?? ''));
    if ($v !== '') {
        return $v;
    }
    if (function_exists('di_alert_level_from_row')) {
        $lvl = di_alert_level_from_row($row);
    } elseif (!empty($row['alert_level']) && in_array($row['alert_level'], ['hard', 'soft'], true)) {
        $lvl = $row['alert_level'];
    } elseif (isset($row['severity']) && (int)$row['severity'] >= 3) {
        $lvl = 'hard';
    } else {
        $lvl = 'soft';
    }
    return $lvl === 'hard' ? 'Contraindicated' : 'Major';
}

function ensure_di_dose_columns($con) {
    $chk = mysqli_query($con, "SHOW COLUMNS FROM monitor_drug_interaction_settings LIKE 'use_dose1_condition'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return true;
    }

    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        $altered = mysqli_query(
            $con,
            "ALTER TABLE monitor_drug_interaction_settings
                ADD COLUMN use_dose1_condition TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'เงื่อนไขขนาดยา 1' AFTER lookback_days,
                ADD COLUMN dose1_min DECIMAL(10,2) NULL DEFAULT NULL COMMENT 'mg/วัน ยา 1' AFTER use_dose1_condition,
                ADD COLUMN dose1_max DECIMAL(10,2) NULL DEFAULT NULL COMMENT 'mg/วัน ยา 1' AFTER dose1_min,
                ADD COLUMN use_dose2_condition TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'เงื่อนไขขนาดยา 2' AFTER dose1_max,
                ADD COLUMN dose2_min DECIMAL(10,2) NULL DEFAULT NULL COMMENT 'mg/วัน ยา 2' AFTER use_dose2_condition,
                ADD COLUMN dose2_max DECIMAL(10,2) NULL DEFAULT NULL COMMENT 'mg/วัน ยา 2' AFTER dose2_min"
        );
        if (!$altered) {
            return false;
        }
        $chk2 = mysqli_query($con, "SHOW COLUMNS FROM monitor_drug_interaction_settings LIKE 'use_dose1_condition'");
        return $chk2 && mysqli_num_rows($chk2) > 0;
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function ensure_di_check_mode_column($con) {
    $chk = @mysqli_query($con, "SHOW COLUMNS FROM monitor_drug_interaction_settings LIKE 'check_mode'");
    if (!$chk || mysqli_num_rows($chk) === 0) {
        return false;
    }
    $row = mysqli_fetch_assoc($chk);
    $type = strtolower((string)($row['Type'] ?? ''));
    if (strpos($type, 'varchar') !== false && strpos($type, 'enum') === false) {
        return true;
    }
    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        return (bool)mysqli_query(
            $con,
            "ALTER TABLE monitor_drug_interaction_settings
             MODIFY check_mode VARCHAR(16) NOT NULL DEFAULT 'same_visit'
             COMMENT 'same_visit | same_rx | lookback'"
        );
    } catch (mysqli_sql_exception $e) {
        return false;
    } finally {
        mysqli_report($prev_mode);
    }
}

function di_normalize_check_mode($mode) {
    $mode = trim((string)$mode);
    if ($mode === 'lookback') {
        return 'lookback';
    }
    if ($mode === 'same_rx') {
        return 'same_rx';
    }
    return 'same_visit';
}

function di_is_group_token($icode) {
    return strncasecmp(trim((string)$icode), 'GROUP:', 6) === 0;
}

function di_group_key_of($icode) {
    $icode = trim((string)$icode);
    if (!di_is_group_token($icode)) {
        return '';
    }
    return strtolower(substr($icode, 6));
}

function di_group_catalog() {
    return [
        'mtx_tab' => [
            'label' => 'Methotrexate tablet',
            'keys' => ['methotrexate', 'เมโธเทรกเซท', 'เมโทเทรกเซท', 'เมโธเทรกเซต'],
            'require_any' => ['tab', 'tablet', 'เม็ด', '2.5'],
            'exclude' => [
                'inj', 'injection', 'amp', 'ampoule', 'vial', 'syringe', ' iv', ' im', ' sc',
                'ฉีด', 'แอมพูล', 'แอมปูล', 'ไวอัล', 'syr',
            ],
        ],
        'nsaid' => [
            'label' => 'กลุ่มยา NSAIDs',
            'keys' => [
                'diclofenac', 'ibuprofen', 'naproxen', 'mefenamic', 'piroxicam', 'meloxicam',
                'celecoxib', 'etoricoxib', 'aceclofenac', 'ketorolac', 'indomethacin', 'indometacin',
                'dexibuprofen', 'tenoxicam', 'etodolac', 'loxoprofen', 'sulindac', 'ketoprofen',
                'ไดโคลฟีแนค', 'ไดโคลฟีเนค', 'ไอบูโพรเฟน', 'นาโพรเซน', 'กรดเมฟีนา', 'เมเฟนามิก',
                'ไพร็อกซิแคม', 'เมโลซิแคม', 'เซเลคอกซิบ', 'อีทอริคอกซิบ', 'เอซคลอฟีแนค', 'คีโตโรแลค',
            ],
            'exclude' => [
                'aspirin', 'acetylsalic', 'asa 81', 'แอสไพริน',
                'norgesic', 'orphenadrine',
                'gel', 'cream', 'ointment', 'topical', 'เจล', 'ครีม', 'ขี้ผึ้ง',
            ],
        ],
    ];
}

function di_group_option_value($key) {
    $cat = di_group_catalog();
    $label = $cat[$key]['label'] ?? $key;
    return 'GROUP:' . $key . '|' . $label;
}

function di_group_options_html() {
    $html = '';
    foreach (di_group_catalog() as $key => $g) {
        $val = htmlspecialchars(di_group_option_value($key), ENT_QUOTES, 'UTF-8');
        $label = htmlspecialchars('กลุ่ม: ' . ($g['label'] ?? $key), ENT_QUOTES, 'UTF-8');
        $html .= '<option value="' . $val . '">' . $label . '</option>';
    }
    return $html;
}

function di_blob_lower($s) {
    $s = (string)$s;
    return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
}

function di_blob_has_any($blob, array $keys) {
    foreach ($keys as $k) {
        $k = di_blob_lower(trim((string)$k));
        if ($k === '') {
            continue;
        }
        if (function_exists('mb_strpos')) {
            if (mb_strpos($blob, $k) !== false) {
                return true;
            }
        } elseif (strpos($blob, $k) !== false) {
            return true;
        }
    }
    return false;
}

function di_group_match_drugs(array $drugs, $group_key) {
    $group_key = strtolower(trim((string)$group_key));
    $def = di_group_catalog()[$group_key] ?? null;
    if (!$def) {
        return [];
    }
    $out = [];
    foreach ($drugs as $d) {
        $blob = di_blob_lower(trim(($d['name_tmt'] ?? '') . ' ' . ($d['name_local'] ?? '') . ' ' . ($d['icode'] ?? '')));
        if ($blob === '') {
            continue;
        }
        if (!empty($def['exclude']) && di_blob_has_any($blob, $def['exclude'])) {
            continue;
        }
        if (!empty($def['keys']) && !di_blob_has_any($blob, $def['keys'])) {
            continue;
        }
        if (!empty($def['require_any']) && !di_blob_has_any($blob, $def['require_any'])) {
            continue;
        }
        $ic = trim((string)($d['icode'] ?? ''));
        if ($ic === '' || di_is_group_token($ic)) {
            continue;
        }
        $out[$ic] = $d;
    }
    return array_values($out);
}

function di_expand_icode_token($hos, $token, $drugs_cache = []) {
    $token = trim((string)$token);
    if ($token === '' || di_is_group_token($token)) {
        $gkey = di_group_key_of($token);
        if ($gkey === '') {
            return [];
        }
        if (!is_array($drugs_cache) || empty($drugs_cache)) {
            return [];
        }
        $matched = di_group_match_drugs($drugs_cache, $gkey);
        $ics = [];
        foreach ($matched as $d) {
            $ic = trim((string)($d['icode'] ?? ''));
            if ($ic !== '') {
                $ics[$ic] = true;
            }
        }
        return array_keys($ics);
    }
    return [$token];
}

function di_prepare_rules_icodes($hos, array $rules) {
    $need_catalog = false;
    foreach ($rules as $rule) {
        if (di_is_group_token($rule['drug_icode'] ?? '') || di_is_group_token($rule['hosxp_icode'] ?? '')) {
            $need_catalog = true;
            break;
        }
    }
    $catalog = [];
    if ($need_catalog && $hos) {
        $loaded = hosxp_fetch_active_drugs_tmt($hos);
        $catalog = is_array($loaded) ? $loaded : [];
    }
    foreach ($rules as &$rule) {
        $rule['_icodes_a'] = di_expand_icode_token($hos, $rule['drug_icode'] ?? '', $catalog);
        $rule['_icodes_b'] = di_expand_icode_token($hos, $rule['hosxp_icode'] ?? '', $catalog);
    }
    unset($rule);
    return $rules;
}

function di_rules_scan_icodes(array $rules) {
    $set = [];
    foreach ($rules as $rule) {
        foreach (array_merge($rule['_icodes_a'] ?? [], $rule['_icodes_b'] ?? []) as $ic) {
            $ic = trim((string)$ic);
            if ($ic === '' || di_is_group_token($ic)) {
                continue;
            }
            $set[$ic] = true;
        }
        foreach ([trim((string)($rule['drug_icode'] ?? '')), trim((string)($rule['hosxp_icode'] ?? ''))] as $ic) {
            if ($ic !== '' && !di_is_group_token($ic)) {
                $set[$ic] = true;
            }
        }
    }
    return array_keys($set);
}

function di_same_rx_key(array $o) {
    $hn = ltrim((string)($o['hn'] ?? ''), '0');
    if ($hn === '') {
        $hn = '0';
    }
    $order_no = trim((string)($o['order_no'] ?? ''));
    if ($order_no !== '' && $order_no !== '0') {
        return $hn . '|ord|' . $order_no;
    }
    $vn = trim((string)($o['vn'] ?? ''));
    $rxdate = trim((string)($o['rxdate'] ?? ''));
    if ($rxdate === '' || $rxdate === '0000-00-00') {
        $rxdate = trim((string)($o['vstdate'] ?? ''));
    }
    $rxtime = function_exists('di_format_time')
        ? di_format_time($o['rxtime'] ?? '')
        : trim((string)($o['rxtime'] ?? ''));
    if ($rxtime === '' || $rxtime === '00:00') {
        $rxtime = function_exists('di_format_time')
            ? di_format_time($o['vsttime'] ?? '')
            : trim((string)($o['vsttime'] ?? ''));
    }
    if ($vn === '' && $rxdate === '') {
        return '';
    }
    return $hn . '|rx|' . $vn . '|' . $rxdate . '|' . $rxtime;
}

function di_ensure_mtx_nsaid_soft_rule($con, array $hosxp_drugs = []) {
    return di_ensure_mtx_nsaid_soft_pairs($con, $hosxp_drugs);
}

function di_ensure_mtx_nsaid_soft_pairs($con, array $hosxp_drugs = []) {
    ensure_di_check_mode_column($con);
    @mysqli_query(
        $con,
        "DELETE FROM monitor_drug_interaction_settings
         WHERE drug_icode IN ('GROUP:mtx_tab','GROUP:nsaid')
            OR hosxp_icode IN ('GROUP:mtx_tab','GROUP:nsaid')"
    );

    $flag_q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='di_mtx_nsaid_pairs_v2' LIMIT 1");
    if ($flag_q && ($fr = mysqli_fetch_assoc($flag_q)) && (string)$fr['config_value'] === '1') {
        return ['ok' => true, 'inserted' => 0, 'skipped' => 0, 'mtx' => 0, 'nsaid' => 0, 'done' => true];
    }
    if (empty($hosxp_drugs)) {
        return ['ok' => false, 'inserted' => 0, 'skipped' => 0, 'mtx' => 0, 'nsaid' => 0, 'missing' => 'ยังไม่ได้โหลดรายการยา HOSxP'];
    }

    $mtx = di_group_match_drugs($hosxp_drugs, 'mtx_tab');
    $nsaids = di_group_match_drugs($hosxp_drugs, 'nsaid');
    if (empty($mtx) || empty($nsaids)) {
        $missing = [];
        if (empty($mtx)) {
            $missing[] = 'ไม่พบ Methotrexate tablet ใน HOSxP';
        }
        if (empty($nsaids)) {
            $missing[] = 'ไม่พบยา NSAIDs ใน HOSxP';
        }
        return [
            'ok' => false,
            'inserted' => 0,
            'skipped' => 0,
            'mtx' => count($mtx),
            'nsaid' => count($nsaids),
            'missing' => implode(', ', $missing),
        ];
    }

    $detail = mysqli_real_escape_string(
        $con,
        "Methotrexate tablet ร่วมกับ NSAIDs ลดการขับ MTX ทางไต เสี่ยงพิษ (myelosuppression, mucositis, AKI) — จับเฉพาะใบสั่งยาเดียวกัน"
    );
    $inserted = 0;
    $skipped = 0;
    $errors = 0;
    foreach ($mtx as $da) {
        $ic_a = trim((string)($da['icode'] ?? ''));
        if ($ic_a === '') {
            continue;
        }
        $name_a = trim((string)(($da['name_tmt'] ?? '') !== '' ? $da['name_tmt'] : ($da['name_local'] ?? $ic_a)));
        foreach ($nsaids as $db) {
            $ic_b = trim((string)($db['icode'] ?? ''));
            if ($ic_b === '' || $ic_a === $ic_b) {
                continue;
            }
            if (function_exists('di_fatal_find_existing') && di_fatal_find_existing($con, $ic_a, $ic_b)) {
                $skipped++;
                continue;
            }
            $exist = @mysqli_query(
                $con,
                "SELECT id FROM monitor_drug_interaction_settings
                 WHERE (drug_icode='" . mysqli_real_escape_string($con, $ic_a) . "' AND hosxp_icode='" . mysqli_real_escape_string($con, $ic_b) . "')
                    OR (drug_icode='" . mysqli_real_escape_string($con, $ic_b) . "' AND hosxp_icode='" . mysqli_real_escape_string($con, $ic_a) . "')
                 LIMIT 1"
            );
            if ($exist && mysqli_num_rows($exist) > 0) {
                $skipped++;
                continue;
            }
            $name_b = trim((string)(($db['name_tmt'] ?? '') !== '' ? $db['name_tmt'] : ($db['name_local'] ?? $ic_b)));
            $sql = "INSERT INTO monitor_drug_interaction_settings
                (drug_id, drug_name, drug_icode, hosxp_icode, hosxp_drug_name, interaction_type, alert_level, detail_text,
                 check_mode, lookback_days, active_status)
                VALUES (0, '" . mysqli_real_escape_string($con, $name_a) . "',
                        '" . mysqli_real_escape_string($con, $ic_a) . "',
                        '" . mysqli_real_escape_string($con, $ic_b) . "',
                        '" . mysqli_real_escape_string($con, $name_b) . "',
                        'drug_drug', 'soft', '$detail', 'same_rx', 0, 1)";
            if (mysqli_query($con, $sql)) {
                $inserted++;
            } else {
                $errors++;
            }
        }
    }

    if ($errors === 0) {
        @mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('di_mtx_nsaid_pairs_v2','1')
            ON DUPLICATE KEY UPDATE config_value='1'");
    }

    return [
        'ok' => $inserted > 0 || $skipped > 0,
        'inserted' => $inserted,
        'skipped' => $skipped,
        'mtx' => count($mtx),
        'nsaid' => count($nsaids),
        'errors' => $errors,
    ];
}

function di_each_matching_pair(array $rule, array $idx, array $opts, callable $on_pair) {
    $mode = di_normalize_check_mode($rule['check_mode'] ?? 'same_visit');
    $lookback_days = max(1, (int)($rule['lookback_days'] ?? 7));
    $icodes_a = $rule['_icodes_a'] ?? [];
    $icodes_b = $rule['_icodes_b'] ?? [];
    if (empty($icodes_a)) {
        $a = trim((string)($rule['drug_icode'] ?? ''));
        if ($a !== '' && !di_is_group_token($a)) {
            $icodes_a = [$a];
        }
    }
    if (empty($icodes_b)) {
        $b = trim((string)($rule['hosxp_icode'] ?? ''));
        if ($b !== '' && !di_is_group_token($b)) {
            $icodes_b = [$b];
        }
    }
    if (empty($icodes_a) || empty($icodes_b)) {
        return;
    }

    $by_icode = ($mode === 'same_rx' && !empty($idx['by_icode_all']))
        ? $idx['by_icode_all']
        : ($idx['by_icode'] ?? []);
    $by_vn_icode = $idx['by_vn_icode'] ?? [];
    $by_hn_icode = $idx['by_hn_icode'] ?? [];
    $date_from = $opts['date_from'] ?? '';
    $date_to = $opts['date_to'] ?? '';
    $date_eq = $opts['date_eq'] ?? '';
    $dose_fn = $opts['dose_fn'] ?? 'di_dose_condition_matches';

    foreach ($icodes_a as $icode1) {
        foreach ($by_icode[$icode1] ?? [] as $o1) {
            if (!di_order_qty_valid($o1)) {
                continue;
            }
            $vst1 = $o1['vstdate'] ?? '';
            if ($date_eq !== '' && $vst1 !== $date_eq) {
                continue;
            }
            if ($date_from !== '' && $vst1 < $date_from) {
                continue;
            }
            if ($date_to !== '' && $vst1 > $date_to) {
                continue;
            }
            $c1 = $o1['_c'] ?? di_calculate_coverage_days($o1['qty'], $o1['method'] ?? '', $o1['units'] ?? '');

            foreach ($icodes_b as $icode2) {
                if ($mode === 'same_rx') {
                    $rx1 = di_same_rx_key($o1);
                    if ($rx1 === '') {
                        continue;
                    }
                    foreach ($by_icode[$icode2] ?? [] as $o2) {
                        if (!di_order_qty_valid($o2)) {
                            continue;
                        }
                        if (di_same_rx_key($o2) !== $rx1) {
                            continue;
                        }
                        if (trim((string)($o1['icode'] ?? '')) === trim((string)($o2['icode'] ?? ''))
                            && (string)($o1['item_no'] ?? '') === (string)($o2['item_no'] ?? '')) {
                            continue;
                        }
                        if (is_callable($dose_fn) && (!$dose_fn($rule, $o1, 1) || !$dose_fn($rule, $o2, 2))) {
                            continue;
                        }
                        $c2 = $o2['_c'] ?? di_calculate_coverage_days($o2['qty'], $o2['method'] ?? '', $o2['units'] ?? '');
                        $on_pair($o1, $o2, $mode, $lookback_days, $c1, $c2);
                    }
                    continue;
                }

                if ($mode === 'same_visit') {
                    $cands = di_same_visit_candidates($o1, $icode2, $by_vn_icode, $by_hn_icode);
                } else {
                    $cands = $by_hn_icode[trim((string)($o1['hn'] ?? ''))][$icode2] ?? [];
                    $lb_start = date('Y-m-d', strtotime($vst1 . " -{$lookback_days} days"));
                }

                foreach ($cands as $o2) {
                    if (!di_order_qty_valid($o2)) {
                        continue;
                    }
                    $c2 = $o2['_c'] ?? di_calculate_coverage_days($o2['qty'], $o2['method'] ?? '', $o2['units'] ?? '');
                    if (!di_periods_overlap($vst1, $c1, $o2['vstdate'] ?? '', $c2)) {
                        continue;
                    }
                    if ($mode === 'lookback') {
                        $end2 = $o2['_end'] ?? di_period_end_date($o2['vstdate'] ?? '', $c2);
                        if ($end2 < $lb_start) {
                            continue;
                        }
                    }
                    if (is_callable($dose_fn) && (!$dose_fn($rule, $o1, 1) || !$dose_fn($rule, $o2, 2))) {
                        continue;
                    }
                    $on_pair($o1, $o2, $mode, $lookback_days, $c1, $c2);
                }
            }
        }
    }
}

/**
 * ตรวจเงื่อนไข mg/วันรวม ตามกฎ ($which = 1|2) — อิงวิธีใช้ (strength × จำนวนเม็ด/วัน)
 * ตัวอย่าง simvastatin 10 mg: 1 เม็ด/วัน = 10 mg, 2 เม็ดวันละ 1 ครั้ง = 20 mg
 * - ตั้งช่วงต่ำสุด/สูงสุด → เปรียบเทียบ mg/วันรวมกับช่วงนั้นเท่านั้น
 * - ไม่ตั้งช่วง → ใช้ strength ฉลากยาในกฎ ±15%
 */
function di_dose_condition_matches(array $rule, array $order, $which = 1) {
    $which = (int)$which;
    $use_key = $which === 2 ? 'use_dose2_condition' : 'use_dose1_condition';
    $min_key = $which === 2 ? 'dose2_min' : 'dose1_min';
    $max_key = $which === 2 ? 'dose2_max' : 'dose1_max';
    $name_key = $which === 2 ? 'hosxp_drug_name' : 'drug_name';

    if (empty($rule[$use_key])) {
        return true;
    }

    if (array_key_exists('_daily_mg', $order)) {
        $mg = $order['_daily_mg'];
    } else {
        $parsed = hosxp_parse_drug_daily_dose_mg([
            'qty' => $order['qty'] ?? 0,
            'strength' => $order['strength'] ?? '',
            'units' => $order['units'] ?? '',
            'method' => $order['method'] ?? '',
        ]);
        $mg = $parsed['mg_dose'] ?? null;
    }
    if ($mg === null || $mg <= 0) {
        return false;
    }

    $has_min = isset($rule[$min_key]) && $rule[$min_key] !== '' && $rule[$min_key] !== null;
    $has_max = isset($rule[$max_key]) && $rule[$max_key] !== '' && $rule[$max_key] !== null;

    if ($has_min || $has_max) {
        $dose_min = $has_min ? (float)$rule[$min_key] : 0;
        $dose_max = $has_max ? (float)$rule[$max_key] : PHP_FLOAT_MAX;
        return $mg >= $dose_min && $mg <= $dose_max;
    }

    $label_strength = di_strength_mg_from_drug_name($rule[$name_key] ?? '');
    if ($label_strength !== null && $label_strength > 0) {
        $tolerance = max(1.0, $label_strength * 0.15);
        return abs($mg - $label_strength) <= $tolerance;
    }

    return true;
}

function di_format_daily_mg_display(array $order) {
    if (array_key_exists('_daily_mg', $order)) {
        $mg_val = $order['_daily_mg'];
        $note = trim((string)($order['_daily_mg_note'] ?? ''));
    } else {
        $parsed = hosxp_parse_drug_daily_dose_mg([
            'qty' => $order['qty'] ?? 0,
            'strength' => $order['strength'] ?? '',
            'units' => $order['units'] ?? '',
            'method' => $order['method'] ?? '',
        ]);
        $mg_val = $parsed['mg_dose'] ?? null;
        $note = trim((string)($parsed['mg_note'] ?? ''));
    }
    if ($mg_val === null || $mg_val <= 0) {
        return null;
    }
    $mg = round((float)$mg_val, 2);
    return $note !== '' ? "{$mg} mg/วัน ({$note})" : "{$mg} mg/วัน";
}

function hosxp_parse_drug_option($raw) {
    $parts = explode('|', $raw ?? '', 2);
    return [
        'icode' => trim($parts[0] ?? ''),
        'name' => trim($parts[1] ?? ''),
    ];
}

/** อันดับเวลาสั่งยา — ใช้เลือก order ล่าสุดเมื่อซ้อนกันวันเดียวกัน */
function di_order_rank($row) {
    $date = $row['rxdate'] ?? $row['vstdate'] ?? '1970-01-01';
    $time = trim((string)($row['rxtime'] ?? $row['vsttime'] ?? '00:00:00'));
    if (strlen($time) === 5) {
        $time .= ':00';
    }
    $ts = strtotime($date . ' ' . $time);
    if ($ts === false) {
        $ts = strtotime($date) ?: 0;
    }
    $item = (int)($row['item_no'] ?? 0);
    return ($ts * 1000) + $item;
}

function di_order_qty_valid($row) {
    return (float)($row['qty'] ?? 0) > 0;
}

/** คง order ล่าสุดต่อ HN + วันที่ + icode (กรณี IPD สั่งซ้อนหลายครั้ง/วัน) — ข้าม qty ≤ 0 */
function di_dedupe_latest_orders(array $rows) {
    $best = [];
    foreach ($rows as $row) {
        if (!di_order_qty_valid($row)) {
            continue;
        }
        $key = trim((string)($row['hn'] ?? '')) . '|' . ($row['vstdate'] ?? '') . '|' . trim((string)($row['icode'] ?? ''));
        if (!isset($best[$key]) || di_order_rank($row) >= di_order_rank($best[$key])) {
            $best[$key] = $row;
        }
    }
    return array_values($best);
}

function di_reindex_orders(array $rows) {
    $by_icode = [];
    $by_vn = [];
    $by_hn = [];
    foreach ($rows as $row) {
        $icode = trim((string)($row['icode'] ?? ''));
        $vn = (string)($row['vn'] ?? '');
        $hn = $row['hn'] ?? '';
        $by_icode[$icode][] = $row;
        $by_vn[$vn][] = $row;
        $by_hn[$hn][] = $row;
    }
    return [$by_icode, $by_vn, $by_hn];
}

/** คำนวณช่วงวันที่ query HOSxP — ไม่ขยาย +365 วันถ้าเป็น Visit เดียวกันทั้งหมด */
function di_compute_query_window($start_date, $end_date, array $rules) {
    $max_lookback = 0;
    $has_lookback = false;
    foreach ($rules as $rule) {
        if (($rule['check_mode'] ?? 'same_visit') === 'lookback') {
            $has_lookback = true;
            $max_lookback = max($max_lookback, max(1, (int)($rule['lookback_days'] ?? 7)));
        }
    }

    if (!$has_lookback) {
        return [
            'query_start' => $start_date,
            'query_end' => $end_date,
            'has_lookback' => false,
            'max_lookback' => 0,
        ];
    }

    $user_span = max(1, (int)round((strtotime($end_date) - strtotime($start_date)) / 86400) + 1);
    $coverage_pad = (int)min(90, max(21, (int)ceil($user_span * 4)));
    $back_days = $max_lookback + $coverage_pad;
    $query_start = date('Y-m-d', strtotime($start_date . " -{$back_days} days"));
    $query_end = date('Y-m-d', strtotime($end_date . " +{$coverage_pad} days"));

    return [
        'query_start' => $query_start,
        'query_end' => $query_end,
        'has_lookback' => true,
        'max_lookback' => $max_lookback,
        'coverage_pad' => $coverage_pad,
        'user_span' => $user_span,
    ];
}

function di_rules_need_dose_mg(array $rules) {
    foreach ($rules as $rule) {
        if (!empty($rule['use_dose1_condition']) || !empty($rule['use_dose2_condition'])) {
            return true;
        }
    }
    return false;
}

/** เตรียม coverage / mg ต่อ order ครั้งเดียว */
function di_prepare_orders(array $rows, $need_dose_mg = false) {
    $prepared = [];
    foreach ($rows as $row) {
        $method = trim((string)($row['method'] ?? ''));
        $units = trim((string)($row['units'] ?? ''));
        $qty = (float)($row['qty'] ?? 0);
        $vstdate = $row['vstdate'] ?? '';

        $row['_c'] = di_calculate_coverage_days($qty, $method, $units);
        $row['_end'] = di_period_end_date($vstdate, $row['_c']);
        $row['_daily'] = di_parse_daily_dose($method);

        if ($need_dose_mg) {
            $parsed = hosxp_parse_drug_daily_dose_mg([
                'qty' => $qty,
                'strength' => $row['strength'] ?? '',
                'units' => $units,
                'method' => $method,
            ]);
            $row['_daily_mg'] = $parsed['mg_dose'] ?? null;
            $row['_daily_mg_note'] = trim((string)($parsed['mg_note'] ?? ''));
        }

        $prepared[] = $row;
    }
    return $prepared;
}

/** index แบบจับคู่เร็ว — by icode, vn+icode, hn+icode */
function di_reindex_orders_fast(array $rows) {
    $by_icode = [];
    $by_vn_icode = [];
    $by_hn_icode = [];
    foreach ($rows as $row) {
        $icode = trim((string)($row['icode'] ?? ''));
        if ($icode === '') {
            continue;
        }
        $vn = trim((string)($row['vn'] ?? ''));
        $hn = trim((string)($row['hn'] ?? ''));

        $by_icode[$icode][] = $row;
        if ($vn !== '') {
            $by_vn_icode[$vn][$icode][] = $row;
        }
        if ($hn !== '') {
            $by_hn_icode[$hn][$icode][] = $row;
        }
    }
    return [$by_icode, $by_vn_icode, $by_hn_icode];
}

function di_rules_have_lookback(array $rules) {
    foreach ($rules as $rule) {
        if (($rule['check_mode'] ?? 'same_visit') === 'lookback') {
            return true;
        }
    }
    return false;
}

function di_hn_variants($hn) {
    $hn = trim((string)$hn);
    if ($hn === '') {
        return [];
    }
    $trim = ltrim($hn, '0');
    if ($trim === '') {
        $trim = '0';
    }
    return array_values(array_unique([$hn, $trim, str_pad($trim, 9, '0', STR_PAD_LEFT)]));
}

function monitor_hn_variants($hn) {
    return di_hn_variants($hn);
}

function monitor_hn_sql_in($mysqli, $hn_raw) {
    $vals = [];
    $list = is_array($hn_raw) ? $hn_raw : [$hn_raw];
    foreach ($list as $hn) {
        foreach (monitor_hn_variants($hn) as $v) {
            $v = trim((string)$v);
            if ($v !== '') {
                $vals[$v] = "'" . mysqli_real_escape_string($mysqli, $v) . "'";
            }
        }
    }
    return implode(',', $vals);
}

function monitor_hn_sql_clause($mysqli, $hn_raw, $col = 'o.hn') {
    $in = monitor_hn_sql_in($mysqli, $hn_raw);
    if ($in === '') {
        return '';
    }
    if (!preg_match('/^[A-Za-z0-9_.]+$/', (string)$col)) {
        $col = 'o.hn';
    }
    return " AND {$col} IN ({$in})";
}

function monitor_req_hn() {
    foreach (['hn', 'filter_hn'] as $key) {
        if (isset($_POST[$key]) && (is_string($_POST[$key]) || is_numeric($_POST[$key]))) {
            $v = trim((string)$_POST[$key]);
            if ($v !== '') {
                return $v;
            }
        }
        if (isset($_GET[$key]) && (is_string($_GET[$key]) || is_numeric($_GET[$key]))) {
            $v = trim((string)$_GET[$key]);
            if ($v !== '') {
                return $v;
            }
        }
    }
    return '';
}

function di_build_hosxp_orders_sql($con_hosxp, array $icodes, $date_from, $date_to, $need_dose_mg, array $hn_filter = []) {
    $icode_sql = [];
    foreach ($icodes as $ic) {
        $ic = trim((string)$ic);
        if ($ic === '' || (function_exists('di_is_group_token') && di_is_group_token($ic))) {
            continue;
        }
        $icode_sql[] = "'" . mysqli_real_escape_string($con_hosxp, $ic) . "'";
    }
    if (empty($icode_sql)) {
        return '';
    }

    $start_esc = mysqli_real_escape_string($con_hosxp, $date_from);
    $end_esc = mysqli_real_escape_string($con_hosxp, $date_to);
    $method_expr = di_sql_method_expr('o');
    $strength_expr = hosxp_sql_tmt_strength('d', 'tm');
    $tmt_name_expr = hosxp_sql_tmt_drug_name('d', 'tm');
    $strength_col = "CAST(CONVERT($strength_expr USING utf8) AS CHAR) AS strength,";

    $hn_clause = '';
    if (!empty($hn_filter)) {
        $hn_sql = [];
        foreach ($hn_filter as $hn) {
            $hn = trim((string)$hn);
            if ($hn === '') {
                continue;
            }
            $hn_sql[] = "'" . mysqli_real_escape_string($con_hosxp, $hn) . "'";
        }
        if (!empty($hn_sql)) {
            $hn_clause = ' AND o.hn IN (' . implode(',', $hn_sql) . ')';
        }
    }

    return "
        SELECT o.hn, o.vn, o.vstdate, o.vsttime, o.rxdate, o.rxtime, o.item_no, IFNULL(o.order_no,'') AS order_no, o.icode, o.qty,
               CAST(CONVERT(CONCAT(IFNULL(p.pname, ''), IFNULL(p.fname, ''), ' ', IFNULL(p.lname, '')) USING utf8) AS CHAR) AS ptname,
               $method_expr AS method,
               $strength_col
               CAST(CONVERT(d.units USING utf8) AS CHAR) AS units,
               $tmt_name_expr AS drug_name
        FROM opitemrece o
        INNER JOIN patient p ON p.hn = o.hn
        INNER JOIN drugitems d ON d.icode = o.icode
        " . hosxp_sql_tmt_join('d', 'tm') . "
        " . di_sql_method_joins('o') . "
        WHERE o.icode IN (" . implode(',', $icode_sql) . ")
          AND o.qty > 0
          AND o.vstdate >= '$start_esc'
          AND o.vstdate <= '$end_esc'
          $hn_clause
        ORDER BY o.vstdate DESC, o.rxdate DESC, o.rxtime DESC, o.vsttime DESC, o.item_no DESC
    ";
}

function di_fetch_hosxp_orders($con_hosxp, array $icodes, $date_from, $date_to, $need_dose_mg, array $hn_filter = [], $limit = 12000) {
    $sql = di_build_hosxp_orders_sql($con_hosxp, $icodes, $date_from, $date_to, $need_dose_mg, $hn_filter);
    if ($sql === '') {
        return [[], 0, false, null];
    }

    $sql .= " LIMIT " . (int)$limit;
    $q = mysqli_query($con_hosxp, $sql);
    if (!$q) {
        return [[], 0, false, mysqli_error($con_hosxp)];
    }

    $rows = [];
    $raw_count = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        if (!di_order_qty_valid($row)) {
            continue;
        }
        $row['method'] = trim((string)($row['method'] ?? ''));
        $raw_count++;
        $rows[] = $row;
    }

    return [$rows, $raw_count, ($raw_count >= $limit), null];
}

/** รายการยา 2 ที่อยู่ visit เดียวกับ o1 */
function di_same_visit_candidates(array $o1, $icode2, array $by_vn_icode, array $by_hn_icode) {
    $icode2 = trim((string)$icode2);
    $vn1 = trim((string)($o1['vn'] ?? ''));
    $vst1 = $o1['vstdate'] ?? '';
    $hn = trim((string)($o1['hn'] ?? ''));

    if ($vn1 !== '' && isset($by_vn_icode[$vn1][$icode2])) {
        return $by_vn_icode[$vn1][$icode2];
    }

    $out = [];
    foreach ($by_hn_icode[$hn][$icode2] ?? [] as $o2) {
        if (($o2['vstdate'] ?? '') === $vst1) {
            $out[] = $o2;
        }
    }
    return $out;
}

function di_build_alert($rule, $o1, $o2, $alert_level, $check_mode, $lookback_days, $ptname, $drug1_name, $drug2_name, $c1 = null, $c2 = null) {
    if ($c1 === null) {
        $c1 = $o1['_c'] ?? di_calculate_coverage_days($o1['qty'], $o1['method'] ?? '', $o1['units'] ?? '');
    }
    if ($c2 === null) {
        $c2 = $o2['_c'] ?? di_calculate_coverage_days($o2['qty'], $o2['method'] ?? '', $o2['units'] ?? '');
    }

    if ($check_mode === 'lookback') {
        $check_lbl = di_build_lookback_label($lookback_days, $c1, $c2, $o1['vstdate'], $o2['vstdate']);
    } elseif ($check_mode === 'same_rx') {
        $check_lbl = 'ใบสั่งยาเดียวกัน';
    } else {
        $check_lbl = 'Visit เดียวกัน · ทับช่วงให้ยา ' . $c1 . '/' . $c2 . ' วัน';
    }

    $fmtDate = function ($d) {
        return !empty($d) ? date('d/m/Y', strtotime($d)) : '';
    };

    return [
        'rule_id' => (int)$rule['id'],
        'hn' => $o1['hn'],
        'ptname' => $ptname,
        'vn' => trim((string)($o1['vn'] ?? '')),
        'vstdate' => $fmtDate($o1['vstdate'] ?? ''),
        'drug1_name' => di_format_drug_display_name($drug1_name, $o1['strength'] ?? ''),
        'drug2_name' => di_format_drug_display_name($drug2_name, $o2['strength'] ?? ''),
        'drug1_date' => $fmtDate($o1['vstdate'] ?? ''),
        'drug2_date' => $fmtDate($o2['vstdate'] ?? ''),
        'drug1_time' => di_format_time($o1['vsttime'] ?? ''),
        'drug2_time' => di_format_time($o2['vsttime'] ?? ''),
        'drug1_vn' => trim((string)($o1['vn'] ?? '')),
        'drug2_vn' => trim((string)($o2['vn'] ?? '')),
        'dose1_qty' => $o1['qty'],
        'dose2_qty' => $o2['qty'],
        'drug1_method' => trim((string)($o1['method'] ?? '')),
        'drug2_method' => trim((string)($o2['method'] ?? '')),
        'drug1_daily_dose' => $o1['_daily'] ?? di_parse_daily_dose($o1['method'] ?? ''),
        'drug2_daily_dose' => $o2['_daily'] ?? di_parse_daily_dose($o2['method'] ?? ''),
        'drug1_daily_mg' => di_format_daily_mg_display($o1),
        'drug2_daily_mg' => di_format_daily_mg_display($o2),
        'drug1_coverage_days' => $c1,
        'drug2_coverage_days' => $c2,
        'drug1_coverage_end' => $fmtDate($o1['_end'] ?? di_period_end_date($o1['vstdate'], $c1)),
        'drug2_coverage_end' => $fmtDate($o2['_end'] ?? di_period_end_date($o2['vstdate'], $c2)),
        'alert_level' => $alert_level,
        'interaction_type' => $rule['interaction_type'],
        'detail_text' => $rule['detail_text'] ?? '',
        'check_mode_label' => $check_lbl,
    ];
}

function di_append_alert($alert_data, $alert_level, &$block_alerts, &$warning_alerts, &$block_count, &$warning_count) {
    if ($alert_level === 'hard') {
        $block_alerts[] = $alert_data;
        $block_count++;
    } else {
        $warning_alerts[] = $alert_data;
        $warning_count++;
    }
}

function di_format_alert_summary_line(array $alert) {
    $d1 = trim((string)($alert['drug1_name'] ?? ''));
    $d2 = trim((string)($alert['drug2_name'] ?? ''));
    $pair = ($d1 !== '' && $d2 !== '') ? "{$d1} + {$d2}" : ($d1 !== '' ? $d1 : ($d2 !== '' ? $d2 : 'คู่ยา'));
    $detail = trim((string)($alert['detail_text'] ?? ''));
    if ($detail === '') {
        $detail = trim((string)($alert['interaction_type'] ?? ''));
    }
    if ($detail === '') {
        $detail = 'พบปฏิกิริยาระหว่างยา';
    }
    $line = $pair . ' — ' . $detail;
    $meta = trim((string)($alert['check_mode_label'] ?? ''));
    if ($meta !== '') {
        $line .= ' (' . $meta . ')';
    }
    return $line;
}

/**
 * ประเมิน Drug Interaction สำหรับผู้ป่วย 1 visit (logic เดียวกับ Monitor DI)
 */
function di_evaluate_visit_alerts($con, $hos, $hn, $vstdate, $vn = '', $ptname = '', array $icodes = null) {
    ensure_di_dose_columns($con);
    $hn = trim((string)$hn);
    $vstdate = trim((string)$vstdate);
    if ($hn === '' || $vstdate === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $vstdate)) {
        return ['alerts' => [], 'has_hard' => false];
    }

    if ($icodes === null) {
        $icodes = [];
        $hn_esc = mysqli_real_escape_string($hos, $hn);
        $date_esc = mysqli_real_escape_string($hos, $vstdate);
        $vn_clause = '';
        if (trim((string)$vn) !== '') {
            $vn_clause = "AND o.vn = '" . mysqli_real_escape_string($hos, $vn) . "'";
        }
        $q_ic = mysqli_query($hos, "SELECT DISTINCT o.icode FROM opitemrece o
            WHERE o.hn = '$hn_esc' AND o.vstdate = '$date_esc' AND o.qty > 0 $vn_clause");
        if ($q_ic) {
            while ($r = mysqli_fetch_assoc($q_ic)) {
                $c = trim($r['icode'] ?? '');
                if ($c !== '') {
                    $icodes[] = $c;
                }
            }
        }
    }

    if (empty($icodes)) {
        return ['alerts' => [], 'has_hard' => false];
    }

    $selected = array_flip($icodes);
    $q_rules = mysqli_query($con, "SELECT * FROM monitor_drug_interaction_settings WHERE active_status = 1");
    $raw_rules = [];
    if ($q_rules) {
        while ($row = mysqli_fetch_assoc($q_rules)) {
            $d1 = trim($row['drug_icode'] ?? '');
            $d2 = trim($row['hosxp_icode'] ?? '');
            if ($d1 === '' || $d2 === '') {
                continue;
            }
            $raw_rules[] = $row;
        }
    }
    $raw_rules = di_prepare_rules_icodes($hos, $raw_rules);
    $rules = [];
    foreach ($raw_rules as $row) {
        $hit = false;
        foreach ($row['_icodes_a'] ?? [] as $ic) {
            if (isset($selected[$ic])) {
                $hit = true;
                break;
            }
        }
        if ($hit) {
            $rules[] = $row;
        }
    }
    if (empty($rules)) {
        return ['alerts' => [], 'has_hard' => false];
    }

    $all_icodes = di_rules_scan_icodes($rules);
    $need_dose_mg = di_rules_need_dose_mg($rules);
    $window = di_compute_query_window($vstdate, $vstdate, $rules);
    $query_start = $window['query_start'];
    $query_end = date('Y-m-d', strtotime($vstdate . ' + 30 days'));

    [$raw_rows] = di_fetch_hosxp_orders($hos, $all_icodes, $query_start, $query_end, $need_dose_mg, [$hn], 5000);
    $prepared_all = di_prepare_orders($raw_rows, $need_dose_mg);
    $prepared_rows = di_prepare_orders(di_dedupe_latest_orders($raw_rows), $need_dose_mg);
    [$by_icode, $by_vn_icode, $by_hn_icode] = di_reindex_orders_fast($prepared_rows);
    [$by_icode_all] = di_reindex_orders_fast($prepared_all);
    $idx = [
        'by_icode' => $by_icode,
        'by_vn_icode' => $by_vn_icode,
        'by_hn_icode' => $by_hn_icode,
        'by_icode_all' => $by_icode_all,
    ];

    $drug_names = [];
    foreach ($prepared_all as $row) {
        $ic = trim($row['icode'] ?? '');
        if ($ic !== '' && !isset($drug_names[$ic])) {
            $drug_names[$ic] = trim($row['drug_name'] ?? '') ?: $ic;
        }
    }

    $alerts = [];
    $seen = [];
    $has_hard = false;

    foreach ($rules as $rule) {
        $alert_level = (!empty($rule['alert_level']) && $rule['alert_level'] === 'hard') ? 'hard' : 'soft';
        di_each_matching_pair($rule, $idx, ['date_eq' => $vstdate], function ($o1, $o2, $check_mode, $lookback_days, $c1, $c2) use ($rule, $alert_level, $ptname, $drug_names, &$alerts, &$seen, &$has_hard) {
            $key = $rule['id'] . '|' . ($o1['hn'] ?? '') . '|' . di_same_rx_key($o1) . '|' . ($o1['icode'] ?? '') . '|' . ($o2['icode'] ?? '') . '|' . ($o2['vstdate'] ?? '') . '|' . ($o2['vn'] ?? '');
            if (isset($seen[$key])) {
                return;
            }
            $seen[$key] = true;
            $drug1_name = $drug_names[$o1['icode'] ?? ''] ?? ($rule['drug_name'] ?? '');
            $drug2_name = $drug_names[$o2['icode'] ?? ''] ?? ($rule['hosxp_drug_name'] ?? '');
            $alerts[] = di_build_alert(
                $rule, $o1, $o2, $alert_level, $check_mode, $lookback_days,
                $ptname, $drug1_name, $drug2_name, $c1, $c2
            );
            if ($alert_level === 'hard') {
                $has_hard = true;
            }
        });
    }

    return ['alerts' => $alerts, 'has_hard' => $has_hard];
}

function di_group_alerts_by_hn($alerts) {
    $grouped = [];
    foreach ($alerts as $a) {
        $hn = $a['hn'];
        if (!isset($grouped[$hn])) {
            $grouped[$hn] = ['hn' => $hn, 'ptname' => $a['ptname'], 'visits' => []];
        }
        $grouped[$hn]['visits'][] = $a;
    }
    return array_values($grouped);
}

/** ตรวจว่าข้อความมีตัวเลขพร้อมหน่วยความแรง/ปริมาณแล้ว */
function di_text_has_strength_info($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return false;
    }
    if (preg_match('/\d+(?:\.\d+)?\s*(?:mg|mcg|µg|ug|g|gm|gram|grams|ml|l|unit|units|iu)\b/i', $text)) {
        return true;
    }
    return (bool)preg_match('/\d+(?:\.\d+)?(?:mg|mcg|g|gm|GM|ml|ML|unit|iu)\b/i', $text);
}

/** ชื่อยาในหน้ารายงาน — ต่อท้าย strength (TMT) ถ้าชื่อยังไม่มีหน่วยความแรง */
function di_format_drug_display_name($name, $strength = '') {
    $name = trim((string)$name);
    $strength = trim((string)$strength);
    if ($name === '') {
        return $strength !== '' ? $strength : '-';
    }
    if (di_text_has_strength_info($name)) {
        return $name;
    }
    if ($strength === '') {
        return $name;
    }
    if (di_text_has_strength_info($strength)) {
        return $name . ' ' . $strength;
    }
    if (preg_match('/^\d+(?:\.\d+)?$/', $strength)) {
        return $name . ' ' . $strength . ' mg';
    }
    return $name . ' ' . $strength;
}

/** ดึง strength (mg) จากชื่อยา เช่น simvastatin 10 mg */
function di_strength_mg_from_drug_name($name) {
    $name = trim((string)$name);
    if ($name === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*mg\b/i', $name, $m)) {
        return (float)$m[1];
    }
    return null;
}

function di_format_time($t) {
    $t = trim((string)$t);
    if ($t === '') {
        return '';
    }
    return strlen($t) >= 5 ? substr($t, 0, 5) : $t;
}

/** แปลงเวลา HOSxP (12:57, 12:57:00, 1257, 125700) เป็น HH:MM:SS */
function monitor_lab_normalize_hosxp_time($time) {
    $time = trim((string)$time);
    if ($time === '') {
        return '00:00:00';
    }
    if (preg_match('/^\d{1,2}:\d{2}(:\d{2})?$/', $time)) {
        return strlen($time) === 5 ? $time . ':00' : $time;
    }
    $digits = preg_replace('/\D/', '', $time);
    if (strlen($digits) >= 4) {
        $digits = str_pad(substr($digits, 0, 6), 6, '0', STR_PAD_RIGHT);
        return substr($digits, 0, 2) . ':' . substr($digits, 2, 2) . ':' . substr($digits, 4, 2);
    }
    return '00:00:00';
}

function monitor_lab_datetime_to_ts($date, $time = '') {
    $date = trim((string)$date);
    if ($date === '' || $date === '-' || $date === '0000-00-00') {
        return null;
    }
    $time = monitor_lab_normalize_hosxp_time($time);
    $ts = strtotime($date . ' ' . $time);
    return $ts ?: null;
}

/** วันที่/เวลาสั่งยา — ใช้ rxdate/rxtime ก่อน vstdate/vsttime */
function monitor_lab_order_datetime(array $order_row) {
    $date = trim((string)($order_row['rxdate'] ?? ''));
    if ($date === '' || $date === '0000-00-00') {
        $date = trim((string)($order_row['vstdate'] ?? ''));
    }
    $time = trim((string)($order_row['rxtime'] ?? ''));
    if ($time === '') {
        $time = trim((string)($order_row['vsttime'] ?? ''));
    }
    return ['date' => $date, 'time' => $time];
}

/** แยกรหัส Lab หลายตัว — คั่นด้วย comma หรือ | (เช่น Potassium 132,1100) */
function monitor_lab_parse_codes($code) {
    if (is_array($code)) {
        $parts = $code;
    } else {
        $code = trim((string)$code);
        if ($code === '') {
            return [];
        }
        $parts = preg_split('/[,|;]+/', $code);
    }
    $out = [];
    foreach ($parts as $p) {
        $p = trim((string)$p);
        if ($p !== '') {
            $out[] = $p;
        }
    }
    return array_values(array_unique($out));
}

/** สร้าง IN (...) สำหรับ lab_items_code หลายรหัส */
function monitor_lab_codes_sql_in($hos, $code) {
    $codes = monitor_lab_parse_codes($code);
    if (empty($codes)) {
        return "''";
    }
    $escaped = [];
    foreach ($codes as $c) {
        $escaped[] = "'" . mysqli_real_escape_string($hos, $c) . "'";
    }
    return implode(',', $escaped);
}

/** วันที่/เวลา Lab ที่ใช้เทียบ — lab_head.order_date + order_time */
function monitor_lab_lab_row_datetime(array $lab_head_row) {
    return [
        'date' => trim((string)($lab_head_row['order_date'] ?? '')),
        'time' => trim((string)($lab_head_row['order_time'] ?? '')),
    ];
}

/** Lab ต้องมีเวลา (order_date + order_time) ก่อนเวลาสั่งยา (rxdate/rxtime) */
function monitor_lab_lab_before_order(array $lab_row, $order_date, $order_time = '') {
    $order_ts = monitor_lab_datetime_to_ts($order_date, $order_time);
    $lab_ts = monitor_lab_datetime_to_ts($lab_row['date'] ?? '', $lab_row['time'] ?? '');
    if ($order_ts !== null && $lab_ts !== null) {
        return $lab_ts < $order_ts;
    }
    if ($order_ts === null) {
        return ($lab_row['date'] ?? '') <= $order_date;
    }
    return ($lab_row['date'] ?? '') < $order_date;
}

/** HN ใน HOSxP อาจเป็น 000443606 หรือ 443606 — ใช้ทั้งสองแบบใน SQL */
/**
 * ดึงผล Lab หลาย HN × หลายรหัสในชุดเดียว แล้วเลือกใน PHP
 * คืน [hn_key][lab_items_code][] = {date,time,raw,value} เรียงใหม่ไปเก่า
 */
function monitor_lab_prefetch_hn_labs($hos, array $hns, array $codes, $min_date, $max_date, $per_hn_code_cap = 12) {
    $cache = [];
    $code_list = [];
    foreach ($codes as $c) {
        foreach (monitor_lab_parse_codes($c) as $p) {
            if ($p !== '') {
                $code_list[$p] = true;
            }
        }
    }
    $code_list = array_keys($code_list);
    if (!$hos || empty($hns) || empty($code_list)) {
        return $cache;
    }
    $hn_keys = [];
    foreach ($hns as $hn) {
        $hn = trim((string)$hn);
        if ($hn === '') {
            continue;
        }
        $trim = ltrim($hn, '0');
        if ($trim === '') {
            $trim = '0';
        }
        $hn_keys[str_pad($trim, 9, '0', STR_PAD_LEFT)] = true;
        $hn_keys[$trim] = true;
    }
    if (empty($hn_keys)) {
        return $cache;
    }
    $code_in = monitor_lab_codes_sql_in($hos, $code_list);
    $min_esc = mysqli_real_escape_string($hos, $min_date);
    $max_esc = mysqli_real_escape_string($hos, $max_date);
    $cap = max(4, min(24, (int)$per_hn_code_cap));

    foreach (array_chunk(array_keys($hn_keys), 80) as $chunk) {
        $hn_in = "'" . implode("','", array_map(static function ($h) use ($hos) {
            return mysqli_real_escape_string($hos, $h);
        }, $chunk)) . "'";
        $sql = "SELECT lh.hn, lo.lab_items_code, lh.order_date, lh.order_time, lo.lab_order_result
            FROM lab_head lh
            INNER JOIN lab_order lo ON lo.lab_order_number = lh.lab_order_number
            WHERE lh.hn IN ($hn_in)
              AND lo.lab_items_code IN ($code_in)
              AND lh.order_date >= '$min_esc'
              AND lh.order_date <= '$max_esc'
              AND lo.lab_order_result IS NOT NULL
              AND TRIM(lo.lab_order_result) <> ''
            ORDER BY lh.order_date DESC, lh.order_time DESC
            LIMIT 12000";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $hn_raw = trim((string)($r['hn'] ?? ''));
            $code = trim((string)($r['lab_items_code'] ?? ''));
            if ($hn_raw === '' || $code === '') {
                continue;
            }
            $row = [
                'date' => trim((string)($r['order_date'] ?? '')),
                'time' => trim((string)($r['order_time'] ?? '')),
                'raw' => trim((string)($r['lab_order_result'] ?? '')),
                'value' => (float)preg_replace('/[^0-9.-]/', '', str_replace(',', '', (string)($r['lab_order_result'] ?? ''))),
            ];
            if ($row['date'] === '' || $row['date'] === '0000-00-00') {
                continue;
            }
            $keys = array_unique([$hn_raw, ltrim($hn_raw, '0')]);
            foreach ($keys as $sk) {
                if ($sk === '') {
                    continue;
                }
                if (!isset($cache[$sk][$code])) {
                    $cache[$sk][$code] = [];
                }
                if (count($cache[$sk][$code]) >= $cap) {
                    continue;
                }
                $cache[$sk][$code][] = $row;
            }
        }
    }
    return $cache;
}

function monitor_lab_pick_prefetched(array $cache, $hn, $code, $order_date, $order_time = '') {
    $empty = ['value' => 0, 'raw' => '', 'date' => '-', 'time' => ''];
    $codes = monitor_lab_parse_codes($code);
    if (empty($codes) || empty($cache)) {
        return $empty;
    }
    $hn = trim((string)$hn);
    $trim = ltrim($hn, '0');
    $hn_keys = array_unique(array_filter([$hn, $trim, $trim !== '' ? str_pad($trim, 9, '0', STR_PAD_LEFT) : '']));
    $best = null;
    $best_ts = null;
    foreach ($hn_keys as $hk) {
        foreach ($codes as $c) {
            foreach ($cache[$hk][$c] ?? [] as $row) {
                if (!monitor_lab_lab_before_order($row, $order_date, $order_time)) {
                    continue;
                }
                $ts = monitor_lab_datetime_to_ts($row['date'] ?? '', $row['time'] ?? '');
                if ($ts === null) {
                    continue;
                }
                if ($best_ts === null || $ts > $best_ts) {
                    $best_ts = $ts;
                    $best = $row;
                }
            }
        }
    }
    if ($best === null) {
        return $empty;
    }
    return [
        'value' => $best['value'],
        'raw' => $best['raw'],
        'date' => !empty($best['date']) ? date('d/m/Y', strtotime($best['date'])) : '-',
        'time' => function_exists('di_format_time')
            ? di_format_time(monitor_lab_normalize_hosxp_time($best['time'] ?? ''))
            : ($best['time'] ?? ''),
    ];
}

function monitor_lab_hn_sql_in($hos, $hn) {
    $trimmed = ltrim((string)$hn, '0');
    if ($trimmed === '') {
        $trimmed = '0';
    }
    $variants = [
        mysqli_real_escape_string($hos, str_pad($trimmed, 9, '0', STR_PAD_LEFT)),
        mysqli_real_escape_string($hos, $trimmed),
    ];
    if ($hn !== $trimmed && $hn !== str_pad($trimmed, 9, '0', STR_PAD_LEFT)) {
        $variants[] = mysqli_real_escape_string($hos, (string)$hn);
    }
    $variants = array_values(array_unique(array_filter($variants)));
    return "'" . implode("','", $variants) . "'";
}

/**
 * ดึงผล Lab ล่าสุดก่อนเวลาสั่งยา:
 * lh.order_date ย้อนหลังไม่เกิน 4 ปี (ตาม min_date), รองรับหลาย lab_items_code
 * เทียบเวลาและแสดงผลด้วย order_date + order_time เทียบกับ rxdate/rxtime
 */
function monitor_lab_fetch_rows_for_cutoff($hos, $hn, $code, $lab_cutoff_date, $min_date = null) {
    $codes = monitor_lab_parse_codes($code);
    $lab_cutoff_date = trim((string)$lab_cutoff_date);
    if (empty($codes) || $lab_cutoff_date === '' || $lab_cutoff_date === '0000-00-00') {
        return [];
    }

    $hn_in = monitor_lab_hn_sql_in($hos, $hn);
    $code_in = monitor_lab_codes_sql_in($hos, $codes);
    $cutoff_esc = mysqli_real_escape_string($hos, $lab_cutoff_date);
    $min_clause = '';
    if ($min_date !== null && $min_date !== '') {
        $min_clause = "AND lh.order_date >= '" . mysqli_real_escape_string($hos, $min_date) . "'";
    }

    $sql = "SELECT lh.lab_order_number,
               lh.order_date, lh.order_time,
               lo.lab_order_result, lo.lab_items_code
        FROM lab_head lh
        INNER JOIN lab_order lo ON lh.lab_order_number = lo.lab_order_number
        WHERE lh.hn IN ($hn_in)
          AND lo.lab_items_code IN ($code_in)
          AND lo.lab_order_result IS NOT NULL
          AND TRIM(lo.lab_order_result) != ''
          AND lh.order_date <= '$cutoff_esc'
          $min_clause
        ORDER BY lo.lab_order_number DESC
        LIMIT 120";

    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return [];
    }

    $rows = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $dt = monitor_lab_lab_row_datetime($r);
        $row = [
            'date' => $dt['date'],
            'time' => $dt['time'],
            'raw' => trim((string)$r['lab_order_result']),
            'value' => (float)preg_replace('/[^0-9.-]/', '', str_replace(',', '', $r['lab_order_result'])),
        ];
        if ($row['date'] === '' || $row['date'] === '0000-00-00') {
            continue;
        }
        $rows[] = $row;
    }
    return $rows;
}

function monitor_lab_pick_latest_before_order(array $rows, $order_date, $order_time = '') {
    $empty = ['value' => 0, 'raw' => '', 'date' => '-', 'time' => ''];
    foreach ($rows as $row) {
        if (!monitor_lab_lab_before_order($row, $order_date, $order_time)) {
            continue;
        }
        return [
            'value' => $row['value'],
            'raw' => $row['raw'],
            'date' => date('d/m/Y', strtotime($row['date'])),
            'time' => di_format_time(monitor_lab_normalize_hosxp_time($row['time'])),
        ];
    }
    return $empty;
}

function monitor_lab_fetch_latest_before_order($hos, $hn, $code, $order_date, $order_time = '', $min_date = null, $lab_cutoff_date = null) {
    $empty = ['value' => 0, 'raw' => '', 'date' => '-', 'time' => ''];
    $order_date = trim((string)$order_date);
    $lab_cutoff_date = trim((string)($lab_cutoff_date ?? $order_date));
    if ($order_date === '' || $order_date === '0000-00-00') {
        return $empty;
    }
    if ($lab_cutoff_date === '' || $lab_cutoff_date === '0000-00-00') {
        $lab_cutoff_date = $order_date;
    }
    $rows = monitor_lab_fetch_rows_for_cutoff($hos, $hn, $code, $lab_cutoff_date, $min_date);
    return monitor_lab_pick_latest_before_order($rows, $order_date, $order_time);
}

/** Memo ต่อ request — cache แถว Lab ตาม HN/code/cutoff ไม่ผูกเวลสั่งยา */
function monitor_lab_get_lab_for_order($hos, array &$memo, $hn, $code, $order_date, $order_time = '', $min_date = null, $lab_cutoff_date = null) {
    $cutoff = $lab_cutoff_date ?? $order_date;
    $code_key = implode(',', monitor_lab_parse_codes($code));
    $rows_key = ltrim((string)$hn, '0') . '|' . $code_key . '|' . trim((string)$cutoff)
        . '|' . trim((string)($min_date ?? ''));
    if (!isset($memo['_rows'][$rows_key])) {
        $memo['_rows'][$rows_key] = monitor_lab_fetch_rows_for_cutoff($hos, $hn, $code, $cutoff, $min_date);
    }
    $pick_key = $rows_key . '|' . trim((string)$order_date) . '|' . monitor_lab_normalize_hosxp_time($order_time);
    if (!isset($memo[$pick_key])) {
        $memo[$pick_key] = monitor_lab_pick_latest_before_order($memo['_rows'][$rows_key], $order_date, $order_time);
    }
    return $memo[$pick_key];
}

/** ดึงผล Lab ล่าสุด (timestamp สูงสุด) ที่ยังอยู่ก่อนเวลาสั่งยา — จาก cache (legacy) */
function monitor_lab_get_lab_from_cache(array $cache, $hn, $code, $order_date, $order_time = '') {
    $hn_key = ltrim((string)$hn, '0');
    if ($code === '' || $code === null || empty($cache[$hn_key][$code])) {
        return ['value' => 0, 'raw' => '', 'date' => '-', 'time' => ''];
    }
    $best = null;
    $best_ts = null;
    foreach ($cache[$hn_key][$code] as $row) {
        if (!monitor_lab_lab_before_order($row, $order_date, $order_time)) {
            continue;
        }
        $lab_ts = monitor_lab_datetime_to_ts($row['date'] ?? '', $row['time'] ?? '');
        if ($lab_ts === null) {
            continue;
        }
        if ($best_ts === null || $lab_ts > $best_ts) {
            $best_ts = $lab_ts;
            $best = $row;
        }
    }
    if ($best === null) {
        return ['value' => 0, 'raw' => '', 'date' => '-', 'time' => ''];
    }
    return [
        'value' => $best['value'],
        'raw' => $best['raw'] ?? '',
        'date' => $best['date'] ? date('d/m/Y', strtotime($best['date'])) : '-',
        'time' => di_format_time(monitor_lab_normalize_hosxp_time($best['time'] ?? '')),
    ];
}

/**
 * วิธีใช้ยา — ตามรูปแบบ HOSxP มาตรฐาน: sp_use → opi_dispense (ถ้าครบ) → drugusage name1-3
 * หมายเหตุ: บางรายการ opi_dispense.usage_line1 มีแค่หน่วย (เช่น "เม็ด") — fallback ไป drugusage
 * @see ตัวอย่าง query รพ. (opitemrece + opi_dispense + drugusage + sp_use)
 */
function di_sql_method_expr($o = 'o', $du = 'du', $sp = 'sp', $od = 'od') {
    $od_line = "TRIM(CONCAT(IFNULL($od.usage_line1,''),' ',IFNULL($od.usage_line2,''),' ',IFNULL($od.usage_line3,'')))";
    $od_ok = "($od.usage_line1 IS NOT NULL AND TRIM($od.usage_line1) <> '' AND CHAR_LENGTH($od_line) >= 8)";
    $inner = "IF($o.sp_use <> '' AND $o.sp_use IS NOT NULL,
        CONCAT(IFNULL($sp.name1,''),' ',IFNULL($sp.name2,''),' ',IFNULL($sp.name3,'')),
        IF($od_ok,
            $od_line,
            CONCAT(IFNULL($du.name1,''),' ',IFNULL($du.name2,''),' ',IFNULL($du.name3,''))
        )
    )";
    return "CAST(CONVERT($inner USING utf8) AS CHAR)";
}

function di_sql_method_joins($o = 'o', $du = 'du', $sp = 'sp', $od = 'od') {
    return "LEFT JOIN drugusage $du ON $du.drugusage = $o.drugusage
            LEFT JOIN opi_dispense $od ON $od.hos_guid = $o.hos_guid
            LEFT JOIN sp_use $sp ON $sp.sp_use = $o.sp_use";
}

/** จำนวนต่อครั้งจากวิธีใช้ */
function hosxp_parse_per_time_dose($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*เม็ด\s*ครึ่ง/ui', $m, $hm)) {
        return (float)$hm[1] + 0.5;
    }
    if (preg_match('/เม็ด\s*ครึ่ง|ครึ่ง\s*เม็ด/ui', $m)) {
        return 0.5;
    }
    if (preg_match('/(?:ครั้งละ|รับประทานครั้งละ|ทานครั้งละ|ใช้ครั้งละ)?\s*(\d+(?:\.\d+)?)\s*เม็ด/ui', $m, $pm)) {
        return (float)$pm[1];
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:cap|capsule|tab|tablet)/i', $m, $cm)) {
        return (float)$cm[1];
    }
    return null;
}

/** นับมื้อจากวิธีใช้ — เที่ยง/กลางวัน นับเป็นมื้อเดียวกัน */
function hosxp_usage_meal_slot_count($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return 0;
    }
    $n = 0;
    if (preg_match('/เช้า/ui', $m)) {
        $n++;
    }
    if (preg_match('/เที่ยง|กลางวัน/ui', $m)) {
        $n++;
    }
    if (preg_match('/เย็น/ui', $m)) {
        $n++;
    }
    if (preg_match('/ก่อนนอน/ui', $m)) {
        $n++;
    }
    return $n;
}

function hosxp_usage_has_meal_slot($text) {
    return (bool)preg_match('/เช้า|เที่ยง|กลางวัน|เย็น|ก่อนนอน/ui', (string)$text);
}

/** จำนวนครั้งต่อวันที่ระบุชัดในข้อความ (วันละ N ครั้ง / tid) — ไม่นับจากมื้อ */
function hosxp_parse_explicit_times_per_day($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return null;
    }
    if (preg_match('/\b(?:stat|asap|now)\b/iu', $m)
        || preg_match('/ครั้งเดียว|ทันที|ฉุกเฉิน/u', $m)
    ) {
        return 1.0;
    }
    if (preg_match('/วันละ\s*(\d+(?:\.\d+)?)\s*ครั้ง/ui', $m, $tp)) {
        return (float)$tp[1];
    }
    if (preg_match('/วันเว้นวัน/u', $m) || preg_match('/\b(?:qod|q\.o\.d\.)\b/i', $m)) {
        return 0.5;
    }
    if (preg_match('/ทุก\s*(\d+(?:\.\d+)?)\s*วัน/ui', $m, $iv)
        || preg_match('/every\s*(\d+(?:\.\d+)?)\s*days?\b/i', $m, $iv)
        || preg_match('/\bq\s*\.?\s*(\d+(?:\.\d+)?)\s*d(?:ays?)?\b/i', $m, $iv)
    ) {
        $days = (float)$iv[1];
        if ($days > 0) {
            return 1.0 / $days;
        }
    }
    if (preg_match('/ทุก\s*(\d+(?:\.\d+)?)\s*(?:ชั่วโมง|ชม\.?|hr|hrs?|hours?)\b/ui', $m, $iv)
        || preg_match('/\bq\s*\.?\s*(\d+(?:\.\d+)?)\s*(?:h|hr|hrs?|hours?|ชม\.?)\b/i', $m, $iv)
        || preg_match('/every\s*(\d+(?:\.\d+)?)\s*(?:h|hr|hrs?|hours?)\b/i', $m, $iv)
    ) {
        $hours = (float)$iv[1];
        if ($hours > 0) {
            return 24.0 / $hours;
        }
    }
    if (preg_match('/\b(qid|q\.i\.d\.)/i', $m)) {
        return 4.0;
    }
    if (preg_match('/\b(tid|t\.i\.d\.)/i', $m)) {
        return 3.0;
    }
    if (preg_match('/\b(bid|b\.i\.d\.)/i', $m)) {
        return 2.0;
    }
    if (preg_match('/\b(od|qd|q\.d\.|hs|h\.s\.)\b/i', $m)) {
        return 1.0;
    }
    return null;
}

/** จำนวนครั้งต่อวันจากวิธีใช้ (วันละ N ครั้ง / bid / เช้า-กลางวัน-เย็น) */
function hosxp_parse_times_per_day($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return null;
    }
    $explicit = hosxp_parse_explicit_times_per_day($m);
    if ($explicit !== null) {
        return $explicit;
    }
    $meal_count = hosxp_usage_meal_slot_count($m);
    return $meal_count > 0 ? (float)$meal_count : null;
}

/** มื้อละคนละจำนวนเม็ดหรือไม่ เช่น เช้า 1 เม็ด เย็น 2 เม็ด */
function hosxp_usage_has_varying_meal_doses($method) {
    if (!preg_match_all('/(\d+(?:\.\d+)?)\s*เม็ด/ui', (string)$method, $mm) || count($mm[1]) < 2) {
        return false;
    }
    $uniq = [];
    foreach ($mm[1] as $n) {
        $uniq[(string)(float)$n] = true;
    }
    return count($uniq) > 1;
}

/**
 * รวมจำนวนเม็ด/วันเมื่อแต่ละมื้อต่างกัน
 * เช่น "2 เม็ด หลังอาหารเช้า และ 1 เม็ด หลังอาหารเย็น" → 3 เม็ด/วัน
 * "ครั้งละ 5 เม็ด วันละ 4 ครั้ง เช้า, กลางวัน, เย็น และก่อนนอน" → 20 เม็ด/วัน
 */
function hosxp_parse_daily_units_from_usage($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return null;
    }

    $uniform = hosxp_parse_per_time_dose($m);
    $explicit_tpd = hosxp_parse_explicit_times_per_day($m);
    $meal_hits = hosxp_usage_meal_slot_count($m);

    // ครั้งละ N × วันละ M ครั้ง — อย่าตัดตามจุลภาคของรายการมื้อ
    if ($uniform !== null && $explicit_tpd !== null && $explicit_tpd > 0
        && !hosxp_usage_has_varying_meal_doses($m)
    ) {
        return max(0.01, $uniform * $explicit_tpd);
    }

    if ($meal_hits > 0) {
        $clauses = preg_split('/\s*(?:และ|,)\s*/u', $m);
        if (count($clauses) > 1) {
            $total = 0.0;
            $parsed = 0;
            $last_per = null;
            foreach ($clauses as $clause) {
                $clause = trim($clause);
                if ($clause === '') {
                    continue;
                }
                if (!hosxp_usage_has_meal_slot($clause)) {
                    continue;
                }
                $per = hosxp_parse_per_time_dose($clause);
                if ($per !== null) {
                    $last_per = $per;
                } elseif ($last_per !== null) {
                    $per = $last_per;
                }
                if ($per !== null) {
                    $slots = max(1, hosxp_usage_meal_slot_count($clause));
                    $total += $per * $slots;
                    $parsed++;
                }
            }
            if ($parsed > 0 && $total > 0) {
                return $total;
            }
        }

        if ($uniform !== null && $explicit_tpd !== null && $explicit_tpd > 0) {
            return max(0.01, $uniform * $explicit_tpd);
        }
        if ($uniform !== null && $meal_hits > 0) {
            return max(0.01, $uniform * $meal_hits);
        }
    }

    $per_time = $uniform !== null ? $uniform : hosxp_parse_per_time_dose($m);
    $times_per_day = $explicit_tpd !== null ? $explicit_tpd : hosxp_parse_times_per_day($m);
    if ($per_time !== null && $times_per_day !== null) {
        return max(0.01, $per_time * $times_per_day);
    }
    if ($per_time !== null) {
        return max(0.01, $per_time);
    }
    return null;
}

/** ปริมาณยาต่อวันจากวิธีใช้ (เช่น 1 เม็ด วันละ 1 ครั้ง → 1) */
function di_parse_daily_dose($method) {
    $parsed = hosxp_parse_daily_units_from_usage($method);
    return $parsed !== null ? $parsed : null;
}

/** จำนวนวันที่ยาครอบคลุมจาก qty ÷ ปริมาณต่อวัน */
function di_calculate_coverage_days($qty, $method, $units = '') {
    $q = (float)$qty;
    if ($q <= 0) {
        return 1;
    }

    $daily = di_parse_daily_dose($method);
    if ($daily !== null && $daily > 0) {
        return max(1, (int)ceil($q / $daily));
    }

    return max(1, (int)ceil($q));
}

function di_period_end_date($start_date, $coverage_days) {
    $days = max(1, (int)$coverage_days);
    if ($days <= 1) {
        return $start_date;
    }
    $ts = strtotime($start_date . ' + ' . ($days - 1) . ' days');
    return $ts ? date('Y-m-d', $ts) : $start_date;
}

/** ช่วงวันให้ยาทับซ้อนกันหรือไม่ */
function di_periods_overlap($start1, $days1, $start2, $days2) {
    $end1 = di_period_end_date($start1, $days1);
    $end2 = di_period_end_date($start2, $days2);
    return $start1 <= $end2 && $start2 <= $end1;
}

function di_build_lookback_label($lookback_days, $c1, $c2, $d1, $d2) {
    $fmt = function ($d) {
        $ts = strtotime($d);
        return $ts ? date('d/m/Y', $ts) : $d;
    };
    $end1 = di_period_end_date($d1, $c1);
    $end2 = di_period_end_date($d2, $c2);
    return "ทับช่วงให้ยา · ยา1 {$c1} วัน (ถึง {$fmt($end1)}) · ยา2 {$c2} วัน (ถึง {$fmt($end2)}) · ค้นหาย้อนหลังสูงสุด {$lookback_days} วัน";
}

/** แปลง strength/units เป็น mg ต่อหน่วย — ตรงกับ smart_drug.php parseStrengthMg */
function hosxp_parse_strength_mg($strength, $units = '') {
    $combined = strtolower(trim((string)$strength . ' ' . (string)$units));
    if ($combined === '') {
        return null;
    }
    if (!preg_match('/(\d+(?:\.\d+)?)/', $combined, $num_match)) {
        return null;
    }
    $num = (float)$num_match[1];
    if (preg_match('/\bmcg\b|µg|μg|\bug\b|ไมโครกรัม/ui', $combined)) {
        return $num / 1000;
    }
    if (preg_match('/\bmg\b|มิลลิกรัม|มก\./ui', $combined)) {
        return $num;
    }
    if (preg_match('/\b(?:g|gm|gram|กร\.?|กรัม)\b/ui', $combined)) {
        return $num * 1000;
    }
    return $num;
}

/** ดึง mg จากข้อความวิธีใช้ — ตรงกับ smart_drug.php extractMgFromText */
function hosxp_extract_mg_from_usage($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|μg|ug|ไมโครกรัม)/iu', $text, $mc)) {
        return (float)$mc[1] / 1000;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*mg(?!cg)/i', $text, $mg)) {
        return (float)$mg[1];
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:g|gm|gram|กร\.?|กรัม)(?![a-zA-Z])/iu', $text, $g)) {
        return (float)$g[1] * 1000;
    }
    return null;
}

/** จำนวนต่อครั้งจากวิธีใช้ — ตรงกับ smart_drug.php parseQtyFromUsage */
function hosxp_parse_qty_from_usage($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*เม็ด\s*ครึ่ง/ui', $text, $half)) {
        return ['qty' => (float)$half[1] + 0.5, 'unit' => 'เม็ด'];
    }
    if (preg_match('/เม็ด\s*ครึ่ง|ครึ่ง\s*เม็ด/ui', $text)) {
        return ['qty' => 0.5, 'unit' => 'เม็ด'];
    }
    if (preg_match('/(?:ครั้งละ|รับประทานครั้งละ|ทานครั้งละ|ใช้ครั้งละ)?\s*(\d+(?:\.\d+)?)\s*เม็ด/ui', $text, $pill)) {
        return ['qty' => (float)$pill[1], 'unit' => 'เม็ด'];
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:cap|capsule|tab|tablet)/i', $text, $cap)) {
        return ['qty' => (float)$cap[1], 'unit' => 'เม็ด'];
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*ช้อน(?:โต๊ะ|tea)?/i', $text, $spoon)) {
        return ['qty' => (float)$spoon[1], 'unit' => 'ช้อน'];
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:ซอง|sachet)/i', $text, $sachet)) {
        return ['qty' => (float)$sachet[1], 'unit' => 'ซอง'];
    }
    return null;
}

/**
 * คำนวณขนาดยา (mg) จาก order — ตรงกับ smart_drug.php parseDrugDose
 * @param array $item keys: qty, strength, units, method
 */
function hosxp_parse_drug_dose_mg(array $item) {
    $usage = trim((string)($item['method'] ?? ''));
    $order_qty = (float)($item['qty'] ?? 0);
    $strength_mg = hosxp_parse_strength_mg($item['strength'] ?? '', $item['units'] ?? '');

    $pill_qty = null;
    $pill_unit = 'หน่วย';
    $mg = hosxp_extract_mg_from_usage($usage);
    $mg_note = ($mg !== null) ? 'จากวิธีใช้' : '';

    $from_usage = hosxp_parse_qty_from_usage($usage);
    if ($from_usage !== null) {
        $pill_qty = $from_usage['qty'];
        $pill_unit = $from_usage['unit'];
    } elseif ($order_qty > 0) {
        $pill_qty = $order_qty;
        $u = trim((string)($item['units'] ?? ''));
        if (preg_match('/เม็ด|tab|cap/i', $u)) {
            $pill_unit = 'เม็ด';
        } elseif ($u !== '') {
            $pill_unit = $u;
        }
    }

    if ($mg === null && $strength_mg !== null && $pill_qty !== null) {
        $mg = $strength_mg * $pill_qty;
        $mg_note = 'strength × จำนวน';
    } elseif ($mg === null && $strength_mg !== null && $order_qty > 0) {
        $mg = $strength_mg * $order_qty;
        $mg_note = 'strength × qty';
    }

    return [
        'pill_qty' => $pill_qty,
        'pill_unit' => $pill_unit,
        'mg_dose' => $mg,
        'mg_note' => $mg_note,
    ];
}

/**
 * คำนวณขนาดยา (mg) รวมต่อวัน — สำหรับ Monitor Lab
 * strength × จำนวนต่อครั้ง × วันละ N ครั้ง (หรือนับจากเช้า-เย็น)
 */
function hosxp_daily_dose_note($usage, $daily_units) {
    $usage = trim((string)$usage);
    if (preg_match('/\s*(?:และ|,)\s*/u', $usage) && preg_match('/เช้า|เที่ยง|กลางวัน|เย็น|ก่อนนอน/ui', $usage)) {
        return 'strength × รวมเม็ด/วัน (แยกมื้อ)';
    }
    $times_per_day = hosxp_parse_times_per_day($usage);
    if ($times_per_day !== null && $times_per_day > 1) {
        return 'strength × จำนวน × วันละ ' . hosxp_format_times_per_day_label($times_per_day);
    }
    return 'strength × จำนวน/วัน';
}

/**
 * ขนาดยาต่อครั้ง (mg/ครั้ง) จากวิธีใช้ — ไม่คูณครั้งต่อวัน และไม่ใช้ qty รวมที่จ่าย
 */
function hosxp_parse_drug_per_admin_dose_mg(array $item) {
    $usage = trim((string)($item['method'] ?? ''));
    $strength_mg = hosxp_parse_strength_mg($item['strength'] ?? '', $item['units'] ?? '');
    $pill_qty = null;
    $pill_unit = 'หน่วย';
    $mg = hosxp_extract_mg_from_usage($usage);
    $mg_note = ($mg !== null) ? 'จากวิธีใช้ (ต่อครั้ง)' : '';

    if ($mg === null) {
        $from_usage = hosxp_parse_qty_from_usage($usage);
        if ($from_usage === null && preg_match('/(\d+(?:\.\d+)?)\s*(?:vial|vials|amp|ampoule|ขวด|หลอด)\b/iu', $usage, $vm)) {
            $from_usage = ['qty' => (float)$vm[1], 'unit' => 'หน่วย'];
        }
        if ($from_usage === null) {
            $per_time = hosxp_parse_per_time_dose($usage);
            if ($per_time !== null) {
                $from_usage = ['qty' => $per_time, 'unit' => 'เม็ด'];
            }
        }
        if ($from_usage !== null) {
            $pill_qty = $from_usage['qty'];
            $pill_unit = $from_usage['unit'];
            if ($strength_mg !== null) {
                $mg = $strength_mg * $pill_qty;
                $mg_note = 'strength × จำนวนต่อครั้ง';
            }
        }
    }

    return [
        'pill_qty' => $pill_qty,
        'pill_unit' => $pill_unit,
        'mg_dose' => $mg,
        'mg_note' => $mg_note,
    ];
}

function monitor_lab_dose_in_range($actual, $min, $max) {
    $actual = (float)$actual;
    if ($actual <= 0) {
        return false;
    }
    $lo = ($min !== '' && $min !== null) ? (float)$min : 0;
    $hi = ($max !== '' && $max !== null) ? (float)$max : PHP_FLOAT_MAX;
    return $actual >= $lo && $actual <= $hi;
}

/** ตรวจเงื่อนไข mg/วัน และ/หรือ mg/ครั้ง ของกฎ Lab — ไม่เปิดเงื่อนไข = ผ่าน */
function monitor_lab_order_dose_conditions_match(array $rule, array $order) {
    $item = [
        'qty' => $order['qty'] ?? 0,
        'strength' => $order['strength'] ?? '',
        'units' => $order['units'] ?? '',
        'method' => $order['method'] ?? '',
    ];
    if (!empty($rule['use_dose_condition'])) {
        $parsed = hosxp_parse_drug_daily_dose_mg($item);
        $actual = ($parsed['mg_dose'] !== null) ? (float)$parsed['mg_dose'] : 0;
        if (!monitor_lab_dose_in_range($actual, $rule['dose_min'] ?? null, $rule['dose_max'] ?? null)) {
            return false;
        }
    }
    if (!empty($rule['use_dose_per_admin_condition'])) {
        $parsed = hosxp_parse_drug_per_admin_dose_mg($item);
        $actual = ($parsed['mg_dose'] !== null) ? (float)$parsed['mg_dose'] : 0;
        if (!monitor_lab_dose_in_range($actual, $rule['dose_per_admin_min'] ?? null, $rule['dose_per_admin_max'] ?? null)) {
            return false;
        }
    }
    return true;
}

function hosxp_parse_drug_daily_dose_mg(array $item) {
    $usage = trim((string)($item['method'] ?? ''));
    $strength_mg = hosxp_parse_strength_mg($item['strength'] ?? '', $item['units'] ?? '');
    $base = hosxp_parse_drug_dose_mg($item);
    $times_per_day = hosxp_parse_times_per_day($usage);

    $mg_direct = hosxp_extract_mg_from_usage($usage);
    if ($mg_direct !== null) {
        $daily_units = hosxp_parse_daily_units_from_usage($usage);
        if ($daily_units !== null && $daily_units > 0 && $times_per_day !== null && $times_per_day > 1) {
            $base['mg_dose'] = $mg_direct * $times_per_day;
            $base['mg_note'] = 'จากวิธีใช้ × วันละ ' . hosxp_format_times_per_day_label($times_per_day);
        }
        return $base;
    }

    if ($strength_mg !== null) {
        $daily_units = hosxp_parse_daily_units_from_usage($usage);
        if ($daily_units !== null && $daily_units > 0) {
            $base['mg_dose'] = $strength_mg * $daily_units;
            $base['mg_note'] = hosxp_daily_dose_note($usage, $daily_units);
            $base['pill_qty'] = $daily_units;
            return $base;
        }
    }

    return $base;
}

function hosxp_format_times_per_day_label($times) {
    $times = (float)$times;
    if ($times == (int)$times) {
        return (int)$times . ' ครั้ง';
    }
    return rtrim(rtrim(number_format($times, 2, '.', ''), '0'), '.') . ' ครั้ง';
}

function hosxp_format_actual_dose_display(array $parsed) {
    if ($parsed['mg_dose'] !== null && $parsed['mg_dose'] > 0) {
        $display = (floor($parsed['mg_dose']) == $parsed['mg_dose'])
            ? (string)(int)$parsed['mg_dose']
            : rtrim(rtrim(number_format($parsed['mg_dose'], 2, '.', ''), '0'), '.');
        $out = $display . ' mg';
        if (!empty($parsed['mg_note'])) {
            $out .= ' <small class="text-muted">(' . htmlspecialchars($parsed['mg_note'], ENT_QUOTES, 'UTF-8') . ')</small>';
        }
        return $out;
    }
    if ($parsed['pill_qty'] !== null && $parsed['pill_qty'] > 0) {
        $display = (floor($parsed['pill_qty']) == $parsed['pill_qty'])
            ? (string)(int)$parsed['pill_qty']
            : rtrim(rtrim(number_format($parsed['pill_qty'], 2, '.', ''), '0'), '.');
        return $display . ' ' . htmlspecialchars($parsed['pill_unit'] ?: 'หน่วย', ENT_QUOTES, 'UTF-8')
            . ' <small class="text-muted">(ไม่สามารถคำนวณ mg)</small>';
    }
    return '-';
}

function monitor_lab_egfr_norm_generic($s) {
    $s = strtoupper(trim(preg_replace('/\s+/u', ' ', (string)$s)));
    return $s;
}

function monitor_lab_egfr_is_sample($blob) {
    return (bool)preg_match('/\bsample\b/i', (string)$blob);
}

function monitor_lab_egfr_is_topical($blob) {
    return (bool)preg_match(
        '/\b(gel|spray|cream|ointment|lotion|topical|eye\s*drop|eardrop|ยาทา|ยาพ่น|ยาหยอด)\b/iu',
        (string)$blob
    );
}

function monitor_lab_egfr_generic_in_drug($generic, array $drug) {
    $g = monitor_lab_egfr_norm_generic($generic);
    if ($g === '') {
        return false;
    }
    $blob = monitor_lab_egfr_norm_generic(implode(' ', [
        $drug['generic_name'] ?? '',
        $drug['name_local'] ?? '',
        $drug['name_tmt'] ?? '',
    ]));
    $pattern = '/(?<![A-Z0-9])' . preg_quote($g, '/') . '(?![A-Z0-9])/';
    return (bool)preg_match($pattern, $blob);
}

function monitor_lab_egfr_suggestion($generic, $inform, $max_val) {
    $g = monitor_lab_egfr_norm_generic($generic);
    $max = rtrim(rtrim(number_format((float)$max_val, 2, '.', ''), '0'), '.');
    if ($max === '') {
        $max = (string)(int)$max_val;
    }
    if (strpos($g, 'METFORMIN') !== false) {
        return 'หลีกเลี่ยงการใช้เนื่องจากเสี่ยงต่อ MALA (eGFR < ' . $max . ')';
    }
    if (strpos($g, 'GLIBENCLAMIDE') !== false || strpos($g, 'GLYBURIDE') !== false) {
        return 'หลีกเลี่ยงการใช้เนื่องจากเสี่ยงต่อ hypoglycemia เมื่อ eGFR < ' . $max;
    }
    $inform = trim((string)$inform);
    if ($inform !== '' && stripos($inform, 'NEPHRO') === false) {
        return trim($inform) . ' (eGFR < ' . $max . ')';
    }
    return 'NSAIDs ห้ามใช้กรณีที่ eGFR < ' . $max;
}

function monitor_lab_fetch_egfr_alert_rows($hos) {
    $sql = "
        SELECT TRIM(generic_name) AS generic_name,
               MIN(value_min) AS value_min,
               MAX(value_max) AS value_max,
               MAX(inform) AS inform,
               GROUP_CONCAT(DISTINCT lab_items_code ORDER BY lab_items_code SEPARATOR ',') AS lab_codes
        FROM drug_lab_alerted_pharma
        WHERE lab_items_name LIKE '%eGFR%'
        GROUP BY TRIM(generic_name)
        ORDER BY generic_name
    ";
    $rows = [];
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return $rows;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $name = monitor_lab_egfr_norm_generic($r['generic_name'] ?? '');
        if ($name === '') {
            continue;
        }
        $rows[$name] = [
            'generic_name' => $name,
            'value_min' => (float)($r['value_min'] ?? 0),
            'value_max' => (float)($r['value_max'] ?? 0),
            'inform' => trim((string)($r['inform'] ?? '')),
            'lab_codes' => monitor_lab_parse_codes($r['lab_codes'] ?? ''),
        ];
    }
    return array_values($rows);
}

function monitor_lab_fetch_active_drugs_for_egfr($hos) {
    $tmt = hosxp_sql_tmt_drug_name('d', 'tm');
    $sql = "
        SELECT d.icode,
               CAST(CONVERT(d.name USING utf8) AS CHAR) AS name_local,
               $tmt AS name_tmt,
               CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
               IFNULL(d.istatus, '') AS istatus
        FROM drugitems d
        " . hosxp_sql_tmt_join('d', 'tm') . "
        WHERE d.icode IS NOT NULL
          AND TRIM(d.icode) <> ''
    ";
    $list = [];
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return $list;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $list[] = [
            'icode' => trim((string)$r['icode']),
            'name_local' => trim((string)($r['name_local'] ?? '')),
            'name_tmt' => trim((string)($r['name_tmt'] ?? '')),
            'generic_name' => trim((string)($r['generic_name'] ?? '')),
            'istatus' => strtoupper(trim((string)($r['istatus'] ?? ''))),
        ];
    }
    return $list;
}

function monitor_lab_merge_ckd_epi_codes($con, array $codes) {
    $q = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = 'h_code_ckd_epi' LIMIT 1");
    $existing = '';
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $existing = (string)($r['config_value'] ?? '');
    }
    $merged = monitor_lab_parse_codes($existing);
    foreach ($codes as $c) {
        foreach (monitor_lab_parse_codes($c) as $p) {
            $merged[] = $p;
        }
    }
    $merged = array_values(array_unique($merged));
    $val = implode(',', $merged);
    $val_esc = mysqli_real_escape_string($con, $val);
    if ($q && mysqli_num_rows($q) > 0) {
        mysqli_query($con, "UPDATE sys_config SET config_value = '$val_esc' WHERE config_name = 'h_code_ckd_epi'");
    } else {
        mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('h_code_ckd_epi', '$val_esc')");
    }
    return $val;
}

/**
 * นำเข้ากฎ Monitor Lab ไต จาก HOSxP drug_lab_alerted_pharma ที่เป็น Lab eGFR
 * จับคู่ยาที่ยังเปิดใช้ (ไม่ทับกฎ icode + CKD-EPI + ช่วงค่า ที่มีแล้ว)
 */
function monitor_lab_import_egfr_from_hosxp($con, $hos) {
    $empty = [
        'ok' => false,
        'inserted' => 0,
        'skipped' => 0,
        'unmatched' => 0,
        'inactive' => 0,
        'unmatched_names' => [],
        'ckd_epi_codes' => '',
        'message' => 'นำเข้าไม่สำเร็จ',
    ];
    if (!$hos) {
        $empty['message'] = 'ไม่สามารถเชื่อมต่อ HOSxP';
        return $empty;
    }
    ensure_drug_safety_rules_hosxp_columns($con);
    ensure_drug_safety_rules_alert_level_column($con);
    ensure_drug_safety_rules_lab_condition_columns($con);
    ensure_drug_safety_rules_patient_extra_columns($con);
    ensure_drug_safety_rules_duration_columns($con);
    ensure_drug_safety_rules_exempt_method_columns($con);

    $alerts = monitor_lab_fetch_egfr_alert_rows($hos);
    if (empty($alerts)) {
        $empty['message'] = 'ไม่พบรายการ Lab eGFR ในตาราง drug_lab_alerted_pharma';
        return $empty;
    }

    $drugs = monitor_lab_fetch_active_drugs_for_egfr($hos);
    $all_lab_codes = [];
    $inserted = 0;
    $skipped = 0;
    $unmatched_names = [];

    foreach ($alerts as $alert) {
        foreach ($alert['lab_codes'] as $code) {
            $all_lab_codes[] = $code;
        }
        $hits = [];
        $inactive_hits = [];
        foreach ($drugs as $d) {
            if ($d['icode'] === '') {
                continue;
            }
            $blob = $d['generic_name'] . ' ' . $d['name_local'] . ' ' . $d['name_tmt'];
            if (monitor_lab_egfr_is_sample($blob) || monitor_lab_egfr_is_topical($blob)) {
                continue;
            }
            if (!monitor_lab_egfr_generic_in_drug($alert['generic_name'], $d)) {
                continue;
            }
            if (($d['istatus'] ?? '') === 'Y') {
                $hits[$d['icode']] = $d;
            } else {
                $inactive_hits[$d['icode']] = $d;
            }
        }
        if (empty($hits)) {
            $hits = $inactive_hits;
        }
        if (empty($hits)) {
            $unmatched_names[] = $alert['generic_name'];
            continue;
        }
        $min_val = number_format((float)$alert['value_min'], 2, '.', '');
        $max_val = number_format((float)$alert['value_max'], 2, '.', '');
        $msg = monitor_lab_egfr_suggestion($alert['generic_name'], $alert['inform'], $alert['value_max']);
        $msg_esc = mysqli_real_escape_string($con, $msg);
        foreach ($hits as $d) {
            $icode_esc = mysqli_real_escape_string($con, $d['icode']);
            $exists = mysqli_query(
                $con,
                "SELECT id FROM drug_safety_rules
                 WHERE drug_icode = '$icode_esc'
                   AND lab_type = 'CKD_EPI'
                   AND min_val = '$min_val'
                   AND max_val = '$max_val'
                 LIMIT 1"
            );
            if ($exists && mysqli_num_rows($exists) > 0) {
                $skipped++;
                continue;
            }
            $name = $d['name_tmt'] !== '' ? $d['name_tmt'] : $d['name_local'];
            $name_esc = mysqli_real_escape_string($con, $name);
            $sql = "INSERT INTO drug_safety_rules
                (drug_id, drug_icode, drug_name, lab_type, min_val, max_val,
                 use_dose_condition, dose_min, dose_max, dose_unit,
                 use_age_condition, age_min, age_max,
                 use_weight_condition, weight_min, weight_max,
                 action_type, action_value, suggestion_msg, alert_level, active_status, lab_condition_type)
                VALUES
                (0, '$icode_esc', '$name_esc', 'CKD_EPI', '$min_val', '$max_val',
                 0, NULL, NULL, NULL,
                 0, NULL, NULL,
                 0, NULL, NULL,
                 'omit', 0, '$msg_esc', 'hard', 1, 'range')";
            if (mysqli_query($con, $sql)) {
                $inserted++;
            }
        }
    }

    $ckd_codes = monitor_lab_merge_ckd_epi_codes($con, $all_lab_codes);
    return [
        'ok' => true,
        'inserted' => $inserted,
        'skipped' => $skipped,
        'unmatched' => count($unmatched_names),
        'inactive' => 0,
        'unmatched_names' => $unmatched_names,
        'ckd_epi_codes' => $ckd_codes,
        'message' => 'ok',
    ];
}
