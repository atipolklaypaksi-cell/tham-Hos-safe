<?php
/**
 * เชื่อมต่อระบบ INVC (SQL Server) แบบอ่านอย่างเดียว
 */

function invc_config_keys() {
    $keys = ['invc_host', 'invc_port', 'invc_user', 'invc_pass', 'invc_db', 'invc_readonly'];
    if (!function_exists('invc_gsheet_config_keys')) {
        require_once __DIR__ . '/invc_gsheet_helper.php';
    }
    return array_merge($keys, invc_gsheet_config_keys());
}

function invc_default_config() {
    $cfg = [
        'invc_host' => '192.168.45.22',
        'invc_port' => '1433',
        'invc_user' => 'inv',
        'invc_pass' => 'inv',
        'invc_db' => 'INV_STOCK',
        'invc_readonly' => '1',
    ];
    if (!function_exists('invc_gsheet_default_config')) {
        require_once __DIR__ . '/invc_gsheet_helper.php';
    }
    return array_merge($cfg, invc_gsheet_default_config());
}

function invc_install_hint() {
    return 'bash /home/co-scph/employee/public/thamhossafe/tools/install_invc_sqlsrv.sh';
}

function invc_pdo_drivers() {
    return class_exists('PDO') ? PDO::getAvailableDrivers() : [];
}

function invc_driver_status() {
    $pdo = invc_pdo_drivers();
    $sqlsrv = in_array('sqlsrv', $pdo, true);
    $dblib = in_array('dblib', $pdo, true);
    $odbc = in_array('odbc', $pdo, true);
    $driver = $sqlsrv ? 'sqlsrv' : ($dblib ? 'dblib' : ($odbc ? 'odbc' : ''));
    return [
        'ok' => ($sqlsrv || $dblib || $odbc),
        'driver' => $driver,
        'sqlsrv' => $sqlsrv,
        'dblib' => $dblib,
        'odbc' => $odbc,
        'install_hint' => invc_install_hint(),
    ];
}

function invc_upsert_config($con, $key, $value) {
    $k = mysqli_real_escape_string($con, $key);
    $v = mysqli_real_escape_string($con, (string)$value);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$k'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
}

function invc_ensure_config($con) {
    $defaults = invc_default_config();
    foreach ($defaults as $key => $value) {
        $k = mysqli_real_escape_string($con, $key);
        $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
        if (!$chk || mysqli_num_rows($chk) === 0) {
            invc_upsert_config($con, $key, $value);
            continue;
        }
        if ($key === 'invc_readonly') {
            invc_upsert_config($con, $key, '1');
        }
    }
}

function invc_load_config($con) {
    invc_ensure_config($con);
    $cfg = invc_default_config();
    $keys = "'" . implode("','", array_map(function ($k) use ($con) {
        return mysqli_real_escape_string($con, $k);
    }, invc_config_keys())) . "'";
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ($keys)");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cfg[$r['config_name']] = (string)$r['config_value'];
        }
    }
    $cfg['invc_readonly'] = '1';
    $port = (int)($cfg['invc_port'] ?? 1433);
    $cfg['invc_port'] = (string)($port > 0 ? $port : 1433);
    return $cfg;
}

function invc_save_config($con, array $input) {
    $next = invc_load_config($con);
    foreach (['invc_host', 'invc_port', 'invc_user', 'invc_db'] as $key) {
        if (array_key_exists($key, $input)) {
            $next[$key] = trim((string)$input[$key]);
        }
    }
    if (isset($input['invc_pass'])) {
        $pass = (string)$input['invc_pass'];
        if ($pass !== '' && $pass !== '********') {
            $next['invc_pass'] = $pass;
        }
    }
    foreach (invc_gsheet_config_keys() as $key) {
        if (!array_key_exists($key, $input)) {
            continue;
        }
        $val = trim((string)$input[$key]);
        if ($key === 'invc_gsheet_enabled') {
            $next[$key] = ($val === '1' || strtolower($val) === 'true' || $val === 'on') ? '1' : '0';
            continue;
        }
        if ($key === 'invc_gsheet_cache_ttl') {
            $ttl = (int)$val;
            $next[$key] = (string)($ttl > 0 ? max(30, min(3600, $ttl)) : 60);
            continue;
        }
        if ($key === 'invc_gsheet_auth') {
            $mode = strtolower($val);
            $next[$key] = in_array($mode, ['auto', 'service_account', 'csv'], true) ? $mode : 'auto';
            continue;
        }
        if ($key === 'invc_gsheet_sa_email') {
            // อัปเดตจากไฟล์ SA เท่านั้น
            continue;
        }
        if (strpos($key, 'invc_gsheet_col_') === 0) {
            $letter = strtoupper($val);
            $next[$key] = preg_match('/^[A-Z]{1,2}$/', $letter) ? $letter : ($next[$key] ?? 'E');
            continue;
        }
        if ($key === 'invc_gsheet_gid') {
            $gid = preg_replace('/\D+/', '', $val);
            $next[$key] = $gid !== '' ? $gid : '0';
            continue;
        }
        $next[$key] = $val;
    }
    if (!empty($next['invc_gsheet_url'])) {
        $gidFromUrl = invc_gsheet_extract_gid($next['invc_gsheet_url'], $next['invc_gsheet_gid'] ?? '0');
        if ($gidFromUrl !== '' && (!isset($input['invc_gsheet_gid']) || trim((string)$input['invc_gsheet_gid']) === '')) {
            $next['invc_gsheet_gid'] = $gidFromUrl;
        }
    }
    if (array_key_exists('invc_gsheet_sa_json', $input)) {
        $saSave = invc_gsheet_save_sa_json($input['invc_gsheet_sa_json']);
        if (empty($saSave['ok'])) {
            // ไม่บล็อกค่าอื่น แต่เก็บ error ให้ caller ผ่าน return ปกติ + email ว่าง
        }
    }
    $saStatus = invc_gsheet_sa_status();
    $next['invc_gsheet_sa_email'] = $saStatus['email'] ?? '';
    $port = (int)$next['invc_port'];
    $next['invc_port'] = (string)($port > 0 ? $port : 1433);
    $next['invc_readonly'] = '1';
    foreach (invc_config_keys() as $key) {
        invc_upsert_config($con, $key, $next[$key] ?? '');
    }
    return invc_load_config($con);
}

function invc_public_config(array $cfg) {
    $out = $cfg;
    $out['invc_pass'] = ($cfg['invc_pass'] ?? '') !== '' ? '********' : '';
    $out['invc_readonly'] = '1';
    $sa = invc_gsheet_sa_status();
    $out['invc_gsheet_sa_configured'] = !empty($sa['configured']);
    $out['invc_gsheet_sa_email'] = (string)($sa['email'] ?? '');
    $out['invc_gsheet_sa_json'] = !empty($sa['configured']) ? '********' : '';
    return $out;
}

function invc_last_error($set = null) {
    static $err = '';
    if ($set !== null) {
        $err = (string)$set;
    }
    return $err;
}

function invc_is_readonly_sql($sql) {
    $sql = trim((string)$sql);
    if ($sql === '') {
        return false;
    }
    $sql = preg_replace('/^\s*\/\*.*?\*\//s', '', $sql);
    $sql = preg_replace('/^\s*--[^\n]*\n/', '', $sql);
    $sql = ltrim($sql);
    if (!preg_match('/^(SELECT|WITH)\b/i', $sql)) {
        return false;
    }
    if (preg_match('/\b(INSERT|UPDATE|DELETE|MERGE|ALTER|DROP|CREATE|TRUNCATE|GRANT|REVOKE|INTO\s+OUTFILE|FOR\s+UPDATE)\b/i', $sql)) {
        return false;
    }
    return true;
}

function invc_ident($name) {
    $name = trim((string)$name);
    if ($name === '' || !preg_match('/^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)?$/', $name)) {
        return null;
    }
    $parts = explode('.', $name);
    return implode('.', array_map(function ($p) {
        return '[' . $p . ']';
    }, $parts));
}

function invc_is_sensitive_column($name, $type = '') {
    $n = strtolower((string)$name);
    $t = strtolower((string)$type);
    if (strpos($t, 'binary') !== false || strpos($t, 'image') !== false || strpos($t, 'varbinary') !== false) {
        return true;
    }
    $needles = ['password', 'passwd', 'hash', 'token', 'secret', 'cid', 'pin'];
    foreach ($needles as $w) {
        if (strpos($n, $w) !== false) {
            return true;
        }
    }
    return false;
}

function invc_dsn_candidates($host, $port, $db) {
    $drivers = invc_pdo_drivers();
    $list = [];
    if (in_array('sqlsrv', $drivers, true)) {
        $list[] = [
            'sqlsrv',
            "sqlsrv:Server={$host},{$port};Database={$db};LoginTimeout=8;TrustServerCertificate=yes;ApplicationIntent=ReadOnly;CharacterSet=UTF-8",
        ];
    }
    if (in_array('dblib', $drivers, true)) {
        $list[] = ['dblib', "dblib:host={$host}:{$port};dbname={$db};charset=UTF-8"];
        $list[] = ['dblib', "dblib:version=7.4;host={$host}:{$port};dbname={$db};charset=UTF-8"];
        $list[] = ['dblib', "dblib:host={$host};port={$port};dbname={$db};charset=UTF-8"];
    }
    if (in_array('odbc', $drivers, true)) {
        $list[] = ['odbc', "odbc:Driver={FreeTDS};Server={$host};Port={$port};Database={$db};TDS_Version=7.4;ClientCharset=UTF-8"];
        $list[] = ['odbc', "odbc:Driver={ODBC Driver 18 for SQL Server};Server={$host},{$port};Database={$db};TrustServerCertificate=yes;Encrypt=yes"];
        $list[] = ['odbc', "odbc:Driver={ODBC Driver 17 for SQL Server};Server={$host},{$port};Database={$db};TrustServerCertificate=yes"];
    }
    return $list;
}

function invc_apply_readonly(PDO $pdo) {
    try {
        $pdo->exec('SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED');
    } catch (Throwable $e) {
        // ignore
    }
    try {
        $pdo->exec('SET NOCOUNT ON');
    } catch (Throwable $e) {
        // ignore
    }
}

function invc_connect($con, $timeout = 8, array $override = null) {
    invc_last_error('');
    if (is_file(__DIR__ . '/integrations_hub_helper.php')) {
        require_once __DIR__ . '/integrations_hub_helper.php';
        if (function_exists('ih_is_enabled') && !ih_is_enabled($con, 'invc')) {
            invc_last_error(function_exists('ih_disabled_message') ? ih_disabled_message('invc') : 'INVC ถูกปิดไว้');
            return null;
        }
    }
    $drv = invc_driver_status();
    if (empty($drv['ok'])) {
        invc_last_error('ยังไม่มี PHP driver สำหรับ SQL Server — ติดตั้งด้วย: ' . invc_install_hint());
        return null;
    }
    $cfg = $override ? array_merge(invc_load_config($con), $override) : invc_load_config($con);
    $host = trim((string)($cfg['invc_host'] ?? ''));
    $user = trim((string)($cfg['invc_user'] ?? ''));
    $pass = (string)($cfg['invc_pass'] ?? '');
    $db = trim((string)($cfg['invc_db'] ?? ''));
    $port = (int)($cfg['invc_port'] ?? 1433);
    if ($host === '' || $user === '' || $db === '') {
        invc_last_error('กรอก Host, Username และ Database ให้ครบ');
        return null;
    }
    if ($port <= 0) {
        $port = 1433;
    }
    $timeout = max(5, min(30, (int)$timeout));
    $errors = [];
    foreach (invc_dsn_candidates($host, $port, $db) as $pair) {
        [$driver, $dsn] = $pair;
        try {
            $pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_TIMEOUT => $timeout,
            ]);
            invc_apply_readonly($pdo);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $pdo;
        } catch (Throwable $e) {
            $errors[] = $driver . ': ' . $e->getMessage();
        }
    }
    invc_last_error($errors ? implode(' | ', $errors) : 'เชื่อมต่อ INVC ไม่ได้');
    return null;
}

function invc_query(PDO $pdo, $sql) {
    if (!invc_is_readonly_sql($sql)) {
        return false;
    }
    try {
        return $pdo->query($sql);
    } catch (Throwable $e) {
        invc_last_error($e->getMessage());
        return false;
    }
}

function invc_close($pdo) {
    if ($pdo instanceof PDO) {
        $pdo = null;
    }
}

function invc_fetch_scalar(PDO $pdo, $sql, $col = null) {
    $st = invc_query($pdo, $sql);
    if (!$st) {
        return null;
    }
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        return null;
    }
    if ($col && array_key_exists($col, $row)) {
        return $row[$col];
    }
    return reset($row);
}

function invc_table_count(PDO $pdo) {
    $sql = "SELECT COUNT(*) AS c
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_TYPE = 'BASE TABLE'";
    $n = invc_fetch_scalar($pdo, $sql, 'c');
    return $n === null ? 0 : (int)$n;
}

function invc_safe_count(PDO $pdo, $table) {
    $ident = invc_ident($table);
    if (!$ident) {
        return null;
    }
    $st = invc_query($pdo, "SELECT COUNT(*) AS c FROM $ident");
    if (!$st) {
        return null;
    }
    $row = $st->fetch(PDO::FETCH_ASSOC);
    return isset($row['c']) ? (int)$row['c'] : null;
}

function invc_list_tables(PDO $pdo, $q = '', $limit = 80) {
    $limit = max(1, min(200, (int)$limit));
    $sql = "SELECT TABLE_SCHEMA, TABLE_NAME
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_TYPE = 'BASE TABLE'
            ORDER BY TABLE_NAME";
    $st = invc_query($pdo, $sql);
    if (!$st) {
        return [];
    }
    $q = trim(mb_strtolower($q, 'UTF-8'));
    $preferred = ['stock', 'drug', 'item', 'warehouse', 'receive', 'dispense', 'ward'];
    $first = [];
    $rest = [];
    while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
        $schema = (string)($row['TABLE_SCHEMA'] ?? 'dbo');
        $name = (string)($row['TABLE_NAME'] ?? '');
        if ($name === '') {
            continue;
        }
        $full = ($schema !== '' && strtolower($schema) !== 'dbo') ? ($schema . '.' . $name) : $name;
        $hay = mb_strtolower($full, 'UTF-8');
        if ($q !== '' && mb_strpos($hay, $q) === false) {
            continue;
        }
        $hit = false;
        foreach ($preferred as $p) {
            if (mb_strpos($hay, $p) !== false) {
                $first[] = $full;
                $hit = true;
                break;
            }
        }
        if (!$hit) {
            $rest[] = $full;
        }
    }
    return array_slice(array_merge($first, $rest), 0, $limit);
}

function invc_describe_table(PDO $pdo, $table) {
    $ident = invc_ident($table);
    if (!$ident) {
        return [];
    }
    $parts = explode('.', $table);
    $name = count($parts) === 2 ? $parts[1] : $parts[0];
    $schema = count($parts) === 2 ? $parts[0] : '';
    $name_sql = str_replace("'", "''", $name);
    $where = "TABLE_NAME = '" . $name_sql . "'";
    if ($schema !== '' && preg_match('/^[A-Za-z0-9_]+$/', $schema)) {
        $where .= " AND TABLE_SCHEMA = '" . str_replace("'", "''", $schema) . "'";
    }
    $sql = "SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE $where
            ORDER BY ORDINAL_POSITION";
    $st = invc_query($pdo, $sql);
    if (!$st) {
        return [];
    }
    $cols = [];
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
        $cname = (string)($r['COLUMN_NAME'] ?? '');
        $type = (string)($r['DATA_TYPE'] ?? '');
        $len = $r['CHARACTER_MAXIMUM_LENGTH'] ?? null;
        if ($len) {
            $type .= '(' . $len . ')';
        }
        $cols[] = [
            'name' => $cname,
            'type' => $type,
            'null' => (string)($r['IS_NULLABLE'] ?? ''),
            'sensitive' => invc_is_sensitive_column($cname, $type),
        ];
    }
    return $cols;
}

function invc_preview_table(PDO $pdo, $table, $limit = 20) {
    $ident = invc_ident($table);
    if (!$ident) {
        return ['columns' => [], 'rows' => [], 'error' => 'ชื่อตารางไม่ถูกต้อง'];
    }
    $cols = invc_describe_table($pdo, $table);
    if (empty($cols)) {
        return ['columns' => [], 'rows' => [], 'error' => 'ไม่พบตารางนี้ หรืออ่านโครงสร้างไม่ได้'];
    }
    $select = [];
    $headers = [];
    foreach ($cols as $c) {
        if (!empty($c['sensitive'])) {
            continue;
        }
        $colIdent = invc_ident($c['name']);
        if (!$colIdent) {
            continue;
        }
        $select[] = $colIdent;
        $headers[] = $c['name'];
        if (count($select) >= 12) {
            break;
        }
    }
    if (empty($select)) {
        return ['columns' => [], 'rows' => [], 'error' => 'คอลัมน์ที่แสดงได้ถูกซ่อนเพราะเป็นข้อมูลอ่อนไหว'];
    }
    $limit = max(1, min(50, (int)$limit));
    $sql = 'SELECT TOP ' . $limit . ' ' . implode(', ', $select) . ' FROM ' . $ident;
    $st = invc_query($pdo, $sql);
    if (!$st) {
        return ['columns' => $headers, 'rows' => [], 'error' => 'อ่านข้อมูลไม่ได้: ' . invc_last_error()];
    }
    $rows = [];
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
        $row = [];
        foreach ($headers as $h) {
            $v = $r[$h] ?? '';
            if (is_resource($v)) {
                $v = '[binary]';
            } elseif (is_string($v) && strlen($v) > 180) {
                $v = substr($v, 0, 180) . '…';
            }
            $row[$h] = $v;
        }
        $rows[] = $row;
    }
    return ['columns' => $headers, 'rows' => $rows, 'error' => ''];
}

function invc_ping($con, array $override = null) {
    $t0 = microtime(true);
    $cfg = $override ? array_merge(invc_load_config($con), $override) : invc_load_config($con);
    $drv = invc_driver_status();
    $out = [
        'ok' => false,
        'ms' => 0,
        'host' => trim((string)($cfg['invc_host'] ?? '')),
        'port' => (int)($cfg['invc_port'] ?? 1433),
        'db' => (string)($cfg['invc_db'] ?? ''),
        'user' => (string)($cfg['invc_user'] ?? ''),
        'readonly' => true,
        'engine' => 'SQL Server',
        'driver' => $drv['driver'],
        'driver_ok' => !empty($drv['ok']),
        'install_hint' => $drv['install_hint'],
        'version' => '',
        'table_count' => 0,
        'stats' => [],
        'error' => '',
    ];
    $pdo = invc_connect($con, 8, $override);
    $out['ms'] = round((microtime(true) - $t0) * 1000, 1);
    if (!$pdo) {
        $out['error'] = invc_last_error() ?: 'เชื่อมต่อ INVC ไม่ได้';
        return $out;
    }
    $ver = invc_fetch_scalar($pdo, "SELECT @@VERSION AS ver", 'ver');
    if (is_string($ver)) {
        $out['version'] = trim(preg_replace('/\s+/', ' ', $ver));
        if (strlen($out['version']) > 120) {
            $out['version'] = substr($out['version'], 0, 120) . '…';
        }
    }
    $dbn = invc_fetch_scalar($pdo, 'SELECT DB_NAME() AS db', 'db');
    if ($dbn) {
        $out['db'] = (string)$dbn;
    }
    $out['table_count'] = invc_table_count($pdo);
    $tables = invc_list_tables($pdo, '', 12);
    $stats = [];
    foreach ($tables as $t) {
        $n = invc_safe_count($pdo, $t);
        if ($n === null) {
            continue;
        }
        $stats[] = ['table' => $t, 'label' => $t, 'count' => $n];
        if (count($stats) >= 3) {
            break;
        }
    }
    $out['stats'] = $stats;
    $out['ok'] = true;
    invc_close($pdo);
    return $out;
}
