<?php
/**
 * คำนวณขนาดยาในเด็ก — ตามตาราง "ยาเด็ก" (mg/kg × น้ำหนัก, ครั้ง/วัน, mL/dose)
 */

function pdc_ensure_table($con) {
    $q = mysqli_query($con, "SHOW TABLES LIKE 'pediatric_dose_settings'");
    if ($q && mysqli_num_rows($q) > 0) {
        pdc_ensure_tolerance_column($con);
        pdc_ensure_monitor_exclude_keywords_column($con);
        pdc_seed_if_empty($con);
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/pediatric_dose.sql');
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '' && !mysqli_query($con, $stmt)) {
            return false;
        }
    }
    pdc_ensure_tolerance_column($con);
    pdc_ensure_monitor_exclude_keywords_column($con);
    pdc_seed_if_empty($con);
    return true;
}

/** เพิ่มคอลัมน์ tolerance_pct บนตารางเดิม */
function pdc_ensure_tolerance_column($con) {
    $chk = mysqli_query($con, "SHOW COLUMNS FROM pediatric_dose_settings LIKE 'tolerance_pct'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return true;
    }
    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        return (bool)mysqli_query(
            $con,
            "ALTER TABLE pediatric_dose_settings
                ADD COLUMN tolerance_pct DECIMAL(5,2) NULL DEFAULT NULL
                COMMENT 'ยอมคลาดเคลื่อน % ต่อรายการยา (NULL=ใช้ค่าทั้งระบบ)'
                AFTER max_mg_day"
        );
    } finally {
        mysqli_report($prev_mode);
    }
}

/** เพิ่มคอลัมน์ monitor_exclude_keywords บนตารางเดิม */
function pdc_ensure_monitor_exclude_keywords_column($con) {
    $chk = mysqli_query($con, "SHOW COLUMNS FROM pediatric_dose_settings LIKE 'monitor_exclude_keywords'");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return true;
    }
    $prev_mode = mysqli_report(MYSQLI_REPORT_OFF);
    try {
        return (bool)mysqli_query(
            $con,
            "ALTER TABLE pediatric_dose_settings
                ADD COLUMN monitor_exclude_keywords VARCHAR(500) NULL DEFAULT NULL
                COMMENT 'คำที่ใช้ยกเว้น monitor รายการนี้ (คั่นด้วย ,)'
                AFTER tolerance_pct"
        );
    } finally {
        mysqli_report($prev_mode);
    }
}

function pdc_escape($con, $v) {
    return mysqli_real_escape_string($con, (string)($v ?? ''));
}

function pdc_sql_num($v) {
    if ($v === null || $v === '') {
        return 'NULL';
    }
    return (string)(float)$v;
}

function pdc_fmt($val, $digits = 2) {
    if ($val === null || $val === '' || !is_numeric($val)) {
        return '—';
    }
    $n = (float)$val;
    $s = number_format($n, $digits, '.', '');
    $s = rtrim(rtrim($s, '0'), '.');
    return $s === '' ? '0' : $s;
}

function pdc_fmt_range($a, $b, $digits = 2, $suffix = '') {
    if ($a === null && $b === null) {
        return '—';
    }
    $lo = pdc_fmt($a, $digits);
    $hi = pdc_fmt($b, $digits);
    if ($lo === $hi) {
        return $lo . $suffix;
    }
    return $lo . '–' . $hi . $suffix;
}

function pdc_times_from_hours($hours) {
    $h = (float)$hours;
    if ($h <= 0) {
        return null;
    }
    return 24.0 / $h;
}

function pdc_hours_from_times($times) {
    $n = (float)$times;
    if ($n <= 0) {
        return null;
    }
    return 24.0 / $n;
}

function pdc_interval_label($times, $hours = null) {
    $n = (float)$times;
    $h = $hours !== null && $hours !== '' ? (float)$hours : pdc_hours_from_times($n);
    if ($h && $h > 0) {
        $n_disp = (abs($n - round($n)) < 0.001) ? (string)(int)round($n) : pdc_fmt($n, 2);
        return 'ทุก ' . pdc_fmt($h, 2) . ' ชม. (×' . $n_disp . '/วัน)';
    }
    if ($n > 0) {
        return 'วันละ ' . pdc_fmt($n, 2) . ' ครั้ง';
    }
    return '—';
}

function pdc_unit_label($unit) {
    return ($unit === 'mg_kg_day') ? 'mg/kg/day' : 'mg/kg/dose';
}

function pdc_category_label($cat) {
    if ($cat === 'oral') {
        return 'ยาน้ำเด็ก';
    }
    if ($cat === 'other') {
        return 'อื่น ๆ';
    }
    return 'ยาฉีด';
}

function pdc_default_catalog() {
    return [
        // ยาฉีด — จากตาราง "ขนาดยาฉีดในเด็ก"
        ['Acyclovir inj', '250 mg/10 mL', 'inject', 'mg_kg_dose', 20, 20, 3, 8, null, 25, 250, 'IV every 8 to 12 hr', 10],
        ['Amikacin inj', '500 mg/2 mL', 'inject', 'mg_kg_dose', 12, 15, 1, 24, null, 250, 500, 'IV every 24–48 hr', 20],
        ['Ampicillin inj', '1 g/5 mL', 'inject', 'mg_kg_dose', 25, 100, 4, 6, null, 200, 1000, 'IV every 6 to 12 hr', 30],
        ['Cefotaxime inj', '1 g/10 mL', 'inject', 'mg_kg_dose', 50, 200, 4, 6, null, 100, 1000, 'IV every 6 to 12 hr', 40],
        ['Ceftazidime inj', '1 g/10 mL', 'inject', 'mg_kg_day', 100, 150, 3, 8, null, 100, 1000, 'IV divided every 8 to 12 hr', 50],
        ['Ceftriaxone inj', '1 g/10 mL', 'inject', 'mg_kg_dose', 25, 100, 1, 24, 4000, 100, 1000, 'IV every 24 hr · UTI 75 mg/kg/day', 60],
        ['Dexamethasone inj', '4 mg/mL', 'inject', 'mg_kg_dose', 0.15, 0.3, 4, 6, null, 4, 4, 'IV every 6 to 24 hr', 70],
        ['Furosemide inj', '20 mg/2 mL', 'inject', 'mg_kg_dose', 1, 2, 2, 12, null, 10, 20, 'IV every 6 to 24 hr', 80],
        ['Gentamicin inj', '80 mg/2 mL', 'inject', 'mg_kg_dose', 4, 5, 1, 24, null, 40, 80, 'IV every 24–48 hr', 90],
        ['Hydrocortisone inj', '100 mg/2 mL', 'inject', 'mg_kg_dose', 0.25, 0.5, 4, 6, null, 50, 100, 'IV', 100],
        ['Meropenem inj', '1 g/20 mL', 'inject', 'mg_kg_dose', 10, 20, 3, 8, null, 50, 1000, 'IV every 8 to 12 hr', 110],
        ['Ondansetron inj', '4 mg/2 mL', 'inject', 'mg_kg_dose', 0.1, 0.15, 3, 8, 16, 2, 4, 'IV every 8 hr', 120],
        ['Piperacillin/Tazobactam inj', '4.5 g', 'inject', 'mg_kg_dose', 100, 100, 3, 8, null, 200, 4000, 'IV every 8 to 12 hr (piperacillin)', 130],
        ['Vancomycin inj', '500 mg/10 mL', 'inject', 'mg_kg_dose', 10, 15, 4, 6, null, 50, 500, 'IV every 6 to 18 hr', 140],
    ];
}

/** ยาน้ำเด็กจากตาราง Google Sheet "ยาเด็ก" — ความแรงแยกแถวเพื่อคิด mL/dose */
function pdc_oral_liquid_catalog() {
    return [
        ['Amoxicillin 125 mg/5 mL', '125 mg/5 mL', 'oral', 'mg_kg_day', 25, 50, 3, 8, null, 25, null, 'แบ่งวันละ 3 ครั้ง (ปรับเป็น 2 ได้)', 10],
        ['Amoxicillin 250 mg/5 mL', '250 mg/5 mL', 'oral', 'mg_kg_day', 25, 50, 3, 8, null, 50, null, 'แบ่งวันละ 3 ครั้ง (ปรับเป็น 2 ได้)', 20],
        ['Augmentin 400+57 mg/5 mL', '400+57 mg/5 mL', 'oral', 'mg_kg_day', 40, 50, 2, 12, null, 80, null, 'คิดตาม amoxicillin · q 12 hr · เพดาน clavulanate 600 mg/วัน', 30],
        ['Dicloxacillin 62.5 mg/5 mL', '62.5 mg/5 mL', 'oral', 'mg_kg_day', 12.5, 25, 4, 6, null, 12.5, null, 'แบ่ง q 6 hr', 40],
        ['Azithromycin 200 mg/5 mL', '200 mg/5 mL', 'oral', 'mg_kg_day', 10, 10, 1, 24, 500, 40, null, 'วันละครั้ง', 50],
        ['Cefixime 100 mg/5 mL', '100 mg/5 mL', 'oral', 'mg_kg_day', 8, 8, 2, 12, 400, 20, null, 'q 12 hr', 60],
        ['Cephalexin 125 mg/5 mL', '125 mg/5 mL', 'oral', 'mg_kg_day', 50, 100, 4, 6, null, 25, null, 'แบ่ง q 6 hr', 70],
        ['Cephalexin 250 mg/5 mL', '250 mg/5 mL', 'oral', 'mg_kg_day', 50, 100, 4, 6, null, 50, null, 'แบ่ง q 6 hr', 80],
        ['Paracetamol 120 mg/5 mL', '120 mg/5 mL', 'oral', 'mg_kg_dose', 10, 15, 4, 6, 4000, 24, null, 'q 4–6 hr · ไม่เกิน 75 mg/kg/day หรือ 4,000 mg/day', 90],
        ['Paracetamol 250 mg/5 mL', '250 mg/5 mL', 'oral', 'mg_kg_dose', 10, 15, 4, 6, 4000, 50, null, 'q 4–6 hr · ไม่เกิน 75 mg/kg/day หรือ 4,000 mg/day', 100],
        ['Ibuprofen 100 mg/5 mL', '100 mg/5 mL', 'oral', 'mg_kg_dose', 5, 10, 3, 8, 2400, 20, null, 'q 6–8 hr', 110],
        ['Salbutamol 2 mg/5 mL', '2 mg/5 mL', 'oral', 'mg_kg_dose', 0.1, 0.15, 4, 6, null, 0.4, null, 'วันละ 3–4 ครั้ง', 120],
        ['TMP/SMX (TMP 40 mg/5 mL)', '40/200 mg/5 mL', 'oral', 'mg_kg_day', 8, 12, 2, 12, null, 8, null, 'คิดตาม trimethoprim · แบ่ง q 12 hr', 130],
        ['Ambroxol 15 mg/5 mL', '15 mg/5 mL', 'oral', 'mg_kg_day', 1.2, 1.6, 3, 8, 45, 3, null, 'หรือ 7.5–15 mg TID ตามอายุ', 140],
        ['Isoniazid (Prophylaxis) 50 mg/5 mL', '50 mg/5 mL', 'oral', 'mg_kg_day', 10, 10, 1, 24, 300, 10, null, 'anti-TB prophylaxis · OD', 200],
        ['Isoniazid (Treatment) 50 mg/5 mL', '50 mg/5 mL', 'oral', 'mg_kg_day', 10, 15, 1, 24, 300, 10, null, 'anti-TB treatment · OD', 210],
        ['Rifampicin (Prophylaxis) 100 mg/5 mL', '100 mg/5 mL', 'oral', 'mg_kg_day', 10, 10, 1, 24, 600, 20, null, 'anti-TB prophylaxis · OD', 220],
        ['Rifampicin (Treatment) 100 mg/5 mL', '100 mg/5 mL', 'oral', 'mg_kg_day', 10, 20, 1, 24, 600, 20, null, 'anti-TB treatment · OD', 230],
        ['Pyrazinamide 500 mg/5 mL', '500 mg/5 mL', 'oral', 'mg_kg_day', 30, 40, 1, 24, 2000, 100, null, 'anti-TB · OD', 240],
        ['Ethambutol 400 mg/5 mL', '400 mg/5 mL', 'oral', 'mg_kg_day', 15, 20, 1, 24, 1600, 80, null, 'anti-TB · OD', 250],
    ];
}

function pdc_insert_catalog_row($con, array $r) {
    $name = pdc_escape($con, $r[0]);
    $str = pdc_escape($con, $r[1]);
    $cat = pdc_escape($con, $r[2]);
    $unit = pdc_escape($con, $r[3]);
    $note = pdc_escape($con, $r[11]);
    $sql = "INSERT INTO pediatric_dose_settings
        (icode, drug_name, strength_text, category, dose_unit,
         mg_per_kg_min, mg_per_kg_max, times_per_day, interval_hours, max_mg_day,
         monitor_exclude_keywords, mg_per_ml, mg_per_amp, note_text, sort_order, active)
        VALUES (NULL, '$name', '$str', '$cat', '$unit',
         " . pdc_sql_num($r[4]) . ", " . pdc_sql_num($r[5]) . ", " . pdc_sql_num($r[6]) . ",
         " . pdc_sql_num($r[7]) . ", " . pdc_sql_num($r[8]) . ",
         NULL, " . pdc_sql_num($r[9]) . ", " . pdc_sql_num($r[10]) . ",
         '$note', " . (int)$r[12] . ", 1)";
    return mysqli_query($con, $sql);
}

function pdc_import_catalog_rows($con, array $rows) {
    $inserted = 0;
    $skipped = 0;
    foreach ($rows as $r) {
        $name = pdc_escape($con, $r[0]);
        $chk = mysqli_query($con, "SELECT id FROM pediatric_dose_settings WHERE drug_name='$name' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            $skipped++;
            continue;
        }
        if (pdc_insert_catalog_row($con, $r)) {
            $inserted++;
        } else {
            $skipped++;
        }
    }
    return ['inserted' => $inserted, 'skipped' => $skipped];
}

function pdc_seed_if_empty($con) {
    $q = mysqli_query($con, 'SELECT COUNT(*) AS c FROM pediatric_dose_settings');
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if ((int)($row['c'] ?? 0) === 0) {
        pdc_import_catalog_rows($con, pdc_default_catalog());
    }
    pdc_import_catalog_rows($con, pdc_oral_liquid_catalog());
    mysqli_query($con, "UPDATE pediatric_dose_settings SET active=0
        WHERE category='oral' AND drug_name IN (
            'Paracetamol','Ibuprofen','Amoxicillin','Amoxicillin/Clavulanate',
            'Azithromycin','Cefixime','Cephalexin'
        )");
}

function pdc_load_items($con, $active_only = false) {
    $where = $active_only ? 'WHERE active=1' : '';
    $q = mysqli_query($con, "SELECT * FROM pediatric_dose_settings $where ORDER BY FIELD(category,'oral','inject','other'), sort_order ASC, drug_name ASC, id ASC");
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function pdc_item_public(array $r) {
    $times = (float)($r['times_per_day'] ?? 0);
    if ($times <= 0) {
        $times = 1;
    }
    $hours = isset($r['interval_hours']) && $r['interval_hours'] !== '' && $r['interval_hours'] !== null
        ? (float)$r['interval_hours'] : pdc_hours_from_times($times);
    return [
        'id' => (int)($r['id'] ?? 0),
        'icode' => trim((string)($r['icode'] ?? '')),
        'drug_name' => trim((string)($r['drug_name'] ?? '')),
        'strength_text' => trim((string)($r['strength_text'] ?? '')),
        'category' => trim((string)($r['category'] ?? 'inject')) ?: 'inject',
        'dose_unit' => (($r['dose_unit'] ?? '') === 'mg_kg_day') ? 'mg_kg_day' : 'mg_kg_dose',
        'mg_per_kg_min' => isset($r['mg_per_kg_min']) && $r['mg_per_kg_min'] !== '' && $r['mg_per_kg_min'] !== null ? (float)$r['mg_per_kg_min'] : null,
        'mg_per_kg_max' => isset($r['mg_per_kg_max']) && $r['mg_per_kg_max'] !== '' && $r['mg_per_kg_max'] !== null ? (float)$r['mg_per_kg_max'] : null,
        'times_per_day' => $times,
        'interval_hours' => ($hours !== null && $hours > 0) ? $hours : null,
        'max_mg_day' => isset($r['max_mg_day']) && $r['max_mg_day'] !== '' && $r['max_mg_day'] !== null ? (float)$r['max_mg_day'] : null,
        'tolerance_pct' => isset($r['tolerance_pct']) && $r['tolerance_pct'] !== '' && $r['tolerance_pct'] !== null
            ? (float)$r['tolerance_pct'] : null,
        'monitor_exclude_keywords' => trim((string)($r['monitor_exclude_keywords'] ?? '')),
        'mg_per_ml' => isset($r['mg_per_ml']) && $r['mg_per_ml'] !== '' && $r['mg_per_ml'] !== null ? (float)$r['mg_per_ml'] : null,
        'mg_per_amp' => isset($r['mg_per_amp']) && $r['mg_per_amp'] !== '' && $r['mg_per_amp'] !== null ? (float)$r['mg_per_amp'] : null,
        'note_text' => trim((string)($r['note_text'] ?? '')),
        'sort_order' => (int)($r['sort_order'] ?? 100),
        'active' => !empty($r['active']) ? 1 : 0,
    ];
}

function pdc_calculate(array $item, $bw, $times_override = null) {
    $bw = (float)$bw;
    $times = $times_override !== null && $times_override !== ''
        ? (float)$times_override : (float)($item['times_per_day'] ?? 1);
    if ($times <= 0) {
        $times = 1;
    }
    $lo = (float)($item['mg_per_kg_min'] ?? 0);
    $hi = (float)($item['mg_per_kg_max'] ?? 0);
    if ($hi <= 0) {
        $hi = $lo;
    }
    if ($lo <= 0) {
        $lo = $hi;
    }
    if ($bw <= 0 || ($lo <= 0 && $hi <= 0)) {
        return null;
    }
    $unit = ($item['dose_unit'] ?? '') === 'mg_kg_day' ? 'mg_kg_day' : 'mg_kg_dose';
    if ($unit === 'mg_kg_day') {
        $day_min = $bw * $lo;
        $day_max = $bw * $hi;
        $dose_min = $day_min / $times;
        $dose_max = $day_max / $times;
    } else {
        $dose_min = $bw * $lo;
        $dose_max = $bw * $hi;
        $day_min = $dose_min * $times;
        $day_max = $dose_max * $times;
    }
    $cap = (float)($item['max_mg_day'] ?? 0);
    $capped = false;
    if ($cap > 0) {
        if ($day_min > $cap) {
            $day_min = $cap;
            $capped = true;
        }
        if ($day_max > $cap) {
            $day_max = $cap;
            $capped = true;
        }
        $dose_min = $day_min / $times;
        $dose_max = $day_max / $times;
    }
    $conc = (float)($item['mg_per_ml'] ?? 0);
    $amp = (float)($item['mg_per_amp'] ?? 0);
    return [
        'times' => $times,
        'hours' => pdc_hours_from_times($times),
        'capped' => $capped,
        'mg_day_min' => $day_min,
        'mg_day_max' => $day_max,
        'mg_dose_min' => $dose_min,
        'mg_dose_max' => $dose_max,
        'ml_dose_min' => $conc > 0 ? $dose_min / $conc : null,
        'ml_dose_max' => $conc > 0 ? $dose_max / $conc : null,
        'amp_dose_min' => $amp > 0 ? $dose_min / $amp : null,
        'amp_dose_max' => $amp > 0 ? $dose_max / $amp : null,
        'amp_day_min' => $amp > 0 ? $day_min / $amp : null,
        'amp_day_max' => $amp > 0 ? $day_max / $amp : null,
    ];
}

function pdc_save_item($con, array $in, $id = 0) {
    pdc_ensure_table($con);
    $icode = trim((string)($in['icode'] ?? ''));
    $drug_name = trim((string)($in['drug_name'] ?? ''));
    $strength_text = trim((string)($in['strength_text'] ?? ''));
    $category = trim((string)($in['category'] ?? 'inject'));
    if (!in_array($category, ['inject', 'oral', 'other'], true)) {
        $category = 'inject';
    }
    $dose_unit = (($in['dose_unit'] ?? '') === 'mg_kg_day') ? 'mg_kg_day' : 'mg_kg_dose';
    $kg_min = ($in['mg_per_kg_min'] ?? '') === '' || $in['mg_per_kg_min'] === null ? null : (float)$in['mg_per_kg_min'];
    $kg_max = ($in['mg_per_kg_max'] ?? '') === '' || $in['mg_per_kg_max'] === null ? null : (float)$in['mg_per_kg_max'];
    $times = ($in['times_per_day'] ?? '') === '' || $in['times_per_day'] === null ? null : (float)$in['times_per_day'];
    $hours = ($in['interval_hours'] ?? '') === '' || $in['interval_hours'] === null ? null : (float)$in['interval_hours'];
    $max_day = ($in['max_mg_day'] ?? '') === '' || $in['max_mg_day'] === null ? null : (float)$in['max_mg_day'];
    $tol_pct = ($in['tolerance_pct'] ?? '') === '' || $in['tolerance_pct'] === null ? null : pdc_clamp_tolerance_pct($in['tolerance_pct']);
    $monitor_exclude_keywords = trim((string)($in['monitor_exclude_keywords'] ?? ''));
    $mg_per_ml = ($in['mg_per_ml'] ?? '') === '' || $in['mg_per_ml'] === null ? null : (float)$in['mg_per_ml'];
    $mg_per_amp = ($in['mg_per_amp'] ?? '') === '' || $in['mg_per_amp'] === null ? null : (float)$in['mg_per_amp'];
    $note_text = trim((string)($in['note_text'] ?? ''));
    $sort_order = (int)($in['sort_order'] ?? 100);
    $active = !empty($in['active']) ? 1 : 0;
    $id = (int)$id;

    if ($drug_name === '') {
        return ['ok' => false, 'error' => 'กรุณาระบุชื่อยา'];
    }
    if (($kg_min === null || $kg_min <= 0) && ($kg_max === null || $kg_max <= 0)) {
        return ['ok' => false, 'error' => 'กรุณาใส่ช่วงขนาดยา mg/kg'];
    }
    if ($kg_min !== null && $kg_min < 0) {
        return ['ok' => false, 'error' => 'mg/kg ต่ำสุดต้องไม่ติดลบ'];
    }
    if ($kg_max !== null && $kg_max < 0) {
        return ['ok' => false, 'error' => 'mg/kg สูงสุดต้องไม่ติดลบ'];
    }
    if ($kg_min !== null && $kg_max !== null && $kg_max < $kg_min) {
        return ['ok' => false, 'error' => 'mg/kg สูงสุดต้องไม่น้อยกว่าค่าต่ำสุด'];
    }
    if ($hours !== null && $hours > 0) {
        $times = pdc_times_from_hours($hours);
    } elseif ($times === null || $times <= 0) {
        $times = 1;
    }
    if ($hours === null || $hours <= 0) {
        $hours = pdc_hours_from_times($times);
    }
    if ($mg_per_ml !== null && $mg_per_ml < 0) {
        return ['ok' => false, 'error' => 'mg/mL ต้องไม่ติดลบ'];
    }

    $icode_e = $icode === '' ? 'NULL' : "'" . pdc_escape($con, $icode) . "'";
    $name_e = pdc_escape($con, $drug_name);
    $str_e = pdc_escape($con, $strength_text);
    $cat_e = pdc_escape($con, $category);
    $exclude_e = pdc_escape($con, $monitor_exclude_keywords);
    $exclude_sql = ($monitor_exclude_keywords === '') ? 'NULL' : "'$exclude_e'";
    $note_e = pdc_escape($con, $note_text);

    if ($id > 0) {
        $ok = mysqli_query($con, "UPDATE pediatric_dose_settings SET
            icode=$icode_e,
            drug_name='$name_e',
            strength_text='$str_e',
            category='$cat_e',
            dose_unit='$dose_unit',
            mg_per_kg_min=" . pdc_sql_num($kg_min) . ",
            mg_per_kg_max=" . pdc_sql_num($kg_max) . ",
            times_per_day=" . pdc_sql_num($times) . ",
            interval_hours=" . pdc_sql_num($hours) . ",
            max_mg_day=" . pdc_sql_num($max_day) . ",
            tolerance_pct=" . pdc_sql_num($tol_pct) . ",
            monitor_exclude_keywords=" . $exclude_sql . ",
            mg_per_ml=" . pdc_sql_num($mg_per_ml) . ",
            mg_per_amp=" . pdc_sql_num($mg_per_amp) . ",
            note_text='$note_e',
            sort_order=$sort_order,
            active=$active
            WHERE id=$id");
        if (!$ok) {
            return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ: ' . mysqli_error($con)];
        }
        return ['ok' => true, 'id' => $id, 'message' => 'บันทึกการแก้ไขเรียบร้อย'];
    }

    $ok = mysqli_query($con, "INSERT INTO pediatric_dose_settings
        (icode, drug_name, strength_text, category, dose_unit,
         mg_per_kg_min, mg_per_kg_max, times_per_day, interval_hours, max_mg_day, tolerance_pct,
         monitor_exclude_keywords, mg_per_ml, mg_per_amp, note_text, sort_order, active)
        VALUES ($icode_e, '$name_e', '$str_e', '$cat_e', '$dose_unit',
         " . pdc_sql_num($kg_min) . ", " . pdc_sql_num($kg_max) . ", " . pdc_sql_num($times) . ",
         " . pdc_sql_num($hours) . ", " . pdc_sql_num($max_day) . ", " . pdc_sql_num($tol_pct) . ",
         " . $exclude_sql . ", " . pdc_sql_num($mg_per_ml) . ", " . pdc_sql_num($mg_per_amp) . ",
         '$note_e', $sort_order, $active)");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ: ' . mysqli_error($con)];
    }
    return ['ok' => true, 'id' => (int)mysqli_insert_id($con), 'message' => 'เพิ่มรายการยาเรียบร้อย'];
}

function pdc_split_keywords($text) {
    $raw = trim((string)$text);
    if ($raw === '') {
        return [];
    }
    $parts = preg_split('/[,;\r\n]+/u', $raw);
    $out = [];
    foreach ($parts as $p) {
        $k = trim((string)$p);
        if ($k !== '') {
            $out[] = $k;
        }
    }
    return array_values(array_unique($out));
}

/**
 * ยกเว้น monitor รายการนี้ เมื่อข้อความวิธีใช้/ชื่อยามีคำที่กำหนดใน monitor_exclude_keywords
 */
function pdc_should_exclude_order(array $rule, array $row) {
    $keywords = pdc_split_keywords($rule['monitor_exclude_keywords'] ?? '');
    if (empty($keywords)) {
        return false;
    }
    $blob = trim(
        (string)($row['method'] ?? '') . ' '
        . (string)($row['drug_name'] ?? '') . ' '
        . (string)($row['strength'] ?? '')
    );
    if ($blob === '') {
        return false;
    }
    foreach ($keywords as $kw) {
        $found = function_exists('mb_stripos')
            ? (mb_stripos($blob, $kw) !== false)
            : (stripos($blob, $kw) !== false);
        if ($found) {
            return true;
        }
    }
    return false;
}

function pdc_load_monitor_rules($con, array $rule_ids = []) {
    pdc_ensure_table($con);
    $rows = pdc_load_items($con, true);
    $filter = [];
    foreach ($rule_ids as $rid) {
        $rid = (int)$rid;
        if ($rid > 0) {
            $filter[$rid] = true;
        }
    }
    $out = [];
    foreach ($rows as $r) {
        if (!empty($filter) && !isset($filter[(int)$r['id']])) {
            continue;
        }
        $item = pdc_item_public($r);
        if (($item['mg_per_kg_min'] === null || $item['mg_per_kg_min'] <= 0)
            && ($item['mg_per_kg_max'] === null || $item['mg_per_kg_max'] <= 0)) {
            continue;
        }
        $out[] = $item;
    }
    return $out;
}

function pdc_item_keyword(array $item) {
    $name = strtolower(trim((string)($item['drug_name'] ?? '')));
    $name = preg_replace('/\([^)]*\)/u', ' ', $name);
    $name = preg_replace('/\b(inj|injection|syrup|syr|oral|tab|cap)\b/u', ' ', $name);
    $name = trim(preg_replace('/\s+/u', ' ', $name));
    if (preg_match('/^([a-z][a-z0-9+\/\-]*(?:\s+[a-z][a-z0-9+\/\-]*){0,2})/u', $name, $m)) {
        $kw = strtolower(trim($m[1]));
        if (strlen($kw) >= 3) {
            return $kw;
        }
    }
    return $name !== '' ? $name : '';
}

function pdc_item_strength_num(array $item) {
    $blob = (string)($item['drug_name'] ?? '') . ' ' . (string)($item['strength_text'] ?? '');
    if (preg_match('/(\d+(?:\.\d+)?)\s*mg\b/iu', $blob, $m)) {
        return $m[1];
    }
    return '';
}

function pdc_match_icodes_from_catalog(array $item, array $catalog) {
    $saved = trim((string)($item['icode'] ?? ''));
    if ($saved !== '') {
        return [$saved];
    }
    $kw = pdc_item_keyword($item);
    if ($kw === '' || strlen($kw) < 3) {
        return [];
    }
    $kw_l = function_exists('mb_strtolower') ? mb_strtolower($kw, 'UTF-8') : strtolower($kw);
    $num = pdc_item_strength_num($item);
    $cat = $item['category'] ?? 'oral';
    $out = [];
    foreach ($catalog as $r) {
        $blob = strtolower(($r['name_local'] ?? '') . ' ' . ($r['name_tmt'] ?? '') . ' ' . ($r['strength'] ?? ''));
        if ($blob === '' || strpos($blob, $kw_l) === false) {
            continue;
        }
        if (function_exists('mmgml_catalog_is_non_injectable') && mmgml_catalog_is_non_injectable($blob)) {
            continue;
        }
        if ($cat === 'oral' && preg_match('/\b(inj|injection|vial|ampoule|tab|tablet|cap|capsule|เม็ด)\b/u', $blob)) {
            continue;
        }
        if ($cat === 'inject' && preg_match('/\b(syrup|suspension|oral|ยาน้ำ)\b/u', $blob)) {
            continue;
        }
        if ($num !== '' && strpos($blob, strtolower($num)) === false) {
            continue;
        }
        $ic = trim((string)($r['icode'] ?? ''));
        if ($ic !== '') {
            $out[$ic] = true;
        }
        if (count($out) >= 12) {
            break;
        }
    }
    return array_keys($out);
}

function pdc_load_hosxp_name_catalog($hos, array $keywords) {
    $catalog = [];
    if (!$hos || empty($keywords)) {
        return $catalog;
    }
    $likes = [];
    foreach ($keywords as $kw) {
        $kw = trim((string)$kw);
        if (strlen($kw) < 3) {
            continue;
        }
        $esc = mysqli_real_escape_string($hos, $kw);
        $likes[$esc] = "LOWER(d.name) LIKE '%$esc%'";
    }
    if (empty($likes)) {
        return $catalog;
    }
    $sql = "SELECT d.icode,
                   CAST(CONVERT(d.name USING utf8) AS CHAR) AS name_local,
                   CAST(CONVERT(IFNULL(d.strength,'') USING utf8) AS CHAR) AS strength
            FROM drugitems d
            WHERE d.istatus = 'Y'
              AND (" . implode(' OR ', array_values($likes)) . ")
            LIMIT 4000";
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return $catalog;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $r['name_tmt'] = $r['name_local'] ?? '';
        $catalog[] = $r;
    }
    return $catalog;
}

function pdc_find_icodes_for_item($hos, array $item) {
    $saved = trim((string)($item['icode'] ?? ''));
    if ($saved !== '') {
        return [$saved];
    }
    $kw = pdc_item_keyword($item);
    if ($kw === '' || strlen($kw) < 3 || !$hos) {
        return [];
    }
    return pdc_match_icodes_from_catalog($item, pdc_load_hosxp_name_catalog($hos, [$kw]));
}

function pdc_build_icode_rule_map($hos, array $rules) {
    $map = [];
    $need_search = [];
    $keywords = [];
    foreach ($rules as $rule) {
        $saved = trim((string)($rule['icode'] ?? ''));
        if ($saved !== '') {
            if (!isset($map[$saved])) {
                $map[$saved] = [];
            }
            $map[$saved][] = $rule;
            continue;
        }
        $need_search[] = $rule;
        $kw = pdc_item_keyword($rule);
        if ($kw !== '' && strlen($kw) >= 3) {
            $keywords[$kw] = true;
        }
    }
    if (empty($need_search) || !$hos) {
        return $map;
    }
    $catalog = pdc_load_hosxp_name_catalog($hos, array_keys($keywords));
    foreach ($need_search as $rule) {
        foreach (pdc_match_icodes_from_catalog($rule, $catalog) as $ic) {
            if (!isset($map[$ic])) {
                $map[$ic] = [];
            }
            $map[$ic][] = $rule;
        }
    }
    return $map;
}

function pdc_default_tolerance_pct() {
    return 20.0;
}

function pdc_clamp_tolerance_pct($v) {
    if ($v === null || $v === '' || !is_numeric($v)) {
        return pdc_default_tolerance_pct();
    }
    $n = (float)$v;
    if ($n < 0) {
        $n = 0;
    }
    if ($n > 100) {
        $n = 100;
    }
    return $n;
}

function pdc_get_monitor_tolerance_pct($con) {
    if (!$con) {
        return pdc_default_tolerance_pct();
    }
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='pdc_monitor_tolerance_pct' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q)) && $r['config_value'] !== '' && $r['config_value'] !== null) {
        return pdc_clamp_tolerance_pct($r['config_value']);
    }
    return pdc_default_tolerance_pct();
}

function pdc_save_monitor_tolerance_pct($con, $pct) {
    $pct = pdc_clamp_tolerance_pct($pct);
    $esc = mysqli_real_escape_string($con, rtrim(rtrim(number_format($pct, 2, '.', ''), '0'), '.') ?: '0');
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='pdc_monitor_tolerance_pct' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        mysqli_query($con, "UPDATE sys_config SET config_value='$esc' WHERE config_name='pdc_monitor_tolerance_pct'");
    } else {
        mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('pdc_monitor_tolerance_pct', '$esc')");
    }
    return $pct;
}

/** ยอมคลาดเคลื่อน % ที่ใช้จริง — รายการยากำหนดเอง หรือใช้ค่าทั้งระบบ */
function pdc_effective_tolerance_pct(array $rule, $global_tol = null, $con = null) {
    if (isset($rule['tolerance_pct']) && $rule['tolerance_pct'] !== '' && $rule['tolerance_pct'] !== null) {
        return pdc_clamp_tolerance_pct($rule['tolerance_pct']);
    }
    if ($global_tol !== null && $global_tol !== '') {
        return pdc_clamp_tolerance_pct($global_tol);
    }
    if ($con) {
        return pdc_get_monitor_tolerance_pct($con);
    }
    return pdc_default_tolerance_pct();
}

/**
 * วิธีใช้ระบุขนาดเป็น mg/g หรือไม่ — ไม่นับปริมาตรในวงเล็บ เช่น 4 mg (2 ml)
 */
function pdc_method_has_mg_dose($method) {
    $m = preg_replace('/\([^)]*(?:ml|ซีซี|cc|มล)[^)]*\)/iu', ' ', (string)$method);
    $m = trim($m);
    if ($m === '') {
        return false;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|μg|ug|ไมโครกรัม)/iu', $m)) {
        return true;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*mg(?!cg)/i', $m)) {
        return true;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:gm|กรัม)/iu', $m)) {
        return true;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*g(?![a-zA-Z])/iu', $m)) {
        return true;
    }
    return false;
}

/** หน่วยที่สั่งในวิธีใช้: mg หรือ ml (ซีซี) */
function pdc_detect_order_unit($method, array $parse = []) {
    if (pdc_method_has_mg_dose($method)) {
        return 'mg';
    }
    $ml = $parse['ml_dose'] ?? null;
    if ($ml === null || $ml === '') {
        $ml = pdc_extract_ml_per_dose($method);
    }
    if ($ml !== null && $ml !== '' && (float)$ml > 0) {
        return 'ml';
    }
    return 'mg';
}

function pdc_round_practical($v, $unit) {
    $n = (float)$v;
    if ($n <= 0) {
        return 0.0;
    }
    if ($unit === 'ml') {
        if ($n >= 10) {
            return (float)round($n);
        }
        if ($n >= 1) {
            return round($n * 2) / 2.0;
        }
        return round($n, 1);
    }
    if ($n >= 100) {
        return (float)round($n);
    }
    if ($n >= 10) {
        return round($n, 1);
    }
    return round($n, 2);
}

/**
 * แนะนำขนาดยาในหน่วยเดียวกับวิธีใช้ และให้อยู่ในช่วงที่เหมาะสม
 */
function pdc_build_dose_suggestion(array $eval, array $parse, $method = '') {
    $unit = pdc_detect_order_unit($method, $parse);
    $basis = (($eval['dose_basis'] ?? '') === 'dose') ? 'dose' : 'day';
    $times = (float)($parse['times'] ?? $eval['times'] ?? 1);
    if ($times <= 0) {
        $times = 1;
    }
    $min = (float)($eval['expected_min'] ?? 0);
    $max = (float)($eval['expected_max'] ?? 0);
    $conc = (float)($parse['mg_per_ml'] ?? 0);
    $digits = 1;

    $out_unit = 'mg';
    $out_suffix = ($basis === 'dose') ? 'mg/ครั้ง' : 'mg/วัน';
    $lo = $min;
    $hi = $max;

    if ($unit === 'ml' && $conc > 0 && $min > 0 && $max > 0) {
        $out_unit = 'ml';
        $out_suffix = 'ซีซี/ครั้ง';
        if ($basis === 'dose') {
            $lo = $min / $conc;
            $hi = $max / $conc;
        } else {
            $lo = ($min / $times) / $conc;
            $hi = ($max / $times) / $conc;
        }
    }
    if ($lo > $hi) {
        $tmp = $lo;
        $lo = $hi;
        $hi = $tmp;
    }

    $mid = ($lo + $hi) / 2.0;
    $dir = $eval['dose_direction'] ?? null;
    if ($dir === 'high') {
        $suggest = $hi;
    } elseif ($dir === 'low') {
        $suggest = $lo;
    } else {
        $suggest = $mid;
    }
    $suggest = pdc_round_practical($suggest, $out_unit);
    $slack = max(0.05, abs($hi) * 0.05);
    if ($suggest < $lo - $slack) {
        $suggest = $lo;
    }
    if ($suggest > $hi + $slack) {
        $suggest = $hi;
    }

    $freq = '';
    if ($out_unit === 'ml' && $times > 1 && $basis === 'day') {
        $freq = ' วันละ ' . pdc_fmt($times, 1) . ' ครั้ง';
    }
    $range_txt = pdc_fmt($lo, $digits) . '–' . pdc_fmt($hi, $digits) . ' ' . $out_suffix . $freq;
    $value_txt = pdc_fmt($suggest, $digits) . ' ' . $out_suffix . $freq;
    $text = 'ควรให้ ' . $value_txt;
    if (abs($hi - $lo) > 0.05) {
        $text .= ' (ช่วงเหมาะสม ' . pdc_fmt($lo, $digits) . '–' . pdc_fmt($hi, $digits) . ' ' . $out_suffix . ')';
    }

    $ordered_txt = '';
    if ($out_unit === 'ml' && isset($parse['ml_dose']) && (float)$parse['ml_dose'] > 0) {
        $ordered_txt = pdc_fmt($parse['ml_dose'], $digits) . ' ซีซี/ครั้ง' . $freq;
    } elseif (isset($eval['daily_mg']) && $eval['daily_mg'] !== null) {
        $ordered_txt = pdc_fmt($eval['daily_mg'], $digits) . ' ' . (($eval['unit_suffix'] ?? '') !== ''
            ? $eval['unit_suffix']
            : $out_suffix);
    }

    return [
        'order_unit' => $out_unit,
        'suffix' => $out_suffix,
        'min' => $lo,
        'max' => $hi,
        'value' => $suggest,
        'range_text' => $range_txt,
        'value_text' => $value_txt,
        'ordered_text' => $ordered_txt,
        'text' => $text,
        'times' => $times,
    ];
}

/** ข้อความช่วงที่ควรได้ใน Monitor — หน่วยเดียวกับวิธีใช้ ถ้าแปลงได้ */
function pdc_format_monitor_expected_display(array $eval, $tol_pct = null) {
    if (!empty($eval['suggest_range_text'])) {
        return $eval['suggest_range_text'];
    }
    $unit = trim((string)($eval['unit_suffix'] ?? ''));
    if ($unit === '') {
        $unit = (($eval['dose_basis'] ?? '') === 'dose') ? 'mg/ครั้ง' : 'mg/วัน';
    }
    if (isset($eval['allow_min'], $eval['allow_max'])
        && ($eval['allow_min'] !== null || $eval['allow_max'] !== null)
    ) {
        $lo = (float)$eval['allow_min'];
        $hi = (float)$eval['allow_max'];
        $tol = pdc_fmt($eval['tolerance_pct'] ?? $tol_pct ?? pdc_default_tolerance_pct(), 1);
        return pdc_fmt($lo, 1) . '–' . pdc_fmt($hi, 1) . ' ' . $unit . ' (±' . $tol . '%)';
    }
    if (!isset($eval['expected_min'], $eval['expected_max'])) {
        return '—';
    }
    $tol = pdc_fmt($eval['tolerance_pct'] ?? $tol_pct ?? pdc_default_tolerance_pct(), 1);
    return pdc_fmt($eval['expected_min'], 1) . '–' . pdc_fmt($eval['expected_max'], 1) . ' ' . $unit . ' (±' . $tol . '%)';
}

/** ความแรงสำหรับแสดงใน Monitor — TMT > HOSxP > กฎ settings */
function pdc_format_strength_display(array $row, array $rule, array $parse = []) {
    $tmt_s = trim((string)($row['strength'] ?? ''));
    $hos_s = trim((string)($row['strength_hosxp'] ?? ''));
    if ($hos_s === '') {
        $hos_s = $tmt_s;
    }
    if ($tmt_s !== '') {
        return $tmt_s;
    }
    if ($hos_s !== '') {
        return $hos_s;
    }
    $rule_s = trim((string)($rule['strength_text'] ?? ''));
    if ($rule_s !== '') {
        return $rule_s;
    }
    if (!empty($parse['mg_per_ml'])) {
        return pdc_fmt($parse['mg_per_ml'], 2) . ' mg/mL';
    }
    return '—';
}

/** ป้าย Low / High dose สำหรับ Monitor */
function pdc_dose_direction_label($dir) {
    if ($dir === 'high') {
        return 'High dose';
    }
    if ($dir === 'low') {
        return 'Low dose';
    }
    return '';
}

/**
 * วิธีใช้แบบพ่นยา / สูดพ่น — ไม่นำไปตรวจขนาดยาเด็ก (เช่น พ่นยา, สูดพ่นยาเข้าทางปาก)
 */
function pdc_is_nebulization_method($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return false;
    }
    if (preg_match('/พ่น/u', $m)) {
        return true;
    }
    if (preg_match('/\b(?:nebuli[sz]e(?:r|d)?|nebulisation|nebulization|inhalation|inhale|aerosol)\b/iu', $m)) {
        return true;
    }
    return false;
}

function pdc_extract_ml_per_dose($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return null;
    }
    // ช้อนชา = 5 mL, ช้อนโต๊ะ = 15 mL
    // 3/4 ช้อนชา, ค่อนช้อนชา / ค่อน ช้อนชา → 3.75 mL
    if (preg_match('/(?:3\s*\/\s*4|¾)\s*ช้อนชา/ui', $m)
        || preg_match('/ค่อน\s*ช้อนชา/ui', $m)
    ) {
        return 3.75;
    }
    // ครึ่งช้อนชา / ช้อนชาครึ่ง / 1 ช้อนชาครึ่ง → 2.5 / 7.5 mL
    if (preg_match('/(\d+(?:\.\d+)?)\s*ช้อนชา\s*ครึ่ง/ui', $m, $x)
        || preg_match('/(\d+(?:\.\d+)?)\s*ช้อนชาครึ่ง/ui', $m, $x)
    ) {
        return ((float)$x[1] + 0.5) * 5.0;
    }
    if (preg_match('/(?:ครึ่ง\s*ช้อนชา|ช้อนชา\s*ครึ่ง|ช้อนชาครึ่ง)/ui', $m)) {
        return 2.5;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*ช้อนชา/ui', $m, $x)) {
        return (float)$x[1] * 5.0;
    }
    // ค่อนช้อนโต๊ะ / 3/4 ช้อนโต๊ะ → 11.25 mL
    if (preg_match('/(?:3\s*\/\s*4|¾)\s*ช้อนโต๊ะ/ui', $m)
        || preg_match('/ค่อน\s*ช้อนโต๊ะ/ui', $m)
    ) {
        return 11.25;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*ช้อนโต๊ะ\s*ครึ่ง/ui', $m, $x)
        || preg_match('/(\d+(?:\.\d+)?)\s*ช้อนโต๊ะครึ่ง/ui', $m, $x)
    ) {
        return ((float)$x[1] + 0.5) * 15.0;
    }
    if (preg_match('/(?:ครึ่ง\s*ช้อนโต๊ะ|ช้อนโต๊ะ\s*ครึ่ง|ช้อนโต๊ะครึ่ง)/ui', $m)) {
        return 7.5;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*ช้อนโต๊ะ/ui', $m, $x)) {
        return (float)$x[1] * 15.0;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:ซีซี|ซี\.?\s*ซี\.?|cc|ml|มล\.?)/iu', $m, $x)) {
        $n = (float)$x[1];
        if ($n > 0 && $n <= 100) {
            return $n;
        }
    }
    return null;
}

/** แปลงความแรงจาก HOSxP/กฎ → mg/mL (รองรับ 50 mg./ml. และ 50 mg/5 mL) */
function pdc_parse_mg_per_ml_from_strength($strength) {
    $s = trim((string)$strength);
    if ($s === '') {
        return null;
    }
    if (function_exists('mmgml_parse_concentration_from_strength')) {
        $p = mmgml_parse_concentration_from_strength($s);
        if ($p && (float)($p['mg_per_ml'] ?? 0) > 0) {
            return (float)$p['mg_per_ml'];
        }
    }
    // HOSxP: 50 mg./ml. หรือ 50 mg./ml.30mL
    if (preg_match('/(\d+(?:\.\d+)?)\s*mg\.?\s*\/\s*ml\.?/iu', $s, $m)) {
        return (float)$m[1];
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*mg\s*\/\s*(\d+(?:\.\d+)?)\s*ml/iu', $s, $m)) {
        $vol = (float)$m[2];
        if ($vol > 0) {
            return (float)$m[1] / $vol;
        }
    }
    return null;
}

function pdc_resolve_mg_per_ml(array $item, $strength = '', $drug_name = '') {
    // ความแรงจากใบสั่ง HOSxP มาก่อน (เช่น ISONIAZID 50 mg./ml.)
    $from_order = pdc_parse_mg_per_ml_from_strength($strength);
    if ($from_order !== null && $from_order > 0) {
        return $from_order;
    }
    $c = (float)($item['mg_per_ml'] ?? 0);
    if ($c > 0) {
        return $c;
    }
    $blob = trim(
        (string)$strength . ' ' . (string)$drug_name . ' '
        . (string)($item['strength_text'] ?? '') . ' ' . (string)($item['drug_name'] ?? '')
    );
    if ($blob === '') {
        return null;
    }
    $from_blob = pdc_parse_mg_per_ml_from_strength($blob);
    if ($from_blob !== null && $from_blob > 0) {
        return $from_blob;
    }
    return null;
}

/**
 * วิธีใช้ว่าง / ไม่ระบุ / เป็นเครื่องหมายขีด — ประเมินขนาดยาไม่ได้
 */
function pdc_method_is_blank($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return true;
    }
    $norm = preg_replace('/\s+/u', '', $m);
    if ($norm === '' || $norm === null) {
        return true;
    }
    // -, –, —, _, ., /, * หรือซ้ำกัน
    if (preg_match('/^[\-\x{2013}\x{2014}_.\/\*]+$/u', $norm)) {
        return true;
    }
    if (preg_match('/^(?:n\/?a|none|null|undefined|ไม่ระบุ|ไม่มี|ว่าง)$/iu', $norm)) {
        return true;
    }
    return false;
}

/**
 * ขนาด mg จากวิธีใช้ — ยาน้ำ: mL×ความเข้ม×ครั้ง; เม็ด: strength×เม็ด×ครั้ง
 * ถ้ากฎเป็น mg/kg/dose และวิธีใช้ไม่ระบุช่วงเวลา → คิดเป็นขนาดต่อครั้ง (ไม่คูณครั้ง/วันจากกฎ)
 */
function pdc_parse_order_daily_mg(array $row, array $rule) {
    $method = trim((string)($row['method'] ?? ''));
    if (pdc_method_is_blank($method)) {
        return [
            'daily_mg' => null,
            'ml_dose' => null,
            'mg_per_ml' => pdc_resolve_mg_per_ml($rule, $row['strength'] ?? '', $row['drug_name'] ?? ''),
            'times' => 1.0,
            'dose_basis' => 'dose',
            'note' => '',
            'method_blank' => true,
        ];
    }
    $times_from_method = function_exists('hosxp_parse_times_per_day') ? hosxp_parse_times_per_day($method) : null;
    $dose_unit = (($rule['dose_unit'] ?? '') === 'mg_kg_day') ? 'mg_kg_day' : 'mg_kg_dose';
    $is_stat = (bool)preg_match('/\b(?:stat|asap|now)\b/iu', $method)
        || (bool)preg_match('/ครั้งเดียว|ทันที|ฉุกเฉิน/u', $method);
    // mg/kg/dose + ไม่มีช่วงเวลาในวิธีใช้ (หรือ STAT) → ตรวจต่อครั้ง ไม่สมมติ ×3 จากกฎ
    $per_dose = ($dose_unit === 'mg_kg_dose' && ($is_stat || $times_from_method === null || $times_from_method <= 0));
    $times = $times_from_method;
    if ($times === null || $times <= 0) {
        $times = $per_dose ? 1.0 : (float)($rule['times_per_day'] ?? 1);
    }
    if ($times <= 0) {
        $times = 1;
    }
    $dose_basis = $per_dose ? 'dose' : 'day';

    $ml = pdc_extract_ml_per_dose($method);
    $conc = pdc_resolve_mg_per_ml($rule, $row['strength'] ?? '', $row['drug_name'] ?? '');
    if ($ml !== null && $ml > 0 && $conc !== null && $conc > 0) {
        $daily = $ml * $conc * $times;
        $note = pdc_fmt($ml, 2) . ' mL × ' . pdc_fmt($conc, 2) . ' mg/mL';
        if ($per_dose) {
            $note .= ' (ต่อครั้ง)';
        } elseif ($times != 1.0) {
            $note .= ' × ' . pdc_fmt($times, 2) . ' ครั้ง/วัน';
        }
        return [
            'daily_mg' => $daily,
            'ml_dose' => $ml,
            'mg_per_ml' => $conc,
            'times' => $times,
            'dose_basis' => $dose_basis,
            'note' => $note,
        ];
    }

    // เม็ด/tab × ความแรง × ครั้ง/วัน เช่น 1 เม็ด ทุก 8 ชั่วโมง ที่ 4 mg = 12 mg/วัน
    if (function_exists('hosxp_parse_qty_from_usage') && function_exists('hosxp_parse_strength_mg')) {
        $from_usage = hosxp_parse_qty_from_usage($method);
        $pill_unit = (string)($from_usage['unit'] ?? '');
        if ($from_usage && preg_match('/เม็ด|tab|cap/ui', $pill_unit)) {
            $strength_mg = hosxp_parse_strength_mg($row['strength'] ?? '', $row['units'] ?? '');
            if ($strength_mg === null || $strength_mg <= 0) {
                $strength_mg = hosxp_parse_strength_mg($rule['strength_text'] ?? '', '');
            }
            if ($strength_mg !== null && $strength_mg > 0) {
                $pills = (float)$from_usage['qty'];
                $freq = ($times_from_method !== null && $times_from_method > 0) ? $times_from_method : 1.0;
                $daily = $strength_mg * $pills * $freq;
                $pill_basis = ($times_from_method === null || $times_from_method <= 0) ? 'dose' : 'day';
                return [
                    'daily_mg' => $daily,
                    'ml_dose' => $ml,
                    'mg_per_ml' => $conc,
                    'times' => $freq,
                    'dose_basis' => $pill_basis,
                    'note' => pdc_fmt($strength_mg, 1) . ' mg × ' . pdc_fmt($pills, 2) . ' เม็ด'
                        . ($freq != 1.0 ? ' × ' . pdc_fmt($freq, 2) . ' ครั้ง/วัน' : ($pill_basis === 'dose' ? ' (ต่อครั้ง)' : '')),
                ];
            }
        }
    }

    $mg = function_exists('hosxp_extract_mg_from_usage') ? hosxp_extract_mg_from_usage($method) : null;
    if ($mg !== null && $mg > 0) {
        $daily = $mg * $times;
        $note = pdc_fmt($mg, 1) . ' mg';
        if ($per_dose) {
            $note .= ' (ต่อครั้ง)';
        } elseif ($times != 1.0) {
            $note .= ' × ' . pdc_fmt($times, 2) . ' ครั้ง/วัน';
        } else {
            $note .= ' จากวิธีใช้';
        }
        return [
            'daily_mg' => $daily,
            'ml_dose' => $ml,
            'mg_per_ml' => $conc,
            'times' => $times,
            'dose_basis' => $dose_basis,
            'note' => $note,
        ];
    }

    if (function_exists('hosxp_parse_drug_daily_dose_mg')) {
        $parsed = hosxp_parse_drug_daily_dose_mg([
            'qty' => $row['qty'] ?? null,
            'strength' => $row['strength'] ?? '',
            'units' => $row['units'] ?? '',
            'method' => $method,
        ]);
        $daily = isset($parsed['mg_dose']) ? (float)$parsed['mg_dose'] : null;
        if ($daily !== null && $daily > 0) {
            return [
                'daily_mg' => $daily,
                'ml_dose' => $ml,
                'mg_per_ml' => $conc,
                'times' => $times,
                'dose_basis' => $dose_basis,
                'note' => $parsed['mg_note'] ?? '',
            ];
        }
    }

    return [
        'daily_mg' => null,
        'ml_dose' => $ml,
        'mg_per_ml' => $conc,
        'times' => $times,
        'dose_basis' => $dose_basis,
        'note' => '',
    ];
}

function pdc_evaluate_order(array $item, $bw, $daily_mg, $method = '', $tol_pct = null, array $parse = []) {
    $bw = (float)$bw;
    if ($bw <= 0) {
        return ['status' => 'unverifiable', 'reason' => 'ไม่พบน้ำหนัก'];
    }
    if (pdc_method_is_blank($method) || !empty($parse['method_blank'])) {
        return [
            'status' => 'unverifiable',
            'reason' => 'ประเมินไม่ได้ — ไม่ระบุวิธีใช้',
            'message' => 'ประเมินไม่ได้ — ไม่ระบุวิธีใช้',
        ];
    }
    $daily_mg = $daily_mg !== null && $daily_mg !== '' ? (float)$daily_mg : null;
    if ($daily_mg === null || $daily_mg <= 0) {
        return ['status' => 'unverifiable', 'reason' => 'ประเมินไม่ได้ — อ่านขนาดยาจากวิธีใช้ไม่ได้'];
    }
    $times_from_method = function_exists('hosxp_parse_times_per_day') ? hosxp_parse_times_per_day($method) : null;
    $dose_unit = (($item['dose_unit'] ?? '') === 'mg_kg_day') ? 'mg_kg_day' : 'mg_kg_dose';
    $is_stat = (bool)preg_match('/\b(?:stat|asap|now)\b/iu', $method)
        || (bool)preg_match('/ครั้งเดียว|ทันที|ฉุกเฉิน/u', $method);
    $dose_basis = ($parse['dose_basis'] ?? '') === 'dose'
        || ($dose_unit === 'mg_kg_dose' && ($is_stat || $times_from_method === null || $times_from_method <= 0))
        ? 'dose' : 'day';
    // ต่อครั้ง: คำนวณช่วงด้วย times=1; ต่อวัน: ใช้ครั้งจากวิธีใช้ (หรือค่าเริ่มต้นในกฎ)
    $times_for_calc = ($dose_basis === 'dose')
        ? 1.0
        : (($times_from_method !== null && $times_from_method > 0) ? $times_from_method : null);
    $calc = pdc_calculate($item, $bw, $times_for_calc);
    if (!$calc) {
        return ['status' => 'unverifiable', 'reason' => 'คำนวณช่วงขนาดยาไม่ได้'];
    }
    $tol_pct = pdc_clamp_tolerance_pct($tol_pct);
    $tol = $tol_pct / 100.0;
    $unit_suffix = ($dose_basis === 'dose') ? 'mg/ครั้ง' : 'mg/วัน';
    $kg_suffix = ($dose_basis === 'dose') ? 'mg/kg/dose' : 'mg/kg/วัน';
    $min = (float)$calc['mg_day_min'];
    $max = (float)$calc['mg_day_max'];
    $allow_min = $min > 0 ? $min * (1 - $tol) : 0;
    $allow_max = $max > 0 ? $max * (1 + $tol) : 0;
    $hard_max = $max > 0 ? $max * max(1.50, 1 + $tol) : 0;
    $cap = (float)($item['max_mg_day'] ?? 0);
    // เพดาน max mg/วัน ใช้เฉพาะเมื่อเทียบต่อวัน
    $over_cap = ($dose_basis === 'day') && $cap > 0 && $daily_mg > $cap + 0.05;
    $mg_kg = $bw > 0 ? ($daily_mg / $bw) : null;
    $over_hard = $hard_max > 0 && $daily_mg > $hard_max + 0.05;
    $over_max = $allow_max > 0 && $daily_mg > $allow_max + 0.05;
    $under_min = $allow_min > 0 && $daily_mg < $allow_min - 0.05;
    $in_exact = ($min <= 0 || $daily_mg >= $min - 0.05) && ($max <= 0 || $daily_mg <= $max + 0.05);
    $status = 'pass';
    $level = 'soft';
    $reason = '';
    $dose_direction = null;
    if ($over_cap || $over_hard) {
        $status = 'alert';
        $level = 'hard';
        $dose_direction = 'high';
        $reason = $over_cap
            ? 'เกิน max mg/วัน (' . pdc_fmt($cap, 1) . ' mg)'
            : 'เกินช่วงสูงสุดมากกว่า ' . pdc_fmt(max(1.50, 1 + $tol), 2) . ' เท่า';
    } elseif ($over_max) {
        $status = 'alert';
        $level = 'soft';
        $dose_direction = 'high';
        $reason = 'เกินช่วงที่ยอมรับ (±' . pdc_fmt($tol_pct, 1) . '%)';
    } elseif ($under_min) {
        $status = 'alert';
        $level = 'soft';
        $dose_direction = 'low';
        $reason = 'ต่ำกว่าช่วงที่ยอมรับ (±' . pdc_fmt($tol_pct, 1) . '%)';
    }
    $sug = pdc_build_dose_suggestion([
        'expected_min' => $min,
        'expected_max' => $max,
        'dose_basis' => $dose_basis,
        'dose_direction' => $dose_direction,
        'times' => $calc['times'],
        'daily_mg' => $daily_mg,
        'unit_suffix' => $unit_suffix,
    ], $parse, $method);
    $ordered = $sug['ordered_text'] !== '' ? $sug['ordered_text'] : (pdc_fmt($daily_mg, 1) . ' ' . $unit_suffix);
    $msg = '';
    if ($status === 'alert') {
        $msg = $reason . ' — สั่ง ' . $ordered
            . ' → ' . $sug['text']
            . ($mg_kg !== null ? ' (' . pdc_fmt($mg_kg, 2) . ' ' . $kg_suffix . ')' : '')
            . ' (BW ' . pdc_fmt($bw, 1) . ' kg)';
    } elseif ($in_exact) {
        $msg = 'อยู่ในช่วงเหมาะสม (' . $sug['range_text'] . ')';
    } else {
        $msg = 'คลาดเคลื่อนไม่เกิน ±' . pdc_fmt($tol_pct, 1) . '% — สั่ง ' . $ordered
            . ' → ' . $sug['text'];
    }
    return [
        'status' => $status,
        'level' => $level,
        'reason' => $reason,
        'message' => $msg,
        'daily_mg' => $daily_mg,
        'mg_kg' => $mg_kg,
        'expected_min' => $min,
        'expected_max' => $max,
        'allow_min' => $allow_min,
        'allow_max' => $allow_max,
        'tolerance_pct' => $tol_pct,
        'dose_direction' => $dose_direction,
        'dose_basis' => $dose_basis,
        'unit_suffix' => $unit_suffix,
        'kg_suffix' => $kg_suffix,
        'times' => $calc['times'],
        'capped' => !empty($calc['capped']) || $over_cap,
        'suggest_text' => $sug['text'],
        'suggest_range_text' => $sug['range_text'],
        'suggest_value_text' => $sug['value_text'],
        'order_unit' => $sug['order_unit'],
    ];
}

function pdc_pick_eval(array $evals) {
    $pass = null;
    $hard = null;
    $soft = null;
    $unver = null;
    foreach ($evals as $e) {
        $st = $e['status'] ?? '';
        if ($st === 'pass') {
            $pass = $e;
        } elseif ($st === 'alert' && ($e['level'] ?? '') === 'hard') {
            $hard = $e;
        } elseif ($st === 'alert') {
            $soft = $e;
        } else {
            $unver = $e;
        }
    }
    if ($pass) {
        return $pass;
    }
    if ($hard) {
        return $hard;
    }
    if ($soft) {
        return $soft;
    }
    return $unver;
}

