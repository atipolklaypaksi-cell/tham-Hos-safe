<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    http_response_code(403);
    exit('unauthorized');
}
include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/allergy_followup_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('allergy_followup') && !tham_menu_can('allergy_report') && !tham_menu_can('smart_pharma.settings')) {
    http_response_code(403);
    exit('forbidden');
}
af_ensure_tables($con);
$id = (int)($_GET['id'] ?? 0);
$row = af_get_photo_row($con, $id);
if (!$row) {
    http_response_code(404);
    exit('not found');
}
$path = af_upload_dir() . '/' . basename((string)$row['stored_name']);
if (!is_file($path)) {
    http_response_code(404);
    exit('missing');
}
$mime = (string)($row['mime'] ?? 'image/jpeg');
if (!isset(af_allowed_mimes()[$mime])) {
    $mime = 'image/jpeg';
}
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));
header('Cache-Control: private, max-age=86400');
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
