<?php
/**
 * Drug Viewer — หน้าต่างแยก (จอ 2 / แนวตั้ง / หมุนอัตโนมัติ)
 */
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('pharm_care.patient_ipd') && ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: home.php');
    exit;
}
$hn = trim((string)($_GET['hn'] ?? ''));
$an = trim((string)($_GET['an'] ?? ''));
$scan_id = (int)($_GET['id'] ?? 0);
$rx_at = trim((string)($_GET['rx_at'] ?? '')); // เวลา IRx จาก HOSxP (สแกนก่อน key)
$order_no = trim((string)($_GET['order_no'] ?? ''));
$user_name = htmlspecialchars((string)($_SESSION['full_name'] ?? ''), ENT_QUOTES, 'UTF-8');
$dv_uid = (int)($_SESSION['user_id'] ?? 0);
require_once __DIR__ . '/patient_ipd_helper.php';
$dv_ui = pip_load_drug_viewer_ui($con, $dv_uid);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drug Viewer</title>
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --bg: #0f172a; --panel: #1e293b; --line: #334155; --text: #e2e8f0;
            --muted: #94a3b8; --accent: #6366f1; --ok: #34d399;
            --dvw-list-w: <?= (int)$dv_ui['list_width'] ?>px;
        }
        * { box-sizing: border-box; }
        html, body { height: 100%; margin: 0; overflow: hidden; }
        body {
            font-family: 'Sarabun', Tahoma, sans-serif; background: var(--bg); color: var(--text);
            display: flex; flex-direction: column;
        }
        .dvw-head {
            flex: 0 0 auto; display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
            padding: 8px 12px; background: linear-gradient(90deg, #312e81, #0f766e);
            border-bottom: 1px solid #4338ca;
        }
        .dvw-head h1 { margin: 0; font-size: 1.05rem; font-weight: 800; }
        .dvw-head .meta { font-size: 12px; opacity: .92; }
        .dvw-head .grow { flex: 1; }
        .dvw-btn {
            border: 1px solid rgba(255,255,255,.28); background: rgba(255,255,255,.14); color: #fff;
            border-radius: 7px; padding: 5px 10px; font-weight: 700; font-size: 12px; cursor: pointer;
        }
        .dvw-btn:hover { background: rgba(255,255,255,.24); }
        .dvw-btn.primary { background: #4f46e5; border-color: #818cf8; }
        .dvw-btn:disabled { opacity: .45; cursor: not-allowed; }
        .dvw-body { flex: 1; min-height: 0; display: flex; position: relative; }
        .dvw-list {
            flex: 0 0 var(--dvw-list-w);
            width: var(--dvw-list-w);
            border-right: 0;
            display: flex; flex-direction: column; background: #111827;
            min-width: 0; overflow: hidden;
            transition: flex-basis .18s ease, width .18s ease, opacity .15s ease;
        }
        .dvw-list-tools {
            flex: 0 0 auto; padding: 8px; border-bottom: 1px solid var(--line);
            display: flex; gap: 6px; align-items: center; flex-wrap: wrap;
        }
        .dvw-list-tools select {
            flex: 1; min-width: 120px; background: var(--panel); color: var(--text);
            border: 1px solid var(--line); border-radius: 6px; padding: 5px 8px; font-size: 12px;
        }
        .dvw-list-body { flex: 1; min-height: 0; overflow: auto; }
        .dvw-item {
            width: 100%; border: 0; border-bottom: 1px solid #1f2937; background: transparent;
            color: var(--text); text-align: left; padding: 9px 10px; cursor: pointer; font-family: inherit;
        }
        .dvw-item:hover { background: #1e293b; }
        .dvw-item.active { background: #312e81; box-shadow: inset 3px 0 0 #a5b4fc; }
        .dvw-item .t1 { font-weight: 800; font-size: 12.5px; }
        .dvw-item .t2 { font-size: 11.5px; color: var(--muted); margin-top: 2px; }
        .dvw-item .t3 { margin-top: 4px; display: flex; gap: 5px; flex-wrap: wrap; }
        .badge {
            display: inline-block; padding: 0 6px; border-radius: 999px; font-size: 10.5px; font-weight: 700;
            background: #334155; color: #e2e8f0;
        }
        .badge.urgent { background: #7f1d1d; color: #fecaca; }
        .badge.home { background: #1e3a8a; color: #bfdbfe; }
        .badge.paid { background: #14532d; color: #bbf7d0; }

        /* เส้นแบ่ง + ปุ่มซ่อน/ขยาย */
        .dvw-splitter {
            flex: 0 0 12px;
            position: relative;
            z-index: 8;
            background: linear-gradient(90deg, #0b1220, #1e293b 50%, #0b1220);
            border-left: 1px solid var(--line);
            border-right: 1px solid var(--line);
            cursor: col-resize;
            user-select: none;
        }
        .dvw-splitter:hover { background: #1e293b; }
        .dvw-split-toggle {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 22px;
            height: 56px;
            border-radius: 8px;
            border: 1px solid #475569;
            background: #334155;
            color: #e2e8f0;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            box-shadow: 0 2px 8px rgba(0,0,0,.35);
            z-index: 2;
        }
        .dvw-split-toggle:hover { background: #4f46e5; border-color: #818cf8; }
        .dvw-split-toggle i { font-size: 11px; transition: transform .18s ease; }
        .dvw-body.is-list-collapsed .dvw-list {
            flex-basis: 0 !important;
            width: 0 !important;
            opacity: 0;
            pointer-events: none;
            border: 0;
        }
        .dvw-body.is-list-collapsed .dvw-split-toggle i { transform: rotate(180deg); }
        .dvw-body.is-list-collapsed .dvw-splitter { cursor: default; }
        body.is-dvw-resizing, body.is-dvw-resizing * { cursor: col-resize !important; }

        .dvw-view { flex: 1; min-width: 0; display: flex; flex-direction: column; background: #020617; }
        .dvw-view-bar {
            flex: 0 0 auto; display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
            padding: 6px 10px; background: var(--panel); border-bottom: 1px solid var(--line); font-size: 12px;
        }
        .dvw-view-bar .status { color: var(--muted); }
        .dvw-view-bar .status.ok { color: var(--ok); }
        .dvw-zoom {
            display: inline-flex; align-items: center; gap: 4px;
            background: #0f172a; border: 1px solid var(--line); border-radius: 8px; padding: 2px 4px;
        }
        .dvw-zoom .dvw-btn {
            padding: 3px 8px; border-radius: 6px; background: #1e293b; border-color: #475569;
        }
        .dvw-zoom #zoomLabel {
            min-width: 42px; text-align: center; font-weight: 800; color: #cbd5e1; font-size: 11.5px;
        }
        .dvw-stage {
            flex: 1; min-height: 0; overflow: auto; display: flex; justify-content: center;
            align-items: flex-start; padding: 10px; background:
                radial-gradient(ellipse at top, #1e293b 0%, #020617 55%);
        }
        .dvw-stage.is-zoomed { justify-content: flex-start; }
        #dvCanvas {
            max-width: none; height: auto; background: #fff; box-shadow: 0 10px 40px rgba(0,0,0,.45);
            border-radius: 2px;
        }
        .dvw-empty {
            margin: auto; color: var(--muted); font-weight: 700; text-align: center; padding: 24px;
        }
        @media (max-width: 720px) {
            .dvw-list { --dvw-list-w: min(42vw, 260px); }
        }
    </style>
</head>
<body>
    <div class="dvw-head">
        <div>
            <h1><i class="fas fa-file-medical me-1"></i>Drug Viewer</h1>
            <div class="meta" id="dvMeta">HN <?= htmlspecialchars($hn ?: '-') ?> · AN <?= htmlspecialchars($an ?: '-') ?></div>
        </div>
        <div class="grow"></div>
        <span class="meta" id="dvUser"><?= $user_name ?></span>
        <button type="button" class="dvw-btn" id="btnReload" title="โหลดใหม่"><i class="fas fa-sync-alt"></i></button>
        <button type="button" class="dvw-btn" id="btnRotLeft" title="หมุนซ้าย"><i class="fas fa-undo"></i></button>
        <button type="button" class="dvw-btn" id="btnRotRight" title="หมุนขวา"><i class="fas fa-redo"></i></button>
        <button type="button" class="dvw-btn primary" id="btnAutoOrient" title="วิเคราะห์แนว/กลับหัว (อาจใช้เวลาสักครู่) — หรือใช้ปุ่มหมุนเอง"><i class="fas fa-magic"></i> ปรับอัตโนมัติ</button>
        <button type="button" class="dvw-btn" id="btnClose">ปิด</button>
    </div>
    <div class="dvw-body<?= !empty($dv_ui['list_collapsed']) ? ' is-list-collapsed' : '' ?>" id="dvBody">
        <aside class="dvw-list" id="dvList" aria-label="รายการสแกนตามวันที่">
            <div class="dvw-list-tools">
                <select id="typeFilter">
                    <option value="">ทุกประเภท</option>
                    <option value="1">ยาเร่งด่วน</option>
                    <option value="2">ยาปกติ</option>
                    <option value="3">ยากลับบ้าน</option>
                </select>
                <span class="meta" id="dvCount">0</span>
            </div>
            <div class="dvw-list-body" id="scanList"><div class="dvw-empty">กำลังโหลด…</div></div>
        </aside>
        <div class="dvw-splitter" id="dvSplitter" title="ลากปรับความกว้าง · กดปุ่มกลางเพื่อซ่อน/ขยายรายการ">
            <button type="button" class="dvw-split-toggle" id="btnListToggle" title="ซ่อน/ขยายรายการวันที่" aria-label="ซ่อนหรือขยายรายการ">
                <i class="fas fa-chevron-left"></i>
            </button>
        </div>
        <div class="dvw-view">
            <div class="dvw-view-bar">
                <strong id="viewTitle">—</strong>
                <span class="status" id="viewStatus">พร้อม</span>
                <span class="grow"></span>
                <div class="dvw-zoom" title="ซูมใบยา">
                    <button type="button" class="dvw-btn" id="btnZoomOut" title="Zoom out"><i class="fas fa-search-minus"></i></button>
                    <span id="zoomLabel">100%</span>
                    <button type="button" class="dvw-btn" id="btnZoomIn" title="Zoom in"><i class="fas fa-search-plus"></i></button>
                    <button type="button" class="dvw-btn" id="btnZoomFit" title="พอดีหน้าจอ">Fit</button>
                </div>
                <span id="rotLabel">หมุน 0°</span>
            </div>
            <div class="dvw-stage" id="stage">
                <div class="dvw-empty" id="viewEmpty">เลือกใบยาสแกนทางซ้าย</div>
                <canvas id="dvCanvas" style="display:none;"></canvas>
            </div>
        </div>
    </div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/pdfjs/pdf.min.js"></script>
<script src="js/tesseract.min.js"></script>
<script>
const PRE = {
    hn: <?= json_encode($hn, JSON_UNESCAPED_UNICODE) ?>,
    an: <?= json_encode($an, JSON_UNESCAPED_UNICODE) ?>,
    id: <?= (int)$scan_id ?>,
    rxAt: <?= json_encode($rx_at, JSON_UNESCAPED_UNICODE) ?>,
    orderNo: <?= json_encode($order_no, JSON_UNESCAPED_UNICODE) ?>,
    userId: <?= (int)$dv_uid ?>
};
const ROT_CACHE_KEY = 'dvw_rot_v1';
const UI_LS_KEY = 'dvw_ui_u' + String(PRE.userId || 0);
const ZOOM_MIN = 0.5;
const ZOOM_MAX = 3;
const ZOOM_STEP = 0.15;
let ITEMS = [];
let ACTIVE_ID = 0;
let PDF_DOC = null;
let CURRENT_ROT = 0; // degrees clockwise applied to page
let RENDER_TOKEN = 0;
let ORIENT_BUSY = false;
let VIEW_ZOOM = <?= json_encode((float)$dv_ui['zoom']) ?>;
let UI_STATE = {
    list_collapsed: <?= !empty($dv_ui['list_collapsed']) ? 1 : 0 ?>,
    list_width: <?= (int)$dv_ui['list_width'] ?>,
    zoom: <?= json_encode((float)$dv_ui['zoom']) ?>
};
let uiSaveTimer = null;

if (window['pdfjsLib']) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'js/pdfjs/pdf.worker.min.js';
}

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function typeBadge(it) {
    const t = String(it.scr_type || '');
    const name = esc(it.type_name || '');
    if (t === '1') return '<span class="badge urgent">' + name + '</span>';
    if (t === '3') return '<span class="badge home">' + name + '</span>';
    return '<span class="badge">' + name + '</span>';
}
function loadRotCache() {
    try { return JSON.parse(sessionStorage.getItem(ROT_CACHE_KEY) || '{}') || {}; }
    catch (e) { return {}; }
}
function saveRotCache(map) {
    try { sessionStorage.setItem(ROT_CACHE_KEY, JSON.stringify(map)); } catch (e) {}
}
function getCachedRot(id) {
    const m = loadRotCache();
    return (m && m[String(id)] != null) ? (Number(m[String(id)]) % 360) : null;
}
function setCachedRot(id, rot) {
    const m = loadRotCache();
    m[String(id)] = ((rot % 360) + 360) % 360;
    saveRotCache(m);
}

function setStatus(msg, ok) {
    const el = document.getElementById('viewStatus');
    el.textContent = msg || '';
    el.className = 'status' + (ok ? ' ok' : '');
}
function updateRotLabel() {
    document.getElementById('rotLabel').textContent = 'หมุน ' + CURRENT_ROT + '°';
}

function clampZoom(z) {
    z = Number(z);
    if (!isFinite(z)) z = 1;
    if (z < ZOOM_MIN) z = ZOOM_MIN;
    if (z > ZOOM_MAX) z = ZOOM_MAX;
    return Math.round(z * 100) / 100;
}

function updateZoomLabel() {
    const el = document.getElementById('zoomLabel');
    if (el) el.textContent = Math.round(VIEW_ZOOM * 100) + '%';
    const stage = document.getElementById('stage');
    if (stage) stage.classList.toggle('is-zoomed', VIEW_ZOOM > 1.02);
    const out = document.getElementById('btnZoomOut');
    const inn = document.getElementById('btnZoomIn');
    if (out) out.disabled = VIEW_ZOOM <= ZOOM_MIN + 0.001;
    if (inn) inn.disabled = VIEW_ZOOM >= ZOOM_MAX - 0.001;
}

function readLocalUi() {
    try {
        const raw = localStorage.getItem(UI_LS_KEY);
        if (!raw) return null;
        const o = JSON.parse(raw);
        return o && typeof o === 'object' ? o : null;
    } catch (e) { return null; }
}

function writeLocalUi(ui) {
    try { localStorage.setItem(UI_LS_KEY, JSON.stringify(ui)); } catch (e) {}
}

function applyListUi(ui) {
    UI_STATE = Object.assign({}, UI_STATE, ui || {});
    const collapsed = !!Number(UI_STATE.list_collapsed);
    const w = Math.max(180, Math.min(480, parseInt(UI_STATE.list_width, 10) || 280));
    UI_STATE.list_width = w;
    document.documentElement.style.setProperty('--dvw-list-w', w + 'px');
    const body = document.getElementById('dvBody');
    if (body) body.classList.toggle('is-list-collapsed', collapsed);
    const btn = document.getElementById('btnListToggle');
    if (btn) {
        btn.title = collapsed ? 'ขยายรายการวันที่' : 'ซ่อนรายการวันที่';
        btn.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
    }
    VIEW_ZOOM = clampZoom(UI_STATE.zoom != null ? UI_STATE.zoom : VIEW_ZOOM);
    UI_STATE.zoom = VIEW_ZOOM;
    updateZoomLabel();
}

function persistUi(partial) {
    UI_STATE = Object.assign({}, UI_STATE, partial || {});
    UI_STATE.zoom = clampZoom(UI_STATE.zoom != null ? UI_STATE.zoom : VIEW_ZOOM);
    UI_STATE.list_collapsed = UI_STATE.list_collapsed ? 1 : 0;
    UI_STATE.list_width = Math.max(180, Math.min(480, parseInt(UI_STATE.list_width, 10) || 280));
    writeLocalUi(UI_STATE);
    if (uiSaveTimer) clearTimeout(uiSaveTimer);
    uiSaveTimer = setTimeout(function () {
        fetch('fetch_patient_ipd_api.php?action=drug_viewer_ui_save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ action: 'drug_viewer_ui_save', ui: UI_STATE })
        }).catch(function () {});
    }, 350);
}

function setListCollapsed(collapsed) {
    applyListUi({ list_collapsed: collapsed ? 1 : 0 });
    persistUi({ list_collapsed: collapsed ? 1 : 0 });
    if (PDF_DOC && !ORIENT_BUSY) {
        const t = ++RENDER_TOKEN;
        setTimeout(function () { renderPageAt(CURRENT_ROT, null, t); }, 200);
    }
}

async function setZoom(next, persist) {
    VIEW_ZOOM = clampZoom(next);
    UI_STATE.zoom = VIEW_ZOOM;
    updateZoomLabel();
    if (persist !== false) persistUi({ zoom: VIEW_ZOOM });
    if (PDF_DOC && !ORIENT_BUSY) {
        const t = ++RENDER_TOKEN;
        await renderPageAt(CURRENT_ROT, null, t);
    }
}

function renderList() {
    const typeF = String(document.getElementById('typeFilter').value || '');
    const items = ITEMS.filter(function (it) { return !typeF || String(it.scr_type) === typeF; });
    document.getElementById('dvCount').textContent = items.length + ' รายการ';
    const box = document.getElementById('scanList');
    if (!items.length) {
        box.innerHTML = '<div class="dvw-empty">ไม่พบใบยาสแกน</div>';
        return;
    }
    box.innerHTML = items.map(function (it) {
        const active = Number(it.id) === Number(ACTIVE_ID) ? ' active' : '';
        const payCls = String(it.pay) === '1' ? ' paid' : '';
        return '<button type="button" class="dvw-item' + active + '" data-id="' + Number(it.id) + '">'
            + '<div class="t1">' + esc(it.datescan || '-') + '</div>'
            + '<div class="t2">' + esc(it.ward_name || it.ward || '-')
            + (it.user_name ? (' · ' + esc(it.user_name)) : '') + '</div>'
            + '<div class="t3">' + typeBadge(it)
            + '<span class="badge' + payCls + '">' + esc(it.pay_label || '') + '</span></div></button>';
    }).join('');
}

function normalizePortraitRot(pageW, pageH, rot) {
    // ให้ผลลัพธ์แสดงเป็นแนวตั้ง (สูง >= กว้าง) เสมอ
    const r = ((rot % 360) + 360) % 360;
    const swap = (r === 90 || r === 270);
    const outW = swap ? pageH : pageW;
    const outH = swap ? pageW : pageH;
    if (outH + 0.5 >= outW) return r;
    return (r + 90) % 360;
}

async function renderPageAt(rot, fitEl, token) {
    if (!PDF_DOC) return null;
    const page = await PDF_DOC.getPage(1);
    const base = page.getViewport({ scale: 1, rotation: rot });
    const stage = fitEl || document.getElementById('stage');
    const maxW = Math.max(200, stage.clientWidth - 20);
    const maxH = Math.max(200, stage.clientHeight - 20);
    // fit สเกลพื้นฐานแล้วคูณ zoom ของ user
    const fitScale = Math.min(maxW / base.width, maxH / base.height, 2.4);
    const scale = Math.max(0.15, fitScale * clampZoom(VIEW_ZOOM));
    const viewport = page.getViewport({ scale: scale, rotation: rot });
    const canvas = document.getElementById('dvCanvas');
    const ctx = canvas.getContext('2d', { alpha: false });
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    canvas.style.width = canvas.width + 'px';
    canvas.style.height = canvas.height + 'px';
    if (token != null && token !== RENDER_TOKEN) return null;
    await page.render({ canvasContext: ctx, viewport: viewport }).promise;
    if (token != null && token !== RENDER_TOKEN) return null;
    canvas.style.display = 'block';
    document.getElementById('viewEmpty').style.display = 'none';
    updateZoomLabel();
    return { pageW: page.getViewport({ scale: 1 }).width, pageH: page.getViewport({ scale: 1 }).height };
}

async function renderProbe(rot, maxSide) {
    const page = await PDF_DOC.getPage(1);
    const base = page.getViewport({ scale: 1, rotation: rot });
    const scale = Math.min(maxSide / base.width, maxSide / base.height);
    const viewport = page.getViewport({ scale: Math.max(0.15, scale), rotation: rot });
    const c = document.createElement('canvas');
    c.width = Math.floor(viewport.width);
    c.height = Math.floor(viewport.height);
    await page.render({ canvasContext: c.getContext('2d', { alpha: false }), viewport: viewport }).promise;
    return c;
}

function scoreCanvasUpright(canvas) {
    // เอียง/กลับหัว: ใช้ความถี่เส้นแนวนอนของหมึก (ฟอร์มใบยาตัวอักษรเรียงแนวนอน)
    const w = canvas.width, h = canvas.height;
    const ctx = canvas.getContext('2d');
    const img = ctx.getImageData(0, 0, w, h).data;
    const rowInk = new Float32Array(h);
    const colInk = new Float32Array(w);
    for (let y = 0; y < h; y++) {
        let sum = 0;
        for (let x = 0; x < w; x++) {
            const i = (y * w + x) * 4;
            const lum = 0.299 * img[i] + 0.587 * img[i + 1] + 0.114 * img[i + 2];
            const ink = lum < 180 ? (180 - lum) : 0;
            sum += ink;
            colInk[x] += ink;
        }
        rowInk[y] = sum;
    }
    function variance(arr) {
        let m = 0;
        for (let i = 0; i < arr.length; i++) m += arr[i];
        m /= arr.length || 1;
        let v = 0;
        for (let i = 0; i < arr.length; i++) {
            const d = arr[i] - m;
            v += d * d;
        }
        return v / (arr.length || 1);
    }
    const rowV = variance(rowInk);
    const colV = variance(colInk);
    // เอกสารแนวตั้งตัวอักษรแนวนอน → variance แถวสูงกว่าคอลัมน์
    return { rowV: rowV, colV: colV, portraitScore: rowV / (colV + 1) };
}

const TESS_OPTS = {
    workerPath: 'js/tesseract/worker.min.js',
    corePath: 'js/tesseract/tesseract-core.wasm.js',
    langPath: 'js/tesseract/lang',
    gzip: true,
    logger: function () {}
};

async function ocrConfidence(canvas) {
    if (!window.Tesseract) return 0;
    try {
        const res = await Tesseract.recognize(canvas, 'eng', TESS_OPTS);
        const conf = Number(res && res.data && res.data.confidence);
        const text = String((res && res.data && res.data.text) || '');
        const alnum = (text.match(/[A-Za-z0-9\u0E00-\u0E7F]/g) || []).length;
        if (!isFinite(conf)) return alnum;
        return conf * 2 + alnum;
    } catch (e) {
        return 0;
    }
}

/** OSD: ได้มุมที่ต้องหมุนเพิ่มเพื่อให้ตัวอักษรหัวขึ้น (0/90/180/270) */
async function detectOsdDelta(canvas) {
    if (!window.Tesseract || typeof Tesseract.detect !== 'function') return 0;
    try {
        const res = await Tesseract.detect(canvas, TESS_OPTS);
        const deg = Number(
            (res && res.data && (res.data.orientation_degrees != null
                ? res.data.orientation_degrees
                : (res.data.osd && res.data.osd.orientation_degrees)))
        );
        if (![0, 90, 180, 270].includes(deg)) return 0;
        // Tesseract OSD = มุมที่ภาพถูกหมุนมาจากแนวปกติ → หมุนกลับด้วยค่านี้
        return deg;
    } catch (e) {
        return 0;
    }
}

async function detectBestRotation() {
    if (!PDF_DOC) return 0;
    setStatus('กำลังวิเคราะห์แนวตั้ง / ตัวอักษร…');
    const page = await PDF_DOC.getPage(1);
    const nat = page.getViewport({ scale: 1 });

    // 1) บังคับแนวตั้งก่อน
    let rot = normalizePortraitRot(nat.width, nat.height, 0);
    let probe = await renderProbe(rot, 700);

    // 2) OSD ตรวจกลับหัว / เอียง
    let delta = await detectOsdDelta(probe);
    if (delta) {
        rot = normalizePortraitRot(nat.width, nat.height, (rot + delta) % 360);
        probe = await renderProbe(rot, 700);
    }

    // 3) ยืนยัน 0° vs 180° ด้วย OCR + โปรเจกชันเส้นข้อความ
    const flip = (rot + 180) % 360;
    const probeFlip = await renderProbe(flip, 700);
    const s0 = scoreCanvasUpright(probe);
    const s1 = scoreCanvasUpright(probeFlip);
    const o0 = await ocrConfidence(probe);
    const o1 = await ocrConfidence(probeFlip);
    const score0 = s0.portraitScore * 8 + o0;
    const score1 = s1.portraitScore * 8 + o1;
    if (score1 > score0 + 3) {
        rot = normalizePortraitRot(nat.width, nat.height, flip);
    }
    return ((rot % 360) + 360) % 360;
}

/** หมุนเร็ว: แค่บังคับแนวตั้ง (ไม่รัน OCR) */
async function quickPortraitRotation() {
    const page = await PDF_DOC.getPage(1);
    const nat = page.getViewport({ scale: 1 });
    return normalizePortraitRot(nat.width, nat.height, 0);
}

async function showScan(id, opts) {
    opts = opts || {};
    id = Number(id) || 0;
    if (!id) return;
    ACTIVE_ID = id;
    RENDER_TOKEN++;
    const token = RENDER_TOKEN;
    renderList();
    const it = ITEMS.find(function (x) { return Number(x.id) === id; });
    document.getElementById('viewTitle').textContent = it
        ? ((it.type_name || 'สแกน') + ' · ' + (it.datescan || ''))
        : ('#' + id);
    if (!it || !it.has_image) {
        PDF_DOC = null;
        document.getElementById('dvCanvas').style.display = 'none';
        document.getElementById('viewEmpty').style.display = 'block';
        document.getElementById('viewEmpty').textContent = 'ไม่มีไฟล์สแกน';
        setStatus('ไม่มีไฟล์');
        return;
    }
    setStatus(opts.forceAuto ? 'กำลังวิเคราะห์แนว…' : 'กำลังโหลด PDF…');
    const url = 'fetch_patient_ipd_api.php?action=drug_viewer_image&id=' + id;
    try {
        const loading = pdfjsLib.getDocument({
            url: url,
            withCredentials: true,
            disableAutoFetch: false,
            disableStream: false
        });
        PDF_DOC = await loading.promise;
        if (token !== RENDER_TOKEN) return;

        let rot;
        if (opts.forceAuto) {
            // ช้าได้ — เฉพาะเมื่อกดปุ่ม "ปรับอัตโนมัติ"
            ORIENT_BUSY = true;
            try {
                rot = await detectBestRotation();
            } catch (e) {
                rot = await quickPortraitRotation();
            }
            ORIENT_BUSY = false;
            setCachedRot(id, rot);
        } else {
            rot = getCachedRot(id);
            if (rot == null) {
                rot = await quickPortraitRotation();
                // ไม่ cache ผล quick — ให้ user หมุนมือ / กดปรับอัตโนมัติแล้วค่อยจำ
            }
        }

        CURRENT_ROT = ((rot % 360) + 360) % 360;
        updateRotLabel();
        await renderPageAt(CURRENT_ROT, null, token);
        if (token !== RENDER_TOKEN) return;
        setStatus(
            opts.forceAuto
                ? ('ปรับอัตโนมัติ · หมุน ' + CURRENT_ROT + '°')
                : ('แสดงแล้ว · หมุน ' + CURRENT_ROT + '° (กด ↺↻ หรือ ปรับอัตโนมัติได้)'),
            true
        );
    } catch (e) {
        ORIENT_BUSY = false;
        document.getElementById('dvCanvas').style.display = 'none';
        document.getElementById('viewEmpty').style.display = 'block';
        document.getElementById('viewEmpty').textContent = 'เปิดไฟล์ไม่สำเร็จ';
        setStatus('ผิดพลาด');
    }
}

/** แปลง 'YYYY-MM-DD HH:MM[:SS]' → ms */
function parseScanTs(s) {
    const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if (!m) return NaN;
    return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)).getTime();
}

/**
 * จับคู่ IRx กับใบสแกน:
 * - วันเดียวกันเป็นหลัก (สแกนก่อน → key ใน HOSxP ทีหลัง เวลา HOSxP มักช้ากว่า)
 * - เลือกใบที่ datescan <= เวลา IRx และใกล้ที่สุด
 * - ถ้าไม่มีก่อนหน้า เลือกใบวันเดียวกันที่ใกล้เวลา IRx ที่สุด
 */
function pickScanForRxAt(items, rxAt) {
    const list = items || [];
    if (!list.length) return null;
    const target = parseScanTs(rxAt);
    if (!isFinite(target)) return list[0];
    const day = String(rxAt).slice(0, 10);
    const sameDay = list.filter(function (it) {
        return String(it.datescan || '').slice(0, 10) === day;
    });
    const pool = sameDay.length ? sameDay : list;

    let bestBefore = null;
    let bestBeforeDiff = Infinity;
    let bestAny = null;
    let bestAnyDiff = Infinity;
    pool.forEach(function (it) {
        const t = parseScanTs(it.datescan);
        if (!isFinite(t)) return;
        const diff = Math.abs(target - t);
        if (diff < bestAnyDiff) {
            bestAnyDiff = diff;
            bestAny = it;
        }
        if (t <= target && (target - t) < bestBeforeDiff) {
            bestBeforeDiff = target - t;
            bestBefore = it;
        }
    });
    return bestBefore || bestAny || list[0];
}

async function loadScans() {
    const qs = new URLSearchParams({
        action: 'drug_viewer_scans',
        hn: PRE.hn || '',
        an: PRE.an || '',
        limit: '100'
    });
    document.getElementById('scanList').innerHTML = '<div class="dvw-empty">กำลังโหลด…</div>';
    try {
        const res = await fetch('fetch_patient_ipd_api.php?' + qs.toString(), { credentials: 'same-origin' });
        const data = await res.json();
        if (!data || !data.ok) {
            ITEMS = [];
            document.getElementById('scanList').innerHTML = '<div class="dvw-empty">' + esc((data && data.message) || 'โหลดไม่สำเร็จ') + '</div>';
            return;
        }
        ITEMS = data.items || [];
        let meta = 'HN ' + (PRE.hn || data.hn || '-') + ' · AN ' + (PRE.an || data.an || '-');
        if (PRE.rxAt) meta += ' · จับคู่ IRx ' + PRE.rxAt;
        if (PRE.orderNo) meta += ' (#' + PRE.orderNo + ')';
        document.getElementById('dvMeta').textContent = meta;
        renderList();

        let startId = PRE.id || 0;
        if (!startId && PRE.rxAt) {
            const matched = pickScanForRxAt(ITEMS, PRE.rxAt);
            if (matched) startId = matched.id;
        }
        if (!startId && ITEMS[0]) startId = ITEMS[0].id;

        if (startId) {
            await showScan(startId, { forceAuto: false });
            // เลื่อนรายการซ้ายไปที่ใบที่เลือก
            const el = document.querySelector('.dvw-item[data-id="' + Number(startId) + '"]');
            if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
            if (PRE.rxAt) {
                const it = ITEMS.find(function (x) { return Number(x.id) === Number(startId); });
                setStatus(
                    it
                        ? ('จับคู่ IRx ' + PRE.rxAt + ' → สแกน ' + (it.datescan || ''))
                        : ('จับคู่ IRx ' + PRE.rxAt),
                    true
                );
            }
        }
    } catch (e) {
        document.getElementById('scanList').innerHTML = '<div class="dvw-empty">เชื่อมต่อไม่สำเร็จ</div>';
    }
}

async function nudgeRot(delta) {
    if (!PDF_DOC || ORIENT_BUSY) return;
    CURRENT_ROT = (CURRENT_ROT + delta + 360) % 360;
    // คงแนวตั้ง: ถ้าผลกลายเป็นแนวนอน หมุนเพิ่มอีก 90
    try {
        const page = await PDF_DOC.getPage(1);
        const nat = page.getViewport({ scale: 1 });
        CURRENT_ROT = normalizePortraitRot(nat.width, nat.height, CURRENT_ROT);
    } catch (e) {}
    setCachedRot(ACTIVE_ID, CURRENT_ROT);
    updateRotLabel();
    RENDER_TOKEN++;
    await renderPageAt(CURRENT_ROT, null, RENDER_TOKEN);
    setStatus('ปรับมือ · หมุน ' + CURRENT_ROT + '°', true);
}

document.getElementById('typeFilter').addEventListener('change', renderList);
document.getElementById('scanList').addEventListener('click', function (e) {
    const btn = e.target.closest('.dvw-item');
    if (!btn) return;
    showScan(btn.getAttribute('data-id'));
});
document.getElementById('btnReload').addEventListener('click', loadScans);
document.getElementById('btnRotLeft').addEventListener('click', function () { nudgeRot(-90); });
document.getElementById('btnRotRight').addEventListener('click', function () { nudgeRot(90); });
document.getElementById('btnAutoOrient').addEventListener('click', function () {
    if (ACTIVE_ID) showScan(ACTIVE_ID, { forceAuto: true });
});
document.getElementById('btnClose').addEventListener('click', function () { window.close(); });

document.getElementById('btnZoomIn').addEventListener('click', function () {
    setZoom(VIEW_ZOOM + ZOOM_STEP);
});
document.getElementById('btnZoomOut').addEventListener('click', function () {
    setZoom(VIEW_ZOOM - ZOOM_STEP);
});
document.getElementById('btnZoomFit').addEventListener('click', function () {
    setZoom(1);
});
document.getElementById('btnListToggle').addEventListener('click', function (e) {
    e.preventDefault();
    e.stopPropagation();
    const collapsed = !document.getElementById('dvBody').classList.contains('is-list-collapsed');
    setListCollapsed(collapsed);
});

(function initListResize() {
    const split = document.getElementById('dvSplitter');
    const body = document.getElementById('dvBody');
    if (!split || !body) return;
    split.addEventListener('mousedown', function (e) {
        if (e.target.closest('.dvw-split-toggle')) return;
        if (body.classList.contains('is-list-collapsed')) return;
        e.preventDefault();
        const bodyRect = body.getBoundingClientRect();
        document.body.classList.add('is-dvw-resizing');
        function onMove(ev) {
            let w = Math.round(ev.clientX - bodyRect.left);
            if (w < 180) w = 180;
            if (w > 480) w = 480;
            document.documentElement.style.setProperty('--dvw-list-w', w + 'px');
            UI_STATE.list_width = w;
        }
        function onUp() {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            document.body.classList.remove('is-dvw-resizing');
            persistUi({ list_width: UI_STATE.list_width });
            if (PDF_DOC && !ORIENT_BUSY) {
                const t = ++RENDER_TOKEN;
                renderPageAt(CURRENT_ROT, null, t);
            }
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    });
})();

window.addEventListener('keydown', function (e) {
    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA')) return;
    if (e.key === '+' || e.key === '=') { e.preventDefault(); setZoom(VIEW_ZOOM + ZOOM_STEP); }
    if (e.key === '-' || e.key === '_') { e.preventDefault(); setZoom(VIEW_ZOOM - ZOOM_STEP); }
    if (e.key === '0') { e.preventDefault(); setZoom(1); }
});

window.addEventListener('resize', function () {
    if (PDF_DOC && !ORIENT_BUSY) {
        const t = ++RENDER_TOKEN;
        renderPageAt(CURRENT_ROT, null, t);
    }
});

// โหลดค่า UI ล่าสุดของ user (local ก่อน แล้ว sync จาก server)
(function bootUiPrefs() {
    const local = readLocalUi();
    if (local) applyListUi(local);
    else applyListUi(UI_STATE);
    fetch('fetch_patient_ipd_api.php?action=drug_viewer_ui_get', { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data || !data.ok || !data.ui) return;
            applyListUi(data.ui);
            writeLocalUi(data.ui);
            if (PDF_DOC && !ORIENT_BUSY) {
                const t = ++RENDER_TOKEN;
                renderPageAt(CURRENT_ROT, null, t);
            }
        })
        .catch(function () {});
})();

/**
 * จำพิกัดหน้าต่างบนจอ 2 ต่อเครื่อง (localStorage)
 * บันทึกเฉพาะเมื่ออยู่นอกจอหลัก: screenX >= screen.width หรือ screenX < 0
 * (ลากกลับมาจอ 1 ชั่วคราวจะไม่ทับค่าจอ 2)
 */
function drugViewerPersistGeomIfOnScreen2() {
    try {
        if (!window.localStorage) return;
        const x = (typeof window.screenX === 'number')
            ? window.screenX
            : (typeof window.screenLeft === 'number' ? window.screenLeft : 0);
        const y = (typeof window.screenY === 'number')
            ? window.screenY
            : (typeof window.screenTop === 'number' ? window.screenTop : 0);
        const primaryW = (window.screen && window.screen.width) ? window.screen.width : 0;
        const onScreen2 = (x >= primaryW) || (x < 0);
        if (!onScreen2) return;
        const w = Math.round(window.outerWidth || window.innerWidth || 0);
        const h = Math.round(window.outerHeight || window.innerHeight || 0);
        if (w < 300 || h < 300) return;
        localStorage.setItem('drugViewer_left', String(Math.round(x)));
        localStorage.setItem('drugViewer_top', String(Math.round(y)));
        localStorage.setItem('drugViewer_width', String(w));
        localStorage.setItem('drugViewer_height', String(h));
    } catch (e) {
        // private mode / storage ถูกบล็อก — เงียบไว้
    }
}

window.addEventListener('beforeunload', drugViewerPersistGeomIfOnScreen2);
window.addEventListener('pagehide', drugViewerPersistGeomIfOnScreen2);

loadScans();
</script>
</body>
</html>
