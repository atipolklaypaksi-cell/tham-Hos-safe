<?php
/**
 * Health ID OAuth → Provider ID token/profile
 * ใช้สำหรับ login และดึง moph_access_token_idp สำหรับ Drugs Center
 */

require_once __DIR__ . '/menu_permissions_helper.php';

function provider_oauth_config_loaded() {
    static $loaded = null;
    if ($loaded !== null) {
        return $loaded;
    }
    $path = __DIR__ . '/provider_oauth_config.php';
    if (!is_file($path)) {
        $loaded = false;
        return false;
    }
    require_once $path;
    $loaded = true;
    return true;
}

function provider_oauth_default_settings_from_file() {
    provider_oauth_config_loaded();
    return [
        'env' => (defined('PROVIDER_OAUTH_ENV') && strtolower(trim((string)PROVIDER_OAUTH_ENV)) === 'prd') ? 'prd' : 'uat',
        'health_client_id' => defined('HEALTH_ID_CLIENT_ID') ? trim((string)HEALTH_ID_CLIENT_ID) : '',
        'health_client_secret' => defined('HEALTH_ID_CLIENT_SECRET') ? trim((string)HEALTH_ID_CLIENT_SECRET) : '',
        'provider_client_id' => defined('PROVIDER_ID_CLIENT_ID') ? trim((string)PROVIDER_ID_CLIENT_ID) : '',
        'provider_secret_key' => defined('PROVIDER_ID_SECRET_KEY') ? trim((string)PROVIDER_ID_SECRET_KEY) : '',
        'redirect_uri' => defined('PROVIDER_OAUTH_REDIRECT_URI') ? trim((string)PROVIDER_OAUTH_REDIRECT_URI) : '',
        'drug_center_api_key' => defined('DRUG_CENTER_API_KEY') ? trim((string)DRUG_CENTER_API_KEY) : '',
    ];
}

function provider_oauth_ensure_settings_table($con) {
    if (!$con) {
        return false;
    }
    return (bool)@mysqli_query($con, "
        CREATE TABLE IF NOT EXISTS tham_provider_oauth_settings (
            setting_key VARCHAR(64) NOT NULL PRIMARY KEY,
            setting_value MEDIUMTEXT NULL,
            updated_at DATETIME NULL,
            updated_by VARCHAR(64) NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8
    ");
}

function provider_oauth_reset_runtime() {
    $ref =& provider_oauth_runtime_ref();
    $ref = null;
}

function &provider_oauth_runtime_ref() {
    static $cfg = null;
    return $cfg;
}

/** ค่าตั้งค่าที่ใช้จริง (ไฟล์ + ทับด้วยฐานข้อมูลถ้ามี) */
function provider_oauth_runtime($con = null) {
    $ref =& provider_oauth_runtime_ref();
    if (is_array($ref)) {
        return $ref;
    }
    $cfg = provider_oauth_default_settings_from_file();
    if ($con === null && isset($GLOBALS['con']) && $GLOBALS['con']) {
        $con = $GLOBALS['con'];
    }
    if ($con) {
        provider_oauth_ensure_settings_table($con);
        $q = @mysqli_query($con, "SELECT setting_value FROM tham_provider_oauth_settings WHERE setting_key='main' LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            $decoded = json_decode((string)($r['setting_value'] ?? ''), true);
            if (is_array($decoded)) {
                foreach ($cfg as $k => $v) {
                    if (array_key_exists($k, $decoded) && trim((string)$decoded[$k]) !== '') {
                        $cfg[$k] = trim((string)$decoded[$k]);
                    }
                }
            }
        }
    }
    $cfg['env'] = (strtolower((string)$cfg['env']) === 'prd') ? 'prd' : 'uat';
    $ref = $cfg;
    return $cfg;
}

function provider_oauth_cfg($key, $default = '') {
    $cfg = provider_oauth_runtime();
    return array_key_exists($key, $cfg) ? $cfg[$key] : $default;
}

function provider_oauth_php_quote($s) {
    return str_replace(["\\", "'"], ["\\\\", "\\'"], (string)$s);
}

/** เขียนกลับไฟล์ provider_oauth_config.php ให้สอดคล้องกับค่าที่บันทึก */
function provider_oauth_write_config_file(array $cfg) {
    $env = (strtolower((string)($cfg['env'] ?? '')) === 'prd') ? 'prd' : 'uat';
    $path = __DIR__ . '/provider_oauth_config.php';
    $body = "<?php\n"
        . "/**\n"
        . " * การตั้งค่า Health ID / Provider ID / Drugs Center\n"
        . " * สร้าง/อัปเดตจากหน้าตั้งค่า Provider ID — ห้ามอัปขึ้น GitHub\n"
        . " */\n\n"
        . "/** uat = ทดสอบ | prd = ใช้งานจริง */\n"
        . "define('PROVIDER_OAUTH_ENV', '" . provider_oauth_php_quote($env) . "');\n\n"
        . "/** 1) Health ID (หน้า Login OAuth) */\n"
        . "define('HEALTH_ID_CLIENT_ID', '" . provider_oauth_php_quote($cfg['health_client_id'] ?? '') . "');\n"
        . "define('HEALTH_ID_CLIENT_SECRET', '" . provider_oauth_php_quote($cfg['health_client_secret'] ?? '') . "');\n\n"
        . "/** 2) Provider ID (แลก moph token) */\n"
        . "define('PROVIDER_ID_CLIENT_ID', '" . provider_oauth_php_quote($cfg['provider_client_id'] ?? '') . "');\n"
        . "define('PROVIDER_ID_SECRET_KEY', '" . provider_oauth_php_quote($cfg['provider_secret_key'] ?? '') . "');\n\n"
        . "/**\n"
        . " * 3) Redirect URI — ต้องลงทะเบียนกับ Health ID ให้ตรงทุกตัวอักษร\n"
        . " */\n"
        . "define('PROVIDER_OAUTH_REDIRECT_URI', '" . provider_oauth_php_quote($cfg['redirect_uri'] ?? '') . "');\n\n"
        . "/** 4) Drugs Center API Key */\n"
        . "define('DRUG_CENTER_API_KEY', '" . provider_oauth_php_quote($cfg['drug_center_api_key'] ?? '') . "');\n";
    $ok = @file_put_contents($path, $body);
    return $ok !== false;
}

function provider_oauth_save_settings($con, array $input, $user = '') {
    if (!$con) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้'];
    }
    $cur = provider_oauth_runtime($con);
    $env = strtolower(trim((string)($input['env'] ?? $cur['env'])));
    if ($env !== 'prd') {
        $env = 'uat';
    }
    $next = [
        'env' => $env,
        'health_client_id' => trim((string)($input['health_client_id'] ?? $cur['health_client_id'])),
        'health_client_secret' => trim((string)($input['health_client_secret'] ?? '')),
        'provider_client_id' => trim((string)($input['provider_client_id'] ?? $cur['provider_client_id'])),
        'provider_secret_key' => trim((string)($input['provider_secret_key'] ?? '')),
        'redirect_uri' => trim((string)($input['redirect_uri'] ?? $cur['redirect_uri'])),
        'drug_center_api_key' => trim((string)($input['drug_center_api_key'] ?? '')),
    ];
    // ช่องลับเว้นว่าง = คงค่าเดิม
    if ($next['health_client_secret'] === '') {
        $next['health_client_secret'] = $cur['health_client_secret'];
    }
    if ($next['provider_secret_key'] === '') {
        $next['provider_secret_key'] = $cur['provider_secret_key'];
    }
    if ($next['drug_center_api_key'] === '') {
        $next['drug_center_api_key'] = $cur['drug_center_api_key'];
    }
    if ($next['health_client_id'] === '' || $next['provider_client_id'] === '') {
        return ['ok' => false, 'error' => 'กรุณาระบุ Health ID Client ID และ Provider ID Client ID'];
    }
    provider_oauth_ensure_settings_table($con);
    $json = mysqli_real_escape_string($con, json_encode($next, JSON_UNESCAPED_UNICODE));
    $user_esc = mysqli_real_escape_string($con, substr(trim((string)$user), 0, 64));
    $ok = @mysqli_query($con, "
        INSERT INTO tham_provider_oauth_settings (setting_key, setting_value, updated_at, updated_by)
        VALUES ('main', '$json', NOW(), '$user_esc')
        ON DUPLICATE KEY UPDATE
            setting_value = VALUES(setting_value),
            updated_at = VALUES(updated_at),
            updated_by = VALUES(updated_by)
    ");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกฐานข้อมูลไม่สำเร็จ: ' . mysqli_error($con)];
    }
    $file_ok = provider_oauth_write_config_file($next);
    provider_oauth_reset_runtime();
    // โหลดค่าใหม่เข้า runtime
    provider_oauth_runtime($con);
    return [
        'ok' => true,
        'settings' => $next,
        'file_written' => $file_ok,
        'warning' => $file_ok ? '' : 'บันทึกฐานข้อมูลแล้ว แต่เขียนไฟล์ provider_oauth_config.php ไม่ได้ (ตรวจสิทธิ์โฟลเดอร์)',
    ];
}

function provider_oauth_env() {
    $env = strtolower(trim((string)provider_oauth_cfg('env', 'uat')));
    return $env === 'prd' ? 'prd' : 'uat';
}

function provider_oauth_health_base_url() {
    return provider_oauth_env() === 'prd' ? 'https://moph.id.th' : 'https://uat-moph.id.th';
}

function provider_oauth_provider_base_url() {
    return provider_oauth_env() === 'prd' ? 'https://provider.id.th' : 'https://uat-provider.id.th';
}

function provider_oauth_is_configured() {
    $hid = trim((string)provider_oauth_cfg('health_client_id'));
    $hs = trim((string)provider_oauth_cfg('health_client_secret'));
    $pid = trim((string)provider_oauth_cfg('provider_client_id'));
    $ps = trim((string)provider_oauth_cfg('provider_secret_key'));
    if ($hid === '' || $hs === '' || $pid === '' || $ps === '') {
        return false;
    }
    if (strpos($hid, 'your-') === 0 || strpos($pid, 'your-') === 0) {
        return false;
    }
    return true;
}

function provider_oauth_redirect_uri() {
    $fixed = trim((string)provider_oauth_cfg('redirect_uri'));
    if ($fixed !== '') {
        return $fixed;
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ((int)($_SERVER['SERVER_PORT'] ?? 0) === 443)
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    $dir = rtrim($dir, '/');
    return $scheme . '://' . $host . $dir . '/oauth_callback.php';
}

function provider_oauth_http_request($method, $url, array $opts = []) {
    $method = strtoupper($method);
    $headers = $opts['headers'] ?? [];
    $body = $opts['body'] ?? null;
    $timeout = max(10, (int)($opts['timeout'] ?? 45));
    $retries = max(1, (int)($opts['retries'] ?? 2));

    $last = ['ok' => false, 'http_code' => 0, 'body' => '', 'error' => 'request failed'];

    if (function_exists('curl_init')) {
        for ($i = 0; $i < $retries; $i++) {
            $ch = curl_init($url);
            $curl_headers = [];
            foreach ($headers as $k => $v) {
                $curl_headers[] = is_int($k) ? $v : ($k . ': ' . $v);
            }
            $curl_opts = [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 15,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 3,
                CURLOPT_CUSTOMREQUEST => $method,
                CURLOPT_HTTPHEADER => $curl_headers,
                // กัน timeout จาก IPv6 ที่ route ไม่ได้
                CURLOPT_IPRESOLVE => defined('CURL_IPRESOLVE_V4') ? CURL_IPRESOLVE_V4 : 1,
                CURLOPT_NOSIGNAL => true,
            ];
            if ($body !== null) {
                $curl_opts[CURLOPT_POSTFIELDS] = $body;
            }
            curl_setopt_array($ch, $curl_opts);
            $resp = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err = curl_error($ch);
            $errno = curl_errno($ch);
            curl_close($ch);
            if ($resp !== false) {
                return ['ok' => true, 'http_code' => $code, 'body' => (string)$resp, 'error' => ''];
            }
            $last = ['ok' => false, 'http_code' => 0, 'body' => '', 'error' => $err ?: ('curl errno ' . $errno)];
            // timeout / could not connect → retry หรือ fallback stream
            if (!in_array($errno, [7, 28], true) && stripos($err, 'timed out') === false) {
                break;
            }
            usleep(300000);
        }
    }

    // fallback: PHP streams (ใช้ได้แม้ไม่มี curl หรือ curl timeout)
    for ($i = 0; $i < $retries; $i++) {
        $header_lines = [];
        foreach ($headers as $k => $v) {
            $header_lines[] = is_int($k) ? $v : ($k . ': ' . $v);
        }
        $ctx = stream_context_create([
            'http' => [
                'method' => $method,
                'header' => implode("\r\n", $header_lines),
                'content' => $body ?? '',
                'timeout' => $timeout,
                'ignore_errors' => true,
            ],
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
            ],
        ]);
        $resp = @file_get_contents($url, false, $ctx);
        $code = 0;
        if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
            $code = (int)$m[1];
        }
        if ($resp !== false) {
            return ['ok' => true, 'http_code' => $code, 'body' => (string)$resp, 'error' => ''];
        }
        $last = ['ok' => false, 'http_code' => $code, 'body' => '', 'error' => $last['error'] ?: 'stream request failed'];
        usleep(300000);
    }

    return $last;
}

function provider_oauth_begin_login() {
    if (!provider_oauth_is_configured()) {
        return ['ok' => false, 'error' => 'ยังไม่ได้ตั้งค่า Provider OAuth (provider_oauth_config.php)'];
    }
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $state = bin2hex(random_bytes(16));
    $_SESSION['provider_oauth_state'] = $state;
    $params = http_build_query([
        'client_id' => provider_oauth_cfg('health_client_id'),
        'redirect_uri' => provider_oauth_redirect_uri(),
        'response_type' => 'code',
        'state' => $state,
    ], '', '&', PHP_QUERY_RFC3986);
    $url = rtrim(provider_oauth_health_base_url(), '/') . '/oauth/redirect?' . $params;
    return ['ok' => true, 'url' => $url];
}

function provider_oauth_exchange_health_token($code) {
    $body = http_build_query([
        'grant_type' => 'authorization_code',
        'code' => $code,
        'redirect_uri' => provider_oauth_redirect_uri(),
        'client_id' => provider_oauth_cfg('health_client_id'),
        'client_secret' => provider_oauth_cfg('health_client_secret'),
    ]);
    $res = provider_oauth_http_request('POST', rtrim(provider_oauth_health_base_url(), '/') . '/api/v1/token', [
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
        'body' => $body,
    ]);
    if (!$res['ok']) {
        return ['ok' => false, 'error' => 'เชื่อมต่อ Health ID ไม่ได้: ' . $res['error']];
    }
    $json = json_decode($res['body'], true);
    if (!is_array($json)) {
        return ['ok' => false, 'error' => 'Health ID ตอบกลับไม่ถูกต้อง (HTTP ' . $res['http_code'] . ')'];
    }
    $token = $json['data']['access_token'] ?? $json['access_token'] ?? '';
    if ($token === '' || $res['http_code'] >= 400) {
        $msg = $json['message'] ?? ('แลก Health ID token ไม่สำเร็จ (HTTP ' . $res['http_code'] . ')');
        return ['ok' => false, 'error' => $msg, 'raw' => $json];
    }
    return [
        'ok' => true,
        'access_token' => $token,
        'account_id' => (string)($json['data']['account_id'] ?? ''),
        'raw' => $json,
    ];
}

function provider_oauth_exchange_provider_token($health_access_token) {
    $payload = json_encode([
        'client_id' => provider_oauth_cfg('provider_client_id'),
        'secret_key' => provider_oauth_cfg('provider_secret_key'),
        'token_by' => 'Health ID',
        'token' => $health_access_token,
    ], JSON_UNESCAPED_UNICODE);
    $res = provider_oauth_http_request('POST', rtrim(provider_oauth_provider_base_url(), '/') . '/api/v1/services/token', [
        'headers' => ['Content-Type: application/json'],
        'body' => $payload,
    ]);
    if (!$res['ok']) {
        return ['ok' => false, 'error' => 'เชื่อมต่อ Provider ID ไม่ได้: ' . $res['error']];
    }
    $json = json_decode($res['body'], true);
    if (!is_array($json)) {
        return ['ok' => false, 'error' => 'Provider ID ตอบกลับไม่ถูกต้อง (HTTP ' . $res['http_code'] . ')'];
    }
    if ($res['http_code'] >= 400 || empty($json['data']['access_token'])) {
        $msg = $json['message'] ?? $json['message_th'] ?? ('ไม่มี Provider ID หรือแลก token ไม่สำเร็จ (HTTP ' . $res['http_code'] . ')');
        return ['ok' => false, 'error' => $msg, 'raw' => $json];
    }
    return [
        'ok' => true,
        'access_token' => $json['data']['access_token'],
        'username' => (string)($json['data']['username'] ?? ''),
        'account_id' => (string)($json['data']['account_id'] ?? ''),
        'raw' => $json,
    ];
}

function provider_oauth_fetch_profile($provider_access_token) {
    $url = rtrim(provider_oauth_provider_base_url(), '/')
        . '/api/v1/services/profile?moph_center_token=1&moph_idp_permission=1&position_type=1';
    $res = provider_oauth_http_request('GET', $url, [
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $provider_access_token,
            'client-id' => provider_oauth_cfg('provider_client_id'),
            'secret-key' => provider_oauth_cfg('provider_secret_key'),
        ],
    ]);
    if (!$res['ok']) {
        return ['ok' => false, 'error' => 'ดึงโปรไฟล์ Provider ID ไม่ได้: ' . $res['error']];
    }
    $json = json_decode($res['body'], true);
    if (!is_array($json) || $res['http_code'] >= 400 || empty($json['data'])) {
        $msg = is_array($json) ? ($json['message'] ?? 'ดึงโปรไฟล์ไม่สำเร็จ') : ('HTTP ' . $res['http_code']);
        return ['ok' => false, 'error' => $msg, 'raw' => $json];
    }
    return ['ok' => true, 'data' => $json['data'], 'raw' => $json];
}

function provider_oauth_normalize_orgs($orgs) {
    if (!is_array($orgs)) {
        return [];
    }
    if (isset($orgs['hcode']) || isset($orgs['moph_access_token_idp']) || isset($orgs['moph_access_token_idp_fdh'])) {
        return [$orgs];
    }
    $out = [];
    foreach ($orgs as $org) {
        if (is_array($org)) {
            $out[] = $org;
        }
    }
    return $out;
}

function provider_oauth_pick_moph_token(array $profile) {
    $orgs = $profile['organization'] ?? $profile['organizations'] ?? [];
    $orgs = provider_oauth_normalize_orgs($orgs);

    $best = null;
    $token = '';
    foreach ($orgs as $org) {
        $cand = trim((string)($org['moph_access_token_idp'] ?? ''));
        if ($cand === '') {
            $cand = trim((string)($org['moph_access_token_idp_fdh'] ?? ''));
        }
        if ($cand === '') {
            $cand = trim((string)($org['moph_access_token_idp_pcu'] ?? ''));
        }
        if ($cand !== '') {
            $best = $org;
            $token = $cand;
            break;
        }
        if (!$best) {
            $best = $org;
        }
    }
    if (!$best) {
        return ['token' => '', 'hcode' => '', 'hname' => '', 'position' => '', 'org_count' => 0];
    }
    $position = provider_oauth_extract_position_text($best);
    if ($position === '') {
        $position = provider_oauth_extract_position_text($profile);
    }
    return [
        'token' => $token,
        'hcode' => trim((string)($best['hcode'] ?? '')),
        'hname' => trim((string)($best['hname_th'] ?? $best['hname'] ?? '')),
        'position' => $position,
        'org_count' => count($orgs),
    ];
}

/** ตัดคำนำหน้า/ช่องว่าง เพื่อเทียบชื่อ Provider ID กับ HOSxP */
function provider_oauth_normalize_person_name($name) {
    $s = trim(preg_replace('/\s+/u', ' ', (string)$name));
    if ($s === '') {
        return '';
    }
    $titles = 'นางสาว|นาง|นาย|น\.ส\.|นส\.|น\.ส|ด\.ญ\.|ด\.ช\.|เด็กหญิง|เด็กชาย|พญ\.|นพ\.|ภก\.|ภญ\.|ทพญ\.|ทพ\.';
    $s = preg_replace('/^(' . $titles . ')\s*/u', '', $s);
    return trim((string)$s);
}

/**
 * ความคล้ายชื่อ 0–100 (หลังตัดคำนำหน้า) — ใช้ similar_text
 */
function provider_oauth_name_similarity($a, $b) {
    $na = provider_oauth_normalize_person_name($a);
    $nb = provider_oauth_normalize_person_name($b);
    if ($na === '' || $nb === '') {
        return 0.0;
    }
    if ($na === $nb) {
        return 100.0;
    }
    $pct = 0.0;
    similar_text($na, $nb, $pct);
    $na2 = preg_replace('/\s+/u', '', $na);
    $nb2 = preg_replace('/\s+/u', '', $nb);
    $pct2 = 0.0;
    if ($na2 !== '' && $nb2 !== '') {
        similar_text($na2, $nb2, $pct2);
    }
    return max((float)$pct, (float)$pct2);
}

/** ชื่อตรงกันเมื่อคล้ายกัน ≥ threshold% (ค่าเริ่มต้น 90) */
function provider_oauth_names_match($a, $b, $threshold = 90.0) {
    return provider_oauth_name_similarity($a, $b) >= (float)$threshold;
}

/** ดึงข้อความตำแหน่งจาก array โปรไฟล์/สังกัด MOPH */
function provider_oauth_extract_position_text($src) {
    if (!is_array($src)) {
        return '';
    }
    $keys = [
        'position', 'position_name', 'position_th', 'position_type', 'position_type_name',
        'entryposition', 'occupation', 'occupation_name', 'job_position', 'affiliation',
        'role_name', 'provider_type', 'provider_type_name',
    ];
    foreach ($keys as $k) {
        if (!isset($src[$k])) {
            continue;
        }
        $v = $src[$k];
        if (is_array($v)) {
            $v = $v['name_th'] ?? $v['name'] ?? $v['label'] ?? $v['value'] ?? '';
        }
        $v = trim((string)$v);
        // ข้ามค่าที่เป็นแค่รหัสตัวเลขสั้นๆ
        if ($v === '' || preg_match('/^\d{1,3}$/', $v)) {
            continue;
        }
        return $v;
    }
    return '';
}

function provider_oauth_local_user_select_sql() {
    return 'id, role, auth_source, username, full_name, entryposition, role_from_entryposition';
}

/**
 * หา user HOSxP ใน THAM ที่ชื่อตรงกันแบบไม่ซ้ำ (หลัง normalize)
 */
function provider_oauth_find_unique_opduser_by_name($con, $full_name) {
    $norm = provider_oauth_normalize_person_name($full_name);
    if ($norm === '') {
        return null;
    }
    $cols = provider_oauth_local_user_select_sql();
    $q = mysqli_query($con, "SELECT $cols FROM users WHERE auth_source = 'opduser'");
    if (!$q) {
        return null;
    }
    $matches = [];
    while ($row = mysqli_fetch_assoc($q)) {
        $score = provider_oauth_name_similarity($row['full_name'] ?? '', $full_name);
        if ($score >= 90.0) {
            $matches[] = ['row' => $row, 'score' => $score];
        }
    }
    return provider_oauth_pick_best_unique_match($matches);
}

/**
 * เลือกคู่ที่ดีที่สุดเมื่อคะแนน ≥90 และไม่คลุมเครือ
 * @param array<int,array{row:array,score:float}> $matches
 */
function provider_oauth_pick_best_unique_match(array $matches) {
    if (!$matches) {
        return null;
    }
    usort($matches, function ($a, $b) {
        return $b['score'] <=> $a['score'];
    });
    $best = $matches[0];
    if (count($matches) === 1) {
        return $best['row'];
    }
    // มีหลายคน — รับเฉพาะเมื่ออันดับ 1 ชัดเจน (100% หรือห่างอันดับ 2 ≥ 5 จุด)
    $second = $matches[1]['score'];
    if ($best['score'] >= 99.9 || ($best['score'] - $second) >= 5.0) {
        return $best['row'];
    }
    return null;
}

/**
 * ค้น opduser บน HOSxP master: loginname = username Provider ก่อน แล้วค่อยชื่อไม่ซ้ำ
 */
function provider_oauth_lookup_hosxp_opduser($con, $username, $full_name) {
    require_once __DIR__ . '/opduser_auth_helper.php';
    $hos = tham_opduser_connect($con, 20);
    if (!$hos) {
        return null;
    }

    $login = trim((string)$username);
    if ($login !== '') {
        $by_login = tham_opduser_fetch_by_loginname($hos, $login);
        if ($by_login) {
            mysqli_close($hos);
            return $by_login;
        }
    }

    $norm = provider_oauth_normalize_person_name($full_name);
    if ($norm === '') {
        mysqli_close($hos);
        return null;
    }
    $parts = preg_split('/\s+/u', $norm);
    $first = $parts[0];
    $last = $parts[count($parts) - 1];
    $esc_first = mysqli_real_escape_string($hos, $first);
    $esc_last = mysqli_real_escape_string($hos, $last);
    $active = tham_opduser_sql_active_only();
    $sql = "SELECT loginname, name, entryposition, department
        FROM opduser
        WHERE $active AND TRIM(IFNULL(name, '')) <> ''
          AND name LIKE '%$esc_first%'
          AND name LIKE '%$esc_last%'
        LIMIT 40";
    $q = mysqli_query($hos, $sql);
    $matches = [];
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $score = provider_oauth_name_similarity($row['name'] ?? '', $full_name);
            if ($score >= 90.0) {
                $matches[] = ['row' => $row, 'score' => $score];
            }
        }
    }
    mysqli_close($hos);
    return provider_oauth_pick_best_unique_match($matches);
}

function provider_oauth_fetch_local_user($con, $user_id) {
    $user_id = (int)$user_id;
    if ($user_id <= 0) {
        return null;
    }
    $cols = provider_oauth_local_user_select_sql();
    $q = mysqli_query($con, "SELECT $cols FROM users WHERE id = $user_id LIMIT 1");
    if (!$q || mysqli_num_rows($q) === 0) {
        return null;
    }
    return mysqli_fetch_assoc($q);
}

/**
 * ซิงก์ opduser จาก HOSxP เข้า THAM แล้วคืนแถว users + ข้อมูล HOSxP
 */
function provider_oauth_resolve_hosxp_link($con, $username, $full_name) {
    require_once __DIR__ . '/opduser_auth_helper.php';
    $hosxp = provider_oauth_lookup_hosxp_opduser($con, $username, $full_name);
    $local = provider_oauth_find_unique_opduser_by_name($con, $full_name);

    if ($hosxp) {
        $synced = tham_opduser_sync_local_user($con, $hosxp);
        if ($synced && !empty($synced['id'])) {
            $row = provider_oauth_fetch_local_user($con, (int)$synced['id']);
            if ($row) {
                return ['user' => $row, 'hosxp' => $hosxp];
            }
        }
        return ['user' => $local, 'hosxp' => $hosxp];
    }
    if ($local) {
        return ['user' => $local, 'hosxp' => null];
    }
    return ['user' => null, 'hosxp' => null];
}

function provider_oauth_merge_orphan_into($con, $orphan_id, $keep_id) {
    $orphan_id = (int)$orphan_id;
    $keep_id = (int)$keep_id;
    if ($orphan_id <= 0 || $keep_id <= 0 || $orphan_id === $keep_id) {
        return;
    }
    @mysqli_query($con, "UPDATE IGNORE user_menu_permissions SET user_id = $keep_id WHERE user_id = $orphan_id");
    @mysqli_query($con, "DELETE FROM user_menu_permissions WHERE user_id = $orphan_id");
    @mysqli_query($con, "DELETE FROM users WHERE id = $orphan_id AND auth_source = 'provider_id'");
}

function provider_oauth_ensure_user_columns($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $cols = [
        'auth_source' => "ALTER TABLE users ADD COLUMN auth_source VARCHAR(20) NOT NULL DEFAULT 'local'",
        'provider_id' => "ALTER TABLE users ADD COLUMN provider_id VARCHAR(64) NULL DEFAULT NULL",
        'provider_account_id' => "ALTER TABLE users ADD COLUMN provider_account_id VARCHAR(64) NULL DEFAULT NULL",
        'entryposition' => "ALTER TABLE users ADD COLUMN entryposition VARCHAR(255) NULL DEFAULT NULL",
        'role_from_entryposition' => "ALTER TABLE users ADD COLUMN role_from_entryposition TINYINT(1) NOT NULL DEFAULT 0",
    ];
    foreach ($cols as $col => $ddl) {
        $q = mysqli_query($con, "SHOW COLUMNS FROM users LIKE '$col'");
        if ($q && mysqli_num_rows($q) === 0) {
            @mysqli_query($con, $ddl);
        }
    }
    $ready = true;
    return true;
}

function provider_oauth_default_role() {
    return 'general_staff';
}

/**
 * sync user จาก Provider profile โดยไม่ทับบัญชี local
 * ถ้ามีชื่อ/loginname ใน HOSxP แบบไม่ซ้ำ จะผูกสิทธิ์ตาม entryposition อัตโนมัติ
 */
function provider_oauth_sync_local_user($con, array $profile, array $provider_token_meta = []) {
    provider_oauth_ensure_user_columns($con);
    require_once __DIR__ . '/opduser_auth_helper.php';
    tham_opduser_ensure_tables($con);

    $provider_id = trim((string)($profile['provider_id'] ?? ''));
    $account_id = trim((string)($profile['account_id'] ?? ($provider_token_meta['account_id'] ?? '')));
    $username = trim((string)($provider_token_meta['username'] ?? ''));
    if ($username === '') {
        $username = $provider_id !== '' ? ('pid_' . preg_replace('/[^A-Za-z0-9_\-]/', '', $provider_id)) : '';
    }
    if ($username === '' && $account_id !== '') {
        $username = 'acc_' . preg_replace('/[^A-Za-z0-9_\-]/', '', $account_id);
    }
    if ($username === '') {
        return null;
    }

    $full_name = trim((string)($profile['name_th'] ?? ''));
    if ($full_name === '') {
        $full_name = trim(($profile['firstname_th'] ?? '') . ' ' . ($profile['lastname_th'] ?? ''));
    }
    if ($full_name === '') {
        $full_name = $username;
    }

    $org = provider_oauth_pick_moph_token($profile);
    $entryposition = trim((string)($org['position'] ?? ''));
    if ($entryposition === '') {
        $entryposition = provider_oauth_extract_position_text($profile);
    }

    $esc_user = mysqli_real_escape_string($con, $username);
    $esc_name = mysqli_real_escape_string($con, $full_name);
    $esc_pid = mysqli_real_escape_string($con, $provider_id);
    $esc_aid = mysqli_real_escape_string($con, $account_id);
    $placeholder = mysqli_real_escape_string($con, 'provider:' . $username);
    $cols = provider_oauth_local_user_select_sql();

    $existing = null;
    $linked_from_opduser = false;

    if ($provider_id !== '') {
        $q = mysqli_query($con, "SELECT $cols FROM users WHERE provider_id = '$esc_pid' LIMIT 1");
        if ($q && mysqli_num_rows($q) > 0) {
            $existing = mysqli_fetch_assoc($q);
        }
    }
    if (!$existing && $account_id !== '') {
        $q = mysqli_query($con, "SELECT $cols FROM users WHERE provider_account_id = '$esc_aid' LIMIT 1");
        if ($q && mysqli_num_rows($q) > 0) {
            $existing = mysqli_fetch_assoc($q);
        }
    }
    if (!$existing) {
        $q = mysqli_query($con, "SELECT $cols FROM users WHERE username = '$esc_user' LIMIT 1");
        if ($q && mysqli_num_rows($q) > 0) {
            $existing = mysqli_fetch_assoc($q);
        }
    }

    $link = provider_oauth_resolve_hosxp_link($con, $username, $full_name);
    $opd_user = $link['user'] ?? null;
    $hosxp = $link['hosxp'] ?? null;
    if ($hosxp) {
        $hos_pos = trim((string)($hosxp['entryposition'] ?? ''));
        if ($hos_pos !== '') {
            $entryposition = $hos_pos;
        }
        $hos_name = trim((string)($hosxp['name'] ?? ''));
        if ($hos_name !== '') {
            $full_name = $hos_name;
            $esc_name = mysqli_real_escape_string($con, $full_name);
        }
    }

    if ($opd_user) {
        if (!$existing) {
            $existing = $opd_user;
            $linked_from_opduser = true;
        } elseif ((int)$existing['id'] !== (int)$opd_user['id']) {
            $orphan_id = (int)$existing['id'];
            $orphan_src = $existing['auth_source'] ?? '';
            $existing = $opd_user;
            $linked_from_opduser = true;
            if ($orphan_src === 'provider_id') {
                provider_oauth_merge_orphan_into($con, $orphan_id, (int)$existing['id']);
            }
        } else {
            $existing = $opd_user;
            $linked_from_opduser = (($existing['auth_source'] ?? '') === 'opduser') || !empty($hosxp);
        }
    }

    $esc_pos = mysqli_real_escape_string($con, $entryposition);
    $mapped_role = $entryposition !== '' ? tham_opduser_resolve_role($con, $entryposition) : provider_oauth_default_role();

    if ($existing) {
        $src = $existing['auth_source'] ?? 'local';
        if ($src === 'local') {
            return null;
        }
        $keep_opd = ($src === 'opduser' || $linked_from_opduser);
        $new_auth = $keep_opd ? 'opduser' : 'provider_id';
        $cur_role = trim((string)($existing['role'] ?? ''));
        $auto_role = (int)($existing['role_from_entryposition'] ?? 0) === 1;
        $role_locked = !$auto_role && $cur_role !== '' && $cur_role !== provider_oauth_default_role();
        if ($role_locked) {
            $role = $cur_role;
            $set_auto = 0;
        } elseif ($keep_opd || $hosxp) {
            $role = $mapped_role;
            $set_auto = 1;
        } else {
            $role = $cur_role !== '' ? $cur_role : provider_oauth_default_role();
            $set_auto = $auto_role ? 1 : 0;
        }
        $esc_role = mysqli_real_escape_string($con, $role);

        $sets = [];
        if ($keep_opd) {
            $sets[] = "auth_source = 'opduser'";
            $sets[] = "role = '$esc_role'";
            $sets[] = 'role_from_entryposition = ' . (int)$set_auto;
            if ($entryposition !== '') {
                $sets[] = "entryposition = '$esc_pos'";
            }
        } else {
            $sets[] = "full_name = '$esc_name'";
            $sets[] = "auth_source = 'provider_id'";
            $sets[] = "role = '$esc_role'";
            $sets[] = 'role_from_entryposition = ' . (int)$set_auto;
            if ($entryposition !== '') {
                $sets[] = "entryposition = '$esc_pos'";
            }
        }
        if ($provider_id !== '') {
            $sets[] = "provider_id = '$esc_pid'";
        }
        if ($account_id !== '') {
            $sets[] = "provider_account_id = '$esc_aid'";
        }
        mysqli_query($con, 'UPDATE users SET ' . implode(', ', $sets) . ' WHERE id = ' . (int)$existing['id']);
        return [
            'id' => (int)$existing['id'],
            'username' => $existing['username'] ?: $username,
            'full_name' => $keep_opd ? ($existing['full_name'] ?? $full_name) : $full_name,
            'role' => $role,
            'auth_source' => $new_auth,
            'provider_id' => $provider_id,
            'linked_opduser' => $keep_opd || !empty($hosxp),
        ];
    }

    $linked = !empty($hosxp);
    $role = $linked ? $mapped_role : provider_oauth_default_role();
    $auto_role = $linked ? 1 : 0;
    $esc_role = mysqli_real_escape_string($con, $role);
    mysqli_query($con, "INSERT INTO users (username, password, full_name, role, auth_source, entryposition, role_from_entryposition, provider_id, provider_account_id)
        VALUES ('$esc_user', '$placeholder', '$esc_name', '$esc_role', 'provider_id', " .
        ($entryposition !== '' ? "'$esc_pos'" : 'NULL') . ", $auto_role, " .
        ($provider_id !== '' ? "'$esc_pid'" : 'NULL') . ', ' .
        ($account_id !== '' ? "'$esc_aid'" : 'NULL') . ')');
    $user_id = (int)mysqli_insert_id($con);
    if ($user_id <= 0) {
        return null;
    }
    return [
        'id' => $user_id,
        'username' => $username,
        'full_name' => $full_name,
        'role' => $role,
        'auth_source' => 'provider_id',
        'provider_id' => $provider_id,
        'linked_opduser' => $linked,
    ];
}

function provider_oauth_complete_login($con, $code, $state) {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (!provider_oauth_is_configured()) {
        return ['ok' => false, 'error' => 'ยังไม่ได้ตั้งค่า Provider OAuth'];
    }
    $expected = (string)($_SESSION['provider_oauth_state'] ?? '');
    unset($_SESSION['provider_oauth_state']);
    if ($expected === '' || !hash_equals($expected, (string)$state)) {
        return ['ok' => false, 'error' => 'State ไม่ถูกต้อง กรุณาเข้าสู่ระบบใหม่'];
    }
    if (trim((string)$code) === '') {
        return ['ok' => false, 'error' => 'ไม่พบรหัส authorization code'];
    }

    $health = provider_oauth_exchange_health_token($code);
    if (empty($health['ok'])) {
        return $health;
    }

    $prov = provider_oauth_exchange_provider_token($health['access_token']);
    if (empty($prov['ok'])) {
        return $prov;
    }

    $profile = provider_oauth_fetch_profile($prov['access_token']);
    if (empty($profile['ok'])) {
        return $profile;
    }

    $org = provider_oauth_pick_moph_token($profile['data']);
    $synced = provider_oauth_sync_local_user($con, $profile['data'], [
        'username' => $prov['username'],
        'account_id' => $prov['account_id'] ?: ($profile['data']['account_id'] ?? ''),
    ]);
    if (!$synced) {
        return ['ok' => false, 'error' => 'ไม่สามารถสร้าง/เชื่อมบัญชีผู้ใช้ได้ (อาจชนกับบัญชีภายในระบบ)'];
    }

    $q = mysqli_query($con, 'SELECT * FROM users WHERE id = ' . (int)$synced['id'] . ' LIMIT 1');
    $user_row = ($q && mysqli_num_rows($q) > 0) ? mysqli_fetch_assoc($q) : null;
    if (!$user_row) {
        return ['ok' => false, 'error' => 'ไม่พบบัญชีผู้ใช้หลัง sync'];
    }

    return [
        'ok' => true,
        'user' => $user_row,
        'moph_access_token_idp' => $org['token'],
        'provider_access_token' => $prov['access_token'],
        'linked_opduser' => !empty($synced['linked_opduser']),
        'provider_profile' => [
            'provider_id' => $profile['data']['provider_id'] ?? '',
            'account_id' => $profile['data']['account_id'] ?? '',
            'name_th' => $profile['data']['name_th'] ?? '',
            'hcode' => $org['hcode'],
            'hname' => $org['hname'],
            'position' => $org['position'],
            'org_count' => $org['org_count'] ?? 0,
        ],
    ];
}

function provider_oauth_session_has_moph_token() {
    return trim((string)($_SESSION['moph_access_token_idp'] ?? '')) !== '';
}

function provider_oauth_session_moph_token() {
    return trim((string)($_SESSION['moph_access_token_idp'] ?? ''));
}

function provider_oauth_session_hcode() {
    $p = $_SESSION['provider_profile'] ?? [];
    return trim((string)($p['hcode'] ?? ''));
}

function provider_oauth_status_summary() {
    $configured = provider_oauth_is_configured();
    $logged = !empty($_SESSION['user_id']);
    $via_provider = ($logged && (($_SESSION['auth_source'] ?? '') === 'provider_id')) || provider_oauth_session_has_moph_token();
    $has_token = provider_oauth_session_has_moph_token();
    return [
        'configured' => $configured,
        'env' => provider_oauth_env(),
        'via_provider' => $via_provider,
        'has_moph_token' => $has_token,
        'hcode' => provider_oauth_session_hcode(),
        'profile_name' => (string)(($_SESSION['provider_profile']['name_th'] ?? '') ?: ($_SESSION['full_name'] ?? '')),
    ];
}

/** รวมค่าจากฟอร์ม (ช่องลับเว้นว่าง = คงค่าเดิม) สำหรับทดสอบก่อนบันทึก */
function provider_oauth_merge_test_settings($con, array $input) {
    $cur = provider_oauth_runtime($con);
    $env = strtolower(trim((string)($input['env'] ?? $cur['env'])));
    if ($env !== 'prd') {
        $env = 'uat';
    }
    $next = [
        'env' => $env,
        'health_client_id' => trim((string)($input['health_client_id'] ?? $cur['health_client_id'])),
        'health_client_secret' => trim((string)($input['health_client_secret'] ?? '')),
        'provider_client_id' => trim((string)($input['provider_client_id'] ?? $cur['provider_client_id'])),
        'provider_secret_key' => trim((string)($input['provider_secret_key'] ?? '')),
        'redirect_uri' => trim((string)($input['redirect_uri'] ?? $cur['redirect_uri'])),
        'drug_center_api_key' => trim((string)($input['drug_center_api_key'] ?? '')),
    ];
    if ($next['health_client_secret'] === '') {
        $next['health_client_secret'] = $cur['health_client_secret'];
    }
    if ($next['provider_secret_key'] === '') {
        $next['provider_secret_key'] = $cur['provider_secret_key'];
    }
    if ($next['drug_center_api_key'] === '') {
        $next['drug_center_api_key'] = $cur['drug_center_api_key'];
    }
    return $next;
}

function provider_oauth_run_with_cfg(array $cfg, callable $fn) {
    $ref =& provider_oauth_runtime_ref();
    $prev = $ref;
    $cfg['env'] = (strtolower((string)($cfg['env'] ?? '')) === 'prd') ? 'prd' : 'uat';
    $ref = $cfg;
    try {
        return $fn();
    } finally {
        $ref = $prev;
    }
}

function provider_oauth_probe_message_blob($http_code, $body) {
    $json = json_decode((string)$body, true);
    $parts = [(string)$http_code];
    if (is_array($json)) {
        foreach (['error', 'error_description', 'message', 'message_th', 'code'] as $k) {
            if (isset($json[$k]) && (is_string($json[$k]) || is_numeric($json[$k]))) {
                $parts[] = (string)$json[$k];
            }
        }
        if (isset($json['data']) && is_array($json['data'])) {
            foreach (['message', 'error'] as $k) {
                if (isset($json['data'][$k])) {
                    $parts[] = (string)$json['data'][$k];
                }
            }
        }
    } else {
        $parts[] = substr(trim((string)$body), 0, 240);
    }
    return strtolower(implode(' ', $parts));
}

/**
 * แยกผลตอบจาก OAuth เมื่อใช้ code/token ปลอม:
 * client_ok = เซิร์ฟเวอร์รับ client ได้ (credential น่าจะถูก)
 * bad_credentials = client/secret ไม่ถูกต้อง
 * reachable = ติดต่อได้แต่ยังสรุป credential ไม่ชัด
 */
function provider_oauth_classify_probe_response($http_code, $body) {
    $blob = provider_oauth_probe_message_blob($http_code, $body);
    if (
        strpos($blob, 'invalid_client') !== false
        || strpos($blob, 'unauthorized_client') !== false
        || strpos($blob, 'invalid client') !== false
        || (strpos($blob, 'client') !== false && (strpos($blob, 'secret') !== false || strpos($blob, 'credential') !== false))
        || (strpos($blob, 'client id') !== false && (strpos($blob, 'invalid') !== false || strpos($blob, 'not found') !== false))
    ) {
        return 'bad_credentials';
    }
    if (
        strpos($blob, 'invalid_grant') !== false
        || strpos($blob, 'invalid_request') !== false
        || strpos($blob, 'authorization code') !== false
        || strpos($blob, 'code has') !== false
        || strpos($blob, 'code is invalid') !== false
        || strpos($blob, 'invalid code') !== false
        || strpos($blob, 'expired') !== false
        || (strpos($blob, 'token') !== false && (strpos($blob, 'invalid') !== false || strpos($blob, 'expired') !== false))
    ) {
        return 'client_ok';
    }
    if ($http_code >= 200 && $http_code < 500) {
        return 'reachable';
    }
    if ($http_code >= 500) {
        return 'server_error';
    }
    return 'unknown';
}

function provider_oauth_check_item($name, $ok, $message, array $extra = []) {
    return array_merge([
        'name' => $name,
        'ok' => (bool)$ok,
        'message' => (string)$message,
    ], $extra);
}

/**
 * ทดสอบการเชื่อมต่อ Health ID / Provider ID / Drugs Center
 * (ไม่ต้อง login จริง — ตรวจเครือข่าย + ตรวจ credential แบบ probe)
 */
function provider_oauth_test_connection($con, array $input = []) {
    $cfg = provider_oauth_merge_test_settings($con, $input);
    $checks = [];
    $tAll = microtime(true);

    $missing = [];
    if ($cfg['health_client_id'] === '') {
        $missing[] = 'Health Client ID';
    }
    if ($cfg['health_client_secret'] === '') {
        $missing[] = 'Health Client Secret';
    }
    if ($cfg['provider_client_id'] === '') {
        $missing[] = 'Provider Client ID';
    }
    if ($cfg['provider_secret_key'] === '') {
        $missing[] = 'Provider Secret Key';
    }
    $checks[] = provider_oauth_check_item(
        'config',
        $missing === [],
        $missing === []
            ? ('ครบค่าพื้นฐาน · env=' . $cfg['env'])
            : ('ยังขาด: ' . implode(', ', $missing)),
        ['env' => $cfg['env']]
    );

    return provider_oauth_run_with_cfg($cfg, function () use ($cfg, &$checks, $tAll) {
        $healthBase = rtrim(provider_oauth_health_base_url(), '/');
        $providerBase = rtrim(provider_oauth_provider_base_url(), '/');
        $redirect = provider_oauth_redirect_uri();

        // 1) Health ID host
        $t0 = microtime(true);
        $res = provider_oauth_http_request('GET', $healthBase . '/', [
            'timeout' => 12,
            'retries' => 1,
        ]);
        $ms = (int)round((microtime(true) - $t0) * 1000);
        $ok = !empty($res['ok']) && (int)$res['http_code'] > 0 && (int)$res['http_code'] < 500;
        $checks[] = provider_oauth_check_item(
            'health_host',
            $ok,
            $ok
                ? ('ติดต่อ ' . $healthBase . ' ได้ (HTTP ' . (int)$res['http_code'] . ')')
                : ('ติดต่อ Health ID ไม่ได้: ' . ($res['error'] ?: ('HTTP ' . (int)$res['http_code']))),
            ['ms' => $ms, 'url' => $healthBase, 'http_code' => (int)$res['http_code']]
        );

        // 2) Health ID client credentials (probe ด้วย code ปลอม)
        if ($cfg['health_client_id'] !== '' && $cfg['health_client_secret'] !== '') {
            $t0 = microtime(true);
            $body = http_build_query([
                'grant_type' => 'authorization_code',
                'code' => 'thamsafe-connection-test',
                'redirect_uri' => $redirect,
                'client_id' => $cfg['health_client_id'],
                'client_secret' => $cfg['health_client_secret'],
            ]);
            $res = provider_oauth_http_request('POST', $healthBase . '/api/v1/token', [
                'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
                'body' => $body,
                'timeout' => 15,
                'retries' => 1,
            ]);
            $ms = (int)round((microtime(true) - $t0) * 1000);
            if (empty($res['ok'])) {
                $checks[] = provider_oauth_check_item(
                    'health_credentials',
                    false,
                    'เรียก Health ID /api/v1/token ไม่ได้: ' . ($res['error'] ?: 'network error'),
                    ['ms' => $ms, 'http_code' => 0]
                );
            } else {
                $cls = provider_oauth_classify_probe_response((int)$res['http_code'], $res['body']);
                $short = provider_oauth_probe_message_blob((int)$res['http_code'], $res['body']);
                $short = trim(preg_replace('/\s+/', ' ', $short));
                if (strlen($short) > 160) {
                    $short = substr($short, 0, 157) . '...';
                }
                if ($cls === 'client_ok') {
                    $checks[] = provider_oauth_check_item(
                        'health_credentials',
                        true,
                        'Client ID/Secret ผ่านการตรวจ (เซิร์ฟเวอร์ตอบ invalid grant ตามที่คาดเมื่อใช้ code ทดสอบ)',
                        ['ms' => $ms, 'http_code' => (int)$res['http_code'], 'detail' => $short]
                    );
                } elseif ($cls === 'bad_credentials') {
                    $checks[] = provider_oauth_check_item(
                        'health_credentials',
                        false,
                        'Client ID หรือ Secret ไม่ถูกต้อง / ไม่ตรง env',
                        ['ms' => $ms, 'http_code' => (int)$res['http_code'], 'detail' => $short]
                    );
                } else {
                    $checks[] = provider_oauth_check_item(
                        'health_credentials',
                        (int)$res['http_code'] > 0 && (int)$res['http_code'] < 500,
                        'เรียก Health ID token ได้ แต่ยังสรุป credential ไม่ชัด — ' . $short,
                        ['ms' => $ms, 'http_code' => (int)$res['http_code'], 'detail' => $short]
                    );
                }
            }
        } else {
            $checks[] = provider_oauth_check_item('health_credentials', false, 'ยังไม่ได้ตั้ง Health Client ID/Secret');
        }

        // 3) Provider ID host
        $t0 = microtime(true);
        $res = provider_oauth_http_request('GET', $providerBase . '/', [
            'timeout' => 12,
            'retries' => 1,
        ]);
        $ms = (int)round((microtime(true) - $t0) * 1000);
        $ok = !empty($res['ok']) && (int)$res['http_code'] > 0 && (int)$res['http_code'] < 500;
        $checks[] = provider_oauth_check_item(
            'provider_host',
            $ok,
            $ok
                ? ('ติดต่อ ' . $providerBase . ' ได้ (HTTP ' . (int)$res['http_code'] . ')')
                : ('ติดต่อ Provider ID ไม่ได้: ' . ($res['error'] ?: ('HTTP ' . (int)$res['http_code']))),
            ['ms' => $ms, 'url' => $providerBase, 'http_code' => (int)$res['http_code']]
        );

        // 4) Provider ID credentials (probe ด้วย token ปลอม)
        if ($cfg['provider_client_id'] !== '' && $cfg['provider_secret_key'] !== '') {
            $t0 = microtime(true);
            $payload = json_encode([
                'client_id' => $cfg['provider_client_id'],
                'secret_key' => $cfg['provider_secret_key'],
                'token_by' => 'Health ID',
                'token' => 'thamsafe-connection-test',
            ], JSON_UNESCAPED_UNICODE);
            $res = provider_oauth_http_request('POST', $providerBase . '/api/v1/services/token', [
                'headers' => ['Content-Type: application/json'],
                'body' => $payload,
                'timeout' => 15,
                'retries' => 1,
            ]);
            $ms = (int)round((microtime(true) - $t0) * 1000);
            if (empty($res['ok'])) {
                $checks[] = provider_oauth_check_item(
                    'provider_credentials',
                    false,
                    'เรียก Provider ID /api/v1/services/token ไม่ได้: ' . ($res['error'] ?: 'network error'),
                    ['ms' => $ms, 'http_code' => 0]
                );
            } else {
                $cls = provider_oauth_classify_probe_response((int)$res['http_code'], $res['body']);
                $short = provider_oauth_probe_message_blob((int)$res['http_code'], $res['body']);
                $short = trim(preg_replace('/\s+/', ' ', $short));
                if (strlen($short) > 160) {
                    $short = substr($short, 0, 157) . '...';
                }
                if ($cls === 'bad_credentials') {
                    $checks[] = provider_oauth_check_item(
                        'provider_credentials',
                        false,
                        'Provider Client ID หรือ Secret ไม่ถูกต้อง / ไม่ตรง env',
                        ['ms' => $ms, 'http_code' => (int)$res['http_code'], 'detail' => $short]
                    );
                } else {
                    // token ปลอมมักได้ 4xx เรื่อง token — ถือว่า credential ใช้งานได้ถ้าไม่ใช่ invalid_client
                    $okCred = (int)$res['http_code'] > 0 && (int)$res['http_code'] < 500;
                    $checks[] = provider_oauth_check_item(
                        'provider_credentials',
                        $okCred,
                        $okCred
                            ? ('เรียก Provider token ได้ · ตอบ: ' . $short)
                            : ('Provider ID ตอบผิดปกติ — ' . $short),
                        ['ms' => $ms, 'http_code' => (int)$res['http_code'], 'detail' => $short]
                    );
                }
            }
        } else {
            $checks[] = provider_oauth_check_item('provider_credentials', false, 'ยังไม่ได้ตั้ง Provider Client ID/Secret');
        }

        // 5) Redirect URI รูปแบบ
        $redirOk = $redirect !== '' && (bool)preg_match('#^https?://#i', $redirect);
        $checks[] = provider_oauth_check_item(
            'redirect_uri',
            $redirOk,
            $redirOk
                ? ('Redirect URI: ' . $redirect)
                : 'Redirect URI ไม่ถูกต้อง (ต้องขึ้นต้นด้วย http:// หรือ https://)',
            ['redirect_uri' => $redirect]
        );

        // 6) Drugs Center API Key
        require_once __DIR__ . '/drug_center_helper.php';
        $apiKey = trim((string)$cfg['drug_center_api_key']);
        if ($apiKey === '' || strpos($apiKey, 'your-') === 0) {
            $checks[] = provider_oauth_check_item(
                'drug_center',
                true,
                'ข้าม Drugs Center (ยังไม่มี API Key) — ไม่บังคับสำหรับการ Login',
                ['skipped' => true]
            );
        } else {
            $t0 = microtime(true);
            $dc = drug_center_search_drugs('paracetamol', 1, 1);
            $ms = (int)round((microtime(true) - $t0) * 1000);
            $msg = trim((string)($dc['message'] ?? ''));
            $code = (int)($dc['code'] ?? 0);
            $blob = strtolower($msg . ' ' . $code);
            $authFail = (
                $code === 401 || $code === 403
                || strpos($blob, 'api key') !== false
                || strpos($blob, 'apikey') !== false
                || strpos($blob, 'unauthorized') !== false
                || strpos($blob, 'forbidden') !== false
            );
            if (!empty($dc['ok'])) {
                $checks[] = provider_oauth_check_item(
                    'drug_center',
                    true,
                    'Drugs Center ใช้งานได้ (' . drug_center_base_url() . ')',
                    ['ms' => $ms, 'code' => $code]
                );
            } elseif ($authFail) {
                $checks[] = provider_oauth_check_item(
                    'drug_center',
                    false,
                    'Drugs Center API Key ไม่ถูกต้องหรือไม่มีสิทธิ์' . ($msg !== '' ? (' — ' . $msg) : ''),
                    ['ms' => $ms, 'code' => $code]
                );
            } else {
                // บาง env อาจตอบ error อื่นแต่ยังถือว่า key ผ่านถ้าไม่ใช่ auth fail และมี HTTP/JSON
                $softOk = $code > 0 && $code < 500 && !$authFail;
                $checks[] = provider_oauth_check_item(
                    'drug_center',
                    $softOk,
                    $softOk
                        ? ('ติดต่อ Drugs Center ได้ · ตอบ: ' . ($msg !== '' ? $msg : ('code ' . $code)))
                        : ('ติดต่อ Drugs Center ไม่สำเร็จ' . ($msg !== '' ? (' — ' . $msg) : '')),
                    ['ms' => $ms, 'code' => $code]
                );
            }
        }

        $failed = 0;
        foreach ($checks as $c) {
            if (empty($c['ok']) && empty($c['skipped'])) {
                $failed++;
            }
        }
        return [
            'ok' => $failed === 0,
            'env' => $cfg['env'],
            'health_base' => $healthBase,
            'provider_base' => $providerBase,
            'redirect_uri' => $redirect,
            'ms' => (int)round((microtime(true) - $tAll) * 1000),
            'failed' => $failed,
            'checks' => $checks,
            'note' => 'การทดสอบนี้ไม่แทนการ Login จริง — ตรวจเครือข่ายและ credential แบบ probe',
        ];
    });
}
