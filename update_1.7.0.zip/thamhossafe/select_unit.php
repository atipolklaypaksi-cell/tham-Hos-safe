<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/user_unit_helper.php';
require_once __DIR__ . '/allergy_followup_helper.php';

tham_user_load_unit_session($con, (int)$_SESSION['user_id']);
$requires = tham_user_requires_unit();
$current = trim((string)($_SESSION['unit_ward'] ?? ''));
if (!$requires && $current === '' && ($_GET['force'] ?? '') !== '1') {
    // ผู้ที่ไม่ใช่พยาบาล/ผู้ช่วย ไม่ต้องบังคับ แต่เข้ามาเปลี่ยนได้
}

$error = '';
$similar_list = [];
$pending_new = '';
$res = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $use_existing = trim((string)($_POST['use_existing'] ?? ''));
    $confirm_new = !empty($_POST['confirm_new']);
    $ward = trim((string)($_POST['unit_ward'] ?? ''));
    if ($use_existing !== '') {
        $ward = $use_existing;
    } elseif ($ward === '__new__') {
        $ward = trim(preg_replace('/\s+/', ' ', (string)($_POST['new_ward'] ?? '')));
    }
    $wards_now = tham_user_list_wards($con);
    $is_new = ($use_existing === '' && (
        !empty($_POST['is_new_ward'])
        || (string)($_POST['unit_ward'] ?? '') === '__new__'
        || $confirm_new
    ));
    if ($is_new && $ward !== '') {
        $exact = '';
        foreach ($wards_now as $w) {
            if (tham_user_ward_norm_key($w) === tham_user_ward_norm_key($ward)) {
                $exact = $w;
                break;
            }
        }
        if ($exact === '') {
            $similar_list = tham_user_similar_wards($ward, $wards_now, 60);
        }
        if ($exact !== '') {
            $res = tham_user_set_unit($con, (int)$_SESSION['user_id'], $exact, false);
        } elseif ($similar_list && !$confirm_new) {
            $pending_new = $ward;
            $error = '';
        } else {
            $res = tham_user_set_unit($con, (int)$_SESSION['user_id'], $ward, true);
        }
    } else {
        $res = tham_user_set_unit($con, (int)$_SESSION['user_id'], $ward, false);
    }
    if (empty($pending_new) && !empty($res['ok'])) {
        if (is_file(__DIR__ . '/smart_pharma_backup_helper.php')) {
            require_once __DIR__ . '/smart_pharma_backup_helper.php';
            if (function_exists('sp_backup_must_confirm') && sp_backup_must_confirm($con)) {
                header('Location: select_dispense.php');
                exit;
            }
        }
        if (!function_exists('tham_login_return_url_consume') && is_file(__DIR__ . '/user_unit_helper.php')) {
            require_once __DIR__ . '/user_unit_helper.php';
        }
        $back = function_exists('tham_login_return_url_consume') ? tham_login_return_url_consume() : '';
        header('Location: ' . ($back !== '' ? $back : 'home.php'));
        exit;
    }
    if (empty($pending_new)) {
        $error = $res['error'] ?? ($error !== '' ? $error : 'บันทึกไม่สำเร็จ');
        $current = $ward;
    } else {
        $current = $pending_new;
    }
}

$wards = tham_user_list_wards($con);
$matched = $current !== '' ? tham_user_match_ward($current, $wards) : '';
$selected = '';
if ($matched !== '') {
    $selected = $matched;
} elseif ($current !== '') {
    foreach ($wards as $w) {
        if (trim((string)$w) === $current) {
            $selected = $current;
            break;
        }
    }
}
$is_first = ($current === '');
$show_new = ($pending_new !== '' || ($current !== '' && $selected === ''));
$new_value = $pending_new !== '' ? $pending_new : (($show_new && $current !== '') ? $current : '');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $is_first ? 'ระบุหน่วยงาน' : 'เปลี่ยนหน่วยงาน' ?> - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #eef7f3 0%, #d4ebe3 50%, #a8d5c2 100%);
            min-height: 100vh;
        }
        .unit-card {
            max-width: 520px;
            border: 0;
            border-radius: 16px;
            box-shadow: 0 12px 32px rgba(15, 36, 25, 0.12);
        }
        .unit-hero {
            background: linear-gradient(135deg, #1a4032 0%, #2a6049 100%);
            color: #fff;
            border-radius: 16px 16px 0 0;
            padding: 1.25rem 1.5rem;
        }
        .btn-unit { background: #2a6049; color: #fff; border: 0; }
        .btn-unit:hover { background: #1a4032; color: #fff; }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center p-3">
<div class="card unit-card w-100">
    <div class="unit-hero">
        <div class="small opacity-75 mb-1"><i class="fas fa-hospital me-1"></i>THAM Hos-Safe</div>
        <h4 class="fw-bold mb-1"><?= $is_first ? 'ระบุหอผู้ป่วยสังกัด' : 'ตั้งค่าหอผู้ป่วยของฉัน' ?></h4>
        <div class="small opacity-75">พยาบาล / ผู้ช่วย / นักวิชาการสาธารณสุข ต้องระบุหอผู้ป่วยสังกัด — ใช้กรองเคสแพ้ยาให้เห็นเฉพาะผู้ป่วยที่เคย admit ที่หอตนเอง (รวมหอที่เคยย้ายใน AN เดียวกัน)</div>
    </div>
    <div class="card-body p-4">
        <div class="mb-3 small text-muted">
            ผู้ใช้: <b><?= htmlspecialchars($_SESSION['full_name'] ?? '', ENT_QUOTES, 'UTF-8') ?></b>
            <?php if (!empty($_SESSION['entryposition'])): ?>
                <div>ตำแหน่ง: <?= htmlspecialchars($_SESSION['entryposition'], ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
        </div>
        <?php if ($error !== ''): ?>
            <div class="alert alert-danger py-2"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        <?php if ($is_first && $requires): ?>
            <div class="alert alert-warning py-2 small">เข้าสู่ระบบครั้งแรก — กรุณาเลือกหอผู้ป่วยสังกัดจากรายการก่อนใช้งาน</div>
        <?php endif; ?>
        <?php if ($current !== '' && $matched !== '' && $matched !== $current && $pending_new === ''): ?>
            <div class="alert alert-info py-2 small">ค่าที่เคยพิมพ์ «<?= htmlspecialchars($current, ENT_QUOTES, 'UTF-8') ?>» ตรงกับตัวเลือก «<?= htmlspecialchars($matched, ENT_QUOTES, 'UTF-8') ?>»</div>
        <?php endif; ?>
        <?php if ($pending_new !== '' && $similar_list): ?>
            <div class="alert alert-warning py-2 small mb-3">
                <div class="fw-bold mb-1">ชื่อ «<?= htmlspecialchars($pending_new, ENT_QUOTES, 'UTF-8') ?>» ใกล้เคียงกับรายการที่มีอยู่</div>
                <div class="mb-2">ตรวจสอบว่าเป็นหอเดียวกันหรือไม่ ถ้าใช่ให้เลือกชื่อที่มีอยู่ ถ้าไม่ใช่จึงยืนยันเพิ่มชื่อใหม่</div>
                <?php foreach (array_slice($similar_list, 0, 5) as $sim): ?>
                    <form method="post" class="d-grid mb-1">
                        <input type="hidden" name="use_existing" value="<?= htmlspecialchars($sim['name'], ENT_QUOTES, 'UTF-8') ?>">
                        <button type="submit" class="btn btn-outline-success btn-sm text-start">
                            ใช้ชื่อที่มี «<?= htmlspecialchars($sim['name'], ENT_QUOTES, 'UTF-8') ?>»
                        </button>
                    </form>
                <?php endforeach; ?>
                <form method="post" class="d-grid mt-2">
                    <input type="hidden" name="unit_ward" value="__new__">
                    <input type="hidden" name="new_ward" value="<?= htmlspecialchars($pending_new, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="is_new_ward" value="1">
                    <input type="hidden" name="confirm_new" value="1">
                    <button type="submit" class="btn btn-outline-danger btn-sm">ยืนยันเพิ่มชื่อใหม่ «<?= htmlspecialchars($pending_new, ENT_QUOTES, 'UTF-8') ?>»</button>
                </form>
            </div>
        <?php endif; ?>
        <form method="post" id="unitForm">
            <label class="form-label fw-bold">หน่วยงาน / หอผู้ป่วย</label>
            <select class="form-select form-select-lg" name="unit_ward" id="unit_ward" <?= $show_new ? '' : 'required' ?>>
                <option value=""><?= $wards ? '— เลือกหอผู้ป่วย —' : '— ยังไม่มีรายการหอผู้ป่วย —' ?></option>
                <?php foreach ($wards as $w): ?>
                    <option value="<?= htmlspecialchars($w, ENT_QUOTES, 'UTF-8') ?>"<?= (!$show_new && $selected === $w) ? ' selected' : '' ?>><?= htmlspecialchars($w, ENT_QUOTES, 'UTF-8') ?></option>
                <?php endforeach; ?>
                <option value="__new__"<?= $show_new ? ' selected' : '' ?>>+ เพิ่มหอผู้ป่วยที่ไม่มีในรายการ</option>
            </select>
            <div id="newWardBox" class="mt-3" style="<?= $show_new ? '' : 'display:none' ?>">
                <label class="form-label fw-bold">ชื่อหอผู้ป่วยใหม่</label>
                <input type="text" class="form-control form-control-lg" name="new_ward" id="new_ward"
                       maxlength="120" autocomplete="off" placeholder="เช่น หอผู้ป่วยวิสัญญีวิทยา"
                       value="<?= htmlspecialchars($new_value, ENT_QUOTES, 'UTF-8') ?>"
                       <?= $show_new ? 'required' : '' ?>>
                <input type="hidden" name="is_new_ward" id="is_new_ward" value="<?= $show_new ? '1' : '0' ?>">
                <div class="form-text">ระบบจะตรวจชื่อที่ใกล้เคียงในรายการก่อนบันทึก</div>
                <div id="similarHint" class="small mt-2"></div>
            </div>
            <div class="form-text mt-2">เลือกจากรายการหอผู้ป่วยของโรงพยาบาล หากไม่มีในรายการ ให้เพิ่มชื่อใหม่ด้านล่าง</div>
            <div class="d-grid gap-2 mt-4">
                <button type="submit" class="btn btn-unit btn-lg fw-bold">
                    <i class="fas fa-save me-1"></i> บันทึกหน่วยงาน
                </button>
                <?php if (!$is_first || !$requires): ?>
                    <a href="home.php" class="btn btn-outline-secondary">ยกเลิก</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>
<script>
(function () {
    const WARDS = <?= json_encode(array_values($wards), JSON_UNESCAPED_UNICODE) ?>;
    const sel = document.getElementById('unit_ward');
    const box = document.getElementById('newWardBox');
    const inp = document.getElementById('new_ward');
    const flag = document.getElementById('is_new_ward');
    const hint = document.getElementById('similarHint');
    function norm(s) {
        return String(s || '').toLowerCase().replace(/[\s\-_.,/\\()]+/g, '').replace(/^(หอผู้ป่วยใน|หอผู้ป่วย|หอ)/, '');
    }
    function similar(name) {
        const key = norm(name);
        if (!key) return [];
        const out = [];
        WARDS.forEach(function (w) {
            const wk = norm(w);
            if (!wk || wk === key) return;
            let score = 0;
            if (wk.indexOf(key) !== -1 || key.indexOf(wk) !== -1) {
                const shorter = Math.min(key.length, wk.length);
                const longer = Math.max(1, Math.max(key.length, wk.length));
                score = 80 + (20 * (shorter / longer));
            } else {
                return;
            }
            if (score >= 60) out.push({ name: w, score: score });
        });
        out.sort(function (a, b) { return b.score - a.score; });
        return out.slice(0, 5);
    }
    function toggleNew() {
        const isNew = sel.value === '__new__';
        box.style.display = isNew ? '' : 'none';
        inp.required = isNew;
        sel.required = !isNew;
        flag.value = isNew ? '1' : '0';
        if (isNew) renderHint();
        else hint.innerHTML = '';
    }
    function renderHint() {
        const name = (inp.value || '').trim();
        const sims = similar(name);
        if (!name || !sims.length) {
            hint.innerHTML = name ? '<span class="text-success">ไม่พบชื่อใกล้เคียงในรายการ — สามารถเพิ่มได้</span>' : '';
            return;
        }
        let h = '<div class="alert alert-warning py-2 mb-0">พบชื่อใกล้เคียง:';
        sims.forEach(function (s) {
            h += '<div class="mt-1"><button type="button" class="btn btn-sm btn-outline-success use-sim" data-name="'
                + s.name.replace(/"/g, '&quot;') + '">ใช้ «' + s.name.replace(/</g, '') + '»</button></div>';
        });
        h += '</div>';
        hint.innerHTML = h;
        hint.querySelectorAll('.use-sim').forEach(function (btn) {
            btn.addEventListener('click', function () {
                sel.value = btn.getAttribute('data-name');
                toggleNew();
            });
        });
    }
    sel.addEventListener('change', toggleNew);
    inp.addEventListener('input', renderHint);
    toggleNew();
})();
</script>
</body>
</html>
