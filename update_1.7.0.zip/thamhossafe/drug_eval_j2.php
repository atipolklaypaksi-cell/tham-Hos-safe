<?php
session_start();
include __DIR__ . '/connect.php';
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/patient_opd_helper.php';
require_once __DIR__ . '/drug_eval_j2_helper.php';
require_once __DIR__ . '/tham_alert_helper.php';
$hosxp_token = trim((string)($_GET['hosxp'] ?? ''));
if ($hosxp_token !== '' && !isset($_SESSION['user_id'])) {
    $redeemed = tham_alert_j2_redeem_token($con, $hosxp_token);
    if ($redeemed && !empty($redeemed['user']['id'])) {
        $user_row = $redeemed['user'];
        $_SESSION['user_id'] = $user_row['id'];
        $_SESSION['username'] = $user_row['username'];
        $_SESSION['full_name'] = $user_row['full_name'];
        $_SESSION['role'] = $user_row['role'];
        $_SESSION['auth_source'] = $user_row['auth_source'] ?? 'opduser';
        $_SESSION['login_via'] = 'hosxp';
        $_SESSION['hosxp_j2_hn'] = $redeemed['hn'];
        $_SESSION['hosxp_j2_icode'] = $redeemed['icode'];
        $_SESSION['hosxp_j2_form'] = $redeemed['form_id'];
        $_SESSION['hosxp_j2_an'] = $redeemed['an'];
        $_SESSION['hosxp_j2_vn'] = $redeemed['vn'];
        $_SESSION['hosxp_j2_auto'] = 1;
        tham_menu_load_session_permissions($con, (int)$user_row['id'], $user_row['role']);
        require_once __DIR__ . '/user_access_helper.php';
        tham_user_access_log_login($con, (int)$user_row['id']);
        $clean = 'drug_eval_j2.php?hn=' . rawurlencode($redeemed['hn'])
            . '&icode=' . rawurlencode($redeemed['icode'])
            . '&form=' . rawurlencode($redeemed['form_id'])
            . '&phase=first'
            . ($redeemed['an'] !== '' ? '&an=' . rawurlencode($redeemed['an']) : '')
            . ($redeemed['vn'] !== '' ? '&vn=' . rawurlencode($redeemed['vn']) : '');
        header('Location: ' . $clean);
        exit;
    }
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
$hosxp_pass = isset($_SESSION['hosxp_j2_hn'], $_SESSION['hosxp_j2_icode'])
    && trim((string)($_GET['hn'] ?? '')) !== ''
    && (string)$_SESSION['hosxp_j2_hn'] === trim((string)$_GET['hn'])
    && (string)$_SESSION['hosxp_j2_icode'] === trim((string)($_GET['icode'] ?? ''));
if (!tham_menu_can('drug_eval.j2') && !$hosxp_pass) {
    echo "<script>alert('คุณไม่มีสิทธิ์เข้าหน้าประเมินยา จ2'); window.location='home.php';</script>";
    exit;
}
dej2_ensure($con);

$evaluator = (string)($_SESSION['full_name'] ?? '');
$user_id = (int)$_SESSION['user_id'];
$flash = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['action'] ?? '') === 'save') {
    $form_id = preg_replace('/[^a-z0-9_]/', '', (string)($_POST['form_id'] ?? ''));
    $phase = (($_POST['phase'] ?? '') === 'cont') ? 'cont' : 'first';
    $form = dej2_form($form_id);
    $hn = trim((string)($_POST['hn'] ?? ''));
    if (!$form || !isset($form['phases'][$phase]) || $hn === '') {
        $flash = 'บันทึกไม่สำเร็จ';
    } else {
        $id = dej2_save($con, (int)($_POST['sheet'] ?? 0), [
            'hn' => $hn,
            'an' => (string)($_POST['an'] ?? ''),
            'icode' => (string)($_POST['icode'] ?? ''),
            'drug_name' => (string)($_POST['drug_name'] ?? ''),
            'form_id' => $form_id,
            'phase' => $phase,
            'answers' => dej2_clean_answers($_POST['a'] ?? []),
            'evaluator' => $evaluator,
            'user_id' => $user_id,
        ]);
        if ($id > 0) {
            header('Location: drug_eval_j2_print.php?id=' . $id);
            exit;
        }
        $flash = 'บันทึกไม่สำเร็จ';
    }
}

$hn_in = trim((string)($_GET['hn'] ?? $_POST['hn'] ?? ''));
$sheet_id = (int)($_GET['sheet'] ?? 0);
$sheet = $sheet_id > 0 ? dej2_get($con, $sheet_id) : null;
if ($hn_in === '' && $sheet) {
    $hn_in = (string)$sheet['hn'];
}
$form_id = preg_replace('/[^a-z0-9_]/', '', (string)($_GET['form'] ?? ''));
if ($form_id === '' && $sheet) {
    $form_id = (string)$sheet['form_id'];
}
$phase = (($_GET['phase'] ?? '') === 'cont') ? 'cont' : 'first';
if (!isset($_GET['phase']) && $sheet) {
    $phase = (($sheet['phase'] ?? '') === 'cont') ? 'cont' : 'first';
}
$icode = trim((string)($_GET['icode'] ?? ''));
if ($icode === '' && $sheet) {
    $icode = (string)$sheet['icode'];
}

$patient = null;
$catalog = [];
$drug_name = $sheet ? (string)$sheet['drug_name'] : '';
$error = '';
$form = dej2_form($form_id);
if ($form && !isset($form['phases'][$phase])) {
    $phase = 'first';
}

if ($hn_in !== '') {
    $hos = pop_connect($con);
    if (!$hos) {
        $error = 'เชื่อมต่อ HOSxP ไม่สำเร็จ';
    } else {
        $patient = dej2_load_patient($hos, $hn_in);
        if (!$patient) {
            $error = 'ไม่พบ HN นี้ใน HOSxP';
        } else {
            $orders = dej2_orders($hos, $patient['hn'], $patient['an']);
            $catalog = dej2_catalog($hos, $orders);
            if ($icode !== '') {
                $drug = dej2_drug_by_icode($hos, $icode);
                if ($drug) {
                    $drug_name = (string)$drug['name'];
                    if ($form_id === '') {
                        $bucket = dej2_bucket($drug_name);
                        $form_id = (string)($bucket['form'] ?? '');
                        $form = dej2_form($form_id);
                    }
                }
            }
        }
    }
}

$answers = ($sheet && (string)$sheet['form_id'] === $form_id) ? $sheet['answers'] : [];
if ($patient) {
    $answers = dej2_prefill($patient, $answers);
}
$show_form = $patient && $form;
$recent = dej2_recent($con, $patient['hn_display'] ?? $hn_in, 8);
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ประเมินยา จ2 - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        <?= dej2_css() ?>
        .hn-box{max-width:28rem}
        .drug-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:12px}
        .drug-card{border:1px solid #e5e7eb;border-radius:12px;padding:12px 14px;background:#fff;height:100%}
        .drug-card.on{border-color:#0f766e;box-shadow:0 0 0 2px rgba(15,118,110,.15)}
        .drug-card .hint{color:#6b7280;font-size:.85rem}
        .drug-card .actions{display:flex;gap:8px;margin-top:8px}
        fieldset.phase{border:0;margin:0;padding:0;min-width:0}
        fieldset.phase[hidden]{display:none !important}
        .phase-tabs{display:flex;gap:8px;justify-content:center;margin:8px 0 12px}
        .phase-tabs button{border-radius:999px}
    </style>
</head>
<body>
<div class="wrapper">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-1 text-dark"><i class="fas fa-clipboard-list me-2 text-primary"></i>ประเมินยา จ2</h4>
            <p class="text-muted small mb-3">ค้นหา HN ก่อน แล้วเลือกยา แบบกำกับการใช้ยาของแต่ละตัวไม่เหมือนกัน</p>
            <?php if ($flash !== ''): ?><div class="alert alert-warning py-2"><?= dej2_h($flash) ?></div><?php endif; ?>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <form method="get" class="hn-box">
                        <label class="form-label fw-bold" for="hn">HN</label>
                        <div class="input-group">
                            <input class="form-control" id="hn" name="hn" value="<?= dej2_h($hn_in) ?>" inputmode="numeric" autocomplete="off" autofocus>
                            <button class="btn btn-primary" type="submit">ค้นหา</button>
                        </div>
                    </form>
                    <?php if ($error !== ''): ?><div class="text-danger small mt-2"><?= dej2_h($error) ?></div><?php endif; ?>
                    <?php if ($patient): ?>
                    <div class="mt-3">
                        <div class="fw-bold"><?= dej2_h($patient['full_name']) ?></div>
                        <div class="small text-muted">
                            HN <?= dej2_h($patient['hn_display']) ?>
                            <?php if ($patient['sex_label'] !== ''): ?> · <?= dej2_h($patient['sex_label']) ?><?php endif; ?>
                            <?php if ($patient['age_y'] !== ''): ?> · <?= dej2_h($patient['age_y']) ?> ปี<?php endif; ?>
                            <?php if ($patient['ward'] !== ''): ?> · <?= dej2_h($patient['ward']) ?><?php endif; ?>
                            <?php if ($patient['an'] !== ''): ?> · AN <?= dej2_h($patient['an']) ?><?php endif; ?>
                            <?php if ($patient['pttype_name'] !== ''): ?> · <?= dej2_h($patient['pttype_name']) ?><?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($patient): ?>
            <div class="mb-3">
                <div class="fw-bold mb-2">เลือกยาบัญชี จ2</div>
                <div class="drug-grid">
                    <?php foreach ($catalog as $item):
                        $on = $form && $item['form'] === $form_id;
                        $base = 'drug_eval_j2.php?hn=' . rawurlencode($patient['hn_display']) . '&icode=' . rawurlencode($item['icode']);
                    ?>
                    <div class="drug-card<?= $on ? ' on' : '' ?>">
                        <div class="fw-bold"><?= dej2_h($item['label']) ?></div>
                        <div class="hint"><?= dej2_h($item['hint']) ?></div>
                        <?php if (!empty($item['ordered'])): ?>
                        <div class="small text-success mt-1"><?= dej2_h($item['order_where']) ?><?= $item['order_date'] !== '' ? ' · ' . dej2_h($item['order_date']) : '' ?></div>
                        <?php endif; ?>
                        <?php if ($item['form']): ?>
                        <div class="actions">
                            <a class="btn btn-sm btn-outline-success" href="<?= dej2_h($base . '&form=' . $item['form'] . '&phase=first') ?>">ครั้งแรก</a>
                            <a class="btn btn-sm btn-outline-primary" href="<?= dej2_h($base . '&form=' . $item['form'] . '&phase=cont') ?>">ต่อเนื่อง</a>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($show_form): ?>
            <form method="post" id="sheetForm">
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="hn" value="<?= dej2_h($patient['hn_display']) ?>">
                <input type="hidden" name="an" value="<?= dej2_h($patient['an']) ?>">
                <input type="hidden" name="icode" value="<?= dej2_h($icode) ?>">
                <input type="hidden" name="drug_name" value="<?= dej2_h($drug_name !== '' ? $drug_name : $form['label']) ?>">
                <input type="hidden" name="form_id" value="<?= dej2_h($form_id) ?>">
                <input type="hidden" name="sheet" value="<?= $sheet && (string)$sheet['form_id'] === $form_id ? (int)$sheet['id'] : 0 ?>">
                <input type="hidden" name="phase" id="phaseInput" value="<?= dej2_h($phase) ?>">
                <div class="phase-tabs">
                    <button type="button" class="btn btn-sm <?= $phase === 'first' ? 'btn-success' : 'btn-outline-success' ?>" data-phase-tab="first">ครั้งแรก</button>
                    <button type="button" class="btn btn-sm <?= $phase === 'cont' ? 'btn-primary' : 'btn-outline-primary' ?>" data-phase-tab="cont">ต่อเนื่อง</button>
                </div>
                <?php foreach (['first', 'cont'] as $ph): ?>
                <fieldset class="phase" data-phase="<?= $ph ?>"<?= $ph === $phase ? '' : ' disabled hidden' ?>>
                    <?php dej2_render_sheet($form, $ph, $answers, $drug_name, false); ?>
                </fieldset>
                <?php endforeach; ?>
                <div class="text-center my-3">
                    <button class="btn btn-primary" type="submit"><i class="fas fa-print me-1"></i>บันทึกและเปิดหน้าพิมพ์ PDF</button>
                </div>
            </form>
            <?php endif; ?>

            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="fw-bold mb-2">รายการที่บันทึกไว้</div>
                    <?php if (!$recent): ?>
                    <div class="text-muted small">ยังไม่มีรายการ</div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead><tr><th>เวลา</th><th>HN</th><th>ยา</th><th>แบบ</th><th></th></tr></thead>
                            <tbody>
                            <?php foreach ($recent as $row): ?>
                            <tr>
                                <td class="small"><?= dej2_h($row['updated_at'] ?: $row['created_at']) ?></td>
                                <td><?= dej2_h($row['hn']) ?></td>
                                <td><?= dej2_h($row['drug_name']) ?></td>
                                <td><?= dej2_h(dej2_phase_label($row['phase'])) ?></td>
                                <td><a href="drug_eval_j2_print.php?id=<?= (int)$row['id'] ?>">พิมพ์</a></td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    var input = document.getElementById('phaseInput');
    document.querySelectorAll('[data-phase-tab]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var phase = btn.getAttribute('data-phase-tab');
            if (input) input.value = phase;
            document.querySelectorAll('fieldset.phase').forEach(function (fs) {
                var on = fs.getAttribute('data-phase') === phase;
                fs.hidden = !on;
                fs.disabled = !on;
            });
            document.querySelectorAll('[data-phase-tab]').forEach(function (b) {
                var on = b.getAttribute('data-phase-tab') === phase;
                b.className = 'btn btn-sm ' + (b.getAttribute('data-phase-tab') === 'first'
                    ? (on ? 'btn-success' : 'btn-outline-success')
                    : (on ? 'btn-primary' : 'btn-outline-primary'));
            });
            refreshAdl();
        });
    });
    function refreshAdl() {
        var root = document.querySelector('fieldset.phase:not([disabled])');
        if (!root) return;
        var sumEl = root.querySelector('#adlSum');
        var groupEl = root.querySelector('#adlGroup');
        if (!sumEl) return;
        var sum = 0, any = false;
        root.querySelectorAll('input[type="radio"]:checked').forEach(function (el) {
            var name = el.name || '';
            if (name.indexOf('a[adl') !== 0) return;
            any = true;
            sum += parseInt(el.value, 10) || 0;
        });
        sumEl.textContent = any ? String(sum) : '';
        if (groupEl) {
            if (!any) groupEl.textContent = '';
            else if (sum >= 12) groupEl.textContent = 'กลุ่มติดสังคม (12 คะแนนขึ้นไป)';
            else if (sum >= 5) groupEl.textContent = 'กลุ่มติดบ้าน (5–11 คะแนน)';
            else groupEl.textContent = 'กลุ่มติดเตียง (0–4 คะแนน)';
        }
    }
    var form = document.getElementById('sheetForm');
    if (form) form.addEventListener('change', refreshAdl);
    refreshAdl();
})();
</script>
</body>
</html>
