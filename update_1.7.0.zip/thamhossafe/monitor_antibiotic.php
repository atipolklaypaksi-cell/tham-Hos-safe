<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('hosxp_tmt_drug_helper.php');
include('monitor_antibiotic_helper.php');
include('monitor_antibiotic_consult_helper.php');
mysqli_set_charset($con, 'utf8');

mab_ensure_tables($con);
mab_ensure_consult_tables($con);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save_config') {
        $group_ids = $_POST['group_ids'] ?? [];
        if (!is_array($group_ids)) {
            $group_ids = [];
        }
        $group_names = [];
        if (!empty($_POST['group_name']) && is_array($_POST['group_name'])) {
            $group_names = $_POST['group_name'];
        }
        $ok = mab_save_config($con, [
            'min_duration_days' => $_POST['min_duration_days'] ?? 10,
            'filter_mode' => $_POST['filter_mode'] ?? 'group',
            'dosage_form' => $_POST['dosage_form'] ?? 'Injection',
            'order_lookback_days' => $_POST['order_lookback_days'] ?? 30,
            'recent_rx_days' => $_POST['recent_rx_days'] ?? 2,
            'exclude_method_regex' => $_POST['exclude_method_regex'] ?? 'PD|HD',
            'reply_wait_days' => $_POST['reply_wait_days'] ?? 3,
            'alert_level' => $_POST['alert_level'] ?? 'soft',
            'monitor_active' => isset($_POST['monitor_active']) ? 1 : 0,
            'group_ids' => $group_ids,
            'group_names' => $group_names,
        ]);
        if ($ok && is_file(__DIR__ . '/smart_pharma_alert_log_helper.php')) {
            require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
            if (function_exists('sp_monitor_settings_changed')) {
                sp_monitor_settings_changed($con, 'antibiotic');
            }
        }
        $_SESSION['mab_msg'] = $ok ? 'บันทึกการตั้งค่า Monitor Antibiotic เรียบร้อย' : ('บันทึกไม่สำเร็จ: ' . mysqli_error($con));
        header('Location: monitor_antibiotic.php?tab=settings');
        exit;
    }

    if ($action === 'add_drug') {
        $parsed = hosxp_parse_drug_option($_POST['drug'] ?? '');
        $hos = hosxp_connect($con);
        $meta = $hos ? mab_fetch_hosxp_drug_by_icode($hos, $parsed['icode']) : null;
        if ($hos) {
            mysqli_close($hos);
        }
        if (!$meta) {
            $meta = [
                'icode' => $parsed['icode'],
                'drug_name' => $parsed['name'] !== '' ? $parsed['name'] : $parsed['icode'],
            ];
        }
        $res = mab_add_drug($con, $meta);
        $_SESSION['mab_msg'] = !empty($res['ok'])
            ? ('เพิ่มยา: ' . ($meta['drug_name'] ?? $parsed['icode']))
            : ('เพิ่มยาไม่สำเร็จ: ' . ($res['error'] ?? ''));
        header('Location: monitor_antibiotic.php?tab=settings#mab-drug-list');
        exit;
    }

    if ($action === 'delete_drug') {
        $id = (int)($_POST['drug_id'] ?? 0);
        $_SESSION['mab_msg'] = mab_delete_drug($con, $id) ? 'ลบรายการยาเรียบร้อย' : 'ลบไม่สำเร็จ';
        header('Location: monitor_antibiotic.php?tab=settings#mab-drug-list');
        exit;
    }

    if ($action === 'toggle_drug') {
        $id = (int)($_POST['drug_id'] ?? 0);
        $active = isset($_POST['active']) ? 1 : 0;
        mab_set_drug_active($con, $id, $active);
        $_SESSION['mab_msg'] = $active ? 'เปิดใช้งานยาแล้ว' : 'ปิดใช้งานยาแล้ว';
        header('Location: monitor_antibiotic.php?tab=settings#mab-drug-list');
        exit;
    }

    if ($action === 'set_drug_alert_level') {
        $id = (int)($_POST['drug_id'] ?? 0);
        $lvl = $_POST['alert_level'] ?? 'soft';
        mab_set_drug_alert_level($con, $id, $lvl);
        if (is_file(__DIR__ . '/smart_pharma_alert_log_helper.php')) {
            require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
            if (function_exists('sp_monitor_settings_changed')) {
                sp_monitor_settings_changed($con, 'antibiotic');
            }
        }
        $_SESSION['mab_msg'] = mab_normalize_alert_level($lvl) === 'hard'
            ? 'ตั้งยาเป็น Hard Alert แล้ว'
            : 'ตั้งยาเป็น Soft Alert แล้ว';
        header('Location: monitor_antibiotic.php?tab=settings#mab-drug-list');
        exit;
    }

    if ($action === 'import_from_groups') {
        $group_ids = $_POST['group_ids'] ?? [];
        if (!is_array($group_ids) || empty($group_ids)) {
            $group_ids = array_column(mab_get_selected_groups($con, true), 'pharmacology_group_id');
        }
        $dosage = trim((string)($_POST['dosage_form'] ?? ''));
        $hos = hosxp_connect($con);
        $res = mab_import_drugs_from_groups($con, $hos, $group_ids, $dosage !== '' ? $dosage : null);
        if ($hos) {
            mysqli_close($hos);
        }
        if (!empty($res['ok'])) {
            $_SESSION['mab_msg'] = $res['message'] ?? 'นำเข้าเรียบร้อย';
        } else {
            $_SESSION['mab_error'] = $res['error'] ?? 'นำเข้าไม่สำเร็จ';
        }
        header('Location: monitor_antibiotic.php?tab=settings#mab-drug-list');
        exit;
    }

    if ($action === 'import_from_flag') {
        $dosage = trim((string)($_POST['dosage_form'] ?? ''));
        $hos = hosxp_connect($con);
        $res = mab_import_drugs_from_antibiotic_flag($con, $hos, $dosage !== '' ? $dosage : null);
        if ($hos) {
            mysqli_close($hos);
        }
        if (!empty($res['ok'])) {
            $_SESSION['mab_msg'] = 'จากติ๊ก ยาปฏิชีวนะ: ' . ($res['message'] ?? 'นำเข้าเรียบร้อย');
        } else {
            $_SESSION['mab_error'] = $res['error'] ?? 'นำเข้าไม่สำเร็จ';
        }
        header('Location: monitor_antibiotic.php?tab=settings#mab-drug-list');
        exit;
    }

    if ($action === 'clear_drugs') {
        mab_clear_drugs($con);
        $_SESSION['mab_msg'] = 'ล้างรายการยาทั้งหมดแล้ว';
        header('Location: monitor_antibiotic.php?tab=settings#mab-drug-list');
        exit;
    }
}

$config = mab_get_config($con);
$selected_groups = mab_get_selected_groups($con, false);
$selected_active_ids = [];
foreach ($selected_groups as $g) {
    if (!empty($g['active'])) {
        $selected_active_ids[(string)$g['pharmacology_group_id']] = true;
    }
}
$drug_list = mab_list_drugs($con, false);

$hosxp_groups = [];
$antibiotic_flag_count = 0;
$hos = hosxp_connect($con);
if ($hos) {
    mysqli_set_charset($hos, 'utf8');
    $hosxp_groups = mab_fetch_hosxp_pharmacology_groups($hos, $config['dosage_form']);
    $antibiotic_flag_count = mab_count_hosxp_antibiotic_flag($hos, $config['dosage_form']);
    mysqli_close($hos);
}

$tab = (isset($_GET['tab']) && $_GET['tab'] === 'settings') ? 'settings' : 'dashboard';
$flash_msg = $_SESSION['mab_msg'] ?? '';
$flash_err = $_SESSION['mab_error'] ?? '';
unset($_SESSION['mab_msg'], $_SESSION['mab_error']);
session_write_close();

$filter_mode = mab_normalize_filter_mode($config['filter_mode'] ?? 'group');
if ($filter_mode === 'drugs') {
    $mode_label = 'รายการยา ' . count(array_filter($drug_list, static function ($d) { return !empty($d['active']); })) . ' รายการ';
} elseif ($filter_mode === 'flag') {
    $mode_label = 'ติ๊ก ยาปฏิชีวนะ (HOSxP)';
} else {
    $mode_label = 'กลุ่ม ' . ($config['pharmacology_group1'] ?: '24');
}

$current_user_id = (int)($_SESSION['user_id'] ?? 0);
$current_user_name = trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? ''));
$pharmacist_options = mab_list_pharmacists($con, $current_user_id);
$reply_wait_days = (int)($config['reply_wait_days'] ?? 3);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor Antibiotic - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/select2.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .mab-card { border-radius: 10px; border: 1px solid #e2e8f0; padding: 1rem 1.1rem; background: #fff; }
        .mab-gauge-num { font-size: 2.5rem; font-weight: 800; color: #b91c1c; }
        .ward-bar-row { margin-bottom: 0.45rem; }
        .ward-bar-label { font-size: 0.78rem; line-height: 1.2; max-width: 42%; }
        .ward-bar-track { flex: 1; background: #f1f5f9; border-radius: 4px; height: 18px; overflow: hidden; }
        .ward-bar-fill { height: 100%; background: linear-gradient(90deg, #22c55e, #eab308, #ef4444); border-radius: 4px; min-width: 2px; }
        .ward-bar-count { font-size: 0.85rem; font-weight: 700; min-width: 28px; text-align: right; }
        .section-alert .table thead { background-color: #dc3545 !important; color: #fff !important; }
        .section-soft .table thead { background-color: #ffc107 !important; color: #212529 !important; }
        .mab-alert-card { border: 2px solid #e2e8f0; border-radius: 10px; padding: 0.85rem 1rem; cursor: pointer; height: 100%; }
        .mab-alert-card.active-soft { border-color: #ca8a04; background: #fffbeb; }
        .mab-alert-card.active-hard { border-color: #dc2626; background: #fef2f2; }
        .duration-badge { font-size: 0.8rem; }
        .nav-tabs .nav-link.active { font-weight: 700; color: #047857; border-color: #dee2e6 #dee2e6 #fff; }
        .btn-mab { background: #047857; border-color: #047857; color: #fff; }
        .btn-mab:hover { background: #065f46; border-color: #065f46; color: #fff; }
        .mab-group-box { max-height: 280px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 8px; padding: 0.75rem; background: #f8fafc; }
        .mab-group-item { padding: 0.25rem 0; border-bottom: 1px dashed #e2e8f0; }
        .mab-group-item:last-child { border-bottom: 0; }
        .mab-mode-card { border: 2px solid #e2e8f0; border-radius: 10px; padding: 0.85rem 1rem; cursor: pointer; }
        .mab-mode-card.active { border-color: #047857; background: #ecfdf5; }
        #mabDrugSearch { width: 100%; }
        .mab-outcome-group { gap: .35rem 1.1rem; }
        .mab-outcome-group .form-check { min-width: 7.5rem; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-2 text-dark">
                <i class="fas fa-bacteria me-2" style="color:#047857;"></i>
                Monitor Antibiotic
            </h4>
            <p class="text-muted small mb-3">
                ดักจับผู้ป่วยใน (IPD) ที่ใช้ยาปฏิชีวนะรูปแบบฉีด ต่อเนื่องเกินเกณฑ์ —
                ค่าเริ่มต้น &gt; <?php echo (int)$config['min_duration_days']; ?> วัน · ตั้งกลุ่มเภสัชวิทยาหรือรายการยาได้เองจาก HOSxP
            </p>

            <?php if ($flash_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo htmlspecialchars($flash_msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            <?php if ($flash_err): ?>
            <div class="alert alert-danger alert-dismissible fade show"><?php echo htmlspecialchars($flash_err); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <ul class="nav nav-tabs mb-3">
                <li class="nav-item">
                    <a class="nav-link <?php echo $tab === 'dashboard' ? 'active' : ''; ?>" href="monitor_antibiotic.php">
                        <i class="fas fa-chart-bar me-1"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $tab === 'settings' ? 'active' : ''; ?>" href="monitor_antibiotic.php?tab=settings">
                        <i class="fas fa-cog me-1"></i> ตั้งค่า
                    </a>
                </li>
            </ul>

            <?php if ($tab === 'settings'): ?>
            <div class="bg-white border p-4 rounded shadow-sm mb-3">
                <form method="post" id="mabConfigForm">
                    <input type="hidden" name="action" value="save_config">
                    <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-sliders-h me-1"></i> การตั้งค่าทั่วไป</h6>
                    <div class="row g-3 mb-3">
                        <div class="col-md-3">
                            <label class="form-label fw-bold small">ระยะเวลาใช้ยาเกิน (วัน)</label>
                            <input type="number" name="min_duration_days" class="form-control" min="1" max="365"
                                value="<?php echo (int)$config['min_duration_days']; ?>" required>
                            <div class="form-text">แจ้งเตือนเมื่อ duration &gt; ค่านี้</div>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold small">รูปแบบยา (dosageform)</label>
                            <input type="text" name="dosage_form" id="dosage_form" class="form-control"
                                value="<?php echo htmlspecialchars($config['dosage_form']); ?>" required>
                            <div class="form-text">ค่าเริ่มต้น Injection (ไม่สนตัวพิมพ์เล็ก/ใหญ่)</div>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold small">ย้อนหลังวันสั่ง med plan</label>
                            <input type="number" name="order_lookback_days" class="form-control" min="1" max="365"
                                value="<?php echo (int)$config['order_lookback_days']; ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold small">มีการจ่ายยาในช่วง (วันล่าสุด)</label>
                            <input type="number" name="recent_rx_days" class="form-control" min="1" max="30"
                                value="<?php echo (int)$config['recent_rx_days']; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">ยกเว้นวิธีใช้ (Regex)</label>
                            <input type="text" name="exclude_method_regex" class="form-control"
                                value="<?php echo htmlspecialchars($config['exclude_method_regex']); ?>">
                            <div class="form-text">ค่าเริ่มต้น PD|HD</div>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold small">รอตอบ Consult (วัน)</label>
                            <input type="number" name="reply_wait_days" class="form-control" min="1" max="30"
                                value="<?php echo (int)$reply_wait_days; ?>" required>
                            <div class="form-text">ค่าเริ่มต้น 3 วัน — เกินแล้วกลับเป็นรอ Consult</div>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" name="monitor_active" id="monitor_active" value="1"
                                    <?php echo !empty($config['monitor_active']) ? 'checked' : ''; ?>>
                                <label class="form-check-label fw-bold" for="monitor_active">เปิดใช้งาน Monitor Antibiotic</label>
                            </div>
                        </div>
                    </div>
                    <?php $mab_lvl = mab_normalize_alert_level($config['alert_level'] ?? 'soft'); ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">ระดับ Alert ค่าเริ่มต้น</label>
                        <div class="row g-2">
                            <div class="col-md-6">
                                <label class="mab-alert-card d-block <?php echo $mab_lvl !== 'hard' ? 'active-soft' : ''; ?>">
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="radio" name="alert_level" id="mab_alert_soft" value="soft"
                                            <?php echo $mab_lvl !== 'hard' ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="mab_alert_soft">
                                            <span class="badge bg-warning text-dark me-1">Soft Alert</span>
                                            <span class="fw-bold">ค่าเริ่มต้น</span>
                                        </label>
                                    </div>
                                    <div class="form-text small mb-0">เตือนสีเหลือง — ไม่บล็อกการจ่าย ใช้กับ Smart Pharma / รายยาที่ยังไม่กำหนดเอง</div>
                                </label>
                            </div>
                            <div class="col-md-6">
                                <label class="mab-alert-card d-block <?php echo $mab_lvl === 'hard' ? 'active-hard' : ''; ?>">
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="radio" name="alert_level" id="mab_alert_hard" value="hard"
                                            <?php echo $mab_lvl === 'hard' ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="mab_alert_hard">
                                            <span class="badge bg-danger me-1">Hard Alert</span>
                                            <span class="fw-bold">เตือนระดับสูง</span>
                                        </label>
                                    </div>
                                    <div class="form-text small mb-0">เตือนสีแดง — ใช้เมื่อต้องการบังคับให้เภสัชกรเห็นและจัดการก่อน</div>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="alert alert-light border small mt-2 mb-3">
                        <i class="fas fa-bell me-1 text-success"></i>
                        Alert ใน Smart Pharma: ไปที่ <a href="smart_pharma_settings.php">ตั้งค่าโมดูล</a>
                        เปิด <b>Monitor Antibiotic</b> เฉพาะ IPD
                        — Cron ใช้สคริปต์เดิม <code>cron_smart_pharma_telegram.php</code>
                        (ดู <code>CRON_SETUP_IT.md</code>)
                    </div>

                    <hr>
                    <h6 class="fw-bold text-secondary mb-2"><i class="fas fa-filter me-1"></i> โหมดการดักจับยา</h6>
                    <div class="row g-2 mb-3">
                        <div class="col-md-4">
                            <label class="mab-mode-card d-block <?php echo $filter_mode === 'group' ? 'active' : ''; ?>" id="modeCardGroup">
                                <div class="form-check mb-0">
                                    <input class="form-check-input" type="radio" name="filter_mode" id="filter_mode_group" value="group"
                                        <?php echo $filter_mode === 'group' ? 'checked' : ''; ?> onchange="mabToggleMode()">
                                    <label class="form-check-label fw-bold" for="filter_mode_group">ตามกลุ่มเภสัชวิทยา</label>
                                </div>
                                <div class="form-text small mb-0">เช่น ANTIBIOTICS (24) จาก Pharmacology</div>
                            </label>
                        </div>
                        <div class="col-md-4">
                            <label class="mab-mode-card d-block <?php echo $filter_mode === 'flag' ? 'active' : ''; ?>" id="modeCardFlag">
                                <div class="form-check mb-0">
                                    <input class="form-check-input" type="radio" name="filter_mode" id="filter_mode_flag" value="flag"
                                        <?php echo $filter_mode === 'flag' ? 'checked' : ''; ?> onchange="mabToggleMode()">
                                    <label class="form-check-label fw-bold" for="filter_mode_flag">ติ๊ก ยาปฏิชีวนะ ใน HOSxP</label>
                                </div>
                                <div class="form-text small mb-0">
                                    ประเภทรายการที่ติ๊ก “ยาปฏิชีวนะ”
                                    <span class="badge bg-light text-dark border"><?php echo (int)$antibiotic_flag_count; ?> ยา Injection</span>
                                </div>
                            </label>
                        </div>
                        <div class="col-md-4">
                            <label class="mab-mode-card d-block <?php echo $filter_mode === 'drugs' ? 'active' : ''; ?>" id="modeCardDrugs">
                                <div class="form-check mb-0">
                                    <input class="form-check-input" type="radio" name="filter_mode" id="filter_mode_drugs" value="drugs"
                                        <?php echo $filter_mode === 'drugs' ? 'checked' : ''; ?> onchange="mabToggleMode()">
                                    <label class="form-check-label fw-bold" for="filter_mode_drugs">ตามรายการยาที่เลือกเอง</label>
                                </div>
                                <div class="form-text small mb-0">เพิ่ม/ลบรายการด้านล่างได้เอง</div>
                            </label>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                            <label class="form-label fw-bold small mb-0">
                                <i class="fas fa-layer-group me-1 text-success"></i>
                                กลุ่มเภสัชวิทยาจาก HOSxP
                                <span class="text-muted fw-normal">(เฉพาะยา Injection)</span>
                            </label>
                            <div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-outline-secondary" onclick="mabSelectGroups(true)">เลือกทั้งหมด</button>
                                <button type="button" class="btn btn-outline-secondary" onclick="mabSelectGroups(false)">ยกเลิกทั้งหมด</button>
                            </div>
                        </div>
                        <?php if (empty($hosxp_groups)): ?>
                        <div class="alert alert-warning small mb-0">ไม่สามารถดึงกลุ่มเภสัชวิทยาจาก HOSxP ได้ — ตรวจสอบการเชื่อมต่อ</div>
                        <?php else: ?>
                        <div class="mab-group-box" id="mabGroupBox">
                            <?php foreach ($hosxp_groups as $g):
                                $gid = (string)$g['pharmacology_group_id'];
                                $checked = isset($selected_active_ids[$gid]);
                                ?>
                            <div class="mab-group-item form-check">
                                <input class="form-check-input mab-group-cb" type="checkbox" name="group_ids[]"
                                    id="grp_<?php echo htmlspecialchars($gid); ?>"
                                    value="<?php echo htmlspecialchars($gid); ?>"
                                    <?php echo $checked ? 'checked' : ''; ?>>
                                <input type="hidden" name="group_name[<?php echo htmlspecialchars($gid); ?>]"
                                    value="<?php echo htmlspecialchars($g['pharmacology_group_name']); ?>">
                                <label class="form-check-label small" for="grp_<?php echo htmlspecialchars($gid); ?>">
                                    <span class="fw-bold"><?php echo htmlspecialchars($gid); ?></span>
                                    — <?php echo htmlspecialchars($g['pharmacology_group_name']); ?>
                                    <span class="badge bg-light text-dark border ms-1"><?php echo (int)$g['drug_count']; ?> ยา</span>
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="form-text">เลือกกลุ่มแล้วกดบันทึก — หรือกด “ดึงยาจากกลุ่มที่เลือก” เพื่อใส่ในรายการยา</div>
                        <?php endif; ?>
                    </div>

                    <div class="mt-3">
                        <button type="submit" class="btn btn-mab fw-bold">
                            <i class="fas fa-save me-1"></i> บันทึกการตั้งค่า
                        </button>
                    </div>
                </form>
            </div>

            <div class="bg-white border p-4 rounded shadow-sm" id="mab-drug-list">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                    <h6 class="fw-bold text-secondary mb-0">
                        <i class="fas fa-pills me-1"></i>
                        รายการยาปฏิชีวนะที่เฝ้าระวัง
                        <span class="badge bg-success"><?php echo count($drug_list); ?></span>
                    </h6>
                    <div class="d-flex flex-wrap gap-2">
                        <form method="post" class="d-inline" onsubmit="return mabCollectGroupsForImport(this);">
                            <input type="hidden" name="action" value="import_from_groups">
                            <input type="hidden" name="dosage_form" value="<?php echo htmlspecialchars($config['dosage_form']); ?>">
                            <div id="importGroupIds"></div>
                            <button type="submit" class="btn btn-sm btn-outline-success fw-bold">
                                <i class="fas fa-download me-1"></i> ดึงยาจากกลุ่มที่เลือก
                            </button>
                        </form>
                        <form method="post" class="d-inline">
                            <input type="hidden" name="action" value="import_from_flag">
                            <input type="hidden" name="dosage_form" value="<?php echo htmlspecialchars($config['dosage_form']); ?>">
                            <button type="submit" class="btn btn-sm btn-outline-primary fw-bold">
                                <i class="fas fa-check-square me-1"></i> ดึงยาที่ติ๊ก ยาปฏิชีวนะ
                                <span class="badge bg-light text-dark ms-1"><?php echo (int)$antibiotic_flag_count; ?></span>
                            </button>
                        </form>
                        <form method="post" class="d-inline" onsubmit="return confirm('ล้างรายการยาทั้งหมด?');">
                            <input type="hidden" name="action" value="clear_drugs">
                            <button type="submit" class="btn btn-sm btn-outline-danger fw-bold" <?php echo empty($drug_list) ? 'disabled' : ''; ?>>
                                <i class="fas fa-trash me-1"></i> ล้างทั้งหมด
                            </button>
                        </form>
                    </div>
                </div>

                <form method="post" class="row g-2 align-items-end mb-3">
                    <input type="hidden" name="action" value="add_drug">
                    <div class="col-md-9">
                        <label class="form-label small fw-bold mb-1">ค้นหาและเพิ่มยาจาก HOSxP</label>
                        <select name="drug" id="mabDrugSearch" class="form-select" required></select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-mab fw-bold w-100">
                            <i class="fas fa-plus me-1"></i> เพิ่มยา
                        </button>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-sm table-bordered table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ยา</th>
                                <th>Generic</th>
                                <th class="text-center">icode</th>
                                <th>รูปแบบ</th>
                                <th class="text-center">กลุ่ม</th>
                                <th class="text-center">Alert</th>
                                <th class="text-center">เปิด</th>
                                <th class="text-center">จัดการ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($drug_list)): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-4">
                                    ยังไม่มีรายการยา — เลือกกลุ่มแล้วกด “ดึงยาจากกลุ่มที่เลือก” หรือค้นหาเพิ่มทีละรายการ
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($drug_list as $d): ?>
                            <tr class="<?php echo empty($d['active']) ? 'table-secondary' : ''; ?>">
                                <td class="small fw-bold"><?php echo htmlspecialchars($d['drug_name']); ?></td>
                                <td class="small"><?php echo htmlspecialchars($d['generic_name']); ?></td>
                                <td class="text-center small"><?php echo htmlspecialchars($d['icode']); ?></td>
                                <td class="small"><?php echo htmlspecialchars($d['dosageform']); ?></td>
                                <td class="text-center small"><?php echo htmlspecialchars($d['pharmacology_group1']); ?></td>
                                <td class="text-center">
                                    <?php $dlvl = mab_normalize_alert_level($d['alert_level'] ?? 'soft'); ?>
                                    <form method="post" class="d-inline">
                                        <input type="hidden" name="action" value="set_drug_alert_level">
                                        <input type="hidden" name="drug_id" value="<?php echo (int)$d['id']; ?>">
                                        <input type="hidden" name="alert_level" value="<?php echo $dlvl === 'hard' ? 'soft' : 'hard'; ?>">
                                        <button type="submit" class="btn btn-sm <?php echo $dlvl === 'hard' ? 'btn-danger' : 'btn-warning'; ?>"
                                            title="คลิกเพื่อสลับ Soft / Hard">
                                            <?php echo $dlvl === 'hard' ? 'Hard' : 'Soft'; ?>
                                        </button>
                                    </form>
                                </td>
                                <td class="text-center">
                                    <form method="post" class="d-inline">
                                        <input type="hidden" name="action" value="toggle_drug">
                                        <input type="hidden" name="drug_id" value="<?php echo (int)$d['id']; ?>">
                                        <?php if (!empty($d['active'])): ?>
                                        <button type="submit" class="btn btn-sm btn-success" title="คลิกเพื่อปิด">เปิด</button>
                                        <?php else: ?>
                                        <input type="hidden" name="active" value="1">
                                        <button type="submit" class="btn btn-sm btn-outline-secondary" title="คลิกเพื่อเปิด">ปิด</button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                                <td class="text-center">
                                    <form method="post" class="d-inline" onsubmit="return confirm('ลบยานี้?');">
                                        <input type="hidden" name="action" value="delete_drug">
                                        <input type="hidden" name="drug_id" value="<?php echo (int)$d['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-times"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="form-text mt-2">
                    คอลัมน์ Alert: <span class="badge bg-warning text-dark">Soft</span> = เตือน
                    · <span class="badge bg-danger">Hard</span> = เตือนระดับสูง — กดปุ่มเพื่อสลับ (ยาใหม่เป็น Soft)
                    · โหมด “ตามรายการยา” ใช้เฉพาะยาที่สถานะ <b>เปิด</b>
                    · โหมด “กลุ่มเภสัชวิทยา” ใช้กลุ่มที่ติ๊กด้านบน
                    · โหมด “ติ๊ก ยาปฏิชีวนะ” ใช้ยาที่ติ๊กในหน้าแก้ไขรายการเวชภัณฑ์ HOSxP (<code>drugitems.antibiotic = Y</code>)
                </div>
            </div>

            <?php else: ?>
            <div class="bg-white border p-4 rounded shadow-sm">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                    <div>
                        <span class="badge bg-light text-dark border me-1">เกณฑ์ &gt; <?php echo (int)$config['min_duration_days']; ?> วัน</span>
                        <span class="badge bg-light text-dark border me-1"><?php echo htmlspecialchars($mode_label); ?></span>
                        <span class="badge bg-light text-dark border me-1">รอตอบ <?php echo (int)$reply_wait_days; ?> วัน</span>
                        <span class="badge bg-light text-dark border me-1"><?php echo htmlspecialchars($config['dosage_form']); ?></span>
                        <?php echo mab_alert_badge_html($config['alert_level'] ?? 'soft'); ?>
                    </div>
                    <div class="d-flex flex-wrap align-items-center gap-2">
                        <input type="text" id="filter_hn" class="form-control form-control-sm" style="width:140px" placeholder="HN" autocomplete="off">
                        <button type="button" class="btn btn-sm btn-mab fw-bold" id="btnFetchMab" onclick="fetchMabData()">
                            <i class="fas fa-sync-alt me-1"></i> โหลดข้อมูล
                        </button>
                    </div>
                </div>
                <div id="hnFocusBanner" class="alert alert-warning py-2 px-3 mb-3 small fw-bold d-none"></div>

                <div id="mabLoading" class="text-center py-5 d-none">
                    <div class="spinner-border text-success" role="status"></div>
                    <div class="small text-muted mt-2">กำลังดึงข้อมูลจาก HOSxP...</div>
                </div>
                <div id="mabError" class="alert alert-danger d-none"></div>
                <div id="mabDisabled" class="alert alert-warning d-none">Monitor Antibiotic ถูกปิดใช้งาน — ไปเปิดในแท็บตั้งค่า</div>

                <div id="mabDashboard" class="d-none">
                    <div class="row g-3 mb-3" id="consultStatusCards">
                        <div class="col-md-4">
                            <div class="mab-card py-2">
                                <div class="small text-muted">รอ Consult</div>
                                <div class="fs-4 fw-bold text-warning" id="stWaiting">0</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mab-card py-2">
                                <div class="small text-muted">ระหว่าง Consult</div>
                                <div class="fs-4 fw-bold text-primary" id="stProgress">0</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mab-card py-2">
                                <div class="small text-muted">ปิดการ Consult</div>
                                <div class="fs-4 fw-bold text-success" id="stClosed">0</div>
                            </div>
                        </div>
                    </div>
                    <div class="row g-3 mb-4">
                        <div class="col-lg-7">
                            <div class="mab-card h-100">
                                <h6 class="fw-bold text-secondary mb-3">
                                    <i class="fas fa-hospital me-1"></i>
                                    Ward ที่มีผู้ป่วยใช้ antibiotic เกินเกณฑ์
                                </h6>
                                <div id="wardChart"></div>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="mab-card h-100 d-flex flex-column justify-content-center align-items-center">
                                <div class="text-muted small fw-bold mb-1">จำนวนรายการ med plan ทั้งหมด</div>
                                <div class="mab-gauge-num" id="totalCases">0</div>
                                <div class="text-muted small mt-2">
                                    ผู้ป่วย <span class="fw-bold text-dark" id="totalPatients">0</span> ราย
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="section-alert mb-4">
                        <h6 class="fw-bold text-danger mb-2">
                            <i class="fas fa-exclamation-circle me-1"></i>
                            Hard Alert <span id="hardCount" class="badge bg-danger">0</span>
                        </h6>
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered table-hover mb-0" id="mabHardTable">
                                <thead>
                                    <tr>
                                        <th>HN</th>
                                        <th>ชื่อผู้ป่วย</th>
                                        <th>Ward</th>
                                        <th>ยา</th>
                                        <th>วิธีใช้</th>
                                        <th class="text-center">qty</th>
                                        <th>วันที่เริ่ม</th>
                                        <th>จ่ายล่าสุด</th>
                                        <th class="text-center">duration</th>
                                        <th class="text-center">สถานะ Consult</th>
                                        <th class="text-center">จัดการ</th>
                                    </tr>
                                </thead>
                                <tbody id="mabHardBody"></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="section-soft">
                        <h6 class="fw-bold text-warning mb-2">
                            <i class="fas fa-exclamation-triangle me-1"></i>
                            Soft Alert <span id="softCount" class="badge bg-warning text-dark">0</span>
                        </h6>
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered table-hover mb-0" id="mabSoftTable">
                                <thead>
                                    <tr>
                                        <th>HN</th>
                                        <th>ชื่อผู้ป่วย</th>
                                        <th>Ward</th>
                                        <th>ยา</th>
                                        <th>วิธีใช้</th>
                                        <th class="text-center">qty</th>
                                        <th>วันที่เริ่ม</th>
                                        <th>จ่ายล่าสุด</th>
                                        <th class="text-center">duration</th>
                                        <th class="text-center">สถานะ Consult</th>
                                        <th class="text-center">จัดการ</th>
                                    </tr>
                                </thead>
                                <tbody id="mabSoftBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mabConsultModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold"><i class="fas fa-notes-medical me-2 text-danger"></i>บันทึก Intervention — Antibiotic</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="small text-muted mb-2" id="mabConsultCaseInfo"></div>
                            <div class="border rounded p-2 mb-3 bg-light" id="mabDrugSelectBox">
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                                    <label class="form-label small fw-bold mb-0">
                                        <i class="fas fa-pills me-1 text-success"></i>
                                        เลือกยาที่จะปรึกษา (HN เดียวกัน)
                                    </label>
                                    <div class="btn-group btn-group-sm">
                                        <button type="button" class="btn btn-outline-secondary" onclick="mabToggleDrugChecks(true)">เลือกทั้งหมด</button>
                                        <button type="button" class="btn btn-outline-secondary" onclick="mabToggleDrugChecks(false)">ยกเลิกทั้งหมด</button>
                                    </div>
                                </div>
                                <div id="mabDrugCheckList" class="small"></div>
                                <div class="form-text mb-0">ค่าเริ่มต้นเลือกทั้งหมด — ติ๊กเฉพาะยาที่ต้องการปรึกษาในใบนี้</div>
                            </div>
                            <div class="row g-2">
                                <div class="col-md-8">
                                    <label class="form-label small fw-bold">เภสัชกรที่ Consult</label>
                                    <select id="mabPharmacist" class="form-select form-select-sm">
                                        <?php if (empty($pharmacist_options)): ?>
                                        <option value="">— ไม่พบผู้ใช้ตำแหน่งเภสัชกร —</option>
                                        <?php else: ?>
                                        <?php foreach ($pharmacist_options as $ph):
                                            $ph_name = trim((string)($ph['full_name'] ?: $ph['username']));
                                            $ph_pos = trim((string)($ph['entryposition'] ?? ''));
                                            $ph_label = $ph_pos !== '' ? ($ph_name . ' (' . $ph_pos . ')') : $ph_name;
                                        ?>
                                        <option value="<?php echo (int)$ph['id']; ?>"
                                            <?php echo ((int)$ph['id'] === $current_user_id) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($ph_label); ?>
                                        </option>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label small fw-bold">รอตอบกลับ (วัน)</label>
                                    <input type="number" id="mabReplyWait" class="form-control form-control-sm" min="1" max="30" value="<?php echo (int)$reply_wait_days; ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">ใช่ความคลาดเคลื่อนไหม</label>
                                    <select id="mabIvDeviation" class="form-select form-select-sm" onchange="AlertMute.sync('mabIvDeviation')">
                                        <option value="">— ไม่ระบุ —</option>
                                        <option value="ความคลาดเคลื่อนจริง">ความคลาดเคลื่อนจริง</option>
                                        <option value="ไม่ใช่ความคลาดเคลื่อน">ไม่ใช่ความคลาดเคลื่อน</option>
                                    </select>
                                    <?php require_once __DIR__ . '/monitor_alert_mute_ui.php'; monitor_alert_mute_box('mabIvDeviation'); ?>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold mb-1">ผลการปรึกษา</label>
                                    <div class="d-flex flex-wrap mab-outcome-group mb-2">
                                        <?php foreach (mab_consult_outcome_options() as $okey => $olabel): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="mabOutcome" id="mabOutcome_<?php echo htmlspecialchars($okey); ?>"
                                                   value="<?php echo htmlspecialchars($okey); ?>" onchange="mabSyncOutcomeOther()">
                                            <label class="form-check-label small" for="mabOutcome_<?php echo htmlspecialchars($okey); ?>"><?php echo htmlspecialchars($olabel); ?></label>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <label class="form-label small fw-bold">หมายเหตุ / ระบุเพิ่มเติม</label>
                                    <textarea id="mabConsultNote" class="form-control form-control-sm" rows="2" placeholder="กรณี อื่นๆ ระบุ รายละเอียด หรือหมายเหตุเพิ่มเติม"></textarea>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold mb-1">ปิดการ Consult — กำหนดวัน</label>
                                    <div class="d-flex flex-wrap gap-3 mb-2">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="mabCloseMode" id="mabCloseModeMore" value="more_days" checked onchange="mabSyncCloseModeHint()">
                                            <label class="form-check-label small" for="mabCloseModeMore">จำนวนวันจนถึง <b>plan off</b> (ใช้ต่ออีกกี่วัน)</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="mabCloseMode" id="mabCloseModeTotal" value="total_days" onchange="mabSyncCloseModeHint()">
                                            <label class="form-check-label small" for="mabCloseModeTotal">จำนวนวันใช้ยา <b>ทั้งหมด</b> (นับจากวันเริ่ม)</label>
                                        </div>
                                    </div>
                                    <div class="row g-2 align-items-end">
                                        <div class="col-md-4">
                                            <label class="form-label small fw-bold mb-1" id="mabDaysValueLabel">วันจนถึง plan off</label>
                                            <input type="number" id="mabContinueDays" class="form-control form-control-sm" min="1" max="365" value="7">
                                        </div>
                                        <div class="col-md-8">
                                            <div class="form-text mb-0" id="mabCloseModeHint">เช่น ใช้ต่ออีก 20 วัน → ระบบจะกลับเป็นรอ Consult เมื่อครบ 20 วัน</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="mabConsultMsg" class="alert mt-3 mb-0 py-2 small d-none"></div>
                        </div>
                        <div class="modal-footer flex-wrap">
                            <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิดหน้าต่าง</button>
                            <button type="button" class="btn btn-outline-info btn-sm fw-bold" onclick="mabOpenHistory()">
                                <i class="fas fa-history me-1"></i> เปิดดูประวัติ
                            </button>
                            <button type="button" class="btn btn-outline-warning btn-sm fw-bold" onclick="mabResetWaiting()">
                                ตั้งเป็นรอ Consult
                            </button>
                            <button type="button" class="btn btn-warning btn-sm fw-bold text-dark" onclick="mabSaveResult()">
                                บันทึกผล Consult
                            </button>
                            <button type="button" class="btn btn-outline-success btn-sm fw-bold" onclick="mabCloseConsult()">
                                ปิดการ Consult
                            </button>
                            <button type="button" class="btn btn-mab btn-sm fw-bold" onclick="mabSaveIntervention(true)">
                                <i class="fas fa-print me-1"></i> บันทึกและพิมพ์ใบปรึกษาแพทย์
                            </button>
                            <button type="button" class="btn btn-sm fw-bold text-white" style="background:#0d9488;" onclick="mabSaveIntervention(false)">บันทึก Intervention</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mabHistoryModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-scrollable">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold"><i class="fas fa-history me-2 text-info"></i>ประวัติ Consult</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="small text-muted mb-2" id="mabHistoryInfo"></div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>เวลา</th>
                                            <th>ยา</th>
                                            <th>การดำเนินการ</th>
                                            <th>สถานะ</th>
                                            <th>กำหนดวัน</th>
                                            <th>ผู้ทำ</th>
                                            <th>หมายเหตุ</th>
                                            <th class="text-center" style="width:90px;">จัดการ</th>
                                        </tr>
                                    </thead>
                                    <tbody id="mabHistoryBody">
                                        <tr><td colspan="8" class="text-center text-muted py-3">ยังไม่มีประวัติ</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">ปิด</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mabHistEditModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header py-2">
                            <h5 class="modal-title fw-bold"><i class="fas fa-edit me-2 text-primary"></i>แก้ไขประวัติ Consult</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" id="mabHistEditId" value="">
                            <div class="row g-2">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold mb-0">ยา</label>
                                    <input type="text" class="form-control form-control-sm" id="mabHistEditDrug">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold mb-0">การดำเนินการ</label>
                                    <input type="text" class="form-control form-control-sm" id="mabHistEditAction">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold mb-0">ผู้ทำ</label>
                                    <input type="text" class="form-control form-control-sm" id="mabHistEditActor">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold mb-0">+วัน (continue)</label>
                                    <input type="number" min="0" class="form-control form-control-sm" id="mabHistEditContinue">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold mb-0">รวมวัน (total)</label>
                                    <input type="number" min="0" class="form-control form-control-sm" id="mabHistEditPlanned">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold mb-0">วัน plan off</label>
                                    <input type="date" class="form-control form-control-sm" id="mabHistEditPlanOff">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold mb-0">กำหนดตอบ (reply due)</label>
                                    <input type="text" class="form-control form-control-sm" id="mabHistEditReplyDue" placeholder="YYYY-MM-DD HH:MM:SS">
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold mb-0">หมายเหตุ</label>
                                    <textarea class="form-control form-control-sm" id="mabHistEditNote" rows="2"></textarea>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold mb-0">คำตอบแพทย์ / ผล Consult</label>
                                    <textarea class="form-control form-control-sm" id="mabHistEditReply" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer py-2">
                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">ยกเลิก</button>
                            <button type="button" class="btn btn-primary btn-sm fw-bold" onclick="mabSaveHistEdit()">บันทึกการแก้ไข</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mabHistDelModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header py-2">
                            <h5 class="modal-title fw-bold text-danger"><i class="fas fa-trash-alt me-2"></i>ลบประวัติ Consult</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p class="mb-2" id="mabHistDelHint">ยืนยันลบรายการนี้ การลบย้อนกลับไม่ได้</p>
                            <label class="form-label small fw-bold">พิมพ์คำว่า <code>delete</code> เพื่อยืนยัน</label>
                            <input type="text" id="mabHistDelConfirm" class="form-control" autocomplete="off" placeholder="delete">
                            <input type="hidden" id="mabHistDelId" value="">
                        </div>
                        <div class="modal-footer py-2">
                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">ยกเลิก</button>
                            <button type="button" class="btn btn-danger btn-sm fw-bold" id="mabHistDelBtn" disabled onclick="mabDoHistDelete()">ลบ</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/monitor_hn_filter.js"></script>
<?php if ($tab === 'settings'): ?>
<script src="js/select2.min.js"></script>
<script>
function mabToggleMode() {
    var isGroup = document.getElementById('filter_mode_group').checked;
    var isFlag = document.getElementById('filter_mode_flag').checked;
    var isDrugs = document.getElementById('filter_mode_drugs').checked;
    document.getElementById('modeCardGroup').classList.toggle('active', isGroup);
    document.getElementById('modeCardFlag').classList.toggle('active', isFlag);
    document.getElementById('modeCardDrugs').classList.toggle('active', isDrugs);
}
function mabToggleAlertCards() {
    var soft = document.getElementById('mab_alert_soft');
    var hard = document.getElementById('mab_alert_hard');
    if (!soft || !hard) return;
    var softCard = soft.closest('.mab-alert-card');
    var hardCard = hard.closest('.mab-alert-card');
    if (softCard) softCard.classList.toggle('active-soft', soft.checked);
    if (hardCard) hardCard.classList.toggle('active-hard', hard.checked);
}
document.addEventListener('change', function(e) {
    if (e.target && e.target.name === 'alert_level') mabToggleAlertCards();
});
function mabSelectGroups(on) {
    document.querySelectorAll('.mab-group-cb').forEach(function(cb) { cb.checked = !!on; });
}
function mabCollectGroupsForImport(form) {
    var box = document.getElementById('importGroupIds');
    box.innerHTML = '';
    var checked = document.querySelectorAll('.mab-group-cb:checked');
    if (!checked.length) {
        alert('กรุณาเลือกกลุ่มเภสัชวิทยาก่อน');
        return false;
    }
    checked.forEach(function(cb) {
        var inp = document.createElement('input');
        inp.type = 'hidden';
        inp.name = 'group_ids[]';
        inp.value = cb.value;
        box.appendChild(inp);
    });
    return true;
}
$(function() {
    mabToggleMode();
    $('#mabDrugSearch').select2({
        theme: 'bootstrap-5',
        width: '100%',
        placeholder: 'พิมพ์ชื่อยาหรือ icode เพื่อค้นหาจาก HOSxP...',
        allowClear: true,
        ajax: {
            url: 'fetch_hosxp_drugs_select_api.php',
            dataType: 'json',
            delay: 250,
            data: function(params) { return { q: params.term || '' }; },
            processResults: function(data) { return { results: data.results || [] }; }
        }
    });
});
</script>
<?php else: ?>
<script>
var MAB_CURRENT_USER_ID = <?php echo (int)$current_user_id; ?>;
var MAB_REPLY_WAIT = <?php echo (int)$reply_wait_days; ?>;
var mabCurrentCase = null;
var mabHnCases = [];
var mabConsultModal = null;

function escHtml(s) {
    if (s == null) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function consultBadge(c) {
    c = c || {};
    var st = c.status || 'waiting';
    var label = c.status_label || st;
    var cls = 'bg-warning text-dark';
    var extra = '';
    if (st === 'in_progress') {
        cls = 'bg-primary';
        if (c.reply_due_at) extra = '<div class="small text-muted">ตอบภายใน ' + escHtml(c.reply_due_at) + '</div>';
    } else if (st === 'closed') {
        cls = 'bg-success';
        if (c.plan_off_date) {
            extra = '<div class="small text-muted">plan off ' + escHtml(c.plan_off_date);
            if (c.close_mode === 'total_days' && c.planned_total_days) {
                extra += ' (รวม ' + escHtml(c.planned_total_days) + ' วัน)';
            } else if (c.continue_days) {
                extra += ' (+' + escHtml(c.continue_days) + ' วัน)';
            }
            extra += '</div>';
        } else if (c.reopen_at) {
            extra = '<div class="small text-muted">เปิดใหม่ ' + escHtml(c.reopen_at) + '</div>';
        }
    }
    return '<span class="badge ' + cls + '">' + escHtml(label) + '</span>' + extra;
}
function renderWardChart(wardSummary) {
    var el = document.getElementById('wardChart');
    if (!wardSummary || !wardSummary.length) {
        el.innerHTML = '<div class="text-muted small py-3">ไม่พบข้อมูล Ward</div>';
        return;
    }
    var max = 0;
    wardSummary.forEach(function(w) { if (w.patient_count > max) max = w.patient_count; });
    if (max < 1) max = 1;
    var html = '';
    wardSummary.forEach(function(w) {
        var pct = Math.round((w.patient_count / max) * 100);
        html += '<div class="d-flex align-items-center gap-2 ward-bar-row">'
            + '<div class="ward-bar-label text-truncate" title="' + escHtml(w.wname) + '">' + escHtml(w.wname) + '</div>'
            + '<div class="ward-bar-track"><div class="ward-bar-fill" style="width:' + pct + '%"></div></div>'
            + '<div class="ward-bar-count text-danger">' + w.patient_count + '</div>'
            + '</div>';
    });
    el.innerHTML = html;
}
function fillAlertTable(tbodyId, items, emptyMsg) {
    var tbody = document.getElementById(tbodyId);
    if (!tbody) return;
    if (!items.length) {
        tbody.innerHTML = '<tr><td colspan="11" class="text-center py-4 text-muted">' + emptyMsg + '</td></tr>';
        return;
    }
    var rows = '';
    items.forEach(function(it) {
        var idx = it._idx;
        var durClass = it.duration >= 14 ? 'bg-danger' : (it.duration >= 12 ? 'bg-warning text-dark' : 'bg-secondary');
        var c = it.consult || {};
        rows += '<tr>'
            + '<td><a href="smart_pharma_screen_hn.php?hn=' + encodeURIComponent(it.hn || '') + '" class="fw-bold text-decoration-none" target="_blank">' + escHtml(it.hn) + '</a></td>'
            + '<td>' + escHtml(it.ptname) + '</td>'
            + '<td class="small">' + escHtml(it.wname) + '</td>'
            + '<td class="small">' + escHtml(it.drug) + '</td>'
            + '<td class="small">' + escHtml(it.method) + '</td>'
            + '<td class="text-center">' + escHtml(it.qty) + '</td>'
            + '<td class="small">' + escHtml(it.firstday) + '</td>'
            + '<td class="small">' + escHtml(it.rxdatetime) + '</td>'
            + '<td class="text-center"><span class="badge ' + durClass + ' duration-badge">' + escHtml(it.duration) + ' วัน</span></td>'
            + '<td class="text-center small">' + consultBadge(c) + '</td>'
            + '<td class="text-center text-nowrap">'
            + '<button type="button" class="btn btn-sm btn-success fw-bold me-1" onclick="openConsultModal(' + idx + ')">'
            + '<i class="fas fa-notes-medical me-1"></i>บันทึก Intervention</button>'
            + '<button type="button" class="btn btn-sm btn-outline-info" title="ประวัติ" onclick="mabOpenHistoryFromRow(' + idx + ')">'
            + '<i class="fas fa-history"></i></button>'
            + '</td>'
            + '</tr>';
    });
    tbody.innerHTML = rows;
}
function renderTable(items) {
    window._mabItems = items;
    var hard = [];
    var soft = [];
    items.forEach(function(it, idx) {
        it._idx = idx;
        if ((it.alert_level || 'soft') === 'hard') hard.push(it);
        else soft.push(it);
    });
    var hc = document.getElementById('hardCount');
    var sc = document.getElementById('softCount');
    if (hc) hc.textContent = hard.length;
    if (sc) sc.textContent = soft.length;
    fillAlertTable('mabHardBody', hard, 'ไม่พบ Hard Alert');
    fillAlertTable('mabSoftBody', soft, 'ไม่พบ Soft Alert');
}
function mabToggleDrugChecks(on) {
    document.querySelectorAll('.mab-drug-cb').forEach(function(cb) { cb.checked = !!on; });
}
function mabRenderDrugChecks(cases, focusKey) {
    var box = document.getElementById('mabDrugCheckList');
    if (!cases.length) {
        box.innerHTML = '<div class="text-muted">ไม่พบยา</div>';
        return;
    }
    var html = '';
    cases.forEach(function(it, i) {
        var key = (it.an || '') + '|' + (it.med_plan_number || '');
        var id = 'mabDrugCb' + i;
        var st = (it.consult && it.consult.status_label) ? it.consult.status_label : 'รอ Consult';
        html += '<div class="form-check border-bottom py-1">'
            + '<input class="form-check-input mab-drug-cb" type="checkbox" id="' + id + '" data-idx="' + i + '" checked>'
            + '<label class="form-check-label" for="' + id + '">'
            + '<b>' + escHtml(it.drug) + '</b>'
            + ' <span class="text-muted">· ' + escHtml(it.method) + '</span>'
            + ' <span class="badge bg-secondary">' + escHtml(it.duration) + ' วัน</span>'
            + ' <span class="text-muted">(' + escHtml(st) + ')</span>'
            + '</label></div>';
    });
    box.innerHTML = html;
}
function mabSyncCloseModeHint() {
    var mode = document.querySelector('input[name="mabCloseMode"]:checked');
    var isTotal = mode && mode.value === 'total_days';
    document.getElementById('mabDaysValueLabel').textContent = isTotal ? 'วันใช้ยาทั้งหมด' : 'วันจนถึง plan off';
    document.getElementById('mabCloseModeHint').textContent = isTotal
        ? 'เช่น ใช้รวม 20 วัน นับจากวันเริ่มยา — ระบบคำนวณวัน off และกลับเป็นรอ Consult เมื่อครบ'
        : 'เช่น ใช้ต่ออีก 20 วัน / plan off ในอีก 20 วัน — ครบแล้วระบบกลับเป็นรอ Consult';
}
function openConsultModal(idx) {
    var it = (window._mabItems || [])[idx];
    if (!it) return;
    mabCurrentCase = it;
    mabHnCases = (window._mabItems || []).filter(function(x) {
        return String(x.hn || '') === String(it.hn || '') && String(x.an || '') === String(it.an || '');
    });
    if (!mabHnCases.length) mabHnCases = [it];
    var c = it.consult || {};
    document.getElementById('mabConsultCaseInfo').innerHTML =
        '<b>HN ' + escHtml(it.hn) + '</b> · ' + escHtml(it.ptname)
        + ' · ' + escHtml(it.wname)
        + '<br>พบยาเกินเกณฑ์ใน AN นี้ <b>' + mabHnCases.length + '</b> รายการ — เลือกยาที่จะใส่ในใบปรึกษาด้านล่าง';
    mabRenderDrugChecks(mabHnCases);
    if (window.AlertMute) {
        var devEl = document.getElementById('mabIvDeviation');
        if (devEl) devEl.value = '';
        AlertMute.set('mabIvDeviation', { hn: it.hn || '', vn: it.vn || '', an: it.an || '', patient_type: 'IPD' });
    }
    mabApplyOutcomeNote(c.consult_note || c.doctor_reply || '');
    document.getElementById('mabReplyWait').value = c.reply_wait_days || MAB_REPLY_WAIT;
    if (c.close_mode === 'total_days') {
        document.getElementById('mabCloseModeTotal').checked = true;
        if (c.planned_total_days) document.getElementById('mabContinueDays').value = c.planned_total_days;
    } else {
        document.getElementById('mabCloseModeMore').checked = true;
        if (c.continue_days) document.getElementById('mabContinueDays').value = c.continue_days;
    }
    mabSyncCloseModeHint();
    if (c.pharmacist_user_id) {
        var sel = document.getElementById('mabPharmacist');
        if (sel.querySelector('option[value="' + c.pharmacist_user_id + '"]')) {
            sel.value = String(c.pharmacist_user_id);
        }
    } else {
        document.getElementById('mabPharmacist').value = String(MAB_CURRENT_USER_ID);
    }
    document.getElementById('mabConsultMsg').className = 'alert mt-3 mb-0 py-2 small d-none';
    if (!mabConsultModal) {
        mabConsultModal = new bootstrap.Modal(document.getElementById('mabConsultModal'));
    }
    mabConsultModal.show();
}
function mabSelectedCases() {
    var selected = [];
    document.querySelectorAll('.mab-drug-cb:checked').forEach(function(cb) {
        var i = parseInt(cb.getAttribute('data-idx'), 10);
        if (!isNaN(i) && mabHnCases[i]) selected.push(mabHnCases[i]);
    });
    return selected;
}
function mabCasesPayloadList() {
    return mabSelectedCases().map(function(it) {
        return {
            hn: it.hn || '',
            an: it.an || '',
            med_plan_number: it.med_plan_number || '',
            icode: it.icode || '',
            drug: it.drug || '',
            method: it.method || '',
            qty: it.qty || '',
            wname: it.wname || '',
            ptname: it.ptname || '',
            firstday: it.firstday || '',
            rxdatetime: it.rxdatetime || '',
            duration: it.duration || '',
            alert_level: it.alert_level || 'soft',
            consult_id: (it.consult && it.consult.id) ? it.consult.id : 0
        };
    });
}
function mabOutcomeLabels() {
    return { stop: 'หยุดยา', hold: 'hold ยา', reduce: 'ลดขนาดยา', continue: 'ให้ยาต่อ', other: 'อื่นๆ' };
}
function mabSelectedOutcome() {
    var el = document.querySelector('input[name="mabOutcome"]:checked');
    return el ? String(el.value || '') : '';
}
function mabSyncOutcomeOther() {
    var ta = document.getElementById('mabConsultNote');
    if (!ta) return;
    ta.placeholder = mabSelectedOutcome() === 'other'
        ? 'ระบุรายละเอียดอื่นๆ'
        : 'หมายเหตุเพิ่มเติม (ถ้ามี)';
}
function mabComposeNote() {
    var key = mabSelectedOutcome();
    var extra = String(document.getElementById('mabConsultNote').value || '').trim();
    var labels = mabOutcomeLabels();
    if (!key || !labels[key]) return extra;
    var line = 'ผลการปรึกษา: ' + labels[key];
    if (extra) {
        line += (key === 'other' ? ' — ' + extra : '\n' + extra);
    }
    return line;
}
function mabApplyOutcomeNote(text) {
    var raw = String(text || '').trim();
    document.querySelectorAll('input[name="mabOutcome"]').forEach(function(el) { el.checked = false; });
    var ta = document.getElementById('mabConsultNote');
    if (!raw) {
        if (ta) ta.value = '';
        mabSyncOutcomeOther();
        return;
    }
    var labels = mabOutcomeLabels();
    var lines = raw.split(/\r\n|\n|\r/);
    var first = String(lines[0] || '').trim();
    var rest = lines.slice(1).join('\n').trim();
    var key = '';
    var extra = raw;
    var m = first.match(/^ผลการปรึกษา:\s*(.+)$/);
    var payload = m ? String(m[1] || '').trim() : first;
    Object.keys(labels).forEach(function(k) {
        var lab = labels[k];
        if (key) return;
        if (payload === lab || payload.indexOf(lab) === 0) {
            key = k;
            var after = payload.slice(lab.length).replace(/^[—\-–:\s]+/, '').trim();
            extra = [after, rest].filter(Boolean).join('\n');
        }
    });
    if (!m && !key) extra = raw;
    if (key) {
        var radio = document.getElementById('mabOutcome_' + key);
        if (radio) radio.checked = true;
        if (ta) ta.value = extra;
    } else if (ta) {
        ta.value = raw;
    }
    mabSyncOutcomeOther();
}
function mabOutcomeInterventionType(key) {
    if (key === 'stop' || key === 'hold') return 'reject';
    if (key === 'reduce') return 'adjust';
    if (key === 'continue') return 'followup';
    return 'recommend';
}
function mabCommonPayload() {
    var sel = document.getElementById('mabPharmacist');
    var opt = sel.options[sel.selectedIndex];
    var modeEl = document.querySelector('input[name="mabCloseMode"]:checked');
    var note = mabComposeNote();
    var outcome = mabSelectedOutcome();
    var labels = mabOutcomeLabels();
    return {
        pharmacist_user_id: sel.value,
        pharmacist_name: opt ? opt.text.replace(/\s*\([^)]*\)\s*$/, '').trim() : '',
        consult_note: note,
        doctor_reply: note,
        reply_wait_days: document.getElementById('mabReplyWait').value,
        continue_days: document.getElementById('mabContinueDays').value,
        days_value: document.getElementById('mabContinueDays').value,
        close_mode: modeEl ? modeEl.value : 'more_days',
        intervention_type: mabOutcomeInterventionType(outcome),
        deviation_category: (document.getElementById('mabIvDeviation') || {}).value || '',
        mute_visit: (window.AlertMute && AlertMute.checked('mabIvDeviation')) ? 1 : 0,
        note_text: String((document.getElementById('mabConsultNote') || {}).value || '').trim(),
        consult_result: (outcome && labels[outcome]) ? labels[outcome] : '',
        cases_json: JSON.stringify(mabCasesPayloadList())
    };
}
function mabShowMsg(ok, text) {
    var el = document.getElementById('mabConsultMsg');
    el.className = 'alert mt-3 mb-0 py-2 small ' + (ok ? 'alert-success' : 'alert-danger');
    el.textContent = text || '';
}
function mabPostConsult(action) {
    var cases = mabSelectedCases();
    if (!cases.length) {
        return Promise.resolve({ status: 'error', message: 'กรุณาเลือกอย่างน้อย 1 รายการยา' });
    }
    var data = Object.assign(mabCommonPayload(), { action: action });
    var body = new URLSearchParams();
    Object.keys(data).forEach(function(k) { body.append(k, data[k] == null ? '' : data[k]); });
    return fetch('fetch_monitor_antibiotic_consult_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString()
    }).then(function(r) { return r.json(); });
}
function mabSaveIntervention(andPrint) {
    var printWin = null;
    if (andPrint) printWin = window.open('about:blank', '_blank');
    mabPostConsult('start').then(function(res) {
        if (res.status !== 'success') {
            if (printWin) printWin.close();
            mabShowMsg(false, res.message || 'บันทึกไม่สำเร็จ');
            return;
        }
        mabShowMsg(true, andPrint ? 'บันทึก Intervention และเปิดใบปรึกษาแล้ว' : 'บันทึก Intervention แล้ว');
        if (andPrint && res.print_url && printWin) {
            printWin.location = res.print_url + (res.print_url.indexOf('?') >= 0 ? '&' : '?') + 'autoprint=1';
        } else if (printWin) {
            printWin.close();
        }
        fetchMabData();
    }).catch(function(e) {
        if (printWin) printWin.close();
        mabShowMsg(false, String(e));
    });
}
function mabStartAndPrint() {
    mabSaveIntervention(true);
}
function mabCloseConsult() {
    var days = parseInt(document.getElementById('mabContinueDays').value, 10);
    var modeEl = document.querySelector('input[name="mabCloseMode"]:checked');
    var mode = modeEl ? modeEl.value : 'more_days';
    if (!days || days < 1) {
        mabShowMsg(false, mode === 'total_days' ? 'กรุณาระบุจำนวนวันใช้ยาทั้งหมด' : 'กรุณาระบุจำนวนวันจนถึง plan off');
        return;
    }
    var n = mabSelectedCases().length;
    if (!n) { mabShowMsg(false, 'กรุณาเลือกอย่างน้อย 1 รายการยา'); return; }
    var confirmMsg = mode === 'total_days'
        ? ('ปิด Consult ' + n + ' รายการ โดยใช้ยารวม ' + days + ' วัน (นับจากวันเริ่ม)?')
        : ('ปิด Consult ' + n + ' รายการ โดย plan off ในอีก ' + days + ' วัน?');
    if (!confirm(confirmMsg)) return;
    mabPostConsult('close').then(function(res) {
        mabShowMsg(res.status === 'success', res.message || '');
        if (res.status === 'success') fetchMabData();
    }).catch(function(e) { mabShowMsg(false, String(e)); });
}
function mabSaveResult() {
    if (!mabSelectedOutcome()) {
        mabShowMsg(false, 'กรุณาเลือกผลการปรึกษา');
        return;
    }
    if (mabSelectedOutcome() === 'other' && !String(document.getElementById('mabConsultNote').value || '').trim()) {
        mabShowMsg(false, 'กรุณาระบุรายละเอียดในช่อง อื่นๆ');
        return;
    }
    mabPostConsult('save_result').then(function(res) {
        mabShowMsg(res.status === 'success', res.message || '');
        if (res.status === 'success') fetchMabData();
    }).catch(function(e) { mabShowMsg(false, String(e)); });
}
function mabResetWaiting() {
    var n = mabSelectedCases().length;
    if (!n) { mabShowMsg(false, 'กรุณาเลือกอย่างน้อย 1 รายการยา'); return; }
    mabPostConsult('reset_waiting').then(function(res) {
        mabShowMsg(res.status === 'success', res.message || '');
        if (res.status === 'success') fetchMabData();
    }).catch(function(e) { mabShowMsg(false, String(e)); });
}
var mabHistEditId = 0;
var mabHistDelId = 0;
function mabRenderHistory(rows) {
    var tbody = document.getElementById('mabHistoryBody');
    window._mabHistoryRows = rows || [];
    if (!rows || !rows.length) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted py-3">ยังไม่มีประวัติ</td></tr>';
        return;
    }
    var html = '';
    rows.forEach(function(h, idx) {
        var dayInfo = '-';
        if (h.close_mode === 'total_days' && h.planned_total_days) {
            dayInfo = 'รวม ' + h.planned_total_days + ' วัน';
            if (h.plan_off_date) dayInfo += '<br><span class="text-muted">off ' + escHtml(h.plan_off_date) + '</span>';
        } else if (h.continue_days) {
            dayInfo = '+' + h.continue_days + ' วัน';
            if (h.plan_off_date) dayInfo += '<br><span class="text-muted">off ' + escHtml(h.plan_off_date) + '</span>';
        } else if (h.reply_due_at) {
            dayInfo = 'ตอบภายใน<br><span class="text-muted">' + escHtml(h.reply_due_at) + '</span>';
        }
        var note = [];
        if (h.note_text) note.push(escHtml(h.note_text));
        if (h.doctor_reply && h.doctor_reply !== h.note_text) note.push(escHtml(h.doctor_reply));
        html += '<tr>'
            + '<td class="small text-nowrap">' + escHtml(h.created_at) + '</td>'
            + '<td class="small">' + escHtml(h.drug_name) + '</td>'
            + '<td class="small fw-bold">' + escHtml(h.action_label || h.action_key) + '</td>'
            + '<td class="small">' + escHtml(h.status_before_label || h.status_before || '-')
            + ' → ' + escHtml(h.status_after_label || h.status_after || '-') + '</td>'
            + '<td class="small">' + dayInfo + '</td>'
            + '<td class="small">' + escHtml(h.actor_name || h.pharmacist_name || '-') + '</td>'
            + '<td class="small">' + (note.length ? note.join('<br>') : '-') + '</td>'
            + '<td class="text-center text-nowrap">'
            + '<button type="button" class="btn btn-sm btn-outline-primary me-1" title="แก้ไข" onclick="mabOpenHistEdit(' + idx + ')">'
            + '<i class="fas fa-pen"></i></button>'
            + '<button type="button" class="btn btn-sm btn-outline-danger" title="ลบ" onclick="mabOpenHistDelete(' + idx + ')">'
            + '<i class="fas fa-trash-alt"></i></button>'
            + '</td>'
            + '</tr>';
    });
    tbody.innerHTML = html;
}
function mabOpenHistoryFromRow(idx) {
    var it = (window._mabItems || [])[idx];
    if (!it) return;
    mabCurrentCase = it;
    mabHnCases = (window._mabItems || []).filter(function(x) {
        return String(x.hn || '') === String(it.hn || '') && String(x.an || '') === String(it.an || '');
    });
    mabOpenHistory();
}
function mabReloadHistory() {
    var it = mabCurrentCase || (mabHnCases && mabHnCases[0]) || null;
    if (!it) return Promise.resolve();
    var params = new URLSearchParams({
        action: 'history',
        hn: it.hn || '',
        an: it.an || '',
        limit: '150'
    });
    return fetch('fetch_monitor_antibiotic_consult_api.php?' + params.toString(), { credentials: 'same-origin' })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            mabRenderHistory(res.history || []);
        });
}
function mabOpenHistory() {
    var it = mabCurrentCase || (mabHnCases && mabHnCases[0]) || null;
    if (!it) {
        alert('ไม่พบข้อมูลผู้ป่วย');
        return;
    }
    document.getElementById('mabHistoryInfo').innerHTML =
        '<b>HN ' + escHtml(it.hn) + '</b> · ' + escHtml(it.ptname) + ' · AN ' + escHtml(it.an);
    mabReloadHistory()
        .then(function() {
            var modalEl = document.getElementById('mabHistoryModal');
            var histModal = bootstrap.Modal.getOrCreateInstance(modalEl);
            histModal.show();
        })
        .catch(function(e) { alert('โหลดประวัติไม่สำเร็จ: ' + e); });
}
function mabOpenHistEdit(idx) {
    var h = (window._mabHistoryRows || [])[idx];
    if (!h || !h.id) return;
    mabHistEditId = parseInt(h.id, 10) || 0;
    document.getElementById('mabHistEditId').value = mabHistEditId;
    document.getElementById('mabHistEditDrug').value = h.drug_name || '';
    document.getElementById('mabHistEditAction').value = h.action_label || h.action_key || '';
    document.getElementById('mabHistEditActor').value = h.actor_name || h.pharmacist_name || '';
    document.getElementById('mabHistEditContinue').value = (h.continue_days != null && h.continue_days !== '') ? h.continue_days : '';
    document.getElementById('mabHistEditPlanned').value = (h.planned_total_days != null && h.planned_total_days !== '') ? h.planned_total_days : '';
    document.getElementById('mabHistEditPlanOff').value = h.plan_off_date ? String(h.plan_off_date).substring(0, 10) : '';
    document.getElementById('mabHistEditReplyDue').value = h.reply_due_at || '';
    document.getElementById('mabHistEditNote').value = h.note_text || '';
    document.getElementById('mabHistEditReply').value = h.doctor_reply || '';
    bootstrap.Modal.getOrCreateInstance(document.getElementById('mabHistEditModal')).show();
}
function mabSaveHistEdit() {
    if (!mabHistEditId) return;
    var fd = new FormData();
    fd.append('action', 'history_update');
    fd.append('id', String(mabHistEditId));
    fd.append('drug_name', document.getElementById('mabHistEditDrug').value);
    fd.append('action_label', document.getElementById('mabHistEditAction').value);
    fd.append('actor_name', document.getElementById('mabHistEditActor').value);
    fd.append('continue_days', document.getElementById('mabHistEditContinue').value);
    fd.append('planned_total_days', document.getElementById('mabHistEditPlanned').value);
    fd.append('plan_off_date', document.getElementById('mabHistEditPlanOff').value);
    fd.append('reply_due_at', document.getElementById('mabHistEditReplyDue').value);
    fd.append('note_text', document.getElementById('mabHistEditNote').value);
    fd.append('doctor_reply', document.getElementById('mabHistEditReply').value);
    fetch('fetch_monitor_antibiotic_consult_api.php', {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
    })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            if (res.status !== 'success') {
                alert(res.message || 'บันทึกไม่สำเร็จ');
                return;
            }
            bootstrap.Modal.getInstance(document.getElementById('mabHistEditModal')).hide();
            mabReloadHistory().catch(function() {});
        })
        .catch(function(e) { alert('บันทึกไม่สำเร็จ: ' + e); });
}
function mabOpenHistDelete(idx) {
    var h = (window._mabHistoryRows || [])[idx];
    if (!h || !h.id) return;
    mabHistDelId = parseInt(h.id, 10) || 0;
    document.getElementById('mabHistDelId').value = mabHistDelId;
    document.getElementById('mabHistDelConfirm').value = '';
    document.getElementById('mabHistDelBtn').disabled = true;
    var label = (h.action_label || h.action_key || '') + (h.drug_name ? (' · ' + h.drug_name) : '');
    document.getElementById('mabHistDelHint').textContent =
        'ยืนยันลบประวัตินี้' + (label ? (' (' + label + ')') : '') + ' — การลบย้อนกลับไม่ได้';
    bootstrap.Modal.getOrCreateInstance(document.getElementById('mabHistDelModal')).show();
    setTimeout(function() {
        var inp = document.getElementById('mabHistDelConfirm');
        if (inp) inp.focus();
    }, 200);
}
function mabDoHistDelete() {
    var typed = String(document.getElementById('mabHistDelConfirm').value || '').trim();
    if (typed !== 'delete' || !mabHistDelId) return;
    var fd = new FormData();
    fd.append('action', 'history_delete');
    fd.append('id', String(mabHistDelId));
    fd.append('confirm', 'delete');
    fetch('fetch_monitor_antibiotic_consult_api.php', {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
    })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            if (res.status !== 'success') {
                alert(res.message || 'ลบไม่สำเร็จ');
                return;
            }
            bootstrap.Modal.getInstance(document.getElementById('mabHistDelModal')).hide();
            mabReloadHistory().catch(function() {});
        })
        .catch(function(e) { alert('ลบไม่สำเร็จ: ' + e); });
}
document.addEventListener('input', function(e) {
    if (e.target && e.target.id === 'mabHistDelConfirm') {
        document.getElementById('mabHistDelBtn').disabled =
            String(e.target.value || '').trim() !== 'delete';
    }
});
function fetchMabData() {
    var loading = document.getElementById('mabLoading');
    var errBox = document.getElementById('mabError');
    var dash = document.getElementById('mabDashboard');
    var disabled = document.getElementById('mabDisabled');
    var btn = document.getElementById('btnFetchMab');
    loading.classList.remove('d-none');
    errBox.classList.add('d-none');
    dash.classList.add('d-none');
    disabled.classList.add('d-none');
    btn.disabled = true;
    fetch('fetch_monitor_antibiotic_api.php' + (function() {
        var qs = new URLSearchParams();
        if (typeof monitorAppendHn === 'function') monitorAppendHn(qs);
        var s = qs.toString();
        return s ? ('?' + s) : '';
    })(), { credentials: 'same-origin' })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            loading.classList.add('d-none');
            btn.disabled = false;
            if (data.status !== 'success') {
                errBox.textContent = data.message || 'โหลดข้อมูลไม่สำเร็จ';
                errBox.classList.remove('d-none');
                return;
            }
            if (data.meta && data.meta.disabled) {
                disabled.classList.remove('d-none');
                return;
            }
            var summary = data.summary || {};
            document.getElementById('totalCases').textContent = summary.total_cases || 0;
            document.getElementById('totalPatients').textContent = summary.total_patients || 0;
            var st = summary.consult_status || {};
            document.getElementById('stWaiting').textContent = st.waiting || 0;
            document.getElementById('stProgress').textContent = st.in_progress || 0;
            document.getElementById('stClosed').textContent = st.closed || 0;
            renderWardChart(summary.ward_summary || []);
            renderTable(data.items || []);
            dash.classList.remove('d-none');
        })
        .catch(function(e) {
            loading.classList.add('d-none');
            btn.disabled = false;
            errBox.textContent = 'เกิดข้อผิดพลาด: ' + e;
            errBox.classList.remove('d-none');
        });
}
document.addEventListener('DOMContentLoaded', function() {
    if (typeof monitorInitHnFilter === 'function') {
        monitorInitHnFilter({
            clearHref: 'monitor_antibiotic.php',
            fetchFn: fetchMabData
        });
    }
    fetchMabData();
});
</script>
<?php endif; ?>
</body>
</html>
