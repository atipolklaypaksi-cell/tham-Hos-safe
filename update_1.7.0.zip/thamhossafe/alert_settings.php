<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/tham_alert_helper.php';

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.alert_pipelines') && !tham_menu_can('admin.hosxp') && !tham_menu_can('admin.hosxp_master') && ($_SESSION['role'] ?? '') !== 'admin') {
    echo "<script>alert('คุณไม่มีสิทธิ์เข้าหน้าตั้งค่า Alert pipelines'); window.location='home.php';</script>";
    exit;
}

tham_alert_ensure_tables($con);
$cfg = tham_alert_config($con);
$pipes = tham_alert_pipelines();
$h = function ($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
};
$host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
$base = rtrim(dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/thamhossafe')), '/');
$cron_url = 'http://' . $host . $base . '/cron_tham_alert.php?key=' . rawurlencode((string)$cfg['cron_secret']);
$poll_url = 'http://' . $host . $base . '/fetch_tham_alert_api.php';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alert pipelines - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/select2.min.css" rel="stylesheet">
    <link href="css/select2-bootstrap-5-theme.min.css" rel="stylesheet">
    <style>
        .ta-hero {
            background: linear-gradient(135deg, #0f766e 0%, #1d4ed8 55%, #4f46e5 100%);
            color: #fff; border-radius: 12px; padding: 1.15rem 1.4rem;
        }
        .ta-switch { border: 1px solid #e2e8f0; border-radius: 10px; padding: .85rem 1rem; height: 100%; }
        .form-check-input:checked { background-color: #0f766e; border-color: #0f766e; }
        code.ta-url { font-size: .78rem; word-break: break-all; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="ta-hero mb-4">
                <div class="small opacity-75 mb-1"><i class="fas fa-bell me-1"></i>ตั้งค่าระบบ</div>
                <h4 class="fw-bold mb-1">Alert pipelines</h4>
                <small>เปิด/ปิดแต่ละช่องได้เอง — Master ใช้ดูว่ากำลังคีย์ยาเสี่ยง, Slave ใช้ชื่อผู้ป่วยและ Lab ย้อนหลัง</small>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="fw-bold mb-1"><i class="fas fa-network-wired me-1 text-success"></i> Slave (ประมวลผลความปลอดภัย)</div>
                            <div class="small text-muted mb-2">ตั้งที่ <a href="hosxp_setting.php">เชื่อมต่อ HOSxP</a> — ชื่อผู้ป่วย, ผลแล็บ, ตรวจ icode ในใบยา</div>
                            <?php if (!empty($cfg['slave_ok'])): ?>
                                <span class="badge bg-success">ตั้งค่าแล้ว</span>
                            <?php else: ?>
                                <span class="badge bg-danger">ยังไม่ตั้งค่า</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="fw-bold mb-1"><i class="fas fa-database me-1 text-warning"></i> Master (กำลังคีย์)</div>
                            <div class="small text-muted mb-2">ตั้งที่ <a href="hosxp_master_setting.php">เชื่อมต่อ HOSxP master</a> — คิวรีเบา icode + ช่วงวินาทีล่าสุด ห้าม JOIN ยา</div>
                            <?php if (!empty($cfg['master_ok'])): ?>
                                <span class="badge bg-success">ตั้งค่าแล้ว</span>
                            <?php else: ?>
                                <span class="badge bg-danger">ยังไม่ตั้งค่า</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <form id="pipeForm" class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-3"><i class="fas fa-toggle-on me-2 text-primary"></i>เปิด / ปิด pipeline</h6>
                    <div class="row g-3 mb-3">
                        <?php foreach ($pipes as $key => $meta): ?>
                        <div class="col-md-6">
                            <div class="ta-switch">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="pipe_<?= $h($key) ?>" name="<?= $h($key) ?>" <?= !empty($cfg[$key]) ? 'checked' : '' ?>>
                                    <label class="form-check-label fw-bold" for="pipe_<?= $h($key) ?>"><?= $h($meta['label']) ?></label>
                                </div>
                                <div class="small text-muted mt-1"><?= $h($meta['hint']) ?></div>
                                <span class="badge bg-light text-dark mt-2"><?= $meta['source'] === 'master' ? 'Master → Slave' : 'เว็บ THAM' ?></span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="row g-3 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label fw-bold small">ย้อนหลัง (วินาที)</label>
                            <input type="number" min="3" max="60" class="form-control" name="lookback_sec" value="<?= (int)$cfg['lookback_sec'] ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold small">ช่วง poll ใน cron (วินาที)</label>
                            <input type="number" min="2" max="15" class="form-control" name="poll_sec" value="<?= (int)$cfg['poll_sec'] ?>">
                        </div>
                        <div class="col-md-3">
                            <div class="form-check form-switch mt-4">
                                <input class="form-check-input" type="checkbox" id="lab_hint" name="lab_hint" <?= !empty($cfg['lab_hint']) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="lab_hint">ดึง Cr/eGFR จาก Slave ตอนเตือน</label>
                            </div>
                        </div>
                        <div class="col-md-3 text-end">
                            <button type="submit" class="btn btn-primary" id="btnSave"><i class="fas fa-save me-1"></i>บันทึก</button>
                            <button type="button" class="btn btn-outline-success" id="btnTick"><i class="fas fa-play me-1"></i>ทดสอบตรวจ</button>
                        </div>
                    </div>
                    <div id="saveMsg" class="small mt-2"></div>
                    <div class="form-check form-switch mt-3">
                        <input class="form-check-input" type="checkbox" id="lan_auto" name="lan_auto" <?= !empty($cfg['lan_auto']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="lan_auto">เมื่อ Login เว็บ ให้ชวนไปหน้าดาวน์โหลด THAM Notify (เปิดเองแบบ SCPH Notify ไม่ยิงไฟล์ติดตั้งเงียบ)</label>
                    </div>
                    <div class="small text-muted mt-1">ค่าเริ่มต้นปิด — เปิดได้ที่หน้า <a href="alert_agent_machines.php">เครื่อง Alert Agent</a> เมื่อต้องการให้เด้งหน้าต่างติดตั้งตอน Login</div>
                </div>
            </form>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-2"><i class="fas fa-pills me-2 text-danger"></i>ยาเสี่ยงที่ให้ดักบน Master</h6>
                    <p class="small text-muted">ค้นจาก HOSxP Slave แล้วเก็บ icode ใน THAM — Master จะถามแค่ <code>icode IN (...)</code> ไม่ JOIN ตารางยา</p>
                    <div class="row g-2 align-items-end mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">ค้นหายา HOSxP</label>
                            <select id="drugSelect" class="form-select"></select>
                        </div>
                        <div class="col-md-4">
                            <div class="d-flex gap-3">
                                <div class="form-check"><input class="form-check-input" type="checkbox" id="add_doc" checked><label class="form-check-label small" for="add_doc">Doctor</label></div>
                                <div class="form-check"><input class="form-check-input" type="checkbox" id="add_popd" checked><label class="form-check-label small" for="add_popd">Phar OPD</label></div>
                                <div class="form-check"><input class="form-check-input" type="checkbox" id="add_pipd" checked><label class="form-check-label small" for="add_pipd">Phar IPD</label></div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-success w-100" id="btnAddDrug"><i class="fas fa-plus me-1"></i>เพิ่ม</button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>icode</th>
                                    <th>ชื่อยา</th>
                                    <th class="text-center">Doctor</th>
                                    <th class="text-center">Phar OPD</th>
                                    <th class="text-center">Phar IPD</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="drugBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-2"><i class="fas fa-history me-2"></i>เหตุการณ์ล่าสุด</h6>
                    <div id="tickMsg" class="small text-muted mb-2"></div>
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>เวลา</th>
                                    <th>pipeline</th>
                                    <th>เครื่อง</th>
                                    <th>ข้อความ</th>
                                </tr>
                            </thead>
                            <tbody id="recentBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-2"><i class="fas fa-clock me-2"></i>Cron และ Agent</h6>
                    <div class="small text-muted mb-1">ตั้ง cron ทุก 1 นาที:</div>
                    <code class="ta-url d-block mb-2">* * * * * curl -sS '<?= $h($cron_url) ?>' >/dev/null 2>&1</code>
                    <div class="small text-muted mb-1">Agent poll:</div>
                    <code class="ta-url d-block"><?= $h($poll_url) ?>?action=pending&amp;pipeline=doctor&amp;station_id=PCNAME&amp;key=SECRET</code>
                    <div class="small mt-2">เครื่องที่ติดตั้งแล้ว: <strong id="agentSummary">กำลังโหลด...</strong>
                        · <a href="alert_agent_machines.php">ตั้งค่าระบบ → เครื่อง Alert Agent</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/select2.min.js"></script>
<script>
function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function api(action, data, method) {
    method = method || (data ? 'POST' : 'GET');
    const opt = { method: method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' } };
    if (method === 'POST') {
        opt.body = JSON.stringify(Object.assign({ action: action }, data || {}));
        return fetch('fetch_tham_alert_api.php', opt).then(function (r) { return r.json(); });
    }
    return fetch('fetch_tham_alert_api.php?action=' + encodeURIComponent(action), { credentials: 'same-origin' })
        .then(function (r) { return r.json(); });
}
function yn(v) { return Number(v) === 1 ? '✓' : '—'; }
function renderDrugs(rows) {
    const body = document.getElementById('drugBody');
    if (!rows || !rows.length) {
        body.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-3">ยังไม่มีรายการยาเสี่ยง</td></tr>';
        return;
    }
    body.innerHTML = rows.map(function (r) {
        return '<tr>' +
            '<td><code>' + esc(r.icode) + '</code></td>' +
            '<td>' + esc(r.drug_name) + '</td>' +
            '<td class="text-center">' + yn(r.use_doctor) + '</td>' +
            '<td class="text-center">' + yn(r.use_phar_opd) + '</td>' +
            '<td class="text-center">' + yn(r.use_phar_ipd) + '</td>' +
            '<td class="text-end"><button type="button" class="btn btn-outline-danger btn-sm py-0 px-2 btn-del" data-id="' + r.id + '">ลบ</button></td>' +
            '</tr>';
    }).join('');
}
function renderRecent(rows) {
    const body = document.getElementById('recentBody');
    if (!rows || !rows.length) {
        body.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-3">ยังไม่มีเหตุการณ์</td></tr>';
        return;
    }
    body.innerHTML = rows.map(function (r) {
        return '<tr>' +
            '<td class="small">' + esc(r.created_at) + '</td>' +
            '<td><span class="badge bg-secondary">' + esc(r.pipeline) + '</span></td>' +
            '<td class="small">' + esc(r.computername || r.station_id || '') + '</td>' +
            '<td class="small">' + esc(r.message || r.title) + '</td>' +
            '</tr>';
    }).join('');
}
function loadAll() {
    api('get').then(function (data) {
        if (data.status !== 'success') return;
        renderDrugs(data.drugs);
        renderRecent(data.recent);
        const ag = data.agents || [];
        const on = ag.filter(function (r) { return r.online; }).length;
        const sum = document.getElementById('agentSummary');
        if (sum) sum.textContent = on + ' ออนไลน์ จาก ' + ag.length + ' เครื่อง';
    });
}
jQuery('#drugSelect').select2({
    theme: 'bootstrap-5',
    width: '100%',
    placeholder: 'พิมพ์ชื่อยาหรือ icode...',
    allowClear: true,
    minimumInputLength: 1,
    ajax: {
        url: 'fetch_hosxp_drugs_select_api.php',
        dataType: 'json',
        delay: 250,
        data: function (params) { return { q: params.term }; },
        processResults: function (data) { return { results: data.results || [] }; }
    }
});
document.getElementById('pipeForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const btn = document.getElementById('btnSave');
    btn.disabled = true;
    const payload = {
        ward: document.getElementById('pipe_ward').checked ? 1 : 0,
        doctor: document.getElementById('pipe_doctor').checked ? 1 : 0,
        phar_opd: document.getElementById('pipe_phar_opd').checked ? 1 : 0,
        phar_ipd: document.getElementById('pipe_phar_ipd').checked ? 1 : 0,
        lan_auto: document.getElementById('lan_auto').checked ? 1 : 0,
        lookback_sec: document.querySelector('[name="lookback_sec"]').value,
        poll_sec: document.querySelector('[name="poll_sec"]').value
    };
    api('save', payload).then(function (data) {
        btn.disabled = false;
        document.getElementById('saveMsg').textContent = data.status === 'success' ? 'บันทึกแล้ว' : (data.message || 'ไม่สำเร็จ');
        document.getElementById('saveMsg').className = 'small mt-2 ' + (data.status === 'success' ? 'text-success' : 'text-danger');
    }).catch(function () {
        btn.disabled = false;
        document.getElementById('saveMsg').textContent = 'เชื่อมต่อไม่สำเร็จ';
    });
});
document.getElementById('btnAddDrug').addEventListener('click', function () {
    const sel = jQuery('#drugSelect').select2('data')[0];
    if (!sel || !sel.id) { alert('กรุณาเลือกยา'); return; }
    const parts = String(sel.id).split('|');
    const btn = this;
    btn.disabled = true;
    api('add_drug', {
        icode: parts[0],
        drug_name: sel.text || parts[1] || '',
        use_doctor: document.getElementById('add_doc').checked ? 1 : 0,
        use_phar_opd: document.getElementById('add_popd').checked ? 1 : 0,
        use_phar_ipd: document.getElementById('add_pipd').checked ? 1 : 0
    }).then(function (data) {
        btn.disabled = false;
        if (data.status !== 'success') { alert(data.message || 'เพิ่มไม่สำเร็จ'); return; }
        jQuery('#drugSelect').val(null).trigger('change');
        renderDrugs(data.drugs);
    }).catch(function () { btn.disabled = false; alert('เชื่อมต่อไม่สำเร็จ'); });
});
document.getElementById('drugBody').addEventListener('click', function (e) {
    const btn = e.target.closest('.btn-del');
    if (!btn) return;
    if (!confirm('ลบยานี้จากรายการดัก?')) return;
    api('delete_drug', { id: Number(btn.dataset.id) }).then(function (data) {
        renderDrugs(data.drugs);
    });
});
document.getElementById('btnTick').addEventListener('click', function () {
    const btn = this;
    btn.disabled = true;
    api('tick').then(function (data) {
        btn.disabled = false;
        const t = data.tick || {};
        const parts = ['doctor', 'phar_opd', 'phar_ipd'].map(function (k) {
            const p = t[k] || {};
            if (!p.on) return k + ': ปิด';
            return k + ': พบ ' + (p.found || 0) + ' คิวใหม่ ' + (p.queued || 0) + (p.error ? ' (' + p.error + ')' : '');
        });
        if (t.slave_error) parts.push(t.slave_error);
        document.getElementById('tickMsg').textContent = parts.join(' · ');
        renderRecent(data.recent);
    }).catch(function () {
        btn.disabled = false;
        document.getElementById('tickMsg').textContent = 'ทดสอบไม่สำเร็จ';
    });
});
loadAll();
</script>
</body>
</html>
