<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตั้งค่ารายการยาเรื้อรัง - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        .sdc-hero {
            background: linear-gradient(135deg, #14532d 0%, #198754 70%);
            color: #fff; border-radius: 12px; padding: 1.1rem 1.3rem;
        }
        .sdc-list { max-height: 560px; overflow: auto; }
        .sdc-item, .sdc-hit, .sdc-group {
            display: flex; align-items: center; gap: 8px;
            padding: 8px 10px; border-bottom: 1px solid #e9ecef;
        }
        .sdc-item:last-child, .sdc-hit:last-child, .sdc-group:last-child { border-bottom: 0; }
        .sdc-code { font-family: ui-monospace, monospace; font-size: 0.78rem; color: #495057; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="sdc-hero mb-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <div class="small opacity-75 mb-1">Smart Drug · Medication Reconciliation</div>
                    <h4 class="fw-bold mb-1">ตั้งค่ารายการยาเรื้อรัง</h4>
                    <div class="small">ยาเรื้อรังคือยาที่ HOSxP ติ๊กใช้ต่อเนื่อง หรือยาที่อยู่ในรายการนี้ อย่างใดอย่างหนึ่ง รายการนี้ใช้รหัส TMT ร่วมกันทุกโรงพยาบาล</div>
                </div>
                <a href="smart_drug.php" class="btn btn-light btn-sm fw-bold">กลับ Smart Drug</a>
            </div>

            <div class="row g-3">
                <div class="col-lg-5">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h6 class="fw-bold mb-2">เพิ่มรายการ</h6>
                            <label class="form-label small fw-bold mb-1">กลุ่มโรค</label>
                            <select id="sdcAddGroup" class="form-select form-select-sm mb-1"></select>
                            <input type="text" id="sdcAddGroupNew" class="form-control form-control-sm mb-2" placeholder="พิมพ์ชื่อกลุ่มโรคใหม่" style="display:none" autocomplete="off">
                            <div class="input-group mb-2">
                                <input type="text" id="sdcQ" class="form-control" placeholder="ชื่อยา หรือรหัส TMT" autocomplete="off">
                                <button class="btn btn-success" id="sdcSearch" type="button">ค้นหา</button>
                            </div>
                            <div id="sdcHits" class="border rounded sdc-list bg-white">
                                <div class="p-3 text-muted small">ค้นจากรายการยาของรพร.สระแก้ว แล้วเพิ่มด้วยรหัส TMT</div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow-sm border-0 mt-3">
                        <div class="card-body">
                            <h6 class="fw-bold mb-1">นำเข้าทั้งกลุ่มโรค</h6>
                            <p class="small text-muted mb-2">กลุ่ม ICD10 จากรพร.สระแก้ว ค่าเริ่มต้นนำเข้าแล้วเฉพาะเบาหวาน ไขมัน และความดัน กลุ่มอื่นกดเพิ่มเองได้</p>
                            <div id="sdcGroups" class="border rounded sdc-list bg-white">
                                <div class="p-3 text-muted small">กำลังโหลดกลุ่มโรค...</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="fw-bold mb-0">รายการที่ใช้อยู่ <span class="text-muted fw-normal" id="sdcCount"></span></h6>
                                <input type="text" id="sdcFilter" class="form-control form-control-sm" style="max-width:220px" placeholder="กรองรายการ">
                            </div>
                            <div id="sdcItems" class="border rounded sdc-list bg-white">
                                <div class="p-3 text-muted small">กำลังโหลด...</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
var sdcItems = [];
var sdcGroups = [];

function sdcEsc(s) {
    return String(s || '').replace(/[&<>"']/g, function (c) {
        return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];
    });
}

function sdcPost(body) {
    return fetch('fetch_smart_drug_chronic_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(body)
    }).then(function (r) { return r.json(); });
}

function sdcGroupNames() {
    var seen = {};
    var names = [];
    function add(n) {
        n = String(n || '').trim();
        if (!n || seen[n]) return;
        seen[n] = true;
        names.push(n);
    }
    (sdcGroups || []).forEach(function (g) { add(g.name); });
    (sdcItems || []).forEach(function (it) { add(it.source_label); });
    names.sort(function (a, b) { return a.localeCompare(b, 'th'); });
    return names;
}

function sdcGroupOptions(selected) {
    var names = sdcGroupNames();
    var html = '<option value="">เลือกกลุ่มโรค</option>';
    names.forEach(function (n) {
        html += '<option value="' + sdcEsc(n) + '"' + (n === selected ? ' selected' : '') + '>' + sdcEsc(n) + '</option>';
    });
    html += '<option value="__new__">กลุ่มโรคใหม่...</option>';
    return html;
}

function sdcFillAddGroup() {
    var sel = document.getElementById('sdcAddGroup');
    if (!sel) return;
    var current = sel.value;
    sel.innerHTML = sdcGroupOptions(current);
    if (current && sel.value !== current) sel.value = current;
}

function sdcChosenGroup(selectId, newInputId) {
    var sel = document.getElementById(selectId);
    var typed = document.getElementById(newInputId);
    if (sel && sel.value === '__new__') return String(typed && typed.value || '').trim();
    return String(sel && sel.value || '').trim();
}

function sdcRenderItems() {
    var q = String(document.getElementById('sdcFilter').value || '').trim().toLowerCase();
    var rows = sdcItems.filter(function (it) {
        if (!q) return true;
        return (it.drug_name + ' ' + it.tpu_code + ' ' + it.source_label).toLowerCase().indexOf(q) >= 0;
    });
    document.getElementById('sdcCount').textContent = '(' + sdcItems.length + ')';
    sdcFillAddGroup();
    if (!rows.length) {
        document.getElementById('sdcItems').innerHTML = '<div class="p-3 text-muted small">ไม่มีรายการ</div>';
        return;
    }
    document.getElementById('sdcItems').innerHTML = rows.map(function (it) {
        return '<div class="sdc-item">'
            + '<div class="flex-grow-1"><div class="fw-bold">' + sdcEsc(it.drug_name) + '</div>'
            + '<div class="sdc-code">' + sdcEsc(it.tpu_code) + '</div></div>'
            + '<select class="form-select form-select-sm" style="max-width:220px" data-set-group="' + it.id + '" data-current="' + sdcEsc(it.source_label) + '">'
            + sdcGroupOptions(it.source_label) + '</select>'
            + '<button type="button" class="btn btn-outline-danger btn-sm" data-del="' + it.id + '">ลบ</button>'
            + '</div>';
    }).join('');
}

function sdcRenderGroups() {
    if (!sdcGroups.length) {
        document.getElementById('sdcGroups').innerHTML = '<div class="p-3 text-muted small">ไม่พบกลุ่มโรค</div>';
        return;
    }
    document.getElementById('sdcGroups').innerHTML = sdcGroups.map(function (g) {
        var done = g.saved_count >= g.tpu_count && g.tpu_count > 0;
        return '<div class="sdc-group">'
            + '<div class="flex-grow-1"><div class="fw-bold">' + sdcEsc(g.name) + '</div>'
            + '<div class="small text-muted">' + g.saved_count + ' / ' + g.tpu_count + ' รหัส TMT</div></div>'
            + '<button type="button" class="btn btn-sm ' + (done ? 'btn-outline-secondary' : 'btn-success') + '" data-group="' + sdcEsc(g.name) + '">'
            + (done ? 'ครบแล้ว' : 'เพิ่มกลุ่ม') + '</button></div>';
    }).join('');
}

function sdcLoad() {
    sdcPost({action: 'list'}).then(function (data) {
        if (data.status !== 'success') {
            document.getElementById('sdcItems').innerHTML = '<div class="p-3 text-danger small">โหลดรายการไม่ได้</div>';
            return;
        }
        sdcItems = data.items || [];
        sdcGroups = data.groups || [];
        sdcRenderItems();
        sdcRenderGroups();
    }).catch(function () {
        document.getElementById('sdcItems').innerHTML = '<div class="p-3 text-danger small">เชื่อมต่อไม่สำเร็จ</div>';
    });
}

document.getElementById('sdcSearch').addEventListener('click', function () {
    var q = document.getElementById('sdcQ').value.trim();
    if (q.length < 2) return;
    document.getElementById('sdcHits').innerHTML = '<div class="p-3 text-muted small">กำลังค้นหา...</div>';
    sdcPost({action: 'search', q: q}).then(function (data) {
        var items = (data && data.items) || [];
        if (!items.length) {
            document.getElementById('sdcHits').innerHTML = '<div class="p-3 text-muted small">ไม่พบยาที่มีรหัส TMT</div>';
            return;
        }
        document.getElementById('sdcHits').innerHTML = items.map(function (it) {
            return '<div class="sdc-hit"><div class="flex-grow-1"><div class="fw-bold">' + sdcEsc(it.drug_name) + '</div>'
                + '<div class="sdc-code">' + sdcEsc(it.tpu_code) + (it.local_name ? ' · ' + sdcEsc(it.local_name) : '') + '</div></div>'
                + '<button type="button" class="btn btn-success btn-sm" data-add="' + sdcEsc(it.tpu_code) + '" data-name="' + sdcEsc(it.drug_name) + '">เพิ่ม</button></div>';
        }).join('');
    });
});
document.getElementById('sdcQ').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') document.getElementById('sdcSearch').click();
});
document.getElementById('sdcFilter').addEventListener('input', sdcRenderItems);

document.getElementById('sdcAddGroup').addEventListener('change', function () {
    document.getElementById('sdcAddGroupNew').style.display = this.value === '__new__' ? '' : 'none';
    if (this.value === '__new__') document.getElementById('sdcAddGroupNew').focus();
});

document.getElementById('sdcHits').addEventListener('click', function (e) {
    var btn = e.target.closest('[data-add]');
    if (!btn) return;
    var group = sdcChosenGroup('sdcAddGroup', 'sdcAddGroupNew');
    if (!group) {
        alert('กรุณาเลือกกลุ่มโรคก่อนเพิ่มรายการ');
        return;
    }
    btn.disabled = true;
    sdcPost({action: 'add', tpu_code: btn.getAttribute('data-add'), drug_name: btn.getAttribute('data-name'), source_label: group}).then(function (data) {
        btn.disabled = false;
        if (data.status !== 'success') {
            alert(data.message || 'เพิ่มไม่ได้');
            return;
        }
        sdcItems = data.items || [];
        sdcRenderItems();
        sdcLoad();
    });
});
function sdcSaveGroup(id, label, sel) {
    sdcPost({action: 'set_group', id: id, source_label: label}).then(function (data) {
        if (!data || data.status !== 'success') {
            alert((data && data.message) || 'บันทึกกลุ่มโรคไม่ได้');
            if (sel) sel.value = sel.getAttribute('data-current') || '';
            return;
        }
        sdcItems = data.items || [];
        sdcRenderItems();
    });
}

document.getElementById('sdcItems').addEventListener('change', function (e) {
    var sel = e.target.closest('[data-set-group]');
    if (!sel) return;
    var id = sel.getAttribute('data-set-group');
    if (sel.value === '__new__') {
        var box = document.createElement('input');
        box.type = 'text';
        box.className = 'form-control form-control-sm';
        box.placeholder = 'ชื่อกลุ่มโรคใหม่';
        box.style.maxWidth = '220px';
        sel.style.display = 'none';
        sel.parentNode.insertBefore(box, sel.nextSibling);
        box.focus();
        var done = false;
        function finish() {
            if (done) return;
            done = true;
            var name = box.value.trim();
            box.remove();
            sel.style.display = '';
            if (!name) {
                sel.value = sel.getAttribute('data-current') || '';
                return;
            }
            sdcSaveGroup(id, name, sel);
        }
        box.addEventListener('keydown', function (ev) {
            if (ev.key === 'Enter') finish();
            if (ev.key === 'Escape') { box.value = ''; finish(); }
        });
        box.addEventListener('blur', finish);
        return;
    }
    if (!sel.value || sel.value === sel.getAttribute('data-current')) return;
    sdcSaveGroup(id, sel.value, sel);
});

document.getElementById('sdcItems').addEventListener('click', function (e) {
    var btn = e.target.closest('[data-del]');
    if (!btn) return;
    btn.disabled = true;
    sdcPost({action: 'delete', id: btn.getAttribute('data-del')}).then(function (data) {
        if (data.status !== 'success') {
            btn.disabled = false;
            alert(data.message || 'ลบไม่ได้');
            return;
        }
        sdcItems = data.items || [];
        sdcRenderItems();
        sdcLoad();
    });
});
document.getElementById('sdcGroups').addEventListener('click', function (e) {
    var btn = e.target.closest('[data-group]');
    if (!btn) return;
    btn.disabled = true;
    sdcPost({action: 'import_group', property_name: btn.getAttribute('data-group')}).then(function (data) {
        btn.disabled = false;
        if (!data || data.status !== 'success') {
            alert((data && data.message) || 'นำเข้าไม่ได้');
            return;
        }
        sdcItems = data.items || [];
        sdcGroups = data.groups || [];
        sdcRenderItems();
        sdcRenderGroups();
    });
});
sdcLoad();
</script>
</body>
</html>
