<?php
/**
 * API เชื่อมต่อ / สำรวจฐานข้อมูลรพ. ต่างๆ (MySQL, Read Only)
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();
include(__DIR__ . '/connect.php');
require_once __DIR__ . '/hospital_ds_helper.php';
mysqli_set_charset($con, 'utf8');

function hds_api_json(array $payload, $code = 200) {
    ob_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    hds_api_json(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], 401);
}

require_once __DIR__ . '/menu_permissions_helper.php';
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.hospital_ds') && !tham_menu_can('admin.hosxp')) {
    hds_api_json(['status' => 'error', 'message' => 'ไม่มีสิทธิ์เชื่อมต่อรพ. ต่างๆ'], 403);
}
session_write_close();

hds_ensure_tables($con);
$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'list'));

if ($action === 'list') {
    $q = trim((string)($input['q'] ?? $_GET['q'] ?? ''));
    hds_api_json([
        'status' => 'success',
        'items' => hds_list($con, $q),
    ]);
}

if ($action === 'get') {
    $id = (int)($input['id'] ?? $_GET['id'] ?? 0);
    $row = hds_get($con, $id);
    if (!$row) {
        hds_api_json(['status' => 'error', 'message' => 'ไม่พบแหล่งข้อมูล'], 404);
    }
    hds_api_json(['status' => 'success', 'item' => hds_public_row($row)]);
}

if ($action === 'save') {
    $res = hds_save($con, $input);
    hds_api_json([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => !empty($res['ok'])
            ? (!empty($res['warning']) ? ('บันทึกใน THAM แล้ว แต่' . $res['warning']) : 'บันทึกการเชื่อมต่อแล้ว')
            : ($res['error'] ?? 'บันทึกไม่ได้'),
        'item' => $res['row'] ?? null,
    ], !empty($res['ok']) ? 200 : 400);
}

if ($action === 'delete') {
    $id = (int)($input['id'] ?? 0);
    if ($id < 1 || !hds_delete($con, $id)) {
        hds_api_json(['status' => 'error', 'message' => 'ลบไม่ได้'], 400);
    }
    hds_api_json(['status' => 'success', 'message' => 'ลบแหล่งข้อมูลแล้ว']);
}

if ($action === 'test') {
    $id = (int)($input['id'] ?? 0);
    $override = [];
    foreach (['host', 'port', 'dbname', 'username'] as $k) {
        if (isset($input[$k])) {
            $override[$k] = trim((string)$input[$k]);
        }
    }
    if (isset($input['password']) && (string)$input['password'] !== '' && (string)$input['password'] !== '********') {
        $override['password'] = (string)$input['password'];
    }
    $ping = hds_ping($con, $id, $override ?: null);
    $via = ($ping['via'] ?? '') === 'grafana' ? ' (ผ่าน Grafana)' : '';
    $row = hds_get($con, $id);
    hds_api_json([
        'status' => $ping['ok'] ? 'success' : 'error',
        'message' => $ping['ok']
            ? ('เชื่อมต่อสำเร็จ' . $via . ' · ตาราง ' . number_format((int)$ping['table_count']) . ' · ' . $ping['ms'] . ' ms')
            : ('เชื่อมต่อล้มเหลว: ' . ($ping['error'] ?: 'ไม่ทราบสาเหตุ')),
        'ping' => $ping,
        'item' => $row ? hds_public_row($row) : null,
        'grafana' => hds_grafana_public_config(hds_grafana_get_config($con)),
    ]);
}

if ($action === 'connect_mode_save') {
    $mode = hds_connect_mode_save($con, (string)($input['mode'] ?? 'direct'));
    $home = hds_home_code_save($con, (string)($input['home_code'] ?? hds_home_code($con)));
    hds_api_json([
        'status' => 'success',
        'message' => $mode === 'grafana'
            ? 'ตั้งให้ทุกโรงพยาบาลคิวรีผ่าน Grafana แล้ว'
            : ($mode === 'mysql'
                ? 'ตั้งให้ต่อ MySQL ตรงด้วยค่าที่บันทึกไว้แล้ว โรงพยาบาลที่ติดตั้งเว็บใช้ค่าจากเชื่อมต่อ HOSxP'
                : 'ตั้งให้ต่อตรงเฉพาะโรงพยาบาลที่ Host เป็น IP แล้ว โรงพยาบาลที่ติดตั้งเว็บใช้ค่าจากเชื่อมต่อ HOSxP'),
        'mode' => $mode,
        'home_code' => $home,
        'items' => hds_list($con, ''),
    ]);
}

if ($action === 'connect_via_save') {
    $res = hds_set_connect_via($con, (int)($input['id'] ?? 0), (string)($input['connect_via'] ?? 'auto'));
    hds_api_json([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => !empty($res['ok']) ? 'บันทึกช่องทางของโรงพยาบาลนี้แล้ว' : ($res['error'] ?? 'บันทึกไม่ได้'),
        'item' => $res['item'] ?? null,
    ], !empty($res['ok']) ? 200 : 400);
}

if ($action === 'grafana_get') {
    hds_api_json([
        'status' => 'success',
        'grafana' => hds_grafana_public_config(hds_grafana_get_config($con)),
    ]);
}

if ($action === 'grafana_save') {
    $cfg = hds_grafana_save_config($con, $input);
    hds_api_json([
        'status' => 'success',
        'message' => 'บันทึกการเชื่อม Grafana แล้ว',
        'grafana' => hds_grafana_public_config($cfg),
    ]);
}

if ($action === 'grafana_sync') {
    if (isset($input['url']) || isset($input['user']) || isset($input['pass'])) {
        hds_grafana_save_config($con, $input);
    }
    $sync = hds_grafana_sync($con);
    hds_api_json([
        'status' => !empty($sync['ok']) ? 'success' : 'error',
        'message' => !empty($sync['ok'])
            ? ('ซิงก์จาก Grafana แล้ว ' . (int)$sync['updated'] . ' รพ.')
            : ($sync['error'] ?? 'ซิงก์ไม่ได้'),
        'items' => hds_list($con, ''),
        'grafana' => hds_grafana_public_config(hds_grafana_get_config($con)),
    ], !empty($sync['ok']) ? 200 : 400);
}

if ($action === 'databases') {
    $id = (int)($input['id'] ?? $_GET['id'] ?? 0);
    $row = hds_get($con, $id);
    $dbn = trim((string)($row['dbname'] ?? 'hos'));
    $res = hds_explore_sql($con, $id, 'SELECT DATABASE() AS db');
    $dbs = [];
    if (!empty($res['rows'][0]['db'])) {
        $dbs[] = (string)$res['rows'][0]['db'];
    }
    if ($dbn !== '' && !in_array($dbn, $dbs, true)) {
        array_unshift($dbs, $dbn);
    }
    hds_api_json(['status' => empty($res['error']) || $dbs ? 'success' : 'error', 'message' => $res['error'] ?? '', 'databases' => $dbs ?: [$dbn]]);
}

if ($action === 'tables') {
    $id = (int)($input['id'] ?? $_GET['id'] ?? 0);
    $q = trim((string)($input['q'] ?? $_GET['q'] ?? ''));
    $q = str_replace(["'", '\\', "\0"], '', $q);
    $like = $q === '' ? '%' : ('%' . str_replace(['%', '_'], ['\\%', '\\_'], $q) . '%');
    $like_e = $like;
    $sql = "SELECT table_name AS t FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name LIKE '$like_e' ORDER BY table_name LIMIT 300";
    $res = hds_explore_sql($con, $id, $sql);
    $tables = [];
    foreach ($res['rows'] ?? [] as $r) {
        $name = (string)($r['t'] ?? reset($r));
        if ($name !== '') {
            $tables[] = $name;
        }
    }
    hds_api_json([
        'status' => empty($res['error']) ? 'success' : 'error',
        'message' => $res['error'] ?? '',
        'tables' => $tables,
        'via' => $res['via'] ?? '',
    ]);
}

if ($action === 'preview') {
    $id = (int)($input['id'] ?? $_GET['id'] ?? 0);
    $table = trim((string)($input['table'] ?? $_GET['table'] ?? ''));
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        hds_api_json(['status' => 'error', 'message' => 'ชื่อตารางไม่ถูกต้อง']);
    }
    $res = hds_explore_sql($con, $id, 'SELECT * FROM `' . $table . '` LIMIT 40');
    $preview = [
        'columns' => $res['columns'] ?? [],
        'rows' => $res['rows'] ?? [],
        'error' => $res['error'] ?? '',
        'total' => null,
    ];
    hds_api_json([
        'status' => empty($preview['error']) ? 'success' : 'error',
        'message' => $preview['error'] ?: '',
        'table' => $table,
        'columns' => array_map(function ($c) {
            return ['name' => $c, 'type' => '', 'sensitive' => hds_is_sensitive_column($c, '')];
        }, $preview['columns']),
        'preview' => $preview,
    ]);
}

if ($action === 'query') {
    $id = (int)($input['id'] ?? $_GET['id'] ?? 0);
    $sql = (string)($input['sql'] ?? '');
    $result = hds_explore_sql($con, $id, $sql);
    hds_api_json([
        'status' => !empty($result['ok']) ? 'success' : 'error',
        'message' => $result['error'] ?? '',
        'result' => $result,
    ]);
}

hds_api_json(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], 400);
