<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/amr_helper.php');
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_sensitivity_helper.php';
require_once __DIR__ . '/amr_mlab_helper.php';
mysqli_set_charset($con, 'utf8');
set_time_limit(90);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

amr_dict_ensure_tables($con);
amr_dict_prime($con);
amr_sens_drug_level_prime($con);

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = [];
}
$src = array_merge($_GET, $input);
$action = trim((string)($src['action'] ?? 'search'));

function amr_sens_json(array $payload) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'rec_rank') {
    amr_sens_json([
        'status' => 'success',
        'ranks' => amr_sens_rec_rank_list($con),
        'drug_levels' => amr_sens_drug_level_prime($con),
        'steward' => amr_sens_steward_mode_meta(amr_sens_steward_mode($con)),
    ]);
}

if ($action === 'rec_rank_save') {
    $aware = $src['aware'] ?? [];
    $class = $src['class'] ?? [];
    if (!is_array($aware)) {
        $aware = [];
    }
    if (!is_array($class)) {
        $class = [];
    }
    if (isset($src['steward_mode'])) {
        amr_sens_steward_mode_save($con, $src['steward_mode']);
    }
    $levels = $src['drug_levels'] ?? $src['drug_level'] ?? null;
    if (is_array($levels)) {
        amr_sens_drug_level_save($con, $levels);
    }
    amr_sens_json([
        'status' => 'success',
        'message' => 'บันทึกลำดับ ระดับยา และโหมดประเมินแล้ว',
        'ranks' => amr_sens_rec_rank_save($con, $aware, $class),
        'drug_levels' => amr_sens_drug_level_prime($con),
        'steward' => amr_sens_steward_mode_meta(amr_sens_steward_mode($con)),
    ]);
}

if ($action === 'rec_rank_reset') {
    amr_sens_json([
        'status' => 'success',
        'message' => 'คืนค่าลำดับเริ่มต้นตามหลัก stewardship แล้ว',
        'ranks' => amr_sens_rec_rank_reset($con),
        'drug_levels' => amr_sens_drug_level_prime($con),
        'steward' => amr_sens_steward_mode_meta(amr_sens_steward_mode($con)),
    ]);
}

if ($action === 'drug_level') {
    amr_sens_json([
        'status' => 'success',
        'drug_levels' => amr_sens_drug_level_prime($con),
    ]);
}

if ($action === 'drug_level_reset') {
    amr_sens_json([
        'status' => 'success',
        'message' => 'คืนค่าระดับยาเริ่มต้นแล้ว (Ceftriaxone = Access)',
        'drug_levels' => amr_sens_drug_level_reset($con),
    ]);
}

if ($action === 'steward_mode') {
    amr_sens_json([
        'status' => 'success',
        'steward' => amr_sens_steward_mode_meta(amr_sens_steward_mode($con)),
    ]);
}

if ($action === 'steward_mode_save') {
    $mode = amr_sens_steward_mode_save($con, $src['steward_mode'] ?? $src['mode'] ?? 'both');
    amr_sens_json([
        'status' => 'success',
        'message' => 'บันทึกโหมดประเมินแล้ว',
        'steward' => amr_sens_steward_mode_meta($mode),
    ]);
}

$hos = hosxp_connect($con, 90);
$use_mlab = amr_mlab_using_direct($con);
if (!$hos && !$use_mlab) {
    amr_sens_json(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้']);
}
if ($hos) {
    hosxp_extend_read_timeout($hos, 90);
}

if ($action === 'search') {
    $end = function_exists('amr_parse_date')
        ? amr_parse_date($src['end_date'] ?? '', date('Y-m-d'))
        : date('Y-m-d');
    $start = function_exists('amr_parse_date')
        ? amr_parse_date($src['start_date'] ?? '', date('Y-m-d', strtotime('-6 days')))
        : date('Y-m-d', strtotime('-6 days'));
    $q = trim((string)($src['q'] ?? $src['hn'] ?? $src['an'] ?? $src['order'] ?? ''));
    $scope = amr_sens_list_scope($src['scope'] ?? 'resistant');
    $list = $use_mlab
        ? amr_mlab_fetch_list($con, $q, $start, $end, $scope, $hos)
        : amr_sens_fetch_list($hos, $q, $start, $end, $scope);
    if ($list['error'] !== '') {
        amr_sens_json(['status' => 'error', 'message' => $list['error']]);
    }
    amr_sens_json([
        'status' => 'success',
        'q' => $q,
        'start_date' => $start,
        'end_date' => $end,
        'scope' => $scope,
        'rows' => $list['rows'],
        'source' => $use_mlab ? 'mlab' : 'hosxp',
        'source_label' => $use_mlab ? 'mLAB (ตาราง THAM Hos-Safe)' : 'HOSxP lab_head',
    ]);
}

if ($action === 'detail') {
    $order = preg_replace('/\D+/', '', (string)($src['order'] ?? $src['orderNumber'] ?? $src['lab_order_number'] ?? ''));
    if ($order === '') {
        $order = trim((string)($src['order'] ?? $src['orderNumber'] ?? $src['lab_order_number'] ?? ''));
    }
    if ($order === '') {
        amr_sens_json(['status' => 'error', 'message' => 'ระบุ lab order number']);
    }
    $header = $use_mlab ? amr_mlab_fetch_header($con, $order, $hos) : ($hos ? amr_sens_fetch_header($hos, $order) : []);
    if (!$header && $hos && $use_mlab) {
        $header = amr_sens_fetch_header($hos, $order);
    }
    if (!$header) {
        amr_sens_json(['status' => 'error', 'message' => 'ไม่พบใบแล็บนี้']);
    }
    $ast_raw = $header['_ast_raw'] ?? [];
    $built_text = (string)($header['_result_text'] ?? '');
    unset($header['_ast_raw'], $header['_result_text']);
    $text = $use_mlab
        ? ($built_text !== '' ? $built_text : amr_mlab_fetch_result_text($con, $order))
        : ($hos ? amr_sens_fetch_result_text($hos, $order) : '');
    if ($text === '' && $hos) {
        $text = amr_sens_fetch_result_text($hos, $order);
    }
    $no_growth = amr_sens_is_no_growth($text)
        || amr_sens_is_no_growth((string)($header['microtype'] ?? ''))
        || amr_sens_is_no_growth((string)($header['result'] ?? ''));
    $hn = (string)($header['hn'] ?? '');
    $an = (string)($header['an'] ?? '');
    $kidney = $hos ? amr_sens_fetch_lab_history($hos, $hn, 'egfr', $con) : [];
    $atb_current = $hos ? amr_sens_fetch_atb_current($hos, $an, $hn, $con) : [];
    $atb_active = $hos ? amr_sens_fetch_atb_active($hos, $an, $hn, $con) : [];
    $atb = $hos
        ? amr_sens_mark_atb_on_now(amr_sens_fetch_atb($hos, $an, $hn, $con), $atb_current, $atb_active)
        : [];
    $atb = amr_sens_annotate_atb_renal($con, $atb, $kidney);
    $ast = [];
    if (!$no_growth) {
        if ($use_mlab && $ast_raw) {
            $ast = amr_sens_ast_from_mlab($ast_raw);
        }
        if (!$ast) {
            $ast = amr_sens_parse_ast($text);
        }
    }
    amr_sens_json([
        'status' => 'success',
        'header' => $header,
        'result_text' => $text,
        'no_growth' => $no_growth,
        'ast' => $ast,
        'kidney' => $kidney,
        'lab_options' => $hos ? amr_sens_fetch_lab_options($hos, $hn, $con) : [],
        'lab_code' => 'egfr',
        'atb' => $atb,
        'atb_current' => $atb_current,
        'source' => $use_mlab ? 'mlab' : 'hosxp',
        'source_label' => $use_mlab ? 'mLAB (ตาราง THAM Hos-Safe)' : 'HOSxP lab_head',
        'summary' => amr_sens_build_therapy_summary(
            $con, $ast, $atb_current, $atb, $kidney, $no_growth,
            amr_sens_organism_label($text, $header)
        ),
    ]);
}

if ($action === 'lab_history') {
    $hn = preg_replace('/\D+/', '', (string)($src['hn'] ?? ''));
    $lab_code = trim((string)($src['lab_code'] ?? 'egfr'));
    if ($hn === '') {
        amr_sens_json(['status' => 'error', 'message' => 'ระบุ HN']);
    }
    amr_sens_json([
        'status' => 'success',
        'lab_code' => $lab_code !== '' ? $lab_code : 'egfr',
        'rows' => $hos ? amr_sens_fetch_lab_history($hos, $hn, $lab_code, $con) : [],
    ]);
}

if ($action === 'atb_drugs') {
    amr_sens_json([
        'status' => 'success',
        'using_custom' => count(amr_sens_atb_active_icodes($con)) > 0,
        'rows' => amr_sens_atb_list($con),
    ]);
}

if ($action === 'atb_drug_add') {
    $raw = (string)($src['drug'] ?? $src['icode'] ?? '');
    $parsed = function_exists('hosxp_parse_drug_option')
        ? hosxp_parse_drug_option($raw)
        : ['icode' => trim($raw), 'name' => ''];
    $icode = $parsed['icode'];
    if ($icode === '') {
        amr_sens_json(['status' => 'error', 'message' => 'ระบุยาที่ต้องการเพิ่ม']);
    }
    $meta = [
        'icode' => $icode,
        'drug_name' => $parsed['name'],
        'generic_name' => '',
        'dosageform' => '',
    ];
    $q = false;
    if ($hos) {
        $sql = "SELECT d.icode,
                       CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
                       CAST(CONVERT(IFNULL(d.generic_name, '') USING utf8) AS CHAR) AS generic_name,
                       IFNULL(d.dosageform, '') AS dosageform
                FROM drugitems d
                WHERE d.icode = '" . mysqli_real_escape_string($hos, $icode) . "'
                LIMIT 1";
        $q = @mysqli_query($hos, $sql);
    }
    if ($q && ($row = mysqli_fetch_assoc($q))) {
        $meta = $row;
    } elseif ($meta['drug_name'] === '') {
        $meta['drug_name'] = $icode;
    }
    $res = amr_sens_atb_add($con, $meta);
    if (empty($res['ok'])) {
        amr_sens_json(['status' => 'error', 'message' => $res['error'] ?? 'เพิ่มยาไม่สำเร็จ']);
    }
    amr_sens_json([
        'status' => 'success',
        'message' => 'เพิ่มยาเรียบร้อย',
        'using_custom' => true,
        'rows' => amr_sens_atb_list($con),
    ]);
}

if ($action === 'atb_drug_delete') {
    $id = (int)($src['id'] ?? 0);
    if (!amr_sens_atb_delete($con, $id)) {
        amr_sens_json(['status' => 'error', 'message' => 'ลบไม่สำเร็จ']);
    }
    $rows = amr_sens_atb_list($con);
    amr_sens_json([
        'status' => 'success',
        'message' => 'ลบรายการแล้ว',
        'using_custom' => count(amr_sens_atb_active_icodes($con)) > 0,
        'rows' => $rows,
    ]);
}

if ($action === 'atb_drug_import_flag') {
    if (!$hos) {
        amr_sens_json(['status' => 'error', 'message' => 'ต้องเชื่อม HOSxP เพื่อนำเข้ายาที่ติ๊ก Antibiotic']);
    }
    $res = amr_sens_atb_import_flag($con, $hos);
    if (empty($res['ok'])) {
        amr_sens_json(['status' => 'error', 'message' => $res['error'] ?? 'นำเข้าไม่สำเร็จ']);
    }
    amr_sens_json([
        'status' => 'success',
        'message' => 'นำเข้า ' . (int)$res['inserted'] . ' รายการจากยาที่ติ๊ก Antibiotic',
        'using_custom' => true,
        'rows' => amr_sens_atb_list($con),
    ]);
}

amr_sens_json(['status' => 'error', 'message' => 'action ไม่ถูกต้อง']);
