<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
session_write_close();
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/postal_drug_report_helper.php');
mysqli_set_charset($con, 'utf8');
set_time_limit(180);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

$action = isset($_GET['action']) ? trim($_GET['action']) : 'report';
$start_date = isset($_GET['start_date']) ? trim($_GET['start_date']) : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? trim($_GET['end_date']) : date('Y-m-d');
$granularity = pdr_normalize_granularity($_GET['granularity'] ?? 'day');
$include_detail = !isset($_GET['include_detail']) || $_GET['include_detail'] !== '0';

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}

hosxp_extend_read_timeout($hos, 120);

if ($action === 'summary' || $action === 'report') {
    $report = pdr_build_report($hos, $start_date, $end_date, $granularity, $action === 'report' ? $include_detail : false);
    mysqli_close($hos);
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($report, JSON_UNESCAPED_UNICODE);
    exit;
}

mysqli_close($hos);
ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
exit;
