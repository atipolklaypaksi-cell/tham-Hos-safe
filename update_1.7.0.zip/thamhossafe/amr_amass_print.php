<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include(__DIR__ . '/connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/amr_amass_helper.php';
require_once __DIR__ . '/amr_amass_engine.php';
tham_menu_ensure_tables($con);
tham_menu_ensure_page_access(basename(__FILE__));
$tables = amr_amass_dashboard_tables();
$has_engine = !empty($tables['meta']) || !empty($tables['section2']) || !empty($tables['byorg']);
$kpis = amr_amass_result_kpis();
$cover = amr_amass_cover_info($con);
$r1 = function_exists('amr_amass_report1_map') ? amr_amass_report1_map() : [];
$hospital_name = $cover['hospital_name'];
$country_name = $cover['country'] !== '' ? $cover['country'] : 'Thailand';
$country = $country_name;
$contact_person = $cover['contact_person'];
$contact_address = $cover['contact_address'];
$contact_email = $cover['contact_email'];
$cover_notes = $cover['notes_on_the_cover'];
$meta = $tables['meta'] ?? [];
$section = preg_replace('/[^a-z0-9_-]/', '', strtolower((string)($_GET['section'] ?? '')));
session_write_close();

function amass_fmt_date($d) {
    $t = strtotime((string)$d);
    return $t ? date('d M Y', $t) : trim((string)$d);
}
function amass_group_rows(array $rows, $key) {
    $out = [];
    foreach ($rows as $row) {
        $k = (string)($row[$key] ?? '');
        if ($k === '') {
            continue;
        }
        $out[$k][] = $row;
    }
    return $out;
}
function amass_p(array $r1, $keys, $default = 'NA') {
    foreach ((array)$keys as $k) {
        if (isset($r1[$k]) && trim((string)$r1[$k]) !== '') {
            return $r1[$k];
        }
    }
    return $default;
}
function amass_int($v) {
    if ($v === '' || $v === null || strtoupper((string)$v) === 'NA') {
        return 'NA';
    }
    if (is_numeric($v)) {
        return number_format((float)$v, 0, '.', ',');
    }
    return (string)$v;
}
function amass_num($v) {
    $s = trim((string)$v);
    return $s === '' ? 'NA' : $s;
}
function amass_hi($v) {
    return '<b><i class="amass-hi">' . htmlspecialchars((string)$v) . '</i></b>';
}
function amass_cover_val($v) {
    return '<b class="cover-val">' . htmlspecialchars((string)$v) . '</b>';
}
function amass_org($name) {
    return '<i>' . htmlspecialchars((string)$name) . '</i>';
}
function amass_mort_cell($row) {
    if (!is_array($row)) {
        return 'NA';
    }
    $n = $row['Total_number_of_patients'] ?? '';
    if ($n === '' || $n === null || (is_numeric($n) && (int)$n <= 0)) {
        return 'NA';
    }
    return amass_num($row['Mortality(%)'] ?? '') . '% (' . amass_num($row['Number_of_deaths'] ?? '') . '/' . amass_num($n) . ')';
}
function amass_sum_col(array $rows, $key) {
    $t = 0;
    foreach ($rows as $row) {
        if (is_numeric($row[$key] ?? '')) {
            $t += (float)$row[$key];
        }
    }
    return $t;
}
function amass_freq_total(array $rows, $denom) {
    $n = (int)amass_sum_col($rows, 'Number_of_patients');
    $d = (int)$denom;
    $f = function_exists('amr_amass_freq_per_100k') ? amr_amass_freq_per_100k($n, $d) : ['rate' => '', 'lo' => '', 'hi' => ''];
    return ['n' => $n, 'rate' => $f['rate'], 'lo' => $f['lo'], 'hi' => $f['hi']];
}
function amass_mort_total(array $rows) {
    $d = (int)amass_sum_col($rows, 'Number_of_deaths');
    $n = (int)amass_sum_col($rows, 'Total_number_of_patients');
    $ci = function_exists('amr_amass_wilson') ? amr_amass_wilson($d, $n) : ['pct' => '', 'lo' => '', 'hi' => ''];
    if ($n <= 0) {
        return ['d' => $d, 'n' => $n, 'pct' => 'NA', 'lo' => 'NA', 'hi' => 'NA'];
    }
    return ['d' => $d, 'n' => $n, 'pct' => $ci['pct'], 'lo' => $ci['lo'], 'hi' => $ci['hi']];
}
function amass_foot($created, $label = '') {
    echo '<div class="footer-line"><span>Created on: ' . htmlspecialchars($created) . '</span><span class="foot-page"></span></div>';
}
function amass_kv(array $rows, $key, $default = 'NA') {
    foreach ($rows as $row) {
        foreach (['Parameter', 'Indicators', 'Description'] as $k) {
            if (($row[$k] ?? '') === $key) {
                foreach (['Value', 'Proportion', 'Number'] as $vk) {
                    if (isset($row[$vk]) && trim((string)$row[$vk]) !== '') {
                        return $row[$vk];
                    }
                }
            }
        }
    }
    return $default;
}
function amass_render_amr_table(array $rows, $n_pat = 0) {
    echo '<table class="amass amr-tbl"><thead><tr>';
    echo '<th>Antibiotic agent</th><th>Proportion of R</th><th>95% CI</th><th style="width:88px"></th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        $r = $row['Non-susceptible(N)'] ?? '';
        $tot = $row['Total(N)'] ?? '';
        $pct = $row['Non-susceptible(%)'] ?? '';
        $lo = $row['lower95CI(%)*'] ?? '';
        $hi = $row['upper95CI(%)*'] ?? '';
        $empty = ($tot === '' || $tot === '0' || $tot === 0);
        $prop = $empty ? 'NA' : (amass_num($pct) . '% (' . amass_num($r) . '/' . amass_num($tot) . ')');
        $ci = ($empty || $lo === '' || $hi === '') ? '-' : (amass_num($lo) . '% - ' . amass_num($hi) . '%');
        $bar = is_numeric($pct) ? max(0, min(100, (float)$pct)) : 0;
        $grey = ($n_pat > 0 && is_numeric($tot) && (float)$tot > 0 && ((float)$tot / $n_pat) < 0.7);
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['Antibiotic'] ?? '') . '</td>';
        echo '<td class="num">' . htmlspecialchars($prop) . '</td>';
        echo '<td class="num">' . htmlspecialchars($ci) . '</td>';
        echo '<td><div class="barwrap"><div class="bar' . ($grey ? ' grey' : '') . '" style="width:' . $bar . '%"></div></div></td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
}

$dmin = $kpis['date_min'] !== '' ? $kpis['date_min'] : ($meta['date_min'] ?? '');
$dmax = $kpis['date_max'] !== '' ? $kpis['date_max'] : ($meta['date_max'] ?? '');
$micro_n = amass_p($r1, ['microbiology_data|Number_of_records'], $kpis['micro_n'] !== '' ? $kpis['micro_n'] : ($meta['micro_rows'] ?? 'NA'));
$adm_n = amass_p($r1, ['hospital_admission_data|Number_of_records'], $kpis['adm_n'] !== '' ? $kpis['adm_n'] : ($meta['admission_rows'] ?? 'NA'));
$pdays = amass_p($r1, ['hospital_admission_data|Patient_days'], $kpis['patient_days'] !== '' ? $kpis['patient_days'] : ($meta['patient_days'] ?? 'NA'));
$pdays_his = amass_p($r1, ['hospital_admission_data|Patient_days_his'], $meta['patient_days_his'] ?? 'NA');
$micro_min = amass_p($r1, ['microbiology_data|Minimum_date'], $dmin);
$micro_max = amass_p($r1, ['microbiology_data|Maximum_date'], $dmax);
$adm_min = amass_p($r1, ['hospital_admission_data|Minimum_date'], 'NA');
$adm_max = amass_p($r1, ['hospital_admission_data|Maximum_date'], 'NA');
$blo_num = amass_p($r1, ['microbiology_data|Number_of_blood_specimens_collected'], $meta['blood_collected'] ?? 'NA');
$blo_neg = amass_p($r1, ['microbiology_data|Number_of_blood_culture_negative'], $meta['blood_neg'] ?? 'NA');
$blo_pos = amass_p($r1, ['microbiology_data|Number_of_blood_culture_positive'], $meta['blood_pos'] ?? 'NA');
$blo_pos_org = amass_p($r1, ['microbiology_data|Number_of_blood_culture_positive_for_organism_under_this_survey'], 'NA');
$n_blood_pat = amass_p($r1, ['merged_data|Number_of_patients_sampled_for_blood_culture'], $meta['n_blood_patients'] ?? 'NA');
$n_bsi = amass_p($r1, ['merged_data|Number_of_patients_with_blood_culture_positive_for_organism_under_this_survey', 'overall_data|Blood_priority_isolates_deduplicated'], $meta['blood_priority_dedup'] ?? 'NA');
$n_com = amass_p($r1, ['merged_data|Number_of_patients_with_community_origin_BSI'], 'NA');
$n_hos = amass_p($r1, ['merged_data|Number_of_patients_with_hospital_origin_BSI'], 'NA');
$n_unk = amass_p($r1, ['merged_data|Number_of_patients_with_unknown_origin_BSI'], 'NA');
$n_tested_com = amass_p($r1, ['merged_data|Number_of_patients_with_blood_culture_within_first_2_days_of_admission'], 'NA');
$n_tested_hos = amass_p($r1, ['merged_data|Number_of_patients_with_blood_culture_within_after_2_days_of_admission'], 'NA');
$n_tested_unk = amass_p($r1, ['merged_data|Number_of_patients_with_unknown_origin'], 'NA');
$n_adm_pat = amass_p($r1, ['hospital_admission_data|Number_of_patients_included'], 'NA');
$n_adm_dead = amass_p($r1, ['hospital_admission_data|Number_of_deaths'], 'NA');
$mort_overall = amass_p($r1, ['hospital_admission_data|Mortality'], 'NA');
$created = !empty($meta['ran_at']) ? date('d M Y', strtotime($meta['ran_at'])) : date('d M Y');
$sec2_by = amass_group_rows($tables['section2'] ?? [], 'Organism');
$sec3_by_org = [];
foreach ($tables['section3'] ?? [] as $row) {
    $org = (string)($row['Organism'] ?? '');
    $origin = (string)($row['Infection_origin'] ?? '');
    if ($org === '') {
        continue;
    }
    $sec3_by_org[$org][$origin][] = $row;
}
$byorg_n = [];
foreach ($tables['byorg'] ?? [] as $row) {
    $byorg_n[(string)($row['Organism'] ?? '')] = (int)($row['Number_of_blood_specimens_culture_positive_deduplicated'] ?? 0);
}
$pat_origin = [];
foreach ($tables['section6'] ?? [] as $row) {
    $pat_origin[(string)($row['Organism'] ?? '')][(string)($row['Infection_origin'] ?? '')] = $row['Total_number_of_patients'] ?? '';
}
$org_list = [
    'Escherichia coli',
    'Klebsiella pneumoniae',
    'Acinetobacter baumannii',
    'Pseudomonas aeruginosa',
    'Staphylococcus aureus',
    'Enterococcus faecium',
    'Enterococcus faecalis',
    'Streptococcus pneumoniae',
    'Salmonella spp.',
];
$jump = [
    'sec1' => '#section-1',
    'sec2' => '#section-2',
    'sec3' => '#section-3',
    'sec4' => '#section-4',
    'sec5' => '#section-5',
    'sec6' => '#section-6',
    'annex-b' => '#annex-b',
    'annex-c' => '#annex-c',
    'annex-d' => '#annex-d',
];
$amr_note = '*Proportion of R represents the number of patients with blood culture positive for resistant isolates (numerator) over the total number of patients with blood culture positive for the organism and the organism was tested for susceptibility against the antibiotic (denominator). AMASS application de-duplicated the data by including only the first isolate per patient per specimen type per evaluation period. Grey bars indicate that AST unknown results are more than 30% of the total number of patients with blood culture positive for the organism. CI=confidence interval; R=resistant; NA=not available/reported/tested.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AMR surveillance report — <?php echo htmlspecialchars($hospital_name); ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root { --amass-green: forestgreen; --amass-gold: #FCBB42; --amass-navy: #000080; --amass-ink: #3e4444; }
        html, body { margin: 0; background: #d8ddd8; color: #222; }
        body { font-family: Helvetica, Arial, "Liberation Sans", sans-serif; font-size: 11pt; }
        .toolbar { position: sticky; top: 0; z-index: 20; background: #146c4a; color: #fff; padding: .55rem 1rem; display: flex; justify-content: space-between; align-items: center; gap: .6rem; font-family: Helvetica, Arial, sans-serif; font-size: 11pt; }
        .sheet { width: 210mm; min-height: 297mm; margin: 12px auto; background: #fff; box-shadow: 0 2px 10px rgba(0,0,0,.18); box-sizing: border-box; position: relative; }
        .cover { overflow: hidden; }
        .cover-gold { position: absolute; left: 0; right: 0; bottom: 590pt; height: 20pt; background: var(--amass-gold); }
        .cover-banner { position: absolute; left: 0; right: 0; bottom: 420pt; height: 150pt; background: var(--amass-green); color: #fff; box-sizing: border-box; padding: 28pt 0.7in 20pt; }
        .cover-banner h1 { font-size: 28pt; font-weight: 700; margin: 0 0 8pt; letter-spacing: 0; line-height: 1.15; font-family: Helvetica, Arial, sans-serif; }
        .cover-lead-wrap { position: absolute; left: 0.7in; bottom: 2.2in; width: 460pt; height: 240pt; }
        .cover-meta { position: absolute; left: 0.7in; bottom: 0.5in; width: 460pt; height: 140pt; font-size: 11pt; line-height: 16pt; }
        .cover-body .k, .cover-lead-wrap .k, .cover-meta .k { font-weight: 700; color: #000; font-style: normal; }
        .cover-lead { font-size: 18pt; line-height: 26pt; margin: 0; }
        .cover-lead.gap { margin-top: 18pt; }
        .cover-val { color: var(--amass-navy); font-weight: 700; font-style: normal; }
        .page { padding: 1.19in 0.81in 0.55in 1.07in; }
        .page.gen-page { padding: 0.85in 1.0in 0.7in; }
        .sec-title { color: var(--amass-ink); font-size: 16pt; font-weight: 700; margin: 0 0 8pt; font-family: Helvetica, Arial, sans-serif; }
        .sec-title.sub { margin: 0 0 14pt; }
        .gen-title { font-size: 11pt; font-weight: 700; margin: 0 0 4pt; color: #000; }
        .sub-title { color: var(--amass-ink); font-size: 12pt; font-weight: 700; margin: 14pt 0 8pt; }
        .sub-title.note { color: darkgreen; }
        .prose { font-size: 11pt; line-height: 16pt; margin: 0 0 10pt; text-align: justify; }
        .indent { padding-left: 35pt; text-align: left; }
        .indent2 { padding-left: 70pt; text-align: left; }
        .amass-hi { color: var(--amass-navy); font-style: italic; font-weight: 700; font-family: Helvetica, Arial, sans-serif; }
        .note-block { color: darkgreen; font-size: 11pt; line-height: 16pt; margin: 8pt 0 12pt; }
        table.amass { width: 100%; border-collapse: collapse; font-size: 9pt; margin: 10pt 0 14pt; font-family: Helvetica, Arial, sans-serif; }
        table.amass th { background: #d3d3d3; color: #000; font-weight: 700; font-style: normal; border: 0.5pt solid #696969; padding: 5pt 4pt; text-align: center; vertical-align: middle; }
        table.amass td { border: 0.5pt solid #696969; padding: 4pt 5pt; text-align: center; vertical-align: middle; }
        table.amass td.left { text-align: left; }
        table.amass td.num { text-align: center; font-variant-numeric: tabular-nums; }
        table.amass td.org { font-style: italic; font-weight: 700; text-align: left; }
        table.amass tr.total td { font-weight: 700; font-style: normal; }
        table.amass tr.total td.org { font-style: normal; font-weight: 700; }
        table.amass.count td.org { font-style: italic; font-weight: 700; color: #000; }
        table.amass.count td.num { color: var(--amass-navy); font-weight: 700; font-style: italic; }
        table.amass.count tr.total td.org, table.amass.count tr.total td:first-child { font-style: normal; font-weight: 700; color: #000; }
        table.toc { width: 100%; border-collapse: collapse; font-size: 11pt; margin-top: 12pt; line-height: 18pt; }
        table.toc td { padding: 3pt 0; border: 0; color: var(--amass-ink); font-family: Helvetica, Arial, sans-serif; }
        table.toc td.pg { text-align: right; width: 48pt; color: var(--amass-ink); }
        table.toc a { color: var(--amass-ink); text-decoration: none; }
        .barwrap { background: #eee; height: 8pt; overflow: hidden; min-width: 70pt; }
        .bar { height: 100%; background: #2e8b57; }
        .bar.grey { background: #9aa39a; }
        .foot { font-size: 9pt; color: #222; margin-top: 10pt; line-height: 14pt; text-align: justify; }
        .footer-line { position: absolute; left: 55pt; right: 55pt; bottom: 30pt; display: flex; justify-content: space-between; font-size: 9pt; color: var(--amass-ink); font-family: Helvetica, Arial, sans-serif; border: 0; margin: 0; padding: 0; }
        .org-head { font-size: 12pt; margin: 8pt 0 12pt; overflow: hidden; }
        .org-head .right { float: right; }
        .split { overflow: hidden; }
        .split .half { width: 48%; float: left; }
        .split .half + .half { margin-left: 4%; }
        .cite { margin-top: 22pt; }
        .ref-rule { border: 0; border-top: 2pt solid #000; margin: 14pt 0 10pt; }
        @media print {
            .toolbar { display: none !important; }
            html, body { background: #fff; }
            .sheet { width: auto; min-height: 297mm; margin: 0; box-shadow: none; page-break-after: always; }
            .sheet:last-child { page-break-after: auto; }
            @page { size: A4; margin: 0; }
        }
    </style>
</head>
<body>
<div class="toolbar no-print">
    <span>AMASS v4.0 build 4028 — Antimicrobial Resistance (AMR) Surveillance report</span>
    <span>
        <a href="amr_amass_dashboard.php" class="btn btn-sm btn-light">กลับ Dashboard</a>
        <button type="button" class="btn btn-sm btn-warning" onclick="window.print()">พิมพ์ PDF</button>
    </span>
</div>

<?php if (!$has_engine): ?>
<div class="sheet page">
    <p>ยังไม่มีรายงานจากข้อมูลโรงพยาบาล — ไปที่ Dashboard AMASS แล้วกดดึงข้อมูลและสร้าง Dashboard</p>
</div>
<?php else: ?>

<div class="sheet cover" id="cover">
    <div class="cover-gold"></div>
    <div class="cover-banner">
        <h1>Antimicrobial Resistance (AMR)</h1>
        <h1>Surveillance report</h1>
    </div>
    <div class="cover-lead-wrap">
        <p class="cover-lead"><span class="k">Hospital name:</span>  <?php echo amass_cover_val($hospital_name); ?></p>
        <p class="cover-lead"><span class="k">Country name:</span>  <?php echo amass_cover_val($country_name); ?></p>
        <p class="cover-lead gap"><span class="k">Data from:</span></p>
        <p class="cover-lead"><?php echo amass_cover_val(amass_fmt_date($dmin) . ' to ' . amass_fmt_date($dmax)); ?></p>
    </div>
    <div class="cover-meta">
        <div><span class="k">Contact person:</span>  <?php echo amass_cover_val($contact_person !== '' ? $contact_person : 'NA'); ?></div>
        <div><span class="k">Contact address:</span>  <?php echo amass_cover_val($contact_address !== '' ? $contact_address : 'NA'); ?></div>
        <div><span class="k">Contact email:</span>  <?php echo amass_cover_val($contact_email !== '' ? $contact_email : 'NA'); ?></div>
        <div><span class="k">Generated on:</span>  <?php echo amass_cover_val($created); ?></div>
        <div><span class="k">Software version:</span>  <?php echo amass_cover_val('AMASS 4.0 build 4028 released on 14 Jan 2026'); ?></div>
        <?php if (trim($cover_notes) !== '' && strtoupper($cover_notes) !== 'NA'): ?>
        <div><span class="k">Notes:</span>  <?php echo htmlspecialchars($cover_notes); ?></div>
        <?php endif; ?>
    </div>
</div>

<div class="sheet page gen-page no-pagenum" id="generated-by">
    <p class="gen-title">Generated by</p>
    <p class="prose">AutoMated tool for Antimicrobial resistance Surveillance System (AMASS) version 4.0<br>
        (build 4028 released on 14 Jan 2026)</p>
    <p class="prose indent">AMASS application is available under the Creative Commons Attribution 4.0 International Public License (CC BY 4.0). The application can be downloaded at: <a href="https://www.amass.website">https://www.amass.website</a></p>
    <p class="prose indent">AMASS application used microbiology data, hospital admission data and pharmacy data files that are stored in the same folder as the application (AMASS.bat) to generate this report.</p>
    <p class="prose indent">The goal of AMASS application is to enable hospitals with microbiology data available in electronic formats to analyze their own data and generate AMR surveillance reports promptly. If hospital admission date data are available, the reports will additionally be stratified by infection origin (community-origin or hospital-origin). If mortality data (such as patient discharge outcome data) are available, a report on mortality involving AMR infection will be included. If pharmacy data are available, a report on antimicrobial use and stewardship will be included.</p>
    <p class="prose indent">This automatically generated report has limitations, validate the report, and requires users to understand those limitations and use the summary data in the report with careful interpretation.</p>
    <p class="prose indent">A valid report could have local implications and much wider benefits if shared with national and international organizations.</p>
    <p class="prose indent">This automatically generated report is under the jurisdiction of the hospital to copy, redistribute, and share with any individual or organization.</p>
    <p class="prose indent">This automatically generated report contains no patient identifier, similar to standard reports on cumulative antimicrobial susceptibility.</p>
    <p class="prose indent">For any query on AMASS, please contact:<br>
        AMASS group email (amass@tropmedres.ac),<br>
        Chalida Rangsiwutisak (chalida@tropmedres.ac),<br>
        Preeyarach Klaytong (preeyarach@tropmedres.ac), and<br>
        Direk Limmathurotsakul (direk@tropmedres.ac)</p>
    <p class="prose cite"><b>Suggested title for citation:</b><br>
        Antimicrobial resistance surveillance report, <?php echo htmlspecialchars($hospital_name); ?>,<br>
        <?php echo htmlspecialchars($country); ?>, <?php echo htmlspecialchars(amass_fmt_date($dmin)); ?> to <?php echo htmlspecialchars(amass_fmt_date($dmax)); ?>.</p>
</div>

<div class="sheet page no-pagenum" id="content">
    <p class="sec-title">Content</p>
    <table class="toc">
        <tr><td><a href="#intro">Introduction</a></td><td class="pg" data-toc="#intro"></td></tr>
        <tr><td><a href="#section-1">Section [1]: Data overview</a></td><td class="pg" data-toc="#section-1"></td></tr>
        <tr><td><a href="#section-2">Section [2]: AMR proportion report</a></td><td class="pg" data-toc="#section-2"></td></tr>
        <tr><td><a href="#section-3">Section [3]: AMR proportion report with stratification by infection origin</a></td><td class="pg" data-toc="#section-3"></td></tr>
        <tr><td><a href="#section-4">Section [4]: AMR frequency report</a></td><td class="pg" data-toc="#section-4"></td></tr>
        <tr><td><a href="#section-5">Section [5]: AMR frequency report with stratification by infection origin</a></td><td class="pg" data-toc="#section-5"></td></tr>
        <tr><td><a href="#section-6">Section [6]: Mortality involving AMR and antimicrobial-susceptible infections</a></td><td class="pg" data-toc="#section-6"></td></tr>
        <tr><td><a href="#annex-a">Annex A: Supplementary report on notifiable bacterial infections</a></td><td class="pg" data-toc="#annex-a"></td></tr>
        <tr><td><a href="#annex-b">Annex B: Supplementary report on data indicators</a></td><td class="pg" data-toc="#annex-b"></td></tr>
        <tr><td><a href="#annex-c">Annex C: Cluster signals</a></td><td class="pg" data-toc="#annex-c"></td></tr>
        <tr><td><a href="#annex-d">Annex D: Antimicrobial use (AMU)</a></td><td class="pg" data-toc="#annex-d"></td></tr>
        <tr><td><a href="#methods">Methods used by AMASS application</a></td><td class="pg" data-toc="#methods"></td></tr>
        <tr><td><a href="#ack">Acknowledgements</a></td><td class="pg" data-toc="#ack"></td></tr>
    </table>
</div>

<div class="sheet page" id="intro">
    <p class="sec-title">Introduction</p>
    <p class="prose">Antimicrobial resistance (AMR) is a global health crisis [1]. The recent modelling study estimated that 1.27 million deaths worldwide were directly attributable to AMR in 2019 [1]. However, data of AMR surveillance from low and middle-income countries (LMICs) are scarce [1,2], and data of mortality associated with AMR infections are rarely available. A recent study estimated that 19,000 deaths are attributable to AMR infections in Thailand annually, using routinely available microbiological and hospital databases [3]. The study also proposed that hospitals in LMICs should utilize routinely available microbiological and hospital admission databases to generate reports on AMR surveillance systematically [3].</p>
    <p class="prose">Reports on AMR surveillance can have a wide range of benefits [2]; including</p>
    <p class="prose indent">− characterization of the frequency of resistance and organisms in different facilities and regions;</p>
    <p class="prose indent">− prospective and retrospective information on emerging public health threats;</p>
    <p class="prose indent">− evaluation and optimization of local and national standard treatment guidelines;</p>
    <p class="prose indent">− evaluation of the impact of interventions beyond antimicrobial guidelines that aim to reduce AMR; and</p>
    <p class="prose indent">− data sharing with national and international organizations to support decisions on resource allocation for interventions against AMR and to inform the implementation of action plans at national and global levels.</p>
    <p class="prose">When reporting AMR surveillance results, it is generally recommended that (a) duplicate results of bacterial isolates are removed, and (b) reports are stratified by infection origin (community-origin or hospital-origin), if possible [2]. Many hospitals in LMICs lack time and resources needed to analyze the data (particularly to deduplicate data and to generate tables and figures), write the reports, and to release the data or reports [4].</p>
    <p class="prose">AutoMated tool for Antimicrobial resistance Surveillance System (AMASS) was developed as an offline, open-access and easy-to-use application that allows a hospital to perform data analysis independently and generate AMR proportion and AMR frequency reports stratified by infection origin from routinely collected electronic databases. The application was built in a free software environment. AMASS application can be downloaded at: <a href="https://www.amass.website">https://www.amass.website</a></p>
    <?php amass_foot($created); ?>
</div>

<div class="sheet page">
    <p class="prose">In 2022, AMASS team started working and conducting research with the Ministry of Public Health (MoPH) Thailand to implement AMASS in all 126 tertiary-care and secondary-care hospitals of the MoPH. At the local level, each hospital gain an ability to (a) monitor not only AMR proportions (%), but also AMR frequencies (e.g. per 100,000 admissions, per 100,000 bed-days and per 100,000 tested patients) and mortality of AMR infections, (b) identify outbreaks (i.e. clusters) of AMR infections and, (c) identify wards that are hyper-endemic with AMR infections (i.e. high rates but not counted as clusters) [4, 5] At the national level, the MoPH can now identify the hospitals with highest burden of AMR and provide audits on AMS and IPC implementation [4, 5]. The key performance indicator to monitor AMR by MoPH has been changed to AMR frequency.</p>
    <p class="prose">We wish that AMASS can support hospitals and policy makers in all LMICs to be able to utilize their electronic data for their local and national actions.</p>
    <p class="prose">AMASS version 4.0 additional generates reports on antimicrobial use (AMU), antimicrobial stewardship practice (AMS, under construction) and diagnostic stewardship practice (under construction) in Annex D. A careful review of the Annex D and Supplementary_data_Annex_D is strongly recommended.</p>
    <hr class="ref-rule">
    <p class="prose"><b>References:</b></p>
    <p class="foot">[1] Antimicrobial Resistance Collaborators. (2022). Global burden of bacterial antimicrobial resistance in 2019: A systematic analysis. The Lancet, 399(10325), 629–655.</p>
    <p class="foot">[2] World Health Organization (2018) Global Antimicrobial Resistance Surveillance System (GLASS) Report. Early implantation 2016-2017.</p>
    <p class="foot">[3] Lim C., et al. (2016) Epidemiology and burden of multidrug-resistant bacterial infection in a developing country. Elife 5: e18082.</p>
    <p class="foot">[4] Ashley EA, Shetty N, Patel J, et al. Harnessing alternative sources of antimicrobial resistance data to support surveillance in low-resource settings. J Antimicrob Chemother. 2019; 74(3):541-546.</p>
    <p class="foot">[5] Clinical and Laboratory Standards Institute (CLSI). Analysis and Presentation of Cumulative Antimicrobial Susceptibility Test Data, 4th Edition. 2014.</p>
    <p class="foot">[6] European Antimicrobial Resistance Surveillance Network (EARS-Net). Antimicrobial resistance (AMR) reporting protocol 2018.</p>
    <p class="foot">[7] European Committee on Antimicrobial Susceptibility Testing (EUCAST). www.eucast.org</p>
    <?php amass_foot($created); ?>
</div>

<div class="sheet page" id="section-1">
    <p class="sec-title">Section [1]: Data overview</p>
    <p class="sub-title">Introduction</p>
    <p class="prose">An overview of the data detected by AMASS application is generated by default. The summary is based on the raw data files saved within the same folder as the application file (AMASS.bat).</p>
    <p class="prose">Please review and validate this section carefully before proceeds to the next section.</p>
    <p class="sub-title">Results</p>
    <p class="prose">The microbiology data file (stored in the same folder as the application file) had:</p>
    <p class="prose indent"><?php echo amass_hi(amass_int($micro_n)); ?> specimen data records with collection dates ranging from</p>
    <p class="prose indent"><?php echo amass_hi(amass_fmt_date($micro_min)); ?> to <?php echo amass_hi(amass_fmt_date($micro_max)); ?></p>
    <p class="prose">The hospital admission data file (stored in the same folder as the application file) had:</p>
    <p class="prose indent"><?php echo amass_hi(amass_int($adm_n)); ?> admission data records with hospital admission dates ranging from</p>
    <p class="prose indent"><?php echo amass_hi(amass_fmt_date($adm_min)); ?> to <?php echo amass_hi(amass_fmt_date($adm_max)); ?></p>
    <p class="prose indent">The total number of patient-days was <?php echo amass_hi(amass_int($pdays)); ?>.</p>
    <p class="prose indent">The total number of patient-days at risk of BSI of hospital-origin was <?php echo amass_hi(amass_int($pdays_his)); ?>.</p>
    <p class="sub-title note">Note:</p>
    <p class="note-block">[1] If the periods of the data in microbiology data and hospital admission data files are not similar, the automatically-generated report should be interpreted with caution. AMASS generates the reports based on the available data.</p>
    <p class="note-block">[2] A patient is defined as at risk of BSI of hospital-origin when the patient is admitted to the hospital for more than two calendar days with calendar day one equal to the day of admission.</p>
    <?php amass_foot($created, 'Section 1'); ?>
</div>

<div class="sheet page">
    <p class="sub-title">Reporting period by months:</p>
    <p class="prose">Data was stratified by month to assist detection of missing data, and verification of whether the month distribution of data records in microbiology data file and hospital admission data file reflected the microbiology culture frequency and admission rate of the hospital, respectively. For example if the number of specimens in the microbiology data file reported below is lower than what is expected, please check the raw data file and data dictionary files.</p>
    <?php if (!empty($tables['section1month'])): ?>
    <table class="amass count">
        <thead>
            <tr>
                <th>Month</th>
                <th>Number of specimen<br>data records in<br>microbiology data file</th>
                <th>Number of admission<br>data records in<br>hospital admission data file</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($tables['section1month'] as $row): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['Month'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_specimen_in_microbiology_data_file'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_hospital_records_in_hospital_admission_data_file'] ?? '')); ?></td>
            </tr>
        <?php endforeach; ?>
            <tr class="total">
                <td>Total:</td>
                <td class="num"><?php echo htmlspecialchars(amass_int(amass_sum_col($tables['section1month'], 'Number_of_specimen_in_microbiology_data_file'))); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int(amass_sum_col($tables['section1month'], 'Number_of_hospital_records_in_hospital_admission_data_file'))); ?></td>
            </tr>
        </tbody>
    </table>
    <?php else: ?>
    <p class="prose"><i>Monthly counts will appear after the analysis is re-run in THAM Hos-Safe.</i></p>
    <?php endif; ?>
    <?php amass_foot($created, 'Section 1'); ?>
</div>

<div class="sheet page" id="section-2">
    <p class="sec-title">Section [2]: AMR proportion report</p>
    <p class="sub-title">Introduction</p>
    <p class="prose">An AMR proportion report is generated by default, even if the hospital admission data file is unavailable. This is to enable hospitals with only microbiology data available to utilize the de-duplication and report generation functions of AMASS. This report is without stratification by origin of infection.</p>
    <p class="prose">The report generated by AMASS application version 3.1 includes only blood samples. The next version of AMASS will include other specimen types, including cerebrospinal fluid (CSF), urine, stool, and other specimens.</p>
    <p class="sub-title">Organisms under this surveillance:</p>
    <?php foreach ($org_list as $org): ?>
    <p class="prose indent">− <?php echo amass_org($org); ?></p>
    <?php endforeach; ?>
    <p class="sub-title">Results</p>
    <p class="prose">The microbiology data file had:</p>
    <p class="prose indent"><i>Sample collection dates ranged from</i> <?php echo amass_hi(amass_fmt_date($micro_min)); ?> to <?php echo amass_hi(amass_fmt_date($micro_max)); ?></p>
    <p class="prose indent"><i>Number of records of blood specimens collected within the above date range:</i></p>
    <p class="prose indent"><?php echo amass_hi(amass_int($blo_num) . ' blood specimen records'); ?></p>
    <p class="prose indent2"><i>Number of records of blood specimens with *negative culture (no growth):</i></p>
    <p class="prose indent2"><?php echo amass_hi(amass_int($blo_neg) . ' blood specimen records'); ?></p>
    <p class="prose indent2"><i>Number of records of blood specimens with culture positive for a microorganism:</i></p>
    <p class="prose indent2"><?php echo amass_hi(amass_int($blo_pos) . ' blood specimen records'); ?></p>
    <p class="prose indent2"><i>Number of records of blood specimens with culture positive for organism under this surveillance:</i></p>
    <p class="prose indent2"><?php echo amass_hi(amass_int($blo_pos_org) . ' blood specimen records'); ?></p>
    <?php amass_foot($created, 'Section 2'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Section [2]: AMR proportion report</p>
    <p class="prose">AMASS application de-duplicated the data by including only the first isolate per patient per specimen type per evaluation period as described in the method. The number of patients with positive samples is as follows:</p>
    <table class="amass count">
        <thead>
            <tr>
                <th>Organism</th>
                <th>Number of records<br>of blood specimens<br>culture positive<br>for the organism</th>
                <th>**Number of patients with<br>blood culture positive<br>for the organism<br>(de-duplicated)</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $raw_map = [];
        foreach ($tables['byorg_raw'] ?? [] as $row) {
            $raw_map[(string)($row['Organism'] ?? '')] = $row['Number_of_blood_specimens_culture_positive_for_the_organism'] ?? '';
        }
        $sum_raw = 0;
        $sum_ded = 0;
        foreach ($tables['byorg'] ?? [] as $row):
            $org = $row['Organism'] ?? '';
            $raw = $raw_map[$org] ?? '';
            $ded = $row['Number_of_blood_specimens_culture_positive_deduplicated'] ?? '';
            if (is_numeric($raw)) {
                $sum_raw += (int)$raw;
            }
            if (is_numeric($ded)) {
                $sum_ded += (int)$ded;
            }
        ?>
            <tr>
                <td class="org"><?php echo htmlspecialchars($org); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($raw)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($ded)); ?></td>
            </tr>
        <?php endforeach; ?>
            <tr class="total">
                <td class="org">Total:</td>
                <td class="num"><?php echo htmlspecialchars(amass_int($sum_raw)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($sum_ded)); ?></td>
            </tr>
        </tbody>
    </table>
    <p class="note-block">*The negative culture included data values specified as "no growth" in the dictionary file for microbiology data (details on data dictionary files are in the method section) to represent specimens with negative culture for any microorganism.</p>
    <p class="note-block">**Only the first isolate for each patient per specimen type, per pathogen, and per evaluation period was included in the analysis.</p>
    <p class="prose">The following figures and tables show the proportion of patients with blood culture positive for antimicrobial resistant isolates.</p>
    <?php amass_foot($created, 'Section 2'); ?>
</div>

<?php foreach ($sec2_by as $org => $rows):
    $npat = $byorg_n[$org] ?? 0;
?>
<div class="sheet page">
    <p class="sec-title">Section [2]: AMR proportion report</p>
    <p class="org-head"><b>Blood: <?php echo amass_org($org); ?></b>
        <span class="right"><?php echo amass_hi('( No. of patients = ' . amass_int($npat) . ' )'); ?></span></p>
    <?php amass_render_amr_table($rows, $npat); ?>
    <p class="foot"><?php echo htmlspecialchars($amr_note); ?></p>
    <?php amass_foot($created, 'Section 2'); ?>
</div>
<?php endforeach; ?>

<div class="sheet page" id="section-3">
    <p class="sec-title">Section [3]: AMR proportion report</p>
    <p class="sec-title sub">with stratification by infection origin</p>
    <p class="sub-title">Introduction</p>
    <p class="prose">An AMR proportion report with stratification by origin of infection is generated only if admission date data are available in the raw data file(s) with the appropriate specification in the data dictionaries.</p>
    <p class="prose">Stratification by origin of infection is used as a proxy to define where the bloodstream infection (BSI) was contracted (hospital versus community).</p>
    <p class="prose">The definitions of infection origin proposed by the WHO GLASS are used. In brief, community-origin BSI is defined as patients in the hospital for less than or equal to two calendar days when the first specimen culture positive for the pathogen was taken. Hospital-origin BSI is defined as patients admitted for more than two calendar days when the first specimen culture positive for the pathogen was taken.</p>
    <p class="sub-title">Results</p>
    <p class="prose">The data included in the analysis to generate the report had:</p>
    <p class="prose indent"><i>Sample collection dates ranged from</i> <?php echo amass_hi(amass_fmt_date($micro_min)); ?> <i>to</i> <?php echo amass_hi(amass_fmt_date($micro_max)); ?></p>
    <p class="prose indent"><i>*Number of patients with blood culture positive for pathogen under the surveillance:</i></p>
    <p class="prose indent"><?php echo amass_hi(amass_int($n_bsi) . ' patients'); ?></p>
    <p class="prose indent2"><i>**Number of patients with community-origin BSI:</i></p>
    <p class="prose indent2"><?php echo amass_hi(amass_int($n_com) . ' patients'); ?></p>
    <p class="prose indent2"><i>**Number of patients with hospital-origin BSI:</i></p>
    <p class="prose indent2"><?php echo amass_hi(amass_int($n_hos) . ' patients'); ?></p>
    <p class="prose indent2"><i>***Number of patients with unknown infection of origin status:</i></p>
    <p class="prose indent2"><?php echo amass_hi(amass_int($n_unk) . ' patients'); ?></p>
    <?php amass_foot($created, 'Section 3'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Section [3]: AMR proportion report</p>
    <p class="sec-title sub">with stratification by infection origin</p>
    <table class="amass count">
        <thead>
            <tr>
                <th>Organism</th>
                <th>Number of patients with<br>blood culture positive<br>for the organism</th>
                <th>Community<br>-origin**</th>
                <th>Hospital<br>-origin**</th>
                <th>Unknown<br>-origin***</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $t_all = 0; $t_c = 0; $t_h = 0; $t_u = 0;
        foreach ($tables['byorg'] ?? [] as $row):
            $org = $row['Organism'] ?? '';
            $all = (int)($row['Number_of_blood_specimens_culture_positive_deduplicated'] ?? 0);
            $c = (int)($pat_origin[$org]['Community-origin'] ?? 0);
            $h = (int)($pat_origin[$org]['Hospital-origin'] ?? 0);
            $u = max(0, $all - $c - $h);
            $t_all += $all; $t_c += $c; $t_h += $h; $t_u += $u;
        ?>
            <tr>
                <td class="org"><?php echo htmlspecialchars($org); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($all)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($c)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($h)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($u)); ?></td>
            </tr>
        <?php endforeach; ?>
            <tr class="total">
                <td class="org">Total:</td>
                <td class="num"><?php echo htmlspecialchars(amass_int($t_all)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($t_c)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($t_h)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($t_u)); ?></td>
            </tr>
        </tbody>
    </table>
    <p class="sub-title note">Note</p>
    <p class="note-block">NA=not applicable (hospital admission date or infection origin data are not available)</p>
    <p class="note-block">*Only the first isolate for each patient per specimen type per pathogen under the reporting period is included in the analysis. Please refer to Section [2] for details on how this number was calculated from the raw microbiology data file.</p>
    <p class="note-block">**The definitions of infection origin proposed by the WHO GLASS is used. In brief, community-origin BSI was defined as patients in the hospital for less than or equal to two calendar days when the first blood culture positive for the pathogen was taken. Hospital-origin BSI was defined as patients admitted for more than two calendar days when the first specimen culture positive for the pathogen was taken.</p>
    <p class="note-block">***Unknown origin could be because admission date data are not available or the patient was not hospitalised.</p>
    <p class="prose">The following figures and tables below show the proportion of patients with blood culture positive for antimicrobial resistant isolates stratified by infection of origin.</p>
    <?php amass_foot($created, 'Section 3'); ?>
</div>

<?php foreach ($sec3_by_org as $org => $by_origin):
    $n_c = $pat_origin[$org]['Community-origin'] ?? ($byorg_n[$org] ?? 0);
    $n_h = $pat_origin[$org]['Hospital-origin'] ?? 0;
?>
<div class="sheet page">
    <p class="sec-title">Section [3]: AMR proportion report</p>
    <p class="sec-title sub">with stratification by infection origin</p>
    <p class="org-head"><b>Blood: <?php echo amass_org($org); ?></b></p>
    <p class="prose"><b>Community-origin</b> <?php echo amass_hi('( No. of patients = ' . amass_int($n_c) . ' )'); ?></p>
    <?php amass_render_amr_table($by_origin['Community-origin'] ?? [], (int)$n_c); ?>
    <p class="prose"><b>Hospital-origin</b> <?php echo amass_hi('( No. of patients = ' . amass_int($n_h) . ' )'); ?></p>
    <?php amass_render_amr_table($by_origin['Hospital-origin'] ?? [], (int)$n_h); ?>
    <p class="foot"><?php echo htmlspecialchars($amr_note); ?></p>
    <?php amass_foot($created, 'Section 3'); ?>
</div>
<?php endforeach; ?>

<div class="sheet page" id="section-4">
    <p class="sec-title">Section [4]: AMR frequency report</p>
    <p class="sub-title">Introduction</p>
    <p class="prose">For each pathogen and antibiotic under surveillance, the frequencies of patients with new infections are calculated per 100,000 tested patients.</p>
    <p class="sub-title">Results</p>
    <p class="prose">The microbiology data file had:</p>
    <p class="prose indent"><i>Specimen collection dates ranged from</i> <?php echo amass_hi(amass_fmt_date($micro_min)); ?> <i>to</i> <?php echo amass_hi(amass_fmt_date($micro_max)); ?></p>
    <p class="prose indent"><i>Number of records on blood specimens collected within the above date range:</i></p>
    <p class="prose indent"><?php echo amass_hi(amass_int($blo_num) . ' blood specimen records'); ?></p>
    <p class="prose indent"><i>*Number of patients sampled for blood culture within the above date range:</i></p>
    <p class="prose indent"><?php echo amass_hi(amass_int($n_blood_pat) . ' patients sampled for blood culture'); ?></p>
    <p class="sub-title note">Note</p>
    <p class="note-block">*Number of patients sampled for blood culture is used as denominator to estimate the frequency of infections per 100,000 tested patients</p>
    <p class="prose">The following figures show the frequency of infections for patients with blood culture tested.</p>
    <?php amass_foot($created, 'Section 4'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Section [4]: AMR frequency report</p>
    <p class="org-head"><b>Blood: Pathogens</b>
        <span class="right"><?php echo amass_hi('( No. of patients = ' . amass_int($n_blood_pat) . ' )'); ?></span></p>
    <?php if (!empty($tables['section4freq'])): ?>
    <table class="amass">
        <thead>
            <tr>
                <th>Organism</th>
                <th>Patients (n)</th>
                <th>Frequency per<br>100,000 tested</th>
                <th>95% CI</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($tables['section4freq'] as $row): ?>
            <tr>
                <td class="org"><?php echo htmlspecialchars($row['Organism'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_patients'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['frequency_per_tested'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['frequency_per_tested_lci'] ?? '') . ' – ' . amass_num($row['frequency_per_tested_uci'] ?? '')); ?></td>
            </tr>
        <?php endforeach;
            $t4 = amass_freq_total($tables['section4freq'], is_numeric($n_blood_pat) ? $n_blood_pat : 0);
        ?>
            <tr class="total">
                <td class="org">Total:</td>
                <td class="num"><?php echo htmlspecialchars(amass_int($t4['n'])); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($t4['rate'])); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($t4['lo']) . ' – ' . amass_num($t4['hi'])); ?></td>
            </tr>
        </tbody>
    </table>
    <?php else: ?>
    <p class="prose"><i>Frequency per 100,000 tested patients will appear after the analysis is re-run.</i></p>
    <?php endif; ?>
    <p class="foot">*Frequency of infection per 100,000 tested patients represents the number of patients with blood culture positive for a pathogen (numerator) over the total number of tested patients (denominator). AMASS application de-duplicates the data by included only the first isolate of each patient per specimen type per reporting period. CI=confidence interval; R=resistant; NA=not available/reported/tested</p>
    <?php amass_foot($created, 'Section 4'); ?>
</div>

<div class="sheet page" id="section-5">
    <p class="sec-title">Section [5]: AMR frequency report</p>
    <p class="sec-title sub">with stratification by infection origin</p>
    <p class="sub-title">Introduction</p>
    <p class="prose">For each infection origin, pathogen and antibiotic under surveillance, the frequencies of patients with new infections are calculated per 100,000 tested patients.</p>
    <p class="sub-title">Results</p>
    <p class="prose">The data included in the analysis had:</p>
    <p class="prose indent"><i>Specimen collection dates ranged from</i> <?php echo amass_hi(amass_fmt_date($micro_min)); ?> to <?php echo amass_hi(amass_fmt_date($micro_max)); ?></p>
    <p class="prose indent"><i>Number of records on blood specimens collected within the above date range:</i></p>
    <p class="prose indent"><?php echo amass_hi(amass_int($blo_num) . ' blood specimen records'); ?></p>
    <p class="prose indent"><i>Number of patients sampled for blood culture within the above date range:</i></p>
    <p class="prose indent"><?php echo amass_hi(amass_int($n_blood_pat) . ' patients sampled for blood culture'); ?></p>
    <p class="prose indent2"><?php echo amass_hi(amass_int($n_tested_com)); ?> <i>patients had at least one admission having the first blood culture drawn within first 2 calendar days of hospital admission.</i></p>
    <p class="prose indent2"><i>This parameter is used as a denominators for frequency of community-origin bacteraemia (per 100,000 patients tested for blood culture on admission).</i></p>
    <p class="prose indent2"><?php echo amass_hi(amass_int($n_tested_hos)); ?> <i>patients had at least one admission having the first blood culture drawn after 2 calendar days of hospital admission.</i></p>
    <p class="prose indent2"><i>This parameter is used as a denominators for frequency of hospital-origin bacteraemia (per 100,000 patients tested for blood culture for HAI).</i></p>
    <p class="prose indent2"><?php echo amass_hi(amass_int($n_tested_unk)); ?> <i>patients had a blood drawn for culture and with unknown origin of infection.</i></p>
    <p class="prose indent2"><i>Validation of this statistics is highly recommended.</i></p>
    <?php amass_foot($created, 'Section 5'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Section [5]: AMR frequency report</p>
    <p class="sec-title sub">with stratification by infection origin</p>
    <p class="sub-title">Community-origin</p>
    <table class="amass">
        <thead>
            <tr>
                <th>Organism</th>
                <th>Patients (n)</th>
                <th>Tested patients</th>
                <th>Frequency per<br>100,000 tested</th>
                <th>95% CI</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach (($tables['section5c_freq'] ?? []) as $row): ?>
            <tr>
                <td class="org"><?php echo htmlspecialchars($row['Organism'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_patients'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Tested_patients'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['frequency_per_tested'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['frequency_per_tested_lci'] ?? '') . ' – ' . amass_num($row['frequency_per_tested_uci'] ?? '')); ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!empty($tables['section5c_freq'])):
            $t5c = amass_freq_total($tables['section5c_freq'], $tables['section5c_freq'][0]['Tested_patients'] ?? $n_tested_com);
        ?>
            <tr class="total">
                <td class="org">Total:</td>
                <td class="num"><?php echo htmlspecialchars(amass_int($t5c['n'])); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($tables['section5c_freq'][0]['Tested_patients'] ?? $n_tested_com)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($t5c['rate'])); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($t5c['lo']) . ' – ' . amass_num($t5c['hi'])); ?></td>
            </tr>
        <?php endif; ?>
        <?php if (empty($tables['section5c_freq'])): ?>
            <tr><td colspan="5"><i>Re-run analysis to fill frequency by origin. Incidence per 100,000 patient-days (previous engine output) is shown below if available.</i></td></tr>
            <?php foreach (($tables['section5c'] ?? []) as $row): ?>
            <tr>
                <td class="org"><?php echo htmlspecialchars($row['Organism'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_patients'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Patient_days'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['Incidence_per_100000_patient_days'] ?? '')); ?></td>
                <td class="num">—</td>
            </tr>
            <?php endforeach; ?>
            <?php if (!empty($tables['section5c'])): ?>
            <tr class="total">
                <td class="org">Total:</td>
                <td class="num"><?php echo htmlspecialchars(amass_int(amass_sum_col($tables['section5c'], 'Number_of_patients'))); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($tables['section5c'][0]['Patient_days'] ?? '')); ?></td>
                <td class="num"></td>
                <td class="num"></td>
            </tr>
            <?php endif; ?>
        <?php endif; ?>
        </tbody>
    </table>
    <p class="sub-title">Hospital-origin</p>
    <table class="amass">
        <thead>
            <tr>
                <th>Organism</th>
                <th>Patients (n)</th>
                <th>Tested patients</th>
                <th>Frequency per<br>100,000 tested</th>
                <th>95% CI</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach (($tables['section5h_freq'] ?? []) as $row): ?>
            <tr>
                <td class="org"><?php echo htmlspecialchars($row['Organism'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_patients'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Tested_patients'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['frequency_per_tested'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['frequency_per_tested_lci'] ?? '') . ' – ' . amass_num($row['frequency_per_tested_uci'] ?? '')); ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!empty($tables['section5h_freq'])):
            $t5h = amass_freq_total($tables['section5h_freq'], $tables['section5h_freq'][0]['Tested_patients'] ?? $n_tested_hos);
        ?>
            <tr class="total">
                <td class="org">Total:</td>
                <td class="num"><?php echo htmlspecialchars(amass_int($t5h['n'])); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($tables['section5h_freq'][0]['Tested_patients'] ?? $n_tested_hos)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($t5h['rate'])); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($t5h['lo']) . ' – ' . amass_num($t5h['hi'])); ?></td>
            </tr>
        <?php endif; ?>
        <?php if (empty($tables['section5h_freq'])): ?>
            <?php foreach (($tables['section5h'] ?? []) as $row): ?>
            <tr>
                <td class="org"><?php echo htmlspecialchars($row['Organism'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_patients'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Patient_days'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['Incidence_per_100000_patient_days'] ?? '')); ?></td>
                <td class="num">—</td>
            </tr>
            <?php endforeach; ?>
            <?php if (!empty($tables['section5h'])): ?>
            <tr class="total">
                <td class="org">Total:</td>
                <td class="num"><?php echo htmlspecialchars(amass_int(amass_sum_col($tables['section5h'], 'Number_of_patients'))); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($tables['section5h'][0]['Patient_days'] ?? '')); ?></td>
                <td class="num"></td>
                <td class="num"></td>
            </tr>
            <?php endif; ?>
        <?php endif; ?>
        </tbody>
    </table>
    <p class="foot">*Frequency of infection per 100,000 tested patients represents the number of patients with blood culture positive for a pathogen (numerator) over the total number of tested patients of that origin (denominator). AMASS application de-duplicates the data by included only the first isolate of each patient per specimen type per reporting period.</p>
    <?php amass_foot($created, 'Section 5'); ?>
</div>

<div class="sheet page" id="section-6">
    <p class="sec-title">Section [6] Mortality involving AMR and</p>
    <p class="sec-title sub">antimicrobial-susceptible infections</p>
    <p class="sub-title">Introduction</p>
    <p class="prose">A surveillance report on mortality involving AMR infections and antimicrobial-susceptible infections with stratification by origin of infection is generated only if data on patient outcomes (i.e. discharge status) are available. Antimicrobial-resistant infection is a threat to modern health care, and the impact of the infection on patient outcomes is largely unknown. Performing analyses and generating reports on mortality often takes time and resources.</p>
    <p class="prose">The term "mortality involving AMR and antimicrobial-susceptible infections" was used because the mortality reported was all-cause mortality. This measure of mortality included deaths caused by or related to other underlying and intermediate causes.</p>
    <p class="prose">Here, AMASS summarized the overall mortality of patients with antimicrobial-resistant and antimicrobial-susceptible bacteria bloodstream infections (BSI).</p>
    <p class="sub-title">Results</p>
    <p class="prose">The data included in the analysis had:</p>
    <p class="prose indent"><i>Sample collection dates ranged from</i> <?php echo amass_hi(amass_fmt_date($micro_min)); ?> to <?php echo amass_hi(amass_fmt_date($micro_max)); ?></p>
    <p class="prose indent"><i>Number of patients with blood culture positive for the organism under the surveillance:</i></p>
    <p class="prose indent"><?php echo amass_hi(amass_int($n_bsi) . ' patients'); ?></p>
    <p class="prose indent2"><i>Number of patients with community-origin BSI:</i> <?php echo amass_hi(amass_int($n_com) . ' patients'); ?></p>
    <p class="prose indent2"><i>Number of patients with hospital-origin BSI:</i> <?php echo amass_hi(amass_int($n_hos) . ' patients'); ?></p>
    <p class="prose">The hospital admission data file had:</p>
    <p class="prose indent"><i>Hospital admission dates ranging from</i> <?php echo amass_hi(amass_fmt_date($adm_min)); ?> to <?php echo amass_hi(amass_fmt_date($adm_max)); ?></p>
    <p class="prose indent"><i>Number of records in the raw hospital admission data:</i> <?php echo amass_hi(amass_int($adm_n) . ' records'); ?></p>
    <p class="prose indent"><i>Number of patients included in the analysis (de-duplicated):</i> <?php echo amass_hi(amass_int($n_adm_pat) . ' patients'); ?></p>
    <p class="prose indent2"><i>Number of patients having death as an outcome in any admission data records:</i> <?php echo amass_hi(amass_int($n_adm_dead) . ' patients'); ?></p>
    <p class="prose indent2"><i>Overall mortality:</i> <?php echo amass_hi($mort_overall === 'NA' ? 'NA' : ($mort_overall . '%')); ?></p>
    <?php amass_foot($created, 'Section 6'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Section [6] Mortality involving AMR and</p>
    <p class="sec-title sub">antimicrobial-susceptible infections</p>
    <p class="prose">AMASS application merged the microbiology data file and hospital admission data file. The merged dataset was then de-duplicated so that only the first isolate per patient per specimen per reporting period was included in the analysis. The de-duplicated data was stratified by infection origin (community-origin infection or hospital-origin infection).</p>
    <table class="amass count">
        <thead>
            <tr>
                <th>Organism</th>
                <th>Mortality in patients with<br>Community-origin BSI</th>
                <th>Mortality in patients with<br>Hospital-origin BSI</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $mort_map = [];
        foreach ($tables['section6'] ?? [] as $row) {
            $mort_map[(string)($row['Organism'] ?? '')][(string)($row['Infection_origin'] ?? '')] = $row;
        }
        $com_rows = [];
        $hos_rows = [];
        foreach ($org_list as $org) {
            $com_rows[] = $mort_map[$org]['Community-origin'] ?? [];
            $hos_rows[] = $mort_map[$org]['Hospital-origin'] ?? [];
        ?>
            <tr>
                <td class="org"><?php echo htmlspecialchars($org); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_mort_cell($mort_map[$org]['Community-origin'] ?? null)); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_mort_cell($mort_map[$org]['Hospital-origin'] ?? null)); ?></td>
            </tr>
        <?php
        }
        $tcom = amass_mort_total($com_rows);
        $thos = amass_mort_total($hos_rows);
        ?>
            <tr class="total">
                <td class="org">Total:</td>
                <td class="num"><?php echo $tcom['n'] > 0 ? htmlspecialchars($tcom['pct'] . '% (' . $tcom['d'] . '/' . $tcom['n'] . ')') : 'NA'; ?></td>
                <td class="num"><?php echo $thos['n'] > 0 ? htmlspecialchars($thos['pct'] . '% (' . $thos['d'] . '/' . $thos['n'] . ')') : 'NA'; ?></td>
            </tr>
        </tbody>
    </table>
    <p class="prose">The following tables show the mortality of patients who were blood culture positive for antimicrobial resistant and susceptible isolates.</p>
    <?php amass_foot($created, 'Section 6'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Section [6] Mortality involving AMR and</p>
    <p class="sec-title sub">antimicrobial-susceptible infections</p>
    <table class="amass">
        <thead><tr><th>Organism</th><th>Origin</th><th>Deaths (n)</th><th>Patients (n)</th><th>Mortality (%)</th><th>95% CI</th></tr></thead>
        <tbody>
        <?php foreach (($tables['section6'] ?? []) as $row): ?>
            <tr>
                <td class="org"><?php echo htmlspecialchars($row['Organism'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($row['Infection_origin'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['Number_of_deaths'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['Total_number_of_patients'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['Mortality(%)'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['Mortality_lower_95ci'] ?? '') . '% - ' . amass_num($row['Mortality_upper_95ci'] ?? '') . '%'); ?></td>
            </tr>
        <?php endforeach;
            $tm6 = amass_mort_total($tables['section6'] ?? []);
        ?>
            <tr class="total">
                <td class="org">Total:</td>
                <td></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($tm6['d'])); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($tm6['n'])); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($tm6['pct'])); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($tm6['lo']) . '% - ' . amass_num($tm6['hi']) . '%'); ?></td>
            </tr>
        </tbody>
    </table>
    <p class="foot">*Mortality is the proportion (%) of in-hospital deaths (all-cause deaths). This represents the number of in-hospital deaths (numerator) over the total number of patients with blood culture positive for the organism (denominator). AMASS application de-duplicates the data by included only the first isolate per patient per specimen type per evaluation period. R=resistant; S=susceptible (including sensitive and intermediate categories); CI=confidence interval</p>
    <?php amass_foot($created, 'Section 6'); ?>
</div>

<div class="sheet page" id="annex-a">
    <p class="sec-title">Annex A: Supplementary report on notifiable bacterial</p>
    <p class="sec-title sub">diseases</p>
    <p class="prose">Supplementary report on notifiable bacterial disease is not applicable in this THAM Hos-Safe run. Official AMASS.bat on Windows generates Annex A from the same microbiology data file.</p>
    <?php amass_foot($created, 'Annex A'); ?>
</div>

<?php
$ann_b = $tables['annex_b'] ?? [];
$ann_b_m = $tables['annex_b_month'] ?? [];
$ann_b_c = $tables['annex_b_cont'] ?? [];
$ann_c = $tables['annex_c'] ?? [];
$ann_c_w = $tables['annex_c_ward'] ?? [];
$ann_d_s = $tables['annex_d_summary'] ?? [];
$ann_d_m = $tables['annex_d_month'] ?? [];
$ann_d_r = $tables['annex_d_route'] ?? [];
$ann_d_dot = $tables['annex_d_dot'] ?? [];
$ann_d_aw = $tables['annex_d_aware'] ?? [];
$ann_d_dp = $tables['annex_d_dept'] ?? [];
$ann_d_atf = $tables['annex_d_atf'] ?? [];
$d_prev = amass_kv($ann_d_s, 'AMU_prevalence_parenteral_antibiotic_text', 'NA');
$d_dot = amass_kv($ann_d_s, 'total_dot_parenteral_antibiotic', 'NA');
$d_lot = amass_kv($ann_d_s, 'total_lot_parenteral_antibiotic', 'NA');
$d_ptd = amass_kv($ann_d_s, 'patient_days_exclude_dayadmission', 'NA');
$d_ndrug = amass_kv($ann_d_s, 'Number_of_drug_records', 'NA');
$d_natb = amass_kv($ann_d_s, 'Number_of_antibiotic_records', 'NA');
$d_natf = amass_kv($ann_d_s, 'Number_of_antifungal_records', 'NA');
$dmin_d = amass_kv($ann_d_s, 'Minimum_Drug_Start_date', 'NA');
$dmax_d = amass_kv($ann_d_s, 'Maximum_Drug_Start_date', 'NA');
?>
<div class="sheet page" id="annex-b">
    <p class="sec-title">Annex B: Supplementary report on data indicators</p>
    <p class="prose">This annex summarises data-quality indicators from blood-culture records, following AMASS version 4.0 Annex B. Possible contaminants are organisms that commonly represent skin flora in blood (coagulase-negative staphylococci, <i>Corynebacterium</i> spp., <i>Bacillus</i> spp., <i>Micrococcus</i> spp., <i>Cutibacterium</i> spp., and viridans-group streptococci). Notifiable antibiotic–pathogen combinations follow WHO GLASS priority AMR phenotypes (MRSA, VRE, CRE, CRAB, CRPA, 3GC-R Enterobacterales, fluoroquinolone-resistant <i>Salmonella</i>). Potential AST errors include intrinsic-resistance violations and discordant results (for example carbapenem-R with 3GC-S among Enterobacterales).</p>
    <table class="amass">
        <thead>
            <tr>
                <th>Indicator</th>
                <th>Number</th>
                <th>Denominator</th>
                <th>Proportion</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($ann_b)): ?>
            <tr><td colspan="4">NA — re-run analysis after extracting microbiology data</td></tr>
        <?php else: foreach ($ann_b as $row): ?>
            <tr>
                <td class="left"><?php echo htmlspecialchars($row['Description'] ?? $row['Indicators'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Denominator'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['Proportion'] ?? '')); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <p class="foot">Denominator for contamination is all blood cultures (positive and negative). Denominator for notifiable combinations and AST errors is de-duplicated blood isolates with at least one AST result. Inpatient contamination uses blood cultures matched to a hospital admission.</p>
    <?php amass_foot($created, 'Annex B'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Annex B: Data indicators by month</p>
    <table class="amass">
        <thead>
            <tr>
                <th>Month</th>
                <th>Contamination rate</th>
                <th>Notifiable AMR combinations</th>
                <th>Potential AST errors</th>
                <th>Blood cultures (N)</th>
                <th>Blood with AST (N)</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($ann_b_m)): ?>
            <tr><td colspan="6">NA</td></tr>
        <?php else: foreach ($ann_b_m as $row):
            $is_tot = ((string)($row['Month'] ?? '')) === 'Total:';
        ?>
            <tr<?php echo $is_tot ? ' class="total"' : ''; ?>>
                <td><?php echo htmlspecialchars($row['Month'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['blood_culture_contamination_rate'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['notifiable_antibiotic_pathogen'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['potential_AST_errors'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Total_blood_positive_and_negative(N)'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Total_blood_positive_AST(N)'] ?? '')); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <p class="sub-title">Possible contaminants isolated from blood</p>
    <table class="amass">
        <thead><tr><th>Organism</th><th>Number</th><th>% of contaminants</th></tr></thead>
        <tbody>
        <?php if (empty($ann_b_c)): ?>
            <tr><td colspan="3">No possible contaminants identified in this period</td></tr>
        <?php else: foreach ($ann_b_c as $row):
            $is_tot = ((string)($row['Organism'] ?? '')) === 'Total:';
        ?>
            <tr<?php echo $is_tot ? ' class="total"' : ''; ?>>
                <td class="<?php echo $is_tot ? '' : 'org'; ?> left"><?php echo $is_tot ? 'Total:' : amass_org($row['Organism'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_possible_contaminants'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['Percent_of_contaminants'] ?? '')); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <?php amass_foot($created, 'Annex B'); ?>
</div>

<div class="sheet page" id="annex-c">
    <p class="sec-title">Annex C: Cluster signals</p>
    <p class="prose">Official AMASS version 4.0 identifies clusters with SaTScan (Windows-only). On this Linux server, THAM Hos-Safe runs a <b>simplified Poisson ward-week scan</b> of hospital-origin blood isolates with priority AMR phenotypes (MRSA, VREfs, VREfm, CREC, CRKP, CRPA, CRAB). A ward-week is listed when at least 2 isolates are observed and either the Poisson p-value is &lt; 0.05 or the observed/expected ratio is ≥ 2. Expected counts use the pathogen’s hospital-origin total, the ward’s share of hospital-origin blood isolates, and the number of ISO weeks in the period.</p>
    <p class="note-block">This is not SaTScan. Do not treat p-values as equivalent to the official AMASS Annex C Monte-Carlo scan. Run AMASS.bat on Windows if a SaTScan report is required.</p>
    <table class="amass">
        <thead>
            <tr>
                <th>AMR pathogen</th>
                <th>Ward</th>
                <th>Week</th>
                <th>Start</th>
                <th>End</th>
                <th>Observed</th>
                <th>Expected</th>
                <th>O/E</th>
                <th>p-value</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($ann_c)): ?>
            <tr><td colspan="9">No ward-week cluster signal in this period (or too few hospital-origin resistant isolates)</td></tr>
        <?php else: foreach ($ann_c as $row): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['AMR_pathogen'] ?? ''); ?></td>
                <td class="left"><?php echo htmlspecialchars($row['Ward'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($row['Week'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars(amass_fmt_date($row['start_signal_date'] ?? '')); ?></td>
                <td><?php echo htmlspecialchars(amass_fmt_date($row['end_signal_date'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['observed_cases'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['expected_cases'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['observed_expected_ratio'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['p_value'] ?? '')); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <?php amass_foot($created, 'Annex C'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Annex C: Hospital-origin AMR isolates by ward</p>
    <p class="prose">Counts of de-duplicated hospital-origin blood isolates with the listed AMR phenotype, by admission ward. High counts that are not listed as clusters may still represent endemic transmission.</p>
    <table class="amass">
        <thead><tr><th>AMR pathogen</th><th>Organism</th><th>Ward</th><th>Isolates (n)</th></tr></thead>
        <tbody>
        <?php if (empty($ann_c_w)): ?>
            <tr><td colspan="4">No hospital-origin priority AMR isolates in this period</td></tr>
        <?php else: foreach ($ann_c_w as $row): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['AMR_pathogen'] ?? ''); ?></td>
                <td class="org left"><?php echo amass_org($row['Organism'] ?? ''); ?></td>
                <td class="left"><?php echo htmlspecialchars($row['Ward'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Hospital_origin_isolates'] ?? '')); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <?php amass_foot($created, 'Annex C'); ?>
</div>

<div class="sheet page" id="annex-d">
    <p class="sec-title">Annex D: Antimicrobial use (AMU)</p>
    <p class="prose">This annex reports inpatient antimicrobial use from HOSxP <i>drug_data</i> merged with hospital admissions, using AMASS version 4.0 definitions. <b>Days of therapy (DOT)</b> is the number of calendar days an inpatient received a given agent (regardless of dose) during an admission. <b>Length of therapy (LOT)</b> is the number of calendar days an inpatient received at least one antimicrobial. <b>AMU prevalence</b> is LOT divided by patient-days after excluding day admissions (same admission and discharge date, outcome not death or DAMA). Parenteral routes are intravenous, intramuscular, intraperitoneal and intrathecal. AWaRe classes follow WHO 2025 Access / Watch / Reserve, with Watch split into low, medium and high as in AMASS v4.0. AMS (D2) and diagnostic stewardship (D3) remain under construction in official AMASS and are not generated here.</p>
    <p class="prose">Drug records in this period: <?php echo amass_hi(amass_int($d_ndrug)); ?> (antibiotics <?php echo amass_hi(amass_int($d_natb)); ?>; antifungals <?php echo amass_hi(amass_int($d_natf)); ?>), from <?php echo amass_hi(amass_fmt_date($dmin_d)); ?> to <?php echo amass_hi(amass_fmt_date($dmax_d)); ?>.</p>
    <p class="prose">Patient-days excluding day admissions: <?php echo amass_hi(amass_int($d_ptd)); ?>. Parenteral antibiotic DOT: <?php echo amass_hi(amass_int($d_dot)); ?>. LOT: <?php echo amass_hi(amass_int($d_lot)); ?>. AMU prevalence: <?php echo amass_hi($d_prev); ?>.</p>
    <?php amass_foot($created, 'Annex D'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Annex D: AMU by month</p>
    <table class="amass">
        <thead>
            <tr>
                <th>Month</th>
                <th>Drug records</th>
                <th>Antibiotic records</th>
                <th>Antifungal records</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($ann_d_m)): ?>
            <tr><td colspan="4">NA — extract drug_data and re-run analysis</td></tr>
        <?php else: foreach ($ann_d_m as $row):
            $is_tot = ((string)($row['Month'] ?? '')) === 'Total:';
        ?>
            <tr<?php echo $is_tot ? ' class="total"' : ''; ?>>
                <td><?php echo htmlspecialchars($row['Month'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_drug_records'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_antibiotic_records'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_antifungal_records'] ?? '')); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <p class="sub-title">AMU by route of administration</p>
    <table class="amass">
        <thead>
            <tr>
                <th>Route of administration</th>
                <th>Antibiotic records</th>
                <th>Antifungal records</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($ann_d_r as $row):
            $is_tot = ((string)($row['Route_of_administration'] ?? '')) === 'Total:';
        ?>
            <tr<?php echo $is_tot ? ' class="total"' : ''; ?>>
                <td class="left"><?php echo htmlspecialchars($row['Route_of_administration'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_antibiotic_records'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['Number_of_antifungal_records'] ?? '')); ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($ann_d_r)): ?>
            <tr><td colspan="3">NA</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    <p class="foot">*Parenteral routes used for DOT. **Other injection routes. ***Other non-injection routes. ****Route not recorded in HOSxP.</p>
    <?php amass_foot($created, 'Annex D'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Annex D: DOT by parenteral antibiotic</p>
    <p class="prose">Days of therapy among inpatients, parenteral antibiotics only. Ranked by DOT. % DOT is the share of total parenteral antibiotic DOT. Rate is DOT per 1,000 patient-days (day admissions excluded).</p>
    <table class="amass">
        <thead>
            <tr>
                <th>Rank</th>
                <th>Antibiotic</th>
                <th>AWaRe</th>
                <th>DOT</th>
                <th>% DOT</th>
                <th>DOT / 1,000 patient-days</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($ann_d_dot)): ?>
            <tr><td colspan="6">NA — no parenteral antibiotic days matched to an admission</td></tr>
        <?php else: foreach ($ann_d_dot as $row):
            $is_tot = ((string)($row['Antibiotic'] ?? '')) === 'Total:';
        ?>
            <tr<?php echo $is_tot ? ' class="total"' : ''; ?>>
                <td class="num"><?php echo htmlspecialchars($row['RANK'] ?? ''); ?></td>
                <td class="left"><?php echo htmlspecialchars($row['Antibiotic'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($row['AWaRe_classification'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['DOT'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['DOT_percent_text'] ?? $row['DOT_percent'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['DOT_per1000patient_days'] ?? '')); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    <?php amass_foot($created, 'Annex D'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Annex D: DOT by AWaRe class and department</p>
    <table class="amass">
        <thead>
            <tr>
                <th>AWaRe classification</th>
                <th>DOT</th>
                <th>% DOT</th>
                <th>DOT / 1,000 patient-days</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($ann_d_aw as $row):
            $is_tot = ((string)($row['AWaRe_classification'] ?? '')) === 'Total:';
        ?>
            <tr<?php echo $is_tot ? ' class="total"' : ''; ?>>
                <td class="left"><?php echo htmlspecialchars($row['AWaRe_classification'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['DOT'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['DOT_percent_text'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['DOT_per1000patient_days'] ?? '')); ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($ann_d_aw)): ?><tr><td colspan="4">NA</td></tr><?php endif; ?>
        </tbody>
    </table>
    <p class="sub-title">DOT by department</p>
    <table class="amass">
        <thead>
            <tr>
                <th>Department</th>
                <th>DOT</th>
                <th>% DOT</th>
                <th>DOT / 1,000 patient-days</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($ann_d_dp as $row):
            $is_tot = ((string)($row['Department'] ?? '')) === 'Total:';
        ?>
            <tr<?php echo $is_tot ? ' class="total"' : ''; ?>>
                <td class="left"><?php echo htmlspecialchars($row['Department'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['DOT'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['DOT_percent_text'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['DOT_per1000patient_days'] ?? '')); ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($ann_d_dp)): ?><tr><td colspan="4">NA</td></tr><?php endif; ?>
        </tbody>
    </table>
    <p class="foot">Department is grouped from HOSxP specialty / ward name (Medicine, Pediatrics, Surgery, Orthopedics, Obstetrics and Gynaecology, ICU, Others). Official AMASS uses dictionary-mapped department groups.</p>
    <?php amass_foot($created, 'Annex D'); ?>
</div>

<div class="sheet page">
    <p class="sec-title">Annex D: Parenteral antifungals and most frequent agents</p>
    <?php if (!empty($ann_d_atf)): ?>
    <p class="sub-title">DOT by parenteral antifungal</p>
    <table class="amass">
        <thead><tr><th>Antifungal</th><th>DOT</th><th>DOT / 1,000 patient-days</th></tr></thead>
        <tbody>
        <?php foreach ($ann_d_atf as $row):
            $is_tot = ((string)($row['Antifungal'] ?? '')) === 'Total:';
        ?>
            <tr<?php echo $is_tot ? ' class="total"' : ''; ?>>
                <td class="left"><?php echo htmlspecialchars($row['Antifungal'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_int($row['DOT'] ?? '')); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['DOT_per1000patient_days'] ?? '')); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <p class="sub-title">Most frequent antimicrobial prescriptions</p>
    <table class="amass">
        <thead><tr><th>Drug</th><th>Prescriptions (n)</th></tr></thead>
        <tbody>
        <?php
        $amu_rows = array_slice($tables['amu'] ?? [], 0, 25);
        $amu_sum = 0;
        foreach ($amu_rows as $row):
            if (is_numeric($row['prescriptions'] ?? '')) {
                $amu_sum += (float)$row['prescriptions'];
            }
        ?>
            <tr>
                <td class="left"><?php echo htmlspecialchars($row['drug_name'] ?? ''); ?></td>
                <td class="num"><?php echo htmlspecialchars(amass_num($row['prescriptions'] ?? '')); ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!empty($amu_rows)): ?>
            <tr class="total">
                <td>Total (top listed):</td>
                <td class="num"><?php echo htmlspecialchars(amass_int($amu_sum)); ?></td>
            </tr>
        <?php else: ?>
            <tr><td colspan="2">NA</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    <p class="foot">A careful review of Annex D is strongly recommended. Official AMASS also generates Supplementary_data_Annex_D. AWaRe mapping is by generic name; strengths in HOSxP drug names are stripped before classification.</p>
    <?php amass_foot($created, 'Annex D'); ?>
</div>

<div class="sheet page" id="methods">
    <p class="sec-title">Methods used by AMASS application</p>
    <p class="prose">This report used AMASS version 4.0 analysis rules (WHO GLASS compatible) as implemented in THAM Hos-Safe:</p>
    <p class="prose indent">− Only blood specimens are included in Sections [2] to [6].</p>
    <p class="prose indent">− Data are de-duplicated by including only the first isolate per patient per specimen type per pathogen per evaluation period.</p>
    <p class="prose indent">− Proportion of R = patients with blood culture positive for resistant isolates / patients with the organism tested against the antibiotic. Intermediate (I) is counted as susceptible for this R-mode report.</p>
    <p class="prose indent">− Infection origin uses the WHO GLASS 2-calendar-day rule. Community-origin: specimen collected on calendar day 1–2 of admission. Hospital-origin: specimen collected on calendar day 3 or later.</p>
    <p class="prose indent">− Frequency of infection is estimated per 100,000 patients sampled for blood culture (Section [4]) and per 100,000 tested patients of that origin (Section [5]).</p>
    <p class="prose indent">− Mortality is all-cause in-hospital mortality among patients with de-duplicated blood culture positive for organisms under surveillance.</p>
    <p class="prose indent">− 95% confidence intervals are Wilson score intervals.</p>
    <p class="prose indent">− Annex B data indicators: blood-culture contamination (possible skin-flora contaminants), notifiable AMR combinations, and potential AST errors / discordant results among de-duplicated blood isolates with AST.</p>
    <p class="prose indent">− Annex C cluster signals: simplified Poisson ward-week scan of hospital-origin MRSA, VRE, CRE, CRAB and CRPA. This is not SaTScan.</p>
    <p class="prose indent">− Annex D AMU: DOT and LOT from inpatient antimicrobial days matched to admissions; day admissions are excluded from patient-days; AWaRe is mapped from generic names (WHO Access / Watch / Reserve, Watch split as in AMASS v4.0).</p>
    <?php amass_foot($created); ?>
</div>

<div class="sheet page" id="ack">
    <p class="sec-title">Acknowledgements</p>
    <p class="prose">AMASS application is developed by the AMASS group. For any query on AMASS, please contact amass@tropmedres.ac.</p>
    <p class="prose">This hospital report was generated from HOSxP extracts inside THAM Hos-Safe. The report contains no patient identifier.</p>
    <?php amass_foot($created); ?>
</div>

<?php endif; ?>
<script>
(function () {
    var numbered = Array.prototype.slice.call(document.querySelectorAll('.sheet.page')).filter(function (el) {
        return !el.classList.contains('no-pagenum');
    });
    var total = numbered.length;
    var byId = {};
    numbered.forEach(function (el, i) {
        var n = i + 1;
        var span = el.querySelector('.foot-page');
        if (span) {
            span.textContent = 'Page ' + n + ' of ' + total;
        }
        if (el.id) {
            byId['#' + el.id] = n;
        }
    });
    document.querySelectorAll('.toc .pg[data-toc]').forEach(function (td) {
        var key = td.getAttribute('data-toc');
        if (byId[key]) {
            td.textContent = String(byId[key]);
        }
    });
})();
</script>
<?php if ($section !== '' && isset($jump[$section])): ?>
<script>location.hash = <?php echo json_encode($jump[$section]); ?>;</script>
<?php endif; ?>
</body>
</html>
