<?php
/**
 * ตัวอย่างการเชื่อมต่อฐานข้อมูลแอป THAM HOS-Safe
 * คัดลอกเป็น db_connect.php แล้วใส่ค่าจริงของ รพ.
 *
 * สำหรับแพ็กกระจาย Docker แนะนำตั้ง:
 *   environment: THAM_DISTRIBUTION=1
 * เพื่อปิด Google Sheet / INVC / HOSoffice ฯลฯ เป็นค่าเริ่มต้นครั้งแรก
 */
require_once __DIR__ . '/check_license.php';
tham_check_license();

$tham_db_host = '127.0.0.1';
$tham_db_name = 'db_thamhossafe';
$tham_db_user = 'CHANGE_ME';
$tham_db_pass = 'CHANGE_ME';
$con = mysqli_init();
if ($con) {
    mysqli_options($con, MYSQLI_OPT_CONNECT_TIMEOUT, 8);
}
$tham_db_ok = $con && @mysqli_real_connect($con, $tham_db_host, $tham_db_user, $tham_db_pass, $tham_db_name);
if (empty($tham_db_ok) || !$con) {
    if (!headers_sent()) {
        http_response_code(503);
        header('Content-Type: text/plain; charset=utf-8');
    }
    die('เชื่อมต่อฐานข้อมูลไม่ได้ชั่วคราว กรุณาลองใหม่');
}
unset($tham_db_pass, $tham_db_user, $tham_db_ok);
mysqli_set_charset($con, 'utf8mb4');
date_default_timezone_set('Asia/Bangkok');

if (is_file(__DIR__ . '/distribution_defaults_helper.php')) {
    require_once __DIR__ . '/distribution_defaults_helper.php';
    if (function_exists('tham_distribution_seed_defaults')) {
        @tham_distribution_seed_defaults($con);
    }
}
