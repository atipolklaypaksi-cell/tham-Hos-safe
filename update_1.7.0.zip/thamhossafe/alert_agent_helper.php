<?php
/**
 * ไฟล์โปรแกรม THAM Notify (หน้าต่าง/ถาดระบบ แบบ SCPH Notify)
 * วางไฟล์ .exe / .msi / .zip ในโฟลเดอร์นี้ แล้วหน้า alert_agent.php จะให้ดาวน์โหลดได้
 */
function tham_alert_agent_download_dir() {
    return __DIR__ . '/downloads';
}

function tham_alert_agent_allowed_ext() {
    return ['exe', 'msi', 'zip'];
}

function tham_alert_agent_list_files() {
    $dir = tham_alert_agent_download_dir();
    $out = [];
    if (!is_dir($dir)) {
        return $out;
    }
    $allowed = array_flip(tham_alert_agent_allowed_ext());
    $files = @scandir($dir);
    if (!is_array($files)) {
        return $out;
    }
    foreach ($files as $name) {
        if ($name === '.' || $name === '..') {
            continue;
        }
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!isset($allowed[$ext])) {
            continue;
        }
        $path = $dir . '/' . $name;
        if (!is_file($path)) {
            continue;
        }
        $out[] = [
            'name' => $name,
            'size' => (int)@filesize($path),
            'mtime' => (int)@filemtime($path),
        ];
    }
    usort($out, function ($a, $b) {
        return ($b['mtime'] <=> $a['mtime']);
    });
    return $out;
}

function tham_alert_agent_find_file($name) {
    $name = basename(str_replace(["\0", '\\', '/'], '', (string)$name));
    if ($name === '' || $name === '.' || $name === '..') {
        return null;
    }
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, tham_alert_agent_allowed_ext(), true)) {
        return null;
    }
    $path = tham_alert_agent_download_dir() . '/' . $name;
    if (!is_file($path)) {
        return null;
    }
    return ['name' => $name, 'path' => $path, 'size' => (int)@filesize($path)];
}

function tham_alert_agent_format_size($bytes) {
    $bytes = (int)$bytes;
    if ($bytes < 1024) {
        return $bytes . ' B';
    }
    if ($bytes < 1048576) {
        return number_format($bytes / 1024, 1) . ' KB';
    }
    return number_format($bytes / 1048576, 1) . ' MB';
}

function tham_alert_agent_parse_version($name) {
    if (preg_match('/(\d+\.\d+(?:\.\d+)?)/', (string)$name, $m)) {
        return $m[1];
    }
    return '';
}

function tham_alert_agent_latest_file() {
    $exe = tham_alert_agent_latest_exe();
    if ($exe) {
        return $exe;
    }
    $files = tham_alert_agent_list_files();
    if (!$files) {
        return null;
    }
    $f = $files[0];
    $f['version'] = tham_alert_agent_parse_version($f['name']);
    $f['size_label'] = tham_alert_agent_format_size($f['size']);
    return $f;
}

function tham_alert_agent_latest_exe() {
    static $done = false;
    static $memo = null;
    if ($done) {
        return $memo;
    }
    $done = true;
    $best = null;
    $bestVer = '';
    foreach (tham_alert_agent_list_files() as $f) {
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        if ($ext !== 'exe') {
            continue;
        }
        if (stripos($f['name'], 'THAM-Notify') === false || stripos($f['name'], 'Alert-Agent') !== false) {
            continue;
        }
        $ver = tham_alert_agent_parse_version($f['name']);
        if ($ver === '') {
            continue;
        }
        $newer = $best === null
            || version_compare($ver, $bestVer, '>')
            || ($ver === $bestVer && (int)$f['mtime'] > (int)$best['mtime']);
        if ($newer) {
            $best = $f;
            $bestVer = $ver;
        }
    }
    if (!$best) {
        return null;
    }
    $path = tham_alert_agent_download_dir() . '/' . $best['name'];
    $best['version'] = $bestVer;
    $best['size_label'] = tham_alert_agent_format_size($best['size']);
    $best['sha256'] = is_file($path) ? hash_file('sha256', $path) : '';
    $memo = $best;
    return $memo;
}

function tham_alert_agent_update_offer($agent_version) {
    $latest = tham_alert_agent_latest_exe();
    if (!$latest || empty($latest['sha256'])) {
        return null;
    }
    $cur = trim((string)$agent_version);
    if ($cur !== '' && version_compare($cur, $latest['version'], '>=')) {
        return null;
    }
    return [
        'version' => $latest['version'],
        'size' => (int)$latest['size'],
        'sha256' => $latest['sha256'],
        'name' => $latest['name'],
    ];
}

function tham_alert_agent_stream_file($found) {
    if (!$found || empty($found['path']) || !is_file($found['path'])) {
        return false;
    }
    $size = (int)$found['size'];
    $safe = str_replace(['"', "\r", "\n"], '', (string)$found['name']);
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    @ini_set('zlib.output_compression', '0');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $safe . '"');
    header('Content-Length: ' . (string)$size);
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store');
    $fh = fopen($found['path'], 'rb');
    if (!$fh) {
        return false;
    }
    while (!feof($fh)) {
        $chunk = fread($fh, 8192);
        if ($chunk === false) {
            break;
        }
        echo $chunk;
    }
    fclose($fh);
    return true;
}

function tham_alert_agent_stream_latest($con = null) {
    unset($con);
    $latest = tham_alert_agent_latest_exe();
    if (!$latest) {
        $latest = tham_alert_agent_latest_file();
    }
    if (!$latest) {
        return false;
    }
    $found = tham_alert_agent_find_file($latest['name']);
    if (!$found) {
        return false;
    }
    return tham_alert_agent_stream_file($found);
}

function tham_alert_is_lan_ip($ip = '') {
    $ip = trim((string)$ip);
    if ($ip === '') {
        if (function_exists('tham_alert_client_ip')) {
            $ip = tham_alert_client_ip();
        } else {
            $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        }
    }
    if ($ip === '127.0.0.1' || $ip === '::1') {
        return true;
    }
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return false;
    }
    if (tham_alert_is_cgnat_ip($ip)) {
        return false;
    }
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false;
}

function tham_alert_is_cgnat_ip($ip) {
    $ip = trim((string)$ip);
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        return false;
    }
    $long = ip2long($ip);
    if ($long === false) {
        return false;
    }
    $long = $long & 0xFFFFFFFF;
    return ($long & 0xFFC00000) === 0x64400000;
}

function tham_alert_ip_network_info($ip) {
    $ip = trim((string)$ip);
    if ($ip === '') {
        return [
            'is_lan' => false,
            'kind' => 'unknown',
            'label' => 'ไม่ทราบ',
            'detail' => '',
        ];
    }
    if (tham_alert_is_cgnat_ip($ip)) {
        return [
            'is_lan' => false,
            'kind' => 'cgnat',
            'label' => 'นอก รพ.',
            'detail' => 'มือถือ/CGNAT',
        ];
    }
    if (tham_alert_is_lan_ip($ip)) {
        return [
            'is_lan' => true,
            'kind' => 'lan',
            'label' => 'ใน รพ.',
            'detail' => 'LAN ในโรงพยาบาล',
        ];
    }
    return [
        'is_lan' => false,
        'kind' => 'wan',
        'label' => 'นอก รพ.',
        'detail' => 'อินเทอร์เน็ต',
    ];
}
