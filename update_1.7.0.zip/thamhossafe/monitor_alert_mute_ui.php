<?php
function monitor_alert_mute_box($prefix) {
    static $script_done = false;
    $prefix = preg_replace('/[^A-Za-z0-9_]/', '', (string)$prefix);
    if ($prefix === '') {
        return;
    }
    $p = htmlspecialchars($prefix, ENT_QUOTES, 'UTF-8');
    echo '<div id="' . $p . 'MuteBox" class="border rounded p-2 mt-2 bg-white d-none">'
        . '<div class="form-check">'
        . '<input class="form-check-input" type="checkbox" id="' . $p . 'MuteVisit">'
        . '<label class="form-check-label small fw-bold" for="' . $p . 'MuteVisit" id="' . $p . 'MuteVisitLabel">ปิดการแจ้งเตือนใน visit นี้</label>'
        . '</div>'
        . '<div class="small text-muted mt-1">ติ๊กแล้วบันทึก ระบบจะไม่แจ้งเตือนใน VN หรือ AN นี้อีก visit ครั้งต่อไปยังแจ้งเตือนตามปกติ</div>'
        . '<button type="button" class="btn btn-outline-danger btn-sm mt-2" onclick="AlertMute.muteHn(\'' . $p . '\')">ปิดการแจ้งเตือนใน HN นี้</button>'
        . '<div class="small text-muted mt-1">ปิดแล้วระบบจะไม่แจ้งเตือน HN นี้ทุกครั้ง ต้องพิมพ์ confirm เพื่อยืนยัน</div>'
        . '</div>';
    if ($script_done) {
        return;
    }
    $script_done = true;
    echo <<<'JS'
<script>
window.AlertMute = {
    contexts: {},
    set: function (prefix, ctx) {
        this.contexts[prefix] = ctx || {};
        this.sync(prefix);
    },
    ctx: function (prefix) {
        return this.contexts[prefix] || {};
    },
    visitLabel: function (prefix) {
        var c = this.ctx(prefix);
        var an = String(c.an || '').trim();
        var vn = String(c.vn || '').trim();
        var ptype = String(c.patient_type || c.type_patient || '').toUpperCase();
        if ((ptype === 'IPD' || (an && an !== '0')) && an && an !== '0') return 'AN ' + an;
        if (vn) return 'VN ' + vn;
        return 'visit นี้';
    },
    sync: function (prefix) {
        var sel = document.getElementById(prefix);
        var box = document.getElementById(prefix + 'MuteBox');
        if (!sel || !box) return;
        var show = sel.value === 'ไม่ใช่ความคลาดเคลื่อน';
        box.classList.toggle('d-none', !show);
        var label = document.getElementById(prefix + 'MuteVisitLabel');
        if (label) label.textContent = 'ปิดการแจ้งเตือนใน ' + this.visitLabel(prefix) + ' นี้';
        if (!show) {
            var cb = document.getElementById(prefix + 'MuteVisit');
            if (cb) cb.checked = false;
        }
    },
    checked: function (prefix) {
        var sel = document.getElementById(prefix);
        var cb = document.getElementById(prefix + 'MuteVisit');
        return !!(sel && cb && sel.value === 'ไม่ใช่ความคลาดเคลื่อน' && cb.checked);
    },
    muteHn: function (prefix) {
        var c = this.ctx(prefix);
        var hn = String(c.hn || '').replace(/^0+/, '') || String(c.hn || '');
        if (!hn) {
            alert('ไม่พบ HN');
            return;
        }
        var typed = prompt('คำเตือน: จะปิดการแจ้งเตือนของ HN ' + hn + ' ทุกครั้ง ทั้ง visit นี้และครั้งต่อไป\n\nพิมพ์คำว่า \'confirm\' เพื่อยืนยัน:');
        if (typed !== 'confirm') {
            if (typed !== null && typed !== '') {
                alert('พิมพ์คำว่า \'confirm\' ไม่ถูกต้อง การแจ้งเตือนจะไม่ถูกปิด');
            }
            return;
        }
        fetch('fetch_smart_pharma_api.php?action=mute_alert_hn', {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                confirm: 'confirm',
                hn: c.hn || '',
                vn: c.vn || '',
                an: c.an || '',
                patient_type: c.patient_type || c.type_patient || ''
            })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (!data || data.status !== 'success' || !data.muted) {
                alert((data && data.message) || 'ปิดการแจ้งเตือนไม่สำเร็จ');
                return;
            }
            alert(data.message || 'ปิดการแจ้งเตือนของ HN นี้แล้ว');
            if (typeof fetchScreenData === 'function') fetchScreenData({ silent: true });
            else window.location.reload();
        }).catch(function () {
            alert('เชื่อมต่อไม่สำเร็จ');
        });
    }
};
</script>
JS;
}
