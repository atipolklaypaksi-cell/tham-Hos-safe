<?php
/**
 * In-app AMASS / WHO GLASS analysis for THAM Hos-Safe.
 * Reads staged xlsx, writes ResultData CSVs (same names as AMASS v4.0),
 * and returns tables for the dashboard. Annex B/D are computed in PHP;
 * Annex C uses a simplified Poisson ward-week scan (not SaTScan).
 */

require_once __DIR__ . '/amr_amass_annex.php';

function amr_amass_zip_read_entry($path, $want) {
    if (!is_file($path)) {
        return '';
    }
    if (class_exists('ZipArchive')) {
        $z = new ZipArchive();
        if ($z->open($path) === true) {
            $data = $z->getFromName($want);
            $z->close();
            if ($data !== false && $data !== '') {
                return (string)$data;
            }
        }
    }
    $fh = @fopen($path, 'rb');
    if (!$fh) {
        return '';
    }
    while (!feof($fh)) {
        $sig = fread($fh, 4);
        if ($sig === '' || strlen($sig) < 4) {
            break;
        }
        if ($sig === "PK\x01\x02" || $sig === "PK\x05\x06" || $sig === "PK\x06\x06") {
            break;
        }
        if ($sig !== "PK\x03\x04") {
            break;
        }
        $hdr = fread($fh, 26);
        if (strlen($hdr) < 26) {
            break;
        }
        $u = unpack('vver/vflag/vmethod/vtime/vdate/Vcrc/Vcomp/Vuncomp/vnamelen/vexlen', $hdr);
        $name = $u['namelen'] ? fread($fh, $u['namelen']) : '';
        if (!empty($u['exlen'])) {
            fread($fh, $u['exlen']);
        }
        $data = $u['comp'] > 0 ? fread($fh, $u['comp']) : '';
        if ($name === $want) {
            fclose($fh);
            if ((int)$u['method'] === 0) {
                return (string)$data;
            }
            if ((int)$u['method'] === 8) {
                $inf = @gzinflate($data);
                return $inf !== false ? $inf : '';
            }
            return '';
        }
    }
    fclose($fh);
    return '';
}

function amr_amass_xlsx_col_index($ref) {
    if (!preg_match('/^([A-Z]+)/', strtoupper((string)$ref), $m)) {
        return -1;
    }
    $n = 0;
    foreach (str_split($m[1]) as $ch) {
        $n = $n * 26 + (ord($ch) - 64);
    }
    return $n - 1;
}

function amr_amass_load_source_table($filename) {
    $dir = amr_amass_upload_dir();
    $csv = $dir . '/' . preg_replace('/\.xlsx$/i', '.csv', $filename);
    $xlsx = $dir . '/' . $filename;
    $csv_ok = is_file($csv) && filesize($csv) > 3;
    $xlsx_ok = is_file($xlsx);
    if ($csv_ok && $xlsx_ok) {
        if (filemtime($xlsx) > filemtime($csv)) {
            return amr_amass_xlsx_read($xlsx);
        }
    }
    if ($csv_ok) {
        $rows = function_exists('amr_amass_read_csv_assoc') ? amr_amass_read_csv_assoc($csv) : [];
        $cols = !empty($rows) ? array_keys($rows[0]) : [];
        return ['columns' => $cols, 'rows' => $rows];
    }
    if ($xlsx_ok) {
        return amr_amass_xlsx_read($xlsx);
    }
    return ['columns' => [], 'rows' => []];
}

function amr_amass_xlsx_read($path) {
    $xml = amr_amass_zip_read_entry($path, 'xl/worksheets/sheet1.xml');
    if ($xml === '') {
        return ['columns' => [], 'rows' => []];
    }
    $columns = [];
    $rows = [];
    if (!preg_match_all('/<row\\b[^>]*>(.*?)<\\/row>/s', $xml, $rowm)) {
        return ['columns' => [], 'rows' => []];
    }
    foreach ($rowm[1] as $ri => $rowxml) {
        $cells = [];
        if (preg_match_all('/<c\\b([^>]*)>(.*?)<\\/c>/s', $rowxml, $cm, PREG_SET_ORDER)) {
            foreach ($cm as $c) {
                $attr = $c[1];
                $inner = $c[2];
                $col = -1;
                if (preg_match('/\\br="([^"]+)"/', $attr, $rm)) {
                    $col = amr_amass_xlsx_col_index($rm[1]);
                }
                $val = '';
                if (preg_match('/<t[^>]*>(.*?)<\\/t>/s', $inner, $tm)) {
                    $val = html_entity_decode($tm[1], ENT_QUOTES | ENT_XML1, 'UTF-8');
                } elseif (preg_match('/<v[^>]*>(.*?)<\\/v>/s', $inner, $vm)) {
                    $val = html_entity_decode($vm[1], ENT_QUOTES | ENT_XML1, 'UTF-8');
                }
                if ($col >= 0) {
                    $cells[$col] = trim($val);
                }
            }
        }
        if (!$cells) {
            continue;
        }
        ksort($cells);
        $max = max(array_keys($cells));
        $vals = [];
        for ($i = 0; $i <= $max; $i++) {
            $vals[] = $cells[$i] ?? '';
        }
        if ($ri === 0) {
            $columns = $vals;
            continue;
        }
        $assoc = [];
        foreach ($columns as $i => $col) {
            $assoc[$col] = $vals[$i] ?? '';
        }
        $rows[] = $assoc;
    }
    return ['columns' => $columns, 'rows' => $rows];
}

function amr_amass_csv_write($path, array $columns, array $rows) {
    $fh = @fopen($path, 'wb');
    if (!$fh) {
        return false;
    }
    fwrite($fh, "\xEF\xBB\xBF");
    fputcsv($fh, $columns);
    foreach ($rows as $row) {
        $line = [];
        foreach ($columns as $col) {
            $line[] = is_array($row) ? ($row[$col] ?? '') : '';
        }
        fputcsv($fh, $line);
    }
    fclose($fh);
    @chmod($path, 0666);
    return true;
}

function amr_amass_parse_date($value) {
    $s = trim((string)$value);
    if ($s === '' || $s === '0000-00-00') {
        return '';
    }
    $s = str_replace(['.', '-'], '/', $s);
    if (preg_match('/^(\\d{1,2})\\/(\\d{1,2})\\/(\\d{2,4})$/', $s, $m)) {
        $y = (int)$m[3];
        if ($y < 100) {
            $y += $y >= 70 ? 1900 : 2000;
        }
        if ($y > 2400) {
            $y -= 543;
        }
        $d = sprintf('%04d-%02d-%02d', $y, (int)$m[2], (int)$m[1]);
        $t = strtotime($d);
        return $t ? date('Y-m-d', $t) : '';
    }
    $t = strtotime(str_replace('/', '-', (string)$value));
    return $t ? date('Y-m-d', $t) : '';
}

function amr_amass_clean_hn($value) {
    $s = strtolower(trim((string)$value));
    $s = str_replace(["'", '"', ' '], '', $s);
    $s = preg_replace('/\\.0$/', '', $s);
    $s = ltrim($s, '0');
    return $s === '' ? '0' : $s;
}

function amr_amass_map_ris($value) {
    $s = strtoupper(trim((string)$value));
    if ($s === '') {
        return '';
    }
    if (preg_match('/\\bR\\b|^R$|ดื้อ|RESIST/', $s)) {
        return 'R';
    }
    if (preg_match('/\\bI\\b|^I$|INTERMED/', $s)) {
        return 'I';
    }
    if (preg_match('/\\bS\\b|^S$|ไว|SUSCEPT/', $s)) {
        return 'S';
    }
    if (preg_match('/^NS\\b|NON[- ]?SUSC/', $s)) {
        return 'R';
    }
    return '';
}

function amr_amass_is_blood($specimen) {
    $s = strtolower(trim((string)$specimen));
    return $s !== '' && preg_match('/blood|hemo|เลือด|hemoculture/', $s);
}

function amr_amass_is_nogrowth($organism) {
    $s = strtolower(trim((string)$organism));
    return $s !== '' && preg_match('/no\\s*growth|ไม่พบเชื้อ|no\\s*organism/', $s);
}

function amr_amass_is_died($status, $type = '') {
    $s = strtolower($status . ' ' . $type);
    return preg_match('/ตาย|เสียชีวิต|dead|died|death|expire/', $s) === 1;
}

function amr_amass_priority_orgs() {
    return [
        'organism_escherichia_coli' => ['Escherichia coli', 'ecoli', ['escherichia coli', 'e.coli', 'e coli']],
        'organism_klebsiella_pneumoniae' => ['Klebsiella pneumoniae', 'kpneu', ['klebsiella pneumoniae', 'k.pneumoniae', 'k pneumoniae']],
        'organism_acinetobacter_baumannii' => ['Acinetobacter baumannii', 'abaum', ['acinetobacter baumannii', 'a.baumannii', 'a baumannii']],
        'organism_pseudomonas_aeruginosa' => ['Pseudomonas aeruginosa', 'paeru', ['pseudomonas aeruginosa', 'p.aeruginosa', 'p aeruginosa']],
        'organism_staphylococcus_aureus' => ['Staphylococcus aureus', 'saure', ['staphylococcus aureus', 's.aureus', 's aureus']],
        'organism_enterococcus_faecium' => ['Enterococcus faecium', 'efaecium', ['enterococcus faecium']],
        'organism_enterococcus_faecalis' => ['Enterococcus faecalis', 'efaecalis', ['enterococcus faecalis']],
        'organism_streptococcus_pneumoniae' => ['Streptococcus pneumoniae', 'spneu', ['streptococcus pneumoniae', 's.pneumoniae']],
        'organism_salmonella_spp' => ['Salmonella spp.', 'salmo', ['salmonella']],
    ];
}

function amr_amass_map_organism($raw) {
    $s = strtolower(trim((string)$raw));
    $s = preg_replace('/\\s+/', ' ', $s);
    if ($s === '' || amr_amass_is_nogrowth($s)) {
        return '';
    }
    foreach (amr_amass_priority_orgs() as $key => $meta) {
        foreach ($meta[2] as $needle) {
            if (strpos($s, $needle) !== false) {
                return $key;
            }
        }
    }
    return '';
}

function amr_amass_atb_canon_map() {
    return [
        'AK' => 'Amikacin', 'AMK' => 'Amikacin', 'AMIKACIN' => 'Amikacin',
        'GM' => 'Gentamicin', 'GEN' => 'Gentamicin', 'GENTAMICIN' => 'Gentamicin',
        'MEM' => 'Meropenem', 'MEROPENEM' => 'Meropenem',
        'IPM' => 'Imipenem', 'IMIPENEM' => 'Imipenem',
        'ETP' => 'Ertapenem', 'ERTAPENEM' => 'Ertapenem',
        'DOR' => 'Doripenem', 'DORIPENEM' => 'Doripenem',
        'CRO' => 'Ceftriaxone', 'CEFTRIAXONE' => 'Ceftriaxone',
        'CTX' => 'Cefotaxime', 'CEFOTAXIME' => 'Cefotaxime',
        'CAZ' => 'Ceftazidime', 'CEFTAZIDIME' => 'Ceftazidime',
        'FEP' => 'Cefepime', 'CEFEPIME' => 'Cefepime',
        'CPD' => 'Cefpodoxime', 'CEFPODOXIME' => 'Cefpodoxime',
        'CIP' => 'Ciprofloxacin', 'CFX' => 'Ciprofloxacin', 'CIPROFLOXACIN' => 'Ciprofloxacin',
        'LVX' => 'Levofloxacin', 'LEVOFLOXACIN' => 'Levofloxacin',
        'TZP' => 'Piperacillin/tazobactam', 'PIPERACILLIN_AND_TAZOBACTAM' => 'Piperacillin/tazobactam',
        'SCF' => 'Cefoperazone/sulbactam', 'CEFOPERAZONE_AND_SULBACTAM' => 'Cefoperazone/sulbactam',
        'SXT' => 'Co-trimoxazole', 'SULFAMETHOXAZOLE_AND_TRIMETHOPRIM' => 'Co-trimoxazole',
        'VA' => 'Vancomycin', 'VAN' => 'Vancomycin', 'VANCOMYCIN' => 'Vancomycin',
        'OX' => 'Oxacillin', 'OXACILLIN' => 'Oxacillin',
        'FOX' => 'Cefoxitin', 'CEFOXITIN' => 'Cefoxitin',
        'CL' => 'Colistin', 'CS' => 'Colistin', 'COLISTIN' => 'Colistin',
        'TGC' => 'Tigecycline', 'TIGECYCLINE' => 'Tigecycline',
        'MI' => 'Minocycline', 'MINOCYCLINE' => 'Minocycline',
        'AP' => 'Ampicillin', 'AM' => 'Ampicillin', 'AMPICILLIN' => 'Ampicillin',
        'AUG' => 'Amoxicillin/clavulanic acid', 'AMC' => 'Amoxicillin/clavulanic acid',
        'DA' => 'Clindamycin', 'CLI' => 'Clindamycin', 'CLINDAMYCIN' => 'Clindamycin',
        'C' => 'Chloramphenicol', 'CHLORAMPHENICOL' => 'Chloramphenicol',
        'PG' => 'Penicillin G', 'P' => 'Penicillin G', 'PENICILLIN_G' => 'Penicillin G',
        'LNZ' => 'Linezolid', 'LINEZOLID' => 'Linezolid',
        'E' => 'Erythromycin', 'ERY' => 'Erythromycin',
    ];
}

function amr_amass_canon_atb($code, $dict_name = '') {
    $map = amr_amass_atb_canon_map();
    $code_u = strtoupper(trim((string)$code));
    if (isset($map[$code_u])) {
        return $map[$code_u];
    }
    $name = trim((string)$dict_name);
    if ($name !== '') {
        $key = strtoupper(str_replace([' ', '-'], '_', $name));
        if (isset($map[$key])) {
            return $map[$key];
        }
        $pretty = str_replace('_', ' ', $name);
        if (isset($map[strtoupper($pretty)])) {
            return $map[strtoupper($pretty)];
        }
        return $pretty;
    }
    return $code_u;
}

function amr_amass_org_atb_list($org_key) {
    $core = [
        'organism_escherichia_coli' => ['Ampicillin', 'Gentamicin', 'Amikacin', 'Co-trimoxazole', 'FLUOROQUINOLONES', 'Ciprofloxacin', 'Levofloxacin', '3GC', 'Ceftriaxone', 'Ceftazidime', 'Cefotaxime', 'Cefepime', 'CARBAPENEMS', 'Imipenem', 'Meropenem', 'Ertapenem', 'Colistin', 'Piperacillin/tazobactam'],
        'organism_klebsiella_pneumoniae' => ['Gentamicin', 'Amikacin', 'Co-trimoxazole', 'FLUOROQUINOLONES', 'Ciprofloxacin', 'Levofloxacin', '3GC', 'Ceftriaxone', 'Ceftazidime', 'Cefotaxime', 'Cefepime', 'CARBAPENEMS', 'Imipenem', 'Meropenem', 'Ertapenem', 'Colistin', 'Piperacillin/tazobactam'],
        'organism_pseudomonas_aeruginosa' => ['Ceftazidime', 'Ciprofloxacin', 'AMINOGLYCOSIDES', 'Gentamicin', 'Amikacin', 'CARBAPENEMS', 'Imipenem', 'Meropenem', 'Colistin', 'Piperacillin/tazobactam'],
        'organism_acinetobacter_baumannii' => ['Tigecycline', 'Minocycline', 'AMINOGLYCOSIDES', 'Gentamicin', 'Amikacin', 'CARBAPENEMS', 'Imipenem', 'Meropenem', 'Colistin', 'Piperacillin/tazobactam'],
        'organism_staphylococcus_aureus' => ['METHICILLIN', 'Cefoxitin', 'Oxacillin', 'Vancomycin', 'Clindamycin', 'Chloramphenicol'],
        'organism_enterococcus_faecium' => ['Ampicillin', 'Vancomycin', 'Linezolid'],
        'organism_enterococcus_faecalis' => ['Ampicillin', 'Vancomycin', 'Linezolid'],
        'organism_streptococcus_pneumoniae' => ['Penicillin G', 'Oxacillin', 'Co-trimoxazole', '3GC', 'Ceftriaxone', 'Cefotaxime', 'Erythromycin', 'Clindamycin', 'Levofloxacin'],
        'organism_salmonella_spp' => ['FLUOROQUINOLONES', 'Ciprofloxacin', 'Levofloxacin', '3GC', 'Ceftriaxone', 'Ceftazidime', 'CARBAPENEMS', 'Imipenem', 'Meropenem'],
    ];
    return $core[$org_key] ?? [];
}

function amr_amass_group_members($group, $org_key) {
    if ($group === '3GC') {
        return ['Ceftriaxone', 'Cefotaxime', 'Ceftazidime'];
    }
    if ($group === 'CARBAPENEMS') {
        $m = ['Imipenem', 'Meropenem', 'Doripenem'];
        if (!in_array($org_key, ['organism_pseudomonas_aeruginosa', 'organism_acinetobacter_baumannii'], true)) {
            $m[] = 'Ertapenem';
        }
        return $m;
    }
    if ($group === 'FLUOROQUINOLONES') {
        return ['Ciprofloxacin', 'Levofloxacin'];
    }
    if ($group === 'AMINOGLYCOSIDES') {
        return ['Gentamicin', 'Amikacin'];
    }
    if ($group === 'METHICILLIN') {
        return ['Oxacillin', 'Cefoxitin'];
    }
    return [];
}

function amr_amass_worst_ris(array $values) {
    $rank = ['R' => 3, 'I' => 2, 'S' => 1];
    $best = '';
    $bestn = 0;
    foreach ($values as $v) {
        $n = $rank[$v] ?? 0;
        if ($n > $bestn) {
            $bestn = $n;
            $best = $v;
        }
    }
    return $best;
}

function amr_amass_wilson($x, $n) {
    $x = (int)$x;
    $n = (int)$n;
    if ($n <= 0) {
        return ['pct' => '', 'lo' => '', 'hi' => ''];
    }
    $z = 1.95996398454;
    $phat = $x / $n;
    $den = 1 + ($z * $z) / $n;
    $mid = ($phat + ($z * $z) / (2 * $n)) / $den;
    $bound = ($z * sqrt(($phat * (1 - $phat) + ($z * $z) / (4 * $n)) / $n)) / $den;
    $lo = max(0, ($mid - $bound) * 100);
    $hi = min(100, ($mid + $bound) * 100);
    return [
        'pct' => round(($x / $n) * 100, 1),
        'lo' => round($lo, 1),
        'hi' => round($hi, 1),
    ];
}

function amr_amass_freq_per_100k($x, $n) {
    $ci = amr_amass_wilson($x, $n);
    $n = (int)$n;
    if ($n <= 0) {
        return ['rate' => '', 'lo' => '', 'hi' => ''];
    }
    return [
        'rate' => round(((int)$x / $n) * 100000, 2),
        'lo' => $ci['lo'] === '' ? '' : round(((float)$ci['lo'] / 100) * 100000, 2),
        'hi' => $ci['hi'] === '' ? '' : round(((float)$ci['hi'] / 100) * 100000, 2),
    ];
}

function amr_amass_isolate_ris(array $row_atb, $org_key, $atb) {
    $groups = ['3GC', 'CARBAPENEMS', 'FLUOROQUINOLONES', 'AMINOGLYCOSIDES', 'METHICILLIN'];
    if (in_array($atb, $groups, true)) {
        $vals = [];
        foreach (amr_amass_group_members($atb, $org_key) as $m) {
            if (!empty($row_atb[$m])) {
                $vals[] = $row_atb[$m];
            }
        }
        return amr_amass_worst_ris($vals);
    }
    return $row_atb[$atb] ?? '';
}

function amr_amass_dedup_first(array $isolates) {
    usort($isolates, function ($a, $b) {
        $c = strcmp($a['hn'], $b['hn']);
        if ($c !== 0) {
            return $c;
        }
        $c = strcmp($a['org_key'], $b['org_key']);
        if ($c !== 0) {
            return $c;
        }
        return strcmp($a['date'], $b['date']);
    });
    $out = [];
    $seen = [];
    foreach ($isolates as $iso) {
        $k = $iso['hn'] . '|' . $iso['org_key'];
        if (isset($seen[$k])) {
            continue;
        }
        $seen[$k] = true;
        $out[] = $iso;
    }
    return $out;
}

function amr_amass_match_admission(array $iso, array $adm_by_hn) {
    $list = $adm_by_hn[$iso['hn']] ?? [];
    if (!$list || $iso['date'] === '') {
        return null;
    }
    $best = null;
    foreach ($list as $adm) {
        if ($adm['admit'] === '') {
            continue;
        }
        if ($iso['date'] < $adm['admit']) {
            continue;
        }
        if ($adm['discharge'] !== '' && $iso['date'] > $adm['discharge']) {
            continue;
        }
        if ($best === null || $adm['admit'] > $best['admit']) {
            $best = $adm;
        }
    }
    return $best;
}

function amr_amass_origin($spec_date, $admit_date) {
    if ($spec_date === '' || $admit_date === '') {
        return '';
    }
    $d = (int)round((strtotime($spec_date) - strtotime($admit_date)) / 86400);
    return $d >= 2 ? 'Hospital' : 'Community';
}

function amr_amass_amr_table(array $isolates) {
    $rows = [];
    foreach (amr_amass_priority_orgs() as $org_key => $meta) {
        $org_iso = array_values(array_filter($isolates, function ($i) use ($org_key) {
            return $i['org_key'] === $org_key;
        }));
        foreach (amr_amass_org_atb_list($org_key) as $atb) {
            $r = 0;
            $s = 0;
            $n = 0;
            foreach ($org_iso as $iso) {
                $ris = amr_amass_isolate_ris($iso['atb'], $org_key, $atb);
                if ($ris === '') {
                    continue;
                }
                $n++;
                if ($ris === 'R') {
                    $r++;
                } elseif ($ris === 'S' || $ris === 'I') {
                    $s++;
                }
            }
            if ($n === 0) {
                continue;
            }
            $ci = amr_amass_wilson($r, $n);
            $rows[] = [
                'Organism' => $meta[0],
                'Antibiotic' => $atb,
                'Susceptible(N)' => $n - $r,
                'Non-susceptible(N)' => $r,
                'Total(N)' => $n,
                'Non-susceptible(%)' => $ci['pct'],
                'lower95CI(%)*' => $ci['lo'],
                'upper95CI(%)*' => $ci['hi'],
            ];
        }
    }
    return $rows;
}

function amr_amass_run_analysis($con = null) {
    $dir = amr_amass_upload_dir();
    $out = amr_amass_results_dir();
    $micro_csv = $dir . '/microbiology_data.csv';
    $micro_xlsx = $dir . '/microbiology_data.xlsx';
    if (!is_file($micro_csv) && !is_file($micro_xlsx)) {
        return ['ok' => false, 'error' => 'ยังไม่มี microbiology_data — ดึงจาก HOSxP ก่อน'];
    }

    $dict_name = [];
    if ($con && function_exists('amr_amass_micro_abx_columns')) {
        $dict_name = amr_amass_micro_abx_columns($con);
    }

    $micro = amr_amass_load_source_table('microbiology_data.xlsx');
    $adm = amr_amass_load_source_table('hospital_admission_data.xlsx');
    $drug = amr_amass_load_source_table('drug_data.xlsx');

    $isolates_all = [];
    $blood_raw_n = 0;
    $blood_collected = 0;
    $blood_neg = 0;
    $blood_pos = 0;
    $blood_pos_survey = 0;
    $blood_hn = [];
    $blood_events = [];
    $blood_cultures = [];
    $month_micro = [];
    $dates = [];
    foreach ($micro['rows'] as $row) {
        $org_raw = $row['CRESULT'] ?? $row['organism'] ?? '';
        $spec = $row['SPECIMEN'] ?? $row['CSOURCE'] ?? $row['specimen_type'] ?? '';
        $hn = amr_amass_clean_hn($row['HN9_HIS'] ?? $row['HN'] ?? $row['hospital_number'] ?? '');
        $date = amr_amass_parse_date($row['DATE_DATA'] ?? $row['CDATE'] ?? $row['specimen_collection_date'] ?? '');
        $is_blood = amr_amass_is_blood($spec);
        $is_nogrowth = amr_amass_is_nogrowth($org_raw) || trim((string)$org_raw) === '';
        if ($date !== '') {
            $dates[] = $date;
            $ym = substr($date, 0, 7);
            if ($ym !== '' && $ym !== '0000-00') {
                if (!isset($month_micro[$ym])) {
                    $month_micro[$ym] = 0;
                }
                $month_micro[$ym]++;
            }
        }
        if ($is_blood) {
            $blood_collected++;
            if ($hn !== '') {
                $blood_hn[$hn] = true;
                if ($date !== '') {
                    $blood_events[] = ['hn' => $hn, 'date' => $date];
                }
            }
            if ($is_nogrowth) {
                $blood_neg++;
            } else {
                $blood_pos++;
                if (amr_amass_map_organism($org_raw) !== '') {
                    $blood_pos_survey++;
                }
            }
            $blood_cultures[] = [
                'hn' => $hn,
                'date' => $date,
                'org_raw' => trim((string)$org_raw),
                'nogrowth' => $is_nogrowth,
                'contaminant' => !$is_nogrowth && amr_amass_is_possible_contaminant($org_raw),
            ];
        }
        if ($is_nogrowth || $hn === '') {
            continue;
        }
        $org_key = amr_amass_map_organism($org_raw);
        if ($org_key === '') {
            continue;
        }
        $atb = [];
        foreach ($row as $col => $val) {
            if (in_array($col, ['HN9_HIS', 'HN', 'DATE_DATA', 'CDATE', 'SPECIMEN', 'CSOURCE', 'CRESULT', 'hospital_number', 'organism', 'specimen_type', 'specimen_collection_date'], true)) {
                continue;
            }
            $ris = amr_amass_map_ris($val);
            if ($ris === '') {
                continue;
            }
            $canon = amr_amass_canon_atb($col, $dict_name[$col] ?? '');
            $atb[$canon] = amr_amass_worst_ris([$atb[$canon] ?? '', $ris]);
        }
        $iso = [
            'hn' => $hn,
            'date' => $date,
            'specimen' => $spec,
            'org_key' => $org_key,
            'org_raw' => $org_raw,
            'blood' => amr_amass_is_blood($spec),
            'atb' => $atb,
        ];
        $isolates_all[] = $iso;
        if ($iso['blood']) {
            $blood_raw_n++;
        }
    }

    $adm_by_hn = [];
    $patient_days = 0;
    $patient_days_his = 0;
    $adm_dates = [];
    $month_adm = [];
    $adm_unique = [];
    $adm_died_unique = [];
    foreach ($adm['rows'] as $row) {
        $hn = amr_amass_clean_hn($row['HN'] ?? $row['hospital_number'] ?? '');
        $admit = amr_amass_parse_date($row['Admit'] ?? $row['date_of_admission'] ?? '');
        $dc = amr_amass_parse_date($row['Discharge'] ?? $row['date_of_discharge'] ?? '');
        if ($hn === '' || $admit === '') {
            continue;
        }
        $adm_dates[] = $admit;
        $ym = substr($admit, 0, 7);
        if ($ym !== '' && $ym !== '0000-00') {
            if (!isset($month_adm[$ym])) {
                $month_adm[$ym] = 0;
            }
            $month_adm[$ym]++;
        }
        $adm_unique[$hn] = true;
        $died = amr_amass_is_died($row['dcstatus'] ?? '', $row['discharge_type'] ?? '');
        if ($died) {
            $adm_died_unique[$hn] = true;
        }
        if ($dc !== '' && $dc >= $admit) {
            $los = (int)round((strtotime($dc) - strtotime($admit)) / 86400) + 1;
            $patient_days += $los;
            $patient_days_his += max(0, $los - 2);
        }
        $dc_type = trim((string)($row['discharge_type'] ?? $row['dcstatus'] ?? ''));
        $adm_by_hn[$hn][] = [
            'admit' => $admit,
            'discharge' => $dc,
            'died' => $died,
            'dama' => preg_match('/dama|against|หนี|ปฏิเสธ/u', $dc_type) === 1,
            'ward' => $row['ward_ad'] ?? $row['ward'] ?? $row['ward_dc'] ?? '',
            'ward_dc' => $row['ward_dc'] ?? '',
        ];
    }

    $blood = array_values(array_filter($isolates_all, function ($i) {
        return $i['blood'];
    }));
    foreach ($blood as &$iso) {
        $adm_row = amr_amass_match_admission($iso, $adm_by_hn);
        $iso['origin'] = $adm_row ? amr_amass_origin($iso['date'], $adm_row['admit']) : '';
        $iso['died'] = $adm_row ? $adm_row['died'] : false;
        $iso['matched'] = $adm_row !== null;
        $iso['ward'] = $adm_row ? trim((string)($adm_row['ward'] ?? '')) : '';
    }
    unset($iso);

    $blood_dedup = amr_amass_dedup_first($blood);
    $sec2 = amr_amass_amr_table($blood_dedup);

    $n_com = 0;
    $n_hos = 0;
    $n_unk = 0;
    foreach ($blood_dedup as $iso) {
        $o = (string)($iso['origin'] ?? '');
        if ($o === 'Community') {
            $n_com++;
        } elseif ($o === 'Hospital') {
            $n_hos++;
        } else {
            $n_unk++;
        }
    }

    $first_blood = [];
    foreach ($blood_events as $ev) {
        $hn = $ev['hn'];
        if ($hn === '' || $ev['date'] === '') {
            continue;
        }
        if (!isset($first_blood[$hn]) || $ev['date'] < $first_blood[$hn]) {
            $first_blood[$hn] = $ev['date'];
        }
    }
    $n_tested_com = 0;
    $n_tested_hos = 0;
    $n_tested_unk = 0;
    foreach ($first_blood as $hn => $bdate) {
        $adm_row = amr_amass_match_admission(['hn' => $hn, 'date' => $bdate], $adm_by_hn);
        if (!$adm_row) {
            $n_tested_unk++;
            continue;
        }
        $orig = amr_amass_origin($bdate, $adm_row['admit']);
        if ($orig === 'Community') {
            $n_tested_com++;
        } elseif ($orig === 'Hospital') {
            $n_tested_hos++;
        } else {
            $n_tested_unk++;
        }
    }
    $n_blood_patients = count($blood_hn);

    $sec3 = [];
    foreach (['Community', 'Hospital'] as $origin) {
        $subset = array_values(array_filter($blood_dedup, function ($i) use ($origin) {
            return ($i['origin'] ?? '') === $origin;
        }));
        foreach (amr_amass_amr_table($subset) as $row) {
            $row['Infection_origin'] = $origin . '-origin';
            $sec3[] = $row;
        }
    }

    $sec4 = [];
    $sec6 = [];
    foreach (amr_amass_priority_orgs() as $org_key => $meta) {
        $org_iso = array_values(array_filter($blood_dedup, function ($i) use ($org_key) {
            return $i['org_key'] === $org_key && !empty($i['matched']);
        }));
        $died = 0;
        foreach ($org_iso as $iso) {
            if (!empty($iso['died'])) {
                $died++;
            }
        }
        $n = count($org_iso);
        $ci = amr_amass_wilson($died, $n);
        $sec4[] = [
            'Organism' => $meta[0],
            'Number_of_deaths' => $died,
            'Total_number_of_patients' => $n,
            'Mortality(%)' => $ci['pct'],
            'Mortality_lower_95ci' => $ci['lo'],
            'Mortality_upper_95ci' => $ci['hi'],
        ];
        foreach (['Community', 'Hospital'] as $origin) {
            $sub = array_values(array_filter($org_iso, function ($i) use ($origin) {
                return ($i['origin'] ?? '') === $origin;
            }));
            $d = 0;
            foreach ($sub as $iso) {
                if (!empty($iso['died'])) {
                    $d++;
                }
            }
            $nn = count($sub);
            $ci2 = amr_amass_wilson($d, $nn);
            $sec6[] = [
                'Organism' => $meta[0],
                'Infection_origin' => $origin . '-origin',
                'Number_of_deaths' => $d,
                'Total_number_of_patients' => $nn,
                'Mortality(%)' => $ci2['pct'],
                'Mortality_lower_95ci' => $ci2['lo'],
                'Mortality_upper_95ci' => $ci2['hi'],
            ];
        }
    }

    $sec5 = [];
    $denom = $patient_days > 0 ? $patient_days : 0;
    foreach (['Community', 'Hospital'] as $origin) {
        foreach (amr_amass_priority_orgs() as $org_key => $meta) {
            $n = 0;
            foreach ($blood_dedup as $iso) {
                if ($iso['org_key'] === $org_key && ($iso['origin'] ?? '') === $origin) {
                    $n++;
                }
            }
            $rate = $denom > 0 ? round(($n / $denom) * 100000, 2) : '';
            $sec5[] = [
                'Organism' => $meta[0],
                'Infection_origin' => $origin . '-origin',
                'Number_of_patients' => $n,
                'Patient_days' => $denom,
                'Incidence_per_100000_patient_days' => $rate,
            ];
        }
    }

    $byorg = [];
    $byorg_dedup = [];
    foreach (amr_amass_priority_orgs() as $org_key => $meta) {
        $raw = 0;
        $ded = 0;
        foreach ($blood as $iso) {
            if ($iso['org_key'] === $org_key) {
                $raw++;
            }
        }
        foreach ($blood_dedup as $iso) {
            if ($iso['org_key'] === $org_key) {
                $ded++;
            }
        }
        $byorg[] = [
            'Organism' => $meta[0],
            'Number_of_blood_specimens_culture_positive_for_the_organism' => $raw,
        ];
        $byorg_dedup[] = [
            'Organism' => $meta[0],
            'Number_of_blood_specimens_culture_positive_deduplicated' => $ded,
        ];
    }

    $n_blood_patients = isset($n_blood_patients) ? $n_blood_patients : count($blood_hn);
    $sec4_freq = [];
    $sec5_freq = [];
    foreach (amr_amass_priority_orgs() as $org_key => $meta) {
        $n = 0;
        foreach ($blood_dedup as $iso) {
            if ($iso['org_key'] === $org_key) {
                $n++;
            }
        }
        $f = amr_amass_freq_per_100k($n, $n_blood_patients);
        $sec4_freq[] = [
            'Organism' => $meta[0],
            'Number_of_patients' => $n,
            'frequency_per_tested' => $f['rate'],
            'frequency_per_tested_lci' => $f['lo'],
            'frequency_per_tested_uci' => $f['hi'],
        ];
        foreach (['Community' => $n_tested_com, 'Hospital' => $n_tested_hos] as $origin => $denom) {
            $no = 0;
            foreach ($blood_dedup as $iso) {
                if ($iso['org_key'] === $org_key && ($iso['origin'] ?? '') === $origin) {
                    $no++;
                }
            }
            $fo = amr_amass_freq_per_100k($no, $denom);
            $sec5_freq[] = [
                'Organism' => $meta[0],
                'Infection_origin' => $origin . '-origin',
                'Number_of_patients' => $no,
                'Tested_patients' => $denom,
                'frequency_per_tested' => $fo['rate'],
                'frequency_per_tested_lci' => $fo['lo'],
                'frequency_per_tested_uci' => $fo['hi'],
            ];
        }
    }

    $all_months = array_unique(array_merge(array_keys($month_micro), array_keys($month_adm)));
    sort($all_months);
    $month_rows = [];
    foreach ($all_months as $ym) {
        $month_rows[] = [
            'Month' => date('F Y', strtotime($ym . '-01')),
            'Number_of_specimen_in_microbiology_data_file' => (int)($month_micro[$ym] ?? 0),
            'Number_of_hospital_records_in_hospital_admission_data_file' => (int)($month_adm[$ym] ?? 0),
        ];
    }

    $date_min = $dates ? min($dates) : '';
    $date_max = $dates ? max($dates) : '';
    $adm_date_min = $adm_dates ? min($adm_dates) : '';
    $adm_date_max = $adm_dates ? max($adm_dates) : '';
    $n_patients_adm = count($adm_unique);
    $n_deaths_adm = count($adm_died_unique);
    $mortality_overall = $n_patients_adm > 0 ? round(($n_deaths_adm / $n_patients_adm) * 100, 1) : '';
    $cover = function_exists('amr_amass_cover_info') ? amr_amass_cover_info($con) : [
        'hospital_name' => amr_amass_hospital_name($con),
        'country' => 'Thailand',
        'contact_person' => '',
        'contact_address' => '',
        'contact_email' => '',
        'notes_on_the_cover' => '',
        'notes_on_fungal_identification' => '',
    ];
    $sec1 = [
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Hospital_name', 'Values' => $cover['hospital_name']],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Country', 'Values' => $cover['country']],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Contact_person', 'Values' => $cover['contact_person']],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Contact_address', 'Values' => $cover['contact_address']],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Contact_email', 'Values' => $cover['contact_email']],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'notes_on_the_cover', 'Values' => $cover['notes_on_the_cover']],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'notes_on_fungal_identification', 'Values' => $cover['notes_on_fungal_identification']],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Number_of_records', 'Values' => count($micro['rows'])],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Minimum_date', 'Values' => $date_min],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Maximum_date', 'Values' => $date_max],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Number_of_blood_specimens_collected', 'Values' => $blood_collected],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Number_of_blood_culture_negative', 'Values' => $blood_neg],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Number_of_blood_culture_positive', 'Values' => $blood_pos],
        ['Type_of_data_file' => 'microbiology_data', 'Parameters' => 'Number_of_blood_culture_positive_for_organism_under_this_survey', 'Values' => $blood_pos_survey],
        ['Type_of_data_file' => 'hospital_admission_data', 'Parameters' => 'Number_of_records', 'Values' => count($adm['rows'])],
        ['Type_of_data_file' => 'hospital_admission_data', 'Parameters' => 'Minimum_date', 'Values' => $adm_date_min],
        ['Type_of_data_file' => 'hospital_admission_data', 'Parameters' => 'Maximum_date', 'Values' => $adm_date_max],
        ['Type_of_data_file' => 'hospital_admission_data', 'Parameters' => 'Patient_days', 'Values' => $patient_days],
        ['Type_of_data_file' => 'hospital_admission_data', 'Parameters' => 'Patient_days_his', 'Values' => $patient_days_his],
        ['Type_of_data_file' => 'hospital_admission_data', 'Parameters' => 'Number_of_patients_included', 'Values' => $n_patients_adm],
        ['Type_of_data_file' => 'hospital_admission_data', 'Parameters' => 'Number_of_deaths', 'Values' => $n_deaths_adm],
        ['Type_of_data_file' => 'hospital_admission_data', 'Parameters' => 'Mortality', 'Values' => $mortality_overall],
        ['Type_of_data_file' => 'merged_data', 'Parameters' => 'Number_of_patients_sampled_for_blood_culture', 'Values' => $n_blood_patients],
        ['Type_of_data_file' => 'merged_data', 'Parameters' => 'Number_of_patients_with_blood_culture_positive_for_organism_under_this_survey', 'Values' => count($blood_dedup)],
        ['Type_of_data_file' => 'merged_data', 'Parameters' => 'Number_of_patients_with_community_origin_BSI', 'Values' => $n_com],
        ['Type_of_data_file' => 'merged_data', 'Parameters' => 'Number_of_patients_with_hospital_origin_BSI', 'Values' => $n_hos],
        ['Type_of_data_file' => 'merged_data', 'Parameters' => 'Number_of_patients_with_unknown_origin_BSI', 'Values' => $n_unk],
        ['Type_of_data_file' => 'merged_data', 'Parameters' => 'Number_of_patients_with_blood_culture_within_first_2_days_of_admission', 'Values' => $n_tested_com],
        ['Type_of_data_file' => 'merged_data', 'Parameters' => 'Number_of_patients_with_blood_culture_within_after_2_days_of_admission', 'Values' => $n_tested_hos],
        ['Type_of_data_file' => 'merged_data', 'Parameters' => 'Number_of_patients_with_unknown_origin', 'Values' => $n_tested_unk],
        ['Type_of_data_file' => 'overall_data', 'Parameters' => 'Minimum_date', 'Values' => $date_min],
        ['Type_of_data_file' => 'overall_data', 'Parameters' => 'Maximum_date', 'Values' => $date_max],
        ['Type_of_data_file' => 'overall_data', 'Parameters' => 'Engine', 'Values' => 'THAM Hos-Safe AMASS engine (WHO GLASS, AMASS v4.0 rules)'],
        ['Type_of_data_file' => 'overall_data', 'Parameters' => 'Blood_priority_isolates_deduplicated', 'Values' => count($blood_dedup)],
    ];

    $annex_b = amr_amass_annex_b_compute($blood_cultures, $blood_dedup, $adm_by_hn);
    $annex_c = amr_amass_annex_c_compute($blood_dedup);
    $annex_d = amr_amass_annex_d_compute($drug['rows'], $adm_by_hn);
    $amu = $annex_d['amu'];

    $files = [
        'ver3_Report1_page3_results.csv' => [['Type_of_data_file', 'Parameters', 'Values'], $sec1],
        'ver3_Report1_page4_counts_by_month.csv' => [['Month', 'Number_of_specimen_in_microbiology_data_file', 'Number_of_hospital_records_in_hospital_admission_data_file'], $month_rows],
        'ver3_Report2_AMR_proportion_table.csv' => [['Organism', 'Antibiotic', 'Susceptible(N)', 'Non-susceptible(N)', 'Total(N)', 'Non-susceptible(%)', 'lower95CI(%)*', 'upper95CI(%)*'], $sec2],
        'ver3_Report2_page6_counts_by_organism.csv' => [['Organism', 'Number_of_blood_specimens_culture_positive_for_the_organism'], $byorg],
        'ver3_Report2_page6_patients_under_this_surveillance_by_organism.csv' => [['Organism', 'Number_of_blood_specimens_culture_positive_deduplicated'], $byorg_dedup],
        'ver3_Report3_table.csv' => [['Organism', 'Antibiotic', 'Infection_origin', 'Susceptible(N)', 'Non-susceptible(N)', 'Total(N)', 'Non-susceptible(%)', 'lower95CI(%)*', 'upper95CI(%)*'], $sec3],
        'ver3_Report4_frequency_priority_pathogen.csv' => [['Organism', 'Number_of_deaths', 'Total_number_of_patients', 'Mortality(%)', 'Mortality_lower_95ci', 'Mortality_upper_95ci'], $sec4],
        'ver3_Report4_frequency_blood_pathogen.csv' => [['Organism', 'Number_of_patients', 'frequency_per_tested', 'frequency_per_tested_lci', 'frequency_per_tested_uci'], $sec4_freq],
        'ver3_Report5_incidence_blood_samples_community_origin.csv' => [['Organism', 'Infection_origin', 'Number_of_patients', 'Patient_days', 'Incidence_per_100000_patient_days'], array_values(array_filter($sec5, function ($r) {
            return strpos($r['Infection_origin'], 'Community') === 0;
        }))],
        'ver3_Report5_incidence_blood_samples_hospital_origin.csv' => [['Organism', 'Infection_origin', 'Number_of_patients', 'Patient_days', 'Incidence_per_100000_patient_days'], array_values(array_filter($sec5, function ($r) {
            return strpos($r['Infection_origin'], 'Hospital') === 0;
        }))],
        'ver3_Report5_frequency_community_origin.csv' => [['Organism', 'Infection_origin', 'Number_of_patients', 'Tested_patients', 'frequency_per_tested', 'frequency_per_tested_lci', 'frequency_per_tested_uci'], array_values(array_filter($sec5_freq, function ($r) {
            return strpos($r['Infection_origin'], 'Community') === 0;
        }))],
        'ver3_Report5_frequency_hospital_origin.csv' => [['Organism', 'Infection_origin', 'Number_of_patients', 'Tested_patients', 'frequency_per_tested', 'frequency_per_tested_lci', 'frequency_per_tested_uci'], array_values(array_filter($sec5_freq, function ($r) {
            return strpos($r['Infection_origin'], 'Hospital') === 0;
        }))],
        'ver3_Report6_mortality_table.csv' => [['Organism', 'Infection_origin', 'Number_of_deaths', 'Total_number_of_patients', 'Mortality(%)', 'Mortality_lower_95ci', 'Mortality_upper_95ci'], $sec6],
        'ver3_AnnexB_proportion_table_blood.csv' => [['Indicators', 'Description', 'Number', 'Denominator', 'Proportion'], $annex_b['indicators']],
        'ver3_AnnexB_proportion_table_blood_bymonth.csv' => [['Month', 'blood_culture_contamination_rate', 'notifiable_antibiotic_pathogen', 'potential_AST_errors', 'Total_blood_positive_and_negative(N)', 'Total_blood_positive_AST(N)'], $annex_b['by_month']],
        'AnnexB1b_blood_culture_contamination.csv' => [['Organism', 'Number_of_possible_contaminants', 'Percent_of_contaminants'], $annex_b['contaminants']],
        'AnnexB2b_blood_culture_contamination_among_inpatients.csv' => [['Description', 'Number', 'Denominator', 'Proportion'], $annex_b['inpatient']],
        'ver3_AnnexC_cluster_signals.csv' => [['AMR_pathogen', 'Description', 'Ward', 'Week', 'start_signal_date', 'end_signal_date', 'observed_cases', 'expected_cases', 'observed_expected_ratio', 'p_value', 'method'], $annex_c['clusters']],
        'ver3_AnnexC_ward_counts.csv' => [['AMR_pathogen', 'Organism', 'Ward', 'Hospital_origin_isolates'], $annex_c['ward_counts']],
        'ver3_AnnexC_ast_profiles.csv' => [['AMR_pathogen', 'Ward', 'AST_profile', 'Isolates'], $annex_c['profiles']],
        'AnnexD1_summary.csv' => [['Parameter', 'Value'], $annex_d['summary']],
        'AnnexD1_AMU_by_month.csv' => [['Month', 'Number_of_drug_records', 'Number_of_antibiotic_records', 'Number_of_antifungal_records'], $annex_d['by_month']],
        'AnnexD1_AMU_by_route.csv' => [['Route_of_administration', 'Number_of_antibiotic_records', 'Number_of_antifungal_records'], $annex_d['by_route']],
        'AnnexD1_AMU_DOT_by_parentaral_atb.csv' => [['RANK', 'Antibiotic', 'AWaRe_classification', 'DOT', 'DOT_percent', 'DOT_percent_text', 'DOT_per1000patient_days'], $annex_d['dot_atb']],
        'AnnexD1_AMU_DOT_by_Aware_class.csv' => [['AWaRe_classification', 'DOT', 'DOT_percent', 'DOT_percent_text', 'DOT_per1000patient_days'], $annex_d['dot_aware']],
        'AnnexD1_AMU_DOT_by_dept.csv' => [['Department', 'DOT', 'DOT_percent', 'DOT_percent_text', 'DOT_per1000patient_days'], $annex_d['dot_dept']],
        'AnnexD1_AMU_DOT_by_parentaral_atf.csv' => [['Antifungal', 'DOT', 'DOT_per1000patient_days'], $annex_d['dot_atf']],
        'ver3_AnnexD_amu_top_drugs.csv' => [['drug_name', 'prescriptions'], $amu],
    ];
    foreach ($files as $fn => $pair) {
        amr_amass_csv_write($out . '/' . $fn, $pair[0], $pair[1]);
    }

    $meta = [
        'engine' => 'thamhossafe',
        'amass_rules' => 'v4.0-4028 WHO GLASS',
        'ran_at' => date('Y-m-d H:i:s'),
        'micro_rows' => count($micro['rows']),
        'admission_rows' => count($adm['rows']),
        'drug_rows' => count($drug['rows']),
        'blood_priority_raw' => $blood_raw_n,
        'blood_priority_dedup' => count($blood_dedup),
        'blood_collected' => $blood_collected,
        'blood_neg' => $blood_neg,
        'blood_pos' => $blood_pos,
        'n_blood_patients' => $n_blood_patients,
        'patient_days' => $patient_days,
        'patient_days_his' => $patient_days_his,
        'date_min' => $date_min,
        'date_max' => $date_max,
        'annex_b' => 'computed',
        'annex_c' => $annex_c['method'],
        'annex_c_clusters' => count($annex_c['clusters']),
        'annex_d' => 'computed',
        'annex_d_dot' => $annex_d['kpis']['dot'],
        'annex_d_prevalence' => $annex_d['kpis']['prevalence_text'],
        'note' => '%R = จำนวน isolate ที่ผล R / จำนวนที่ตรวจยา (deduplicate เชื้อแรกต่อผู้ป่วย ตาม AMASS). Origin ใช้กฎ 2 calendar days ของการนอนโรงพยาบาล',
    ];
    @file_put_contents($out . '/analysis_meta.json', json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    @chmod($out . '/analysis_meta.json', 0666);

    return [
        'ok' => true,
        'meta' => $meta,
        'section2' => $sec2,
        'section3' => $sec3,
        'section4' => $sec4,
        'section5' => $sec5,
        'section6' => $sec6,
        'byorg' => $byorg_dedup,
        'amu' => $amu,
        'kpis' => amr_amass_result_kpis(),
    ];
}

function amr_amass_dashboard_tables() {
    $dir = amr_amass_results_dir();
    $load = function ($fn) use ($dir) {
        return function_exists('amr_amass_read_csv_assoc') ? amr_amass_read_csv_assoc($dir . '/' . $fn) : [];
    };
    $meta_path = $dir . '/analysis_meta.json';
    $meta = [];
    if (is_file($meta_path)) {
        $raw = json_decode((string)file_get_contents($meta_path), true);
        if (is_array($raw)) {
            $meta = $raw;
        }
    }
    return [
        'meta' => $meta,
        'section2' => $load('ver3_Report2_AMR_proportion_table.csv'),
        'section3' => $load('ver3_Report3_table.csv'),
        'section4' => $load('ver3_Report4_frequency_priority_pathogen.csv'),
        'section5c' => $load('ver3_Report5_incidence_blood_samples_community_origin.csv'),
        'section5h' => $load('ver3_Report5_incidence_blood_samples_hospital_origin.csv'),
        'section6' => $load('ver3_Report6_mortality_table.csv'),
        'byorg' => $load('ver3_Report2_page6_patients_under_this_surveillance_by_organism.csv'),
        'byorg_raw' => $load('ver3_Report2_page6_counts_by_organism.csv'),
        'section4freq' => $load('ver3_Report4_frequency_blood_pathogen.csv'),
        'section5c_freq' => $load('ver3_Report5_frequency_community_origin.csv'),
        'section5h_freq' => $load('ver3_Report5_frequency_hospital_origin.csv'),
        'section1month' => $load('ver3_Report1_page4_counts_by_month.csv'),
        'amu' => $load('ver3_AnnexD_amu_top_drugs.csv'),
        'annex_b' => $load('ver3_AnnexB_proportion_table_blood.csv'),
        'annex_b_month' => $load('ver3_AnnexB_proportion_table_blood_bymonth.csv'),
        'annex_b_cont' => $load('AnnexB1b_blood_culture_contamination.csv'),
        'annex_b_inp' => $load('AnnexB2b_blood_culture_contamination_among_inpatients.csv'),
        'annex_c' => $load('ver3_AnnexC_cluster_signals.csv'),
        'annex_c_ward' => $load('ver3_AnnexC_ward_counts.csv'),
        'annex_c_prof' => $load('ver3_AnnexC_ast_profiles.csv'),
        'annex_d_summary' => $load('AnnexD1_summary.csv'),
        'annex_d_month' => $load('AnnexD1_AMU_by_month.csv'),
        'annex_d_route' => $load('AnnexD1_AMU_by_route.csv'),
        'annex_d_dot' => $load('AnnexD1_AMU_DOT_by_parentaral_atb.csv'),
        'annex_d_aware' => $load('AnnexD1_AMU_DOT_by_Aware_class.csv'),
        'annex_d_dept' => $load('AnnexD1_AMU_DOT_by_dept.csv'),
        'annex_d_atf' => $load('AnnexD1_AMU_DOT_by_parentaral_atf.csv'),
    ];
}
