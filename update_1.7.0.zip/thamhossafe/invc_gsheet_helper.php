<?php
/**
 * เชื่อม Google Sheet จัดซื้อ → เทียบรายการคลัง = 0 ที่รอตรวจรับ
 * คอลัมน์เริ่มต้น: E=รหัสยา, H=Pack, I=ORDER, N=วันที่รับ
 *
 * โหมดดึงข้อมูล:
 * - service_account: Google Sheets API (Sheet แชร์เฉพาะ SA ได้)
 * - csv: export สาธารณะ
 * - auto: ใช้ SA ถ้ามี key, ไม่มีแล้วค่อย CSV
 */

function invc_gsheet_default_config() {
    return [
        'invc_gsheet_enabled' => '1',
        'invc_gsheet_url' => 'https://docs.google.com/spreadsheets/d/1tqIBijYdnnyPCZz1a0JTIAqNfcp3YSztJ-ALK8gWSag/edit?usp=sharing',
        'invc_gsheet_gid' => '0',
        'invc_gsheet_col_code' => 'E',
        'invc_gsheet_col_pack' => 'H',
        'invc_gsheet_col_order' => 'I',
        'invc_gsheet_col_recv' => 'N',
        'invc_gsheet_cache_ttl' => '60',
        'invc_gsheet_auth' => 'auto',
        'invc_gsheet_sa_email' => '',
    ];
}

function invc_gsheet_config_keys() {
    return array_keys(invc_gsheet_default_config());
}

function invc_gsheet_sa_path() {
    // เก็บเป็น .php เพื่อไม่ถูกดาวน์โหลดตรงๆ แม้ไม่มี .htaccess
    return __DIR__ . '/secure/invc_gsheet_sa.php';
}

function invc_gsheet_letter_to_index($letter) {
    $letter = strtoupper(trim((string)$letter));
    if (!preg_match('/^[A-Z]{1,2}$/', $letter)) {
        return null;
    }
    $n = 0;
    $len = strlen($letter);
    for ($i = 0; $i < $len; $i++) {
        $n = $n * 26 + (ord($letter[$i]) - 64);
    }
    return $n - 1;
}

function invc_gsheet_extract_id($url) {
    $url = trim((string)$url);
    if ($url === '') {
        return '';
    }
    if (preg_match('#/spreadsheets/d/([a-zA-Z0-9_-]+)#', $url, $m)) {
        return $m[1];
    }
    if (preg_match('/^[a-zA-Z0-9_-]{20,}$/', $url)) {
        return $url;
    }
    return '';
}

function invc_gsheet_extract_gid($url, $fallback = '0') {
    $url = trim((string)$url);
    if (preg_match('/[?#&]gid=([0-9]+)/', $url, $m)) {
        return $m[1];
    }
    $fallback = preg_replace('/\D+/', '', (string)$fallback);
    return $fallback !== '' ? $fallback : '0';
}

function invc_gsheet_csv_url(array $cfg) {
    $id = invc_gsheet_extract_id($cfg['invc_gsheet_url'] ?? '');
    if ($id === '') {
        return '';
    }
    $gid = invc_gsheet_extract_gid($cfg['invc_gsheet_url'] ?? '', $cfg['invc_gsheet_gid'] ?? '0');
    return 'https://docs.google.com/spreadsheets/d/' . rawurlencode($id) . '/export?format=csv&gid=' . rawurlencode($gid);
}

function invc_gsheet_parse_date($value) {
    $value = trim((string)$value);
    if ($value === '') {
        return '';
    }
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $value, $m)) {
        return $m[1] . '-' . $m[2] . '-' . $m[3];
    }
    if (preg_match('/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/', $value, $m)) {
        $d = (int)$m[1];
        $mo = (int)$m[2];
        $y = (int)$m[3];
        if ($y < 100) {
            $y += 2000;
        }
        if ($y > 2400) {
            $y -= 543;
        }
        if (!checkdate($mo, $d, $y)) {
            return '';
        }
        return sprintf('%04d-%02d-%02d', $y, $mo, $d);
    }
    $ts = strtotime(str_replace('/', '-', $value));
    return $ts ? date('Y-m-d', $ts) : '';
}

function invc_gsheet_parse_num($value) {
    $value = trim((string)$value);
    if ($value === '') {
        return 0.0;
    }
    $value = str_replace([',', ' ', '฿'], '', $value);
    if (!is_numeric($value)) {
        return 0.0;
    }
    return (float)$value;
}

function invc_gsheet_normalize_code($code) {
    $code = trim((string)$code);
    $code = preg_replace('/\s+/', '', $code);
    return $code;
}

function invc_gsheet_cache_dir() {
    $dir = sys_get_temp_dir() . '/tham_invc_gsheet';
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    return $dir;
}

function invc_gsheet_cache_path(array $cfg, $suffix = 'csv') {
    $id = invc_gsheet_extract_id($cfg['invc_gsheet_url'] ?? '');
    $gid = invc_gsheet_extract_gid($cfg['invc_gsheet_url'] ?? '', $cfg['invc_gsheet_gid'] ?? '0');
    return invc_gsheet_cache_dir() . '/sheet_' . md5($id . '|' . $gid) . '.' . $suffix;
}

function invc_gsheet_http_json($url, array $opts = []) {
    $method = strtoupper((string)($opts['method'] ?? 'GET'));
    $headers = $opts['headers'] ?? [];
    $body = $opts['body'] ?? null;
    $timeout = max(5, min(60, (int)($opts['timeout'] ?? 45)));
    if (!function_exists('curl_init')) {
        return ['ok' => false, 'code' => 0, 'error' => 'ไม่มี cURL', 'json' => null, 'raw' => ''];
    }
    $ch = curl_init($url);
    $curlHeaders = [];
    foreach ($headers as $k => $v) {
        $curlHeaders[] = $k . ': ' . $v;
    }
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $curlHeaders,
        CURLOPT_USERAGENT => 'THAM-HosSafe-INVC-GSheet',
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    $raw = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);
    if ($raw === '' && $cerr) {
        return ['ok' => false, 'code' => $code, 'error' => $cerr, 'json' => null, 'raw' => ''];
    }
    $json = json_decode($raw, true);
    if ($code < 200 || $code >= 300) {
        $msg = '';
        if (is_array($json)) {
            $msg = (string)($json['error']['message'] ?? $json['error_description'] ?? '');
        }
        return [
            'ok' => false,
            'code' => $code,
            'error' => $msg !== '' ? $msg : ('HTTP ' . $code),
            'json' => is_array($json) ? $json : null,
            'raw' => $raw,
        ];
    }
    return [
        'ok' => true,
        'code' => $code,
        'error' => '',
        'json' => is_array($json) ? $json : null,
        'raw' => $raw,
    ];
}

function invc_gsheet_b64url($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function invc_gsheet_validate_sa(array $sa) {
    $email = trim((string)($sa['client_email'] ?? ''));
    $key = trim((string)($sa['private_key'] ?? ''));
    if ($email === '' || $key === '' || strpos($key, 'BEGIN') === false) {
        return null;
    }
    if (($sa['type'] ?? '') !== '' && ($sa['type'] ?? '') !== 'service_account') {
        return null;
    }
    return $sa;
}

function invc_gsheet_load_sa_json($raw = null) {
    if ($raw === null) {
        $path = invc_gsheet_sa_path();
        if (!is_file($path)) {
            // รองรับไฟล์เก่า .json
            $legacy = __DIR__ . '/secure/invc_gsheet_sa.json';
            if (is_file($legacy)) {
                $raw = (string)@file_get_contents($legacy);
                $sa = invc_gsheet_validate_sa(json_decode($raw, true) ?: []);
                if ($sa) {
                    invc_gsheet_save_sa_json(json_encode($sa));
                    @unlink($legacy);
                    return $sa;
                }
            }
            return null;
        }
        $loaded = include $path;
        return is_array($loaded) ? invc_gsheet_validate_sa($loaded) : null;
    }
    $raw = trim((string)$raw);
    if ($raw === '') {
        return null;
    }
    $sa = json_decode($raw, true);
    if (!is_array($sa)) {
        return null;
    }
    return invc_gsheet_validate_sa($sa);
}

function invc_gsheet_sa_status() {
    $sa = invc_gsheet_load_sa_json();
    if (!$sa) {
        return ['configured' => false, 'email' => '', 'path' => invc_gsheet_sa_path()];
    }
    return [
        'configured' => true,
        'email' => (string)$sa['client_email'],
        'path' => invc_gsheet_sa_path(),
        'project_id' => (string)($sa['project_id'] ?? ''),
    ];
}

function invc_gsheet_save_sa_json($jsonText) {
    $jsonText = trim((string)$jsonText);
    if ($jsonText === '' || $jsonText === '********') {
        return ['ok' => true, 'unchanged' => true, 'email' => (invc_gsheet_sa_status()['email'] ?? '')];
    }
    if (strtoupper($jsonText) === 'CLEAR' || $jsonText === '-') {
        $path = invc_gsheet_sa_path();
        if (is_file($path)) {
            @unlink($path);
        }
        return ['ok' => true, 'cleared' => true, 'email' => ''];
    }
    $sa = invc_gsheet_load_sa_json($jsonText);
    if (!$sa) {
        return ['ok' => false, 'error' => 'JSON Service Account ไม่ถูกต้อง ต้องมี client_email และ private_key'];
    }
    $dir = dirname(invc_gsheet_sa_path());
    if (!is_dir($dir)) {
        @mkdir($dir, 0750, true);
    }
    $exported = var_export($sa, true);
    $php = "<?php\n/** Service Account credentials — do not serve as static file */\nreturn " . $exported . ";\n";
    if (@file_put_contents(invc_gsheet_sa_path(), $php) === false) {
        return ['ok' => false, 'error' => 'บันทึกไฟล์ Service Account ไม่สำเร็จ'];
    }
    // ต้องให้อ่านได้โดย PHP-FPM (www-data) — ไฟล์เป็น .php จะไม่ถูกเสิร์ฟเป็น static
    @chmod(invc_gsheet_sa_path(), 0644);
    // ล้าง token cache
    $tok = invc_gsheet_cache_dir() . '/sa_token_' . md5($sa['client_email']) . '.json';
    if (is_file($tok)) {
        @unlink($tok);
    }
    return ['ok' => true, 'email' => (string)$sa['client_email']];
}

function invc_gsheet_sa_access_token(array $sa) {
    $email = (string)$sa['client_email'];
    $cache = invc_gsheet_cache_dir() . '/sa_token_' . md5($email) . '.json';
    if (is_file($cache)) {
        $cached = json_decode((string)@file_get_contents($cache), true);
        if (is_array($cached) && !empty($cached['access_token']) && (int)($cached['exp'] ?? 0) > (time() + 60)) {
            return ['ok' => true, 'token' => $cached['access_token'], 'error' => ''];
        }
    }
    if (!function_exists('openssl_sign')) {
        return ['ok' => false, 'token' => '', 'error' => 'PHP ไม่มี OpenSSL สำหรับลงนาม JWT'];
    }
    $now = time();
    $header = invc_gsheet_b64url(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
    $claim = invc_gsheet_b64url(json_encode([
        'iss' => $email,
        'scope' => 'https://www.googleapis.com/auth/spreadsheets.readonly',
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $now,
        'exp' => $now + 3600,
    ]));
    $unsigned = $header . '.' . $claim;
    $private = openssl_pkey_get_private($sa['private_key']);
    if (!$private) {
        return ['ok' => false, 'token' => '', 'error' => 'อ่าน private_key ของ Service Account ไม่ได้'];
    }
    $sig = '';
    $ok = openssl_sign($unsigned, $sig, $private, OPENSSL_ALGO_SHA256);
    if (is_object($private) || (is_resource($private) && function_exists('openssl_free_key'))) {
        // PHP 8+: OpenSSLAsymmetricKey object; older: free key
        if (is_resource($private)) {
            @openssl_free_key($private);
        }
    }
    if (!$ok) {
        return ['ok' => false, 'token' => '', 'error' => 'ลงนาม JWT ไม่สำเร็จ'];
    }
    $jwt = $unsigned . '.' . invc_gsheet_b64url($sig);
    $res = invc_gsheet_http_json('https://oauth2.googleapis.com/token', [
        'method' => 'POST',
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
        'body' => http_build_query([
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt,
        ]),
        'timeout' => 20,
    ]);
    if (empty($res['ok']) || empty($res['json']['access_token'])) {
        return ['ok' => false, 'token' => '', 'error' => 'ขอ access token ไม่สำเร็จ: ' . ($res['error'] ?: 'unknown')];
    }
    $token = (string)$res['json']['access_token'];
    $exp = $now + (int)($res['json']['expires_in'] ?? 3600);
    @file_put_contents($cache, json_encode(['access_token' => $token, 'exp' => $exp]));
    return ['ok' => true, 'token' => $token, 'error' => ''];
}

function invc_gsheet_sheet_title_by_gid(array $meta, $gid) {
    $gid = (string)$gid;
    $sheets = $meta['sheets'] ?? [];
    if (!is_array($sheets)) {
        return '';
    }
    foreach ($sheets as $sh) {
        $props = $sh['properties'] ?? [];
        if ((string)($props['sheetId'] ?? '') === $gid) {
            return (string)($props['title'] ?? '');
        }
    }
    // fallback ชีตแรก
    if (!empty($sheets[0]['properties']['title'])) {
        return (string)$sheets[0]['properties']['title'];
    }
    return '';
}

function invc_gsheet_a1_range($title, $endCol = 'Z') {
    $title = str_replace("'", "''", (string)$title);
    $endCol = strtoupper(preg_replace('/[^A-Z]/', '', (string)$endCol) ?: 'Z');
    return "'" . $title . "'!A:" . $endCol;
}

function invc_gsheet_fetch_via_sa(array $cfg, array $sa, $force = false) {
    $id = invc_gsheet_extract_id($cfg['invc_gsheet_url'] ?? '');
    if ($id === '') {
        return ['ok' => false, 'error' => 'กรุณาใส่ลิงก์หรือ ID ของ Google Sheet', 'rows' => [], 'from_cache' => false, 'mode' => 'service_account'];
    }
    $ttl = max(30, min(3600, (int)($cfg['invc_gsheet_cache_ttl'] ?? 60)));
    $path = invc_gsheet_cache_path($cfg, 'json');
    if (!$force && is_file($path) && (time() - filemtime($path)) <= $ttl) {
        $cached = json_decode((string)@file_get_contents($path), true);
        if (is_array($cached) && isset($cached['rows']) && is_array($cached['rows'])) {
            return [
                'ok' => true,
                'error' => '',
                'rows' => $cached['rows'],
                'from_cache' => true,
                'mode' => 'service_account',
                'sheet_title' => (string)($cached['sheet_title'] ?? ''),
            ];
        }
    }
    $tok = invc_gsheet_sa_access_token($sa);
    if (empty($tok['ok'])) {
        return ['ok' => false, 'error' => $tok['error'], 'rows' => [], 'from_cache' => false, 'mode' => 'service_account'];
    }
    $auth = ['Authorization' => 'Bearer ' . $tok['token']];
    $metaRes = invc_gsheet_http_json(
        'https://sheets.googleapis.com/v4/spreadsheets/' . rawurlencode($id) . '?fields=sheets.properties(sheetId,title)',
        ['headers' => $auth, 'timeout' => 30]
    );
    if (empty($metaRes['ok'])) {
        $hint = $metaRes['error'];
        if (stripos($hint, 'permission') !== false || stripos($hint, '403') !== false || (int)$metaRes['code'] === 403) {
            $hint .= ' — แชร์ Sheet ให้ ' . $sa['client_email'] . ' เป็น Viewer';
        }
        if ((int)$metaRes['code'] === 404) {
            $hint = 'ไม่พบ Spreadsheet (ตรวจลิงก์/ID) หรือยังไม่ได้แชร์ให้ Service Account';
        }
        return ['ok' => false, 'error' => $hint, 'rows' => [], 'from_cache' => false, 'mode' => 'service_account'];
    }
    $gid = invc_gsheet_extract_gid($cfg['invc_gsheet_url'] ?? '', $cfg['invc_gsheet_gid'] ?? '0');
    $title = invc_gsheet_sheet_title_by_gid($metaRes['json'] ?? [], $gid);
    if ($title === '') {
        return ['ok' => false, 'error' => 'ไม่พบชีตตาม GID ' . $gid, 'rows' => [], 'from_cache' => false, 'mode' => 'service_account'];
    }
    $endCol = strtoupper((string)($cfg['invc_gsheet_col_recv'] ?? 'N'));
    if (strlen($endCol) === 1 && ord($endCol) < ord('Z')) {
        $endCol = 'Z';
    }
    $range = invc_gsheet_a1_range($title, $endCol);
    $valRes = invc_gsheet_http_json(
        'https://sheets.googleapis.com/v4/spreadsheets/' . rawurlencode($id)
            . '/values/' . rawurlencode($range) . '?valueRenderOption=FORMATTED_VALUE&dateTimeRenderOption=FORMATTED_STRING',
        ['headers' => $auth, 'timeout' => 45]
    );
    if (empty($valRes['ok'])) {
        return ['ok' => false, 'error' => 'อ่านค่าชีตไม่สำเร็จ: ' . ($valRes['error'] ?: 'unknown'), 'rows' => [], 'from_cache' => false, 'mode' => 'service_account'];
    }
    $rows = $valRes['json']['values'] ?? [];
    if (!is_array($rows)) {
        $rows = [];
    }
    @file_put_contents($path, json_encode(['sheet_title' => $title, 'rows' => $rows], JSON_UNESCAPED_UNICODE));
    return [
        'ok' => true,
        'error' => '',
        'rows' => $rows,
        'from_cache' => false,
        'mode' => 'service_account',
        'sheet_title' => $title,
    ];
}

function invc_gsheet_fetch_via_csv(array $cfg, $force = false) {
    $url = invc_gsheet_csv_url($cfg);
    if ($url === '') {
        return ['ok' => false, 'error' => 'กรุณาใส่ลิงก์หรือ ID ของ Google Sheet', 'rows' => [], 'from_cache' => false, 'mode' => 'csv'];
    }
    $ttl = max(30, min(3600, (int)($cfg['invc_gsheet_cache_ttl'] ?? 60)));
    $path = invc_gsheet_cache_path($cfg, 'csv');
    if (!$force && is_file($path) && (time() - filemtime($path)) <= $ttl) {
        $cached = (string)@file_get_contents($path);
        if ($cached !== '') {
            return ['ok' => true, 'error' => '', 'rows' => invc_gsheet_csv_to_rows($cached), 'from_cache' => true, 'mode' => 'csv'];
        }
    }
    $csv = '';
    $code = 0;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_USERAGENT => 'THAM-HosSafe-INVC-GSheet',
        ]);
        $csv = (string)curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $cerr = curl_error($ch);
        curl_close($ch);
        if (($code < 200 || $code >= 300 || $csv === '') && $cerr) {
            return ['ok' => false, 'error' => 'ดึง Google Sheet ไม่สำเร็จ: ' . $cerr, 'rows' => [], 'from_cache' => false, 'mode' => 'csv'];
        }
        if ($code < 200 || $code >= 300 || $csv === '') {
            return ['ok' => false, 'error' => 'ดึง Google Sheet ไม่สำเร็จ (HTTP ' . $code . ') — ใช้ Service Account หรือแชร์ Viewer สาธารณะ', 'rows' => [], 'from_cache' => false, 'mode' => 'csv'];
        }
    } else {
        $csv = (string)@file_get_contents($url);
        if ($csv === '') {
            return ['ok' => false, 'error' => 'ดึง Google Sheet ไม่สำเร็จ', 'rows' => [], 'from_cache' => false, 'mode' => 'csv'];
        }
    }
    if (strncmp($csv, "\xEF\xBB\xBF", 3) === 0) {
        $csv = substr($csv, 3);
    }
    if (stripos($csv, '<html') !== false && stripos($csv, 'รหัสยา') === false) {
        return ['ok' => false, 'error' => 'Sheet ไม่เปิดสาธารณะ — อัปโหลด Service Account แล้วแชร์ Sheet ให้ SA เป็น Viewer', 'rows' => [], 'from_cache' => false, 'mode' => 'csv'];
    }
    @file_put_contents($path, $csv);
    return ['ok' => true, 'error' => '', 'rows' => invc_gsheet_csv_to_rows($csv), 'from_cache' => false, 'mode' => 'csv'];
}

function invc_gsheet_csv_to_rows($csv) {
    $fh = fopen('php://temp', 'r+');
    fwrite($fh, $csv);
    rewind($fh);
    $rows = [];
    while (($r = fgetcsv($fh)) !== false) {
        if (is_array($r)) {
            $rows[] = $r;
        }
    }
    fclose($fh);
    return $rows;
}

function invc_gsheet_resolve_auth(array $cfg, $saOverride = null) {
    $mode = strtolower(trim((string)($cfg['invc_gsheet_auth'] ?? 'auto')));
    if (!in_array($mode, ['auto', 'service_account', 'csv'], true)) {
        $mode = 'auto';
    }
    $sa = $saOverride ?: invc_gsheet_load_sa_json();
    if ($mode === 'csv') {
        return ['mode' => 'csv', 'sa' => null];
    }
    if ($mode === 'service_account') {
        return ['mode' => 'service_account', 'sa' => $sa];
    }
    // auto
    return $sa ? ['mode' => 'service_account', 'sa' => $sa] : ['mode' => 'csv', 'sa' => null];
}

function invc_gsheet_fetch_rows(array $cfg, $force = false, $saOverride = null) {
    $auth = invc_gsheet_resolve_auth($cfg, $saOverride);
    if ($auth['mode'] === 'service_account') {
        if (!$auth['sa']) {
            return ['ok' => false, 'error' => 'ยังไม่มี Service Account JSON — อัปโหลดในหน้าตั้งค่า', 'rows' => [], 'from_cache' => false, 'mode' => 'service_account'];
        }
        return invc_gsheet_fetch_via_sa($cfg, $auth['sa'], $force);
    }
    return invc_gsheet_fetch_via_csv($cfg, $force);
}

/** @deprecated ใช้ invc_gsheet_fetch_rows */
function invc_gsheet_fetch_csv(array $cfg, $force = false) {
    $res = invc_gsheet_fetch_rows($cfg, $force);
    if (empty($res['ok'])) {
        return ['ok' => false, 'error' => $res['error'], 'csv' => '', 'from_cache' => false];
    }
    // แปลงกลับเป็น csv สำหรับโค้ดเก่า
    $fh = fopen('php://temp', 'r+');
    foreach ($res['rows'] as $row) {
        fputcsv($fh, $row);
    }
    rewind($fh);
    $csv = stream_get_contents($fh);
    fclose($fh);
    return ['ok' => true, 'error' => '', 'csv' => $csv, 'from_cache' => !empty($res['from_cache'])];
}

function invc_gsheet_parse_orders_rows(array $rows, array $cfg) {
    $idx_code = invc_gsheet_letter_to_index($cfg['invc_gsheet_col_code'] ?? 'E');
    $idx_pack = invc_gsheet_letter_to_index($cfg['invc_gsheet_col_pack'] ?? 'H');
    $idx_order = invc_gsheet_letter_to_index($cfg['invc_gsheet_col_order'] ?? 'I');
    $idx_recv = invc_gsheet_letter_to_index($cfg['invc_gsheet_col_recv'] ?? 'N');
    if ($idx_code === null || $idx_pack === null || $idx_order === null || $idx_recv === null) {
        return ['ok' => false, 'error' => 'ตัวอักษรคอลัมน์ไม่ถูกต้อง', 'orders' => [], 'row_count' => 0];
    }
    $need = max($idx_code, $idx_pack, $idx_order, $idx_recv);
    if (count($rows) < 2) {
        return ['ok' => false, 'error' => 'อ่านหัวตาราง Google Sheet ไม่ได้', 'orders' => [], 'row_count' => 0];
    }
    $orders = [];
    $row_count = 0;
    $n = count($rows);
    for ($i = 1; $i < $n; $i++) {
        $r = $rows[$i];
        if (!is_array($r) || count($r) <= $need) {
            // pad short rows
            if (!is_array($r)) {
                continue;
            }
            while (count($r) <= $need) {
                $r[] = '';
            }
        }
        $code = invc_gsheet_normalize_code($r[$idx_code] ?? '');
        if ($code === '' || !preg_match('/^[A-Za-z0-9._-]+$/', $code)) {
            continue;
        }
        $recv = invc_gsheet_parse_date($r[$idx_recv] ?? '');
        if ($recv === '') {
            continue;
        }
        $row_count++;
        $orders[] = [
            'code' => $code,
            'pack' => invc_gsheet_parse_num($r[$idx_pack] ?? 0),
            'order_qty' => invc_gsheet_parse_num($r[$idx_order] ?? 0),
            'recv_date' => $recv,
            'name' => trim((string)($r[$idx_code + 1] ?? '')),
        ];
    }
    return ['ok' => true, 'error' => '', 'orders' => $orders, 'row_count' => $row_count];
}

function invc_gsheet_parse_orders($csv, array $cfg) {
    return invc_gsheet_parse_orders_rows(invc_gsheet_csv_to_rows($csv), $cfg);
}

function invc_gsheet_load_orders($con, $force = false) {
    if (!function_exists('invc_load_config')) {
        require_once __DIR__ . '/invc_helper.php';
    }
    if (is_file(__DIR__ . '/integrations_hub_helper.php')) {
        require_once __DIR__ . '/integrations_hub_helper.php';
        if (function_exists('ih_is_enabled') && !ih_is_enabled($con, 'google_sheet_invc')) {
            return ['ok' => true, 'enabled' => false, 'error' => '', 'orders' => [], 'row_count' => 0, 'from_cache' => false, 'mode' => ''];
        }
    }
    $cfg = invc_load_config($con);
    if (($cfg['invc_gsheet_enabled'] ?? '0') !== '1') {
        return ['ok' => true, 'enabled' => false, 'error' => '', 'orders' => [], 'row_count' => 0, 'from_cache' => false, 'mode' => ''];
    }
    $fetch = invc_gsheet_fetch_rows($cfg, $force);
    if (empty($fetch['ok'])) {
        return ['ok' => false, 'enabled' => true, 'error' => $fetch['error'], 'orders' => [], 'row_count' => 0, 'from_cache' => false, 'mode' => $fetch['mode'] ?? ''];
    }
    $parsed = invc_gsheet_parse_orders_rows($fetch['rows'], $cfg);
    if (empty($parsed['ok'])) {
        return ['ok' => false, 'enabled' => true, 'error' => $parsed['error'], 'orders' => [], 'row_count' => 0, 'from_cache' => !empty($fetch['from_cache']), 'mode' => $fetch['mode'] ?? ''];
    }
    return [
        'ok' => true,
        'enabled' => true,
        'error' => '',
        'orders' => $parsed['orders'],
        'row_count' => $parsed['row_count'],
        'from_cache' => !empty($fetch['from_cache']),
        'mode' => $fetch['mode'] ?? '',
        'sheet_title' => (string)($fetch['sheet_title'] ?? ''),
        'csv_url' => invc_gsheet_csv_url($cfg),
    ];
}

function invc_gsheet_test($con, array $override = null) {
    $cfg = invc_load_config($con);
    $saOverride = null;
    if (is_array($override)) {
        foreach (invc_gsheet_config_keys() as $k) {
            if (array_key_exists($k, $override)) {
                $cfg[$k] = trim((string)$override[$k]);
            }
        }
        if (!empty($override['invc_gsheet_sa_json']) && trim((string)$override['invc_gsheet_sa_json']) !== '' && trim((string)$override['invc_gsheet_sa_json']) !== '********') {
            $saOverride = invc_gsheet_load_sa_json($override['invc_gsheet_sa_json']);
            if (!$saOverride && strtoupper(trim((string)$override['invc_gsheet_sa_json'])) !== 'CLEAR') {
                return [
                    'ok' => false,
                    'ms' => 0,
                    'error' => 'JSON Service Account ในฟอร์มไม่ถูกต้อง',
                    'row_count' => 0,
                    'sample' => [],
                    'mode' => 'service_account',
                    'sa_email' => '',
                ];
            }
        }
    }
    $cfg['invc_gsheet_enabled'] = '1';
    $t0 = microtime(true);
    $fetch = invc_gsheet_fetch_rows($cfg, true, $saOverride);
    $ms = round((microtime(true) - $t0) * 1000, 1);
    $saStatus = $saOverride
        ? ['configured' => true, 'email' => (string)$saOverride['client_email']]
        : invc_gsheet_sa_status();
    if (empty($fetch['ok'])) {
        return [
            'ok' => false,
            'ms' => $ms,
            'error' => $fetch['error'],
            'row_count' => 0,
            'sample' => [],
            'mode' => $fetch['mode'] ?? '',
            'sa_email' => $saStatus['email'] ?? '',
            'csv_url' => invc_gsheet_csv_url($cfg),
        ];
    }
    $parsed = invc_gsheet_parse_orders_rows($fetch['rows'], $cfg);
    if (empty($parsed['ok'])) {
        return [
            'ok' => false,
            'ms' => $ms,
            'error' => $parsed['error'],
            'row_count' => 0,
            'sample' => [],
            'mode' => $fetch['mode'] ?? '',
            'sa_email' => $saStatus['email'] ?? '',
            'csv_url' => invc_gsheet_csv_url($cfg),
        ];
    }
    return [
        'ok' => true,
        'ms' => $ms,
        'error' => '',
        'row_count' => $parsed['row_count'],
        'sample' => array_slice($parsed['orders'], 0, 5),
        'mode' => $fetch['mode'] ?? '',
        'sheet_title' => (string)($fetch['sheet_title'] ?? ''),
        'sa_email' => $saStatus['email'] ?? '',
        'csv_url' => invc_gsheet_csv_url($cfg),
    ];
}

/**
 * รวมรายการ sheet ตามรหัสยา ที่วันที่รับ > วันที่จ่ายล่าสุด
 */
function invc_gsheet_pending_map(array $orders, array $last_dispense_map) {
    $map = [];
    foreach ($orders as $o) {
        $code = $o['code'] ?? '';
        if ($code === '') {
            continue;
        }
        $recv = $o['recv_date'] ?? '';
        if ($recv === '') {
            continue;
        }
        $last = $last_dispense_map[$code] ?? '';
        if ($last !== '' && strcmp($recv, $last) <= 0) {
            continue;
        }
        if (!isset($map[$code])) {
            $map[$code] = [
                'pending' => true,
                'pack' => round((float)($o['pack'] ?? 0), 2),
                'order_qty' => round((float)($o['order_qty'] ?? 0), 2),
                'recv_date' => $recv,
                'order_lines' => 1,
                'last_dispense' => $last,
            ];
            continue;
        }
        $cur = &$map[$code];
        $cur['order_qty'] = round($cur['order_qty'] + (float)($o['order_qty'] ?? 0), 2);
        $cur['order_lines']++;
        if (strcmp($recv, $cur['recv_date']) > 0) {
            $cur['recv_date'] = $recv;
            $cur['pack'] = round((float)($o['pack'] ?? 0), 2);
        }
        unset($cur);
    }
    return $map;
}
