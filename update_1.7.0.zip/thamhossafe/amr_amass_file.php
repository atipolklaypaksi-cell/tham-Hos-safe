<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include(__DIR__ . '/connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/amr_amass_helper.php';
tham_menu_ensure_tables($con);
tham_menu_ensure_page_access(basename(__FILE__));

$key = preg_replace('/[^A-Za-z0-9._-]/', '', (string)($_GET['key'] ?? ''));
$catalog = amr_amass_file_catalog();
if ($key === '' || !isset($catalog[$key]) || empty($catalog[$key]['path']) || !is_file($catalog[$key]['path'])) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'ไม่พบไฟล์';
    exit;
}
$meta = $catalog[$key];
$path = $meta['path'];
$mime = $meta['mime'] ?? 'application/octet-stream';
$download = isset($_GET['download']);
$filename = basename($path);
header('Content-Type: ' . $mime);
header('X-Content-Type-Options: nosniff');
header('Content-Length: ' . filesize($path));
header('Content-Disposition: ' . ($download ? 'attachment' : 'inline') . '; filename="' . str_replace('"', '', $filename) . '"');
readfile($path);
exit;
