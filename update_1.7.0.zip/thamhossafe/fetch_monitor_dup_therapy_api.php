<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_dup_therapy_helper.php');
mysqli_set_charset($con, 'utf8');
set_time_limit(180);

function mdt_api_req($key, $default = '') {
    if (isset($_POST[$key]) && (is_string($_POST[$key]) || is_numeric($_POST[$key]))) {
        return trim((string)$_POST[$key]);
    }
    if (isset($_GET[$key]) && (is_string($_GET[$key]) || is_numeric($_GET[$key]))) {
        return trim((string)$_GET[$key]);
    }
    return $default;
}

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

mdt_ensure_table($con, false);

$start_date = mdt_api_req('start_date', date('Y-m-d', strtotime('-3 days')));
$end_date = mdt_api_req('end_date', date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-3 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if (strtotime($start_date) > strtotime($end_date)) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$rule_ids = [];
$rule_ids_raw = mdt_api_req('rule_ids', '');
if ($rule_ids_raw !== '') {
    foreach (explode(',', $rule_ids_raw) as $rid) {
        $rid = (int)trim($rid);
        if ($rid > 0) {
            $rule_ids[] = $rid;
        }
    }
}

$rules = mdt_load_active_rules($con, $rule_ids);
if (empty($rules)) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'meta' => ['rule_count' => 0, 'message' => 'ยังไม่มีกฎที่เปิดใช้งาน'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}

$t0 = microtime(true);
$hn_raw = mdt_api_req('hn');
$hn_filter = [];
if ($hn_raw !== '') {
    $hn_filter[] = $hn_raw;
}
$filter = mdt_get_filter_config($con);
$res = mdt_screen_rules($hos, $rules, $start_date, $end_date, $filter, $hn_filter);
if (!empty($res['error'])) {
    mysqli_close($hos);
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'SQL Error: ' . $res['error']], JSON_UNESCAPED_UNICODE);
    exit;
}
$hard_alerts = $res['hard_alerts'] ?? [];
$soft_alerts = $res['soft_alerts'] ?? [];
$m = $res['meta'] ?? [];
$matched_a = (int)($m['matched_a'] ?? 0);
$matched_b = (int)($m['matched_b'] ?? 0);
$orders_scanned = (int)($m['orders_scanned'] ?? 0);
$skipped_off = (int)($m['skipped_off'] ?? 0);
$skipped_keyword = (int)($m['skipped_keyword'] ?? 0);
$truncated = !empty($m['truncated']);
$pair_label = (string)($m['pair_label'] ?? '');

$elapsed = (int)round((microtime(true) - $t0) * 1000);
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
mysqli_close($hos);

ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'status' => 'success',
    'hard_alerts' => sp_alert_mute_filter_rows($con, $hard_alerts),
    'soft_alerts' => sp_alert_mute_filter_rows($con, $soft_alerts),
    'module_key' => $pair_label,
    'meta' => [
        'rule_count' => count($rules),
        'hard_count' => count($hard_alerts),
        'soft_count' => count($soft_alerts),
        'matched_a' => $matched_a,
        'matched_b' => $matched_b,
        'orders_scanned' => $orders_scanned,
        'skipped_off' => $skipped_off,
        'skipped_keyword' => $skipped_keyword,
        'start_date' => $start_date,
        'end_date' => $end_date,
        'elapsed_ms' => $elapsed,
        'truncated' => $truncated,
        'pair_label' => $pair_label,
        'hn' => $hn_raw,
    ],
], JSON_UNESCAPED_UNICODE);
