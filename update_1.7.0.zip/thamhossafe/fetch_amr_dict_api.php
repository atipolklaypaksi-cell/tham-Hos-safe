<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
session_write_close();
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_amass_helper.php';
mysqli_set_charset($con, 'utf8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

amr_dict_ensure_tables($con);

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'summary'));
$user_name = trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? ''));

function amr_dict_api_out(array $payload) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'summary') {
    $info = amr_dict_counts($con);
    amr_dict_api_out([
        'status' => 'success',
        'counts' => $info['counts'],
        'meta' => $info['meta'],
        'categories' => amr_dict_categories(),
    ]);
}

if ($action === 'list') {
    $cat = trim((string)($input['category'] ?? $_GET['category'] ?? 'organism'));
    $q = trim((string)($input['q'] ?? $_GET['q'] ?? ''));
    $rows = amr_dict_list($con, $cat, $q, true);
    amr_dict_api_out([
        'status' => 'success',
        'category' => amr_dict_normalize_category($cat),
        'rows' => $rows,
        'count' => count($rows),
    ]);
}

if ($action === 'save') {
    $res = amr_dict_save_row($con, $input);
    if (empty($res['ok'])) {
        amr_dict_api_out(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกไม่สำเร็จ']);
    }
    amr_dict_prime($con);
    amr_dict_api_out(['status' => 'success', 'id' => $res['id']]);
}

if ($action === 'delete') {
    $ok = amr_dict_delete_row($con, (int)($input['id'] ?? 0));
    amr_dict_api_out($ok
        ? ['status' => 'success']
        : ['status' => 'error', 'message' => 'ลบไม่สำเร็จ']);
}

if ($action === 'toggle') {
    $ok = amr_dict_toggle($con, (int)($input['id'] ?? 0), !empty($input['active']));
    amr_dict_api_out($ok
        ? ['status' => 'success']
        : ['status' => 'error', 'message' => 'ปรับสถานะไม่สำเร็จ']);
}

if ($action === 'delete_source') {
    $cat = trim((string)($input['category'] ?? 'organism'));
    $source = trim((string)($input['source'] ?? 'builtin'));
    $res = amr_dict_delete_source($con, $cat, $source);
    if (empty($res['ok'])) {
        amr_dict_api_out(['status' => 'error', 'message' => $res['error'] ?? 'ลบไม่สำเร็จ']);
    }
    amr_dict_api_out([
        'status' => 'success',
        'deleted' => (int)($res['deleted'] ?? 0),
        'message' => 'ลบค่าเดิม ' . (int)($res['deleted'] ?? 0) . ' รายการแล้ว',
    ]);
}

if ($action === 'reset_builtin') {
    amr_dict_reset_builtin($con);
    amr_dict_api_out(['status' => 'success', 'message' => 'คืนค่า mapping เชื้อ / specimen / ผลดื้อยา ตาม CASE เดิมแล้ว']);
}

if ($action === 'preview' || $action === 'import') {
    $filename = trim((string)($input['filename'] ?? 'dictionary.xlsx'));
    if (amr_dict_is_data_file($filename)) {
        amr_dict_api_out([
            'status' => 'error',
            'message' => 'ไฟล์นี้เป็นข้อมูล AMASS (microbiology_data / admission / drug) ไม่ใช่ Dictionary — กรุณาเลือกไฟล์ dictionary_for_*.xlsx',
        ]);
    }
    $dict_file = trim((string)($input['dict_file'] ?? ''));
    if ($dict_file === '') {
        $dict_file = amr_dict_guess_file($filename);
    }
    if ($dict_file === '') {
        amr_dict_api_out(['status' => 'error', 'message' => 'ระบุประเภท Dictionary ไม่ได้ — เลือกประเภทไฟล์ หรือใช้ชื่อ dictionary_for_*.xlsx']);
    }
    $dict_file = amr_dict_normalize_file($dict_file);
    if (!in_array($dict_file, ['microbiology', 'admission', 'drug', 'ward'], true)) {
        amr_dict_api_out(['status' => 'error', 'message' => 'ประเภท Dictionary ไม่ถูกต้อง']);
    }

    $sheets = $input['sheets'] ?? [];
    if (!is_array($sheets) || empty($sheets)) {
        $rows = $input['rows'] ?? [];
        $sheets = [['name' => 'Sheet1', 'rows' => is_array($rows) ? $rows : []]];
    }
    $parsed = amr_dict_parse_workbook($sheets, $dict_file);
    if (empty($parsed)) {
        amr_dict_api_out([
            'status' => 'error',
            'message' => 'ไม่พบแถว mapping ในไฟล์ (ต้องมีคอลัมน์ A = ค่า AMASS, คอลัมน์ B = ค่าในข้อมูลโรงพยาบาล)',
        ]);
    }
    $by_cat = [];
    foreach ($parsed as $it) {
        $c = $it['category'];
        if (!isset($by_cat[$c])) {
            $by_cat[$c] = 0;
        }
        $by_cat[$c]++;
    }
    $preview = array_slice($parsed, 0, 12);
    if ($action === 'preview') {
        amr_dict_api_out([
            'status' => 'success',
            'dict_file' => $dict_file,
            'filename' => $filename,
            'total' => count($parsed),
            'by_category' => $by_cat,
            'preview' => $preview,
        ]);
    }
    $mode = (($input['mode'] ?? '') === 'replace_file') ? 'replace_file' : 'merge';
    $res = amr_dict_import($con, $parsed, $dict_file, $filename, $user_name, $mode);
    amr_dict_api_out([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => !empty($res['ok'])
            ? ('นำเข้า ' . (int)$res['total'] . ' แถว (ใหม่ ' . (int)$res['inserted'] . ' / อัปเดต ' . (int)$res['updated'] . ')')
            : ($res['error'] ?? 'นำเข้าไม่สำเร็จ'),
        'dict_file' => $dict_file,
        'inserted' => $res['inserted'] ?? 0,
        'updated' => $res['updated'] ?? 0,
        'skipped' => $res['skipped'] ?? 0,
        'by_category' => $res['by_category'] ?? $by_cat,
        'mode' => $mode,
    ]);
}

amr_dict_api_out(['status' => 'error', 'message' => 'Unknown action']);
