<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ini_set('memory_limit', '512M');
set_time_limit(600);
ignore_user_abort(true);
ob_start();
session_start();

register_shutdown_function(function () {
    $err = error_get_last();
    if (!$err) {
        return;
    }
    $fatal = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];
    if (!in_array($err['type'], $fatal, true)) {
        return;
    }
    if (headers_sent()) {
        return;
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'error',
        'message' => 'เซิร์ฟเวอร์หยุดทำงาน: ' . $err['message'],
    ], JSON_UNESCAPED_UNICODE);
});

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/amr_helper.php');
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_mlab_helper.php';
require_once __DIR__ . '/amr_amass_helper.php';
require_once __DIR__ . '/amr_amass_engine.php';
mysqli_set_charset($con, 'utf8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

amr_dict_ensure_tables($con);
amr_amass_seed_ward_aliases($con);
amr_amass_load_ward_pairs($con);

$ct = (string)($_SERVER['CONTENT_TYPE'] ?? '');
$input = [];
if (stripos($ct, 'application/json') !== false) {
    $decoded = json_decode((string)file_get_contents('php://input'), true);
    if (is_array($decoded)) {
        $input = $decoded;
    }
}
$src = array_merge($_GET, $_POST, $input);
$action = trim((string)($src['action'] ?? 'status'));

function amr_amass_api_out(array $payload) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if ($action === 'status') {
    $pkg = amr_amass_package_status();
    $kpis = amr_amass_result_kpis();
    amr_amass_api_out([
        'status' => 'success',
        'datasets' => amr_amass_datasets(),
        'ward_alias_count' => count(amr_amass_active_ward_pairs()),
        'staged' => amr_amass_staged_status(),
        'package' => $pkg,
        'kpis' => $kpis,
        'run_ready' => true,
        'run_note' => $pkg['run_note'],
        'tables' => amr_amass_dashboard_tables(),
        'periods' => amr_amass_list_periods(),
        'micro_source' => amr_amass_dataset_source($con, 'microbiology'),
        'micro_source_label' => amr_amass_dataset_source($con, 'microbiology') === 'mlab'
            ? 'mLAB (ตาราง THAM Hos-Safe)'
            : 'HOSxP lab_head',
    ]);
}

if ($action === 'staged') {
    amr_amass_api_out([
        'status' => 'success',
        'staged' => amr_amass_staged_status(),
    ]);
}

if ($action === 'upload') {
    $dataset = trim((string)($_POST['dataset'] ?? $src['dataset'] ?? ''));
    if (empty($_FILES['file']['tmp_name'])) {
        amr_amass_api_out(['status' => 'error', 'message' => 'ไม่พบไฟล์']);
    }
    $res = amr_amass_save_upload($dataset, $_FILES['file']['tmp_name'], $_FILES['file']['name'] ?? '');
    if (empty($res['ok'])) {
        amr_amass_api_out(['status' => 'error', 'message' => $res['error'] ?? 'อัปโหลดไม่สำเร็จ']);
    }
    $source = trim((string)($_POST['source'] ?? $src['source'] ?? 'upload'));
    if (!in_array($source, ['hosxp', 'mlab', 'upload'], true)) {
        $source = 'upload';
    }
    amr_amass_touch_source($res['dataset'], $source, $_FILES['file']['name'] ?? '');
    amr_amass_api_out([
        'status' => 'success',
        'message' => 'เก็บไฟล์ ' . $res['filename'] . ' เป็นชุดรันแล้ว',
        'dataset' => $res['dataset'],
        'filename' => $res['filename'],
        'bytes' => $res['bytes'],
        'staged' => amr_amass_staged_status(),
    ]);
}

if ($action === 'upload_result') {
    if (empty($_FILES['file']['tmp_name'])) {
        amr_amass_api_out(['status' => 'error', 'message' => 'ไม่พบไฟล์']);
    }
    $res = amr_amass_save_result_upload($_FILES['file']['tmp_name'], $_FILES['file']['name'] ?? '');
    if (empty($res['ok'])) {
        amr_amass_api_out(['status' => 'error', 'message' => $res['error'] ?? 'อัปโหลดไม่สำเร็จ']);
    }
    amr_amass_api_out([
        'status' => 'success',
        'message' => 'เก็บผลรันแล้ว: ' . implode(', ', $res['files']),
        'files' => $res['files'],
        'kpis' => amr_amass_result_kpis(),
    ]);
}

if ($action === 'download') {
    $dataset = trim((string)($src['dataset'] ?? ''));
    $fn = amr_amass_canonical_filename($dataset);
    if ($fn === '') {
        amr_amass_api_out(['status' => 'error', 'message' => 'ไม่รู้จักชุดข้อมูล']);
    }
    $xlsx = amr_amass_ensure_xlsx($dataset);
    if ($xlsx === '' || !is_file($xlsx)) {
        amr_amass_api_out(['status' => 'error', 'message' => 'ยังไม่มีไฟล์ให้ดาวน์โหลด — ดึงข้อมูลตามช่วงวันที่ก่อน']);
    }
    $start = amr_parse_date($src['start_date'] ?? '', '');
    $end = amr_parse_date($src['end_date'] ?? '', '');
    if ($start === '' || $end === '') {
        $st = amr_amass_staged_status();
        $start = $st[$dataset]['start_date'] ?? '';
        $end = $st[$dataset]['end_date'] ?? '';
    }
    $stamp = amr_amass_export_stamp($start, $end);
    $base = preg_replace('/\.xlsx$/i', '', $fn);
    $out_name = $base . '_' . $stamp . '.xlsx';
    amr_amass_send_file(
        $xlsx,
        $out_name,
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
}

if ($action === 'download_zip') {
    $sets = amr_amass_datasets();
    $files = [];
    foreach ($sets as $key => $meta) {
        $xlsx = amr_amass_ensure_xlsx($key);
        if ($xlsx === '' || !is_file($xlsx)) {
            amr_amass_api_out([
                'status' => 'error',
                'message' => 'ยังไม่มี ' . $meta['filename'] . ' — ดึงข้อมูลตามช่วงวันที่ก่อน',
                'dataset' => $key,
            ]);
        }
        $files[$meta['filename']] = $xlsx;
    }
    $start = amr_parse_date($src['start_date'] ?? '', '');
    $end = amr_parse_date($src['end_date'] ?? '', '');
    if ($start === '' || $end === '') {
        $st = amr_amass_staged_status();
        $start = $st['microbiology']['start_date'] ?? ($st['admission']['start_date'] ?? ($st['drug']['start_date'] ?? ''));
        $end = $st['microbiology']['end_date'] ?? ($st['admission']['end_date'] ?? ($st['drug']['end_date'] ?? ''));
    }
    $stamp = amr_amass_export_stamp($start, $end);
    $zip_name = 'AMASS_HOSxP_' . $stamp . '.zip';
    $zip_path = amr_amass_upload_dir() . '/.' . $zip_name;
    $entries = [];
    foreach ($files as $name => $path) {
        $entries[$name] = ['file' => $path];
    }
    if (!amr_amass_zip_write($zip_path, $entries) || !is_file($zip_path)) {
        amr_amass_api_out(['status' => 'error', 'message' => 'สร้างไฟล์ zip ไม่สำเร็จ']);
    }
    amr_amass_send_file($zip_path, $zip_name, 'application/zip', true);
}

if ($action === 'save_hospital' || $action === 'save_cover') {
    $cover = amr_amass_save_cover($con, $src);
    amr_amass_api_out([
        'status' => 'success',
        'message' => 'บันทึกข้อมูลปก AMASS แล้ว',
        'hospital_name' => $cover['hospital_name'],
        'cover' => $cover,
    ]);
}

if ($action === 'analyze') {
    $t0 = microtime(true);
    $res = amr_amass_run_analysis($con);
    if (empty($res['ok'])) {
        amr_amass_api_out([
            'status' => 'error',
            'message' => $res['error'] ?? 'วิเคราะห์ไม่สำเร็จ',
        ]);
    }
    $pstart = trim((string)($src['start_date'] ?? ''));
    $pend = trim((string)($src['end_date'] ?? ''));
    if ($pstart === '' || $pend === '') {
        $pstart = (string)($res['meta']['date_min'] ?? '');
        $pend = (string)($res['meta']['date_max'] ?? '');
    }
    $period = null;
    if ($pstart !== '' && $pend !== '') {
        $period = amr_amass_save_period($pstart, $pend, $res['meta']);
    }
    amr_amass_api_out([
        'status' => 'success',
        'message' => 'วิเคราะห์ตาม AMASS/WHO GLASS แล้ว — เลือดเดดูป ' . (int)($res['meta']['blood_priority_dedup'] ?? 0) . ' isolate',
        'meta' => $res['meta'],
        'kpis' => $res['kpis'],
        'tables' => amr_amass_dashboard_tables(),
        'period' => $period,
        'periods' => amr_amass_list_periods(),
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
    ]);
}

if ($action === 'reset_chunks') {
    $dataset = trim((string)($src['dataset'] ?? ''));
    $n = amr_amass_reset_chunks($dataset);
    amr_amass_api_out([
        'status' => 'success',
        'cleared' => $n,
        'dataset' => $dataset,
    ]);
}

if ($action === 'merge_chunks') {
    $dataset = trim((string)($src['dataset'] ?? ''));
    $end = amr_parse_date($src['end_date'] ?? '', date('Y-m-d'));
    $start = amr_parse_date($src['start_date'] ?? '', date('Y-01-01'));
    if ($start > $end) {
        $tmp = $start;
        $start = $end;
        $end = $tmp;
    }
    $write_xlsx = !empty($src['write_xlsx']) && $src['write_xlsx'] !== '0' && $src['write_xlsx'] !== 'false';
    $sets = amr_amass_datasets();
    $merged = [];
    $keys = $dataset !== '' ? [$dataset] : array_keys($sets);
    foreach ($keys as $ds) {
        if (empty($sets[$ds]['ready'])) {
            continue;
        }
        $one = amr_amass_merge_chunks($ds, $start, $end, $write_xlsx, $con);
        if (empty($one['ok'])) {
            amr_amass_api_out([
                'status' => 'error',
                'message' => 'รวมไฟล์ ' . $ds . ' ไม่สำเร็จ: ' . ($one['error'] ?? ''),
                'dataset' => $ds,
            ]);
        }
        $merged[$ds] = $one;
    }
    $total = 0;
    foreach ($merged as $one) {
        $total += (int)($one['row_count'] ?? 0);
    }
    amr_amass_api_out([
        'status' => 'success',
        'message' => 'รวมไฟล์รายเดือนแล้ว ' . number_format($total) . ' แถว',
        'merged' => $merged,
        'staged' => amr_amass_staged_status(),
        'start_date' => $start,
        'end_date' => $end,
    ]);
}

if ($action === 'periods') {
    amr_amass_api_out([
        'status' => 'success',
        'periods' => amr_amass_list_periods(),
    ]);
}

if ($action === 'compare') {
    $keys_raw = trim((string)($src['keys'] ?? ''));
    if ($keys_raw !== '') {
        $keys = array_filter(array_map('trim', explode(',', $keys_raw)));
        $res = amr_amass_compare_multi($keys);
    } else {
        $a = trim((string)($src['a'] ?? $src['period_a'] ?? ''));
        $b = trim((string)($src['b'] ?? $src['period_b'] ?? ''));
        $res = amr_amass_compare_periods($a, $b);
        if (!empty($res['ok'])) {
            $res = amr_amass_compare_multi([$a, $b]);
        }
    }
    if (empty($res['ok'])) {
        amr_amass_api_out([
            'status' => 'error',
            'message' => $res['error'] ?? 'เปรียบเทียบไม่สำเร็จ',
        ]);
    }
    amr_amass_api_out(['status' => 'success'] + $res);
}

if ($action === 'extract') {
    $dataset = trim((string)($src['dataset'] ?? ''));
    $end = amr_parse_date($src['end_date'] ?? '', date('Y-m-d'));
    $start = amr_parse_date($src['start_date'] ?? '', date('Y-01-01'));
    if ($start > $end) {
        $tmp = $start;
        $start = $end;
        $end = $tmp;
    }
    $mode = trim((string)($src['mode'] ?? ''));
    $span = (int)floor((strtotime($end) - strtotime($start)) / 86400);
    if ($mode !== 'chunk' && $span > 366) {
        $start = date('Y-m-d', strtotime($end . ' -366 days'));
    }
    if ($mode === 'chunk' && $span > 40) {
        amr_amass_api_out(['status' => 'error', 'message' => 'ช่วงรายเดือนยาวเกินไป']);
    }
    $sets = amr_amass_datasets();
    if (!isset($sets[$dataset])) {
        amr_amass_api_out(['status' => 'error', 'message' => 'ไม่รู้จักชุดข้อมูล']);
    }
    $need_hos = $dataset !== 'microbiology' || amr_amass_dataset_source($con, 'microbiology') !== 'mlab';
    $hos = null;
    if ($need_hos) {
        $hos = hosxp_connect($con, 180);
        if (!$hos) {
            amr_amass_api_out(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้']);
        }
        hosxp_extend_read_timeout($hos, 180);
    }
    $t0 = microtime(true);
    $src_name = amr_amass_dataset_source($con, $dataset) === 'mlab' ? 'mLAB' : 'HOSxP';
    if ($mode === 'chunk') {
        set_time_limit(240);
        $eval_start = amr_parse_date($src['eval_start'] ?? '', $start);
        $eval_end = amr_parse_date($src['eval_end'] ?? '', $end);
        $res = amr_amass_extract_chunk($hos, $con, $dataset, $start, $end, $eval_start, $eval_end);
    } else {
        $res = amr_amass_extract_to_stage($hos, $con, $dataset, $start, $end);
    }
    if ($hos) {
        mysqli_close($hos);
    }
    if (empty($res['ok'])) {
        amr_amass_api_out([
            'status' => 'error',
            'message' => 'ดึงข้อมูลไม่สำเร็จ: ' . ($res['error'] ?? ''),
            'dataset' => $dataset,
            'start_date' => $start,
            'end_date' => $end,
        ]);
    }
    amr_amass_api_out([
        'status' => 'success',
        'message' => $mode === 'chunk'
            ? ('ดึง ' . ($res['filename'] ?? '') . ' ' . ($res['chunk'] ?? '') . ' ได้ ' . number_format($res['row_count']) . ' แถว (' . $src_name . ')')
            : ('ดึง ' . $res['filename'] . ' จาก ' . $src_name . ' แล้ว ' . number_format($res['row_count']) . ' แถว'),
        'dataset' => $res['dataset'],
        'filename' => $res['filename'],
        'chunk' => $res['chunk'] ?? '',
        'row_count' => $res['row_count'],
        'bytes' => $res['bytes'],
        'start_date' => $res['start_date'],
        'end_date' => $res['end_date'],
        'source' => amr_amass_dataset_source($con, $dataset),
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
        'download' => 'fetch_amr_amass_api.php?action=download&dataset=' . rawurlencode($dataset),
        'staged' => $mode === 'chunk' ? null : amr_amass_staged_status(),
    ]);
}

amr_amass_api_out(['status' => 'error', 'message' => 'Unknown action']);
