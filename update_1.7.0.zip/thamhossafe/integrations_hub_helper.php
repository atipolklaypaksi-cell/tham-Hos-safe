<?php
/**
 * ศูนย์เปิด/ปิดการเชื่อมต่อภายนอก — เก็บใน sys_config (feat_conn_*)
 * เมื่อปิด: helper/API คืน disabled ทันที ไม่พยายาม connect (กันค้างตอนกระจาย รพ.อื่น)
 */

function ih_sys_get($con, $name, $default = '') {
    $n = mysqli_real_escape_string($con, $name);
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='$n' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return (string)$r['config_value'];
    }
    return $default;
}

function ih_sys_set($con, $name, $value) {
    $n = mysqli_real_escape_string($con, $name);
    $v = mysqli_real_escape_string($con, (string)$value);
    $chk = @mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$n' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$n'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$n','$v')");
}

/**
 * รายการการเชื่อมต่อที่เปิด/ปิดได้
 * required=true = แนะนำไม่ปิด (ระบบหลัก) แต่ยังสลับได้สำหรับ demo
 */
function ih_connection_defs() {
    return [
        'hosxp' => [
            'label' => 'HOSxP',
            'desc' => 'ฐานผู้ป่วยหลัก — จำเป็นสำหรับเกือบทุกเมนู',
            'setting' => 'hosxp_setting.php',
            'required' => true,
            'icon' => 'fa-network-wired',
        ],
        'hosxp_master' => [
            'label' => 'HOSxP Master',
            'desc' => 'ฐาน master (ถ้ามีแยกจาก HOSxP)',
            'setting' => 'hosxp_master_setting.php',
            'required' => false,
            'icon' => 'fa-database',
        ],
        'hosoffice' => [
            'label' => 'HOSoffice',
            'desc' => 'ระบบสำนักงาน / เอกสาร HOSoffice',
            'setting' => 'hosoffice_setting.php',
            'required' => false,
            'icon' => 'fa-building',
        ],
        'jhcis' => [
            'label' => 'JHCIS PCC',
            'desc' => 'เชื่อมต่อหน่วยบริการปฐมภูมิ',
            'setting' => 'jhcis_setting.php',
            'required' => false,
            'icon' => 'fa-clinic-medical',
        ],
        'drug_viewer' => [
            'label' => 'Drug Viewer',
            'desc' => 'ดูสแกนใบสั่งยา / เอกสารยา',
            'setting' => 'drug_viewer_setting.php',
            'required' => false,
            'icon' => 'fa-file-medical',
        ],
        'robot' => [
            'label' => 'Robot OPD',
            'desc' => 'ระบบจ่ายยา Robot OPD',
            'setting' => 'robot_setting.php',
            'required' => false,
            'icon' => 'fa-robot',
        ],
        'hapysure' => [
            'label' => 'HAPYsure',
            'desc' => 'เชื่อมต่อ HAPYsure',
            'setting' => 'hapysure_setting.php',
            'required' => false,
            'icon' => 'fa-notes-medical',
        ],
        'invc' => [
            'label' => 'INVC (คลังยา)',
            'desc' => 'SQL Server คลังยา — ต้องมี driver ใน Docker',
            'setting' => 'invc_setting.php',
            'required' => false,
            'icon' => 'fa-boxes',
        ],
        'google_sheet_invc' => [
            'label' => 'Google Sheet (INVC)',
            'desc' => 'ดึง Sheet ประกอบ INVC — ปิดได้เมื่อกระจาย รพ.อื่น',
            'setting' => 'invc_setting.php',
            'required' => false,
            'icon' => 'fa-file-excel',
        ],
        'google_sheet_allergy' => [
            'label' => 'Google Sheet (นำเข้าแพ้ยา)',
            'desc' => 'ปุ่มนำเข้าสมุดจาก Sheet ใน Allergy Follow-up',
            'setting' => 'allergy_followup.php',
            'required' => false,
            'icon' => 'fa-file-import',
        ],
        'hospital_ds' => [
            'label' => 'รพ.เครือข่าย',
            'desc' => 'เชื่อมต่อฐาน รพ. อื่นในเครือข่าย',
            'setting' => 'hospital_connect.php',
            'required' => false,
            'icon' => 'fa-hospital',
        ],
        'amr' => [
            'label' => 'AMR / MLab',
            'desc' => 'เชื่อมต่อข้อมูล AMR',
            'setting' => 'amr_connect.php',
            'required' => false,
            'icon' => 'fa-bacteria',
        ],
        'provider_id' => [
            'label' => 'Provider ID / Drug Center',
            'desc' => 'Login Provider ID สำหรับดึง Med Recon จาก Drug Center',
            'setting' => 'provider_id_setting.php',
            'required' => false,
            'icon' => 'fa-id-card',
        ],
    ];
}

function ih_config_key($code) {
    return 'feat_conn_' . preg_replace('/[^a-z0-9_]/i', '', $code);
}

/** ค่าเริ่มต้น = เปิด (1) เพื่อไม่กระทบ รพ.ที่ใช้อยู่ */
function ih_is_enabled($con, $code) {
    $defs = ih_connection_defs();
    if (!isset($defs[$code])) {
        return true;
    }
    $key = ih_config_key($code);
    $raw = ih_sys_get($con, $key, '');
    // ยังไม่เคยตั้ง feat_conn_* → sync จากคีย์เดิมของ INVC Sheet ถ้ามี
    if ($raw === '' && $code === 'google_sheet_invc') {
        $raw = ih_sys_get($con, 'invc_gsheet_enabled', '1');
    }
    if ($raw === '') {
        $raw = '1';
    }
    return $raw === '1' || $raw === 'true' || $raw === 'yes';
}

function ih_set_enabled($con, $code, $on) {
    $defs = ih_connection_defs();
    if (!isset($defs[$code])) {
        return false;
    }
    return ih_sys_set($con, ih_config_key($code), $on ? '1' : '0');
}

function ih_list_status($con) {
    $out = [];
    foreach (ih_connection_defs() as $code => $def) {
        $on = ih_is_enabled($con, $code);
        $out[] = [
            'code' => $code,
            'label' => $def['label'],
            'desc' => $def['desc'],
            'setting' => $def['setting'],
            'required' => !empty($def['required']),
            'icon' => $def['icon'],
            'enabled' => $on ? 1 : 0,
        ];
    }
    return $out;
}

/** ข้อความมาตรฐานเมื่อปิดการเชื่อมต่อ */
function ih_disabled_message($code) {
    $defs = ih_connection_defs();
    $label = $defs[$code]['label'] ?? $code;
    return 'การเชื่อมต่อ ' . $label . ' ถูกปิดไว้ (ตั้งค่าที่เมนู เปิด/ปิดการเชื่อมต่อ)';
}
