<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/allergy_followup_helper.php';
require_once __DIR__ . '/allergy_followup_import_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('allergy_followup') && !tham_menu_can('allergy_report') && !tham_menu_can('smart_pharma.settings')) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

af_ensure_tables($con);

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';
$user = af_current_user();
$can_assess = af_can_assess();
$flags = JSON_UNESCAPED_UNICODE;

if ($action === 'meta') {
    $scope = af_user_ward_scope();
    echo json_encode([
        'status' => 'success',
        'can_assess' => $can_assess,
        'user' => $user,
        'channels' => af_channels(),
        'summaries' => af_summary_options(),
        'wards' => af_list_wards($con),
        'pharmacists' => af_list_pharmacists($con),
        'telegram_notify' => af_telegram_notify_enabled($con),
        'unread' => af_unread_notification_count($con),
        'workflow_stages' => af_workflow_stages(),
        'see_all_wards' => ($scope === ''),
        'ward_locked' => ($scope !== ''),
        'scope_ward' => $scope,
    ], $flags);
    exit;
}

if ($action === 'lookup_hn') {
    $hn = trim((string)($_GET['hn'] ?? $_POST['hn'] ?? ''));
    $pt = $hn !== '' ? af_lookup_patient($con, $hn) : null;
    if (!$pt) {
        echo json_encode(['status' => 'not_found', 'message' => 'ไม่พบผู้ป่วยใน HOSxP'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'patient' => $pt], $flags);
    exit;
}

if ($action === 'list') {
    $filters = [
        'start_date' => $_GET['start_date'] ?? '',
        'end_date' => $_GET['end_date'] ?? '',
        'ward' => $_GET['ward'] ?? '',
        'summary_result' => array_key_exists('summary_result', $_GET) ? $_GET['summary_result'] : 'all',
        'q' => $_GET['q'] ?? '',
        'only_mine' => !empty($_GET['only_mine']) && !$can_assess,
        'user_id' => $user['id'],
        'workflow_stage' => $_GET['workflow_stage'] ?? 'all',
    ];
    $filters = af_apply_viewer_scope($filters);
    $cases = af_list_cases($con, $filters);
    echo json_encode(['status' => 'success', 'cases' => $cases, 'unread' => af_unread_notification_count($con)], $flags);
    exit;
}

if ($action === 'get') {
    $id = (int)($_GET['id'] ?? 0);
    $case = af_get_case($con, $id, true);
    if (!$case) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบเคส'], $flags);
        exit;
    }
    $allergies = $case['hn'] !== '' ? af_lookup_hosxp_allergies($con, $case['hn']) : [];
    $dress_labs = $case['hn'] !== '' ? af_fetch_dress_labs($con, $case['hn']) : af_fetch_dress_labs($con, '');
    echo json_encode([
        'status' => 'success',
        'case' => $case,
        'allergies' => $allergies,
        'dress_labs' => $dress_labs,
    ], $flags);
    exit;
}

if ($action === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0 && !$can_assess) {
        $cur = af_get_case($con, $id, false);
        if (!$cur || (int)$cur['reporter_user_id'] !== (int)$user['id']) {
            echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์แก้ไขเคสนี้'], $flags);
            exit;
        }
    }
    $res = af_save_case($con, $_POST, $can_assess);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกไม่สำเร็จ'], $flags);
        exit;
    }
    $photo_res = null;
    if (!empty($_FILES['photos'])) {
        $photo_res = af_store_uploaded_files($con, (int)$res['id'], $_FILES['photos'], $user, 'nurse');
        $res['case'] = af_get_case($con, (int)$res['id'], true);
    }
    echo json_encode([
        'status' => 'success',
        'id' => $res['id'],
        'case' => $res['case'],
        'photos_saved' => (int)($photo_res['saved'] ?? 0),
        'photo_error' => empty($photo_res['ok']) ? ($photo_res['error'] ?? '') : '',
        'unread' => af_unread_notification_count($con),
    ], $flags);
    exit;
}

if ($action === 'assess' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_assess) {
        echo json_encode(['status' => 'error', 'message' => 'เฉพาะเภสัชกรประเมินเคสได้'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $res = af_assess_case($con, $raw);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'case' => $res['case']], $flags);
    exit;
}

if ($action === 'upload_photos' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['case_id'] ?? $_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบเคส'], $flags);
        exit;
    }
    $cur = af_case_row($con, $id);
    if (!$cur) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบเคส'], $flags);
        exit;
    }
    if (!af_can_upload_photos($cur, $user, $can_assess)) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์แนบรูปเคสนี้'], $flags);
        exit;
    }
    $files = $_FILES['photos'] ?? ($_FILES['photos'] ?? null);
    if (empty($_FILES['photos']) && empty($_FILES['photo'])) {
        $too_big = (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0 && empty($_POST) && empty($_FILES);
        echo json_encode([
            'status' => 'error',
            'message' => $too_big
                ? 'ไฟล์ใหญ่เกินที่เซิร์ฟเวอร์รับได้ กรุณาถ่ายใหม่หรือใช้รูปที่เล็กกว่า'
                : 'กรุณาเลือกรูป',
        ], $flags);
        exit;
    }
    $kind = af_photo_kind($_POST['photo_kind'] ?? 'nurse');
    if ($kind === 'progress' && !$can_assess) {
        $kind = 'nurse';
    }
    $photo_res = af_store_uploaded_files($con, $id, $_FILES['photos'] ?? $_FILES['photo'], $user, $kind);
    if (empty($photo_res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $photo_res['error'] ?? 'อัปโหลดไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'saved' => $photo_res['saved'],
        'case' => af_get_case($con, $id, true) ?: af_format_case($cur, $photo_res['photos'] ?? []),
        'unread' => af_unread_notification_count($con),
    ], $flags);
    exit;
}

if ($action === 'delete_photo' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_assess) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์ลบรูป'], $flags);
        exit;
    }
    $pid = (int)($_POST['photo_id'] ?? 0);
    if (!af_delete_photo($con, $pid)) {
        echo json_encode(['status' => 'error', 'message' => 'ลบรูปไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success'], $flags);
    exit;
}

if ($action === 'notifications') {
    $unread_only = !isset($_GET['all']) || $_GET['all'] !== '1';
    echo json_encode([
        'status' => 'success',
        'unread' => af_unread_notification_count($con),
        'telegram_notify' => af_telegram_notify_enabled($con),
        'items' => af_list_notifications($con, 40, $unread_only),
    ], $flags);
    exit;
}

if ($action === 'mark_read' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    if (!empty($raw['all'])) {
        af_mark_all_notifications_read($con, $user['id']);
    } elseif (!empty($raw['case_id'])) {
        $cid = (int)$raw['case_id'];
        $uid = (int)$user['id'];
        mysqli_query($con, "UPDATE allergy_followup_notifications
            SET is_read=1, read_at=NOW(), read_by=$uid
            WHERE case_id=$cid AND is_read=0");
    } else {
        $ids = $raw['ids'] ?? [];
        if (!is_array($ids) && isset($raw['id'])) {
            $ids = [$raw['id']];
        }
        af_mark_notifications_read($con, (array)$ids, $user['id']);
    }
    echo json_encode(['status' => 'success', 'unread' => af_unread_notification_count($con)], $flags);
    exit;
}

if ($action === 'set_telegram_notify' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_assess && ($_SESSION['role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    $enabled = is_array($raw) ? !empty($raw['enabled']) : !empty($_POST['enabled']);
    af_set_telegram_notify($con, $enabled);
    echo json_encode(['status' => 'success', 'telegram_notify' => $enabled], $flags);
    exit;
}

if ($action === 'import_gsheet' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_assess) {
        echo json_encode(['status' => 'error', 'message' => 'เฉพาะเภสัชกรนำเข้าสมุดได้'], $flags);
        exit;
    }
    if (is_file(__DIR__ . '/integrations_hub_helper.php')) {
        require_once __DIR__ . '/integrations_hub_helper.php';
        if (function_exists('ih_is_enabled') && !ih_is_enabled($con, 'google_sheet_allergy')) {
            echo json_encode([
                'status' => 'error',
                'message' => function_exists('ih_disabled_message')
                    ? ih_disabled_message('google_sheet_allergy')
                    : 'การนำเข้า Google Sheet ถูกปิดไว้',
            ], $flags);
            exit;
        }
    }
    @set_time_limit(180);
    $res = af_import_gsheet_cases($con);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'นำเข้าไม่สำเร็จ'], $flags);
        exit;
    }
    $msg = 'นำเข้า ' . $res['total'] . ' รายการ (ใหม่ ' . $res['inserted'] . ' อัปเดต ' . $res['updated'] . ')';
    if (!empty($res['hosxp_matched'])) {
        $msg .= "\nพบประวัติแพ้ใน HOSxP " . $res['hosxp_matched'] . ' เคส';
    }
    if (!empty($res['hosxp_missing'])) {
        $msg .= "\nยังไม่พบใน HOSxP " . $res['hosxp_missing'] . ' เคส';
    }
    echo json_encode([
        'status' => 'success',
        'inserted' => (int)$res['inserted'],
        'updated' => (int)$res['updated'],
        'failed' => (int)($res['failed'] ?? 0),
        'total' => (int)$res['total'],
        'hosxp_matched' => (int)($res['hosxp_matched'] ?? 0),
        'hosxp_missing' => (int)($res['hosxp_missing'] ?? 0),
        'message' => $msg,
    ], $flags);
    exit;
}

if ($action === 'dashboard') {
    $filters = [
        'start_date' => $_GET['start_date'] ?? '',
        'end_date' => $_GET['end_date'] ?? '',
        'ward' => $_GET['ward'] ?? '',
        'q' => $_GET['q'] ?? '',
        'workflow_stage' => $_GET['workflow_stage'] ?? 'all',
        'summary_result' => 'all',
        'only_mine' => !empty($_GET['only_mine']) && !$can_assess,
        'user_id' => $user['id'],
        'exclude_import' => !empty($_GET['exclude_import']),
    ];
    $filters = af_apply_viewer_scope($filters);
    $count_filters = $filters;
    $count_filters['workflow_stage'] = 'all';
    echo json_encode([
        'status' => 'success',
        'counts' => af_dashboard_counts($con, $count_filters),
        'cases' => af_list_cases($con, $filters),
        'unread' => af_unread_notification_count($con),
    ], $flags);
    exit;
}

if ($action === 'ack' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_assess) {
        echo json_encode(['status' => 'error', 'message' => 'เฉพาะเภสัชกรรับเคสได้'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $res = af_advance_ack(
        $con,
        (int)($raw['id'] ?? 0),
        (string)($raw['note'] ?? ''),
        $raw['ack_user_id'] ?? $raw['user_id'] ?? 0,
        (string)($raw['ack_by_name'] ?? $raw['ack_name'] ?? '')
    );
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'รับเคสไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'case' => $res['case']], $flags);
    exit;
}

if ($action === 'transfer' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_assess) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์ส่งต่อเคส'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $res = af_transfer_case(
        $con,
        (int)($raw['id'] ?? 0),
        $raw['ack_user_id'] ?? $raw['user_id'] ?? $raw['owner_user_id'] ?? $raw['to_user_id'] ?? 0,
        (string)($raw['ack_by_name'] ?? $raw['ack_name'] ?? $raw['owner_name'] ?? $raw['to_name'] ?? ''),
        (string)($raw['note'] ?? '')
    );
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'ส่งต่อเคสไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'case' => $res['case']], $flags);
    exit;
}

if ($action === 'update_workflow' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_assess) {
        echo json_encode(['status' => 'error', 'message' => 'เฉพาะเภสัชกรแก้ไขสถานะได้'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $res = af_update_workflow(
        $con,
        (int)($raw['id'] ?? 0),
        (string)($raw['workflow_stage'] ?? $raw['stage'] ?? ''),
        (int)($raw['ack_user_id'] ?? $raw['user_id'] ?? 0),
        (string)($raw['ack_by_name'] ?? $raw['ack_name'] ?? ''),
        (string)($raw['note'] ?? '')
    );
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกสถานะไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'case' => $res['case']], $flags);
    exit;
}

if ($action === 'followup' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_assess) {
        echo json_encode(['status' => 'error', 'message' => 'เฉพาะเภสัชกรบันทึกติดตามได้'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $extra = [
        'assessment_detail' => (string)($raw['assessment_detail'] ?? ''),
        'referral_note' => (string)($raw['referral_note'] ?? ''),
        'summary_result' => (string)($raw['summary_result'] ?? ''),
    ];
    if (array_key_exists('allergy_chronology', $raw)) {
        $extra['allergy_chronology'] = $raw['allergy_chronology'];
    }
    if (array_key_exists('naranjo_assessment', $raw)) {
        $extra['naranjo_assessment'] = $raw['naranjo_assessment'];
    }
    if (array_key_exists('regiscar_assessment', $raw)) {
        $extra['regiscar_assessment'] = $raw['regiscar_assessment'];
    }
    if (array_key_exists('assessed_drugs', $raw)) {
        $extra['assessed_drugs'] = $raw['assessed_drugs'];
    }
    if (array_key_exists('owner_user_id', $raw) || array_key_exists('owner_name', $raw)) {
        $extra['owner_user_id'] = (int)($raw['owner_user_id'] ?? 0);
        $extra['owner_name'] = (string)($raw['owner_name'] ?? '');
    }
    $res = af_add_followup(
        $con,
        (int)($raw['id'] ?? 0),
        (string)($raw['note'] ?? ''),
        $extra
    );
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกติดตามไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'followup_no' => $res['followup_no'] ?? 0, 'case' => $res['case']], $flags);
    exit;
}

if ($action === 'close' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_assess) {
        echo json_encode(['status' => 'error', 'message' => 'เฉพาะเภสัชกรปิดเคสได้'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $res = af_close_case(
        $con,
        (int)($raw['id'] ?? 0),
        (string)($raw['summary_result'] ?? ''),
        (string)($raw['note'] ?? ''),
        (string)($raw['assessment_detail'] ?? ''),
        (string)($raw['referral_note'] ?? ''),
        array_key_exists('allergy_chronology', $raw) ? $raw['allergy_chronology'] : null,
        array_key_exists('naranjo_assessment', $raw) ? $raw['naranjo_assessment'] : null,
        array_key_exists('regiscar_assessment', $raw) ? $raw['regiscar_assessment'] : null,
        array_key_exists('owner_user_id', $raw) ? (int)$raw['owner_user_id'] : null,
        array_key_exists('owner_name', $raw) ? (string)$raw['owner_name'] : null,
        array_key_exists('assessed_drugs', $raw) ? $raw['assessed_drugs'] : null
    );
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'ปิดเคสไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'case' => $res['case']], $flags);
    exit;
}

if ($action === 'update_event' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_assess) {
        echo json_encode(['status' => 'error', 'message' => 'เฉพาะเภสัชกรแก้ไขไทม์ไลน์ได้'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $res = af_update_event($con, (int)($raw['event_id'] ?? $raw['id'] ?? 0), (string)($raw['note'] ?? ''));
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'case' => $res['case'], 'event_id' => (int)($res['event_id'] ?? 0)], $flags);
    exit;
}

if ($action === 'delete_case' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $confirm = trim((string)($raw['confirm'] ?? ''));
    if ($confirm !== 'delete') {
        echo json_encode(['status' => 'error', 'message' => "พิมพ์คำว่า 'delete' เพื่อยืนยันการลบ"], $flags);
        exit;
    }
    $res = af_delete_case($con, (int)($raw['id'] ?? 0));
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'ลบเคสไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'id' => (int)$res['id'], 'unread' => af_unread_notification_count($con)], $flags);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], $flags);
