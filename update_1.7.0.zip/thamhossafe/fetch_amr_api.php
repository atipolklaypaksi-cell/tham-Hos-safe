<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/amr_helper.php');
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_mlab_helper.php';
mysqli_set_charset($con, 'utf8');
set_time_limit(120);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

amr_dict_ensure_tables($con);
amr_dict_prime($con);

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = [];
}
$src = array_merge($_GET, $input);

$action = trim((string)($src['action'] ?? 'dashboard'));
$end = amr_parse_date($src['end_date'] ?? '', date('Y-m-d'));
$start = amr_parse_date($src['start_date'] ?? '', date('Y-m-d', strtotime('-29 days')));
if ($start > $end) {
    $tmp = $start;
    $start = $end;
    $end = $tmp;
}
$span = (int)floor((strtotime($end) - strtotime($start)) / 86400);
if ($span > 366) {
    $start = date('Y-m-d', strtotime($end . ' -366 days'));
}

$chunk_days = (int)($src['chunk_days'] ?? 3);
if ($chunk_days < 1) {
    $chunk_days = 1;
}
if ($chunk_days > 7) {
    $chunk_days = 7;
}

function amr_api_filters(array $src) {
    return [
        'wards' => amr_parse_list($src['wards'] ?? ($src['Wardname'] ?? '')),
        'microtypes' => amr_parse_list($src['microtypes'] ?? ($src['Microbiotype'] ?? '')),
        'typeinfect' => amr_parse_list($src['typeinfect'] ?? ($src['Typeinfect'] ?? '')),
        'specimens' => amr_parse_list($src['specimens'] ?? ($src['Specimen'] ?? '')),
        'results' => amr_parse_list($src['results'] ?? ''),
        'ward_mode' => (($src['ward_mode'] ?? 'snapshot') === 'now') ? 'now' : 'snapshot',
        'culture_scope' => amr_dashboard_culture_scope($src['culture_scope'] ?? 'resistant'),
    ];
}

function amr_api_json(array $payload) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function amr_api_connect($con, $timeout = 90, $required = true) {
    $hos = hosxp_connect($con, $timeout);
    if (!$hos) {
        if ($required) {
            amr_api_json(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้']);
        }
        return null;
    }
    hosxp_extend_read_timeout($hos, $timeout);
    return $hos;
}

$use_mlab = amr_mlab_using_direct($con);

if ($action === 'plan') {
    amr_api_json([
        'status' => 'success',
        'start_date' => $start,
        'end_date' => $end,
        'chunk_days' => $chunk_days,
        'chunks' => amr_date_chunks($start, $end, $chunk_days),
    ]);
}

if ($action === 'assemble') {
    $rows = $input['rows'] ?? [];
    if (!is_array($rows)) {
        $rows = [];
    }
    $bed_days = $input['bed_days'] ?? [];
    if (!is_array($bed_days)) {
        $bed_days = [];
    }
    $report = amr_assemble_dashboard(
        $rows,
        $bed_days,
        $start,
        $end,
        (int)($input['grafana_join_count'] ?? 0)
    );
    if (!isset($report['meta']) || !is_array($report['meta'])) {
        $report['meta'] = [];
    }
    $report['meta']['data_source'] = $use_mlab ? 'mlab' : 'hosxp';
    $report['meta']['data_source_label'] = $use_mlab
        ? 'mLAB (ตาราง THAM Hos-Safe)'
        : 'HOSxP';
    $report['meta']['culture_scope'] = amr_dashboard_culture_scope($src['culture_scope'] ?? 'resistant');
    amr_api_json($report);
}

$filters = amr_api_filters($src);

if ($action === 'filters' || $action === 'wards') {
    $hos = amr_api_connect($con, 60, !$use_mlab);
    $wards = $hos ? amr_fetch_wards($hos) : [];
    $result_labels = amr_dict_labels($con, 'result');
    if (empty($result_labels)) {
        $result_labels = ['CRE_MDR', 'MRSA', 'MRSA_VRSA', 'MRSE', 'VRE', 'ESBL', 'CRAB_MDR', 'CRAB', 'CRPA', 'CRPA_MDR', 'MDR'];
    }
    if ($hos) {
        mysqli_close($hos);
    }
    amr_api_json([
        'status' => 'success',
        'wards' => $wards,
        'typeinfect' => ['NI', 'CI'],
        'results' => $result_labels,
        'source' => $use_mlab ? 'mlab' : 'hosxp',
    ]);
}

if ($action === 'bed_days') {
    $hos = amr_api_connect($con, 90, !$use_mlab);
    $t0 = microtime(true);
    $bed_days = $hos ? amr_fetch_bed_days($hos, $start, $end, $filters['wards'] ?? []) : [];
    if ($hos) {
        mysqli_close($hos);
    }
    amr_api_json([
        'status' => 'success',
        'bed_days' => $bed_days,
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
    ]);
}

if ($action === 'chunk') {
    $t0 = microtime(true);
    if ($use_mlab) {
        amr_mlab_ensure_tables($con);
        $hosNi = amr_api_connect($con, 60, false);
        $cases = amr_mlab_fetch_cases($con, $start, $end, $filters, $hosNi);
        if ($hosNi) {
            mysqli_close($hosNi);
        }
    } else {
        $hos = amr_api_connect($con, 90);
        $cases = amr_fetch_cases($hos, $start, $end, $filters);
        mysqli_close($hos);
    }
    if ($cases['error'] !== '') {
        amr_api_json([
            'status' => 'error',
            'message' => 'ดึงข้อมูลเชื้อดื้อยาไม่สำเร็จ: ' . $cases['error'],
            'start_date' => $start,
            'end_date' => $end,
        ]);
    }
    amr_api_json([
        'status' => 'success',
        'start_date' => $start,
        'end_date' => $end,
        'rows' => $cases['rows'],
        'row_count' => count($cases['rows']),
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
        'source' => $use_mlab ? 'mlab' : 'hosxp',
    ]);
}

$hos = amr_api_connect($con, 180, !$use_mlab);
if ($use_mlab) {
    $t0 = microtime(true);
    $cases = amr_mlab_fetch_cases($con, $start, $end, $filters, $hos);
    if ($cases['error'] !== '') {
        amr_api_json(['status' => 'error', 'message' => 'ดึงข้อมูลเชื้อดื้อยาไม่สำเร็จ: ' . $cases['error']]);
    }
    $bed_days = $hos ? amr_fetch_bed_days($hos, $start, $end, $filters['wards'] ?? []) : [];
    $report = amr_assemble_dashboard($cases['rows'], $bed_days, $start, $end, 0, $t0);
} else {
    $report = amr_build_dashboard($hos, $start, $end, $filters);
}
if (!isset($report['meta']) || !is_array($report['meta'])) {
    $report['meta'] = [];
}
$report['meta']['data_source'] = $use_mlab ? 'mlab' : 'hosxp';
$report['meta']['data_source_label'] = $use_mlab ? 'mLAB (ตาราง THAM Hos-Safe)' : 'HOSxP';
$report['meta']['culture_scope'] = $filters['culture_scope'] ?? 'resistant';
if ($hos) {
    mysqli_close($hos);
}
amr_api_json($report);
