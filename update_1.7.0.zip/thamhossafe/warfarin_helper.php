<?php
/**
 * คำนวณปรับขนาด Warfarin — ดึงรายการจาก HOSxP ตาม HN + แนะนำวิธีใช้ใกล้เคียง mg/สัปดาห์
 */

require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
require_once __DIR__ . '/drug_reconciliation_helper.php';

function wf_is_warfarin_text($text) {
    $t = trim((string)$text);
    if ($t === '') {
        return false;
    }
    return (bool)preg_match('/warfarin|วาร์ฟาริน|วาร์ฟารีน|วารfarin|marevan|orfari|วาฟาริน/ui', $t);
}

/** รายการที่เป็นคำเตือน/คำแนะนำ — ไม่ใช่เม็ดยา */
function wf_is_warfarin_advisory(array $drug) {
    $name = trim(($drug['drug_name'] ?? '') . ' ' . ($drug['drug_name_tmt'] ?? ''));
    if ($name === '') {
        return true;
    }
    if (preg_match('/หลีกเลี่ยง|NSAIDs?|คำแนะนำ|คำเตือน|ระวัง|ห้ามใช้|ปฏิกิริยา/ui', $name)) {
        return true;
    }
    // เช่น "ผู้ป่วยใช้ยา Warfarin ..." โดยไม่มีความแรง mg
    $strength = hosxp_parse_strength_mg($drug['strength'] ?? '', $drug['units'] ?? '');
    if ($strength === null || $strength <= 0) {
        if (!preg_match('/\d+(?:\.\d+)?\s*mg/i', $name)) {
            return true;
        }
    }
    return false;
}

function wf_is_warfarin_product(array $drug) {
    $blob = ($drug['drug_name'] ?? '') . ' ' . ($drug['drug_name_tmt'] ?? '') . ' ' . ($drug['strength'] ?? '');
    if (!wf_is_warfarin_text($blob)) {
        return false;
    }
    if (wf_is_warfarin_advisory($drug)) {
        return false;
    }
    return true;
}

/** รายการที่หยุดยา / ไม่ได้จ่าย — ไม่นำมาคำนวณ mg/สัปดาห์ */
function wf_is_off_warfarin_order(array $drug) {
    $method = trim(preg_replace('/\s+/u', ' ', (string)($drug['method'] ?? '')));
    if ($method !== '' && preg_match('/^off$/i', $method)) {
        return true;
    }
    // HOSxP ต่อท้ายวิธีใช้เดิมด้วย OFF / แพทย์ให้หยุดใช้เท่านี้
    if (preg_match('/\boff\b/i', $method)) {
        return true;
    }
    if (preg_match('/แพทย์ให้หยุด|หยุดใช้เท่านี้|สั่งหยุด/ui', $method)) {
        return true;
    }
    if (preg_match('/^(หยุด|งดทาน|งดยา|ยกเลิก)(\s|$)/ui', $method)) {
        return true;
    }
    $src = (string)($drug['source_label'] ?? '');
    $isIpdMedplan = (stripos($src, 'IPD') !== false);
    $hasQtyKey = array_key_exists('qty', $drug);
    $qty = $hasQtyKey ? (float)$drug['qty'] : null;
    // OPD จำนวนสั่ง 0 = แพทย์ OFF (IPD medplan มัก qty=0 แต่ยังใช้ยาอยู่)
    if ($hasQtyKey && $qty <= 0 && !$isIpdMedplan) {
        return true;
    }
    if ($hasQtyKey && $qty <= 0 && $method === '') {
        return true;
    }
    return false;
}

function wf_is_inactive_warfarin_order(array $drug) {
    return wf_is_off_warfarin_order($drug);
}

function wf_is_hme_order_row(array $row) {
    $order_type = strtolower(trim((string)($row['order_type'] ?? $row['order_kind'] ?? '')));
    $item_type = trim((string)($row['item_type'] ?? ''));
    if ($order_type === 'hme' || $order_type === 'hme.') {
        return true;
    }
    return ($item_type === 'H' || strcasecmp($item_type, 'Hme') === 0);
}

function wf_filter_warfarin_rows(array $rows, $includeOff = false) {
    $out = [];
    foreach ($rows as $r) {
        if (!wf_is_warfarin_product($r)) {
            continue;
        }
        $off = wf_is_off_warfarin_order($r);
        if ($off && !$includeOff) {
            continue;
        }
        if ($off) {
            $r['is_off'] = true;
            $r['mg_week'] = null;
            $r['strength_mg'] = $r['strength_mg'] ?? null;
            $r['daily_units'] = null;
            $r['days_per_week'] = 0;
            $r['mg_week_source'] = 'off';
            $r['mg_week_notes'] = ['แพทย์ OFF (จำนวนสั่ง 0)'];
            if (!isset($r['strength_mg']) || !($r['strength_mg'] > 0)) {
                $est = wf_estimate_mg_week($r);
                $r['strength_mg'] = $est['strength_mg'];
            }
            $out[] = $r;
            continue;
        }
        $est = wf_estimate_mg_week($r);
        $r['is_off'] = false;
        $r['mg_week'] = $est['mg_week'];
        $r['strength_mg'] = $est['strength_mg'];
        $r['daily_units'] = $est['daily_units'];
        $r['days_per_week'] = $est['days_per_week'] ?? null;
        $r['mg_week_source'] = $est['source'];
        $r['mg_week_notes'] = $est['notes'];
        $out[] = $r;
    }
    return $out;
}

function wf_day_names() {
    return ['จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์', 'อาทิตย์'];
}

/** map ชื่อวัน → index 0..6 (จันทร์=0) */
function wf_day_alias_map() {
    return [
        'พฤหัสบดี' => 3,
        'อาทิตย์' => 6,
        'อังคาร' => 1,
        'จันทร์' => 0,
        'พฤหัส' => 3,
        'ศุกร์' => 4,
        'เสาร์' => 5,
        'พุธ' => 2,
        'จัน' => 0,
        'อังค' => 1,
        'พฤห' => 3,
        'ศุก' => 4,
        'เสา' => 5,
        'อาทิต' => 6,
    ];
}

function wf_day_index_from_name($name) {
    $name = trim((string)$name);
    $map = wf_day_alias_map();
    if (isset($map[$name])) {
        return $map[$name];
    }
    return null;
}

/**
 * ดึงวันในสัปดาห์จากวิธีใช้
 * @return int[]|null รายการ index วัน หรือ null ถ้าไม่ระบุวัน (กินทุกวัน)
 */
function wf_parse_day_indices_from_method($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return null;
    }

    // ไม่มีคำบอกวันเลย → กินทุกวัน
    if (!preg_match('/จันทร์|อังคาร|พุธ|พฤหัส|ศุกร์|เสาร์|อาทิตย์|เฉพาะวัน/ui', $m)) {
        return null;
    }

    $aliases = wf_day_alias_map();
    // เรียงยาวก่อน (คงที่) เพื่อจับ พฤหัสบดี ก่อน พฤหัส
    $names = [
        'พฤหัสบดี', 'อาทิตย์', 'อังคาร', 'จันทร์', 'พฤหัส', 'ศุกร์', 'เสาร์', 'พุธ',
        'อาทิต', 'อังค', 'พฤห', 'ศุก', 'เสา', 'จัน',
    ];

    $selected = [];
    $hadRange = false;

    // ช่วงวัน: จันทร์ ถึง เสาร์ / จันทร์ถึงวันเสาร์ / จันทร์-เสาร์
    // รองรับคำว่า "วัน" นำหน้าชื่อวัน
    $dayPat = '(?:วัน)?(พฤหัสบดี|อาทิตย์|อังคาร|จันทร์|พฤหัส|ศุกร์|เสาร์|พุธ|จัน|อังค|พฤห|ศุก|เสา|อาทิต)';
    if (preg_match('/' . $dayPat . '\s*(?:ถึง|ถึงวัน|-|–|—)\s*' . $dayPat . '/u', $m, $rm)) {
        $from = wf_day_index_from_name($rm[1]);
        $to = wf_day_index_from_name($rm[2]);
        if ($from !== null && $to !== null) {
            $hadRange = true;
            if ($from <= $to) {
                for ($i = $from; $i <= $to; $i++) {
                    $selected[$i] = true;
                }
            } else {
                for ($i = $from; $i <= 6; $i++) {
                    $selected[$i] = true;
                }
                for ($i = 0; $i <= $to; $i++) {
                    $selected[$i] = true;
                }
            }
        }
    }

    // รายชื่อวันเดี่ยวๆ — ถ้ามีช่วง "ถึง" แล้ว ไม่ต้องไล่จับชื่อวันซ้ำจากข้อความช่วงนั้น
    // (กันกรณีจับได้แค่ จันทร์+เสาร์ ทั้งที่เป็นจันทร์ถึงเสาร์)
    if (!$hadRange) {
        foreach ($names as $name) {
            if (!isset($aliases[$name])) {
                continue;
            }
            if (preg_match('/' . preg_quote($name, '/') . '/u', $m)) {
                $selected[$aliases[$name]] = true;
            }
        }
    } else {
        // มีช่วงแล้ว แต่ยังมีวันอื่นนอกช่วง เช่น "จันทร์ถึงพุธ และศุกร์"
        // ตัดส่วนช่วงออกก่อน แล้วค่อยหาวันที่เหลือ
        $rest = preg_replace('/' . $dayPat . '\s*(?:ถึง|ถึงวัน|-|–|—)\s*' . $dayPat . '/u', ' ', $m);
        foreach ($names as $name) {
            if (!isset($aliases[$name])) {
                continue;
            }
            if (preg_match('/' . preg_quote($name, '/') . '/u', $rest)) {
                $selected[$aliases[$name]] = true;
            }
        }
    }

    if (empty($selected)) {
        return null;
    }
    $idxs = array_map('intval', array_keys($selected));
    sort($idxs);
    return $idxs;
}

function wf_parse_tabs_per_dose($method) {
    $qtyInfo = hosxp_parse_qty_from_usage($method);
    if ($qtyInfo !== null && isset($qtyInfo['qty'])) {
        return (float)$qtyInfo['qty'];
    }
    $m = trim((string)$method);
    if (preg_match('/ครึ่ง/ui', $m)) {
        return 0.5;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*เม็ด/ui', $m, $mm)) {
        return (float)$mm[1];
    }
    return null;
}

/**
 * แยกวิธีใช้ที่มีหลายขนาดในประโยคเดียว
 * เช่น "ครั้งละ 1 เม็ด จันทร์ถึงเสาร์ และครั้งละ ครึ่ง เม็ด เฉพาะวันอาทิตย์"
 * @return array<int,array{tabs:float,days:?int[],text:string}>
 */
function wf_parse_method_dose_clauses($method) {
    $m = trim((string)$method);
    if ($m === '') {
        return [];
    }
    $re = '/(?:ครั้งละ|วันละ)?\s*(?:(\d+(?:\.\d+)?)\s*เม็ด\s*ครึ่ง|ครึ่ง\s*เม็ด|เม็ด\s*ครึ่ง|ครึ่งเม็ด|(\d+(?:\.\d+)?)\s*เม็ด)/ui';
    if (!preg_match_all($re, $m, $mm, PREG_SET_ORDER | PREG_OFFSET_CAPTURE)) {
        return [];
    }
    $n = count($mm);
    $clauses = [];
    for ($i = 0; $i < $n; $i++) {
        $full = $mm[$i][0][0];
        $start = ($i === 0) ? 0 : (int)$mm[$i][0][1];
        $end = ($i + 1 < $n) ? (int)$mm[$i + 1][0][1] : strlen($m);
        $slice = trim((string)substr($m, $start, max(0, $end - $start)));
        $tabs = null;
        if (!empty($mm[$i][1][0])) {
            $tabs = (float)$mm[$i][1][0] + 0.5;
        } elseif (preg_match('/ครึ่ง/ui', $full)) {
            $tabs = 0.5;
        } elseif (!empty($mm[$i][2][0])) {
            $tabs = (float)$mm[$i][2][0];
        } else {
            $tabs = wf_parse_tabs_per_dose($slice);
        }
        if ($tabs === null || $tabs <= 0) {
            continue;
        }
        $clauses[] = [
            'tabs' => (float)$tabs,
            'days' => wf_parse_day_indices_from_method($slice),
            'text' => $slice,
        ];
    }
    return $clauses;
}

/**
 * จำนวนเม็ดต่อวัน (จันทร์=0 .. อาทิตย์=6) จากวิธีใช้ รองรับหลายขนาดในประโยคเดียว
 * @return float[] length 7
 */
function wf_tabs_per_weekday_from_method($method) {
    $tabs = array_fill(0, 7, 0.0);
    $clauses = wf_parse_method_dose_clauses($method);
    if (count($clauses) >= 2) {
        $assigned = [];
        $pending = [];
        foreach ($clauses as $c) {
            $days = $c['days'];
            if (is_array($days) && count($days) > 0) {
                foreach ($days as $d) {
                    $d = (int)$d;
                    if ($d < 0 || $d > 6) {
                        continue;
                    }
                    $tabs[$d] += (float)$c['tabs'];
                    $assigned[$d] = true;
                }
            } else {
                $pending[] = $c;
            }
        }
        foreach ($pending as $c) {
            $rest = [];
            for ($i = 0; $i < 7; $i++) {
                if (empty($assigned[$i])) {
                    $rest[] = $i;
                }
            }
            if (empty($rest)) {
                $rest = [0, 1, 2, 3, 4, 5, 6];
            }
            foreach ($rest as $d) {
                $tabs[$d] += (float)$c['tabs'];
                $assigned[$d] = true;
            }
        }
        return $tabs;
    }

    $t = wf_parse_tabs_per_dose($method);
    if ($t === null || $t <= 0) {
        $t = (count($clauses) === 1) ? (float)$clauses[0]['tabs'] : null;
    }
    if ($t === null || $t <= 0) {
        return $tabs;
    }
    $days = wf_parse_day_indices_from_method($method);
    if ($days === null && count($clauses) === 1) {
        $days = $clauses[0]['days'];
    }
    if ($days === null) {
        $days = [0, 1, 2, 3, 4, 5, 6];
    }
    foreach ($days as $d) {
        $d = (int)$d;
        if ($d >= 0 && $d <= 6) {
            $tabs[$d] = (float)$t;
        }
    }
    return $tabs;
}

/**
 * ประมาณ mg/สัปดาห์ จาก strength + วิธีใช้
 */
function wf_estimate_mg_week(array $drug) {
    $strength = hosxp_parse_strength_mg($drug['strength'] ?? '', $drug['units'] ?? '');
    if (($strength === null || $strength <= 0) && preg_match('/(\d+(?:\.\d+)?)\s*mg/i', ($drug['drug_name'] ?? '') . ' ' . ($drug['drug_name_tmt'] ?? ''), $sm)) {
        $strength = (float)$sm[1];
    }
    $method = trim((string)($drug['method'] ?? ''));
    $notes = [];
    $byDay = wf_tabs_per_weekday_from_method($method);
    $dayNames = wf_day_names();
    $activeDays = [];
    $mg = 0.0;
    $tabSum = 0.0;
    $distinctTabs = [];
    foreach ($byDay as $i => $t) {
        $t = (float)$t;
        if ($t <= 0) {
            continue;
        }
        $mg += $strength !== null && $strength > 0 ? ($strength * $t) : 0.0;
        $tabSum += $t;
        $activeDays[] = $dayNames[$i] ?? $i;
        $k = rtrim(rtrim(number_format($t, 2, '.', ''), '0'), '.');
        $distinctTabs[$k] = true;
    }

    if ($strength !== null && $strength > 0 && $tabSum > 0) {
        $clauses = wf_parse_method_dose_clauses($method);
        if (count($clauses) >= 2) {
            $parts = [];
            foreach ($clauses as $c) {
                $days = is_array($c['days']) ? $c['days'] : [];
                $dn = [];
                foreach ($days as $di) {
                    $dn[] = $dayNames[$di] ?? $di;
                }
                $tb = rtrim(rtrim(number_format((float)$c['tabs'], 2, '.', ''), '0'), '.');
                $parts[] = $tb . ' เม็ด × ' . $strength . ' mg × ' . max(1, count($days)) . ' วัน'
                    . ($dn ? ' (' . implode(',', $dn) . ')' : '');
            }
            $notes[] = implode(' + ', $parts);
        } else {
            $tabsUse = (count($distinctTabs) === 1)
                ? (float)array_keys($distinctTabs)[0]
                : ($tabSum / count($activeDays));
            $notes[] = rtrim(rtrim(number_format($tabsUse, 2, '.', ''), '0'), '.')
                . ' เม็ด × ' . $strength . ' mg × ' . count($activeDays) . ' วัน (' . implode(',', $activeDays) . ')';
        }
        return [
            'mg_week' => round($mg, 2),
            'strength_mg' => $strength,
            'daily_units' => round($tabSum / max(1, count($activeDays)), 4),
            'days_per_week' => count($activeDays),
            'tabs_by_day' => $byDay,
            'source' => count($clauses) >= 2 ? 'compound_days' : (count($activeDays) < 7 ? 'day_specific' : 'daily_x7'),
            'notes' => $notes,
        ];
    }

    $tabs = wf_parse_tabs_per_dose($method);
    $dayIdx = wf_parse_day_indices_from_method($method);

    // กรณีระบุวันชัดเจน เช่น เฉพาะวันจันทร์ถึงเสาร์ / วันอาทิตย์
    if ($strength !== null && $strength > 0 && $dayIdx !== null && count($dayIdx) > 0) {
        $tabsUse = ($tabs !== null && $tabs > 0) ? $tabs : 1.0;
        $days = count($dayIdx);
        $mg = $strength * $tabsUse * $days;
        $dayNames = wf_day_names();
        $label = [];
        foreach ($dayIdx as $i) {
            $label[] = $dayNames[$i] ?? $i;
        }
        $notes[] = $tabsUse . ' เม็ด × ' . $strength . ' mg × ' . $days . ' วัน (' . implode(',', $label) . ')';
        return [
            'mg_week' => round($mg, 2),
            'strength_mg' => $strength,
            'daily_units' => $tabsUse,
            'days_per_week' => $days,
            'source' => 'day_specific',
            'notes' => $notes,
        ];
    }

    // กินทุกวัน (ไม่ระบุวัน)
    if ($strength !== null && $strength > 0 && $tabs !== null && $tabs > 0) {
        return [
            'mg_week' => round($strength * $tabs * 7, 2),
            'strength_mg' => $strength,
            'daily_units' => $tabs,
            'days_per_week' => 7,
            'source' => 'daily_x7',
            'notes' => $notes,
        ];
    }

    $daily_units = hosxp_parse_daily_units_from_usage($method);
    if ($strength !== null && $strength > 0 && $daily_units !== null && $daily_units > 0) {
        return [
            'mg_week' => round($strength * $daily_units * 7, 2),
            'strength_mg' => $strength,
            'daily_units' => $daily_units,
            'days_per_week' => 7,
            'source' => 'strength_x_daily_units',
            'notes' => $notes,
        ];
    }

    if ($strength !== null && $strength > 0) {
        $notes[] = 'ไม่พบจำนวนเม็ด/วันชัดเจน — สมมติ 1 เม็ด/วัน × 7';
        return [
            'mg_week' => round($strength * 7, 2),
            'strength_mg' => $strength,
            'daily_units' => 1,
            'days_per_week' => 7,
            'source' => 'assumed_1_tab_daily',
            'notes' => $notes,
        ];
    }

    return [
        'mg_week' => null,
        'strength_mg' => $strength,
        'daily_units' => $tabs,
        'days_per_week' => null,
        'source' => 'unknown',
        'notes' => ['ไม่สามารถคำนวณ mg/สัปดาห์จากข้อมูลที่มีได้'],
    ];
}

function wf_format_date_th($date) {
    $d = wf_ymd_normalize($date);
    if ($d === '') {
        return '';
    }
    $ts = strtotime($d);
    if (!$ts) {
        return trim((string)$date);
    }
    return date('d/m/', $ts) . ((int)date('Y', $ts) + 543);
}

/** เงื่อนไขชื่อยา Warfarin ใน SQL */
function wf_sql_warfarin_name_clause($d_alias = 'd', $tm_alias = 'tm') {
    return "(
        $d_alias.name LIKE '%warfarin%' OR $d_alias.name LIKE '%Warfarin%'
        OR $d_alias.name LIKE '%วาร์ฟาริน%' OR $d_alias.name LIKE '%วาร์ฟารีน%'
        OR $d_alias.name LIKE '%Marevan%' OR $d_alias.name LIKE '%Orfarin%'
        OR $d_alias.name LIKE '%วาฟาริน%'
        OR COALESCE($tm_alias.active_ingredient,'') LIKE '%Warfarin%'
    )";
}

/**
 * icode ของยา Warfarin จาก drugitems (ตารางเล็ก) — ใช้กรอง opitemrece ให้ใช้ index
 * @return string[]
 */
function wf_warfarin_icodes($hos) {
    static $cache = null;
    if (is_array($cache)) {
        return $cache;
    }
    $cache = [];
    if (!$hos) {
        return $cache;
    }
    $name_clause = wf_sql_warfarin_name_clause('d', 'tm');
    $tmt = function_exists('hosxp_sql_tmt_join') ? hosxp_sql_tmt_join('d', 'tm') : '';
    $sql = "SELECT d.icode FROM drugitems d $tmt WHERE $name_clause LIMIT 80";
    $q = @mysqli_query($hos, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $icode = trim((string)($r['icode'] ?? ''));
            if ($icode !== '') {
                $cache[$icode] = $icode;
            }
        }
    }
    $cache = array_values($cache);
    return $cache;
}

function wf_sql_warfarin_icode_in($hos, $alias = 'o') {
    $icodes = wf_warfarin_icodes($hos);
    if (empty($icodes)) {
        return '';
    }
    $parts = [];
    foreach ($icodes as $icode) {
        $parts[] = "'" . mysqli_real_escape_string($hos, $icode) . "'";
    }
    return $alias . '.icode IN (' . implode(',', $parts) . ')';
}

/**
 * ดึง Warfarin จาก visit ล่าสุดเท่านั้น — คงทุกบรรทัด (เช่น 3 mg 1 เม็ด และ 3 mg ½ เม็ด)
 * ใช้กับ OPD
 */
function wf_fetch_latest_visit_warfarin($con_hosxp, $hn) {
    $hn_sql = function_exists('dr_hn_sql_in') ? dr_hn_sql_in($con_hosxp, $hn) : '';
    if ($hn_sql === '') {
        return ['items' => [], 'visit' => null];
    }

    $joins = dr_sql_drug_joins();
    $name_clause = wf_sql_warfarin_name_clause('d', 'tm');

    // หา visit ล่าสุดที่มีสั่ง Warfarin
    $sql_visit = "
        SELECT o.vn, o.an, o.vstdate, o.vsttime,
               COALESCE(NULLIF(o.rxdate, '0000-00-00'), o.vstdate) AS order_date
        FROM opitemrece o
        $joins
        WHERE o.hn IN ($hn_sql)
          AND $name_clause
          AND o.vstdate IS NOT NULL
          AND o.vstdate <> '0000-00-00'
        ORDER BY o.vstdate DESC, o.vsttime DESC, o.rxdate DESC, o.rxtime DESC, o.item_no DESC
        LIMIT 1
    ";
    $visit = null;
    $qv = @mysqli_query($con_hosxp, $sql_visit);
    if ($qv && ($vr = mysqli_fetch_assoc($qv))) {
        $visit = [
            'vn' => trim((string)($vr['vn'] ?? '')),
            'an' => trim((string)($vr['an'] ?? '')),
            'vstdate' => trim((string)($vr['vstdate'] ?? '')),
            'vsttime' => trim((string)($vr['vsttime'] ?? '')),
            'order_date' => trim((string)($vr['order_date'] ?? '')),
        ];
    }
    if (!$visit || $visit['vstdate'] === '') {
        return ['items' => [], 'visit' => null];
    }

    $method = di_sql_method_expr('o', 'du', 'sp', 'od');
    $tmt = hosxp_sql_tmt_drug_name('d', 'tm');
    $strength = hosxp_sql_tmt_strength('d', 'tm');
    $sel = "
        o.icode,
        o.item_no,
        o.qty,
        o.vn,
        o.an,
        o.vstdate,
        o.vsttime,
        o.rxdate,
        o.rxtime,
        CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name_local,
        $tmt AS drug_name_tmt,
        CAST(CONVERT($strength USING utf8) AS CHAR) AS strength,
        CAST(CONVERT(d.units USING utf8) AS CHAR) AS units,
        $method AS method,
        COALESCE(NULLIF(o.rxdate, '0000-00-00'), o.vstdate) AS source_date
    ";

    $where_visit = '';
    if ($visit['vn'] !== '') {
        $vn_esc = mysqli_real_escape_string($con_hosxp, $visit['vn']);
        $where_visit = "o.vn = '$vn_esc'";
    } elseif ($visit['an'] !== '') {
        $an_esc = mysqli_real_escape_string($con_hosxp, $visit['an']);
        $vst_esc = mysqli_real_escape_string($con_hosxp, $visit['vstdate']);
        $where_visit = "o.an = '$an_esc' AND o.vstdate = '$vst_esc'";
    } else {
        $vst_esc = mysqli_real_escape_string($con_hosxp, $visit['vstdate']);
        $where_visit = "o.hn IN ($hn_sql) AND o.vstdate = '$vst_esc'";
    }

    $date_th = wf_format_date_th($visit['vstdate']);
    $source_label = 'Visit ล่าสุด' . ($date_th !== '' ? ' (' . $date_th . ')' : '');

    $sql = "
        SELECT $sel
        FROM opitemrece o
        $joins
        WHERE $where_visit
          AND $name_clause
        ORDER BY o.item_no ASC, o.rxdate ASC, o.rxtime ASC
    ";

    $rows = [];
    $q = @mysqli_query($con_hosxp, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $mapped = dr_map_drug_row($r, $source_label);
            $item_no = trim((string)($r['item_no'] ?? ''));
            $rxdate = trim((string)($r['rxdate'] ?? ''));
            if ($rxdate === '' || $rxdate === '0000-00-00') {
                $rxdate = trim((string)($r['vstdate'] ?? ''));
            }
            // คีย์ไม่ซ้ำแม้ icode เดียวกัน (วิธีใช้ต่างกัน)
            $mapped['row_key'] = ($mapped['icode'] ?: 'x') . '|' . $item_no . '|' . md5($mapped['method'] ?? '');
            $mapped['item_no'] = $item_no;
            $mapped['vn'] = trim((string)($r['vn'] ?? ''));
            $mapped['an'] = trim((string)($r['an'] ?? ''));
            $mapped['vstdate'] = trim((string)($r['vstdate'] ?? ''));
            $mapped['rxdate'] = $rxdate;
            $mapped['rxtime'] = trim((string)($r['rxtime'] ?? ''));
            $mapped['order_date'] = $rxdate;
            $mapped['order_date_th'] = wf_format_date_th($rxdate);
            $mapped['source_date'] = $rxdate;
            $rows[] = $mapped;
        }
    }

    $items = wf_filter_warfarin_rows($rows);
    $visit['vstdate_th'] = $date_th;
    $visit['label'] = $source_label;

    return ['items' => $items, 'visit' => $visit];
}

function wf_is_empty_offdate($offdate) {
    $d = trim((string)$offdate);
    if ($d === '' || $d === '0000-00-00' || $d === '0000-00-00 00:00:00') {
        return true;
    }
    return false;
}

/** หา AN ที่ยัง admit อยู่ (dchdate ว่าง/null) */
function wf_find_active_an($con_hosxp, $hn) {
    $hn_sql = function_exists('dr_hn_sql_in') ? dr_hn_sql_in($con_hosxp, $hn) : '';
    if ($hn_sql === '') {
        return '';
    }
    $sql = "
        SELECT an
        FROM ipt
        WHERE hn IN ($hn_sql)
          AND (dchdate IS NULL OR TRIM(dchdate) = '' OR dchdate = '0000-00-00')
        ORDER BY regdate DESC, an DESC
        LIMIT 1
    ";
    $q = @mysqli_query($con_hosxp, $sql);
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return trim((string)($r['an'] ?? ''));
    }
    return '';
}

/**
 * ผู้ป่วยใน (IPD): ดึงจาก medplan_ipd (Current Profile)
 * - มีรายการที่ยังไม่มีวันที่หยุด → ใช้รายการนั้น
 * - ถ้าหยุดครบทุกรายการ → ใช้กลุ่ม orderdate ล่าสุด
 */
function wf_fetch_ipd_medplan_warfarin($con_hosxp, $an) {
    $an = trim((string)$an);
    if ($an === '') {
        return ['items' => [], 'visit' => null];
    }

    $an_esc = mysqli_real_escape_string($con_hosxp, $an);
    $name_clause = wf_sql_warfarin_name_clause('d', 'tm');
    $tmt = hosxp_sql_tmt_drug_name('d', 'tm');
    $strength = hosxp_sql_tmt_strength('d', 'tm');
    $method = "CAST(CONVERT(
        IF(m.usage_line1 IS NOT NULL AND TRIM(m.usage_line1) <> '',
            CONCAT(IFNULL(m.usage_line1,''),' ',IFNULL(m.usage_line2,''),' ',IFNULL(m.usage_line3,''),' ',IFNULL(m.usage_line4,'')),
            IF(m.sp_use <> '' AND m.sp_use IS NOT NULL,
                CONCAT(IFNULL(sp.name1,''),' ',IFNULL(sp.name2,''),' ',IFNULL(sp.name3,'')),
                IF(m.shortlist IS NOT NULL AND TRIM(m.shortlist) <> '',
                    m.shortlist,
                    CONCAT(IFNULL(du.name1,''),' ',IFNULL(du.name2,''),' ',IFNULL(du.name3,''))
                )
            )
        )
    USING utf8) AS CHAR)";

    $sql = "
        SELECT
            m.med_plan_number,
            m.an,
            m.icode,
            m.qty,
            m.orderdate,
            m.offdate,
            m.off_time,
            m.orderstatus,
            m.drugusage,
            m.sp_use,
            m.last_update,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name_local,
            $tmt AS drug_name_tmt,
            CAST(CONVERT($strength USING utf8) AS CHAR) AS strength,
            CAST(CONVERT(d.units USING utf8) AS CHAR) AS units,
            $method AS method,
            DATE(m.orderdate) AS source_date
        FROM medplan_ipd m
        INNER JOIN drugitems d ON d.icode = m.icode
        " . hosxp_sql_tmt_join('d', 'tm') . "
        LEFT JOIN drugusage du ON du.drugusage = m.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = m.sp_use
        WHERE m.an = '$an_esc'
          AND $name_clause
        ORDER BY m.orderdate ASC, m.med_plan_number ASC
    ";

    $all = [];
    $q = @mysqli_query($con_hosxp, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $all[] = $r;
        }
    }
    if (empty($all)) {
        return ['items' => [], 'visit' => null];
    }

    $active = [];
    foreach ($all as $r) {
        if (wf_is_empty_offdate($r['offdate'] ?? '')) {
            $active[] = $r;
        }
    }

    $mode = 'active';
    if (!empty($active)) {
        $picked = $active;
    } else {
        $mode = 'latest_stopped';
        $latestOrder = '';
        foreach ($all as $r) {
            $od = trim((string)($r['orderdate'] ?? ''));
            if ($od > $latestOrder) {
                $latestOrder = $od;
            }
        }
        $picked = [];
        foreach ($all as $r) {
            if (trim((string)($r['orderdate'] ?? '')) === $latestOrder) {
                $picked[] = $r;
            }
        }
    }

    $orderDate = '';
    foreach ($picked as $r) {
        $od = trim((string)($r['source_date'] ?? $r['orderdate'] ?? ''));
        if ($od !== '' && ($orderDate === '' || $od > $orderDate)) {
            $orderDate = substr($od, 0, 10);
        }
    }
    $date_th = wf_format_date_th($orderDate);
    if ($mode === 'active') {
        $source_label = 'IPD Active' . ($date_th !== '' ? ' (' . $date_th . ')' : '');
    } else {
        $source_label = 'IPD ล่าสุด (หยุดแล้ว)' . ($date_th !== '' ? ' (' . $date_th . ')' : '');
    }

    $rows = [];
    foreach ($picked as $r) {
        $mapped = dr_map_drug_row($r, $source_label);
        $plan_no = trim((string)($r['med_plan_number'] ?? ''));
        $rxdate = substr(trim((string)($r['orderdate'] ?? '')), 0, 10);
        $off = trim((string)($r['offdate'] ?? ''));
        $off_date = wf_is_empty_offdate($off) ? '' : substr($off, 0, 10);

        $mapped['row_key'] = 'ipd|' . $plan_no . '|' . md5($mapped['method'] ?? '');
        $mapped['item_no'] = $plan_no;
        $mapped['vn'] = '';
        $mapped['an'] = $an;
        $mapped['vstdate'] = $rxdate;
        $mapped['rxdate'] = $rxdate;
        $mapped['rxtime'] = '';
        $mapped['order_date'] = $rxdate;
        $mapped['order_date_th'] = wf_format_date_th($rxdate);
        $mapped['source_date'] = $rxdate;
        $mapped['off_date'] = $off_date;
        $mapped['off_date_th'] = $off_date !== '' ? wf_format_date_th($off_date) : '';
        $rows[] = $mapped;
    }

    $items = wf_filter_warfarin_rows($rows);
    $visit = [
        'vn' => '',
        'an' => $an,
        'vstdate' => $orderDate,
        'vsttime' => '',
        'order_date' => $orderDate,
        'vstdate_th' => $date_th,
        'label' => $source_label,
        'source' => 'ipd_medplan',
        'mode' => $mode,
    ];

    return ['items' => $items, 'visit' => $visit];
}

function wf_lookup_patient_warfarin($con_hosxp, $hn_raw) {
    $hn = trim((string)$hn_raw);
    if ($hn === '') {
        return ['ok' => false, 'error' => 'กรุณากรอก HN'];
    }
    $ctx = dr_fetch_patient_context($con_hosxp, $hn);
    if (!$ctx || empty($ctx['hn'])) {
        return ['ok' => false, 'error' => 'ไม่พบ HN ในระบบ HOSxP'];
    }

    $active_an = trim((string)($ctx['an'] ?? ''));
    if ($active_an === '') {
        $active_an = wf_find_active_an($con_hosxp, $ctx['hn']);
    }
    $is_ipd = ($active_an !== '');

    if ($is_ipd) {
        $fetched = wf_fetch_ipd_medplan_warfarin($con_hosxp, $active_an);
        // ถ้าไม่มีใน medplan เลย ให้ fallback เป็น visit ล่าสุด
        if (empty($fetched['items'])) {
            $fetched = wf_fetch_latest_visit_warfarin($con_hosxp, $ctx['hn']);
        }
    } else {
        $fetched = wf_fetch_latest_visit_warfarin($con_hosxp, $ctx['hn']);
    }

    $merged = $fetched['items'] ?? [];
    $visit = $fetched['visit'] ?? null;

    $patient = [
        'hn' => $ctx['hn'],
        'an' => $active_an !== '' ? $active_an : (($visit['an'] ?? '') !== '' ? $visit['an'] : ''),
        'vn' => ($visit['vn'] ?? '') !== '' ? $visit['vn'] : ($ctx['vn'] ?? ''),
        'ptname' => $ctx['patient_name'] ?? '',
        'visit_type' => $is_ipd ? 'ipd' : 'opd',
        'visit_date' => $visit['vstdate'] ?? '',
        'visit_date_th' => $visit['vstdate_th'] ?? '',
    ];

    $total_mg_week = 0.0;
    $has_mg = false;
    $strengths = [];
    foreach ($merged as $r) {
        if ($r['mg_week'] !== null && $r['mg_week'] > 0) {
            $total_mg_week += (float)$r['mg_week'];
            $has_mg = true;
        }
        if (!empty($r['strength_mg']) && $r['strength_mg'] > 0) {
            $strengths[] = (float)$r['strength_mg'];
        }
    }
    $strengths = array_values(array_unique($strengths));
    sort($strengths);

    return [
        'ok' => true,
        'patient' => $patient,
        'visit' => $visit,
        'items' => $merged,
        'mg_week_total' => $has_mg ? round($total_mg_week, 2) : null,
        'tablet_strengths' => $strengths,
        'has_warfarin' => count($merged) > 0,
    ];
}

/**
 * แนะนำตาราง 7 วัน ให้ใกล้เคียง target mg/สัปดาห์
 * @param float $targetMgWeek
 * @param float|array $strengthMgOrList ความแรงเม็ด 1 ค่า หรือหลายค่า
 * @return array
 */
function wf_normalize_strengths($strengthMgOrList) {
    if (!is_array($strengthMgOrList)) {
        $strengthMgOrList = [$strengthMgOrList];
    }
    $out = [];
    foreach ($strengthMgOrList as $s) {
        $v = (float)$s;
        if ($v > 0) {
            $out[] = round($v, 4);
        }
    }
    $out = array_values(array_unique($out));
    sort($out);
    return $out;
}

/** สร้างตัวเลือก dose/วัน จากชุดความแรง (รองรับครึ่งเม็ด) */
function wf_daily_dose_options(array $strengths, $maxTabsEach = 2.0) {
    $strengths = wf_normalize_strengths($strengths);
    if (empty($strengths)) {
        return [];
    }
    $states = [[0.0, []]]; // [mg, pills[]]
    foreach ($strengths as $S) {
        $next = [];
        foreach ($states as $st) {
            for ($t = 0.0; $t <= $maxTabsEach + 1e-9; $t += 0.5) {
                $mg = round($st[0] + ($t * $S), 4);
                $pills = $st[1];
                if ($t > 1e-9) {
                    $pills[] = ['strength' => $S, 'tabs' => round($t, 2)];
                }
                $next[] = [$mg, $pills];
            }
        }
        $states = $next;
    }

    $best = [];
    foreach ($states as $st) {
        $mg = (float)$st[0];
        $key = number_format($mg, 4, '.', '');
        $complexity = 0.0;
        foreach ($st[1] as $p) {
            $complexity += (float)$p['tabs'];
        }
        $pillCount = count($st[1]);
        if (!isset($best[$key])
            || $complexity < $best[$key]['complexity'] - 1e-9
            || (abs($complexity - $best[$key]['complexity']) < 1e-9 && $pillCount < $best[$key]['pill_count'])
        ) {
            $best[$key] = [
                'mg' => $mg,
                'pills' => $st[1],
                'complexity' => $complexity,
                'pill_count' => $pillCount,
            ];
        }
    }

    $list = array_values($best);
    usort($list, function ($a, $b) {
        return $a['mg'] <=> $b['mg'];
    });
    return $list;
}

function wf_pills_label(array $pills) {
    if (empty($pills)) {
        return 'ไม่ทาน';
    }
    $parts = [];
    foreach ($pills as $p) {
        $s = $p['strength'];
        $parts[] = wf_tabs_label($p['tabs']) . ' (' . rtrim(rtrim(number_format((float)$s, 2, '.', ''), '0'), '.') . ' mg)';
    }
    return implode(' + ', $parts);
}

function wf_pills_signature(array $pills) {
    if (empty($pills)) {
        return '0';
    }
    $bits = [];
    foreach ($pills as $p) {
        $bits[] = number_format((float)$p['strength'], 2, '.', '') . 'x' . number_format((float)$p['tabs'], 2, '.', '');
    }
    return implode('+', $bits);
}

/**
 * สร้างตาราง 7 วันจากรายการยาปัจจุบัน (เพื่อให้คำแนะนำใกล้เคียงวิธีใช้เดิม)
 * @return array{days:array,total:float}|null
 */
function wf_week_schedule_from_items(array $items) {
    if (empty($items)) {
        return null;
    }
    $days = [];
    for ($i = 0; $i < 7; $i++) {
        $days[$i] = ['mg' => 0.0, 'pills' => []];
    }
    $any = false;
    foreach ($items as $it) {
        if (!is_array($it)) {
            continue;
        }
        $strength = isset($it['strength_mg']) ? (float)$it['strength_mg'] : 0.0;
        if (!($strength > 0)) {
            $strength = (float)(hosxp_parse_strength_mg($it['strength'] ?? '', $it['units'] ?? '') ?? 0);
        }
        if (!($strength > 0)) {
            continue;
        }
        $byDay = wf_tabs_per_weekday_from_method($it['method'] ?? '');
        $hasByDay = false;
        foreach ($byDay as $t) {
            if ((float)$t > 0) {
                $hasByDay = true;
                break;
            }
        }
        if ($hasByDay) {
            foreach ($byDay as $di => $t) {
                $t = (float)$t;
                if ($t <= 0) {
                    continue;
                }
                $di = (int)$di;
                $days[$di]['mg'] = round($days[$di]['mg'] + ($strength * $t), 4);
                $days[$di]['pills'][] = ['strength' => $strength, 'tabs' => round($t, 2)];
                $any = true;
            }
            continue;
        }
        $tabs = isset($it['daily_units']) ? (float)$it['daily_units'] : null;
        if ($tabs === null || $tabs <= 0) {
            $tabs = wf_parse_tabs_per_dose($it['method'] ?? '');
        }
        if ($tabs === null || $tabs <= 0) {
            $tabs = 1.0;
        }
        $dayIdx = wf_parse_day_indices_from_method($it['method'] ?? '');
        if ($dayIdx === null) {
            $dayIdx = [0, 1, 2, 3, 4, 5, 6];
        }
        foreach ($dayIdx as $di) {
            $di = (int)$di;
            if ($di < 0 || $di > 6) {
                continue;
            }
            $days[$di]['mg'] = round($days[$di]['mg'] + ($strength * $tabs), 4);
            $days[$di]['pills'][] = ['strength' => $strength, 'tabs' => round($tabs, 2)];
            $any = true;
        }
    }
    if (!$any) {
        return null;
    }
    // รวมเม็ดความแรงเดียวกันต่อวัน
    for ($i = 0; $i < 7; $i++) {
        $merged = [];
        foreach ($days[$i]['pills'] as $p) {
            $k = number_format((float)$p['strength'], 2, '.', '');
            if (!isset($merged[$k])) {
                $merged[$k] = ['strength' => (float)$p['strength'], 'tabs' => 0.0];
            }
            $merged[$k]['tabs'] += (float)$p['tabs'];
        }
        $pills = array_values($merged);
        usort($pills, function ($a, $b) {
            return $b['strength'] <=> $a['strength'];
        });
        $days[$i]['pills'] = $pills;
        $days[$i]['mg'] = round((float)$days[$i]['mg'], 2);
        $days[$i]['sig'] = wf_pills_signature($pills);
    }
    $total = 0.0;
    foreach ($days as $d) {
        $total += (float)$d['mg'];
    }
    return ['days' => $days, 'total' => round($total, 2)];
}

/** หา option ที่ใกล้เคียง mg/ลายเซ็นเม็ดของวันนั้นที่สุด */
function wf_find_nearest_day_option(array $options, $mg, $sig = '') {
    $best = null;
    $bestScore = PHP_FLOAT_MAX;
    foreach ($options as $i => $opt) {
        $dmg = abs((float)$opt['mg'] - (float)$mg);
        $sigPen = ($sig !== '' && wf_pills_signature($opt['pills']) !== $sig) ? 0.25 : 0.0;
        $cplx = (float)($opt['complexity'] ?? 0);
        $score = $dmg * 10 + $sigPen + $cplx * 0.01;
        if ($score < $bestScore - 1e-9) {
            $bestScore = $score;
            $best = $i;
        }
    }
    return $best !== null ? $best : 0;
}

/**
 * ลำดับวันที่นิยมปรับขนาดเมื่อกินเท่ากันทุกวันแล้วเพิ่ม/ลด 1 วัน
 * นิยม: อาทิตย์ → เสาร์ → ศุกร์ ... → จันทร์
 * @return int[] index 0=จันทร์ .. 6=อาทิตย์
 */
function wf_preferred_adjust_day_order() {
    return [6, 5, 4, 3, 2, 1, 0];
}

/** คะแนนความนิยมของวันที่ถูกเปลี่ยน (ต่ำกว่า = ดีกว่า) */
function wf_changed_days_pref_score(array $weekIdx, array $baseIdx) {
    $rank = [6 => 0, 5 => 1, 4 => 2, 3 => 3, 2 => 4, 1 => 5, 0 => 6];
    $sum = 0.0;
    $n = 0;
    for ($d = 0; $d < 7; $d++) {
        if ((int)$weekIdx[$d] !== (int)$baseIdx[$d]) {
            $sum += (float)($rank[$d] ?? 9);
            $n++;
        }
    }
    return $n > 0 ? ($sum / $n) : 99.0;
}

/**
 * แนะนำตารางโดยยึดวิธีใช้เดิมเป็นหลัก — เปลี่ยนน้อยวันที่สุด
 */
function wf_recommend_near_baseline($target, array $options, array $baselineDays) {
    $nOpt = count($options);
    if ($nOpt === 0) {
        return null;
    }
    $baseIdx = [];
    for ($d = 0; $d < 7; $d++) {
        $bm = (float)($baselineDays[$d]['mg'] ?? 0);
        $bs = (string)($baselineDays[$d]['sig'] ?? '');
        $baseIdx[$d] = wf_find_nearest_day_option($options, $bm, $bs);
    }

    $best = null;
    $consider = function (array $weekIdx) use ($options, $target, $baseIdx, $baselineDays, &$best) {
        $sum = 0.0;
        $changed = 0;
        $mgShift = 0.0;
        $cplx = 0.0;
        $baseCplx = 0.0;
        for ($d = 0; $d < 7; $d++) {
            $opt = $options[$weekIdx[$d]];
            $sum += (float)$opt['mg'];
            $cplx += (float)($opt['complexity'] ?? 0) + 0.5 * (float)($opt['pill_count'] ?? 0);
            $baseOpt = $options[$baseIdx[$d]];
            $baseCplx += (float)($baseOpt['complexity'] ?? 0) + 0.5 * (float)($baseOpt['pill_count'] ?? 0);
            if ($weekIdx[$d] !== $baseIdx[$d]) {
                $changed++;
                $mgShift += abs((float)$opt['mg'] - (float)($baselineDays[$d]['mg'] ?? 0));
            }
        }
        $diff = abs($sum - $target);
        // ใกล้เป้า ≤1 mg หรือ ≤4% ของเป้า → จัดเป็นกลุ่ม "ดีพอ" ให้ยึด pattern เดิมก่อน
        $closeEnough = ($diff <= max(1.0, abs($target) * 0.04));
        $tier = $closeEnough ? 0 : 1;
        $cplxDelta = max(0.0, $cplx - $baseCplx);
        $candidate = [
            'week' => $weekIdx,
            'sum' => $sum,
            'diff' => $diff,
            'changed' => $changed,
            'day_pref' => wf_changed_days_pref_score($weekIdx, $baseIdx),
            'mg_shift' => $mgShift,
            'cplx_delta' => $cplxDelta,
            'tier' => $tier,
        ];
        if ($best === null) {
            $best = $candidate;
            return;
        }
        // เปรียบเทียบแบบ lexicographic (day_pref: นิยมอาทิตย์/เสาร์เมื่อคะแนนอื่นเท่ากัน)
        $keys = ['tier', 'changed', 'diff', 'day_pref', 'mg_shift', 'cplx_delta'];
        foreach ($keys as $k) {
            if ($candidate[$k] + 1e-9 < $best[$k]) {
                $best = $candidate;
                return;
            }
            if ($candidate[$k] > $best[$k] + 1e-9) {
                return;
            }
        }
    };

    // 0) คงตารางเดิม
    $consider($baseIdx);

    // 1) เปลี่ยน 1 วัน — ไล่จากอาทิตย์ → เสาร์ ก่อน
    $dayOrder = wf_preferred_adjust_day_order();
    foreach ($dayOrder as $d) {
        for ($oi = 0; $oi < $nOpt; $oi++) {
            if ($oi === $baseIdx[$d]) {
                continue;
            }
            $week = $baseIdx;
            $week[$d] = $oi;
            $consider($week);
        }
    }

    // 2) เปลี่ยน 2 วัน (ถ้ายังห่างเป้า)
    if ($best === null || $best['diff'] > max(0.75, abs($target) * 0.03)) {
        // จำกัด: วันที่มี mg ต่างจากโหมดเดิม หรือ Sunday/Saturday ก่อน
        $mgCounts = [];
        foreach ($baselineDays as $bd) {
            $k = number_format((float)$bd['mg'], 2, '.', '');
            $mgCounts[$k] = ($mgCounts[$k] ?? 0) + 1;
        }
        arsort($mgCounts);
        $modeMg = (float)array_key_first($mgCounts);
        $priorityDays = [];
        foreach (wf_preferred_adjust_day_order() as $d) {
            if (abs((float)$baselineDays[$d]['mg'] - $modeMg) > 0.05) {
                $priorityDays[] = $d;
            }
        }
        foreach (wf_preferred_adjust_day_order() as $d) {
            if (!in_array($d, $priorityDays, true)) {
                $priorityDays[] = $d;
            }
        }
        $priorityDays = array_values(array_unique($priorityDays));
        $focus = array_slice($priorityDays, 0, 4);
        $nFocus = count($focus);
        for ($a = 0; $a < $nFocus; $a++) {
            for ($b = $a + 1; $b < $nFocus; $b++) {
                $d1 = $focus[$a];
                $d2 = $focus[$b];
                for ($o1 = 0; $o1 < $nOpt; $o1++) {
                    for ($o2 = 0; $o2 < $nOpt; $o2++) {
                        if ($o1 === $baseIdx[$d1] && $o2 === $baseIdx[$d2]) {
                            continue;
                        }
                        $week = $baseIdx;
                        $week[$d1] = $o1;
                        $week[$d2] = $o2;
                        $consider($week);
                    }
                }
            }
        }
    }

    return $best;
}

function wf_schedule_from_day_options(array $dayOpts, array $strengths, $target) {
    $dayNames = wf_day_names();
    $schedule = [];
    $sum = 0.0;
    foreach ($dayOpts as $i => $opt) {
        $pills = $opt['pills'];
        $mg = (float)$opt['mg'];
        $tabsTotal = 0.0;
        foreach ($pills as $p) {
            $tabsTotal += (float)$p['tabs'];
        }
        $schedule[] = [
            'day' => $dayNames[$i],
            'mg' => round($mg, 2),
            'tabs' => round($tabsTotal, 2),
            'pills' => $pills,
            'pills_label' => wf_pills_label($pills),
        ];
        $sum += $mg;
    }
    return [
        'ok' => true,
        'target_mg_week' => round($target, 2),
        'actual_mg_week' => round($sum, 2),
        'diff_mg' => round($sum - $target, 2),
        'strength_mg' => count($strengths) === 1 ? $strengths[0] : null,
        'strengths' => $strengths,
        'schedule' => $schedule,
        'method_text' => wf_format_method_text($schedule, $strengths),
    ];
}

/**
 * แนะนำตาราง 7 วัน ให้ใกล้เคียง target mg/สัปดาห์
 * ถ้ามี baseline items จะพยายามคงวิธีใช้เดิมให้มากที่สุด
 * @param float $targetMgWeek
 * @param float|array $strengthMgOrList
 * @param array|null $baselineItems รายการยาปัจจุบันจาก lookup
 */
function wf_recommend_schedule($targetMgWeek, $strengthMgOrList, $baselineItems = null) {
    $target = (float)$targetMgWeek;
    $strengths = wf_normalize_strengths($strengthMgOrList);
    if (!($target > 0) || empty($strengths)) {
        return ['ok' => false, 'error' => 'ต้องระบุ mg/สัปดาห์ และเลือกความแรงเม็ดอย่างน้อย 1 ค่า'];
    }

    $options = wf_daily_dose_options($strengths, count($strengths) >= 2 ? 2.0 : 4.0);
    if (empty($options)) {
        return ['ok' => false, 'error' => 'สร้างตัวเลือกขนาดยาไม่สำเร็จ'];
    }

    // --- แนวทางหลัก: ใกล้เคียงวิธีใช้เดิม ---
    if (is_array($baselineItems) && !empty($baselineItems)) {
        $base = wf_week_schedule_from_items($baselineItems);
        if ($base && !empty($base['days'])) {
            $near = wf_recommend_near_baseline($target, $options, $base['days']);
            if ($near && !empty($near['week'])) {
                $dayOpts = [];
                foreach ($near['week'] as $oi) {
                    $dayOpts[] = $options[$oi];
                }
                $rec = wf_schedule_from_day_options($dayOpts, $strengths, $target);
                $rec['pattern_mode'] = 'near_baseline';
                $rec['days_changed'] = (int)$near['changed'];
                return $rec;
            }
        }
    }

    // --- fallback: high/low แบบเดิม ---
    $avg = $target / 7.0;
    $lowIdx = 0;
    foreach ($options as $i => $opt) {
        if ($opt['mg'] <= $avg + 1e-9) {
            $lowIdx = $i;
        }
    }

    $best = null;
    $bestDiff = PHP_FLOAT_MAX;
    // วาง high-dose วัน: อาทิตย์ → เสาร์ ก่อน
    $prefer = wf_preferred_adjust_day_order();

    $tryPair = function ($li, $hi) use ($options, $target, &$best, &$bestDiff) {
        $L = $options[$li]['mg'];
        $H = $options[$hi]['mg'];
        if (abs($H - $L) < 1e-9) {
            $sum = 7 * $L;
            $diff = abs($sum - $target);
            if ($diff < $bestDiff - 1e-9) {
                $bestDiff = $diff;
                $best = ['n_high' => 0, 'low_idx' => $li, 'high_idx' => $li, 'sum' => $sum];
            }
            return;
        }
        $nGuess = (int)round(($target - 7 * $L) / ($H - $L));
        for ($n = 0; $n <= 7; $n++) {
            $sum = $n * $H + (7 - $n) * $L;
            $diff = abs($sum - $target);
            if ($diff < $bestDiff - 1e-9) {
                $bestDiff = $diff;
                $best = ['n_high' => $n, 'low_idx' => $li, 'high_idx' => $hi, 'sum' => $sum];
            }
        }
    };

    for ($li = max(0, $lowIdx - 2); $li <= min(count($options) - 1, $lowIdx + 2); $li++) {
        for ($hi = $li; $hi <= min(count($options) - 1, $li + 3); $hi++) {
            $tryPair($li, $hi);
        }
    }
    if ($best === null) {
        $nearest = 0;
        $nd = PHP_FLOAT_MAX;
        foreach ($options as $i => $opt) {
            $d = abs(7 * $opt['mg'] - $target);
            if ($d < $nd) {
                $nd = $d;
                $nearest = $i;
            }
        }
        $best = ['n_high' => 0, 'low_idx' => $nearest, 'high_idx' => $nearest, 'sum' => 7 * $options[$nearest]['mg']];
    }

    $dayOpts = array_fill(0, 7, $options[$best['low_idx']]);
    $placed = 0;
    foreach ($prefer as $di) {
        if ($placed >= $best['n_high']) {
            break;
        }
        $dayOpts[$di] = $options[$best['high_idx']];
        $placed++;
    }

    $rec = wf_schedule_from_day_options($dayOpts, $strengths, $target);
    $rec['pattern_mode'] = 'balanced';
    return $rec;
}

function wf_tabs_label($tabs) {
    $tabs = round((float)$tabs, 2);
    if (abs($tabs) < 1e-9) {
        return 'ไม่ทาน';
    }
    if (abs($tabs - 0.5) < 1e-9) {
        return '½ เม็ด';
    }
    if (abs($tabs - 1.5) < 1e-9) {
        return '1½ เม็ด';
    }
    if (abs($tabs - floor($tabs) - 0.5) < 1e-9) {
        return ((int)floor($tabs)) . '½ เม็ด';
    }
    if (abs($tabs - (int)$tabs) < 1e-9) {
        return ((int)$tabs) . ' เม็ด';
    }
    return rtrim(rtrim(number_format($tabs, 2, '.', ''), '0'), '.') . ' เม็ด';
}

function wf_format_method_text(array $schedule, $strengthMgOrList) {
    $strengths = wf_normalize_strengths($strengthMgOrList);
    $strengthLabel = empty($strengths)
        ? ''
        : implode('+', array_map(function ($s) {
            return rtrim(rtrim(number_format((float)$s, 2, '.', ''), '0'), '.');
        }, $strengths)) . ' mg';

    $groups = [];
    foreach ($schedule as $row) {
        $pills = $row['pills'] ?? [];
        if (empty($pills) && isset($row['tabs']) && isset($strengths[0])) {
            // legacy single-strength rows
            $tabs = (float)$row['tabs'];
            if ($tabs > 0) {
                $pills = [['strength' => $strengths[0], 'tabs' => $tabs]];
            }
        }
        $key = wf_pills_signature($pills);
        if (!isset($groups[$key])) {
            $groups[$key] = [
                'pills' => $pills,
                'label' => wf_pills_label($pills),
                'days' => [],
                'tabs_sum' => 0.0,
            ];
        }
        $groups[$key]['days'][] = $row['day'];
        foreach ($pills as $p) {
            $groups[$key]['tabs_sum'] += (float)$p['tabs'];
        }
    }
    uasort($groups, function ($a, $b) {
        return $b['tabs_sum'] <=> $a['tabs_sum'];
    });

    $parts = [];
    foreach ($groups as $g) {
        if (empty($g['pills'])) {
            continue;
        }
        $parts[] = $g['label'] . ' ก่อนนอน วัน' . implode(' ', $g['days']);
    }
    if (empty($parts)) {
        return 'ไม่ทาน Warfarin';
    }
    $prefix = 'รับประทาน Warfarin';
    if ($strengthLabel !== '') {
        $prefix .= ' ' . $strengthLabel;
    }
    return $prefix . ' — ' . implode(' และ ', $parts);
}

/** รหัส Lab INR จากตั้งค่าระบบ (h_code_inr) */
function wf_get_inr_lab_code($con) {
    $q = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = 'h_code_inr' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return trim((string)($r['config_value'] ?? ''));
    }
    return '';
}

/** ผล INR ใช้ประเมินได้ไม่เกินกี่เดือน (ตั้งค่าระบบ) — ค่าเริ่มต้น 6 */
function wf_inr_max_age_months($con) {
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = 'h_inr_max_age_months' LIMIT 1");
    $v = 6;
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        if (trim((string)($r['config_value'] ?? '')) !== '') {
            $v = (int)$r['config_value'];
        }
    }
    return max(1, min(60, $v));
}

function wf_inr_save_max_age_months($con, $months) {
    $months = max(1, min(60, (int)$months));
    $esc = mysqli_real_escape_string($con, (string)$months);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='h_inr_max_age_months' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$esc' WHERE config_name='h_inr_max_age_months'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('h_inr_max_age_months', '$esc')");
}

function wf_ymd_normalize($ymd) {
    $ymd = trim((string)$ymd);
    if ($ymd === '' || $ymd === '0000-00-00') {
        return '';
    }
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $ymd, $m)) {
        $y = (int)$m[1];
        if ($y >= 2400) {
            $y -= 543;
        }
        return sprintf('%04d-%s-%s', $y, $m[2], $m[3]);
    }
    $ts = strtotime($ymd);
    return $ts ? date('Y-m-d', $ts) : '';
}

/** แปลงเวลา HOSxP เป็น H:i:s */
function wf_normalize_time($t) {
    $t = trim((string)$t);
    if ($t === '') {
        return '';
    }
    if (preg_match('/^(\d{1,2}):(\d{2})(?::(\d{2}))?/', $t, $m)) {
        return sprintf('%02d:%02d:%02d', (int)$m[1], (int)$m[2], isset($m[3]) ? (int)$m[3] : 0);
    }
    $digits = preg_replace('/\D+/', '', $t);
    if (strlen($digits) >= 4) {
        $h = (int)substr($digits, 0, 2);
        $i = (int)substr($digits, 2, 2);
        $s = strlen($digits) >= 6 ? (int)substr($digits, 4, 2) : 0;
        if ($h <= 23 && $i <= 59 && $s <= 59) {
            return sprintf('%02d:%02d:%02d', $h, $i, $s);
        }
    }
    return '';
}

function wf_format_time_hm($t) {
    $n = wf_normalize_time($t);
    return $n !== '' ? substr($n, 0, 5) : '';
}

/** ผล Lab เก่ากว่า $months เดือนเมื่อเทียบกับวันที่อ้างอิงหรือไม่ (นานกว่า N เดือน = true) */
function wf_inr_is_older_than_months($labYmd, $refYmd, $months) {
    $labYmd = wf_ymd_normalize($labYmd);
    $refYmd = wf_ymd_normalize($refYmd);
    $months = max(1, min(60, (int)$months));
    if ($labYmd === '' || $refYmd === '') {
        return false;
    }
    try {
        $lab = new DateTime($labYmd);
        $ref = new DateTime($refYmd);
    } catch (Exception $e) {
        return false;
    }
    if ($lab > $ref) {
        return false;
    }
    $cutoff = clone $ref;
    $cutoff->modify('-' . $months . ' months');
    return $lab < $cutoff;
}

function wf_assess_mark_unevaluable(array $assess, $detail) {
    if (($assess['verdict'] ?? '') === 'baseline' && trim((string)$detail) === '') {
        return $assess;
    }
    $pct = $assess['pct'] ?? null;
    $pctText = ($pct !== null) ? (($pct > 0 ? '+' : '') . $pct . '%') : '';
    $assess['verdict'] = 'unknown';
    $assess['label'] = 'ประเมินไม่ได้';
    $assess['badge'] = 'secondary';
    $assess['detail'] = trim(($pctText !== '' ? 'ปรับ ' . $pctText . ' — ' : '') . $detail);
    return $assess;
}

function wf_parse_lab_numeric($raw) {
    $s = trim((string)$raw);
    if ($s === '') {
        return null;
    }
    $s = str_replace([',', ' '], ['', ''], $s);
    if (preg_match('/[-+]?\d+(?:\.\d+)?/', $s, $m)) {
        return (float)$m[0];
    }
    return null;
}

/**
 * ดึง INR ล่าสุด + ประวัติย้อนหลังจาก HOSxP ตามรหัสที่ตั้งในระบบ
 * @return array{configured:bool,lab_code:string,latest:?array,history:array,message?:string}
 */
function wf_fetch_inr($con, $hos, $hn, $months = 36, $limit = 48) {
    $code = wf_get_inr_lab_code($con);
    if ($code === '') {
        return [
            'configured' => false,
            'lab_code' => '',
            'latest' => null,
            'history' => [],
            'message' => 'ยังไม่ได้ตั้งค่า Lab Code: INR ในตั้งค่าระบบ',
        ];
    }

    $hn_in = monitor_lab_hn_sql_in($hos, $hn);
    $code_esc = mysqli_real_escape_string($hos, $code);
    $months = max(1, min(120, (int)$months));
    $limit = max(1, min(120, (int)$limit));

    $sql = "SELECT lo.lab_order_result, lh.order_date, lh.order_time, lh.lab_order_number
            FROM lab_head lh
            INNER JOIN lab_order lo ON lh.lab_order_number = lo.lab_order_number
            WHERE lh.hn IN ($hn_in)
              AND lo.lab_items_code = '$code_esc'
              AND lo.lab_order_result IS NOT NULL
              AND TRIM(lo.lab_order_result) != ''
              AND lh.order_date >= DATE_SUB(CURDATE(), INTERVAL $months MONTH)
            ORDER BY lh.order_date DESC, lh.order_time DESC, lh.lab_order_number DESC
            LIMIT $limit";

    $history = [];
    $q = mysqli_query($hos, $sql);
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $raw = trim((string)($row['lab_order_result'] ?? ''));
            $num = wf_parse_lab_numeric($raw);
            $od = wf_ymd_normalize($row['order_date'] ?? '');
            if ($od === '') {
                continue;
            }
            $ot = trim((string)($row['order_time'] ?? ''));
            $date_th = wf_format_date_th($od);
            $history[] = [
                'raw' => $raw,
                'value' => $num,
                'order_date' => $od,
                'order_time' => $ot,
                'date_th' => $date_th,
                'label' => $date_th,
            ];
        }
    }

    $latest = count($history) > 0 ? $history[0] : null;

    return [
        'configured' => true,
        'lab_code' => $code,
        'latest' => $latest,
        'history' => $history,
        'message' => $latest ? null : 'ไม่พบผล INR ในช่วง ' . $months . ' เดือน',
    ];
}

/**
 * หา INR ของวันเดียวกับวันที่กำหนดเท่านั้น (ใช้ประเมินความเหมาะสม)
 * @param array $inrHistory จาก wf_fetch_inr (ใหม่→เก่า)
 * @return array{value:?float,raw:string,order_date:string,date_th:string,days_diff:?int,same_day:bool}|null
 */
function wf_find_inr_same_day(array $inrHistory, $dateYmd) {
    $dateYmd = wf_ymd_normalize($dateYmd);
    if ($dateYmd === '' || empty($inrHistory)) {
        return null;
    }
    $targetTs = strtotime($dateYmd);
    if (!$targetTs) {
        return null;
    }
    $best = null;
    foreach ($inrHistory as $row) {
        $od = wf_ymd_normalize($row['order_date'] ?? '');
        if ($od === '') {
            continue;
        }
        $ts = strtotime($od);
        if (!$ts) {
            continue;
        }
        $diff = (int)round(($targetTs - $ts) / 86400);
        if ($diff !== 0) {
            continue;
        }
        $best = [
            'value' => isset($row['value']) && $row['value'] !== null ? (float)$row['value'] : null,
            'raw' => (string)($row['raw'] ?? ''),
            'order_date' => $od,
            'date_th' => (string)($row['date_th'] ?? wf_format_date_th($od)),
            'days_diff' => 0,
            'same_day' => true,
        ];
        break; // history เรียงใหม่→เก่า — เอาตัวแรกของวันนั้น
    }
    return $best;
}

/**
 * หา INR ล่าสุดในวันสั่งยา หรือผลก่อนหน้า (สำหรับแสดงในตาราง)
 * @return array{value:?float,raw:string,order_date:string,date_th:string,days_diff:?int,same_day:bool}|null
 */
function wf_find_inr_on_or_before(array $inrHistory, $dateYmd) {
    $dateYmd = wf_ymd_normalize($dateYmd);
    if ($dateYmd === '' || empty($inrHistory)) {
        return null;
    }
    $targetTs = strtotime($dateYmd);
    if (!$targetTs) {
        return null;
    }
    $best = null;
    $bestDiff = null;
    foreach ($inrHistory as $row) {
        $od = wf_ymd_normalize($row['order_date'] ?? '');
        if ($od === '' || $od === '0000-00-00') {
            continue;
        }
        $ts = strtotime($od);
        if (!$ts) {
            continue;
        }
        $diff = (int)round(($targetTs - $ts) / 86400); // >=0 = วันเดียวกันหรือก่อนหน้า
        if ($diff < 0) {
            continue;
        }
        if ($bestDiff === null || $diff < $bestDiff) {
            $bestDiff = $diff;
            $best = [
                'value' => isset($row['value']) && $row['value'] !== null ? (float)$row['value'] : null,
                'raw' => (string)($row['raw'] ?? ''),
                'order_date' => $od,
                'date_th' => (string)($row['date_th'] ?? wf_format_date_th($od)),
                'days_diff' => $diff,
                'same_day' => ($diff === 0),
            ];
        }
    }
    return $best;
}

/**
 * หา INR สำหรับประเมิน: วันสั่งยา หรือผลก่อนหน้าไม่เกิน $maxDays วัน
 * @return array{value:?float,raw:string,order_date:string,date_th:string,days_diff:?int,same_day:bool,usable:bool}|null
 */
function wf_find_inr_for_assess(array $inrHistory, $dateYmd, $maxDays = 5) {
    $found = wf_find_inr_on_or_before($inrHistory, $dateYmd);
    if (!$found) {
        return null;
    }
    $maxDays = max(0, (int)$maxDays);
    $diff = (int)($found['days_diff'] ?? 0);
    if ($diff > $maxDays) {
        return null; // เก่าเกินกว่าอนุโลม — ไม่ใช้ประเมิน
    }
    $found['usable'] = true;
    $found['same_day'] = ($diff === 0);
    return $found;
}

/** @deprecated ใช้ wf_find_inr_same_day / wf_find_inr_on_or_before / wf_find_inr_for_assess */
function wf_find_inr_near(array $inrHistory, $dateYmd, $maxDays = 0) {
    if ((int)$maxDays === 0) {
        return wf_find_inr_same_day($inrHistory, $dateYmd);
    }
    return wf_find_inr_for_assess($inrHistory, $dateYmd, (int)$maxDays);
}

/** INR ถัดไปหลังวันที่กำหนด */
function wf_find_inr_after(array $inrHistory, $dateYmd, $minDays = 3, $maxDays = 90) {
    $dateYmd = wf_ymd_normalize($dateYmd);
    if ($dateYmd === '' || empty($inrHistory)) {
        return null;
    }
    $targetTs = strtotime($dateYmd);
    if (!$targetTs) {
        return null;
    }
    $best = null;
    $bestDiff = null;
    foreach ($inrHistory as $row) {
        $od = wf_ymd_normalize($row['order_date'] ?? '');
        if ($od === '') {
            continue;
        }
        $ts = strtotime($od);
        if (!$ts) {
            continue;
        }
        $diff = (int)round(($ts - $targetTs) / 86400);
        if ($diff < $minDays || $diff > $maxDays) {
            continue;
        }
        if ($bestDiff === null || $diff < $bestDiff) {
            $bestDiff = $diff;
            $best = [
                'value' => isset($row['value']) && $row['value'] !== null ? (float)$row['value'] : null,
                'raw' => (string)($row['raw'] ?? ''),
                'order_date' => $od,
                'date_th' => (string)($row['date_th'] ?? wf_format_date_th($od)),
                'days_diff' => $diff,
            ];
        }
    }
    return $best;
}

/**
 * ประเมินว่าการปรับ dose เหมาะสมตาม guideline หรือไม่
 * @return array{pct:?float,verdict:string,label:string,detail:string,badge:string}
 */
function wf_assess_dose_change($con, $prevMg, $currMg, $inrValue, $protocolId, $nextInr = null) {
    $prevMg = ($prevMg !== null && is_numeric($prevMg)) ? (float)$prevMg : null;
    $currMg = ($currMg !== null && is_numeric($currMg)) ? (float)$currMg : null;

    $pct = null;
    if ($prevMg !== null && $prevMg > 0 && $currMg !== null) {
        $pct = round((($currMg - $prevMg) / $prevMg) * 100, 1);
    }

    if ($pct === null) {
        return [
            'pct' => null,
            'verdict' => 'baseline',
            'label' => 'เริ่มต้น',
            'detail' => 'ไม่มี dose ก่อนหน้าเปรียบเทียบ',
            'badge' => 'secondary',
        ];
    }

    $pctText = ($pct > 0 ? '+' : '') . $pct . '%';

    if ($inrValue === null || !is_numeric($inrValue)) {
        return [
            'pct' => $pct,
            'verdict' => 'unknown',
            'label' => 'ประเมินไม่ได้(ไม่มี INR)',
            'detail' => 'ปรับ ' . $pctText . ' — ไม่มีผล INR ในวันสั่งยา',
            'badge' => 'secondary',
        ];
    }

    $match = wf_guideline_match($con, (float)$inrValue, $protocolId);
    if (empty($match['ok'])) {
        return [
            'pct' => $pct,
            'verdict' => 'unknown',
            'label' => 'ประเมินไม่ได้',
            'detail' => 'ปรับ ' . $pctText . ' — ' . ($match['error'] ?? 'ไม่มี guideline'),
            'badge' => 'secondary',
        ];
    }

    $suggest = $match['suggest'];
    $dir = $suggest['direction'];
    $pMin = (float)$suggest['pct_min'];
    $pMax = (float)$suggest['pct_max'];
    $guideText = $suggest['pct_text'];
    $absPct = abs($pct);
    $tol = 3.0; // ความคลาดเคลื่อนที่ยอมรับได้ (%)

    $verdict = 'mismatch';
    $label = 'ไม่สอดคล้อง';
    $badge = 'danger';

    if ($dir === 'hold') {
        if ($absPct <= $tol) {
            $verdict = 'ok';
            $label = 'เหมาะสม';
            $badge = 'success';
        } elseif ($absPct <= 8) {
            $verdict = 'partial';
            $label = 'ค่อนข้างเหมาะสม';
            $badge = 'warning';
        }
    } elseif ($dir === 'up') {
        // ต้องเพิ่มขนาด — ถ้าคงเดิมหรือลด = ไม่สอดคล้อง
        if ($pct > $tol) {
            if ($absPct >= max(0, $pMin - $tol) && $absPct <= ($pMax + $tol + 2)) {
                $verdict = 'ok';
                $label = 'เหมาะสม';
                $badge = 'success';
            } else {
                // ทิศถูกแต่ % นอกช่วง guideline
                $verdict = 'partial';
                $label = 'ค่อนข้างเหมาะสม';
                $badge = 'warning';
            }
        }
    } elseif ($dir === 'down') {
        // ต้องลดขนาด — ถ้าคงเดิมหรือเพิ่ม = ไม่สอดคล้อง
        if ($pct < -$tol) {
            if ($absPct >= max(0, $pMin - $tol) && $absPct <= ($pMax + $tol + 2)) {
                $verdict = 'ok';
                $label = 'เหมาะสม';
                $badge = 'success';
            } else {
                $verdict = 'partial';
                $label = 'ค่อนข้างเหมาะสม';
                $badge = 'warning';
            }
        }
    }

    $detail = 'ปรับจริง ' . $pctText . ' · Guideline: ' . $guideText . ' (INR ' . round((float)$inrValue, 2) . ')';

    // ผลลัพธ์ INR ถัดไป (เสริม)
    if (is_array($nextInr) && isset($nextInr['value']) && $nextInr['value'] !== null) {
        $nv = (float)$nextInr['value'];
        $tLow = (float)($match['protocol']['target_low'] ?? 2);
        $tHigh = (float)($match['protocol']['target_high'] ?? 3);
        $outcome = '';
        if ($nv >= $tLow && $nv <= $tHigh) {
            $outcome = 'INR ถัดไปเข้าเป้า (' . round($nv, 2) . ')';
            if ($verdict === 'partial') {
                $verdict = 'ok';
                $label = 'เหมาะสม';
                $badge = 'success';
            }
        } elseif ($nv < $tLow) {
            $outcome = 'INR ถัดไปยังต่ำ (' . round($nv, 2) . ')';
        } else {
            $outcome = 'INR ถัดไปยังสูง (' . round($nv, 2) . ')';
        }
        if ($outcome !== '') {
            $detail .= ' · ' . $outcome;
        }
    }

    return [
        'pct' => $pct,
        'verdict' => $verdict,
        'label' => $label,
        'detail' => $detail,
        'badge' => $badge,
        'guide_text' => $guideText,
        'guide_direction' => $dir,
    ];
}

/**
 * ดึง episode Warfarin ตาม visit/วัน จาก opitemrece แล้วยุบช่วง dose เท่ากันติดกัน
 * @return array<int,array{date:string,date_th:string,mg_week:?float,source:string,vn:string,an:string,methods:string,item_count:int}>
 */
function wf_fetch_warfarin_dose_episodes($hos, $hn, $months = 24) {
    $hn_sql = function_exists('dr_hn_sql_in') ? dr_hn_sql_in($hos, $hn) : '';
    if ($hn_sql === '') {
        return [];
    }
    $months = max(1, min(60, (int)$months));
    $joins = dr_sql_drug_joins();
    $name_clause = wf_sql_warfarin_name_clause('d', 'tm');
    $method = di_sql_method_expr('o', 'du', 'sp', 'od');
    $tmt = hosxp_sql_tmt_drug_name('d', 'tm');
    $strength = hosxp_sql_tmt_strength('d', 'tm');

    $icode_in = function_exists('wf_sql_warfarin_icode_in') ? wf_sql_warfarin_icode_in($hos, 'o') : '';
    $drug_filter = $icode_in !== '' ? $icode_in : $name_clause;

    $sql = "
        SELECT
            o.icode,
            o.item_no,
            o.qty,
            o.vn,
            o.an,
            o.vstdate,
            o.vsttime,
            o.rxdate,
            o.rxtime,
            o.order_no,
            o.item_type,
            ion.order_type,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name_local,
            $tmt AS drug_name_tmt,
            CAST(CONVERT($strength USING utf8) AS CHAR) AS strength,
            CAST(CONVERT(d.units USING utf8) AS CHAR) AS units,
            $method AS method,
            COALESCE(NULLIF(o.rxdate, '0000-00-00'), o.vstdate) AS source_date
        FROM opitemrece o
        $joins
        LEFT JOIN ipt_order_no ion ON ion.order_no = o.order_no
        WHERE o.hn IN ($hn_sql)
          AND $drug_filter
          AND o.vstdate IS NOT NULL
          AND o.vstdate <> '0000-00-00'
          AND o.vstdate >= DATE_SUB(CURDATE(), INTERVAL $months MONTH)
        ORDER BY o.vstdate ASC, o.vsttime ASC, o.rxdate ASC, o.rxtime ASC, o.item_no ASC
    ";

    $groups = []; // key => rows
    $q = @mysqli_query($hos, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $vn = trim((string)($r['vn'] ?? ''));
            $an = trim((string)($r['an'] ?? ''));
            $vst = wf_ymd_normalize($r['vstdate'] ?? '');
            $src = wf_ymd_normalize($r['source_date'] ?? $vst);
            if ($src === '') {
                $src = $vst;
            }
            $orderNo = trim((string)($r['order_no'] ?? ''));
            $isHme = wf_is_hme_order_row($r);
            $orderType = trim((string)($r['order_type'] ?? ''));
            if ($orderType === '' && $isHme) {
                $orderType = 'HMe';
            }
            // OPD: รวมตาม VN
            // IPD HME: แยกตามใบสั่งยา (order_no) แม้วันเดียวกัน
            // IPD อื่น: รวมตามวันใน AN
            if ($an !== '') {
                if ($isHme) {
                    $gkey = 'an:' . $an . '|hme|' . ($orderNo !== '' ? $orderNo : ($src . '|' . trim((string)($r['rxtime'] ?? $r['vsttime'] ?? ''))));
                } else {
                    $gkey = 'an:' . $an . '|' . $src;
                }
            } elseif ($vn !== '') {
                $gkey = 'vn:' . $vn;
            } else {
                $gkey = 'd:' . $src;
            }
            if (!isset($groups[$gkey])) {
                $groups[$gkey] = [
                    'date' => $src,
                    'time' => '',
                    'vn' => $vn,
                    'an' => $an,
                    'order_no' => $orderNo,
                    'order_type' => $orderType,
                    'is_hme' => $isHme,
                    'rows' => [],
                ];
            }
            if ($isHme) {
                $groups[$gkey]['is_hme'] = true;
                if ($orderType !== '') {
                    $groups[$gkey]['order_type'] = $orderType;
                }
                if ($orderNo !== '') {
                    $groups[$gkey]['order_no'] = $orderNo;
                }
            }
            // ใช้วันที่สั่งยา (rx) ถ้าใหม่กว่า
            if ($src > $groups[$gkey]['date']) {
                $groups[$gkey]['date'] = $src;
            }
            $tm = wf_normalize_time($r['rxtime'] ?? '');
            if ($tm === '') {
                $tm = wf_normalize_time($r['vsttime'] ?? '');
            }
            if ($tm !== '' && ($groups[$gkey]['time'] === '' || $tm > $groups[$gkey]['time'])) {
                $groups[$gkey]['time'] = $tm;
            }
            $mapped = dr_map_drug_row($r, 'history');
            $mapped['method'] = trim((string)($r['method'] ?? $mapped['method'] ?? ''));
            $groups[$gkey]['rows'][] = $mapped;
        }
    }

    $episodes = [];
    foreach ($groups as $g) {
        $items = wf_filter_warfarin_rows($g['rows'], true);
        if (empty($items)) {
            continue;
        }
        $total = 0.0;
        $has = false;
        $offCount = 0;
        $methods = [];
        $lines = [];
        $qtyParts = [];
        foreach ($items as $it) {
            $isOff = !empty($it['is_off']);
            if ($isOff) {
                $offCount++;
            } elseif ($it['mg_week'] !== null && $it['mg_week'] > 0) {
                $total += (float)$it['mg_week'];
                $has = true;
            }
            $m = trim((string)($it['method'] ?? ''));
            if ($m !== '') {
                $methods[$m] = true;
            }
            $qty = isset($it['qty']) ? (float)$it['qty'] : 0.0;
            $units = trim((string)($it['units'] ?? ''));
            if ($units === '') {
                $units = 'เม็ด';
            }
            $strMg = isset($it['strength_mg']) && $it['strength_mg'] > 0
                ? rtrim(rtrim(number_format((float)$it['strength_mg'], 2, '.', ''), '0'), '.')
                : '';
            $qtyLabel = '';
            if ($isOff || $qty <= 0) {
                $qtyLabel = '0 ' . $units . ' (OFF)';
                $qtyParts[] = $qtyLabel;
            } elseif ($qty > 0) {
                $qtyDisp = (abs($qty - round($qty)) < 1e-6) ? (string)(int)round($qty) : rtrim(rtrim(number_format($qty, 2, '.', ''), '0'), '.');
                $qtyLabel = $qtyDisp . ' ' . $units;
                if ($strMg !== '') {
                    $qtyLabel .= ' (' . $strMg . ' mg)';
                }
                $qtyParts[] = $qtyLabel;
            }
            $lines[] = [
                'method' => $m,
                'qty' => $isOff ? 0.0 : ($qty > 0 ? $qty : null),
                'units' => $units,
                'qty_label' => $qtyLabel !== '' ? $qtyLabel : null,
                'strength_mg' => isset($it['strength_mg']) ? $it['strength_mg'] : null,
                'drug_name' => trim((string)($it['drug_name_tmt'] ?? $it['drug_name'] ?? '')),
                'is_off' => $isOff,
            ];
        }
        $allOff = ($offCount > 0 && $offCount === count($items) && !$has);
        $episodes[] = [
            'date' => $g['date'],
            'date_th' => wf_format_date_th($g['date']),
            'time' => $g['time'] ?? '',
            'time_hm' => wf_format_time_hm($g['time'] ?? ''),
            'mg_week' => $has ? round($total, 2) : null,
            'is_off' => $allOff,
            'source' => ($g['vn'] !== '' ? 'opd' : ($g['an'] !== '' ? 'ipd' : 'visit')),
            'vn' => $g['vn'],
            'an' => $g['an'],
            'order_no' => $g['order_no'] ?? '',
            'order_type' => $g['order_type'] ?? '',
            'is_hme' => !empty($g['is_hme']),
            'methods' => implode(' / ', array_keys($methods)),
            'qty_label' => implode(' + ', $qtyParts),
            'lines' => $lines,
            'item_count' => count($items),
        ];
    }

    usort($episodes, function ($a, $b) {
        $c = strcmp($a['date'], $b['date']);
        if ($c !== 0) {
            return $c;
        }
        $c = strcmp((string)($a['time'] ?? ''), (string)($b['time'] ?? ''));
        if ($c !== 0) {
            return $c;
        }
        return strcmp($a['vn'] . $a['an'], $b['vn'] . $b['an']);
    });

    // ยุบเฉพาะ IPD ที่จ่ายรายวันติดกัน (dose+วิธีใช้เท่ากัน) — ไม่ยุบ OPD คนละ visit
    $collapsed = [];
    foreach ($episodes as $ep) {
        $n = count($collapsed);
        if ($n > 0) {
            $prev = $collapsed[$n - 1];
            $sameMg = ($prev['mg_week'] !== null && $ep['mg_week'] !== null
                && abs((float)$prev['mg_week'] - (float)$ep['mg_week']) < 0.05);
            $sameMethod = (($prev['methods'] ?? '') === ($ep['methods'] ?? ''));
            $bothIpd = (($prev['source'] ?? '') === 'ipd' && ($ep['source'] ?? '') === 'ipd'
                && ($prev['an'] ?? '') !== '' && ($prev['an'] ?? '') === ($ep['an'] ?? ''));
            $eitherHme = !empty($prev['is_hme']) || !empty($ep['is_hme']);
            $dayGap = null;
            if (!empty($prev['date']) && !empty($ep['date'])) {
                $t0 = strtotime($prev['date']);
                $t1 = strtotime($ep['date']);
                if ($t0 && $t1) {
                    $dayGap = (int)round(($t1 - $t0) / 86400);
                }
            }
            if ($bothIpd && !$eitherHme && $sameMg && $sameMethod && $dayGap !== null && $dayGap <= 2) {
                continue;
            }
        }
        $collapsed[] = $ep;
    }

    return $collapsed;
}

/**
 * สร้างประวัติ therapy: dose mg/สัปดาห์ + INR + % เทียบก่อนหน้า + สรุปความเหมาะสม
 * @return array{rows:array,protocol_id:string,message:?string}
 */
function wf_build_therapy_history($con, $hos, $hn, $protocolId = 'inr_2_3', $inrPayload = null, $months = 36, $limit = 5, $inrAssessMaxDays = 5) {
    $inrMaxAgeMonths = wf_inr_max_age_months($con);
    if (!is_array($inrPayload)) {
        $inrPayload = wf_fetch_inr($con, $hos, $hn, max(72, $months + $inrMaxAgeMonths), 80);
    }
    $inrHist = is_array($inrPayload['history'] ?? null) ? $inrPayload['history'] : [];
    $episodes = wf_fetch_warfarin_dose_episodes($hos, $hn, $months);
    $limit = max(1, min(50, (int)$limit));
    $inrAssessMaxDays = max(0, min(30, (int)$inrAssessMaxDays));

    if (empty($episodes)) {
        return [
            'rows' => [],
            'protocol_id' => $protocolId,
            'message' => 'ไม่พบประวัติ Warfarin ในช่วง ' . $months . ' เดือน',
            'limit' => $limit,
        ];
    }

    $rowsAsc = [];
    $prevMg = null;
    $prevDate = null;
    foreach ($episodes as $ep) {
        $isOff = !empty($ep['is_off']);
        $currMg = $isOff ? null : $ep['mg_week'];
        $inrDisplay = wf_find_inr_on_or_before($inrHist, $ep['date']);
        $daysDiff = isset($inrDisplay['days_diff']) ? (int)$inrDisplay['days_diff'] : null;
        $sameDayInr = !empty($inrDisplay) && $daysDiff === 0;
        $carriedInr = !empty($inrDisplay) && !$sameDayInr;
        $staleInr = !empty($inrDisplay) && wf_inr_is_older_than_months(
            $inrDisplay['order_date'] ?? '',
            $ep['date'],
            $inrMaxAgeMonths
        );
        $gapStale = $prevDate !== null && wf_inr_is_older_than_months(
            $prevDate,
            $ep['date'],
            $inrMaxAgeMonths
        );
        // ประเมินได้เฉพาะเมื่อเจาะ INR วันเดียวกับวัน visit
        $inrValueForAssess = (!$isOff && $sameDayInr && !$staleInr && isset($inrDisplay['value']))
            ? $inrDisplay['value']
            : null;
        $inrAfter = wf_find_inr_after($inrHist, $ep['date'], 3, 90);
        $assess = wf_assess_dose_change(
            $con,
            $isOff ? null : $prevMg,
            $currMg,
            $inrValueForAssess,
            $protocolId,
            $inrAfter
        );
        if ($isOff) {
            $assess = wf_assess_mark_unevaluable(
                [
                    'pct' => null,
                    'verdict' => 'unknown',
                    'label' => 'ประเมินไม่ได้',
                    'detail' => '',
                    'badge' => 'secondary',
                ],
                'แพทย์ OFF (จำนวนสั่ง 0) — ไม่ประเมิน'
            );
        } elseif ($carriedInr) {
            $labTh = trim((string)($inrDisplay['date_th'] ?? ''));
            $assess = wf_assess_mark_unevaluable(
                $assess,
                'ใช้ผล Lab ก่อนหน้า' . ($labTh !== '' ? ' (' . $labTh . ')' : '') . ' ไม่ได้เจาะใหม่'
            );
        } elseif ($staleInr) {
            $assess = wf_assess_mark_unevaluable(
                $assess,
                'ผล INR นานกว่า ' . $inrMaxAgeMonths . ' เดือน'
            );
        } elseif ($gapStale) {
            $assess = wf_assess_mark_unevaluable(
                $assess,
                'dose ก่อนหน้านานกว่า ' . $inrMaxAgeMonths . ' เดือน — ไม่ใช้ประเมินการปรับขนาด'
            );
        }

        $usable = $sameDayInr && !$staleInr && !$gapStale && $inrValueForAssess !== null;
        $carriedOnly = $carriedInr;
        $recentCarry = false;

        $rowsAsc[] = [
            'date' => $ep['date'],
            'date_th' => $ep['date_th'],
            'time' => $ep['time'] ?? '',
            'time_hm' => $ep['time_hm'] ?? wf_format_time_hm($ep['time'] ?? ''),
            'mg_week' => $currMg,
            'prev_mg_week' => $prevMg,
            'pct_change' => $assess['pct'],
            'inr' => $inrDisplay['value'] ?? null,
            'inr_raw' => $inrDisplay['raw'] ?? null,
            'inr_date' => $inrDisplay['order_date'] ?? null,
            'inr_date_th' => $inrDisplay['date_th'] ?? null,
            'inr_same_day' => ($daysDiff === 0),
            'inr_usable' => $usable,
            'inr_stale' => $staleInr,
            'dose_gap_stale' => $gapStale,
            'inr_max_age_months' => $inrMaxAgeMonths,
            'inr_carried' => $carriedOnly,
            'inr_recent' => $recentCarry,
            'inr_days_diff' => $daysDiff,
            'next_inr' => $inrAfter['value'] ?? null,
            'next_inr_date_th' => $inrAfter['date_th'] ?? null,
            'assess_label' => $assess['label'],
            'assess_detail' => $assess['detail'],
            'assess_verdict' => $assess['verdict'],
            'assess_badge' => $assess['badge'],
            'methods' => $ep['methods'],
            'qty_label' => $ep['qty_label'] ?? '',
            'lines' => $ep['lines'] ?? [],
            'is_off' => $isOff,
            'is_hme' => !empty($ep['is_hme']),
            'order_no' => $ep['order_no'] ?? '',
            'order_type' => $ep['order_type'] ?? '',
            'source' => $ep['source'],
            'vn' => $ep['vn'],
            'an' => $ep['an'],
        ];
        if ($currMg !== null && $currMg > 0) {
            $prevMg = $currMg;
            $prevDate = $ep['date'];
        }
    }

    // แสดงใหม่ → เก่า แล้วจำกัดย้อนหลังไม่เกิน $limit ช่วง
    $rows = array_reverse($rowsAsc);
    $total = count($rows);
    if ($total > $limit) {
        $rows = array_slice($rows, 0, $limit);
    }

    return [
        'rows' => array_values($rows),
        'protocol_id' => $protocolId,
        'message' => null,
        'count' => count($rows),
        'total' => $total,
        'limit' => $limit,
        'inr_max_age_months' => $inrMaxAgeMonths,
    ];
}
