<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json; charset=utf-8');
include('connect.php');
include('hosxp_tmt_drug_helper.php');
mysqli_set_charset($con, 'utf8');

set_time_limit(180);
ini_set('memory_limit', '512M');
$api_started = microtime(true);

function di_api_json_error($message, $code = 200) {
    http_response_code($code);
    echo json_encode(['status' => 'error', 'message' => $message], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function di_api_req($key, $default = '') {
    if (isset($_POST[$key]) && (is_string($_POST[$key]) || is_numeric($_POST[$key]))) {
        return trim((string)$_POST[$key]);
    }
    if (isset($_GET[$key]) && (is_string($_GET[$key]) || is_numeric($_GET[$key]))) {
        return trim((string)$_GET[$key]);
    }
    return $default;
}

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    di_api_json_error('กรุณาเข้าสู่ระบบ', 401);
}
session_write_close();

register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode([
            'status' => 'error',
            'message' => 'ระบบขัดข้อง: ' . ($err['message'] ?? 'unknown'),
        ], JSON_UNESCAPED_UNICODE);
    }
});

try {

$start_date = di_api_req('start_date', date('Y-m-d', strtotime('-1 month')));
$end_date = di_api_req('end_date', date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-1 month'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if ($start_date > $end_date) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$max_rows = 12000;

$hn_raw = di_api_req('hn');
$hn_filter = $hn_raw !== '' ? di_hn_variants($hn_raw) : [];

$tbl_chk = mysqli_query($con, "SHOW TABLES LIKE 'monitor_drug_interaction_settings'");
if (!$tbl_chk || mysqli_num_rows($tbl_chk) === 0) {
    di_api_json_error('ยังไม่มีตาราง monitor_drug_interaction_settings — กรุณารัน upgrade.php');
}
ensure_di_dose_columns($con);
ensure_di_check_mode_column($con);

$q_rules = mysqli_query($con, "SELECT * FROM monitor_drug_interaction_settings WHERE active_status = 1 ORDER BY FIELD(COALESCE(alert_level,'soft'), 'hard', 'soft'), drug_name ASC");
if (!$q_rules) {
    di_api_json_error('ไม่สามารถโหลดกฎได้: ' . mysqli_error($con));
}
$all_active_rules = [];
while ($row = mysqli_fetch_assoc($q_rules)) {
    if (trim($row['drug_icode'] ?? '') === '' || trim($row['hosxp_icode'] ?? '') === '') {
        continue;
    }
    $all_active_rules[] = $row;
}

if (empty($all_active_rules)) {
    di_api_json_error('ยังไม่มีการตั้งค่า Drug Interaction ในระบบ');
}

$rules_total = count($all_active_rules);
$rules = $all_active_rules;
$rule_ids_param = di_api_req('rule_ids', '');
if ($rule_ids_param !== '') {
    $allowed_ids = [];
    foreach (explode(',', $rule_ids_param) as $rid) {
        $rid = (int)trim($rid);
        if ($rid > 0) {
            $allowed_ids[$rid] = true;
        }
    }
    if (!empty($allowed_ids)) {
        $rules = array_values(array_filter($all_active_rules, function ($r) use ($allowed_ids) {
            return isset($allowed_ids[(int)$r['id']]);
        }));
    }
}

if (empty($rules)) {
    di_api_json_error('ไม่ได้เลือกกฎที่ต้องการรายงาน — กรุณาเลือกอย่างน้อย 1 คู่ยา');
}
$rules_selected = count($rules);

$con_hosxp = hosxp_connect($con);
if (!$con_hosxp) {
    di_api_json_error('ไม่สามารถเชื่อมต่อฐานข้อมูล HOSxP ได้');
}

$rules = di_prepare_rules_icodes($con_hosxp, $rules);

$icode_set = [];
$lookback_anchor_icodes = [];
$lookback_partner_icodes = [];
foreach ($rules as $rule) {
    foreach ($rule['_icodes_a'] ?? [] as $ic) {
        $icode_set[$ic] = true;
        if (di_normalize_check_mode($rule['check_mode'] ?? '') === 'lookback') {
            $lookback_anchor_icodes[$ic] = true;
        }
    }
    foreach ($rule['_icodes_b'] ?? [] as $ic) {
        $icode_set[$ic] = true;
        if (di_normalize_check_mode($rule['check_mode'] ?? '') === 'lookback') {
            $lookback_partner_icodes[$ic] = true;
        }
    }
}

$window = di_compute_query_window($start_date, $end_date, $rules);
$query_start = $window['query_start'];
$query_end = $window['query_end'];
$need_dose_mg = di_rules_need_dose_mg($rules);
$has_lookback = di_rules_have_lookback($rules);
$all_icodes = di_rules_scan_icodes($rules);

if (empty($all_icodes)) {
    mysqli_close($con_hosxp);
    di_api_json_error('ไม่พบ icode ในกฎที่ตั้งไว้');
}

$raw_rows = [];
$drug_names = [];
$ptnames = [];
$row_count_raw = 0;
$truncated = false;

[$phase1_rows, $phase1_raw, $phase1_trunc, $phase1_err] = di_fetch_hosxp_orders(
    $con_hosxp, $all_icodes, $start_date, $end_date, $need_dose_mg, $hn_filter, $max_rows
);
if ($phase1_err) {
    mysqli_close($con_hosxp);
    di_api_json_error('SQL Error: ' . $phase1_err);
}
$row_count_raw += $phase1_raw;
$truncated = $truncated || $phase1_trunc;
$raw_rows = array_merge($raw_rows, $phase1_rows);

if ($has_lookback && !empty($lookback_partner_icodes)) {
    $hn_list = [];
    if (!empty($hn_filter)) {
        $hn_list = $hn_filter;
    } else {
        $hn_for_lookback = [];
        foreach ($phase1_rows as $row) {
            $ic = trim((string)($row['icode'] ?? ''));
            if (isset($lookback_anchor_icodes[$ic]) || isset($lookback_partner_icodes[$ic])) {
                $hn_for_lookback[trim((string)($row['hn'] ?? ''))] = true;
            }
        }
        foreach (array_keys($hn_for_lookback) as $hn) {
            if ($hn !== '') {
                $hn_list[] = $hn;
            }
        }
    }

    if (!empty($hn_list)) {
        $lb_icodes = array_keys($lookback_partner_icodes);
        [$phase2_rows, $phase2_raw, $phase2_trunc, $phase2_err] = di_fetch_hosxp_orders(
            $con_hosxp, $lb_icodes, $query_start, $query_end, $need_dose_mg, $hn_list, min(8000, $max_rows)
        );
        if ($phase2_err) {
            mysqli_close($con_hosxp);
            di_api_json_error('SQL Error (lookback): ' . $phase2_err);
        }
        if ($phase2_raw > 0) {
            $row_count_raw += $phase2_raw;
            $truncated = $truncated || $phase2_trunc;
            $raw_rows = array_merge($raw_rows, $phase2_rows);
        }
    }
}

foreach ($raw_rows as $row) {
    $icode = trim($row['icode']);
    $hn = $row['hn'];
    if (!isset($drug_names[$icode])) {
        $drug_names[$icode] = trim($row['drug_name'] ?? '') ?: $icode;
    }
    if (!isset($ptnames[$hn])) {
        $ptnames[$hn] = trim($row['ptname'] ?? '');
    }
}

mysqli_close($con_hosxp);

$deduped_rows = di_dedupe_latest_orders($raw_rows);
$prepared_rows = di_prepare_orders($deduped_rows, $need_dose_mg);
$prepared_all = di_prepare_orders($raw_rows, $need_dose_mg);
[$by_icode, $by_vn_icode, $by_hn_icode] = di_reindex_orders_fast($prepared_rows);
[$by_icode_all] = di_reindex_orders_fast($prepared_all);
$idx = [
    'by_icode' => $by_icode,
    'by_vn_icode' => $by_vn_icode,
    'by_hn_icode' => $by_hn_icode,
    'by_icode_all' => $by_icode_all,
];
$row_count = count($prepared_rows);

$block_alerts = [];
$warning_alerts = [];
$block_count = 0;
$warning_count = 0;
$seen = [];

foreach ($rules as $rule) {
    $alert_level = 'soft';
    if (!empty($rule['alert_level']) && in_array($rule['alert_level'], ['hard', 'soft'], true)) {
        $alert_level = $rule['alert_level'];
    } elseif (isset($rule['severity']) && (int)$rule['severity'] >= 3) {
        $alert_level = 'hard';
    }

    di_each_matching_pair($rule, $idx, ['date_from' => $start_date, 'date_to' => $end_date], function ($o1, $o2, $check_mode, $lookback_days, $c1, $c2) use ($rule, $alert_level, $drug_names, $ptnames, &$seen, &$block_alerts, &$warning_alerts, &$block_count, &$warning_count) {
        $key = $rule['id'] . '|' . ($o1['hn'] ?? '') . '|' . di_same_rx_key($o1) . '|' . ($o1['icode'] ?? '') . '|' . ($o2['icode'] ?? '') . '|' . ($o2['vstdate'] ?? '') . '|' . ($o2['vn'] ?? '');
        if (isset($seen[$key])) {
            return;
        }
        $seen[$key] = true;
        $drug1_name = $drug_names[$o1['icode'] ?? ''] ?? ($rule['drug_name'] ?? '');
        $drug2_name = $drug_names[$o2['icode'] ?? ''] ?? ($rule['hosxp_drug_name'] ?? '');
        $alert_data = di_build_alert(
            $rule, $o1, $o2, $alert_level, $check_mode, $lookback_days,
            $ptnames[$o1['hn']] ?? '', $drug1_name, $drug2_name, $c1, $c2
        );
        di_append_alert($alert_data, $alert_level, $block_alerts, $warning_alerts, $block_count, $warning_count);
    });
}

$hn_set = [];
foreach ($prepared_rows as $row) {
    if (($row['vstdate'] ?? '') >= $start_date && ($row['vstdate'] ?? '') <= $end_date) {
        $hn_set[$row['hn']] = true;
    }
}

require_once __DIR__ . '/monitor_drug_interaction_consult_helper.php';
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
$block_alerts = sp_alert_mute_filter_rows($con, $block_alerts);
$warning_alerts = sp_alert_mute_filter_rows($con, $warning_alerts);
$block_count = count($block_alerts);
$warning_count = count($warning_alerts);

echo json_encode([
    'status' => 'success',
    'meta' => [
        'block_count' => $block_count,
        'warning_count' => $warning_count,
        'rule_count' => $rules_selected,
        'rules_selected' => $rules_selected,
        'rules_total' => $rules_total,
        'orders_scanned' => $row_count,
        'orders_raw' => $row_count_raw,
        'date_from' => $start_date,
        'date_to' => $end_date,
        'query_from' => $query_start,
        'query_to' => $query_end,
        'truncated' => $truncated,
        'elapsed_ms' => (int)round((microtime(true) - $api_started) * 1000),
        'patients_scanned' => count($hn_set),
        'high_volume' => (count($icode_set) > 20 || count($rules) > 30),
        'hn' => $hn_raw,
    ],
    'block_groups' => mdi_attach_to_groups($con, di_group_alerts_by_hn($block_alerts)),
    'warning_groups' => mdi_attach_to_groups($con, di_group_alerts_by_hn($warning_alerts)),
], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);

} catch (Throwable $e) {
    di_api_json_error('เกิดข้อผิดพลาด: ' . $e->getMessage());
}
