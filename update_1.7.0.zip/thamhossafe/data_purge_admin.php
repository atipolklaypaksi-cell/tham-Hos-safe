<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/data_purge_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: home.php');
    exit;
}
dp_ensure_tables($con);
$groups = dp_group_counts($con);
$batches = dp_list_batches($con, true);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ล้างข้อมูลปฏิบัติการ - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .dp-hero {
            background: linear-gradient(135deg, #7f1d1d 0%, #b91c1c 50%, #9a3412 100%);
            color: #fff; border-radius: 14px; padding: 1.15rem 1.4rem; margin-bottom: 1.1rem;
        }
        .dp-card { border: 0; border-radius: 12px; }
        .dp-warn {
            background: #fff7ed; border: 1px solid #fdba74; border-radius: 10px; padding: 12px 14px;
        }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="dp-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="small text-uppercase" style="letter-spacing:.08em;opacity:.75;">ตั้งค่าระบบ · Data Purge</div>
                    <h4 class="fw-bold mb-1"><i class="fas fa-trash-alt me-2"></i>ล้างข้อมูลปฏิบัติการ</h4>
                    <p class="mb-0 small" style="opacity:.92;">
                        ลบเฉพาะข้อมูลปฏิบัติการ (Med Error, แพ้ยา, ประวัติ Med Recon / Smart Drug)
                        — <b>ไม่ลบ</b> users, สิทธิ์เมนู, ตั้งค่าเชื่อมต่อ, ประเภท Med Error, guideline
                        · กู้คืนได้ภายใน <b>7 วัน</b>
                    </p>
                </div>
                <div class="d-flex gap-2">
                    <a href="integrations_hub.php" class="btn btn-light btn-sm fw-bold"><i class="fas fa-plug me-1"></i> เปิด/ปิดการเชื่อมต่อ</a>
                    <span class="badge bg-light text-dark px-3 py-2">Admin เท่านั้น</span>
                </div>
            </div>

            <div id="dpAlert" class="alert d-none" role="alert"></div>

            <div class="row g-3">
                <div class="col-lg-7">
                    <div class="card dp-card shadow-sm mb-3">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3">เลือกกลุ่มที่จะลบ</h6>
                            <div id="dpGroups">
                                <?php foreach ($groups as $g): ?>
                                <label class="d-flex gap-2 align-items-start border rounded p-3 mb-2 bg-white">
                                    <input type="checkbox" class="form-check-input mt-1 dp-g" value="<?php echo htmlspecialchars($g['code']); ?>">
                                    <span>
                                        <span class="fw-bold"><?php echo htmlspecialchars($g['label']); ?></span>
                                        <span class="badge bg-secondary ms-1"><?php echo (int)$g['total']; ?> แถว</span>
                                        <div class="small text-muted"><?php echo htmlspecialchars($g['desc']); ?></div>
                                    </span>
                                </label>
                                <?php endforeach; ?>
                            </div>
                            <div class="mb-2">
                                <label class="form-label small fw-bold mb-0">หมายเหตุ (ถ้ามี)</label>
                                <input type="text" id="dpNote" class="form-control form-control-sm" placeholder="เช่น ล้างข้อมูลก่อนส่ง Docker ให้ รพ.อื่น">
                            </div>
                            <div class="dp-warn mb-3">
                                <div class="fw-bold text-danger mb-1"><i class="fas fa-exclamation-triangle me-1"></i>ยืนยันการลบ</div>
                                <div class="small mb-2">พิมพ์คำว่า <code>delete</code> แล้วกดปุ่ม — ข้อมูลจะถูกเก็บสำรองอัตโนมัติ 7 วัน</div>
                                <input type="text" id="dpConfirm" class="form-control form-control-sm" placeholder="พิมพ์ delete" autocomplete="off">
                            </div>
                            <button type="button" class="btn btn-danger fw-bold" id="btnPurge">
                                <i class="fas fa-trash me-1"></i> ลบกลุ่มที่เลือก
                            </button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="card dp-card shadow-sm mb-3">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3"><i class="fas fa-undo me-1 text-success"></i> กู้คืนภายใน 7 วัน</h6>
                            <div id="dpBatches">
                                <?php if (!$batches): ?>
                                <div class="text-muted small">ยังไม่มีชุดที่กู้คืนได้</div>
                                <?php else: ?>
                                <?php foreach ($batches as $b): ?>
                                <div class="border rounded p-2 mb-2" data-batch="<?php echo (int)$b['id']; ?>">
                                    <div class="fw-bold small">#<?php echo (int)$b['id']; ?> · <?php echo htmlspecialchars($b['groups_csv']); ?></div>
                                    <div class="small text-muted">
                                        ลบเมื่อ <?php echo htmlspecialchars($b['created_at']); ?>
                                        โดย <?php echo htmlspecialchars($b['created_by_name'] ?: '-'); ?>
                                        · <?php echo (int)$b['row_count']; ?> แถว
                                    </div>
                                    <div class="small">หมดอายุ <?php echo htmlspecialchars($b['expires_at']); ?></div>
                                    <?php if (!empty($b['note'])): ?>
                                    <div class="small text-muted"><?php echo htmlspecialchars($b['note']); ?></div>
                                    <?php endif; ?>
                                    <button type="button" class="btn btn-sm btn-outline-success mt-2 btn-restore" data-id="<?php echo (int)$b['id']; ?>">
                                        กู้คืนชุดนี้
                                    </button>
                                </div>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
function dpFlash(msg, ok) {
    $('#dpAlert').removeClass('d-none alert-success alert-danger')
        .addClass(ok ? 'alert-success' : 'alert-danger').html(msg);
}
function dpReload() {
    return fetch('fetch_data_purge_api.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'summary' })
    }).then(r => r.json()).then(function (data) {
        if (!data || !data.ok) return;
        let gHtml = '';
        (data.groups || []).forEach(function (g) {
            gHtml += '<label class="d-flex gap-2 align-items-start border rounded p-3 mb-2 bg-white">'
                + '<input type="checkbox" class="form-check-input mt-1 dp-g" value="' + g.code + '">'
                + '<span><span class="fw-bold">' + g.label + '</span>'
                + ' <span class="badge bg-secondary ms-1">' + g.total + ' แถว</span>'
                + '<div class="small text-muted">' + g.desc + '</div></span></label>';
        });
        $('#dpGroups').html(gHtml);
        let bHtml = '';
        if (!(data.batches || []).length) {
            bHtml = '<div class="text-muted small">ยังไม่มีชุดที่กู้คืนได้</div>';
        } else {
            (data.batches || []).forEach(function (b) {
                bHtml += '<div class="border rounded p-2 mb-2">'
                    + '<div class="fw-bold small">#' + b.id + ' · ' + (b.groups_csv || '') + '</div>'
                    + '<div class="small text-muted">ลบเมื่อ ' + (b.created_at || '') + ' โดย ' + (b.created_by_name || '-')
                    + ' · ' + (b.row_count || 0) + ' แถว</div>'
                    + '<div class="small">หมดอายุ ' + (b.expires_at || '') + '</div>'
                    + '<button type="button" class="btn btn-sm btn-outline-success mt-2 btn-restore" data-id="' + b.id + '">กู้คืนชุดนี้</button></div>';
            });
        }
        $('#dpBatches').html(bHtml);
    });
}
$('#btnPurge').on('click', function () {
    const groups = [];
    $('.dp-g:checked').each(function () { groups.push(this.value); });
    if (!groups.length) { dpFlash('เลือกอย่างน้อย 1 กลุ่ม', false); return; }
    const confirm = ($('#dpConfirm').val() || '').trim();
    if (confirm !== 'delete') { dpFlash('พิมพ์คำว่า <b>delete</b> เพื่อยืนยัน', false); return; }
    if (!window.confirm('ยืนยันลบข้อมูลกลุ่มที่เลือก?\nจะเก็บสำรองไว้กู้คืนได้ 7 วัน')) return;
    const btn = this;
    btn.disabled = true;
    fetch('fetch_data_purge_api.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'purge',
            groups: groups,
            confirm: confirm,
            note: ($('#dpNote').val() || '').trim()
        })
    })
    .then(r => r.json())
    .then(function (data) {
        if (!data || !data.ok) {
            dpFlash((data && data.error) || 'ลบไม่สำเร็จ', false);
            return;
        }
        dpFlash('ลบแล้ว ' + (data.row_count || 0) + ' แถว · batch #' + data.batch_id + ' · กู้คืนได้ถึง ' + data.expires_at, true);
        $('#dpConfirm').val('');
        return dpReload();
    })
    .catch(function () { dpFlash('เชื่อมต่อ API ไม่สำเร็จ', false); })
    .finally(function () { btn.disabled = false; });
});
$('#dpBatches').on('click', '.btn-restore', function () {
    const id = parseInt(this.getAttribute('data-id'), 10);
    if (!id || !confirm('กู้คืนชุด #' + id + ' กลับเข้าตารางเดิม?')) return;
    const btn = this;
    btn.disabled = true;
    fetch('fetch_data_purge_api.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'restore', batch_id: id })
    })
    .then(r => r.json())
    .then(function (data) {
        if (!data || !data.ok) {
            dpFlash((data && data.error) || 'กู้คืนไม่สำเร็จ', false);
            return;
        }
        dpFlash('กู้คืนแล้ว ' + (data.restored || 0) + ' แถว', true);
        return dpReload();
    })
    .catch(function () { dpFlash('เชื่อมต่อ API ไม่สำเร็จ', false); })
    .finally(function () { btn.disabled = false; });
});
</script>
</body>
</html>
