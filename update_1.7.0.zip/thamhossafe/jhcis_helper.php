<?php
/**
 * เชื่อมต่อฐานข้อมูล JHCIS PCC แบบอ่านอย่างเดียว (Read Only)
 */

function jhcis_config_keys() {
    return ['jhcis_host', 'jhcis_port', 'jhcis_user', 'jhcis_pass', 'jhcis_db', 'jhcis_readonly'];
}

function jhcis_default_config() {
    return [
        'jhcis_host' => '10.10.22.99',
        'jhcis_port' => '3333',
        'jhcis_user' => 'tum',
        'jhcis_pass' => 'scph27',
        'jhcis_db' => 'jhcisdb',
        'jhcis_readonly' => '1',
    ];
}

function jhcis_upsert_config($con, $key, $value) {
    $k = mysqli_real_escape_string($con, $key);
    $v = mysqli_real_escape_string($con, (string)$value);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$k'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
}

function jhcis_ensure_config($con) {
    $defaults = jhcis_default_config();
    foreach ($defaults as $key => $value) {
        $k = mysqli_real_escape_string($con, $key);
        $chk = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name='$k' LIMIT 1");
        if (!$chk || mysqli_num_rows($chk) === 0) {
            jhcis_upsert_config($con, $key, $value);
            continue;
        }
        if ($key === 'jhcis_readonly') {
            jhcis_upsert_config($con, $key, '1');
        }
    }
}

function jhcis_load_config($con) {
    jhcis_ensure_config($con);
    $cfg = jhcis_default_config();
    $keys = "'" . implode("','", array_map(function ($k) use ($con) {
        return mysqli_real_escape_string($con, $k);
    }, jhcis_config_keys())) . "'";
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ($keys)");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cfg[$r['config_name']] = (string)$r['config_value'];
        }
    }
    $cfg['jhcis_readonly'] = '1';
    $port = (int)($cfg['jhcis_port'] ?? 3333);
    $cfg['jhcis_port'] = (string)($port > 0 ? $port : 3333);
    return $cfg;
}

function jhcis_save_config($con, array $input) {
    $cur = jhcis_load_config($con);
    $next = $cur;
    foreach (['jhcis_host', 'jhcis_port', 'jhcis_user', 'jhcis_db'] as $key) {
        if (array_key_exists($key, $input)) {
            $next[$key] = trim((string)$input[$key]);
        }
    }
    if (isset($input['jhcis_pass'])) {
        $pass = (string)$input['jhcis_pass'];
        if ($pass !== '' && $pass !== '********') {
            $next['jhcis_pass'] = $pass;
        }
    }
    $port = (int)$next['jhcis_port'];
    $next['jhcis_port'] = (string)($port > 0 ? $port : 3333);
    $next['jhcis_readonly'] = '1';
    foreach (jhcis_config_keys() as $key) {
        jhcis_upsert_config($con, $key, $next[$key] ?? '');
    }
    return jhcis_load_config($con);
}

function jhcis_public_config(array $cfg) {
    $out = $cfg;
    $out['jhcis_pass'] = ($cfg['jhcis_pass'] ?? '') !== '' ? '********' : '';
    $out['jhcis_readonly'] = '1';
    return $out;
}

function jhcis_is_readonly_sql($sql) {
    $sql = trim((string)$sql);
    if ($sql === '') {
        return false;
    }
    $sql = preg_replace('/^\s*\/\*.*?\*\//s', '', $sql);
    $sql = preg_replace('/^\s*--[^\n]*\n/', '', $sql);
    $sql = ltrim($sql);
    if (!preg_match('/^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN|WITH)\b/i', $sql)) {
        return false;
    }
    if (preg_match('/\b(INSERT|UPDATE|DELETE|ALTER|DROP|CREATE|TRUNCATE|GRANT|REVOKE|LOAD\s+DATA|INTO\s+OUTFILE|INTO\s+DUMPFILE|FOR\s+UPDATE)\b/i', $sql)) {
        return false;
    }
    if (preg_match('/\bREPLACE\s+INTO\b/i', $sql)) {
        return false;
    }
    return true;
}

function jhcis_ident($name) {
    $name = trim((string)$name);
    if ($name === '' || !preg_match('/^[A-Za-z0-9_]+$/', $name)) {
        return null;
    }
    return '`' . $name . '`';
}

function jhcis_apply_readonly($jhcis) {
    if (!$jhcis) {
        return;
    }
    @mysqli_query($jhcis, 'SET SESSION TRANSACTION READ ONLY');
}

function jhcis_connect($con, $read_timeout = 30, array $override = null) {
    $cfg = $override ? array_merge(jhcis_load_config($con), $override) : jhcis_load_config($con);
    $host = trim((string)($cfg['jhcis_host'] ?? ''));
    $user = trim((string)($cfg['jhcis_user'] ?? ''));
    $pass = (string)($cfg['jhcis_pass'] ?? '');
    $db = trim((string)($cfg['jhcis_db'] ?? ''));
    $port = (int)($cfg['jhcis_port'] ?? 3333);
    if ($host === '' || $user === '' || $db === '') {
        return null;
    }
    if ($port <= 0) {
        $port = 3333;
    }
    mysqli_report(MYSQLI_REPORT_OFF);
    $c = mysqli_init();
    if (!$c) {
        return null;
    }
    $read_timeout = max(8, min(120, (int)$read_timeout));
    mysqli_options($c, MYSQLI_OPT_CONNECT_TIMEOUT, 8);
    if (defined('MYSQLI_OPT_READ_TIMEOUT')) {
        mysqli_options($c, MYSQLI_OPT_READ_TIMEOUT, $read_timeout);
    }
    $ok = @mysqli_real_connect($c, $host, $user, $pass, $db, $port);
    if (!$ok) {
        return null;
    }
    @mysqli_set_charset($c, 'utf8mb4');
    jhcis_apply_readonly($c);
    return $c;
}

function jhcis_query($jhcis, $sql) {
    if (!$jhcis || !jhcis_is_readonly_sql($sql)) {
        return false;
    }
    return @mysqli_query($jhcis, $sql);
}

function jhcis_close($jhcis) {
    if (!$jhcis) {
        return;
    }
    try {
        @mysqli_close($jhcis);
    } catch (Throwable $e) {
        // ignore
    }
}

function jhcis_is_sensitive_column($name, $type = '') {
    $n = strtolower((string)$name);
    $t = strtolower((string)$type);
    if (strpos($t, 'blob') !== false || strpos($t, 'binary') !== false) {
        return true;
    }
    $needles = [
        'password', 'passwd', 'pass_hash', 'hash', 'token', 'secret', 'otp',
        'cid', 'idcard', 'pid', 'cardid', 'salary', 'finger', 'fingle',
    ];
    foreach ($needles as $w) {
        if (strpos($n, $w) !== false) {
            return true;
        }
    }
    return false;
}

function jhcis_table_count($jhcis) {
    $q = jhcis_query($jhcis, 'SHOW TABLES');
    if (!$q) {
        return 0;
    }
    return (int)mysqli_num_rows($q);
}

function jhcis_table_row_estimate($jhcis, $table) {
    $ident = jhcis_ident($table);
    if (!$ident) {
        return null;
    }
    $esc = mysqli_real_escape_string($jhcis, $table);
    $q = jhcis_query($jhcis, "SELECT TABLE_ROWS AS c FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$esc' LIMIT 1");
    if (!$q) {
        return null;
    }
    $r = mysqli_fetch_assoc($q);
    if (!$r) {
        return null;
    }
    return isset($r['c']) ? (int)$r['c'] : null;
}

function jhcis_explain_connect_error($error) {
    $error = trim((string)$error);
    if ($error === '') {
        return 'เชื่อมต่อ JHCIS PCC ไม่ได้';
    }
    if (stripos($error, 'Access denied') !== false && stripos($error, 'to database') !== false) {
        return 'บัญชีเข้าเซิร์ฟเวอร์ MySQL ได้ แต่ยังไม่มีสิทธิ์ใช้ฐานที่ระบุ — ให้ผู้ดูแลเครื่อง JHCIS ให้สิทธิ์อ่าน (SELECT) บนฐานนี้แก่ user นี้ แล้วกดทดสอบอีกครั้ง · ' . $error;
    }
    if (stripos($error, 'Access denied') !== false) {
        return 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง หรือ user นี้ยังไม่ได้รับอนุญาตจาก IP ของ THAM SAFE · ' . $error;
    }
    return $error;
}

function jhcis_ping($con, array $override = null) {
    $t0 = microtime(true);
    $cfg = $override ? array_merge(jhcis_load_config($con), $override) : jhcis_load_config($con);
    $host = trim((string)($cfg['jhcis_host'] ?? ''));
    $out = [
        'ok' => false,
        'ms' => 0,
        'host' => $host,
        'port' => (int)($cfg['jhcis_port'] ?? 3333),
        'db' => (string)($cfg['jhcis_db'] ?? ''),
        'user' => (string)($cfg['jhcis_user'] ?? ''),
        'readonly' => true,
        'version' => '',
        'table_count' => 0,
        'stats' => [],
        'error' => '',
        'write_blocked' => true,
    ];
    $jhcis = jhcis_connect($con, 12, $override);
    $out['ms'] = round((microtime(true) - $t0) * 1000, 1);
    if (!$jhcis) {
        $out['error'] = jhcis_explain_connect_error(mysqli_connect_error() ?: 'เชื่อมต่อ JHCIS PCC ไม่ได้');
        return $out;
    }
    $info = jhcis_query($jhcis, 'SELECT @@session.transaction_read_only AS ro, DATABASE() AS db, VERSION() AS ver');
    if ($info) {
        $r = mysqli_fetch_assoc($info);
        $out['version'] = (string)($r['ver'] ?? '');
        $out['db'] = (string)($r['db'] ?? $out['db']);
        $out['readonly'] = ((string)($r['ro'] ?? '1')) === '1';
    }
    $out['table_count'] = jhcis_table_count($jhcis);
    $stats = [];
    foreach (['person' => 'ประชากร', 'visit' => 'การรับบริการ', 'village' => 'หมู่บ้าน'] as $table => $label) {
        $n = jhcis_table_row_estimate($jhcis, $table);
        if ($n !== null) {
            $stats[] = ['table' => $table, 'label' => $label, 'count' => $n];
        }
    }
    $out['stats'] = $stats;
    $probe = @mysqli_query($jhcis, 'UPDATE person SET pcucode = pcucode WHERE 1=0');
    $out['write_blocked'] = !$probe;
    $out['ok'] = true;
    jhcis_close($jhcis);
    return $out;
}

function jhcis_list_tables($jhcis, $q = '', $limit = 80) {
    $limit = max(1, min(200, (int)$limit));
    $res = jhcis_query($jhcis, 'SHOW TABLES');
    if (!$res) {
        return [];
    }
    $q = trim(mb_strtolower($q, 'UTF-8'));
    $preferred = ['person', 'visit', 'village', 'house', 'user', 'office', 'visitdiag', 'chospital'];
    $tables = [];
    $rest = [];
    while ($row = mysqli_fetch_row($res)) {
        $name = (string)($row[0] ?? '');
        if ($name === '') {
            continue;
        }
        if ($q !== '' && mb_strpos(mb_strtolower($name, 'UTF-8'), $q) === false) {
            continue;
        }
        if (in_array($name, $preferred, true)) {
            $tables[] = $name;
        } else {
            $rest[] = $name;
        }
    }
    $tables = array_merge($tables, $rest);
    return array_slice($tables, 0, $limit);
}

function jhcis_describe_table($jhcis, $table) {
    $ident = jhcis_ident($table);
    if (!$ident) {
        return [];
    }
    $q = jhcis_query($jhcis, "SHOW COLUMNS FROM $ident");
    if (!$q) {
        return [];
    }
    $cols = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $name = (string)($r['Field'] ?? '');
        $type = (string)($r['Type'] ?? '');
        $cols[] = [
            'name' => $name,
            'type' => $type,
            'null' => (string)($r['Null'] ?? ''),
            'key' => (string)($r['Key'] ?? ''),
            'sensitive' => jhcis_is_sensitive_column($name, $type),
        ];
    }
    return $cols;
}

function jhcis_preview_table($jhcis, $table, $limit = 20) {
    $ident = jhcis_ident($table);
    if (!$ident) {
        return ['columns' => [], 'rows' => [], 'error' => 'ชื่อตารางไม่ถูกต้อง'];
    }
    $cols = jhcis_describe_table($jhcis, $table);
    if (empty($cols)) {
        return ['columns' => [], 'rows' => [], 'error' => 'ไม่พบตารางนี้ หรืออ่านโครงสร้างไม่ได้'];
    }
    $select = [];
    $headers = [];
    foreach ($cols as $c) {
        if (!empty($c['sensitive'])) {
            continue;
        }
        $colIdent = jhcis_ident($c['name']);
        if (!$colIdent) {
            continue;
        }
        $select[] = $colIdent;
        $headers[] = $c['name'];
        if (count($select) >= 12) {
            break;
        }
    }
    if (empty($select)) {
        return ['columns' => [], 'rows' => [], 'error' => 'คอลัมน์ที่แสดงได้ถูกซ่อนเพราะเป็นข้อมูลอ่อนไหว'];
    }
    $limit = max(1, min(50, (int)$limit));
    $sql = 'SELECT ' . implode(', ', $select) . " FROM $ident LIMIT $limit";
    $q = jhcis_query($jhcis, $sql);
    if (!$q) {
        return ['columns' => $headers, 'rows' => [], 'error' => 'อ่านข้อมูลไม่ได้'];
    }
    $rows = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $row = [];
        foreach ($headers as $h) {
            $v = $r[$h] ?? '';
            if (is_string($v) && strlen($v) > 180) {
                $v = substr($v, 0, 180) . '…';
            }
            $row[$h] = $v;
        }
        $rows[] = $row;
    }
    return ['columns' => $headers, 'rows' => $rows, 'error' => ''];
}

function jhcis_table_exists($jhcis, $table) {
    $ident = jhcis_ident($table);
    if (!$ident) {
        return false;
    }
    $q = jhcis_query($jhcis, "SHOW TABLES LIKE '" . mysqli_real_escape_string($jhcis, $table) . "'");
    return $q && mysqli_num_rows($q) > 0;
}

function jhcis_column_names($jhcis, $table) {
    $ident = jhcis_ident($table);
    if (!$ident) {
        return [];
    }
    $q = jhcis_query($jhcis, "SHOW COLUMNS FROM $ident");
    if (!$q) {
        return [];
    }
    $cols = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $n = strtolower(trim((string)($r['Field'] ?? '')));
        if ($n !== '') {
            $cols[$n] = $n;
        }
    }
    return $cols;
}

function jhcis_pick_col(array $cols, array $candidates) {
    foreach ($candidates as $c) {
        $c = strtolower(trim((string)$c));
        if ($c !== '' && isset($cols[$c])) {
            return $c;
        }
    }
    return null;
}

/** รหัสหน่วยขาย JHCIS เช่น 027, 006 — ไม่ใช่ชื่อหน่วยหรือความแรง */
function jhcis_is_code_like($val) {
    $v = trim((string)$val);
    return $v !== '' && preg_match('/^\d{2,4}$/', $v);
}

/**
 * ความแรงจากชื่อยา JHCIS เช่น FOLIC ACID 5 MG. TAB → "5 mg"
 * ไม่ดึงปริมาตร (ml) เพราะเป็นขนาดบรรจุ ไม่ใช่ขนาดต่อครั้ง
 */
function jhcis_extract_strength_from_name($name) {
    $name = trim((string)$name);
    if ($name === '') {
        return '';
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|μg|ug|ไมโครกรัม)\b/iu', $name, $m)) {
        return $m[1] . ' mcg';
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)\s*(?:mg|มก\.?|มิลลิกรัม)\b/iu', $name, $m)) {
        return $m[1] . '/' . $m[2] . ' mg';
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mg|มก\.?|มิลลิกรัม)\b/iu', $name, $m)) {
        return $m[1] . ' mg';
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:gm|grams?|กรัม|กร\.)\b/iu', $name, $m)) {
        return $m[1] . ' g';
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*g\b/iu', $name, $m)) {
        return $m[1] . ' g';
    }
    return '';
}

function jhcis_readable_unit($unit) {
    $u = trim((string)$unit);
    if ($u === '' || jhcis_is_code_like($u)) {
        return '';
    }
    return $u;
}

function jhcis_display_name() {
    return 'คลินิกหมอครอบครัว';
}

function jhcis_office_name($jhcis) {
    return jhcis_display_name();
}

/**
 * ประวัติยาจาก JHCIS PCC — จับคู่ด้วยเลขบัตรประชาชน (CID) อ่านอย่างเดียว
 */
function jhcis_fetch_smart_drug($con, $cid, $months = 12, $limit = 800) {
    $t0 = microtime(true);
    $cid = preg_replace('/\D+/', '', (string)$cid);
    $limit = max(50, min(1500, (int)$limit));
    $months = (int)$months;
    $out = [
        'ok' => false,
        'code' => 'jhcis',
        'name' => jhcis_display_name(),
        'rows' => 0,
        'visits' => 0,
        'ms' => 0,
        'error' => '',
        'history' => [],
        'visit_list' => [],
    ];
    if (strlen($cid) !== 13) {
        $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
        $out['error'] = 'ไม่มีเลขบัตรประชาชนจาก HOSxP จึงจับคู่ JHCIS ไม่ได้';
        return $out;
    }
    $jhcis = jhcis_connect($con, 20);
    $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
    if (!$jhcis) {
        $out['error'] = jhcis_explain_connect_error(mysqli_connect_error() ?: 'เชื่อมต่อ JHCIS PCC ไม่ได้');
        return $out;
    }
    $out['name'] = jhcis_office_name($jhcis);

    if (!jhcis_table_exists($jhcis, 'person') || !jhcis_table_exists($jhcis, 'visit') || !jhcis_table_exists($jhcis, 'visitdrug')) {
        jhcis_close($jhcis);
        $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
        $out['error'] = 'ไม่พบตาราง person / visit / visitdrug ใน JHCIS';
        return $out;
    }

    $person_cols = jhcis_column_names($jhcis, 'person');
    $cid_cols = [];
    foreach (['idcard', 'cid', 'pidcard', 'cardid'] as $c) {
        if (isset($person_cols[$c])) {
            $cid_cols[] = $c;
        }
    }
    $pid_col = jhcis_pick_col($person_cols, ['pid']);
    $pcu_col = jhcis_pick_col($person_cols, ['pcucodeperson', 'pcucode']);
    if (!$cid_cols || !$pid_col) {
        jhcis_close($jhcis);
        $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
        $out['error'] = 'ตาราง person ไม่มีคอลัมน์เลขบัตร/pid';
        return $out;
    }

    $esc_cid = mysqli_real_escape_string($jhcis, $cid);
    $pid_ident = jhcis_ident($pid_col);
    $pcu_ident = $pcu_col ? jhcis_ident($pcu_col) : "''";
    $cid_where = [];
    foreach ($cid_cols as $c) {
        $ident = jhcis_ident($c);
        $cid_where[] = "REPLACE(REPLACE(TRIM(IFNULL($ident, '')), '-', ''), ' ', '') = '$esc_cid'";
    }
    $q_person = jhcis_query($jhcis, "SELECT $pid_ident AS pid, " . ($pcu_col ? $pcu_ident : "''") . " AS pcucode
        FROM person
        WHERE (" . implode(' OR ', $cid_where) . ")
        LIMIT 5");
    $person = ($q_person && mysqli_num_rows($q_person) > 0) ? mysqli_fetch_assoc($q_person) : null;
    if (!$q_person) {
        jhcis_close($jhcis);
        $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
        $out['error'] = 'ค้นหาบุคคลใน JHCIS ไม่สำเร็จ';
        return $out;
    }
    if (!$person || trim((string)($person['pid'] ?? '')) === '') {
        jhcis_close($jhcis);
        $out['ok'] = true;
        $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
        $out['error'] = '';
        $out['miss_reason'] = 'no_person';
        return $out;
    }

    $visit_cols = jhcis_column_names($jhcis, 'visit');
    $drug_cols = jhcis_column_names($jhcis, 'visitdrug');
    $v_visitno = jhcis_pick_col($visit_cols, ['visitno']);
    $v_date = jhcis_pick_col($visit_cols, ['visitdate', 'datevisit', 'vstdate']);
    $v_time = jhcis_pick_col($visit_cols, ['visittime', 'timestart', 'timevisit', 'vsttime']);
    $v_pid = jhcis_pick_col($visit_cols, ['pid']);
    $v_pcu_person = jhcis_pick_col($visit_cols, ['pcucodeperson']);
    $v_pcu = jhcis_pick_col($visit_cols, ['pcucode']);
    $d_visitno = jhcis_pick_col($drug_cols, ['visitno']);
    $d_pcu = jhcis_pick_col($drug_cols, ['pcucode']);
    $d_code = jhcis_pick_col($drug_cols, ['drugcode', 'icode']);
    $d_qty = jhcis_pick_col($drug_cols, ['qty']);
    if (!$d_qty && isset($drug_cols['unit'])) {
        $d_qty = 'unit';
    }
    $d_usage = jhcis_pick_col($drug_cols, ['drugusage', 'usagecode', 'dose']);
    if (!$v_visitno || !$v_date || !$v_pid || !$d_visitno || !$d_code) {
        jhcis_close($jhcis);
        $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
        $out['error'] = 'โครงสร้างตาราง visit/visitdrug ไม่ครบ';
        return $out;
    }

    $has_cdrug = jhcis_table_exists($jhcis, 'cdrug');
    $cdrug_cols = $has_cdrug ? jhcis_column_names($jhcis, 'cdrug') : [];
    $cdrug_code = jhcis_pick_col($cdrug_cols, ['drugcode']);
    $cdrug_name = jhcis_pick_col($cdrug_cols, ['drugname', 'drugnamethai', 'name', 'namedrug']);
    $cdrug_name_th = jhcis_pick_col($cdrug_cols, ['drugnamethai']);
    $cdrug_str = jhcis_pick_col($cdrug_cols, ['strength', 'unitsize']);
    $cdrug_unitusage = jhcis_pick_col($cdrug_cols, ['unitusage']);
    $cdrug_unitsell = jhcis_pick_col($cdrug_cols, ['unitsell']);
    $cdrug_unitpack = jhcis_pick_col($cdrug_cols, ['unitpacking']);

    $has_unitsell_lut = jhcis_table_exists($jhcis, 'cdrugunitsell');
    $usell_cols = $has_unitsell_lut ? jhcis_column_names($jhcis, 'cdrugunitsell') : [];
    $usell_code = jhcis_pick_col($usell_cols, ['unitsellcode', 'unitcode', 'code']);
    $usell_name = jhcis_pick_col($usell_cols, ['unitsellname', 'unitname', 'name']);

    $has_usage = $d_usage && jhcis_table_exists($jhcis, 'cdrugusage');
    $usage_cols = $has_usage ? jhcis_column_names($jhcis, 'cdrugusage') : [];
    $usage_code = jhcis_pick_col($usage_cols, ['drugusage', 'usagecode', 'code']);
    $usage_name = jhcis_pick_col($usage_cols, ['drugusagename', 'name1', 'drugusageename', 'name']);
    $usage_concat = [];
    foreach (['name1', 'name2', 'name3'] as $p) {
        if (isset($usage_cols[$p])) {
            $usage_concat[] = $p;
        }
    }

    $pid_esc = mysqli_real_escape_string($jhcis, trim((string)$person['pid']));
    $pcu_esc = mysqli_real_escape_string($jhcis, trim((string)($person['pcucode'] ?? '')));
    $date_ident = jhcis_ident($v_date);
    $date_filter = '';
    if ($months > 0) {
        $date_filter = " AND v.$date_ident >= DATE_SUB(CURDATE(), INTERVAL $months MONTH) ";
    }

    $person_join = "v." . jhcis_ident($v_pid) . " = '$pid_esc'";
    if ($v_pcu_person && $pcu_esc !== '') {
        $person_join .= " AND v." . jhcis_ident($v_pcu_person) . " = '$pcu_esc'";
    }

    $join_drug = "vd." . jhcis_ident($d_visitno) . " = v." . jhcis_ident($v_visitno);
    if ($d_pcu && $v_pcu) {
        $join_drug .= " AND vd." . jhcis_ident($d_pcu) . " = v." . jhcis_ident($v_pcu);
    }

    $name_sql = $has_cdrug && $cdrug_name
        ? "TRIM(IFNULL(d." . jhcis_ident($cdrug_name) . ", vd." . jhcis_ident($d_code) . "))"
        : "vd." . jhcis_ident($d_code);
    $name_th_sql = ($has_cdrug && $cdrug_name_th && $cdrug_name_th !== $cdrug_name)
        ? "TRIM(IFNULL(d." . jhcis_ident($cdrug_name_th) . ", ''))"
        : "''";
    $str_sql = $has_cdrug && $cdrug_str ? "TRIM(IFNULL(d." . jhcis_ident($cdrug_str) . ", ''))" : "''";

    $unit_parts = [];
    if ($has_unitsell_lut && $usell_name) {
        $unit_parts[] = "NULLIF(TRIM(IFNULL(us." . jhcis_ident($usell_name) . ", '')), '')";
    }
    if ($has_cdrug && $cdrug_unitusage) {
        $unit_parts[] = "NULLIF(TRIM(IFNULL(d." . jhcis_ident($cdrug_unitusage) . ", '')), '')";
    }
    if ($has_cdrug && $cdrug_unitsell) {
        $unit_parts[] = "NULLIF(TRIM(IFNULL(d." . jhcis_ident($cdrug_unitsell) . ", '')), '')";
    }
    if ($has_cdrug && $cdrug_unitpack) {
        $unit_parts[] = "NULLIF(TRIM(IFNULL(d." . jhcis_ident($cdrug_unitpack) . ", '')), '')";
    }
    $unit_sql = $unit_parts ? ('COALESCE(' . implode(', ', $unit_parts) . ", '')") : "''";

    $qty_sql = $d_qty ? "vd." . jhcis_ident($d_qty) : "0";

    $usage_text_sql = null;
    if ($has_usage && count($usage_concat) >= 2) {
        $concat_bits = [];
        foreach ($usage_concat as $p) {
            $concat_bits[] = "IFNULL(du." . jhcis_ident($p) . ", '')";
        }
        $usage_text_sql = "TRIM(CONCAT(" . implode(", ' ', ", $concat_bits) . "))";
    } elseif ($has_usage && $usage_name) {
        $usage_text_sql = "TRIM(IFNULL(du." . jhcis_ident($usage_name) . ", ''))";
    }
    if ($usage_text_sql && $d_usage) {
        $method_sql = "TRIM(IFNULL(NULLIF($usage_text_sql, ''), IFNULL(vd." . jhcis_ident($d_usage) . ", '')))";
    } elseif ($d_usage) {
        $method_sql = "TRIM(IFNULL(vd." . jhcis_ident($d_usage) . ", ''))";
    } elseif ($usage_text_sql) {
        $method_sql = $usage_text_sql;
    } else {
        $method_sql = "''";
    }
    $time_sql = $v_time ? "TRIM(IFNULL(v." . jhcis_ident($v_time) . ", ''))" : "''";

    $join_cdrug = '';
    if ($has_cdrug && $cdrug_code) {
        $codeIdent = jhcis_ident($cdrug_code);
        $vdCode = 'vd.' . jhcis_ident($d_code);
        $resolved = "SELECT c1.$codeIdent FROM cdrug c1 WHERE c1.$codeIdent = $vdCode LIMIT 1";
        if (isset($cdrug_cols['drugcodeold'])) {
            $resolved = "COALESCE(($resolved), (SELECT c2.$codeIdent FROM cdrug c2 WHERE c2.`drugcodeold` = $vdCode ORDER BY c2.$codeIdent LIMIT 1))";
        }
        $join_cdrug = "LEFT JOIN cdrug d ON d.$codeIdent = ($resolved)";
    }
    $join_unitsell = ($has_cdrug && $has_unitsell_lut && $usell_code && $cdrug_unitsell)
        ? "LEFT JOIN cdrugunitsell us ON us." . jhcis_ident($usell_code) . " = d." . jhcis_ident($cdrug_unitsell)
        : '';
    $join_usage = ($has_usage && $usage_code && $d_usage)
        ? "LEFT JOIN cdrugusage du ON du." . jhcis_ident($usage_code) . " = vd." . jhcis_ident($d_usage)
        : '';

    $sql = "
        SELECT
            v." . jhcis_ident($v_visitno) . " AS visitno,
            v.$date_ident AS visitdate,
            $time_sql AS visittime,
            vd." . jhcis_ident($d_code) . " AS drugcode,
            $qty_sql AS qty,
            $name_sql AS drug_name,
            $name_th_sql AS drug_name_th,
            $str_sql AS strength,
            $unit_sql AS units,
            $method_sql AS method
        FROM visit v
        INNER JOIN visitdrug vd ON $join_drug
        $join_cdrug
        $join_unitsell
        $join_usage
        WHERE $person_join
          $date_filter
        ORDER BY v.$date_ident DESC, visitno DESC
        LIMIT $limit
    ";
    $q = jhcis_query($jhcis, $sql);
    if (!$q) {
        $out['error'] = 'อ่าน visitdrug ไม่ได้';
        $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
        jhcis_close($jhcis);
        return $out;
    }

    $hosp_code = 'jhcis';
    $hosp_name = $out['name'];
    $history = [];
    $visits_map = [];
    while ($row = mysqli_fetch_assoc($q)) {
        $vn = trim((string)($row['visitno'] ?? ''));
        if ($vn === '') {
            continue;
        }
        $raw_date = trim((string)($row['visitdate'] ?? ''));
        $ts = strtotime($raw_date);
        if (!$ts) {
            continue;
        }
        $be_year = (int)date('Y', $ts) + 543;
        $iso = date('Y-m-d', $ts);
        $disp = date('d/m/', $ts) . $be_year;
        $time_raw = trim((string)($row['visittime'] ?? ''));
        if (preg_match('/(\d{1,2}:\d{2}(?::\d{2})?)/', $time_raw, $m)) {
            $time_disp = strlen($m[1]) === 5 ? $m[1] . ':00' : $m[1];
        } else {
            $time_disp = '';
        }
        $visit_key = $hosp_code . ':opd:' . $vn;
        $name = trim((string)($row['drug_name'] ?? ''));
        $name_th = trim((string)($row['drug_name_th'] ?? ''));
        $units = jhcis_readable_unit($row['units'] ?? '');
        $strength = trim((string)($row['strength'] ?? ''));
        if ($strength === '' || jhcis_is_code_like($strength)) {
            $strength = jhcis_extract_strength_from_name($name);
        }
        if ($strength === '') {
            $strength = jhcis_extract_strength_from_name($name_th);
        }
        $method = trim((string)($row['method'] ?? ''));
        if (jhcis_is_code_like($method)) {
            $method = '';
        }
        $item = [
            'vn' => $vn,
            'an' => '',
            'vstdate' => $iso,
            'vsttime' => $time_disp,
            'rxdate' => $iso,
            'rxtime' => $time_disp,
            'order_no' => '',
            'item_type' => '',
            'order_type' => '',
            'item_no' => '',
            'icode' => trim((string)($row['drugcode'] ?? '')),
            'qty' => (float)($row['qty'] ?? 0),
            'drug_name_local' => $name,
            'strength_local' => $strength,
            'drug_name' => $name,
            'strength' => $strength,
            'units' => $units,
            'method' => $method,
            'vstdate_iso' => $iso,
            'vstdate_display' => $disp,
            'vsttime_display' => $time_disp,
            'numeric_mg_value' => null,
            'order_date_iso' => $iso,
            'order_date_display' => $disp,
            'order_time_display' => $time_disp,
            'order_sort_key' => $iso . ' ' . str_pad(substr($time_disp, 0, 8), 8, '0'),
            'is_hme' => false,
            'is_chronic' => false,
            'visit_key' => $visit_key,
            'visit_type' => 'opd',
            'hospital_code' => $hosp_code,
            'hospital_name' => $hosp_name,
        ];
        $history[] = $item;
        if (!isset($visits_map[$visit_key])) {
            $visits_map[$visit_key] = [
                'visit_key' => $visit_key,
                'visit_type' => 'opd',
                'vn' => $vn,
                'an' => '',
                'vstdate_iso' => $iso,
                'vstdate_display' => $disp,
                'vsttime_display' => $time_disp,
                'drug_count' => 0,
                'ward_name' => '',
                'admit_date' => '',
                'hospital_code' => $hosp_code,
                'hospital_name' => $hosp_name,
            ];
        }
        $visits_map[$visit_key]['drug_count']++;
    }

    jhcis_close($jhcis);
    $out['ok'] = true;
    $out['history'] = $history;
    $out['visit_list'] = array_values($visits_map);
    $out['rows'] = count($history);
    $out['visits'] = count($visits_map);
    $out['ms'] = (int)round((microtime(true) - $t0) * 1000);
    return $out;
}

function jhcis_fold_key($text) {
    $t = trim((string)$text);
    $t = preg_replace('/\s+/u', ' ', $t);
    if (function_exists('mb_strtolower')) {
        return mb_strtolower($t, 'UTF-8');
    }
    return strtolower($t);
}

function jhcis_allergy_is_denial($text) {
    $t = trim((string)$text);
    if ($t === '' || $t === '-' || $t === '0') {
        return true;
    }
    return (bool)preg_match('/^(ปฏิเสธ|ปฎิเสธ|ปฏฺเสธ|ไม่มีประวัติ|ไม่มี|ไม่แพ้|ไม่เคยแพ้|nka|nkda|none|no\s*known)/iu', $t);
}

/**
 * ประวัติแพ้ยาจาก JHCIS PCC — จับคู่ด้วยเลขบัตรประชาชน อ่านอย่างเดียว
 * คืนรายการยาที่แพ้จริง ไม่รวมข้อความปฏิเสธการแพ้
 */
function jhcis_fetch_allergy($con, $cid) {
    $cid = preg_replace('/\D+/', '', (string)$cid);
    $out = ['ok' => false, 'rows' => [], 'error' => ''];
    if (strlen($cid) !== 13) {
        $out['error'] = 'ไม่มีเลขบัตร';
        return $out;
    }
    $jhcis = jhcis_connect($con, 15);
    if (!$jhcis) {
        $out['error'] = 'เชื่อมต่อ JHCIS ไม่ได้';
        return $out;
    }
    if (!jhcis_table_exists($jhcis, 'person') || !jhcis_table_exists($jhcis, 'personalergic')) {
        jhcis_close($jhcis);
        $out['error'] = 'ไม่พบตารางแพ้ยาใน JHCIS';
        return $out;
    }
    $cid_sql = "'" . mysqli_real_escape_string($jhcis, $cid) . "'";
    $idcard = "REPLACE(REPLACE(REPLACE(TRIM(p.idcard), '-', ''), ' ', ''), '.', '')";
    $has_drug = jhcis_table_exists($jhcis, 'cdrug');
    $has_sym = jhcis_table_exists($jhcis, 'cdrugallergysymtom');
    $has_hos = jhcis_table_exists($jhcis, 'chospital');
    $name_sql = $has_drug
        ? "TRIM(IFNULL(d.drugnamethai, '')) AS drugnamethai, TRIM(IFNULL(d.drugname, '')) AS drugname"
        : "'' AS drugnamethai, '' AS drugname";
    $sym_sql = $has_sym ? "TRIM(IFNULL(s.symtomname, '')) AS symptom" : "'' AS symptom";
    $hos_sql = $has_hos ? "TRIM(IFNULL(h.hosname, '')) AS hosname" : "'' AS hosname";
    $join_drug = $has_drug ? 'LEFT JOIN cdrug d ON d.drugcode = a.drugcode' : '';
    $join_sym = $has_sym ? 'LEFT JOIN cdrugallergysymtom s ON s.symtomcode = a.symptom' : '';
    $join_hos = $has_hos ? 'LEFT JOIN chospital h ON h.hoscode = a.pcucodeperson' : '';
    $sql = "SELECT TRIM(a.drugcode) AS drugcode, $name_sql, $sym_sql, $hos_sql
            FROM personalergic a
            INNER JOIN person p ON p.pcucodeperson = a.pcucodeperson AND p.pid = a.pid
            $join_drug
            $join_sym
            $join_hos
            WHERE $idcard = $cid_sql
            ORDER BY a.daterecord DESC
            LIMIT 40";
    $q = jhcis_query($jhcis, $sql);
    $rows = [];
    $seen = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $agent = trim((string)($r['drugnamethai'] ?? ''));
            if ($agent === '') {
                $agent = trim((string)($r['drugname'] ?? ''));
            }
            if ($agent === '') {
                $agent = trim((string)($r['drugcode'] ?? ''));
            }
            if (jhcis_allergy_is_denial($agent)) {
                continue;
            }
            $key = jhcis_fold_key($agent);
            if ($key === '' || isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $place = trim((string)($r['hosname'] ?? ''));
            if ($place === '') {
                $place = 'JHCIS';
            }
            $rows[] = [
                'agent' => $agent,
                'symptom' => trim((string)($r['symptom'] ?? '')),
                'hospital_name' => $place,
                'source_kind' => 'jhcis',
            ];
        }
    }
    $hos_free = $has_hos ? "TRIM(IFNULL(h.hosname, '')) AS hosname" : "'' AS hosname";
    $join_free = $has_hos ? 'LEFT JOIN chospital h ON h.hoscode = p.pcucodeperson' : '';
    $qf = jhcis_query($jhcis, "SELECT TRIM(p.allergic) AS allergic, $hos_free
            FROM person p
            $join_free
            WHERE $idcard = $cid_sql
              AND p.allergic IS NOT NULL AND TRIM(p.allergic) <> ''
            LIMIT 20");
    if ($qf) {
        while ($r = mysqli_fetch_assoc($qf)) {
            $text = trim((string)($r['allergic'] ?? ''));
            if (jhcis_allergy_is_denial($text) || jhcis_allergy_text_redundant($text, $seen)) {
                continue;
            }
            $key = jhcis_fold_key($text);
            if ($key === '' || isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $place = trim((string)($r['hosname'] ?? ''));
            if ($place === '') {
                $place = 'JHCIS';
            }
            $rows[] = [
                'agent' => $text,
                'symptom' => '',
                'hospital_name' => $place,
                'source_kind' => 'jhcis',
            ];
        }
    }
    jhcis_close($jhcis);
    $out['ok'] = true;
    $out['rows'] = $rows;
    return $out;
}

/**
 * นัดหมายจาก JHCIS PCC (oappoint) — จับคู่ด้วยเลขบัตรประชาชน อ่านอย่างเดียว
 */
function jhcis_fetch_appointments($con, $cid) {
    $cid = preg_replace('/\D+/', '', (string)$cid);
    $out = ['ok' => false, 'rows' => [], 'error' => ''];
    if (strlen($cid) !== 13) {
        $out['error'] = 'ไม่มีเลขบัตร';
        return $out;
    }
    $jhcis = jhcis_connect($con, 15);
    if (!$jhcis) {
        $out['error'] = 'เชื่อมต่อ JHCIS ไม่ได้';
        return $out;
    }
    if (!jhcis_table_exists($jhcis, 'oappoint') || !jhcis_table_exists($jhcis, 'person')) {
        jhcis_close($jhcis);
        $out['error'] = 'ไม่พบตารางนัดใน JHCIS';
        return $out;
    }
    $cid_sql = "'" . mysqli_real_escape_string($jhcis, $cid) . "'";
    $idcard = "REPLACE(REPLACE(REPLACE(TRIM(p.idcard), '-', ''), ' ', ''), '.', '')";
    $has_hos = jhcis_table_exists($jhcis, 'chospital');
    $has_visit = jhcis_table_exists($jhcis, 'visit');
    $hos_sql = $has_hos ? "TRIM(IFNULL(h.hosname, '')) AS hosname" : "'' AS hosname";
    $join_visit = $has_visit ? 'INNER JOIN visit v ON v.visitno = a.visitno AND v.pid = a.pid' : '';
    $join_person = $has_visit
        ? 'INNER JOIN person p ON p.pid = v.pid AND p.pcucodeperson = v.pcucodeperson'
        : 'INNER JOIN person p ON p.pid = a.pid';
    $join_hos = $has_hos ? 'LEFT JOIN chospital h ON h.hoscode = p.pcucodeperson' : '';
    $sql = "SELECT TRIM(a.visitno) AS visitno, a.visitdate, a.nextvisitdate, a.nextvisittime,
                   TRIM(IFNULL(a.clinic, '')) AS clinic, $hos_sql
            FROM oappoint a
            $join_visit
            $join_person
            $join_hos
            WHERE $idcard = $cid_sql
              AND a.nextvisitdate IS NOT NULL AND a.nextvisitdate <> '0000-00-00'
            ORDER BY a.nextvisitdate DESC
            LIMIT 80";
    $q = jhcis_query($jhcis, $sql);
    $rows = [];
    $seen = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $next = substr(trim((string)($r['nextvisitdate'] ?? '')), 0, 10);
            $vst = substr(trim((string)($r['visitdate'] ?? '')), 0, 10);
            if ($next === '' || $next === '0000-00-00') {
                continue;
            }
            if ($vst === '0000-00-00') {
                $vst = '';
            }
            $vn = trim((string)($r['visitno'] ?? ''));
            $place = trim((string)($r['hosname'] ?? ''));
            if ($place === '') {
                $place = 'JHCIS';
            }
            $clinic = trim((string)($r['clinic'] ?? ''));
            if ($clinic !== '' && preg_match('/^\d+$/', $clinic)) {
                $clinic = '';
            }
            $key = $vst . '|' . $next . '|' . $vn . '|' . $place;
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $rows[] = [
                'vn' => $vn,
                'an' => '',
                'vstdate' => $vst,
                'nextdate' => $next,
                'nexttime' => substr(trim((string)($r['nextvisittime'] ?? '')), 0, 8),
                'clinic_name' => $clinic !== '' ? $clinic : $place,
                'hospital_code' => 'jhcis',
                'hospital_name' => $place,
            ];
        }
        $out['ok'] = true;
    } else {
        $out['error'] = 'อ่านนัด JHCIS ไม่ได้';
    }
    $out['rows'] = $rows;
    jhcis_close($jhcis);
    return $out;
}

function jhcis_allergy_text_redundant($text, array $seen_keys) {
    $fold = jhcis_fold_key($text);
    if ($fold === '' || isset($seen_keys[$fold])) {
        return true;
    }
    $rest = $fold;
    foreach ($seen_keys as $key => $on) {
        if (!$on || $key === '') {
            continue;
        }
        $rest = str_replace($key, ' ', $rest);
    }
    $rest = preg_replace('/(แพ้ยา|แพ้|และ|กับ|อาหาร)/u', '', $rest);
    $rest = preg_replace('/[^a-z0-9ก-๙]+/u', '', $rest);
    return $rest === '';
}
