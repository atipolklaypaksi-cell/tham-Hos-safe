<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/hospital_ds_helper.php';
mysqli_set_charset($con, 'utf8');
hds_ensure_tables($con);
$items = hds_list($con, '');
$grafana = hds_grafana_public_config(hds_grafana_get_config($con));
$connect_mode = hds_connect_mode($con);
$home_code = hds_home_code($con);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เชื่อมต่อรพ. ต่างๆ - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .hds-hero {
            background: linear-gradient(135deg, #111827 0%, #1e3a5f 55%, #2563eb 100%);
            color: #fff; border-radius: 16px; padding: 1.2rem 1.4rem; margin-bottom: 1.1rem;
        }
        .hds-badge { background: rgba(255,255,255,.16); border: 1px solid rgba(255,255,255,.28); }
        .hds-row {
            display: flex; align-items: center; gap: 1rem; padding: .85rem 1rem;
            border: 1px solid #e5e7eb; border-radius: 12px; background: #fff; margin-bottom: .65rem;
        }
        .hds-row:hover { border-color: #93c5fd; box-shadow: 0 4px 14px rgba(37,99,235,.08); }
        .hds-mysql {
            width: 42px; height: 42px; border-radius: 10px; flex: 0 0 42px;
            background: #00758f; color: #fff; display: flex; align-items: center; justify-content: center;
            font-weight: 800; font-size: .72rem;
        }
        .hds-meta { color: #6b7280; font-size: .82rem; }
        .hds-dot { width: 9px; height: 9px; border-radius: 50%; display: inline-block; margin-right: 6px; background: #d1d5db; }
        .hds-dot.ok { background: #16a34a; }
        .hds-dot.bad { background: #dc2626; }
        code.small { font-size: .78rem; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="hds-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="small text-uppercase" style="letter-spacing:.08em;opacity:.75;">ตั้งค่าระบบ · Data sources</div>
                    <h4 class="fw-bold mb-1">เชื่อมต่อรพ. ต่างๆ ในจังหวัด</h4>
                    <p class="mb-0 small" style="opacity:.92;">เลือกช่องทางได้ทั้งระบบ ติดตั้งที่รพ.สมเด็จพระยุพราชสระแก้วใช้ต่อตรงได้ ถ้านำเว็บไปใช้ที่รพ.อื่นให้เลือกผ่าน Grafana</p>
                </div>
                <div class="d-flex flex-column align-items-end gap-1">
                    <span class="badge hds-badge px-3 py-2 fs-6"><i class="fas fa-lock me-1"></i> Read Only</span>
                    <span class="badge hds-badge">กลุ่มรพ. จังหวัดสระแก้ว</span>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body py-3">
                    <div class="fw-bold mb-2"><i class="fas fa-random me-1 text-primary"></i> ช่องทางเชื่อมโรงพยาบาล</div>
                    <div class="row g-2 align-items-end">
                        <div class="col-md-4">
                            <label class="form-label small mb-1" for="hds_home">โรงพยาบาลที่ติดตั้งเว็บนี้</label>
                            <select class="form-select form-select-sm" id="hds_home">
                                <?php foreach ($items as $it): ?>
                                    <option value="<?php echo htmlspecialchars($it['code']); ?>" <?php echo $home_code === $it['code'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($it['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small mb-1" for="hds_mode">ใช้กับทุกโรงพยาบาลในหน้านี้</label>
                            <select class="form-select form-select-sm" id="hds_mode">
                                <option value="direct" <?php echo $connect_mode === 'direct' ? 'selected' : ''; ?>>อัตโนมัติ — Host ที่เป็น IP ต่อตรง, ชื่อจาก Grafana ยังคิวรีผ่าน Grafana</option>
                                <option value="mysql" <?php echo $connect_mode === 'mysql' ? 'selected' : ''; ?>>ต่อตรงทั้งหมด — ใช้ Host / User / Password ที่บันทึกไว้ ไม่ผ่าน Grafana</option>
                                <option value="grafana" <?php echo $connect_mode === 'grafana' ? 'selected' : ''; ?>>ผ่าน Grafana ทั้งหมด — ใช้เมื่อนำเว็บไปติดตั้งที่รพ.อื่น</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="button" class="btn btn-sm btn-primary" id="btnModeSave">บันทึกช่องทาง</button>
                        </div>
                    </div>
                    <div class="small text-muted mt-2" id="hdsModeHint">โรงพยาบาลที่ติดตั้งเว็บนี้ เมื่อเลือกต่อตรง จะใช้ Host, ฐานข้อมูล, ผู้ใช้ และรหัสจากหน้าเชื่อมต่อ HOSxP</div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body py-3">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
                        <div>
                            <div class="fw-bold"><i class="fas fa-cloud me-1 text-primary"></i> บัญชี Grafana (กลุ่มรพ. จังหวัดสระแก้ว)</div>
                            <div class="small text-muted">ใช้ดึง Host / Username / UID ของแต่ละรพ. แล้ว Explore ผ่าน Grafana ไม่ต้องรู้รหัส MySQL ของรพ.อื่น — Grafana 11 ใช้ Basic Auth / CSRF อัตโนมัติ ถ้ายัง 401 ให้ใส่ Service Account token ในช่องรหัส</div>
                        </div>
                        <span class="badge bg-light text-dark" id="gfStatus">ยังไม่ซิงก์</span>
                    </div>
                    <div class="row g-2 align-items-end">
                        <div class="col-md-5">
                            <label class="form-label small mb-1">URL</label>
                            <input type="text" class="form-control form-control-sm" id="gf_url" value="<?php echo htmlspecialchars($grafana['url'] ?? ''); ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small mb-1">User</label>
                            <input type="text" class="form-control form-control-sm" id="gf_user" value="<?php echo htmlspecialchars($grafana['user'] ?? ''); ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small mb-1">Password</label>
                            <input type="password" class="form-control form-control-sm" id="gf_pass" value="<?php echo !empty($grafana['has_pass']) ? '********' : ''; ?>" autocomplete="new-password">
                        </div>
                        <div class="col-md-3 d-flex gap-1">
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="btnGfSave">บันทึก</button>
                            <button type="button" class="btn btn-sm btn-primary" id="btnGfSync"><i class="fas fa-sync-alt me-1"></i> ซิงก์จาก Grafana</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
                <div class="input-group" style="max-width:360px;">
                    <span class="input-group-text bg-white"><i class="fas fa-search"></i></span>
                    <input type="text" class="form-control" id="q" placeholder="ค้นหาชื่อ รหัส หรือ host">
                </div>
                <button type="button" class="btn btn-outline-secondary" id="btnPingAll"><i class="fas fa-heartbeat me-1"></i> ตรวจสถานะที่เลือก</button>
                <button type="button" class="btn btn-primary ms-auto" id="btnAdd"><i class="fas fa-plus me-1"></i> เพิ่มแหล่งข้อมูล</button>
            </div>

            <div id="listBox">
                <?php if (empty($items)): ?>
                    <div class="text-muted p-3">ยังไม่มีแหล่งข้อมูล</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <form id="editForm">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="editTitle">เพิ่มแหล่งข้อมูล</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="f_id" value="0">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">รหัส (เช่น scph)</label>
                            <input type="text" class="form-control" id="f_code" required>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label small fw-bold">ชื่อโรงพยาบาล</label>
                            <input type="text" class="form-control" id="f_name" required>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label small fw-bold">Host / IP</label>
                            <input type="text" class="form-control" id="f_host" placeholder="IP เช่น 192.168.65.2 หรือชื่อใน Grafana เช่น mysql-kck">
                            <div class="form-text">รพ.อื่นไม่ต้องใส่ IP — กดซิงก์จาก Grafana ด้านบน</div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Port</label>
                            <input type="number" class="form-control" id="f_port" value="3306">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Database</label>
                            <input type="text" class="form-control" id="f_db" value="hos">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Username</label>
                            <input type="text" class="form-control" id="f_user" placeholder="phpapi หรือ Grafana">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Password</label>
                            <input type="password" class="form-control" id="f_pass" value="" autocomplete="new-password">
                            <div class="form-text">เว้น ******** ไว้ถ้าไม่เปลี่ยนรหัส</div>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small fw-bold">ชื่อใน Grafana (ถ้ามี)</label>
                            <input type="text" class="form-control" id="f_grafana" placeholder="เช่น mysql-scph">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">ช่องทางของรพ.นี้</label>
                            <select class="form-select" id="f_via">
                                <option value="auto">ตามการตั้งค่าทั้งระบบ</option>
                                <option value="direct">ต่อตรง</option>
                                <option value="grafana">ผ่าน Grafana</option>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="f_active" checked>
                                <label class="form-check-label" for="f_active">เปิดใช้งาน</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <hr class="my-1">
                            <div class="fw-bold small">Additional settings</div>
                            <div class="text-muted" style="font-size:.78rem;">MySQL options และ Connection limits แบบเดียวกับ Grafana — รพ.ที่คิวรีผ่าน Grafana จะอัปเดตค่าที่ Grafana ด้วย</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Session timezone</label>
                            <input type="text" class="form-control" id="f_tz" placeholder="เช่น Asia/Bangkok หรือ +07:00">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Min time interval</label>
                            <input type="text" class="form-control" id="f_interval" value="1m" placeholder="1m">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Max open</label>
                            <input type="number" class="form-control" id="f_max_open" min="0" value="200">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Max idle</label>
                            <input type="number" class="form-control" id="f_max_idle" min="0" value="200">
                            <div class="form-check form-switch mt-1">
                                <input class="form-check-input" type="checkbox" id="f_max_idle_auto" checked>
                                <label class="form-check-label small" for="f_max_idle_auto">Auto max idle</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Max lifetime</label>
                            <input type="number" class="form-control" id="f_max_lifetime" min="0" value="14400">
                            <div class="form-text">วินาที (ค่าใน Grafana ตอนนี้ 14400)</div>
                        </div>
                    </div>
                    <div class="alert alert-info small mt-3 mb-0">
                        บังคับอ่านอย่างเดียว: อนุญาต SELECT / SHOW / DESCRIBE เท่านั้น ไม่เขียนฐานต้นทาง
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-primary" id="btnTestForm"><i class="fas fa-plug me-1"></i> ทดสอบ</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i> บันทึก</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const API = 'fetch_hospital_connect_api.php';
let items = <?php echo json_encode($items, JSON_UNESCAPED_UNICODE); ?>;
let grafana = <?php echo json_encode($grafana, JSON_UNESCAPED_UNICODE); ?>;
let connectMode = <?php echo json_encode($connect_mode, JSON_UNESCAPED_UNICODE); ?>;
const modal = new bootstrap.Modal(document.getElementById('editModal'));

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function api(action, extra) {
    return fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ action: action }, extra || {}))
    }).then(async function (res) {
        const text = await res.text();
        try { return JSON.parse(text); }
        catch (e) { throw new Error('API ตอบกลับไม่ใช่ JSON'); }
    });
}
function statusDot(it) {
    if (it.last_ok === 1) return '<span class="hds-dot ok" title="เชื่อมได้"></span>';
    if (it.last_ok === 0) return '<span class="hds-dot bad" title="เชื่อมไม่ได้"></span>';
    return '<span class="hds-dot" title="ยังไม่ทดสอบ"></span>';
}
function render(list) {
    const box = document.getElementById('listBox');
    if (!list.length) {
        box.innerHTML = '<div class="text-muted p-3">ไม่พบแหล่งข้อมูล</div>';
        return;
    }
    box.innerHTML = list.map(function (it) {
        const viaGrafana = it.via === 'grafana';
        const host = (it.host || (viaGrafana ? 'รอซิงก์จาก Grafana' : 'ยังไม่ใส่ Host')) + ':' + (it.port || 3306);
        const viaBadge = viaGrafana
            ? ' <span class="badge bg-info text-dark">ผ่าน Grafana</span>'
            : ' <span class="badge bg-success">เชื่อมตรง</span>';
        const checked = it.last_checked_at
            ? (it.last_ok ? ('เชื่อมได้ · ' + (it.last_ms || 0) + ' ms') : ('ล้มเหลว: ' + (it.last_error || '')))
            : 'ยังไม่ทดสอบ';
        return '<div class="hds-row" data-id="' + it.id + '">'
            + '<div class="hds-mysql">SQL</div>'
            + '<div class="flex-grow-1">'
            + '<div class="fw-bold">' + statusDot(it) + esc(it.name)
            + ' <code class="small text-muted">' + esc(it.grafana_uid || ('mysql-' + it.code)) + '</code>'
            + viaBadge
            + (it.uses_hosxp_setting ? ' <span class="badge bg-primary">ค่าจากเชื่อมต่อ HOSxP</span>' : '')
            + (it.is_home ? ' <span class="badge bg-dark">ติดตั้งที่นี่</span>' : '')
            + '</div>'
            + '<div class="hds-meta">MySQL · ' + esc(host) + ' · ฐาน ' + esc(it.dbname)
            + ' · user ' + esc(it.username || '-')
            + '</div>'
            + '<div class="hds-meta">Max open ' + Number(it.max_open || 0)
            + ' · Max idle ' + Number(it.max_idle || 0) + (it.max_idle_auto ? ' (auto)' : '')
            + ' · Max lifetime ' + Number(it.max_lifetime || 0)
            + (it.min_interval ? (' · interval ' + esc(it.min_interval)) : '')
            + '</div>'
            + '<div class="hds-meta">' + esc(checked) + '</div>'
            + '</div>'
            + '<div class="d-flex flex-wrap gap-1 align-items-center">'
            + '<select class="form-select form-select-sm js-via" data-id="' + it.id + '" style="width:168px" title="ช่องทางของโรงพยาบาลนี้">'
            + '<option value="auto"' + ((it.connect_via || 'auto') === 'auto' ? ' selected' : '') + '>ตามระบบ</option>'
            + '<option value="direct"' + (it.connect_via === 'direct' ? ' selected' : '') + '>ต่อตรง</option>'
            + '<option value="grafana"' + (it.connect_via === 'grafana' ? ' selected' : '') + '>ผ่าน Grafana</option>'
            + '</select>'
            + '<button type="button" class="btn btn-sm btn-outline-secondary btn-edit">ตั้งค่า</button>'
            + '<button type="button" class="btn btn-sm btn-outline-primary btn-test">ทดสอบ</button>'
            + '<a class="btn btn-sm btn-primary" href="hospital_explore.php?id=' + it.id + '">Explore</a>'
            + '</div></div>';
    }).join('');
}
function filtered() {
    const q = document.getElementById('q').value.trim().toLowerCase();
    if (!q) return items.slice();
    return items.filter(function (it) {
        return [it.name, it.code, it.host, it.dbname, it.grafana_uid].join(' ').toLowerCase().indexOf(q) >= 0;
    });
}
function fillForm(it) {
    document.getElementById('editTitle').textContent = it ? 'ตั้งค่า ' + it.name : 'เพิ่มแหล่งข้อมูล';
    document.getElementById('f_id').value = it ? it.id : 0;
    document.getElementById('f_code').value = it ? it.code : '';
    document.getElementById('f_name').value = it ? it.name : '';
    document.getElementById('f_host').value = it ? it.host : '';
    document.getElementById('f_port').value = it ? it.port : 3306;
    document.getElementById('f_db').value = it ? it.dbname : 'hos';
    document.getElementById('f_user').value = it ? it.username : '';
    document.getElementById('f_pass').value = it && it.has_password ? '********' : '';
    document.getElementById('f_grafana').value = it ? (it.grafana_uid || '') : '';
    document.getElementById('f_via').value = it ? (it.connect_via || 'auto') : 'auto';
    document.getElementById('f_active').checked = !it || it.active !== 0;
    document.getElementById('f_tz').value = it ? (it.session_tz || '') : '';
    document.getElementById('f_interval').value = it ? (it.min_interval || '1m') : '1m';
    document.getElementById('f_max_open').value = it ? (it.max_open || 200) : 200;
    document.getElementById('f_max_idle').value = it ? (it.max_idle || 200) : 200;
    document.getElementById('f_max_idle_auto').checked = !it || Number(it.max_idle_auto) !== 0;
    document.getElementById('f_max_lifetime').value = it ? (it.max_lifetime || 14400) : 14400;
    syncIdleAuto();
}
function syncIdleAuto() {
    const auto = document.getElementById('f_max_idle_auto').checked;
    const idle = document.getElementById('f_max_idle');
    idle.disabled = auto;
    if (auto) idle.value = document.getElementById('f_max_open').value || 200;
}
document.getElementById('f_max_idle_auto').addEventListener('change', syncIdleAuto);
document.getElementById('f_max_open').addEventListener('input', function () {
    if (document.getElementById('f_max_idle_auto').checked) {
        document.getElementById('f_max_idle').value = this.value || 200;
    }
});
function formBody() {
    return {
        id: Number(document.getElementById('f_id').value || 0),
        code: document.getElementById('f_code').value.trim(),
        name: document.getElementById('f_name').value.trim(),
        host: document.getElementById('f_host').value.trim(),
        port: document.getElementById('f_port').value.trim(),
        dbname: document.getElementById('f_db').value.trim(),
        username: document.getElementById('f_user').value.trim(),
        password: document.getElementById('f_pass').value,
        grafana_uid: document.getElementById('f_grafana').value.trim(),
        connect_via: document.getElementById('f_via').value,
        active: document.getElementById('f_active').checked ? 1 : 0,
        session_tz: document.getElementById('f_tz').value.trim(),
        min_interval: document.getElementById('f_interval').value.trim(),
        max_open: document.getElementById('f_max_open').value,
        max_idle: document.getElementById('f_max_idle').value,
        max_idle_auto: document.getElementById('f_max_idle_auto').checked ? 1 : 0,
        max_lifetime: document.getElementById('f_max_lifetime').value
    };
}
document.getElementById('q').addEventListener('input', function () { render(filtered()); });
document.getElementById('btnAdd').addEventListener('click', function () {
    fillForm(null);
    modal.show();
});
document.getElementById('listBox').addEventListener('change', function (e) {
    const sel = e.target.closest('.js-via');
    if (!sel) return;
    const id = Number(sel.getAttribute('data-id'));
    sel.disabled = true;
    api('connect_via_save', { id: id, connect_via: sel.value }).then(function (data) {
        if (data.item) {
            items = items.map(function (x) { return x.id === id ? data.item : x; });
            render(filtered());
        } else if (data.status !== 'success') {
            alert('❌ ' + (data.message || 'บันทึกช่องทางไม่สำเร็จ'));
        }
    }).catch(function (err) {
        alert('❌ ' + (err.message || 'บันทึกช่องทางไม่สำเร็จ'));
        sel.disabled = false;
    });
});
document.getElementById('listBox').addEventListener('click', function (e) {
    const row = e.target.closest('.hds-row');
    if (!row) return;
    const id = Number(row.getAttribute('data-id'));
    const it = items.find(function (x) { return x.id === id; });
    if (e.target.closest('.btn-edit')) {
        fillForm(it);
        modal.show();
    }
    if (e.target.closest('.btn-test')) {
        const btn = e.target.closest('.btn-test');
        btn.disabled = true;
        api('test', { id: id }).then(function (data) {
            alert((data.status === 'success' ? '✅ ' : '❌ ') + data.message);
            if (data.item) {
                items = items.map(function (x) { return x.id === id ? data.item : x; });
                render(filtered());
            }
        }).catch(function (err) {
            alert('❌ ' + (err.message || 'ทดสอบไม่สำเร็จ'));
        }).finally(function () { btn.disabled = false; });
    }
});
document.getElementById('editForm').addEventListener('submit', function (e) {
    e.preventDefault();
    api('save', formBody()).then(function (data) {
        alert((data.status === 'success' ? '✅ ' : '❌ ') + data.message);
        if (data.status === 'success') {
            return api('list').then(function (res) {
                items = res.items || [];
                render(filtered());
                modal.hide();
            });
        }
    }).catch(function () { alert('❌ บันทึกไม่สำเร็จ'); });
});
document.getElementById('btnTestForm').addEventListener('click', function () {
    const body = formBody();
    if (!body.id) {
        alert('บันทึกก่อนแล้วจึงทดสอบได้ หรือใส่ Host ให้ครบแล้วบันทึก');
        return;
    }
    api('test', body).then(function (data) {
        alert((data.status === 'success' ? '✅ ' : '❌ ') + data.message);
    }).catch(function (err) {
        alert('❌ ' + (err.message || 'ทดสอบไม่สำเร็จ'));
    });
});
document.getElementById('btnPingAll').addEventListener('click', async function () {
    const btn = this;
    btn.disabled = true;
    const list = filtered();
    for (const it of list) {
        try {
            const data = await api('test', { id: it.id });
            if (data.item) {
                items = items.map(function (x) { return x.id === it.id ? data.item : x; });
            }
        } catch (e) {}
        render(filtered());
    }
    btn.disabled = false;
});
function syncModeHint() {
    const mode = document.getElementById('hds_mode').value;
    const hint = {
        grafana: 'ทุกโรงพยาบาลคิวรีผ่าน Grafana เหมาะกับเครื่องที่เข้า MySQL ของรพ.อื่นไม่ได้',
        mysql: 'ทุกโรงพยาบาลต่อ MySQL ตรง โรงพยาบาลที่ติดตั้งเว็บนี้ใช้ค่าจากหน้าเชื่อมต่อ HOSxP รพ.อื่นใช้ Host ที่บันทึกไว้',
        direct: 'Host ที่เป็น IP ต่อตรง โรงพยาบาลที่ติดตั้งเว็บนี้ถ้าเลือกต่อตรงที่แถวนั้น จะใช้ค่าจากหน้าเชื่อมต่อ HOSxP ไม่ใช้ชื่อ mysql- จาก Grafana'
    };
    document.getElementById('hdsModeHint').textContent = hint[mode] || hint.direct;
}
document.getElementById('hds_mode').addEventListener('change', syncModeHint);
syncModeHint();
document.getElementById('btnModeSave').addEventListener('click', function () {
    const btn = this;
    btn.disabled = true;
    api('connect_mode_save', {
        mode: document.getElementById('hds_mode').value,
        home_code: document.getElementById('hds_home').value
    }).then(function (data) {
        connectMode = data.mode || document.getElementById('hds_mode').value;
        if (data.items) items = data.items;
        render(filtered());
        alert((data.status === 'success' ? '✅ ' : '❌ ') + data.message);
    }).catch(function (err) {
        alert('❌ ' + (err.message || 'บันทึกช่องทางไม่สำเร็จ'));
    }).finally(function () { btn.disabled = false; });
});
function applyGrafana(g) {
    if (!g) return;
    grafana = g;
    if (g.url) document.getElementById('gf_url').value = g.url;
    if (g.user) document.getElementById('gf_user').value = g.user;
    if (g.has_pass) document.getElementById('gf_pass').value = '********';
}
document.getElementById('btnGfSave').addEventListener('click', function () {
    const btn = this;
    btn.disabled = true;
    api('grafana_save', {
        url: document.getElementById('gf_url').value.trim(),
        user: document.getElementById('gf_user').value.trim(),
        pass: document.getElementById('gf_pass').value
    }).then(function (data) {
        applyGrafana(data.grafana);
        alert((data.status === 'success' ? '✅ ' : '❌ ') + data.message);
    }).catch(function (err) {
        alert('❌ ' + (err.message || 'บันทึก Grafana ไม่สำเร็จ'));
    }).finally(function () { btn.disabled = false; });
});
document.getElementById('btnGfSync').addEventListener('click', function () {
    const btn = this;
    btn.disabled = true;
    document.getElementById('gfStatus').textContent = 'กำลังซิงก์…';
    api('grafana_sync', {
        url: document.getElementById('gf_url').value.trim(),
        user: document.getElementById('gf_user').value.trim(),
        pass: document.getElementById('gf_pass').value
    }).then(function (data) {
        applyGrafana(data.grafana);
        if (data.items) items = data.items;
        render(filtered());
        document.getElementById('gfStatus').textContent = data.status === 'success' ? data.message : (data.message || 'ซิงก์ไม่สำเร็จ');
        alert((data.status === 'success' ? '✅ ' : '❌ ') + data.message);
    }).catch(function (err) {
        document.getElementById('gfStatus').textContent = 'ซิงก์ไม่สำเร็จ';
        alert('❌ ' + (err.message || 'ซิงก์ไม่สำเร็จ'));
    }).finally(function () { btn.disabled = false; });
});
render(filtered());
if (items.some(function (it) { return it.via === 'grafana' && !it.grafana_ds_uid; })) {
    api('grafana_sync').then(function (data) {
        applyGrafana(data.grafana);
        if (data.items) items = data.items;
        render(filtered());
        document.getElementById('gfStatus').textContent = data.status === 'success' ? data.message : (data.message || 'ซิงก์ไม่สำเร็จ');
    }).catch(function () {
        document.getElementById('gfStatus').textContent = 'ซิงก์อัตโนมัติไม่สำเร็จ — กดปุ่มซิงก์';
    });
} else if (items.some(function (it) { return it.grafana_ds_uid; })) {
    document.getElementById('gfStatus').textContent = 'พร้อมใช้งานผ่าน Grafana';
}
</script>
</body>
</html>
