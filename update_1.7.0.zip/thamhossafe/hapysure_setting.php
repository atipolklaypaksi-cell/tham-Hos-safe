<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/hapysure_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.hapysure') && !tham_menu_can('admin.hosxp') && ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: home.php');
    exit;
}
hapysure_ensure_config($con);
$msg = '';
$msg_ok = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $saved = hapysure_save_config($con, [
        'hapysure_base_url' => trim((string)($_POST['hapysure_base_url'] ?? '')),
        'hapysure_login_path' => trim((string)($_POST['hapysure_login_path'] ?? '/login')),
    ]);
    $msg = 'บันทึก URL HAPYsure แล้ว';
    $msg_ok = true;
    $cfg = $saved;
} else {
    $cfg = hapysure_load_config($con);
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>เชื่อมต่อ HAPYsure - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="fw-bold text-dark mb-0"><i class="fas fa-notes-medical me-2" style="color:#0aa2c0;"></i>เชื่อมต่อ HAPYsure</h4>
        </div>
        <div class="card shadow-sm border-0" style="max-width:720px;">
            <div class="card-body p-4">
                <p class="text-muted">ใช้เมื่อกด <b>ยืนยันการคัดกรอง</b> ใน Patient OPD เพื่อเปิดหน้า CPOE ของ HAPYsure ตาม HN/VN ที่กำลังดู</p>
                <?php if ($msg !== ''): ?>
                    <div class="alert alert-<?php echo $msg_ok ? 'success' : 'danger'; ?>"><?php echo htmlspecialchars($msg, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <form method="post">
                    <label class="form-label fw-bold">URL ต้นทาง HAPYsure</label>
                    <input type="text" class="form-control" name="hapysure_base_url" value="<?php echo htmlspecialchars($cfg['hapysure_base_url'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="https://192.168.6.10:8443" required>
                    <div class="form-text">ตัวอย่างหน้า CPOE: <code>/cpoe-detail?hn=...&amp;vn=...&amp;vstdate=...&amp;status=NEW</code></div>
                    <label class="form-label fw-bold mt-3">เส้นทางหน้า login HAPYsure</label>
                    <input type="text" class="form-control" name="hapysure_login_path" value="<?php echo htmlspecialchars($cfg['hapysure_login_path'] ?? '/login', ENT_QUOTES, 'UTF-8'); ?>" placeholder="/login">
                    <div class="form-text">ค่าเริ่มต้น <code>/login</code> — ใช้เมื่อกดยืนยันการคัดกรองแล้วให้ login ด้วย user/password เดียวกับ THAM</div>
                    <div class="alert alert-info small mt-3 mb-0">
                        <i class="fas fa-shield-alt me-1"></i>
                        ไม่เก็บรหัสผ่าน HAPYsure ในฐานข้อมูล ใช้รหัสที่ login THAM ใน session รอบนี้เท่านั้น ถ้า user/password ตรงกับ HAPYsure จะเข้าหน้าผู้ป่วยต่อได้เลย
                    </div>
                    <div class="d-flex justify-content-end mt-3">
                        <button type="submit" class="btn btn-info text-white fw-bold"><i class="fas fa-save me-1"></i> บันทึก</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
