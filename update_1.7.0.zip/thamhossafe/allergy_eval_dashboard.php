<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/allergy_followup_helper.php';
mysqli_set_charset($con, 'utf8');
$can_edit = af_can_assess();
$fy_start = ((int)date('n') >= 10) ? date('Y-10-01') : date('Y-10-01', strtotime('-1 year'));
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard การประเมินแพ้ยา - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        :root { --af-rose: #be123c; --af-dark: #9f1239; --af-soft: #fff1f2; }
        .af-hero {
            background: linear-gradient(135deg, #9f1239 0%, #e11d48 55%, #fb7185 100%);
            color: #fff; border-radius: 12px; padding: 1.15rem 1.4rem;
            box-shadow: 0 8px 24px rgba(190, 18, 60, 0.25);
        }
        .btn-af { background: var(--af-rose); color: #fff; border: 0; }
        .btn-af:hover { background: var(--af-dark); color: #fff; }
        .kpi-card { border-radius: 12px; border: none; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .kpi-num { font-size: 1.7rem; font-weight: 800; }
        .aed-table thead th { font-size: 0.78rem; background: #f8fafc; white-space: nowrap; }
        .aed-pharm { font-weight: 700; color: #0f172a; cursor: pointer; }
        .aed-pharm:hover { color: var(--af-rose); }
        .fee-chip { display: inline-block; background: #fff1f2; color: #9f1239; border-radius: 999px; padding: 0.2rem 0.55rem; font-size: 0.75rem; font-weight: 700; }
        tr.aed-active { background: #fff1f2; }
        .aed-bar { height: 8px; border-radius: 99px; background: #fee2e2; overflow: hidden; }
        .aed-bar > span { display: block; height: 100%; background: #be123c; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="af-hero mb-4">
                <div class="small opacity-75 mb-1"><i class="fas fa-allergies me-1"></i>ระบบแพ้ยา</div>
                <h4 class="fw-bold mb-1"><i class="fas fa-chart-pie me-2"></i>Dashboard การประเมินแพ้ยา</h4>
                <small>นับเป็นราย (HN + วันที่เดียวกัน = 1 แม้มียาหลายตัว) รวมจากติดตามการแพ้ยาและประวัติแพ้ยาใน รพ. — รายการซ้ำตัดออก ประวัติไม่สมบูรณ์ไม่นับมูลค่า</small>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body py-2">
                    <div class="row g-2 align-items-end">
                        <div class="col-6 col-md-2">
                            <label class="form-label small mb-0">จากวันที่</label>
                            <input type="date" class="form-control form-control-sm" id="flt_start" value="<?= htmlspecialchars($fy_start, ENT_QUOTES, 'UTF-8') ?>">
                        </div>
                        <div class="col-6 col-md-2">
                            <label class="form-label small mb-0">ถึงวันที่</label>
                            <input type="date" class="form-control form-control-sm" id="flt_end" value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small mb-0">ค้นหาเภสัช / HN / ชื่อ</label>
                            <input type="text" class="form-control form-control-sm" id="flt_q" placeholder="ชื่อเภสัช, HN...">
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-af btn-sm fw-bold" id="btnLoad"><i class="fas fa-search me-1"></i>สรุป</button>
                        </div>
                        <?php if ($can_edit): ?>
                        <div class="col-md-3 text-md-end">
                            <button type="button" class="btn btn-outline-danger btn-sm fw-bold" id="btnFees"><i class="fas fa-coins me-1"></i>ตั้งค่ามูลค่าต่อเคส</button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div id="aedAlert"></div>

            <div class="row g-3 mb-3">
                <div class="col-6 col-lg">
                    <div class="card kpi-card p-3 h-100">
                        <div class="small text-muted fw-bold">รายที่นับได้</div>
                        <div class="kpi-num text-danger" id="kpi_persons">-</div>
                    </div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card kpi-card p-3 h-100">
                        <div class="small text-muted fw-bold">มูลค่ารวม (บาท)</div>
                        <div class="kpi-num" id="kpi_baht">-</div>
                    </div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card kpi-card p-3 h-100">
                        <div class="small text-muted fw-bold">จำนวนเภสัช</div>
                        <div class="kpi-num" id="kpi_pharm">-</div>
                    </div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card kpi-card p-3 h-100 border-start border-4 border-warning" id="kpiIncompleteCard" style="cursor:pointer">
                        <div class="small text-muted fw-bold">ประวัติไม่สมบูรณ์</div>
                        <div class="kpi-num text-warning" id="kpi_incomplete">-</div>
                        <div class="small text-muted">ราย (ไม่นับมูลค่า)</div>
                    </div>
                </div>
                <div class="col-6 col-lg">
                    <div class="card kpi-card p-3 h-100">
                        <div class="small text-muted fw-bold">ตัดรายการซ้ำ</div>
                        <div class="kpi-num" id="kpi_dup">-</div>
                    </div>
                </div>
            </div>

            <div class="d-flex flex-wrap gap-2 mb-3" id="feeChips"></div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white fw-bold">สรุปตามเภสัชแต่ละคน</div>
                <div class="table-responsive">
                    <table class="table table-hover table-sm align-middle mb-0 aed-table">
                        <thead>
                            <tr>
                                <th>เภสัชผู้ประเมิน</th>
                                <th class="text-center">ราย</th>
                                <th class="text-center">ไม่สมบูรณ์</th>
                                <th class="text-end">มูลค่า (บาท)</th>
                                <th>สัดส่วน</th>
                                <th>แยกตามประเภท</th>
                            </tr>
                        </thead>
                        <tbody id="pharmBody">
                            <tr><td colspan="6" class="text-center text-muted py-4">กดสรุปเพื่อโหลดข้อมูล</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <span class="fw-bold">รายละเอียดราย <span id="caseTitle" class="text-muted fw-normal"></span></span>
                    <span class="small text-muted">คลิกชื่อเภสัชด้านบนเพื่อกรอง</span>
                </div>
                <div class="table-responsive">
                    <table class="table table-sm align-middle mb-0 aed-table">
                        <thead>
                            <tr>
                                <th>วันที่</th>
                                <th>HN</th>
                                <th>ชื่อ-สกุล</th>
                                <th>เภสัช</th>
                                <th>ประเภท</th>
                                <th class="text-center">ยา (นับ 1)</th>
                                <th>แหล่ง</th>
                                <th class="text-end">บาท</th>
                            </tr>
                        </thead>
                        <tbody id="caseBody">
                            <tr><td colspan="8" class="text-center text-muted py-3">-</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card border-0 shadow-sm" id="incCard">
                <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <span class="fw-bold text-warning"><i class="fas fa-exclamation-triangle me-1"></i>ประวัติแพ้ยาใน รพ. ที่ข้อมูลไม่สมบูรณ์ <span id="incTitle" class="fw-normal"></span></span>
                    <a class="btn btn-outline-warning btn-sm fw-bold" id="btnFixHistory" href="allergy_history.php" target="_blank">ไปแก้ในประวัติแพ้ยาใน รพ.</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-sm align-middle mb-0 aed-table">
                        <thead>
                            <tr>
                                <th>วันที่</th>
                                <th>HN</th>
                                <th>ชื่อ-สกุล</th>
                                <th>ผู้ประเมิน</th>
                                <th>จำนวนยา</th>
                                <th>ขาดข้อมูล</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="incBody">
                            <tr><td colspan="6" class="text-center text-muted py-3">-</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="feeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">ตั้งค่ามูลค่าที่ประเมินแต่ละเคส</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="small text-muted mb-2">หน่วยเป็นบาท / 1 ราย (HN+วันที่เดียวกันนับ 1)</div>
                <div id="feeForm"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิด</button>
                <button type="button" class="btn btn-af btn-sm fw-bold" id="btnSaveFees">บันทึกมูลค่า</button>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const CAN_EDIT = <?= $can_edit ? 'true' : 'false' ?>;
let dash = { pharmacists: [], cases: [], incomplete: [], fees: {}, summary: {} };
let feeModal = null;
let filterPharm = '';

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function nfmt(n) {
    return Number(n || 0).toLocaleString('th-TH', { maximumFractionDigits: 2 });
}
function fmtDate(iso) {
    if (!iso) return '-';
    const p = String(iso).split('-');
    return p.length === 3 ? (p[2] + '/' + p[1] + '/' + p[0]) : iso;
}
function sourceLabel(s) {
    if (s === 'both') return '<span class="badge bg-secondary">ติดตาม + HOSxP</span>';
    if (s === 'followup') return '<span class="badge bg-danger">ติดตามการแพ้ยา</span>';
    return '<span class="badge bg-dark">ประวัติใน รพ.</span>';
}

function loadDash() {
    const qs = new URLSearchParams({
        action: 'summary',
        start_date: $('#flt_start').val(),
        end_date: $('#flt_end').val()
    });
    $('#pharmBody').html('<tr><td colspan="6" class="text-center text-muted py-4">กำลังสรุป...</td></tr>');
    fetch('fetch_allergy_eval_dashboard_api.php?' + qs.toString(), { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') {
                $('#aedAlert').html('<div class="alert alert-danger">' + esc(data.message || 'โหลดไม่สำเร็จ') + '</div>');
                return;
            }
            dash = data;
            let warn = '';
            if (data.hosxp_error) {
                warn = '<div class="alert alert-warning py-2">ดึงประวัติแพ้ยาใน รพ. ไม่ได้: ' + esc(data.hosxp_error) + ' — สรุปจากสมุดติดตามอย่างเดียว</div>';
            }
            $('#aedAlert').html(warn);
            renderAll();
        })
        .catch(() => {
            $('#aedAlert').html('<div class="alert alert-danger">โหลดไม่สำเร็จ</div>');
        });
}

function renderAll() {
    const s = dash.summary || {};
    $('#kpi_persons').text(nfmt(s.persons));
    $('#kpi_baht').text(nfmt(s.baht));
    $('#kpi_pharm').text(nfmt(s.pharmacists));
    $('#kpi_incomplete').text(nfmt(s.incomplete_persons));
    $('#kpi_dup').text(nfmt(s.duplicates_removed));
    const chips = Object.keys(s.by_type || {}).map(function(code) {
        const t = s.by_type[code];
        if (!t || !t.count) return '';
        return '<span class="fee-chip">' + esc(t.label) + ' ' + nfmt(t.count) + ' ราย × ' + nfmt(t.baht_each) + ' = ' + nfmt(t.baht) + ' บาท</span>';
    }).join('');
    $('#feeChips').html(chips || '');
    renderPharm();
    renderCases();
    renderIncomplete();
}

function qmatch(row) {
    const q = ($('#flt_q').val() || '').trim().toLowerCase();
    if (!q) return true;
    const blob = [row.pharmacist, row.hn, row.ptname, row.fee_label].join(' ').toLowerCase();
    return blob.indexOf(q) >= 0;
}

function renderPharm() {
    const totalBaht = Number((dash.summary && dash.summary.baht) || 0) || 1;
    const rows = (dash.pharmacists || []).filter(function(p) {
        const q = ($('#flt_q').val() || '').trim().toLowerCase();
        if (!q) return true;
        return String(p.pharmacist || '').toLowerCase().indexOf(q) >= 0;
    });
    if (!rows.length) {
        $('#pharmBody').html('<tr><td colspan="6" class="text-center text-muted py-4">ไม่พบข้อมูลในช่วงที่เลือก</td></tr>');
        return;
    }
    $('#pharmBody').html(rows.map(function(p) {
        const pct = Math.round((Number(p.baht) / totalBaht) * 100);
        const types = Object.keys(p.by_type || {}).map(function(code) {
            const t = p.by_type[code];
            return t && t.count ? esc(t.label) + ' ' + t.count : '';
        }).filter(Boolean).join(' · ');
        const inc = Number(p.incomplete || 0);
        const incBtn = inc > 0
            ? '<button type="button" class="btn btn-sm btn-warning fw-bold py-0 px-2 btn-inc" data-key="' + esc(p.pharmacist_key) + '" data-name="' + esc(p.pharmacist) + '">' + nfmt(inc) + ' ราย</button>'
            : '<span class="text-muted">0</span>';
        const active = filterPharm === p.pharmacist_key ? ' aed-active' : '';
        return '<tr class="aed-pharm-row' + active + '" data-key="' + esc(p.pharmacist_key) + '">'
            + '<td class="aed-pharm">' + esc(p.pharmacist) + '</td>'
            + '<td class="text-center fw-bold">' + nfmt(p.cases) + '</td>'
            + '<td class="text-center">' + incBtn + '</td>'
            + '<td class="text-end fw-bold">' + nfmt(p.baht) + '</td>'
            + '<td style="min-width:120px"><div class="aed-bar"><span style="width:' + pct + '%"></span></div><div class="small text-muted">' + pct + '%</div></td>'
            + '<td class="small">' + (types || '-') + '</td>'
            + '</tr>';
    }).join(''));
}

function renderCases() {
    let rows = dash.cases || [];
    if (filterPharm) rows = rows.filter(c => c.pharmacist_key === filterPharm);
    rows = rows.filter(qmatch);
    $('#caseTitle').text(filterPharm ? ('— กรองเภสัชที่เลือก') : '');
    if (!rows.length) {
        $('#caseBody').html('<tr><td colspan="8" class="text-center text-muted py-3">ไม่มีรายการ</td></tr>');
        return;
    }
    $('#caseBody').html(rows.slice(0, 800).map(function(c) {
        const link = c.followup_id
            ? '<a href="allergy_followup.php?open=' + c.followup_id + '">' + esc(c.hn) + '</a>'
            : '<a href="allergy_history.php?q=' + encodeURIComponent(c.hn) + '">' + esc(c.hn) + '</a>';
        return '<tr>'
            + '<td class="text-nowrap">' + esc(fmtDate(c.date)) + '</td>'
            + '<td class="fw-bold text-danger">' + link + '</td>'
            + '<td>' + esc(c.ptname) + '</td>'
            + '<td>' + esc(c.pharmacist) + '</td>'
            + '<td>' + esc(c.fee_label) + '</td>'
            + '<td class="text-center">' + nfmt(c.drug_count || 1) + '</td>'
            + '<td>' + sourceLabel(c.source) + '</td>'
            + '<td class="text-end">' + nfmt(c.baht) + '</td>'
            + '</tr>';
    }).join(''));
}

function historyUrl(q) {
    const qs = new URLSearchParams({
        q: q || '',
        view: 'incomplete',
        start_date: $('#flt_start').val() || '',
        end_date: $('#flt_end').val() || ''
    });
    return 'allergy_history.php?' + qs.toString();
}

function updateFixLink() {
    const name = filterPharm
        ? (((dash.pharmacists || []).find(p => p.pharmacist_key === filterPharm) || {}).pharmacist || '')
        : '';
    $('#btnFixHistory').attr('href', historyUrl(name));
}

function renderIncomplete() {
    let rows = dash.incomplete || [];
    if (filterPharm) rows = rows.filter(c => c.pharmacist_key === filterPharm);
    $('#incTitle').text(filterPharm ? ('— ของเภสัชที่เลือก ' + nfmt(rows.length) + ' ราย') : ('(' + nfmt(rows.length) + ' ราย)'));
    updateFixLink();
    if (!rows.length) {
        $('#incBody').html('<tr><td colspan="7" class="text-center text-muted py-3">ไม่มีรายการไม่สมบูรณ์ในช่วงนี้</td></tr>');
        return;
    }
    $('#incBody').html(rows.map(function(c) {
        return '<tr>'
            + '<td class="text-nowrap">' + esc(fmtDate(c.date)) + '</td>'
            + '<td class="fw-bold">' + esc(c.hn) + '</td>'
            + '<td>' + esc(c.ptname) + '</td>'
            + '<td>' + esc(c.pharmacist) + '</td>'
            + '<td class="text-center">' + nfmt(c.incomplete_drugs) + '</td>'
            + '<td class="small text-danger">' + esc((c.missing_fields || []).join(', ') || '-') + '</td>'
            + '<td><a class="btn btn-sm btn-outline-warning py-0" href="' + esc(historyUrl(c.hn)) + '" target="_blank">ไปแก้</a></td>'
            + '</tr>';
    }).join(''));
}

function openFeeModal() {
    const fees = dash.fees || {};
    const codes = Object.keys(fees);
    $('#feeForm').html(codes.map(function(code) {
        const f = fees[code];
        return '<div class="mb-2 row align-items-center">'
            + '<label class="col-8 col-form-label small fw-bold">' + esc(f.label) + '</label>'
            + '<div class="col-4"><div class="input-group input-group-sm">'
            + '<input type="number" min="0" step="1" class="form-control fee-baht" data-code="' + esc(code) + '" value="' + esc(f.baht) + '">'
            + '<span class="input-group-text">บาท</span></div></div></div>';
    }).join(''));
    feeModal.show();
}

$(function() {
    feeModal = new bootstrap.Modal(document.getElementById('feeModal'));
    loadDash();
    $('#btnLoad').on('click', function() { filterPharm = ''; loadDash(); });
    $('#flt_q').on('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); renderPharm(); renderCases(); renderIncomplete(); } });
    $('#pharmBody').on('click', 'tr.aed-pharm-row', function(e) {
        if ($(e.target).closest('.btn-inc').length) return;
        const key = this.getAttribute('data-key') || '';
        filterPharm = (filterPharm === key) ? '' : key;
        renderPharm();
        renderCases();
        renderIncomplete();
    });
    $('#pharmBody').on('click', '.btn-inc', function(e) {
        e.preventDefault();
        e.stopPropagation();
        filterPharm = this.getAttribute('data-key') || '';
        renderPharm();
        renderCases();
        renderIncomplete();
        const box = document.getElementById('incCard');
        if (box) box.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    $('#kpiIncompleteCard').on('click', function() {
        const box = document.getElementById('incCard');
        if (box) box.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    $('#btnSaveFees').on('click', function() {
        const fees = {};
        $('.fee-baht').each(function() {
            fees[this.getAttribute('data-code')] = { baht: parseFloat(this.value || '0') || 0 };
        });
        fetch('fetch_allergy_eval_dashboard_api.php?action=save_fees', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fees: fees })
        }).then(r => r.json()).then(function(data) {
            if (data.status !== 'success') { alert(data.message || 'บันทึกไม่สำเร็จ'); return; }
            feeModal.hide();
            loadDash();
        });
    });
});
</script>
</body>
</html>
