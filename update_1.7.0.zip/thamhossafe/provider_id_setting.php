<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/provider_oauth_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.provider_id') && !tham_menu_can('admin.hosxp') && ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: home.php');
    exit;
}

$msg = '';
$msg_ok = false;
$cfg = provider_oauth_runtime($con);

// AJAX: ทดสอบการเชื่อมต่อ (ใช้ค่าในฟอร์ม — ช่องลับเว้นว่าง = ค่าที่บันทึกไว้)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (string)($_POST['action'] ?? '') === 'test_connection') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(provider_oauth_test_connection($con, [
        'env' => trim((string)($_POST['env'] ?? 'uat')),
        'health_client_id' => trim((string)($_POST['health_client_id'] ?? '')),
        'health_client_secret' => trim((string)($_POST['health_client_secret'] ?? '')),
        'provider_client_id' => trim((string)($_POST['provider_client_id'] ?? '')),
        'provider_secret_key' => trim((string)($_POST['provider_secret_key'] ?? '')),
        'redirect_uri' => trim((string)($_POST['redirect_uri'] ?? '')),
        'drug_center_api_key' => trim((string)($_POST['drug_center_api_key'] ?? '')),
    ]), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = (string)($_SESSION['username'] ?? $_SESSION['full_name'] ?? '');
    $result = provider_oauth_save_settings($con, [
        'env' => trim((string)($_POST['env'] ?? 'uat')),
        'health_client_id' => trim((string)($_POST['health_client_id'] ?? '')),
        'health_client_secret' => trim((string)($_POST['health_client_secret'] ?? '')),
        'provider_client_id' => trim((string)($_POST['provider_client_id'] ?? '')),
        'provider_secret_key' => trim((string)($_POST['provider_secret_key'] ?? '')),
        'redirect_uri' => trim((string)($_POST['redirect_uri'] ?? '')),
        'drug_center_api_key' => trim((string)($_POST['drug_center_api_key'] ?? '')),
    ], $user);
    if (!empty($result['ok'])) {
        $msg_ok = true;
        $msg = 'บันทึกตั้งค่า Provider ID แล้ว';
        if (!empty($result['warning'])) {
            $msg .= ' — ' . $result['warning'];
        }
        $cfg = $result['settings'] ?? provider_oauth_runtime($con);
    } else {
        $msg = $result['error'] ?? 'บันทึกไม่สำเร็จ';
        $cfg = provider_oauth_runtime($con);
    }
}

function pid_mask_secret($s) {
    $s = trim((string)$s);
    if ($s === '') {
        return '';
    }
    $len = strlen($s);
    if ($len <= 8) {
        return str_repeat('•', $len);
    }
    return substr($s, 0, 4) . str_repeat('•', max(4, $len - 8)) . substr($s, -4);
}

$auto_redirect = provider_oauth_redirect_uri();
$env = ($cfg['env'] ?? '') === 'prd' ? 'prd' : 'uat';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ตั้งค่า Provider ID - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content p-4">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <div>
                <div class="small text-muted">ตั้งค่าระบบ</div>
                <h4 class="fw-bold text-dark mb-0"><i class="fas fa-id-card me-2" style="color:#0aa2c0;"></i>ตั้งค่า Provider ID</h4>
            </div>
            <span class="badge bg-<?php echo $env === 'prd' ? 'primary' : 'secondary'; ?> fs-6">env: <?php echo htmlspecialchars($env, ENT_QUOTES, 'UTF-8'); ?></span>
        </div>

        <div class="card shadow-sm border-0" style="max-width:820px;">
            <div class="card-body p-4">
                <p class="text-muted mb-3">
                    ใช้สำหรับ Login ด้วย Provider ID (Health ID OAuth) และ Drugs Center
                    — ค่า <b>env</b> ที่หน้า login คือ <code>PROVIDER_OAUTH_ENV</code> (<b>uat</b> = ทดสอบ, <b>prd</b> = ใช้งานจริง)
                </p>
                <?php if ($msg !== ''): ?>
                    <div class="alert alert-<?php echo $msg_ok ? 'success' : 'danger'; ?>"><?php echo htmlspecialchars($msg, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>

                <form method="post" autocomplete="off">
                    <div class="mb-3">
                        <label class="form-label fw-bold">สภาพแวดล้อม (env)</label>
                        <select name="env" class="form-select" style="max-width:220px;">
                            <option value="uat" <?php echo $env === 'uat' ? 'selected' : ''; ?>>uat — ทดสอบ (uat-moph.id.th)</option>
                            <option value="prd" <?php echo $env === 'prd' ? 'selected' : ''; ?>>prd — ใช้งานจริง (moph.id.th)</option>
                        </select>
                        <div class="form-text">ถ้า credential หมดอายุ ให้ขอชุดใหม่จากทีม Provider ID แล้ววางค่าด้านล่าง — หรือสลับไป uat ชั่วคราว</div>
                    </div>

                    <hr class="my-3">
                    <h6 class="fw-bold text-secondary">1) Health ID (OAuth Login)</h6>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Client ID</label>
                        <input type="text" class="form-control" name="health_client_id"
                               value="<?php echo htmlspecialchars($cfg['health_client_id'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Client Secret</label>
                        <input type="password" class="form-control" name="health_client_secret" value=""
                               placeholder="<?php echo $cfg['health_client_secret'] !== '' ? ('คงค่าเดิม: ' . htmlspecialchars(pid_mask_secret($cfg['health_client_secret']), ENT_QUOTES, 'UTF-8')) : 'วางค่าใหม่'; ?>"
                               autocomplete="new-password">
                        <div class="form-text">เว้นว่าง = ไม่เปลี่ยนค่าเดิม</div>
                    </div>

                    <hr class="my-3">
                    <h6 class="fw-bold text-secondary">2) Provider ID</h6>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Client ID</label>
                        <input type="text" class="form-control" name="provider_client_id"
                               value="<?php echo htmlspecialchars($cfg['provider_client_id'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Secret Key</label>
                        <input type="password" class="form-control" name="provider_secret_key" value=""
                               placeholder="<?php echo $cfg['provider_secret_key'] !== '' ? ('คงค่าเดิม: ' . htmlspecialchars(pid_mask_secret($cfg['provider_secret_key']), ENT_QUOTES, 'UTF-8')) : 'วางค่าใหม่'; ?>"
                               autocomplete="new-password">
                        <div class="form-text">เว้นว่าง = ไม่เปลี่ยนค่าเดิม</div>
                    </div>

                    <hr class="my-3">
                    <h6 class="fw-bold text-secondary">3) Redirect URI</h6>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Redirect URI (ลงทะเบียนกับ Health ID)</label>
                        <input type="text" class="form-control" name="redirect_uri"
                               value="<?php echo htmlspecialchars($cfg['redirect_uri'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                               placeholder="<?php echo htmlspecialchars($auto_redirect, ENT_QUOTES, 'UTF-8'); ?>">
                        <div class="form-text">
                            ต้องตรงกับที่ลงทะเบียนทุกตัวอักษร — ถ้าเว้นว่าง ระบบใช้:
                            <code><?php echo htmlspecialchars($auto_redirect, ENT_QUOTES, 'UTF-8'); ?></code>
                        </div>
                    </div>

                    <hr class="my-3">
                    <h6 class="fw-bold text-secondary">4) Drugs Center API Key</h6>
                    <div class="mb-3">
                        <label class="form-label fw-bold">API Key</label>
                        <input type="password" class="form-control" name="drug_center_api_key" value=""
                               placeholder="<?php echo $cfg['drug_center_api_key'] !== '' ? ('คงค่าเดิม: ' . htmlspecialchars(pid_mask_secret($cfg['drug_center_api_key']), ENT_QUOTES, 'UTF-8')) : 'วางค่าใหม่'; ?>"
                               autocomplete="new-password">
                        <div class="form-text">เว้นว่าง = ไม่เปลี่ยนค่าเดิม</div>
                    </div>

                    <div class="alert alert-info small">
                        <i class="fas fa-info-circle me-1"></i>
                        บันทึกแล้วจะเก็บในฐานข้อมูล และอัปเดตไฟล์ <code>provider_oauth_config.php</code> ด้วย
                        — หน้า login จะแสดง <code>env: uat|prd</code> ตามค่าที่เลือก
                    </div>

                    <div id="pidTestResult" class="mb-3" style="display:none;"></div>

                    <div class="d-flex justify-content-end gap-2 flex-wrap">
                        <button type="button" class="btn btn-outline-primary fw-bold" id="btnTestConnection">
                            <i class="fas fa-plug me-1"></i> ทดสอบการเชื่อมต่อ
                        </button>
                        <a href="login.php" class="btn btn-outline-secondary" target="_blank">เปิดหน้า Login</a>
                        <button type="submit" class="btn btn-info text-white fw-bold"><i class="fas fa-save me-1"></i> บันทึก</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    const LABELS = {
        config: 'ค่าตั้งค่า',
        health_host: 'Health ID (เครือข่าย)',
        health_credentials: 'Health ID (Client ID/Secret)',
        provider_host: 'Provider ID (เครือข่าย)',
        provider_credentials: 'Provider ID (Client ID/Secret)',
        redirect_uri: 'Redirect URI',
        drug_center: 'Drugs Center'
    };

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function renderTest(data) {
        const $box = $('#pidTestResult').show();
        if (!data || typeof data !== 'object') {
            $box.html('<div class="alert alert-danger mb-0">ตอบกลับไม่ถูกต้อง</div>');
            return;
        }
        const ok = !!data.ok;
        const checks = Array.isArray(data.checks) ? data.checks : [];
        let rows = '';
        checks.forEach(function (c) {
            const skipped = !!c.skipped;
            const icon = skipped
                ? '<i class="fas fa-minus-circle text-secondary me-1"></i>'
                : (c.ok
                    ? '<i class="fas fa-check-circle text-success me-1"></i>'
                    : '<i class="fas fa-times-circle text-danger me-1"></i>');
            const ms = (c.ms != null) ? (' <span class="text-muted">(' + esc(c.ms) + ' ms)</span>') : '';
            rows += '<li class="mb-1">' + icon
                + '<b>' + esc(LABELS[c.name] || c.name) + '</b>: '
                + esc(c.message) + ms + '</li>';
        });
        $box.html(
            '<div class="alert alert-' + (ok ? 'success' : 'warning') + ' mb-0">'
            + '<div class="fw-bold mb-2">'
            + (ok ? '<i class="fas fa-check me-1"></i> ทดสอบผ่าน' : '<i class="fas fa-exclamation-triangle me-1"></i> พบปัญหาบางรายการ')
            + ' <span class="fw-normal text-muted">· env=' + esc(data.env || '')
            + (data.ms != null ? (' · ' + esc(data.ms) + ' ms') : '')
            + '</span></div>'
            + '<ul class="mb-2 ps-3">' + rows + '</ul>'
            + '<div class="small text-muted mb-0">' + esc(data.note || '') + '</div>'
            + '</div>'
        );
    }

    $('#btnTestConnection').on('click', function () {
        const $btn = $(this).prop('disabled', true);
        const old = $btn.html();
        $btn.html('<i class="fas fa-spinner fa-spin me-1"></i> กำลังทดสอบ...');
        $('#pidTestResult').show().html(
            '<div class="alert alert-secondary mb-0"><i class="fas fa-spinner fa-spin me-1"></i> กำลังทดสอบการเชื่อมต่อ...</div>'
        );
        const fd = new FormData(document.querySelector('form'));
        fd.set('action', 'test_connection');
        fetch('provider_id_setting.php', {
            method: 'POST',
            body: fd,
            credentials: 'same-origin'
        })
            .then(function (r) { return r.json(); })
            .then(function (data) { renderTest(data); })
            .catch(function () {
                $('#pidTestResult').html('<div class="alert alert-danger mb-0">ทดสอบไม่สำเร็จ (เครือข่ายหรือเซิร์ฟเวอร์ตอบผิดพลาด)</div>');
            })
            .finally(function () {
                $btn.prop('disabled', false).html(old);
            });
    });
})();
</script>
</body>
</html>
