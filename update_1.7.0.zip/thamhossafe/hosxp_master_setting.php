<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
mysqli_set_charset($con, 'utf8');

$primary = hosxp_load_config($con);
$cfg = hosxp_load_master_config($con);
$write_cfg = hosxp_load_write_config($con);
$has_pass = trim((string)($cfg['h_master_pass'] ?? '')) !== '';
$has_write_pass = trim((string)($write_cfg['h_write_pass'] ?? '')) !== '';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ตั้งค่าการเชื่อมต่อ HOSxP master - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="wrapper">
    <?php include('sidebar.php'); ?>

    <div id="content" class="content p-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <h4 class="fw-bold text-dark mb-0"><i class="fas fa-database me-2 text-warning"></i>ตั้งค่าระบบเชื่อมต่อ HOSxP master</h4>
            <div class="d-flex gap-2">
                <a href="hosxp_setting.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-network-wired me-1"></i> เชื่อมต่อ HOSxP หลัก</a>
                <a href="alert_settings.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-bell me-1"></i> Alert pipelines</a>
            </div>
        </div>

        <div class="alert alert-info">
            <i class="fas fa-info-circle me-1"></i>
            ใช้ master สำหรับ<b>ดึงบัญชีผู้ใช้ (opduser)</b> และ<b>ดักว่ากำลังคีย์ยาเสี่ยง</b> (คิวรีเบา ไม่ JOIN ยา)
            รายงานหนัก ยา แล็บ และหน้าจอ realtime ยังใช้ <a href="hosxp_setting.php" class="fw-bold">เชื่อมต่อ HOSxP</a> · เปิด/ปิดช่องแจ้งเตือนที่ <a href="alert_settings.php" class="fw-bold">Alert pipelines</a>
        </div>

        <div class="card shadow-sm border-0 mb-3">
            <div class="card-body py-3">
                <div class="small text-muted fw-bold mb-1">การเชื่อมต่อ HOSxP หลัก (ใช้อยู่ตอนนี้)</div>
                <div>
                    <code><?php echo htmlspecialchars(($primary['h_host'] ?? '') !== '' ? $primary['h_host'] : 'ยังไม่ตั้งค่า'); ?></code>
                    · ฐาน <code><?php echo htmlspecialchars($primary['h_db'] ?? 'hos'); ?></code>
                    · user <code><?php echo htmlspecialchars($primary['h_user'] ?? '-'); ?></code>
                </div>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <form id="configForm" onsubmit="saveConfig(event)">
                    <h6 class="fw-bold text-primary border-bottom pb-2 mb-3"><i class="fas fa-network-wired me-2"></i>1. ข้อมูลฐานข้อมูล master (Database Connection)</h6>
                    <div class="row g-3 mb-4 bg-white p-3 border rounded">
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Host / IP</label>
                            <input type="text" class="form-control border-primary" name="h_master_host" id="h_master_host" value="<?php echo htmlspecialchars($cfg['h_master_host'] ?? ''); ?>" placeholder="เช่น 192.168.1.5">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-bold">Port</label>
                            <input type="number" class="form-control border-primary" name="h_master_port" id="h_master_port" value="<?php echo htmlspecialchars($cfg['h_master_port'] ?? '3306'); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Database Name</label>
                            <input type="text" class="form-control border-primary" name="h_master_db" id="h_master_db" value="<?php echo htmlspecialchars($cfg['h_master_db'] ?? 'hos'); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Username</label>
                            <input type="text" class="form-control border-primary" name="h_master_user" id="h_master_user" value="<?php echo htmlspecialchars($cfg['h_master_user'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Password</label>
                            <input type="password" class="form-control border-primary" name="h_master_pass" id="h_master_pass" value="<?php echo $has_pass ? '********' : ''; ?>" autocomplete="new-password">
                            <div class="form-text">เว้น ******** ไว้ถ้าไม่ต้องการเปลี่ยนรหัส</div>
                        </div>
                        <div class="col-md-12">
                            <button type="button" class="btn btn-outline-secondary btn-sm" onclick="copyFromPrimary()">
                                <i class="fas fa-copy me-1"></i> คัดลอก Host / ฐาน / User จาก HOSxP หลัก
                            </button>
                        </div>
                    </div>

                    <div class="alert alert-warning small mb-4">
                        <i class="fas fa-pause-circle me-1"></i>
                        ยังไม่สลับคิวรีอัตโนมัติ — บันทึกค่าไว้ก่อน เมื่อพร้อมจะใช้กับงานที่ดึงรายการบางตัว (คิวรีไม่หนัก) เท่านั้น
                    </div>

                    <h6 class="fw-bold text-success border-bottom pb-2 mb-3"><i class="fas fa-save me-2"></i>2. บัญชีสำหรับบันทึกข้อมูลลง HOSxP (UPDATE)</h6>
                    <div class="row g-3 mb-4 bg-white p-3 border rounded">
                        <div class="col-12">
                            <div class="small text-muted">ใช้ตอนแก้จำนวนยาใน Patient OPD ให้บันทึกลงตาราง <code>opitemrece</code> บน master — ถ้าเว้นว่าง จะใช้ Username ของ master ซึ่งตอนนี้มีสิทธิ์อ่านอย่างเดียว</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Username (สิทธิ์ UPDATE)</label>
                            <input type="text" class="form-control border-success" name="h_write_user" id="h_write_user" value="<?php echo htmlspecialchars($write_cfg['h_write_user'] ?? ''); ?>" placeholder="บัญชีที่มีสิทธิ์ UPDATE opitemrece" autocomplete="off">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Password</label>
                            <input type="password" class="form-control border-success" name="h_write_pass" id="h_write_pass" value="<?php echo $has_write_pass ? '********' : ''; ?>" autocomplete="new-password">
                            <div class="form-text">เว้น ******** ไว้ถ้าไม่ต้องการเปลี่ยนรหัส</div>
                        </div>
                    </div>

                    <hr>
                    <div class="text-end">
                        <button type="button" class="btn btn-outline-info fw-bold me-2" onclick="testConnection()">
                            <i class="fas fa-plug me-1"></i> ทดสอบการเชื่อมต่อ
                        </button>
                        <button type="submit" class="btn btn-warning px-5 fw-bold shadow-sm text-dark">
                            <i class="fas fa-save me-1"></i> บันทึกการตั้งค่า
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const PRIMARY = {
    host: <?php echo json_encode((string)($primary['h_host'] ?? ''), JSON_UNESCAPED_UNICODE); ?>,
    db: <?php echo json_encode((string)($primary['h_db'] ?? 'hos'), JSON_UNESCAPED_UNICODE); ?>,
    user: <?php echo json_encode((string)($primary['h_user'] ?? ''), JSON_UNESCAPED_UNICODE); ?>
};

function copyFromPrimary() {
    document.getElementById('h_master_host').value = PRIMARY.host || '';
    document.getElementById('h_master_db').value = PRIMARY.db || 'hos';
    document.getElementById('h_master_user').value = PRIMARY.user || '';
    if (!document.getElementById('h_master_port').value) {
        document.getElementById('h_master_port').value = '3306';
    }
}

function testConnection() {
    const host = document.getElementById('h_master_host').value.trim();
    const port = document.getElementById('h_master_port').value.trim();
    const db = document.getElementById('h_master_db').value.trim();
    const user = document.getElementById('h_master_user').value.trim();
    const pass = document.getElementById('h_master_pass').value;
    const btn = document.querySelector('button[onclick="testConnection()"]');
    const originalHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังทดสอบ...';
    btn.disabled = true;

    fetch('test_hosxp_connection_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ h_host: host, h_port: port, h_db: db, h_user: user, h_pass: pass, source: 'master' })
    })
    .then(async res => {
        const text = await res.text();
        try { return JSON.parse(text); }
        catch (e) {
            throw new Error(res.ok ? 'ไฟล์ API ตอบกลับไม่ใช่ JSON' : ('เรียกไฟล์ API ไม่สำเร็จ (HTTP ' + res.status + ')'));
        }
    })
    .then(data => {
        if (data.status === 'success') {
            alert('✅ ' + data.message);
        } else if (data.status === 'warning') {
            alert('⚠️ ' + data.message);
        } else {
            alert('❌ ' + data.message);
        }
    })
    .catch(err => {
        alert('❌ ' + (err.message || 'เกิดข้อผิดพลาดในการเชื่อมต่อกับไฟล์ API'));
    })
    .finally(() => {
        btn.innerHTML = originalHtml;
        btn.disabled = false;
    });
}

function saveConfig(event) {
    event.preventDefault();
    const form = document.getElementById('configForm');
    const formData = new FormData(form);
    const btn = document.querySelector('button[type="submit"]');
    const originalHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังบันทึก...';
    btn.disabled = true;

    fetch('save_hosxp_master_config.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            alert('✅ ' + data.message);
        } else {
            alert('❌ ' + (data.message || 'เกิดข้อผิดพลาดไม่ทราบสาเหตุ'));
        }
    })
    .catch(() => {
        alert('❌ เกิดข้อผิดพลาดในการส่งข้อมูล');
    })
    .finally(() => {
        btn.innerHTML = originalHtml;
        btn.disabled = false;
    });
}
</script>
</body>
</html>
