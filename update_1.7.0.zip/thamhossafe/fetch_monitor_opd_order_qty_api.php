<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_opd_order_qty_helper.php');
mysqli_set_charset($con, 'utf8');
set_time_limit(180);

function moq_api_req($key, $default = '') {
    if (isset($_POST[$key]) && (is_string($_POST[$key]) || is_numeric($_POST[$key]))) {
        return trim((string)$_POST[$key]);
    }
    if (isset($_GET[$key]) && (is_string($_GET[$key]) || is_numeric($_GET[$key]))) {
        return trim((string)$_GET[$key]);
    }
    return $default;
}

function moq_api_json($payload, $code = 200) {
    ob_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    moq_api_json(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], 401);
}
session_write_close();

$start_date = moq_api_req('start_date', date('Y-m-d', strtotime('-3 days')));
$end_date = moq_api_req('end_date', date('Y-m-d'));

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-3 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if (strtotime($start_date) > strtotime($end_date)) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$rule_ids = [];
$rule_ids_raw = moq_api_req('rule_ids', '');
if ($rule_ids_raw !== '') {
    foreach (explode(',', $rule_ids_raw) as $rid) {
        $rid = (int)trim($rid);
        if ($rid > 0) {
            $rule_ids[] = $rid;
        }
    }
}

$filter_icodes = [];
$icodes_raw = moq_api_req('icodes', '');
if ($icodes_raw !== '') {
    foreach (explode(',', $icodes_raw) as $ic) {
        $ic = trim($ic);
        if ($ic !== '') {
            $filter_icodes[$ic] = true;
        }
    }
}

$rules = moq_load_active_rules($con, $rule_ids);
$moq_cfg = moq_load_config($con);
$min_excess_raw = moq_api_req('min_excess_value', '');
$min_excess_value = ($min_excess_raw !== '' && is_numeric($min_excess_raw))
    ? max(0, (float)$min_excess_raw)
    : (float)($moq_cfg['min_excess_value'] ?? 0);
if (empty($rules)) {
    moq_api_json([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'icodes' => [],
        'meta' => ['message' => 'ยังไม่มีกฎที่เปิดใช้งาน — ไปที่แท็บตั้งค่า', 'rule_count' => 0],
    ]);
}

$hos = hosxp_connect($con);
if (!$hos) {
    moq_api_json(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้']);
}

$rule_by_icode = [];
$icode_list = [];
list($rule_by_icode, $icode_list) = moq_build_rule_map_by_icode($hos, $rules);

if (!empty($filter_icodes)) {
    $filtered_map = [];
    $filtered_sql = [];
    foreach ($rule_by_icode as $ic => $matched) {
        if (!isset($filter_icodes[$ic])) {
            continue;
        }
        $filtered_map[$ic] = $matched;
        $filtered_sql[] = "'" . mysqli_real_escape_string($hos, $ic) . "'";
    }
    $rule_by_icode = $filtered_map;
    $icode_list = $filtered_sql;
}

if (moq_api_req('action', '') === 'list_icodes') {
    mysqli_close($hos);
    moq_api_json([
        'status' => 'success',
        'icodes' => array_keys($rule_by_icode),
        'meta' => [
            'rule_count' => count($rules),
            'icode_count' => count($rule_by_icode),
        ],
    ]);
}

$icode_in = implode(',', array_unique($icode_list));

if ($icode_in === '') {
    mysqli_close($hos);
    moq_api_json([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'meta' => ['rule_count' => count($rules), 'icode_count' => 0],
    ]);
}

$start_esc = mysqli_real_escape_string($hos, $start_date);
$end_esc = mysqli_real_escape_string($hos, $end_date);
$method_expr = di_sql_method_expr('o');
$tmt_expr = hosxp_sql_tmt_drug_name('d', 'tm');
$hn_raw = function_exists('monitor_req_hn') ? monitor_req_hn() : moq_api_req('hn', '');
$hn_clause = function_exists('monitor_hn_sql_clause') ? monitor_hn_sql_clause($hos, $hn_raw, 'o.hn') : '';

$sql = "
SELECT
    o.hn, o.vn, o.vstdate, o.rxdate, o.rxtime, o.icode, o.qty, o.item_no,
    $method_expr AS method,
    CAST(CONVERT(d.units USING utf8) AS CHAR) AS units,
    CAST(IFNULL(NULLIF(o.unitprice, 0), IFNULL(d.unitprice, 0)) AS DECIMAL(16,4)) AS unitprice,
    $tmt_expr AS drug_name,
    CAST(CONVERT(CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,'')) USING utf8) AS CHAR) AS ptname,
    CAST(CONVERT(IFNULL(dep.department,'') USING utf8) AS CHAR) AS clinic_name
FROM opitemrece o
INNER JOIN drugitems d ON d.icode = o.icode
INNER JOIN vn_stat v ON v.vn = o.vn
" . hosxp_sql_tmt_join('d', 'tm') . "
LEFT JOIN patient pt ON pt.hn = o.hn
LEFT JOIN ovst k ON k.vn = o.vn
LEFT JOIN kskdepartment dep ON dep.depcode = k.main_dep
" . di_sql_method_joins('o') . "
WHERE o.icode IN ($icode_in)
  AND o.rxdate BETWEEN '$start_esc' AND '$end_esc'
  AND o.qty > 0
  AND o.vn IS NOT NULL AND o.vn <> ''
  AND (o.an IS NULL OR o.an = '')
  AND v.vn IS NOT NULL
  $hn_clause
ORDER BY o.rxdate DESC, o.rxtime DESC, o.item_no DESC
LIMIT 8000
";

$t0 = microtime(true);
$q = mysqli_query($hos, $sql);
if (!$q) {
    $err = mysqli_error($hos);
    mysqli_close($hos);
    moq_api_json(['status' => 'error', 'message' => 'SQL Error: ' . $err]);
}

$rows = [];
$vn_list = [];
$hn_list = [];
while ($row = mysqli_fetch_assoc($q)) {
    $rows[] = $row;
    $vn = trim($row['vn'] ?? '');
    if ($vn !== '') {
        $vn_list[] = $vn;
    }
    $hn = trim($row['hn'] ?? '');
    if ($hn !== '') {
        $hn_list[] = $hn;
    }
}
$appt_by_hn = moq_fetch_appointments_by_hn($hos, $hn_list, $start_date, $end_date);
$appt_map = moq_fetch_appointments_by_vn($hos, $vn_list);

$hard_alerts = [];
$soft_alerts = [];
$seen = [];
$skipped_no_appt = 0;
$skipped_method = 0;
$orders_scanned = count($rows);

foreach ($rows as $row) {
    $icode = trim($row['icode'] ?? '');
    $matched_rules = $rule_by_icode[$icode] ?? [];
    if (empty($matched_rules)) {
        continue;
    }

    $vn = trim($row['vn'] ?? '');
    $order_date = trim($row['rxdate'] ?? '') ?: trim($row['vstdate'] ?? '');
    $hn_appts = moq_lookup_hn_appointments($appt_by_hn, $row['hn'] ?? '');
    $visit_appts = moq_filter_appointments_for_order($hn_appts, $order_date);
    if (empty($visit_appts) && $vn !== '') {
        $visit_appts = moq_filter_appointments_for_order($appt_map[$vn] ?? [], $order_date);
    }
    if (empty($visit_appts)) {
        $skipped_no_appt++;
        continue;
    }
    $display_src = $hn_appts;
    if ($vn !== '') {
        $display_src = array_merge($display_src, $appt_map[$vn] ?? []);
    }
    $display_appts = moq_appointments_for_display($display_src, $order_date);

    $method = trim(preg_replace('/\s+/u', ' ', $row['method'] ?? ''));
    $qty = (float)($row['qty'] ?? 0);

    foreach ($matched_rules as $rule) {
        $excess_allowed = (int)($rule['excess_pills_allowed'] ?? moq_default_excess_pills());
        if ($excess_allowed <= 0) {
            $excess_allowed = moq_default_excess_pills();
        }
        $shortage_allowed = max(0, (int)($rule['shortage_pills_allowed'] ?? moq_default_shortage_pills()));
        $result = moq_evaluate_order_against_appointments(
            $qty, $method, $row['units'] ?? '', $order_date, $visit_appts,
            $excess_allowed, $shortage_allowed, $con,
            $rule['monitor_scope'] ?? 'both'
        );
        $eval = moq_attach_excess_value($result['eval'] ?? [], $qty, $row['unitprice'] ?? 0);
        if (($result['status'] ?? '') === 'skip' || ($result['status'] ?? '') === 'ok') {
            if (($result['status'] ?? '') === 'skip') {
                $skipped_method++;
            }
            continue;
        }

        $appt = $result['appointment'] ?? [];
        $nextdate = $appt['nextdate'] ?? '';
        $nexttime = di_format_time(monitor_lab_normalize_hosxp_time($appt['nexttime'] ?? ''));

        $alert_type = $result['status'];
        $level = $alert_type === 'shortage'
            ? moq_alert_level($rule['alert_level_shortage'] ?? 'hard')
            : moq_alert_level($rule['alert_level_excess'] ?? 'soft');

        $dedupe = implode('|', [
            $row['hn'] ?? '',
            $row['vn'] ?? '',
            $icode,
            $row['item_no'] ?? '',
            (int)$rule['id'],
            $alert_type,
        ]);
        if (isset($seen[$dedupe])) {
            continue;
        }
        $seen[$dedupe] = true;

        $rx_date_fmt = !empty($row['rxdate']) ? date('d/m/Y', strtotime($row['rxdate'])) : '-';
        $rx_time_fmt = di_format_time(monitor_lab_normalize_hosxp_time($row['rxtime'] ?? ''));

        $alert = [
            'rule_id' => (int)$rule['id'],
            'alert_type' => $alert_type,
            'hn' => ltrim($row['hn'] ?? '', '0'),
            'hn_full' => $row['hn'] ?? '',
            'ptname' => trim($row['ptname'] ?? ''),
            'type_patient' => 'OPD',
            'vn' => $vn,
            'vstdate' => $row['vstdate'] ?? '',
            'order_date' => $rx_date_fmt,
            'order_time' => $rx_time_fmt,
            'drug_name' => trim($row['drug_name'] ?? ($rule['drug_name'] ?? '')),
            'icode' => $icode,
            'method' => $method,
            'qty' => $qty,
            'unitprice' => (float)($eval['unitprice'] ?? 0),
            'excess_qty' => $eval['excess_qty'] ?? null,
            'excess_days' => $eval['excess_days'] ?? null,
            'excess_value' => $eval['excess_value'] ?? null,
            'units' => trim($row['units'] ?? ''),
            'daily_units' => $eval['daily_units'],
            'coverage_days' => (int)($eval['coverage_days'] ?? 0),
            'coverage_end' => moq_format_date_th($eval['coverage_end'] ?? ''),
            'days_needed' => (int)($eval['days_needed'] ?? 0),
            'pills_needed' => $eval['pills_needed'],
            'max_qty_allowed' => $eval['max_qty_allowed'],
            'max_days_allowed' => $eval['max_days_allowed'] ?? null,
            'min_days_required' => $eval['min_days_required'] ?? null,
            'excess_pills_allowed' => (int)($eval['excess_pills_allowed'] ?? $excess_allowed),
            'shortage_pills_allowed' => (int)($eval['shortage_pills_allowed'] ?? $shortage_allowed),
            'min_qty_required' => $eval['min_qty_required'] ?? null,
            'next_appointment' => moq_format_date_th($nextdate),
            'next_appointment_time' => $nexttime,
            'next_appointment_clinic' => trim((string)($appt['clinic_name'] ?? '')),
            'next_appointment_doctor' => trim((string)($appt['doctor_name'] ?? $appt['doctor'] ?? '')),
            'order_date_iso' => $order_date,
            'appointments' => $display_appts,
            'clinic_name' => trim($row['clinic_name'] ?? ''),
            'alert_level' => $level,
            'alert_message' => $alert_type === 'shortage'
                ? moq_default_shortage_message($rule, $eval, $nextdate)
                : moq_default_excess_message($rule, $eval, $nextdate),
            'detail_text' => trim($rule['detail_text'] ?? ''),
        ];

        if ($level === 'hard') {
            $hard_alerts[] = $alert;
        } else {
            $soft_alerts[] = $alert;
        }
    }
}

$elapsed = (int)round((microtime(true) - $t0) * 1000);
mysqli_close($hos);
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';

moq_api_json([
    'status' => 'success',
    'hard_alerts' => sp_alert_mute_filter_rows($con, $hard_alerts),
    'soft_alerts' => sp_alert_mute_filter_rows($con, $soft_alerts),
    'meta' => [
        'rule_count' => count($rules),
        'hard_count' => count($hard_alerts),
        'soft_count' => count($soft_alerts),
        'orders_scanned' => $orders_scanned,
        'skipped_no_appointment' => $skipped_no_appt,
        'skipped_method' => $skipped_method,
        'min_excess_value' => $min_excess_value,
        'start_date' => $start_date,
        'end_date' => $end_date,
        'elapsed_ms' => $elapsed,
        'icode_count' => count($rule_by_icode),
        'truncated' => ($orders_scanned >= 8000),
    ],
]);
