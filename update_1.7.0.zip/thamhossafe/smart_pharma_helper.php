<?php
/**
 * Smart Pharma — ระบบคัดกรองผู้ป่วย
 */
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
require_once __DIR__ . '/monitor_hla_helper.php';
require_once __DIR__ . '/monitor_lab_hepatic_dosing_helper.php';
require_once __DIR__ . '/smart_pharma_extra_modules_helper.php';

/** เวลาไทย — HOSxP บันทึก rxtime เป็น Asia/Bangkok */
function sp_timezone() {
    static $tz = null;
    if ($tz === null) {
        $tz = new DateTimeZone('Asia/Bangkok');
    }
    return $tz;
}

function sp_now_datetime() {
    return new DateTime('now', sp_timezone());
}

function sp_now_timestamp() {
    return sp_now_datetime()->getTimestamp();
}

function sp_today_date() {
    return sp_now_datetime()->format('Y-m-d');
}

/** Cache สำหรับลดเวลาเมื่อสลับแท็บช่วงเวลา (TTL วินาที) — ไฟล์/APCu เพราะ session ถูกปิดก่อนคัดกรอง */
function sp_cache_ttl($screen_date, $time_window = null) {
    if (!sp_is_screen_date_today($screen_date)) {
        return 600;
    }
    // ช่วงเลื่อน (30 นาที/1 ชม./3 ชม.) — TTL สั้น + fingerprint ดักรายการใหม่
    if (in_array((string)$time_window, sp_live_time_windows(), true)) {
        return 45;
    }
    return 60;
}

function sp_cache_store_dir() {
    $dir = rtrim(sys_get_temp_dir(), '/\\') . '/tham_sp_cache';
    if (!is_dir($dir)) {
        @mkdir($dir, 0700, true);
    }
    return $dir;
}

function sp_cache_store_path($key) {
    return sp_cache_store_dir() . '/' . hash('sha256', (string)$key) . '.cache';
}

function sp_cache_get($key, $ttl = 600) {
    if (function_exists('apcu_fetch')) {
        $ok = false;
        $data = apcu_fetch('sp:' . $key, $ok);
        if ($ok) {
            return $data;
        }
    }
    $file = sp_cache_store_path($key);
    if (!is_file($file)) {
        return null;
    }
    $raw = @file_get_contents($file);
    if ($raw === false || $raw === '') {
        return null;
    }
    $entry = @unserialize($raw);
    if (!is_array($entry)) {
        return null;
    }
    if (time() - (int)($entry['t'] ?? 0) > $ttl) {
        @unlink($file);
        return null;
    }
    return $entry['data'] ?? null;
}

function sp_cache_set($key, $data, $ttl = 600) {
    $ttl = max(1, (int)$ttl);
    if (function_exists('apcu_store')) {
        @apcu_store('sp:' . $key, $data, $ttl);
    }
    $file = sp_cache_store_path($key);
    @file_put_contents($file, serialize(['t' => time(), 'data' => $data]), LOCK_EX);
    @chmod($file, 0600);
    sp_cache_index_remember($key);
}

/** ลบแคชราย key */
function sp_cache_delete($key) {
    if (function_exists('apcu_delete')) {
        @apcu_delete('sp:' . $key);
    }
    $file = sp_cache_store_path($key);
    if (is_file($file)) {
        @unlink($file);
    }
}

/** บันทึก key ลง index เพื่อให้ invalidate ตาม prefix ได้ */
function sp_cache_index_remember($key) {
    $dir = sp_cache_store_dir();
    $index = $dir . '/_keys.index';
    $map = [];
    if (is_file($index)) {
        $decoded = @unserialize((string)@file_get_contents($index));
        if (is_array($decoded)) {
            $map = $decoded;
        }
    }
    $map[(string)$key] = hash('sha256', (string)$key);
    @file_put_contents($index, serialize($map), LOCK_EX);
}

/**
 * ล้างแคชที่ขึ้นต้นด้วย prefix (เช่น 'pd_', 'ctx_', 'hosxp_drugs')
 * คืนจำนวน key ที่ลบ
 */
function sp_cache_invalidate_prefix($prefix) {
    $prefix = (string)$prefix;
    $n = 0;
    $dir = sp_cache_store_dir();
    $index = $dir . '/_keys.index';
    $map = [];
    if (is_file($index)) {
        $decoded = @unserialize((string)@file_get_contents($index));
        if (is_array($decoded)) {
            $map = $decoded;
        }
    }
    foreach (array_keys($map) as $key) {
        if ($prefix !== '' && strpos((string)$key, $prefix) !== 0) {
            continue;
        }
        sp_cache_delete($key);
        unset($map[$key]);
        $n++;
    }
    @file_put_contents($index, serialize($map), LOCK_EX);
    return $n;
}

/** รายชื่อผู้ป่วยที่มียาในวันคัดกรอง — ใช้ session cache เมื่อมี */
function sp_load_cached_patients($hos, $patient_type, $screen_date) {
    $ttl = sp_cache_ttl($screen_date);
    $fp = sp_day_orders_fingerprint($hos, $patient_type, $screen_date);
    $key = 'pd_' . $screen_date . '_' . $patient_type . '_' . $fp;
    $cached = sp_cache_get($key, $ttl);
    if ($cached !== null) {
        return [$cached, true];
    }
    if ($patient_type === 'OPD') {
        $cached = sp_fetch_opd_patients_with_drugs($hos, $screen_date);
    } else {
        $patients_all = sp_fetch_ipd_patients($hos, $screen_date);
        $cached = sp_filter_patients_with_drug_orders(
            sp_enrich_patients_rx_time($hos, $patients_all, $screen_date)
        );
    }
    sp_cache_set($key, $cached, $ttl);
    return [$cached, false];
}

function sp_filter_modules_by_key(array $modules, $module_key) {
    $module_key = trim((string)$module_key);
    if ($module_key === '') {
        return $modules;
    }
    $out = [];
    foreach ($modules as $mod) {
        if (($mod['module_key'] ?? '') === $module_key) {
            $out[] = $mod;
        }
    }
    return $out;
}

function sp_extract_hn_list(array $patients) {
    $hns = [];
    foreach ($patients as $p) {
        $hn = trim((string)($p['hn'] ?? ''));
        if ($hn !== '') {
            $hns[$hn] = true;
        }
    }
    return array_keys($hns);
}

function sp_sql_drug_order_join($o = 'o', $d = 'd') {
    return "INNER JOIN drugitems $d ON $d.icode = $o.icode AND $d.istatus = 'Y'";
}

function sp_ensure_tables($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/smart_pharma.sql');
    if (!$sql) {
        return false;
    }
    if (!mysqli_multi_query($con, $sql)) {
        return false;
    }
    while (mysqli_more_results($con)) {
        mysqli_next_result($con);
    }
    require_once __DIR__ . '/smart_pharma_telegram_helper.php';
    sp_telegram_ensure_tables($con);
    require_once __DIR__ . '/smart_pharma_webhook_helper.php';
    sp_webhook_ensure_tables($con);
    require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
    sp_alert_log_ensure_tables($con);
    sp_ensure_extra_modules($con);
    $ready = true;
    return true;
}

/** รายการโมดูลทั้งหมด (ไม่กรอง enabled) — ไม่รวมโมดูลที่เลิกใช้ */
function sp_list_all_modules($con) {
    $out = [];
    $q = mysqli_query($con, "SELECT * FROM smart_pharma_modules ORDER BY sort_order ASC, label_th ASC");
    if (!$q) {
        return $out;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        if (sp_is_retired_module($r['module_key'] ?? '')) {
            continue;
        }
        $out[] = $r;
    }
    return $out;
}

/**
 * ดึงโมดูลตามรายการ key (ไม่สน enabled ใน settings) — ใช้เมื่อ caller เลือกโมดูลเอง
 * @param array $keys module_key ที่ต้องการ
 */
function sp_get_modules_by_keys($con, array $keys) {
    $want = [];
    foreach ($keys as $k) {
        $k = trim((string)$k);
        if ($k !== '' && !sp_is_retired_module($k)) {
            $want[$k] = true;
        }
    }
    if (!$want) {
        return [];
    }
    $out = [];
    foreach (sp_list_all_modules($con) as $r) {
        $mk = (string)($r['module_key'] ?? '');
        if (isset($want[$mk])) {
            $out[] = $r;
        }
    }
    return $out;
}

function sp_get_modules($con, $patient_type = null) {
    $out = [];
    foreach (sp_list_all_modules($con) as $r) {
        if (empty($r['enabled'])) {
            continue;
        }
        if ($patient_type === 'OPD' && empty($r['enabled_opd'])) {
            continue;
        }
        if ($patient_type === 'IPD' && empty($r['enabled_ipd'])) {
            continue;
        }
        $out[] = $r;
    }
    return $out;
}

function sp_save_module_settings($con, array $rows) {
    foreach ($rows as $key => $data) {
        if (!is_array($data)) {
            continue;
        }
        $key_esc = mysqli_real_escape_string($con, $key);
        $sets = [];
        if (array_key_exists('enabled', $data)) {
            $sets[] = 'enabled=' . (!empty($data['enabled']) ? 1 : 0);
        }
        if (array_key_exists('enabled_opd', $data)) {
            $sets[] = 'enabled_opd=' . (!empty($data['enabled_opd']) ? 1 : 0);
        }
        if (array_key_exists('enabled_ipd', $data)) {
            $sets[] = 'enabled_ipd=' . (!empty($data['enabled_ipd']) ? 1 : 0);
        }
        if (!$sets) {
            continue;
        }
        mysqli_query($con, "UPDATE smart_pharma_modules SET " . implode(', ', $sets) . " WHERE module_key='$key_esc'");
    }
}

function sp_hn_in_sql($hos, $hn) {
    return monitor_lab_hn_sql_in($hos, $hn);
}

/** รายชื่อผู้ป่วยนอก (OPD) ตามวัน visit — ใช้ ovst (มี vsttime) ไม่ใช่ vn_stat */
function sp_fetch_opd_patients($hos, $date) {
    $date_esc = mysqli_real_escape_string($hos, $date);
    $ptname_sql = "CAST(CONVERT(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) USING utf8) AS CHAR)";

    $queries = [
        "SELECT o.vn, o.hn, o.vstdate, o.vsttime, $ptname_sql AS ptname,
                'OPD' AS patient_type, '' AS ward_name, '' AS bedno, '' AS an
            FROM ovst o
            INNER JOIN patient p ON p.hn = o.hn
            WHERE o.vstdate = '$date_esc'
              AND (o.an IS NULL OR o.an = '')
            ORDER BY o.vsttime DESC",
        "SELECT v.vn, v.hn, v.vstdate, '' AS vsttime, $ptname_sql AS ptname,
                'OPD' AS patient_type, '' AS ward_name, '' AS bedno, '' AS an
            FROM vn_stat v
            INNER JOIN patient p ON p.hn = v.hn
            WHERE v.vstdate = '$date_esc'
            GROUP BY v.vn, v.hn, v.vstdate
            ORDER BY v.vn DESC",
    ];

    foreach ($queries as $sql) {
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        $list = [];
        while ($r = mysqli_fetch_assoc($q)) {
            $list[] = $r;
        }
        if (!empty($list)) {
            return $list;
        }
    }
    return [];
}

/** OPD ที่มียาสั่งจริง — query เดียว ไม่ดึง ovst ทั้งวัน */
function sp_fetch_opd_patients_with_drugs($hos, $date) {
    $date_esc = mysqli_real_escape_string($hos, $date);
    $ptname_sql = "CAST(CONVERT(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) USING utf8) AS CHAR)";

    // ตัดออเดอร์ IPD (มี AN) ออก — กันผู้ป่วยในถูกคัดกรองซ้ำในฝั่ง OPD
    $sql = "SELECT o.vn, o.hn, o.vstdate,
            IFNULL(ov.vsttime, '') AS vsttime,
            o.rxdate, o.rxtime,
            $ptname_sql AS ptname,
            'OPD' AS patient_type, '' AS ward_name, '' AS bedno, '' AS an
        FROM opitemrece o
        " . sp_sql_drug_order_join('o', 'd') . "
        INNER JOIN patient p ON p.hn = o.hn
        LEFT JOIN ovst ov ON ov.vn = o.vn AND ov.vstdate = o.vstdate
        WHERE o.vstdate = '$date_esc' AND o.qty > 0
          AND o.rxdate IS NOT NULL AND o.rxdate != '0000-00-00'
          AND o.rxtime IS NOT NULL AND TRIM(o.rxtime) != ''
          AND (o.an IS NULL OR TRIM(o.an) = '')
          AND o.vn IS NOT NULL AND TRIM(o.vn) <> ''
        ORDER BY o.rxdate DESC, o.rxtime DESC, o.item_no DESC";

    $q = mysqli_query($hos, $sql);
    $seen_vn = [];
    $list = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $vn = trim((string)($r['vn'] ?? ''));
            if ($vn === '' || isset($seen_vn[$vn])) {
                continue;
            }
            $seen_vn[$vn] = true;
            $list[] = $r;
        }
    }
    return $list;
}

/**
 * ดึงผู้ป่วย OPD รายคนตาม HN (visit ล่าสุดที่มียาสั่งในวันนั้น หรือระบุ VN)
 * @return array|null
 */
function sp_fetch_opd_patient_by_hn($hos, $hn, $date, $vn = '') {
    $hn = trim((string)$hn);
    if ($hn === '') {
        return null;
    }
    $date_esc = mysqli_real_escape_string($hos, $date);
    $hn_in = sp_hn_in_sql($hos, $hn);
    $vn_clause = '';
    if (trim((string)$vn) !== '') {
        $vn_clause = "AND o.vn = '" . mysqli_real_escape_string($hos, trim($vn)) . "'";
    }
    $ptname_sql = "CAST(CONVERT(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) USING utf8) AS CHAR)";
    $sql = "SELECT o.vn, o.hn, o.vstdate,
            IFNULL(ov.vsttime, '') AS vsttime,
            o.rxdate, o.rxtime,
            $ptname_sql AS ptname,
            'OPD' AS patient_type, '' AS ward_name, '' AS bedno, '' AS an
        FROM opitemrece o
        " . sp_sql_drug_order_join('o', 'd') . "
        INNER JOIN patient p ON p.hn = o.hn
        LEFT JOIN ovst ov ON ov.vn = o.vn AND ov.vstdate = o.vstdate
        WHERE o.hn IN ($hn_in) AND o.vstdate = '$date_esc' AND o.qty > 0
          AND o.rxdate IS NOT NULL AND o.rxdate != '0000-00-00'
          AND o.rxtime IS NOT NULL AND TRIM(o.rxtime) != ''
          AND (o.an IS NULL OR TRIM(o.an) = '')
          AND o.vn IS NOT NULL AND TRIM(o.vn) <> ''
          $vn_clause
        ORDER BY o.rxdate DESC, o.rxtime DESC, o.item_no DESC
        LIMIT 1";
    $q = mysqli_query($hos, $sql);
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

/**
 * ดึงผู้ป่วย IPD รายคนตาม HN (admit อยู่ ณ วันที่กำหนด หรือระบุ AN)
 * @return array|null
 */
function sp_fetch_ipd_patient_by_hn($hos, $hn, $date, $an = '') {
    $hn = trim((string)$hn);
    if ($hn === '') {
        return null;
    }
    $all = sp_fetch_ipd_patients($hos, $date);
    $hn_norm = ltrim($hn, '0');
    foreach ($all as $p) {
        $p_hn = ltrim(trim((string)($p['hn'] ?? '')), '0');
        if ($p_hn !== $hn_norm && trim((string)($p['hn'] ?? '')) !== $hn) {
            continue;
        }
        if (trim((string)$an) !== '' && trim((string)($p['an'] ?? '')) !== trim($an)) {
            continue;
        }
        return $p;
    }
    return null;
}

function sp_screen_api_get_key($con) {
    $q = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='sp_screen_api_key' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return trim((string)($r['config_value'] ?? ''));
    }
    return '';
}

function sp_screen_api_save_key($con, $key) {
    $key_esc = mysqli_real_escape_string($con, trim((string)$key));
    return mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('sp_screen_api_key', '$key_esc')
        ON DUPLICATE KEY UPDATE config_value = '$key_esc'");
}

function sp_screen_api_verify($con, $key) {
    $stored = sp_screen_api_get_key($con);
    if ($stored === '') {
        return false;
    }
    return hash_equals($stored, trim((string)$key));
}

/**
 * คัดกรองผู้ป่วยรายคนตาม HN
 * @return array
 */
function sp_run_screening_hn($con, $hos, $patient_type, $screen_date, $hn, $vn = '', $an = '', array $options = []) {
    require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
    require_once __DIR__ . '/smart_pharma_telegram_helper.php';
    require_once __DIR__ . '/smart_pharma_webhook_helper.php';

    $notify = !array_key_exists('notify', $options) || !empty($options['notify']);
    $patient_type = $patient_type === 'IPD' ? 'IPD' : 'OPD';
    $hn = trim((string)$hn);
    if ($hn === '') {
        return ['ok' => false, 'message' => 'กรุณาระบุ HN'];
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $screen_date)) {
        $screen_date = sp_today_date();
    }

    $module_keys_opt = $options['module_keys'] ?? null;
    if (is_string($module_keys_opt)) {
        $module_keys_opt = preg_split('/[\s,;]+/', $module_keys_opt, -1, PREG_SPLIT_NO_EMPTY);
    }
    if (is_array($module_keys_opt) && count($module_keys_opt)) {
        $modules = sp_get_modules_by_keys($con, $module_keys_opt);
    } else {
        $modules = sp_get_modules($con, $patient_type);
    }
    if (empty($modules)) {
        return ['ok' => false, 'message' => 'ยังไม่ได้เปิดโมดูลคัดกรอง'];
    }

    if ($patient_type === 'OPD') {
        $pat = sp_fetch_opd_patient_by_hn($hos, $hn, $screen_date, $vn);
        if (!$pat) {
            return ['ok' => false, 'message' => 'ไม่พบผู้ป่วยนอกหรือยังไม่มียาสั่งในวันที่เลือก'];
        }
    } else {
        $pat = sp_fetch_ipd_patient_by_hn($hos, $hn, $screen_date, $an);
        if (!$pat) {
            return ['ok' => false, 'message' => 'ไม่พบผู้ป่วยในที่ admit อยู่ในวันที่เลือก'];
        }
        $enriched = sp_enrich_patients_rx_time($hos, [$pat], $screen_date);
        $with_drugs = sp_filter_patients_with_drug_orders($enriched);
        if (empty($with_drugs)) {
            return ['ok' => false, 'message' => 'พบผู้ป่วยในแต่ยังไม่มียาสั่งในวันที่เลือก'];
        }
        $pat = $with_drugs[0];
    }

    $di_batch = null;
    foreach ($modules as $mod) {
        if (($mod['module_key'] ?? '') === 'di') {
            $di_batch = sp_batch_screen_di_for_date($con, $hos, $screen_date, sp_extract_hn_list([$pat]));
            break;
        }
    }
    $screen_ctx = sp_build_screen_cache($con, $hos, [$pat], $screen_date, $modules);
    $screen = sp_screen_patient($con, $hos, $pat, $modules, $di_batch, $screen_date, $screen_ctx);
    $row = sp_build_screened_patient_row($pat, $screen, $patient_type, $screen_date, $modules);
    $muted_rows = sp_apply_alert_mutes($con, $patient_type, [$row]);
    $row = $muted_rows[0];
    $alert_log = sp_alert_log_sync($con, $patient_type, $screen_date, [$row]);

    $module_labels = [];
    $module_cols = [];
    foreach ($modules as $mod) {
        $module_labels[$mod['module_key']] = $mod['label_th'];
        $module_cols[] = [
            'key' => $mod['module_key'],
            'label' => $mod['label_th'],
            'icon' => $mod['icon'],
            'color' => $mod['color'],
        ];
    }

    $telegram_result = ['sent' => 0, 'skipped' => 0, 'errors' => []];
    $webhook_result = ['sent' => 0, 'skipped' => 0, 'errors' => []];
    if ($notify) {
        $telegram_result = sp_telegram_notify_screening($con, $patient_type, $screen_date, [$row], $module_labels);
        $webhook_result = sp_webhook_notify_screening($con, $patient_type, $screen_date, [$row], $module_labels);
    }

    $alerts = [];
    foreach ($row['modules'] ?? [] as $mk => $mod) {
        if (($mod['status'] ?? '') === 'alert') {
            $alerts[] = [
                'module_key' => $mk,
                'module_label' => $module_labels[$mk] ?? $mk,
                'level' => $mod['level'] ?? 'soft',
                'summary' => $mod['summary'] ?? '',
            ];
        }
    }

    return [
        'ok' => true,
        'message' => ($row['overall'] ?? '') === 'alert'
            ? 'พบ Alert ' . count($alerts) . ' รายการ'
            : 'คัดกรองผ่าน — ไม่พบ Alert',
        'patient' => $row,
        'modules' => $module_cols,
        'alerts' => $alerts,
        'alert_count' => count($alerts),
        'has_alert' => ($row['overall'] ?? '') === 'alert',
        'alert_log' => $alert_log,
        'telegram' => $telegram_result,
        'webhook' => $webhook_result,
    ];
}

/** รายชื่อผู้ป่วยใน (IPD) ที่ยัง Admit อยู่ ณ วันที่กำหนด */
function sp_fetch_ipd_patients($hos, $date) {
    if (!function_exists('hosxp_connection_alive') || !hosxp_connection_alive($hos)) {
        return [];
    }
    $date_esc = mysqli_real_escape_string($hos, $date);
    $ptname_sql = "CAST(CONVERT(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) USING utf8) AS CHAR)";
    $bed_sql = "(SELECT adm.bedno FROM iptadm adm
            WHERE adm.an = ia.an
              AND adm.indate <= '$date_esc'
              AND (adm.outdate IS NULL OR adm.outdate = '0000-00-00' OR adm.outdate >= '$date_esc')
            ORDER BY adm.indate DESC, adm.intime DESC
            LIMIT 1)";

    $queries = [
        "SELECT ia.an, ia.hn, IFNULL(ia.vn, '') AS vn,
                COALESCE(NULLIF(ia.regdate,'0000-00-00'), '$date_esc') AS vstdate,
                IFNULL(ia.regtime, '') AS vsttime,
                $ptname_sql AS ptname,
                'IPD' AS patient_type,
                CAST(CONVERT(IFNULL(w.name, '') USING utf8) AS CHAR) AS ward_name,
                IFNULL($bed_sql, IFNULL(ia.cur_bedno, '')) AS bedno
            FROM ipt ia
            INNER JOIN patient p ON p.hn = ia.hn
            LEFT JOIN ward w ON w.ward = ia.ward
            WHERE (ia.dchdate IS NULL OR ia.dchdate = '0000-00-00' OR ia.dchdate >= '$date_esc')
              AND ia.regdate IS NOT NULL
              AND ia.regdate != '0000-00-00'
              AND ia.regdate <= '$date_esc'
            ORDER BY ward_name, bedno, ia.an",
        "SELECT ia.an, ia.hn, IFNULL(ia.vn, '') AS vn,
                COALESCE(NULLIF(ia.regdate,'0000-00-00'), '$date_esc') AS vstdate,
                IFNULL(ia.regtime, '') AS vsttime,
                $ptname_sql AS ptname,
                'IPD' AS patient_type,
                CAST(CONVERT(IFNULL(w2.name, IFNULL(w1.name, '')) USING utf8) AS CHAR) AS ward_name,
                IFNULL($bed_sql, '') AS bedno
            FROM ipt ia
            INNER JOIN patient p ON p.hn = ia.hn
            LEFT JOIN ward_admit_snapshot wa ON wa.an = ia.an
            LEFT JOIN ward w1 ON w1.ward = wa.ward
            LEFT JOIN ward w2 ON w2.ward = ia.ward
            WHERE (ia.dchdate IS NULL OR ia.dchdate = '0000-00-00' OR ia.dchdate >= '$date_esc')
              AND ia.regdate IS NOT NULL
              AND ia.regdate != '0000-00-00'
              AND ia.regdate <= '$date_esc'
            ORDER BY ward_name, bedno, ia.an",
    ];

    foreach ($queries as $sql) {
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        $list = [];
        while ($r = mysqli_fetch_assoc($q)) {
            $list[] = $r;
        }
        if (!empty($list)) {
            return $list;
        }
    }
    return [];
}

function sp_patient_icodes_on_date($hos, $hn, $vstdate, $vn = '') {
    $hn_esc = mysqli_real_escape_string($hos, $hn);
    $date_esc = mysqli_real_escape_string($hos, $vstdate);
    $vn_clause = '';
    if ($vn !== '') {
        $vn_clause = "AND o.vn = '" . mysqli_real_escape_string($hos, $vn) . "'";
    }
    $sql = "SELECT DISTINCT o.icode FROM opitemrece o
        WHERE o.hn = '$hn_esc' AND o.vstdate = '$date_esc' AND o.qty > 0 $vn_clause";
    $q = mysqli_query($hos, $sql);
    $codes = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $c = trim($r['icode'] ?? '');
            if ($c !== '') {
                $codes[] = $c;
            }
        }
    }
    return $codes;
}

function sp_result_pass($summary = '') {
    return ['status' => 'pass', 'level' => '', 'summary' => $summary ?: 'ผ่าน', 'details' => [], 'items' => []];
}

function sp_result_alert($level, $summary, array $details = [], array $items = []) {
    if (empty($details) && $summary !== '') {
        $details = array_values(array_filter(array_map('trim', preg_split('/\s*;\s*/', $summary))));
    }
    return [
        'status' => 'alert',
        'level' => $level ?: 'soft',
        'summary' => $summary,
        'details' => $details,
        'items' => $items,
    ];
}

function sp_result_na($summary = 'ไม่เกี่ยวข้อง') {
    return ['status' => 'na', 'level' => '', 'summary' => $summary, 'details' => [], 'items' => []];
}

/** โมดูลที่ถอดออกจากเมนู Monitor แล้ว — ไม่แสดงในตั้งค่า / แจ้งเตือน */
function sp_retired_module_keys() {
    return ['cumulative', 'hbv', 'ua'];
}

function sp_is_retired_module($module_key) {
    return in_array(trim((string)$module_key), sp_retired_module_keys(), true);
}

function sp_patient_screen_key($patient, $screen_date = '') {
    $hn = trim((string)($patient['hn'] ?? ''));
    $vn = trim((string)($patient['vn'] ?? ''));
    $ptype = trim((string)($patient['patient_type'] ?? ''));
    $date = trim((string)$screen_date);
    if ($date === '') {
        if ($ptype === 'IPD') {
            $date = trim((string)($patient['rxdate'] ?? ''));
        }
        if ($date === '') {
            $date = trim((string)($patient['vstdate'] ?? ''));
        }
    }
    return $hn . '|' . $vn . '|' . $date;
}

function sp_patient_screen_key_variants($patient, $screen_date = '') {
    $hn = trim((string)($patient['hn'] ?? ''));
    if ($hn === '') {
        return [];
    }
    $vn = trim((string)($patient['vn'] ?? ''));
    $ptype = trim((string)($patient['patient_type'] ?? ''));
    $date = trim((string)$screen_date);
    if ($date === '') {
        if ($ptype === 'IPD') {
            $date = trim((string)($patient['rxdate'] ?? ''));
        }
        if ($date === '') {
            $date = trim((string)($patient['vstdate'] ?? ''));
        }
    }
    $keys = [$hn . '|' . $vn . '|' . $date];
    if ($vn !== '') {
        $keys[] = $hn . '||' . $date;
    }
    return array_values(array_unique($keys));
}

/** คีย์สำหรับ lookup DI batch — IPD ใช้วันที่คัดกรอง ไม่ใช่ regdate */
function sp_is_screen_date_today($screen_date) {
    return trim((string)$screen_date) === sp_today_date();
}

function sp_slot_time_windows() {
    return ['00-08', '08-16', '16-24', 'full'];
}

function sp_live_time_windows() {
    return ['30m', '1h', '2h', '3h', '6h'];
}

function sp_live_window_minutes($window) {
    $map = [
        '30m' => 30,
        '1h' => 60,
        '2h' => 120,
        '3h' => 180,
        '6h' => 360,
    ];
    return (int)($map[$window] ?? 0);
}

function sp_allowed_time_windows($screen_date) {
    if (sp_is_screen_date_today($screen_date)) {
        return array_merge(sp_live_time_windows(), sp_slot_time_windows(), ['custom']);
    }
    return sp_slot_time_windows();
}

function sp_time_window_label($window, $time_from = '', $time_to = '') {
    $labels = [
        '30m' => '30 นาทีล่าสุด',
        '1h' => '1 ชั่วโมงล่าสุด',
        '2h' => '2 ชั่วโมงล่าสุด',
        '3h' => '3 ชั่วโมงล่าสุด',
        '6h' => '6 ชั่วโมงล่าสุด',
        '00-08' => '00:00–08:00',
        '08-16' => '08:01–16:00',
        '16-24' => '16:01–24:00',
        'full' => 'ทั้งวัน',
        'custom' => 'ช่วงเวลาที่เลือก',
    ];
    if ($window === 'custom' && $time_from !== '' && $time_to !== '') {
        return sp_format_time_hm($time_from) . '–' . sp_format_time_hm($time_to);
    }
    return $labels[$window] ?? $window;
}

function sp_normalize_time_window($window, $screen_date = null) {
    $screen_date = $screen_date ?? date('Y-m-d');
    $allowed = sp_allowed_time_windows($screen_date);
    if (in_array($window, $allowed, true)) {
        return $window;
    }
    return sp_is_screen_date_today($screen_date) ? '30m' : 'full';
}

/**
 * Fingerprint รายชื่อผู้ป่วยในชุดคัดกรอง — เปลี่ยนเมื่อมีคนใหม่ / เวลาสั่งยาล่าสุดเปลี่ยน
 */
function sp_patients_fingerprint(array $patients) {
    $n = count($patients);
    $max_ts = 0;
    $parts = [];
    foreach ($patients as $p) {
        $ts = (int)(sp_patient_order_timestamp($p) ?: 0);
        if ($ts > $max_ts) {
            $max_ts = $ts;
        }
        $hn = trim((string)($p['hn'] ?? ''));
        $vn = trim((string)($p['vn'] ?? ''));
        $an = trim((string)($p['an'] ?? ''));
        $parts[] = $hn . '|' . $vn . '|' . $an . '|' . $ts;
    }
    sort($parts);
    return $n . '_' . $max_ts . '_' . substr(hash('sha256', implode(';', $parts)), 0, 12);
}

/**
 * Fingerprint เบาๆ จาก HOSxP — ตรวจว่ามีออเดอร์ยาใหม่/แก้ในวันนั้นหรือยัง (ก่อนดึงรายชื่อเต็ม)
 */
function sp_day_orders_fingerprint($hos, $patient_type, $screen_date) {
    $date_esc = mysqli_real_escape_string($hos, $screen_date);
    $type = strtoupper(trim((string)$patient_type)) === 'IPD' ? 'IPD' : 'OPD';
    if ($type === 'OPD') {
        $scope = "(o.an IS NULL OR TRIM(o.an) = '') AND o.vn IS NOT NULL AND TRIM(o.vn) <> ''";
        $dist = 'o.vn';
        $date_col = 'o.vstdate';
    } else {
        $scope = "o.an IS NOT NULL AND TRIM(o.an) <> ''";
        $dist = 'o.an';
        // IPD ใช้วันสั่งยา (rxdate) เพราะผู้ป่วย admit ค้างข้ามวัน
        $date_col = 'o.rxdate';
    }
    $sql = "SELECT COUNT(DISTINCT $dist) AS c,
                   COALESCE(MAX(CONCAT(o.rxdate, ' ', o.rxtime)), '') AS mx
            FROM opitemrece o
            " . sp_sql_drug_order_join('o', 'd') . "
            WHERE $date_col = '$date_esc' AND o.qty > 0
              AND o.rxdate IS NOT NULL AND o.rxdate != '0000-00-00'
              AND o.rxtime IS NOT NULL AND TRIM(o.rxtime) != ''
              AND $scope";
    $q = @mysqli_query($hos, $sql);
    $c = 0;
    $mx = '';
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $c = (int)($r['c'] ?? 0);
        $mx = trim((string)($r['mx'] ?? ''));
    }
    return $c . '_' . substr(hash('sha256', $mx), 0, 10);
}

/** แปลง HH:MM หรือ HH:MM:SS เป็นวินาทีในวัน */
function sp_time_to_seconds_of_day($time) {
    $time = trim((string)$time);
    if ($time === '') {
        return null;
    }
    if (strlen($time) === 5) {
        $time .= ':00';
    }
    if (!preg_match('/^(\d{1,2}):(\d{2}):(\d{2})$/', $time, $m)) {
        return null;
    }
    $h = (int)$m[1];
    $min = (int)$m[2];
    $s = (int)$m[3];
    if ($h > 23 || $min > 59 || $s > 59) {
        return null;
    }
    return ($h * 3600) + ($min * 60) + $s;
}

function sp_format_time_hm($time) {
    $sec = sp_time_to_seconds_of_day($time);
    if ($sec === null) {
        return trim((string)$time);
    }
    $h = (int)floor($sec / 3600);
    $m = (int)floor(($sec % 3600) / 60);
    return sprintf('%02d:%02d', $h, $m);
}

function sp_normalize_custom_time_range($time_from, $time_to) {
    $from = sp_time_to_seconds_of_day($time_from);
    $to = sp_time_to_seconds_of_day($time_to);
    if ($from === null || $to === null) {
        return null;
    }
    return ['from' => $from, 'to' => $to, 'from_raw' => sp_format_time_hm($time_from), 'to_raw' => sp_format_time_hm($time_to)];
}

/** กรองตามช่วงเวลาสั่งยาในวัน (HH:MM–HH:MM) */
function sp_filter_patients_by_custom_time(array $patients, $time_from, $time_to) {
    $range = sp_normalize_custom_time_range($time_from, $time_to);
    if ($range === null) {
        return $patients;
    }
    $from = $range['from'];
    $to = $range['to'];
    $out = [];
    foreach ($patients as $p) {
        $sec = sp_patient_rx_seconds_of_day($p);
        if ($sec === null) {
            continue;
        }
        if ($from <= $to) {
            if ($sec >= $from && $sec <= $to) {
                $out[] = $p;
            }
        } elseif ($sec >= $from || $sec <= $to) {
            $out[] = $p;
        }
    }
    return $out;
}

/** วันที่/เวลาสั่งยาล่าสุด — rxdate/rxtime ก่อน vstdate/vsttime */
function sp_patient_order_datetime(array $patient) {
    $date = trim((string)($patient['rxdate'] ?? ''));
    if ($date === '' || $date === '0000-00-00') {
        $date = trim((string)($patient['vstdate'] ?? ''));
    }
    $time = trim((string)($patient['rxtime'] ?? ''));
    if ($time === '') {
        $time = trim((string)($patient['vsttime'] ?? ''));
    }
    return ['date' => $date, 'time' => $time];
}

function sp_patient_rx_timestamp(array $patient) {
    $d = trim((string)($patient['rxdate'] ?? ''));
    if ($d === '' || $d === '0000-00-00') {
        return null;
    }
    $t = trim((string)($patient['rxtime'] ?? ''));
    if ($t === '') {
        return null;
    }
    if (strlen($t) === 5) {
        $t .= ':00';
    }
    $dt = DateTime::createFromFormat('Y-m-d H:i:s', $d . ' ' . $t, sp_timezone());
    if (!$dt) {
        try {
            $dt = new DateTime($d . ' ' . $t, sp_timezone());
        } catch (Exception $e) {
            return null;
        }
    }
    return $dt->getTimestamp();
}

function sp_patient_rx_seconds_of_day(array $patient) {
    $t = trim((string)($patient['rxtime'] ?? ''));
    if ($t === '') {
        return null;
    }
    if (strlen($t) === 5) {
        $t .= ':00';
    }
    if (!preg_match('/^(\d{1,2}):(\d{2}):(\d{2})$/', $t, $m)) {
        return null;
    }
    return ((int)$m[1] * 3600) + ((int)$m[2] * 60) + (int)$m[3];
}

/** แสดงผล — fallback vst ถ้าไม่มียาสั่ง */
function sp_patient_order_timestamp(array $patient) {
    return sp_patient_rx_timestamp($patient) ?: (function ($p) {
        $d = trim((string)($p['vstdate'] ?? ''));
        if ($d === '' || $d === '0000-00-00') {
            return null;
        }
        $t = trim((string)($p['vsttime'] ?? '00:00:00')) ?: '00:00:00';
        if (strlen($t) === 5) {
            $t .= ':00';
        }
        $ts = strtotime($d . ' ' . $t);
        return $ts ?: null;
    })($patient);
}

/** เติม rxdate/rxtime ล่าสุดจาก opitemrece ต่อ visit */
function sp_enrich_patients_rx_time($hos, array $patients, $screen_date) {
    if (empty($patients)) {
        return $patients;
    }
    $date_esc = mysqli_real_escape_string($hos, $screen_date);
    $sql = "SELECT o.hn, o.vn, IFNULL(o.an, '') AS an, o.rxdate, o.rxtime
        FROM opitemrece o
        " . sp_sql_drug_order_join('o', 'd') . "
        WHERE o.vstdate = '$date_esc' AND o.qty > 0
          AND o.rxdate IS NOT NULL AND o.rxdate != '0000-00-00'
          AND o.rxtime IS NOT NULL AND TRIM(o.rxtime) != ''
        ORDER BY o.rxdate DESC, o.rxtime DESC, o.item_no DESC";
    $q = mysqli_query($hos, $sql);
    $by_vn = [];
    $by_an = [];
    $by_hn = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $hn = trim($r['hn'] ?? '');
            $vn = trim($r['vn'] ?? '');
            $an = trim($r['an'] ?? '');
            if ($vn !== '' && !isset($by_vn[$vn])) {
                $by_vn[$vn] = $r;
            }
            if ($an !== '' && !isset($by_an[$an])) {
                $by_an[$an] = $r;
            }
            if ($hn !== '' && !isset($by_hn[$hn])) {
                $by_hn[$hn] = $r;
            }
        }
    }
    foreach ($patients as &$p) {
        $vn = trim($p['vn'] ?? '');
        $an = trim($p['an'] ?? '');
        $hn = trim($p['hn'] ?? '');
        $rx = null;
        if ($vn !== '' && isset($by_vn[$vn])) {
            $rx = $by_vn[$vn];
        } elseif ($an !== '' && isset($by_an[$an])) {
            $rx = $by_an[$an];
        } elseif ($hn !== '' && isset($by_hn[$hn])) {
            $rx = $by_hn[$hn];
        }
        if ($rx) {
            $p['rxdate'] = $rx['rxdate'];
            $p['rxtime'] = $rx['rxtime'];
        } else {
            $p['rxdate'] = '';
            $p['rxtime'] = '';
        }
    }
    unset($p);
    return $patients;
}

/** คัดเฉพาะผู้ป่วยที่มีรายการยาจริง (มี rxdate/rxtime จาก drugitems) */
function sp_filter_patients_with_drug_orders(array $patients) {
    return array_values(array_filter($patients, function ($p) {
        $d = trim((string)($p['rxdate'] ?? ''));
        $t = trim((string)($p['rxtime'] ?? ''));
        return $d !== '' && $d !== '0000-00-00' && $t !== '';
    }));
}

function sp_patient_in_time_slot($seconds, $slot) {
    $s8 = 8 * 3600;
    $s16 = 16 * 3600;
    $eod = (24 * 3600) - 1;
    switch ($slot) {
        case '00-08':
            return $seconds >= 0 && $seconds <= $s8;
        case '08-16':
            return $seconds > $s8 && $seconds <= $s16;
        case '16-24':
            return $seconds > $s16 && $seconds <= $eod;
        default:
            return false;
    }
}

/** กรองรายชื่อผู้ป่วยตามช่วงเวลาสั่งยา (rxdate/rxtime) */
function sp_filter_patients_by_time_window(array $patients, $screen_date, $window) {
    $screen_date = trim((string)$screen_date);
    $window = sp_normalize_time_window($window, $screen_date);

    if ($window === 'full') {
        return $patients;
    }

    $out = [];
    $live_mins = sp_live_window_minutes($window);
    if (sp_is_screen_date_today($screen_date) && $live_mins > 0) {
        $end = sp_now_timestamp();
        $start = $end - ($live_mins * 60);
        foreach ($patients as $p) {
            $ts = sp_patient_rx_timestamp($p);
            if ($ts === null) {
                continue;
            }
            if ($ts >= $start && $ts <= $end) {
                $out[] = $p;
            }
        }
        return $out;
    }

    if (in_array($window, ['00-08', '08-16', '16-24'], true)) {
        foreach ($patients as $p) {
            $sec = sp_patient_rx_seconds_of_day($p);
            if ($sec === null) {
                continue;
            }
            if (sp_patient_in_time_slot($sec, $window)) {
                $out[] = $p;
            }
        }
        return $out;
    }

    return $patients;
}

/** กรองรายชื่อผู้ป่วยตามแท็บช่วงเวลาก่อนคัดกรอง — ไม่ต้องประมวลผลทั้งวันเมื่อดู 1 ชั่วโมงล่าสุด */
function sp_patients_for_time_window(array $patients, $screen_date, $window, $time_from = '', $time_to = '') {
    $window = sp_normalize_time_window($window, $screen_date);
    if ($window === 'full') {
        return $patients;
    }
    if ($window === 'custom' && $time_from !== '' && $time_to !== '') {
        return sp_filter_patients_by_custom_time($patients, $time_from, $time_to);
    }
    return sp_filter_patients_by_time_window($patients, $screen_date, $window);
}

/** icode ต่อ visit — query เดียวสำหรับทุกคนในวัน */
function sp_batch_patient_icodes_map($hos, $screen_date, array $patients) {
    $vns = [];
    $ans = [];
    $hns = [];
    $by_vn = [];
    $by_an = [];
    $by_hn = [];
    foreach ($patients as $p) {
        $vn = trim((string)($p['vn'] ?? ''));
        $an = trim((string)($p['an'] ?? ''));
        $hn = trim((string)($p['hn'] ?? ''));
        $keys = sp_patient_screen_key_variants($p, $screen_date);
        if ($vn !== '') {
            $vns[$vn] = true;
            if (!isset($by_vn[$vn])) {
                $by_vn[$vn] = [];
            }
            foreach ($keys as $k) {
                $by_vn[$vn][$k] = true;
            }
        }
        if ($an !== '') {
            $ans[$an] = true;
            if (!isset($by_an[$an])) {
                $by_an[$an] = [];
            }
            foreach ($keys as $k) {
                $by_an[$an][$k] = true;
            }
        }
        if ($hn !== '') {
            $hns[$hn] = true;
            if (!isset($by_hn[$hn])) {
                $by_hn[$hn] = [];
            }
            foreach ($keys as $k) {
                $by_hn[$hn][$k] = true;
            }
        }
    }
    if (empty($vns) && empty($ans) && empty($hns)) {
        return [];
    }
    $date_esc = mysqli_real_escape_string($hos, $screen_date);
    $where_parts = [];
    if (!empty($vns)) {
        $vn_in = [];
        foreach (array_keys($vns) as $vn) {
            $vn_in[] = "'" . mysqli_real_escape_string($hos, $vn) . "'";
        }
        $where_parts[] = "(o.vn <> '' AND o.vn IN (" . implode(',', $vn_in) . "))";
    }
    if (!empty($ans)) {
        $an_in = [];
        foreach (array_keys($ans) as $an) {
            $an_in[] = "'" . mysqli_real_escape_string($hos, $an) . "'";
        }
        $where_parts[] = "(o.an <> '' AND o.an IN (" . implode(',', $an_in) . "))";
    }
    if (!empty($hns)) {
        $hn_in = [];
        foreach (array_keys($hns) as $hn) {
            $hn_in[] = "'" . mysqli_real_escape_string($hos, $hn) . "'";
        }
        $where_parts[] = "(o.hn IN (" . implode(',', $hn_in) . "))";
    }
    if (empty($where_parts)) {
        return [];
    }
    $sql = "SELECT o.vn, o.an, o.hn, o.icode FROM opitemrece o
        " . sp_sql_drug_order_join('o', 'd') . "
        WHERE o.vstdate = '$date_esc' AND o.qty > 0
          AND (" . implode(' OR ', $where_parts) . ")";
    $q = mysqli_query($hos, $sql);
    $map = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $vn = trim((string)($r['vn'] ?? ''));
            $an = trim((string)($r['an'] ?? ''));
            $hn = trim((string)($r['hn'] ?? ''));
            $c = trim((string)($r['icode'] ?? ''));
            if ($c === '') {
                continue;
            }
            $targets = [];
            if ($vn !== '' && isset($by_vn[$vn])) {
                $targets = array_merge($targets, array_keys($by_vn[$vn]));
            }
            if ($an !== '' && isset($by_an[$an])) {
                $targets = array_merge($targets, array_keys($by_an[$an]));
            }
            if ($hn !== '' && isset($by_hn[$hn])) {
                $targets = array_merge($targets, array_keys($by_hn[$hn]));
            }
            $targets = array_values(array_unique($targets));
            foreach ($targets as $key) {
                if (!isset($map[$key])) {
                    $map[$key] = [];
                }
                $map[$key][$c] = true;
            }
        }
    }
    foreach ($map as $k => $codes) {
        $map[$k] = array_keys($codes);
    }
    return $map;
}

/** HLA alert ทั้งวัน — query เดียว */
function sp_batch_hla_alert_map($con, $hos, $screen_date) {
    ensure_monitor_hla_alert_level_column($con);
    $drug_settings = hla_load_drug_settings($con);
    if (empty($drug_settings)) {
        return ['no_settings' => true, 'icodes' => [], 'alerts' => [], 'alert_levels' => []];
    }
    $hla_icodes = array_fill_keys(array_keys($drug_settings), true);

    $cfg = [];
    $qc = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name LIKE 'hla_%'");
    if ($qc) {
        while ($r = mysqli_fetch_assoc($qc)) {
            $cfg[$r['config_name']] = $r['config_value'];
        }
    }
    $lb = (int)($cfg['hla_lookback_months'] ?? 24);
    $lab_in = monitor_lab_codes_sql_in($hos, $cfg['hla_lab_items_code'] ?? '2281');
    $ptnote = mysqli_real_escape_string($hos, $cfg['hla_ptnote_regex'] ?? 'ผ่านการตัดกรองยีนแพ้ยา|HLA-B');
    $rxnote = mysqli_real_escape_string($hos, $cfg['hla_rxnote_regex'] ?? 'ยีนแพ้ยา|HLA-B|ตรวจยีน');
    $date_esc = mysqli_real_escape_string($hos, $screen_date);
    $icode_in = implode(',', array_map(function ($c) use ($hos) {
        return "'" . mysqli_real_escape_string($hos, $c) . "'";
    }, array_keys($hla_icodes)));

    $sql = "SELECT DISTINCT o.hn, o.vn, o.icode FROM opitemrece o
        WHERE o.vstdate = '$date_esc' AND o.icode IN ($icode_in) AND o.qty > 0
        AND NOT EXISTS (SELECT 1 FROM opitemrece o2 WHERE o2.hn=o.hn AND o2.icode=o.icode
            AND o2.vstdate < o.vstdate AND o2.vstdate >= DATE_SUB(o.vstdate, INTERVAL $lb MONTH))
        AND NOT EXISTS (SELECT 1 FROM lab_order lo2 JOIN lab_head lh2 ON lo2.lab_order_number=lh2.lab_order_number
            WHERE lh2.hn=o.hn AND lo2.lab_items_code IN ($lab_in)
            AND lh2.order_date < o.vstdate AND lh2.order_date >= DATE_SUB(o.vstdate, INTERVAL $lb MONTH))
        AND NOT EXISTS (SELECT 1 FROM ptnote pn2 WHERE pn2.hn=o.hn
            AND CAST(CONVERT(pn2.plain_text USING utf8) AS binary) REGEXP '$ptnote')
        AND NOT EXISTS (SELECT 1 FROM patient_rx_note pr2 WHERE pr2.hn=o.hn
            AND CAST(CONVERT(pr2.rx_note USING utf8) AS binary) REGEXP '$rxnote')";

    $alerts = [];
    $alert_levels = [];
    $alert_icodes = [];
    $q2 = mysqli_query($hos, $sql);
    if ($q2) {
        while ($r = mysqli_fetch_assoc($q2)) {
            $key = sp_patient_screen_key([
                'hn' => $r['hn'] ?? '',
                'vn' => $r['vn'] ?? '',
                'vstdate' => $screen_date,
            ]);
            $icode = trim((string)($r['icode'] ?? ''));
            $lvl = $drug_settings[$icode]['alert_level'] ?? hla_default_alert_level();
            $hn = trim((string)($r['hn'] ?? ''));
            $hn_key = $hn . '||' . $screen_date;
            foreach (array_unique([$key, $hn_key]) as $k) {
                $alerts[$k] = true;
                $prev = $alert_levels[$k] ?? 'soft';
                $alert_levels[$k] = hla_resolve_alert_level([$prev, $lvl]);
                if ($icode === '') {
                    continue;
                }
                if (!isset($alert_icodes[$k])) {
                    $alert_icodes[$k] = [];
                }
                if (!in_array($icode, $alert_icodes[$k], true)) {
                    $alert_icodes[$k][] = $icode;
                }
            }
        }
    }
    return [
        'no_settings' => false,
        'icodes' => array_keys($hla_icodes),
        'drugs' => $drug_settings,
        'alerts' => $alerts,
        'alert_levels' => $alert_levels,
        'alert_icodes' => $alert_icodes,
    ];
}

/** UA ทั้งวัน — ดึง lab ครั้งเดียว แล้วประเมินใน PHP */
function sp_batch_ua_results_map($con, $hos, $screen_date, array $icodes_map) {
    $rules = [];
    $q = mysqli_query($con, "SELECT * FROM monitor_ua_settings");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rules[] = $r;
        }
    }
    if (empty($rules)) {
        return ['no_rules' => true, 'results' => []];
    }
    $rule_map = [];
    $lab_codes = [];
    foreach ($rules as $r) {
        $c = trim((string)($r['icode'] ?? ''));
        if ($c === '') {
            continue;
        }
        $rule_map[$c][] = $r;
        $lc = trim((string)($r['lab_code'] ?? ''));
        if ($lc !== '') {
            $lab_codes[$lc] = true;
        }
    }
    if (empty($rule_map)) {
        return ['no_rules' => true, 'results' => []];
    }

    $candidates = [];
    $vn_by_key = [];
    foreach ($icodes_map as $pkey => $icodes) {
        $has_rule = false;
        foreach ($icodes as $icode) {
            if (isset($rule_map[$icode])) {
                $has_rule = true;
                break;
            }
        }
        if (!$has_rule) {
            continue;
        }
        $parts = explode('|', $pkey, 3);
        $vn = $parts[1] ?? '';
        if ($vn === '') {
            continue;
        }
        $candidates[$pkey] = $icodes;
        $vn_by_key[$pkey] = $vn;
    }

    $lab_latest = [];
    if (!empty($candidates) && !empty($lab_codes)) {
        $vn_in = [];
        foreach ($vn_by_key as $vn) {
            $vn_in[$vn] = "'" . mysqli_real_escape_string($hos, $vn) . "'";
        }
        $lab_in = [];
        foreach (array_keys($lab_codes) as $lc) {
            $lab_in[] = "'" . mysqli_real_escape_string($hos, $lc) . "'";
        }
        $sql = "SELECT lh.vn, lo.lab_items_code, lo.lab_order_result, lh.order_date
            FROM lab_order lo
            JOIN lab_head lh ON lh.lab_order_number = lo.lab_order_number
            WHERE lh.vn IN (" . implode(',', array_values($vn_in)) . ")
              AND lo.lab_items_code IN (" . implode(',', $lab_in) . ")
            ORDER BY lh.order_date DESC";
        $ql = mysqli_query($hos, $sql);
        if ($ql) {
            while ($row = mysqli_fetch_assoc($ql)) {
                $vn = trim((string)($row['vn'] ?? ''));
                $code = trim((string)($row['lab_items_code'] ?? ''));
                $lk = $vn . '|' . $code;
                if (!isset($lab_latest[$lk])) {
                    $lab_latest[$lk] = trim((string)($row['lab_order_result'] ?? ''));
                }
            }
        }
    }

    $results = [];
    foreach ($candidates as $pkey => $icodes) {
        $vn = $vn_by_key[$pkey] ?? '';
        $found = false;
        foreach ($icodes as $icode) {
            if (!isset($rule_map[$icode])) {
                continue;
            }
            foreach ($rule_map[$icode] as $rule) {
                $lab_code = trim((string)($rule['lab_code'] ?? ''));
                $lk = $vn . '|' . $lab_code;
                if (!isset($lab_latest[$lk])) {
                    continue;
                }
                $res = $lab_latest[$lk];
                if (monitor_lab_match_condition($rule['condition_type'] ?? 'range', $rule['condition_value'] ?? '', $res)) {
                    $lvl = ($rule['alert_level'] ?? '') === 'hard' ? 'hard' : 'soft';
                    $results[$pkey] = sp_result_alert($lvl, ($rule['alert_message'] ?? 'UA Alert') . ': ' . $res);
                    $found = true;
                    break 2;
                }
            }
        }
        if (!$found) {
            $results[$pkey] = sp_result_pass();
        }
    }
    return ['no_rules' => false, 'results' => $results];
}

function sp_lab_organ_types_sql($organ) {
    if ($organ === 'renal') {
        return "'GFR','CKD_EPI','SERUM_CR'";
    }
    if ($organ === 'hepatic') {
        return "'Bilirubin','Bilirubin_xULN','AST','ALT','AST_xULN','ALT_xULN','AST_ALT_xULN','DirectBilirubin','IndirectBilirubin','CHILD_PUGH','MELD_NA'";
    }
    return "'CUSTOM'";
}

function sp_load_lab_organ_rule_map($con, $organ) {
    ensure_drug_safety_rules_hosxp_columns($con);
    ensure_drug_safety_rules_lab_items_columns($con);
    ensure_drug_safety_rules_lab_condition_columns($con);
    ensure_drug_safety_rules_alert_level_column($con);
    ensure_drug_safety_rules_patient_extra_columns($con);
    ensure_drug_safety_rules_duration_columns($con);
    ensure_drug_safety_rules_dose_per_admin_columns($con);
    ensure_drug_safety_rules_exempt_method_columns($con);
    ensure_drug_safety_rules_first_order_columns($con);

    $types = sp_lab_organ_types_sql($organ);
    $q = mysqli_query(
        $con,
        "SELECT * FROM drug_safety_rules
         WHERE active_status=1 AND lab_type IN ($types)
           AND drug_icode IS NOT NULL AND TRIM(drug_icode)<>''"
    );
    $rule_map = [];
    if (!$q) {
        return $rule_map;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $icode = trim((string)($r['drug_icode'] ?? ''));
        if ($icode === '') {
            continue;
        }
        if ($organ === 'other' && trim((string)($r['lab_items_code'] ?? '')) === '') {
            continue;
        }
        $rule_map[$icode][] = $r;
    }
    return $rule_map;
}

function sp_lab_sys_config($con) {
    static $sys = null;
    if ($sys !== null) {
        return $sys;
    }
    $sys = [];
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name LIKE 'h\\_%' OR config_name LIKE 'lab\\_%'");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $sys[$r['config_name']] = $r['config_value'];
        }
    }
    return $sys;
}

/**
 * คัดกรอง Lab (renal/hepatic/other) ทั้งวัน — ประเมินเงื่อนไขจริงเพื่อ Alert Log / Telegram
 * @return array{no_rules:bool, results:array}
 */
function sp_batch_lab_organ_results_map($con, $hos, $screen_date, $organ, array $patients, array $icodes_map) {
    $organ = in_array($organ, ['renal', 'hepatic', 'other'], true) ? $organ : 'other';
    $rule_map = sp_load_lab_organ_rule_map($con, $organ);
    if (empty($rule_map)) {
        return ['no_rules' => true, 'results' => []];
    }

    $patients_by_key = [];
    foreach ($patients as $p) {
        foreach (sp_patient_screen_key_variants($p, $screen_date) as $k) {
            $patients_by_key[$k] = $p;
        }
    }

    $sys = ($organ === 'other') ? [] : sp_lab_sys_config($con);
    $tbili_uln = (float)($sys['lab_tbili_uln'] ?? 1.2);
    $ast_uln = (float)($sys['lab_ast_uln'] ?? 40);
    $alt_uln = (float)($sys['lab_alt_uln'] ?? 40);
    if ($tbili_uln <= 0) {
        $tbili_uln = 1.2;
    }
    if ($ast_uln <= 0) {
        $ast_uln = 40;
    }
    if ($alt_uln <= 0) {
        $alt_uln = 40;
    }

    $lab_memo = [];
    $lab_lookback_years = 4;
    $results = [];

    $fo_icodes = [];
    $max_fo_lookback = 0;
    foreach ($rule_map as $ic => $rs) {
        foreach ($rs as $rule) {
            if (!empty($rule['first_order_only'])) {
                $fo_icodes[$ic] = true;
                $max_fo_lookback = max($max_fo_lookback, (int)($rule['first_order_lookback_days'] ?? 0));
            }
        }
    }
    $fo_hns = [];
    foreach ($patients as $p) {
        $fo_hns[] = $p['hn'] ?? '';
    }
    $first_order_map = !empty($fo_icodes)
        ? monitor_lab_prefetch_first_orders($hos, $fo_hns, array_keys($fo_icodes), $screen_date, $max_fo_lookback, $screen_date)
        : [];
    $need_hepatic_scores = false;
    if ($organ === 'hepatic') {
        foreach ($rule_map as $rs) {
            foreach ($rs as $rule) {
                if (function_exists('monitor_lab_hepatic_is_score_type') && monitor_lab_hepatic_is_score_type($rule['lab_type'] ?? '')) {
                    $need_hepatic_scores = true;
                    break 2;
                }
            }
        }
    }
    $hepatic_clinical = [];
    if ($need_hepatic_scores) {
        $hepatic_clinical = monitor_lab_hepatic_prefetch_clinical($hos, $fo_hns, $screen_date);
    }

    foreach ($icodes_map as $pkey => $icodes) {
        $pat = $patients_by_key[$pkey] ?? null;
        if (!$pat) {
            continue;
        }
        $matched_by_icode = [];
        foreach ($icodes as $ic) {
            if (!empty($rule_map[$ic])) {
                $matched_by_icode[$ic] = $rule_map[$ic];
            }
        }
        if (empty($matched_by_icode)) {
            continue;
        }

        $hn = $pat['hn'] ?? '';
        $orders = sp_lab_patient_rule_orders($hos, $pat, $screen_date, array_keys($matched_by_icode));
        if (empty($orders)) {
            $results[$pkey] = sp_result_pass('ไม่เข้าเงื่อนไข Lab');
            continue;
        }

        $alert_summaries = [];
        $alert_details = [];
        $has_hard = false;
        $has_soft = false;
        $seen_alert_keys = [];

        foreach ($orders as $order) {
            $icode = trim((string)($order['icode'] ?? ''));
            if ($icode === '' || empty($matched_by_icode[$icode])) {
                continue;
            }
            if (monitor_lab_should_exempt_method_from_rules($matched_by_icode[$icode], $order['method'] ?? '')) {
                continue;
            }
            $order_dt = monitor_lab_order_datetime($order);
            $order_date = $order_dt['date'] !== '' ? $order_dt['date'] : $screen_date;
            $order_time = $order_dt['time'];
            // cutoff ตามวันของออเดอร์ (opitemrece.vstdate) — ไม่ใช้วัน admit ของ IPD
            $lab_cutoff = trim((string)($order['vstdate'] ?? ''));
            if ($lab_cutoff === '' || $lab_cutoff === '0000-00-00') {
                $lab_cutoff = $order_date;
            }
            $order_lab_min = ($order_date !== '' && $order_date !== '0000-00-00')
                ? date('Y-m-d', strtotime($order_date . " -{$lab_lookback_years} years"))
                : date('Y-m-d', strtotime($screen_date . " -{$lab_lookback_years} years"));

            $labs = sp_lab_build_values_for_order(
                $hos,
                $lab_memo,
                $hn,
                $organ,
                $sys,
                $matched_by_icode[$icode],
                $order_date,
                $order_time,
                $order_lab_min,
                $lab_cutoff,
                $tbili_uln,
                $ast_uln,
                $alt_uln,
                $hepatic_clinical
            );

            foreach ($matched_by_icode[$icode] as $rule) {
                $lab_type = $rule['lab_type'] ?? '';
                $lab_key = ($organ === 'other') ? trim((string)($rule['lab_items_code'] ?? '')) : $lab_type;
                if ($lab_key === '' || !isset($labs[$lab_key])) {
                    continue;
                }
                $current_val = (float)($labs[$lab_key]['val'] ?? 0);
                $current_raw = (string)($labs[$lab_key]['raw'] ?? '');
                $cond_type = trim((string)($rule['lab_condition_type'] ?? 'range'));
                if ($cond_type === '') {
                    $cond_type = 'range';
                }
                $cond_val = trim((string)($rule['lab_condition_value'] ?? ''));
                $min = (float)($rule['min_val'] ?? 0);
                $max = (float)($rule['max_val'] ?? 0);

                $lab_matched = false;
                if ($organ === 'other' && $cond_type !== 'range') {
                    if ($current_raw !== '' && monitor_lab_match_condition($cond_type, $cond_val, $current_raw)) {
                        $lab_matched = true;
                    }
                } else {
                    if ($current_val > 0 && $current_val >= $min && $current_val <= $max) {
                        $lab_matched = true;
                    }
                }
                if (!$lab_matched) {
                    continue;
                }
                if (!monitor_lab_match_patient_extra($rule, 0, 0)) {
                    continue;
                }
                if (!monitor_lab_order_dose_conditions_match($rule, $order)) {
                    continue;
                }
                if (!empty($rule['first_order_only'])) {
                    $fo = monitor_lab_first_order_check($rule, $first_order_map, $hn, $icode, $order_date, $order_time);
                    if (!empty($fo['skip_alert'])) {
                        continue;
                    }
                }
                if (!empty($rule['use_duration_condition'])) {
                    $dur = monitor_lab_duration_check($rule, $order['method'] ?? '');
                    if (!empty($dur['skip_alert'])) {
                        continue;
                    }
                }

                $alert_key = $icode . '|' . $lab_key . '|' . $cond_type . '|' . $cond_val;
                if (isset($seen_alert_keys[$alert_key])) {
                    continue;
                }
                $seen_alert_keys[$alert_key] = true;

                $lvl = monitor_lab_alert_level_from_rule($rule);
                if ($lvl === 'hard') {
                    $has_hard = true;
                } else {
                    $has_soft = true;
                }
                $drug = trim((string)($rule['drug_name'] ?? $rule['drug_icode'] ?? 'ยา'));
                $lab_disp = ($organ === 'other')
                    ? (trim((string)($rule['lab_items_name'] ?? '')) ?: $lab_key)
                    : $lab_type;
                $val_disp = ($current_raw !== '') ? $current_raw : (string)$current_val;
                $msg = trim((string)($rule['suggestion_msg'] ?? 'Lab Alert'));
                $line = $drug . ' · ' . $lab_disp . '=' . $val_disp . ' — ' . $msg;
                $alert_summaries[] = $line;
                $detail = trim((string)($labs[$lab_key]['detail'] ?? ''));
                $alert_details[] = ($detail !== '') ? ($line . "\n" . $detail) : $line;
            }
        }

        if ($has_hard || $has_soft) {
            $level = $has_hard ? 'hard' : 'soft';
            $summary = implode('; ', array_slice($alert_summaries, 0, 3));
            if (count($alert_summaries) > 3) {
                $summary .= ' (+' . (count($alert_summaries) - 3) . ')';
            }
            $results[$pkey] = sp_result_alert($level, $summary, $alert_details);
        } else {
            $results[$pkey] = sp_result_pass('ไม่เข้าเงื่อนไข Lab');
        }
    }

    return ['no_rules' => false, 'results' => $results];
}

/** ออเดอร์ยาที่เกี่ยวข้องกับกฎ Lab ในวันที่คัดกรอง (ใช้ rxdate/rxtime ต่อรายการ) */
function sp_lab_patient_rule_orders($hos, array $patient, $screen_date, array $icodes) {
    $hn = trim((string)($patient['hn'] ?? ''));
    $vn = trim((string)($patient['vn'] ?? ''));
    $an = trim((string)($patient['an'] ?? ''));
    $date = trim((string)$screen_date);
    if ($hn === '' || $date === '' || empty($icodes)) {
        return [];
    }
    $hn_in = sp_hn_in_sql($hos, $hn);
    $date_esc = mysqli_real_escape_string($hos, $date);
    $icode_in = [];
    foreach ($icodes as $ic) {
        $ic = trim((string)$ic);
        if ($ic !== '') {
            $icode_in[] = "'" . mysqli_real_escape_string($hos, $ic) . "'";
        }
    }
    if (empty($icode_in)) {
        return [];
    }
    $extra = [];
    if ($vn !== '') {
        $extra[] = "o.vn='" . mysqli_real_escape_string($hos, $vn) . "'";
    }
    if ($an !== '') {
        $extra[] = "o.an='" . mysqli_real_escape_string($hos, $an) . "'";
    }
    $extra_sql = empty($extra) ? '' : (' AND (' . implode(' OR ', $extra) . ')');
    $method_expr = function_exists('di_sql_method_expr') ? di_sql_method_expr('o') : "''";
    $joins = function_exists('di_sql_method_joins') ? di_sql_method_joins('o') : '';
    $sql = "SELECT o.hn, o.vn, o.an, o.vstdate, o.rxdate, o.rxtime, o.icode, o.qty,
            CAST(CONVERT(COALESCE(NULLIF(TRIM(tm.strength), ''), d.strength) USING utf8) AS CHAR) AS strength,
            CAST(CONVERT(d.units USING utf8) AS CHAR) AS units,
            $method_expr AS method
        FROM opitemrece o
        INNER JOIN drugitems d ON d.icode = o.icode
        LEFT JOIN tmt_tpu_code tm ON d.tpu_code_list = tm.tpu_code
        $joins
        WHERE o.hn IN ($hn_in)
          AND o.vstdate = '$date_esc'
          AND o.qty > 0
          AND o.icode IN (" . implode(',', $icode_in) . ")
          $extra_sql
        ORDER BY o.rxdate ASC, o.rxtime ASC, o.item_no ASC";
    $q = mysqli_query($hos, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

/** สร้างค่า Lab สำหรับออเดอร์หนึ่งรายการ */
function sp_lab_build_values_for_order($hos, array &$lab_memo, $hn, $organ, array $sys, array $rules, $order_date, $order_time, $order_lab_min, $lab_cutoff, $tbili_uln, $ast_uln, $alt_uln, array $hepatic_clinical = []) {
    $labs = [];
    if ($organ === 'other') {
        $codes_seen = [];
        foreach ($rules as $rule) {
            $code = trim((string)($rule['lab_items_code'] ?? ''));
            if ($code === '' || isset($codes_seen[$code])) {
                continue;
            }
            $codes_seen[$code] = true;
            $lab_data = monitor_lab_get_lab_for_order($hos, $lab_memo, $hn, $code, $order_date, $order_time, $order_lab_min, $lab_cutoff);
            $labs[$code] = [
                'val' => round((float)($lab_data['value'] ?? 0), 4),
                'raw' => (string)($lab_data['raw'] ?? ''),
                'date' => $lab_data['date'] ?? '-',
                'time' => $lab_data['time'] ?? '',
            ];
        }
        return $labs;
    }
    if ($organ === 'renal') {
        $scr_data = ['value' => 0, 'raw' => '', 'date' => '-', 'time' => ''];
        if (!empty($sys['h_code_scr'])) {
            $scr_data = monitor_lab_get_lab_for_order($hos, $lab_memo, $hn, $sys['h_code_scr'], $order_date, $order_time, $order_lab_min, $lab_cutoff);
        }
        $labs['SERUM_CR'] = [
            'val' => round((float)$scr_data['value'], 2),
            'raw' => (string)($scr_data['raw'] ?? ''),
            'date' => $scr_data['date'] ?? '-',
            'time' => $scr_data['time'] ?? '',
        ];
        $ckd = ['value' => 0, 'raw' => '', 'date' => '-', 'time' => ''];
        if (!empty($sys['h_code_ckd_epi'])) {
            $ckd = monitor_lab_get_lab_for_order($hos, $lab_memo, $hn, $sys['h_code_ckd_epi'], $order_date, $order_time, $order_lab_min, $lab_cutoff);
        }
        $labs['CKD_EPI'] = [
            'val' => round((float)$ckd['value'], 2),
            'raw' => (string)($ckd['raw'] ?? ''),
            'date' => $ckd['date'] ?? '-',
            'time' => $ckd['time'] ?? '',
        ];
        $labs['GFR'] = ['val' => 0, 'raw' => '', 'date' => $scr_data['date'] ?? '-', 'time' => $scr_data['time'] ?? ''];
        return $labs;
    }

    $ast = monitor_lab_get_lab_for_order($hos, $lab_memo, $hn, $sys['h_code_ast'] ?? '', $order_date, $order_time, $order_lab_min, $lab_cutoff);
    $alt = monitor_lab_get_lab_for_order($hos, $lab_memo, $hn, $sys['h_code_alt'] ?? '', $order_date, $order_time, $order_lab_min, $lab_cutoff);
    $tbili = monitor_lab_get_lab_for_order($hos, $lab_memo, $hn, $sys['h_code_tbili'] ?? '', $order_date, $order_time, $order_lab_min, $lab_cutoff);
    $dbili = monitor_lab_get_lab_for_order($hos, $lab_memo, $hn, $sys['h_code_dbili'] ?? '', $order_date, $order_time, $order_lab_min, $lab_cutoff);
    $ibili = monitor_lab_get_lab_for_order($hos, $lab_memo, $hn, $sys['h_code_ibili'] ?? '', $order_date, $order_time, $order_lab_min, $lab_cutoff);
    $tbili_x = ($tbili['value'] > 0) ? round($tbili['value'] / $tbili_uln, 2) : 0;
    $ast_x = ($ast['value'] > 0) ? round($ast['value'] / $ast_uln, 2) : 0;
    $alt_x = ($alt['value'] > 0) ? round($alt['value'] / $alt_uln, 2) : 0;
    $max_x = max($ast_x, $alt_x);
    $max_src = ($ast_x >= $alt_x) ? $ast : $alt;
    $labs = [
        'AST' => ['val' => (float)$ast['value'], 'raw' => (string)($ast['raw'] ?? ''), 'date' => $ast['date'], 'time' => $ast['time']],
        'ALT' => ['val' => (float)$alt['value'], 'raw' => (string)($alt['raw'] ?? ''), 'date' => $alt['date'], 'time' => $alt['time']],
        'Bilirubin' => ['val' => (float)$tbili['value'], 'raw' => (string)($tbili['raw'] ?? ''), 'date' => $tbili['date'], 'time' => $tbili['time']],
        'Bilirubin_xULN' => ['val' => $tbili_x, 'raw' => (string)$tbili_x, 'date' => $tbili['date'], 'time' => $tbili['time']],
        'DirectBilirubin' => ['val' => (float)$dbili['value'], 'raw' => (string)($dbili['raw'] ?? ''), 'date' => $dbili['date'], 'time' => $dbili['time']],
        'IndirectBilirubin' => ['val' => (float)$ibili['value'], 'raw' => (string)($ibili['raw'] ?? ''), 'date' => $ibili['date'], 'time' => $ibili['time']],
        'AST_xULN' => ['val' => $ast_x, 'raw' => (string)$ast_x, 'date' => $ast['date'], 'time' => $ast['time']],
        'ALT_xULN' => ['val' => $alt_x, 'raw' => (string)$alt_x, 'date' => $alt['date'], 'time' => $alt['time']],
        'AST_ALT_xULN' => [
            'val' => $max_x,
            'raw' => (string)$max_x,
            'date' => ($max_x > 0 ? ($max_src['date'] ?? '-') : '-'),
            'time' => ($max_x > 0 ? ($max_src['time'] ?? '') : ''),
        ],
    ];
    $need_scores = false;
    foreach ($rules as $rule) {
        if (function_exists('monitor_lab_hepatic_is_score_type') && monitor_lab_hepatic_is_score_type($rule['lab_type'] ?? '')) {
            $need_scores = true;
            break;
        }
    }
    if ($need_scores) {
        $score_inputs = monitor_lab_hepatic_fetch_score_inputs($hos, $lab_memo, $hn, $sys, $order_date, $order_time, $order_lab_min, $lab_cutoff);
        if ((float)($score_inputs['tbili']['value'] ?? 0) <= 0 && (float)($tbili['value'] ?? 0) > 0) {
            $score_inputs['tbili'] = $tbili;
        }
        $clinical = monitor_lab_hepatic_clinical_for_hn($hepatic_clinical, $hn);
        $score = monitor_lab_hepatic_compute_scores($score_inputs, $clinical);
        foreach (monitor_lab_hepatic_score_lab_slots($score) as $sk => $slot) {
            $labs[$sk] = $slot;
        }
    }
    return $labs;
}

/** ตรวจเงื่อนไข dose จากแถวออเดอร์ที่ดึงมาแล้ว */
function sp_lab_order_dose_matches(array $rule, array $order) {
    return monitor_lab_order_dose_conditions_match($rule, $order);
}

/** ตรวจเงื่อนไข dose ของกฎ Lab (เมื่อเปิด use_dose_condition) — legacy รายคน */
function sp_lab_rule_dose_matches($hos, array $patient, $screen_date, array $rule) {
    $icode = trim((string)($rule['drug_icode'] ?? ''));
    if ($icode === '') {
        return false;
    }
    $orders = sp_lab_patient_rule_orders($hos, $patient, $screen_date, [$icode]);
    if (empty($orders)) {
        return false;
    }
    return sp_lab_order_dose_matches($rule, $orders[0]);
}

function sp_load_rule_icodes($con, $table, $icode_col = 'icode', $where = '') {
    $sql = "SELECT $icode_col FROM $table";
    if ($where !== '') {
        $sql .= " WHERE $where";
    }
    $q = mysqli_query($con, $sql);
    $codes = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $c = trim((string)($r[$icode_col] ?? ''));
            if ($c !== '') {
                $codes[$c] = true;
            }
        }
    }
    return array_keys($codes);
}

/** โหลดกฎ + batch screening ครั้งเดียวต่อวัน */
function sp_build_screen_cache($con, $hos, array $patients, $screen_date, array $modules) {
    $ctx = [
        'icodes' => sp_batch_patient_icodes_map($hos, $screen_date, $patients),
        'hla' => null,
        'ua' => null,
        'hbv_icodes' => [],
        'hbv_has_settings' => false,
        'lab_renal_icodes' => [],
        'lab_hepatic_icodes' => [],
        'lab_other_icodes' => [],
        'lab_renal' => null,
        'lab_hepatic' => null,
        'lab_other' => null,
        'lab_has_rules' => ['renal' => false, 'hepatic' => false, 'other' => false],
        'cumulative_has_rules' => false,
        'drug_usage' => null,
        'max_dose' => null,
        'warfarin' => null,
        'mg_ml' => null,
        'pediatric_dose' => null,
        'dose_calculator' => null,
        'opd_qty' => null,
        'drug_allergy' => null,
        'opd_dup' => null,
        'home_med' => null,
        'antibiotic' => null,
        'amr_drug' => null,
        'dup_therapy' => null,
    ];
    $need = [];
    foreach ($modules as $mod) {
        $need[$mod['module_key'] ?? ''] = true;
    }
    if (!empty($need['hla'])) {
        $ctx['hla'] = sp_batch_hla_alert_map($con, $hos, $screen_date);
    }
    if (!empty($need['ua'])) {
        $ctx['ua'] = sp_batch_ua_results_map($con, $hos, $screen_date, $ctx['icodes']);
    }
    if (!empty($need['hbv'])) {
        $ctx['hbv_icodes'] = sp_load_rule_icodes(
            $con,
            'monitor_hbv_settings',
            'icode',
            "monitor_type IN ('hbv_required_drug','hbv_high_risk_chemo','hbv_moderate_risk_chemo')"
        );
        $ctx['hbv_has_settings'] = !empty($ctx['hbv_icodes']);
    }
    if (!empty($need['lab_renal'])) {
        $renal_map = sp_load_lab_organ_rule_map($con, 'renal');
        $ctx['lab_renal_icodes'] = array_keys($renal_map);
        $ctx['lab_has_rules']['renal'] = !empty($renal_map);
        $ctx['lab_renal'] = !empty($renal_map)
            ? sp_batch_lab_organ_results_map($con, $hos, $screen_date, 'renal', $patients, $ctx['icodes'])
            : ['no_rules' => true, 'results' => []];
    }
    if (!empty($need['lab_hepatic'])) {
        $hepatic_map = sp_load_lab_organ_rule_map($con, 'hepatic');
        $ctx['lab_hepatic_icodes'] = array_keys($hepatic_map);
        $ctx['lab_has_rules']['hepatic'] = !empty($hepatic_map);
        $ctx['lab_hepatic'] = !empty($hepatic_map)
            ? sp_batch_lab_organ_results_map($con, $hos, $screen_date, 'hepatic', $patients, $ctx['icodes'])
            : ['no_rules' => true, 'results' => []];
    }
    if (!empty($need['lab_other'])) {
        $other_map = sp_load_lab_organ_rule_map($con, 'other');
        $ctx['lab_other_icodes'] = array_keys($other_map);
        $ctx['lab_has_rules']['other'] = !empty($other_map);
        $ctx['lab_other'] = !empty($other_map)
            ? sp_batch_lab_organ_results_map($con, $hos, $screen_date, 'other', $patients, $ctx['icodes'])
            : ['no_rules' => true, 'results' => []];
    }
    if (!empty($need['cumulative'])) {
        $qc = mysqli_query($con, "SELECT COUNT(*) AS c FROM monitor_settings");
        $row = $qc ? mysqli_fetch_assoc($qc) : null;
        $ctx['cumulative_has_rules'] = $row && (int)($row['c'] ?? 0) > 0;
    }
    if (!empty($need['drug_usage'])) {
        $ctx['drug_usage'] = sp_batch_drug_usage_map($con, $hos, $screen_date, $patients);
    }
    if (!empty($need['max_dose'])) {
        $ctx['max_dose'] = sp_batch_max_dose_map($con, $hos, $screen_date, $patients);
    }
    if (!empty($need['warfarin'])) {
        $ctx['warfarin'] = sp_batch_warfarin_map($con, $hos, $screen_date, $patients);
    }
    if (!empty($need['mg_ml'])) {
        $ctx['mg_ml'] = sp_batch_mg_ml_map($con, $hos, $screen_date, $patients);
    }
    if (!empty($need['pediatric_dose'])) {
        $ctx['pediatric_dose'] = sp_batch_pediatric_dose_map($con, $hos, $screen_date, $patients);
    }
    if (!empty($need['dose_calculator'])) {
        $ctx['dose_calculator'] = sp_batch_dose_calculator_map($con, $hos, $screen_date, $patients);
    }
    if (!empty($need['opd_qty'])) {
        $ctx['opd_qty'] = sp_batch_opd_qty_map($con, $hos, $screen_date, $patients);
    }
    if (!empty($need['drug_allergy'])) {
        $ctx['drug_allergy'] = sp_batch_drug_allergy_map($con, $hos, $screen_date, $patients);
    }
    if (!empty($need['opd_dup'])) {
        $ctx['opd_dup'] = sp_extra_run_batch('sp_batch_opd_dup_map', $con, $hos, $screen_date, $patients);
    }
    if (!empty($need['home_med'])) {
        $ctx['home_med'] = sp_extra_run_batch('sp_batch_home_med_map', $con, $hos, $screen_date, $patients);
    }
    if (!empty($need['antibiotic'])) {
        $ctx['antibiotic'] = sp_extra_run_batch('sp_batch_antibiotic_map', $con, $hos, $screen_date, $patients);
    }
    if (!empty($need['amr_drug'])) {
        $ctx['amr_drug'] = sp_extra_run_batch('sp_batch_amr_drug_map', $con, $hos, $screen_date, $patients);
    }
    if (!empty($need['dup_therapy'])) {
        $ctx['dup_therapy'] = sp_extra_run_batch('sp_batch_dup_therapy_map', $con, $hos, $screen_date, $patients);
    }
    // เปิด enrichment Drugs Center เมื่อคัดกรองจำนวนน้อย (รายคน / กลุ่มเล็ก)
    $ctx['drug_center_enrich'] = false;
    if (count($patients) <= 3
        && function_exists('provider_oauth_session_has_moph_token')
        && provider_oauth_session_has_moph_token()
    ) {
        if (!function_exists('drug_center_is_configured')) {
            $f = __DIR__ . '/drug_center_helper.php';
            if (is_file($f)) {
                require_once $f;
            }
        }
        $ctx['drug_center_enrich'] = function_exists('drug_center_is_configured') && drug_center_is_configured();
    }
    return $ctx;
}

function sp_patient_icodes_from_ctx(array $ctx, $pkey, $patient = null, $screen_date = '') {
    if (isset($ctx['icodes'][$pkey])) {
        return $ctx['icodes'][$pkey];
    }
    if (is_array($patient)) {
        foreach (sp_patient_screen_key_variants($patient, $screen_date) as $k) {
            if (isset($ctx['icodes'][$k])) {
                return $ctx['icodes'][$k];
            }
        }
    }
    return [];
}

function sp_hla_drug_label(array $drug_settings, $icode) {
    $icode = trim((string)$icode);
    $name = trim((string)($drug_settings[$icode]['drug_name'] ?? ''));
    if ($name !== '') {
        return $name;
    }
    return $icode !== '' ? $icode : 'ยา HLA';
}

function sp_hla_collect_alert_icodes(array $hla, $pkey, array $patient = [], $screen_date = '', array $patient_icodes = []) {
    $hit = [];
    $keys = [$pkey];
    if (!empty($patient)) {
        $keys = array_merge($keys, sp_patient_screen_key_variants($patient, $screen_date));
    }
    foreach (array_unique($keys) as $k) {
        foreach (($hla['alert_icodes'][$k] ?? []) as $ic) {
            $ic = trim((string)$ic);
            if ($ic !== '' && !in_array($ic, $hit, true)) {
                $hit[] = $ic;
            }
        }
    }
    if (!empty($hit)) {
        return $hit;
    }
    $hla_set = array_flip($hla['icodes'] ?? []);
    foreach ($patient_icodes as $ic) {
        $ic = trim((string)$ic);
        if ($ic !== '' && isset($hla_set[$ic]) && !in_array($ic, $hit, true)) {
            $hit[] = $ic;
        }
    }
    return $hit;
}

function sp_hla_build_alert_result($level, array $drug_settings, array $icodes) {
    $icodes = array_values(array_unique(array_filter(array_map('trim', $icodes), function ($c) {
        return $c !== '';
    })));
    $details = [];
    $items = [];
    $names = [];
    foreach ($icodes as $ic) {
        $name = sp_hla_drug_label($drug_settings, $ic);
        $names[] = $name;
        $details[] = $name . ' — ยังไม่คัดกรองยีนแพ้ยา HLA-B';
        $items[] = [
            'icode' => $ic,
            'drug_name' => $name,
            'alert_message' => 'ยังไม่คัดกรองยีนแพ้ยา HLA-B',
        ];
    }
    if (empty($names)) {
        return sp_result_alert($level, 'ยังไม่คัดกรองยีนแพ้ยา HLA-B');
    }
    $summary = 'ยังไม่คัดกรองยีนแพ้ยา HLA-B: ' . implode(', ', $names);
    return sp_result_alert($level, $summary, $details, $items);
}

function sp_screen_hla_cached(array $patient, array $ctx, $pkey, $screen_date = '') {
    $hla = $ctx['hla'] ?? null;
    if (!$hla || !empty($hla['no_settings'])) {
        return sp_result_na('ยังไม่ตั้งยา HLA');
    }
    $icodes = sp_patient_icodes_from_ctx($ctx, $pkey, $patient, $screen_date);
    $hla_set = array_flip($hla['icodes'] ?? []);
    $matched = false;
    foreach ($icodes as $ic) {
        if (isset($hla_set[$ic])) {
            $matched = true;
            break;
        }
    }
    if (!$matched) {
        return sp_result_na('ไม่มียา HLA');
    }
    $alert_hit = !empty($hla['alerts'][$pkey]);
    if (!$alert_hit) {
        foreach (sp_patient_screen_key_variants($patient, $screen_date) as $k) {
            if (!empty($hla['alerts'][$k])) {
                $alert_hit = true;
                break;
            }
        }
    }
    if ($alert_hit) {
        $collected = [];
        if (!empty($hla['alert_levels'][$pkey])) {
            $collected[] = $hla['alert_levels'][$pkey];
        }
        foreach (sp_patient_screen_key_variants($patient, $screen_date) as $k) {
            if (!empty($hla['alert_levels'][$k])) {
                $collected[] = $hla['alert_levels'][$k];
            }
        }
        $level = empty($collected)
            ? hla_default_alert_level()
            : hla_resolve_alert_level($collected);
        $hit_icodes = sp_hla_collect_alert_icodes($hla, $pkey, $patient, $screen_date, $icodes);
        return sp_hla_build_alert_result($level, $hla['drugs'] ?? [], $hit_icodes);
    }
    return sp_result_pass('คัดกรองแล้ว / ไม่เข้าเงื่อนไข');
}

function sp_screen_ua_cached(array $ctx, $pkey, array $patient = [], $screen_date = '') {
    $ua = $ctx['ua'] ?? null;
    if (!$ua || !empty($ua['no_rules'])) {
        return sp_result_na('ยังไม่ตั้งกฎ UA');
    }
    if (isset($ua['results'][$pkey])) {
        return $ua['results'][$pkey];
    }
    $icodes = sp_patient_icodes_from_ctx($ctx, $pkey, $patient, $screen_date);
    if (empty($icodes)) {
        return sp_result_na();
    }
    return sp_result_pass();
}

function sp_screen_hbv_cached(array $ctx, $pkey, array $patient = [], $screen_date = '') {
    if (empty($ctx['hbv_has_settings'])) {
        return sp_result_na('ยังไม่ตั้งยา HBV');
    }
    $icodes = sp_patient_icodes_from_ctx($ctx, $pkey, $patient, $screen_date);
    $hbv_set = array_flip($ctx['hbv_icodes'] ?? []);
    foreach ($icodes as $ic) {
        if (isset($hbv_set[$ic])) {
            return sp_result_pass('ตรวจรายละเอียดที่ Monitor HBV');
        }
    }
    return sp_result_na('ไม่มียา HBV');
}

function sp_screen_lab_organ_cached(array $ctx, $pkey, $organ, array $patient = [], $screen_date = '') {
    $batch_key = [
        'renal' => 'lab_renal',
        'hepatic' => 'lab_hepatic',
        'other' => 'lab_other',
    ];
    $ikey = $batch_key[$organ] ?? 'lab_other';
    $batch = $ctx[$ikey] ?? null;
    if (!$batch || !empty($batch['no_rules'])) {
        return sp_result_na('ยังไม่ตั้งกฎ Lab');
    }
    if (isset($batch['results'][$pkey])) {
        return $batch['results'][$pkey];
    }
    foreach (sp_patient_screen_key_variants($patient, $screen_date) as $k) {
        if (isset($batch['results'][$k])) {
            return $batch['results'][$k];
        }
    }
    // มียาในกลุ่มกฎหรือไม่ — ถ้าไม่มีถือว่าไม่เกี่ยวข้อง
    $icode_key = $ikey . '_icodes';
    $rule_icodes = array_flip($ctx[$icode_key] ?? []);
    $icodes = sp_patient_icodes_from_ctx($ctx, $pkey, $patient, $screen_date);
    foreach ($icodes as $ic) {
        if (isset($rule_icodes[$ic])) {
            return sp_result_pass('ไม่เข้าเงื่อนไข Lab');
        }
    }
    return sp_result_na('ไม่มียาในกลุ่ม Lab');
}

function sp_screen_cumulative_cached(array $ctx) {
    if (empty($ctx['cumulative_has_rules'])) {
        return sp_result_na('ยังไม่ตั้ง Cumulative');
    }
    return sp_result_pass('ตรวจที่ Monitor Cumulative');
}

function sp_patient_di_key($patient, $screen_date = '') {
    $ptype = $patient['patient_type'] ?? '';
    $vst = ($ptype === 'IPD' && $screen_date !== '') ? $screen_date : ($patient['vstdate'] ?? '');
    return trim((string)($patient['hn'] ?? '')) . '|'
        . trim((string)($patient['vn'] ?? '')) . '|'
        . trim((string)$vst);
}

/**
 * คีย์ดึงผล DI batch — IPD มี vn จาก ipt แต่ order ใน opitemrece มัก vn ว่าง
 */
function sp_di_batch_lookup_keys(array $patient, $screen_date = '') {
    $keys = [];
    $keys[] = sp_patient_di_key($patient, $screen_date);
    foreach (sp_patient_screen_key_variants($patient, $screen_date) as $k) {
        $keys[] = $k;
    }

    $hn = trim((string)($patient['hn'] ?? ''));
    $vn = trim((string)($patient['vn'] ?? ''));
    $ptype = trim((string)($patient['patient_type'] ?? ''));
    $date = trim((string)$screen_date);
    if ($date === '') {
        if ($ptype === 'IPD') {
            $date = trim((string)($patient['rxdate'] ?? ''));
        }
        if ($date === '') {
            $date = trim((string)($patient['vstdate'] ?? ''));
        }
    }
    if ($hn === '' || $date === '') {
        return array_values(array_unique(array_filter($keys)));
    }

    $hn_variants = [$hn];
    $trimmed = ltrim($hn, '0');
    if ($trimmed === '') {
        $trimmed = '0';
    }
    $hn_variants[] = $trimmed;
    $hn_variants[] = str_pad($trimmed, 9, '0', STR_PAD_LEFT);
    $hn_variants = array_values(array_unique($hn_variants));

    foreach ($hn_variants as $h) {
        $keys[] = $h . '|' . $vn . '|' . $date;
        $keys[] = $h . '||' . $date;
    }
    return array_values(array_unique(array_filter($keys)));
}

/** เงื่อนไข Dose — ถ้าคำนวณ mg ไม่ได้ ยังให้แจ้ง Alert (ไม่กรองทิ้ง) */
function sp_di_dose_matches_lenient(array $rule, array $order, $which = 1) {
    $which = (int)$which;
    $use_key = $which === 2 ? 'use_dose2_condition' : 'use_dose1_condition';
    if (empty($rule[$use_key])) {
        return true;
    }
    if (di_dose_condition_matches($rule, $order, $which)) {
        return true;
    }
    if (array_key_exists('_daily_mg', $order)) {
        $mg = $order['_daily_mg'];
    } else {
        $parsed = hosxp_parse_drug_daily_dose_mg([
            'qty' => $order['qty'] ?? 0,
            'strength' => $order['strength'] ?? '',
            'units' => $order['units'] ?? '',
            'method' => $order['method'] ?? '',
        ]);
        $mg = $parsed['mg_dose'] ?? null;
    }
    return ($mg === null || $mg <= 0);
}

/**
 * คัดกรอง DI ทั้งวันครั้งเดียว (ดึง order จาก HOSxP รอบเดียว — เร็วกว่าทีละคน)
 * @return array{results: array, has_drug: array}
 */
function sp_batch_screen_di_for_date($con, $hos, $screen_date, array $hn_filter = []) {
    ensure_di_dose_columns($con);
    $screen_date = trim((string)$screen_date);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $screen_date)) {
        return ['results' => [], 'has_drug' => [], 'has_rules' => false];
    }

    $q_rules = mysqli_query($con, "SELECT * FROM monitor_drug_interaction_settings WHERE active_status = 1");
    $rules = [];
    if ($q_rules) {
        while ($row = mysqli_fetch_assoc($q_rules)) {
            $d1 = trim($row['drug_icode'] ?? '');
            $d2 = trim($row['hosxp_icode'] ?? '');
            if ($d1 === '' || $d2 === '') {
                continue;
            }
            $rules[] = $row;
        }
    }
    if (empty($rules)) {
        return ['results' => [], 'has_drug' => [], 'has_rules' => false];
    }
    $rules = di_prepare_rules_icodes($hos, $rules);

    $monitor_icodes = [];
    foreach ($rules as $rule) {
        foreach ($rule['_icodes_a'] ?? [] as $d1) {
            $monitor_icodes[$d1] = true;
        }
    }

    $all_icodes = di_rules_scan_icodes($rules);
    $need_dose_mg = di_rules_need_dose_mg($rules);
    $window = di_compute_query_window($screen_date, $screen_date, $rules);
    $query_start = $window['query_start'];
    $query_end = date('Y-m-d', strtotime($screen_date . ' + 30 days'));

    [$raw_rows] = di_fetch_hosxp_orders($hos, $all_icodes, $query_start, $query_end, $need_dose_mg, $hn_filter, 80000);
    $prepared_all = di_prepare_orders($raw_rows, $need_dose_mg);
    $prepared_rows = di_prepare_orders(di_dedupe_latest_orders($raw_rows), $need_dose_mg);
    [$by_icode, $by_vn_icode, $by_hn_icode] = di_reindex_orders_fast($prepared_rows);
    [$by_icode_all] = di_reindex_orders_fast($prepared_all);
    $idx = [
        'by_icode' => $by_icode,
        'by_vn_icode' => $by_vn_icode,
        'by_hn_icode' => $by_hn_icode,
        'by_icode_all' => $by_icode_all,
    ];

    $drug_names = [];
    $ptnames = [];
    $has_drug = [];
    foreach ($prepared_all as $row) {
        $ic = trim($row['icode'] ?? '');
        if ($ic !== '' && !isset($drug_names[$ic])) {
            $drug_names[$ic] = trim($row['drug_name'] ?? '') ?: $ic;
        }
        $hn = trim($row['hn'] ?? '');
        if ($hn !== '' && !isset($ptnames[$hn])) {
            $ptnames[$hn] = trim($row['ptname'] ?? '');
        }
        if (($row['vstdate'] ?? '') === $screen_date && isset($monitor_icodes[$ic])) {
            $has_drug[sp_patient_screen_key($row)] = true;
        }
    }

    $alert_buckets = [];
    $seen = [];

    foreach ($rules as $rule) {
        $alert_level = (!empty($rule['alert_level']) && $rule['alert_level'] === 'hard') ? 'hard' : 'soft';
        di_each_matching_pair($rule, $idx, [
            'date_eq' => $screen_date,
            'dose_fn' => 'sp_di_dose_matches_lenient',
        ], function ($o1, $o2, $check_mode, $lookback_days, $c1, $c2) use ($rule, $alert_level, $ptnames, $drug_names, &$alert_buckets, &$seen) {
            $pkey = sp_patient_screen_key($o1);
            $dedupe = $rule['id'] . '|' . $pkey . '|' . di_same_rx_key($o1) . '|' . ($o1['icode'] ?? '') . '|' . ($o2['icode'] ?? '') . '|' . ($o2['vstdate'] ?? '') . '|' . ($o2['vn'] ?? '');
            if (isset($seen[$dedupe])) {
                return;
            }
            $seen[$dedupe] = true;
            $ptname = $ptnames[trim((string)($o1['hn'] ?? ''))] ?? '';
            $drug1_name = $drug_names[$o1['icode'] ?? ''] ?? ($rule['drug_name'] ?? '');
            $drug2_name = $drug_names[$o2['icode'] ?? ''] ?? ($rule['hosxp_drug_name'] ?? '');
            $alert_buckets[$pkey][] = di_build_alert(
                $rule, $o1, $o2, $alert_level, $check_mode, $lookback_days,
                $ptname, $drug1_name, $drug2_name, $c1, $c2
            );
        });
    }

    $results = [];
    foreach ($alert_buckets as $pkey => $alerts) {
        $details = array_values(array_unique(array_map('di_format_alert_summary_line', $alerts)));
        $has_hard = false;
        foreach ($alerts as $a) {
            if (($a['alert_level'] ?? '') === 'hard') {
                $has_hard = true;
            }
        }
        $results[$pkey] = sp_result_alert(
            $has_hard ? 'hard' : 'soft',
            implode('; ', $details),
            $details,
            $alerts
        );
    }

    return ['results' => $results, 'has_drug' => $has_drug, 'has_rules' => true];
}

/** Drug Interaction — ใช้ cache จาก batch ถ้ามี */
function sp_screen_di($con, $hos, $patient, array $di_batch = null, $screen_date = '') {
    if (is_array($di_batch)) {
        $keys = sp_di_batch_lookup_keys($patient, $screen_date);
        foreach ($keys as $key) {
            if (!empty($di_batch['results'][$key])) {
                return $di_batch['results'][$key];
            }
        }
        foreach ($keys as $key) {
            if (!empty($di_batch['has_drug'][$key])) {
                return sp_result_pass();
            }
        }
        if (empty($di_batch['has_rules'])) {
            return sp_result_na('ยังไม่ตั้งกฎ DI');
        }
        return sp_result_na('ไม่มียาในกลุ่ม DI');
    }
    $icodes = sp_patient_icodes_on_date($hos, $patient['hn'], $patient['vstdate'], $patient['vn'] ?? '');
    if (empty($icodes)) {
        return sp_result_na('ไม่มียาที่เฝ้าระวัง');
    }
    $eval = di_evaluate_visit_alerts(
        $con,
        $hos,
        $patient['hn'],
        $patient['vstdate'],
        $patient['vn'] ?? '',
        trim($patient['ptname'] ?? ''),
        $icodes
    );
    if (empty($eval['alerts'])) {
        $q = mysqli_query($con, "SELECT 1 FROM monitor_drug_interaction_settings WHERE active_status = 1 LIMIT 1");
        if (!$q || mysqli_num_rows($q) === 0) {
            return sp_result_na('ยังไม่ตั้งกฎ DI');
        }
        $selected = array_flip($icodes);
        $has_rule = false;
        $q2 = mysqli_query($con, "SELECT drug_icode FROM monitor_drug_interaction_settings WHERE active_status = 1");
        if ($q2) {
            while ($r = mysqli_fetch_assoc($q2)) {
                if (isset($selected[trim($r['drug_icode'] ?? '')])) {
                    $has_rule = true;
                    break;
                }
            }
        }
        return $has_rule ? sp_result_pass() : sp_result_na('ไม่มียาในกลุ่ม DI');
    }
    $details = array_map('di_format_alert_summary_line', $eval['alerts']);
    $details = array_values(array_unique($details));
    return sp_result_alert(
        !empty($eval['has_hard']) ? 'hard' : 'soft',
        implode('; ', $details),
        $details,
        $eval['alerts']
    );
}

/** HLA screening */
function sp_screen_hla($con, $hos, $patient) {
    ensure_monitor_hla_alert_level_column($con);
    $drug_settings = hla_load_drug_settings($con);
    if (empty($drug_settings)) {
        return sp_result_na('ยังไม่ตั้งยา HLA');
    }
    $hla_icodes = array_fill_keys(array_keys($drug_settings), true);
    $icodes = sp_patient_icodes_on_date($hos, $patient['hn'], $patient['vstdate'], $patient['vn'] ?? '');
    $matched = array_intersect($icodes, array_keys($hla_icodes));
    if (empty($matched)) {
        return sp_result_na('ไม่มียา HLA');
    }
    $cfg = [];
    $qc = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name LIKE 'hla_%'");
    if ($qc) {
        while ($r = mysqli_fetch_assoc($qc)) {
            $cfg[$r['config_name']] = $r['config_value'];
        }
    }
    $lb = (int)($cfg['hla_lookback_months'] ?? 24);
    $lab_in = monitor_lab_codes_sql_in($hos, $cfg['hla_lab_items_code'] ?? '2281');
    $ptnote = mysqli_real_escape_string($hos, $cfg['hla_ptnote_regex'] ?? 'ผ่านการตัดกรองยีนแพ้ยา|HLA-B');
    $rxnote = mysqli_real_escape_string($hos, $cfg['hla_rxnote_regex'] ?? 'ยีนแพ้ยา|HLA-B|ตรวจยีน');
    $hn_in = sp_hn_in_sql($hos, $patient['hn']);
    $vst_esc = mysqli_real_escape_string($hos, $patient['vstdate']);
    $icode_in = implode(',', array_map(function ($c) use ($hos) {
        return "'" . mysqli_real_escape_string($hos, $c) . "'";
    }, $matched));
    $sql = "SELECT DISTINCT o.icode FROM opitemrece o
        WHERE o.hn IN ($hn_in) AND o.icode IN ($icode_in) AND o.vstdate = '$vst_esc' AND o.qty > 0
        AND NOT EXISTS (SELECT 1 FROM opitemrece o2 WHERE o2.hn=o.hn AND o2.icode=o.icode
            AND o2.vstdate < o.vstdate AND o2.vstdate >= DATE_SUB(o.vstdate, INTERVAL $lb MONTH))
        AND NOT EXISTS (SELECT 1 FROM lab_order lo2 JOIN lab_head lh2 ON lo2.lab_order_number=lh2.lab_order_number
            WHERE lh2.hn=o.hn AND lo2.lab_items_code IN ($lab_in)
            AND lh2.order_date < o.vstdate AND lh2.order_date >= DATE_SUB(o.vstdate, INTERVAL $lb MONTH))
        AND NOT EXISTS (SELECT 1 FROM ptnote pn2 WHERE pn2.hn=o.hn
            AND CAST(CONVERT(pn2.plain_text USING utf8) AS binary) REGEXP '$ptnote')
        AND NOT EXISTS (SELECT 1 FROM patient_rx_note pr2 WHERE pr2.hn=o.hn
            AND CAST(CONVERT(pr2.rx_note USING utf8) AS binary) REGEXP '$rxnote')";
    $q2 = mysqli_query($hos, $sql);
    $hit_icodes = [];
    if ($q2) {
        while ($r = mysqli_fetch_assoc($q2)) {
            $ic = trim((string)($r['icode'] ?? ''));
            if ($ic !== '' && !in_array($ic, $hit_icodes, true)) {
                $hit_icodes[] = $ic;
            }
        }
    }
    if (!empty($hit_icodes)) {
        $hit_levels = [];
        foreach ($hit_icodes as $ic) {
            $hit_levels[] = $drug_settings[$ic]['alert_level'] ?? hla_default_alert_level();
        }
        return sp_hla_build_alert_result(hla_resolve_alert_level($hit_levels), $drug_settings, $hit_icodes);
    }
    return sp_result_pass('คัดกรองแล้ว / ไม่เข้าเงื่อนไข');
}

/** UA */
function sp_screen_ua($con, $hos, $patient) {
    $icodes = sp_patient_icodes_on_date($hos, $patient['hn'], $patient['vstdate'], $patient['vn'] ?? '');
    if (empty($icodes)) {
        return sp_result_na();
    }
    $rules = [];
    $q = mysqli_query($con, "SELECT * FROM monitor_ua_settings");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rules[] = $r;
        }
    }
    if (empty($rules)) {
        return sp_result_na('ยังไม่ตั้งกฎ UA');
    }
    $map = [];
    foreach ($rules as $r) {
        $c = trim($r['icode'] ?? '');
        if ($c !== '') {
            $map[$c][] = $r;
        }
    }
    $hn_esc = mysqli_real_escape_string($hos, $patient['hn']);
    $date_esc = mysqli_real_escape_string($hos, $patient['vstdate']);
    $vn = trim($patient['vn'] ?? '');
    foreach ($icodes as $icode) {
        if (!isset($map[$icode])) {
            continue;
        }
        foreach ($map[$icode] as $rule) {
            if ($vn === '') {
                continue;
            }
            $lab_code = mysqli_real_escape_string($hos, $rule['lab_code']);
            $vn_esc = mysqli_real_escape_string($hos, $vn);
            $ql = mysqli_query($hos, "SELECT lo.lab_order_result FROM lab_order lo
                JOIN lab_head lh ON lh.lab_order_number = lo.lab_order_number
                WHERE lh.vn = '$vn_esc' AND lo.lab_items_code = '$lab_code'
                ORDER BY lh.order_date DESC LIMIT 1");
            if (!$ql || !($lab = mysqli_fetch_assoc($ql))) {
                continue;
            }
            $res = trim($lab['lab_order_result'] ?? '');
            if (monitor_lab_match_condition($rule['condition_type'] ?? 'range', $rule['condition_value'] ?? '', $res)) {
                $lvl = ($rule['alert_level'] ?? '') === 'hard' ? 'hard' : 'soft';
                return sp_result_alert($lvl, ($rule['alert_message'] ?? 'UA Alert') . ': ' . $res);
            }
        }
    }
    return sp_result_pass();
}

/** HBV — simplified */
function sp_screen_hbv($con, $hos, $patient) {
    $q = mysqli_query($con, "SELECT icode FROM monitor_hbv_settings WHERE monitor_type IN ('hbv_required_drug','hbv_high_risk_chemo','hbv_moderate_risk_chemo')");
    if (!$q || mysqli_num_rows($q) === 0) {
        return sp_result_na('ยังไม่ตั้งยา HBV');
    }
    $hbv_icodes = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $hbv_icodes[trim($r['icode'])] = true;
    }
    $icodes = sp_patient_icodes_on_date($hos, $patient['hn'], $patient['vstdate'], $patient['vn'] ?? '');
    if (!array_intersect($icodes, array_keys($hbv_icodes))) {
        return sp_result_na('ไม่มียา HBV');
    }
    return sp_result_pass('ตรวจรายละเอียดที่ Monitor HBV');
}

/** Lab organ — ประเมินเงื่อนไข Lab จริง (ใช้เมื่อไม่มี screen cache) */
function sp_screen_lab_organ($con, $hos, $patient, $organ) {
    $organ = in_array($organ, ['renal', 'hepatic', 'other'], true) ? $organ : 'other';
    $screen_date = trim((string)($patient['vstdate'] ?? ''));
    if ($screen_date === '' || $screen_date === '0000-00-00') {
        $screen_date = sp_today_date();
    }
    $pkey = sp_patient_screen_key($patient, $screen_date);
    $icodes = sp_patient_icodes_on_date($hos, $patient['hn'], $patient['vstdate'] ?? $screen_date, $patient['vn'] ?? '');
    $batch = sp_batch_lab_organ_results_map($con, $hos, $screen_date, $organ, [$patient], [$pkey => $icodes]);
    if (!empty($batch['no_rules'])) {
        return sp_result_na('ยังไม่ตั้งกฎ Lab');
    }
    if (isset($batch['results'][$pkey])) {
        return $batch['results'][$pkey];
    }
    foreach (sp_patient_screen_key_variants($patient, $screen_date) as $k) {
        if (isset($batch['results'][$k])) {
            return $batch['results'][$k];
        }
    }
    $rule_map = sp_load_lab_organ_rule_map($con, $organ);
    if (!array_intersect($icodes, array_keys($rule_map))) {
        return sp_result_na('ไม่มียาในกลุ่ม Lab');
    }
    return sp_result_pass('ไม่เข้าเงื่อนไข Lab');
}

function sp_screen_cumulative($con, $hos, $patient) {
    $q = mysqli_query($con, "SELECT COUNT(*) AS c FROM monitor_settings");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row || (int)$row['c'] === 0) {
        return sp_result_na('ยังไม่ตั้ง Cumulative');
    }
    return sp_result_pass('ตรวจที่ Monitor Cumulative');
}

/**
 * รวมผล Drugs Center เข้าโมดูล di / drug_allergy
 * เรียกเฉพาะเมื่อ screen รายคน (ไม่มี batch ctx) เพื่อไม่ช้าตอนคัดกรองทั้งวัน
 */
function sp_enrich_module_with_drug_center($hos, array $patient, $module_key, array $local_result, $screen_date = '') {
    if (!in_array($module_key, ['di', 'drug_allergy'], true)) {
        return $local_result;
    }
    if (!function_exists('drug_center_enrich_patient')) {
        $dc_helper = __DIR__ . '/drug_center_helper.php';
        if (is_file($dc_helper)) {
            require_once $dc_helper;
        }
    }
    if (!function_exists('drug_center_enrich_patient') || !function_exists('provider_oauth_session_has_moph_token')) {
        return $local_result;
    }
    if (!provider_oauth_session_has_moph_token() || !drug_center_is_configured()) {
        return $local_result;
    }

    $icodes = sp_patient_icodes_on_date(
        $hos,
        $patient['hn'] ?? '',
        $patient['vstdate'] ?? $screen_date,
        $patient['vn'] ?? ''
    );
    if (empty($icodes)) {
        return $local_result;
    }
    $kind = ($module_key === 'drug_allergy') ? 'allergy' : 'contrast';
    $remote = drug_center_enrich_patient($hos, $patient, $icodes, $kind);
    if ($remote === null) {
        return $local_result;
    }
    return drug_center_merge_sp_result($local_result, $remote);
}

function sp_screen_patient($con, $hos, $patient, array $modules, array $di_batch = null, $screen_date = '', array $ctx = null) {
    $results = [];
    $has_alert = false;
    $max_level = 'soft';
    $pkey = sp_patient_screen_key($patient, $screen_date);
    $use_ctx = is_array($ctx);
    foreach ($modules as $mod) {
        $key = $mod['module_key'];
        switch ($key) {
            case 'di':
                $r = sp_screen_di($con, $hos, $patient, $di_batch, $screen_date);
                break;
            case 'hla':
                $r = $use_ctx ? sp_screen_hla_cached($patient, $ctx, $pkey, $screen_date) : sp_screen_hla($con, $hos, $patient);
                break;
            case 'ua':
                $r = $use_ctx ? sp_screen_ua_cached($ctx, $pkey, $patient, $screen_date) : sp_screen_ua($con, $hos, $patient);
                break;
            case 'hbv':
                $r = $use_ctx ? sp_screen_hbv_cached($ctx, $pkey, $patient, $screen_date) : sp_screen_hbv($con, $hos, $patient);
                break;
            case 'lab_renal':
                $r = $use_ctx ? sp_screen_lab_organ_cached($ctx, $pkey, 'renal', $patient, $screen_date) : sp_screen_lab_organ($con, $hos, $patient, 'renal');
                break;
            case 'lab_hepatic':
                $r = $use_ctx ? sp_screen_lab_organ_cached($ctx, $pkey, 'hepatic', $patient, $screen_date) : sp_screen_lab_organ($con, $hos, $patient, 'hepatic');
                break;
            case 'lab_other':
                $r = $use_ctx ? sp_screen_lab_organ_cached($ctx, $pkey, 'other', $patient, $screen_date) : sp_screen_lab_organ($con, $hos, $patient, 'other');
                break;
            case 'cumulative':
                $r = $use_ctx ? sp_screen_cumulative_cached($ctx) : sp_screen_cumulative($con, $hos, $patient);
                break;
            case 'drug_usage':
            case 'max_dose':
            case 'warfarin':
            case 'mg_ml':
            case 'pediatric_dose':
            case 'dose_calculator':
            case 'opd_qty':
            case 'drug_allergy':
            case 'opd_dup':
            case 'home_med':
            case 'antibiotic':
            case 'amr_drug':
            case 'dup_therapy':
                if ($use_ctx) {
                    $r = sp_screen_extra_cached($ctx, $key, $pkey, $patient, $screen_date);
                } else {
                    $batch_fn = [
                        'drug_usage' => 'sp_batch_drug_usage_map',
                        'max_dose' => 'sp_batch_max_dose_map',
                        'warfarin' => 'sp_batch_warfarin_map',
                        'mg_ml' => 'sp_batch_mg_ml_map',
                        'pediatric_dose' => 'sp_batch_pediatric_dose_map',
                        'dose_calculator' => 'sp_batch_dose_calculator_map',
                        'opd_qty' => 'sp_batch_opd_qty_map',
                        'drug_allergy' => 'sp_batch_drug_allergy_map',
                        'opd_dup' => 'sp_batch_opd_dup_map',
                        'home_med' => 'sp_batch_home_med_map',
                        'antibiotic' => 'sp_batch_antibiotic_map',
                        'amr_drug' => 'sp_batch_amr_drug_map',
                        'dup_therapy' => 'sp_batch_dup_therapy_map',
                    ][$key];
                    $tmp = $batch_fn($con, $hos, $screen_date, [$patient]);
                    $r = sp_screen_extra_cached([$key => $tmp], $key, $pkey, $patient, $screen_date);
                }
                break;
            default:
                $r = sp_result_na();
        }
        // เสริม Drugs Center เมื่อ screen รายคน หรือกลุ่มเล็กที่มี flag
        if ((!$use_ctx || !empty($ctx['drug_center_enrich'])) && in_array($key, ['di', 'drug_allergy'], true)) {
            $r = sp_enrich_module_with_drug_center($hos, $patient, $key, $r, $screen_date);
        }
        $results[$key] = $r;
        if ($r['status'] === 'alert') {
            $has_alert = true;
            if ($r['level'] === 'hard') {
                $max_level = 'hard';
            }
        }
    }
    return [
        'modules' => $results,
        'overall' => $has_alert ? 'alert' : 'pass',
        'overall_level' => $has_alert ? $max_level : '',
    ];
}

function sp_pending_module_placeholder() {
    return [
        'status' => 'pending',
        'level' => '',
        'summary' => 'กำลังตรวจ...',
        'details' => [],
        'items' => [],
    ];
}

function sp_build_pending_patient_row(array $pat, $patient_type, $screen_date, array $modules) {
    $fake = [
        'modules' => [],
        'overall' => 'pending',
        'overall_level' => '',
    ];
    foreach ($modules as $mod) {
        $k = $mod['module_key'] ?? '';
        if ($k !== '') {
            $fake['modules'][$k] = sp_pending_module_placeholder();
        }
    }
    return sp_build_screened_patient_row($pat, $fake, $patient_type, $screen_date, $modules);
}

function sp_build_screened_patient_row(array $pat, array $screen, $patient_type, $screen_date, array $modules) {
    $ward_display = ($patient_type === 'OPD')
        ? 'ผู้ป่วยนอก'
        : (trim(($pat['ward_name'] ?? '') . (($pat['ward_name'] ?? '') && ($pat['bedno'] ?? '') ? ' / ' : '') . ($pat['bedno'] ?? '')) ?: '-');
    $mod_display = [];
    foreach ($modules as $mod) {
        $k = $mod['module_key'];
        $r = $screen['modules'][$k] ?? sp_result_na();
        $mod_display[$k] = [
            'status' => $r['status'],
            'level' => $r['level'],
            'summary' => $r['summary'],
            'details' => $r['details'] ?? [],
            'items' => $r['items'] ?? [],
        ];
    }
    $order_dt = sp_patient_order_datetime($pat);
    return [
        'hn' => ltrim($pat['hn'] ?? '', '0'),
        'hn_full' => $pat['hn'] ?? '',
        'vn' => $pat['vn'] ?? '',
        'an' => $pat['an'] ?? '',
        'ptname' => trim($pat['ptname'] ?? ''),
        'vstdate' => $pat['vstdate'] ?? $screen_date,
        'vsttime' => $pat['vsttime'] ?? '',
        'rxdate' => $order_dt['date'],
        'rxtime' => $order_dt['time'],
        'patient_type' => $patient_type,
        'ward_display' => $ward_display,
        'overall' => $screen['overall'],
        'overall_level' => $screen['overall_level'],
        'modules' => $mod_display,
    ];
}

/** รายการที่บันทึก Intervention แล้ว ไม่โชว์เป็น Alert — ใช้สัญลักษณ์ Intervention แทน */
function sp_apply_intervention_display($con, $patient_type, $screen_date, array $rows) {
    $ptype = $patient_type === 'IPD' ? 'IPD' : 'OPD';
    $sdate = mysqli_real_escape_string($con, $screen_date);
    $ptype_esc = mysqli_real_escape_string($con, $ptype);
    $q = mysqli_query($con, "SELECT l.hn, l.vn, l.module_key
        FROM smart_pharma_alert_logs l
        INNER JOIN pharmacist_interventions i ON i.alert_log_id = l.id
        WHERE l.patient_type='$ptype_esc' AND l.screen_date='$sdate'
        GROUP BY l.hn, l.vn, l.module_key");
    if (!$q) {
        return $rows;
    }
    $map = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $hn = trim((string)($r['hn'] ?? ''));
        $hn0 = ltrim($hn, '0');
        if ($hn0 === '') {
            $hn0 = $hn;
        }
        $vn = trim((string)($r['vn'] ?? ''));
        $mod = trim((string)($r['module_key'] ?? ''));
        foreach (array_unique([$hn, $hn0]) as $h) {
            if ($h === '' || $mod === '') {
                continue;
            }
            $map[$h . '|' . $vn . '|' . $mod] = true;
        }
    }
    if (!$map) {
        return $rows;
    }
    foreach ($rows as &$row) {
        $hn = trim((string)($row['hn_full'] ?? $row['hn'] ?? ''));
        $hn0 = ltrim($hn, '0');
        if ($hn0 === '') {
            $hn0 = $hn;
        }
        $vn = trim((string)($row['vn'] ?? ''));
        $has_alert = false;
        $has_hard = false;
        $pending = false;
        if (!isset($row['modules']) || !is_array($row['modules'])) {
            continue;
        }
        foreach ($row['modules'] as $k => &$mod) {
            $hit = !empty($map[$hn . '|' . $vn . '|' . $k]) || !empty($map[$hn0 . '|' . $vn . '|' . $k]);
            if ($hit && ($mod['status'] ?? '') === 'alert') {
                $mod['status'] = 'intervention';
            }
            if (($mod['status'] ?? '') === 'alert') {
                $has_alert = true;
                if (($mod['level'] ?? '') === 'hard') {
                    $has_hard = true;
                }
            } elseif (($mod['status'] ?? '') === 'pending') {
                $pending = true;
            }
        }
        unset($mod);
        if ($has_alert) {
            $row['overall'] = 'alert';
            $row['overall_level'] = $has_hard ? 'hard' : 'soft';
        } elseif ($pending) {
            $row['overall'] = 'pending';
            $row['overall_level'] = '';
        } else {
            $row['overall'] = 'pass';
            $row['overall_level'] = '';
        }
    }
    unset($row);
    return $rows;
}

function sp_filter_screened_rows_by_time(array $rows, $screen_date, $window, $time_from = '', $time_to = '') {
    if ($window === 'full') {
        return $rows;
    }
    $out = [];
    foreach ($rows as $row) {
        $p = [
            'rxdate' => $row['rxdate'] ?? '',
            'rxtime' => $row['rxtime'] ?? '',
            'vstdate' => $row['vstdate'] ?? '',
            'vsttime' => $row['vsttime'] ?? '',
        ];
        if ($window === 'custom' && $time_from !== '' && $time_to !== '') {
            $hit = sp_filter_patients_by_custom_time([$p], $time_from, $time_to);
        } else {
            $hit = sp_filter_patients_by_time_window([$p], $screen_date, $window);
        }
        if (!empty($hit)) {
            $out[] = $row;
        }
    }
    return $out;
}

function sp_intervention_resolve_recorder($con, array $data, $user_id, $user_name) {
    $session_id = (int)$user_id;
    $session_name = trim((string)$user_name);
    $want = (int)($data['recorded_by'] ?? 0);
    if ($want <= 0 || $want === $session_id) {
        return [$session_id, $session_name];
    }
    $q = mysqli_query($con, "SELECT id, full_name, role FROM users WHERE id=$want LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    $name = trim((string)($row['full_name'] ?? ''));
    if (!$row || ($row['role'] ?? '') !== 'pharmacist' || $name === '') {
        return [$session_id, $session_name];
    }
    return [(int)$row['id'], $name];
}

function sp_save_intervention($con, array $data, $user_id, $user_name) {
    require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
    sp_alert_log_ensure_tables($con);

    $hn_raw = trim((string)($data['hn'] ?? ''));
    $vn_raw = trim((string)($data['vn'] ?? ''));
    $ptype = in_array($data['patient_type'] ?? '', ['OPD', 'IPD'], true) ? $data['patient_type'] : 'OPD';
    $screen_date = trim((string)($data['screen_date'] ?? $data['vstdate'] ?? date('Y-m-d')));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $screen_date)) {
        $screen_date = date('Y-m-d');
    }
    $module_key = trim((string)($data['module_key'] ?? ''));
    $alert_level = ($data['alert_level'] ?? '') === 'hard' ? 'hard' : 'soft';

    $alert_log_id = (int)($data['alert_log_id'] ?? 0);
    $alert_log = null;
    if ($alert_log_id > 0) {
        $q = mysqli_query($con, "SELECT * FROM smart_pharma_alert_logs WHERE id=$alert_log_id LIMIT 1");
        $alert_log = $q ? mysqli_fetch_assoc($q) : null;
        if ($alert_log) {
            $alert_level = ($alert_log['alert_level'] ?? '') === 'hard' ? 'hard' : 'soft';
            if ($module_key === '') {
                $module_key = trim((string)($alert_log['module_key'] ?? ''));
            }
        } else {
            $alert_log_id = 0;
        }
    }
    if ($alert_log_id <= 0) {
        $alert_log = sp_alert_log_find_pending($con, $ptype, $screen_date, $hn_raw, $vn_raw, $module_key);
        $alert_log_id = (int)($alert_log['id'] ?? 0);
    }
    if ($alert_log_id <= 0) {
        $alert_log = sp_alert_log_find_for_intervention(
            $con, $ptype, $screen_date, $hn_raw, $vn_raw, $module_key, $data['an'] ?? '', true
        );
        $alert_log_id = (int)($alert_log['id'] ?? 0);
    }

    $hn = mysqli_real_escape_string($con, $hn_raw);
    $vn = mysqli_real_escape_string($con, $vn_raw);
    $an = mysqli_real_escape_string($con, $data['an'] ?? '');
    $vst = mysqli_real_escape_string($con, $data['vstdate'] ?? $screen_date);
    $mod = mysqli_real_escape_string($con, $module_key);
    $lvl = mysqli_real_escape_string($con, $alert_level);
    $sum = mysqli_real_escape_string($con, $data['alert_summary'] ?? '');
    $itype = mysqli_real_escape_string($con, $data['intervention_type'] ?? 'recommend');
    $dcat = mysqli_real_escape_string($con, $data['deviation_category'] ?? '');
    $note = mysqli_real_escape_string($con, $data['note_text'] ?? '');
    $consult = mysqli_real_escape_string($con, $data['consult_result'] ?? '');
    list($uid, $recorder_name) = sp_intervention_resolve_recorder($con, $data, $user_id, $user_name);
    $uname = mysqli_real_escape_string($con, $recorder_name);

    $resolves = 1;
    $alert_log_sql = $alert_log_id > 0 ? (string)$alert_log_id : 'NULL';

    $sql = "INSERT INTO pharmacist_interventions
        (hn, vn, an, patient_type, vstdate, module_key, alert_log_id, resolves_alert, alert_level, alert_summary,
         intervention_type, deviation_category, note_text, consult_result, recorded_by, recorded_name)
        VALUES ('$hn','$vn','$an','$ptype','$vst','$mod',$alert_log_sql,$resolves,'$lvl','$sum','$itype','$dcat','$note','$consult',$uid,'$uname')";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'message' => 'บันทึกไม่สำเร็จ: ' . mysqli_error($con)];
    }
    $new_iv_id = (int)mysqli_insert_id($con);

    if ($alert_log_id <= 0) {
        $alert_log = sp_alert_log_find_by_uid($con, $ptype, $screen_date, $hn_raw, $vn_raw, $module_key);
        $alert_log_id = (int)($alert_log['id'] ?? 0);
    }
    if ($alert_log_id <= 0) {
        $alert_log = sp_alert_log_find_for_intervention(
            $con, $ptype, $screen_date, $hn_raw, $vn_raw, $module_key, $data['an'] ?? '', false
        );
        $alert_log_id = (int)($alert_log['id'] ?? 0);
    }
    if ($alert_log_id > 0) {
        $st_q = mysqli_query($con, "SELECT status, resolved_by FROM smart_pharma_alert_logs WHERE id=$alert_log_id LIMIT 1");
        $st = $st_q ? mysqli_fetch_assoc($st_q) : null;
        if ($st && ($st['status'] ?? '') === 'pending') {
            sp_alert_log_resolve_by_intervention($con, $alert_log_id);
        } elseif ($st && ($st['resolved_by'] ?? '') !== 'intervention') {
            mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
                status='resolved', resolved_by='intervention', resolved_at=NOW(), has_pharmacist_note=1
                WHERE id=$alert_log_id");
        }
        if ($new_iv_id > 0) {
            mysqli_query($con, "UPDATE pharmacist_interventions SET alert_log_id=$alert_log_id, resolves_alert=1
                WHERE id=$new_iv_id");
        }
    }
    $message = 'บันทึก Intervention แล้ว — ปิดการแจ้งเตือนรายการนี้';
    require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
    $mute_msg = sp_alert_mute_from_intervention($con, $data, $user_id, $user_name);
    if ($mute_msg !== '') {
        $message .= ' — ' . $mute_msg;
    }
    return [
        'ok' => true,
        'id' => $new_iv_id,
        'message' => $message,
        'hard_pending' => false,
    ];
}

function sp_update_intervention($con, $intervention_id, array $data, $user_id, $user_name) {
    $id = (int)$intervention_id;
    if ($id <= 0) {
        return ['ok' => false, 'message' => 'ไม่พบรายการ Intervention'];
    }
    $q = mysqli_query($con, "SELECT * FROM pharmacist_interventions WHERE id=$id LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return ['ok' => false, 'message' => 'ไม่พบรายการ Intervention'];
    }
    $itype = mysqli_real_escape_string($con, $data['intervention_type'] ?? $row['intervention_type']);
    $dcat = mysqli_real_escape_string($con, $data['deviation_category'] ?? $row['deviation_category']);
    $note = mysqli_real_escape_string($con, $data['note_text'] ?? $row['note_text']);
    $consult = mysqli_real_escape_string($con, $data['consult_result'] ?? ($row['consult_result'] ?? ''));
    list($uid, $recorder_name) = sp_intervention_resolve_recorder($con, $data, $user_id, $user_name);
    $uname = mysqli_real_escape_string($con, $recorder_name);
    if (!mysqli_query($con, "UPDATE pharmacist_interventions SET
            intervention_type='$itype', deviation_category='$dcat', note_text='$note',
            consult_result='$consult',
            recorded_by=$uid, recorded_name='$uname'
            WHERE id=$id")) {
        return ['ok' => false, 'message' => 'แก้ไขไม่สำเร็จ: ' . mysqli_error($con)];
    }
    $message = 'แก้ไข Intervention เรียบร้อย';
    require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
    $mute_msg = sp_alert_mute_from_intervention($con, $data, $user_id, $user_name);
    if ($mute_msg !== '') {
        $message .= ' — ' . $mute_msg;
    }
    return ['ok' => true, 'message' => $message];
}

function sp_delete_intervention($con, $intervention_id) {
    $id = (int)$intervention_id;
    if ($id <= 0) {
        return ['ok' => false, 'message' => 'ไม่พบรายการ Intervention'];
    }
    $q = mysqli_query($con, "SELECT * FROM pharmacist_interventions WHERE id=$id LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return ['ok' => false, 'message' => 'ไม่พบรายการ Intervention'];
    }
    $key = sp_intervention_event_key($row);
    $hn = trim((string)($row['hn'] ?? ''));
    $hn_norm = ltrim($hn, '0');
    if ($hn_norm === '') {
        $hn_norm = $hn;
    }
    $mod = mysqli_real_escape_string($con, (string)($row['module_key'] ?? ''));
    $vst = mysqli_real_escape_string($con, substr((string)($row['vstdate'] ?? ''), 0, 10));
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $norm_esc = mysqli_real_escape_string($con, $hn_norm);
    $cand = mysqli_query($con, "SELECT * FROM pharmacist_interventions
        WHERE module_key='$mod' AND vstdate='$vst'
          AND (hn='$hn_esc' OR TRIM(LEADING '0' FROM hn)='$norm_esc')");
    $ids = [];
    $alert_ids = [];
    $deleted_rows = [$row];
    if ($cand) {
        while ($r = mysqli_fetch_assoc($cand)) {
            if (sp_intervention_event_key($r) !== $key) {
                continue;
            }
            $rid = (int)($r['id'] ?? 0);
            if ($rid > 0) {
                $ids[$rid] = true;
            }
            $aid = (int)($r['alert_log_id'] ?? 0);
            if ($aid > 0) {
                $alert_ids[$aid] = true;
            }
            $deleted_rows[] = $r;
        }
    }
    if (!$ids) {
        $ids[$id] = true;
        $aid = (int)($row['alert_log_id'] ?? 0);
        if ($aid > 0) {
            $alert_ids[$aid] = true;
        }
    }
    $id_sql = implode(',', array_map('intval', array_keys($ids)));
    if (!mysqli_query($con, "DELETE FROM pharmacist_interventions WHERE id IN ($id_sql)")) {
        return ['ok' => false, 'message' => 'ลบไม่สำเร็จ: ' . mysqli_error($con)];
    }
    require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
    foreach ($deleted_rows as $deleted_row) {
        sp_intervention_remember_deletion($con, $deleted_row);
    }
    $reopened = 0;
    foreach (array_keys($alert_ids) as $alert_log_id) {
        $alert_log_id = (int)$alert_log_id;
        $left_q = mysqli_query($con, "SELECT COUNT(*) AS n FROM pharmacist_interventions WHERE alert_log_id=$alert_log_id");
        $left = $left_q ? (int)(mysqli_fetch_assoc($left_q)['n'] ?? 0) : 0;
        if ($left === 0 && mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
                status='pending', resolved_by=NULL, resolved_at=NULL, has_pharmacist_note=0
                WHERE id=$alert_log_id AND resolved_by='intervention'")) {
            $reopened += mysqli_affected_rows($con);
        }
    }
    $n = count($ids);
    $message = 'ลบ Intervention ของเคสนี้ ' . $n . ' รายการแล้ว';
    if ($reopened > 0) {
        $message .= ' และเปิด Alert ที่เกี่ยวข้องกลับมา';
    }
    return [
        'ok' => true,
        'deleted_count' => $n,
        'message' => $message,
    ];
}

function sp_list_interventions($con, $start, $end, $limit = 200) {
    $start_esc = mysqli_real_escape_string($con, $start);
    $end_esc = mysqli_real_escape_string($con, $end);
    $limit = max(1, min(500, (int)$limit));
    $sql = "SELECT i.*, m.label_th AS module_label
        FROM pharmacist_interventions i
        LEFT JOIN smart_pharma_modules m ON m.module_key = i.module_key
        WHERE i.vstdate >= '$start_esc' AND i.vstdate <= '$end_esc'
        ORDER BY i.created_at DESC
        LIMIT $limit";
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function sp_intervention_type_labels() {
    return [
        'recommend' => 'แนะนำ / Consult',
        'adjust' => 'ปรับยา',
        'reject' => 'ไม่จ่าย / Hold',
        'followup' => 'ติดตาม',
        'document' => 'บันทึกเท่านั้น',
    ];
}

function sp_intervention_type_label($key) {
    $key = trim((string)$key);
    $map = sp_intervention_type_labels();
    if (isset($map[$key])) {
        return $map[$key];
    }
    return $key !== '' ? $key : 'ไม่ระบุ';
}

function sp_intervention_report_note($note, $summary = '') {
    $lines = preg_split("/\r\n|\n|\r/", trim((string)$note));
    $skip = [
        'เริ่ม Consult + พิมพ์ใบปรึกษาแพทย์',
        'ปิดการ Consult',
        'บันทึกผล Consult',
    ];
    $kept = [];
    foreach ($lines as $line) {
        $line = trim((string)$line);
        if ($line === '' || in_array($line, $skip, true)) {
            continue;
        }
        $kept[] = $line;
    }
    $text = trim(implode("\n", $kept));
    $sum = trim((string)$summary);
    if ($text !== '' && $sum !== '' && strpos($sum, $text) !== false) {
        return '';
    }
    return $text;
}

function sp_person_name_compact($name) {
    $name = preg_replace('/\s+/u', '', trim((string)$name));
    $name = preg_replace('/^(นางสาว|นาย|นาง|ภก\.|ภญ\.)/u', '', (string)$name);
    return $name;
}

function sp_person_name_sql($column) {
    return "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(IFNULL($column,''),' ',''),'นางสาว',''),'นาย',''),'นาง',''),'ภก.','')";
}

function sp_intervention_report_fetch($con, $start, $end, array $filters = []) {
    $start_esc = mysqli_real_escape_string($con, $start);
    $end_esc = mysqli_real_escape_string($con, $end);
    $where = [
        "i.created_at >= '$start_esc 00:00:00'",
        "i.created_at <= '$end_esc 23:59:59'",
    ];
    $ptype = $filters['patient_type'] ?? '';
    if (in_array($ptype, ['OPD', 'IPD'], true)) {
        $where[] = "i.patient_type='$ptype'";
    }
    $module = trim((string)($filters['module_key'] ?? ''));
    if ($module !== '') {
        $where[] = "i.module_key='" . mysqli_real_escape_string($con, $module) . "'";
    }
    $itype = trim((string)($filters['intervention_type'] ?? ''));
    if ($itype !== '') {
        $where[] = "i.intervention_type='" . mysqli_real_escape_string($con, $itype) . "'";
    }
    $level = $filters['alert_level'] ?? '';
    if (in_array($level, ['hard', 'soft'], true)) {
        $where[] = "i.alert_level='$level'";
    }
    $deviation = trim((string)($filters['deviation'] ?? ''));
    if ($deviation === 'error') {
        $where[] = "i.deviation_category='ความคลาดเคลื่อนจริง'";
    } elseif ($deviation === 'not_error') {
        $where[] = "i.deviation_category='ไม่ใช่ความคลาดเคลื่อน'";
    } elseif ($deviation === 'unset') {
        $where[] = "(i.deviation_category IS NULL OR i.deviation_category='')";
    } elseif ($deviation !== '') {
        $where[] = "i.deviation_category='" . mysqli_real_escape_string($con, $deviation) . "'";
    }
    $recorder = trim((string)($filters['recorder'] ?? ''));
    if (strpos($recorder, 'who:') === 0) {
        $who = mysqli_real_escape_string($con, sp_person_name_compact(substr($recorder, 4)));
        if ($who !== '') {
            $where[] = sp_person_name_sql('i.recorded_name') . "='$who'";
        }
    } elseif (strpos($recorder, 'id:') === 0) {
        $where[] = 'i.recorded_by=' . (int)substr($recorder, 3);
    } elseif (strpos($recorder, 'name:') === 0) {
        $name = mysqli_real_escape_string($con, substr($recorder, 5));
        $where[] = "i.recorded_name='$name'";
    }
    $ward = trim((string)($filters['ward'] ?? ''));
    if ($ward === '__none__') {
        $where[] = "(l.ward_display IS NULL OR l.ward_display='')";
    } elseif ($ward !== '') {
        $where[] = "l.ward_display='" . mysqli_real_escape_string($con, $ward) . "'";
    }
    $qtext = trim((string)($filters['q'] ?? ''));
    if ($qtext !== '') {
        $like = mysqli_real_escape_string($con, $qtext);
        $compact = mysqli_real_escape_string($con, sp_person_name_compact($qtext));
        $name_sql = $compact !== ''
            ? " OR " . sp_person_name_sql('i.recorded_name') . " LIKE '%$compact%' OR " . sp_person_name_sql('l.ptname') . " LIKE '%$compact%'"
            : '';
        $where[] = "(i.hn LIKE '%$like%' OR i.vn LIKE '%$like%' OR i.an LIKE '%$like%'
            OR i.note_text LIKE '%$like%' OR i.alert_summary LIKE '%$like%'
            OR i.recorded_name LIKE '%$like%' OR l.ptname LIKE '%$like%'$name_sql)";
    }
    $sql = "SELECT i.*, m.label_th AS module_label, l.ptname, l.ward_display
        FROM pharmacist_interventions i
        LEFT JOIN smart_pharma_modules m ON m.module_key = i.module_key
        LEFT JOIN smart_pharma_alert_logs l ON l.id = i.alert_log_id
        WHERE " . implode(' AND ', $where) . "
        ORDER BY i.created_at DESC, i.id DESC
        LIMIT 3000";
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return sp_intervention_report_latest_only($rows);
}

/** ผู้ป่วย + เหตุการณ์ + ผู้บันทึกเดียวกัน เหลือรายการล่าสุดรายการเดียว */
function sp_intervention_event_key(array $r) {
    $hn = ltrim(trim((string)($r['hn'] ?? '')), '0');
    if ($hn === '') {
        $hn = trim((string)($r['hn'] ?? ''));
    }
    $event = preg_replace('/\s+/u', ' ', trim((string)($r['alert_summary'] ?? '')));
    if ($event === '') {
        $event = preg_replace('/\s+/u', ' ', trim((string)($r['note_text'] ?? '')));
    }
    $who = sp_person_name_compact($r['recorded_name'] ?? '');
    if ($who === '') {
        $who = 'id:' . (int)($r['recorded_by'] ?? 0);
    }
    return implode('|', [
        $hn,
        trim((string)($r['module_key'] ?? '')),
        substr(trim((string)($r['vstdate'] ?? '')), 0, 10),
        $event,
        $who,
    ]);
}

function sp_intervention_report_latest_only(array $rows) {
    $kept = [];
    $seen = [];
    foreach ($rows as $r) {
        $key = sp_intervention_event_key($r);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $kept[] = $r;
    }
    return $kept;
}

function sp_intervention_report_options($con, $start, $end) {
    $start_esc = mysqli_real_escape_string($con, $start);
    $end_esc = mysqli_real_escape_string($con, $end);
    $span = "i.created_at >= '$start_esc 00:00:00' AND i.created_at <= '$end_esc 23:59:59'";
    $out = [
        'modules' => [],
        'types' => [],
        'deviations' => [],
        'recorders' => [],
        'wards' => [],
    ];
    $mq = mysqli_query($con, "SELECT module_key, label_th FROM smart_pharma_modules ORDER BY sort_order ASC, label_th ASC");
    if ($mq) {
        while ($r = mysqli_fetch_assoc($mq)) {
            $out['modules'][$r['module_key']] = $r['label_th'] ?: $r['module_key'];
        }
    }
    $tq = mysqli_query($con, "SELECT DISTINCT intervention_type FROM pharmacist_interventions i WHERE $span AND intervention_type <> ''");
    if ($tq) {
        while ($r = mysqli_fetch_assoc($tq)) {
            $k = trim((string)$r['intervention_type']);
            if ($k !== '') {
                $out['types'][$k] = sp_intervention_type_label($k);
            }
        }
    }
    foreach (sp_intervention_type_labels() as $k => $label) {
        if (!isset($out['types'][$k])) {
            $out['types'][$k] = $label;
        }
    }
    $dq = mysqli_query($con, "SELECT DISTINCT deviation_category FROM pharmacist_interventions i WHERE $span");
    if ($dq) {
        while ($r = mysqli_fetch_assoc($dq)) {
            $k = trim((string)($r['deviation_category'] ?? ''));
            if ($k !== '' && !in_array($k, ['ความคลาดเคลื่อนจริง', 'ไม่ใช่ความคลาดเคลื่อน'], true)) {
                $out['deviations'][$k] = $k;
            }
        }
    }
    $rq = mysqli_query($con, "SELECT recorded_by, recorded_name, COUNT(*) AS n
        FROM pharmacist_interventions i
        WHERE $span
        GROUP BY recorded_by, recorded_name
        ORDER BY n DESC, recorded_name ASC");
    if ($rq) {
        while ($r = mysqli_fetch_assoc($rq)) {
            $id = (int)($r['recorded_by'] ?? 0);
            $name = trim((string)preg_replace('/\s+/u', ' ', (string)($r['recorded_name'] ?? '')));
            $compact = sp_person_name_compact($name);
            if ($compact !== '') {
                $key = 'who:' . $compact;
                $label = preg_replace('/^(นางสาว|นาย|นาง|ภก\.|ภญ\.)\s*/u', '', $name);
                $out['recorders'][$key] = $label !== '' ? $label : $name;
            } else {
                $key = $id > 0 ? ('id:' . $id) : ('name:' . $name);
                $out['recorders'][$key] = $name !== '' ? $name : ('ผู้ใช้ #' . $id);
            }
        }
    }
    $wq = mysqli_query($con, "SELECT DISTINCT l.ward_display
        FROM pharmacist_interventions i
        LEFT JOIN smart_pharma_alert_logs l ON l.id = i.alert_log_id
        WHERE $span AND l.ward_display IS NOT NULL AND l.ward_display <> ''
        ORDER BY l.ward_display ASC");
    if ($wq) {
        while ($r = mysqli_fetch_assoc($wq)) {
            $w = trim((string)($r['ward_display'] ?? ''));
            if ($w !== '') {
                $out['wards'][$w] = $w;
            }
        }
    }
    return $out;
}

/**
 * คัดกรองรายชื่อผู้ป่วย (ใช้กับ Cron Telegram)
 * กรองตาม time_window ก่อนคัดกรอง — ไม่ประมวลผลทั้งวันแล้วค่อยตัดทิ้ง
 */
function sp_run_screening_list($con, &$hos, $patient_type, $screen_date, $time_window = 'full') {
    $patient_type = $patient_type === 'IPD' ? 'IPD' : 'OPD';
    $time_window = sp_normalize_time_window($time_window, $screen_date);
    $hos_timeout = 180;
    if (function_exists('hosxp_ensure_connection')) {
        hosxp_ensure_connection($con, $hos, $hos_timeout);
    }
    $modules = sp_get_modules($con, $patient_type);
    if (empty($modules)) {
        return ['patients' => [], 'module_labels' => [], 'alert_log' => ['new' => 0, 'updated' => 0, 'reopened' => 0, 'resolved' => 0, 'skipped' => 0]];
    }
    if (!$hos) {
        return ['patients' => [], 'module_labels' => [], 'alert_log' => ['new' => 0, 'updated' => 0, 'reopened' => 0, 'resolved' => 0, 'skipped' => 0], 'error' => 'HOSxP connection lost'];
    }
    if ($patient_type === 'OPD') {
        $patients_with_drugs = sp_fetch_opd_patients_with_drugs($hos, $screen_date);
    } else {
        $patients_all = sp_fetch_ipd_patients($hos, $screen_date);
        $patients_with_drugs = sp_filter_patients_with_drug_orders(
            sp_enrich_patients_rx_time($hos, $patients_all, $screen_date)
        );
    }
    // สำคัญ: คัดเฉพาะช่วงเวลาที่ต้องการก่อนยิง DI / build cache / screen
    $patients_to_screen = sp_patients_for_time_window($patients_with_drugs, $screen_date, $time_window);
    if (empty($patients_to_screen)) {
        $module_labels = [];
        foreach ($modules as $mod) {
            $module_labels[$mod['module_key']] = $mod['label_th'];
        }
        return [
            'patients' => [],
            'all_screened' => [],
            'module_labels' => $module_labels,
            'alert_log' => ['new' => 0, 'updated' => 0, 'reopened' => 0, 'resolved' => 0, 'skipped' => 0],
            'time_window' => $time_window,
            'total_day' => count($patients_with_drugs),
            'screened' => 0,
        ];
    }

    $di_batch = null;
    foreach ($modules as $mod) {
        if (($mod['module_key'] ?? '') === 'di') {
            $hn_filter = sp_extract_hn_list($patients_to_screen);
            $di_batch = sp_batch_screen_di_for_date($con, $hos, $screen_date, $hn_filter);
            break;
        }
    }
    $screen_ctx = sp_build_screen_cache($con, $hos, $patients_to_screen, $screen_date, $modules);

    $module_labels = [];
    foreach ($modules as $mod) {
        $module_labels[$mod['module_key']] = $mod['label_th'];
    }
    $all_screened = [];
    foreach ($patients_to_screen as $pat) {
        $screen = sp_screen_patient($con, $hos, $pat, $modules, $di_batch, $screen_date, $screen_ctx);
        $all_screened[] = sp_build_screened_patient_row($pat, $screen, $patient_type, $screen_date, $modules);
    }
    require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
    $all_screened = sp_apply_alert_mutes($con, $patient_type, $all_screened);
    // ช่วงไม่ใช่ทั้งวัน — ไม่ resolve alert ของคนนอกช่วง (กันปิด alert ผิด)
    $alert_log = sp_alert_log_sync(
        $con,
        $patient_type,
        $screen_date,
        $all_screened,
        $time_window === 'full'
    );
    return [
        'patients' => $all_screened,
        'all_screened' => $all_screened,
        'module_labels' => $module_labels,
        'alert_log' => $alert_log,
        'time_window' => $time_window,
        'total_day' => count($patients_with_drugs),
        'screened' => count($all_screened),
    ];
}
