<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    die('Unauthorized');
}
$role = (string)($_SESSION['role'] ?? '');
if ($role !== 'admin') {
    // อนุญาตสิทธิ์เมนูอัปเกรดด้วย
    include __DIR__ . '/connect.php';
    require_once __DIR__ . '/menu_permissions_helper.php';
    if (empty($_SESSION['menu_permissions_loaded'])) {
        tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $role);
    }
    if (!tham_menu_can('admin.upgrade')) {
        die('เฉพาะ Admin / ผู้มีสิทธิ์อัปเกรด');
    }
}

require_once __DIR__ . '/update_install_helper.php';

$zipUrl = isset($_GET['url']) ? trim((string)$_GET['url']) : '';
if ($zipUrl === '') {
    die('ไม่พบลิงก์สำหรับดาวน์โหลดอัปเดต');
}

@ini_set('max_execution_time', '240');
@set_time_limit(240);

$appRoot = __DIR__;
$localZipFile = $appRoot . '/update_temp.zip';

header('Content-Type: text/html; charset=utf-8');
echo "<!DOCTYPE html><html lang='th'><head><meta charset='utf-8'><title>อัปเดตระบบ</title></head><body>";
echo "<div style='font-family: Sarabun, Tahoma, sans-serif; max-width:720px; margin:40px auto; padding:24px; border:1px solid #ddd; border-radius:10px;'>";
echo '<h2>กำลังดาวน์โหลดการอัปเดต…</h2>';
echo '<p class="small" style="color:#555;">ระบบจะ<strong>ไม่ทับ</strong>ไฟล์ตั้งค่าเฉพาะ รพ. '
    . '(db_connect.php, license.key, secure/, uploads/, logs/)</p>';

$dl = tham_update_download_zip($zipUrl, $localZipFile);
if (empty($dl['ok'])) {
    echo "<h3 style='color:#c0392b;'>❌ " . htmlspecialchars($dl['error'] ?? 'ดาวน์โหลดล้มเหลว', ENT_QUOTES, 'UTF-8') . '</h3>';
    echo "<p><a href='upgrade.php'>กลับหน้าอัปเกรด</a></p></div></body></html>";
    exit;
}

echo '<p>✅ ดาวน์โหลดสำเร็จ (' . number_format((int)$dl['bytes']) . ' bytes) — กำลังติดตั้ง…</p>';
flush();

$apply = tham_update_apply_zip($localZipFile, $appRoot);
@unlink($localZipFile);

if (empty($apply['ok'])) {
    echo "<h3 style='color:#c0392b;'>❌ " . htmlspecialchars($apply['error'] ?? 'ติดตั้งล้มเหลว', ENT_QUOTES, 'UTF-8') . '</h3>';
    echo "<p><a href='upgrade.php'>กลับหน้าอัปเกรด</a></p></div></body></html>";
    exit;
}

echo '<p>✅ คัดลอกไฟล์ใหม่ ' . (int)$apply['copied'] . ' ไฟล์';
if (!empty($apply['skipped'])) {
    echo ' · ข้ามไฟล์ที่ป้องกัน/ล้มเหลว ' . (int)$apply['skipped'] . ' รายการ';
}
echo '</p>';
if (!empty($apply['skipped_list'])) {
    echo '<details style="text-align:left;margin:12px 0;"><summary>ไฟล์ที่ข้าม (ตัวอย่าง)</summary><ul style="font-size:13px;">';
    foreach ($apply['skipped_list'] as $s) {
        echo '<li>' . htmlspecialchars($s, ENT_QUOTES, 'UTF-8') . '</li>';
    }
    echo '</ul></details>';
}

echo "<h3 style='color:#1a7f37;'>กำลังพาไปอัปเดตฐานข้อมูล…</h3>";
echo "<script>setTimeout(function(){ location.href='upgrade.php'; }, 1600);</script>";
echo '<p><a href="upgrade.php">ไปหน้าอัปเกรดฐานข้อมูลทันที</a></p>';
echo '</div></body></html>';
