<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_mg_ml_helper.php');
include(__DIR__ . '/dose_calculator_helper.php');
include(__DIR__ . '/pediatric_dose_helper.php');
mysqli_set_charset($con, 'utf8');
pdc_ensure_table($con);
dc_ensure_tables($con);
set_time_limit(180);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($_POST)) {
    $raw_body = file_get_contents('php://input');
    if (is_string($raw_body) && $raw_body !== '') {
        $parsed_body = [];
        parse_str($raw_body, $parsed_body);
        if (is_array($parsed_body) && $parsed_body) {
            $_POST = $parsed_body;
        }
    }
}

function pdc_mon_req($key, $default = '') {
    if (isset($_POST[$key]) && (is_string($_POST[$key]) || is_numeric($_POST[$key]))) {
        return trim((string)$_POST[$key]);
    }
    if (isset($_GET[$key]) && (is_string($_GET[$key]) || is_numeric($_GET[$key]))) {
        return trim((string)$_GET[$key]);
    }
    return $default;
}

function pdc_mon_norm_hn($hn) {
    $d = preg_replace('/\D+/', '', (string)$hn);
    $d = ltrim((string)$d, '0');
    return $d === '' ? '' : $d;
}

function pdc_mon_hn_match($got, $want_raw) {
    $a = pdc_mon_norm_hn($got);
    $b = pdc_mon_norm_hn($want_raw);
    return $a !== '' && $b !== '' && $a === $b;
}

function pdc_mon_filter_items_hn(array $items, $hn_raw) {
    if (pdc_mon_norm_hn($hn_raw) === '') {
        return $items;
    }
    $out = [];
    foreach ($items as $it) {
        if (!is_array($it)) {
            continue;
        }
        $got = $it['hn_full'] ?? $it['hn'] ?? '';
        if (pdc_mon_hn_match($got, $hn_raw)) {
            $out[] = $it;
        }
    }
    return $out;
}

$start_date = (string)pdc_mon_req('start_date', date('Y-m-d', strtotime('-3 days')));
$end_date = (string)pdc_mon_req('end_date', date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-3 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if (strtotime($start_date) > strtotime($end_date)) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$kids_only = (int)pdc_mon_req('kids_only', 1) === 1;
$tol_raw = pdc_mon_req('tolerance_pct', '');
$tol_pct = ($tol_raw === '' || $tol_raw === null)
    ? pdc_get_monitor_tolerance_pct($con)
    : pdc_clamp_tolerance_pct($tol_raw);
$rule_ids = [];
foreach (explode(',', (string)pdc_mon_req('rule_ids', '')) as $rid) {
    $rid = (int)trim($rid);
    if ($rid > 0) {
        $rule_ids[] = $rid;
    }
}

header('Content-Type: application/json; charset=utf-8');
$rules = pdc_load_monitor_rules($con, $rule_ids);
if (empty($rules)) {
    ob_clean();
    echo json_encode([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'passed_items' => [],
        'unverifiable_items' => [],
        'meta' => ['message' => 'ยังไม่มีรายการยาที่เปิดใช้งาน — ไปตั้งค่าที่คำนวณขนาดยาในเด็ก', 'rule_count' => 0],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}

$t0 = microtime(true);
$rule_by_icode = pdc_build_icode_rule_map($hos, $rules);
$icode_list = array_keys($rule_by_icode);
if (empty($icode_list)) {
    mysqli_close($hos);
    ob_clean();
    echo json_encode([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'passed_items' => [],
        'unverifiable_items' => [],
        'meta' => [
            'message' => 'จับคู่ icode จาก HOSxP ไม่ได้ — ผูกยาในแท็บตั้งค่าเครื่องคำนวณ',
            'rule_count' => count($rules),
            'matched_icodes' => 0,
        ],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$hn_raw = function_exists('monitor_req_hn') ? monitor_req_hn() : '';
if ($hn_raw === '') {
    $hn_raw = (string)pdc_mon_req('hn', '');
}
if ($hn_raw === '') {
    $hn_raw = (string)pdc_mon_req('filter_hn', '');
}
$order_rows = mmgml_fetch_orders_lean($hos, $icode_list, $start_date, $end_date, 0, 4000, $hn_raw);
if ($hn_raw !== '' && !empty($order_rows)) {
    $order_rows = array_values(array_filter($order_rows, static function ($row) use ($hn_raw) {
        return pdc_mon_hn_match($row['hn'] ?? '', $hn_raw);
    }));
}

$hn_for_age = [];
foreach ($order_rows as $row) {
    $hn = trim((string)($row['hn'] ?? ''));
    if ($hn !== '') {
        $hn_for_age[$hn] = true;
    }
}
$age_map = [];
if (!empty($hn_for_age)) {
    $hnIn = mmgml_sql_in_strings($hos, array_keys($hn_for_age));
    if ($hnIn !== '') {
        $qage = mysqli_query($hos, "SELECT hn, birthday FROM patient WHERE hn IN ({$hnIn})");
        if ($qage) {
            $today = $end_date ?: date('Y-m-d');
            while ($ar = mysqli_fetch_assoc($qage)) {
                $bd = trim((string)($ar['birthday'] ?? ''));
                if ($bd === '' || $bd === '0000-00-00') {
                    continue;
                }
                $age = function_exists('monitor_lab_patient_age_years')
                    ? (int)monitor_lab_patient_age_years($bd, $today) : null;
                if ($age === null) {
                    continue;
                }
                $hn = (string)$ar['hn'];
                $age_map[$hn] = $age;
                $age_map[ltrim($hn, '0')] = $age;
            }
        }
    }
}

if ($kids_only && $order_rows) {
    $kept = [];
    foreach ($order_rows as $row) {
        $hn = trim((string)($row['hn'] ?? ''));
        $age = $age_map[$hn] ?? $age_map[ltrim($hn, '0')] ?? null;
        if ($age !== null && $age > 15) {
            continue;
        }
        $kept[] = $row;
    }
    $order_rows = $kept;
}

$order_rows = mmgml_enrich_monitor_orders($hos, $order_rows);

$hn_for_vitals = [];
foreach ($order_rows as $row) {
    $hn = trim($row['hn'] ?? '');
    if ($hn !== '') {
        $hn_for_vitals[$hn] = true;
    }
}
$vitals_cache = [];
$dc_overrides = [];
if (!empty($hn_for_vitals)) {
    $vitals_cache = mmgml_prefetch_vitals($hos, $con, array_keys($hn_for_vitals), $start_date, $end_date, 365);
    $dc_overrides = dc_prefetch_vitals_overrides($con, array_keys($hn_for_vitals));
}

$hard_alerts = [];
$soft_alerts = [];
$passed_items = [];
$unverifiable_items = [];
$seen = [];
$orders_scanned = 0;
$orders_checked = 0;
$orders_excluded = 0;

foreach ($order_rows as $row) {
    $orders_scanned++;
    $icode = trim($row['icode'] ?? '');
    $matched = $rule_by_icode[$icode] ?? [];
    if (!$matched) {
        continue;
    }
    $hn = trim((string)($row['hn'] ?? ''));
    $age = $age_map[$hn] ?? $age_map[ltrim($hn, '0')] ?? null;

    $method = trim(preg_replace('/\s+/u', ' ', (string)($row['method'] ?? '')));
    if (pdc_is_nebulization_method($method)) {
        continue;
    }
    $order_date = !empty($row['rxdate']) ? $row['rxdate'] : ($row['vstdate'] ?? '');

    $weight_info = mmgml_get_weight_info_from_cache($vitals_cache, $hn, $order_date, 365);
    $weight_info = dc_merge_weight_override($weight_info, $dc_overrides, $hn);
    $bw = isset($weight_info['bw']) ? (float)$weight_info['bw'] : null;
    if ($bw !== null && $bw <= 0) {
        $bw = null;
    }
    if ($kids_only) {
        if ($age !== null && $age > 15) {
            continue;
        }
        if ($age === null && $bw !== null && $bw > 40) {
            continue;
        }
        if ($age === null && $bw === null) {
            continue;
        }
    }

    $evals = [];
    foreach ($matched as $rule) {
        if (pdc_should_exclude_order($rule, $row)) {
            $orders_excluded++;
            continue;
        }
        $parsed = pdc_parse_order_daily_mg(array_merge($row, ['method' => $method]), $rule);
        $daily_mg = $parsed['daily_mg'] ?? null;
        if ($daily_mg !== null && $daily_mg <= 0) {
            $daily_mg = null;
        }
        $rule_tol = pdc_effective_tolerance_pct($rule, $tol_pct, $con);
        $evals[] = array_merge(pdc_evaluate_order($rule, $bw, $daily_mg, $method, $rule_tol, $parsed), [
            '_rule' => $rule,
            '_parse' => $parsed,
            '_tolerance_pct' => $rule_tol,
        ]);
    }
    $eval = pdc_pick_eval($evals);
    if (!$eval) {
        continue;
    }
    $rule = $eval['_rule'] ?? $matched[0];
    $item_tol = $eval['_tolerance_pct'] ?? pdc_effective_tolerance_pct($rule, $tol_pct, $con);
    $orders_checked++;

    $dedupe = implode('|', [$hn, $row['vn'] ?? '', $row['an'] ?? '', $icode, $row['item_no'] ?? '', $method]);
    if (isset($seen[$dedupe])) {
        continue;
    }
    $seen[$dedupe] = true;

    $type_patient = $row['type_patient'] ?? ((trim((string)($row['vn'] ?? '')) === '') ? 'IPD' : 'OPD');
    $ward = trim((string)($row['ward_name'] ?? ''));
    $bedno = trim((string)($row['bedno'] ?? ''));
    $ward_display = $type_patient === 'OPD' ? 'ผู้ป่วยนอก' : trim($ward . ($ward && $bedno ? ' / ' : '') . $bedno);
    if ($ward_display === '') {
        $ward_display = '-';
    }
    $rx_time = '';
    if (function_exists('di_format_time') && function_exists('monitor_lab_normalize_hosxp_time')) {
        $rx_time = di_format_time(monitor_lab_normalize_hosxp_time($row['rxtime'] ?? ''));
    }
    $hn_disp = ltrim($hn, '0');
    if ($hn_disp === '') {
        $hn_disp = $hn;
    }
    $item = [
        'hn' => $hn_disp,
        'hn_full' => $hn,
        'ptname' => $row['ptname'] ?? '',
        'icode' => $icode,
        'drug_name' => $row['drug_name'] ?? ($rule['drug_name'] ?? ''),
        'strength_display' => pdc_format_strength_display($row, $rule, $eval['_parse'] ?? []),
        'rule_name' => $rule['drug_name'] ?? '',
        'method' => $method,
        'type_patient' => $type_patient,
        'ward_display' => $ward_display,
        'rxdate' => $order_date,
        'order_date' => $order_date ? date('d/m/Y', strtotime($order_date)) : '-',
        'order_time' => $rx_time,
        'qty' => isset($row['qty']) ? (float)$row['qty'] : null,
        'age' => $age,
        'weight_kg' => $bw,
        'weight_source' => !empty($weight_info['source']) ? $weight_info['source'] : (!empty($weight_info['from_calculator']) ? 'calculator' : 'hosxp'),
        'weight_vstdate' => $weight_info['vstdate'] ?? null,
        'daily_mg' => $eval['daily_mg'] ?? null,
        'daily_mg_display' => isset($eval['daily_mg']) && $eval['daily_mg'] !== null
            ? pdc_fmt($eval['daily_mg'], 1) . ' ' . (($eval['unit_suffix'] ?? '') !== '' ? $eval['unit_suffix'] : 'mg/วัน')
            : '—',
        'parse_note' => trim((string)(($eval['_parse']['note'] ?? ''))),
        'mg_kg_display' => isset($eval['mg_kg']) && $eval['mg_kg'] !== null
            ? pdc_fmt($eval['mg_kg'], 2) . ' ' . (($eval['kg_suffix'] ?? '') !== '' ? $eval['kg_suffix'] : 'mg/kg/วัน')
            : '—',
        'expected_display' => pdc_format_monitor_expected_display($eval, $item_tol),
        'suggest_text' => $eval['suggest_text'] ?? '',
        'suggest_value_text' => $eval['suggest_value_text'] ?? '',
        'order_unit' => $eval['order_unit'] ?? 'mg',
        'dose_basis' => $eval['dose_basis'] ?? 'day',
        'tolerance_pct' => $item_tol,
        'tolerance_custom' => isset($rule['tolerance_pct']) && $rule['tolerance_pct'] !== '' && $rule['tolerance_pct'] !== null,
        'unit_label' => pdc_unit_label($rule['dose_unit'] ?? 'mg_kg_dose'),
        'kg_range' => pdc_fmt_range($rule['mg_per_kg_min'] ?? null, $rule['mg_per_kg_max'] ?? null) . ' ' . pdc_unit_label($rule['dose_unit'] ?? ''),
        'alert_message' => $eval['message'] ?? '',
        'pass_message' => $eval['message'] ?? '',
        'dose_direction' => $eval['dose_direction'] ?? null,
        'dose_direction_label' => pdc_dose_direction_label($eval['dose_direction'] ?? null),
    ];

    $st = $eval['status'] ?? '';
    if ($st === 'alert' && ($eval['level'] ?? '') === 'hard') {
        $hard_alerts[] = $item;
    } elseif ($st === 'alert') {
        $soft_alerts[] = $item;
    } elseif ($st === 'pass') {
        $passed_items[] = $item;
    } else {
        $item['alert_message'] = $eval['reason'] ?? $eval['message'] ?? 'ประเมินไม่ได้';
        $unverifiable_items[] = $item;
    }
}

mysqli_close($hos);

if ($hn_raw !== '') {
    $hard_alerts = pdc_mon_filter_items_hn($hard_alerts, $hn_raw);
    $soft_alerts = pdc_mon_filter_items_hn($soft_alerts, $hn_raw);
    $passed_items = pdc_mon_filter_items_hn($passed_items, $hn_raw);
    $unverifiable_items = pdc_mon_filter_items_hn($unverifiable_items, $hn_raw);
}
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';

ob_clean();
echo json_encode([
    'status' => 'success',
    'hard_alerts' => sp_alert_mute_filter_rows($con, $hard_alerts),
    'soft_alerts' => sp_alert_mute_filter_rows($con, $soft_alerts),
    'passed_items' => $passed_items,
    'unverifiable_items' => $unverifiable_items,
    'meta' => [
        'rule_count' => count($rules),
        'matched_icodes' => count($icode_list),
        'orders_scanned' => $orders_scanned,
        'orders_checked' => $orders_checked,
        'orders_excluded' => $orders_excluded,
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
        'kids_only' => $kids_only ? 1 : 0,
        'tolerance_pct' => $tol_pct,
        'hn' => $hn_raw,
    ],
], JSON_UNESCAPED_UNICODE);
