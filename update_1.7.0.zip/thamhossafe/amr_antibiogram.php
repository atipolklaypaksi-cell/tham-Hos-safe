<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/amr_mlab_helper.php';
require_once __DIR__ . '/amr_amass_helper.php';
mysqli_set_charset($con, 'utf8');
$source_mlab = amr_mlab_using_direct($con);
$source_label = $source_mlab ? 'mLAB (ตาราง THAM Hos-Safe)' : 'HOSxP lab_head';
$cover = function_exists('amr_amass_cover_info') ? amr_amass_cover_info($con) : [];
$hospital_th = trim((string)($cover['hospital_name_th'] ?? ''));
if ($hospital_th === '') {
    $hospital_th = trim((string)($cover['hospital_name'] ?? ''));
}
$default_end = date('Y-m-d');
$default_start = date('Y-01-01');
$year_now = (int)date('Y');
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Antibiogram — CLSI M39</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        :root {
            --amr-ink: #12261c;
            --amr-muted: #5f7468;
            --amr-line: #d7e4dc;
            --amr-card: #ffffff;
            --amr-soft: #eef6f1;
            --amr-page: #e8f1ec;
            --amr-teal: #0f766e;
            --amr-ok: #059669;
            --amr-amber: #d97706;
            --amr-rose: #e11d48;
        }
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: var(--amr-page); color: var(--amr-ink); }
        #content.amr-content { background: var(--amr-page); }
        .abg-hero {
            display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; flex-wrap: wrap;
            margin-bottom: 18px;
        }
        .abg-kicker { font-size: .78rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: var(--amr-teal); }
        .abg-title { font-size: 1.7rem; font-weight: 800; margin: 0; }
        .abg-sub { color: var(--amr-muted); margin: 4px 0 0; max-width: 52rem; }
        .abg-chip {
            display: inline-flex; align-items: center; gap: 6px;
            background: #fff; border: 1px solid var(--amr-line); border-radius: 999px;
            padding: 6px 12px; font-size: .82rem; font-weight: 700; color: var(--amr-teal);
        }
        .abg-card {
            background: var(--amr-card); border: 1px solid var(--amr-line); border-radius: 16px;
            padding: 16px 18px; margin-bottom: 16px; box-shadow: 0 8px 24px rgba(15, 36, 25, .04);
        }
        .abg-label { font-size: .72rem; font-weight: 700; color: var(--amr-muted); text-transform: uppercase; letter-spacing: .04em; margin-bottom: 4px; }
        .abg-card .form-control, .abg-card .form-select {
            border-radius: 10px; border-color: var(--amr-line); background: var(--amr-soft);
        }
        .abg-range-btn {
            border-radius: 999px !important; font-weight: 700; font-size: .8rem;
        }
        .abg-range-btn.active { background: var(--amr-teal); border-color: var(--amr-teal); color: #fff; }
        .abg-kpi { text-align: center; }
        .abg-kpi .n { font-size: 1.55rem; font-weight: 800; line-height: 1.1; color: var(--amr-teal); }
        .abg-kpi .l { font-size: .78rem; color: var(--amr-muted); font-weight: 600; }
        .abg-pheno {
            border: 1px solid var(--amr-line); border-radius: 14px; padding: 12px 14px; height: 100%;
            background: #f7fbf9;
        }
        .abg-pheno .nm { font-weight: 800; font-size: .95rem; }
        .abg-pheno .pct { font-size: 1.4rem; font-weight: 800; color: var(--amr-rose); }
        .abg-pheno .pct.ok { color: var(--amr-ok); }
        .abg-pheno .pct.mid { color: var(--amr-amber); }
        .abg-pheno .hint { font-size: .75rem; color: var(--amr-muted); }
        .abg-wrap { overflow: auto; max-height: 72vh; border-radius: 12px; border: 1px solid var(--amr-line); }
        table.abg-table { margin: 0; font-size: .82rem; border-collapse: separate; border-spacing: 0; }
        table.abg-table th, table.abg-table td { white-space: nowrap; vertical-align: middle; }
        table.abg-table thead th {
            position: sticky; top: 0; z-index: 2; background: #0f766e; color: #fff;
            font-weight: 700; text-align: center; padding: 8px 6px; font-size: .72rem;
            border-color: #0d9488;
        }
        table.abg-table thead tr:nth-child(2) th.drug { top: 28px; z-index: 2; }
        table.abg-table thead th.sticky-org, table.abg-table thead th.tot { z-index: 4; }
        table.abg-table thead th.sticky-org { left: 0; text-align: left; min-width: 210px; }
        table.abg-table tbody td.sticky-org {
            position: sticky; left: 0; z-index: 1; background: #fff; text-align: left;
            font-weight: 700; padding: 7px 10px; border-right: 1px solid var(--amr-line);
        }
        table.abg-table tbody tr:nth-child(even) td.sticky-org { background: #f4faf7; }
        table.abg-table tbody td.cell { text-align: center; padding: 4px 5px; min-width: 54px; }
        table.abg-table .org-it { font-style: italic; }
        table.abg-table .org-n { display: block; font-style: normal; font-weight: 600; font-size: .72rem; color: var(--amr-muted); }
        .abg-empty { text-align: center; padding: 48px 16px; color: var(--amr-muted); }
        .abg-note { font-size: .8rem; color: var(--amr-muted); }
        .abg-std li { margin-bottom: 4px; }
        .cell-s { font-weight: 800; }
        .cell-n { display: block; font-size: .65rem; font-weight: 600; color: #94a3b8; }
        .cell-ns { color: #94a3b8; font-weight: 700; }
        .heat-ok, .heat-ok .cell-s { color: #16a34a; }
        .heat-mid, .heat-mid .cell-s { color: #ca8a04; }
        .heat-bad, .heat-bad .cell-s { color: #dc2626; }
        .heat-na { color: #64748b; }
        .heat-empty { color: #cbd5d1; }
        .heat-R { color: #334155; font-weight: 800; }
        table.abg-table thead th.grp {
            background: #115e59; font-size: .68rem; letter-spacing: .04em;
        }
        table.abg-table thead th.drug {
            writing-mode: vertical-rl; transform: rotate(180deg);
            height: 132px; min-width: 34px; max-width: 42px; white-space: nowrap;
            font-size: .68rem; font-weight: 600; padding: 6px 4px;
        }
        table.abg-table thead th.tot { min-width: 64px; }
        table.abg-table tbody td.tot { font-weight: 800; text-align: center; background: #f8fafc; }
        .abg-sheet-title { font-size: .92rem; font-weight: 700; text-align: center; margin: 0 0 8px; }
        .abg-tabs .btn { border-radius: 999px; font-weight: 700; font-size: .8rem; }
        .abg-footnote { font-size: .75rem; color: var(--amr-muted); }
        .abg-legend span { display: inline-block; padding: 2px 8px; border-radius: 6px; font-size: .72rem; font-weight: 700; margin-right: 4px; }
        .abg-analysis { background: #f7fbf9; border: 1px solid var(--amr-line); border-radius: 14px; padding: 14px 16px; }
        .abg-analysis h2 { font-size: 1.05rem; font-weight: 800; margin: 0 0 8px; }
        .abg-analysis li { margin-bottom: 6px; }
        .abg-analysis .caution { font-size: .8rem; color: var(--amr-muted); }
        .delta-better { color: #16a34a; font-weight: 800; }
        .delta-worse { color: #dc2626; font-weight: 800; }
        .delta-flat { color: #64748b; font-weight: 700; }
        .delta-na { color: #94a3b8; }
        table.abg-trend { font-size: .8rem; }
        table.abg-trend th { background: #0f766e; color: #fff; font-weight: 700; white-space: nowrap; }
        table.abg-trend td { vertical-align: middle; }
        .abg-year-btn.active { background: var(--amr-teal); border-color: var(--amr-teal); color: #fff; }
        #abgPhenoChartWrap { height: 260px; position: relative; }
        .abg-status.err { color: var(--amr-rose); }
        @media print {
            #sidebar, .no-print, .abg-filter { display: none !important; }
            .wrapper, #content { display: block !important; margin: 0 !important; padding: 0 !important; width: 100% !important; max-width: none !important; }
            body { background: #fff; }
            .abg-wrap { max-height: none; overflow: visible; border: 0; }
            .abg-sheet, .abg-sheet.d-none { page-break-after: always; break-after: page; display: block !important; }
            .abg-sheet:last-child { page-break-after: auto; }
            #printHead { display: none !important; }
            #abgAnalysisCard { page-break-after: always; break-after: page; }
            table.abg-table thead th { background: #0f766e !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .heat-ok, .heat-ok .cell-s { color: #16a34a !important; }
            .heat-mid, .heat-mid .cell-s { color: #ca8a04 !important; }
            .heat-bad, .heat-bad .cell-s { color: #dc2626 !important; }
            .heat-ok, .heat-mid, .heat-bad, .heat-R { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            @page { size: A4 landscape; margin: 10mm; }
        }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content amr-content">
        <div class="container-fluid py-4">
            <div class="abg-hero">
                <div>
                    <div class="abg-kicker"><i class="fas fa-bacteria"></i> AMR · Cumulative AST</div>
                    <h1 class="abg-title">Antibiogram</h1>
                    <p class="abg-sub">
                        ตาราง %S ตามรูปแบบ Antibiogram ที่โรงพยาบาลใช้ (WHONET)
                        · first isolate ตาม <b>CLSI M39</b> · แปลผล <b>CLSI M100</b>
                        · แยก All Specimen / Blood / Urine / Respiratory Tract / Stool
                        · เปรียบเทียบย้อนหลัง 3 ปีปฏิทิน พร้อมแนวโน้มและบทวิเคราะห์
                    </p>
                </div>
                <div class="d-flex align-items-center gap-2 flex-wrap no-print">
                    <span class="abg-chip"><i class="fas fa-database"></i> <?php echo htmlspecialchars($source_label, ENT_QUOTES, 'UTF-8'); ?></span>
                    <button type="button" class="btn btn-sm btn-outline-secondary fw-bold" style="border-radius:999px;" onclick="window.print()">
                        <i class="fas fa-print me-1"></i>พิมพ์
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-secondary fw-bold" style="border-radius:999px;" id="btnCsv" disabled onclick="exportCsv()">
                        <i class="fas fa-file-csv me-1"></i>CSV
                    </button>
                </div>
            </div>

            <div class="abg-card abg-filter no-print">
                <div class="row g-2 align-items-end">
                    <div class="col-6 col-md-2">
                        <div class="abg-label">วันที่เริ่ม</div>
                        <input type="text" class="form-control form-control-sm" id="filterStart" value="<?php echo htmlspecialchars($default_start, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="abg-label">วันที่สิ้นสุด</div>
                        <input type="text" class="form-control form-control-sm" id="filterEnd" value="<?php echo htmlspecialchars($default_end, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-12 col-md-auto">
                        <div class="abg-label">ช่วงด่วน</div>
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-secondary abg-range-btn active" data-range="ytd" onclick="setAbgRange('ytd')">ปีนี้</button>
                            <button type="button" class="btn btn-outline-secondary abg-range-btn" data-range="lastyear" onclick="setAbgRange('lastyear')">ปี <?php echo $year_now - 1; ?></button>
                            <button type="button" class="btn btn-outline-secondary abg-range-btn" data-range="3y" onclick="setAbgRange('3y')">3 ปี</button>
                        </div>
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="abg-label">แหล่งรักษา</div>
                        <select class="form-select form-select-sm" id="filterOrigin" <?php echo $source_mlab ? '' : 'disabled'; ?>>
                            <option value="all">ทั้งหมด</option>
                            <option value="ipd">IPD</option>
                            <option value="opd">OPD</option>
                        </select>
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="abg-label">Isolate (M39)</div>
                        <select class="form-select form-select-sm" id="filterRule">
                            <option value="first">First isolate / ผู้ป่วย / เชื้อ</option>
                            <option value="all">ทุกรายการ (ไม่ใช่ M39)</option>
                        </select>
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="abg-label">แสดงค่า</div>
                        <select class="form-select form-select-sm" id="filterMetric">
                            <option value="S">%S (แนะนำ — M39)</option>
                            <option value="R">%R</option>
                            <option value="NS">%NS (I+R)</option>
                        </select>
                    </div>
                    <div class="col-6 col-md-1">
                        <div class="abg-label">ขั้นต่ำ n</div>
                        <input type="number" class="form-control form-control-sm" id="filterMinN" value="30" min="1" max="100">
                    </div>
                    <div class="col-12 col-md-auto">
                        <div class="form-check mt-4">
                            <input class="form-check-input" type="checkbox" id="filterCompare">
                            <label class="form-check-label small fw-bold" for="filterCompare">เปรียบเทียบรายปี (3 ปีปฏิทิน)</label>
                        </div>
                    </div>
                    <div class="col-12 col-md-auto">
                        <div class="form-check mt-4">
                            <input class="form-check-input" type="checkbox" id="filterOther">
                            <label class="form-check-label small fw-bold" for="filterOther">รวมเชื้อนอกชุด NARST/GLASS</label>
                        </div>
                    </div>
                    <div class="col-12 col-md-auto">
                        <button type="button" class="btn btn-success fw-bold" id="btnRun" onclick="runAntibiogram()">
                            <i class="fas fa-play me-1"></i> สร้างรายงาน
                        </button>
                    </div>
                </div>
                <div class="abg-status mt-3" id="abgStatus">เลือกช่วงวันที่แล้วกด <b>สร้างรายงาน</b> — ไม่ดึงข้อมูลอัตโนมัติเมื่อเปิดหน้า</div>
                <?php if (!$source_mlab): ?>
                <div class="small text-muted mt-1">แหล่ง HOSxP ไม่แยก IPD/OPD จาก AST โดยตรง — ตัวกรองแหล่งรักษาใช้ได้เมื่อเลือกแหล่ง mLAB</div>
                <?php endif; ?>
            </div>

            <div id="abgResult" class="d-none">
                <div class="abg-card" id="printHead">
                    <div class="d-flex justify-content-between flex-wrap gap-2">
                        <div>
                            <div class="fw-bold"><?php echo htmlspecialchars($hospital_th !== '' ? $hospital_th : 'โรงพยาบาล', ENT_QUOTES, 'UTF-8'); ?></div>
                            <div class="small text-muted" id="printPeriod"></div>
                        </div>
                        <div class="small text-muted text-md-end" id="printRule"></div>
                    </div>
                    <div class="row g-2 mt-3" id="abgKpis"></div>
                </div>

                <div id="abgCompare" class="d-none">
                    <div class="abg-card" id="abgAnalysisCard">
                        <div class="abg-analysis">
                            <h2 id="abgAnalysisTitle">บทวิเคราะห์</h2>
                            <ul class="mb-2 ps-3" id="abgAnalysisBullets"></ul>
                            <div class="caution" id="abgAnalysisCaution"></div>
                        </div>
                    </div>
                    <div class="abg-card">
                        <h2 class="h6 fw-bold mb-2">แนวโน้มฟีโนไทป์เฝ้าระวัง</h2>
                        <div id="abgPhenoChartWrap"><canvas id="abgPhenoChart"></canvas></div>
                        <div class="table-responsive mt-3">
                            <table class="table table-sm abg-trend" id="abgPhenoTrend"></table>
                        </div>
                    </div>
                    <div class="abg-card">
                        <h2 class="h6 fw-bold mb-2">แนวโน้ม %S คู่เชื้อ–ยาสำคัญ (All Specimen)</h2>
                        <div class="table-responsive">
                            <table class="table table-sm abg-trend" id="abgPairTrend"></table>
                        </div>
                        <p class="abg-footnote mb-0">Δ = ปีล่าสุด − ปีแรก · แดง = แย่ลง (≥ 5 จุด) · เขียว = ดีขึ้น · ค่าว่างหรือ r = n &lt; 30 ไม่นำมาคำนวณแนวโน้ม</p>
                    </div>
                    <div class="abg-card no-print">
                        <div class="abg-label mb-1">ตาราง Antibiogram ตามปี</div>
                        <div class="btn-group" id="abgYearTabs"></div>
                    </div>
                </div>

                <div class="abg-card">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2 no-print">
                        <div class="abg-tabs btn-group" id="abgTabs"></div>
                        <div class="abg-legend">
                            <span class="heat-ok">เขียว = ไว (≥ 80%)</span>
                            <span class="heat-mid">เหลือง = เริ่มดื้อ (50–79%)</span>
                            <span class="heat-bad">แดง = ดื้อ (&lt; 50%)</span>
                            <span class="heat-R">R intrinsic</span>
                            <span class="heat-na">r = n&lt;30</span>
                        </div>
                    </div>
                    <div id="abgSheets"></div>
                    <p class="abg-footnote mt-2 mb-0">
                        <span class="heat-ok">เขียว = ไว (%S ≥ 80)</span>
                        &nbsp;·&nbsp; <span class="heat-mid">เหลือง = เริ่มดื้อ (50–79)</span>
                        &nbsp;·&nbsp; <span class="heat-bad">แดง = ดื้อ (&lt; 50)</span>
                        &nbsp;·&nbsp; R = Intrinsic resistance &nbsp;·&nbsp; r = ไม่รายงาน % ตาม CLSI M39 (n &lt; 30) หรือไม่ได้ทดสอบ
                        &nbsp;·&nbsp; ตัวเลขในวงเล็บ = จำนวน isolate ที่ทดสอบยา
                    </p>
                </div>

                <div class="abg-card no-print">
                    <h2 class="h6 fw-bold mb-2">ตัวชี้วัดฟีโนไทป์ (NARST / GLASS)</h2>
                    <div class="row g-2" id="abgPheno"></div>
                </div>

                <div class="abg-card">
                    <h2 class="h6 fw-bold mb-2">หลักเกณฑ์ที่ใช้</h2>
                    <ul class="abg-std small mb-2 ps-3" id="abgStd"></ul>
                    <p class="abg-note mb-0">
                        First isolate = ผล AST แรกของแต่ละผู้ป่วย (HN) ต่อเชื้อ ในช่วงวิเคราะห์ ตาม CLSI M39
                        · %S = S ÷ (S+I+R) × 100 โดยไม่นับ SDD เป็น S (นับเป็น I)
                        · เกณฑ์ S/I/R เป็นค่าที่ห้องปฏิบัติการแปลตาม CLSI M100 ในช่วงที่รายงาน
                        · ชุดเชื้อเริ่มต้นอิง NARST และ priority pathogens ของ WHO/GLASS (เลือดเป็นตัวแทน GLASS)
                    </p>
                </div>
            </div>

            <div class="abg-card" id="abgIdle">
                <div class="abg-empty">
                    <i class="fas fa-table fa-2x mb-3" style="color:#99c2b5;"></i>
                    <div class="fw-bold">ยังไม่มีรายงาน</div>
                    <div class="small">กดปุ่มสร้างรายงานเมื่อเลือกช่วงเวลาแล้ว — ค่าเริ่มต้นคือปีปฏิทินปัจจุบัน ตามแนว M39</div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/flatpickr.min.js"></script>
<script src="vendor/chart.js/Chart.bundle.js"></script>
<script>
const YEAR_NOW = <?php echo $year_now; ?>;
let lastPayload = null;
let fpStart = null;
let fpEnd = null;
let phenoChart = null;
let activeYear = '';

if (typeof flatpickr !== 'undefined') {
    fpStart = flatpickr('#filterStart', { dateFormat: 'Y-m-d' });
    fpEnd = flatpickr('#filterEnd', { dateFormat: 'Y-m-d' });
}

function setAbgRange(kind) {
    document.querySelectorAll('.abg-range-btn').forEach(b => b.classList.toggle('active', b.getAttribute('data-range') === kind));
    const today = new Date();
    const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    let s, e;
    if (kind === 'lastyear') {
        s = YEAR_NOW - 1 + '-01-01';
        e = YEAR_NOW - 1 + '-12-31';
        document.getElementById('filterCompare').checked = false;
    } else if (kind === '12m') {
        e = iso(today);
        const d = new Date(today);
        d.setDate(d.getDate() - 365);
        s = iso(d);
        document.getElementById('filterCompare').checked = false;
    } else if (kind === '3y') {
        e = iso(today);
        s = (YEAR_NOW - 2) + '-01-01';
        document.getElementById('filterCompare').checked = true;
    } else {
        s = YEAR_NOW + '-01-01';
        e = iso(today);
        document.getElementById('filterCompare').checked = false;
    }
    if (fpStart) fpStart.setDate(s, true);
    else document.getElementById('filterStart').value = s;
    if (fpEnd) fpEnd.setDate(e, true);
    else document.getElementById('filterEnd').value = e;
}

function setStatus(msg, isErr) {
    const el = document.getElementById('abgStatus');
    el.classList.toggle('err', !!isErr);
    el.innerHTML = msg;
}

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

let activeSheet = 'all';

function heatClass(cell) {
    if (!cell) return 'heat-empty';
    if (cell.intrinsic) return 'heat-R';
    if (cell.mark === 'r' || cell.suppressed || cell.pct == null) {
        return cell.n ? 'heat-na' : 'heat-empty';
    }
    const metric = document.getElementById('filterMetric').value;
    let v = Number(cell.pct);
    if (metric === 'R' || metric === 'NS') v = 100 - v;
    if (v >= 80) return 'heat-ok';
    if (v >= 50) return 'heat-mid';
    return 'heat-bad';
}

function fmtPct(v) {
    if (v == null) return '';
    return Number(v).toFixed(2);
}

function drugGroups(drugs) {
    const groups = [];
    drugs.forEach(function (d) {
        const g = d.group || '';
        if (!groups.length || groups[groups.length - 1].name !== g) {
            groups.push({ name: g, cols: 1 });
        } else {
            groups[groups.length - 1].cols++;
        }
    });
    return groups;
}

function renderSheetTable(sheet, drugs) {
    const rows = sheet.rows || [];
    const groups = drugGroups(drugs);
    const grp = groups.map(function (g) {
        return '<th class="grp" colspan="' + g.cols + '">' + esc(g.name) + '</th>';
    }).join('');
    const head2 = drugs.map(function (d) {
        return '<th class="drug" title="' + esc(d.label) + '">' + esc(d.short) + '</th>';
    }).join('');
    const body = rows.length ? rows.map(function (row) {
        const name = '<span class="' + (row.italic ? 'org-it' : '') + '">' + esc(row.label || row.short) + '</span>';
        const tds = drugs.map(function (d) {
            const c = (row.cells && row.cells[d.code]) ? row.cells[d.code] : null;
            if (c && (c.intrinsic || c.mark === 'R')) {
                return '<td class="cell heat-R" title="Intrinsic resistance">R</td>';
            }
            const title = d.label + ' · S ' + (c && c.s || 0) + ' / I ' + (c && c.i || 0) + ' / R ' + (c && c.r || 0) + ' (n=' + (c && c.n || 0) + ')';
            if (!c || !c.n || c.suppressed || c.pct == null || c.mark === 'r') {
                const nHtml = (c && c.n) ? '<span class="cell-n">(' + c.n + ')</span>' : '';
                return '<td class="cell heat-na" title="' + esc(title) + '">r' + nHtml + '</td>';
            }
            return '<td class="cell ' + heatClass(c) + '" title="' + esc(title) + '"><span class="cell-s">' + esc(fmtPct(c.pct)) + '</span><span class="cell-n">(' + c.n + ')</span></td>';
        }).join('');
        return '<tr><td class="sticky-org">' + name + '</td><td class="tot">' + (row.n || 0) + '</td>' + tds + '</tr>';
    }).join('') : '<tr><td class="text-center text-muted py-4" colspan="' + (drugs.length + 2) + '">ไม่พบ isolate ตามเงื่อนไข</td></tr>';
    return '<div class="abg-sheet-title">' + esc(sheet.heading || sheet.title) + '</div>'
        + '<div class="abg-wrap"><table class="table table-sm abg-table"><thead>'
        + '<tr><th class="sticky-org" rowspan="2">Organism Name</th><th class="tot" rowspan="2">TOTAL no. ISOLATES</th>' + grp + '</tr>'
        + '<tr>' + head2 + '</tr></thead><tbody>' + body + '</tbody></table></div>';
}

function showSheet(key) {
    activeSheet = key;
    document.querySelectorAll('.abg-sheet').forEach(function (el) {
        const on = el.getAttribute('data-sheet') === key;
        el.classList.toggle('d-none', !on);
    });
    document.querySelectorAll('#abgTabs [data-sheet]').forEach(function (b) {
        b.classList.toggle('btn-success', b.getAttribute('data-sheet') === key);
        b.classList.toggle('btn-outline-secondary', b.getAttribute('data-sheet') !== key);
    });
}

async function runAntibiogram() {
    const btn = document.getElementById('btnRun');
    btn.disabled = true;
    setStatus('<i class="fas fa-spinner fa-spin me-1"></i> ' + (
        document.getElementById('filterCompare').checked
            ? 'กำลังประมวลผล Antibiogram และเปรียบเทียบ 3 ปีปฏิทิน...'
            : 'กำลังประมวลผลตามรูปแบบ Antibiogram โรงพยาบาล...'
    ));
    lastPayload = null;
    document.getElementById('btnCsv').disabled = true;
    try {
        const compareOn = document.getElementById('filterCompare').checked;
        if (compareOn) {
            const endV = document.getElementById('filterEnd').value;
            const y = parseInt(String(endV).slice(0, 4), 10) || YEAR_NOW;
            const s = (y - 2) + '-01-01';
            if (fpStart) fpStart.setDate(s, true);
            else document.getElementById('filterStart').value = s;
        }
        const body = {
            start_date: document.getElementById('filterStart').value,
            end_date: document.getElementById('filterEnd').value,
            origin: document.getElementById('filterOrigin').value,
            isolate_rule: document.getElementById('filterRule').value,
            metric: document.getElementById('filterMetric').value,
            min_n: Number(document.getElementById('filterMinN').value || 30),
            include_other: document.getElementById('filterOther').checked ? 1 : 0,
            compare_years: compareOn ? 3 : 0
        };
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), compareOn ? 230000 : 170000);
        const r = await fetch('fetch_amr_antibiogram_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            signal: ctrl.signal
        });
        clearTimeout(t);
        const data = await r.json();
        if (!r.ok || data.status !== 'success') {
            throw new Error(data.message || ('HTTP ' + r.status));
        }
        lastPayload = data;
        renderAbg(data);
        document.getElementById('btnCsv').disabled = false;
        const m = data.meta || {};
        setStatus('เสร็จแล้ว · ' + esc(m.source_label || '') + ' · first isolate ' + (m.used_isolates || 0) + ' ราย · เชื้อ ' + (m.organisms || 0) + ' ชนิด'
            + (m.compare_years ? ' · เปรียบเทียบ ' + m.compare_years + ' ปี' : ''));
    } catch (e) {
        const msg = (e && e.name === 'AbortError')
            ? 'ใช้เวลานานเกินกำหนด — ลองย่อช่วงวันที่ หรือใช้แหล่ง mLAB'
            : (e.message || String(e));
        setStatus(msg, true);
        document.getElementById('abgResult').classList.add('d-none');
        document.getElementById('abgIdle').classList.remove('d-none');
    }
    btn.disabled = false;
}

function renderAbg(data) {
    const m = data.meta || {};
    document.getElementById('abgIdle').classList.add('d-none');
    document.getElementById('abgResult').classList.remove('d-none');
    document.getElementById('printPeriod').textContent =
        (data.compare
            ? ('เปรียบเทียบ ' + (data.compare.years || []).join('/') + ' · ตารางด้านล่าง = ปีล่าสุด')
            : ('Percentage of susceptible organisms · ' + (m.period_en || (m.start + ' – ' + m.end))))
        + ' · ' + (m.source_label || '');
    document.getElementById('printRule').textContent =
        (m.isolate_rule === 'first' ? 'CLSI M39 first isolate' : 'ทุกรายการ') +
        ' · %S · R = intrinsic resistance · r = n < ' + (m.min_n || 30);

    const sc = m.spec_counts || {};
    const kpis = [
        ['First isolate', m.used_isolates],
        ['Blood', sc.blood || 0],
        ['Urine', sc.urine || 0],
        ['Respiratory', sc.respiratory || 0],
        ['Stool', sc.stool || 0],
        ['เชื้อในตาราง', m.organisms]
    ];
    document.getElementById('abgKpis').innerHTML = kpis.map(function (x) {
        return '<div class="col-6 col-md"><div class="abg-kpi"><div class="n">' + esc(x[1] == null ? '–' : x[1]) + '</div><div class="l">' + esc(x[0]) + '</div></div></div>';
    }).join('');

    const ph = data.phenotypes || [];
    document.getElementById('abgPheno').innerHTML = ph.map(function (p) {
        let pctHtml = (p.suppressed || p.pct == null) ? '—' : (fmtPct(p.pct) + '%');
        let cls = 'pct';
        if (p.pct != null && p.pct < 20) cls += ' ok';
        else if (p.pct != null && p.pct < 40) cls += ' mid';
        return '<div class="col-6 col-md-4 col-xl-2"><div class="abg-pheno" title="' + esc(p.detail) + '">'
            + '<div class="nm">' + esc(p.label) + '</div>'
            + '<div class="' + cls + '">' + pctHtml + '</div>'
            + '<div class="hint">' + (p.n || 0) + ' / ' + (p.d || 0) + (p.suppressed ? ' · n&lt;30' : '') + '</div>'
            + '</div></div>';
    }).join('');

    const drugs = data.drugs || [];
    const order = ['all', 'blood', 'urine', 'respiratory', 'stool'];
    const sheets = data.sheets || {};
    const tabs = document.getElementById('abgTabs');
    const box = document.getElementById('abgSheets');
    tabs.innerHTML = order.filter(function (k) { return sheets[k]; }).map(function (k) {
        const sh = sheets[k];
        return '<button type="button" class="btn btn-sm btn-outline-secondary" data-sheet="' + k + '" onclick="showSheet(\'' + k + '\')">'
            + esc(sh.title_th || sh.title) + ' <small>(' + (sh.used_isolates || 0) + ')</small></button>';
    }).join('');
    box.innerHTML = order.filter(function (k) { return sheets[k]; }).map(function (k) {
        return '<div class="abg-sheet d-none" data-sheet="' + k + '">' + renderSheetTable(sheets[k], drugs) + '</div>';
    }).join('');
    showSheet(sheets[activeSheet] ? activeSheet : 'all');

    const std = (m.standards || []);
    document.getElementById('abgStd').innerHTML = std.map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('');
    renderCompare(data);
}

function deltaClass(dir) {
    if (dir === 'worse') return 'delta-worse';
    if (dir === 'better') return 'delta-better';
    if (dir === 'flat') return 'delta-flat';
    return 'delta-na';
}

function deltaText(dir, delta) {
    if (delta == null || dir === 'na') return '—';
    const sign = delta > 0 ? '+' : '';
    const arrow = dir === 'worse' ? ' ↓' : (dir === 'better' ? ' ↑' : ' →');
    return sign + Number(delta).toFixed(1) + arrow;
}

function fmtYearPct(cell) {
    if (cell && cell.mark === 'R') return '<span class="heat-R">R</span>';
    if (!cell || cell.pct == null) return '<span class="heat-na">r</span>';
    const fake = { pct: cell.pct, n: cell.n || 1, mark: '', intrinsic: false };
    return '<span class="' + heatClass(fake) + '">' + Number(cell.pct).toFixed(1) + '</span>';
}

function renderCompare(data) {
    const box = document.getElementById('abgCompare');
    const c = data.compare;
    if (!c || !c.years || c.years.length < 2) {
        box.classList.add('d-none');
        if (phenoChart) { phenoChart.destroy(); phenoChart = null; }
        return;
    }
    box.classList.remove('d-none');
    const years = c.years;
    const an = c.analysis || {};
    document.getElementById('abgAnalysisTitle').textContent = an.headline || 'บทวิเคราะห์';
    document.getElementById('abgAnalysisBullets').innerHTML = (an.bullets || []).map(function (b) {
        return '<li>' + esc(b) + '</li>';
    }).join('');
    document.getElementById('abgAnalysisCaution').innerHTML = (an.cautions || []).map(function (x) {
        return '· ' + esc(x);
    }).join('<br>');

    const phHead = '<thead><tr><th>ฟีโนไทป์</th>' + years.map(function (y) { return '<th>' + y + '</th>'; }).join('') + '<th>Δ</th></tr></thead>';
    const phBody = (c.phenotypes || []).map(function (p) {
        const tds = years.map(function (y) {
            const cell = (p.by_year && p.by_year[y]) ? p.by_year[y] : null;
            if (!cell || cell.pct == null) {
                return '<td class="heat-na">r</td>';
            }
            return '<td>' + Number(cell.pct).toFixed(1) + '%<div class="cell-n">(' + cell.n + '/' + cell.d + ')</div></td>';
        }).join('');
        return '<tr><td class="fw-bold">' + esc(p.label) + '</td>' + tds
            + '<td class="' + deltaClass(p.dir) + '">' + esc(deltaText(p.dir, p.delta)) + '</td></tr>';
    }).join('');
    document.getElementById('abgPhenoTrend').innerHTML = phHead + '<tbody>' + phBody + '</tbody>';

    const palettes = ['#0f766e', '#dc2626', '#d97706', '#2563eb', '#7c3aed', '#db2777'];
    const ds = (c.phenotypes || []).map(function (p, i) {
        return {
            label: p.label,
            data: years.map(function (y) {
                const cell = (p.by_year && p.by_year[y]) ? p.by_year[y] : null;
                return (cell && cell.pct != null) ? cell.pct : null;
            }),
            borderColor: palettes[i % palettes.length],
            backgroundColor: palettes[i % palettes.length],
            fill: false,
            spanGaps: true,
            lineTension: 0.15,
            pointRadius: 4
        };
    });
    if (phenoChart) phenoChart.destroy();
    const ctx = document.getElementById('abgPhenoChart').getContext('2d');
    phenoChart = new Chart(ctx, {
        type: 'line',
        data: { labels: years.map(String), datasets: ds },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: { position: 'bottom' },
            scales: {
                yAxes: [{ ticks: { beginAtZero: true, max: 100 }, scaleLabel: { display: true, labelString: '%' } }]
            },
            tooltips: { mode: 'index', intersect: false }
        }
    });

    const pairHead = '<thead><tr><th>เชื้อ</th><th>ยา</th>' + years.map(function (y) { return '<th>' + y + '</th>'; }).join('') + '<th>Δ</th></tr></thead>';
    let lastOrg = '';
    const pairBody = (c.pairs || []).map(function (p) {
        const orgCell = (p.org_label === lastOrg) ? '' : esc(p.org_label);
        lastOrg = p.org_label;
        const tds = years.map(function (y) {
            const cell = (p.by_year && p.by_year[y]) ? p.by_year[y] : null;
            return '<td>' + fmtYearPct(cell) + '</td>';
        }).join('');
        return '<tr><td>' + orgCell + '</td><td>' + esc(p.drug_label) + '</td>' + tds
            + '<td class="' + deltaClass(p.dir) + '">' + esc(deltaText(p.dir, p.delta)) + '</td></tr>';
    }).join('');
    document.getElementById('abgPairTrend').innerHTML = pairHead + '<tbody>' + pairBody + '</tbody>';

    const ym = c.year_meta || [];
    activeYear = String(years[years.length - 1]);
    document.getElementById('abgYearTabs').innerHTML = ym.map(function (y) {
        return '<button type="button" class="btn btn-sm btn-outline-secondary abg-year-btn" data-year="' + y.year + '" onclick="showAbgYear(\'' + y.year + '\')">'
            + y.year + (y.partial ? ' (YTD)' : '') + ' · ' + (y.used_isolates || 0) + '</button>';
    }).join('');
    highlightYearTab(activeYear);
}

function highlightYearTab(year) {
    document.querySelectorAll('#abgYearTabs [data-year]').forEach(function (b) {
        b.classList.toggle('active', String(b.getAttribute('data-year')) === String(year));
    });
}

function showAbgYear(year) {
    if (!lastPayload || !lastPayload.year_sheets || !lastPayload.year_sheets[year]) return;
    activeYear = String(year);
    lastPayload.sheets = lastPayload.year_sheets[year];
    const drugs = lastPayload.drugs || [];
    const order = ['all', 'blood', 'urine', 'respiratory', 'stool'];
    const sheets = lastPayload.sheets || {};
    const tabs = document.getElementById('abgTabs');
    const box = document.getElementById('abgSheets');
    tabs.innerHTML = order.filter(function (k) { return sheets[k]; }).map(function (k) {
        const sh = sheets[k];
        return '<button type="button" class="btn btn-sm btn-outline-secondary" data-sheet="' + k + '" onclick="showSheet(\'' + k + '\')">'
            + esc(sh.title_th || sh.title) + ' <small>(' + (sh.used_isolates || 0) + ')</small></button>';
    }).join('');
    box.innerHTML = order.filter(function (k) { return sheets[k]; }).map(function (k) {
        return '<div class="abg-sheet d-none" data-sheet="' + k + '">' + renderSheetTable(sheets[k], drugs) + '</div>';
    }).join('');
    showSheet(sheets[activeSheet] ? activeSheet : 'all');
    highlightYearTab(year);
    const ym = ((lastPayload.compare && lastPayload.compare.year_meta) || []).find(function (x) { return String(x.year) === String(year); });
    if (ym) {
        document.getElementById('printPeriod').textContent =
            'ปี ' + year + (ym.partial ? ' (ยังไม่ครบปี)' : '') + ' · ' + (ym.period_en || '') + ' · first isolate ' + (ym.used_isolates || 0);
    }
}

function exportCsv() {
    if (!lastPayload) return;
    const drugs = lastPayload.drugs || [];
    const sheets = lastPayload.sheets || {};
    const m = lastPayload.meta || {};
    const lines = [];
    Object.keys(sheets).forEach(function (k) {
        const sheet = sheets[k];
        lines.push(sheet.heading || sheet.title);
        const head = ['Organism', 'TOTAL'].concat(drugs.map(function (d) { return d.short; }));
        lines.push(head.join(','));
        (sheet.rows || []).forEach(function (row) {
            const rec = ['"' + String(row.label || '').replace(/"/g, '""') + '"', row.n || 0];
            drugs.forEach(function (d) {
                const c = (row.cells && row.cells[d.code]) ? row.cells[d.code] : null;
                if (!c) { rec.push(''); return; }
                if (c.intrinsic) { rec.push('R'); return; }
                if (c.pct == null) { rec.push(c.n ? 'r' : ''); return; }
                rec.push(c.pct);
            });
            lines.push(rec.join(','));
        });
        lines.push('');
    });
    const cmp = lastPayload.compare;
    if (cmp && cmp.pairs) {
        lines.push('');
        lines.push((cmp.analysis && cmp.analysis.headline) || 'COMPARE');
        (cmp.analysis && cmp.analysis.bullets || []).forEach(function (b) {
            lines.push('"' + String(b).replace(/"/g, '""') + '"');
        });
        lines.push('');
        const years = cmp.years || [];
        lines.push(['Organism', 'Drug'].concat(years, ['delta', 'dir']).join(','));
        (cmp.pairs || []).forEach(function (p) {
            const rec = ['"' + String(p.org_label || '').replace(/"/g, '""') + '"', p.drug_label];
            years.forEach(function (y) {
                const cell = (p.by_year && p.by_year[y]) ? p.by_year[y] : null;
                if (!cell) { rec.push(''); return; }
                if (cell.mark === 'R') { rec.push('R'); return; }
                rec.push(cell.pct != null ? cell.pct : 'r');
            });
            rec.push(p.delta == null ? '' : p.delta, p.dir || '');
            lines.push(rec.join(','));
        });
        lines.push('');
        lines.push(['Phenotype'].concat(years, ['delta', 'dir']).join(','));
        (cmp.phenotypes || []).forEach(function (p) {
            const rec = [p.label];
            years.forEach(function (y) {
                const cell = (p.by_year && p.by_year[y]) ? p.by_year[y] : null;
                rec.push(cell && cell.pct != null ? cell.pct : 'r');
            });
            rec.push(p.delta == null ? '' : p.delta, p.dir || '');
            lines.push(rec.join(','));
        });
    }
    const blob = new Blob(['\ufeff' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'antibiogram_' + (m.start || '') + '_' + (m.end || '') + '.csv';
    a.click();
}
</script>
</body>
</html>
