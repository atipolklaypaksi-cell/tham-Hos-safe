<?php
/**
 * ติดตั้งอัปเดตจาก zip อย่างปลอดภัย — ไม่ทับไฟล์ตั้งค่าเฉพาะ รพ.
 */

/** path (เทียบจากโฟลเดอร์แอป) ที่ห้ามทับตอนอัปเดต */
function tham_update_protected_paths() {
    return [
        'db_connect.php',          // host/user/pass ของ รพ.
        'license.key',
        'secure/',                 // service account / ความลับ
        'uploads/',
        'logs/',
        'tmp/',
        'update_temp.zip',
        'update_staging/',
        '.env',
        '.env.local',
        'config.local.php',
        'db_config.php',
    ];
}

function tham_update_is_protected($relativePath) {
    $rel = str_replace('\\', '/', (string)$relativePath);
    $rel = ltrim($rel, '/');
    // ตัด prefix โฟลเดอร์ใน zip ถ้ามี (เช่น thamhossafe/xxx)
    if (preg_match('#^(?:thamhossafe|public/thamhossafe)/(.+)$#i', $rel, $m)) {
        $rel = $m[1];
    }
    foreach (tham_update_protected_paths() as $p) {
        $p = str_replace('\\', '/', $p);
        if (substr($p, -1) === '/') {
            if ($rel === rtrim($p, '/') || strpos($rel, $p) === 0) {
                return true;
            }
        } elseif ($rel === $p) {
            return true;
        }
    }
    return false;
}

/**
 * ดาวน์โหลด zip ด้วย timeout
 * @return array{ok:bool,error?:string,bytes?:int,path?:string}
 */
function tham_update_download_zip($url, $destPath) {
    $url = trim((string)$url);
    if ($url === '' || !preg_match('#^https?://#i', $url)) {
        return ['ok' => false, 'error' => 'URL อัปเดตไม่ถูกต้อง'];
    }
    if (!function_exists('curl_init')) {
        return ['ok' => false, 'error' => 'ไม่มี cURL ใน PHP'];
    }
    $fp = fopen($destPath, 'wb');
    if (!$fp) {
        return ['ok' => false, 'error' => 'เขียนไฟล์ชั่วคราวไม่ได้'];
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_FILE => $fp,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT => 'THAM-HOS-SAFE-Updater',
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 180,
    ]);
    $ok = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    fclose($fp);
    if (!$ok || $code !== 200) {
        @unlink($destPath);
        return ['ok' => false, 'error' => 'ดาวน์โหลดล้มเหลว HTTP ' . $code . ($err ? " ($err)" : '')];
    }
    $size = filesize($destPath);
    if ($size === false || $size < 100) {
        @unlink($destPath);
        return ['ok' => false, 'error' => 'ไฟล์อัปเดตว่างหรือเล็กผิดปกติ'];
    }
    return ['ok' => true, 'bytes' => (int)$size, 'path' => $destPath];
}

/**
 * แตก zip ไป staging แล้วคัดลอกเฉพาะไฟล์ที่ไม่ถูกป้องกัน
 * @return array{ok:bool,error?:string,copied?:int,skipped?:int,skipped_list?:array}
 */
function tham_update_apply_zip($zipPath, $appRoot) {
    if (!class_exists('ZipArchive')) {
        return ['ok' => false, 'error' => 'ไม่มี ZipArchive'];
    }
    $appRoot = rtrim(str_replace('\\', '/', $appRoot), '/');
    $staging = $appRoot . '/update_staging_' . date('YmdHis');
    if (!@mkdir($staging, 0775, true) && !is_dir($staging)) {
        return ['ok' => false, 'error' => 'สร้างโฟลเดอร์ staging ไม่ได้'];
    }

    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) {
        tham_update_rrmdir($staging);
        return ['ok' => false, 'error' => 'เปิดไฟล์ zip ไม่ได้'];
    }
    $zip->extractTo($staging);
    $zip->close();

    // ถ้า zip มี root folder เดียว ให้เลื่อนลงมา
    $entries = array_values(array_filter(scandir($staging) ?: [], function ($e) {
        return $e !== '.' && $e !== '..';
    }));
    $sourceRoot = $staging;
    if (count($entries) === 1 && is_dir($staging . '/' . $entries[0])) {
        $sourceRoot = $staging . '/' . $entries[0];
    }

    $copied = 0;
    $skipped = 0;
    $skippedList = [];
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($sourceRoot, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iterator as $item) {
        $full = str_replace('\\', '/', $item->getPathname());
        $rel = ltrim(substr($full, strlen(str_replace('\\', '/', $sourceRoot))), '/');
        if ($rel === '') {
            continue;
        }
        if (tham_update_is_protected($rel)) {
            $skipped++;
            if (count($skippedList) < 40) {
                $skippedList[] = $rel;
            }
            continue;
        }
        $dest = $appRoot . '/' . $rel;
        if ($item->isDir()) {
            if (!is_dir($dest)) {
                @mkdir($dest, 0775, true);
            }
            continue;
        }
        $dir = dirname($dest);
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        if (@copy($full, $dest)) {
            $copied++;
        } else {
            $skipped++;
            if (count($skippedList) < 40) {
                $skippedList[] = $rel . ' (copy failed)';
            }
        }
    }

    tham_update_rrmdir($staging);
    return [
        'ok' => true,
        'copied' => $copied,
        'skipped' => $skipped,
        'skipped_list' => $skippedList,
    ];
}

function tham_update_rrmdir($dir) {
    if (!is_dir($dir)) {
        return;
    }
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $f) {
        $p = $f->getPathname();
        if ($f->isDir()) {
            @rmdir($p);
        } else {
            @unlink($p);
        }
    }
    @rmdir($dir);
}
