<?php
session_start();
// 🎯 บังคับ Header ให้ส่งออกเป็น UTF-8
header('Content-Type: text/html; charset=utf-8');
header('Accept-CH: Sec-CH-UA-Mobile, Sec-CH-UA-Platform');

include('connect.php');
// 🎯 บังคับการเชื่อมต่อฐานข้อมูลเป็น UTF-8 เสมอ
mysqli_set_charset($con, "utf8");

if (empty($_SESSION['user_id']) && function_exists('tham_keep_login_restore')) {
    tham_keep_login_restore($con);
}

require_once __DIR__ . '/provider_oauth_helper.php';
require_once __DIR__ . '/user_unit_helper.php';
// โหลดค่า env/credential จากฐานข้อมูล (ถ้ามี) ทับไฟล์ config
provider_oauth_runtime($con);

// หน้าที่จะกลับหลัง Login สำเร็จ (เช่น smart_drug.php)
$login_return = trim((string)($_GET['return'] ?? $_GET['next'] ?? ''));
if ($login_return !== '') {
    tham_login_return_url_set($login_return);
}

$error_msg = '';
$oauth_error = trim((string)($_GET['oauth_error'] ?? ''));
if ($oauth_error !== '') {
    $error_msg = $oauth_error;
}

$provider_ready = provider_oauth_is_configured();
$login_mode = ($_GET['mode'] ?? '') === 'provider' ? 'provider' : 'local';

// เริ่ม OAuth Provider ID — อนุญาตแม้ล็อกอินอยู่แล้ว (เพื่อรับ moph token แล้วกลับหน้าเดิม)
if (isset($_GET['provider_login']) && $_GET['provider_login'] === '1') {
    $begin = provider_oauth_begin_login();
    if (!empty($begin['ok'])) {
        header('Location: ' . $begin['url']);
        exit;
    }
    $error_msg = $begin['error'] ?? 'ไม่สามารถเริ่มเข้าสู่ระบบ Provider ID ได้';
    $login_mode = 'provider';
}

// ผู้ที่ล็อกอินแล้ว: ไม่เด้งออกถ้าอยู่โหมด Provider / มี error (เช่น เริ่ม OAuth ไม่สำเร็จ)
if (isset($_SESSION['user_id']) && $error_msg === '' && $login_mode !== 'provider') {
    $back = tham_login_return_url_consume();
    header('Location: ' . ($back !== '' ? $back : 'home.php'));
    exit;
}

$provider_login_href = 'login.php?provider_login=1';
$ret_peek = tham_login_return_url_peek();
if ($ret_peek !== '') {
    $provider_login_href .= '&return=' . rawurlencode($ret_peek);
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    require_once __DIR__ . '/opduser_auth_helper.php';
    require_once __DIR__ . '/menu_permissions_helper.php';

    $logged_in = false;
    $user_row = null;

    // 1) บัญชีภายในระบบ (Admin ที่สร้างใน users.php)
    if ($username !== '') {
        $esc_user = mysqli_real_escape_string($con, $username);
        $hashed_password = md5($password);
        $sql = "SELECT * FROM users WHERE username = '$esc_user' AND auth_source = 'local' AND password = '$hashed_password' LIMIT 1";
        $query = mysqli_query($con, $sql);
        if ($query && mysqli_num_rows($query) > 0) {
            $user_row = mysqli_fetch_assoc($query);
            $logged_in = true;
        }
    }

    // 2) ยืนยันตัวตนจาก HOSxP opduser (เฉพาะ username ที่ไม่ใช่บัญชีภายใน)
    if (!$logged_in && $username !== '') {
        $esc_user = mysqli_real_escape_string($con, $username);
        $local_only = mysqli_query($con, "SELECT id FROM users WHERE username = '$esc_user' AND auth_source = 'local' LIMIT 1");
        if (!$local_only || mysqli_num_rows($local_only) === 0) {
            $auth = tham_opduser_authenticate($con, $username, $password);
            if (!empty($auth['ok'])) {
                $synced = tham_opduser_sync_local_user($con, $auth['opduser']);
                if ($synced) {
                    $q = mysqli_query($con, "SELECT * FROM users WHERE id = " . (int)$synced['id'] . " LIMIT 1");
                    if ($q && mysqli_num_rows($q) > 0) {
                        $user_row = mysqli_fetch_assoc($q);
                        $logged_in = true;
                    }
                }
            } elseif ($error_msg === '' && !empty($auth['error'])) {
                $error_msg = $auth['error'];
            }
        }
    }

    if ($logged_in && $user_row) {
        require_once __DIR__ . '/local_web_helper.php';
        if (!tham_local_web_allow_login($con, $user_row)) {
            $logged_in = false;
            $user_row = null;
            $error_msg = tham_local_web_deny_message();
        }
    }

    if ($logged_in && $user_row) {
        $_SESSION['user_id'] = $user_row['id'];
        $_SESSION['username'] = $user_row['username'];
        $_SESSION['full_name'] = $user_row['full_name'];
        $_SESSION['role'] = $user_row['role'];
        $_SESSION['auth_source'] = $user_row['auth_source'] ?? 'local';
        $_SESSION['local_web_only'] = !empty($user_row['local_web_only'])
            || (function_exists('tham_user_local_web_only_flag') && tham_user_local_web_only_flag($con, (int)$user_row['id']))
            ? 1 : 0;
        // ล้าง token จากรอบ Provider ก่อนหน้า (ถ้ามี)
        unset($_SESSION['moph_access_token_idp'], $_SESSION['provider_access_token'], $_SESSION['provider_profile'], $_SESSION['login_via']);

        tham_menu_load_session_permissions($con, (int)$user_row['id'], $user_row['role']);

        require_once __DIR__ . '/hapysure_helper.php';
        hapysure_session_save_credentials($username, $password);

        require_once __DIR__ . '/user_access_helper.php';
        tham_user_access_log_login($con, (int)$user_row['id']);

        require_once __DIR__ . '/user_unit_helper.php';
        tham_user_post_login_redirect($con);
    }
    if ($error_msg === '') {
        $error_msg = 'ชื่อผู้ใช้งาน หรือ รหัสผ่านไม่ถูกต้อง!';
    }
    $login_mode = 'local';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>เข้าสู่ระบบ - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #eef7f3 0%, #d4ebe3 50%, #a8d5c2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px 12px;
        }
        .login-card {
            width: 100%;
            max-width: 440px;
            border-radius: 16px;
            box-shadow: 0 12px 40px rgba(47, 61, 36, 0.2);
            border: 1px solid #a8d5c2;
        }
        .login-header {
            background: linear-gradient(135deg, #143326, #1a4032);
            color: white;
            border-top-left-radius: 16px;
            border-top-right-radius: 16px;
            padding: 30px 20px;
            text-align: center;
        }
        .login-card .btn-primary {
            background-color: #1f4d3b;
            border-color: #1f4d3b;
        }
        .login-card .btn-primary:hover {
            background-color: #143326;
            border-color: #143326;
        }
        .login-mode-tabs .btn {
            border-radius: 10px;
            font-weight: 700;
        }
        .login-mode-tabs .btn.active {
            background: #1f4d3b;
            border-color: #1f4d3b;
            color: #fff;
        }
        .provider-box {
            background: linear-gradient(180deg, #f7fbf9 0%, #eef6f2 100%);
            border: 1px dashed #7fb59a;
            border-radius: 12px;
            padding: 20px 16px;
            text-align: center;
        }
        .btn-provider {
            background: #0b5cab;
            border-color: #0b5cab;
            color: #fff;
        }
        .btn-provider:hover {
            background: #094a8a;
            border-color: #094a8a;
            color: #fff;
        }
    </style>
</head>
<body>

<div class="card login-card">
    <div class="login-header">
        <i class="fas fa-shield-virus fa-3x mb-3"></i>
        <h3 class="fw-bold mb-0">THAM Hos-Safe</h3>
        <p class="mb-0 text-light">ระบบความปลอดภัยด้านยา</p>
    </div>
    <div class="card-body p-4">

        <?php if($error_msg != ''): ?>
            <div class="alert alert-danger fw-bold text-center py-2"><i class="fas fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error_msg, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <div class="login-mode-tabs d-grid gap-2 d-sm-flex mb-4" role="group" aria-label="เลือกวิธีเข้าสู่ระบบ">
            <button type="button" class="btn btn-outline-secondary flex-fill <?php echo $login_mode === 'local' ? 'active' : ''; ?>" id="tabLocal" onclick="setLoginMode('local')">
                <i class="fas fa-user-lock me-1"></i> แบบเดิม
            </button>
            <button type="button" class="btn btn-outline-secondary flex-fill <?php echo $login_mode === 'provider' ? 'active' : ''; ?>" id="tabProvider" onclick="setLoginMode('provider')">
                <i class="fas fa-id-card me-1"></i> Provider ID
            </button>
        </div>

        <div id="panelLocal" style="<?php echo $login_mode === 'local' ? '' : 'display:none'; ?>">
            <form action="login.php" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold text-muted">ชื่อผู้ใช้งาน (Username)</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fas fa-user text-primary"></i></span>
                        <input type="text" name="username" class="form-control" required <?php echo $login_mode === 'local' ? 'autofocus' : ''; ?> placeholder="loginname จาก HOSxP">
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold text-muted">รหัสผ่าน (Password)</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fas fa-lock text-primary"></i></span>
                        <input type="password" name="password" class="form-control" required placeholder="รหัสผ่าน HOSxP">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100 fw-bold py-2 shadow-sm"><i class="fas fa-sign-in-alt me-2"></i>เข้าสู่ระบบ</button>
            </form>
            <p class="small text-muted text-center mt-3 mb-0">บัญชีภายในระบบ หรือ loginname จาก HOSxP</p>
        </div>

        <div id="panelProvider" style="<?php echo $login_mode === 'provider' ? '' : 'display:none'; ?>">
            <div class="provider-box">
                <i class="fas fa-hospital-user fa-2x text-primary mb-2"></i>
                <h5 class="fw-bold mb-2">เข้าสู่ระบบด้วย Provider ID</h5>
                <p class="small text-muted mb-3">ผ่าน Health ID OAuth เพื่อใช้งาน Drugs Center และการตรวจสอบยาจากข้อมูลกลาง</p>
                <?php if ($provider_ready): ?>
                    <a href="<?php echo htmlspecialchars($provider_login_href, ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-provider w-100 fw-bold py-2 shadow-sm">
                        <i class="fas fa-sign-in-alt me-2"></i>Login with Provider ID
                    </a>
                    <p class="small text-muted mt-3 mb-0">env: <?php echo htmlspecialchars(provider_oauth_env(), ENT_QUOTES, 'UTF-8'); ?></p>
                <?php else: ?>
                    <div class="alert alert-warning small mb-0 text-start">
                        ยังไม่ได้ตั้งค่า OAuth — คัดลอก <code>provider_oauth_config.example.php</code> เป็น <code>provider_oauth_config.php</code> แล้วใส่ Client ID / Secret
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="text-center mt-4">
            <small class="text-muted d-block">© <?php echo date('Y'); ?> THAM Hos-Safe. All rights reserved.</small>
            <small class="text-muted" style="font-size: 0.75rem;">Developed by Pharm. Atipol Klaipaksi</small>
        </div>
    </div>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
<script>
function setLoginMode(mode) {
    var local = document.getElementById('panelLocal');
    var provider = document.getElementById('panelProvider');
    var tabLocal = document.getElementById('tabLocal');
    var tabProvider = document.getElementById('tabProvider');
    if (mode === 'provider') {
        local.style.display = 'none';
        provider.style.display = '';
        tabLocal.classList.remove('active');
        tabProvider.classList.add('active');
    } else {
        local.style.display = '';
        provider.style.display = 'none';
        tabProvider.classList.remove('active');
        tabLocal.classList.add('active');
    }
}
</script>
</body>
</html>
