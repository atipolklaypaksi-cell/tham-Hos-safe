<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/smart_pharma_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)($_SESSION['user_id'] ?? 0), $_SESSION['role'] ?? '');
}
sp_ensure_tables($con);
session_write_close();

$h = function ($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
};
$parse_date = function ($key, $fallback) {
    $raw = trim((string)($_GET[$key] ?? ''));
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw) ? $raw : $fallback;
};

$start_date = $parse_date('start_date', date('Y-m-01'));
$end_date = $parse_date('end_date', date('Y-m-d'));
if ($start_date > $end_date) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$filters = [
    'patient_type' => in_array($_GET['patient_type'] ?? '', ['OPD', 'IPD'], true) ? $_GET['patient_type'] : '',
    'module_key' => trim((string)($_GET['module_key'] ?? '')),
    'intervention_type' => trim((string)($_GET['intervention_type'] ?? '')),
    'deviation' => trim((string)($_GET['deviation'] ?? '')),
    'alert_level' => in_array($_GET['alert_level'] ?? '', ['hard', 'soft'], true) ? $_GET['alert_level'] : '',
    'recorder' => trim((string)($_GET['recorder'] ?? '')),
    'ward' => trim((string)($_GET['ward'] ?? '')),
    'q' => trim((string)($_GET['q'] ?? '')),
];

$options = sp_intervention_report_options($con, $start_date, $end_date);
$rows = sp_intervention_report_fetch($con, $start_date, $end_date, $filters);

$dash = [
    'total' => count($rows),
    'patients' => 0,
    'error' => 0,
    'not_error' => 0,
    'unset' => 0,
    'hard' => 0,
    'soft' => 0,
    'opd' => 0,
    'ipd' => 0,
    'types' => [],
    'modules' => [],
    'recorders' => [],
    'days' => [],
];
$hn_seen = [];
foreach ($rows as $r) {
    $hn_key = ltrim((string)($r['hn'] ?? ''), '0') ?: (string)($r['hn'] ?? '');
    if ($hn_key !== '') {
        $hn_seen[$hn_key] = true;
    }
    $dev = trim((string)($r['deviation_category'] ?? ''));
    if ($dev === 'ความคลาดเคลื่อนจริง') {
        $dash['error']++;
    } elseif ($dev === 'ไม่ใช่ความคลาดเคลื่อน') {
        $dash['not_error']++;
    } else {
        $dash['unset']++;
    }
    if (($r['alert_level'] ?? '') === 'hard') {
        $dash['hard']++;
    } else {
        $dash['soft']++;
    }
    if (($r['patient_type'] ?? '') === 'IPD') {
        $dash['ipd']++;
    } else {
        $dash['opd']++;
    }
    $type_label = sp_intervention_type_label($r['intervention_type'] ?? '');
    $dash['types'][$type_label] = ($dash['types'][$type_label] ?? 0) + 1;
    $mod_label = trim((string)($r['module_label'] ?? ''));
    if ($mod_label === '') {
        $mod_label = trim((string)($r['module_key'] ?? '')) ?: 'ไม่ระบุโมดูล';
    }
    $dash['modules'][$mod_label] = ($dash['modules'][$mod_label] ?? 0) + 1;
    $rec_name = trim((string)($r['recorded_name'] ?? ''));
    if ($rec_name === '') {
        $rec_name = 'ไม่ระบุผู้บันทึก';
    }
    $dash['recorders'][$rec_name] = ($dash['recorders'][$rec_name] ?? 0) + 1;
    $day = substr((string)($r['created_at'] ?? ''), 0, 10);
    if ($day !== '') {
        $dash['days'][$day] = ($dash['days'][$day] ?? 0) + 1;
    }
}
$dash['patients'] = count($hn_seen);
$ivr_edit = [];
foreach ($rows as $r) {
    $ivr_edit[(string)(int)($r['id'] ?? 0)] = [
        'id' => (int)($r['id'] ?? 0),
        'ptname' => trim((string)($r['ptname'] ?? '')),
        'hn' => (string)($r['hn'] ?? ''),
        'an' => (string)($r['an'] ?? ''),
        'vn' => (string)($r['vn'] ?? ''),
        'patient_type' => (string)($r['patient_type'] ?? ''),
        'module' => trim((string)($r['module_label'] ?? '')) ?: (string)($r['module_key'] ?? ''),
        'intervention_type' => (string)($r['intervention_type'] ?? 'recommend'),
        'deviation_category' => (string)($r['deviation_category'] ?? ''),
        'note_text' => sp_intervention_report_note($r['note_text'] ?? '', $r['alert_summary'] ?? ''),
        'consult_result' => (string)($r['consult_result'] ?? ''),
        'alert_summary' => (string)($r['alert_summary'] ?? ''),
    ];
}
arsort($dash['types']);
arsort($dash['modules']);
arsort($dash['recorders']);
ksort($dash['days']);

$fmt_dt = function ($dt) {
    $ts = strtotime((string)$dt);
    if (!$ts) {
        return '-';
    }
    return date('d/m/', $ts) . ((int)date('Y', $ts) + 543) . ' ' . date('H:i', $ts);
};
$fmt_day = function ($d) {
    $ts = strtotime((string)$d);
    if (!$ts) {
        return (string)$d;
    }
    return date('d/m/', $ts) . ((int)date('Y', $ts) + 543);
};

$qs = function (array $over = []) use ($start_date, $end_date, $filters) {
    $p = array_merge([
        'start_date' => $start_date,
        'end_date' => $end_date,
    ], $filters, $over);
    $keep = [];
    foreach ($p as $k => $v) {
        if ($v === '' || $v === null) {
            continue;
        }
        $keep[$k] = $v;
    }
    return 'smart_pharma_intervention_report.php' . ($keep ? ('?' . http_build_query($keep)) : '');
};

$bar = function ($title, array $items, $max_n = 8) use ($h, $dash) {
    if (!$items) {
        return '<div class="text-muted small">ไม่มีข้อมูลในช่วงนี้</div>';
    }
    $max = max($items);
    $html = '';
    $n = 0;
    foreach ($items as $label => $count) {
        if ($n >= $max_n) {
            break;
        }
        $n++;
        $pct = $max > 0 ? max(4, (int)round($count / $max * 100)) : 0;
        $html .= '<div class="mb-2">'
            . '<div class="d-flex justify-content-between small"><span class="text-truncate me-2">' . $h($label) . '</span><b>' . number_format($count) . '</b></div>'
            . '<div class="ivr-track"><div class="ivr-bar" style="width:' . $pct . '%"></div></div>'
            . '</div>';
    }
    $rest = count($items) - $n;
    if ($rest > 0) {
        $html .= '<div class="small text-muted">และอีก ' . $rest . ' รายการ</div>';
    }
    return $html;
};
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intervention Report - Smart Pharma</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f7f6; }
        .ivr-hero {
            background: linear-gradient(135deg, #0f766e 0%, #0d9488 55%, #14b8a6 100%);
            color: #fff; border-radius: 12px; padding: 1.1rem 1.35rem;
        }
        .kpi-card { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,.06); height: 100%; }
        .kpi-value { font-size: 1.7rem; font-weight: 800; line-height: 1.1; }
        .ivr-track { height: 8px; border-radius: 99px; background: #e2e8f0; overflow: hidden; }
        .ivr-bar { height: 100%; background: #0d9488; border-radius: 99px; }
        .ivr-table thead th { background: #0f766e; color: #fff; font-size: .8rem; white-space: nowrap; position: sticky; top: 0; }
        .ivr-table td { vertical-align: top; font-size: .86rem; }
        .ivr-note { max-width: 280px; white-space: pre-wrap; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <div id="content" class="content">
        <div class="container-fluid py-3">
            <div class="ivr-hero mb-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <h4 class="fw-bold mb-1"><i class="fas fa-chart-pie me-2"></i>Intervention Report</h4>
                    <div class="small">รายการ Intervention ที่บันทึกแล้ว แยกตามประเภท ความคลาดเคลื่อน และผู้บันทึก</div>
                </div>
                <a href="smart_pharma_interventions.php" class="btn btn-light btn-sm fw-bold"><i class="fas fa-notes-medical me-1"></i>Intervention Log</a>
            </div>

            <div class="card shadow-sm border-0 mb-3">
                <div class="card-header bg-white py-2 fw-bold"><i class="fas fa-filter me-1 text-success"></i>ตัวกรอง</div>
                <div class="card-body py-3">
                    <form method="get" class="row g-2 align-items-end">
                        <div class="col-6 col-lg-2">
                            <label class="form-label small fw-bold mb-1">วันที่บันทึก ตั้งแต่</label>
                            <input type="date" name="start_date" class="form-control form-control-sm" value="<?php echo $h($start_date); ?>">
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label small fw-bold mb-1">ถึงวันที่</label>
                            <input type="date" name="end_date" class="form-control form-control-sm" value="<?php echo $h($end_date); ?>">
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label small fw-bold mb-1">ประเภทผู้ป่วย</label>
                            <select name="patient_type" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="OPD"<?php echo $filters['patient_type'] === 'OPD' ? ' selected' : ''; ?>>OPD</option>
                                <option value="IPD"<?php echo $filters['patient_type'] === 'IPD' ? ' selected' : ''; ?>>IPD</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label small fw-bold mb-1">โมดูล</label>
                            <select name="module_key" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <?php foreach ($options['modules'] as $key => $label): ?>
                                <option value="<?php echo $h($key); ?>"<?php echo $filters['module_key'] === $key ? ' selected' : ''; ?>><?php echo $h($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label small fw-bold mb-1">ประเภทการแทรกแซง</label>
                            <select name="intervention_type" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <?php foreach ($options['types'] as $key => $label): ?>
                                <option value="<?php echo $h($key); ?>"<?php echo $filters['intervention_type'] === $key ? ' selected' : ''; ?>><?php echo $h($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label small fw-bold mb-1">ใช่ความคลาดเคลื่อนไหม</label>
                            <select name="deviation" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="error"<?php echo $filters['deviation'] === 'error' ? ' selected' : ''; ?>>ความคลาดเคลื่อนจริง</option>
                                <option value="not_error"<?php echo $filters['deviation'] === 'not_error' ? ' selected' : ''; ?>>ไม่ใช่ความคลาดเคลื่อน</option>
                                <option value="unset"<?php echo $filters['deviation'] === 'unset' ? ' selected' : ''; ?>>ยังไม่ระบุ</option>
                                <?php foreach ($options['deviations'] as $key => $label): ?>
                                <option value="<?php echo $h($key); ?>"<?php echo $filters['deviation'] === $key ? ' selected' : ''; ?>><?php echo $h($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label small fw-bold mb-1">ระดับ Alert</label>
                            <select name="alert_level" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="hard"<?php echo $filters['alert_level'] === 'hard' ? ' selected' : ''; ?>>Hard</option>
                                <option value="soft"<?php echo $filters['alert_level'] === 'soft' ? ' selected' : ''; ?>>Soft</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label small fw-bold mb-1">ผู้บันทึก</label>
                            <select name="recorder" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <?php foreach ($options['recorders'] as $key => $label): ?>
                                <option value="<?php echo $h($key); ?>"<?php echo $filters['recorder'] === $key ? ' selected' : ''; ?>><?php echo $h($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label small fw-bold mb-1">วอร์ด</label>
                            <select name="ward" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="__none__"<?php echo $filters['ward'] === '__none__' ? ' selected' : ''; ?>>ไม่ระบุวอร์ด</option>
                                <?php foreach ($options['wards'] as $key => $label): ?>
                                <option value="<?php echo $h($key); ?>"<?php echo $filters['ward'] === $key ? ' selected' : ''; ?>><?php echo $h($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12 col-lg-4">
                            <label class="form-label small fw-bold mb-1">ค้นหา HN / ชื่อ / AN / VN / หมายเหตุ</label>
                            <input type="text" name="q" class="form-control form-control-sm" value="<?php echo $h($filters['q']); ?>" placeholder="เช่น 544932">
                        </div>
                        <div class="col-6 col-lg-1 d-grid">
                            <button type="submit" class="btn btn-sm text-white fw-bold" style="background:#0d9488;"><i class="fas fa-search me-1"></i>ดู</button>
                        </div>
                        <div class="col-6 col-lg-1 d-grid">
                            <a href="smart_pharma_intervention_report.php" class="btn btn-outline-secondary btn-sm">ล้าง</a>
                        </div>
                        <div class="col-12">
                            <div class="d-flex flex-wrap gap-1">
                                <a class="btn btn-sm btn-outline-secondary" href="<?php echo $h($qs(['start_date' => date('Y-m-d', strtotime('-6 days')), 'end_date' => date('Y-m-d')])); ?>">7 วัน</a>
                                <a class="btn btn-sm btn-outline-secondary" href="<?php echo $h($qs(['start_date' => date('Y-m-01'), 'end_date' => date('Y-m-d')])); ?>">เดือนนี้</a>
                                <a class="btn btn-sm btn-outline-secondary" href="<?php echo $h($qs(['start_date' => date('Y-01-01'), 'end_date' => date('Y-m-d')])); ?>">ตั้งแต่ต้นปี</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row g-2 mb-3">
                <div class="col-6 col-lg-2">
                    <div class="card kpi-card p-3">
                        <div class="text-muted small">รายการ Intervention</div>
                        <div class="kpi-value"><?php echo number_format($dash['total']); ?></div>
                    </div>
                </div>
                <div class="col-6 col-lg-2">
                    <div class="card kpi-card p-3">
                        <div class="text-muted small">จำนวนผู้ป่วย</div>
                        <div class="kpi-value"><?php echo number_format($dash['patients']); ?></div>
                    </div>
                </div>
                <div class="col-6 col-lg-2">
                    <a class="card kpi-card p-3 text-decoration-none" href="<?php echo $h($qs(['deviation' => 'error'])); ?>">
                        <div class="text-muted small">ความคลาดเคลื่อนจริง</div>
                        <div class="kpi-value text-danger"><?php echo number_format($dash['error']); ?></div>
                    </a>
                </div>
                <div class="col-6 col-lg-2">
                    <a class="card kpi-card p-3 text-decoration-none" href="<?php echo $h($qs(['deviation' => 'not_error'])); ?>">
                        <div class="text-muted small">ไม่ใช่ความคลาดเคลื่อน</div>
                        <div class="kpi-value text-info"><?php echo number_format($dash['not_error']); ?></div>
                    </a>
                </div>
                <div class="col-6 col-lg-2">
                    <a class="card kpi-card p-3 text-decoration-none" href="<?php echo $h($qs(['deviation' => 'unset'])); ?>">
                        <div class="text-muted small">ยังไม่ระบุ</div>
                        <div class="kpi-value text-secondary"><?php echo number_format($dash['unset']); ?></div>
                    </a>
                </div>
                <div class="col-6 col-lg-2">
                    <div class="card kpi-card p-3">
                        <div class="text-muted small">Hard / Soft</div>
                        <div class="kpi-value"><span class="text-danger"><?php echo number_format($dash['hard']); ?></span> <span class="text-muted fs-6">/</span> <span class="text-warning"><?php echo number_format($dash['soft']); ?></span></div>
                        <div class="small text-muted">OPD <?php echo number_format($dash['opd']); ?> · IPD <?php echo number_format($dash['ipd']); ?></div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-lg-3">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white py-2 fw-bold small">การแทรกแซง</div>
                        <div class="card-body"><?php echo $bar('types', $dash['types']); ?></div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white py-2 fw-bold small">โมดูล</div>
                        <div class="card-body"><?php echo $bar('modules', $dash['modules']); ?></div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white py-2 fw-bold small">ผู้บันทึก</div>
                        <div class="card-body"><?php echo $bar('recorders', $dash['recorders']); ?></div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white py-2 fw-bold small">รายวัน</div>
                        <div class="card-body"><?php
                            $day_items = [];
                            foreach ($dash['days'] as $day => $count) {
                                $day_items[$fmt_day($day)] = $count;
                            }
                            echo $bar('days', array_slice($day_items, -14, 14, true), 14);
                        ?></div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-2 fw-bold d-flex justify-content-between">
                    <span><i class="fas fa-user-injured me-1"></i>ผู้ป่วยที่บันทึก Intervention</span>
                    <span class="text-muted small fw-normal"><?php echo number_format($dash['total']); ?> รายการ · <?php echo number_format($dash['patients']); ?> คน</span>
                </div>
                <div class="table-responsive" style="max-height:70vh;">
                    <table class="table table-sm table-hover ivr-table mb-0">
                        <thead>
                            <tr>
                                <th>วันที่บันทึก</th>
                                <th>ผู้ป่วย</th>
                                <th>โมดูล</th>
                                <th>การแทรกแซง</th>
                                <th>ใช่ความคลาดเคลื่อนไหม</th>
                                <th>หมายเหตุ</th>
                                <th>รายละเอียดหลัง Consult</th>
                                <th>ผู้บันทึก</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (!$rows): ?>
                            <tr><td colspan="9" class="text-center text-muted py-4">ไม่พบรายการในช่วงนี้</td></tr>
                        <?php endif; ?>
                        <?php foreach ($rows as $r):
                            $dev = trim((string)($r['deviation_category'] ?? ''));
                            if ($dev === 'ความคลาดเคลื่อนจริง') {
                                $dev_html = '<span class="badge bg-danger">ความคลาดเคลื่อนจริง</span>';
                            } elseif ($dev === 'ไม่ใช่ความคลาดเคลื่อน') {
                                $dev_html = '<span class="badge bg-info text-dark">ไม่ใช่ความคลาดเคลื่อน</span>';
                            } elseif ($dev === '') {
                                $dev_html = '<span class="badge bg-light text-dark border">ยังไม่ระบุ</span>';
                            } else {
                                $dev_html = '<span class="badge bg-secondary">' . $h($dev) . '</span>';
                            }
                            $visit = $fmt_day($r['vstdate'] ?? '');
                            $id_bits = 'HN ' . $h($r['hn'] ?? '-');
                            if (trim((string)($r['an'] ?? '')) !== '') {
                                $id_bits .= ' · AN ' . $h($r['an']);
                            }
                            if (trim((string)($r['vn'] ?? '')) !== '') {
                                $id_bits .= ' · VN ' . $h($r['vn']);
                            }
                            $summary = trim((string)($r['alert_summary'] ?? ''));
                            $note = sp_intervention_report_note($r['note_text'] ?? '', $summary);
                            $consult = trim((string)($r['consult_result'] ?? ''));
                            $level_html = ($r['alert_level'] ?? '') === 'hard'
                                ? '<span class="badge bg-danger">Hard</span>'
                                : '<span class="badge bg-warning text-dark">Soft</span>';
                        ?>
                            <tr>
                                <td class="text-nowrap"><?php echo $h($fmt_dt($r['created_at'] ?? '')); ?></td>
                                <td>
                                    <div class="fw-bold"><?php echo $h(trim((string)($r['ptname'] ?? '')) ?: '—'); ?></div>
                                    <div class="small text-muted"><?php echo $id_bits; ?></div>
                                    <div class="small text-muted">Visit <?php echo $h($visit); ?><?php echo trim((string)($r['ward_display'] ?? '')) !== '' ? ' · ' . $h($r['ward_display']) : ''; ?> · <?php echo $h($r['patient_type'] ?? ''); ?> <?php echo $level_html; ?></div>
                                </td>
                                <td>
                                    <div><?php echo $h(trim((string)($r['module_label'] ?? '')) ?: ($r['module_key'] ?? '')); ?></div>
                                    <?php if ($summary !== ''): ?><div class="small text-muted ivr-note"><?php echo $h($summary); ?></div><?php endif; ?>
                                </td>
                                <td><?php echo $h(sp_intervention_type_label($r['intervention_type'] ?? '')); ?></td>
                                <td><?php echo $dev_html; ?></td>
                                <td class="ivr-note"><?php echo $note !== '' ? $h($note) : '<span class="text-muted">—</span>'; ?></td>
                                <td class="ivr-note"><?php echo $consult !== '' ? $h($consult) : '<span class="text-muted">—</span>'; ?></td>
                                <td><?php echo $h(trim((string)($r['recorded_name'] ?? '')) ?: '—'); ?></td>
                                <td class="text-nowrap">
                                    <a class="btn btn-outline-success btn-sm py-0" target="_blank" rel="noopener" href="smart_pharma_intervention_consult_print.php?id=<?php echo (int)($r['id'] ?? 0); ?>">พิมพ์ใบ Consult</a>
                                    <button type="button" class="btn btn-outline-primary btn-sm py-0" onclick="ivrOpenEdit(<?php echo (int)($r['id'] ?? 0); ?>)">แก้ไข</button>
                                    <button type="button" class="btn btn-outline-danger btn-sm py-0" onclick="ivrDelete(<?php echo (int)($r['id'] ?? 0); ?>)">ลบ</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="ivrEditModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">แก้ไข Intervention</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="ivr_id">
                <p class="small text-muted mb-2" id="ivr_patient"></p>
                <p class="small mb-3" id="ivr_summary"></p>
                <div class="mb-2">
                    <label class="form-label small fw-bold">การแทรกแซง</label>
                    <select id="ivr_type" class="form-select form-select-sm">
                        <?php foreach (sp_intervention_type_labels() as $key => $label): ?>
                        <option value="<?php echo $h($key); ?>"><?php echo $h($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-2">
                    <label class="form-label small fw-bold">ใช่ความคลาดเคลื่อนไหม</label>
                    <select id="ivr_deviation" class="form-select form-select-sm">
                        <option value="">— ไม่ระบุ —</option>
                        <option value="ความคลาดเคลื่อนจริง">ความคลาดเคลื่อนจริง</option>
                        <option value="ไม่ใช่ความคลาดเคลื่อน">ไม่ใช่ความคลาดเคลื่อน</option>
                    </select>
                </div>
                <div class="mb-2">
                    <label class="form-label small fw-bold">หมายเหตุ</label>
                    <textarea id="ivr_note" class="form-control form-control-sm" rows="3"></textarea>
                </div>
                <div class="mb-2">
                    <label class="form-label small fw-bold">รายละเอียดหลัง Consult</label>
                    <div class="d-flex flex-wrap gap-1 mb-1">
                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="ivrApplyConsult('แพทย์ Off')">แพทย์ Off</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="ivrApplyConsult('แพทย์ Hold')">แพทย์ Hold</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="ivrApplyConsult('แพทย์ลดขนาดยา')">แพทย์ลดขนาดยา</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="ivrApplyConsult('แพทย์ให้ยาต่อ')">แพทย์ให้ยาต่อ</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="ivrApplyConsult('')">อื่นๆ</button>
                    </div>
                    <textarea id="ivr_consult" class="form-control form-control-sm" rows="2" placeholder="เลือกตัวช่วยด้านบน หรือพิมพ์รายละเอียดเอง"></textarea>
                </div>
                <div id="ivr_edit_err" class="text-danger small"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="button" class="btn btn-success btn-sm fw-bold" onclick="ivrSaveEdit(true)"><i class="fas fa-print me-1"></i>บันทึกและพิมพ์ใบ Consult</button>
                <button type="button" class="btn btn-sm text-white fw-bold" style="background:#0d9488;" onclick="ivrSaveEdit(false)">บันทึก</button>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const IVR_ROWS = <?php echo json_encode($ivr_edit, JSON_UNESCAPED_UNICODE); ?>;
let ivrEditModal;
function ivrOpenEdit(id) {
    const row = IVR_ROWS[String(id)];
    if (!row) return;
    document.getElementById('ivr_id').value = row.id;
    const who = [row.ptname || '—', 'HN ' + (row.hn || '-'), row.patient_type, row.module].filter(Boolean).join(' · ');
    document.getElementById('ivr_patient').textContent = who;
    document.getElementById('ivr_summary').textContent = row.alert_summary || '';
    const typeSel = document.getElementById('ivr_type');
    if (![...typeSel.options].some(function(o) { return o.value === row.intervention_type; }) && row.intervention_type) {
        const extra = document.createElement('option');
        extra.value = row.intervention_type;
        extra.textContent = row.intervention_type;
        typeSel.appendChild(extra);
    }
    typeSel.value = row.intervention_type || 'recommend';
    const devSel = document.getElementById('ivr_deviation');
    if (row.deviation_category && ![...devSel.options].some(function(o) { return o.value === row.deviation_category; })) {
        const extraDev = document.createElement('option');
        extraDev.value = row.deviation_category;
        extraDev.textContent = row.deviation_category;
        devSel.appendChild(extraDev);
    }
    devSel.value = row.deviation_category || '';
    document.getElementById('ivr_note').value = row.note_text || '';
    document.getElementById('ivr_consult').value = row.consult_result || '';
    document.getElementById('ivr_edit_err').textContent = '';
    if (!ivrEditModal) ivrEditModal = new bootstrap.Modal(document.getElementById('ivrEditModal'));
    ivrEditModal.show();
}
function ivrSaveEdit(andPrint) {
    const id = document.getElementById('ivr_id').value;
    const err = document.getElementById('ivr_edit_err');
    err.textContent = '';
    let printWin = null;
    if (andPrint) {
        printWin = window.open('about:blank', '_blank');
    }
    fetch('fetch_smart_pharma_api.php?action=update_intervention', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        cache: 'no-store',
        body: JSON.stringify({
            id: id,
            intervention_type: document.getElementById('ivr_type').value,
            deviation_category: document.getElementById('ivr_deviation').value,
            note_text: document.getElementById('ivr_note').value,
            consult_result: document.getElementById('ivr_consult').value
        })
    }).then(function(r) { return r.json(); }).then(function(data) {
        if (!data || data.status !== 'success' || !data.saved) {
            if (printWin) printWin.close();
            err.textContent = (data && data.message) || 'แก้ไขไม่สำเร็จ';
            return;
        }
        if (andPrint && id && printWin) {
            printWin.location = 'smart_pharma_intervention_consult_print.php?id=' + encodeURIComponent(id) + '&autoprint=1';
        } else if (printWin) {
            printWin.close();
        }
        window.location.reload();
    }).catch(function() {
        if (printWin) printWin.close();
        err.textContent = 'เชื่อมต่อไม่สำเร็จ';
    });
}
function ivrApplyConsult(text) {
    const box = document.getElementById('ivr_consult');
    const phrase = String(text || '').trim();
    if (!phrase) {
        box.focus();
        return;
    }
    const cur = box.value.replace(/\s+$/, '');
    if (!cur) {
        box.value = phrase + ' ';
    } else if (cur.indexOf(phrase) === -1) {
        box.value = cur + '\n' + phrase + ' ';
    }
    box.focus();
    box.setSelectionRange(box.value.length, box.value.length);
}
function ivrDelete(id) {
    const row = IVR_ROWS[String(id)] || {};
    const who = (row.ptname || 'HN ' + (row.hn || id));
    const confirmText = prompt('คำเตือน: จะลบ Intervention ของ ' + who + ' ทั้งเคสเดียวกัน เหตุการณ์เดียวกัน และผู้บันทึกเดียวกัน\n\nพิมพ์คำว่า \'delete\' เพื่อยืนยัน:');
    if (confirmText === 'delete') {
        fetch('fetch_smart_pharma_api.php?action=delete_intervention', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            cache: 'no-store',
            body: JSON.stringify({ id: id, confirm: 'delete' })
        }).then(function(r) { return r.json(); }).then(function(data) {
            if (!data || data.status !== 'success' || !data.deleted) {
                alert((data && data.message) || 'ลบไม่สำเร็จ');
                return;
            }
            window.location.reload();
        }).catch(function() {
            alert('เชื่อมต่อไม่สำเร็จ');
        });
    } else if (confirmText !== null && confirmText !== '') {
        alert('พิมพ์คำว่า \'delete\' ไม่ถูกต้อง ข้อมูลจะไม่ถูกลบ');
    }
}
</script>
</body>
</html>
