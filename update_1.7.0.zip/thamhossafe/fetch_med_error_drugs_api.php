<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'unauthorized', 'drugs' => []]);
    exit;
}

include('connect.php');
session_write_close();
require_once __DIR__ . '/med_error_helper.php';
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
mysqli_set_charset($con, 'utf8');

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? 'search'));
$hos = hosxp_connect($con);
if (!$hos) {
    echo json_encode(['status' => 'error', 'message' => 'เชื่อมต่อ HOSxP ไม่สำเร็จ', 'drugs' => []]);
    exit;
}
mysqli_set_charset($hos, 'utf8');

if ($action === 'from_text') {
    $text = trim((string)($_POST['text'] ?? $_GET['text'] ?? ''));
    $solution = trim((string)($_POST['solution'] ?? $_GET['solution'] ?? ''));
    $hn = trim((string)($_POST['hn'] ?? $_GET['hn'] ?? ''));
    $an = trim((string)($_POST['an'] ?? $_GET['an'] ?? ''));
    $vn = trim((string)($_POST['vn'] ?? $_GET['vn'] ?? ''));
    $date = trim((string)($_POST['date'] ?? $_GET['date'] ?? ''));
    $split = med_error_split_desc_for_drugs($text, $solution);
    $error_drugs = med_error_drugs_from_text($hos, $split['error'], $hn, $an, $vn, $date, $con);
    $correct_drugs = [];
    if (trim($split['correct']) !== '') {
        $correct_drugs = med_error_drugs_from_text($hos, $split['correct'], $hn, $an, $vn, $date, $con);
    }
    $error_icodes = [];
    foreach ($error_drugs as $d) {
        $error_icodes[$d['icode']] = true;
    }
    $correct_only = [];
    foreach ($correct_drugs as $d) {
        if (!isset($error_icodes[$d['icode']])) {
            $correct_only[] = $d;
        }
    }
    mysqli_close($hos);
    echo json_encode([
        'status' => 'success',
        'drugs' => $error_drugs,
        'error_drugs' => $error_drugs,
        'correct_drugs' => $correct_only,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$term = trim((string)($_GET['q'] ?? $_GET['term'] ?? $_POST['q'] ?? ''));
$drugs = med_error_search_drugs($hos, $term, 30);
mysqli_close($hos);
echo json_encode(['status' => 'success', 'drugs' => $drugs], JSON_UNESCAPED_UNICODE);
