<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/amr_helper.php');
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_sensitivity_helper.php';
require_once __DIR__ . '/monitor_amr_drug_helper.php';
require_once __DIR__ . '/monitor_sepsis_helper.php';
mysqli_set_charset($con, 'utf8');
set_time_limit(120);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = [];
}
$src = array_merge($_GET, $input);
$action = trim((string)($src['action'] ?? 'list'));

function msp_json(array $payload) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'config_get') {
    msp_json(['status' => 'success', 'config' => msp_config_get($con)]);
}

if ($action === 'config_save') {
    msp_json([
        'status' => 'success',
        'message' => 'บันทึกการตั้งค่าแล้ว',
        'config' => msp_config_save($con, $src['config'] ?? $src),
    ]);
}

if ($action === 'config_reset') {
    msp_json([
        'status' => 'success',
        'message' => 'คืนค่าเกณฑ์มาตรฐานแล้ว',
        'config' => msp_config_reset($con),
    ]);
}

$hos = hosxp_connect($con, 120);
if (!$hos) {
    msp_json(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้']);
}
hosxp_extend_read_timeout($hos, 120);

if ($action === 'lab_detect') {
    $codes = msp_auto_lab_codes($hos);
    $cfg = msp_config_get($con);
    $cfg['lab_codes'] = array_merge($cfg['lab_codes'], $codes);
    msp_json(['status' => 'success', 'lab_codes' => $codes, 'config' => $cfg]);
}

if ($action === 'list') {
    $scan = msp_scan($hos, $con);
    if ($scan['error'] !== '') {
        msp_json(['status' => 'error', 'message' => $scan['error']]);
    }
    msp_json([
        'status' => 'success',
        'rows' => $scan['rows'],
        'meta' => $scan['meta'],
        'config' => $scan['config'],
    ]);
}

msp_json(['status' => 'error', 'message' => 'ไม่รู้จัก action']);
