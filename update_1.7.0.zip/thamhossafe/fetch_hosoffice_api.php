<?php
/**
 * API เชื่อมต่อ HOSoffice (Read Only)
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();
include(__DIR__ . '/connect.php');
require_once __DIR__ . '/hosoffice_helper.php';
mysqli_set_charset($con, 'utf8');

function hosoffice_api_json(array $payload, $code = 200) {
    ob_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    hosoffice_api_json(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], 401);
}

require_once __DIR__ . '/menu_permissions_helper.php';
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.hosoffice') && !tham_menu_can('admin.hosxp')) {
    hosoffice_api_json(['status' => 'error', 'message' => 'ไม่มีสิทธิ์ตั้งค่า HOSoffice'], 403);
}
session_write_close();

hosoffice_ensure_config($con);
$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'get'));

if ($action === 'get') {
    hosoffice_api_json([
        'status' => 'success',
        'config' => hosoffice_public_config(hosoffice_load_config($con)),
    ]);
}

if ($action === 'save') {
    $cfg = hosoffice_save_config($con, $input);
    hosoffice_api_json([
        'status' => 'success',
        'message' => 'บันทึกการเชื่อมต่อ HOSoffice แล้ว (Read Only)',
        'config' => hosoffice_public_config($cfg),
    ]);
}

if ($action === 'test') {
    $override = [];
    foreach (['ho_host', 'ho_port', 'ho_user', 'ho_db'] as $k) {
        if (isset($input[$k])) {
            $override[$k] = trim((string)$input[$k]);
        }
    }
    if (isset($input['ho_pass']) && (string)$input['ho_pass'] !== '' && (string)$input['ho_pass'] !== '********') {
        $override['ho_pass'] = (string)$input['ho_pass'];
    }
    $ping = hosoffice_ping($con, $override ?: null);
    hosoffice_api_json([
        'status' => $ping['ok'] ? 'success' : 'error',
        'message' => $ping['ok']
            ? 'เชื่อมต่อ HOSoffice สำเร็จ (Read Only)'
            : ('เชื่อมต่อล้มเหลว: ' . ($ping['error'] ?: 'ไม่ทราบสาเหตุ')),
        'ping' => $ping,
    ]);
}

if ($action === 'tables') {
    $ho = hosoffice_connect($con, 20);
    if (!$ho) {
        hosoffice_api_json(['status' => 'error', 'message' => 'เชื่อมต่อ HOSoffice ไม่ได้']);
    }
    $q = trim((string)($input['q'] ?? $_GET['q'] ?? ''));
    $tables = hosoffice_list_tables($ho, $q, 100);
    hosoffice_close($ho);
    hosoffice_api_json([
        'status' => 'success',
        'tables' => $tables,
    ]);
}

if ($action === 'preview') {
    $table = trim((string)($input['table'] ?? $_GET['table'] ?? ''));
    $ho = hosoffice_connect($con, 20);
    if (!$ho) {
        hosoffice_api_json(['status' => 'error', 'message' => 'เชื่อมต่อ HOSoffice ไม่ได้']);
    }
    $preview = hosoffice_preview_table($ho, $table, 20);
    $cols = hosoffice_describe_table($ho, $table);
    hosoffice_close($ho);
    hosoffice_api_json([
        'status' => empty($preview['error']) ? 'success' : 'error',
        'message' => $preview['error'] ?: '',
        'table' => $table,
        'columns' => $cols,
        'preview' => $preview,
    ]);
}

hosoffice_api_json(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], 400);
