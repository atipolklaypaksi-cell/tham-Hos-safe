<?php
/**
 * ซิงก์บัญชียาเครือข่ายจาก hospital_connect ตามความถี่ที่ตั้งในหน้า Upload
 * CLI:  php cron_network_drug_sync.php [--force]
 * HTTP: cron_network_drug_sync.php?key=SECRET[&force=1]
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
set_time_limit(600);
ini_set('memory_limit', '1024M');
if (function_exists('date_default_timezone_set')) {
    date_default_timezone_set('Asia/Bangkok');
}

include(__DIR__ . '/connect.php');
require_once __DIR__ . '/network_drug_sync_helper.php';
mysqli_set_charset($con, 'utf8');
nd_ensure_tables($con);
hds_ensure_tables($con);

$cfg = nd_sync_get_config($con);
$force = !empty($_GET['force']) || (isset($argv) && in_array('--force', $argv, true));

if (php_sapi_name() !== 'cli') {
    $secret = trim((string)($cfg['cron_secret'] ?? ''));
    $key = trim((string)($_GET['key'] ?? ''));
    if ($secret === '' || $key !== $secret) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Forbidden';
        exit;
    }
}

$due = nd_sync_is_due($cfg, $force);
if (empty($due['due'])) {
    $wait = (int)($due['wait_sec'] ?? 0);
    $out = [
        'status' => 'skipped',
        'message' => ($due['reason'] ?? '') === 'disabled'
            ? 'ยังไม่เปิดซิงก์อัตโนมัติ'
            : ('ยังไม่ถึงรอบซิงก์ · อีก ' . max(1, (int)ceil($wait / 60)) . ' นาที'),
        'wait_sec' => $wait,
        'freq' => $cfg['freq'] ?? 'daily',
        'time' => $cfg['time'] ?? '02:00',
    ];
    if (php_sapi_name() !== 'cli') {
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
    exit(0);
}

$log_dir = __DIR__ . '/logs';
if (!is_dir($log_dir)) {
    @mkdir($log_dir, 0775, true);
}
$lock = fopen($log_dir . '/cron_network_drug_sync.lock', 'c+');
if ($lock && !flock($lock, LOCK_EX | LOCK_NB)) {
    $out = ['status' => 'skipped', 'message' => 'มีรอบซิงก์กำลังทำงาน'];
    echo json_encode($out, JSON_UNESCAPED_UNICODE) . PHP_EOL;
    exit(0);
}

$res = nd_sync_all($con, [
    'user_id' => 0,
    'user_name' => 'ระบบ (เชื่อมต่อรพ.)',
]);

if ($lock) {
    flock($lock, LOCK_UN);
    fclose($lock);
}

if (php_sapi_name() !== 'cli') {
    header('Content-Type: application/json; charset=utf-8');
}
echo json_encode($res, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
