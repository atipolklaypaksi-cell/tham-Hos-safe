<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header("Location: login.php");
    exit;
}
include('connect.php');
include('hosxp_tmt_drug_helper.php');
require_once __DIR__ . '/monitor_drug_interaction_fatal_helper.php';
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
mysqli_set_charset($con, "utf8");

function di_escape($con, $v) {
    return mysqli_real_escape_string($con, $v ?? '');
}

function di_alert_level_from_row($row) {
    if (!empty($row['alert_level']) && in_array($row['alert_level'], ['hard', 'soft'], true)) {
        return $row['alert_level'];
    }
    // รองรับข้อมูลเก่าที่ยังมี severity
    if (isset($row['severity']) && (int)$row['severity'] >= 3) {
        return 'hard';
    }
    return 'soft';
}

function di_alert_badge_html($level) {
    if ($level === 'hard') {
        return '<span class="badge bg-danger">Hard Alert</span>';
    }
    return '<span class="badge bg-warning text-dark">Soft Alert</span>';
}

function di_build_dose_sql($con, $use_dose, $prefix) {
    if (!$use_dose) {
        return [
            'use' => 0,
            'min' => 'NULL',
            'max' => 'NULL',
        ];
    }
    $min = mysqli_real_escape_string($con, $_POST["{$prefix}_min"] ?? '');
    $max = mysqli_real_escape_string($con, $_POST["{$prefix}_max"] ?? '');
    return [
        'use' => 1,
        'min' => ($min !== '') ? "'$min'" : 'NULL',
        'max' => ($max !== '') ? "'$max'" : 'NULL',
    ];
}

function di_dose_config_warning($row, $which = 1) {
    return '';
}

function di_dose_condition_label($row, $which = 1) {
    $use_key = $which === 2 ? 'use_dose2_condition' : 'use_dose1_condition';
    $min_key = $which === 2 ? 'dose2_min' : 'dose1_min';
    $max_key = $which === 2 ? 'dose2_max' : 'dose1_max';
    if (empty($row[$use_key])) {
        return '';
    }
    $min = $row[$min_key] ?? '';
    $max = $row[$max_key] ?? '';
    if ($min === '' && $max === '') {
        return '';
    }
    return trim("{$min} – {$max} mg/วัน");
}

$has_di_dose_cols = ensure_di_dose_columns($con);
$has_di_pdf_cols = ensure_di_pdf_columns($con);
ensure_di_check_mode_column($con);

function di_pdf_sanitize_choice($v, array $options) {
    $v = trim((string)$v);
    return array_key_exists($v, $options) ? $v : '';
}

// --- CRUD ตั้งค่า ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_di' || $action === 'edit_di') {
        $drug_a = hosxp_parse_drug_option($_POST['drug_a'] ?? '');
        $drug_b = hosxp_parse_drug_option($_POST['drug_b'] ?? '');

        $drug_icode = di_escape($con, $drug_a['icode']);
        $drug_name = di_escape($con, $drug_a['name']);
        $hosxp_icode = di_escape($con, $drug_b['icode']);
        $hosxp_drug_name = di_escape($con, $drug_b['name']);
        $drug_id = 0;

        $alert_level = ($_POST['alert_level'] ?? '') === 'hard' ? 'hard' : 'soft';
        $interaction_type = di_escape($con, $_POST['interaction_type'] ?? 'drug_drug');
        $detail_text = di_escape($con, $_POST['detail_text'] ?? '');
        $cm = trim((string)($_POST['check_mode'] ?? 'same_visit'));
        $check_mode = di_normalize_check_mode($cm);
        $lookback_days = $check_mode === 'lookback' ? max(1, (int)($_POST['lookback_days'] ?? 7)) : 0;
        $active_status = isset($_POST['active_status']) ? 1 : 0;
        $dose1 = di_build_dose_sql($con, isset($_POST['use_dose1_condition']), 'dose1');
        $dose2 = di_build_dose_sql($con, isset($_POST['use_dose2_condition']), 'dose2');
        $pdf_onset = di_escape($con, di_pdf_sanitize_choice($_POST['pdf_onset'] ?? '', di_pdf_onset_options()));
        $pdf_severity = di_escape($con, di_pdf_sanitize_choice($_POST['pdf_severity'] ?? '', di_pdf_severity_options()));
        $pdf_documentation = di_escape($con, di_pdf_sanitize_choice($_POST['pdf_documentation'] ?? '', di_pdf_documentation_options()));
        $pdf_reference = di_escape($con, $_POST['pdf_reference'] ?? '');

        if ($drug_icode === '') {
            $_SESSION['di_error'] = 'กรุณาเลือกยาที่ 1 จาก HOSxP';
            header("Location: monitor_drug_interaction.php?tab=settings");
            exit;
        }
        if ($hosxp_icode === '') {
            $_SESSION['di_error'] = 'กรุณาเลือกยาที่ 2 จาก HOSxP';
            header("Location: monitor_drug_interaction.php?tab=settings");
            exit;
        }
        if ($drug_icode === $hosxp_icode) {
            $_SESSION['di_error'] = 'ยาที่ 1 และยาที่ 2 ต้องไม่ใช่รายการเดียวกัน';
            header("Location: monitor_drug_interaction.php?tab=settings");
            exit;
        }

        if ($action === 'add_di') {
            $dose_cols = $has_di_dose_cols
                ? ", use_dose1_condition, dose1_min, dose1_max, use_dose2_condition, dose2_min, dose2_max"
                : '';
            $dose_vals = $has_di_dose_cols
                ? ", {$dose1['use']}, {$dose1['min']}, {$dose1['max']}, {$dose2['use']}, {$dose2['min']}, {$dose2['max']}"
                : '';
            $pdf_cols = $has_di_pdf_cols
                ? ", pdf_onset, pdf_severity, pdf_documentation, pdf_reference"
                : '';
            $pdf_vals = $has_di_pdf_cols
                ? ", '$pdf_onset', '$pdf_severity', '$pdf_documentation', '$pdf_reference'"
                : '';
            $sql = "INSERT INTO monitor_drug_interaction_settings
                (drug_id, drug_name, drug_icode, hosxp_icode, hosxp_drug_name, interaction_type, alert_level, detail_text
                 {$pdf_cols},
                 check_mode, lookback_days{$dose_cols}, active_status)
                VALUES ('$drug_id', '$drug_name', '$drug_icode', '$hosxp_icode', '$hosxp_drug_name', '$interaction_type', '$alert_level', '$detail_text'
                        {$pdf_vals},
                        '$check_mode', '$lookback_days'{$dose_vals}, '$active_status')";
            if (mysqli_query($con, $sql)) {
                $_SESSION['di_msg'] = 'บันทึกกฎ Drug Interaction สำเร็จ';
                sp_monitor_settings_changed($con, 'di');
            } else {
                $_SESSION['di_error'] = 'เกิดข้อผิดพลาด: ' . mysqli_error($con);
            }
        } else {
            $id = (int)($_POST['rule_id'] ?? 0);
            if ($id <= 0) {
                $_SESSION['di_error'] = 'ไม่พบรหัสกฎที่ต้องการแก้ไข';
            } else {
                $dose_set = $has_di_dose_cols
                    ? ", use_dose1_condition={$dose1['use']}, dose1_min={$dose1['min']}, dose1_max={$dose1['max']},
                       use_dose2_condition={$dose2['use']}, dose2_min={$dose2['min']}, dose2_max={$dose2['max']}"
                    : '';
                $pdf_set = $has_di_pdf_cols
                    ? ", pdf_onset='$pdf_onset', pdf_severity='$pdf_severity', pdf_documentation='$pdf_documentation', pdf_reference='$pdf_reference'"
                    : '';
                $sql = "UPDATE monitor_drug_interaction_settings SET
                    drug_id='$drug_id', drug_name='$drug_name', drug_icode='$drug_icode',
                    hosxp_icode='$hosxp_icode', hosxp_drug_name='$hosxp_drug_name',
                    interaction_type='$interaction_type', alert_level='$alert_level', detail_text='$detail_text'
                    {$pdf_set},
                    check_mode='$check_mode', lookback_days='$lookback_days'{$dose_set},
                    active_status='$active_status'
                    WHERE id='$id'";
                if (mysqli_query($con, $sql)) {
                    $_SESSION['di_msg'] = 'แก้ไขกฎ Drug Interaction สำเร็จ';
                    sp_monitor_settings_changed($con, 'di');
                } else {
                    $_SESSION['di_error'] = 'เกิดข้อผิดพลาด: ' . mysqli_error($con);
                }
            }
        }
        header("Location: monitor_drug_interaction.php?tab=settings");
        exit;
    }

    if ($action === 'delete_di') {
        $id = (int)($_POST['del_id'] ?? 0);
        if ($id > 0) {
            mysqli_query($con, "DELETE FROM monitor_drug_interaction_settings WHERE id = $id");
            sp_monitor_settings_changed($con, 'di');
            $_SESSION['di_msg'] = 'ลบกฎ Drug Interaction สำเร็จ';
        }
        header("Location: monitor_drug_interaction.php?tab=settings");
        exit;
    }

    if ($action === 'import_fatal_di') {
        $con_hosxp_imp = hosxp_connect($con);
        if (!$con_hosxp_imp) {
            $_SESSION['di_error'] = 'เชื่อมต่อ HOSxP ไม่ได้ จึงนำเข้า Fatal DI ไม่ได้';
            header("Location: monitor_drug_interaction.php?tab=settings");
            exit;
        }
        $hosxp_drugs_imp = hosxp_fetch_active_drugs_tmt($con_hosxp_imp);
        mysqli_close($con_hosxp_imp);
        $result = di_fatal_import($con, $hosxp_drugs_imp);
        if (!empty($result['errors'])) {
            $_SESSION['di_error'] = 'นำเข้า Fatal DI มีข้อผิดพลาด: ' . implode('; ', $result['errors']);
        }
        $msg = 'นำเข้า Fatal DI จากเอกสารจังหวัดสระแก้วแล้ว '
            . (int)$result['inserted'] . ' รายการ (จับคู่ได้ '
            . (int)$result['pair_ok'] . '/' . (int)$result['pair_total'] . ' คู่'
            . ', ข้ามคู่ที่ซ้ำ ' . (int)$result['skipped_exist'] . ' รายการ)';
        $_SESSION['di_msg'] = $msg;
        if (!empty($result['missing'])) {
            $_SESSION['di_warn'] = "คู่ยาที่ยังไม่มีในคลัง HOSxP จึงยังไม่ถูกเพิ่ม:\n" . implode("\n", $result['missing']);
        }
        if ($result['inserted'] > 0) {
            sp_monitor_settings_changed($con, 'di');
        }
        header("Location: monitor_drug_interaction.php?tab=settings");
        exit;
    }
}

// Dropdown ยาจาก HOSxP ทั้งคู่ (ชื่อจาก TMT)
$con_hosxp = hosxp_connect($con);
$hosxp_drugs = $con_hosxp ? hosxp_fetch_active_drugs_tmt($con_hosxp) : [];
if ($con_hosxp) {
    mysqli_close($con_hosxp);
}
$seed_pairs = di_ensure_mtx_nsaid_soft_pairs($con, $hosxp_drugs);
if (!empty($seed_pairs['inserted'])) {
    $_SESSION['di_msg'] = 'เพิ่มคู่ยา Methotrexate tablet × NSAIDs '
        . (int)$seed_pairs['inserted'] . ' คู่ (Soft Alert · ใบสั่งยาเดียวกัน · MTX '
        . (int)$seed_pairs['mtx'] . ' รายการ × NSAID ' . (int)$seed_pairs['nsaid'] . ' รายการ)';
    if (function_exists('sp_monitor_settings_changed')) {
        sp_monitor_settings_changed($con, 'di');
    }
} elseif (!empty($seed_pairs['missing']) && empty($seed_pairs['done'])) {
    $_SESSION['di_warn'] = $seed_pairs['missing'];
}
$opt_hosxp_drugs_a = hosxp_build_drug_options_html($hosxp_drugs, '- เลือกยาที่ 1 จาก HOSxP -');
$opt_hosxp_drugs_b = hosxp_build_drug_options_html($hosxp_drugs, '- เลือกยาที่ 2 จาก HOSxP -');

$type_options = [
    'drug_drug' => 'Drug - Drug Interaction',
    'drug_food' => 'Drug - Food Interaction',
    'drug_disease' => 'Drug - Disease Interaction',
    'other' => 'อื่นๆ',
];

$monitor_rules = [];
$tbl_di_mon = mysqli_query($con, "SHOW TABLES LIKE 'monitor_drug_interaction_settings'");
if ($tbl_di_mon && mysqli_num_rows($tbl_di_mon) > 0) {
    $q_mon_rules = mysqli_query(
        $con,
        "SELECT id, drug_name, hosxp_drug_name, drug_icode, alert_level
         FROM monitor_drug_interaction_settings
         WHERE active_status = 1
           AND TRIM(drug_icode) <> ''
           AND TRIM(hosxp_icode) <> ''
         ORDER BY drug_name ASC, hosxp_drug_name ASC"
    );
    if ($q_mon_rules) {
        while ($mr = mysqli_fetch_assoc($q_mon_rules)) {
            $monitor_rules[] = $mr;
        }
    }
}

require_once __DIR__ . '/monitor_drug_interaction_consult_helper.php';
mdi_ensure_tables($con);
$current_user_id = (int)($_SESSION['user_id'] ?? 0);
$pharmacist_options = mdi_list_pharmacists($con, $current_user_id);
$mdi_reply_wait_days = mdi_get_reply_wait_days($con);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor Interaction - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/select2.min.css" rel="stylesheet">
    <link href="css/select2-bootstrap-5-theme.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .hn-group-header { background: #e9ecef; font-weight: bold; }
        .hn-group-header td { border-left: 4px solid #6f42c1; }
        .visit-row td { background: #fff; }
        .visit-row td:first-child { padding-left: 2rem; }
        .section-block .table thead { background-color: #dc3545 !important; color: #fff !important; }
        .section-warn .table thead { background-color: #fd7e14 !important; color: #fff !important; }
        #diFormCard.edit-mode .card-header { background-color: #6f42c1 !important; border-color: #6f42c1; }
        #diFormCard.copy-mode .card-header { background-color: #6c757d !important; border-color: #6c757d; }
        tr.di-editing-row { background-color: #f3e8ff !important; }
        .disabled-section { opacity: 0.45; pointer-events: none; }
        .lookback-wrap.disabled-section { opacity: 0.45; pointer-events: none; }
        .di-detail-cell { font-size: 0.85rem; white-space: pre-wrap; word-break: break-word; min-width: 280px; max-width: 480px; }
        .di-detail-label { font-weight: 700; color: #495057; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.02em; }
        .di-detail-text { color: #212529; line-height: 1.45; }
        .di-check-meta { color: #0d6efd; line-height: 1.45; font-weight: 600; }
        #diRuleFilterBox { background: #fafbfc; }
        #diRuleFilterBox .form-check-label { line-height: 1.35; }
        #diRuleFilterBox .di-rule-cb-label { cursor: pointer; }
        .di-action-cell { white-space: normal; min-width: 168px; }
        .di-action-cell .btn { min-width: 32px; margin-bottom: 2px; }
        .mdi-outcome-group { gap: .35rem 1.1rem; }
        .mdi-outcome-group .form-check { min-width: 7.5rem; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-4 text-dark"><i class="fas fa-exclamation-triangle text-danger me-2"></i>Monitor Interaction</h4>

            <?php
            require_once __DIR__ . '/drug_center_helper.php';
            echo drug_center_status_banner_html();
            ?>

            <?php if (!empty($_SESSION['di_msg'])): ?>
                <div class="alert alert-success fw-bold"><i class="fas fa-check-circle me-1"></i><?php echo htmlspecialchars($_SESSION['di_msg']); ?></div>
                <?php unset($_SESSION['di_msg']); ?>
            <?php endif; ?>
            <?php if (!empty($_SESSION['di_error'])): ?>
                <div class="alert alert-danger fw-bold"><i class="fas fa-times-circle me-1"></i><?php echo htmlspecialchars($_SESSION['di_error']); ?></div>
                <?php unset($_SESSION['di_error']); ?>
            <?php endif; ?>
            <?php if (!empty($_SESSION['di_warn'])): ?>
                <div class="alert alert-warning small" style="white-space:pre-line;"><?php echo htmlspecialchars($_SESSION['di_warn']); ?></div>
                <?php unset($_SESSION['di_warn']); ?>
            <?php endif; ?>

            <ul class="nav nav-tabs fw-bold" id="diTab" role="tablist">
                <li class="nav-item">
                    <button class="nav-link <?php echo (!isset($_GET['tab']) || $_GET['tab'] !== 'settings') ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#monitor" type="button"><i class="fas fa-desktop me-1"></i> รายการเฝ้าระวังหน้างาน</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link <?php echo (isset($_GET['tab']) && $_GET['tab'] === 'settings') ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#settings" type="button"><i class="fas fa-cogs me-1"></i> ตั้งค่า Drug Interaction</button>
                </li>
            </ul>

            <div class="tab-content bg-white border border-top-0 p-4 rounded-bottom shadow-sm">

                <div class="tab-pane fade <?php echo (!isset($_GET['tab']) || $_GET['tab'] !== 'settings') ? 'show active' : ''; ?>" id="monitor">
                    <div class="filter-box p-3 mb-3">
                        <div class="row g-2 align-items-end">
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ช่วงวันที่ให้ยา ตั้งแต่</label>
                                <input type="text" id="filter_start" class="form-control form-control-sm bg-white">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ถึงวันที่</label>
                                <input type="text" id="filter_end" class="form-control form-control-sm bg-white">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold mb-1">ช่วงเวลาเร็ว</label>
                                <div class="btn-group w-100" role="group">
                                    <button type="button" class="btn btn-outline-secondary btn-sm fw-bold di-range-btn" data-days="1" onclick="setDIDateRange(1)">วันนี้</button>
                                    <button type="button" class="btn btn-outline-secondary btn-sm fw-bold di-range-btn" data-days="3" onclick="setDIDateRange(3)">3 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary btn-sm fw-bold di-range-btn" data-days="7" onclick="setDIDateRange(7)">7 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary btn-sm fw-bold di-range-btn" data-days="15" onclick="setDIDateRange(15)">15 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary btn-sm fw-bold di-range-btn active" data-days="30" onclick="setDIDateRange(30)">30 วัน</button>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">HN (ไม่บังคับ)</label>
                                <input type="text" id="filter_hn" class="form-control form-control-sm bg-white" placeholder="ทุก HN" autocomplete="off">
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-primary btn-sm fw-bold shadow-sm w-100" type="button" id="btnFetchDI" onclick="fetchDIData()">
                                    <i class="fas fa-sync-alt me-1"></i> ประมวลผล / ดึงรายงาน
                                </button>
                            </div>
                        </div>
                        <div class="small text-muted mt-2"><i class="fas fa-info-circle me-1"></i> ตรวจทีละคู่ยาพร้อมกันหลายรายการ — แนะนำเริ่มที่ <b>7 วัน</b> และย่อช่วงวันที่ถ้ายังช้า · เปิดจาก Smart Pharma จะกรองตาม HN อัตโนมัติ</div>
                        <div id="diFocusBanner" class="alert alert-warning py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                        <div id="reportMeta" class="alert alert-info py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                    </div>

                    <div class="border rounded p-3 mb-3" id="diRuleFilterBox">
                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                            <label class="form-label fw-bold small mb-0">
                                <i class="fas fa-filter me-1 text-primary"></i> เลือกคู่ยาที่ต้องการรายงาน
                                <span class="text-muted fw-normal" id="diRuleSelectedCount"></span>
                            </label>
                            <div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-outline-primary fw-bold" onclick="diSelectAllRules(true)">เลือกทั้งหมด</button>
                                <button type="button" class="btn btn-outline-secondary fw-bold" onclick="diSelectAllRules(false)">ยกเลิกทั้งหมด</button>
                                <button type="button" class="btn btn-outline-danger fw-bold" onclick="printDIRulesPdf()"><i class="fas fa-file-pdf me-1"></i>พิมพ์ PDF</button>
                            </div>
                        </div>
                        <?php if (empty($monitor_rules)): ?>
                        <div class="small text-muted">ยังไม่มีกฎที่เปิดใช้งาน — ไปที่แท็บ <b>ตั้งค่า Drug Interaction</b> เพื่อเพิ่มกฎ</div>
                        <?php else: ?>
                        <div class="row g-2" id="diRuleCheckboxes">
                            <?php foreach ($monitor_rules as $mr):
                                $lvl = di_alert_level_from_row($mr);
                                $lvl_badge = $lvl === 'hard'
                                    ? '<span class="badge bg-danger ms-1">Hard</span>'
                                    : '<span class="badge bg-warning text-dark ms-1">Soft</span>';
                            ?>
                            <div class="col-md-6 col-xl-4">
                                <div class="form-check border rounded px-2 py-1 bg-white h-100">
                                    <input class="form-check-input di-rule-cb" type="checkbox"
                                           value="<?php echo (int)$mr['id']; ?>"
                                           data-icode="<?php echo htmlspecialchars($mr['drug_icode'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                           data-drug="<?php echo htmlspecialchars($mr['drug_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                           id="di_rule_cb_<?php echo (int)$mr['id']; ?>" checked>
                                    <label class="form-check-label small di-rule-cb-label" for="di_rule_cb_<?php echo (int)$mr['id']; ?>">
                                        <span class="text-primary fw-bold"><?php echo htmlspecialchars($mr['drug_name']); ?></span>
                                        <i class="fas fa-arrows-left-right text-muted mx-1"></i>
                                        <span class="text-danger fw-bold"><?php echo htmlspecialchars($mr['hosxp_drug_name']); ?></span>
                                        <?php echo $lvl_badge; ?>
                                    </label>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="section-block mb-4">
                        <h6 class="fw-bold text-danger mb-2"><i class="fas fa-exclamation-circle me-2"></i>Hard Alert <span id="blockCount" class="badge bg-danger">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center">
                                    <tr>
                                        <th>HN</th><th class="text-start">ชื่อ-สกุล</th>
                                        <th class="text-start">ยาที่ 1 (วันที่ · qty · วิธีใช้)</th>
                                        <th class="text-start">ยาที่ 2 (วันที่ · qty · วิธีใช้)</th>
                                        <th>Alert</th>
                                        <th class="text-start" style="min-width:300px">รายละเอียด / วิธีตรวจ</th><th>จัดการ</th>
                                    </tr>
                                </thead>
                                <tbody id="blockTbody"><tr><td colspan="7" class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</td></tr></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="section-warn mb-4">
                        <h6 class="fw-bold text-warning mb-2"><i class="fas fa-exclamation-triangle me-2"></i>Soft Alert <span id="warnCount" class="badge bg-warning text-dark">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center">
                                    <tr>
                                        <th>HN</th><th class="text-start">ชื่อ-สกุล</th>
                                        <th class="text-start">ยาที่ 1 (วันที่ · qty · วิธีใช้)</th>
                                        <th class="text-start">ยาที่ 2 (วันที่ · qty · วิธีใช้)</th>
                                        <th>Alert</th>
                                        <th class="text-start" style="min-width:300px">รายละเอียด / วิธีตรวจ</th><th>จัดการ</th>
                                    </tr>
                                </thead>
                                <tbody id="warnTbody"><tr><td colspan="7" class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade <?php echo (isset($_GET['tab']) && $_GET['tab'] === 'settings') ? 'show active' : ''; ?>" id="settings">
                    <div class="alert alert-light border small mb-4">
                        <i class="fas fa-info-circle text-primary me-2"></i>
                        <b>การตั้งค่า:</b> เลือก <b>ยาที่ 1 และยาที่ 2 จาก HOSxP</b> (แสดงชื่อจาก TMT code)
                        กำหนดระดับการเตือน (Hard / Soft Alert) รายละเอียดทางคลินิก และเลือกรูปแบบการตรวจ —
                        <b>Visit เดียวกัน</b> หรือ <b>ย้อนหลังตามจำนวนวัน</b>
                    </div>

                    <div class="row">
                        <div class="col-lg-5 border-end">
                            <div class="card shadow-sm border-0" id="diFormCard">
                                <div class="card-header bg-danger text-white py-2 fw-bold" id="diFormHeader">
                                    <i class="fas fa-plus-circle me-1" id="diFormIcon"></i> <span id="diFormTitle">เพิ่มกฎ Drug Interaction</span>
                                </div>
                                <div class="card-body">
                                    <form method="POST" action="monitor_drug_interaction.php" id="diRuleForm">
                                        <input type="hidden" name="action" id="di_form_action" value="add_di">
                                        <input type="hidden" name="rule_id" id="di_rule_id" value="">

                                        <div class="mb-3">
                                            <label class="form-label fw-bold small">ชื่อยา 1 — จาก HOSxP (TMT)</label>
                                            <select name="drug_a" id="drug_a" class="form-select select2-hosxp" required><?php echo $opt_hosxp_drugs_a; ?></select>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label fw-bold small">ชื่อยา 2 — จาก HOSxP (TMT)</label>
                                            <select name="drug_b" id="drug_b" class="form-select select2-hosxp" required><?php echo $opt_hosxp_drugs_b; ?></select>
                                        </div>

                                        <div class="row g-2 mb-3">
                                            <div class="col-5">
                                                <label class="form-label fw-bold small">ระดับการเตือน</label>
                                                <select name="alert_level" id="alert_level" class="form-select form-select-sm fw-bold" required>
                                                    <option value="soft" class="text-warning">🟡 Soft Alert</option>
                                                    <option value="hard" class="text-danger">🔴 Hard Alert</option>
                                                </select>
                                            </div>
                                            <div class="col-7">
                                                <label class="form-label fw-bold small">ประเภท</label>
                                                <select name="interaction_type" id="interaction_type" class="form-select form-select-sm" required>
                                                    <?php foreach ($type_options as $k => $lbl): ?>
                                                    <option value="<?php echo htmlspecialchars($k); ?>"><?php echo htmlspecialchars($lbl); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label fw-bold small">รายละเอียด / effect (แสดงใน PDF)</label>
                                            <textarea name="detail_text" id="detail_text" class="form-control" rows="5" placeholder="Effect: ...&#10;Mechanism: ...&#10;Management: ..."></textarea>
                                        </div>

                                        <div class="border rounded p-3 mb-3">
                                            <label class="form-label fw-bold small d-block mb-2"><i class="fas fa-file-pdf me-1 text-danger"></i> ข้อมูลเอกสาร PDF (Fatal DI)</label>
                                            <div class="row g-2 mb-2">
                                                <div class="col-4">
                                                    <label class="form-label small mb-1">onset</label>
                                                    <select name="pdf_onset" id="pdf_onset" class="form-select form-select-sm">
                                                        <?php foreach (di_pdf_onset_options() as $k => $lbl): ?>
                                                        <option value="<?php echo htmlspecialchars($k); ?>"><?php echo htmlspecialchars($lbl); ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="col-4">
                                                    <label class="form-label small mb-1">severity</label>
                                                    <select name="pdf_severity" id="pdf_severity" class="form-select form-select-sm">
                                                        <?php foreach (di_pdf_severity_options() as $k => $lbl): ?>
                                                        <option value="<?php echo htmlspecialchars($k); ?>"><?php echo htmlspecialchars($lbl); ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="col-4">
                                                    <label class="form-label small mb-1">documentation</label>
                                                    <select name="pdf_documentation" id="pdf_documentation" class="form-select form-select-sm">
                                                        <?php foreach (di_pdf_documentation_options() as $k => $lbl): ?>
                                                        <option value="<?php echo htmlspecialchars($k); ?>"><?php echo htmlspecialchars($lbl); ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <label class="form-label small mb-1">Reference</label>
                                            <textarea name="pdf_reference" id="pdf_reference" class="form-control form-control-sm" rows="2" placeholder="เช่น Micromedex drug interactions"></textarea>
                                            <small class="text-muted d-block mt-1">ใช้ในเอกสาร PDF คู่ยา Fatal DI — ถ้าไม่เลือก severity จะใช้ Hard = Contraindicated, Soft = Major</small>
                                        </div>

                                        <div class="border rounded p-3 mb-3">
                                            <label class="form-label fw-bold small d-block mb-2"><i class="fas fa-pills me-1"></i> เงื่อนไขขนาดยา (mg/วัน)</label>
                                            <div class="form-check form-switch mb-2">
                                                <input class="form-check-input" type="checkbox" id="use_dose1_condition" name="use_dose1_condition" value="1">
                                                <label class="form-check-label small fw-bold text-primary" for="use_dose1_condition">กำหนดขนาดยา 1 — mg/วันรวมที่สั่งใช้</label>
                                            </div>
                                            <div class="row g-2 mb-3 disabled-section" id="dose1Fields">
                                                <div class="col-6">
                                                    <input type="number" step="0.01" min="0" class="form-control form-control-sm" name="dose1_min" id="dose1_min" placeholder="ต่ำสุด mg/วัน">
                                                </div>
                                                <div class="col-6">
                                                    <input type="number" step="0.01" min="0" class="form-control form-control-sm" name="dose1_max" id="dose1_max" placeholder="สูงสุด mg/วัน">
                                                </div>
                                            </div>
                                            <div class="form-check form-switch mb-2">
                                                <input class="form-check-input" type="checkbox" id="use_dose2_condition" name="use_dose2_condition" value="1">
                                                <label class="form-check-label small fw-bold text-danger" for="use_dose2_condition">กำหนดขนาดยา 2 (ถ้าต้องการ)</label>
                                            </div>
                                            <div class="row g-2 disabled-section" id="dose2Fields">
                                                <div class="col-6">
                                                    <input type="number" step="0.01" min="0" class="form-control form-control-sm" name="dose2_min" id="dose2_min" placeholder="ต่ำสุด mg/วัน">
                                                </div>
                                                <div class="col-6">
                                                    <input type="number" step="0.01" min="0" class="form-control form-control-sm" name="dose2_max" id="dose2_max" placeholder="สูงสุด mg/วัน">
                                                </div>
                                            </div>
                                            <small class="text-muted d-block mt-2">
                                                อิง <b>mg/วันรวม</b> จากวิธีใช้ (strength × จำนวนเม็ด/วัน) — ไม่ใช่ strength บนฉลากอย่างเดียว<br>
                                                ตัวอย่าง <b>simvastatin 10 mg</b> + ต่ำสุด <b>20</b> สูงสุด <b>80</b>:<br>
                                                · 1 เม็ด/วัน = 10 mg/วัน → <span class="text-success">ไม่เตือน</span><br>
                                                · 2 เม็ด วันละ 1 ครั้ง = 20 mg/วัน → <span class="text-danger">เตือน</span><br>
                                                · ครึ่งเม็ด/วัน เช่น simvastatin 40 mg ครึ่งเม็ด = 20 mg/วัน → รองรับ<br>
                                                เลือก icode ตามฉลากที่สั่ง (10 mg หรือ 20 mg) แล้วกำหนดช่วง mg/วันรวมที่ต้องการ
                                            </small>
                                        </div>

                                        <div class="border rounded p-3 mb-3">
                                            <label class="form-label fw-bold small d-block mb-2"><i class="fas fa-clock me-1"></i> รูปแบบการตรวจจับ</label>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input" type="radio" name="check_mode" id="check_same_visit" value="same_visit" checked>
                                                <label class="form-check-label small fw-bold" for="check_same_visit">Visit เดียวกัน (VN เดียวกัน)</label>
                                            </div>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input" type="radio" name="check_mode" id="check_same_rx" value="same_rx">
                                                <label class="form-check-label small fw-bold" for="check_same_rx">ใบสั่งยาเดียวกันเท่านั้น</label>
                                                <div class="small text-muted ms-4">จับเมื่อยาทั้งสองอยู่ในใบสั่งเดียวกัน (order_no / วัน+เวลาสั่ง) — ไม่ดึงข้ามใบสั่งหรือ visit อื่น</div>
                                            </div>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input" type="radio" name="check_mode" id="check_lookback" value="lookback">
                                                <label class="form-check-label small fw-bold" for="check_lookback">ตรวจช่วงทับซ้อน (qty + วิธีใช้)</label>
                                            </div>
                                            <div class="lookback-wrap disabled-section" id="lookbackWrap">
                                                <label class="form-label small mb-1">ค้นหาย้อนหลังสูงสุด</label>
                                                <div class="input-group input-group-sm">
                                                    <input type="number" name="lookback_days" id="lookback_days" class="form-control" min="1" max="365" value="30" placeholder="เช่น 30">
                                                    <span class="input-group-text">วัน</span>
                                                </div>
                                                <small class="text-muted d-block mt-1">คำนวณ <b>จำนวนวันครอบคลุม</b> จาก qty ÷ ปริมาณต่อวัน (เช่น 55 เม็ด วันละ 1 เม็ด = 55 วัน) แล้วตรวจว่าช่วงให้ยาทั้งสองยาทับซ้อนกันหรือไม่ — qty 1 เม็ด = 1 วัน</small>
                                            </div>
                                        </div>

                                        <div class="form-check form-switch mb-3">
                                            <input class="form-check-input" type="checkbox" name="active_status" id="active_status" value="1" checked>
                                            <label class="form-check-label fw-bold small" for="active_status">เปิดใช้งานกฎนี้</label>
                                        </div>

                                        <div class="d-flex gap-2">
                                            <button type="submit" class="btn btn-danger flex-grow-1 fw-bold" id="di_btn_submit"><i class="fas fa-save me-1"></i> บันทึก</button>
                                            <button type="button" class="btn btn-secondary fw-bold d-none" id="di_btn_cancel" onclick="setDiAddMode()"><i class="fas fa-times me-1"></i> ยกเลิก</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-7 ps-lg-4 mt-4 mt-lg-0">
                            <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                                <h6 class="fw-bold text-secondary mb-0"><i class="fas fa-list me-2"></i>รายการ Drug Interaction ที่ตั้งไว้</h6>
                                <div class="d-flex gap-2">
                                    <form method="post" class="d-inline" onsubmit="return confirm('นำเข้าคู่ยา Fatal DI 23 คู่จากเอกสารจังหวัดสระแก้ว (จับคู่ icode จาก HOSxP อัตโนมัติ คู่ที่ซ้ำจะถูกข้าม)?');">
                                        <input type="hidden" name="action" value="import_fatal_di">
                                        <button type="submit" class="btn btn-sm btn-danger fw-bold">
                                            <i class="fas fa-file-import me-1"></i> นำเข้า Fatal DI 23 คู่
                                        </button>
                                    </form>
                                    <a href="monitor_drug_interaction_print.php" target="_blank" class="btn btn-sm btn-outline-danger fw-bold">
                                        <i class="fas fa-file-pdf me-1"></i> พิมพ์ PDF
                                    </a>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-sm align-middle small">
                                    <thead class="table-light text-center">
                                        <tr>
                                            <th>ID</th>
                                            <th class="text-start">ยา 1 → ยา 2</th>
                                            <th>Dose</th>
                                            <th>Alert</th>
                                            <th>การตรวจ</th>
                                            <th>สถานะ</th>
                                            <th>จัดการ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $tbl_exists = mysqli_query($con, "SHOW TABLES LIKE 'monitor_drug_interaction_settings'");
                                        if (!$tbl_exists || mysqli_num_rows($tbl_exists) === 0) {
                                            echo '<tr><td colspan="7" class="text-center text-danger py-3">ยังไม่มีตาราง — กรุณารัน <a href="upgrade.php">อัปเกรดฐานข้อมูล</a></td></tr>';
                                        } else {
                                            $q_rules = mysqli_query($con, "SELECT * FROM monitor_drug_interaction_settings ORDER BY drug_name ASC, hosxp_drug_name ASC");
                                            if (mysqli_num_rows($q_rules) === 0) {
                                                echo '<tr><td colspan="7" class="text-center text-muted py-3">ยังไม่มีการตั้งค่า Drug Interaction</td></tr>';
                                            } else {
                                                while ($r = mysqli_fetch_assoc($q_rules)) {
                                                    $cm = $r['check_mode'] ?? '';
                                                    if ($cm === 'lookback') {
                                                        $check_lbl = 'ย้อนหลัง ' . (int)$r['lookback_days'] . ' วัน';
                                                    } elseif ($cm === 'same_rx') {
                                                        $check_lbl = 'ใบสั่งยาเดียวกัน';
                                                    } else {
                                                        $check_lbl = 'Visit เดียวกัน';
                                                    }
                                                    $active_badge = !empty($r['active_status'])
                                                        ? '<span class="badge bg-success">เปิด</span>'
                                                        : '<span class="badge bg-secondary">ปิด</span>';
                                                    $dose1_lbl = di_dose_condition_label($r, 1);
                                                    $dose2_lbl = di_dose_condition_label($r, 2);
                                                    $rule_json = htmlspecialchars(json_encode([
                                                        'id' => (int)$r['id'],
                                                        'drug_a' => $r['drug_icode'] . '|' . $r['drug_name'],
                                                        'drug_b' => $r['hosxp_icode'] . '|' . $r['hosxp_drug_name'],
                                                        'alert_level' => di_alert_level_from_row($r),
                                                        'interaction_type' => $r['interaction_type'],
                                                        'detail_text' => $r['detail_text'] ?? '',
                                                        'check_mode' => $r['check_mode'],
                                                        'lookback_days' => (int)$r['lookback_days'],
                                                        'active_status' => (int)!empty($r['active_status']),
                                                        'use_dose1_condition' => (int)!empty($r['use_dose1_condition']),
                                                        'dose1_min' => $r['dose1_min'] ?? '',
                                                        'dose1_max' => $r['dose1_max'] ?? '',
                                                        'use_dose2_condition' => (int)!empty($r['use_dose2_condition']),
                                                        'dose2_min' => $r['dose2_min'] ?? '',
                                                        'dose2_max' => $r['dose2_max'] ?? '',
                                                        'pdf_onset' => $r['pdf_onset'] ?? '',
                                                        'pdf_severity' => $r['pdf_severity'] ?? '',
                                                        'pdf_documentation' => $r['pdf_documentation'] ?? '',
                                                        'pdf_reference' => $r['pdf_reference'] ?? '',
                                                    ], JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
                                                    echo '<tr class="di-rule-row" data-rule-id="' . (int)$r['id'] . '">';
                                                    echo '<td class="text-center">' . (int)$r['id'] . '</td>';
                                                    echo '<td class="text-start"><span class="fw-bold text-primary">' . htmlspecialchars($r['drug_name']) . '</span>';
                                                    echo ' <i class="fas fa-arrows-left-right text-muted mx-1"></i> ';
                                                    echo '<span class="fw-bold text-danger">' . htmlspecialchars($r['hosxp_drug_name']) . '</span>';
                                                    echo '<br><small class="text-muted">' . htmlspecialchars($r['drug_icode']) . ' ↔ ' . htmlspecialchars($r['hosxp_icode']) . '</small>';
                                                    echo '</td>';
                                                    echo '<td class="text-center small">';
                                                    if ($dose1_lbl !== '') {
                                                        echo '<span class="badge bg-primary d-block mb-1">ยา1: ' . htmlspecialchars($dose1_lbl) . '</span>';
                                                    }
                                                    if ($dose2_lbl !== '') {
                                                        echo '<span class="badge bg-danger d-block">ยา2: ' . htmlspecialchars($dose2_lbl) . '</span>';
                                                    }
                                                    if ($dose1_lbl === '' && $dose2_lbl === '') {
                                                        echo '<span class="text-muted">ไม่กำหนด</span>';
                                                    }
                                                    $dose_warn = di_dose_config_warning($r, 1);
                                                    if ($dose_warn !== '') {
                                                        echo '<small class="text-warning d-block mt-1"><i class="fas fa-exclamation-triangle me-1"></i>' . htmlspecialchars($dose_warn) . '</small>';
                                                    }
                                                    echo '</td>';
                                                    $lvl = di_alert_level_from_row($r);
                                                    echo '<td class="text-center">' . di_alert_badge_html($lvl) . '</td>';
                                                    echo '<td class="text-center small">' . htmlspecialchars($check_lbl) . '</td>';
                                                    echo '<td class="text-center">' . $active_badge . '</td>';
                                                    echo '<td class="text-center text-nowrap">';
                                                    echo '<button type="button" class="btn btn-sm btn-outline-primary di-btn-edit me-1" title="แก้ไข" data-rule="' . $rule_json . '"><i class="fas fa-edit"></i></button>';
                                                    echo '<button type="button" class="btn btn-sm btn-outline-secondary di-btn-copy me-1" title="คัดลอก" data-rule="' . $rule_json . '"><i class="fas fa-copy"></i></button>';
                                                    echo '<form method="POST" style="display:inline;" onsubmit="return confirm(\'ยืนยันลบกฎนี้?\');">';
                                                    echo '<input type="hidden" name="action" value="delete_di"><input type="hidden" name="del_id" value="' . (int)$r['id'] . '">';
                                                    echo '<button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button></form>';
                                                    echo '</td></tr>';
                                                }
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

            <div class="modal fade" id="mdiConsultModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold"><i class="fas fa-notes-medical me-2 text-danger"></i>บันทึก Intervention — Drug Interaction</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="small text-muted mb-2" id="mdiConsultCaseInfo"></div>
                            <div class="border rounded p-2 mb-3 bg-light">
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                                    <label class="form-label small fw-bold mb-0">
                                        <i class="fas fa-pills me-1 text-danger"></i>
                                        เลือกคู่ยาที่จะปรึกษา (HN เดียวกัน)
                                    </label>
                                    <div class="btn-group btn-group-sm">
                                        <button type="button" class="btn btn-outline-secondary" onclick="mdiTogglePairChecks(true)">เลือกทั้งหมด</button>
                                        <button type="button" class="btn btn-outline-secondary" onclick="mdiTogglePairChecks(false)">ยกเลิกทั้งหมด</button>
                                    </div>
                                </div>
                                <div id="mdiPairCheckList" class="small"></div>
                                <div class="form-text mb-0">ค่าเริ่มต้นเลือกทั้งหมด — ติ๊กเฉพาะคู่ยาที่ต้องการปรึกษาในใบนี้</div>
                            </div>
                            <div class="row g-2">
                                <div class="col-md-8">
                                    <label class="form-label small fw-bold">เภสัชกรที่ Consult</label>
                                    <select id="mdiPharmacist" class="form-select form-select-sm">
                                        <?php if (empty($pharmacist_options)): ?>
                                        <option value="">— ไม่พบผู้ใช้ตำแหน่งเภสัชกร —</option>
                                        <?php else: ?>
                                        <?php foreach ($pharmacist_options as $ph):
                                            $ph_name = trim((string)($ph['full_name'] ?: $ph['username']));
                                            $ph_pos = trim((string)($ph['entryposition'] ?? ''));
                                            $ph_label = $ph_pos !== '' ? ($ph_name . ' (' . $ph_pos . ')') : $ph_name;
                                        ?>
                                        <option value="<?php echo (int)$ph['id']; ?>"
                                            <?php echo ((int)$ph['id'] === $current_user_id) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($ph_label); ?>
                                        </option>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label small fw-bold">รอตอบกลับ</label>
                                    <select id="mdiReplyWait" class="form-select form-select-sm">
                                        <option value="0"<?php echo ((int)$mdi_reply_wait_days === 0) ? ' selected' : ''; ?>>ทันที</option>
                                        <?php for ($d = 1; $d <= 7; $d++): ?>
                                        <option value="<?php echo $d; ?>"<?php echo ((int)$mdi_reply_wait_days === $d) ? ' selected' : ''; ?>><?php echo $d; ?> วัน</option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">การแทรกแซง</label>
                                    <select id="mdiIvType" class="form-select form-select-sm">
                                        <option value="recommend">แนะนำ / Consult</option>
                                        <option value="adjust">ปรับยา</option>
                                        <option value="reject">ไม่จ่าย / Hold</option>
                                        <option value="followup">ติดตาม</option>
                                        <option value="document">บันทึกเท่านั้น</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">ใช่ความคลาดเคลื่อนไหม</label>
                                    <select id="mdiIvDeviation" class="form-select form-select-sm" onchange="AlertMute.sync('mdiIvDeviation')">
                                        <option value="">— ไม่ระบุ —</option>
                                        <option value="ความคลาดเคลื่อนจริง">ความคลาดเคลื่อนจริง</option>
                                        <option value="ไม่ใช่ความคลาดเคลื่อน">ไม่ใช่ความคลาดเคลื่อน</option>
                                    </select>
                                    <?php require_once __DIR__ . '/monitor_alert_mute_ui.php'; monitor_alert_mute_box('mdiIvDeviation'); ?>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold">หมายเหตุ</label>
                                    <textarea id="mdiConsultNote" class="form-control form-control-sm" rows="2" placeholder="รายละเอียดที่ต้องการบันทึกใน Intervention และใส่ในใบปรึกษา"></textarea>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold">รายละเอียดหลัง Consult <span class="fw-normal text-muted">(บันทึกภายหลังได้ใน Intervention Report)</span></label>
                                    <div class="d-flex flex-wrap gap-1 mb-1">
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mdiApplyConsultChip('แพทย์ Off')">แพทย์ Off</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mdiApplyConsultChip('แพทย์ Hold')">แพทย์ Hold</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mdiApplyConsultChip('แพทย์ลดขนาดยา')">แพทย์ลดขนาดยา</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mdiApplyConsultChip('แพทย์ให้ยาต่อ')">แพทย์ให้ยาต่อ</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mdiApplyConsultChip('')">อื่นๆ</button>
                                    </div>
                                    <textarea id="mdiIvConsult" class="form-control form-control-sm" rows="2" placeholder="เลือกตัวช่วยด้านบน หรือพิมพ์รายละเอียดเอง"></textarea>
                                </div>
                            </div>
                            <div id="mdiConsultMsg" class="alert mt-3 mb-0 py-2 small d-none"></div>
                        </div>
                        <div class="modal-footer flex-wrap">
                            <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิดหน้าต่าง</button>
                            <button type="button" class="btn btn-outline-info btn-sm fw-bold" onclick="mdiOpenHistory()">
                                <i class="fas fa-history me-1"></i> เปิดดูประวัติ
                            </button>
                            <button type="button" class="btn btn-outline-warning btn-sm fw-bold" onclick="mdiResetWaiting()">
                                ตั้งเป็นรอ Consult
                            </button>
                            <button type="button" class="btn btn-outline-success btn-sm fw-bold" onclick="mdiCloseConsult()">
                                ปิดการ Consult
                            </button>
                            <button type="button" class="btn btn-success btn-sm fw-bold" onclick="mdiSaveIntervention(true)">
                                <i class="fas fa-print me-1"></i> บันทึกและพิมพ์ใบปรึกษาแพทย์
                            </button>
                            <button type="button" class="btn btn-sm fw-bold text-white" style="background:#0d9488;" onclick="mdiSaveIntervention(false)">
                                บันทึก Intervention
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mdiHistoryModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-scrollable">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold"><i class="fas fa-history me-2 text-info"></i>ประวัติ Consult — Drug Interaction</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="small text-muted mb-2" id="mdiHistoryInfo"></div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>เวลา</th>
                                            <th>คู่ยา</th>
                                            <th>การดำเนินการ</th>
                                            <th>สถานะ</th>
                                            <th>กำหนดตอบกลับ</th>
                                            <th>ผู้ทำ</th>
                                            <th>หมายเหตุ</th>
                                        </tr>
                                    </thead>
                                    <tbody id="mdiHistoryBody">
                                        <tr><td colspan="7" class="text-center text-muted py-3">ยังไม่มีประวัติ</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">ปิด</button>
                        </div>
                    </div>
                </div>
            </div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/flatpickr.min.js"></script>
<script>
const MDI_CURRENT_USER_ID = <?php echo (int)$current_user_id; ?>;
const MDI_REPLY_WAIT = <?php echo (int)$mdi_reply_wait_days; ?>;
let lastHardGroups = [];
let lastSoftGroups = [];
let lastHardVisits = [];
let lastSoftVisits = [];
let mdiCurrentCase = null;
let mdiHnCases = [];
let mdiConsultModal = null;

function toggleLookbackWrap() {
    const isLb = $('#check_lookback').is(':checked');
    const $w = $('#lookbackWrap');
    if (isLb) {
        $w.removeClass('disabled-section');
        $('#lookback_days').prop('required', true);
    } else {
        $w.addClass('disabled-section');
        $('#lookback_days').prop('required', false);
    }
}

function toggleDiDoseFields(which) {
    const on = $('#use_dose' + which + '_condition').is(':checked');
    const $sec = $('#dose' + which + 'Fields');
    if (on) {
        $sec.removeClass('disabled-section');
        $('#dose' + which + '_min, #dose' + which + '_max').prop('required', true);
    } else {
        $sec.addClass('disabled-section');
        $('#dose' + which + '_min, #dose' + which + '_max').prop('required', false);
    }
}

function ensureSelectOption($sel, val, label) {
    if (!val) return;
    if ($sel.find('option').filter(function() { return this.value === val; }).length === 0) {
        $sel.append(new Option(label || val, val, true, true));
    }
}

function setDiAddMode() {
    document.getElementById('diRuleForm').reset();
    $('#di_form_action').val('add_di');
    $('#di_rule_id').val('');
    $('#diFormCard').removeClass('edit-mode copy-mode');
    $('#diFormHeader').removeClass('bg-primary bg-secondary').addClass('bg-danger');
    $('#diFormIcon').removeClass('fa-edit').addClass('fa-plus-circle');
    $('#diFormTitle').text('เพิ่มกฎ Drug Interaction');
    $('#di_btn_submit').removeClass('btn-primary').addClass('btn-danger').html('<i class="fas fa-save me-1"></i> บันทึก');
    $('#di_btn_cancel').addClass('d-none');
    $('#active_status').prop('checked', true);
    $('#check_same_visit').prop('checked', true);
    $('#use_dose1_condition, #use_dose2_condition').prop('checked', false);
    $('#pdf_onset, #pdf_severity, #pdf_documentation').val('');
    $('#pdf_reference').val('');
    $('.select2-hosxp').val(null).trigger('change');
    toggleLookbackWrap();
    toggleDiDoseFields(1);
    toggleDiDoseFields(2);
    $('tr.di-editing-row').removeClass('di-editing-row');
}

function fillDiRuleForm(rule) {
    ensureSelectOption($('#drug_a'), rule.drug_a, rule.drug_a);
    $('#drug_a').val(rule.drug_a).trigger('change');
    ensureSelectOption($('#drug_b'), rule.drug_b, rule.drug_b);
    $('#drug_b').val(rule.drug_b).trigger('change');

    $('#alert_level').val(rule.alert_level === 'hard' ? 'hard' : 'soft');
    $('#interaction_type').val(rule.interaction_type);
    $('#detail_text').val(rule.detail_text || '');
    $('#active_status').prop('checked', !!rule.active_status);

    if (rule.check_mode === 'lookback') {
        $('#check_lookback').prop('checked', true);
        $('#lookback_days').val(rule.lookback_days || 7);
    } else if (rule.check_mode === 'same_rx') {
        $('#check_same_rx').prop('checked', true);
        $('#lookback_days').val(rule.lookback_days || 7);
    } else {
        $('#check_same_visit').prop('checked', true);
        $('#lookback_days').val(rule.lookback_days || 7);
    }
    $('#use_dose1_condition').prop('checked', !!rule.use_dose1_condition);
    $('#dose1_min').val(rule.dose1_min ?? '');
    $('#dose1_max').val(rule.dose1_max ?? '');
    $('#use_dose2_condition').prop('checked', !!rule.use_dose2_condition);
    $('#dose2_min').val(rule.dose2_min ?? '');
    $('#dose2_max').val(rule.dose2_max ?? '');
    $('#pdf_onset').val(rule.pdf_onset || '');
    $('#pdf_severity').val(rule.pdf_severity || '');
    $('#pdf_documentation').val(rule.pdf_documentation || '');
    $('#pdf_reference').val(rule.pdf_reference || '');
    toggleLookbackWrap();
    toggleDiDoseFields(1);
    toggleDiDoseFields(2);
}

function setDiEditMode(rule) {
    $('#di_form_action').val('edit_di');
    $('#di_rule_id').val(rule.id);
    $('#diFormCard').removeClass('copy-mode').addClass('edit-mode');
    $('#diFormHeader').removeClass('bg-danger bg-secondary').addClass('bg-primary');
    $('#diFormIcon').removeClass('fa-plus-circle fa-copy').addClass('fa-edit');
    $('#diFormTitle').text('แก้ไขกฎ (ID: ' + rule.id + ')');
    $('#di_btn_submit').removeClass('btn-danger btn-secondary').addClass('btn-primary').html('<i class="fas fa-save me-1"></i> บันทึกการแก้ไข');
    $('#di_btn_cancel').removeClass('d-none');

    fillDiRuleForm(rule);

    $('tr.di-editing-row').removeClass('di-editing-row');
    $('tr.di-rule-row[data-rule-id="' + rule.id + '"]').addClass('di-editing-row');
    document.getElementById('diFormCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function setDiCopyMode(rule) {
    $('#di_form_action').val('add_di');
    $('#di_rule_id').val('');
    $('#diFormCard').removeClass('edit-mode').addClass('copy-mode');
    $('#diFormHeader').removeClass('bg-primary bg-danger').addClass('bg-secondary');
    $('#diFormIcon').removeClass('fa-edit fa-plus-circle').addClass('fa-copy');
    $('#diFormTitle').text('คัดลอกกฎจาก ID: ' + rule.id);
    $('#di_btn_submit').removeClass('btn-primary btn-danger').addClass('btn-secondary').html('<i class="fas fa-save me-1"></i> บันทึกกฎใหม่');
    $('#di_btn_cancel').removeClass('d-none');

    fillDiRuleForm(rule);

    $('tr.di-editing-row').removeClass('di-editing-row');
    $('tr.di-rule-row[data-rule-id="' + rule.id + '"]').addClass('di-editing-row');
    document.getElementById('diFormCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function diEsc(str) {
    if (!str && str !== 0) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function renderDIDrugCell(v, which) {
    const is1 = which === 1;
    const name = diEsc(is1 ? v.drug1_name : v.drug2_name);
    const date = diEsc(is1 ? (v.drug1_date || v.vstdate || '-') : (v.drug2_date || '-'));
    const time = diEsc(is1 ? (v.drug1_time || '') : (v.drug2_time || ''));
    const qty = diEsc(is1 ? v.dose1_qty : v.dose2_qty);
    const cov = diEsc(is1 ? v.drug1_coverage_days : v.drug2_coverage_days);
    const covEnd = diEsc(is1 ? v.drug1_coverage_end : v.drug2_coverage_end);
    const method = diEsc(is1 ? (v.drug1_method || '') : (v.drug2_method || ''));
    const daily = is1 ? v.drug1_daily_dose : v.drug2_daily_dose;
    const dailyMg = diEsc(is1 ? (v.drug1_daily_mg || '') : (v.drug2_daily_mg || ''));
    const color = is1 ? 'text-primary' : 'text-danger';
    const badge = is1 ? 'bg-primary' : 'bg-danger';
    let covLine = '';
    if (cov) {
        covLine = `<div class="small text-success fw-bold"><i class="fas fa-hourglass-half me-1"></i>ครอบคลุม ${cov} วัน${covEnd ? ` (ถึง ${covEnd})` : ''}</div>`;
    }
    let methodLine = `<div class="small mt-2 p-2 rounded border bg-light lh-sm" style="max-width:300px">`;
    methodLine += `<div class="fw-bold text-secondary mb-1"><i class="fas fa-prescription-bottle-alt me-1"></i>วิธีใช้</div>`;
    methodLine += method
        ? `<div class="text-dark">${method}</div>`
        : `<div class="text-muted fst-italic">ไม่พบข้อมูลวิธีใช้</div>`;
    if (dailyMg) {
        methodLine += `<div class="text-success fw-bold mt-1"><i class="fas fa-weight me-1"></i>${dailyMg}</div>`;
    }
    if (daily !== null && daily !== undefined && daily !== '') {
        methodLine += `<div class="text-warning-emphasis fw-bold mt-1">≈ ${daily} หน่วย/วัน → ใช้คำนวณครอบคลุม</div>`;
    }
    methodLine += `</div>`;
    return `<div class="${color} fw-bold">${name}</div>
        <div class="small mt-1"><i class="far fa-calendar-alt me-1"></i><span class="fw-bold">${date}</span>${time ? ` <span class="text-muted">${time} น.</span>` : ''}</div>
        <div class="small fw-bold text-muted mt-1">qty: <span class="text-dark">${qty}</span></div>
        ${methodLine}
        ${covLine}
        <span class="badge ${badge} mt-1">ยา ${which}</span>`;
}

function diNormHn(s) {
    const d = String(s || '').replace(/\D+/g, '').replace(/^0+/, '');
    return d === '' ? '0' : d;
}

function diFocusHn() {
    if ($('#filter_hn').length) {
        return String($('#filter_hn').val() || '').trim();
    }
    return diUrlParam('hn');
}

function diUrlParam(name) {
    return String(new URLSearchParams(location.search).get(name) || '').trim();
}

function diFilterGroupsByHn(groups) {
    const hn = diFocusHn();
    const want = diNormHn(hn);
    if (!hn || want === '0') return groups || [];
    return (groups || []).filter(function(g) {
        return diNormHn(g.hn) === want;
    }).map(function(g) {
        return {
            hn: g.hn,
            ptname: g.ptname,
            visits: (g.visits || []).filter(function(v) {
                return !v.hn || diNormHn(v.hn) === want;
            })
        };
    }).filter(function(g) { return (g.visits || []).length > 0; });
}

function renderDITable(groups, tbodyId, emptyMsg, which) {
    if (!groups || groups.length === 0) {
        $(tbodyId).html('<tr><td colspan="7" class="text-center py-4 text-success fw-bold"><i class="fas fa-check-circle me-2"></i>' + emptyMsg + '</td></tr>');
        return;
    }
    let html = '';
    let idx = 0;
    groups.forEach(grp => {
        html += '<tr class="hn-group-header"><td colspan="7"><i class="fas fa-user-injured me-2 text-primary"></i>HN: <b>' + diEsc(grp.hn) + '</b> — ' + diEsc(grp.ptname) + '</td></tr>';
        grp.visits.forEach(v => {
            const visitIdx = idx++;
            const sevBadge = v.alert_level === 'hard'
                ? '<span class="badge bg-danger">Hard Alert</span>'
                : '<span class="badge bg-warning text-dark">Soft Alert</span>';
            const detail = diEsc(v.detail_text || '');
            const meta = diEsc(v.check_mode_label || '');
            html += '<tr class="visit-row">';
            html += '<td class="text-center small text-muted">↳ ' + diEsc(grp.hn) + '</td>';
            html += '<td class="small">' + diEsc(grp.ptname) + '</td>';
            html += '<td class="small align-top">' + renderDIDrugCell(v, 1) + '</td>';
            html += '<td class="small align-top">' + renderDIDrugCell(v, 2) + '</td>';
            html += '<td class="text-center align-top">' + sevBadge + '</td>';
            html += '<td class="small align-top di-detail-cell">';
            html += '<div class="di-detail-label mb-1"><i class="fas fa-file-medical me-1"></i>รายละเอียด</div>';
            html += '<div class="di-detail-text">' + (detail || '<span class="text-muted">-</span>') + '</div>';
            html += '<div class="di-detail-label mt-2 mb-1"><i class="fas fa-search me-1"></i>วิธีตรวจ</div>';
            html += '<div class="di-check-meta">' + (meta || '<span class="text-muted fw-normal">-</span>') + '</div>';
            html += '</td>';
            html += '<td class="text-center align-top di-action-cell">';
            html += '<div class="mb-1">' + mdiConsultBadge(v.consult) + '</div>';
            html += '<button type="button" class="btn btn-sm btn-success fw-bold py-0 px-2 mb-1" title="บันทึก Intervention และพิมพ์ใบปรึกษาแพทย์ได้จากฟอร์มนี้" onclick="mdiOpenConsult(\'' + which + '\',' + visitIdx + ')"><i class="fas fa-notes-medical me-1"></i>บันทึก Intervention</button>';
            html += '<div>';
            html += '<a href="smart_drug.php?hn=' + encodeURIComponent(grp.hn) + '" target="_blank" class="btn btn-sm btn-dark py-0 me-1" title="ดูรายละเอียดยา"><i class="fas fa-search"></i></a>';
            html += '<button type="button" class="btn btn-sm btn-outline-info py-0" title="ประวัติการปรึกษาแพทย์" onclick="mdiOpenHistoryFromRow(\'' + which + '\',' + visitIdx + ')"><i class="fas fa-history"></i></button>';
            html += '</div>';
            html += '</td>';
            html += '</tr>';
        });
    });
    $(tbodyId).html(html);
}

const DI_PARALLEL = 3;
let diFetchGen = 0;
let diAbortCtl = null;

function getSelectedDiRuleIds() {
    return $('.di-rule-cb:checked').map(function() { return this.value; }).get();
}

function getSelectedDiDrugJobs() {
    const byKey = {};
    $('.di-rule-cb:checked').each(function() {
        const id = String($(this).val() || '');
        const icode = String($(this).data('icode') || '').trim();
        const name = String($(this).data('drug') || '').trim();
        const key = icode !== '' ? icode : ('id:' + id);
        if (!byKey[key]) {
            byKey[key] = { icode: icode, name: name, ids: [] };
        }
        byKey[key].ids.push(id);
        if (name && !byKey[key].name) {
            byKey[key].name = name;
        }
    });
    return Object.keys(byKey).map(function(k) { return byKey[k]; });
}

function diSelectAllRules(checked) {
    $('.di-rule-cb').prop('checked', checked);
    diUpdateRuleSelectedCount();
}

function diUpdateRuleSelectedCount() {
    const total = $('.di-rule-cb').length;
    const sel = getSelectedDiRuleIds().length;
    $('#diRuleSelectedCount').text(total > 0 ? '(เลือก ' + sel + ' / ' + total + ' คู่)' : '');
}

function printDIRulesPdf() {
    const ids = getSelectedDiRuleIds();
    if (ids.length === 0) {
        alert('กรุณาเลือกอย่างน้อย 1 คู่ยาที่ต้องการพิมพ์');
        return;
    }
    window.open('monitor_drug_interaction_print.php?ids=' + encodeURIComponent(ids.join(',')) + '&autoprint=1', '_blank');
}

function diFriendlyFetchError(text, status) {
    const raw = String(text || '');
    if (status === 504 || /504|Gateway Time-out/i.test(raw)) {
        return 'ประมวลผลนานเกินกำหนด (504) — ลองย่อช่วงวันที่ หรือเลือกคู่น้อยลง';
    }
    if (status === 502 || /Bad Gateway/i.test(raw)) {
        return 'เซิร์ฟเวอร์ไม่ตอบ (502) — ลองใหม่ในอีกสักครู่';
    }
    const stripped = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    return (stripped || ('HTTP ' + status)).substring(0, 240);
}

function diAddGroups(map, groups) {
    (groups || []).forEach(function(g) {
        const hn = String(g.hn || '');
        if (!hn) return;
        if (!map[hn]) {
            map[hn] = { hn: hn, ptname: g.ptname || '', visits: [] };
        } else if (!map[hn].ptname && g.ptname) {
            map[hn].ptname = g.ptname;
        }
        map[hn].visits.push.apply(map[hn].visits, g.visits || []);
    });
}

function diGroupsArray(map) {
    return Object.keys(map).sort().map(function(hn) { return map[hn]; });
}

function diCountVisits(map) {
    let n = 0;
    Object.keys(map).forEach(function(hn) {
        n += (map[hn].visits || []).length;
    });
    return n;
}

function diFlattenVisits(groups) {
    const out = [];
    (groups || []).forEach(function(g) {
        (g.visits || []).forEach(function(v) {
            if (!v.hn) v.hn = g.hn;
            if (!v.ptname) v.ptname = g.ptname;
            out.push(v);
        });
    });
    return out;
}

function diPaintMonitor(agg, isFinal) {
    const hard = diFilterGroupsByHn(diGroupsArray(agg.blockByHn));
    const soft = diFilterGroupsByHn(diGroupsArray(agg.warnByHn));
    lastHardGroups = hard;
    lastSoftGroups = soft;
    lastHardVisits = diFlattenVisits(hard);
    lastSoftVisits = diFlattenVisits(soft);
    const hardN = diCountVisitsFromGroups(hard);
    const softN = diCountVisitsFromGroups(soft);
    const hn = diFocusHn();
    $('#blockCount').text(hardN);
    $('#warnCount').text(softN);
    const emptyHard = hn ? ('ไม่พบรายการ Block ของ HN ' + diEsc(hn) + ' ในช่วงเวลานี้') : 'ไม่พบรายการ Block ในช่วงเวลานี้';
    const emptySoft = hn ? ('ไม่พบรายการ Warning ของ HN ' + diEsc(hn) + ' ในช่วงเวลานี้') : 'ไม่พบรายการ Warning ในช่วงเวลานี้';
    if (hardN === 0) {
        $('#blockTbody').html(isFinal
            ? '<tr><td colspan="7" class="text-center py-4 text-success fw-bold"><i class="fas fa-check-circle me-2"></i>' + emptyHard + '</td></tr>'
            : '<tr><td colspan="7" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังตรวจทีละคู่ยา...</td></tr>');
    } else {
        renderDITable(hard, '#blockTbody', emptyHard, 'hard');
    }
    if (softN === 0) {
        $('#warnTbody').html(isFinal
            ? '<tr><td colspan="7" class="text-center py-4 text-success fw-bold"><i class="fas fa-check-circle me-2"></i>' + emptySoft + '</td></tr>'
            : '<tr><td colspan="7" class="text-center py-4 text-muted">กำลังตรวจ...</td></tr>');
    } else {
        renderDITable(soft, '#warnTbody', emptySoft, 'soft');
    }
}

function diCountVisitsFromGroups(groups) {
    let n = 0;
    (groups || []).forEach(function(g) { n += (g.visits || []).length; });
    return n;
}

async function diPostJob(job, signal) {
    const r = await fetch('fetch_drug_interaction_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        signal: signal,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams({
            start_date: $('#filter_start').val() || '',
            end_date: $('#filter_end').val() || '',
            rule_ids: job.ids.join(','),
            hn: diFocusHn()
        })
    });
    const text = await r.text();
    let data;
    try {
        data = JSON.parse(text);
    } catch (e) {
        throw new Error(diFriendlyFetchError(text, r.status));
    }
    if (!r.ok && data.status !== 'success') {
        throw new Error(data.message || diFriendlyFetchError(text, r.status));
    }
    return data;
}

async function fetchDIData() {
    const jobs = getSelectedDiDrugJobs();
    if (jobs.length === 0) {
        alert('กรุณาเลือกอย่างน้อย 1 คู่ยาที่ต้องการรายงาน');
        return;
    }

    const gen = ++diFetchGen;
    if (diAbortCtl) {
        try { diAbortCtl.abort(); } catch (e) {}
    }
    const ac = new AbortController();
    diAbortCtl = ac;

    const t0 = Date.now();
    const agg = {
        blockByHn: {},
        warnByHn: {},
        orders_scanned: 0,
        rules_selected: 0,
        rules_total: 0,
        truncated: false,
        high_volume: false
    };
    const failed = [];
    let done = 0;
    let lastPaint = 0;
    const workers = Math.min(DI_PARALLEL, jobs.length);
    const loading = '<tr><td colspan="7" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังตรวจทีละคู่ยา (พร้อมกัน ' + workers + ' รายการ)...</td></tr>';

    $('#btnFetchDI').prop('disabled', true);
    $('#blockTbody, #warnTbody').html(loading);
    $('#blockCount, #warnCount').text(0);
    $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info')
        .html('<i class="fas fa-spinner fa-spin me-1"></i> เริ่มตรวจ 0/' + jobs.length + ' ยา (พร้อมกัน ' + workers + ' รายการ)');

    function updateMeta(currentName, isFinal) {
        if (gen !== diFetchGen) return;
        const sec = ((Date.now() - t0) / 1000).toFixed(1);
        const hardN = diCountVisits(agg.blockByHn);
        const softN = diCountVisits(agg.warnByHn);
        const hnN = Object.keys(Object.assign({}, agg.blockByHn, agg.warnByHn)).length;
        let html = '<i class="fas fa-info-circle me-1"></i> ตรวจแล้ว ' + done + '/' + jobs.length + ' ยา'
            + ' | พร้อมกัน ' + workers + ' รายการ'
            + ' | กฎที่เลือก: ' + agg.rules_selected
            + (agg.rules_total ? ' / ' + agg.rules_total : '')
            + ' | Hard Alert: ' + hardN
            + ' | Soft Alert: ' + softN
            + ' | สแกน order: ' + agg.orders_scanned + ' รายการ'
            + ' (HN ' + hnN + ' ราย)'
            + ' | ' + sec + ' วินาที';
        if (!isFinal && currentName) html += ' | ล่าสุด: ' + diEsc(currentName);
        if (agg.high_volume) html += ' <span class="text-warning">(กฎ/ยามาก — แนะนำลดจำนวนกฎที่เปิดใช้หรือใช้ Visit เดียวกัน)</span>';
        if (agg.truncated) html += ' <span class="text-danger">(เกิน limit — ลดช่วงวันที่)</span>';
        if (failed.length) html += ' | <span class="text-danger">ไม่สำเร็จ ' + failed.length + ' ยา</span>';
        if (isFinal && failed.length) {
            html += '<div class="small fw-normal mt-1">' + failed.map(function(f) { return diEsc(f); }).join('<br>') + '</div>';
        }
        $('#reportMeta').toggleClass('alert-danger', failed.length > 0 && isFinal)
            .toggleClass('alert-info', !(failed.length > 0 && isFinal))
            .removeClass('d-none')
            .html(html);
    }

    async function runOne(job) {
        const data = await diPostJob(job, ac.signal);
        if (data.status !== 'success') {
            throw new Error(data.message || 'เกิดข้อผิดพลาด');
        }
        const m = data.meta || {};
        diAddGroups(agg.blockByHn, data.block_groups);
        diAddGroups(agg.warnByHn, data.warning_groups);
        agg.orders_scanned += m.orders_scanned || 0;
        agg.rules_selected += m.rules_selected || m.rule_count || 0;
        if (m.rules_total) agg.rules_total = m.rules_total;
        if (m.truncated) agg.truncated = true;
        if (m.high_volume) agg.high_volume = true;
    }

    let next = 0;
    async function worker() {
        while (next < jobs.length) {
            if (gen !== diFetchGen) return;
            const job = jobs[next++];
            try {
                await runOne(job);
            } catch (err) {
                if (err && err.name === 'AbortError') throw err;
                failed.push((job.name || job.icode || job.ids.join(',')) + ' — ' + (err && err.message ? err.message : 'เชื่อมต่อไม่สำเร็จ'));
            }
            done++;
            updateMeta(job.name, false);
            if (done - lastPaint >= 3 || done === jobs.length) {
                lastPaint = done;
                diPaintMonitor(agg, false);
            }
        }
    }

    try {
        await Promise.all(Array.from({ length: workers }, worker));
    } catch (err) {
        if (err && err.name === 'AbortError') return;
        if (gen !== diFetchGen) return;
        $('#btnFetchDI').prop('disabled', false);
        const msg = (err && err.message) ? err.message : 'เชื่อมต่อ API ไม่สำเร็จ';
        $('#blockTbody, #warnTbody').html('<tr><td colspan="7" class="text-center text-danger py-4">' + diEsc(msg) + '</td></tr>');
        return;
    }

    if (gen !== diFetchGen) return;
    $('#btnFetchDI').prop('disabled', false);
    diPaintMonitor(agg, true);
    updateMeta('', true);
    mdiMaybeOpenConsultFromUrl();
}

$(document).ready(function() {
    $('.select2-hosxp').select2({ theme: 'bootstrap-5', width: '100%' });
    $('input[name="check_mode"]').on('change', toggleLookbackWrap);
    $('#use_dose1_condition').on('change', function() { toggleDiDoseFields(1); });
    $('#use_dose2_condition').on('change', function() { toggleDiDoseFields(2); });
    toggleLookbackWrap();
    toggleDiDoseFields(1);
    toggleDiDoseFields(2);

    function parseDiRuleData(el) {
        let rule = $(el).data('rule');
        if (typeof rule === 'string') {
            try { rule = JSON.parse(rule); } catch (e) { return null; }
        }
        return rule && rule.id ? rule : null;
    }

    $(document).on('click', '.di-btn-edit', function() {
        const rule = parseDiRuleData(this);
        if (!rule) return;
        setDiEditMode(rule);
    });

    $(document).on('click', '.di-btn-copy', function() {
        const rule = parseDiRuleData(this);
        if (!rule) return;
        setDiCopyMode(rule);
    });

    $(document).on('change', '.di-rule-cb', diUpdateRuleSelectedCount);
    diUpdateRuleSelectedCount();

    flatpickr('#filter_start', { dateFormat: 'Y-m-d' });
    flatpickr('#filter_end', { dateFormat: 'Y-m-d' });

    const urlHn = diUrlParam('hn');
    const urlDate = diUrlParam('date');
    if (urlHn) {
        $('#filter_hn').val(urlHn);
        const vn = diUrlParam('vn');
        const an = diUrlParam('an');
        let banner = '<i class="fas fa-link me-1"></i> เปิดจาก Smart Pharma · HN <b>' + diEsc(urlHn) + '</b>';
        if (urlDate) banner += ' · วันที่ ' + diEsc(urlDate);
        if (vn) banner += ' · VN ' + diEsc(vn);
        if (an) banner += ' · AN ' + diEsc(an);
        banner += ' <a href="monitor_drug_interaction.php" class="ms-2">ดูทุก HN</a>';
        $('#diFocusBanner').removeClass('d-none').html(banner);
    }
    if (/^\d{4}-\d{2}-\d{2}$/.test(urlDate)) {
        setDIDateRangeTo(urlDate, urlDate);
    } else {
        setDIDateRange(30);
    }
    if (urlHn) {
        fetchDIData();
    }
});

function setDIDateRangeTo(startYmd, endYmd) {
    const fpStart = document.getElementById('filter_start')._flatpickr;
    const fpEnd = document.getElementById('filter_end')._flatpickr;
    if (fpStart) fpStart.setDate(startYmd, true); else $('#filter_start').val(startYmd);
    if (fpEnd) fpEnd.setDate(endYmd, true); else $('#filter_end').val(endYmd);
    $('.di-range-btn').removeClass('active');
}

function setDIDateRange(days) {
    const end = new Date();
    const start = new Date();
    if (days <= 1) {
        start.setHours(0, 0, 0, 0);
    } else {
        start.setDate(end.getDate() - (days - 1));
    }
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const fpStart = document.getElementById('filter_start')._flatpickr;
    const fpEnd = document.getElementById('filter_end')._flatpickr;
    if (fpStart) fpStart.setDate(fmt(start), true); else $('#filter_start').val(fmt(start));
    if (fpEnd) fpEnd.setDate(fmt(end), true); else $('#filter_end').val(fmt(end));
    $('.di-range-btn').removeClass('active');
    $('.di-range-btn[data-days="' + days + '"]').addClass('active');
}

function mdiConsultBadge(c) {
    c = c || {};
    var st = c.status || 'waiting';
    var label = c.status_label || 'รอ Consult';
    var cls = 'bg-warning text-dark';
    var extra = '';
    if (st === 'in_progress') {
        cls = 'bg-primary';
        if (c.reply_due_at) extra = '<div class="small text-muted">ตอบภายใน ' + diEsc(c.reply_due_at) + '</div>';
        else if (Number(c.reply_wait_days) === 0) extra = '<div class="small text-muted">ทันที</div>';
    } else if (st === 'closed') {
        cls = 'bg-success';
    }
    return '<span class="badge ' + cls + '">' + diEsc(label) + '</span>' + extra;
}
function mdiVisitFromRow(which, idx) {
    var arr = which === 'soft' ? lastSoftVisits : lastHardVisits;
    return (arr || [])[idx] || null;
}
function mdiAllVisits() {
    return (lastHardVisits || []).concat(lastSoftVisits || []);
}
function mdiRerenderAlerts() {
    var hn = diFocusHn();
    var emptyHard = hn ? ('ไม่พบรายการ Block ของ HN ' + diEsc(hn) + ' ในช่วงเวลานี้') : 'ไม่พบรายการ Block ในช่วงเวลานี้';
    var emptySoft = hn ? ('ไม่พบรายการ Warning ของ HN ' + diEsc(hn) + ' ในช่วงเวลานี้') : 'ไม่พบรายการ Warning ในช่วงเวลานี้';
    if (!lastHardGroups.length) {
        $('#blockTbody').html('<tr><td colspan="7" class="text-center py-4 text-muted">' + emptyHard + '</td></tr>');
        $('#blockCount').text(0);
    } else {
        renderDITable(lastHardGroups, '#blockTbody', emptyHard, 'hard');
        $('#blockCount').text(diCountVisitsFromGroups(lastHardGroups));
    }
    if (!lastSoftGroups.length) {
        $('#warnTbody').html('<tr><td colspan="7" class="text-center py-4 text-muted">' + emptySoft + '</td></tr>');
        $('#warnCount').text(0);
    } else {
        renderDITable(lastSoftGroups, '#warnTbody', emptySoft, 'soft');
        $('#warnCount').text(diCountVisitsFromGroups(lastSoftGroups));
    }
}
function mdiTogglePairChecks(on) {
    document.querySelectorAll('.mdi-pair-cb').forEach(function(cb) { cb.checked = !!on; });
}
function mdiRenderPairChecks(cases) {
    var box = document.getElementById('mdiPairCheckList');
    if (!box) return;
    if (!cases.length) {
        box.innerHTML = '<div class="text-muted">ไม่พบคู่ยา</div>';
        return;
    }
    var html = '';
    cases.forEach(function(it, i) {
        var id = 'mdiPairCb' + i;
        var st = (it.consult && it.consult.status_label) ? it.consult.status_label : 'รอ Consult';
        html += '<div class="form-check border-bottom py-1">'
            + '<input class="form-check-input mdi-pair-cb" type="checkbox" id="' + id + '" data-idx="' + i + '" checked>'
            + '<label class="form-check-label" for="' + id + '">'
            + '<b>' + diEsc(it.drug1_name || '') + '</b> <i class="fas fa-arrows-left-right text-muted mx-1"></i> <b>' + diEsc(it.drug2_name || '') + '</b>'
            + ' <span class="text-muted">(' + diEsc(st) + ')</span>'
            + '</label></div>';
    });
    box.innerHTML = html;
}
function mdiMaybeOpenConsultFromUrl() {
    if (window._mdiConsultOpened || diUrlParam('consult') !== '1') return;
    if (!mdiAllVisits().length) return;
    window._mdiConsultOpened = true;
    var which = (lastHardVisits && lastHardVisits.length) ? 'hard' : 'soft';
    mdiOpenConsult(which, 0);
}
function mdiOpenConsult(which, idx) {
    var it = mdiVisitFromRow(which, idx);
    if (!it) return;
    mdiCurrentCase = it;
    mdiHnCases = mdiAllVisits().filter(function(x) { return diNormHn(x.hn) === diNormHn(it.hn); });
    if (!mdiHnCases.length) mdiHnCases = [it];
    var c = it.consult || {};
    document.getElementById('mdiConsultCaseInfo').innerHTML =
        '<b>HN ' + diEsc(it.hn) + '</b> · ' + diEsc(it.ptname)
        + (it.vn ? ' · VN ' + diEsc(it.vn) : '')
        + '<br>พบ Alert ในช่วงนี้ <b>' + mdiHnCases.length + '</b> คู่ยา — เลือกคู่ยาที่จะใส่ในใบปรึกษาด้านล่าง';
    mdiRenderPairChecks(mdiHnCases);
    mdiFillIntervention(c);
    document.getElementById('mdiReplyWait').value = String(MDI_REPLY_WAIT);
    var sel = document.getElementById('mdiPharmacist');
    if (c.pharmacist_user_id && sel.querySelector('option[value="' + c.pharmacist_user_id + '"]')) {
        sel.value = String(c.pharmacist_user_id);
    } else {
        sel.value = String(MDI_CURRENT_USER_ID);
    }
    if (window.AlertMute) {
        AlertMute.set('mdiIvDeviation', { hn: it.hn || '', vn: it.vn || '', an: it.an || '', patient_type: it.an ? 'IPD' : 'OPD' });
    }
    document.getElementById('mdiConsultMsg').className = 'alert mt-3 mb-0 py-2 small d-none';
    if (!mdiConsultModal) {
        mdiConsultModal = new bootstrap.Modal(document.getElementById('mdiConsultModal'));
    }
    mdiConsultModal.show();
}
function mdiSelectedCases() {
    var selected = [];
    document.querySelectorAll('.mdi-pair-cb:checked').forEach(function(cb) {
        var i = parseInt(cb.getAttribute('data-idx'), 10);
        if (!isNaN(i) && mdiHnCases[i]) selected.push(mdiHnCases[i]);
    });
    return selected;
}
function mdiCasesPayloadList() {
    return mdiSelectedCases().map(function(it) {
        return {
            hn: it.hn || '',
            vn: it.vn || '',
            ptname: it.ptname || '',
            vstdate: it.vstdate || '',
            rule_id: it.rule_id || 0,
            drug1_name: it.drug1_name || '',
            drug2_name: it.drug2_name || '',
            drug1_method: it.drug1_method || '',
            drug2_method: it.drug2_method || '',
            dose1_qty: it.dose1_qty == null ? '' : String(it.dose1_qty),
            dose2_qty: it.dose2_qty == null ? '' : String(it.dose2_qty),
            drug1_date: it.drug1_date || '',
            drug2_date: it.drug2_date || '',
            drug1_time: it.drug1_time || '',
            drug2_time: it.drug2_time || '',
            drug1_daily_mg: it.drug1_daily_mg || '',
            drug2_daily_mg: it.drug2_daily_mg || '',
            drug1_coverage_days: it.drug1_coverage_days == null ? '' : String(it.drug1_coverage_days),
            drug2_coverage_days: it.drug2_coverage_days == null ? '' : String(it.drug2_coverage_days),
            drug1_coverage_end: it.drug1_coverage_end || '',
            drug2_coverage_end: it.drug2_coverage_end || '',
            alert_level: it.alert_level || 'soft',
            interaction_type: it.interaction_type || '',
            detail_text: it.detail_text || '',
            check_mode_label: it.check_mode_label || '',
            case_key: it.case_key || '',
            consult_id: (it.consult && it.consult.id) ? it.consult.id : 0
        };
    });
}
function mdiApplyConsultChip(text) {
    var box = document.getElementById('mdiIvConsult');
    if (!box) return;
    var phrase = String(text || '').trim();
    if (!phrase) {
        box.focus();
        return;
    }
    var cur = box.value.replace(/\s+$/, '');
    if (!cur) {
        box.value = phrase + ' ';
    } else if (cur.indexOf(phrase) === -1) {
        box.value = cur + '\n' + phrase + ' ';
    }
    box.focus();
    box.setSelectionRange(box.value.length, box.value.length);
}
function mdiFillIntervention(c) {
    c = c || {};
    var typeEl = document.getElementById('mdiIvType');
    var devEl = document.getElementById('mdiIvDeviation');
    var noteEl = document.getElementById('mdiConsultNote');
    var consultEl = document.getElementById('mdiIvConsult');
    if (typeEl) typeEl.value = 'recommend';
    if (devEl) devEl.value = '';
    if (window.AlertMute) AlertMute.sync('mdiIvDeviation');
    if (noteEl) noteEl.value = c.consult_note || c.doctor_reply || '';
    if (consultEl) consultEl.value = '';
}
function mdiComposeNote() {
    var note = String((document.getElementById('mdiConsultNote') || {}).value || '').trim();
    var after = String((document.getElementById('mdiIvConsult') || {}).value || '').trim();
    var lines = [];
    if (note) lines.push(note);
    if (after) lines.push('หลัง Consult: ' + after);
    return lines.join('\n');
}
function mdiCommonPayload() {
    var sel = document.getElementById('mdiPharmacist');
    var opt = sel.options[sel.selectedIndex];
    var note = mdiComposeNote();
    return {
        pharmacist_user_id: sel.value,
        pharmacist_name: opt ? opt.text.replace(/\s*\([^)]*\)\s*$/, '').trim() : '',
        consult_note: note,
        doctor_reply: note,
        reply_wait_days: document.getElementById('mdiReplyWait').value,
        intervention_type: (document.getElementById('mdiIvType') || {}).value || 'recommend',
        deviation_category: (document.getElementById('mdiIvDeviation') || {}).value || '',
        mute_visit: (window.AlertMute && AlertMute.checked('mdiIvDeviation')) ? 1 : 0,
        note_text: String((document.getElementById('mdiConsultNote') || {}).value || '').trim(),
        consult_result: String((document.getElementById('mdiIvConsult') || {}).value || '').trim(),
        cases_json: JSON.stringify(mdiCasesPayloadList())
    };
}
function mdiShowMsg(ok, text) {
    var el = document.getElementById('mdiConsultMsg');
    el.className = 'alert mt-3 mb-0 py-2 small ' + (ok ? 'alert-success' : 'alert-danger');
    el.textContent = text || '';
}
function mdiApplyConsults(consults) {
    var map = {};
    (consults || []).forEach(function(c) {
        if (c && c.case_key) map[c.case_key] = c;
    });
    function patch(list) {
        (list || []).forEach(function(v) {
            if (v.case_key && map[v.case_key]) v.consult = map[v.case_key];
        });
    }
    patch(lastHardVisits);
    patch(lastSoftVisits);
    (lastHardGroups || []).forEach(function(g) { patch(g.visits); });
    (lastSoftGroups || []).forEach(function(g) { patch(g.visits); });
    mdiRerenderAlerts();
}
function mdiPatchSelectedConsult(extra) {
    extra = extra || {};
    mdiSelectedCases().forEach(function(it) {
        it.consult = Object.assign({}, it.consult || {}, extra);
    });
    mdiRerenderAlerts();
}
function mdiPostConsult(action) {
    var cases = mdiSelectedCases();
    if (!cases.length) {
        return Promise.resolve({ status: 'error', message: 'กรุณาเลือกอย่างน้อย 1 คู่ยา' });
    }
    var data = Object.assign(mdiCommonPayload(), { action: action });
    var body = new URLSearchParams();
    Object.keys(data).forEach(function(k) { body.append(k, data[k] == null ? '' : data[k]); });
    return fetch('fetch_monitor_drug_interaction_consult_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString()
    }).then(function(r) { return r.json(); });
}
function mdiSaveIntervention(andPrint) {
    var printWin = null;
    if (andPrint) printWin = window.open('about:blank', '_blank');
    mdiPostConsult('start').then(function(res) {
        if (res.status !== 'success') {
            if (printWin) printWin.close();
            mdiShowMsg(false, res.message || 'บันทึกไม่สำเร็จ');
            return;
        }
        mdiShowMsg(true, andPrint ? 'บันทึก Intervention และเปิดใบปรึกษาแล้ว' : 'บันทึก Intervention แล้ว');
        if (res.consults) mdiApplyConsults(res.consults);
        else if (res.consult) mdiApplyConsults([res.consult]);
        if (andPrint && res.print_url && printWin) {
            var url = res.print_url + (res.print_url.indexOf('?') >= 0 ? '&' : '?') + 'autoprint=1';
            printWin.location = url;
        } else if (printWin) {
            printWin.close();
        }
    }).catch(function(e) {
        if (printWin) printWin.close();
        mdiShowMsg(false, String(e));
    });
}
function mdiApplyResponseConsults(res) {
    if (res.consults) mdiApplyConsults(res.consults);
    else if (res.consult) mdiApplyConsults([res.consult]);
}
function mdiCloseConsult() {
    var n = mdiSelectedCases().length;
    if (!n) { mdiShowMsg(false, 'กรุณาเลือกอย่างน้อย 1 คู่ยา'); return; }
    if (!confirm('ปิด Consult ' + n + ' รายการ?')) return;
    mdiPostConsult('close').then(function(res) {
        mdiShowMsg(res.status === 'success', res.message || '');
        if (res.status === 'success') {
            mdiPatchSelectedConsult({ status: 'closed', status_label: 'ปิด Consult', reply_due_at: '' });
            mdiApplyResponseConsults(res);
        }
    }).catch(function(e) { mdiShowMsg(false, String(e)); });
}
function mdiSaveResult() {
    mdiSaveIntervention(false);
}
function mdiResetWaiting() {
    var n = mdiSelectedCases().length;
    if (!n) { mdiShowMsg(false, 'กรุณาเลือกอย่างน้อย 1 คู่ยา'); return; }
    mdiPostConsult('reset_waiting').then(function(res) {
        mdiShowMsg(res.status === 'success', res.message || '');
        if (res.status === 'success') {
            mdiPatchSelectedConsult({ status: 'waiting', status_label: 'รอ Consult', reply_due_at: '' });
            mdiApplyResponseConsults(res);
        }
    }).catch(function(e) { mdiShowMsg(false, String(e)); });
}
function mdiRenderHistory(rows) {
    var tbody = document.getElementById('mdiHistoryBody');
    if (!rows || !rows.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted py-3">ยังไม่มีประวัติ</td></tr>';
        return;
    }
    var html = '';
    rows.forEach(function(h) {
        var dayInfo = '-';
        if (h.reply_due_at) dayInfo = 'ตอบภายใน<br><span class="text-muted">' + diEsc(h.reply_due_at) + '</span>';
        var note = [];
        if (h.note_text) note.push(diEsc(h.note_text));
        if (h.doctor_reply && h.doctor_reply !== h.note_text) note.push(diEsc(h.doctor_reply));
        html += '<tr>'
            + '<td class="small text-nowrap">' + diEsc(h.created_at) + '</td>'
            + '<td class="small">' + diEsc(h.drug_name) + '</td>'
            + '<td class="small fw-bold">' + diEsc(h.action_label || h.action_key) + '</td>'
            + '<td class="small">' + diEsc(h.status_before_label || h.status_before || '-')
            + ' → ' + diEsc(h.status_after_label || h.status_after || '-') + '</td>'
            + '<td class="small">' + dayInfo + '</td>'
            + '<td class="small">' + diEsc(h.actor_name || h.pharmacist_name || '-') + '</td>'
            + '<td class="small">' + (note.length ? note.join('<br>') : '-')
            + (h.consult_id ? '<div class="mt-1"><a class="btn btn-sm btn-outline-success py-0" target="_blank" href="monitor_drug_interaction_consult_print.php?id=' + encodeURIComponent(h.consult_id) + '"><i class="fas fa-print me-1"></i>พิมพ์ใบปรึกษา</a></div>' : '')
            + '</td>'
            + '</tr>';
    });
    tbody.innerHTML = html;
}
function mdiOpenHistoryFromRow(which, idx) {
    var it = mdiVisitFromRow(which, idx);
    if (!it) return;
    mdiCurrentCase = it;
    mdiHnCases = mdiAllVisits().filter(function(x) { return diNormHn(x.hn) === diNormHn(it.hn); });
    mdiOpenHistory();
}
function mdiOpenHistory() {
    var it = mdiCurrentCase || (mdiHnCases && mdiHnCases[0]) || null;
    if (!it) {
        alert('ไม่พบข้อมูลผู้ป่วย');
        return;
    }
    document.getElementById('mdiHistoryInfo').innerHTML =
        '<b>HN ' + diEsc(it.hn) + '</b> · ' + diEsc(it.ptname);
    var params = new URLSearchParams({ action: 'history', hn: it.hn || '', limit: '150' });
    fetch('fetch_monitor_drug_interaction_consult_api.php?' + params.toString(), { credentials: 'same-origin' })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            mdiRenderHistory(res.history || []);
            bootstrap.Modal.getOrCreateInstance(document.getElementById('mdiHistoryModal')).show();
        })
        .catch(function(e) { alert('โหลดประวัติไม่สำเร็จ: ' + e); });
}
</script>
<?php
if (function_exists('drug_center_status_banner_script')) {
    echo drug_center_status_banner_script();
}
?>
</body>
</html>
