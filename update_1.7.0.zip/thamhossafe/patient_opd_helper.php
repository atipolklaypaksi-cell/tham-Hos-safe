<?php
/**
 * Patient OPD — ดูประวัติผู้ป่วย OPD/IPD จาก HOSxP
 * (รูปแบบเทียบเท่าหน้า CPOE ประวัติผู้ป่วย)
 */

function pop_utf8($expr) {
    return "CAST(CONVERT(IFNULL($expr,'') USING utf8) AS CHAR)";
}

function pop_hn_variants($hn) {
    $hn = trim((string)$hn);
    if ($hn === '') {
        return [];
    }
    $out = [$hn];
    if (ctype_digit($hn)) {
        $pad = str_pad($hn, 9, '0', STR_PAD_LEFT);
        $trim = ltrim($hn, '0');
        if ($trim === '') {
            $trim = '0';
        }
        $out[] = $pad;
        $out[] = $trim;
    }
    return array_values(array_unique($out));
}

function pop_hn_in($hos, $hn) {
    $parts = [];
    foreach (pop_hn_variants($hn) as $v) {
        $parts[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return implode(',', $parts);
}

function pop_hn_pad($hn) {
    $hn = trim((string)$hn);
    if ($hn !== '' && ctype_digit($hn)) {
        return str_pad($hn, 9, '0', STR_PAD_LEFT);
    }
    return $hn;
}

function pop_cols($hos, $table) {
    static $cache = [];
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$table);
    if ($table === '') {
        return [];
    }
    if (isset($cache[$table])) {
        return $cache[$table];
    }
    $cols = [];
    $q = @mysqli_query($hos, "SHOW COLUMNS FROM `$table`");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $field = (string)($r['Field'] ?? '');
            if ($field !== '') {
                $cols[strtolower($field)] = $field;
            }
        }
    }
    $cache[$table] = $cols;
    return $cols;
}

function pop_col(array $cols, array $cands, $fallback = "''") {
    foreach ($cands as $c) {
        $k = strtolower((string)$c);
        if (isset($cols[$k])) {
            return '`' . $cols[$k] . '`';
        }
    }
    return $fallback;
}

function pop_has(array $cols, $name) {
    return isset($cols[strtolower((string)$name)]);
}

function pop_connect($con) {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 30) : null;
    if ($hos) {
        @mysqli_set_charset($hos, 'utf8');
        return $hos;
    }
    return null;
}

/** รูปผู้ป่วยอยู่ใน HOSxP master (replica มักไม่มี blob หรือมีไม่ครบ) */
function pop_photo_connect($con) {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    if (function_exists('hosxp_master_configured') && hosxp_master_configured($con)
        && function_exists('hosxp_connect_master')) {
        $hos = @hosxp_connect_master($con, 20);
        if ($hos) {
            return $hos;
        }
    }
    return pop_connect($con);
}

function pop_photo_mime($blob) {
    if (!is_string($blob) || $blob === '') {
        return 'image/jpeg';
    }
    if (strncmp($blob, "\xFF\xD8\xFF", 3) === 0) {
        return 'image/jpeg';
    }
    if (strncmp($blob, "\x89PNG", 4) === 0) {
        return 'image/png';
    }
    if (strncmp($blob, 'GIF8', 4) === 0) {
        return 'image/gif';
    }
    if (strncmp($blob, 'BM', 2) === 0) {
        return 'image/bmp';
    }
    if (strncmp($blob, 'RIFF', 4) === 0 && substr($blob, 8, 4) === 'WEBP') {
        return 'image/webp';
    }
    return 'image/jpeg';
}

function pop_fetch_blob_sql($hos, $sql) {
    if (!$hos) {
        return null;
    }
    @mysqli_query($hos, 'SET character_set_results = binary');
    $q = @mysqli_query($hos, $sql);
    $blob = null;
    if ($q) {
        $r = mysqli_fetch_assoc($q);
        if ($r) {
            $val = $r['image'] ?? null;
            if (is_string($val) && strlen($val) > 32) {
                $blob = $val;
            }
        }
        mysqli_free_result($q);
    }
    @mysqli_set_charset($hos, 'utf8');
    if ($blob !== null && strncmp($blob, "\xFF\xD8\xFF", 3) !== 0
        && strncmp($blob, "\x89PNG", 4) !== 0
        && strncmp($blob, 'GIF8', 4) !== 0
        && strncmp($blob, 'BM', 2) !== 0) {
        $hexSql = preg_replace('/SELECT\s+image\s+FROM/i', 'SELECT HEX(image) AS image FROM', $sql, 1);
        if ($hexSql && $hexSql !== $sql) {
            $q = @mysqli_query($hos, $hexSql);
            if ($q && ($r = mysqli_fetch_assoc($q)) && !empty($r['image'])) {
                $decoded = @hex2bin($r['image']);
                if (is_string($decoded) && strlen($decoded) > 32) {
                    $blob = $decoded;
                }
            }
            if ($q) {
                mysqli_free_result($q);
            }
        }
    }
    return $blob;
}

function pop_fetch_photo_from($hos, $hn) {
    $in = pop_hn_in($hos, $hn);
    if ($in === '' || !$hos) {
        return null;
    }
    $blob = pop_fetch_blob_sql($hos, "SELECT image FROM patient_image WHERE hn IN ($in) AND image IS NOT NULL LIMIT 1");
    if ($blob !== null) {
        return $blob;
    }
    $pcols = pop_cols($hos, 'patient');
    if (pop_has($pcols, 'image')) {
        $blob = pop_fetch_blob_sql($hos, "SELECT image FROM patient WHERE hn IN ($in) AND image IS NOT NULL LIMIT 1");
        if ($blob !== null) {
            return $blob;
        }
    }
    return null;
}

function pop_fmt_date_th($date) {
    $date = substr(trim((string)$date), 0, 10);
    if ($date === '' || $date === '0000-00-00') {
        return '';
    }
    $ts = strtotime($date);
    if (!$ts) {
        return $date;
    }
    $months = ['', 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    $d = (int)date('j', $ts);
    $m = (int)date('n', $ts);
    $y = ((int)date('Y', $ts) + 543) % 100;
    return $d . ' ' . ($months[$m] ?? '') . ' ' . sprintf('%02d', $y);
}

function pop_fmt_date_be($date) {
    $date = substr(trim((string)$date), 0, 10);
    if ($date === '' || $date === '0000-00-00') {
        return '';
    }
    $ts = strtotime($date);
    if (!$ts) {
        return $date;
    }
    return date('d/m/', $ts) . ((int)date('Y', $ts) + 543);
}

function pop_fmt_time($time) {
    $time = trim((string)$time);
    if ($time === '') {
        return '';
    }
    if (preg_match('/^(\d{1,2}):(\d{2})(?::\d{2})?$/', $time, $m)) {
        return sprintf('%02d:%02d', (int)$m[1], (int)$m[2]);
    }
    $digits = preg_replace('/\D+/', '', $time);
    if (strlen($digits) >= 4) {
        return substr($digits, 0, 2) . ':' . substr($digits, 2, 2);
    }
    return $time;
}

function pop_age_text($birthday, $as_of = '') {
    $birthday = substr(trim((string)$birthday), 0, 10);
    if ($birthday === '' || $birthday === '0000-00-00') {
        return '';
    }
    $as_of = substr(trim((string)$as_of), 0, 10);
    try {
        $from = new DateTime($birthday);
        $to = ($as_of !== '' && $as_of !== '0000-00-00') ? new DateTime($as_of) : new DateTime('today');
        $diff = $from->diff($to);
        return $diff->y . ' ปี ' . $diff->m . ' เดือน ' . $diff->d . ' วัน';
    } catch (Exception $e) {
        return '';
    }
}

function pop_phone($raw) {
    $d = preg_replace('/\D+/', '', (string)$raw);
    if (strlen($d) === 10) {
        return substr($d, 0, 3) . '-' . substr($d, 3, 3) . '-' . substr($d, 6);
    }
    if (strlen($d) === 9) {
        return substr($d, 0, 2) . '-' . substr($d, 2, 3) . '-' . substr($d, 5);
    }
    return trim((string)$raw);
}

function pop_num($v) {
    $v = trim((string)$v);
    if ($v === '' || $v === '-' || strtolower($v) === 'null') {
        return '';
    }
    if (is_numeric($v)) {
        $f = (float)$v;
        if (abs($f - round($f)) < 0.0001) {
            return (string)(int)round($f);
        }
        return rtrim(rtrim(number_format($f, 2, '.', ''), '0'), '.');
    }
    return $v;
}

function pop_money($v) {
    return number_format((float)$v, 2);
}

function pop_clean($s) {
    $s = trim(preg_replace('/\s+/u', ' ', (string)$s));
    return $s;
}

function pop_query_one($hos, $sql) {
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return null;
    }
    $row = mysqli_fetch_assoc($q);
    return $row ?: null;
}

function pop_query_all($hos, $sql) {
    $out = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return $out;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $out[] = $r;
    }
    return $out;
}

function pop_fetch_patient($hos, $hn) {
    $in = pop_hn_in($hos, $hn);
    if ($in === '') {
        return null;
    }
    $pcols = pop_cols($hos, 'patient');
    $phone_sql = pop_col($pcols, ['mobile_phone_number', 'informtel', 'hometel', 'phone'], "''");
    $phone2_sql = pop_col($pcols, ['hometel', 'informtel'], "''");
    $cid_sql = pop_col($pcols, ['cid', 'idpop'], "''");
    $sex_sql = pop_col($pcols, ['sex'], "''");
    $bday_sql = pop_col($pcols, ['birthday'], "NULL");
    $addr_sql = pop_col($pcols, ['addrpart'], "''");
    $moo_sql = pop_col($pcols, ['moopart'], "''");
    $addr_names = "
        (SELECT " . pop_utf8('t.name') . "
         FROM thaiaddress t
         WHERE t.chwpart = p.chwpart AND t.amppart = p.amppart AND t.tmbpart = p.tmbpart AND t.codetype = '3'
         LIMIT 1) AS tmb_name,
        (SELECT " . pop_utf8('t.name') . "
         FROM thaiaddress t
         WHERE t.chwpart = p.chwpart AND t.amppart = p.amppart AND t.tmbpart = '00' AND t.codetype = '2'
         LIMIT 1) AS amp_name,
        (SELECT " . pop_utf8('t.name') . "
         FROM thaiaddress t
         WHERE t.chwpart = p.chwpart AND t.amppart = '00' AND t.tmbpart = '00' AND t.codetype = '1'
         LIMIT 1) AS chw_name
    ";
    $sql = "SELECT p.hn,
                   " . pop_utf8('p.pname') . " AS pname,
                   " . pop_utf8('p.fname') . " AS fname,
                   " . pop_utf8('p.lname') . " AS lname,
                   $sex_sql AS sex,
                   $bday_sql AS birthday,
                   $cid_sql AS cid,
                   " . pop_utf8($phone_sql) . " AS phone,
                   " . pop_utf8($phone2_sql) . " AS phone2,
                   " . pop_utf8($addr_sql) . " AS addrpart,
                   " . pop_utf8($moo_sql) . " AS moopart,
                   $addr_names
            FROM patient p
            WHERE p.hn IN ($in)
            LIMIT 1";
    $row = pop_query_one($hos, $sql);
    if (!$row) {
        $row = pop_query_one($hos, "SELECT hn, " . pop_utf8('pname') . " AS pname, " . pop_utf8('fname') . " AS fname, " . pop_utf8('lname') . " AS lname
            FROM patient WHERE hn IN ($in) LIMIT 1");
        if (!$row) {
            return null;
        }
    }
    $addr = trim((string)($row['addrpart'] ?? ''));
    $moo = trim((string)($row['moopart'] ?? ''));
    $tmb = trim((string)($row['tmb_name'] ?? ''));
    $amp = trim((string)($row['amp_name'] ?? ''));
    $chw = trim((string)($row['chw_name'] ?? ''));
    $parts = [];
    if ($addr !== '') {
        $parts[] = $addr;
    }
    if ($moo !== '' && $moo !== '0') {
        $parts[] = 'หมู่ที่ ' . $moo;
    }
    if ($tmb !== '') {
        $parts[] = 'ต.' . $tmb;
    }
    if ($amp !== '') {
        $parts[] = 'อ.' . $amp;
    }
    if ($chw !== '') {
        $parts[] = 'จ.' . $chw;
    }
    $sex = trim((string)($row['sex'] ?? ''));
    $sex_label = ($sex === '1' || strtoupper($sex) === 'M') ? 'ชาย' : (($sex === '2' || strtoupper($sex) === 'F') ? 'หญิง' : '');
    $phone = pop_phone($row['phone'] ?? '');
    if ($phone === '') {
        $phone = pop_phone($row['phone2'] ?? '');
    }
    return [
        'hn' => (string)$row['hn'],
        'hn_display' => pop_hn_pad($row['hn']),
        'pname' => trim((string)($row['pname'] ?? '')),
        'fname' => trim((string)($row['fname'] ?? '')),
        'lname' => trim((string)($row['lname'] ?? '')),
        'full_name' => trim(trim((string)($row['pname'] ?? '')) . trim((string)($row['fname'] ?? '')) . ' ' . trim((string)($row['lname'] ?? ''))),
        'sex' => $sex,
        'sex_label' => $sex_label,
        'birthday' => substr(trim((string)($row['birthday'] ?? '')), 0, 10),
        'cid' => preg_replace('/\D+/', '', (string)($row['cid'] ?? '')),
        'phone' => $phone,
        'address' => implode(' ', $parts),
        'has_photo' => pop_has_photo($hos, $row['hn']),
    ];
}

function pop_has_photo($hos, $hn) {
    $in = pop_hn_in($hos, $hn);
    if ($in === '') {
        return false;
    }
    $r = pop_query_one($hos, "SELECT 1 AS ok FROM patient_image WHERE hn IN ($in) AND image IS NOT NULL LIMIT 1");
    if ($r) {
        return true;
    }
    $pcols = pop_cols($hos, 'patient');
    if (pop_has($pcols, 'image')) {
        $r = pop_query_one($hos, "SELECT 1 AS ok FROM patient WHERE hn IN ($in) AND image IS NOT NULL AND OCTET_LENGTH(image) > 100 LIMIT 1");
        if ($r) {
            return true;
        }
    }
    return false;
}

function pop_fetch_photo($hos, $hn) {
    return pop_fetch_photo_from($hos, $hn);
}

function pop_fetch_photo_any($con, $hn) {
    $master = pop_photo_connect($con);
    $blob = $master ? pop_fetch_photo_from($master, $hn) : null;
    if ($blob !== null) {
        if ($master) {
            mysqli_close($master);
        }
        return $blob;
    }
    if ($master) {
        mysqli_close($master);
    }
    $rep = pop_connect($con);
    if ($rep) {
        $blob = pop_fetch_photo_from($rep, $hn);
        mysqli_close($rep);
    }
    return $blob;
}

function pop_write_connect($con) {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    if (function_exists('hosxp_connect_write')) {
        $hos = @hosxp_connect_write($con, 20);
        if ($hos) {
            return $hos;
        }
    }
    return pop_photo_connect($con);
}

function pop_qty_write_denied_message() {
    return 'บัญชี HOSxP ที่ใช้ตอนนี้มีสิทธิ์อ่านอย่างเดียว ยังบันทึกจำนวนยาลง HOSxP ไม่ได้ '
        . 'กรุณาตั้งบัญชีที่มีสิทธิ์ UPDATE ตาราง opitemrece ที่เมนู เชื่อมต่อ HOSxP master '
        . 'หรือให้ DBA เพิ่มสิทธิ์ UPDATE ให้บัญชีที่ใช้อยู่';
}

function pop_guid_ok($guid) {
    return (bool)preg_match('/^[A-Za-z0-9-]{8,38}$/', (string)$guid);
}

function pop_save_drug_qtys($con, $hn, $vn, array $items) {
    $hn = trim((string)$hn);
    $vn = trim((string)$vn);
    if ($hn === '' || $vn === '') {
        return ['ok' => false, 'error' => 'ไม่พบ HN หรือ VN'];
    }
    if (empty($items) || !is_array($items)) {
        return ['ok' => false, 'error' => 'ไม่มีรายการยาที่ต้องการบันทึก'];
    }
    $hos = pop_write_connect($con);
    if (!$hos) {
        return ['ok' => false, 'error' => 'เชื่อมต่อ HOSxP เพื่อบันทึกไม่สำเร็จ'];
    }
    $in = pop_hn_in($hos, $hn);
    if ($in === '') {
        mysqli_close($hos);
        return ['ok' => false, 'error' => 'HN ไม่ถูกต้อง'];
    }
    $vn_esc = mysqli_real_escape_string($hos, $vn);
    $hn_vars = pop_hn_variants($hn);
    $updated = 0;
    $unchanged = 0;
    $skipped = [];
    foreach ($items as $it) {
        if (!is_array($it)) {
            continue;
        }
        $guid = trim((string)($it['hos_guid'] ?? ''));
        $icode = trim((string)($it['icode'] ?? ''));
        $qty_raw = $it['qty'] ?? '';
        if (!pop_guid_ok($guid)) {
            mysqli_close($hos);
            return ['ok' => false, 'error' => 'รหัสรายการยาไม่ถูกต้อง'];
        }
        if ($icode === '' || !preg_match('/^[A-Za-z0-9]{1,7}$/', $icode)) {
            mysqli_close($hos);
            return ['ok' => false, 'error' => 'รหัสยาไม่ถูกต้อง'];
        }
        if (!is_numeric($qty_raw)) {
            mysqli_close($hos);
            return ['ok' => false, 'error' => 'จำนวนยาไม่ถูกต้อง'];
        }
        $qty_i = (int)round((float)$qty_raw);
        if ($qty_i < 0 || $qty_i > 9999) {
            mysqli_close($hos);
            return ['ok' => false, 'error' => 'จำนวนยาต้องอยู่ระหว่าง 0–9999'];
        }
        $guid_esc = mysqli_real_escape_string($hos, $guid);
        $icode_esc = mysqli_real_escape_string($hos, $icode);
        $row = pop_query_one($hos, "SELECT hos_guid, vn, hn, icode, qty, unitprice, paidst, finance_number
            FROM opitemrece WHERE hos_guid = '$guid_esc' LIMIT 1");
        if (!$row) {
            $skipped[] = $icode;
            continue;
        }
        if (trim((string)$row['vn']) !== $vn) {
            mysqli_close($hos);
            return ['ok' => false, 'error' => 'VN ไม่ตรงกับรายการยา'];
        }
        if (!in_array(trim((string)$row['hn']), $hn_vars, true)) {
            mysqli_close($hos);
            return ['ok' => false, 'error' => 'HN ไม่ตรงกับรายการยา'];
        }
        if (trim((string)$row['icode']) !== $icode) {
            mysqli_close($hos);
            return ['ok' => false, 'error' => 'รหัสยาไม่ตรงกับรายการ'];
        }
        $paidst = strtoupper(trim((string)($row['paidst'] ?? '')));
        $fin = trim((string)($row['finance_number'] ?? ''));
        if ($paidst === 'Y' || $paidst === '1' || ($fin !== '' && $fin !== '0')) {
            $skipped[] = $icode;
            continue;
        }
        if ((int)$row['qty'] === $qty_i) {
            $unchanged++;
            continue;
        }
        $sum = round($qty_i * (float)($row['unitprice'] ?? 0), 3);
        $ok = @mysqli_query($hos, "UPDATE opitemrece
            SET qty = $qty_i, sum_price = $sum
            WHERE hos_guid = '$guid_esc'
              AND vn = '$vn_esc'
              AND hn IN ($in)
              AND icode = '$icode_esc'
              AND IFNULL(paidst,'N') NOT IN ('Y','1')
            LIMIT 1");
        if (!$ok) {
            $err = mysqli_error($hos);
            mysqli_close($hos);
            if (stripos($err, 'denied') !== false || stripos($err, 'privilege') !== false) {
                return ['ok' => false, 'error' => pop_qty_write_denied_message()];
            }
            return ['ok' => false, 'error' => 'บันทึกจำนวนยาลง HOSxP ไม่สำเร็จ'];
        }
        if (mysqli_affected_rows($hos) > 0) {
            $updated++;
        }
    }
    mysqli_close($hos);
    if ($updated === 0 && $unchanged === 0 && $skipped) {
        return ['ok' => false, 'error' => 'ไม่สามารถแก้จำนวนยาได้ (อาจชำระแล้วหรือออกบิลแล้ว)'];
    }
    return [
        'ok' => true,
        'updated' => $updated,
        'unchanged' => $unchanged,
        'skipped' => count($skipped),
    ];
}

function pop_fetch_allergy($hos, $hn) {
    $in = pop_hn_in($hos, $hn);
    if ($in === '') {
        return ['has_allergy' => false, 'items' => [], 'text' => ''];
    }
    $cols = pop_cols($hos, 'opd_allergy');
    if (!$cols) {
        return ['has_allergy' => false, 'items' => [], 'text' => ''];
    }
    $note_sql = pop_has($cols, 'note') ? pop_utf8('a.note') : "''";
    $reporter_sql = pop_has($cols, 'reporter') ? 'a.reporter' : "''";
    $rel_id_sql = pop_has($cols, 'allergy_relation_id') ? 'a.allergy_relation_id' : '0';
    $no_alert = pop_has($cols, 'no_alert') ? "AND IFNULL(a.no_alert,'') <> 'Y'" : '';
    $rel_join = '';
    $rel_name = "''";
    $relCols = pop_cols($hos, 'allergy_relation');
    if ($relCols && pop_has($relCols, 'allergy_relation_id') && pop_has($relCols, 'relation_name')) {
        $rel_join = 'LEFT JOIN allergy_relation ar ON ar.allergy_relation_id = ' . $rel_id_sql;
        $rel_name = pop_utf8('ar.relation_name');
    }
    $rows = pop_query_all($hos, "
        SELECT " . pop_utf8('a.agent') . " AS agent,
               " . pop_utf8('a.symptom') . " AS symptom,
               a.report_date,
               $note_sql AS note,
               $reporter_sql AS reporter,
               $rel_id_sql AS allergy_relation_id,
               $rel_name AS relation_name
        FROM opd_allergy a
        $rel_join
        WHERE a.hn IN ($in)
          $no_alert
        ORDER BY a.report_date ASC, a.agent ASC
        LIMIT 50
    ");
    $items = [];
    $seen = [];
    foreach ($rows as $r) {
        $agent = pop_clean($r['agent'] ?? '');
        if ($agent === '' || isset($seen[$agent])) {
            continue;
        }
        $seen[$agent] = true;
        $sym = pop_clean($r['symptom'] ?? '');
        $rd = substr(trim((string)($r['report_date'] ?? '')), 0, 10);
        if ($rd === '0000-00-00') {
            $rd = '';
        }
        $level = pop_clean($r['relation_name'] ?? '');
        // PharMS ย่อ "ใช่แน่นอน (Certain)" → "แน่นอน (Certain)"
        if ($level !== '' && function_exists('mb_strpos') && mb_strpos($level, 'ใช่แน่นอน', 0, 'UTF-8') === 0) {
            $level = 'แน่นอน' . mb_substr($level, mb_strlen('ใช่แน่นอน', 'UTF-8'), null, 'UTF-8');
        } elseif ($level !== '' && strpos($level, 'ใช่แน่นอน') === 0) {
            $level = 'แน่นอน' . substr($level, strlen('ใช่แน่นอน'));
        }
        $items[] = [
            'agent' => $agent,
            'symptom' => $sym,
            'note' => pop_clean($r['note'] ?? ''),
            'reporter' => trim((string)($r['reporter'] ?? '')),
            'level' => $level,
            'allergy_relation_id' => (int)($r['allergy_relation_id'] ?? 0),
            'report_date' => $rd,
            'report_date_dmy' => ($rd !== '' && ($ts = strtotime($rd)) ? date('d/m/Y', $ts) : ''),
            'report_date_be' => $rd !== '' ? pop_fmt_date_be($rd) : '',
        ];
    }
    $names = [];
    foreach ($items as $it) {
        $names[] = $it['agent'];
    }
    return [
        'has_allergy' => count($items) > 0,
        'items' => $items,
        'text' => implode(', ', $names),
    ];
}

function pop_fetch_hosxp_notes($hos, $hn) {
    $in = pop_hn_in($hos, $hn);
    $cols = pop_cols($hos, 'ptnote');
    if ($in === '' || !$cols) {
        return [];
    }
    $plain = pop_has($cols, 'plain_text') ? pop_utf8('n.plain_text') : "''";
    $body = pop_has($cols, 'ptnote') ? pop_utf8('n.ptnote') : "''";
    $staff = pop_has($cols, 'note_staff') ? 'n.note_staff' : "''";
    $dt = pop_has($cols, 'note_datetime') ? 'n.note_datetime' : 'NULL';
    $vst = pop_has($cols, 'vstdate') ? 'n.vstdate' : 'NULL';
    $has_exp = pop_has($cols, 'has_expired') ? 'n.has_expired' : "''";
    $exp = pop_has($cols, 'expire_date') ? 'n.expire_date' : 'NULL';
    $enc = pop_has($cols, 'encrypt_note') ? 'n.encrypt_note' : "''";
    $sql = "SELECT n.ptnote_id,
                   $plain AS plain_text,
                   $body AS ptnote,
                   $staff AS staff_code,
                   " . pop_utf8('ou.name') . " AS staff_name,
                   $dt AS note_datetime,
                   $vst AS vstdate,
                   $has_exp AS has_expired,
                   $exp AS expire_date,
                   $enc AS encrypt_note
            FROM ptnote n
            LEFT JOIN opduser ou ON ou.loginname = n.note_staff
            WHERE n.hn IN ($in)
            ORDER BY COALESCE(n.note_datetime, n.vstdate) DESC, n.ptnote_id DESC
            LIMIT 80";
    $rows = pop_query_all($hos, $sql);
    $out = [];
    foreach ($rows as $r) {
        if (strtoupper(trim((string)($r['encrypt_note'] ?? ''))) === 'Y') {
            continue;
        }
        $raw = trim((string)($r['plain_text'] ?? ''));
        if ($raw === '') {
            $raw = trim((string)($r['ptnote'] ?? ''));
        }
        $raw = html_entity_decode(strip_tags($raw), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $raw = pop_clean($raw);
        if ($raw === '') {
            continue;
        }
        $dtRaw = trim((string)($r['note_datetime'] ?? ''));
        if ($dtRaw === '' || strpos($dtRaw, '0000-00-00') === 0) {
            $dtRaw = '';
        }
        $when = $dtRaw !== '' ? substr($dtRaw, 0, 10) : substr(trim((string)($r['vstdate'] ?? '')), 0, 10);
        if ($when === '0000-00-00') {
            $when = '';
        }
        $exp_date = substr(trim((string)($r['expire_date'] ?? '')), 0, 10);
        if ($exp_date === '0000-00-00') {
            $exp_date = '';
        }
        $has_expired = strtoupper(trim((string)($r['has_expired'] ?? '')));
        $staff_code = trim((string)($r['staff_code'] ?? ''));
        $staff_name = pop_clean($r['staff_name'] ?? '');
        // note_datetime แบบ PharMS เช่น 01/02/2567 13:56:12
        $dtBe = '';
        if ($dtRaw !== '') {
            $ts = strtotime($dtRaw);
            if ($ts) {
                $dtBe = date('d/m/', $ts) . ((int)date('Y', $ts) + 543) . date(' H:i:s', $ts);
            }
        } elseif ($when !== '') {
            $dtBe = pop_fmt_date_be($when);
        }
        $out[] = [
            'text' => $raw,
            'plain_text' => $raw,
            'staff' => $staff_code,
            'note_staff' => $staff_code,
            'staff_name' => $staff_name,
            'note_date' => $when,
            'note_date_be' => pop_fmt_date_be($when),
            'note_datetime' => $dtRaw,
            'note_datetime_be' => $dtBe,
            'has_expired' => ($has_expired === 'Y' || $has_expired === '1'),
            'expire_date' => $exp_date,
            'expire_date_be' => $exp_date !== '' ? pop_fmt_date_be($exp_date) : '',
        ];
    }
    return $out;
}

function pop_visit_key($type, $vn, $an) {
    $an = trim((string)$an);
    $vn = trim((string)$vn);
    if (strtoupper((string)$type) === 'I' && $an !== '') {
        return 'ipd:' . $an;
    }
    if ($vn !== '') {
        return 'opd:' . $vn;
    }
    if ($an !== '') {
        return 'ipd:' . $an;
    }
    return '';
}

function pop_fetch_visits($hos, $hn, $limit = 80) {
    $in = pop_hn_in($hos, $hn);
    if ($in === '') {
        return [];
    }
    $limit = max(10, min(120, (int)$limit));
    $ovcols = pop_cols($hos, 'ovst');
    $dep_expr = 'o.main_dep';
    if (pop_has($ovcols, 'cur_dep')) {
        $dep_expr = "COALESCE(NULLIF(o.cur_dep,''), o.main_dep)";
    }
    $opd = pop_query_all($hos, "
        SELECT o.vn, IFNULL(o.an,'') AS an, o.vstdate, o.vsttime, o.doctor, o.pttype,
               " . pop_utf8('k.department') . " AS room_name,
               " . pop_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . " AS doctor_name,
               " . pop_utf8('pt.name') . " AS pttype_name
        FROM ovst o
        LEFT JOIN kskdepartment k ON k.depcode = $dep_expr
        LEFT JOIN doctor doc ON doc.code = o.doctor
        LEFT JOIN pttype pt ON pt.pttype = o.pttype
        WHERE o.hn IN ($in)
        ORDER BY o.vstdate DESC, o.vsttime DESC
        LIMIT $limit
    ");
    $ipd = pop_query_all($hos, "
        SELECT i.vn, i.an, i.regdate AS vstdate, i.regtime AS vsttime, i.admdoctor AS doctor, i.pttype,
               " . pop_utf8('w.name') . " AS room_name,
               " . pop_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . " AS doctor_name,
               " . pop_utf8('pt.name') . " AS pttype_name
        FROM ipt i
        LEFT JOIN ward w ON w.ward = i.ward
        LEFT JOIN doctor doc ON doc.code = i.admdoctor
        LEFT JOIN pttype pt ON pt.pttype = i.pttype
        WHERE i.hn IN ($in)
        ORDER BY i.regdate DESC, i.an DESC
        LIMIT $limit
    ");
    $out = [];
    $seen = [];
    foreach ($opd as $r) {
        $vn = trim((string)($r['vn'] ?? ''));
        $an = trim((string)($r['an'] ?? ''));
        $key = pop_visit_key('O', $vn, '');
        if ($key === '' || isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = pop_map_visit($r, 'O');
    }
    foreach ($ipd as $r) {
        $an = trim((string)($r['an'] ?? ''));
        $vn = trim((string)($r['vn'] ?? ''));
        $key = pop_visit_key('I', $vn, $an);
        if ($key === '' || isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = pop_map_visit($r, 'I');
    }
    usort($out, static function ($a, $b) {
        $da = (string)($a['vstdate'] ?? '');
        $db = (string)($b['vstdate'] ?? '');
        if ($da === $db) {
            return strcmp((string)($b['vsttime'] ?? ''), (string)($a['vsttime'] ?? ''));
        }
        return strcmp($db, $da);
    });
    return array_slice($out, 0, $limit);
}

function pop_map_visit(array $r, $type) {
    $vn = trim((string)($r['vn'] ?? ''));
    $an = trim((string)($r['an'] ?? ''));
    $date = substr(trim((string)($r['vstdate'] ?? '')), 0, 10);
    if ($date === '0000-00-00') {
        $date = '';
    }
    return [
        'key' => pop_visit_key($type, $vn, $an),
        'type' => $type,
        'vn' => $vn,
        'an' => $an,
        'vstdate' => $date,
        'vsttime' => pop_fmt_time($r['vsttime'] ?? ''),
        'vstdate_th' => pop_fmt_date_th($date),
        'vstdate_be' => pop_fmt_date_be($date),
        'room_name' => pop_clean($r['room_name'] ?? ''),
        'doctor_name' => pop_clean($r['doctor_name'] ?? ''),
        'doctor' => trim((string)($r['doctor'] ?? '')),
        'pttype' => trim((string)($r['pttype'] ?? '')),
        'pttype_name' => pop_clean($r['pttype_name'] ?? ''),
        'drug_count' => (int)($r['drug_count'] ?? 0),
    ];
}

function pop_find_visit(array $visits, $vn, $an, $date = '') {
    $vn = trim((string)$vn);
    $an = trim((string)$an);
    $date = substr(trim((string)$date), 0, 10);
    if ($an !== '') {
        foreach ($visits as $v) {
            if (($v['type'] ?? '') === 'I' && ($v['an'] ?? '') === $an) {
                return $v;
            }
        }
    }
    if ($vn !== '') {
        foreach ($visits as $v) {
            if (($v['vn'] ?? '') === $vn) {
                return $v;
            }
        }
    }
    if ($date !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        foreach ($visits as $v) {
            if (($v['vstdate'] ?? '') === $date && ($v['type'] ?? '') === 'O') {
                return $v;
            }
        }
        foreach ($visits as $v) {
            if (($v['vstdate'] ?? '') === $date) {
                return $v;
            }
        }
    }
    return $visits[0] ?? null;
}

function pop_next_visit(array $visits, $current_key) {
    $found = false;
    foreach ($visits as $v) {
        if ($found) {
            return $v;
        }
        if (($v['key'] ?? '') === $current_key) {
            $found = true;
        }
    }
    return null;
}

function pop_next_visit_with_drugs(array $visits, $current_key) {
    foreach ($visits as $v) {
        if (($v['key'] ?? '') === $current_key) {
            continue;
        }
        if ((int)($v['drug_count'] ?? 0) > 0) {
            return $v;
        }
    }
    return pop_next_visit($visits, $current_key);
}

function pop_attach_drug_counts($hos, $hn, array $visits) {
    if (!$visits) {
        return $visits;
    }
    $in = pop_hn_in($hos, $hn);
    if ($in === '') {
        return $visits;
    }
    $vns = [];
    $ans = [];
    foreach ($visits as $v) {
        $vn = trim((string)($v['vn'] ?? ''));
        $an = trim((string)($v['an'] ?? ''));
        if ($vn !== '') {
            $vns[$vn] = "'" . mysqli_real_escape_string($hos, $vn) . "'";
        }
        if (($v['type'] ?? '') === 'I' && $an !== '') {
            $ans[$an] = "'" . mysqli_real_escape_string($hos, $an) . "'";
        }
    }
    $by_vn = [];
    $by_an = [];
    if ($vns) {
        $rows = pop_query_all($hos, "SELECT o.vn, COUNT(*) AS n
            FROM opitemrece o
            INNER JOIN drugitems d ON d.icode = o.icode
            WHERE o.hn IN ($in) AND o.vn IN (" . implode(',', $vns) . ")
            GROUP BY o.vn");
        foreach ($rows as $r) {
            $by_vn[trim((string)($r['vn'] ?? ''))] = (int)$r['n'];
        }
    }
    if ($ans) {
        $rows = pop_query_all($hos, "SELECT o.an, COUNT(*) AS n
            FROM opitemrece o
            INNER JOIN drugitems d ON d.icode = o.icode
            WHERE o.hn IN ($in) AND o.an IN (" . implode(',', $ans) . ")
            GROUP BY o.an");
        foreach ($rows as $r) {
            $by_an[trim((string)($r['an'] ?? ''))] = (int)$r['n'];
        }
    }
    foreach ($visits as &$v) {
        $n = 0;
        $an = trim((string)($v['an'] ?? ''));
        $vn = trim((string)($v['vn'] ?? ''));
        if (($v['type'] ?? '') === 'I' && $an !== '' && isset($by_an[$an])) {
            $n = $by_an[$an];
        } elseif ($vn !== '' && isset($by_vn[$vn])) {
            $n = $by_vn[$vn];
        }
        $v['drug_count'] = $n;
    }
    unset($v);
    return $visits;
}

function pop_fetch_screen($hos, $vn, $hn, $date = '') {
    $empty = [
        'bw' => '', 'height' => '', 'bmi' => '', 'bps' => '', 'bpd' => '',
        'pulse' => '', 'rr' => '', 'temperature' => '', 'o2sat' => '',
        'cc' => '', 'pe' => '', 'hpi' => '', 'pmh' => '',
    ];
    $scols = pop_cols($hos, 'opdscreen');
    if (!$scols) {
        return $empty;
    }
    $sel = [
        'bw' => pop_col($scols, ['bw']),
        'height' => pop_col($scols, ['height']),
        'bmi' => pop_col($scols, ['bmi']),
        'bps' => pop_col($scols, ['bps']),
        'bpd' => pop_col($scols, ['bpd']),
        'pulse' => pop_col($scols, ['pulse', 'hr']),
        'rr' => pop_col($scols, ['rr']),
        'temperature' => pop_col($scols, ['temperature', 'temp']),
        'o2sat' => pop_col($scols, ['o2sat', 'spo2']),
        'cc' => pop_utf8(pop_col($scols, ['cc'], "''")) . ' AS cc',
        'pe' => pop_utf8(pop_col($scols, ['pe'], "''")) . ' AS pe',
        'hpi' => pop_utf8(pop_col($scols, ['hpi'], "''")) . ' AS hpi',
        'pmh' => pop_utf8(pop_col($scols, ['pmh'], "''")) . ' AS pmh',
    ];
    $fields = "{$sel['bw']} AS bw, {$sel['height']} AS height, {$sel['bmi']} AS bmi,
               {$sel['bps']} AS bps, {$sel['bpd']} AS bpd, {$sel['pulse']} AS pulse,
               {$sel['rr']} AS rr, {$sel['temperature']} AS temperature, {$sel['o2sat']} AS o2sat,
               {$sel['cc']}, {$sel['pe']}, {$sel['hpi']}, {$sel['pmh']}";
    $row = null;
    $vn = trim((string)$vn);
    if ($vn !== '') {
        $vn_esc = mysqli_real_escape_string($hos, $vn);
        $row = pop_query_one($hos, "SELECT $fields FROM opdscreen WHERE vn = '$vn_esc' LIMIT 1");
    }
    if (!$row) {
        $in = pop_hn_in($hos, $hn);
        $date = substr(trim((string)$date), 0, 10);
        if ($in !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) && pop_has($scols, 'vstdate')) {
            $d = mysqli_real_escape_string($hos, $date);
            $row = pop_query_one($hos, "SELECT $fields FROM opdscreen WHERE hn IN ($in) AND vstdate = '$d' ORDER BY vsttime DESC LIMIT 1");
        }
        if (!$row && $in !== '') {
            $order = pop_has($scols, 'vstdate') ? 'vstdate DESC, vsttime DESC' : 'vn DESC';
            $row = pop_query_one($hos, "SELECT $fields FROM opdscreen WHERE hn IN ($in) ORDER BY $order LIMIT 1");
        }
    }
    if (!$row) {
        return $empty;
    }
    $bw = pop_num($row['bw'] ?? '');
    $height = pop_num($row['height'] ?? '');
    $bmi = pop_num($row['bmi'] ?? '');
    if ($bmi === '' && $bw !== '' && $height !== '' && (float)$height > 0) {
        $hm = (float)$height / 100;
        if ($hm > 0) {
            $bmi = pop_num((float)$bw / ($hm * $hm));
        }
    }
    $bps = pop_num($row['bps'] ?? '');
    $bpd = pop_num($row['bpd'] ?? '');
    $bp = $bps;
    if ($bps !== '' && $bpd !== '') {
        $bp = $bps . '/' . $bpd;
    }
    return [
        'bw' => $bw,
        'height' => $height,
        'bmi' => $bmi,
        'bps' => $bp,
        'bpd' => $bpd,
        'pulse' => pop_num($row['pulse'] ?? ''),
        'rr' => pop_num($row['rr'] ?? ''),
        'temperature' => pop_num($row['temperature'] ?? ''),
        'o2sat' => pop_num($row['o2sat'] ?? ''),
        'cc' => trim((string)($row['cc'] ?? '')),
        'pe' => trim((string)($row['pe'] ?? '')),
        'hpi' => trim((string)($row['hpi'] ?? '')),
        'pmh' => trim((string)($row['pmh'] ?? '')),
    ];
}

function pop_ed_label($ed) {
    $ed = trim((string)$ed);
    if ($ed === '' || $ed === 'N' || $ed === '0') {
        return '';
    }
    if ($ed === 'Y' || $ed === '1') {
        return 'ก';
    }
    if (function_exists('mb_strlen')) {
        if (mb_strlen($ed, 'UTF-8') <= 4) {
            return $ed;
        }
        return mb_substr($ed, 0, 4, 'UTF-8');
    }
    if (strlen($ed) <= 4) {
        return $ed;
    }
    return substr($ed, 0, 4);
}

function pop_norm_usage($s) {
    $s = pop_clean($s);
    if (function_exists('mb_strtolower')) {
        return mb_strtolower($s, 'UTF-8');
    }
    return strtolower($s);
}

function pop_qty_eq($a, $b) {
    if ($a === '' && $b === '') {
        return true;
    }
    if ($a === '' || $b === '') {
        return false;
    }
    return abs((float)$a - (float)$b) < 0.0001;
}

function pop_compare_status($cur_name, $cmp_name, $cur_qty, $cmp_qty, $cur_usage, $cmp_usage) {
    $has_cur = trim((string)$cur_name) !== '';
    $has_cmp = trim((string)$cmp_name) !== '';
    if ($has_cur && !$has_cmp) {
        return ['key' => 'new', 'label' => 'ยาใหม่'];
    }
    if (!$has_cur && $has_cmp) {
        return ['key' => 'stop', 'label' => 'หยุดยา'];
    }
    $qty_same = pop_qty_eq($cur_qty, $cmp_qty);
    $use_same = pop_norm_usage($cur_usage) === pop_norm_usage($cmp_usage);
    if ($qty_same && $use_same) {
        return ['key' => 'same', 'label' => 'เท่ากัน'];
    }
    if (!$qty_same && !$use_same) {
        return ['key' => 'both', 'label' => 'เปลี่ยนจำนวน/วิธีใช้'];
    }
    if (!$qty_same) {
        return ['key' => 'qty', 'label' => 'เปลี่ยนจำนวน'];
    }
    return ['key' => 'usage', 'label' => 'เปลี่ยนวิธีใช้'];
}

function pop_fetch_drugs($hos, $vn, $an) {
    $vn = trim((string)$vn);
    $an = trim((string)$an);
    if ($vn === '' && $an === '') {
        return [];
    }
    $ocols = pop_cols($hos, 'opitemrece');
    $dcols = pop_cols($hos, 'drugitems');
    $paid = pop_has($ocols, 'paidst') ? "o.paidst" : "''";
    $price_parts = [];
    if (pop_has($ocols, 'sum_price')) {
        $price_parts[] = 'NULLIF(o.sum_price,0)';
    }
    if (pop_has($ocols, 'unitprice')) {
        $price_parts[] = 'NULLIF(o.qty * o.unitprice,0)';
    }
    if (pop_has($ocols, 'income')) {
        $price_parts[] = 'NULLIF(o.income,0)';
    }
    if (pop_has($dcols, 'unitprice')) {
        $price_parts[] = 'NULLIF(o.qty * d.unitprice,0)';
    }
    if (pop_has($dcols, 'stdprice')) {
        $price_parts[] = 'NULLIF(o.qty * d.stdprice,0)';
    }
    if (pop_has($dcols, 'ipd_price')) {
        $price_parts[] = 'NULLIF(o.qty * d.ipd_price,0)';
    }
    $price_sql = $price_parts ? ('COALESCE(' . implode(', ', $price_parts) . ', 0)') : '0';
    $unitprice = pop_has($ocols, 'unitprice') ? "o.unitprice" : "0";
    $doctor_code = pop_has($ocols, 'doctor') ? "o.doctor" : "''";
    $staff_code = pop_has($ocols, 'staff') ? "o.staff" : "''";
    $ed_sql = "'' AS ed";
    if (pop_has($dcols, 'drugaccount')) {
        $ed_sql = pop_utf8('d.drugaccount') . ' AS ed';
    } elseif (pop_has($dcols, 'ed')) {
        $ed_sql = pop_utf8('d.ed') . ' AS ed';
    }
    $where = [];
    if ($an !== '') {
        $where[] = "o.an = '" . mysqli_real_escape_string($hos, $an) . "'";
    }
    if ($vn !== '') {
        $where[] = "o.vn = '" . mysqli_real_escape_string($hos, $vn) . "'";
    }
    $sql = "SELECT o.icode, o.qty, $paid AS paidst, $price_sql AS line_price, $unitprice AS unitprice,
                   $doctor_code AS doctor_code, $staff_code AS staff_code,
                   " . (pop_has($ocols, 'hos_guid') ? 'o.hos_guid' : "''") . " AS hos_guid,
                   " . (pop_has($ocols, 'item_no') ? 'o.item_no' : '0') . " AS item_no,
                   " . (pop_has($ocols, 'finance_number') ? 'o.finance_number' : "''") . " AS finance_number,
                   " . pop_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . " AS doctor_name,
                   " . pop_utf8('ou.name') . " AS staff_name,
                   " . pop_utf8('d.name') . " AS drug_name,
                   " . pop_utf8('d.strength') . " AS strength,
                   " . pop_utf8('d.units') . " AS units,
                   $ed_sql,
                   " . pop_utf8("IF(o.sp_use IS NOT NULL AND TRIM(o.sp_use) <> '',
                        CONCAT(IFNULL(sp.name1,''),' ',IFNULL(sp.name2,''),' ',IFNULL(sp.name3,'')),
                        CONCAT(IFNULL(du.name1,''),' ',IFNULL(du.name2,''),' ',IFNULL(du.name3,''))
                   )") . " AS usage_text
            FROM opitemrece o
            INNER JOIN drugitems d ON d.icode = o.icode
            LEFT JOIN drugusage du ON du.drugusage = o.drugusage
            LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
            LEFT JOIN doctor doc ON doc.code = o.doctor
            LEFT JOIN opduser ou ON ou.loginname = o.staff
            WHERE (" . implode(' OR ', $where) . ")
            ORDER BY o.item_no ASC, o.icode ASC
            LIMIT 200";
    $rows = pop_query_all($hos, $sql);
    if (!$rows) {
        $sql = "SELECT o.icode, o.qty, $paid AS paidst, $price_sql AS line_price, $unitprice AS unitprice,
                       $doctor_code AS doctor_code, $staff_code AS staff_code,
                       " . (pop_has($ocols, 'hos_guid') ? 'o.hos_guid' : "''") . " AS hos_guid,
                       " . (pop_has($ocols, 'item_no') ? 'o.item_no' : '0') . " AS item_no,
                       " . (pop_has($ocols, 'finance_number') ? 'o.finance_number' : "''") . " AS finance_number,
                       '' AS doctor_name, '' AS staff_name,
                       " . pop_utf8('d.name') . " AS drug_name,
                       " . pop_utf8('d.strength') . " AS strength,
                       " . pop_utf8('d.units') . " AS units,
                       $ed_sql,
                       " . pop_utf8("IF(o.sp_use IS NOT NULL AND TRIM(o.sp_use) <> '',
                            CONCAT(IFNULL(sp.name1,''),' ',IFNULL(sp.name2,''),' ',IFNULL(sp.name3,'')),
                            CONCAT(IFNULL(du.name1,''),' ',IFNULL(du.name2,''),' ',IFNULL(du.name3,''))
                       )") . " AS usage_text
                FROM opitemrece o
                INNER JOIN drugitems d ON d.icode = o.icode
                LEFT JOIN drugusage du ON du.drugusage = o.drugusage
                LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
                WHERE (" . implode(' OR ', $where) . ")
                ORDER BY o.item_no ASC, o.icode ASC
                LIMIT 200";
        $rows = pop_query_all($hos, $sql);
    }
    $out = [];
    foreach ($rows as $r) {
        $icode = trim((string)($r['icode'] ?? ''));
        $name = pop_clean($r['drug_name'] ?? '');
        $strength = pop_clean($r['strength'] ?? '');
        $units = pop_clean($r['units'] ?? '');
        if ($icode === '' || $name === '') {
            continue;
        }
        $label = $name;
        if ($strength !== '' && stripos($label, $strength) === false) {
            $label = trim($label . ' ' . $strength);
        }
        if ($units !== '' && stripos($label, $units) === false) {
            $label = trim($label . ' ' . $units);
        }
        $qty = pop_num($r['qty'] ?? '0');
        $paidst = strtoupper(trim((string)($r['paidst'] ?? '')));
        $paid = ($paidst === 'Y' || $paidst === '1');
        $finance = trim((string)($r['finance_number'] ?? ''));
        $billed = ($finance !== '' && $finance !== '0');
        $qty_locked = $paid || $billed;
        $qty_lock_reason = '';
        if ($paid) {
            $qty_lock_reason = 'ชำระแล้ว';
        } elseif ($billed) {
            $qty_lock_reason = 'ออกบิลแล้ว';
        }
        $remain = $paid ? '0' : $qty;
        $price = (float)($r['line_price'] ?? 0);
        if ($price <= 0) {
            $price = (float)($r['unitprice'] ?? 0) * (float)($qty === '' ? 0 : $qty);
        }
        $out[] = [
            'icode' => $icode,
            'name' => $label,
            'qty' => $qty === '' ? '0' : $qty,
            'remain' => $remain === '' ? '0' : $remain,
            'usage' => pop_clean($r['usage_text'] ?? ''),
            'ed' => pop_ed_label($r['ed'] ?? ''),
            'paid' => $paid,
            'price' => round($price, 2),
            'unitprice' => (float)($r['unitprice'] ?? 0),
            'hos_guid' => trim((string)($r['hos_guid'] ?? '')),
            'item_no' => (int)($r['item_no'] ?? 0),
            'qty_locked' => $qty_locked,
            'qty_lock_reason' => $qty_lock_reason,
            'doctor_name' => pop_clean($r['doctor_name'] ?? ''),
            'staff_name' => pop_clean($r['staff_name'] ?? ''),
            'picker_name' => '',
        ];
    }
    return $out;
}

function pop_merge_drugs(array $current, array $compare) {
    $map = [];
    $order = [];
    foreach ($current as $d) {
        $icode = $d['icode'];
        if (!isset($map[$icode])) {
            $order[] = $icode;
            $map[$icode] = [
                'icode' => $icode,
                'ed' => $d['ed'],
                'cur_name' => $d['name'],
                'cur_qty' => $d['qty'],
                'cur_remain' => $d['remain'],
                'cur_usage' => $d['usage'],
                'cmp_name' => '',
                'cmp_qty' => '',
                'cmp_usage' => '',
                'is_new' => true,
                'paid' => !empty($d['paid']),
                'price' => (float)($d['price'] ?? 0),
                'unitprice' => (float)($d['unitprice'] ?? 0),
                'hos_guid' => $d['hos_guid'] ?? '',
                'item_no' => (int)($d['item_no'] ?? 0),
                'qty_locked' => !empty($d['qty_locked']),
                'qty_lock_reason' => $d['qty_lock_reason'] ?? '',
                'doctor_name' => $d['doctor_name'] ?? '',
                'staff_name' => $d['staff_name'] ?? '',
                'picker_name' => $d['picker_name'] ?? '',
            ];
        }
    }
    foreach ($compare as $d) {
        $icode = $d['icode'];
        if (!isset($map[$icode])) {
            $order[] = $icode;
            $map[$icode] = [
                'icode' => $icode,
                'ed' => $d['ed'],
                'cur_name' => '',
                'cur_qty' => '',
                'cur_remain' => '',
                'cur_usage' => '',
                'cmp_name' => $d['name'],
                'cmp_qty' => $d['qty'],
                'cmp_usage' => $d['usage'],
                'is_new' => false,
                'paid' => false,
                'price' => 0,
                'unitprice' => 0,
                'hos_guid' => '',
                'item_no' => 0,
                'qty_locked' => true,
                'qty_lock_reason' => '',
                'doctor_name' => $d['doctor_name'] ?? '',
                'staff_name' => '',
                'picker_name' => '',
            ];
        } else {
            $map[$icode]['cmp_name'] = $d['name'];
            $map[$icode]['cmp_qty'] = $d['qty'];
            $map[$icode]['cmp_usage'] = $d['usage'];
            $map[$icode]['is_new'] = false;
            if ($map[$icode]['ed'] === '') {
                $map[$icode]['ed'] = $d['ed'];
            }
            if ($map[$icode]['doctor_name'] === '' && !empty($d['doctor_name'])) {
                $map[$icode]['doctor_name'] = $d['doctor_name'];
            }
        }
    }
    $out = [];
    $n = 1;
    foreach ($order as $icode) {
        $row = $map[$icode];
        $st = pop_compare_status($row['cur_name'], $row['cmp_name'], $row['cur_qty'], $row['cmp_qty'], $row['cur_usage'], $row['cmp_usage']);
        $row['seq'] = $n++;
        $row['compare_key'] = $st['key'];
        $row['compare_label'] = $st['label'];
        $out[] = $row;
    }
    return $out;
}

function pop_fetch_labs($hos, $hn, $vn, $date) {
    $in = pop_hn_in($hos, $hn);
    if ($in === '') {
        return [];
    }
    $vn = trim((string)$vn);
    $date = substr(trim((string)$date), 0, 10);
    $hcols = pop_cols($hos, 'lab_head');
    $where = ["h.hn IN ($in)"];
    $rows = [];
    $vn_ok = false;
    if ($vn !== '' && pop_has($hcols, 'vn')) {
        $where_vn = $where;
        $where_vn[] = "h.vn = '" . mysqli_real_escape_string($hos, $vn) . "'";
        $sql = pop_lab_sql($where_vn);
        $rows = pop_query_all($hos, $sql);
        if ($rows) {
            $vn_ok = true;
        }
    }
    if (!$vn_ok) {
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            $d = mysqli_real_escape_string($hos, $date);
            $where[] = "(h.order_date = '$d' OR h.report_date = '$d')";
        } elseif ($vn === '') {
            return [];
        } else {
            return [];
        }
        $rows = pop_query_all($hos, pop_lab_sql($where));
    }
    $out = [];
    $seen = [];
    foreach ($rows as $r) {
        $code = trim((string)($r['lab_items_code'] ?? ''));
        $name = pop_clean($r['lab_name'] ?? '');
        if ($code === '') {
            $code = $name;
        }
        if ($code === '' || isset($seen[$code])) {
            continue;
        }
        $seen[$code] = true;
        $rdate = substr(trim((string)($r['report_date'] ?? '')), 0, 10);
        if ($rdate === '' || $rdate === '0000-00-00') {
            $rdate = substr(trim((string)($r['order_date'] ?? '')), 0, 10);
        }
        $out[] = [
            'code' => $code,
            'name' => $name !== '' ? $name : $code,
            'result' => pop_clean($r['result'] ?? ''),
            'normal' => pop_clean($r['normal'] ?? ''),
            'report_date' => $rdate,
            'report_date_be' => pop_fmt_date_be($rdate),
        ];
    }
    return $out;
}

function pop_lab_sql(array $where) {
    return "SELECT o.lab_items_code,
                   " . pop_utf8('o.lab_items_name_ref') . " AS lab_name,
                   " . pop_utf8('o.lab_order_result') . " AS result,
                   " . pop_utf8('i.lab_items_normal_value') . " AS normal,
                   h.order_date, h.report_date
            FROM lab_head h
            INNER JOIN lab_order o ON o.lab_order_number = h.lab_order_number
            LEFT JOIN lab_items i ON i.lab_items_code = o.lab_items_code
            WHERE " . implode(' AND ', $where) . "
            ORDER BY h.order_date DESC, h.report_date DESC, o.lab_items_name_ref ASC
            LIMIT 400";
}

function pop_merge_labs(array $current, array $compare) {
    $map = [];
    $order = [];
    foreach ($current as $r) {
        $code = $r['code'];
        if (!isset($map[$code])) {
            $order[] = $code;
            $map[$code] = [
                'code' => $code,
                'name' => $r['name'],
                'cur_result' => $r['result'],
                'cmp_result' => '',
                'report_date' => $r['report_date'],
                'report_date_be' => $r['report_date_be'],
                'normal' => $r['normal'],
            ];
        }
    }
    foreach ($compare as $r) {
        $code = $r['code'];
        if (!isset($map[$code])) {
            $order[] = $code;
            $map[$code] = [
                'code' => $code,
                'name' => $r['name'],
                'cur_result' => '',
                'cmp_result' => $r['result'],
                'report_date' => $r['report_date'],
                'report_date_be' => $r['report_date_be'],
                'normal' => $r['normal'],
            ];
        } else {
            $map[$code]['cmp_result'] = $r['result'];
            if ($map[$code]['name'] === '') {
                $map[$code]['name'] = $r['name'];
            }
        }
    }
    $out = [];
    foreach ($order as $code) {
        $out[] = $map[$code];
    }
    return $out;
}

function pop_fetch_cost($hos, $vn) {
    $empty = ['total' => 0, 'ed' => 0, 'neg' => 0, 'discount' => 0, 'claim' => 0];
    $vn = trim((string)$vn);
    if ($vn === '') {
        return $empty;
    }
    $cols = pop_cols($hos, 'vn_stat');
    if (!$cols) {
        return $empty;
    }
    $income = pop_col($cols, ['income'], '0');
    $paid = pop_col($cols, ['paid_money'], '0');
    $uc = pop_col($cols, ['uc_money'], '0');
    $item = pop_col($cols, ['item_money', 'rcpt_money'], '0');
    $disc = pop_col($cols, ['discount_money'], '0');
    $vn_esc = mysqli_real_escape_string($hos, $vn);
    $row = pop_query_one($hos, "SELECT $income AS income, $paid AS paid_money, $uc AS uc_money, $item AS item_money, $disc AS discount_money
        FROM vn_stat WHERE vn = '$vn_esc' LIMIT 1");
    if (!$row) {
        return $empty;
    }
    $total = (float)($row['income'] ?? 0);
    $ed = (float)($row['paid_money'] ?? 0);
    $ucv = (float)($row['uc_money'] ?? 0);
    $neg = $ucv > 0 ? $ucv : max(0, $total - $ed);
    $claim = (float)($row['item_money'] ?? 0);
    if ($claim === $total) {
        $claim = 0;
    }
    return [
        'total' => $total,
        'ed' => $ed,
        'neg' => $neg,
        'discount' => (float)($row['discount_money'] ?? 0),
        'claim' => $claim,
    ];
}

function pop_fetch_appointments($hos, $hn, $vn = '') {
    $in = pop_hn_in($hos, $hn);
    if ($in === '') {
        return [];
    }
    $vn = trim((string)$vn);
    $sql = "SELECT o.oapp_id, o.vn, o.vstdate, o.nextdate, o.nexttime, o.clinic,
                   " . pop_utf8('c.name') . " AS clinic_name,
                   " . pop_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . " AS doctor_name
            FROM oapp o
            LEFT JOIN clinic c ON c.clinic = o.clinic
            LEFT JOIN doctor doc ON doc.code = o.doctor
            WHERE o.hn IN ($in)
              AND o.nextdate IS NOT NULL AND o.nextdate <> '0000-00-00'
            ORDER BY o.nextdate DESC, o.oapp_id DESC
            LIMIT 40";
    $rows = pop_query_all($hos, $sql);
    if (!$rows) {
        $rows = pop_query_all($hos, "SELECT o.oapp_id, o.vn, o.vstdate, o.nextdate, o.nexttime, o.clinic,
                   " . pop_utf8('c.name') . " AS clinic_name,
                   '' AS doctor_name
            FROM oapp o
            LEFT JOIN clinic c ON c.clinic = o.clinic
            WHERE o.hn IN ($in)
              AND o.nextdate IS NOT NULL AND o.nextdate <> '0000-00-00'
            ORDER BY o.nextdate DESC, o.oapp_id DESC
            LIMIT 40");
    }
    $today = date('Y-m-d');
    $out = [];
    foreach ($rows as $r) {
        $next = substr(trim((string)($r['nextdate'] ?? '')), 0, 10);
        if ($next === '' || $next === '0000-00-00') {
            continue;
        }
        $days = null;
        $ts = strtotime($next);
        if ($ts) {
            $days = (int)round(($ts - strtotime($today)) / 86400);
        }
        $out[] = [
            'vn' => trim((string)($r['vn'] ?? '')),
            'vstdate' => substr(trim((string)($r['vstdate'] ?? '')), 0, 10),
            'nextdate' => $next,
            'nextdate_be' => pop_fmt_date_be($next),
            'nexttime' => pop_fmt_time($r['nexttime'] ?? ''),
            'clinic' => trim((string)($r['clinic'] ?? '')),
            'clinic_name' => pop_clean($r['clinic_name'] ?? ''),
            'doctor_name' => pop_clean($r['doctor_name'] ?? ''),
            'days' => $days,
            'is_future' => $next >= $today,
            'from_current' => $vn !== '' && trim((string)($r['vn'] ?? '')) === $vn,
        ];
    }
    return $out;
}

function pop_lookup($con, $hn, $vn = '', $an = '', $date = '', $compare_vn = '', $compare_an = '') {
    $hos = pop_connect($con);
    if (!$hos) {
        return ['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อฐานข้อมูล HOSxP ได้'];
    }
    $patient = pop_fetch_patient($hos, $hn);
    if (!$patient) {
        mysqli_close($hos);
        return ['ok' => false, 'error' => 'ไม่พบ HN นี้ใน HOSxP'];
    }
    $hn_real = $patient['hn'];
    $visits = pop_fetch_visits($hos, $hn_real, 80);
    $visits = pop_attach_drug_counts($hos, $hn_real, $visits);
    $current = pop_find_visit($visits, $vn, $an, $date);
    if (!$current && $visits) {
        $current = $visits[0];
    }
    $compare = null;
    if ($compare_vn !== '' || $compare_an !== '') {
        $compare = pop_find_visit($visits, $compare_vn, $compare_an, '');
    }
    if (!$compare && $current) {
        $compare = pop_next_visit_with_drugs($visits, $current['key']);
    }
    $cur_vn = $current['vn'] ?? '';
    $cur_an = $current['an'] ?? '';
    $cur_date = $current['vstdate'] ?? '';
    $cmp_vn = $compare['vn'] ?? '';
    $cmp_an = $compare['an'] ?? '';
    $cmp_date = $compare['vstdate'] ?? '';

    $screen_cur = pop_fetch_screen($hos, $cur_vn, $hn_real, $cur_date);
    $screen_cmp = $compare
        ? pop_fetch_screen($hos, $cmp_vn, $hn_real, $cmp_date)
        : ['bw' => '', 'height' => '', 'bmi' => '', 'bps' => '', 'pulse' => '', 'cc' => '', 'pe' => '', 'hpi' => '', 'pmh' => ''];

    $drugs_cur = pop_fetch_drugs($hos, $cur_an !== '' && ($current['type'] ?? '') === 'I' ? '' : $cur_vn, $cur_an !== '' && ($current['type'] ?? '') === 'I' ? $cur_an : '');
    if (!$drugs_cur && $cur_vn !== '') {
        $drugs_cur = pop_fetch_drugs($hos, $cur_vn, '');
    }
    $drugs_cmp = [];
    if ($compare) {
        $drugs_cmp = pop_fetch_drugs($hos, ($compare['type'] ?? '') === 'I' ? '' : $cmp_vn, ($compare['type'] ?? '') === 'I' ? $cmp_an : '');
        if (!$drugs_cmp && $cmp_vn !== '') {
            $drugs_cmp = pop_fetch_drugs($hos, $cmp_vn, '');
        }
    }
    $labs_cur = pop_fetch_labs($hos, $hn_real, $cur_vn, $cur_date);
    $labs_cmp = $compare ? pop_fetch_labs($hos, $hn_real, $cmp_vn, $cmp_date) : [];
    $cost = pop_fetch_cost($hos, $cur_vn);
    $appts = pop_fetch_appointments($hos, $hn_real, $cur_vn);
    $allergy = pop_fetch_allergy($hos, $hn_real);
    $hosxp_notes = pop_fetch_hosxp_notes($hos, $hn_real);
    $patient['age_text'] = pop_age_text($patient['birthday'], $cur_date !== '' ? $cur_date : date('Y-m-d'));

    $next_from_visit = null;
    foreach ($appts as $a) {
        if (!empty($a['from_current']) && !empty($a['is_future'])) {
            $next_from_visit = $a;
            break;
        }
    }
    if (!$next_from_visit) {
        foreach ($appts as $a) {
            if (!empty($a['is_future'])) {
                $next_from_visit = $a;
                break;
            }
        }
    }
    $future_appts = [];
    foreach ($appts as $a) {
        if (!empty($a['is_future'])) {
            $future_appts[] = $a;
        }
    }

    mysqli_close($hos);
    return [
        'ok' => true,
        'patient' => $patient,
        'allergy' => $allergy,
        'hosxp_notes' => $hosxp_notes,
        'current' => $current,
        'compare' => $compare,
        'visits' => $visits,
        'screen' => $screen_cur,
        'screen_compare' => $screen_cmp,
        'drugs' => pop_merge_drugs($drugs_cur, $drugs_cmp),
        'labs' => pop_merge_labs($labs_cur, $labs_cmp),
        'cost' => $cost,
        'appointments' => $future_appts,
        'next_appointment' => $next_from_visit,
    ];
}
