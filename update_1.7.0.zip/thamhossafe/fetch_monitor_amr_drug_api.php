<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/amr_helper.php');
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_sensitivity_helper.php';
require_once __DIR__ . '/amr_mlab_helper.php';
require_once __DIR__ . '/monitor_lab_renal_dosing_helper.php';
require_once __DIR__ . '/monitor_amr_drug_helper.php';
mysqli_set_charset($con, 'utf8');
set_time_limit(90);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

amr_dict_ensure_tables($con);
amr_dict_prime($con);
amr_sens_drug_level_prime($con);

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = [];
}
$src = array_merge($_GET, $input);
$action = trim((string)($src['action'] ?? 'list'));

function mad_json(array $payload) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'steward_mode') {
    mad_json([
        'status' => 'success',
        'steward' => amr_sens_steward_mode_meta(amr_sens_steward_mode($con)),
    ]);
}

if ($action === 'steward_mode_save') {
    $mode = amr_sens_steward_mode_save($con, $src['steward_mode'] ?? $src['mode'] ?? 'both');
    mad_json([
        'status' => 'success',
        'message' => 'บันทึกโหมดประเมินแล้ว',
        'steward' => amr_sens_steward_mode_meta($mode),
    ]);
}

if ($action === 'skip_method_save') {
    $list = mad_skip_method_save($con, $src['keywords'] ?? $src['skip_method_keywords'] ?? []);
    mad_json([
        'status' => 'success',
        'message' => 'บันทึกคำยกเว้นวิธีใช้แล้ว',
        'skip_method_keywords' => $list,
    ]);
}

$hos = hosxp_connect($con, 90);
if (!$hos) {
    mad_json(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้']);
}
hosxp_extend_read_timeout($hos, 90);

if ($action === 'list') {
    $lookback = mad_parse_lookback($src['lookback'] ?? '7d');
    $scan = mad_scan($hos, $con, $lookback['key']);
    if ($scan['error'] !== '') {
        mad_json(['status' => 'error', 'message' => $scan['error']]);
    }
    mad_json([
        'status' => 'success',
        'rows' => $scan['rows'],
        'rows_ok' => $scan['rows_ok'] ?? [],
        'rows_caution' => $scan['rows_caution'] ?? [],
        'rows_renal' => $scan['rows_renal'] ?? [],
        'rows_escalate' => $scan['rows_escalate'] ?? [],
        'rows_deescalate' => $scan['rows_deescalate'] ?? [],
        'steward' => $scan['steward'] ?? amr_sens_steward_mode_meta(amr_sens_steward_mode($con)),
        'meta' => $scan['meta'],
        'source' => ($scan['meta']['micro_source'] ?? 'hosxp'),
        'source_label' => ($scan['meta']['micro_source_label'] ?? 'HOSxP lab_head'),
    ]);
}

mad_json(['status' => 'error', 'message' => 'ไม่รู้จัก action']);
