<?php
/**
 * Monitor ยาเหลือบ้าน OPD
 * ใบยา OPD วันนี้ เทียบยา OPD เดิมของ HN เดียวกันที่ยังเหลืออยู่
 */

require_once __DIR__ . '/monitor_home_med_helper.php';

function mopd_default_config() {
    $cfg = mhm_default_config();
    $cfg['min_remaining_value'] = 0;
    $cfg['only_off_appointment'] = 0;
    return $cfg;
}

function mopd_ensure_tables($con) {
    $q = mysqli_query($con, "SHOW TABLES LIKE 'monitor_opd_dup_config'");
    if ($q && mysqli_num_rows($q) > 0) {
        mysqli_query($con, "INSERT IGNORE INTO monitor_opd_dup_config (id) VALUES (1)");
        mopd_ensure_config_columns($con);
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_opd_dup.sql');
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '' && !mysqli_query($con, $stmt)) {
            return false;
        }
    }
    mopd_ensure_config_columns($con);
    return true;
}

function mopd_ensure_config_columns($con) {
    $need = [
        'hide_low_remaining' => "TINYINT(1) NOT NULL DEFAULT 1",
        'hide_low_remaining_days' => "INT NOT NULL DEFAULT 20",
        'hide_short_hme' => "TINYINT(1) NOT NULL DEFAULT 1",
        'hide_short_hme_days' => "INT NOT NULL DEFAULT 14",
        'unitprice_exception' => "DECIMAL(10,2) NOT NULL DEFAULT 50.00",
        'min_remaining_value' => "DECIMAL(10,2) NOT NULL DEFAULT 0.00",
        'only_off_appointment' => "TINYINT(1) NOT NULL DEFAULT 0",
    ];
    foreach ($need as $col => $def) {
        $q = @mysqli_query($con, "SHOW COLUMNS FROM monitor_opd_dup_config LIKE '$col'");
        if ($q && mysqli_num_rows($q) === 0) {
            @mysqli_query($con, "ALTER TABLE monitor_opd_dup_config ADD COLUMN $col $def");
        }
    }
    @mysqli_query($con, "ALTER TABLE monitor_opd_dup_config
        MODIFY COLUMN alert_level_remaining VARCHAR(10) NOT NULL DEFAULT 'soft'");
    @mysqli_query($con, "ALTER TABLE monitor_opd_dup_config
        MODIFY COLUMN alert_level_unknown VARCHAR(10) NOT NULL DEFAULT 'soft'");
    $flag = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='mopd_soft_alert_default_v1' LIMIT 1");
    if (!$flag || mysqli_num_rows($flag) === 0) {
        @mysqli_query($con, "UPDATE monitor_opd_dup_config SET alert_level_remaining='soft' WHERE id=1 AND LOWER(IFNULL(alert_level_remaining,''))='hard'");
        @mysqli_query($con, "INSERT IGNORE INTO sys_config (config_name, config_value) VALUES ('mopd_soft_alert_default_v1','1')");
    }
}

function mopd_get_config($con) {
    mopd_ensure_tables($con);
    $cfg = mopd_default_config();
    $q = mysqli_query($con, 'SELECT * FROM monitor_opd_dup_config WHERE id = 1 LIMIT 1');
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return $cfg;
    }
    $cfg['lookback_days'] = max(7, min(365, (int)($row['lookback_days'] ?? 90)));
    $cfg['match_mode'] = mhm_normalize_match_mode($row['match_mode'] ?? 'icode_or_tmt');
    $cfg['min_remaining_days'] = max(0, min(180, (int)($row['min_remaining_days'] ?? 1)));
    $cfg['include_unknown_remaining'] = !empty($row['include_unknown_remaining']) ? 1 : 0;
    $cfg['exclude_prn'] = !empty($row['exclude_prn']) ? 1 : 0;
    $cfg['alert_level_remaining'] = mhm_normalize_alert_level($row['alert_level_remaining'] ?? 'soft');
    $cfg['alert_level_unknown'] = mhm_normalize_alert_level($row['alert_level_unknown'] ?? 'soft');
    $cfg['exclude_icodes'] = mhm_decode_exclude_icodes($row['exclude_icodes'] ?? '[]');
    $cfg['monitor_active'] = !empty($row['monitor_active']) ? 1 : 0;
    $cfg['hide_low_remaining'] = array_key_exists('hide_low_remaining', $row)
        ? (!empty($row['hide_low_remaining']) ? 1 : 0) : 1;
    $cfg['hide_low_remaining_days'] = max(0, min(365, (int)($row['hide_low_remaining_days'] ?? 20)));
    $cfg['hide_short_hme'] = array_key_exists('hide_short_hme', $row)
        ? (!empty($row['hide_short_hme']) ? 1 : 0) : 1;
    $cfg['hide_short_hme_days'] = max(0, min(365, (int)($row['hide_short_hme_days'] ?? 14)));
    $cfg['unitprice_exception'] = max(0, (float)($row['unitprice_exception'] ?? 50));
    $cfg['min_remaining_value'] = max(0, (float)($row['min_remaining_value'] ?? 0));
    $cfg['only_off_appointment'] = !empty($row['only_off_appointment']) ? 1 : 0;
    return $cfg;
}

function mopd_save_config($con, array $in) {
    mopd_ensure_tables($con);
    $lookback = max(7, min(365, (int)($in['lookback_days'] ?? 90)));
    $mode = mhm_normalize_match_mode($in['match_mode'] ?? 'icode_or_tmt');
    $min_rem = max(0, min(180, (int)($in['min_remaining_days'] ?? 1)));
    $unk = !empty($in['include_unknown_remaining']) ? 1 : 0;
    $prn = !empty($in['exclude_prn']) ? 1 : 0;
    $lvl_rem = mhm_normalize_alert_level($in['alert_level_remaining'] ?? 'soft');
    $lvl_unk = mhm_normalize_alert_level($in['alert_level_unknown'] ?? 'soft');
    $active = !empty($in['monitor_active']) ? 1 : 0;
    $hide_low = !empty($in['hide_low_remaining']) ? 1 : 0;
    $hide_days = max(0, min(365, (int)($in['hide_low_remaining_days'] ?? 20)));
    $hide_short = !empty($in['hide_short_hme']) ? 1 : 0;
    $hide_short_days = max(0, min(365, (int)($in['hide_short_hme_days'] ?? 14)));
    $price_ex = max(0, (float)($in['unitprice_exception'] ?? 50));
    $price_sql = number_format($price_ex, 2, '.', '');
    $min_val = max(0, (float)($in['min_remaining_value'] ?? 0));
    $min_val_sql = number_format($min_val, 2, '.', '');
    $off_appt = !empty($in['only_off_appointment']) ? 1 : 0;
    $exclude = mhm_decode_exclude_icodes($in['exclude_icodes'] ?? []);
    $exclude_json = mysqli_real_escape_string($con, json_encode(array_values($exclude), JSON_UNESCAPED_UNICODE));
    $mode_esc = mysqli_real_escape_string($con, $mode);
    $lvl_rem_esc = mysqli_real_escape_string($con, $lvl_rem);
    $lvl_unk_esc = mysqli_real_escape_string($con, $lvl_unk);
    $sql = "INSERT INTO monitor_opd_dup_config
            (id, lookback_days, match_mode, min_remaining_days, include_unknown_remaining,
             exclude_prn, alert_level_remaining, alert_level_unknown, exclude_icodes, monitor_active,
             hide_low_remaining, hide_low_remaining_days, hide_short_hme, hide_short_hme_days,
             unitprice_exception, min_remaining_value, only_off_appointment)
            VALUES (1, $lookback, '$mode_esc', $min_rem, $unk, $prn, '$lvl_rem_esc', '$lvl_unk_esc', '$exclude_json', $active,
                    $hide_low, $hide_days, $hide_short, $hide_short_days, $price_sql, $min_val_sql, $off_appt)
            ON DUPLICATE KEY UPDATE
                lookback_days = VALUES(lookback_days),
                match_mode = VALUES(match_mode),
                min_remaining_days = VALUES(min_remaining_days),
                include_unknown_remaining = VALUES(include_unknown_remaining),
                exclude_prn = VALUES(exclude_prn),
                alert_level_remaining = VALUES(alert_level_remaining),
                alert_level_unknown = VALUES(alert_level_unknown),
                exclude_icodes = VALUES(exclude_icodes),
                monitor_active = VALUES(monitor_active),
                hide_low_remaining = VALUES(hide_low_remaining),
                hide_low_remaining_days = VALUES(hide_low_remaining_days),
                hide_short_hme = VALUES(hide_short_hme),
                hide_short_hme_days = VALUES(hide_short_hme_days),
                unitprice_exception = VALUES(unitprice_exception),
                min_remaining_value = VALUES(min_remaining_value),
                only_off_appointment = VALUES(only_off_appointment)";
    return (bool)mysqli_query($con, $sql);
}

function mopd_sql_hn_shard($col, $shard, $shards) {
    $shards = max(1, min(16, (int)$shards));
    $shard = ((int)$shard % $shards + $shards) % $shards;
    if ($shards <= 1) {
        return '';
    }
    $col = preg_replace('/[^a-zA-Z0-9_.]/', '', (string)$col) ?: 'o.hn';
    return " AND MOD(CRC32(IFNULL(NULLIF(TRIM(LEADING '0' FROM TRIM($col)), ''), TRIM($col))), $shards) = $shard";
}

function mopd_fetch_current_opd($hos, $start_date, $end_date, $shard = 0, $shards = 1, array $hn_filter = []) {
    $start_esc = mysqli_real_escape_string($hos, $start_date);
    $end_esc = mysqli_real_escape_string($hos, $end_date);
    $order_date = mhm_sql_order_date('o');
    $method_expr = di_sql_method_expr('o');
    $tmt_expr = hosxp_sql_tmt_drug_name('d', 'tm');
    $ptname = "CAST(CONVERT(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) USING utf8) AS CHAR)";
    $clinic = "CAST(CONVERT(IFNULL(NULLIF(k.department,''), IFNULL(s.name, '')) USING utf8) AS CHAR)";
    $pttype_name = "CAST(CONVERT(IFNULL(ptt.name,'') USING utf8) AS CHAR)";
    $hn_keys = [];
    foreach ($hn_filter as $hn) {
        foreach (mhm_hn_variants($hn) as $v) {
            $hn_keys[$v] = true;
        }
    }
    $hn_sql = mhm_sql_in_list($hos, array_keys($hn_keys));
    $hn_clause = $hn_sql !== '' ? "AND o.hn IN ($hn_sql)" : '';
    $shard_sql = $hn_sql !== '' ? '' : mopd_sql_hn_shard('o.hn', $shard, $shards);
    $sql = "
        SELECT
            o.hn, o.vn, o.icode, o.qty, o.rxdate, o.rxtime, o.vstdate,
            IFNULL(o.order_no, '') AS order_no,
            $order_date AS hme_date,
            $order_date AS admit_date,
            $method_expr AS method,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
            $tmt_expr AS tmt_name,
            CAST(IFNULL(d.unitprice, 0) AS DECIMAL(16,4)) AS unitprice,
            $ptname AS ptname,
            $clinic AS ward_name,
            IFNULL(ov.pttype, '') AS pttype,
            $pttype_name AS pttype_name
        FROM opitemrece o
        INNER JOIN drugitems d ON d.icode = o.icode
        " . hosxp_sql_tmt_join('d', 'tm') . "
        " . di_sql_method_joins('o') . "
        LEFT JOIN patient p ON p.hn = o.hn
        LEFT JOIN ovst ov ON ov.vn = o.vn
        LEFT JOIN pttype ptt ON ptt.pttype = ov.pttype
        LEFT JOIN kskdepartment k ON k.depcode = ov.cur_dep
        LEFT JOIN spclty s ON s.spclty = ov.spclty
        WHERE o.vn IS NOT NULL AND o.vn <> '' AND o.vn <> '0'
          AND (o.an IS NULL OR o.an = '' OR o.an = '0')
          AND o.qty > 0
          AND o.vstdate BETWEEN '$start_esc' AND '$end_esc'
          AND $order_date BETWEEN '$start_esc' AND '$end_esc'
          $hn_clause
          $shard_sql
        LIMIT 8000
    ";
    return mhm_query_rows($hos, $sql);
}

function mopd_prior_opd_list(array $opd_list, $vn, $order_date) {
    $vn = trim((string)$vn);
    $order_date = substr(trim((string)$order_date), 0, 10);
    $out = [];
    foreach ($opd_list as $opd) {
        $ovn = trim((string)($opd['vn'] ?? ''));
        if ($vn !== '' && $ovn === $vn) {
            continue;
        }
        $d = substr(trim((string)($opd['opd_date'] ?? $opd['rxdate'] ?? '')), 0, 10);
        if ($d === '' || $d === '0000-00-00') {
            continue;
        }
        if ($order_date !== '' && $d > $order_date) {
            continue;
        }
        $out[] = $opd;
    }
    return $out;
}

/**
 * นัดที่สั่งก่อนวันมา — ใช้ตัดสินว่าวันมาตรงกับ oapp.nextdate หรือไม่
 * คืน map hn => [ ['vstdate'=>, 'nextdate'=>], ... ]
 */
function mopd_fetch_prior_appointments($hos, array $hn_list, $start_date, $end_date) {
    $keys = [];
    foreach ($hn_list as $hn) {
        foreach (mhm_hn_variants($hn) as $v) {
            $keys[$v] = true;
        }
    }
    $hn_list = array_keys($keys);
    $map = [];
    if (!$hn_list) {
        return $map;
    }
    $start_date = substr(trim((string)$start_date), 0, 10);
    $end_date = substr(trim((string)$end_date), 0, 10);
    $min_made = date('Y-m-d', strtotime($start_date . ' -540 days'));
    $min_esc = mysqli_real_escape_string($hos, $min_made);
    $end_esc = mysqli_real_escape_string($hos, $end_date);
    foreach (array_chunk($hn_list, 40) as $chunk) {
        $hn_sql = mhm_sql_in_list($hos, $chunk);
        if ($hn_sql === '') {
            continue;
        }
        $sql = "
            SELECT o.hn, o.vstdate, o.nextdate
            FROM oapp o
            WHERE o.hn IN ($hn_sql)
              AND o.vstdate IS NOT NULL AND o.vstdate <> '0000-00-00'
              AND o.nextdate IS NOT NULL AND o.nextdate <> '0000-00-00'
              AND o.vstdate >= '$min_esc'
              AND o.vstdate < '$end_esc'
        ";
        $res = mhm_query_rows($hos, $sql);
        if (empty($res['ok'])) {
            continue;
        }
        foreach ($res['rows'] as $row) {
            $made = substr(trim((string)($row['vstdate'] ?? '')), 0, 10);
            $next = substr(trim((string)($row['nextdate'] ?? '')), 0, 10);
            if ($made === '' || $next === '' || $made === '0000-00-00' || $next === '0000-00-00') {
                continue;
            }
            $item = ['vstdate' => $made, 'nextdate' => $next];
            foreach (mhm_hn_variants($row['hn'] ?? '') as $hv) {
                $map[$hv][] = $item;
            }
        }
    }
    return $map;
}

/** วันมาไม่ตรงวันนัด = เคยมีนัดที่สั่งก่อนวันมา และไม่มีนัดที่ nextdate ตรงกับวันมา */
function mopd_visit_off_appointment(array $map, $hn, $visit_date) {
    $visit_date = substr(trim((string)$visit_date), 0, 10);
    if ($visit_date === '' || $visit_date === '0000-00-00') {
        return false;
    }
    $list = [];
    foreach (mhm_hn_variants($hn) as $hv) {
        if (!empty($map[$hv]) && is_array($map[$hv])) {
            $list = $map[$hv];
            break;
        }
    }
    $had_prior = false;
    foreach ($list as $a) {
        $made = substr(trim((string)($a['vstdate'] ?? '')), 0, 10);
        $next = substr(trim((string)($a['nextdate'] ?? '')), 0, 10);
        if ($made === '' || $made >= $visit_date) {
            continue;
        }
        $had_prior = true;
        if ($next === $visit_date) {
            return false;
        }
    }
    return $had_prior;
}

function mopd_scan($con, $hos, $start_date, $end_date, $shard = 0, $shards = 1, array $hn_filter = []) {
    $cfg = mopd_get_config($con);
    $t0 = microtime(true);
    $meta = [
        'start_date' => $start_date,
        'end_date' => $end_date,
        'lookback_days' => (int)$cfg['lookback_days'],
        'match_mode' => $cfg['match_mode'],
        'hme_orders' => 0,
        'opd_orders' => 0,
        'patients' => 0,
        'duplicate_count' => 0,
        'error' => '',
        'elapsed_ms' => 0,
        'hidden_low_remaining' => 0,
        'hidden_short_hme' => 0,
        'hide_low_remaining_days' => (int)$cfg['hide_low_remaining_days'],
        'hide_short_hme_days' => (int)$cfg['hide_short_hme_days'],
        'shard' => (int)$shard,
        'shards' => (int)$shards,
        'only_off_appointment' => !empty($cfg['only_off_appointment']) ? 1 : 0,
        'skipped_on_appointment' => 0,
    ];
    if (empty($cfg['monitor_active'])) {
        $meta['error'] = 'Monitor ถูกปิดไว้ที่แท็บตั้งค่า';
        return mhm_empty_scan_result($meta);
    }

    $cur_res = mopd_fetch_current_opd($hos, $start_date, $end_date, $shard, $shards, $hn_filter);
    if (empty($cur_res['ok'])) {
        $meta['error'] = 'SQL OPD: ' . ($cur_res['error'] ?? 'unknown');
        return mhm_empty_scan_result($meta);
    }
    $cur_rows = $cur_res['rows'];
    $meta['hme_orders'] = count($cur_rows);
    if (empty($cur_rows)) {
        $meta['elapsed_ms'] = (int)round((microtime(true) - $t0) * 1000);
        return mhm_empty_scan_result($meta);
    }

    $hn_set = [];
    $hn_visit = [];
    foreach ($cur_rows as $h) {
        $ad = substr(trim((string)($h['hme_date'] ?? $h['admit_date'] ?? '')), 0, 10);
        foreach (mhm_hn_variants($h['hn'] ?? '') as $hn) {
            $hn_set[$hn] = true;
            if ($ad !== '' && $ad !== '0000-00-00') {
                if (!isset($hn_visit[$hn])) {
                    $hn_visit[$hn] = ['min' => $ad, 'max' => $ad];
                } else {
                    if ($ad < $hn_visit[$hn]['min']) {
                        $hn_visit[$hn]['min'] = $ad;
                    }
                    if ($ad > $hn_visit[$hn]['max']) {
                        $hn_visit[$hn]['max'] = $ad;
                    }
                }
            }
        }
    }

    $lookback = (int)$cfg['lookback_days'];
    $opd_all = [];
    $hn_keys = array_keys($hn_set);
    foreach (array_chunk($hn_keys, 40) as $chunk) {
        $admits = [];
        foreach ($chunk as $hn) {
            if (!empty($hn_visit[$hn]['min'])) {
                $admits[] = $hn_visit[$hn]['min'];
            }
            if (!empty($hn_visit[$hn]['max'])) {
                $admits[] = $hn_visit[$hn]['max'];
            }
        }
        $min_visit = $admits ? min($admits) : $start_date;
        $max_visit = $admits ? max($admits) : $end_date;
        $min_opd = date('Y-m-d', strtotime($min_visit . ' -' . $lookback . ' days'));
        $opd_res = mhm_fetch_opd_orders($hos, $chunk, $min_opd, $max_visit);
        if (empty($opd_res['ok'])) {
            $meta['error'] = 'SQL ยาเดิม: ' . ($opd_res['error'] ?? 'unknown');
            return mhm_empty_scan_result($meta);
        }
        foreach ($opd_res['rows'] as $row) {
            $opd_all[] = $row;
        }
    }
    $opd_by_hn = mhm_index_opd_by_hn($opd_all);
    $meta['opd_orders'] = count($opd_all);
    $appt_by_hn = mhm_fetch_next_appointments($hos, array_keys($hn_set), $start_date, $start_date, $end_date);
    $prior_appts = !empty($cfg['only_off_appointment'])
        ? mopd_fetch_prior_appointments($hos, array_keys($hn_set), $start_date, $end_date)
        : [];
    $skipped_on_appt = [];

    $exclude = array_flip($cfg['exclude_icodes']);
    $best = [];
    $by_hn = [];
    $hidden_short = 0;

    foreach ($cur_rows as $cur) {
        $icode = trim((string)($cur['icode'] ?? ''));
        if ($icode !== '' && isset($exclude[$icode])) {
            continue;
        }
        $hn = trim((string)($cur['hn'] ?? ''));
        $vn = trim((string)($cur['vn'] ?? ''));
        $order_date = substr(trim((string)($cur['hme_date'] ?? $cur['admit_date'] ?? '')), 0, 10);
        if ($hn === '' || $vn === '') {
            continue;
        }
        if (!empty($cfg['only_off_appointment']) && !mopd_visit_off_appointment($prior_appts, $hn, $order_date)) {
            $skipped_on_appt[$vn] = true;
            continue;
        }
        $hn_disp = ltrim($hn, '0') ?: $hn;
        $opd_list = [];
        foreach (mhm_hn_variants($hn) as $hv) {
            if (!empty($opd_by_hn[$hv])) {
                $opd_list = $opd_by_hn[$hv];
                break;
            }
        }
        $opd_list = mopd_prior_opd_list($opd_list, $vn, $order_date);
        $cur['an'] = $vn;
        $cur['admit_date'] = $order_date;
        $match = $opd_list ? mhm_find_best_opd_match($cur, $opd_list, $cfg) : null;
        $item = mhm_format_drug_item($cur, $match, $cfg);
        if (mhm_skip_unusable_remaining($item)) {
            continue;
        }

        if (!isset($by_hn[$hn_disp])) {
            $appt = mhm_lookup_appointment($appt_by_hn, $hn);
            $by_hn[$hn_disp] = [
                'hn' => $hn_disp,
                'hn_full' => $hn,
                'ptname' => trim((string)($cur['ptname'] ?? '')),
                'pttype' => trim((string)($cur['pttype'] ?? '')),
                'pttype_name' => trim((string)($cur['pttype_name'] ?? '')),
                'appointments' => $appt['appointments'],
                'next_appointment' => $appt['next_appointment'],
                'next_appointment_fmt' => $appt['next_appointment_fmt'],
                'next_appointment_time' => $appt['next_appointment_time'],
                'next_appointment_clinic' => $appt['next_appointment_clinic'],
                'next_appointment_doctor' => $appt['next_appointment_doctor'] ?? '',
                'admissions' => [],
            ];
        } elseif ($by_hn[$hn_disp]['ptname'] === '' && trim((string)($cur['ptname'] ?? '')) !== '') {
            $by_hn[$hn_disp]['ptname'] = trim((string)($cur['ptname'] ?? ''));
        }
        if (($by_hn[$hn_disp]['pttype_name'] ?? '') === '') {
            $ptn = trim((string)($cur['pttype_name'] ?? ''));
            if ($ptn !== '') {
                $by_hn[$hn_disp]['pttype_name'] = $ptn;
                $by_hn[$hn_disp]['pttype'] = trim((string)($cur['pttype'] ?? ''));
            }
        }
        $visit_appts = mhm_appointments_for_visit_date($by_hn[$hn_disp]['appointments'] ?? [], $order_date);
        $item = mhm_attach_appt_days(
            $item,
            $visit_appts[0]['date'] ?? '',
            $visit_appts
        );
        $item = mhm_apply_low_remaining_line($item, $cfg);
        if (mhm_skip_short_hme($item, $cfg)) {
            $hidden_short++;
            continue;
        }
        if (!isset($by_hn[$hn_disp]['admissions'][$vn])) {
            $clinic = trim((string)($cur['ward_name'] ?? ''));
            $pttype = trim((string)($cur['pttype'] ?? ''));
            $pttype_name = trim((string)($cur['pttype_name'] ?? ''));
            $by_hn[$hn_disp]['admissions'][$vn] = [
                'an' => $vn,
                'admit_date' => $order_date,
                'admit_date_fmt' => mhm_format_date($order_date),
                'ward_display' => $clinic !== '' ? $clinic : '-',
                'pttype' => $pttype,
                'pttype_name' => $pttype_name,
                'drugs' => [],
            ];
        }
        $drug_key = $icode !== '' ? $icode : ($item['hme_drug_name'] . '|' . $item['hme_date']);
        $prev = $by_hn[$hn_disp]['admissions'][$vn]['drugs'][$drug_key] ?? null;
        if (!$prev || ($item['hme_date'] > ($prev['hme_date'] ?? ''))
            || (($item['hme_date'] === ($prev['hme_date'] ?? '')) && $item['prior_opd'] && empty($prev['prior_opd']))) {
            $by_hn[$hn_disp]['admissions'][$vn]['drugs'][$drug_key] = $item;
        }

        if ($match && !empty($item['prior_opd'])) {
            $alert = mhm_build_alert($cur, $match['opd'], $match['match_type'], $cfg);
            if ($alert) {
                $alert['alert_message'] = 'ยา OPD ซ้ำกับยาเดิมที่ยังเหลือ (' . ($alert['match_label'] ?? '') . ') — เหลือประมาณ '
                    . ($alert['remaining_text'] ?? '') . ' ณ วันสั่งใหม่ — เสี่ยงจ่ายซ้ำสิ้นเปลือง';
                $akey = $vn . '|' . $icode;
                $score = (int)($alert['remaining_days'] ?? -1);
                if (!isset($best[$akey]) || $score > (int)($best[$akey]['remaining_days'] ?? -1)) {
                    $best[$akey] = $alert;
                }
            }
        }
    }

    $patients = [];
    $prior_drug_total = 0;
    $hme_drug_total = 0;
    $hidden_ans = [];
    $hidden_n = 0;
    foreach ($by_hn as $hn_row) {
        $admissions = [];
        $prior = 0;
        $hard_n = 0;
        $soft_n = 0;
        $drug_n = 0;
        $ignored_only = 0;
        foreach ($hn_row['admissions'] as $adm) {
            $drugs = array_values(array_filter($adm['drugs'], function ($d) {
                return !mhm_skip_unusable_remaining($d);
            }));
            if (empty($drugs)) {
                continue;
            }
            if (mhm_drugs_all_remaining_low($drugs, $cfg) || mhm_drugs_rx_value_below_min($drugs, $cfg)) {
                $hidden_n++;
                $an_hide = trim((string)($adm['an'] ?? ''));
                if ($an_hide !== '') {
                    $hidden_ans[$an_hide] = true;
                }
                continue;
            }
            $adm['rx_remaining_value'] = mhm_drugs_rx_remaining_value($drugs);
            usort($drugs, function ($a, $b) {
                if (!empty($a['prior_opd']) !== !empty($b['prior_opd'])) {
                    return !empty($b['prior_opd']) ? 1 : -1;
                }
                return strcmp((string)($a['hme_drug_name'] ?? ''), (string)($b['hme_drug_name'] ?? ''));
            });
            $adm['drugs'] = $drugs;
            $adm['prior_count'] = 0;
            $adm['hard_count'] = 0;
            $adm['soft_count'] = 0;
            $adm_ignored = 0;
            foreach ($drugs as $d) {
                $drug_n++;
                if (!empty($d['remaining_ignored'])) {
                    $adm_ignored++;
                }
                if (!empty($d['prior_opd'])) {
                    $adm['prior_count']++;
                    $prior++;
                }
                if (($d['alert_level'] ?? '') === 'hard') {
                    $adm['hard_count']++;
                    $hard_n++;
                } elseif (($d['alert_level'] ?? '') === 'soft') {
                    $adm['soft_count']++;
                    $soft_n++;
                }
            }
            if ($adm['prior_count'] < 1 && $adm_ignored > 0) {
                $ignored_only++;
                $drug_n -= count($drugs);
                $an_hide = trim((string)($adm['an'] ?? ''));
                if ($an_hide !== '') {
                    $hidden_ans[$an_hide] = true;
                }
                continue;
            }
            $admissions[] = $adm;
        }
        usort($admissions, function ($a, $b) {
            return strcmp((string)($b['admit_date'] ?? ''), (string)($a['admit_date'] ?? ''));
        });
        $hidden_n += $ignored_only;
        if (empty($admissions) || $drug_n < 1 || $prior < 1) {
            continue;
        }
        $hme_drug_total += $drug_n;
        $prior_drug_total += $prior;
        $latest_hme = '';
        foreach ($admissions as $adm) {
            foreach ($adm['drugs'] as $d) {
                $hd = substr(trim((string)($d['hme_date'] ?? '')), 0, 10);
                if ($hd !== '' && $hd > $latest_hme) {
                    $latest_hme = $hd;
                }
            }
        }
        $visit_appts = mhm_appointments_for_visit_date($hn_row['appointments'] ?? [], $latest_hme);
        $appointments = mhm_future_appointments($visit_appts, $latest_hme);
        $next = mhm_next_from_appointments($appointments);
        $days_appt = $next['next_appointment'] !== ''
            ? mhm_days_hme_to_appointment($latest_hme, $next['next_appointment'])
            : null;
        $patients[] = [
            'hn' => $hn_row['hn'],
            'hn_full' => $hn_row['hn_full'],
            'ptname' => $hn_row['ptname'],
            'pttype' => $hn_row['pttype'] ?? '',
            'pttype_name' => $hn_row['pttype_name'] ?? '',
            'appointments' => $hn_row['appointments'] ?? [],
            'next_appointment' => $next['next_appointment'],
            'next_appointment_fmt' => $next['next_appointment_fmt'],
            'next_appointment_time' => $next['next_appointment_time'],
            'next_appointment_clinic' => $next['next_appointment_clinic'],
            'next_appointment_doctor' => $next['next_appointment_doctor'],
            'hme_latest_date' => $latest_hme,
            'days_to_appointment' => $days_appt,
            'days_to_appointment_text' => mhm_days_hme_to_appointment_text($days_appt),
            'admissions' => $admissions,
            'drug_count' => $drug_n,
            'prior_count' => $prior,
            'hard_count' => $hard_n,
            'soft_count' => $soft_n,
        ];
    }
    usort($patients, function ($a, $b) {
        if ((int)$b['prior_count'] !== (int)$a['prior_count']) {
            return (int)$b['prior_count'] - (int)$a['prior_count'];
        }
        return strnatcmp((string)$a['hn'], (string)$b['hn']);
    });

    $hard = [];
    $soft = [];
    foreach ($best as $alert) {
        $an_a = trim((string)($alert['an'] ?? ''));
        if ($an_a !== '' && isset($hidden_ans[$an_a])) {
            continue;
        }
        if (($alert['alert_level'] ?? '') === 'hard') {
            $hard[] = $alert;
        } else {
            $soft[] = $alert;
        }
    }

    $meta['patients'] = count($patients);
    $meta['duplicate_count'] = count($hard) + count($soft);
    $meta['prior_drug_count'] = $prior_drug_total;
    $meta['hme_drug_unique'] = $hme_drug_total;
    $meta['hidden_low_remaining'] = $hidden_n;
    $meta['hidden_short_hme'] = $hidden_short;
    $meta['skipped_on_appointment'] = count($skipped_on_appt);
    $meta['elapsed_ms'] = (int)round((microtime(true) - $t0) * 1000);
    return ['hard_alerts' => $hard, 'soft_alerts' => $soft, 'patients' => $patients, 'meta' => $meta];
}
