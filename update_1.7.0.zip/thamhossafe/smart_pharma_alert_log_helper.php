<?php
/**
 * Smart Pharma — Alert Log & Intervention tracking
 */

function sp_alert_log_ensure_tables($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/smart_pharma_alert_logs.sql');
    if (!$sql) {
        return false;
    }
    if (!mysqli_multi_query($con, $sql)) {
        return false;
    }
    while (mysqli_more_results($con)) {
        mysqli_next_result($con);
    }
    $cols = [
        'alert_log_id' => "ALTER TABLE pharmacist_interventions ADD COLUMN alert_log_id INT NULL DEFAULT NULL AFTER module_key",
        'resolves_alert' => "ALTER TABLE pharmacist_interventions ADD COLUMN resolves_alert TINYINT(1) NOT NULL DEFAULT 0 AFTER alert_log_id",
        'consult_result' => "ALTER TABLE pharmacist_interventions ADD COLUMN consult_result TEXT NULL AFTER note_text",
    ];
    foreach ($cols as $col => $alter) {
        $q = mysqli_query($con, "SHOW COLUMNS FROM pharmacist_interventions LIKE '$col'");
        if ($q && mysqli_num_rows($q) === 0) {
            mysqli_query($con, $alter);
        }
    }
    $ready = true;
    return true;
}

function sp_intervention_hn_norm($hn) {
    $hn = trim((string)$hn);
    $norm = ltrim($hn, '0');
    return $norm !== '' ? $norm : $hn;
}

/** จำว่าผู้ใช้ลบ Intervention ของ visit นี้แล้ว — กัน backfill สร้างกลับมา */
function sp_intervention_remember_deletion($con, array $row) {
    sp_alert_log_ensure_tables($con);
    $hn = sp_intervention_hn_norm($row['hn'] ?? '');
    $mod = trim((string)($row['module_key'] ?? ''));
    $ymd = substr(trim((string)($row['vstdate'] ?? '')), 0, 10);
    if ($hn === '' || $mod === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $ymd)) {
        return false;
    }
    $vn = trim((string)($row['vn'] ?? ''));
    $an = trim((string)($row['an'] ?? ''));
    $alert_id = (int)($row['alert_log_id'] ?? 0);
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $mod_esc = mysqli_real_escape_string($con, $mod);
    $vn_esc = mysqli_real_escape_string($con, $vn);
    $an_esc = mysqli_real_escape_string($con, $an);
    $aid_sql = $alert_id > 0 ? (string)$alert_id : 'NULL';
    return (bool)mysqli_query($con, "INSERT IGNORE INTO pharmacist_intervention_suppressions
        (hn_norm, module_key, vstdate, vn, an, alert_log_id)
        VALUES ('$hn_esc','$mod_esc','$ymd','$vn_esc','$an_esc',$aid_sql)");
}

function sp_intervention_clear_deletion($con, $hn, $module_key, $vstdate, $vn = '', $an = '') {
    sp_alert_log_ensure_tables($con);
    $where = sp_intervention_suppression_where($con, $hn, $module_key, $vstdate, $vn, $an);
    if ($where === '') {
        return false;
    }
    return (bool)mysqli_query($con, "DELETE FROM pharmacist_intervention_suppressions WHERE $where");
}

function sp_intervention_visit_blocked($con, $hn, $module_key, $vstdate, $vn = '', $an = '') {
    sp_alert_log_ensure_tables($con);
    $where = sp_intervention_suppression_where($con, $hn, $module_key, $vstdate, $vn, $an);
    if ($where === '') {
        return false;
    }
    $q = mysqli_query($con, "SELECT id FROM pharmacist_intervention_suppressions WHERE $where LIMIT 1");
    return $q && mysqli_fetch_assoc($q);
}

function sp_intervention_suppression_where($con, $hn, $module_key, $vstdate, $vn = '', $an = '') {
    $hn = sp_intervention_hn_norm($hn);
    $mod = trim((string)$module_key);
    $ymd = substr(trim((string)$vstdate), 0, 10);
    if ($hn === '' || $mod === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $ymd)) {
        return '';
    }
    $vn = trim((string)$vn);
    $an = trim((string)$an);
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $mod_esc = mysqli_real_escape_string($con, $mod);
    $vn_esc = mysqli_real_escape_string($con, $vn);
    $an_esc = mysqli_real_escape_string($con, $an);
    $visit = [];
    if ($vn !== '') {
        $visit[] = "(vn<>'' AND vn='$vn_esc')";
        $visit[] = "(an<>'' AND an='$vn_esc')";
    }
    if ($an !== '' && $an !== $vn) {
        $visit[] = "(an<>'' AND an='$an_esc')";
        $visit[] = "(vn<>'' AND vn='$an_esc')";
    }
    if (!$visit) {
        $visit[] = "(vn='' AND an='')";
    }
    return "hn_norm='$hn_esc' AND module_key='$mod_esc' AND vstdate='$ymd' AND (" . implode(' OR ', $visit) . ")";
}

function sp_alert_log_uid($patient_type, $screen_date, $hn, $vn, $module_key) {
    return implode('|', [
        $patient_type,
        trim((string)$screen_date),
        trim((string)$hn),
        trim((string)$vn),
        trim((string)$module_key),
    ]);
}

function sp_alert_log_status_label($row) {
    if (($row['status'] ?? '') === 'resolved') {
        if (($row['resolved_by'] ?? '') === 'auto_cleared') {
            return 'แก้ไขแล้ว — ไม่พบ Alert (HOSxP)';
        }
        if (($row['resolved_by'] ?? '') === 'intervention') {
            return 'แก้ไขแล้ว — Intervention';
        }
        if (($row['resolved_by'] ?? '') === 'muted') {
            return 'ปิดการแจ้งเตือน';
        }
        return 'แก้ไขแล้ว';
    }
    if (!empty($row['has_pharmacist_note'])) {
        return 'รอแก้ไข HOSxP (มีบันทึกเภสัช)';
    }
    return 'รอการแก้ไข';
}

function sp_alert_mute_index($con, $reload = false) {
    static $idx = null;
    if ($idx !== null && !$reload) {
        return $idx;
    }
    sp_alert_log_ensure_tables($con);
    $idx = ['hn' => [], 'visit' => [], 'visit_any' => []];
    $q = mysqli_query($con, "SELECT scope, hn_norm, patient_type, visit_key FROM smart_pharma_alert_mutes");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $hn = sp_intervention_hn_norm($r['hn_norm'] ?? '');
            if (($r['scope'] ?? '') === 'hn' && $hn !== '') {
                $idx['hn'][$hn] = true;
                continue;
            }
            $ptype = ($r['patient_type'] ?? '') === 'IPD' ? 'IPD' : 'OPD';
            $key = trim((string)($r['visit_key'] ?? ''));
            if ($hn !== '' && $key !== '') {
                $idx['visit'][$hn . '|' . $ptype . '|' . $key] = true;
                $idx['visit_any'][$hn . '|' . $key] = true;
            }
        }
    }
    return $idx;
}

function sp_alert_mute_visit_parts($patient_type, $vn, $an) {
    $ptype = $patient_type === 'IPD' ? 'IPD' : 'OPD';
    $vn = trim((string)$vn);
    $an = trim((string)$an);
    if ($ptype === 'IPD') {
        $key = ($an !== '' && $an !== '0') ? $an : $vn;
    } else {
        $key = $vn !== '' ? $vn : $an;
    }
    return [$ptype, $key];
}

function sp_alert_mute_matches_patient($con, $patient_type, $hn, $vn = '', $an = '') {
    $idx = sp_alert_mute_index($con);
    $norm = sp_intervention_hn_norm($hn);
    if ($norm !== '' && !empty($idx['hn'][$norm])) {
        return true;
    }
    list($ptype, $key) = sp_alert_mute_visit_parts($patient_type, $vn, $an);
    if ($norm !== '' && $key !== '' && !empty($idx['visit'][$norm . '|' . $ptype . '|' . $key])) {
        return true;
    }
    foreach ([trim((string)$vn), trim((string)$an)] as $candidate) {
        if ($candidate === '' || $candidate === '0') {
            continue;
        }
        if ($norm !== '' && !empty($idx['visit_any'][$norm . '|' . $candidate])) {
            return true;
        }
    }
    return false;
}

function sp_alert_mute_filter_rows($con, array $rows) {
    if (!$rows) {
        return $rows;
    }
    $idx = sp_alert_mute_index($con);
    if (!$idx['hn'] && empty($idx['visit_any'])) {
        return $rows;
    }
    $out = [];
    foreach ($rows as $row) {
        if (!is_array($row)) {
            $out[] = $row;
            continue;
        }
        if (!empty($row['visits']) && is_array($row['visits'])) {
            $row['visits'] = sp_alert_mute_filter_rows($con, $row['visits']);
            if (!$row['visits']) {
                continue;
            }
            $out[] = $row;
            continue;
        }
        $hn = $row['hn'] ?? $row['hn_full'] ?? '';
        $vn = $row['vn'] ?? $row['drug1_vn'] ?? '';
        $an = $row['an'] ?? '';
        $ptype = $row['patient_type'] ?? $row['type_patient'] ?? '';
        if (sp_alert_mute_matches_patient($con, $ptype, $hn, $vn, $an)) {
            continue;
        }
        $out[] = $row;
    }
    return array_values($out);
}

function sp_apply_alert_mutes($con, $patient_type, array $rows) {
    if (!$rows) {
        return $rows;
    }
    $idx = sp_alert_mute_index($con);
    if (!$idx['hn'] && !$idx['visit'] && empty($idx['visit_any'])) {
        return $rows;
    }
    foreach ($rows as &$row) {
        $hn = $row['hn_full'] ?? $row['hn'] ?? '';
        $vn = $row['vn'] ?? '';
        $an = $row['an'] ?? '';
        if (!sp_alert_mute_matches_patient($con, $patient_type, $hn, $vn, $an)) {
            continue;
        }
        if (!isset($row['modules']) || !is_array($row['modules'])) {
            continue;
        }
        $has_alert = false;
        $has_hard = false;
        $pending = false;
        foreach ($row['modules'] as &$mod) {
            if (($mod['status'] ?? '') === 'alert') {
                $mod['status'] = 'pass';
                $mod['level'] = '';
            }
            if (($mod['status'] ?? '') === 'alert') {
                $has_alert = true;
                if (($mod['level'] ?? '') === 'hard') {
                    $has_hard = true;
                }
            } elseif (($mod['status'] ?? '') === 'pending') {
                $pending = true;
            }
        }
        unset($mod);
        if ($has_alert) {
            $row['overall'] = 'alert';
            $row['overall_level'] = $has_hard ? 'hard' : 'soft';
        } elseif ($pending) {
            $row['overall'] = 'pending';
            $row['overall_level'] = '';
        } else {
            $row['overall'] = 'pass';
            $row['overall_level'] = '';
        }
    }
    unset($row);
    return $rows;
}

function sp_alert_mute_resolve_open($con, $scope, $hn, $patient_type = '', $visit_key = '') {
    $norm = sp_intervention_hn_norm($hn);
    if ($norm === '') {
        return 0;
    }
    $norm_esc = mysqli_real_escape_string($con, $norm);
    $where = "(TRIM(LEADING '0' FROM hn)='$norm_esc' OR hn='$norm_esc') AND status='pending'";
    if ($scope === 'visit') {
        $ptype = $patient_type === 'IPD' ? 'IPD' : 'OPD';
        $key = trim((string)$visit_key);
        if ($key === '') {
            return 0;
        }
        $key_esc = mysqli_real_escape_string($con, $key);
        $ptype_esc = mysqli_real_escape_string($con, $ptype);
        $where .= " AND patient_type='$ptype_esc' AND (vn='$key_esc' OR an='$key_esc')";
    }
    $q = mysqli_query($con, "SELECT id, patient_type, screen_date, hn, vn, module_key FROM smart_pharma_alert_logs WHERE $where");
    if (!$q) {
        return 0;
    }
    $n = 0;
    require_once __DIR__ . '/smart_pharma_notify_helper.php';
    while ($row = mysqli_fetch_assoc($q)) {
        $id = (int)$row['id'];
        if (!mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
            status='resolved', resolved_by='muted', resolved_at=NOW()
            WHERE id=$id AND status='pending'")) {
            continue;
        }
        if (mysqli_affected_rows($con) > 0) {
            sp_notify_clear_sent_for_alert(
                $con,
                $row['patient_type'] ?? '',
                $row['screen_date'] ?? '',
                $row['hn'] ?? '',
                $row['vn'] ?? '',
                $row['module_key'] ?? ''
            );
            $n++;
        }
    }
    return $n;
}

function sp_alert_mute_add($con, $scope, $hn, $patient_type, $vn, $an, $user_id, $user_name) {
    sp_alert_log_ensure_tables($con);
    $norm = sp_intervention_hn_norm($hn);
    if ($norm === '') {
        return ['ok' => false, 'message' => 'ไม่พบ HN'];
    }
    $scope = $scope === 'hn' ? 'hn' : 'visit';
    $ptype = '';
    $key = '';
    if ($scope === 'visit') {
        list($ptype, $key) = sp_alert_mute_visit_parts($patient_type, $vn, $an);
        if ($key === '') {
            return ['ok' => false, 'message' => 'ไม่พบ VN หรือ AN ของ visit นี้'];
        }
    }
    $hn_esc = mysqli_real_escape_string($con, $norm);
    $ptype_esc = mysqli_real_escape_string($con, $ptype);
    $key_esc = mysqli_real_escape_string($con, $key);
    $name_esc = mysqli_real_escape_string($con, (string)$user_name);
    $uid = (int)$user_id;
    $uid_sql = $uid > 0 ? (string)$uid : 'NULL';
    $ok = mysqli_query($con, "INSERT INTO smart_pharma_alert_mutes
        (scope, hn_norm, patient_type, visit_key, created_by, created_name)
        VALUES ('$scope','$hn_esc','$ptype_esc','$key_esc',$uid_sql,'$name_esc')
        ON DUPLICATE KEY UPDATE created_by=$uid_sql, created_name='$name_esc', created_at=NOW()");
    if (!$ok) {
        return ['ok' => false, 'message' => 'ปิดการแจ้งเตือนไม่สำเร็จ: ' . mysqli_error($con)];
    }
    sp_alert_mute_index($con, true);
    $closed = sp_alert_mute_resolve_open($con, $scope, $norm, $ptype, $key);
    if ($scope === 'hn') {
        $message = 'ปิดการแจ้งเตือนของ HN นี้ทุกครั้งแล้ว';
    } else {
        $label = $ptype === 'IPD' ? 'AN' : 'VN';
        $message = 'ปิดการแจ้งเตือนของ ' . $label . ' ' . $key . ' แล้ว visit ครั้งต่อไปยังแจ้งเตือนตามปกติ';
    }
    if ($closed > 0) {
        $message .= ' และปิด Alert ที่ค้างอยู่ ' . $closed . ' รายการ';
    }
    return ['ok' => true, 'message' => $message, 'closed' => $closed];
}

function sp_alert_mute_from_intervention($con, array $data, $user_id, $user_name) {
    if (trim((string)($data['deviation_category'] ?? '')) !== 'ไม่ใช่ความคลาดเคลื่อน') {
        return '';
    }
    if (empty($data['mute_visit'])) {
        return '';
    }
    $result = sp_alert_mute_add(
        $con,
        'visit',
        $data['hn'] ?? '',
        $data['patient_type'] ?? '',
        $data['vn'] ?? '',
        $data['an'] ?? '',
        $user_id,
        $user_name
    );
    return (string)($result['message'] ?? '');
}

/**
 * @return array{id:int, action:string}|null  action: new|updated|reopened
 */
function sp_alert_log_upsert_pending($con, $patient_type, $screen_date, array $patient, $module_key, array $mod) {
    $hn = trim((string)($patient['hn_full'] ?? $patient['hn'] ?? ''));
    if ($hn === '') {
        return null;
    }
    $vn = trim((string)($patient['vn'] ?? ''));
    $level = ($mod['level'] ?? '') === 'hard' ? 'hard' : 'soft';
    $uid = sp_alert_log_uid($patient_type, $screen_date, $hn, $vn, $module_key);
    $uid_esc = mysqli_real_escape_string($con, $uid);
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $vn_esc = mysqli_real_escape_string($con, $vn);
    $an_esc = mysqli_real_escape_string($con, trim((string)($patient['an'] ?? '')));
    $ptype_esc = mysqli_real_escape_string($con, $patient_type);
    $sdate_esc = mysqli_real_escape_string($con, $screen_date);
    $vst_esc = mysqli_real_escape_string($con, $patient['vstdate'] ?? $screen_date);
    $pt_esc = mysqli_real_escape_string($con, $patient['ptname'] ?? '');
    $rxdate = trim((string)($patient['rxdate'] ?? ''));
    $rxdate_sql = ($rxdate !== '' && $rxdate !== '0000-00-00')
        ? "'" . mysqli_real_escape_string($con, $rxdate) . "'"
        : 'NULL';
    $rxtime_esc = mysqli_real_escape_string($con, $patient['rxtime'] ?? '');
    $ward_esc = mysqli_real_escape_string($con, $patient['ward_display'] ?? '');
    $mod_esc = mysqli_real_escape_string($con, $module_key);
    $lvl_esc = mysqli_real_escape_string($con, $level);
    $sum_esc = mysqli_real_escape_string($con, $mod['summary'] ?? '');
    $details = $mod['details'] ?? [];
    if (!is_array($details)) {
        $details = [];
    }
    $det_esc = mysqli_real_escape_string($con, json_encode($details, JSON_UNESCAPED_UNICODE));

    $q = mysqli_query($con, "SELECT id, status, resolved_by, alert_level, alert_summary, alert_details
        FROM smart_pharma_alert_logs WHERE alert_uid='$uid_esc' LIMIT 1");
    $existing = $q ? mysqli_fetch_assoc($q) : null;
    if (sp_alert_mute_matches_patient($con, $patient_type, $hn, $vn, $patient['an'] ?? '')) {
        if ($existing && ($existing['status'] ?? '') === 'pending') {
            $eid = (int)$existing['id'];
            mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
                status='resolved', resolved_by='muted', resolved_at=NOW()
                WHERE id=$eid AND status='pending'");
        }
        return ['id' => (int)($existing['id'] ?? 0), 'action' => 'skipped'];
    }
    if ($existing && ($existing['status'] ?? '') === 'resolved') {
        if (in_array($existing['resolved_by'] ?? '', ['intervention', 'muted'], true)) {
            mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
                alert_level='$lvl_esc', alert_summary='$sum_esc', alert_details='$det_esc',
                ptname='$pt_esc', rxdate=$rxdate_sql, rxtime='$rxtime_esc', ward_display='$ward_esc',
                last_seen_at=NOW()
                WHERE alert_uid='$uid_esc'");
            return ['id' => (int)$existing['id'], 'action' => 'kept_resolved'];
        }
        mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
            status='pending', resolved_by=NULL, resolved_at=NULL, has_pharmacist_note=0,
            alert_level='$lvl_esc', alert_summary='$sum_esc', alert_details='$det_esc',
            ptname='$pt_esc', rxdate=$rxdate_sql, rxtime='$rxtime_esc', ward_display='$ward_esc',
            last_seen_at=NOW()
            WHERE alert_uid='$uid_esc'");
        require_once __DIR__ . '/smart_pharma_notify_helper.php';
        sp_notify_clear_sent_for_alert($con, $patient_type, $screen_date, $hn, $vn, $module_key);
        return ['id' => (int)$existing['id'], 'action' => 'reopened'];
    }
    if ($existing) {
        $old_level = trim((string)($existing['alert_level'] ?? ''));
        $old_summary = trim((string)($existing['alert_summary'] ?? ''));
        $old_details = trim((string)($existing['alert_details'] ?? ''));
        $changed = ($old_level !== $level) || ($old_summary !== ($mod['summary'] ?? '')) || ($old_details !== json_encode($details, JSON_UNESCAPED_UNICODE));

        mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
            alert_level='$lvl_esc', alert_summary='$sum_esc', alert_details='$det_esc',
            ptname='$pt_esc', rxdate=$rxdate_sql, rxtime='$rxtime_esc', ward_display='$ward_esc',
            last_seen_at=NOW()
            WHERE alert_uid='$uid_esc'");
        if ($changed) {
            require_once __DIR__ . '/smart_pharma_notify_helper.php';
            sp_notify_clear_sent_for_alert($con, $patient_type, $screen_date, $hn, $vn, $module_key);
        }
        return ['id' => (int)$existing['id'], 'action' => 'updated'];
    }
    if (!mysqli_query($con, "INSERT INTO smart_pharma_alert_logs
        (alert_uid, hn, vn, an, patient_type, screen_date, vstdate, ptname, rxdate, rxtime, ward_display,
         module_key, alert_level, alert_summary, alert_details, status, last_seen_at)
        VALUES ('$uid_esc','$hn_esc','$vn_esc','$an_esc','$ptype_esc','$sdate_esc','$vst_esc','$pt_esc',
            $rxdate_sql,'$rxtime_esc','$ward_esc','$mod_esc','$lvl_esc','$sum_esc','$det_esc','pending',NOW())")) {
        return null;
    }
    return ['id' => (int)mysqli_insert_id($con), 'action' => 'new'];
}

/**
 * ซิงก์ Alert Log จากผลคัดกรอง
 * - ทั้งวัน: ปิด pending ที่ไม่พบแล้วทั้งวัน
 * - ช่วงสั้น (เช่น 30 นาที/1 ชม.): ปิดเฉพาะคนที่คัดในรอบนี้แล้วไม่พบ Alert (เช่น แก้ใน HOSxP แล้ว)
 * @return array{new:int, updated:int, reopened:int, resolved:int, skipped:int}
 */
function sp_alert_log_sync($con, $patient_type, $screen_date, array $patients, $resolve_missing = true, $only_module_key = '') {
    $stats = ['new' => 0, 'updated' => 0, 'reopened' => 0, 'resolved' => 0, 'skipped' => 0];
    $active_uids = [];
    $screened_keys = [];
    $only_module_key = trim((string)$only_module_key);

    foreach ($patients as $patient) {
        foreach (sp_alert_log_patient_match_keys($patient) as $k) {
            $screened_keys[$k] = true;
        }
        if (($patient['overall'] ?? '') !== 'alert') {
            continue;
        }
        $mods = $patient['modules'] ?? [];
        foreach ($mods as $module_key => $mod) {
            if ($only_module_key !== '' && $module_key !== $only_module_key) {
                continue;
            }
            if (($mod['status'] ?? '') !== 'alert') {
                continue;
            }
            $uid = sp_alert_log_uid(
                $patient_type,
                $screen_date,
                $patient['hn_full'] ?? $patient['hn'] ?? '',
                $patient['vn'] ?? '',
                $module_key
            );
            // ถ้ามี IPD pending อยู่แล้ว อย่าสร้าง OPD ซ้ำสำหรับ HN+วัน+โมดูลเดียวกัน
            if ($patient_type === 'OPD' && sp_alert_log_has_pending_other_type($con, 'IPD', $screen_date, $patient['hn_full'] ?? $patient['hn'] ?? '', $module_key)) {
                $stats['skipped']++;
                continue;
            }
            $active_uids[$uid] = true;
            $upsert = sp_alert_log_upsert_pending($con, $patient_type, $screen_date, $patient, $module_key, $mod);
            if (!$upsert) {
                $stats['skipped']++;
                continue;
            }
            $action = $upsert['action'] ?? 'updated';
            if ($action === 'kept_resolved') {
                $stats['skipped']++;
            } elseif (isset($stats[$action])) {
                $stats[$action]++;
            }
            // คัดกรอง IPD สำเร็จแล้ว → ปิด OPD duplicate ที่ค้างอยู่
            if ($patient_type === 'IPD') {
                $stats['resolved'] += sp_alert_log_resolve_duplicate_opd(
                    $con,
                    $screen_date,
                    $patient['hn_full'] ?? $patient['hn'] ?? '',
                    $module_key
                );
            }
        }
    }

    $ptype_esc = mysqli_real_escape_string($con, $patient_type);
    $sdate_esc = mysqli_real_escape_string($con, $screen_date);
    $mod_clause = '';
    if ($only_module_key !== '') {
        $mod_esc = mysqli_real_escape_string($con, $only_module_key);
        $mod_clause = " AND module_key='$mod_esc'";
    }
    $q = mysqli_query($con, "SELECT id, alert_uid FROM smart_pharma_alert_logs
        WHERE status='pending' AND patient_type='$ptype_esc' AND screen_date='$sdate_esc'$mod_clause");
    if ($q) {
        require_once __DIR__ . '/smart_pharma_notify_helper.php';
        while ($row = mysqli_fetch_assoc($q)) {
            $uid = $row['alert_uid'] ?? '';
            if ($uid === '' || isset($active_uids[$uid])) {
                continue;
            }
            $in_batch = sp_alert_log_uid_in_screened($uid, $screened_keys);
            if (!$resolve_missing && !$in_batch) {
                continue;
            }
            $id = (int)$row['id'];
            mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
                status='resolved', resolved_by='auto_cleared', resolved_at=NOW()
                WHERE id=$id");
            $parts = explode('|', $uid, 5);
            if (count($parts) >= 5) {
                sp_notify_clear_sent_for_alert($con, $parts[0], $parts[1], $parts[2], $parts[3], $parts[4]);
            }
            $stats['resolved']++;
        }
    }
    if ($resolve_missing) {
        $stats['resolved'] += sp_alert_log_resolve_all_opd_ipd_duplicates($con, $screen_date);
    }
    return $stats;
}

function sp_alert_log_patient_match_keys(array $patient) {
    $hn = trim((string)($patient['hn_full'] ?? $patient['hn'] ?? ''));
    $vn = trim((string)($patient['vn'] ?? ''));
    if ($hn === '') {
        return [];
    }
    $hn0 = ltrim($hn, '0');
    if ($hn0 === '') {
        $hn0 = $hn;
    }
    $keys = [$hn . '|' . $vn, $hn0 . '|' . $vn];
    return array_values(array_unique($keys));
}

function sp_alert_log_uid_in_screened($uid, array $screened_keys) {
    $parts = explode('|', (string)$uid, 5);
    if (count($parts) < 5) {
        return false;
    }
    $hn = trim((string)$parts[2]);
    $vn = trim((string)$parts[3]);
    $hn0 = ltrim($hn, '0');
    if ($hn0 === '') {
        $hn0 = $hn;
    }
    return isset($screened_keys[$hn . '|' . $vn])
        || isset($screened_keys[$hn0 . '|' . $vn]);
}

/** มี Alert pending ของ patient_type อื่น (เช่น IPD) สำหรับ HN+วัน+โมดูลเดียวกันหรือไม่ */
function sp_alert_log_has_pending_other_type($con, $other_type, $screen_date, $hn, $module_key) {
    $hn = trim((string)$hn);
    $module_key = trim((string)$module_key);
    if ($hn === '' || $module_key === '') {
        return false;
    }
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $hn_trim = mysqli_real_escape_string($con, ltrim($hn, '0'));
    $mod_esc = mysqli_real_escape_string($con, $module_key);
    $ptype_esc = mysqli_real_escape_string($con, $other_type);
    $sdate_esc = mysqli_real_escape_string($con, $screen_date);
    $q = mysqli_query($con, "SELECT id FROM smart_pharma_alert_logs
        WHERE status='pending' AND patient_type='$ptype_esc' AND screen_date='$sdate_esc'
          AND module_key='$mod_esc'
          AND (hn='$hn_esc' OR hn='$hn_trim' OR TRIM(LEADING '0' FROM hn)=TRIM(LEADING '0' FROM '$hn_esc'))
        LIMIT 1");
    return $q && mysqli_num_rows($q) > 0;
}

/** ปิด OPD pending ที่ซ้ำกับ IPD ของ HN+วัน+โมดูลเดียวกัน */
function sp_alert_log_resolve_duplicate_opd($con, $screen_date, $hn, $module_key) {
    $hn = trim((string)$hn);
    $module_key = trim((string)$module_key);
    if ($hn === '' || $module_key === '') {
        return 0;
    }
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $mod_esc = mysqli_real_escape_string($con, $module_key);
    $sdate_esc = mysqli_real_escape_string($con, $screen_date);
    $q = mysqli_query($con, "SELECT id, alert_uid, hn, vn, module_key FROM smart_pharma_alert_logs
        WHERE status='pending' AND patient_type='OPD' AND screen_date='$sdate_esc'
          AND module_key='$mod_esc'
          AND (hn='$hn_esc' OR TRIM(LEADING '0' FROM hn)=TRIM(LEADING '0' FROM '$hn_esc'))");
    if (!$q) {
        return 0;
    }
    $n = 0;
    require_once __DIR__ . '/smart_pharma_notify_helper.php';
    while ($row = mysqli_fetch_assoc($q)) {
        $id = (int)($row['id'] ?? 0);
        if ($id <= 0) {
            continue;
        }
        mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
            status='resolved', resolved_by='auto_cleared', resolved_at=NOW()
            WHERE id=$id");
        sp_notify_clear_sent_for_alert($con, 'OPD', $screen_date, $row['hn'] ?? '', $row['vn'] ?? '', $row['module_key'] ?? '');
        $n++;
    }
    return $n;
}

/** ปิดทุก OPD pending ที่ยังมี IPD pending ซ้อนกันในวันคัดกรอง */
function sp_alert_log_resolve_all_opd_ipd_duplicates($con, $screen_date) {
    $sdate_esc = mysqli_real_escape_string($con, $screen_date);
    $q = mysqli_query($con, "SELECT o.id, o.hn, o.vn, o.module_key
        FROM smart_pharma_alert_logs o
        INNER JOIN smart_pharma_alert_logs i
          ON i.screen_date = o.screen_date
         AND i.module_key = o.module_key
         AND i.patient_type = 'IPD'
         AND i.status = 'pending'
         AND TRIM(LEADING '0' FROM i.hn) = TRIM(LEADING '0' FROM o.hn)
        WHERE o.patient_type = 'OPD' AND o.status = 'pending' AND o.screen_date = '$sdate_esc'");
    if (!$q) {
        return 0;
    }
    $n = 0;
    require_once __DIR__ . '/smart_pharma_notify_helper.php';
    while ($row = mysqli_fetch_assoc($q)) {
        $id = (int)($row['id'] ?? 0);
        if ($id <= 0) {
            continue;
        }
        mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
            status='resolved', resolved_by='auto_cleared', resolved_at=NOW()
            WHERE id=$id AND status='pending'");
        sp_notify_clear_sent_for_alert($con, 'OPD', $screen_date, $row['hn'] ?? '', $row['vn'] ?? '', $row['module_key'] ?? '');
        $n++;
    }
    return $n;
}

function sp_alert_log_find_pending($con, $patient_type, $screen_date, $hn, $vn, $module_key) {
    $uid = sp_alert_log_uid($patient_type, $screen_date, $hn, $vn, $module_key);
    $uid_esc = mysqli_real_escape_string($con, $uid);
    $q = mysqli_query($con, "SELECT * FROM smart_pharma_alert_logs
        WHERE alert_uid='$uid_esc' AND status='pending' LIMIT 1");
    return $q ? mysqli_fetch_assoc($q) : null;
}

/**
 * หา Alert เมื่อ HN มีศูนย์นำหน้า หรือ VN ไม่ตรงกับตอนเปิดฟอร์ม
 * ใช้ปิดรายการบนหน้า Backup log ที่อ่านจาก log โดยตรง
 */
function sp_alert_log_find_for_intervention($con, $patient_type, $screen_date, $hn, $vn, $module_key, $an = '', $pending_only = true) {
    $ptype = in_array($patient_type, ['OPD', 'IPD'], true) ? $patient_type : 'OPD';
    $sdate = trim((string)$screen_date);
    $mod = trim((string)$module_key);
    $hn = trim((string)$hn);
    if ($hn === '' || $mod === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $sdate)) {
        return null;
    }
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $mod_esc = mysqli_real_escape_string($con, $mod);
    $sdate_esc = mysqli_real_escape_string($con, $sdate);
    $status_sql = $pending_only ? " AND status='pending'" : '';
    $q = mysqli_query($con, "SELECT * FROM smart_pharma_alert_logs
        WHERE patient_type='$ptype' AND screen_date='$sdate_esc' AND module_key='$mod_esc'
          $status_sql
          AND (hn='$hn_esc' OR TRIM(LEADING '0' FROM hn)=TRIM(LEADING '0' FROM '$hn_esc'))
        ORDER BY id DESC");
    if (!$q) {
        return null;
    }
    $rows = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $rows[] = $r;
    }
    if (!$rows) {
        return null;
    }
    $vn = trim((string)$vn);
    $an = trim((string)$an);
    if ($vn !== '') {
        foreach ($rows as $r) {
            if (trim((string)($r['vn'] ?? '')) === $vn) {
                return $r;
            }
        }
    }
    if ($an !== '') {
        foreach ($rows as $r) {
            if (trim((string)($r['an'] ?? '')) === $an) {
                return $r;
            }
        }
    }
    return $rows[0];
}

function sp_alert_log_find_by_uid($con, $patient_type, $screen_date, $hn, $vn, $module_key) {
    $uid = sp_alert_log_uid($patient_type, $screen_date, $hn, $vn, $module_key);
    $uid_esc = mysqli_real_escape_string($con, $uid);
    $q = mysqli_query($con, "SELECT * FROM smart_pharma_alert_logs WHERE alert_uid='$uid_esc' LIMIT 1");
    return $q ? mysqli_fetch_assoc($q) : null;
}

function sp_alert_log_mark_pharmacist_note($con, $alert_log_id) {
    $id = (int)$alert_log_id;
    if ($id <= 0) {
        return false;
    }
    $q = mysqli_query($con, "SELECT * FROM smart_pharma_alert_logs WHERE id=$id AND status='pending' LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return false;
    }
    $ok = mysqli_query($con, "UPDATE smart_pharma_alert_logs SET has_pharmacist_note=1 WHERE id=$id AND status='pending'");
    if ($ok) {
        require_once __DIR__ . '/smart_pharma_notify_helper.php';
        sp_notify_clear_sent_for_alert(
            $con,
            $row['patient_type'] ?? 'OPD',
            $row['screen_date'] ?? date('Y-m-d'),
            $row['hn'] ?? '',
            $row['vn'] ?? '',
            $row['module_key'] ?? ''
        );
    }
    return $ok;
}

function sp_alert_log_resolve_by_intervention($con, $alert_log_id) {
    $id = (int)$alert_log_id;
    if ($id <= 0) {
        return false;
    }
    $q = mysqli_query($con, "SELECT * FROM smart_pharma_alert_logs WHERE id=$id AND status='pending' LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return false;
    }
    $ok = mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
        status='resolved', resolved_by='intervention', resolved_at=NOW(), has_pharmacist_note=1
        WHERE id=$id AND status='pending'");
    if ($ok) {
        require_once __DIR__ . '/smart_pharma_notify_helper.php';
        sp_notify_clear_sent_for_alert(
            $con,
            $row['patient_type'] ?? 'OPD',
            $row['screen_date'] ?? date('Y-m-d'),
            $row['hn'] ?? '',
            $row['vn'] ?? '',
            $row['module_key'] ?? ''
        );
    }
    return $ok;
}

/**
 * Alert Log ล่าสุดสำหรับทดสอบ Telegram (ข้อมูลจริง)
 */
function sp_alert_log_recent_samples($con, $limit = 3) {
    $limit = max(1, min(10, (int)$limit));
    $sql = "SELECT l.*, m.label_th AS module_label
        FROM smart_pharma_alert_logs l
        LEFT JOIN smart_pharma_modules m ON m.module_key = l.module_key
        ORDER BY l.last_seen_at DESC, l.id DESC
        LIMIT $limit";
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function sp_alert_log_list($con, array $filters = []) {
    sp_alert_log_apply_monitor_settings($con);
    sp_backfill_consults_to_intervention($con);
    $where = ['1=1'];
    $start = $filters['start_date'] ?? '';
    $end = $filters['end_date'] ?? '';
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $start)) {
        $where[] = "l.screen_date >= '" . mysqli_real_escape_string($con, $start) . "'";
    }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
        $where[] = "l.screen_date <= '" . mysqli_real_escape_string($con, $end) . "'";
    }
    $status = $filters['status'] ?? '';
    if (in_array($status, ['pending', 'resolved'], true)) {
        $where[] = "l.status='" . mysqli_real_escape_string($con, $status) . "'";
    }
    $resolved_by = $filters['resolved_by'] ?? '';
    if (in_array($resolved_by, ['auto_cleared', 'intervention'], true)) {
        $where[] = "l.resolved_by='" . mysqli_real_escape_string($con, $resolved_by) . "'";
    }
    $ptype = $filters['patient_type'] ?? '';
    if (in_array($ptype, ['OPD', 'IPD'], true)) {
        $where[] = "l.patient_type='" . mysqli_real_escape_string($con, $ptype) . "'";
    }
    $mod_keys = [];
    $one = trim((string)($filters['module_key'] ?? ''));
    if ($one !== '') {
        $mod_keys[] = $one;
    }
    $many = $filters['module_keys'] ?? '';
    if (is_array($many)) {
        $mod_keys = array_merge($mod_keys, $many);
    } elseif (is_string($many) && trim($many) !== '') {
        foreach (preg_split('/[,\s]+/', $many) as $k) {
            $k = trim($k);
            if ($k !== '') {
                $mod_keys[] = $k;
            }
        }
    }
    $mod_keys = array_values(array_unique(array_filter($mod_keys)));
    if ($mod_keys) {
        $esc = [];
        foreach ($mod_keys as $k) {
            $esc[] = "'" . mysqli_real_escape_string($con, $k) . "'";
        }
        $where[] = 'l.module_key IN (' . implode(',', $esc) . ')';
    }
    $limit = max(1, min(500, (int)($filters['limit'] ?? 300)));
    $order = 'l.status ASC, l.last_seen_at DESC, l.id DESC';
    if ($resolved_by === 'auto_cleared') {
        $order = 'l.screen_date DESC, l.id DESC';
    }
    $sql = "SELECT l.*, m.label_th AS module_label,
            (SELECT COUNT(*) FROM pharmacist_interventions pi WHERE pi.alert_log_id = l.id) AS intervention_count,
            (SELECT pi.id FROM pharmacist_interventions pi WHERE pi.alert_log_id = l.id ORDER BY pi.created_at DESC, pi.id DESC LIMIT 1) AS latest_intervention_id,
            (SELECT pi.recorded_name FROM pharmacist_interventions pi WHERE pi.alert_log_id = l.id ORDER BY pi.created_at DESC, pi.id DESC LIMIT 1) AS latest_recorded_name
        FROM smart_pharma_alert_logs l
        LEFT JOIN smart_pharma_modules m ON m.module_key = l.module_key
        WHERE " . implode(' AND ', $where) . "
        ORDER BY $order
        LIMIT $limit";
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $r['status_label'] = sp_alert_log_status_label($r);
            $rows[] = $r;
        }
    }
    return $rows;
}

function sp_alert_log_interventions($con, $alert_log_id) {
    $id = (int)$alert_log_id;
    if ($id <= 0) {
        return [];
    }
    $q = mysqli_query($con, "SELECT * FROM pharmacist_interventions WHERE alert_log_id=$id ORDER BY created_at DESC");
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

function sp_alert_level_token($v) {
    $v = strtolower(trim((string)$v));
    if ($v === 'hard' || $v === 'soft') {
        return $v;
    }
    return '';
}

function sp_collect_sql_alert_levels($con, $sql, array $columns = ['alert_level']) {
    $found = [];
    $q = @mysqli_query($con, $sql);
    if (!$q) {
        return [];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        foreach ($columns as $col) {
            $tok = sp_alert_level_token($r[$col] ?? '');
            if ($tok !== '') {
                $found[$tok] = true;
            }
        }
    }
    return array_keys($found);
}

/** ระดับ Hard/Soft จากกฎที่เปิดในแต่ละ Monitor */
function sp_module_active_alert_levels($con, $module_key) {
    $mk = trim((string)$module_key);
    switch ($mk) {
        case 'hla':
            return sp_collect_sql_alert_levels($con, "SELECT alert_level FROM monitor_hla_settings WHERE active=1");
        case 'drug_usage':
            return sp_collect_sql_alert_levels($con, "SELECT alert_level FROM monitor_drug_usage_settings WHERE active=1");
        case 'max_dose':
            return sp_collect_sql_alert_levels($con, "SELECT alert_level FROM monitor_max_dose_settings WHERE active=1");
        case 'mg_ml':
            return sp_collect_sql_alert_levels($con, "SELECT alert_level FROM monitor_mg_ml_settings WHERE active=1");
        case 'dose_calculator':
            return sp_collect_sql_alert_levels($con, "SELECT alert_level FROM monitor_dose_calculator_settings WHERE active=1");
        case 'warfarin':
            return sp_collect_sql_alert_levels($con, "SELECT alert_level FROM monitor_warfarin_alert_rules WHERE active=1");
        case 'home_med':
            return sp_collect_sql_alert_levels(
                $con,
                "SELECT alert_level_remaining, alert_level_unknown FROM monitor_home_med_config WHERE id=1 AND monitor_active=1",
                ['alert_level_remaining', 'alert_level_unknown']
            );
        case 'opd_dup':
            return sp_collect_sql_alert_levels(
                $con,
                "SELECT alert_level_remaining, alert_level_unknown FROM monitor_opd_dup_config WHERE id=1 AND monitor_active=1",
                ['alert_level_remaining', 'alert_level_unknown']
            );
        case 'antibiotic':
            $lv = sp_collect_sql_alert_levels(
                $con,
                "SELECT alert_level FROM monitor_antibiotic_config WHERE id=1 AND monitor_active=1",
                ['alert_level']
            );
            foreach (sp_collect_sql_alert_levels($con, "SELECT alert_level FROM monitor_antibiotic_drugs WHERE active=1") as $tok) {
                $lv[] = $tok;
            }
            return array_values(array_unique($lv));
        case 'amr_drug':
            return ['hard', 'soft'];
        case 'opd_qty':
            return sp_collect_sql_alert_levels(
                $con,
                "SELECT alert_level_shortage, alert_level_excess FROM monitor_opd_order_qty_settings WHERE active=1",
                ['alert_level_shortage', 'alert_level_excess']
            );
        case 'di':
            return sp_collect_sql_alert_levels($con, "SELECT alert_level FROM monitor_drug_interaction_settings WHERE active_status=1");
        case 'lab_renal':
            return sp_collect_sql_alert_levels($con, "SELECT alert_level FROM drug_safety_rules WHERE active_status=1 AND lab_type IN ('GFR','CKD_EPI','SERUM_CR')");
        case 'lab_hepatic':
            return sp_collect_sql_alert_levels($con, "SELECT alert_level FROM drug_safety_rules WHERE active_status=1 AND lab_type IN ('Bilirubin','Bilirubin_xULN','AST','ALT','AST_xULN','ALT_xULN','AST_ALT_xULN','DirectBilirubin','IndirectBilirubin')");
        case 'lab_other':
            return sp_collect_sql_alert_levels($con, "SELECT alert_level FROM drug_safety_rules WHERE active_status=1 AND lab_type='CUSTOM'");
        case 'drug_allergy':
            $found = [];
            $qc = @mysqli_query($con, "SELECT config_value FROM sys_config
                WHERE config_name IN ('mda_direct_alert_level','mda_cross_alert_level')");
            if ($qc) {
                while ($r = mysqli_fetch_assoc($qc)) {
                    $tok = sp_alert_level_token($r['config_value'] ?? '');
                    if ($tok !== '') {
                        $found[$tok] = true;
                    }
                }
            }
            foreach (sp_collect_sql_alert_levels($con, "SELECT alert_level FROM monitor_drug_allergy_cross_rules WHERE active=1") as $tok) {
                $found[$tok] = true;
            }
            return array_keys($found);
        default:
            return [];
    }
}

function sp_module_uniform_alert_level($con, $module_key) {
    $levels = sp_module_active_alert_levels($con, $module_key);
    if (count($levels) === 1) {
        return $levels[0];
    }
    return null;
}

/**
 * ปรับ alert_level ของ Intervention Log ที่ยัง pending ให้ตรงการตั้งค่า Monitor
 * ถ้ากฎที่เปิดอยู่เป็น Soft ทั้งโมดูล → ลด Hard เป็น Soft (Cron จะไม่แจ้งซ้ำแบบ Hard)
 */
function sp_alert_log_apply_monitor_settings($con, $module_key = null) {
    $keys = [];
    $mk_in = trim((string)($module_key ?? ''));
    if ($mk_in !== '') {
        $keys = [$mk_in];
    } else {
        $q = @mysqli_query($con, "SELECT DISTINCT module_key FROM smart_pharma_alert_logs WHERE status='pending'");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $mk = trim((string)($r['module_key'] ?? ''));
                if ($mk !== '') {
                    $keys[] = $mk;
                }
            }
        }
    }
    $updated = 0;
    foreach ($keys as $mk) {
        $uniform = sp_module_uniform_alert_level($con, $mk);
        if ($uniform !== 'hard' && $uniform !== 'soft') {
            continue;
        }
        $mk_esc = mysqli_real_escape_string($con, $mk);
        $lvl_esc = mysqli_real_escape_string($con, $uniform);
        if (@mysqli_query($con, "UPDATE smart_pharma_alert_logs
            SET alert_level='$lvl_esc'
            WHERE module_key='$mk_esc' AND status='pending' AND alert_level<>'$lvl_esc'")) {
            $n = (int)mysqli_affected_rows($con);
            if ($n > 0) {
                $updated += $n;
            }
        }
    }
    return $updated;
}

/** เรียกหลังบันทึกการตั้งค่า Monitor เพื่อให้ Intervention Log / Cron ตามทันที */
function sp_monitor_settings_changed($con, $module_key) {
    sp_alert_log_ensure_tables($con);
    return sp_alert_log_apply_monitor_settings($con, $module_key);
}

function sp_consult_ymd($date) {
    $date = trim((string)$date);
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $date, $m)) {
        return sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[2], (int)$m[1]);
    }
    if (preg_match('/^\d{4}-\d{2}-\d{2}/', $date)) {
        return substr($date, 0, 10);
    }
    return '';
}

function sp_lab_organ_module_key($organ) {
    $organ = trim((string)$organ);
    if ($organ === 'hepatic') {
        return 'lab_hepatic';
    }
    if ($organ === 'other') {
        return 'lab_other';
    }
    return 'lab_renal';
}

function sp_sql_hn_in_list($con, $hn) {
    $hn = trim((string)$hn);
    $norm = ltrim($hn, '0');
    if ($norm === '') {
        $norm = $hn;
    }
    $vars = [$hn, $norm];
    foreach ([7, 8, 9, 10] as $w) {
        $vars[] = str_pad($norm, $w, '0', STR_PAD_LEFT);
    }
    $vars = array_unique(array_filter($vars, function ($v) {
        return $v !== '';
    }));
    $esc = [];
    foreach ($vars as $v) {
        $esc[] = "'" . mysqli_real_escape_string($con, $v) . "'";
    }
    return empty($esc) ? "''" : implode(',', $esc);
}

function sp_consult_pair_label(array $c) {
    $d1 = trim((string)($c['drug1_name'] ?? ''));
    $d2 = trim((string)($c['drug2_name'] ?? ''));
    if ($d1 !== '' && $d2 !== '') {
        return $d1 . ' + ' . $d2;
    }
    $dn = trim((string)($c['drug_name'] ?? $c['pair_label'] ?? ''));
    return $dn;
}

function sp_consult_alert_summary($module_key, array $consults) {
    $parts = [];
    foreach ($consults as $c) {
        if (!is_array($c)) {
            continue;
        }
        $lab = sp_consult_pair_label($c);
        if ($lab !== '') {
            $parts[$lab] = $lab;
        }
    }
    $list = array_slice(array_values($parts), 0, 4);
    $head = 'ปรึกษาแพทย์';
    if ($module_key === 'di') {
        $head = 'ปรึกษาแพทย์ (Drug Interaction)';
    } elseif (strpos($module_key, 'lab_') === 0) {
        $head = 'ปรึกษาแพทย์ (Monitor Lab)';
    } elseif ($module_key === 'antibiotic') {
        $head = 'ปรึกษาแพทย์ (Antibiotic)';
    } elseif ($module_key === 'opd_dup') {
        $head = 'ปรึกษาแพทย์ (ยาเหลือ OPD)';
    } elseif ($module_key === 'drug_allergy') {
        $head = 'ปรึกษาแพทย์ (Drug Allergy)';
    } elseif ($module_key === 'drug_usage') {
        $head = 'ปรึกษาแพทย์ (วิธีใช้ยา)';
    } elseif ($module_key === 'max_dose') {
        $head = 'ปรึกษาแพทย์ (Max Dose)';
    } elseif ($module_key === 'warfarin') {
        $head = 'ปรึกษาแพทย์ (Warfarin)';
    } elseif ($module_key === 'mg_ml') {
        $head = 'ปรึกษาแพทย์ (mg to mL)';
    } elseif ($module_key === 'pediatric_dose') {
        $head = 'ปรึกษาแพทย์ (ยาเด็ก)';
    } elseif ($module_key === 'home_med') {
        $head = 'ปรึกษาแพทย์ (ยากลับบ้าน)';
    } elseif ($module_key === 'dup_therapy') {
        $head = 'ปรึกษาแพทย์ (คู่ยาซ้ำซ้อน)';
    } elseif ($module_key === 'hla') {
        $head = 'ปรึกษาแพทย์ (ยีนแพ้ยา)';
    }
    return $list ? ($head . ': ' . implode('; ', $list)) : $head;
}

function sp_consult_action_label($action) {
    if ($action === 'close') {
        return 'ปิดการ Consult';
    }
    if ($action === 'save_result') {
        return 'บันทึกผล Consult';
    }
    return 'เริ่ม Consult + พิมพ์ใบปรึกษาแพทย์';
}

function sp_consult_drug_needles(array $consults) {
    $needles = [];
    foreach ($consults as $c) {
        if (!is_array($c)) {
            continue;
        }
        foreach (['drug_name', 'drug1_name', 'drug2_name', 'pair_label'] as $k) {
            $n = trim((string)($c[$k] ?? ''));
            if ($n === '') {
                continue;
            }
            $needles[] = $n;
            $base = preg_split('/[\s\/+,]+/u', $n, 2);
            if (!empty($base[0]) && strlen($base[0]) >= 3) {
                $needles[] = $base[0];
            }
        }
    }
    $needles = array_values(array_unique(array_filter($needles)));
    usort($needles, function ($a, $b) {
        return strlen($b) <=> strlen($a);
    });
    return $needles;
}

function sp_alert_summary_mentions_drugs($summary, array $needles) {
    $s = strtolower((string)$summary);
    if ($s === '' || empty($needles)) {
        return false;
    }
    foreach ($needles as $n) {
        $n = strtolower(trim((string)$n));
        if ($n !== '' && strpos($s, $n) !== false) {
            return true;
        }
    }
    return false;
}

function sp_alert_log_hn_clause($con, $hn) {
    $hn = trim((string)$hn);
    $norm = ltrim($hn, '0');
    if ($norm === '') {
        $norm = $hn;
    }
    $hn_in = sp_sql_hn_in_list($con, $hn);
    $norm_esc = mysqli_real_escape_string($con, $norm);
    return "(hn IN ($hn_in) OR TRIM(LEADING '0' FROM hn)='$norm_esc')";
}

/**
 * หา Alert Log ของ HN + โมดูล — กรองด้วยยา/วันที่ ถ้ามี
 * @return array<int, array>
 */
function sp_alert_log_match_pending_for_consult($con, $hn, $module_key, $vn = '', $an = '', $vstdate = '', array $consults = []) {
    return sp_alert_log_match_for_consult($con, $hn, $module_key, $vn, $an, $vstdate, $consults, true);
}

function sp_alert_log_match_for_consult($con, $hn, $module_key, $vn = '', $an = '', $vstdate = '', array $consults = [], $pending_only = true) {
    $hn = trim((string)$hn);
    $module_key = trim((string)$module_key);
    if ($hn === '' || $module_key === '') {
        return [];
    }
    $mod_esc = mysqli_real_escape_string($con, $module_key);
    $status_sql = $pending_only ? " AND status='pending'" : '';
    $sql = "SELECT * FROM smart_pharma_alert_logs
        WHERE module_key='$mod_esc' $status_sql
          AND " . sp_alert_log_hn_clause($con, $hn) . "
        ORDER BY last_seen_at DESC, id DESC
        LIMIT 80";
    $q = mysqli_query($con, $sql);
    if (!$q) {
        return [];
    }
    $rows = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $rows[] = $r;
    }
    if (empty($rows)) {
        return [];
    }
    $vn = trim((string)$vn);
    $an = trim((string)$an);
    $ymd = sp_consult_ymd($vstdate);
    $needles = sp_consult_drug_needles($consults);

    $by_drug = [];
    $by_visit = [];
    foreach ($rows as $r) {
        $summary = (string)($r['alert_summary'] ?? '');
        $drug_ok = $needles ? sp_alert_summary_mentions_drugs($summary, $needles) : false;
        $visit_ok = false;
        if ($vn !== '' && trim((string)($r['vn'] ?? '')) === $vn) {
            $visit_ok = true;
        }
        if ($an !== '' && trim((string)($r['an'] ?? '')) === $an) {
            $visit_ok = true;
        }
        if ($ymd !== '' && (substr((string)($r['screen_date'] ?? ''), 0, 10) === $ymd
            || substr((string)($r['vstdate'] ?? ''), 0, 10) === $ymd
            || substr((string)($r['rxdate'] ?? ''), 0, 10) === $ymd)) {
            $visit_ok = true;
        }
        if ($drug_ok) {
            $by_drug[] = $r;
        }
        if ($visit_ok) {
            $by_visit[] = $r;
        }
    }
    // มีชื่อยาจากใบปรึกษาแล้ว ปิดได้เฉพาะ Alert ที่พูดถึงยานั้น — ห้ามปัดไปยาอื่นของ HN/AN เดียวกัน
    if ($needles) {
        return $by_drug;
    }
    if ($by_visit) {
        return $by_visit;
    }
    return [];
}

function sp_alert_log_create_resolved_from_consult($con, array $info) {
    $hn = trim((string)($info['hn'] ?? ''));
    $module_key = trim((string)($info['module_key'] ?? ''));
    if ($hn === '' || $module_key === '') {
        return null;
    }
    $vn = trim((string)($info['vn'] ?? ''));
    $an = trim((string)($info['an'] ?? ''));
    $ptype = ($an !== '' && $an !== '0') ? 'IPD' : 'OPD';
    $ymd = sp_consult_ymd($info['vstdate'] ?? '') ?: date('Y-m-d');
    $hn_store = $hn;
    $norm = ltrim($hn, '0');
    if ($norm !== '' && ctype_digit($norm) && strlen($hn) < 9) {
        $hn_store = str_pad($norm, 9, '0', STR_PAD_LEFT);
    }
    $vn_key = $vn !== '' ? $vn : $an;
    $uid = sp_alert_log_uid($ptype, $ymd, $hn_store, $vn_key, $module_key);
    $uid_esc = mysqli_real_escape_string($con, $uid);
    $q = mysqli_query($con, "SELECT * FROM smart_pharma_alert_logs WHERE alert_uid='$uid_esc' LIMIT 1");
    $existing = $q ? mysqli_fetch_assoc($q) : null;
    if ($existing) {
        return $existing;
    }
    $hn_esc = mysqli_real_escape_string($con, $hn_store);
    $vn_esc = mysqli_real_escape_string($con, $vn);
    $an_esc = mysqli_real_escape_string($con, $an);
    $ptype_esc = mysqli_real_escape_string($con, $ptype);
    $ymd_esc = mysqli_real_escape_string($con, $ymd);
    $pt_esc = mysqli_real_escape_string($con, (string)($info['ptname'] ?? ''));
    $mod_esc = mysqli_real_escape_string($con, $module_key);
    $lvl = (($info['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
    $sum_esc = mysqli_real_escape_string($con, (string)($info['alert_summary'] ?? 'ปรึกษาแพทย์'));
    $ward_esc = mysqli_real_escape_string($con, (string)($info['ward_display'] ?? $info['ward_name'] ?? ''));
    $ok = mysqli_query($con, "INSERT INTO smart_pharma_alert_logs
        (alert_uid, hn, vn, an, patient_type, screen_date, vstdate, ptname, ward_display,
         module_key, alert_level, alert_summary, status, resolved_by, has_pharmacist_note,
         last_seen_at, resolved_at)
        VALUES ('$uid_esc','$hn_esc','$vn_esc','$an_esc','$ptype_esc','$ymd_esc','$ymd_esc','$pt_esc','$ward_esc',
            '$mod_esc','$lvl','$sum_esc','resolved','intervention',1,NOW(),NOW())");
    if (!$ok) {
        $q2 = mysqli_query($con, "SELECT * FROM smart_pharma_alert_logs WHERE alert_uid='$uid_esc' LIMIT 1");
        return $q2 ? mysqli_fetch_assoc($q2) : null;
    }
    $id = (int)mysqli_insert_id($con);
    $q3 = mysqli_query($con, "SELECT * FROM smart_pharma_alert_logs WHERE id=$id LIMIT 1");
    return $q3 ? mysqli_fetch_assoc($q3) : null;
}

function sp_consult_intervention_note(array $consults, $action, $extra_note = '') {
    $lines = [sp_consult_action_label($action)];
    foreach ($consults as $c) {
        if (!is_array($c)) {
            continue;
        }
        $lab = sp_consult_pair_label($c);
        if ($lab !== '') {
            $lines[] = $lab;
        }
    }
    $extra = trim((string)$extra_note);
    if ($extra !== '') {
        $lines[] = $extra;
    }
    $lines = array_values(array_unique(array_filter($lines)));
    return implode("\n", $lines);
}

/**
 * เมื่อปรึกษาแพทย์จากหน้า Monitor — ปิด Alert Log เป็น แก้ไขแล้ว — Intervention
 * และบันทึก pharmacist_interventions ให้โชว์ในแท็บ Intervention
 */
function sp_sync_consult_to_intervention($con, $module_key, array $consults, array $meta = []) {
    sp_alert_log_ensure_tables($con);
    $consults = array_values(array_filter($consults, 'is_array'));
    $module_key = trim((string)$module_key);
    if ($module_key === '' || empty($consults)) {
        return ['ok' => false, 'count' => 0];
    }
    $first = $consults[0];
    $hn = trim((string)($first['hn'] ?? ''));
    if ($hn === '') {
        return ['ok' => false, 'count' => 0];
    }
    $vn = trim((string)($first['vn'] ?? ''));
    $an = trim((string)($first['an'] ?? ''));
    $vstdate = (string)($first['vstdate'] ?? $first['order_date'] ?? $first['drug1_date'] ?? $first['firstday'] ?? '');
    if (!empty($meta['force_new'])) {
        sp_intervention_clear_deletion($con, $hn, $module_key, $vstdate, $vn, $an);
    } elseif (sp_intervention_visit_blocked($con, $hn, $module_key, $vstdate, $vn, $an)) {
        return ['ok' => true, 'count' => 0, 'suppressed' => true];
    }
    $action = trim((string)($meta['action'] ?? 'start'));
    if (array_key_exists('note_text', $meta)) {
        $note = trim((string)$meta['note_text']);
    } else {
        $note = sp_consult_intervention_note($consults, $action, $meta['note'] ?? '');
    }
    $itype = trim((string)($meta['intervention_type'] ?? 'recommend'));
    if (!in_array($itype, ['recommend', 'adjust', 'reject', 'followup', 'document'], true)) {
        $itype = 'recommend';
    }
    $dcat = trim((string)($meta['deviation_category'] ?? ''));
    if (!in_array($dcat, ['', 'ความคลาดเคลื่อนจริง', 'ไม่ใช่ความคลาดเคลื่อน'], true)) {
        $dcat = '';
    }
    $consult_result = trim((string)($meta['consult_result'] ?? ''));
    $summary = sp_consult_alert_summary($module_key, $consults);
    $actor_id = (int)($meta['actor_id'] ?? 0);
    $actor_name = trim((string)($meta['actor_name'] ?? $first['pharmacist_name'] ?? ''));
    $level = (($first['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
    foreach ($consults as $c) {
        if (($c['alert_level'] ?? '') === 'hard') {
            $level = 'hard';
            break;
        }
    }

    $logs = sp_alert_log_match_pending_for_consult($con, $hn, $module_key, $vn, $an, $vstdate, $consults);
    if (empty($logs)) {
        $logs = sp_alert_log_match_for_consult($con, $hn, $module_key, $vn, $an, $vstdate, $consults, false);
    }
    if (empty($logs)) {
        $created = sp_alert_log_create_resolved_from_consult($con, [
            'hn' => $hn,
            'vn' => $vn,
            'an' => $an,
            'ptname' => $first['ptname'] ?? '',
            'vstdate' => $vstdate,
            'module_key' => $module_key,
            'alert_level' => $level,
            'alert_summary' => $summary,
            'ward_name' => $first['ward_name'] ?? '',
        ]);
        if ($created) {
            $logs = [$created];
        }
    }
    if (empty($logs)) {
        return ['ok' => false, 'count' => 0];
    }

    $ymd = sp_consult_ymd($vstdate) ?: date('Y-m-d');
    $note_esc = mysqli_real_escape_string($con, $note);
    $itype_esc = mysqli_real_escape_string($con, $itype);
    $dcat_esc = mysqli_real_escape_string($con, $dcat);
    $consult_esc = mysqli_real_escape_string($con, $consult_result);
    $sum_esc = mysqli_real_escape_string($con, $summary);
    $uname = mysqli_real_escape_string($con, $actor_name);
    $n = 0;
    $seen = [];
    $force_new = !empty($meta['force_new']);
    $did_insert = false;
    $new_id = 0;
    foreach ($logs as $log) {
        $log_id = (int)($log['id'] ?? 0);
        if ($log_id <= 0 || isset($seen[$log_id])) {
            continue;
        }
        $seen[$log_id] = true;
        $ptype = in_array($log['patient_type'] ?? '', ['OPD', 'IPD'], true) ? $log['patient_type'] : (($an !== '' && $an !== '0') ? 'IPD' : 'OPD');
        $hn_esc = mysqli_real_escape_string($con, (string)($log['hn'] ?? $hn));
        $vn_esc = mysqli_real_escape_string($con, (string)($log['vn'] ?? $vn));
        $an_esc = mysqli_real_escape_string($con, (string)($log['an'] ?? $an));
        $ptype_esc = mysqli_real_escape_string($con, $ptype);
        $vst_esc = mysqli_real_escape_string($con, substr((string)($log['vstdate'] ?? $ymd), 0, 10) ?: $ymd);
        $mod_esc = mysqli_real_escape_string($con, (string)($log['module_key'] ?? $module_key));
        $lvl_esc = mysqli_real_escape_string($con, (($log['alert_level'] ?? $level) === 'hard') ? 'hard' : 'soft');

        $exist = null;
        if (!$force_new) {
            $exist_q = mysqli_query($con, "SELECT id FROM pharmacist_interventions
                WHERE alert_log_id=$log_id
                ORDER BY id DESC LIMIT 1");
            $exist = $exist_q ? mysqli_fetch_assoc($exist_q) : null;
        }
        if (!($force_new && $did_insert)) {
            if ($exist && !$force_new) {
                $iv_id = (int)$exist['id'];
                $extra_set = '';
                if (array_key_exists('intervention_type', $meta)) {
                    $extra_set .= ", intervention_type='$itype_esc'";
                }
                if (array_key_exists('deviation_category', $meta)) {
                    $extra_set .= ", deviation_category='$dcat_esc'";
                }
                if (array_key_exists('consult_result', $meta)) {
                    $extra_set .= ", consult_result='$consult_esc'";
                }
                mysqli_query($con, "UPDATE pharmacist_interventions SET
                    note_text='$note_esc', alert_summary='$sum_esc', resolves_alert=1
                    $extra_set,
                    recorded_by=" . ($actor_id > 0 ? $actor_id : 'recorded_by') . ",
                    recorded_name=IF('$uname'='', recorded_name, '$uname')
                    WHERE id=$iv_id");
            } else {
                $ins_ok = mysqli_query($con, "INSERT INTO pharmacist_interventions
                    (hn, vn, an, patient_type, vstdate, module_key, alert_log_id, resolves_alert,
                     alert_level, alert_summary, intervention_type, deviation_category, note_text, consult_result,
                     recorded_by, recorded_name)
                    VALUES ('$hn_esc','$vn_esc','$an_esc','$ptype_esc','$vst_esc','$mod_esc',$log_id,1,
                        '$lvl_esc','$sum_esc','$itype_esc','$dcat_esc','$note_esc','$consult_esc',
                        " . ($actor_id > 0 ? $actor_id : 'NULL') . ",'$uname')");
                if (!$ins_ok) {
                    return ['ok' => false, 'count' => $n, 'message' => 'บันทึก Intervention ไม่สำเร็จ: ' . mysqli_error($con)];
                }
                $did_insert = true;
                $new_id = (int)mysqli_insert_id($con);
            }
            $n++;
        }

        if (($log['status'] ?? '') === 'pending') {
            sp_alert_log_resolve_by_intervention($con, $log_id);
        } else {
            mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
                has_pharmacist_note=1,
                resolved_by=IF(status='resolved' AND resolved_by='auto_cleared', resolved_by, 'intervention'),
                last_seen_at=NOW()
                WHERE id=$log_id");
        }
    }
    return ['ok' => $n > 0, 'count' => $n, 'id' => $new_id];
}

/**
 * เปิด Alert ที่ถูกปิดผิด เพราะ Consult ยาอื่นของ HN เดียวกัน
 */
function sp_repair_misapplied_consult_interventions($con) {
    $q = @mysqli_query($con, "SELECT pi.id AS iv_id, pi.alert_log_id, pi.note_text, pi.alert_summary AS iv_sum,
            l.alert_summary, l.resolved_by
        FROM pharmacist_interventions pi
        INNER JOIN smart_pharma_alert_logs l ON l.id = pi.alert_log_id
        WHERE pi.intervention_type='recommend'
          AND l.status='resolved'
          AND l.resolved_by='intervention'");
    if (!$q) {
        return 0;
    }
    $n = 0;
    $reopen = [];
    $del_iv = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $drug = trim((string)($r['iv_sum'] ?? ''));
        if (preg_match('/:\s*(.+)$/u', $drug, $m)) {
            $drug = trim($m[1]);
        }
        $needles = sp_consult_drug_needles([['drug_name' => $drug]]);
        if (empty($needles)) {
            continue;
        }
        if (sp_alert_summary_mentions_drugs((string)($r['alert_summary'] ?? ''), $needles)) {
            continue;
        }
        $log_id = (int)$r['alert_log_id'];
        $iv_id = (int)$r['iv_id'];
        if ($log_id > 0) {
            $reopen[$log_id] = true;
        }
        if ($iv_id > 0) {
            $del_iv[$iv_id] = true;
        }
    }
    foreach (array_keys($reopen) as $log_id) {
        if (mysqli_query($con, "UPDATE smart_pharma_alert_logs SET
            status='pending', resolved_by=NULL, resolved_at=NULL, has_pharmacist_note=0
            WHERE id=" . (int)$log_id . " AND resolved_by='intervention'")) {
            $n++;
        }
    }
    if ($del_iv) {
        $ids = implode(',', array_map('intval', array_keys($del_iv)));
        mysqli_query($con, "DELETE FROM pharmacist_interventions WHERE id IN ($ids)");
    }
    return $n;
}

function sp_backfill_one_consult_table($con, $table, $module_or_fn) {
    $chk = @mysqli_query($con, "SHOW TABLES LIKE '" . mysqli_real_escape_string($con, $table) . "'");
    if (!$chk || mysqli_num_rows($chk) === 0) {
        return 0;
    }
    $q = mysqli_query($con, "SELECT * FROM `$table`
        WHERE status IN ('in_progress','closed','consulting')
        ORDER BY id DESC LIMIT 400");
    if (!$q) {
        return 0;
    }
    $n = 0;
    while ($r = mysqli_fetch_assoc($q)) {
        if (is_callable($module_or_fn)) {
            $mod = $module_or_fn($r);
        } else {
            $mod = (string)$module_or_fn;
        }
        if ($mod === '') {
            continue;
        }
        $action = (($r['status'] ?? '') === 'closed') ? 'close' : 'start';
        $res = sp_sync_consult_to_intervention($con, $mod, [$r], [
            'action' => $action,
            'note' => $r['consult_note'] ?? '',
            'actor_name' => $r['pharmacist_name'] ?? '',
            'actor_id' => (int)($r['pharmacist_user_id'] ?? $r['updated_by'] ?? 0),
        ]);
        if (!empty($res['ok'])) {
            $n += (int)$res['count'];
        }
    }
    return $n;
}

/** ดึง Consult ที่ทำไปแล้วขึ้น Intervention Log (เคสที่ปรึกษาก่อนมีระบบซิงก์) */
function sp_backfill_consults_to_intervention($con) {
    static $done = false;
    if ($done) {
        return 0;
    }
    $done = true;
    sp_repair_misapplied_consult_interventions($con);
    $n = 0;
    $n += sp_backfill_one_consult_table($con, 'monitor_lab_consults', function ($r) {
        return sp_lab_organ_module_key($r['organ'] ?? 'renal');
    });
    $n += sp_backfill_one_consult_table($con, 'monitor_drug_interaction_consults', 'di');
    $n += sp_backfill_one_consult_table($con, 'monitor_antibiotic_consults', 'antibiotic');
    $n += sp_backfill_one_consult_table($con, 'monitor_opd_dup_consults', 'opd_dup');
    return $n;
}
