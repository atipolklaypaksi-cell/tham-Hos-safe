<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_mg_ml_helper.php');
include(__DIR__ . '/dose_calculator_helper.php');
mysqli_set_charset($con, 'utf8');
dc_ensure_tables($con);
set_time_limit(180);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

function mmgml_req($key, $default = '') {
    if (isset($_POST[$key])) {
        return is_string($_POST[$key]) ? trim($_POST[$key]) : $_POST[$key];
    }
    if (isset($_GET[$key])) {
        return is_string($_GET[$key]) ? trim($_GET[$key]) : $_GET[$key];
    }
    return $default;
}

$start_date = (string)mmgml_req('start_date', date('Y-m-d', strtotime('-3 days')));
$end_date = (string)mmgml_req('end_date', date('Y-m-d'));
$recent_minutes = (int)mmgml_req('recent_minutes', 0);

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-3 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if (strtotime($start_date) > strtotime($end_date)) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}
if ($recent_minutes < 0) {
    $recent_minutes = 0;
}
if ($recent_minutes > 1440) {
    $recent_minutes = 1440;
}

$rule_ids = [];
foreach (explode(',', (string)mmgml_req('rule_ids', '')) as $rid) {
    $rid = (int)trim($rid);
    if ($rid > 0) {
        $rule_ids[] = $rid;
    }
}

$rules = mmgml_load_active_rules($con, $rule_ids);
if (empty($rules)) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'passed_items' => [],
        'meta' => [
            'message' => 'ยังไม่มีกฎที่เปิดใช้งาน — ไปที่แท็บตั้งค่า',
            'rule_count' => 0,
        ],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}

$rule_by_icode = mmgml_build_rule_map_by_icode($rules);
$icode_list = array_keys($rule_by_icode);

if (empty($icode_list)) {
    mysqli_close($hos);
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'passed_items' => [],
        'meta' => ['rule_count' => 0],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$t0 = microtime(true);
$hn_raw = function_exists('monitor_req_hn') ? monitor_req_hn() : (string)mmgml_req('hn', '');
$order_rows = mmgml_fetch_orders_lean($hos, $icode_list, $start_date, $end_date, $recent_minutes, 4000, $hn_raw);
$order_rows = mmgml_enrich_monitor_orders($hos, $order_rows);

$hard_alerts = [];
$soft_alerts = [];
$passed_items = [];
$unverifiable_items = [];
$seen = [];
$orders_scanned = 0;
$orders_checked = 0;

$hn_for_vitals = [];
foreach ($order_rows as $row) {
    $hn = trim($row['hn'] ?? '');
    if ($hn !== '') {
        $hn_for_vitals[$hn] = true;
    }
}

$vitals_cache = [];
$dc_overrides = [];
if (mmgml_rules_need_weight($rules) && !empty($hn_for_vitals)) {
    $lookback = mmgml_max_weight_lookback_days($rules);
    $vitals_cache = mmgml_prefetch_vitals($hos, $con, array_keys($hn_for_vitals), $start_date, $end_date, $lookback);
    $dc_overrides = dc_prefetch_vitals_overrides($con, array_keys($hn_for_vitals));
}

$pending = [];

foreach ($order_rows as $row) {
    $orders_scanned++;
    $icode = trim($row['icode'] ?? '');
    $matched_rules = $rule_by_icode[$icode] ?? [];
    if (empty($matched_rules)) {
        continue;
    }

    $method = trim(preg_replace('/\s+/u', ' ', $row['method'] ?? ''));
    $order_date = !empty($row['rxdate']) ? $row['rxdate'] : ($row['vstdate'] ?? '');
    $qty = isset($row['qty']) ? (float)$row['qty'] : null;

    foreach ($matched_rules as $rule) {
        $lookback = (int)($rule['weight_lookback_days'] ?? 365);
        $weight_info = mmgml_get_weight_info_from_cache($vitals_cache, $row['hn'] ?? '', $order_date, $lookback);
        $weight_info = dc_merge_weight_override($weight_info, $dc_overrides, $row['hn'] ?? '');
        $weight_kg = $weight_info['bw'];
        $ctx = [
            'weight_kg' => $weight_kg,
            'weight_stale' => !empty($weight_info['stale']),
            'weight_vstdate' => $weight_info['vstdate'],
            'qty' => $qty,
            'drug_name' => trim((string)($row['drug_name'] ?? '')),
        ];
        $eval = mmgml_evaluate_order($rule, $method, $ctx);
        if (($eval['status'] ?? 'skip') === 'skip') {
            continue;
        }
        $orders_checked++;

        $dedupe = implode('|', [
            $row['hn'] ?? '',
            $row['vstdate'] ?? '',
            $row['vn'] ?? '',
            $row['an'] ?? '',
            $icode,
            $row['item_no'] ?? '',
            (int)$rule['id'],
            $method,
        ]);
        if (isset($seen[$dedupe])) {
            continue;
        }
        $seen[$dedupe] = true;

        $row_for_group = $row;
        $row_for_group['method'] = $method;
        $pending[] = [
            'rule' => $rule,
            'row' => $row_for_group,
            'eval' => $eval,
            'weight_kg' => $weight_kg,
            'weight_stale' => !empty($weight_info['stale']),
            'weight_info' => $weight_info,
            'order_date' => $order_date,
            'qty' => $qty,
            'method' => $method,
            'icode' => $icode,
        ];
    }
}

mmgml_apply_combined_qty_checks($pending);

foreach ($pending as $p) {
    $rule = $p['rule'];
    $row = $p['row'];
    $eval = $p['eval'];
    $weight_info = $p['weight_info'];
    $weight_kg = $p['weight_kg'];
    $qty = $p['qty'];
    $method = $p['method'];
    $icode = $p['icode'];

    $level = mmgml_alert_level($rule);
    $rx_date_fmt = !empty($row['rxdate']) ? date('d/m/Y', strtotime($row['rxdate'])) : '-';
    $rx_time_fmt = di_format_time(monitor_lab_normalize_hosxp_time($row['rxtime'] ?? ''));

    $type_patient = $row['type_patient'] ?? 'OPD';
    $ward_name = trim($row['ward_name'] ?? '');
    $bedno = trim($row['bedno'] ?? '');
    if ($type_patient === 'OPD') {
        $ward_display = 'ผู้ป่วยนอก';
    } else {
        $ward_display = trim($ward_name . ($ward_name && $bedno ? ' / ' : '') . $bedno);
        if ($ward_display === '') {
            $ward_display = '-';
        }
    }

    $dose_mg = $eval['dose_mg'] ?? null;
    $stated_ml = $eval['stated_ml'] ?? null;
    $expected_ml = $eval['expected_ml'] ?? null;
    $diff_ml = $eval['diff_ml'] ?? null;
    $mg_per_ml = isset($eval['mg_per_ml']) ? (float)$eval['mg_per_ml'] : (float)($rule['mg_per_ml'] ?? 0);
    $mix_label = trim((string)($eval['mix_label'] ?? ''));

    $qty_display = '';
    if ($qty !== null && $qty > 0) {
        $qty_display = mmgml_format_num($qty, 3) . ' Amp';
        if (!empty($eval['expected_amp']) && empty($eval['fixed_dose_exempt'])) {
            $qty_display .= ' (คาด ' . mmgml_format_num($eval['expected_amp'], 3) . ')';
        }
    }
    $rate_display = '';
    if (!empty($eval['stated_rate']) || !empty($eval['expected_rate'])) {
        $rate_display = ($eval['stated_rate'] !== null ? mmgml_format_num($eval['stated_rate'], 2) : '—')
            . ' / คาด ' . ($eval['expected_rate'] !== null ? mmgml_format_num($eval['expected_rate'], 2) : '—')
            . ' ml/hr';
    }

    $item = [
        'rule_id' => (int)$rule['id'],
        'hn' => ltrim($row['hn'] ?? '', '0'),
        'hn_full' => $row['hn'] ?? '',
        'ptname' => trim($row['ptname'] ?? ''),
        'type_patient' => $type_patient,
        'vstdate' => $row['vstdate'] ?? '',
        'vn' => $row['vn'] ?? '',
        'an' => $row['an'] ?? '',
        'item_no' => $row['item_no'] ?? '',
        'rxdate' => trim((string)($row['rxdate'] ?? '')),
        'order_date' => $rx_date_fmt,
        'order_time' => $rx_time_fmt,
        'drug_name' => trim($row['drug_name'] ?? ($rule['drug_name'] ?? '')),
        'icode' => $icode,
        'method' => $method,
        'qty' => $row['qty'] ?? '',
        'qty_display' => $qty_display,
        'strength' => trim($row['strength'] ?? ''),
        'dose_mg' => $dose_mg !== null ? (float)$dose_mg : null,
        'stated_ml' => $stated_ml !== null ? (float)$stated_ml : null,
        'expected_ml' => $expected_ml !== null ? (float)$expected_ml : null,
        'tolerance_ml' => $eval['tolerance_ml'] ?? null,
        'diff_ml' => $diff_ml !== null ? (float)$diff_ml : null,
        'mg_per_ml' => $mg_per_ml,
        'strength_text' => trim($rule['strength_text'] ?? ''),
            'weight_kg' => $eval['weight_kg'] ?? $weight_kg,
            'weight_vstdate' => $weight_info['vstdate'],
            'weight_stale' => !empty($weight_info['stale']),
            'weight_source' => $weight_info['source'] ?? 'hosxp',
            'stated_rate' => $eval['stated_rate'] ?? null,
        'expected_rate' => $eval['expected_rate'] ?? null,
            'expected_amp' => $eval['expected_amp'] ?? null,
            'rate_display' => $rate_display,
            'fixed_dose_exempt' => !empty($eval['fixed_dose_exempt']),
            'mismatch_types' => [],
        'dose_mg_display' => $dose_mg !== null ? mmgml_format_mg($dose_mg) . ' mg' : '—',
        'stated_ml_display' => $stated_ml !== null ? mmgml_format_ml($stated_ml) . ' mL' : '—',
        'expected_ml_display' => $expected_ml !== null ? mmgml_format_ml($expected_ml) . ' mL' : '—',
        'mg_per_ml_display' => mmgml_format_mg($mg_per_ml) . ' mg/mL' . ($mix_label !== '' ? ' (' . $mix_label . ')' : ''),
        'diff_ml_display' => $diff_ml !== null ? mmgml_format_ml($diff_ml) . ' mL' : '—',
        'ward_display' => $ward_display,
        'alert_level' => $level,
        'alert_message' => '',
        'detail_text' => trim($rule['detail_text'] ?? ''),
    ];

    if (($eval['status'] ?? '') === 'pass') {
        $pass_bits = ['ผ่านเกณฑ์'];
        if ($diff_ml !== null) {
            $pass_bits[] = 'ผลต่าง mL ' . $item['diff_ml_display'] . ' ภายในอนุโลม';
        }
        if (!empty($item['weight_kg'])) {
            $bwNote = 'BW ' . mmgml_format_num($item['weight_kg'], 1) . ' kg';
            if (($item['weight_source'] ?? '') === 'calculator') {
                $bwNote .= ' (จากเครื่องคำนวณ)';
            } elseif (!empty($item['weight_stale']) && !empty($item['weight_vstdate'])) {
                $bwNote .= ' (ล่าสุด ' . date('d/m/Y', strtotime($item['weight_vstdate'])) . ', อนุโลม×2)';
            }
            $pass_bits[] = $bwNote;
        }
        if (!empty($eval['phase'])) {
            $pass_bits[] = ($eval['phase'] === 'infusion' ? 'Infusion' : ($eval['phase'] === 'bolus' ? 'Bolus' : ''));
        }
        if (mmgml_rule_has_bolus_and_infusion($rule) && !empty($rule['check_qty']) && empty($eval['fixed_dose_exempt'])) {
            $pass_bits[] = 'Amp รวม Bolus+Infusion ผ่าน';
        }
        if (!empty($eval['fixed_dose_exempt'])) {
            $pass_bits[] = 'ขนาดคงที่ (ตรวจเฉพาะ mg→mL ถ้ามี)';
        }
        $item['pass_message'] = implode(' · ', array_filter($pass_bits));
        $passed_items[] = $item;
        continue;
    }

    if (($eval['status'] ?? '') === 'unverifiable') {
        $item['alert_message'] = 'ตรวจสอบไม่ได้ (ไม่พบน้ำหนักผู้ป่วยล่าสุด)';
        $item['pass_message'] = $item['alert_message'];
        $item['mismatch_types'] = ['unverifiable'];
        $unverifiable_items[] = $item;
        continue;
    }

    foreach ($eval['mismatches'] ?? [] as $mm) {
        if (!empty($mm['type'])) {
            $item['mismatch_types'][] = $mm['type'];
        }
    }

    $item['alert_message'] = mmgml_default_alert_message($rule, $eval);

    if ($level === 'hard') {
        $hard_alerts[] = $item;
    } else {
        $soft_alerts[] = $item;
    }
}

$elapsed = (int)round((microtime(true) - $t0) * 1000);
mysqli_close($hos);
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';

ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'status' => 'success',
    'hard_alerts' => sp_alert_mute_filter_rows($con, $hard_alerts),
    'soft_alerts' => sp_alert_mute_filter_rows($con, $soft_alerts),
    'passed_items' => $passed_items,
    'unverifiable_items' => $unverifiable_items,
    'meta' => [
        'rule_count' => count($rules),
        'hard_count' => count($hard_alerts),
        'soft_count' => count($soft_alerts),
        'passed_count' => count($passed_items),
        'unverifiable_count' => count($unverifiable_items),
        'orders_scanned' => $orders_scanned,
        'orders_checked' => $orders_checked,
        'start_date' => $start_date,
        'end_date' => $end_date,
        'recent_minutes' => $recent_minutes,
        'elapsed_ms' => $elapsed,
        'vitals_loaded' => !empty($vitals_cache),
        'truncated' => $orders_scanned >= 4000,
    ],
], JSON_UNESCAPED_UNICODE);
