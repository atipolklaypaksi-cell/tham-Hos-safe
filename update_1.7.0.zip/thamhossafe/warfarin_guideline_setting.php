<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/warfarin_guideline_helper.php';
mysqli_set_charset($con, 'utf8');
$guidelines = wf_guideline_load($con);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ตั้งค่า Guideline Warfarin - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: #f4f7f6; }
        .wg-card { border: 0; box-shadow: 0 1px 4px rgba(0,0,0,.08); border-radius: 10px; }
        .wg-proto-head { background: linear-gradient(90deg, #0f766e, #0ea5e9); color: #fff; border-radius: 10px 10px 0 0; }
        .wg-table input.form-control, .wg-table select.form-select { min-width: 4.5rem; }
        .wg-table textarea { min-width: 16rem; font-size: .85rem; }
        .wg-hint { background: #ecfeff; border: 1px solid #a5f3fc; border-radius: 8px; padding: .75rem 1rem; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <div>
                    <h4 class="fw-bold mb-1"><i class="fas fa-book-medical me-2 text-danger"></i>ตั้งค่า Guideline ปรับยา Warfarin</h4>
                    <p class="text-muted small mb-0">ระบบจะแนะนำการปรับ TWD ตาม INR และแนวทางที่เลือก — แก้ไขได้ตามนโยบายโรงพยาบาล</p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" id="wgBtnReset" class="btn btn-outline-secondary fw-bold">
                        <i class="fas fa-undo me-1"></i> คืนค่าเริ่มต้น
                    </button>
                    <button type="button" id="wgBtnSave" class="btn btn-success fw-bold">
                        <i class="fas fa-save me-1"></i> บันทึก
                    </button>
                </div>
            </div>

            <div class="wg-hint mb-3 small">
                <strong>วิธีใช้:</strong> แก้ไขข้อความ/ช่วง INR/% ที่นี่แล้วกดบันทึก — หน้าคำนวณยา Warfarin จะแสดงคำแนะนำตามการตั้งค่านี้โดยอัตโนมัติ
                (เลือก Target INR บนหน้าคำนวณได้ และระบบจำค่าตาม HN)
            </div>
            <div id="wgMsg" class="mb-3 small fw-bold" style="display:none;"></div>

            <div id="wgProtocols"></div>
        </div>
    </div>
</div>

<script>
window.WG_INITIAL = <?= json_encode($guidelines, JSON_UNESCAPED_UNICODE) ?>;
window.WG_DEFAULTS = <?= json_encode(wf_guideline_defaults(), JSON_UNESCAPED_UNICODE) ?>;
</script>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/warfarin_guideline_setting.js?v=20260731a"></script>
</body>
</html>
