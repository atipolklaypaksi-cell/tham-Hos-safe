<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

$sp_bk_action = $_GET['action'] ?? $_POST['action'] ?? 'poll';
if ($sp_bk_action === 'poll') {
    if (!defined('THAM_LICENSE_NO_SESSION')) {
        define('THAM_LICENSE_NO_SESSION', true);
    }
    if (!defined('THAM_SKIP_UNIT_GATE')) {
        define('THAM_SKIP_UNIT_GATE', true);
    }
    session_write_close();
}

include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/smart_pharma_backup_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}

$action = $sp_bk_action;
$flags = JSON_UNESCAPED_UNICODE;
$role = $_SESSION['role'] ?? '';
$can_settings = ($role === 'admin') || tham_menu_can('smart_pharma.settings');

if ($action === 'get_config') {
    if (!$can_settings) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], $flags);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'config' => sp_backup_get_config($con),
        'roles' => sp_backup_get_role_access($con),
        'labels' => tham_menu_role_labels(),
    ], $flags);
    exit;
}

if ($action === 'save_config' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_settings) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $res = sp_backup_save_config($con, $raw);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'message' => 'บันทึกโหมด Backup แล้ว',
        'config' => $res['config'],
        'roles' => $res['roles'] ?? sp_backup_get_role_access($con),
    ], $flags);
    exit;
}

session_write_close();

if ($action === 'poll') {
    $eligible = sp_backup_user_eligible($con, $role);
    if (!$eligible) {
        echo json_encode([
            'status' => 'success',
            'eligible' => false,
            'pending' => 0,
            'cases' => [],
            'patient_type' => '',
            'settings' => ['sound_enabled' => 0, 'interval_min' => 3],
        ], $flags);
        exit;
    }
    $data = sp_backup_pending($con);
    echo json_encode([
        'status' => 'success',
        'eligible' => true,
        'pending' => $data['count'],
        'cases' => $data['cases'],
        'patient_type' => $data['patient_type'],
        'room_label' => $data['room_label'],
        'settings' => [
            'sound_enabled' => !empty($data['config']['sound_enabled']) ? 1 : 0,
            'interval_min' => (int)$data['config']['interval_min'],
            'lookback_minutes' => (int)($data['config']['lookback_minutes'] ?? 60),
            'lookback_label' => sp_backup_lookback_label($data['config']['lookback_minutes'] ?? 60),
        ],
    ], $flags);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'unknown action'], $flags);
