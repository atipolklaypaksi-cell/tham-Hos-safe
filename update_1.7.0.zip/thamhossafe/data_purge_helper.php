<?php
/**
 * ล้างข้อมูลปฏิบัติการ (soft-archive) + กู้คืนภายใน 7 วัน — Admin เท่านั้น
 * ไม่ลบ master/config (ประเภท Med Error, users, settings, guideline ฯลฯ)
 */

function dp_ensure_tables($con) {
    mysqli_query($con, "CREATE TABLE IF NOT EXISTS data_purge_batches (
        id INT AUTO_INCREMENT PRIMARY KEY,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_by INT NOT NULL DEFAULT 0,
        created_by_name VARCHAR(255) NOT NULL DEFAULT '',
        groups_csv VARCHAR(500) NOT NULL DEFAULT '',
        note VARCHAR(500) NOT NULL DEFAULT '',
        row_count INT NOT NULL DEFAULT 0,
        expires_at DATETIME NOT NULL,
        restored_at DATETIME NULL DEFAULT NULL,
        restored_by INT NOT NULL DEFAULT 0,
        KEY idx_dp_exp (expires_at),
        KEY idx_dp_rest (restored_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    mysqli_query($con, "CREATE TABLE IF NOT EXISTS data_purge_archive (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        batch_id INT NOT NULL,
        table_name VARCHAR(120) NOT NULL,
        row_pk VARCHAR(64) NOT NULL DEFAULT '',
        row_json LONGTEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_dp_arch_batch (batch_id),
        KEY idx_dp_arch_tbl (table_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

/**
 * กลุ่มที่เลือกลบได้ (ข้อมูลปฏิบัติการ)
 */
function dp_group_defs() {
    return [
        'med_error' => [
            'label' => 'Med Error (บันทึกเหตุการณ์)',
            'desc' => 'ลบรายการเหตุการณ์ที่บันทึก — คงประเภทข้อผิดพลาด / กลุ่มแพทย์ / รายการ HAD master',
            'tables' => [
                ['table' => 'med_error_records', 'pk' => 'id'],
            ],
        ],
        'allergy_followup' => [
            'label' => 'แจ้ง/ติดตามแพ้ยา (Allergy Follow-up)',
            'desc' => 'ลบเคส เหตุการณ์ การแจ้งเตือน และรูปถ่ายในระบบ',
            'tables' => [
                ['table' => 'allergy_followup_photos', 'pk' => 'id'],
                ['table' => 'allergy_followup_notifications', 'pk' => 'id'],
                ['table' => 'allergy_followup_events', 'pk' => 'id'],
                ['table' => 'allergy_followup_cases', 'pk' => 'id'],
            ],
        ],
        'med_recon_history' => [
            'label' => 'ประวัติ Med Reconciliation / Smart Drug',
            'desc' => 'ลบประวัติที่บันทึกในแอป (smart_drug_medrecon_history)',
            'tables' => [
                ['table' => 'smart_drug_medrecon_history', 'pk' => 'id'],
            ],
        ],
        'drug_recon_session' => [
            'label' => 'เซสชัน Drug Reconciliation อื่น',
            'desc' => 'ลบ drug_reconciliation_session / item (ถ้ามี)',
            'tables' => [
                ['table' => 'drug_reconciliation_item', 'pk' => 'id'],
                ['table' => 'drug_reconciliation_session', 'pk' => 'id'],
            ],
        ],
    ];
}

function dp_table_exists($con, $table) {
    $t = mysqli_real_escape_string($con, $table);
    $q = @mysqli_query($con, "SHOW TABLES LIKE '$t'");
    return $q && mysqli_num_rows($q) > 0;
}

function dp_count_table($con, $table) {
    if (!dp_table_exists($con, $table)) {
        return 0;
    }
    $t = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $q = @mysqli_query($con, "SELECT COUNT(*) AS c FROM `$t`");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return (int)$r['c'];
    }
    return 0;
}

function dp_group_counts($con) {
    $out = [];
    foreach (dp_group_defs() as $code => $def) {
        $total = 0;
        $parts = [];
        foreach ($def['tables'] as $ti) {
            $c = dp_count_table($con, $ti['table']);
            $parts[] = ['table' => $ti['table'], 'count' => $c, 'exists' => dp_table_exists($con, $ti['table'])];
            $total += $c;
        }
        $out[] = [
            'code' => $code,
            'label' => $def['label'],
            'desc' => $def['desc'],
            'total' => $total,
            'tables' => $parts,
        ];
    }
    return $out;
}

function dp_archive_table_rows($con, $batchId, $table, $pkCol) {
    if (!dp_table_exists($con, $table)) {
        return 0;
    }
    $t = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $pk = preg_replace('/[^a-zA-Z0-9_]/', '', $pkCol);
    $n = 0;
    $q = mysqli_query($con, "SELECT * FROM `$t`");
    if (!$q) {
        return 0;
    }
    $bid = (int)$batchId;
    while ($row = mysqli_fetch_assoc($q)) {
        $pkVal = isset($row[$pk]) ? (string)$row[$pk] : '';
        $json = mysqli_real_escape_string($con, json_encode($row, JSON_UNESCAPED_UNICODE));
        $pkEsc = mysqli_real_escape_string($con, $pkVal);
        $tEsc = mysqli_real_escape_string($con, $t);
        if (!mysqli_query($con, "INSERT INTO data_purge_archive (batch_id, table_name, row_pk, row_json)
            VALUES ($bid, '$tEsc', '$pkEsc', '$json')")) {
            continue;
        }
        $n++;
    }
    if ($n > 0) {
        mysqli_query($con, "DELETE FROM `$t`");
    }
    return $n;
}

/**
 * @param string[] $groupCodes
 * @return array{ok:bool,error?:string,batch_id?:int,row_count?:int,expires_at?:string}
 */
function dp_purge_groups($con, array $groupCodes, $userId, $userName, $note = '') {
    dp_ensure_tables($con);
    $defs = dp_group_defs();
    $codes = [];
    foreach ($groupCodes as $c) {
        $c = trim((string)$c);
        if ($c !== '' && isset($defs[$c])) {
            $codes[] = $c;
        }
    }
    $codes = array_values(array_unique($codes));
    if (!$codes) {
        return ['ok' => false, 'error' => 'เลือกอย่างน้อย 1 กลุ่มข้อมูล'];
    }

    $expires = date('Y-m-d H:i:s', time() + 7 * 86400);
    $uid = (int)$userId;
    $uname = mysqli_real_escape_string($con, (string)$userName);
    $csv = mysqli_real_escape_string($con, implode(',', $codes));
    $noteEsc = mysqli_real_escape_string($con, mb_substr(trim((string)$note), 0, 500));
    $expEsc = mysqli_real_escape_string($con, $expires);

    mysqli_begin_transaction($con);
    try {
        $ok = mysqli_query($con, "INSERT INTO data_purge_batches
            (created_by, created_by_name, groups_csv, note, row_count, expires_at)
            VALUES ($uid, '$uname', '$csv', '$noteEsc', 0, '$expEsc')");
        if (!$ok) {
            throw new Exception(mysqli_error($con) ?: 'สร้างชุดลบไม่สำเร็จ');
        }
        $batchId = (int)mysqli_insert_id($con);
        $total = 0;
        foreach ($codes as $code) {
            foreach ($defs[$code]['tables'] as $ti) {
                $total += dp_archive_table_rows($con, $batchId, $ti['table'], $ti['pk']);
            }
        }
        mysqli_query($con, "UPDATE data_purge_batches SET row_count=$total WHERE id=$batchId");
        mysqli_commit($con);
        return [
            'ok' => true,
            'batch_id' => $batchId,
            'row_count' => $total,
            'expires_at' => $expires,
            'groups' => $codes,
        ];
    } catch (Throwable $e) {
        mysqli_rollback($con);
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}

function dp_list_batches($con, $onlyRestorable = true) {
    dp_ensure_tables($con);
    dp_expire_old($con);
    $where = $onlyRestorable
        ? "WHERE restored_at IS NULL AND expires_at >= NOW()"
        : 'WHERE 1=1';
    $q = mysqli_query($con, "SELECT * FROM data_purge_batches $where ORDER BY id DESC LIMIT 50");
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    return $rows;
}

/**
 * กู้คืนชุดที่ลบ — ใส่แถวกลับจาก archive
 */
function dp_restore_batch($con, $batchId, $userId) {
    dp_ensure_tables($con);
    $bid = (int)$batchId;
    $q = mysqli_query($con, "SELECT * FROM data_purge_batches WHERE id=$bid LIMIT 1");
    if (!$q || !($batch = mysqli_fetch_assoc($q))) {
        return ['ok' => false, 'error' => 'ไม่พบชุดข้อมูล'];
    }
    if (!empty($batch['restored_at']) && $batch['restored_at'] !== '0000-00-00 00:00:00') {
        return ['ok' => false, 'error' => 'ชุดนี้กู้คืนไปแล้ว'];
    }
    if (strtotime($batch['expires_at']) < time()) {
        return ['ok' => false, 'error' => 'หมดเวลากู้คืน (เกิน 7 วัน)'];
    }

    $defs = dp_group_defs();
    $pkMap = [];
    foreach ($defs as $def) {
        foreach ($def['tables'] as $ti) {
            $pkMap[$ti['table']] = $ti['pk'];
        }
    }

    mysqli_begin_transaction($con);
    try {
        // คืนจากตารางลูกก่อน? archive เรียงตาม id — ควรคืน parent ก่อน child
        // เรา archive ลำดับ child→parent ตอนลบ ดังนั้น restore ควร parent→child = reverse id order per table groups
        $orderTables = [];
        foreach (array_reverse(explode(',', $batch['groups_csv'])) as $code) {
            $code = trim($code);
            if (!isset($defs[$code])) {
                continue;
            }
            foreach (array_reverse($defs[$code]['tables']) as $ti) {
                $orderTables[] = $ti['table'];
            }
        }
        $restored = 0;
        foreach ($orderTables as $table) {
            if (!dp_table_exists($con, $table)) {
                continue;
            }
            $tEsc = mysqli_real_escape_string($con, $table);
            $aq = mysqli_query($con, "SELECT id, row_json FROM data_purge_archive
                WHERE batch_id=$bid AND table_name='$tEsc' ORDER BY id ASC");
            if (!$aq) {
                continue;
            }
            $t = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
            while ($ar = mysqli_fetch_assoc($aq)) {
                $data = json_decode($ar['row_json'], true);
                if (!is_array($data) || !$data) {
                    continue;
                }
                $cols = [];
                $vals = [];
                foreach ($data as $k => $v) {
                    if (!preg_match('/^[a-zA-Z0-9_]+$/', $k)) {
                        continue;
                    }
                    $cols[] = '`' . $k . '`';
                    if ($v === null) {
                        $vals[] = 'NULL';
                    } else {
                        $vals[] = "'" . mysqli_real_escape_string($con, (string)$v) . "'";
                    }
                }
                if (!$cols) {
                    continue;
                }
                $sql = "INSERT INTO `$t` (" . implode(',', $cols) . ") VALUES (" . implode(',', $vals) . ")";
                if (@mysqli_query($con, $sql)) {
                    $restored++;
                } else {
                    // ถ้า PK ซ้ำ — ข้าม
                }
            }
        }
        $uid = (int)$userId;
        mysqli_query($con, "UPDATE data_purge_batches SET restored_at=NOW(), restored_by=$uid WHERE id=$bid");
        mysqli_query($con, "DELETE FROM data_purge_archive WHERE batch_id=$bid");
        mysqli_commit($con);
        return ['ok' => true, 'restored' => $restored, 'batch_id' => $bid];
    } catch (Throwable $e) {
        mysqli_rollback($con);
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}

/** ลบ archive ที่หมดอายุ */
function dp_expire_old($con) {
    dp_ensure_tables($con);
    $q = mysqli_query($con, "SELECT id FROM data_purge_batches
        WHERE restored_at IS NULL AND expires_at < NOW()");
    if (!$q) {
        return 0;
    }
    $n = 0;
    while ($r = mysqli_fetch_assoc($q)) {
        $id = (int)$r['id'];
        mysqli_query($con, "DELETE FROM data_purge_archive WHERE batch_id=$id");
        mysqli_query($con, "UPDATE data_purge_batches SET note=CONCAT(note,' [expired]') WHERE id=$id AND note NOT LIKE '%[expired]%'");
        // mark expired by setting restored_at? better leave and just wipe archive
        $n++;
    }
    // clean archive orphans
    mysqli_query($con, "DELETE a FROM data_purge_archive a
        INNER JOIN data_purge_batches b ON b.id=a.batch_id
        WHERE b.expires_at < NOW() AND b.restored_at IS NULL");
    return $n;
}
