<?php
/**
 * Med Reconcile ยากลับบ้าน — เทียบยา ก่อน Admit / ขณะ Admit / HME
 */
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
require_once __DIR__ . '/drug_reconciliation_helper.php';

function mrd_utf8($expr) {
    return "CAST(CONVERT($expr USING utf8) AS CHAR)";
}

/** ค่าเริ่มต้นคำสำคัญที่ถือว่า OFF */
function mrd_default_off_keywords() {
    return ['hold off', 'holdoff', 'งด', 'หยุดใช้', 'หยุดยา', 'hold'];
}

function mrd_default_settings() {
    return [
        'off_keywords' => mrd_default_off_keywords(),
    ];
}

function mrd_ensure_settings_table($con) {
    if (!$con) {
        return false;
    }
    @mysqli_query($con, "
        CREATE TABLE IF NOT EXISTS tham_mrd_settings (
            setting_key VARCHAR(64) NOT NULL PRIMARY KEY,
            setting_value MEDIUMTEXT NULL,
            updated_at DATETIME NULL,
            updated_by VARCHAR(64) NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8
    ");
    return true;
}

function mrd_load_settings($con) {
    $out = mrd_default_settings();
    if (!$con) {
        return $out;
    }
    mrd_ensure_settings_table($con);
    $q = @mysqli_query($con, "SELECT setting_value FROM tham_mrd_settings WHERE setting_key='main' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $decoded = json_decode((string)($r['setting_value'] ?? ''), true);
        if (is_array($decoded)) {
            if (isset($decoded['off_keywords']) && is_array($decoded['off_keywords'])) {
                $kw = [];
                foreach ($decoded['off_keywords'] as $k) {
                    $k = trim((string)$k);
                    if ($k !== '') {
                        $kw[] = $k;
                    }
                }
                if ($kw) {
                    $out['off_keywords'] = array_values(array_unique($kw));
                }
            }
        }
    }
    return $out;
}

function mrd_save_settings($con, array $settings, $user = '') {
    if (!$con) {
        return false;
    }
    mrd_ensure_settings_table($con);
    $base = mrd_default_settings();
    $kw = [];
    $raw = $settings['off_keywords'] ?? [];
    if (is_string($raw)) {
        $parts = preg_split('/[\n,;]+/u', $raw);
        $raw = is_array($parts) ? $parts : [];
    }
    if (is_array($raw)) {
        foreach ($raw as $k) {
            $k = trim((string)$k);
            if ($k !== '') {
                $kw[] = $k;
            }
        }
    }
    if (!$kw) {
        $kw = $base['off_keywords'];
    }
    $payload = json_encode(['off_keywords' => array_values(array_unique($kw))], JSON_UNESCAPED_UNICODE);
    $payload_esc = mysqli_real_escape_string($con, $payload);
    $user_esc = mysqli_real_escape_string($con, substr(trim((string)$user), 0, 64));
    $ok = @mysqli_query($con, "
        INSERT INTO tham_mrd_settings (setting_key, setting_value, updated_at, updated_by)
        VALUES ('main', '$payload_esc', NOW(), '$user_esc')
        ON DUPLICATE KEY UPDATE
            setting_value = VALUES(setting_value),
            updated_at = NOW(),
            updated_by = VALUES(updated_by)
    ");
    return (bool)$ok;
}

function mrd_settings_off_keywords(array $settings = null) {
    if ($settings === null) {
        $settings = mrd_default_settings();
    }
    $kw = $settings['off_keywords'] ?? mrd_default_off_keywords();
    if (!is_array($kw) || !$kw) {
        return mrd_default_off_keywords();
    }
    $out = array_values(array_filter(array_map(function ($k) {
        return trim((string)$k);
    }, $kw)));
    // ยาวก่อน เพื่อให้ "hold off" ชนะ "hold"
    usort($out, function ($a, $b) {
        $la = function_exists('mb_strlen') ? mb_strlen($a, 'UTF-8') : strlen($a);
        $lb = function_exists('mb_strlen') ? mb_strlen($b, 'UTF-8') : strlen($b);
        return $lb <=> $la;
    });
    return $out;
}

/** คืนคำสำคัญที่ match ในวิธีใช้ หรือ null */
function mrd_method_match_keyword($method, array $keywords) {
    $text = mrd_norm_method($method);
    if ($text === '') {
        return null;
    }
    foreach ($keywords as $kw) {
        $k = mrd_norm_method($kw);
        if ($k === '') {
            continue;
        }
        if (function_exists('mb_strpos')) {
            if (mb_strpos($text, $k, 0, 'UTF-8') !== false) {
                return trim((string)$kw);
            }
        } elseif (strpos($text, $k) !== false) {
            return trim((string)$kw);
        }
    }
    return null;
}

function mrd_is_hme_row(array $row) {
    $order_type = strtolower(trim((string)($row['order_type'] ?? '')));
    $item_type = strtoupper(trim((string)($row['item_type'] ?? '')));
    if ($order_type === 'hme') {
        return true;
    }
    if ($item_type === 'H') {
        return true;
    }
    return false;
}

/**
 * วิธีใช้แบบเดียวกับ smart_drug.php / fetch_hosxp_history_api.php
 * sp_use → drugusage.name1+name2+name3 (ไม่ใช้ shortlist / opi_dispense)
 */
function mrd_sql_method_expr($o = 'o', $du = 'du', $sp = 'sp') {
    return "CAST(CONVERT(
        IF($o.sp_use <> '' AND $o.sp_use IS NOT NULL,
            CONCAT(IFNULL($sp.name1,''), ' ', IFNULL($sp.name2,''), ' ', IFNULL($sp.name3,'')),
            CONCAT(IFNULL($du.name1,''), ' ', IFNULL($du.name2,''), ' ', IFNULL($du.name3,''))
        )
    USING utf8) AS CHAR)";
}

function mrd_sql_drug_select_extra() {
    $method = mrd_sql_method_expr('o', 'du', 'sp');
    $tmt = hosxp_sql_tmt_drug_name('d', 'tm');
    return "
        o.icode,
        CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name_local,
        $tmt AS drug_name_tmt,
        CAST(CONVERT(IFNULL(d.strength,'') USING utf8) AS CHAR) AS strength,
        CAST(CONVERT(IFNULL(d.strength,'') USING utf8) AS CHAR) AS strength_local,
        CAST(CONVERT(d.units USING utf8) AS CHAR) AS units,
        o.qty,
        $method AS method,
        o.vstdate AS source_date,
        o.vn,
        o.an,
        o.item_type,
        IFNULL(ion.order_type,'') AS order_type,
        o.vsttime AS source_time,
        o.item_no
    ";
}

function mrd_sql_drug_joins_extra() {
    return "
        INNER JOIN drugitems d ON d.icode = o.icode
        " . hosxp_sql_tmt_join('d', 'tm') . "
        LEFT JOIN drugusage du ON du.drugusage = o.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
        LEFT JOIN ipt_order_no ion ON ion.order_no = o.order_no
    ";
}

function mrd_map_row(array $row, $source_label) {
    $mapped = dr_map_drug_row($row, $source_label);
    $mapped['vn'] = trim((string)($row['vn'] ?? ''));
    $mapped['an'] = trim((string)($row['an'] ?? ''));
    $mapped['is_hme'] = mrd_is_hme_row($row) ? 1 : 0;
    $mapped['source_time'] = substr(trim((string)($row['source_time'] ?? '')), 0, 8);
    $mapped['item_no'] = (int)($row['item_no'] ?? 0);
    // แสดงชื่อจาก drugitems.name + drugitems.strength
    $baseName = trim((string)($mapped['drug_name'] ?? ''));
    if ($baseName === '') {
        $baseName = trim((string)($mapped['drug_name_tmt'] ?? ''));
    }
    $strengthLocal = trim((string)($row['strength_local'] ?? ''));
    if ($strengthLocal !== '') {
        $mapped['strength'] = $strengthLocal;
    }
    $mapped['display_name'] = di_format_drug_display_name($baseName, $mapped['strength'] ?? '');
    return $mapped;
}

function mrd_format_date_th($iso) {
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})/', (string)$iso, $m)) {
        return (string)$iso;
    }
    return sprintf('%02d/%02d/%04d', (int)$m[3], (int)$m[2], (int)$m[1] + 543);
}

/** รายการ Visit สำหรับเลือกก่อน Admit
 * @param bool $only_with_drugs ถ้า true คืนเฉพาะ Visit ที่มีรายการยา (opitemrece.icode ↔ drugitems)
 */
function mrd_fetch_visits($con_hosxp, $hn, $limit = 40, $only_with_drugs = false) {
    $hn_sql = dr_hn_sql_in($con_hosxp, $hn);
    if ($hn_sql === '') {
        return [];
    }
    $visits = [];
    // ดึงเผื่อไว้ก่อนกรองเฉพาะที่มียา
    $fetch_limit = $only_with_drugs ? max((int)$limit * 3, 80) : (int)$limit;

    $q = @mysqli_query($con_hosxp, "
        SELECT i.an, i.hn, i.regdate, i.regtime, i.dchdate,
               " . mrd_utf8("IFNULL(w.name,'')") . " AS ward_name,
               (SELECT COUNT(*)
                  FROM opitemrece o
                  INNER JOIN drugitems d ON d.icode = o.icode
                 WHERE o.an = i.an
                   AND TRIM(IFNULL(o.icode,'')) <> '') AS drug_count_op,
               (SELECT COUNT(*) FROM medplan_ipd m
                 INNER JOIN drugitems d2 ON d2.icode = m.icode
                WHERE m.an = i.an
                  AND TRIM(IFNULL(m.icode,'')) <> '') AS drug_count_mp,
               (SELECT COUNT(*)
                  FROM opitemrece oh
                  INNER JOIN drugitems dh ON dh.icode = oh.icode
                  LEFT JOIN ipt_order_no ionh ON ionh.order_no = oh.order_no
                 WHERE oh.an = i.an
                   AND TRIM(IFNULL(oh.icode,'')) <> ''
                   AND (
                        LOWER(TRIM(IFNULL(ionh.order_type,''))) = 'hme'
                     OR UPPER(TRIM(IFNULL(oh.item_type,''))) = 'H'
                   )) AS hme_count
        FROM ipt i
        LEFT JOIN ward w ON w.ward = i.ward
        WHERE i.hn IN ($hn_sql)
        ORDER BY i.regdate DESC, i.regtime DESC
        LIMIT " . (int)$fetch_limit . "
    ");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $an = trim((string)($r['an'] ?? ''));
            if ($an === '') {
                continue;
            }
            $iso = (($r['regdate'] ?? '') !== '0000-00-00') ? ($r['regdate'] ?? '') : '';
            $nOp = (int)($r['drug_count_op'] ?? 0);
            $nMp = (int)($r['drug_count_mp'] ?? 0);
            $nHme = (int)($r['hme_count'] ?? 0);
            $visits[] = [
                'visit_key' => 'ipd:' . $an,
                'visit_type' => 'ipd',
                'an' => $an,
                'vn' => '',
                'vstdate_iso' => $iso,
                'vstdate_display' => mrd_format_date_th($iso),
                'vsttime_display' => substr(trim((string)($r['regtime'] ?? '')), 0, 8),
                'nextdate_iso' => '',
                'nextdate_display' => '',
                'ward_name' => trim((string)($r['ward_name'] ?? '')),
                'drug_count' => max($nOp, $nMp),
                'drug_count_op' => $nOp,
                'drug_count_mp' => $nMp,
                'hme_count' => $nHme,
                'is_active' => (empty($r['dchdate']) || $r['dchdate'] === '0000-00-00') ? 1 : 0,
            ];
        }
    }

    // OPD + วันที่นัดจาก oapp (นัดที่สั่งใน visit นั้น: oapp.vn / oapp.vstdate)
    $q = @mysqli_query($con_hosxp, "
        SELECT o.vn, o.vstdate, o.vsttime,
               " . mrd_utf8("IFNULL(k.department,'')") . " AS department_name,
               (SELECT COUNT(*)
                  FROM opitemrece oi
                  INNER JOIN drugitems d ON d.icode = oi.icode
                 WHERE oi.vn = o.vn
                   AND TRIM(IFNULL(oi.icode,'')) <> '') AS drug_count,
               IFNULL((
                    SELECT MIN(oa.nextdate)
                      FROM oapp oa
                     WHERE oa.vn = o.vn
                       AND oa.nextdate IS NOT NULL
                       AND oa.nextdate <> '0000-00-00'
               ), (
                    SELECT MIN(oa2.nextdate)
                      FROM oapp oa2
                     WHERE oa2.hn IN ($hn_sql)
                       AND oa2.vstdate = o.vstdate
                       AND oa2.nextdate IS NOT NULL
                       AND oa2.nextdate <> '0000-00-00'
               )) AS nextdate
        FROM ovst o
        LEFT JOIN kskdepartment k ON k.depcode = o.main_dep
        WHERE o.hn IN ($hn_sql)
        ORDER BY o.vstdate DESC, o.vsttime DESC
        LIMIT " . (int)$fetch_limit . "
    ");
    if (!$q) {
        // fallback ถ้า schema oapp ไม่รองรับ subquery ซ้อน
        $q = @mysqli_query($con_hosxp, "
            SELECT o.vn, o.vstdate, o.vsttime,
                   " . mrd_utf8("IFNULL(k.department,'')") . " AS department_name,
                   (SELECT COUNT(*)
                      FROM opitemrece oi
                      INNER JOIN drugitems d ON d.icode = oi.icode
                     WHERE oi.vn = o.vn
                       AND TRIM(IFNULL(oi.icode,'')) <> '') AS drug_count,
                   (SELECT MIN(oa.nextdate)
                      FROM oapp oa
                     WHERE oa.vn = o.vn
                       AND oa.nextdate IS NOT NULL
                       AND oa.nextdate <> '0000-00-00') AS nextdate
            FROM ovst o
            LEFT JOIN kskdepartment k ON k.depcode = o.main_dep
            WHERE o.hn IN ($hn_sql)
            ORDER BY o.vstdate DESC, o.vsttime DESC
            LIMIT " . (int)$fetch_limit . "
        ");
    }
    if (!$q) {
        $q = @mysqli_query($con_hosxp, "
            SELECT o.vn, o.vstdate, o.vsttime,
                   " . mrd_utf8("IFNULL(k.department,'')") . " AS department_name,
                   (SELECT COUNT(*)
                      FROM opitemrece oi
                      INNER JOIN drugitems d ON d.icode = oi.icode
                     WHERE oi.vn = o.vn
                       AND TRIM(IFNULL(oi.icode,'')) <> '') AS drug_count,
                   '' AS nextdate
            FROM ovst o
            LEFT JOIN kskdepartment k ON k.depcode = o.main_dep
            WHERE o.hn IN ($hn_sql)
            ORDER BY o.vstdate DESC, o.vsttime DESC
            LIMIT " . (int)$fetch_limit . "
        ");
    }
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $vn = trim((string)($r['vn'] ?? ''));
            if ($vn === '') {
                continue;
            }
            $iso = (($r['vstdate'] ?? '') !== '0000-00-00') ? ($r['vstdate'] ?? '') : '';
            $nextIso = substr(trim((string)($r['nextdate'] ?? '')), 0, 10);
            if ($nextIso === '0000-00-00') {
                $nextIso = '';
            }
            $drug_count = (int)($r['drug_count'] ?? 0);
            $visits[] = [
                'visit_key' => 'opd:' . $vn,
                'visit_type' => 'opd',
                'an' => '',
                'vn' => $vn,
                'vstdate_iso' => $iso,
                'vstdate_display' => mrd_format_date_th($iso),
                'vsttime_display' => substr(trim((string)($r['vsttime'] ?? '')), 0, 8),
                'nextdate_iso' => $nextIso,
                'nextdate_display' => $nextIso !== '' ? mrd_format_date_th($nextIso) : '',
                'ward_name' => trim((string)($r['department_name'] ?? '')),
                'drug_count' => $drug_count,
                'is_active' => 0,
            ];
        }
    }

    usort($visits, function ($a, $b) {
        $c = strcmp((string)($b['vstdate_iso'] ?? ''), (string)($a['vstdate_iso'] ?? ''));
        if ($c !== 0) {
            return $c;
        }
        return strcmp((string)($b['vsttime_display'] ?? ''), (string)($a['vsttime_display'] ?? ''));
    });

    if ($only_with_drugs) {
        $visits = array_values(array_filter($visits, function ($v) {
            return (int)($v['drug_count'] ?? 0) > 0;
        }));
    }

    return array_slice($visits, 0, (int)$limit);
}

function mrd_is_empty_offdate($offdate) {
    $d = trim((string)$offdate);
    return ($d === '' || $d === '0000-00-00' || $d === '0000-00-00 00:00:00');
}

/** วิธีใช้ medplan — หลักการเดียวกับ smart_drug (sp_use → drugusage name1-3) */
function mrd_medplan_method_sql($m = 'm') {
    return "CAST(CONVERT(
        IF($m.sp_use <> '' AND $m.sp_use IS NOT NULL,
            CONCAT(IFNULL(sp.name1,''),' ',IFNULL(sp.name2,''),' ',IFNULL(sp.name3,'')),
            CONCAT(IFNULL(du.name1,''),' ',IFNULL(du.name2,''),' ',IFNULL(du.name3,''))
        )
    USING utf8) AS CHAR)";
}

/**
 * หา AN สำหรับเทียบยา Admit
 * 1) ที่ยัง admit อยู่  2) IPD ล่าสุด (แม้จำหน่ายแล้ว)  3) ตาม an ที่ระบุ
 */
function mrd_resolve_ipd_context($con_hosxp, $hn, $prefer_an = '') {
    $prefer_an = trim((string)$prefer_an);
    $hn_sql = dr_hn_sql_in($con_hosxp, $hn);
    $out = [
        'an' => '',
        'ward_name' => '',
        'doctor_name' => '',
        'admit_date' => '',
        'admit_time' => '',
        'is_active' => 0,
        'an_source' => '',
    ];
    if ($hn_sql === '' && $prefer_an === '') {
        return $out;
    }

    $base_select = "
        SELECT i.an, i.hn, i.regdate, i.regtime, i.dchdate, i.admdoctor,
               " . mrd_utf8("CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,''))") . " AS doctor_name,
               " . mrd_utf8("IFNULL(w.name,'')") . " AS ward_name
        FROM ipt i
        LEFT JOIN doctor doc ON doc.code = i.admdoctor
        LEFT JOIN ward w ON w.ward = i.ward
    ";

    $try_fill = function ($sql) use ($con_hosxp, &$out) {
        $q = @mysqli_query($con_hosxp, $sql);
        if (!$q || !($row = mysqli_fetch_assoc($q))) {
            return false;
        }
        $out['an'] = trim((string)($row['an'] ?? ''));
        $out['ward_name'] = trim((string)($row['ward_name'] ?? ''));
        $out['doctor_name'] = trim((string)($row['doctor_name'] ?? ''));
        $out['admit_date'] = (($row['regdate'] ?? '') !== '0000-00-00') ? ($row['regdate'] ?? '') : '';
        $out['admit_time'] = substr(trim((string)($row['regtime'] ?? '')), 0, 8);
        $out['is_active'] = mrd_is_empty_offdate($row['dchdate'] ?? '') ? 1 : 0;
        return $out['an'] !== '';
    };

    if ($prefer_an !== '') {
        $an_esc = mysqli_real_escape_string($con_hosxp, $prefer_an);
        if ($try_fill("$base_select WHERE i.an = '$an_esc' LIMIT 1")) {
            $out['an_source'] = 'selected';
            return $out;
        }
    }

    if ($hn_sql !== '') {
        if ($try_fill("
            $base_select
            WHERE i.hn IN ($hn_sql)
              AND (i.dchdate IS NULL OR TRIM(IFNULL(i.dchdate,'')) = '' OR i.dchdate = '0000-00-00')
            ORDER BY i.regdate DESC, i.an DESC
            LIMIT 1
        ")) {
            $out['an_source'] = 'active';
            return $out;
        }
        if ($try_fill("
            $base_select
            WHERE i.hn IN ($hn_sql)
            ORDER BY i.regdate DESC, i.an DESC
            LIMIT 1
        ")) {
            $out['an_source'] = 'latest_ipd';
            return $out;
        }
    }
    return $out;
}

function mrd_fetch_patient($con_hosxp, $hn, $prefer_an = '') {
    $ctx = dr_fetch_patient_context($con_hosxp, $hn);
    if (!$ctx) {
        return null;
    }
    $hn_sql = dr_hn_sql_in($con_hosxp, $ctx['hn']);
    $full_name = trim((string)($ctx['patient_name'] ?? ''));
    $sex = '';
    $age_y = null;
    $q = @mysqli_query($con_hosxp, "
        SELECT " . mrd_utf8("CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,''))") . " AS full_name,
               p.sex,
               TIMESTAMPDIFF(YEAR, p.birthday, CURDATE()) AS age_y
        FROM patient p
        WHERE p.hn IN ($hn_sql)
        LIMIT 1
    ");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        if ($full_name === '') {
            $full_name = trim((string)($r['full_name'] ?? ''));
        }
        $sex = trim((string)($r['sex'] ?? ''));
        $age_y = isset($r['age_y']) ? (int)$r['age_y'] : null;
    }

    $ipd = mrd_resolve_ipd_context($con_hosxp, $ctx['hn'], $prefer_an !== '' ? $prefer_an : ($ctx['an'] ?? ''));
    $an = $ipd['an'] !== '' ? $ipd['an'] : trim((string)($ctx['an'] ?? ''));
    $ward = $ipd['ward_name'] !== '' ? $ipd['ward_name'] : trim((string)($ctx['ward_name'] ?? ''));
    $doctor = $ipd['doctor_name'] !== '' ? $ipd['doctor_name'] : trim((string)($ctx['doctor_name'] ?? ''));
    $admit_date = $ipd['admit_date'] !== '' ? $ipd['admit_date'] : trim((string)($ctx['admit_date'] ?? ''));
    $admit_time = $ipd['admit_time'];

    $allergy = ['has_allergy' => false, 'text' => '', 'label_no_allergy' => 'ไม่แพ้ยา (HOSxP)'];
    $qa = @mysqli_query($con_hosxp, "
        SELECT " . mrd_utf8("IFNULL(a.agent,'')") . " AS agent
        FROM opd_allergy a
        WHERE a.hn IN ($hn_sql)
        ORDER BY a.report_date DESC
        LIMIT 20
    ");
    if ($qa) {
        $parts = [];
        while ($ar = mysqli_fetch_assoc($qa)) {
            $agent = trim((string)($ar['agent'] ?? ''));
            if ($agent === '') {
                continue;
            }
            if (!in_array($agent, $parts, true)) {
                $parts[] = $agent;
            }
        }
        if ($parts) {
            $allergy['has_allergy'] = true;
            $allergy['text'] = implode(', ', $parts);
        }
    }

    return [
        'hn' => $ctx['hn'],
        'an' => $an,
        'vn' => $ctx['vn'] ?? '',
        'visit_type' => $an !== '' ? 'ipd' : ($ctx['visit_type'] ?? ''),
        'full_name' => $full_name,
        'sex' => $sex,
        'age_y' => $age_y,
        'ward_name' => $ward,
        'doctor_name' => $doctor,
        'admit_date' => $admit_date,
        'admit_time' => $admit_time,
        'ipd_active' => (int)($ipd['is_active'] ?? 0),
        'an_source' => $ipd['an_source'] ?? '',
        'allergy' => $allergy,
    ];
}

function mrd_fetch_drugs_by_visit_keys($con_hosxp, array $visit_keys) {
    $sel = mrd_sql_drug_select_extra();
    $joins = mrd_sql_drug_joins_extra();
    $rows = [];
    foreach ($visit_keys as $vk) {
        $vk = trim((string)$vk);
        if ($vk === '') {
            continue;
        }
        if (strpos($vk, 'ipd:') === 0) {
            $an = mysqli_real_escape_string($con_hosxp, substr($vk, 4));
            // IPD ก่อน Admit — ดึงเฉพาะ HME
            $sql = "
                SELECT $sel
                FROM opitemrece o
                $joins
                WHERE o.an = '$an'
                  AND (
                        LOWER(TRIM(IFNULL(ion.order_type,''))) = 'hme'
                     OR UPPER(TRIM(IFNULL(o.item_type,''))) = 'H'
                  )
                ORDER BY o.vstdate DESC, o.vsttime DESC, o.item_no ASC
                LIMIT 300
            ";
            $label = 'IPD HME AN ' . substr($vk, 4);
        } elseif (strpos($vk, 'opd:') === 0) {
            $vn = mysqli_real_escape_string($con_hosxp, substr($vk, 4));
            $sql = "
                SELECT $sel
                FROM opitemrece o
                $joins
                WHERE o.vn = '$vn'
                ORDER BY o.item_no ASC
                LIMIT 200
            ";
            $label = 'OPD VN ' . substr($vk, 4);
        } else {
            continue;
        }
        $q = @mysqli_query($con_hosxp, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $mapped = mrd_map_row($r, $label);
            $mapped['visit_key'] = $vk;
            $rows[] = $mapped;
        }
    }
    return mrd_dedupe_keep_latest($rows);
}

/**
 * รวมหลายแหล่งของยาก่อน Admit
 * รายการที่มาก่อนชนะ ถ้ายาเดียวกันมีทั้งใน Med Recon และ Visit จะคงแถวจาก Med Recon
 */
function mrd_merge_pre_prefer_earlier(array $lists) {
    $out = [];
    $seenKey = [];
    $seenIcode = [];
    foreach ($lists as $list) {
        if (!is_array($list)) {
            continue;
        }
        foreach ($list as $r) {
            if (!is_array($r)) {
                continue;
            }
            $key = trim((string)($r['row_key'] ?? ''));
            $icode = trim((string)($r['icode'] ?? ''));
            if ($key !== '' && isset($seenKey[$key])) {
                continue;
            }
            if ($icode !== '' && isset($seenIcode[$icode])) {
                continue;
            }
            if ($key !== '') {
                $seenKey[$key] = true;
            }
            if ($icode !== '') {
                $seenIcode[$icode] = true;
            }
            $out[] = $r;
        }
    }
    return $out;
}

/** รวมยาซ้ำ — คงวิธีใช้ล่าสุด */
function mrd_dedupe_keep_latest(array $rows) {
    $map = [];
    foreach ($rows as $r) {
        $key = $r['row_key'] ?? dr_normalize_row_key($r['icode'] ?? '', $r['display_name'] ?? $r['drug_name'] ?? '');
        $sort = trim((string)($r['_sort'] ?? ''));
        if ($sort === '') {
            $sort = ($r['source_date'] ?? '') . ' ' . ($r['source_time'] ?? '') . ' ' . str_pad((string)($r['item_no'] ?? 0), 4, '0', STR_PAD_LEFT);
        }
        if (!isset($map[$key]) || $sort >= ($map[$key]['_sort'] ?? '')) {
            $r['row_key'] = $key;
            $r['_sort'] = $sort;
            $map[$key] = $r;
        }
    }
    $out = array_values($map);
    foreach ($out as &$r) {
        unset($r['_sort']);
    }
    unset($r);
    return $out;
}

/** ดึง medplan_ipd ของ AN (เหมือน IPD Medication Profile ใน HOSxP) */
function mrd_fetch_medplan_rows($con_hosxp, $an) {
    $an = trim((string)$an);
    if ($an === '') {
        return [];
    }
    $an_esc = mysqli_real_escape_string($con_hosxp, $an);
    $tmt = hosxp_sql_tmt_drug_name('d', 'tm');
    $method = mrd_medplan_method_sql('m');

    $sql = "
        SELECT
            m.icode,
            m.qty,
            m.orderdate,
            m.offdate,
            m.orderstatus,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name_local,
            $tmt AS drug_name_tmt,
            CAST(CONVERT(IFNULL(d.strength,'') USING utf8) AS CHAR) AS strength,
            CAST(CONVERT(IFNULL(d.strength,'') USING utf8) AS CHAR) AS strength_local,
            CAST(CONVERT(d.units USING utf8) AS CHAR) AS units,
            $method AS method,
            DATE(m.orderdate) AS source_date,
            '' AS order_type,
            '' AS item_type,
            '' AS vn,
            m.an AS an,
            '' AS source_time,
            IFNULL(m.med_plan_number, 0) AS item_no
        FROM medplan_ipd m
        INNER JOIN drugitems d ON d.icode = m.icode
        " . hosxp_sql_tmt_join('d', 'tm') . "
        LEFT JOIN drugusage du ON du.drugusage = m.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = m.sp_use
        WHERE m.an = '$an_esc'
        ORDER BY m.orderdate DESC, m.med_plan_number DESC
        LIMIT 800
    ";
    $rows = [];
    $q = @mysqli_query($con_hosxp, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $r['_offdate'] = $r['offdate'] ?? '';
            $rows[] = $r;
        }
    }
    return $rows;
}

/** icode ที่เป็น HME ใน AN (จาก ipt_order_no + opitemrece) */
function mrd_hme_icodes_for_an($con_hosxp, $an) {
    $an = trim((string)$an);
    if ($an === '') {
        return [];
    }
    $an_esc = mysqli_real_escape_string($con_hosxp, $an);
    $set = [];
    $q = @mysqli_query($con_hosxp, "
        SELECT DISTINCT o.icode
        FROM opitemrece o
        LEFT JOIN ipt_order_no ion ON ion.order_no = o.order_no
        WHERE o.an = '$an_esc'
          AND (
                LOWER(TRIM(IFNULL(ion.order_type,''))) = 'hme'
             OR UPPER(TRIM(IFNULL(o.item_type,''))) = 'H'
          )
    ");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $ic = trim((string)($r['icode'] ?? ''));
            if ($ic !== '') {
                $set[$ic] = true;
            }
        }
    }
    return $set;
}

/** หา order ล่าสุดของ AN ตาม order_type (BCH / IRx / ...) */
function mrd_latest_order_by_type($con_hosxp, $an, $order_type) {
    $an = trim((string)$an);
    $order_type = strtoupper(trim((string)$order_type));
    if ($an === '' || $order_type === '') {
        return null;
    }
    $an_esc = mysqli_real_escape_string($con_hosxp, $an);
    $type_esc = mysqli_real_escape_string($con_hosxp, $order_type);
    $q = @mysqli_query($con_hosxp, "
        SELECT ion.order_no, ion.rxdate, ion.rxtime, ion.order_type, ion.item_count
        FROM ipt_order_no ion
        WHERE ion.an = '$an_esc'
          AND UPPER(TRIM(IFNULL(ion.order_type,''))) = '$type_esc'
        ORDER BY ion.rxdate DESC, ion.rxtime DESC, ion.order_no DESC
        LIMIT 1
    ");
    if (!$q || !($r = mysqli_fetch_assoc($q))) {
        return null;
    }
    $orderNo = trim((string)($r['order_no'] ?? ''));
    if ($orderNo === '') {
        return null;
    }
    $otype = trim((string)($r['order_type'] ?? $order_type));
    return [
        'order_no' => $orderNo,
        'rxdate' => (($r['rxdate'] ?? '') !== '0000-00-00') ? ($r['rxdate'] ?? '') : '',
        'rxtime' => substr(trim((string)($r['rxtime'] ?? '')), 0, 8),
        'order_type' => $otype !== '' ? $otype : $order_type,
        'item_count' => (int)($r['item_count'] ?? 0),
    ];
}

function mrd_latest_bch_order($con_hosxp, $an) {
    return mrd_latest_order_by_type($con_hosxp, $an, 'BCH');
}

function mrd_latest_irx_order($con_hosxp, $an) {
    return mrd_latest_order_by_type($con_hosxp, $an, 'IRX');
}

/** ดึงยาจาก order_no หนึ่งรายการ พร้อมป้าย BCH/IRx */
function mrd_fetch_drugs_for_order($con_hosxp, $an, array $orderInfo) {
    $an = trim((string)$an);
    $orderNo = trim((string)($orderInfo['order_no'] ?? ''));
    if ($an === '' || $orderNo === '') {
        return [];
    }
    $an_esc = mysqli_real_escape_string($con_hosxp, $an);
    $order_esc = mysqli_real_escape_string($con_hosxp, $orderNo);
    $sel = mrd_sql_drug_select_extra();
    $joins = mrd_sql_drug_joins_extra();
    $otype = trim((string)($orderInfo['order_type'] ?? ''));
    $otypeDisp = strtoupper($otype) === 'IRX' ? 'IRx' : (strtoupper($otype) === 'BCH' ? 'BCH' : ($otype !== '' ? $otype : 'Order'));
    $label = 'ขณะ Admit (' . $otypeDisp . ' ' . $orderNo . ')';
    if (!empty($orderInfo['rxdate'])) {
        $label .= ' ' . $orderInfo['rxdate'];
        if (!empty($orderInfo['rxtime'])) {
            $label .= ' ' . substr($orderInfo['rxtime'], 0, 5);
        }
    }
    $sql = "
        SELECT $sel
        FROM opitemrece o
        $joins
        WHERE o.an = '$an_esc'
          AND o.order_no = '$order_esc'
        ORDER BY o.item_no ASC, o.icode ASC
        LIMIT 400
    ";
    $rows = [];
    $q = @mysqli_query($con_hosxp, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $mapped = mrd_map_row($r, $label);
            $mapped['order_no'] = $orderNo;
            $mapped['order_type'] = $otypeDisp;
            $mapped['order_rxdate'] = $orderInfo['rxdate'] ?? '';
            $mapped['order_rxtime'] = $orderInfo['rxtime'] ?? '';
            $mapped['_sort'] = ($orderInfo['rxdate'] ?? '') . ' ' . ($orderInfo['rxtime'] ?? '') . ' ' . str_pad($orderNo, 10, '0', STR_PAD_LEFT);
            $rows[] = $mapped;
        }
    }
    return $rows;
}

/**
 * ยาขณะ Admit จาก BCH ล่าสุด + IRx ล่าสุด
 * ยาซ้ำคงรายการที่ order ใหม่กว่า และระบุว่าเป็น IRx หรือ BCH
 */
function mrd_fetch_admit_drugs($con_hosxp, $an) {
    $an = trim((string)$an);
    if ($an === '') {
        return [];
    }

    $bch = mrd_latest_bch_order($con_hosxp, $an);
    $irx = mrd_latest_irx_order($con_hosxp, $an);
    $rows = [];
    if ($bch) {
        $rows = array_merge($rows, mrd_fetch_drugs_for_order($con_hosxp, $an, $bch));
    }
    if ($irx) {
        $rows = array_merge($rows, mrd_fetch_drugs_for_order($con_hosxp, $an, $irx));
    }
    if ($rows) {
        return mrd_dedupe_keep_latest($rows);
    }

    // fallback: medplan active → opitemrece ถ้าไม่มี BCH/IRx
    $an_esc = mysqli_real_escape_string($con_hosxp, $an);
    $sel = mrd_sql_drug_select_extra();
    $joins = mrd_sql_drug_joins_extra();
    $rows = [];
    $medplan = mrd_fetch_medplan_rows($con_hosxp, $an);
    $active = [];
    foreach ($medplan as $r) {
        if (mrd_is_empty_offdate($r['_offdate'] ?? '')) {
            $active[] = $r;
        }
    }
    $picked = $active;
    if (!$picked && $medplan) {
        $latest = '';
        foreach ($medplan as $r) {
            $od = (string)($r['orderdate'] ?? '');
            if ($od > $latest) {
                $latest = $od;
            }
        }
        foreach ($medplan as $r) {
            if ((string)($r['orderdate'] ?? '') === $latest) {
                $picked[] = $r;
            }
        }
    }
    foreach ($picked as $r) {
        unset($r['_offdate']);
        $mapped = mrd_map_row($r, 'ขณะ Admit (Medplan · ไม่มี BCH/IRx)');
        $mapped['order_type'] = 'Medplan';
        $rows[] = $mapped;
    }

    $sql = "
        SELECT $sel
        FROM opitemrece o
        $joins
        WHERE o.an = '$an_esc'
        ORDER BY o.vstdate DESC, o.vsttime DESC, o.item_no ASC
        LIMIT 400
    ";
    $q = @mysqli_query($con_hosxp, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            if (mrd_is_hme_row($r)) {
                continue;
            }
            $mapped = mrd_map_row($r, 'ขณะ Admit');
            $mapped['order_type'] = trim((string)($r['order_type'] ?? '')) ?: 'Admit';
            $rows[] = $mapped;
        }
    }
    return mrd_dedupe_keep_latest($rows);
}

/** ยากลับบ้าน HME — จาก opitemrece เป็นหลัก + medplan ที่ icode เป็น HME */
function mrd_fetch_hme_drugs($con_hosxp, $an) {
    $an = trim((string)$an);
    if ($an === '') {
        return [];
    }
    $rows = [];
    $hmeIcodes = mrd_hme_icodes_for_an($con_hosxp, $an);

    $an_esc = mysqli_real_escape_string($con_hosxp, $an);
    $sel = mrd_sql_drug_select_extra();
    $joins = mrd_sql_drug_joins_extra();
    $sql = "
        SELECT $sel
        FROM opitemrece o
        $joins
        WHERE o.an = '$an_esc'
          AND (
                LOWER(TRIM(IFNULL(ion.order_type,''))) = 'hme'
             OR UPPER(TRIM(IFNULL(o.item_type,''))) = 'H'
          )
        ORDER BY o.vstdate DESC, o.vsttime DESC, o.item_no ASC
        LIMIT 300
    ";
    $q = @mysqli_query($con_hosxp, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = mrd_map_row($r, 'HME ยากลับบ้าน');
        }
    }

    if ($hmeIcodes) {
        foreach (mrd_fetch_medplan_rows($con_hosxp, $an) as $r) {
            $ic = trim((string)($r['icode'] ?? ''));
            if ($ic === '' || !isset($hmeIcodes[$ic])) {
                continue;
            }
            unset($r['_offdate']);
            $rows[] = mrd_map_row($r, 'HME ยากลับบ้าน (Medplan)');
        }
    }
    return mrd_dedupe_keep_latest($rows);
}

/** Med Recon จาก HOSxP (ถ้ามี) — ใช้เป็น baseline ก่อน Admit */
function mrd_th_datetime($dt) {
    $ts = strtotime(trim((string)$dt));
    if ($ts === false) {
        return '';
    }
    $out = date('d/m/', $ts) . ((int)date('Y', $ts) + 543);
    $hm = date('H:i', $ts);
    if ($hm !== '00:00') {
        $out .= ' ' . $hm;
    }
    return $out;
}

function mrd_hn_norm($hn) {
    $hn = trim((string)$hn);
    if ($hn !== '' && ctype_digit($hn)) {
        $hn = ltrim($hn, '0');
        return $hn === '' ? '0' : $hn;
    }
    return $hn;
}

function mrd_fetch_smart_medrecon_history($con, $hn) {
    $norm = mrd_hn_norm($hn);
    if ($norm === '' || !$con) {
        return [];
    }
    $esc = mysqli_real_escape_string($con, $norm);
    $q = @mysqli_query($con, "SELECT id, vn, an, saved_name, saved_at, payload
        FROM smart_drug_medrecon_history
        WHERE hn_norm = '$esc'
        ORDER BY saved_at DESC, id DESC
        LIMIT 20");
    if (!$q) {
        return [];
    }
    $items = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $payload = json_decode((string)($r['payload'] ?? ''), true);
        $raw = (is_array($payload) && isset($payload['rows']) && is_array($payload['rows'])) ? $payload['rows'] : [];
        $rows = mrd_normalize_client_rows($raw);
        if (!$rows) {
            continue;
        }
        $items[] = [
            'id' => 'local:' . (int)$r['id'],
            'vn' => (string)($r['vn'] ?? ''),
            'an' => (string)($r['an'] ?? ''),
            'saved_name' => (string)($r['saved_name'] ?? ''),
            'saved_at' => (string)($r['saved_at'] ?? ''),
            'saved_at_th' => mrd_th_datetime($r['saved_at'] ?? ''),
            'drug_count' => count($rows),
            'rows' => $rows,
        ];
    }
    return $items;
}

function mrd_fetch_hosxp_medrecon($con_hosxp, $an) {
    $an = trim((string)$an);
    if ($an === '') {
        return [];
    }
    $an_esc = mysqli_real_escape_string($con_hosxp, $an);
    $sql = "
        SELECT mrd.medication_name, mrd.usage_name, mrd.last_receive_date, mrd.qty,
               drc.doctor_reconciliation_command_name
        FROM medication_reconciliation mr
        INNER JOIN medication_reconciliation_detail mrd
            ON mrd.medication_reconciliation_id = mr.medication_reconciliation_id
        LEFT JOIN doctor_reconciliation_command drc
            ON drc.doctor_reconciliation_command_id = mrd.doctor_reconciliation_command_id
        WHERE mr.an = '$an_esc'
        ORDER BY mrd.medication_reconciliation_detail_id DESC
        LIMIT 80
    ";
    $rows = [];
    $q = @mysqli_query($con_hosxp, $sql);
    if (!$q) {
        return [];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $name = trim((string)($r['medication_name'] ?? ''));
        if ($name === '') {
            continue;
        }
        $action = '';
        $cmd = trim((string)($r['doctor_reconciliation_command_name'] ?? ''));
        if ($cmd === 'ใช้ต่อ') {
            $action = 'continue';
        } elseif ($cmd === 'เปลี่ยน') {
            $action = 'change';
        } elseif ($cmd === 'หยุดใช้' || $cmd === 'งด') {
            $action = 'off';
        }
        $rows[] = [
            'row_key' => dr_normalize_row_key('', $name),
            'icode' => '',
            'drug_name' => $name,
            'drug_name_tmt' => $name,
            'display_name' => $name,
            'strength' => '',
            'qty' => (float)($r['qty'] ?? 0),
            'units' => '',
            'method' => dr_clean_method($r['usage_name'] ?? ''),
            'source_label' => 'Med Recon HOSxP',
            'source_date' => $r['last_receive_date'] ?? null,
            'is_hme' => 0,
            'recon_action' => $action,
        ];
    }
    return mrd_dedupe_keep_latest($rows);
}

function mrd_normalize_client_rows(array $rows) {
    $out = [];
    foreach ($rows as $r) {
        if (!is_array($r)) {
            continue;
        }
        $name = trim((string)($r['drug_name'] ?? $r['display_name'] ?? $r['drug_text'] ?? ''));
        $method = trim((string)($r['method'] ?? ''));
        if ($name === '' && !empty($r['drug_text'])) {
            $parts = preg_split("/\n/", (string)$r['drug_text']);
            $name = trim((string)($parts[0] ?? ''));
            if ($method === '' && count($parts) > 1) {
                $method = trim(implode(' ', array_slice($parts, 1)));
            }
        }
        if ($name === '') {
            continue;
        }
        $icode = trim((string)($r['icode'] ?? ''));
        $strength = trim((string)($r['strength'] ?? ''));
        $display = function_exists('di_format_drug_display_name')
            ? di_format_drug_display_name($name, $strength)
            : trim($name . ($strength !== '' ? ' ' . $strength : ''));
        $out[] = [
            'row_key' => dr_normalize_row_key($icode, $display),
            'icode' => $icode,
            'drug_name' => $name,
            'drug_name_tmt' => $name,
            'display_name' => $display,
            'strength' => $strength,
            'qty' => (float)($r['qty'] ?? 0),
            'units' => trim((string)($r['units'] ?? '')),
            'method' => dr_clean_method($method),
            'hospital_name' => trim((string)($r['hospital_name'] ?? '')),
            'source_label' => trim((string)($r['source_label'] ?? 'Smart Drug Med Recon')),
            'source_date' => $r['order_date_iso'] ?? ($r['source_date'] ?? null),
            'is_hme' => 0,
            'recon_action' => trim((string)($r['admit_action'] ?? $r['recon_action'] ?? '')),
            'home_action' => trim((string)($r['home_action'] ?? '')),
            'remark' => trim((string)($r['remark'] ?? '')),
        ];
    }
    return mrd_dedupe_keep_latest($out);
}

function mrd_norm_method($s) {
    $t = function_exists('mb_strtolower')
        ? mb_strtolower(trim(preg_replace('/\s+/u', ' ', (string)$s)), 'UTF-8')
        : strtolower(trim(preg_replace('/\s+/', ' ', (string)$s)));
    return $t;
}

/** ประมาณ mg/วัน จากรายการยา (strength + วิธีใช้) */
function mrd_estimate_mg_day($drug) {
    if (!is_array($drug)) {
        return null;
    }
    if (!function_exists('hosxp_parse_drug_daily_dose_mg')) {
        return null;
    }
    $parsed = hosxp_parse_drug_daily_dose_mg([
        'method' => $drug['method'] ?? '',
        'strength' => $drug['strength'] ?? '',
        'units' => $drug['units'] ?? '',
        'qty' => $drug['qty'] ?? 0,
    ]);
    $mg = $parsed['mg_dose'] ?? null;
    if ($mg === null || !is_numeric($mg) || (float)$mg <= 0) {
        return null;
    }
    return round((float)$mg, 4);
}

/**
 * เทียบวิธีใช้สองฝั่ง (กฎเดียวกับ Admit↔HME)
 * $from = ฐาน (ก่อน Admit หรือ Admit), $to = เป้าหมาย (Admit หรือ HME)
 */
function mrd_compare_usage_sides($from, $to, $fromLabel, $toLabel) {
    $fromMethod = mrd_norm_method(is_array($from) ? ($from['method'] ?? '') : '');
    $toMethod = mrd_norm_method(is_array($to) ? ($to['method'] ?? '') : '');
    $fromMg = is_array($from) ? mrd_estimate_mg_day($from) : null;
    $toMg = is_array($to) ? mrd_estimate_mg_day($to) : null;

    if ($fromMethod !== '' && $fromMethod === $toMethod) {
        return [
            'action' => 'continue',
            'action_reason' => 'วิธีใช้' . $fromLabel . ' = ' . $toLabel,
            'from_mg' => $fromMg,
            'to_mg' => $toMg,
        ];
    }

    if ($fromMg !== null && $toMg !== null) {
        $diff = round($toMg - $fromMg, 4);
        if (abs($diff) < 0.0001) {
            return [
                'action' => 'continue',
                'action_reason' => 'mg/วันเท่ากัน (' . $fromLabel . '→' . $toLabel . ')',
                'from_mg' => $fromMg,
                'to_mg' => $toMg,
            ];
        }
        if ($diff > 0) {
            return [
                'action' => 'up',
                'action_reason' => $toLabel . ' mg/วัน มากกว่า ' . $fromLabel . ' (' . $fromMg . ' → ' . $toMg . ')',
                'from_mg' => $fromMg,
                'to_mg' => $toMg,
            ];
        }
        return [
            'action' => 'down',
            'action_reason' => $toLabel . ' mg/วัน น้อยกว่า ' . $fromLabel . ' (' . $fromMg . ' → ' . $toMg . ')',
            'from_mg' => $fromMg,
            'to_mg' => $toMg,
        ];
    }

    return [
        'action' => 'change',
        'action_reason' => 'วิธีใช้' . $fromLabel . '≠' . $toLabel . ' แต่เทียบ mg/วันไม่ได้',
        'from_mg' => $fromMg,
        'to_mg' => $toMg,
    ];
}

/**
 * คำสั่ง auto:
 * - วิธีใช้มีคำสำคัญงด/hold off (ตั้งค่าได้) → OFF
 * - มี HME: เทียบ Admit↔HME (Cont/Up/Down/Change) · มี HME ไม่มี Admit → Cont
 * - ยังไม่มี HME: เทียบก่อน Admit↔ขณะ Admit (Cont/Up/Down/Change)
 *   · มีก่อน Admit แต่ไม่มีขณะ Admit → OFF
 * - กรณี New (มียาขณะ Admit แต่ไม่มีก่อน Admit): ตัดสินขั้นสุดท้ายจาก HME
 *   · มี HME → เทียบ Admit↔HME ตามด้านบน
 *   · ไม่มี HME → OFF
 */
function mrd_suggest_action($pre, $admit, $hme, array $settings = null) {
    $hasPre = is_array($pre);
    $hasAdmit = is_array($admit);
    $hasHme = is_array($hme);
    if ($settings === null) {
        $settings = [];
    }
    $offKeywords = mrd_settings_off_keywords($settings);

    // ตรวจคำสำคัญงด/hold off ในวิธีใช้ (เน้น HME แล้วตามด้วย Admit / ก่อน Admit)
    $checkTexts = [];
    if ($hasHme) {
        $checkTexts[] = ['side' => 'HME', 'text' => (string)($hme['method'] ?? '')];
    }
    if ($hasAdmit) {
        $checkTexts[] = ['side' => 'Admit', 'text' => (string)($admit['method'] ?? '')];
    }
    if ($hasPre) {
        $checkTexts[] = ['side' => 'ก่อน Admit', 'text' => (string)($pre['method'] ?? '')];
    }
    foreach ($checkTexts as $ct) {
        $hit = mrd_method_match_keyword($ct['text'], $offKeywords);
        if ($hit !== null) {
            return [
                'action' => 'off',
                'action_reason' => 'พบคำสำคัญงด/OFF ในวิธีใช้' . $ct['side'] . ' («' . $hit . '»)',
                'admit_mg' => $hasAdmit ? mrd_estimate_mg_day($admit) : null,
                'hme_mg' => $hasHme ? mrd_estimate_mg_day($hme) : null,
            ];
        }
    }

    // กรณี New: มีขณะ Admit แต่ไม่มีก่อน Admit → ตัดสินขั้นสุดท้ายจาก HME
    $isNewAdmitOnly = $hasAdmit && !$hasPre;
    if ($isNewAdmitOnly && !$hasHme) {
        return [
            'action' => 'off',
            'action_reason' => 'รายการใหม่ขณะ Admit แต่ยังไม่มี HME → OFF',
            'admit_mg' => mrd_estimate_mg_day($admit),
            'hme_mg' => null,
        ];
    }

    // ยังไม่มี HME — เทียบก่อน Admit กับขณะ Admit
    if (!$hasHme) {
        if ($hasPre && !$hasAdmit) {
            return [
                'action' => 'off',
                'action_reason' => 'มียาก่อน Admit แต่ไม่มีขณะ Admit',
                'admit_mg' => null,
                'hme_mg' => null,
            ];
        }
        if ($hasPre && $hasAdmit) {
            $cmp = mrd_compare_usage_sides($pre, $admit, 'ก่อน Admit', 'ขณะ Admit');
            return [
                'action' => $cmp['action'],
                'action_reason' => $cmp['action_reason'],
                'admit_mg' => $cmp['to_mg'],
                'hme_mg' => null,
            ];
        }
        return [
            'action' => '',
            'action_reason' => '',
            'admit_mg' => null,
            'hme_mg' => null,
        ];
    }

    // มี HME (รวมกรณี New ที่มี HME แล้ว — เทียบจาก HME)
    if (!$hasAdmit) {
        return [
            'action' => 'continue',
            'action_reason' => 'มี HME ไม่มี Admit → Cont',
            'admit_mg' => null,
            'hme_mg' => mrd_estimate_mg_day($hme),
        ];
    }

    $cmp = mrd_compare_usage_sides($admit, $hme, 'Admit', 'HME');
    $reason = $cmp['action_reason'];
    if ($isNewAdmitOnly) {
        $reason = 'รายการใหม่ขณะ Admit · ตัดสินจาก HME — ' . $reason;
    }
    return [
        'action' => $cmp['action'],
        'action_reason' => $reason,
        'admit_mg' => $cmp['from_mg'],
        'hme_mg' => $cmp['to_mg'],
    ];
}

function mrd_find_match(array $list, array $probe) {
    $ikey = $probe['row_key'] ?? '';
    $icode = trim((string)($probe['icode'] ?? ''));
    foreach ($list as $row) {
        if ($ikey !== '' && ($row['row_key'] ?? '') === $ikey) {
            return $row;
        }
    }
    if ($icode !== '') {
        foreach ($list as $row) {
            if (trim((string)($row['icode'] ?? '')) === $icode) {
                return $row;
            }
        }
    }
    $name = function_exists('mb_strtolower')
        ? mb_strtolower(trim((string)($probe['display_name'] ?? $probe['drug_name'] ?? '')), 'UTF-8')
        : strtolower(trim((string)($probe['display_name'] ?? $probe['drug_name'] ?? '')));
    if ($name !== '') {
        foreach ($list as $row) {
            $n = function_exists('mb_strtolower')
                ? mb_strtolower(trim((string)($row['display_name'] ?? $row['drug_name'] ?? '')), 'UTF-8')
                : strtolower(trim((string)($row['display_name'] ?? $row['drug_name'] ?? '')));
            if ($n !== '' && $n === $name) {
                return $row;
            }
        }
    }
    return null;
}

/**
 * รวมเป็นแถวเปรียบเทียบ 3 ฝั่ง
 * @return array{rows: array, summary: array}
 */
function mrd_build_three_way(array $pre, array $admit, array $hme, array $settings = null) {
    if ($settings === null) {
        $settings = mrd_default_settings();
    }
    $rows = [];
    $seen = [];
    $sources = [
        ['list' => $pre, 'side' => 'pre'],
        ['list' => $admit, 'side' => 'admit'],
        ['list' => $hme, 'side' => 'hme'],
    ];
    foreach ($sources as $src) {
        foreach ($src['list'] as $seed) {
            $matchKey = $seed['row_key'] ?? '';
            if ($matchKey === '' || isset($seen[$matchKey])) {
                $dup = false;
                foreach ($rows as $ex) {
                    if (!empty($seed['icode']) && $ex['icode'] !== '' && $ex['icode'] === $seed['icode']) {
                        $dup = true;
                        break;
                    }
                }
                if ($dup || $matchKey === '') {
                    continue;
                }
            }
            $seen[$matchKey] = true;

            $p = mrd_find_match($pre, $seed);
            $a = mrd_find_match($admit, $seed);
            $h = mrd_find_match($hme, $seed);
            $display = '';
            $strength = '';
            foreach ([$a, $h, $p, $seed] as $cand) {
                if (!$cand) {
                    continue;
                }
                if ($display === '' && !empty($cand['display_name'])) {
                    $display = $cand['display_name'];
                }
                if ($strength === '' && !empty($cand['strength'])) {
                    $strength = trim((string)$cand['strength']);
                }
                if ($display !== '' && $strength !== '') {
                    break;
                }
            }
            // บังคับรูปแบบ drugname + ความแรง ถ้ายังไม่มี strength ในชื่อ
            if ($display !== '' && $strength !== '' && function_exists('di_format_drug_display_name')) {
                $base = trim((string)(($a['drug_name'] ?? '') ?: ($h['drug_name'] ?? '') ?: ($p['drug_name'] ?? '') ?: ($seed['drug_name'] ?? '') ?: $display));
                $display = di_format_drug_display_name($base, $strength);
            }
            $icode = trim((string)(($a['icode'] ?? '') ?: ($h['icode'] ?? '') ?: ($p['icode'] ?? '') ?: ($seed['icode'] ?? '')));

            $preMethod = $p['method'] ?? '';
            $admitMethod = $a['method'] ?? '';
            $hmeMethod = $h['method'] ?? '';

            $suggest = mrd_suggest_action($p, $a, $h, $settings);
            $action = $suggest['action'];

            $rows[] = [
                'row_key' => $matchKey,
                'icode' => $icode,
                'display_name' => $display,
                'pre' => $p,
                'admit' => $a,
                'hme' => $h,
                'pre_method' => $preMethod,
                'pre_hospital' => trim((string)(is_array($p) ? ($p['hospital_name'] ?? '') : '')),
                'admit_method' => $admitMethod,
                'hme_method' => $hmeMethod,
                'admit_order_type' => trim((string)($a['order_type'] ?? '')),
                'admit_order_no' => trim((string)($a['order_no'] ?? '')),
                'pre_qty' => $p['qty'] ?? null,
                'admit_qty' => $a['qty'] ?? null,
                'hme_qty' => $h['qty'] ?? null,
                'pre_date' => $p['source_date'] ?? '',
                'admit_date' => $a['source_date'] ?? '',
                'hme_date' => $h['source_date'] ?? '',
                'pre_source' => $p['source_label'] ?? '',
                'pre_visit_key' => $p['visit_key'] ?? '',
                'action' => $action,
                'action_reason' => $suggest['action_reason'] ?? '',
                'admit_mg' => $suggest['admit_mg'],
                'hme_mg' => $suggest['hme_mg'],
                'remark' => $p['remark'] ?? '',
                'flags' => [
                    'has_pre' => $p ? 1 : 0,
                    'has_admit' => $a ? 1 : 0,
                    'has_hme' => $h ? 1 : 0,
                ],
            ];
        }
    }

    usort($rows, function ($x, $y) {
        return strcmp((string)$x['display_name'], (string)$y['display_name']);
    });

    return [
        'rows' => $rows,
        'summary' => [
            'pre_count' => count($pre),
            'admit_count' => count($admit),
            'hme_count' => count($hme),
            'row_count' => count($rows),
            'with_hme' => count(array_filter($rows, function ($r) { return !empty($r['flags']['has_hme']); })),
            'pre_only' => count(array_filter($rows, function ($r) {
                return !empty($r['flags']['has_pre']) && empty($r['flags']['has_admit']) && empty($r['flags']['has_hme']);
            })),
            'auto_cont' => count(array_filter($rows, function ($r) { return ($r['action'] ?? '') === 'continue'; })),
            'auto_off' => count(array_filter($rows, function ($r) { return ($r['action'] ?? '') === 'off'; })),
            'auto_up' => count(array_filter($rows, function ($r) { return ($r['action'] ?? '') === 'up'; })),
            'auto_down' => count(array_filter($rows, function ($r) { return ($r['action'] ?? '') === 'down'; })),
            'auto_change' => count(array_filter($rows, function ($r) { return ($r['action'] ?? '') === 'change'; })),
            'auto_new' => count(array_filter($rows, function ($r) { return ($r['action'] ?? '') === 'new'; })),
        ],
    ];
}
