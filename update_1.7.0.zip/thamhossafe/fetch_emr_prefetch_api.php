<?php
/**
 * เตรียม / อ่าน cache Smart Lab (และอ่าน cache Smart Drug ฝั่งเซิร์ฟเวอร์ถ้ามี)
 * Smart Drug หลักถูกเตรียมจากเบราว์เซอร์ผ่าน fetch_hosxp_history_api.php
 */
session_start();
header('Content-Type: application/json; charset=utf-8');
set_time_limit(180);

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/emr_prefetch_helper.php';
require_once __DIR__ . '/hospital_ds_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}

$user_id = (int)$_SESSION['user_id'];
$role = (string)($_SESSION['role'] ?? '');
$can_drug = tham_menu_can('pharm_care.smart_drug') || $role === 'admin';
$can_lab = tham_menu_can('pharm_care.smart_lab') || $role === 'admin';

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST ?: [];
}

$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'prefetch_lab'));
$hn = emr_prefetch_norm_hn($input['hn'] ?? $_GET['hn'] ?? '');

if ($hn === '') {
    echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ HN'], JSON_UNESCAPED_UNICODE);
    exit;
}

$months = emr_prefetch_lookback_months($input['months'] ?? 12, 12);
$include_network = !isset($input['include_network']) || $input['include_network'] === true
    || $input['include_network'] === 1 || $input['include_network'] === '1';
$include_jhcis = isset($input['include_jhcis']) && ($input['include_jhcis'] === true
    || $input['include_jhcis'] === 1 || $input['include_jhcis'] === '1');

session_write_close();

if ($action === 'put_drug_cache') {
    if (!$can_drug) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $data = $input['data'] ?? null;
    if (!is_array($data) || ($data['status'] ?? '') !== 'success') {
        echo json_encode(['status' => 'error', 'message' => 'ข้อมูลไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $params = [
        'months' => $months,
        'network' => $include_network ? 1 : 0,
        'jhcis' => $include_jhcis ? 1 : 0,
    ];
    $ok = emr_prefetch_put('smart_drug', $user_id, $hn, $params, $data);
    echo json_encode(['status' => $ok ? 'success' : 'error'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'get_drug_cache') {
    if (!$can_drug) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $params = [
        'months' => $months,
        'network' => $include_network ? 1 : 0,
        'jhcis' => $include_jhcis ? 1 : 0,
    ];
    $cached = emr_prefetch_get('smart_drug', $user_id, $hn, $params);
    if (!$cached) {
        echo json_encode(['status' => 'miss'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode(['status' => 'success', 'from_cache' => true, 'data' => $cached], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'prefetch_lab' || $action === 'prefetch') {
    if (!$can_lab) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์ Smart Lab'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $lab_params = [
        'months' => $months,
        'network' => $include_network ? 1 : 0,
    ];
    $existing = emr_prefetch_get('smart_lab', $user_id, $hn, $lab_params, 120);
    if ($existing) {
        echo json_encode([
            'status' => 'success',
            'from_cache' => true,
            'order_count' => (int)($existing['order_count'] ?? count($existing['orders'] ?? [])),
            'total_ms' => 0,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $hos = emr_prefetch_hosxp_connect($con);
    if (!$hos) {
        echo json_encode(['status' => 'error', 'message' => 'เชื่อมต่อ HOSxP ไม่ได้'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $lab_bundle = emr_prefetch_fetch_smart_lab($hos, $con, $hn, $months, $include_network);
    @mysqli_close($hos);
    if (empty($lab_bundle['ok'])) {
        echo json_encode(['status' => 'error', 'message' => 'ดึง Lab ไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    emr_prefetch_put('smart_lab', $user_id, $hn, $lab_params, $lab_bundle);
    echo json_encode([
        'status' => 'success',
        'from_cache' => false,
        'order_count' => (int)($lab_bundle['order_count'] ?? 0),
        'total_ms' => (int)($lab_bundle['total_ms'] ?? 0),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'ไม่รู้จักคำสั่ง'], JSON_UNESCAPED_UNICODE);

function emr_prefetch_hosxp_connect($con) {
    if (is_file(__DIR__ . '/hosxp_tmt_drug_helper.php')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
        if (function_exists('hosxp_connect')) {
            $h = @hosxp_connect($con, 30);
            if ($h) {
                return $h;
            }
        }
    }
    $cfg = [];
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ('h_host','h_user','h_pass','h_db')");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cfg[$r['config_name']] = $r['config_value'];
        }
    }
    if (empty($cfg['h_host']) || empty($cfg['h_user'])) {
        return null;
    }
    mysqli_report(MYSQLI_REPORT_OFF);
    $hos = mysqli_init();
    mysqli_options($hos, MYSQLI_OPT_CONNECT_TIMEOUT, 5);
    if (!@mysqli_real_connect($hos, $cfg['h_host'], $cfg['h_user'], $cfg['h_pass'] ?? '', $cfg['h_db'] ?? 'hos')) {
        return null;
    }
    mysqli_set_charset($hos, 'utf8');
    return $hos;
}
