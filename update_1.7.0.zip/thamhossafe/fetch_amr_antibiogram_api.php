<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ini_set('memory_limit', '768M');
set_time_limit(180);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/amr_helper.php');
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_mlab_helper.php';
require_once __DIR__ . '/amr_amass_helper.php';
require_once __DIR__ . '/amr_antibiogram_helper.php';
if (is_file(__DIR__ . '/amr_sensitivity_helper.php')) {
    require_once __DIR__ . '/amr_sensitivity_helper.php';
}
if (is_file(__DIR__ . '/menu_permissions_helper.php')) {
    require_once __DIR__ . '/menu_permissions_helper.php';
}
mysqli_set_charset($con, 'utf8');
if (!function_exists('amr_mlab_using_direct') || !amr_mlab_using_direct($con)) {
    set_time_limit(300);
}

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
if (function_exists('tham_menu_can') && isset($_SESSION['user_id'])
    && !tham_menu_can('amr.antibiogram') && !tham_menu_can('amr.dashboard')) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์เข้าถึง Antibiogram'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

function amr_abg_api_out(array $payload) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = [];
}
$src = array_merge($_GET, $_POST, $input);

$end = amr_parse_date($src['end_date'] ?? '', date('Y-m-d'));
$start = amr_parse_date($src['start_date'] ?? '', date('Y-01-01'));
if ($start > $end) {
    $tmp = $start;
    $start = $end;
    $end = $tmp;
}
$span = (int)floor((strtotime($end) - strtotime($start)) / 86400);
$compare_years = (int)($src['compare_years'] ?? 0);
if ($compare_years < 0) {
    $compare_years = 0;
}
if ($compare_years > 5) {
    $compare_years = 5;
}
if ($compare_years >= 2) {
    if ($span > 1900) {
        $start = date('Y-m-d', strtotime($end . ' -1900 days'));
    }
    set_time_limit(240);
} elseif ($span > 366) {
    $start = date('Y-m-d', strtotime($end . ' -366 days'));
}

$specimen = strtolower(trim((string)($src['specimen'] ?? 'all')));
if (!in_array($specimen, ['all', 'blood', 'urine', 'sputum', 'respiratory', 'stool', 'sterile'], true)) {
    $specimen = 'all';
}
$origin = strtolower(trim((string)($src['origin'] ?? 'all')));
if (!in_array($origin, ['all', 'ipd', 'opd'], true)) {
    $origin = 'all';
}

$result = amr_abg_build($con, [
    'start' => $start,
    'end' => $end,
    'specimen' => $specimen,
    'origin' => $origin,
    'isolate_rule' => (($src['isolate_rule'] ?? 'first') === 'all') ? 'all' : 'first',
    'metric' => $src['metric'] ?? 'S',
    'min_n' => (int)($src['min_n'] ?? 30),
    'include_other' => !empty($src['include_other']),
    'compare_years' => $compare_years,
]);

if (!empty($result['error'])) {
    amr_abg_api_out(['status' => 'error', 'message' => $result['error']]);
}

amr_abg_api_out([
    'status' => 'success',
    'meta' => $result['meta'],
    'drugs' => $result['drugs'],
    'rows' => $result['rows'],
    'sheets' => $result['sheets'] ?? [],
    'phenotypes' => $result['phenotypes'],
    'compare' => $result['compare'] ?? null,
    'year_sheets' => $result['year_sheets'] ?? [],
]);
