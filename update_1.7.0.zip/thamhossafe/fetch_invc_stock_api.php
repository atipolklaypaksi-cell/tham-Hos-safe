<?php
/**
 * API สต็อก INVC (อ่านอย่างเดียว)
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();
include(__DIR__ . '/connect.php');
require_once __DIR__ . '/invc_helper.php';
require_once __DIR__ . '/invc_stock_helper.php';
mysqli_set_charset($con, 'utf8');

function invc_stock_api_json(array $payload, $code = 200) {
    ob_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    invc_stock_api_json(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], 401);
}

require_once __DIR__ . '/menu_permissions_helper.php';
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('invc.stock') && !tham_menu_can('admin.invc')) {
    invc_stock_api_json(['status' => 'error', 'message' => 'ไม่มีสิทธิ์ใช้ระบบ INVC'], 403);
}
session_write_close();

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'list'));

$pdo = invc_connect($con, 20);
if (!$pdo) {
    invc_stock_api_json([
        'status' => 'error',
        'message' => invc_last_error() ?: 'เชื่อมต่อ INVC ไม่ได้',
    ]);
}

if ($action === 'list') {
    $force_sheet = !empty($input['force_sheet']) || (string)($_GET['force_sheet'] ?? '') === '1';
    $res = invc_stock_list(
        $pdo,
        $input['q'] ?? $_GET['q'] ?? '',
        $input['status'] ?? $_GET['status'] ?? 'all',
        !empty($input['include_inactive']) || (string)($_GET['include_inactive'] ?? '') === '1',
        $input['page'] ?? $_GET['page'] ?? 1,
        $input['per_page'] ?? $_GET['per_page'] ?? 40,
        $input['sort'] ?? $_GET['sort'] ?? 'alert',
        $con,
        $force_sheet
    );
    invc_close($pdo);
    if (empty($res['ok'])) {
        invc_stock_api_json(['status' => 'error', 'message' => $res['error'] ?? 'อ่านสต็อกไม่ได้']);
    }
    unset($res['ok']);
    $res['status'] = 'success';
    invc_stock_api_json($res);
}

if ($action === 'history') {
    $res = invc_stock_history($pdo, $input['code'] ?? $_GET['code'] ?? '', 80);
    invc_close($pdo);
    if (empty($res['ok'])) {
        invc_stock_api_json(['status' => 'error', 'message' => $res['error'] ?? 'อ่านประวัติไม่ได้']);
    }
    unset($res['ok']);
    $res['status'] = 'success';
    invc_stock_api_json($res);
}

invc_close($pdo);
invc_stock_api_json(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], 400);
