<?php
/**
 * ยืนยันตัวตนและซิงก์ผู้ใช้จาก HOSxP opduser
 */

require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
require_once __DIR__ . '/menu_permissions_helper.php';

function tham_opduser_default_role() {
    return 'general_staff';
}

/** ตัด \r \n และช่องว่างซ้ำ จาก entryposition ของ HOSxP ให้คีย์ตรงกันตอนบันทึก/โหลด */
function tham_opduser_norm_position($s) {
    $s = str_replace(["\r", "\n", "\0"], '', (string)$s);
    $s = trim($s);
    $s = preg_replace('/[ \t\xA0]+/u', ' ', $s);
    return trim((string)$s);
}

function tham_opduser_valid_roles() {
    return array_keys(tham_menu_role_labels());
}

/** เฉพาะบัญชีที่ยังใช้งานได้ใน HOSxP (account_disable = N) */
function tham_opduser_sql_active_only() {
    return "UPPER(TRIM(IFNULL(account_disable, ''))) = 'N'";
}

/**
 * ต่อ HOSxP สำหรับตาราง opduser เท่านั้น (login / ค้นหารายชื่อ / ตำแหน่ง)
 * ใช้ master ถ้าตั้งค่าไว้ เพราะคิวรีเบา — รายงานยา/แล็บยังใช้การเชื่อมต่อหลัก
 * ถ้า master ต่อไม่ได้ จะถอยไปใช้ HOSxP หลัก
 */
function tham_opduser_connect($con, $read_timeout = 15) {
    $read_timeout = max(8, min(60, (int)$read_timeout));
    if (function_exists('hosxp_master_configured') && hosxp_master_configured($con)) {
        $hos = hosxp_connect_master($con, $read_timeout);
        if ($hos) {
            return $hos;
        }
    }
    if (function_exists('hosxp_connect')) {
        return hosxp_connect($con, $read_timeout);
    }
    return null;
}

function tham_opduser_ensure_tables($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/opduser_auth.sql');
    if ($sql !== false) {
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
            if ($stmt !== '') {
                @mysqli_query($con, $stmt);
            }
        }
    }
    $cols = [
        'auth_source' => "ALTER TABLE users ADD COLUMN auth_source VARCHAR(20) NOT NULL DEFAULT 'local'",
        'entryposition' => "ALTER TABLE users ADD COLUMN entryposition VARCHAR(255) NULL DEFAULT NULL",
        'role_from_entryposition' => "ALTER TABLE users ADD COLUMN role_from_entryposition TINYINT(1) NOT NULL DEFAULT 0",
        'unit_ward' => "ALTER TABLE users ADD COLUMN unit_ward VARCHAR(120) NULL DEFAULT NULL",
    ];
    foreach ($cols as $col => $ddl) {
        $q = mysqli_query($con, "SHOW COLUMNS FROM users LIKE '$col'");
        if ($q && mysqli_num_rows($q) === 0) {
            @mysqli_query($con, $ddl);
        }
    }
    $ready = true;
    return true;
}

function tham_opduser_hash_password($plain) {
    return strtoupper(md5((string)$plain));
}

function tham_opduser_fetch_by_loginname($hos, $loginname) {
    if (!$hos) {
        return null;
    }
    $loginname = trim((string)$loginname);
    if ($loginname === '') {
        return null;
    }
    $esc = mysqli_real_escape_string($hos, $loginname);
    $active = tham_opduser_sql_active_only();
    $q = mysqli_query($hos, "SELECT loginname, name, password, passweb, entryposition, department
        FROM opduser WHERE loginname = '$esc' AND $active LIMIT 1");
    if (!$q || mysqli_num_rows($q) === 0) {
        return null;
    }
    return mysqli_fetch_assoc($q);
}

function tham_opduser_password_matches(array $row, $plain) {
    $hash = tham_opduser_hash_password($plain);
    $lower = md5((string)$plain);
    foreach (['password', 'passweb'] as $field) {
        $stored = trim((string)($row[$field] ?? ''));
        if ($stored === '') {
            continue;
        }
        if (strcasecmp($stored, $hash) === 0 || strcasecmp($stored, $lower) === 0 || $stored === $hash || $stored === $lower) {
            return true;
        }
    }
    return false;
}

function tham_opduser_authenticate($con, $loginname, $password) {
    tham_opduser_ensure_tables($con);
    $hos = tham_opduser_connect($con, 15);
    if (!$hos) {
        return ['ok' => false, 'error' => 'เชื่อมต่อ HOSxP ไม่ได้ กรุณาตรวจสอบการตั้งค่า'];
    }
    $row = tham_opduser_fetch_by_loginname($hos, $loginname);
    mysqli_close($hos);
    if (!$row) {
        return ['ok' => false, 'error' => 'ชื่อผู้ใช้งาน หรือ รหัสผ่านไม่ถูกต้อง'];
    }
    if (!tham_opduser_password_matches($row, $password)) {
        return ['ok' => false, 'error' => 'ชื่อผู้ใช้งาน หรือ รหัสผ่านไม่ถูกต้อง'];
    }
    return ['ok' => true, 'opduser' => $row];
}

function tham_opduser_fetch_role_map($con) {
    tham_opduser_ensure_tables($con);
    $map = [];
    $default = tham_opduser_default_role();
    $q = mysqli_query($con, "SELECT entryposition, role FROM entryposition_role_map");
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $key = tham_opduser_norm_position($row['entryposition'] ?? '');
            if ($key === '') {
                continue;
            }
            $role = trim((string)($row['role'] ?? ''));
            if (!in_array($role, tham_opduser_valid_roles(), true)) {
                continue;
            }
            if (!isset($map[$key]) || ($map[$key] === $default && $role !== $default)) {
                $map[$key] = $role;
            }
        }
    }
    return $map;
}

function tham_opduser_resolve_role($con, $entryposition) {
    $entryposition = tham_opduser_norm_position($entryposition);
    if ($entryposition === '') {
        return tham_opduser_default_role();
    }
    $map = tham_opduser_fetch_role_map($con);
    if (isset($map[$entryposition])) {
        $role = $map[$entryposition];
        if (in_array($role, tham_opduser_valid_roles(), true)) {
            return $role;
        }
    }
    return tham_opduser_default_role();
}

function tham_opduser_sync_local_user($con, array $opduser, $role_override = null) {
    tham_opduser_ensure_tables($con);
    $loginname = trim((string)($opduser['loginname'] ?? ''));
    $full_name = trim((string)($opduser['name'] ?? ''));
    $entryposition = trim((string)($opduser['entryposition'] ?? ''));
    if ($loginname === '') {
        return null;
    }

    $esc_user = mysqli_real_escape_string($con, $loginname);
    $esc_name = mysqli_real_escape_string($con, $full_name);
    $esc_pos = mysqli_real_escape_string($con, $entryposition);
    $placeholder_pass = mysqli_real_escape_string($con, 'opduser:' . $loginname);

    $q = mysqli_query($con, "SELECT id, role, role_from_entryposition, auth_source FROM users WHERE username = '$esc_user' LIMIT 1");
    $existing = ($q && mysqli_num_rows($q) > 0) ? mysqli_fetch_assoc($q) : null;

    if ($role_override !== null && in_array($role_override, tham_opduser_valid_roles(), true)) {
        $role = $role_override;
        $auto_role = 0;
    } elseif ($existing && (int)($existing['role_from_entryposition'] ?? 0) === 0) {
        $role = $existing['role'];
        $auto_role = 0;
    } else {
        $role = tham_opduser_resolve_role($con, $entryposition);
        $auto_role = 1;
    }
    $esc_role = mysqli_real_escape_string($con, $role);

    if ($existing) {
        if (($existing['auth_source'] ?? 'local') === 'local') {
            return null;
        }
        mysqli_query($con, "UPDATE users SET
            full_name = '$esc_name',
            entryposition = " . ($entryposition !== '' ? "'$esc_pos'" : "NULL") . ",
            auth_source = 'opduser',
            role = '$esc_role',
            role_from_entryposition = $auto_role
            WHERE id = " . (int)$existing['id']);
        $user_id = (int)$existing['id'];
    } else {
        mysqli_query($con, "INSERT INTO users (username, password, full_name, role, auth_source, entryposition, role_from_entryposition)
            VALUES ('$esc_user', '$placeholder_pass', '$esc_name', '$esc_role', 'opduser', " .
            ($entryposition !== '' ? "'$esc_pos'" : "NULL") . ", $auto_role)");
        $user_id = (int)mysqli_insert_id($con);
    }
    return [
        'id' => $user_id,
        'username' => $loginname,
        'full_name' => $full_name,
        'role' => $role,
        'entryposition' => $entryposition,
        'auth_source' => 'opduser',
    ];
}

function tham_opduser_fetch_distinct_positions($con) {
    tham_opduser_ensure_tables($con);
    $hos = tham_opduser_connect($con, 30);
    if (!$hos) {
        return ['ok' => false, 'error' => 'เชื่อมต่อ HOSxP ไม่ได้', 'positions' => []];
    }
    $grouped = [];
    $active = tham_opduser_sql_active_only();
    $q = mysqli_query($hos, "SELECT TRIM(entryposition) AS entryposition, COUNT(*) AS user_count
        FROM opduser
        WHERE $active AND TRIM(IFNULL(entryposition, '')) <> ''
        GROUP BY TRIM(entryposition)");
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $pos = tham_opduser_norm_position($row['entryposition'] ?? '');
            if ($pos === '') {
                continue;
            }
            if (!isset($grouped[$pos])) {
                $grouped[$pos] = 0;
            }
            $grouped[$pos] += (int)($row['user_count'] ?? 0);
        }
    }
    mysqli_close($hos);
    $map = tham_opduser_fetch_role_map($con);
    $default = tham_opduser_default_role();
    $positions = [];
    foreach ($grouped as $pos => $count) {
        $positions[] = [
            'entryposition' => $pos,
            'user_count' => $count,
            'role' => $map[$pos] ?? $default,
            'mapped' => isset($map[$pos]),
        ];
    }
    usort($positions, function ($a, $b) {
        return strcasecmp($a['entryposition'], $b['entryposition']);
    });
    return ['ok' => true, 'positions' => $positions, 'default_role' => $default];
}

function tham_opduser_save_role_map($con, array $rows) {
    tham_opduser_ensure_tables($con);
    $valid = array_flip(tham_opduser_valid_roles());
    $default_role = tham_opduser_default_role();
    $seen = [];
    $value_sql = [];
    foreach ($rows as $row) {
        $pos = tham_opduser_norm_position($row['entryposition'] ?? '');
        $role = trim((string)($row['role'] ?? $default_role));
        if ($pos === '' || !isset($valid[$role]) || isset($seen[$pos])) {
            continue;
        }
        $seen[$pos] = true;
        $esc_pos = mysqli_real_escape_string($con, $pos);
        $esc_role = mysqli_real_escape_string($con, $role);
        $value_sql[] = "('$esc_pos','$esc_role')";
    }

    mysqli_begin_transaction($con);
    if (!mysqli_query($con, 'DELETE FROM entryposition_role_map')) {
        $err = mysqli_error($con);
        mysqli_rollback($con);
        return ['ok' => false, 'error' => $err];
    }
    foreach (array_chunk($value_sql, 80) as $chunk) {
        if (empty($chunk)) {
            continue;
        }
        $sql = 'INSERT INTO entryposition_role_map (entryposition, role) VALUES ' . implode(',', $chunk);
        if (!mysqli_query($con, $sql)) {
            $err = mysqli_error($con);
            mysqli_rollback($con);
            return ['ok' => false, 'error' => $err];
        }
    }
    mysqli_commit($con);
    return ['ok' => true, 'saved' => count($seen)];
}

function tham_opduser_apply_role_map_to_users($con) {
    tham_opduser_ensure_tables($con);
    $map = tham_opduser_fetch_role_map($con);
    $default_role = tham_opduser_default_role();
    $q = mysqli_query($con, "SELECT id, role, entryposition FROM users
        WHERE auth_source = 'opduser' AND role_from_entryposition = 1");
    if (!$q) {
        return 0;
    }
    $updated = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $pos = tham_opduser_norm_position($row['entryposition'] ?? '');
        $want = $pos !== '' && isset($map[$pos]) ? $map[$pos] : $default_role;
        if ($want === (string)($row['role'] ?? '')) {
            continue;
        }
        $id = (int)$row['id'];
        $esc = mysqli_real_escape_string($con, $want);
        if (mysqli_query($con, "UPDATE users SET role = '$esc' WHERE id = $id LIMIT 1")) {
            $updated++;
        }
    }
    return $updated;
}

function tham_opduser_build_report_where($hos, array $filters) {
    $parts = [tham_opduser_sql_active_only()];
    $entryposition = trim((string)($filters['entryposition'] ?? ''));
    $department = trim((string)($filters['department'] ?? ''));
    $q = trim((string)($filters['q'] ?? ''));

    if ($entryposition !== '') {
        if ($entryposition === '__empty__') {
            $parts[] = "TRIM(IFNULL(entryposition, '')) = ''";
        } else {
            $esc = mysqli_real_escape_string($hos, $entryposition);
            $parts[] = "TRIM(entryposition) = '$esc'";
        }
    }
    if ($department !== '') {
        $esc = mysqli_real_escape_string($hos, '%' . $department . '%');
        $parts[] = "department LIKE '$esc'";
    }
    if ($q !== '') {
        $esc = mysqli_real_escape_string($hos, '%' . $q . '%');
        $parts[] = "(loginname LIKE '$esc' OR name LIKE '$esc' OR entryposition LIKE '$esc' OR department LIKE '$esc' OR departmentposition LIKE '$esc')";
    }
    return implode(' AND ', $parts);
}

function tham_opduser_fetch_users_report($con, array $filters = []) {
    tham_opduser_ensure_tables($con);
    $hos = tham_opduser_connect($con, 30);
    if (!$hos) {
        return ['ok' => false, 'error' => 'เชื่อมต่อ HOSxP ไม่ได้', 'rows' => [], 'total' => 0];
    }

    $where = tham_opduser_build_report_where($hos, $filters);
    $limit = max(1, min(2000, (int)($filters['limit'] ?? 500)));
    $offset = max(0, (int)($filters['offset'] ?? 0));

    $total = 0;
    $cq = mysqli_query($hos, "SELECT COUNT(*) AS c FROM opduser WHERE $where");
    if ($cq && ($cr = mysqli_fetch_assoc($cq))) {
        $total = (int)$cr['c'];
    }

    $rows = [];
    $sql = "SELECT loginname, name,
            TRIM(IFNULL(entryposition, '')) AS entryposition,
            TRIM(IFNULL(department, '')) AS department,
            TRIM(IFNULL(departmentposition, '')) AS departmentposition
        FROM opduser
        WHERE $where
        ORDER BY entryposition ASC, name ASC, loginname ASC
        LIMIT $offset, $limit";
    $q = mysqli_query($hos, $sql);
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $rows[] = $row;
        }
    }
    mysqli_close($hos);

    $role_map = tham_opduser_fetch_role_map($con);
    $default_role = tham_opduser_default_role();
    $local_users = [];
    $lq = mysqli_query($con, "SELECT username, role, auth_source FROM users");
    if ($lq) {
        while ($lu = mysqli_fetch_assoc($lq)) {
            $local_users[$lu['username']] = $lu;
        }
    }

    $role_labels = tham_menu_role_labels();
    foreach ($rows as &$row) {
        $pos = tham_opduser_norm_position($row['entryposition'] ?? '');
        $mapped_role = $pos !== '' ? ($role_map[$pos] ?? $default_role) : $default_role;
        $local = $local_users[$row['loginname']] ?? null;
        $row['mapped_role'] = $mapped_role;
        $row['mapped_role_label'] = $role_labels[$mapped_role] ?? $mapped_role;
        $row['tham_registered'] = $local ? 1 : 0;
        $row['tham_role'] = $local['role'] ?? '';
        $row['tham_role_label'] = isset($local['role']) ? ($role_labels[$local['role']] ?? $local['role']) : '';
        $row['tham_auth_source'] = $local['auth_source'] ?? '';
    }
    unset($row);

    return [
        'ok' => true,
        'rows' => $rows,
        'total' => $total,
        'limit' => $limit,
        'offset' => $offset,
        'truncated' => ($offset + count($rows)) < $total,
    ];
}

function tham_opduser_fetch_departments($con) {
    $hos = tham_opduser_connect($con, 30);
    if (!$hos) {
        return [];
    }
    $list = [];
    $active = tham_opduser_sql_active_only();
    $q = mysqli_query($hos, "SELECT TRIM(department) AS department, COUNT(*) AS user_count
        FROM opduser
        WHERE $active AND TRIM(IFNULL(department, '')) <> ''
        GROUP BY TRIM(department)
        ORDER BY department ASC");
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $list[] = [
                'department' => $row['department'],
                'user_count' => (int)$row['user_count'],
            ];
        }
    }
    mysqli_close($hos);
    return $list;
}

/**
 * ตำแหน่งเภสัชกรสำหรับช่อง "เภสัชกรที่ Consult"
 * — เท่ากับ "เภสัชกร" หรือขึ้นต้นด้วย "เภสัชกร" (เช่น เภสัชกร ปฏิบัติการ, เภสัชกร (รพ.xxx))
 * — ไม่รวมตำแหน่งที่ขึ้นต้นด้วย "เภสัชกรรม"
 */
function tham_is_pharmacist_consult_position($entryposition) {
    $p = trim((string)$entryposition);
    if ($p === '') {
        return false;
    }
    if (mb_strpos($p, 'เภสัชกร', 0, 'UTF-8') !== 0) {
        return false;
    }
    if (mb_strpos($p, 'เภสัชกรรม', 0, 'UTF-8') === 0) {
        return false;
    }
    return true;
}

function tham_list_consult_pharmacists($con, $prefer_user_id = 0) {
    tham_opduser_ensure_tables($con);
    $prefer_user_id = (int)$prefer_user_id;
    $by_id = [];

    $q = mysqli_query($con, "SELECT id, username, full_name, role, entryposition
        FROM users
        WHERE TRIM(IFNULL(entryposition, '')) LIKE 'เภสัชกร%'
          AND TRIM(IFNULL(entryposition, '')) NOT LIKE 'เภสัชกรรม%'
        ORDER BY full_name ASC, username ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            if (!tham_is_pharmacist_consult_position($r['entryposition'] ?? '')) {
                continue;
            }
            $id = (int)($r['id'] ?? 0);
            if ($id > 0) {
                $by_id[$id] = $r;
            }
        }
    }

    $hos = tham_opduser_connect($con, 20);
    if ($hos) {
        $active = tham_opduser_sql_active_only();
        $q2 = mysqli_query($hos, "SELECT loginname, name, entryposition FROM opduser
            WHERE $active
              AND TRIM(IFNULL(entryposition, '')) LIKE 'เภสัชกร%'
              AND TRIM(IFNULL(entryposition, '')) NOT LIKE 'เภสัชกรรม%'");
        $hos_pos = [];
        if ($q2) {
            while ($r = mysqli_fetch_assoc($q2)) {
                $login = trim((string)($r['loginname'] ?? ''));
                if ($login === '' || !tham_is_pharmacist_consult_position($r['entryposition'] ?? '')) {
                    continue;
                }
                $hos_pos[$login] = trim((string)($r['entryposition'] ?? ''));
            }
        }
        mysqli_close($hos);
        if (!empty($hos_pos)) {
            $in = [];
            foreach (array_keys($hos_pos) as $login) {
                $in[] = "'" . mysqli_real_escape_string($con, $login) . "'";
            }
            foreach (array_chunk($in, 200) as $chunk) {
                $q3 = mysqli_query($con, "SELECT id, username, full_name, role, entryposition
                    FROM users WHERE username IN (" . implode(',', $chunk) . ")");
                if (!$q3) {
                    continue;
                }
                while ($r = mysqli_fetch_assoc($q3)) {
                    $id = (int)($r['id'] ?? 0);
                    if ($id <= 0) {
                        continue;
                    }
                    $login = trim((string)($r['username'] ?? ''));
                    if (!tham_is_pharmacist_consult_position($r['entryposition'] ?? '') && !empty($hos_pos[$login])) {
                        $r['entryposition'] = $hos_pos[$login];
                    }
                    if (!tham_is_pharmacist_consult_position($r['entryposition'] ?? '')) {
                        continue;
                    }
                    $by_id[$id] = $r;
                }
            }
        }
    }

    $rows = array_values($by_id);
    usort($rows, function ($a, $b) {
        $na = trim((string)(($a['full_name'] ?? '') !== '' ? $a['full_name'] : ($a['username'] ?? '')));
        $nb = trim((string)(($b['full_name'] ?? '') !== '' ? $b['full_name'] : ($b['username'] ?? '')));
        return strcmp($na, $nb);
    });

    if ($prefer_user_id > 0) {
        $pref = [];
        $rest = [];
        foreach ($rows as $r) {
            if ((int)$r['id'] === $prefer_user_id) {
                $pref[] = $r;
            } else {
                $rest[] = $r;
            }
        }
        $rows = array_merge($pref, $rest);
    }
    return $rows;
}
