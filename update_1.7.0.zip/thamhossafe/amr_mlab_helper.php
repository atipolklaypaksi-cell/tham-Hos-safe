<?php
/**
 * เชื่อม AMR กับ mLAB โดยตรง — เก็บลงฐาน THAM Hos-Safe แล้วให้ Dashboard/CDSS อ่านจากแคช
 * แหล่งข้อมูล: MySQL mLAB และ/หรือ ไฟล์ DBF (โฟลเดอร์ DATA)
 */

function amr_mlab_cfg_defaults() {
    return [
        'source' => 'hosxp',
        'host' => '',
        'port' => '3306',
        'db' => '',
        'user' => '',
        'pass' => '',
        'dbf_path' => '',
        'dbf_mode' => 'auto',
        'smb_share' => 'C',
        'smb_remote' => 'MLAB/DATA',
        'sync_enabled' => '0',
        'cron_secret' => '',
        'lookback_days' => '365',
        'sync_interval_min' => '10',
    ];
}

function amr_mlab_cfg_keys() {
    return [
        'amr_mlab_source' => 'source',
        'amr_mlab_host' => 'host',
        'amr_mlab_port' => 'port',
        'amr_mlab_db' => 'db',
        'amr_mlab_user' => 'user',
        'amr_mlab_pass' => 'pass',
        'amr_mlab_dbf_path' => 'dbf_path',
        'amr_mlab_dbf_mode' => 'dbf_mode',
        'amr_mlab_smb_share' => 'smb_share',
        'amr_mlab_smb_remote' => 'smb_remote',
        'amr_mlab_sync_enabled' => 'sync_enabled',
        'amr_mlab_cron_secret' => 'cron_secret',
        'amr_mlab_lookback_days' => 'lookback_days',
        'amr_mlab_sync_interval_min' => 'sync_interval_min',
    ];
}

function amr_mlab_get_config($con) {
    $cfg = amr_mlab_cfg_defaults();
    $keys = array_keys(amr_mlab_cfg_keys());
    $in = "'" . implode("','", array_map(function ($k) use ($con) {
        return mysqli_real_escape_string($con, $k);
    }, $keys)) . "'";
    $q = @mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ($in)");
    $map = amr_mlab_cfg_keys();
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $name = $r['config_name'] ?? '';
            if (isset($map[$name])) {
                $cfg[$map[$name]] = (string)($r['config_value'] ?? '');
            }
        }
    }
    if (!in_array($cfg['source'], ['hosxp', 'mlab'], true)) {
        $cfg['source'] = 'hosxp';
    }
    $port = (int)$cfg['port'];
    $cfg['port'] = (string)($port > 0 ? $port : 3306);
    $days = (int)$cfg['lookback_days'];
    $cfg['lookback_days'] = (string)($days > 0 ? min(3650, $days) : 365);
    $cfg['sync_enabled'] = ((string)$cfg['sync_enabled'] === '1') ? '1' : '0';
    $cfg['sync_interval_min'] = (string)amr_mlab_norm_sync_interval($cfg['sync_interval_min'] ?? 10);
    $mode = strtolower(trim($cfg['dbf_mode'] ?? 'auto'));
    $cfg['dbf_mode'] = in_array($mode, ['auto', 'local', 'smb', 'mysql'], true) ? $mode : 'auto';
    if (trim($cfg['smb_share']) === '') {
        $cfg['smb_share'] = 'C';
    }
    if (trim($cfg['smb_remote']) === '') {
        $cfg['smb_remote'] = 'MLAB/DATA';
    }
    return $cfg;
}

function amr_mlab_using_direct($con) {
    $cfg = amr_mlab_get_config($con);
    return ($cfg['source'] ?? '') === 'mlab';
}

function amr_mlab_save_config($con, array $in) {
    $cur = amr_mlab_get_config($con);
    $next = [
        'source' => (($in['source'] ?? $cur['source']) === 'mlab') ? 'mlab' : 'hosxp',
        'host' => trim((string)($in['host'] ?? $cur['host'])),
        'port' => (string)max(1, (int)($in['port'] ?? $cur['port'] ?: 3306)),
        'db' => trim((string)($in['db'] ?? $cur['db'])),
        'user' => trim((string)($in['user'] ?? $cur['user'])),
        'pass' => array_key_exists('pass', $in) ? (string)$in['pass'] : $cur['pass'],
        'dbf_path' => trim((string)($in['dbf_path'] ?? $cur['dbf_path'])),
        'dbf_mode' => strtolower(trim((string)($in['dbf_mode'] ?? $cur['dbf_mode'] ?: 'auto'))),
        'smb_share' => trim((string)($in['smb_share'] ?? $cur['smb_share'] ?: 'C')),
        'smb_remote' => str_replace('\\', '/', trim((string)($in['smb_remote'] ?? $cur['smb_remote'] ?: 'MLAB/DATA'))),
        'sync_enabled' => !empty($in['sync_enabled']) ? '1' : '0',
        'cron_secret' => trim((string)($in['cron_secret'] ?? $cur['cron_secret'])),
        'lookback_days' => (string)max(7, min(3650, (int)($in['lookback_days'] ?? $cur['lookback_days'] ?: 365))),
        'sync_interval_min' => (string)amr_mlab_norm_sync_interval($in['sync_interval_min'] ?? $cur['sync_interval_min'] ?? 10),
    ];
    if (!in_array($next['dbf_mode'], ['auto', 'local', 'smb', 'mysql'], true)) {
        $next['dbf_mode'] = 'auto';
    }
    if ($next['cron_secret'] === '') {
        $next['cron_secret'] = bin2hex(random_bytes(12));
    }
    $rev = array_flip(amr_mlab_cfg_keys());
    foreach ($next as $short => $val) {
        $key = $rev[$short] ?? '';
        if ($key === '') {
            continue;
        }
        $k = mysqli_real_escape_string($con, $key);
        $v = mysqli_real_escape_string($con, $val);
        $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$k'");
        } else {
            mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
        }
    }
    return amr_mlab_get_config($con);
}

function amr_mlab_sync_interval_options() {
    return [
        5 => '5 นาที',
        10 => '10 นาที',
        15 => '15 นาที',
        30 => '30 นาที',
        60 => '1 ชั่วโมง',
        360 => '6 ชั่วโมง',
        1440 => '24 ชั่วโมง',
    ];
}

function amr_mlab_norm_sync_interval($raw) {
    $n = (int)$raw;
    return isset(amr_mlab_sync_interval_options()[$n]) ? $n : 10;
}

function amr_mlab_sync_interval_label($minutes) {
    $opts = amr_mlab_sync_interval_options();
    $n = amr_mlab_norm_sync_interval($minutes);
    return $opts[$n];
}

function amr_mlab_cron_due($con, $interval_min, $force = false) {
    if ($force) {
        return ['due' => true, 'wait_sec' => 0, 'last' => null];
    }
    $interval_min = amr_mlab_norm_sync_interval($interval_min);
    $st = amr_mlab_state_get($con, 'cron');
    $last = $st['updated_at'] ?? null;
    if (!$last) {
        return ['due' => true, 'wait_sec' => 0, 'last' => null];
    }
    $ts = strtotime($last);
    if (!$ts) {
        return ['due' => true, 'wait_sec' => 0, 'last' => $last];
    }
    $need = ($interval_min * 60) - 30;
    $elapsed = time() - $ts;
    if ($elapsed >= $need) {
        return ['due' => true, 'wait_sec' => 0, 'last' => $last];
    }
    return ['due' => false, 'wait_sec' => max(0, $need - $elapsed), 'last' => $last];
}

function amr_mlab_cfg_put($con, $key, $val) {
    $k = mysqli_real_escape_string($con, $key);
    $v = mysqli_real_escape_string($con, (string)$val);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$k'");
    } else {
        mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
    }
}

function amr_mlab_ensure_tables($con) {
    $ok1 = mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_mlab_lab (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        lab_key VARCHAR(64) NOT NULL,
        hn VARCHAR(32) NOT NULL DEFAULT '',
        an VARCHAR(32) NOT NULL DEFAULT '',
        vn VARCHAR(32) NOT NULL DEFAULT '',
        ptname VARCHAR(191) NOT NULL DEFAULT '',
        ward VARCHAR(120) NOT NULL DEFAULT '',
        specimen VARCHAR(120) NOT NULL DEFAULT '',
        organism VARCHAR(191) NOT NULL DEFAULT '',
        order_date DATE DEFAULT NULL,
        order_time VARCHAR(16) NOT NULL DEFAULT '',
        report_date DATE DEFAULT NULL,
        report_time VARCHAR(16) NOT NULL DEFAULT '',
        result_text MEDIUMTEXT NULL,
        source VARCHAR(16) NOT NULL DEFAULT 'sql',
        source_table VARCHAR(64) NOT NULL DEFAULT '',
        synced_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_lab_key (lab_key),
        KEY idx_order_date (order_date),
        KEY idx_hn (hn),
        KEY idx_report_date (report_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    $ok2 = mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_mlab_ast (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        lab_key VARCHAR(64) NOT NULL,
        organism VARCHAR(191) NOT NULL DEFAULT '',
        drug VARCHAR(120) NOT NULL DEFAULT '',
        sir VARCHAR(8) NOT NULL DEFAULT '',
        mic VARCHAR(32) NOT NULL DEFAULT '',
        zone VARCHAR(32) NOT NULL DEFAULT '',
        PRIMARY KEY (id),
        UNIQUE KEY uq_ast (lab_key, organism, drug),
        KEY idx_lab_key (lab_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    $ok3 = mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_mlab_code (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        kind VARCHAR(32) NOT NULL DEFAULT '',
        code VARCHAR(64) NOT NULL DEFAULT '',
        name VARCHAR(191) NOT NULL DEFAULT '',
        extra VARCHAR(191) NOT NULL DEFAULT '',
        PRIMARY KEY (id),
        UNIQUE KEY uq_code (kind, code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    $ok4 = mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_mlab_sync_state (
        state_key VARCHAR(80) NOT NULL,
        last_date DATE DEFAULT NULL,
        last_mtime INT UNSIGNED NOT NULL DEFAULT 0,
        last_count INT UNSIGNED NOT NULL DEFAULT 0,
        last_error VARCHAR(255) NOT NULL DEFAULT '',
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (state_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    $ok5 = mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_mlab_sync_log (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        started_at DATETIME NOT NULL,
        ended_at DATETIME DEFAULT NULL,
        status VARCHAR(16) NOT NULL DEFAULT '',
        inserted_n INT UNSIGNED NOT NULL DEFAULT 0,
        updated_n INT UNSIGNED NOT NULL DEFAULT 0,
        skipped_n INT UNSIGNED NOT NULL DEFAULT 0,
        message VARCHAR(255) NOT NULL DEFAULT '',
        PRIMARY KEY (id),
        KEY idx_started (started_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    return $ok1 && $ok2 && $ok3 && $ok4 && $ok5;
}

function amr_mlab_tis($s) {
    $s = trim((string)$s);
    if ($s === '') {
        return '';
    }
    if (function_exists('mb_detect_encoding') && @mb_detect_encoding($s, ['UTF-8'], true)) {
        return $s;
    }
    if (function_exists('iconv')) {
        $u = @iconv('TIS-620', 'UTF-8//IGNORE', $s);
        if ($u !== false && $u !== '') {
            return trim($u);
        }
        $u = @iconv('Windows-874', 'UTF-8//IGNORE', $s);
        if ($u !== false && $u !== '') {
            return trim($u);
        }
    }
    return $s;
}

function amr_mlab_parse_date($raw) {
    $raw = trim((string)$raw);
    if ($raw === '' || $raw === '0000-00-00' || $raw === '0') {
        return null;
    }
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $raw, $m)) {
        return $m[1] . '-' . $m[2] . '-' . $m[3];
    }
    if (preg_match('/^(\d{4})(\d{2})(\d{2})$/', $raw, $m)) {
        return $m[1] . '-' . $m[2] . '-' . $m[3];
    }
    if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $raw, $m)) {
        return $m[3] . '-' . $m[2] . '-' . $m[1];
    }
    $ts = strtotime($raw);
    return $ts ? date('Y-m-d', $ts) : null;
}

function amr_mlab_pick(array $row, array $aliases) {
    $lower = [];
    foreach ($row as $k => $v) {
        $lower[strtolower((string)$k)] = $v;
    }
    foreach ($aliases as $a) {
        $a = strtolower($a);
        if (array_key_exists($a, $lower) && trim((string)$lower[$a]) !== '') {
            return amr_mlab_tis($lower[$a]);
        }
    }
    return '';
}

function amr_mlab_lab_key($labno, $hn, $date, $organism = '') {
    $labno = preg_replace('/\s+/', '', (string)$labno);
    if ($labno !== '') {
        return substr($labno, 0, 64);
    }
    $hn = preg_replace('/\D+/', '', (string)$hn);
    $date = substr((string)$date, 0, 10);
    $org = substr(preg_replace('/\s+/', '_', $organism), 0, 24);
    return substr('gen|' . $hn . '|' . $date . '|' . $org, 0, 64);
}

function amr_mlab_build_result_text($organism, array $ast_rows, $specimen = '', $extra = '') {
    $lines = [];
    if ($specimen !== '') {
        $lines[] = $specimen;
    }
    $org = trim((string)$organism);
    if ($org !== '') {
        $pheno = function_exists('amr_mlab_derive_phenotype') ? amr_mlab_derive_phenotype($org, $ast_rows) : '';
        if ($pheno !== '') {
            $lines[] = $org . '..(' . $pheno . ')';
        }
        $lines[] = $org;
    }
    if ($extra !== '') {
        $lines[] = $extra;
    }
    foreach ($ast_rows as $a) {
        $drug = trim((string)($a['drug'] ?? ''));
        if ($drug === '') {
            continue;
        }
        $mic = trim((string)($a['mic'] ?? ''));
        $sir = strtoupper(trim((string)($a['sir'] ?? '')));
        $zone = trim((string)($a['zone'] ?? ''));
        $pad = str_pad($drug, 22, '.');
        $mid = $mic !== '' ? $mic : ($zone !== '' ? $zone : '');
        $lines[] = trim($pad . '  ' . str_pad($mid, 6, ' ', STR_PAD_LEFT) . '   ' . $sir);
    }
    $txt = implode("\n", $lines);
    if ($txt !== '' && stripos($txt, 'APPROVED') === false && !empty($ast_rows)) {
        $txt .= "\nAPPROVED";
    }
    return $txt;
}

function amr_mlab_upsert_lab($con, array $lab, array $ast = []) {
    $lab_key = amr_mlab_lab_key($lab['lab_key'] ?? $lab['labno'] ?? '', $lab['hn'] ?? '', $lab['order_date'] ?? '', $lab['organism'] ?? '');
    if ($lab_key === '' || $lab_key === 'gen|||') {
        return 'skip';
    }
    $hn = mysqli_real_escape_string($con, substr((string)($lab['hn'] ?? ''), 0, 32));
    $an = mysqli_real_escape_string($con, substr((string)($lab['an'] ?? ''), 0, 32));
    $vn = mysqli_real_escape_string($con, substr((string)($lab['vn'] ?? ''), 0, 32));
    $ptname = mysqli_real_escape_string($con, substr((string)($lab['ptname'] ?? ''), 0, 191));
    $ward = mysqli_real_escape_string($con, substr((string)($lab['ward'] ?? ''), 0, 120));
    $specimen = mysqli_real_escape_string($con, substr((string)($lab['specimen'] ?? ''), 0, 120));
    $od = amr_mlab_parse_date($lab['order_date'] ?? '');
    $rd = amr_mlab_parse_date($lab['report_date'] ?? $lab['order_date'] ?? '');
    $od_sql = $od ? ("'" . mysqli_real_escape_string($con, $od) . "'") : 'NULL';
    $rd_sql = $rd ? ("'" . mysqli_real_escape_string($con, $rd) . "'") : 'NULL';
    $ot = mysqli_real_escape_string($con, substr((string)($lab['order_time'] ?? ''), 0, 16));
    $rt = mysqli_real_escape_string($con, substr((string)($lab['report_time'] ?? ''), 0, 16));
    $key_esc = mysqli_real_escape_string($con, $lab_key);
    $chk = mysqli_query($con, "SELECT id, organism FROM amr_mlab_lab WHERE lab_key='$key_esc' LIMIT 1");
    $exists = $chk && mysqli_num_rows($chk) > 0;
    $cur_org = '';
    if ($exists) {
        $cur = mysqli_fetch_assoc($chk);
        $cur_org = trim((string)($cur['organism'] ?? ''));
    }
    $new_org = trim((string)($lab['organism'] ?? ''));
    if ($cur_org !== '' && amr_mlab_org_quality($cur_org) > amr_mlab_org_quality($new_org)) {
        $lab['organism'] = $cur_org;
        $new_org = $cur_org;
    }
    $organism = mysqli_real_escape_string($con, substr($new_org, 0, 191));
    $text = (string)($lab['result_text'] ?? '');
    if ($text === '' && ($new_org !== '' || !empty($ast))) {
        $text = amr_mlab_build_result_text($new_org, $ast, $lab['specimen'] ?? '', $lab['extra'] ?? '');
    }
    $text_sql = "'" . mysqli_real_escape_string($con, $text) . "'";
    $source = mysqli_real_escape_string($con, substr((string)($lab['source'] ?? 'sql'), 0, 16));
    $src_tbl = mysqli_real_escape_string($con, substr((string)($lab['source_table'] ?? ''), 0, 64));
    $sql = "INSERT INTO amr_mlab_lab
        (lab_key, hn, an, vn, ptname, ward, specimen, organism, order_date, order_time, report_date, report_time, result_text, source, source_table)
        VALUES ('$key_esc','$hn','$an','$vn','$ptname','$ward','$specimen','$organism',$od_sql,'$ot',$rd_sql,'$rt',$text_sql,'$source','$src_tbl')
        ON DUPLICATE KEY UPDATE
            hn=VALUES(hn), an=VALUES(an), vn=VALUES(vn), ptname=IF(VALUES(ptname)<>'',VALUES(ptname),ptname),
            ward=IF(VALUES(ward)<>'',VALUES(ward),ward), specimen=IF(VALUES(specimen)<>'',VALUES(specimen),specimen),
            organism=IF(VALUES(organism)<>'',VALUES(organism),organism),
            order_date=COALESCE(VALUES(order_date), order_date),
            report_date=COALESCE(VALUES(report_date), report_date),
            result_text=IF(CHAR_LENGTH(VALUES(result_text))>=CHAR_LENGTH(IFNULL(result_text,'')), VALUES(result_text), result_text),
            source=VALUES(source), source_table=VALUES(source_table)";
    if (!mysqli_query($con, $sql)) {
        return 'skip';
    }
    foreach ($ast as $a) {
        $drug = trim((string)($a['drug'] ?? ''));
        if ($drug === '') {
            continue;
        }
        $d = mysqli_real_escape_string($con, substr($drug, 0, 120));
        $org = mysqli_real_escape_string($con, substr((string)($a['organism'] ?? $lab['organism'] ?? ''), 0, 191));
        $sir = mysqli_real_escape_string($con, strtoupper(substr((string)($a['sir'] ?? ''), 0, 8)));
        $mic = mysqli_real_escape_string($con, substr((string)($a['mic'] ?? ''), 0, 32));
        $zone = mysqli_real_escape_string($con, substr((string)($a['zone'] ?? ''), 0, 32));
        mysqli_query($con, "INSERT INTO amr_mlab_ast (lab_key, organism, drug, sir, mic, zone)
            VALUES ('$key_esc','$org','$d','$sir','$mic','$zone')
            ON DUPLICATE KEY UPDATE
                sir=IF(VALUES(sir)<>'',VALUES(sir),sir),
                mic=IF(VALUES(mic)<>'',VALUES(mic),mic),
                zone=IF(VALUES(zone)<>'',VALUES(zone),zone),
                organism=IF(VALUES(organism)<>'',VALUES(organism),organism)");
    }
    return $exists ? 'update' : 'insert';
}

function amr_mlab_state_get($con, $key) {
    $esc = mysqli_real_escape_string($con, $key);
    $q = mysqli_query($con, "SELECT * FROM amr_mlab_sync_state WHERE state_key='$esc' LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function amr_mlab_state_set($con, $key, $date, $mtime, $count, $error = '') {
    $esc = mysqli_real_escape_string($con, $key);
    $d = $date ? ("'" . mysqli_real_escape_string($con, $date) . "'") : 'NULL';
    $mt = (int)$mtime;
    $n = (int)$count;
    $er = mysqli_real_escape_string($con, substr((string)$error, 0, 255));
    mysqli_query($con, "INSERT INTO amr_mlab_sync_state (state_key, last_date, last_mtime, last_count, last_error)
        VALUES ('$esc', $d, $mt, $n, '$er')
        ON DUPLICATE KEY UPDATE last_date=VALUES(last_date), last_mtime=VALUES(last_mtime),
            last_count=VALUES(last_count), last_error=VALUES(last_error)");
}

/* ---------- DBF reader (dBase III/IV / FoxPro, no dbase extension) ---------- */

function amr_mlab_dbf_read($path, $limit = 0, $since_date = null) {
    $path = (string)$path;
    if ($path === '' || !is_file($path) || !is_readable($path)) {
        return ['ok' => false, 'error' => 'อ่านไฟล์ไม่ได้', 'rows' => [], 'fields' => []];
    }
    $fh = @fopen($path, 'rb');
    if (!$fh) {
        return ['ok' => false, 'error' => 'เปิดไฟล์ไม่ได้', 'rows' => [], 'fields' => []];
    }
    $header = fread($fh, 32);
    if (strlen($header) < 32) {
        fclose($fh);
        return ['ok' => false, 'error' => 'ไฟล์ DBF ไม่สมบูรณ์', 'rows' => [], 'fields' => []];
    }
    $nrec = unpack('V', substr($header, 4, 4))[1];
    $hlen = unpack('v', substr($header, 8, 2))[1];
    $rlen = unpack('v', substr($header, 10, 2))[1];
    if ($hlen < 33 || $rlen < 2 || $nrec > 5000000) {
        fclose($fh);
        return ['ok' => false, 'error' => 'หัวไฟล์ DBF ไม่ถูกต้อง', 'rows' => [], 'fields' => []];
    }
    $fields = [];
    $pos = 32;
    while ($pos + 32 <= $hlen) {
        $fd = fread($fh, 32);
        $pos += 32;
        if ($fd === false || strlen($fd) < 32 || ord($fd[0]) === 0x0D) {
            break;
        }
        $name = strtolower(rtrim(substr($fd, 0, 11), "\0 "));
        if ($name === '') {
            continue;
        }
        $fields[] = [
            'name' => $name,
            'type' => strtoupper($fd[11]),
            'len' => ord($fd[16]),
            'dec' => ord($fd[17]),
        ];
    }
    fseek($fh, $hlen);
    $rows = [];
    $max = $limit > 0 ? min($nrec, $limit) : $nrec;
    for ($i = 0; $i < $max; $i++) {
        $rec = fread($fh, $rlen);
        if ($rec === false || strlen($rec) < $rlen) {
            break;
        }
        if (ord($rec[0]) === 0x2A) {
            continue;
        }
        $off = 1;
        $row = [];
        foreach ($fields as $f) {
            $raw = substr($rec, $off, $f['len']);
            $off += $f['len'];
            $val = amr_mlab_tis(rtrim($raw, " \0"));
            if ($f['type'] === 'D' && preg_match('/^\d{8}$/', $val)) {
                $val = substr($val, 0, 4) . '-' . substr($val, 4, 2) . '-' . substr($val, 6, 2);
            }
            $row[$f['name']] = $val;
        }
        if ($since_date) {
            $d = amr_mlab_parse_date(amr_mlab_pick($row, ['date', 'dat', 'hdate', 'recdate', 'order_date', 'cdate', 'labdate']));
            if ($d && $d < $since_date) {
                continue;
            }
        }
        $rows[] = $row;
    }
    fclose($fh);
    return ['ok' => true, 'error' => '', 'rows' => $rows, 'fields' => $fields, 'nrec' => $nrec];
}

function amr_mlab_dbf_each($path, $fn, $since_date = null, $until_date = null) {
    $path = (string)$path;
    if ($path === '' || !is_file($path) || !is_readable($path)) {
        return ['ok' => false, 'error' => 'อ่านไฟล์ไม่ได้', 'nrec' => 0, 'matched' => 0];
    }
    $fh = @fopen($path, 'rb');
    if (!$fh) {
        return ['ok' => false, 'error' => 'เปิดไฟล์ไม่ได้', 'nrec' => 0, 'matched' => 0];
    }
    $header = fread($fh, 32);
    if (strlen($header) < 32) {
        fclose($fh);
        return ['ok' => false, 'error' => 'ไฟล์ DBF ไม่สมบูรณ์', 'nrec' => 0, 'matched' => 0];
    }
    $nrec = unpack('V', substr($header, 4, 4))[1];
    $hlen = unpack('v', substr($header, 8, 2))[1];
    $rlen = unpack('v', substr($header, 10, 2))[1];
    if ($hlen < 33 || $rlen < 2 || $nrec > 5000000) {
        fclose($fh);
        return ['ok' => false, 'error' => 'หัวไฟล์ DBF ไม่ถูกต้อง', 'nrec' => 0, 'matched' => 0];
    }
    $fields = [];
    $pos = 32;
    while ($pos + 32 <= $hlen) {
        $fd = fread($fh, 32);
        $pos += 32;
        if ($fd === false || strlen($fd) < 32 || ord($fd[0]) === 0x0D) {
            break;
        }
        $name = strtolower(rtrim(substr($fd, 0, 11), "\0 "));
        if ($name === '') {
            continue;
        }
        $fields[] = [
            'name' => $name,
            'type' => strtoupper($fd[11]),
            'len' => ord($fd[16]),
        ];
    }
    $date_names = ['date', 'dat', 'hdate', 'recdate', 'order_date', 'cdate', 'labdate', 'spcdate'];
    $date_off = null;
    $date_len = 0;
    $off_acc = 1;
    foreach ($fields as $fi => $f) {
        $fields[$fi]['off'] = $off_acc;
        if ($date_off === null && in_array($f['name'], $date_names, true)) {
            $date_off = $off_acc;
            $date_len = (int)$f['len'];
        }
        $off_acc += $f['len'];
    }
    fseek($fh, $hlen);
    $matched = 0;
    for ($i = 0; $i < $nrec; $i++) {
        $rec = fread($fh, $rlen);
        if ($rec === false || strlen($rec) < $rlen) {
            break;
        }
        if (ord($rec[0]) === 0x2A) {
            continue;
        }
        if (($since_date || $until_date) && $date_off !== null && $date_len > 0) {
            $rawd = rtrim(substr($rec, $date_off, $date_len), " \0");
            $d = null;
            if (preg_match('/^\d{8}$/', $rawd)) {
                $d = substr($rawd, 0, 4) . '-' . substr($rawd, 4, 2) . '-' . substr($rawd, 6, 2);
            } else {
                $d = amr_mlab_parse_date(amr_mlab_tis($rawd));
            }
            if (!$d) {
                continue;
            }
            if ($since_date && $d < $since_date) {
                continue;
            }
            if ($until_date && $d > $until_date) {
                continue;
            }
        }
        $off = 1;
        $row = [];
        foreach ($fields as $f) {
            $raw = substr($rec, $off, $f['len']);
            $off += $f['len'];
            $val = amr_mlab_tis(rtrim($raw, " \0"));
            if ($f['type'] === 'D' && preg_match('/^\d{8}$/', $val)) {
                $val = substr($val, 0, 4) . '-' . substr($val, 4, 2) . '-' . substr($val, 6, 2);
            }
            $row[$f['name']] = $val;
        }
        if (($since_date || $until_date) && $date_off === null) {
            $d = amr_mlab_parse_date(amr_mlab_pick($row, $date_names));
            if (!$d) {
                continue;
            }
            if ($since_date && $d < $since_date) {
                continue;
            }
            if ($until_date && $d > $until_date) {
                continue;
            }
        }
        $matched++;
        if ($fn($row) === false) {
            break;
        }
    }
    fclose($fh);
    return ['ok' => true, 'error' => '', 'nrec' => $nrec, 'matched' => $matched];
}

function amr_mlab_dbf_list($dir) {
    $dir = rtrim(str_replace('\\', '/', (string)$dir), '/');
    if ($dir === '' || !is_dir($dir)) {
        return [];
    }
    $out = [];
    foreach (scandir($dir) ?: [] as $f) {
        if (preg_match('/\.dbf$/i', $f)) {
            $out[strtoupper(preg_replace('/\.dbf$/i', '', $f))] = $dir . '/' . $f;
        }
    }
    return $out;
}

function amr_mlab_local_data_dir() {
    return dirname(__DIR__, 2) . '/mlab_DATA';
}

function amr_mlab_resolve_dbf_path($configured, $smb_cache = false) {
    $configured = rtrim(str_replace('\\', '/', trim((string)$configured)), '/');
    $runtime = amr_mlab_local_data_dir();
    if ($smb_cache) {
        return $runtime;
    }
    if ($configured !== '' && is_dir($configured)) {
        return $configured;
    }
    if (is_dir($runtime)) {
        return $runtime;
    }
    if ($configured !== '') {
        $alt = dirname(__DIR__, 2) . '/' . basename($configured);
        if (is_dir($alt)) {
            return $alt;
        }
    }
    return $configured !== '' ? $configured : $runtime;
}

function amr_mlab_dbf_mode(array $cfg) {
    $m = strtolower(trim((string)($cfg['dbf_mode'] ?? 'auto')));
    return in_array($m, ['auto', 'local', 'smb', 'mysql'], true) ? $m : 'auto';
}

function amr_mlab_want_smb_pull(array $cfg) {
    $mode = amr_mlab_dbf_mode($cfg);
    if ($mode === 'local' || $mode === 'mysql') {
        return false;
    }
    $host = trim((string)($cfg['host'] ?? ''));
    if ($host === '') {
        return false;
    }
    if ($mode === 'smb') {
        return true;
    }
    return amr_mlab_tcp_open($host, 445, 2) || amr_mlab_tcp_open($host, 139, 2);
}

function amr_mlab_smbclient_bin() {
    foreach (['/usr/bin/smbclient', '/usr/local/bin/smbclient', '/bin/smbclient'] as $p) {
        if (is_executable($p)) {
            return $p;
        }
    }
    return '';
}

function amr_mlab_smb_pull(array $cfg, $verbose = false) {
    $host = trim((string)($cfg['host'] ?? ''));
    $user = trim((string)($cfg['user'] ?? ''));
    $pass = (string)($cfg['pass'] ?? '');
    $share = preg_replace('/[^A-Za-z0-9._$\\-]/', '', (string)($cfg['smb_share'] ?? 'C'));
    if ($share === '') {
        $share = 'C';
    }
    $remote = str_replace('\\', '/', (string)($cfg['smb_remote'] ?? 'MLAB/DATA'));
    $remote = trim(preg_replace('#[^A-Za-z0-9._/\\-]#', '', $remote), '/');
    $local = amr_mlab_resolve_dbf_path($cfg['dbf_path'] ?? '', true);
    $cached = amr_mlab_dbf_list($local);
    if ($host === '' || $user === '') {
        return ['ok' => false, 'error' => 'ยังไม่มี Host / Username สำหรับแชร์ไฟล์ (SMB)', 'local' => $local, 'files' => count($cached)];
    }
    if (!is_dir($local) && !@mkdir($local, 0775, true) && !is_dir($local)) {
        return ['ok' => false, 'error' => 'สร้างโฟลเดอร์เก็บ DBF ไม่ได้: ' . $local, 'local' => $local, 'files' => 0];
    }
    $bin = amr_mlab_smbclient_bin();
    if ($bin === '') {
        return [
            'ok' => false,
            'error' => 'เครื่องที่รันเว็บไม่มีคำสั่ง smbclient',
            'local' => $local,
            'files' => count($cached),
            'dbf' => array_keys($cached),
            'cache_ok' => isset($cached['SP']),
        ];
    }
    $cred = tempnam(sys_get_temp_dir(), 'mlabsmb');
    if ($cred === false) {
        return ['ok' => false, 'error' => 'สร้างไฟล์ credentials ไม่ได้', 'local' => $local, 'files' => count($cached)];
    }
    chmod($cred, 0600);
    file_put_contents($cred, "username=$user\npassword=$pass\ndomain=WORKGROUP\n");
    $cd = $remote !== '' ? ('cd ' . $remote . '; ') : '';
    $remote_cmd = $cd . 'lcd ' . $local . '; prompt OFF; mget *.DBF; mget *.dbf';
    $cmd = [$bin, '//' . $host . '/' . $share, '-A', $cred, '-c', $remote_cmd];
    $ds = [1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
    $p = @proc_open($cmd, $ds, $pipes, $local);
    $out = '';
    $err = '';
    if (is_resource($p)) {
        $out = stream_get_contents($pipes[1]);
        $err = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        $code = proc_close($p);
    } else {
        $code = 1;
        $err = 'เรียก smbclient ไม่ได้';
    }
    @unlink($cred);
    $files = amr_mlab_dbf_list($local);
    $ok = $code === 0 && !empty($files);
    $from = '//' . $host . '/' . $share . ($remote !== '' ? '/' . $remote : '');
    $msg = $ok
        ? ('ดึงไฟล์ DBF จาก ' . $from . ' สำเร็จ ' . count($files) . ' ไฟล์')
        : ('ดึงไฟล์ DBF ไม่สำเร็จ' . ($err !== '' ? ': ' . trim(str_replace($pass, '***', $err)) : ''));
    return [
        'ok' => $ok,
        'error' => $ok ? '' : $msg,
        'message' => $msg,
        'local' => $local,
        'files' => count($files),
        'dbf' => array_keys($files),
        'exit' => $code,
        'cache_ok' => isset($files['SP']),
        'log' => $verbose ? trim(str_replace($pass, '***', $out . "\n" . $err)) : '',
    ];
}

function amr_mlab_dbf_inspect($dir) {
    $files = amr_mlab_dbf_list($dir);
    $out = [];
    foreach ($files as $name => $path) {
        $read = amr_mlab_dbf_read($path, 2, null);
        $fields = [];
        foreach ($read['fields'] ?? [] as $f) {
            $fields[] = $f['name'] . ':' . $f['type'] . $f['len'];
        }
        $samples = [];
        foreach ($read['rows'] ?? [] as $row) {
            $safe = [];
            foreach ($row as $k => $v) {
                if (preg_match('/hn|name|pname|fname|lname|cid|idcard|hnno|ptname|patient/i', $k)) {
                    $safe[$k] = ($v === '' || $v === null) ? '' : '(set)';
                } else {
                    $safe[$k] = amr_mlab_tis((string)$v);
                    if (strlen($safe[$k]) > 40) {
                        $safe[$k] = substr($safe[$k], 0, 40) . '…';
                    }
                }
            }
            $samples[] = $safe;
        }
        $out[$name] = [
            'bytes' => filesize($path),
            'nrec' => $read['nrec'] ?? 0,
            'ok' => !empty($read['ok']),
            'error' => $read['error'] ?? '',
            'fields' => $fields,
            'sample' => $samples,
        ];
    }
    return $out;
}

function amr_mlab_row_to_lab(array $row, $source, $table) {
    $labno = amr_mlab_pick($row, ['ln', 'labno', 'lab_no', 'labnumber', 'hcno', 'recno', 'lab_order', 'laborderno', 'lno', 'no']);
    $hn = amr_mlab_pick($row, ['hn', 'pt_hn', 'patienthn', 'hnno']);
    $date = amr_mlab_parse_date(amr_mlab_pick($row, ['date', 'dat', 'hdate', 'recdate', 'order_date', 'cdate', 'labdate', 'collectdate']));
    $org = amr_mlab_pick($row, ['org', 'organism', 'micro', 'bug', 'germ', 'bacteria', 'isolate', 'organismname', 'orgname', 'microbe']);
    $spec = amr_mlab_pick($row, ['spec', 'specimen', 'sample', 'stype', 'spectype', 'sampletype', 'specimen_name']);
    $name = amr_mlab_pick($row, ['name', 'pname', 'ptname', 'fname', 'patient']);
    $ward = amr_mlab_pick($row, ['ward', 'wardname', 'dep', 'department']);
    $extra = amr_mlab_pick($row, ['result', 'report', 'comment', 'note', 'find', 'finding', 'remark']);
    $drug = amr_mlab_pick($row, ['drug', 'drugname', 'ab', 'antibiotic', 'atb', 'abx']);
    $sir = amr_mlab_pick($row, ['sir', 's_i_r', 'interp', 'interpretation', 'result_sir']);
    $mic = amr_mlab_pick($row, ['mic', 'micvalue']);
    $zone = amr_mlab_pick($row, ['zone', 'diam', 'diameter']);
    $ast = [];
    if ($drug !== '') {
        $ast[] = ['drug' => $drug, 'sir' => $sir, 'mic' => $mic, 'zone' => $zone, 'organism' => $org];
    }
    return [
        'lab' => [
            'lab_key' => $labno,
            'hn' => $hn,
            'ptname' => $name,
            'ward' => $ward,
            'specimen' => $spec,
            'organism' => $org,
            'order_date' => $date,
            'report_date' => $date,
            'extra' => $extra,
            'source' => $source,
            'source_table' => $table,
        ],
        'ast' => $ast,
        'date' => $date,
    ];
}

function amr_mlab_code_is_staff_name($name) {
    $n = trim((string)$name);
    return $n !== '' && preg_match('/^พ\./u', $n);
}

function amr_mlab_org_is_screen($code, $name = '') {
    $code = strtoupper(trim((string)$code));
    $name = trim((string)$name);
    $blob = strtoupper(trim($code . ' ' . $name));
    $blob = trim(preg_replace('/[^A-Z0-9+.\-]+/', ' ', $blob));
    if (preg_match('/\b(NLF|XXXNL|XXXLF|GNB|GPC|GPB|GNC|GNR|GPR)\b/', $blob)) {
        return true;
    }
    if ($code === 'LF' || preg_match('/(^|\s)LF(\s|$)/', $blob)) {
        if (!preg_match('/coli|lactobacillus|haemophilus/i', $name)) {
            return true;
        }
    }
    if (preg_match('/^\.?G[+\-][A-Z0-9]*$/', $code)) {
        return true;
    }
    if (preg_match('/GRAM\s+(POSITIVE|NEGATIVE)/i', $name)) {
        return true;
    }
    if (preg_match('/(NON\s*)?LACTOSE\s+FERMENT/i', $name)) {
        return true;
    }
    if (amr_mlab_code_is_staff_name($name)) {
        return true;
    }
    return false;
}

function amr_mlab_org_quality($name, $code = '') {
    $name = trim((string)$name);
    if ($name === '') {
        return 0;
    }
    if (amr_mlab_org_is_screen($code, $name)) {
        return 1;
    }
    if (preg_match('/\b(coli|pneumoniae|aureus|baumannii|aeruginosa|faecium|faecalis|cloacae|hominis|epidermidis|haemolyticus|mirabilis)\b/i', $name)) {
        return 5;
    }
    if (preg_match('/\s/', $name) && strlen($name) > 5) {
        return 4;
    }
    if (!preg_match('/^[A-Z0-9.+_\-]{1,12}$/', $name)) {
        return 3;
    }
    return 2;
}

function amr_mlab_pick_best_org(array $orgs) {
    $best = '';
    $best_q = -1;
    foreach ($orgs as $code => $name) {
        $label = trim((string)$name);
        if ($label === '') {
            $label = trim((string)$code);
        }
        if ($label === '' || amr_mlab_code_is_staff_name($label)) {
            continue;
        }
        $q = amr_mlab_org_quality($label, (string)$code);
        if ($q > $best_q) {
            $best_q = $q;
            $best = $label;
        }
    }
    return $best;
}

function amr_mlab_code_lookup(array $map, $code) {
    $c = strtoupper(trim((string)$code));
    if ($c === '' || $c === '00' || $c === '.') {
        return '';
    }
    if (isset($map[$c]) && $map[$c] !== '' && !amr_mlab_code_is_staff_name($map[$c])) {
        return $map[$c];
    }
    return $c;
}

function amr_mlab_ref_hosxp($ref) {
    $ref = trim((string)$ref);
    if (preg_match('/^(\d+)\s*,/', $ref, $m)) {
        return $m[1];
    }
    if (preg_match('/^\d{6,}$/', $ref)) {
        return $ref;
    }
    return '';
}

function amr_mlab_pair_key($lab_no, $date) {
    return $date . '|' . preg_replace('/\s+/', '', (string)$lab_no);
}

function amr_mlab_load_name_map($path, $code_field, $name_fields) {
    $out = [];
    $read = amr_mlab_dbf_read($path, 0, null);
    if (empty($read['ok'])) {
        return $out;
    }
    foreach ($read['rows'] as $row) {
        $c = strtoupper(trim((string)($row[$code_field] ?? '')));
        if ($c === '') {
            continue;
        }
        $name = '';
        foreach ($name_fields as $f) {
            $name = trim((string)($row[$f] ?? ''));
            if ($name !== '') {
                break;
            }
        }
        if ($name !== '') {
            if (!amr_mlab_code_is_staff_name($name)) {
                $out[$c] = $name;
            }
            $loc = strtoupper(trim((string)($row['code_loc'] ?? $row['code_new'] ?? '')));
            if ($loc !== '' && !amr_mlab_code_is_staff_name($name) && !isset($out[$loc])) {
                $out[$loc] = $name;
            }
        }
    }
    return $out;
}

function amr_mlab_ast_from_wide(array $row, array $drugs) {
    $skip = [
        'lab_no', 'date', 'quantity', 'organism', 'micit_meth', 'micdr_itsp', 'micit_trou',
        'mbcbt_trou', 'micit_peak', 'mbcbt_peak', 'micit_date', 'repo_day', 'reporter',
        'organism2', 'barcode', 'barcodeold', 'datesend', 'timesend', 'sender', 'sendno',
        'vendor', 'dateread', 'timeread', 'day_done', 'media', 'color', 'texture', 'hemolyse',
        'size', 'odor', 'method', 'status', 'ws_date', 'ws_time', 'purpose', 'note',
        'sp_errtype', 'wbc', 'epith', 'infection', 'order',
    ];
    $org = strtoupper(trim((string)($row['organism'] ?? '')));
    $ast = [];
    foreach ($row as $k => $v) {
        if (in_array($k, $skip, true)) {
            continue;
        }
        $v = strtoupper(trim((string)$v));
        if ($v === '' || $v === '.' || $v === '-') {
            continue;
        }
        if (!preg_match('/^[SIR][+-]?$/', $v) && !in_array($v, ['NS', 'NI', 'SDD'], true)) {
            continue;
        }
        $kk = strtoupper($k);
        $ast[] = [
            'drug' => $drugs[$kk] ?? $kk,
            'sir' => substr($v, 0, 8),
            'mic' => '',
            'zone' => '',
            'organism' => $org,
        ];
    }
    return $ast;
}

function amr_mlab_sync_dbf_native($con, array $files, array $cfg, $since_date = null, $until_date = null) {
    $stats = ['insert' => 0, 'update' => 0, 'skip' => 0, 'files' => 0, 'error' => ''];
    $until_date = $until_date ?: ($cfg['_until'] ?? null);
    if (empty($cfg['_no_lookback_floor'])) {
        $lookback = max(7, (int)($cfg['lookback_days'] ?? 365));
        $floor = date('Y-m-d', strtotime('-' . $lookback . ' days'));
        if (!$since_date || $since_date < $floor) {
            $since_date = $floor;
        }
    }

    $codes = amr_mlab_load_name_map($files['CODE'], 'code', ['decode', 'name']);
    $stats['files']++;
    foreach ($codes as $code => $name) {
        if (amr_mlab_org_is_screen($code, $name) && !preg_match('/\s/', $name)) {
            continue;
        }
        if (amr_mlab_code_is_staff_name($name)) {
            continue;
        }
        $c = mysqli_real_escape_string($con, substr((string)$code, 0, 64));
        $n = mysqli_real_escape_string($con, substr((string)$name, 0, 191));
        mysqli_query($con, "INSERT INTO amr_mlab_code (kind, code, name) VALUES ('organism','$c','$n')
            ON DUPLICATE KEY UPDATE name=VALUES(name)");
    }
    $drugs = [];
    if (isset($files['DRUG'])) {
        $drugs = amr_mlab_load_name_map($files['DRUG'], 'dr_field', ['dr_lname', 'dr_lname1', 'dr_sname1', 'dr_sname2']);
        $stats['files']++;
    }
    $patients = [];
    if (isset($files['PA'])) {
        $stats['files']++;
        amr_mlab_dbf_each($files['PA'], function ($row) use (&$patients) {
            $hn = preg_replace('/\s+/', '', (string)($row['hn'] ?? ''));
            if ($hn === '') {
                return;
            }
            $patients[$hn] = [
                'name' => trim((string)($row['name'] ?? '')),
                'ward' => trim((string)($row['ward'] ?? '')),
            ];
        });
    }

    $isolates = [];
    foreach (['ZR', 'OZ', 'NS', 'WS', 'OR', 'OA', 'OM'] as $tbl) {
        if (!isset($files[$tbl])) {
            continue;
        }
        $stats['files']++;
        amr_mlab_dbf_each($files[$tbl], function ($row) use (&$isolates, $tbl, $codes, $drugs) {
            $date = amr_mlab_parse_date($row['date'] ?? '');
            $lab_no = trim((string)($row['lab_no'] ?? ''));
            if ($date === '' || $lab_no === '') {
                return;
            }
            $k = amr_mlab_pair_key($lab_no, $date);
            if (!isset($isolates[$k])) {
                $isolates[$k] = ['orgs' => [], 'ast' => []];
            }
            foreach (['organism', 'organism2'] as $of) {
                $org_code = strtoupper(trim((string)($row[$of] ?? '')));
                if ($org_code === '' || $org_code === '00' || $org_code === '.') {
                    continue;
                }
                $isolates[$k]['orgs'][$org_code] = amr_mlab_code_lookup($codes, $org_code);
            }
            if ($tbl === 'OR' || $tbl === 'OA') {
                foreach (amr_mlab_ast_from_wide($row, $drugs) as $a) {
                    $oc = strtoupper(trim((string)($a['organism'] ?? '')));
                    if ($oc !== '') {
                        $a['organism'] = amr_mlab_code_lookup($codes, $oc);
                    }
                    $isolates[$k]['ast'][] = $a;
                }
            } elseif ($tbl === 'OM') {
                $drug_code = strtoupper(trim((string)($row['micdr_itsp'] ?? '')));
                $mic = trim((string)($row['micit_trou'] ?? ''));
                if ($drug_code !== '' && $mic !== '') {
                    $org_code = strtoupper(trim((string)($row['organism'] ?? '')));
                    $drug_name = $drugs[$drug_code] ?? $drug_code;
                    $applied = false;
                    foreach ($isolates[$k]['ast'] as &$a) {
                        $ad = (string)($a['drug'] ?? '');
                        if ($ad === $drug_name || strcasecmp($ad, $drug_code) === 0
                            || (function_exists('amr_sens_ast_matches_atb') && amr_sens_ast_matches_atb($ad, $drug_name))
                        ) {
                            if (trim((string)($a['mic'] ?? '')) === '') {
                                $a['mic'] = $mic;
                            }
                            $applied = true;
                            break;
                        }
                    }
                    unset($a);
                    if (!$applied) {
                        $isolates[$k]['ast'][] = [
                            'drug' => $drug_name,
                            'sir' => '',
                            'mic' => $mic,
                            'zone' => '',
                            'organism' => amr_mlab_code_lookup($codes, $org_code),
                        ];
                    }
                }
            }
        }, $since_date, $until_date);
    }

    $max_date = $since_date;
    $n = 0;
    $sp = amr_mlab_dbf_each($files['SP'], function ($row) use ($con, &$isolates, &$patients, $codes, &$stats, &$n, &$max_date) {
        $date = amr_mlab_parse_date($row['date'] ?? $row['spcdate'] ?? '');
        $lab_no = trim((string)($row['lab_no'] ?? ''));
        if ($date === '' || $lab_no === '') {
            $stats['skip']++;
            return;
        }
        $hn = preg_replace('/\s+/', '', (string)($row['hn'] ?? ''));
        $pair = amr_mlab_pair_key($lab_no, $date);
        $iso = $isolates[$pair] ?? ['orgs' => [], 'ast' => []];
        $org_names = array_values(array_filter($iso['orgs']));
        $best_org = amr_mlab_pick_best_org($iso['orgs'] ?? []);
        $spec = amr_mlab_code_lookup($codes, $row['source'] ?? '');
        $pt = $patients[$hn] ?? ['name' => '', 'ward' => ''];
        $hos = amr_mlab_ref_hosxp($row['ref_no'] ?? '');
        $lab_key = $hos !== '' ? $hos : ($date . '-' . $lab_no);
        $extra = implode(' ; ', $org_names);
        $mapped = [
            'lab' => [
                'lab_key' => $lab_key,
                'hn' => $hn,
                'ptname' => $pt['name'],
                'ward' => trim((string)($row['ward'] ?? '')) !== '' ? trim((string)$row['ward']) : ($pt['ward'] ?? ''),
                'specimen' => $spec,
                'organism' => $best_org !== '' ? $best_org : ($org_names[0] ?? ''),
                'order_date' => $date,
                'order_time' => trim((string)($row['spctime'] ?? $row['rcvtime'] ?? '')),
                'report_date' => $date,
                'report_time' => trim((string)($row['rpttime'] ?? '')),
                'extra' => $extra,
                'source' => 'dbf',
                'source_table' => 'SP',
            ],
            'ast' => $iso['ast'],
        ];
        $act = amr_mlab_upsert_lab($con, $mapped['lab'], $mapped['ast']);
        if ($act === 'insert') {
            $stats['insert']++;
        } elseif ($act === 'update') {
            $stats['update']++;
        } else {
            $stats['skip']++;
        }
        $n++;
        if ($date > $max_date) {
            $max_date = $date;
        }
        unset($isolates[$pair]);
    }, $since_date, $until_date);
    $stats['files']++;
    if (empty($sp['ok'])) {
        $stats['error'] = $sp['error'] !== '' ? $sp['error'] : 'อ่าน SP.DBF ไม่ได้';
        return $stats;
    }
    $prev = amr_mlab_state_get($con, 'dbf:SP');
    $prev_date = $prev['last_date'] ?? '';
    if ($max_date && ($prev_date === '' || $max_date > $prev_date)) {
        amr_mlab_state_set($con, 'dbf:SP', $max_date, (int)@filemtime($files['SP']), $n, '');
    }
    $note = 'SP ' . $n . ' รายการตั้งแต่ ' . ($since_date ?: '-');
    if ($until_date) {
        $note .= ' ถึง ' . $until_date;
    }
    $stats['files_note'] = $note;
    return $stats;
}

function amr_mlab_sync_dbf($con, array $cfg, $since_date = null, $until_date = null) {
    $stats = ['insert' => 0, 'update' => 0, 'skip' => 0, 'files' => 0, 'error' => ''];
    $cfg['dbf_path'] = amr_mlab_resolve_dbf_path($cfg['dbf_path'] ?? '', amr_mlab_dbf_mode($cfg) !== 'local');
    $files = amr_mlab_dbf_list($cfg['dbf_path'] ?? '');
    if (empty($files)) {
        $stats['error'] = 'ไม่พบไฟล์ .DBF ในโฟลเดอร์ที่ระบุ';
        return $stats;
    }
    if (isset($files['SP']) && isset($files['CODE'])) {
        return amr_mlab_sync_dbf_native($con, $files, $cfg, $since_date, $until_date);
    }
    $prefer = ['HC', 'CA', 'CL', 'NS'];
    $queue = [];
    foreach ($prefer as $name) {
        if (isset($files[$name])) {
            $queue[$name] = $files[$name];
        }
    }
    foreach ($files as $name => $path) {
        if (!isset($queue[$name]) && !in_array($name, ['CODE', 'DRUG', 'DRUGEXP', 'DRUGZONE', 'PA'], true)) {
            $queue[$name] = $path;
        }
    }
    foreach (['CODE', 'DRUG'] as $dict) {
        if (!isset($files[$dict])) {
            continue;
        }
        $read = amr_mlab_dbf_read($files[$dict], 20000, null);
        if (empty($read['ok'])) {
            continue;
        }
        $stats['files']++;
        foreach ($read['rows'] as $row) {
            $code = amr_mlab_pick($row, ['code', 'cd', 'id', 'no']);
            $name = amr_mlab_pick($row, ['name', 'desc', 'description', 'drug', 'org', 'decode', 'dr_lname']);
            if ($code === '' && $name === '') {
                continue;
            }
            $kind = strtolower($dict);
            $c = mysqli_real_escape_string($con, substr($code !== '' ? $code : $name, 0, 64));
            $n = mysqli_real_escape_string($con, substr($name !== '' ? $name : $code, 0, 191));
            mysqli_query($con, "INSERT INTO amr_mlab_code (kind, code, name) VALUES ('$kind','$c','$n')
                ON DUPLICATE KEY UPDATE name=VALUES(name)");
        }
    }
    $max_date = $since_date;
    foreach ($queue as $name => $path) {
        $st = amr_mlab_state_get($con, 'dbf:' . $name);
        $mtime = (int)@filemtime($path);
        $file_since = $since_date;
        if ($st && (int)($st['last_mtime'] ?? 0) === $mtime && !$since_date) {
            $file_since = $st['last_date'] ?? $file_since;
        } elseif ($st && !empty($st['last_date']) && !$since_date) {
            $file_since = $st['last_date'];
        }
        $read = amr_mlab_dbf_read($path, 0, $file_since);
        $stats['files']++;
        if (empty($read['ok'])) {
            amr_mlab_state_set($con, 'dbf:' . $name, $st['last_date'] ?? null, $mtime, 0, $read['error'] ?? '');
            continue;
        }
        $n = 0;
        $local_max = $file_since;
        foreach ($read['rows'] as $row) {
            $mapped = amr_mlab_row_to_lab($row, 'dbf', $name);
            $act = amr_mlab_upsert_lab($con, $mapped['lab'], $mapped['ast']);
            if ($act === 'insert') {
                $stats['insert']++;
            } elseif ($act === 'update') {
                $stats['update']++;
            } else {
                $stats['skip']++;
            }
            $n++;
            if ($mapped['date'] && ($local_max === null || $mapped['date'] > $local_max)) {
                $local_max = $mapped['date'];
            }
        }
        amr_mlab_state_set($con, 'dbf:' . $name, $local_max, $mtime, $n, '');
        if ($local_max && ($max_date === null || $local_max > $max_date)) {
            $max_date = $local_max;
        }
    }
    return $stats;
}

/* ---------- Direct MySQL mLAB ---------- */

function amr_mlab_tcp_open($host, $port, $timeout = 2) {
    $host = trim((string)$host);
    $port = (int)$port;
    if ($host === '' || $port < 1 || $port > 65535) {
        return false;
    }
    $errno = 0;
    $errstr = '';
    $fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
    if (is_resource($fp)) {
        fclose($fp);
        return true;
    }
    return false;
}

function amr_mlab_sql_connect(array $cfg) {
    if (trim($cfg['host'] ?? '') === '' || trim($cfg['db'] ?? '') === '') {
        return ['ok' => false, 'error' => 'กรุณาระบุ Host และชื่อฐานข้อมูล mLAB', 'link' => null];
    }
    mysqli_report(MYSQLI_REPORT_OFF);
    $c = mysqli_init();
    if (!$c) {
        return ['ok' => false, 'error' => 'สร้างการเชื่อมต่อไม่ได้', 'link' => null];
    }
    mysqli_options($c, MYSQLI_OPT_CONNECT_TIMEOUT, 8);
    $port = (int)($cfg['port'] ?? 3306);
    $ok = @mysqli_real_connect($c, $cfg['host'], $cfg['user'] ?? '', $cfg['pass'] ?? '', $cfg['db'], $port);
    if (!$ok) {
        return ['ok' => false, 'error' => 'เชื่อม mLAB ไม่สำเร็จ: ' . mysqli_connect_error(), 'link' => null];
    }
    @mysqli_set_charset($c, 'tis620');
    @mysqli_query($c, "SET NAMES tis620");
    return ['ok' => true, 'error' => '', 'link' => $c];
}

function amr_mlab_sql_tables($mlab) {
    $out = [];
    $q = @mysqli_query($mlab, 'SHOW TABLES');
    if (!$q) {
        return $out;
    }
    while ($r = mysqli_fetch_row($q)) {
        $name = (string)($r[0] ?? '');
        if ($name !== '') {
            $out[strtolower($name)] = $name;
        }
    }
    return $out;
}

function amr_mlab_sql_columns($mlab, $table) {
    $esc = str_replace('`', '', $table);
    $q = @mysqli_query($mlab, 'SHOW COLUMNS FROM `' . $esc . '`');
    $out = [];
    if (!$q) {
        return $out;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $out[strtolower((string)($r['Field'] ?? ''))] = $r['Field'];
    }
    return $out;
}

function amr_mlab_sql_pick_table(array $tables, array $want) {
    foreach ($want as $w) {
        if (isset($tables[strtolower($w)])) {
            return $tables[strtolower($w)];
        }
    }
    return '';
}

function amr_mlab_sync_sql($con, $mlab, array $cfg, $since_date = null) {
    $stats = ['insert' => 0, 'update' => 0, 'skip' => 0, 'tables' => [], 'error' => ''];
    $tables = amr_mlab_sql_tables($mlab);
    if (empty($tables)) {
        $stats['error'] = 'เชื่อมได้แต่ไม่พบตารางในฐาน mLAB';
        return $stats;
    }
    $candidates = [];
    foreach (['hc', 'ca', 'cl', 'ns', 'laborder', 'lab_order', 'culture', 'ast', 'labresult', 'lab_result'] as $t) {
        if (isset($tables[$t])) {
            $candidates[] = $tables[$t];
        }
    }
    if (empty($candidates)) {
        foreach ($tables as $t) {
            $candidates[] = $t;
            if (count($candidates) >= 8) {
                break;
            }
        }
    }
    $lookback = max(7, (int)($cfg['lookback_days'] ?? 365));
    $floor = date('Y-m-d', strtotime('-' . $lookback . ' days'));
    if ($since_date && $since_date > $floor) {
        $floor = $since_date;
    }
    foreach ($candidates as $table) {
        $cols = amr_mlab_sql_columns($mlab, $table);
        if (empty($cols)) {
            continue;
        }
        $date_col = '';
        foreach (['date', 'dat', 'hdate', 'recdate', 'order_date', 'cdate', 'labdate', 'collectdate', 'report_date'] as $c) {
            if (isset($cols[$c])) {
                $date_col = $cols[$c];
                break;
            }
        }
        $sql = 'SELECT * FROM `' . str_replace('`', '', $table) . '`';
        $where = [];
        if ($date_col !== '') {
            $where[] = '`' . str_replace('`', '', $date_col) . "` >= '" . mysqli_real_escape_string($mlab, $floor) . "'";
        }
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' LIMIT 50000';
        $q = @mysqli_query($mlab, $sql);
        if (!$q) {
            continue;
        }
        $n = 0;
        $local_max = $floor;
        while ($row = mysqli_fetch_assoc($q)) {
            $mapped = amr_mlab_row_to_lab($row, 'sql', $table);
            $act = amr_mlab_upsert_lab($con, $mapped['lab'], $mapped['ast']);
            if ($act === 'insert') {
                $stats['insert']++;
            } elseif ($act === 'update') {
                $stats['update']++;
            } else {
                $stats['skip']++;
            }
            $n++;
            if ($mapped['date'] && $mapped['date'] > $local_max) {
                $local_max = $mapped['date'];
            }
        }
        $stats['tables'][] = $table . ':' . $n;
        amr_mlab_state_set($con, 'sql:' . strtolower($table), $local_max, time(), $n, '');
    }
    return $stats;
}

function amr_mlab_test_connection(array $cfg) {
    $out = [
        'sql_ok' => false,
        'sql_message' => '',
        'sql_tables' => [],
        'dbf_ok' => false,
        'dbf_message' => '',
        'dbf_files' => [],
        'hint' => '',
        'port_mysql' => false,
        'port_smb' => false,
        'dbf_mode' => amr_mlab_dbf_mode($cfg),
    ];
    $mode = $out['dbf_mode'];
    $host = trim($cfg['host'] ?? '');
    $mysql_port = (int)($cfg['port'] ?? 3306);
    if ($mysql_port < 1) {
        $mysql_port = 3306;
    }
    if ($host !== '') {
        $out['port_mysql'] = amr_mlab_tcp_open($host, $mysql_port, 2);
        $out['port_smb'] = amr_mlab_tcp_open($host, 445, 2) || amr_mlab_tcp_open($host, 139, 2);
    }
    if ($mode !== 'local' && $host !== '' && $out['port_mysql'] && trim($cfg['db'] ?? '') !== '') {
        $c = amr_mlab_sql_connect($cfg);
        $out['sql_ok'] = !empty($c['ok']);
        $out['sql_message'] = $c['error'] !== '' ? $c['error'] : 'เชื่อมฐานข้อมูล mLAB (MySQL) สำเร็จ';
        if (!empty($c['ok']) && $c['link']) {
            $out['sql_tables'] = array_values(amr_mlab_sql_tables($c['link']));
            mysqli_close($c['link']);
        }
    } elseif ($mode === 'mysql' && $host === '') {
        $out['sql_message'] = 'โหมด MySQL — กรุณาระบุ Host และชื่อฐาน';
    } elseif ($mode === 'mysql' && !$out['port_mysql']) {
        $out['sql_message'] = 'พอร์ต ' . $mysql_port . ' ไม่ตอบ — เครื่องนี้ไม่ได้เปิด MySQL';
    } else {
        $out['sql_message'] = 'ข้ามทดสอบ MySQL (ใช้ไฟล์ DBF)';
    }

    if ($mode !== 'mysql' && amr_mlab_want_smb_pull($cfg)) {
        $pull = amr_mlab_smb_pull($cfg);
        if (!empty($pull['ok'])) {
            $cfg['dbf_path'] = $pull['local'];
            $out['hint'] = $pull['message'];
        } else {
            $out['hint'] = $pull['error'] !== '' ? $pull['error'] : 'ดึงไฟล์จากแชร์ SMB ไม่สำเร็จ';
        }
    }

    $use_cache = ($mode === 'smb') || ($mode === 'auto' && amr_mlab_want_smb_pull($cfg));
    $path = amr_mlab_resolve_dbf_path($cfg['dbf_path'] ?? '', $use_cache);
    if ($mode === 'mysql') {
        $out['dbf_message'] = 'โหมด MySQL — ไม่ใช้โฟลเดอร์ DBF';
    } elseif ($path === '') {
        $out['dbf_message'] = 'ยังไม่ระบุโฟลเดอร์ไฟล์ DBF';
        if ($out['hint'] === '' && $mode === 'local') {
            $out['hint'] = 'รพ.ที่ใช้ Linux/NFS ให้ใส่พาธที่ PHP มองเห็นได้ เช่น /var/www/html/mlab_DATA';
        }
    } elseif (!is_dir($path)) {
        $out['dbf_message'] = 'ไม่พบโฟลเดอร์: ' . $path . ' (ต้องเป็นพาธที่โปรเซส PHP เห็น — ถ้าเว็บรันใน Docker ใช้พาธในคอนเทนเนอร์ เช่น /var/www/html/mlab_DATA ไม่ใช่พาธบนเครื่องโฮสต์)';
    } else {
        $files = amr_mlab_dbf_list($path);
        $out['dbf_ok'] = !empty($files);
        $out['dbf_files'] = array_keys($files);
        $out['dbf_message'] = $out['dbf_ok']
            ? ('พบไฟล์ DBF ' . count($files) . ' ไฟล์ ที่ ' . $path)
            : 'โฟลเดอร์มีอยู่แต่ไม่พบไฟล์ .DBF';
        $out['dbf_path'] = $path;
    }
    return $out;
}

function amr_mlab_sync($con, $full = false, $window = null) {
    amr_mlab_ensure_tables($con);
    $cfg = amr_mlab_get_config($con);
    $cfg['dbf_path'] = amr_mlab_resolve_dbf_path(
        $cfg['dbf_path'] ?? '',
        amr_mlab_dbf_mode($cfg) !== 'local'
    );
    $started = date('Y-m-d H:i:s');
    $since = null;
    $until = null;
    $skip_pull = false;
    $touch_global = true;
    if (is_array($window) && !empty($window['start']) && !empty($window['end'])) {
        $since = substr((string)$window['start'], 0, 10);
        $until = substr((string)$window['end'], 0, 10);
        $skip_pull = !empty($window['skip_pull']);
        $touch_global = empty($window['clone']);
        $cfg['_no_lookback_floor'] = true;
        $cfg['_until'] = $until;
        $full = true;
    } elseif (!$full) {
        $st = amr_mlab_state_get($con, 'global');
        if ($st && !empty($st['last_date'])) {
            $since = date('Y-m-d', strtotime($st['last_date'] . ' -1 day'));
        }
    }
    $ins = 0;
    $upd = 0;
    $skip = 0;
    $msgs = [];
    if ($until) {
        $msgs[] = $since . ' → ' . $until;
    }
    if (amr_mlab_want_smb_pull($cfg) && !$skip_pull) {
        $pull = amr_mlab_smb_pull($cfg);
        if (!empty($pull['ok'])) {
            $cfg['dbf_path'] = $pull['local'];
            amr_mlab_cfg_put($con, 'amr_mlab_smb_share', $cfg['smb_share'] !== '' ? $cfg['smb_share'] : 'C');
            amr_mlab_cfg_put($con, 'amr_mlab_smb_remote', $cfg['smb_remote'] !== '' ? $cfg['smb_remote'] : 'MLAB/DATA');
            $msgs[] = 'SMB ' . (int)$pull['files'] . ' ไฟล์';
        } elseif (!is_dir(amr_mlab_resolve_dbf_path($cfg['dbf_path'] ?? '', true))) {
            $msgs[] = $pull['error'] !== '' ? $pull['error'] : 'ดึงไฟล์ DBF จากแชร์ SMB ไม่สำเร็จ';
        }
    } elseif ($skip_pull) {
        $cfg['dbf_path'] = amr_mlab_resolve_dbf_path($cfg['dbf_path'] ?? '', true);
    }
    if (amr_mlab_dbf_mode($cfg) !== 'local' && trim($cfg['host'] ?? '') !== '' && trim($cfg['db'] ?? '') !== '' && amr_mlab_tcp_open($cfg['host'], (int)($cfg['port'] ?? 3306), 2)) {
        $c = amr_mlab_sql_connect($cfg);
        if (!empty($c['ok'])) {
            $s = amr_mlab_sync_sql($con, $c['link'], $cfg, $since);
            mysqli_close($c['link']);
            $ins += (int)$s['insert'];
            $upd += (int)$s['update'];
            $skip += (int)$s['skip'];
            if ($s['error'] !== '') {
                $msgs[] = $s['error'];
            } elseif (!empty($s['tables'])) {
                $msgs[] = 'SQL ' . implode(', ', $s['tables']);
            }
        } else {
            $msgs[] = $c['error'];
        }
    }
    if (amr_mlab_dbf_mode($cfg) !== 'mysql' && trim($cfg['dbf_path'] ?? '') !== '') {
        $s = amr_mlab_sync_dbf($con, $cfg, $since, $until);
        $ins += (int)$s['insert'];
        $upd += (int)$s['update'];
        $skip += (int)$s['skip'];
        if ($s['error'] !== '') {
            $msgs[] = $s['error'];
        } else {
            $note = !empty($s['files_note']) ? $s['files_note'] : ('DBF ' . (int)$s['files'] . ' ไฟล์');
            $msgs[] = $note;
        }
    }
    if (trim($cfg['host'] ?? '') === '' && trim($cfg['dbf_path'] ?? '') === '') {
        $msgs[] = 'ยังไม่ได้ตั้งค่า Host mLAB หรือโฟลเดอร์ DBF';
    }
    $status = ($ins + $upd) > 0 || empty(array_filter($msgs, function ($m) {
        return stripos($m, 'ไม่') !== false || stripos($m, 'error') !== false || stripos($m, 'ไม่ได้') !== false;
    })) ? 'ok' : 'error';
    if (($ins + $upd + $skip) === 0 && $status === 'ok') {
        $status = 'ok';
        $msgs[] = 'ไม่มีรายการใหม่';
    }
    $msg = implode(' · ', array_filter($msgs));
    $today = date('Y-m-d');
    if ($touch_global) {
        amr_mlab_state_set($con, 'global', $today, time(), $ins + $upd, $status === 'ok' ? '' : $msg);
    }
    $st_esc = mysqli_real_escape_string($con, $started);
    $en_esc = mysqli_real_escape_string($con, date('Y-m-d H:i:s'));
    $stat_esc = mysqli_real_escape_string($con, $status);
    $msg_esc = mysqli_real_escape_string($con, substr($msg, 0, 255));
    mysqli_query($con, "INSERT INTO amr_mlab_sync_log (started_at, ended_at, status, inserted_n, updated_n, skipped_n, message)
        VALUES ('$st_esc','$en_esc','$stat_esc',$ins,$upd,$skip,'$msg_esc')");
    mysqli_query($con, "DELETE FROM amr_mlab_sync_log WHERE started_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
    return [
        'status' => $status,
        'inserted' => $ins,
        'updated' => $upd,
        'skipped' => $skip,
        'message' => $msg,
        'started_at' => $started,
        'ended_at' => date('Y-m-d H:i:s'),
    ];
}

function amr_mlab_last_sync($con) {
    amr_mlab_ensure_tables($con);
    $q = mysqli_query($con, "SELECT * FROM amr_mlab_sync_log ORDER BY id DESC LIMIT 1");
    $last = ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
    $cq = mysqli_query($con, "SELECT COUNT(*) AS n, MIN(order_date) AS mn, MAX(order_date) AS mx FROM amr_mlab_lab");
    $n = 0;
    $mn = null;
    $mx = null;
    if ($cq && ($r = mysqli_fetch_assoc($cq))) {
        $n = (int)$r['n'];
        $mn = $r['mn'] ?? null;
        $mx = $r['mx'] ?? null;
    }
    $aq = mysqli_query($con, "SELECT COUNT(*) AS n FROM amr_mlab_ast");
    $ast_n = 0;
    if ($aq && ($r = mysqli_fetch_assoc($aq))) {
        $ast_n = (int)$r['n'];
    }
    return [
        'last' => $last,
        'lab_count' => $n,
        'ast_count' => $ast_n,
        'min_date' => $mn,
        'max_date' => $mx,
    ];
}

function amr_mlab_dbf_year_counts($path) {
    $years = [];
    $months = [];
    $min = null;
    $max = null;
    $r = amr_mlab_dbf_each($path, function ($row) use (&$years, &$months, &$min, &$max) {
        $d = amr_mlab_parse_date($row['date'] ?? $row['spcdate'] ?? '');
        if (!$d) {
            return;
        }
        $y = (int)substr($d, 0, 4);
        if ($y < 1990 || $y > 2100) {
            return;
        }
        $years[$y] = ($years[$y] ?? 0) + 1;
        $ym = substr($d, 0, 7);
        $months[$ym] = ($months[$ym] ?? 0) + 1;
        if ($min === null || $d < $min) {
            $min = $d;
        }
        if ($max === null || $d > $max) {
            $max = $d;
        }
    });
    ksort($years);
    ksort($months);
    return [
        'ok' => !empty($r['ok']),
        'error' => $r['error'] ?? '',
        'nrec' => (int)($r['nrec'] ?? 0),
        'min' => $min,
        'max' => $max,
        'years' => $years,
        'months' => $months,
    ];
}

function amr_mlab_clone_month_done($have, $est) {
    $have = (int)$have;
    $est = (int)$est;
    if ($est <= 0) {
        return false;
    }
    if ($have >= $est) {
        return true;
    }
    $missing = $est - $have;
    return $missing <= 5 || ($have / $est) >= 0.98;
}

function amr_mlab_lab_count_range($con, $start, $end) {
    $a = mysqli_real_escape_string($con, substr((string)$start, 0, 10));
    $b = mysqli_real_escape_string($con, substr((string)$end, 0, 10));
    $q = mysqli_query($con, "SELECT COUNT(*) AS n FROM amr_mlab_lab WHERE order_date >= '$a' AND order_date <= '$b'");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return (int)$r['n'];
    }
    return 0;
}

function amr_mlab_imported_by_month($con) {
    $out = [];
    $q = mysqli_query($con, "SELECT DATE_FORMAT(order_date, '%Y-%m') AS ym, COUNT(*) AS n
        FROM amr_mlab_lab WHERE order_date IS NOT NULL
        GROUP BY DATE_FORMAT(order_date, '%Y-%m')");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $ym = (string)($r['ym'] ?? '');
            if ($ym !== '') {
                $out[$ym] = (int)$r['n'];
            }
        }
    }
    return $out;
}

function amr_mlab_clone_mark_done($con, $label, $end, $count) {
    $label = preg_replace('/[^0-9\-]/', '', (string)$label);
    if ($label === '') {
        return;
    }
    amr_mlab_state_set($con, 'clone:' . $label, $end, time(), (int)$count, '');
}

function amr_mlab_clone_chunk_is_done($con, $label, $start, $end, $est, $force = false) {
    if ($force) {
        return false;
    }
    $have = amr_mlab_lab_count_range($con, $start, $end);
    if (amr_mlab_clone_month_done($have, $est)) {
        return true;
    }
    $st = amr_mlab_state_get($con, 'clone:' . $label);
    return $st && $have > 0;
}

function amr_mlab_clone_chunks(array $years, array $months = [], array $imported = [], $con = null) {
    $chunks = [];
    if (!empty($months)) {
        foreach ($months as $ym => $n) {
            $n = (int)$n;
            if ($n < 1 || !preg_match('/^(\d{4})-(\d{2})$/', (string)$ym, $m)) {
                continue;
            }
            $label = $m[1] . '-' . $m[2];
            $start = $label . '-01';
            $end = date('Y-m-t', strtotime($start));
            $have = (int)($imported[$label] ?? 0);
            $marked = false;
            if ($con) {
                $st = amr_mlab_state_get($con, 'clone:' . $label);
                $marked = $st && $have > 0;
            }
            $chunks[] = [
                'label' => $label,
                'start' => $start,
                'end' => $end,
                'est' => $n,
                'have' => $have,
                'done' => amr_mlab_clone_month_done($have, $n) || $marked,
            ];
        }
        return $chunks;
    }
    foreach ($years as $y => $n) {
        $y = (int)$y;
        $n = (int)$n;
        if ($y < 1990) {
            continue;
        }
        $label = (string)$y;
        $start = sprintf('%04d-01-01', $y);
        $end = sprintf('%04d-12-31', $y);
        $have = 0;
        foreach ($imported as $ym => $c) {
            if (strpos((string)$ym, $label) === 0) {
                $have += (int)$c;
            }
        }
        $chunks[] = [
            'label' => $label,
            'start' => $start,
            'end' => $end,
            'est' => $n,
            'have' => $have,
            'done' => amr_mlab_clone_month_done($have, $n),
        ];
    }
    return $chunks;
}

function amr_mlab_clone_plan($con, $pull = true) {
    amr_mlab_ensure_tables($con);
    $cfg = amr_mlab_get_config($con);
    $msgs = [];
    if ($pull && amr_mlab_want_smb_pull($cfg)) {
        $p = amr_mlab_smb_pull($cfg);
        if (!empty($p['ok'])) {
            $cfg['dbf_path'] = $p['local'];
            $msgs[] = 'ดึง SMB ' . (int)$p['files'] . ' ไฟล์';
        } else {
            $cfg['dbf_path'] = $p['local'] ?? amr_mlab_resolve_dbf_path($cfg['dbf_path'] ?? '', true);
            $have = amr_mlab_dbf_list($cfg['dbf_path'] ?? '');
            if (!isset($have['SP'])) {
                return [
                    'ok' => false,
                    'error' => $p['error'] !== '' ? $p['error'] : 'ดึงไฟล์จากแชร์ SMB ไม่สำเร็จ',
                    'chunks' => [],
                ];
            }
            $msgs[] = 'ใช้สำเนา DBF ที่มีอยู่แล้ว ' . count($have) . ' ไฟล์ (รอบอัตโนมัติบนเซิร์ฟเวอร์เป็นตัวดึงจาก mLAB)';
        }
    }
    $cfg['dbf_path'] = amr_mlab_resolve_dbf_path($cfg['dbf_path'] ?? '', amr_mlab_dbf_mode($cfg) !== 'local');
    $files = amr_mlab_dbf_list($cfg['dbf_path'] ?? '');
    if (!isset($files['SP'])) {
        return [
            'ok' => false,
            'error' => 'ไม่พบ SP.DBF ใน ' . ($cfg['dbf_path'] ?: '(ยังไม่ระบุโฟลเดอร์)'),
            'chunks' => [],
        ];
    }
    $span = amr_mlab_dbf_year_counts($files['SP']);
    if (empty($span['ok'])) {
        return [
            'ok' => false,
            'error' => $span['error'] !== '' ? $span['error'] : 'อ่าน SP.DBF ไม่ได้',
            'chunks' => [],
        ];
    }
    $imported = amr_mlab_imported_by_month($con);
    $sync = amr_mlab_last_sync($con);
    $chunks = amr_mlab_clone_chunks($span['years'], $span['months'] ?? [], $imported, $con);
    $pending_n = 0;
    $skipped_n = 0;
    foreach ($chunks as $c) {
        if (!empty($c['done'])) {
            $skipped_n++;
        } else {
            $pending_n++;
        }
    }
    $msgs[] = $skipped_n > 0
        ? ('ข้าม ' . $skipped_n . ' เดือนที่มีข้อมูลครบแล้ว · เหลือ ' . $pending_n . ' เดือน')
        : ('จะดึง ' . $pending_n . ' เดือน');
    return [
        'ok' => true,
        'error' => '',
        'sp_nrec' => $span['nrec'],
        'min_date' => $span['min'],
        'max_date' => $span['max'],
        'years' => $span['years'],
        'imported' => $imported,
        'lab_count' => (int)($sync['lab_count'] ?? 0),
        'ast_count' => (int)($sync['ast_count'] ?? 0),
        'tham_min' => $sync['min_date'] ?? null,
        'tham_max' => $sync['max_date'] ?? null,
        'chunks' => $chunks,
        'pending_n' => $pending_n,
        'skipped_n' => $skipped_n,
        'dbf_path' => $cfg['dbf_path'],
        'message' => implode(' · ', $msgs),
    ];
}

function amr_mlab_text_col() {
    return 'IFNULL(l.result_text, \'\')';
}

/** จัดกลุ่มยาจากชื่อในตาราง AST ของ mLAB */
function amr_mlab_drug_class($drug) {
    $d = strtolower(preg_replace('/[^a-z0-9]+/i', '', (string)$drug));
    if ($d === '') {
        return '';
    }
    if (preg_match('/oxacillin|cefoxitin|methicillin|flucloxacillin|cloxacillin/', $d)) {
        return 'oxa';
    }
    if (preg_match('/vancomycin/', $d)) {
        return 'vanco';
    }
    if (preg_match('/teicoplanin/', $d)) {
        return 'teico';
    }
    if (preg_match('/ertapenem|imipenem|meropenem|doripenem|carbapenem/', $d)) {
        return 'carbapenem';
    }
    if (preg_match('/ceftriaxone|cefotaxime|ceftazidime|cefotaxim/', $d)) {
        return '3gc';
    }
    if (preg_match('/ciprofloxacin|levofloxacin|moxifloxacin|ofloxacin|norfloxacin/', $d)) {
        return 'fq';
    }
    if (preg_match('/amikacin|gentamicin|tobramycin|netilmicin|gentamycin/', $d)) {
        return 'ag';
    }
    if (preg_match('/piperacillin|tazobac/', $d)) {
        return 'pip';
    }
    return '';
}

function amr_mlab_org_group($organism) {
    $o = strtolower((string)$organism);
    if (preg_match('/staph.*aureus|\bs\.?\s*aureus\b/', $o)) {
        return 'saureus';
    }
    if (preg_match('/epidermidis|hominis|haemolyticus|saprophyticus|coagulase|coag\.?\s*neg|capitis|warneri|sciuri|kloosii|xylosus|caprae|cohnii|auricularis|arlettae|lugdunensis|staphylococcus\s+species/', $o)) {
        return 'cons';
    }
    if (preg_match('/enterococcus/', $o)) {
        return 'entero';
    }
    if (preg_match('/acinetobacter\s+baumannii|baumannii/', $o)) {
        return 'abaum';
    }
    if (preg_match('/acinetobacter/', $o)) {
        return 'acineto';
    }
    if (preg_match('/pseudomonas\s+aeruginosa/', $o)) {
        return 'paer';
    }
    if (preg_match('/escherichia\s+coli|\be\.?\s*coli\b|klebsiella|enterobacter|proteus|citrobacter|serratia|morganella|providencia|salmonella|kleb\./', $o)) {
        return 'entbact';
    }
    return '';
}

function amr_mlab_ast_resistant_classes(array $ast) {
    $r = [];
    foreach ($ast as $a) {
        $sir = strtoupper(substr(trim((string)($a['sir'] ?? '')), 0, 1));
        if ($sir !== 'R') {
            continue;
        }
        $cls = amr_mlab_drug_class($a['drug'] ?? '');
        if ($cls !== '') {
            $r[$cls] = true;
        }
    }
    return $r;
}

/**
 * แปลง AST (S/I/R) + ชื่อเชื้อ → phenotype แบบ HOSxP เช่น MRSA, ESBL, CRE_MDR, CRAB
 */
function amr_mlab_derive_phenotype($organism, array $ast) {
    $g = amr_mlab_org_group($organism);
    if ($g === '' || empty($ast)) {
        return '';
    }
    $r = amr_mlab_ast_resistant_classes($ast);
    $has = function ($k) use ($r) {
        return !empty($r[$k]);
    };
    if ($g === 'saureus') {
        if ($has('oxa') && $has('vanco')) {
            return 'MRSA_VRSA';
        }
        if ($has('oxa')) {
            return 'MRSA';
        }
        return '';
    }
    if ($g === 'cons') {
        return $has('oxa') ? 'MRSE' : '';
    }
    if ($g === 'entero') {
        return ($has('vanco') || $has('teico')) ? 'VRE' : '';
    }
    if ($g === 'abaum') {
        if (!$has('carbapenem')) {
            return '';
        }
        return ($has('fq') || $has('ag') || $has('pip')) ? 'CRAB_MDR' : 'CRAB';
    }
    if ($g === 'acineto') {
        if ($has('carbapenem') || (($has('fq') ? 1 : 0) + ($has('ag') ? 1 : 0) + ($has('3gc') ? 1 : 0) + ($has('pip') ? 1 : 0)) >= 2) {
            return 'MDR';
        }
        return '';
    }
    if ($g === 'paer') {
        if ($has('carbapenem')) {
            return ($has('fq') || $has('ag') || $has('pip') || $has('3gc')) ? 'CRPA_MDR' : 'CRPA';
        }
        $n = ($has('3gc') ? 1 : 0) + ($has('fq') ? 1 : 0) + ($has('ag') ? 1 : 0) + ($has('pip') ? 1 : 0);
        return $n >= 3 ? 'MDR' : '';
    }
    if ($g === 'entbact') {
        if ($has('carbapenem')) {
            return 'CRE_MDR';
        }
        if ($has('3gc')) {
            return 'ESBL';
        }
        return '';
    }
    return '';
}

function amr_mlab_org_label($organism, $tagged) {
    $else = 'อื่นๆ';
    if (function_exists('amr_dict_match_text')) {
        $from = amr_dict_match_text('organism', $tagged, '');
        if ($from !== '' && $from !== $else) {
            return $from;
        }
    }
    $o = strtolower((string)$organism);
    $map = [
        '/staphylococcus\s+aureus/' => 'S.aureus',
        '/escherichia\s+coli|\be\.?\s*coli\b/' => 'E.coli',
        '/klebsiella\s+pneumoniae/' => 'K.pneumoniae',
        '/acinetobacter\s+baumannii/' => 'A.baumannii',
        '/pseudomonas\s+aeruginosa/' => 'P.aeruginosa',
        '/enterococcus\s+faecium/' => 'Enterococcus faecium',
        '/enterococcus\s+faecalis/' => 'Enterococcus faecalis',
        '/enterobacter\s+cloacae/' => 'Enterobacter cloacae',
        '/proteus\s+mirabilis/' => 'Proteus mirabilis',
        '/staphylococcus\s+epidermidis/' => 'Staphylococcus epidermidis',
        '/staphylococcus\s+hominis/' => 'Staphylococcus hominis',
        '/staphylococcus\s+haemolyticus/' => 'Staphylococcus haemolyticus',
        '/citrobacter\s+freundii/' => 'Citrobacter freundii',
    ];
    foreach ($map as $re => $label) {
        if (preg_match($re, $o)) {
            return $label;
        }
    }
    $org = trim((string)$organism);
    return $org !== '' ? $org : $else;
}

function amr_mlab_in_filter($value, array $allowed) {
    if (empty($allowed)) {
        return true;
    }
    return in_array((string)$value, $allowed, true);
}

function amr_mlab_sql_date_range($con, $start, $end, $alias = '') {
    $p = $alias !== '' ? ($alias . '.') : '';
    $s = mysqli_real_escape_string($con, $start);
    $e = mysqli_real_escape_string($con, $end);
    return "({$p}order_date BETWEEN '$s' AND '$e' OR ({$p}order_date IS NULL AND {$p}report_date BETWEEN '$s' AND '$e'))";
}

function amr_mlab_load_labs($con, $start, $end, $opts = []) {
    $light = is_array($opts) && !empty($opts['light']);
    $date_sql = amr_mlab_sql_date_range($con, $start, $end, '');
    $labs = [];
    $cols = "lab_key, hn, an, vn, ptname, ward, specimen, organism,
                   order_date, order_time, report_date, report_time";
    if (!$light) {
        $cols .= ", result_text";
    }
    $sql = "SELECT $cols
            FROM amr_mlab_lab
            WHERE $date_sql";
    $q = mysqli_query($con, $sql);
    if (!$q) {
        return ['error' => mysqli_error($con), 'labs' => []];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $k = (string)($r['lab_key'] ?? '');
        if ($k === '') {
            continue;
        }
        if ($light) {
            $r['result_text'] = '';
        }
        $r['ast'] = [];
        $labs[$k] = $r;
    }
    if (empty($labs)) {
        return ['error' => '', 'labs' => []];
    }
    $ast_cols = $light
        ? 'a.lab_key, a.organism, a.drug, a.sir'
        : 'a.lab_key, a.organism, a.drug, a.sir, a.mic, a.zone';
    $join_date = amr_mlab_sql_date_range($con, $start, $end, 'l');
    $aq = mysqli_query($con, "SELECT $ast_cols
        FROM amr_mlab_ast a
        INNER JOIN amr_mlab_lab l ON l.lab_key = a.lab_key
        WHERE $join_date");
    if ($aq) {
        while ($a = mysqli_fetch_assoc($aq)) {
            $k = (string)($a['lab_key'] ?? '');
            if (!isset($labs[$k]) || trim((string)($a['drug'] ?? '')) === '') {
                continue;
            }
            $labs[$k]['ast'][] = $a;
        }
    }
    return ['error' => '', 'labs' => $labs];
}

function amr_mlab_hn_keys($hn) {
    $hn = preg_replace('/\s+/', '', (string)$hn);
    if ($hn === '') {
        return [];
    }
    $trim = ltrim($hn, '0');
    if ($trim === '') {
        return [$hn];
    }
    $out = [$hn => $hn, $trim => $trim];
    for ($len = strlen($trim); $len <= 9; $len++) {
        $p = str_pad($trim, $len, '0', STR_PAD_LEFT);
        $out[$p] = $p;
    }
    return array_values($out);
}

function amr_mlab_hn_norm($hn) {
    $t = ltrim(preg_replace('/\s+/', '', (string)$hn), '0');
    return $t === '' ? '' : $t;
}

function amr_mlab_sql_ptname($alias = 'p') {
    $expr = "CONCAT(IFNULL($alias.pname,''), IFNULL($alias.fname,''), ' ', IFNULL($alias.lname,''))";
    return function_exists('amr_sql_utf8') ? amr_sql_utf8($expr) : "CAST(CONVERT($expr USING utf8) AS CHAR)";
}

function amr_mlab_in_sql($hos, array $values) {
    $out = [];
    foreach ($values as $v) {
        $v = trim((string)$v);
        if ($v === '') {
            continue;
        }
        $out[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return $out;
}

/** ชื่อ-สกุล / HN มาตรฐานจากตาราง patient ของ HOSxP */
function amr_mlab_fetch_hosxp_patients($hos, array $hns) {
    if (!$hos || empty($hns)) {
        return [];
    }
    $variants = [];
    foreach ($hns as $hn) {
        foreach (amr_mlab_hn_keys($hn) as $v) {
            $variants[$v] = true;
        }
    }
    $keys = array_keys($variants);
    $map = [];
    $name_sql = amr_mlab_sql_ptname('p');
    for ($i = 0; $i < count($keys); $i += 80) {
        $in = amr_mlab_in_sql($hos, array_slice($keys, $i, 80));
        if (!$in) {
            continue;
        }
        $sql = "SELECT p.hn, $name_sql AS ptname
                FROM patient p
                WHERE p.hn IN (" . implode(',', $in) . ")";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $norm = amr_mlab_hn_norm($r['hn'] ?? '');
            if ($norm === '') {
                continue;
            }
            $map[$norm] = [
                'hn' => trim((string)($r['hn'] ?? '')),
                'ptname' => trim((string)($r['ptname'] ?? '')),
            ];
        }
    }
    return $map;
}

function amr_mlab_apply_hosxp_patient(array $row, array $patients) {
    $norm = amr_mlab_hn_norm($row['hn'] ?? '');
    if ($norm === '' || empty($patients[$norm])) {
        return $row;
    }
    $p = $patients[$norm];
    if (!empty($p['hn'])) {
        $row['hn'] = $p['hn'];
    }
    if (!empty($p['ptname'])) {
        $row['ptname'] = $p['ptname'];
    }
    return $row;
}

function amr_mlab_fetch_ipt_by_an($hos, array $ans) {
    if (!$hos || empty($ans)) {
        return [];
    }
    $ids = [];
    foreach ($ans as $an) {
        $an = trim((string)$an);
        if ($an !== '') {
            $ids[$an] = "'" . mysqli_real_escape_string($hos, $an) . "'";
        }
    }
    if (empty($ids)) {
        return [];
    }
    $ward_expr = function_exists('amr_sql_utf8')
        ? amr_sql_utf8("IFNULL(w.name,'')")
        : "CAST(CONVERT(IFNULL(w.name,'') USING utf8) AS CHAR)";
    $name_sql = amr_mlab_sql_ptname('p');
    $dc_sql = function_exists('amr_sql_utf8')
        ? amr_sql_utf8("IFNULL(ds.name,'')")
        : "CAST(CONVERT(IFNULL(ds.name,'') USING utf8) AS CHAR)";
    $map = [];
    foreach (array_chunk(array_values($ids), 80) as $part) {
        $sql = "SELECT i.hn, i.an, i.regdate, i.dchdate, $ward_expr AS ward_name,
                       $name_sql AS ptname, $dc_sql AS DCstatus, IFNULL(ia.bedno,'') AS bedno
                FROM ipt i
                LEFT JOIN ward w ON w.ward = i.ward
                LEFT JOIN patient p ON p.hn = i.hn
                LEFT JOIN dchstts ds ON ds.dchstts = i.dchstts
                LEFT JOIN iptadm ia ON ia.an = i.an
                WHERE i.an IN (" . implode(',', $part) . ")";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $an = trim((string)($r['an'] ?? ''));
            if ($an !== '') {
                $map[$an] = $r;
            }
        }
    }
    return $map;
}

function amr_mlab_apply_ipt_an(array $row, array $byAn) {
    $an = trim((string)($row['an'] ?? ''));
    if ($an === '' || empty($byAn[$an])) {
        return $row;
    }
    $s = $byAn[$an];
    $hn = trim((string)($s['hn'] ?? ''));
    if ($hn !== '') {
        $row['hn'] = $hn;
    }
    $pt = trim((string)($s['ptname'] ?? ''));
    if ($pt !== '') {
        $row['ptname'] = $pt;
    }
    $wname = trim((string)($s['ward_name'] ?? ''));
    if ($wname !== '') {
        $row['ward'] = $wname;
        $row['wardsnapshot'] = $wname;
        $row['ward_now'] = $wname;
    }
    $dc = trim((string)($s['DCstatus'] ?? ''));
    if ($dc !== '') {
        $row['DCstatus'] = $dc;
    }
    $bed = trim((string)($s['bedno'] ?? ''));
    if ($bed !== '') {
        $row['bedno'] = $bed;
    }
    $od = substr((string)($row['order_date'] ?? ''), 0, 10);
    $reg = substr((string)($s['regdate'] ?? ''), 0, 10);
    if ($od !== '' && $reg !== '') {
        $days = (int)floor((strtotime($od) - strtotime($s['regdate'])) / 86400);
        $row['Typeinfect'] = $days > 2 ? 'NI' : 'CI';
        $row['regdate'] = $reg;
    }
    $row['_ipd'] = true;
    return $row;
}

function amr_mlab_hosxp_overlay($hos, array $lab_keys, $opts = []) {
    if (!$hos || empty($lab_keys)) {
        return [];
    }
    $light = is_array($opts) && !empty($opts['light']);
    if (!$light && !function_exists('amr_sql_result_case')) {
        return [];
    }
    $ids = [];
    foreach ($lab_keys as $k) {
        $k = trim((string)$k);
        if (preg_match('/^\d{4,14}$/', $k)) {
            $ids[$k] = "'" . mysqli_real_escape_string($hos, $k) . "'";
        }
    }
    if (empty($ids)) {
        return [];
    }
    $rtf_sql = '';
    if (!$light) {
        $microtype_sql = amr_sql_microtype_case('lh.result_rtf', $hos);
        $result_sql = amr_sql_result_case('lh.result_rtf', $hos);
        $specimen_sql = amr_sql_specimen_case('lh.result_rtf', $hos);
        $rtf_sql = "
                MAX($microtype_sql) AS microtype,
                MAX($result_sql) AS result,
                MAX($specimen_sql) AS Specimen,";
    }
    $map = [];
    $chunk = array_chunk(array_values($ids), 120);
    foreach ($chunk as $part) {
        $sql = "SELECT
                lh.lab_order_number,
                MAX(IF(i.an IS NULL OR TRIM(i.an) = '', 'CI', IF((lh.order_date - i.regdate) > 2, 'NI', 'CI'))) AS Typeinfect,
                MAX(IFNULL(i.an, '')) AS an,
                MAX(i.regdate) AS regdate,
                MAX(" . amr_sql_utf8("IFNULL(w.name,'')") . ") AS ward,
                MAX(" . amr_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))") . ") AS ptname,
                MAX(" . amr_sql_utf8("IFNULL(ds.name,'')") . ") AS DCstatus,
                $rtf_sql
                MAX(CONCAT(IFNULL(lh.order_date,''), ' ', IFNULL(lh.order_time,''))) AS ordertime,
                MAX(CONCAT(IFNULL(lh.report_date,''), ' ', IFNULL(lh.report_time,''))) AS reportdatetime,
                MAX(IFNULL(lh.order_time,'')) AS order_time,
                MAX(IFNULL(lh.report_date,'')) AS report_date,
                MAX(IFNULL(lh.report_time,'')) AS report_time
            FROM lab_head lh
            LEFT JOIN ipt i ON i.an = lh.vn
            LEFT JOIN patient pt ON pt.hn = COALESCE(NULLIF(i.hn, ''), lh.hn)
            LEFT JOIN ward w ON w.ward = i.ward
            LEFT JOIN dchstts ds ON ds.dchstts = i.dchstts
            WHERE lh.lab_order_number IN (" . implode(',', $part) . ")
            GROUP BY lh.lab_order_number";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $id = trim((string)($r['lab_order_number'] ?? ''));
            if ($id !== '') {
                $map[$id] = $r;
            }
        }
    }
    return $map;
}

function amr_mlab_fetch_ipt_stays($hos, array $hns, $start, $end) {
    if (!$hos || empty($hns)) {
        return [];
    }
    $variants = [];
    foreach ($hns as $hn) {
        foreach (amr_mlab_hn_keys($hn) as $v) {
            $variants[$v] = true;
        }
    }
    $keys = array_keys($variants);
    $stays = [];
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $chunk_size = 80;
    for ($i = 0; $i < count($keys); $i += $chunk_size) {
        $part = array_slice($keys, $i, $chunk_size);
        $in = [];
        foreach ($part as $hn) {
            $in[] = "'" . mysqli_real_escape_string($hos, $hn) . "'";
        }
        $ward_expr = function_exists('amr_sql_utf8')
            ? amr_sql_utf8("IFNULL(w.name,'')")
            : "CAST(CONVERT(IFNULL(w.name,'') USING utf8) AS CHAR)";
        $name_sql = amr_mlab_sql_ptname('p');
        $dc_sql = function_exists('amr_sql_utf8')
            ? amr_sql_utf8("IFNULL(ds.name,'')")
            : "CAST(CONVERT(IFNULL(ds.name,'') USING utf8) AS CHAR)";
        $sql = "SELECT i.hn, i.an, i.regdate, i.dchdate, $ward_expr AS ward_name,
                       $name_sql AS ptname, $dc_sql AS DCstatus, IFNULL(ia.bedno,'') AS bedno
                FROM ipt i
                LEFT JOIN ward w ON w.ward = i.ward
                LEFT JOIN patient p ON p.hn = i.hn
                LEFT JOIN dchstts ds ON ds.dchstts = i.dchstts
                LEFT JOIN iptadm ia ON ia.an = i.an
                WHERE i.hn IN (" . implode(',', $in) . ")
                  AND i.regdate <= '$end_esc'
                  AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00' OR i.dchdate >= '$start_esc')";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $norm = amr_mlab_hn_norm($r['hn'] ?? '');
            if ($norm === '') {
                continue;
            }
            $stays[$norm][] = $r;
        }
    }
    return $stays;
}

function amr_mlab_apply_ipt_stay(array $row, array $stays) {
    $norm = amr_mlab_hn_norm($row['hn'] ?? '');
    $od = substr((string)($row['order_date'] ?? ''), 0, 10);
    $cands = ($norm !== '' && isset($stays[$norm])) ? $stays[$norm] : [];
    $best = null;
    $bestReg = '';
    foreach ($cands as $s) {
        $reg = substr((string)($s['regdate'] ?? ''), 0, 10);
        $dch = substr((string)($s['dchdate'] ?? ''), 0, 10);
        if ($reg === '' || $od === '' || $od < $reg) {
            continue;
        }
        if ($dch !== '' && $dch !== '0000-00-00' && $od > $dch) {
            continue;
        }
        if ($best === null || $reg >= $bestReg) {
            $best = $s;
            $bestReg = $reg;
        }
    }
    if (!$best) {
        $row['_ipd'] = false;
        return $row;
    }
    $days = (int)floor((strtotime($od) - strtotime($best['regdate'])) / 86400);
    $row['an'] = trim((string)($best['an'] ?? $row['an']));
    $row['Typeinfect'] = $days > 2 ? 'NI' : 'CI';
    $row['regdate'] = substr((string)$best['regdate'], 0, 10);
    $wname = trim((string)($best['ward_name'] ?? ''));
    if ($wname !== '') {
        $row['ward'] = $wname;
        $row['wardsnapshot'] = $wname;
        $row['ward_now'] = $wname;
    }
    $pt = trim((string)($best['ptname'] ?? ''));
    if ($pt !== '') {
        $row['ptname'] = $pt;
    }
    $dc = trim((string)($best['DCstatus'] ?? ''));
    if ($dc !== '') {
        $row['DCstatus'] = $dc;
    }
    $bed = trim((string)($best['bedno'] ?? ''));
    if ($bed !== '') {
        $row['bedno'] = $bed;
    }
    $hn = trim((string)($best['hn'] ?? ''));
    if ($hn !== '') {
        $row['hn'] = $hn;
    }
    $row['_ipd'] = true;
    return $row;
}

function amr_mlab_pack_case(array $lab, $require_pheno = true) {
    $org = trim((string)($lab['organism'] ?? ''));
    $ast = $lab['ast'] ?? [];
    if ($org === '') {
        foreach ($ast as $a) {
            $o = trim((string)($a['organism'] ?? ''));
            if ($o !== '') {
                $org = $o;
                break;
            }
        }
    }
    $pheno = amr_mlab_derive_phenotype($org, $ast);
    if ($require_pheno && $pheno === '') {
        return null;
    }
    $specimen = trim((string)($lab['specimen'] ?? ''));
    $tagged = $org !== '' && $pheno !== '' ? ($org . '..(' . $pheno . ')') : $org;
    $blob = trim($specimen . "\n" . $tagged . "\n" . (string)($lab['result_text'] ?? ''));
    $ward = trim((string)($lab['ward'] ?? ''));
    if ($ward === '') {
        $ward = '(ไม่ระบุหอผู้ป่วย)';
    }
    $result = $pheno;
    if ($pheno !== '' && function_exists('amr_dict_match_text')) {
        $from = amr_dict_match_text('result', '(' . $pheno . ')', '');
        if ($from !== '') {
            $result = $from;
        }
    }
    $spec_label = $specimen;
    if (function_exists('amr_dict_match_text')) {
        $s = amr_dict_match_text('specimen', $specimen !== '' ? $specimen : $blob, '');
        if ($s !== '') {
            $spec_label = $s;
        }
    }
    $od = substr((string)($lab['order_date'] ?? ''), 0, 10);
    return [
        'ward' => $ward,
        'wardsnapshot' => $ward,
        'ward_now' => $ward,
        'Typeinfect' => 'CI',
        'regdate' => $od,
        'ordertime' => trim($od . ' ' . (string)($lab['order_time'] ?? '')),
        'reportdatetime' => trim((string)($lab['report_date'] ?? '') . ' ' . (string)($lab['report_time'] ?? '')),
        'hn' => trim((string)($lab['hn'] ?? '')),
        'an' => trim((string)(($lab['an'] ?? '') !== '' ? $lab['an'] : ($lab['vn'] ?? ''))),
        'ptname' => (string)($lab['ptname'] ?? ''),
        'bedno' => '',
        'lab_order_number' => (string)($lab['lab_key'] ?? ''),
        'order_date' => $od,
        'order_time' => trim((string)($lab['order_time'] ?? '')),
        'report_date' => substr((string)($lab['report_date'] ?? ''), 0, 10),
        'report_time' => trim((string)($lab['report_time'] ?? '')),
        'microtype' => ($org === '') ? 'No growth' : amr_mlab_org_label($org, $blob),
        'result' => $result,
        'Specimen' => $spec_label,
        'DCstatus' => '',
        '_ipd' => null,
        '_opd_ward' => in_array(strtoupper($ward), ['OPD', 'ER'], true),
    ];
}

function amr_mlab_fetch_cases($con, $start, $end, array $filters, $hos = null) {
    amr_mlab_ensure_tables($con);
    if (function_exists('amr_dict_prime')) {
        amr_dict_prime($con);
    }
    $scope = function_exists('amr_dashboard_culture_scope')
        ? amr_dashboard_culture_scope($filters['culture_scope'] ?? 'resistant')
        : 'resistant';
    $loaded = amr_mlab_load_labs($con, $start, $end, ['light' => true]);
    if ($loaded['error'] !== '') {
        return ['error' => $loaded['error'], 'rows' => []];
    }
    $lab_keys = [];
    $hns = [];
    foreach ($loaded['labs'] as $lab) {
        $lab_keys[] = $lab['lab_key'] ?? '';
        if (trim((string)($lab['hn'] ?? '')) !== '') {
            $hns[$lab['hn']] = true;
        }
    }
    $overlay = $hos ? amr_mlab_hosxp_overlay($hos, $lab_keys, ['light' => true]) : [];
    $ans = [];
    foreach ($overlay as $ovRow) {
        if (!empty($ovRow['an'])) {
            $ans[] = $ovRow['an'];
        }
    }
    $byAn = $hos ? amr_mlab_fetch_ipt_by_an($hos, $ans) : [];
    $stays = $hos ? amr_mlab_fetch_ipt_stays($hos, array_keys($hns), $start, $end) : [];
    $patients = $hos ? amr_mlab_fetch_hosxp_patients($hos, array_keys($hns)) : [];
    $out = [];
    foreach ($loaded['labs'] as $lab) {
        $row = amr_mlab_pack_case($lab, false);
        if (!$row) {
            continue;
        }
        $ov = $overlay[$row['lab_order_number']] ?? null;
        if (is_array($ov)) {
            if (trim((string)($ov['an'] ?? '')) !== '') {
                $row['an'] = trim((string)$ov['an']);
                $row['_ipd'] = true;
            }
            if (trim((string)($ov['Typeinfect'] ?? '')) !== '') {
                $row['Typeinfect'] = trim((string)$ov['Typeinfect']);
            }
            if (trim((string)($ov['regdate'] ?? '')) !== '') {
                $row['regdate'] = substr((string)$ov['regdate'], 0, 10);
            }
            $wname = trim((string)($ov['ward'] ?? ''));
            if ($wname !== '') {
                $row['ward'] = $wname;
                $row['wardsnapshot'] = $wname;
                $row['ward_now'] = $wname;
            }
            $dc = trim((string)($ov['DCstatus'] ?? ''));
            if ($dc !== '') {
                $row['DCstatus'] = $dc;
            }
            $ov_result = trim((string)($ov['result'] ?? ''));
            if ($ov_result !== '') {
                $row['result'] = $ov_result;
            }
            $ov_micro = trim((string)($ov['microtype'] ?? ''));
            if ($ov_micro !== '' && ($row['microtype'] === '' || $row['microtype'] === 'อื่นๆ')) {
                $row['microtype'] = $ov_micro;
            }
            $ov_spec = trim((string)($ov['Specimen'] ?? ''));
            if ($ov_spec !== '' && trim((string)($lab['specimen'] ?? '')) === '') {
                $row['Specimen'] = $ov_spec;
            }
            $ov_ot = trim((string)($ov['ordertime'] ?? ''));
            if ($ov_ot !== '') {
                $row['ordertime'] = $ov_ot;
            }
            $ov_rt = trim((string)($ov['reportdatetime'] ?? ''));
            if ($ov_rt !== '') {
                $row['reportdatetime'] = $ov_rt;
            }
            if (trim((string)($ov['report_date'] ?? '')) !== '') {
                $row['report_date'] = substr((string)$ov['report_date'], 0, 10);
            }
            if (trim((string)($ov['order_time'] ?? '')) !== '') {
                $row['order_time'] = trim((string)$ov['order_time']);
            }
            if (trim((string)($ov['report_time'] ?? '')) !== '') {
                $row['report_time'] = trim((string)$ov['report_time']);
            }
        }
        $row = amr_mlab_apply_hosxp_patient($row, $patients);
        if (!empty($row['an']) && !empty($byAn)) {
            $row = amr_mlab_apply_ipt_an($row, $byAn);
            $row = amr_mlab_apply_hosxp_patient($row, $patients);
        }
        if (empty($row['_ipd']) && !empty($stays)) {
            $row = amr_mlab_apply_ipt_stay($row, $stays);
            $row = amr_mlab_apply_hosxp_patient($row, $patients);
        }
        if ($scope === 'resistant' && trim((string)($row['result'] ?? '')) === '') {
            continue;
        }
        if ($scope === 'all' && preg_match('/no\s*growth/i', (string)($row['microtype'] ?? ''))) {
            continue;
        }
        if (!amr_mlab_in_filter($row['microtype'], $filters['microtypes'] ?? [])) {
            continue;
        }
        if (!amr_mlab_in_filter($row['Specimen'], $filters['specimens'] ?? [])) {
            continue;
        }
        if (!amr_mlab_in_filter($row['result'], $filters['results'] ?? [])) {
            continue;
        }
        if (!amr_mlab_in_filter($row['Typeinfect'], $filters['typeinfect'] ?? [])) {
            continue;
        }
        if (!amr_mlab_in_filter($row['ward'], $filters['wards'] ?? [])) {
            continue;
        }
        unset($row['_ipd'], $row['_opd_ward']);
        $out[] = $row;
    }
    usort($out, function ($a, $b) {
        return strcmp((string)($b['order_date'] ?? ''), (string)($a['order_date'] ?? ''));
    });
    return ['error' => '', 'rows' => $out];
}

function amr_mlab_fetch_list($con, $q, $start, $end, $scope = 'resistant', $hos = null) {
    amr_mlab_ensure_tables($con);
    if (function_exists('amr_dict_prime')) {
        amr_dict_prime($con);
    }
    $scope = function_exists('amr_sens_list_scope') ? amr_sens_list_scope($scope) : $scope;
    $loaded = amr_mlab_load_labs($con, $start, $end);
    if ($loaded['error'] !== '') {
        return ['error' => $loaded['error'], 'rows' => []];
    }
    $hns = [];
    $lab_keys = [];
    foreach ($loaded['labs'] as $lab) {
        $lab_keys[] = $lab['lab_key'] ?? '';
        if (trim((string)($lab['hn'] ?? '')) !== '') {
            $hns[$lab['hn']] = true;
        }
    }
    $overlay = $hos ? amr_mlab_hosxp_overlay($hos, $lab_keys) : [];
    $ans = [];
    foreach ($overlay as $ovRow) {
        if (!empty($ovRow['an'])) {
            $ans[] = $ovRow['an'];
        }
    }
    $patients = $hos ? amr_mlab_fetch_hosxp_patients($hos, array_keys($hns)) : [];
    $stays = $hos ? amr_mlab_fetch_ipt_stays($hos, array_keys($hns), $start, $end) : [];
    $byAn = $hos ? amr_mlab_fetch_ipt_by_an($hos, $ans) : [];
    $q_raw = trim((string)$q);
    $q_num = preg_replace('/\D+/', '', $q_raw);
    $out = [];
    foreach ($loaded['labs'] as $lab) {
        $need_pheno = ($scope === 'resistant');
        $row = amr_mlab_pack_case($lab, $need_pheno);
        if (!$row) {
            continue;
        }
        $row = amr_mlab_enrich_row_hosxp($row, $lab, $hos, $overlay, $patients, $stays, $byAn);
        $micro = strtolower((string)$row['microtype']);
        if (($scope === 'growth' || $scope === 'resistant') && strpos($micro, 'no growth') !== false) {
            continue;
        }
        if ($q_num !== '') {
            $hn = preg_replace('/\D+/', '', (string)$row['hn']);
            $key = (string)$row['lab_order_number'];
            if ($key !== $q_num && $hn !== $q_num && ltrim($hn, '0') !== ltrim($q_num, '0')) {
                continue;
            }
        } elseif ($q_raw !== '' && stripos((string)$row['ptname'], $q_raw) === false) {
            continue;
        }
        $out[] = [
            'lab_order_number' => $row['lab_order_number'],
            'ordertime' => $row['ordertime'],
            'reportdatetime' => $row['reportdatetime'],
            'hn' => $row['hn'],
            'an' => $row['an'],
            'ptname' => $row['ptname'],
            'Wname' => $row['ward'],
            'microtype' => $row['microtype'],
            'result' => $row['result'],
            'Specimen' => $row['Specimen'],
        ];
    }
    usort($out, function ($a, $b) {
        return strcmp((string)($b['reportdatetime'] ?? ''), (string)($a['reportdatetime'] ?? ''));
    });
    return ['error' => '', 'rows' => array_slice($out, 0, 80)];
}

function amr_mlab_format_dmy($date, $time = '') {
    $d = substr(trim((string)$date), 0, 10);
    if ($d === '' || $d === '0000-00-00') {
        return '';
    }
    $ts = strtotime($d);
    $out = $ts ? date('d/m/Y', $ts) : $d;
    $digits = preg_replace('/\D+/', '', (string)$time);
    if (strlen($digits) >= 4) {
        $out .= ' ' . substr($digits, 0, 2) . ':' . substr($digits, 2, 2);
    }
    return $out;
}

function amr_mlab_drug_key($drug) {
    return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)$drug));
}

function amr_mlab_is_lis_print($text) {
    $t = (string)$text;
    if (strlen($t) < 80) {
        return false;
    }
    return stripos($t, 'Aerobic Culture') !== false
        || stripos($t, 'MIC------SIR') !== false
        || stripos($t, 'mLAB Version') !== false
        || (stripos($t, 'RELEASED') !== false && substr_count($t, "\n") >= 10);
}

function amr_mlab_lis_panel_rows() {
    return [
        ['AMIKACIN', 'CLINDAMYCIN', 'PENICILLIN'],
        ['AMPICILLIN', 'ERYTHROMYCIN', 'AMPICILL/SULB'],
        ['AMOXICIL/CLAV', 'FOSFOMYCIN', 'OXACILLIN'],
        ['CEFOPERA/SULB', 'FUSIDIC ACID', 'PIPERACI/TAZO'],
        ['CEFOTAXIME', 'VANCOMYCIN', 'CEFUROXIME'],
        ['CEFTAZIDIME', 'COLISTIN', 'CEFTRIAXONE'],
        ['CEFTAZID/AVIB', 'GENTAMICIN', 'CEFEPIME'],
        ['CIPROFLOXACIN', 'NETILMICIN', 'TEICOPLANIN'],
        ['NITROFURANTOI', 'PEFLOXACIN', 'LINEZOLID'],
        ['TRIMETHO/SULF', 'OFLOXACIN', 'TIGECYCLINE'],
        ['ERTAPENEM', 'LEVOFLOXACIN', 'SITAFLOXACIN'],
        ['IMIPENEM', 'MEROPENEM', 'DOXYCYCLINE'],
        ['DORIPENEM', 'TETRACYCLINE', ''],
        ['CEFOXITIN', 'CHLORAMPHENIC', ''],
    ];
}

function amr_mlab_lis_short_name($drug) {
    $k = amr_mlab_drug_key($drug);
    $map = [
        'CEFOPERAZONESULBACTAM' => 'CEFOPERA/SULB',
        'CEFOPERAZONESULBAC' => 'CEFOPERA/SULB',
        'PIPERACILLINTAZOBACTAM' => 'PIPERACI/TAZO',
        'PIPERACILLINTAZOBAC' => 'PIPERACI/TAZO',
        'AMOXICILLINCLAVULANATE' => 'AMOXICIL/CLAV',
        'AMPICILLINSULBACTAM' => 'AMPICILL/SULB',
        'TRIMETHOPRIMSULFA' => 'TRIMETHO/SULF',
        'CEFTAZIDIMEAVIBACTAM' => 'CEFTAZID/AVIB',
        'NITROFURANTOIN' => 'NITROFURANTOI',
        'CHLORAMPHENICOL' => 'CHLORAMPHENIC',
    ];
    if (isset($map[$k])) {
        return $map[$k];
    }
    $u = strtoupper(trim((string)$drug));
    return strlen($u) > 13 ? substr($u, 0, 13) : $u;
}

function amr_mlab_lis_cell($name, $mic, $sir) {
    $name = strtoupper(trim((string)$name));
    if ($name === '') {
        return str_repeat(' ', 28);
    }
    if (strlen($name) > 13) {
        $name = substr($name, 0, 13);
    }
    $left = str_pad($name, 13, '.');
    $sir = strtoupper(trim((string)$sir));
    $mic = trim((string)$mic);
    if ($sir === '' || $sir === '-') {
        return $left . str_pad('-', 13, ' ', STR_PAD_LEFT) . '  ';
    }
    return $left . ' ' . str_pad($mic, 10, ' ', STR_PAD_LEFT) . ' ' . $sir . '  ';
}

function amr_mlab_ast_fill_mic(array $ast, array $parsed) {
    $by = [];
    foreach ($parsed as $r) {
        $mic = trim((string)($r['mic'] ?? ''));
        if ($mic === '' || $mic === '-') {
            continue;
        }
        $k = amr_mlab_drug_key($r['drug'] ?? '');
        if ($k !== '') {
            $by[$k] = $mic;
        }
    }
    if (!$by) {
        return $ast;
    }
    foreach ($ast as &$a) {
        if (trim((string)($a['mic'] ?? '')) !== '') {
            continue;
        }
        $k = amr_mlab_drug_key($a['drug'] ?? '');
        if (isset($by[$k])) {
            $a['mic'] = $by[$k];
            continue;
        }
        foreach ($by as $bk => $mic) {
            if ($k !== '' && min(strlen($k), strlen($bk)) >= 8
                && (strpos($bk, $k) === 0 || strpos($k, $bk) === 0)) {
                $a['mic'] = $mic;
                break;
            }
        }
    }
    unset($a);
    return $ast;
}

function amr_mlab_lis_mark_used(array &$idx, $panel_name, array $hit = []) {
    $pk = amr_mlab_drug_key($panel_name);
    $id = amr_mlab_drug_key($hit['drug'] ?? '');
    foreach ($idx as $k => $v) {
        $vid = amr_mlab_drug_key($v['drug'] ?? '');
        if ($k === $pk
            || ($id !== '' && $vid === $id)
            || ($pk !== '' && min(strlen($k), strlen($pk)) >= 8 && (strpos($k, $pk) === 0 || strpos($pk, $k) === 0))) {
            $idx[$k]['used'] = true;
        }
    }
}

function amr_mlab_lis_lookup(array $idx, $panel_name) {
    $pk = amr_mlab_drug_key($panel_name);
    if ($pk === '') {
        return ['sir' => '', 'mic' => ''];
    }
    $alias = [
        'CEFOPERASULB' => ['CEFOPERAZONESULBAC', 'CEFOPERAZONESULBACTAM'],
        'PIPERACITAZO' => ['PIPERACILLINTAZOBAC', 'PIPERACILLINTAZOBACTAM'],
        'AMOXICILCLAV' => ['AMOXICILLINCLAVULANATE'],
        'AMPICILLSULB' => ['AMPICILLINSULBACTAM'],
        'TRIMETHOSULF' => ['TRIMETHOPRIMSULFA'],
        'NITROFURANTOI' => ['NITROFURANTOIN'],
        'CHLORAMPHENIC' => ['CHLORAMPHENICOL'],
        'CEFTAZIDAVIB' => ['CEFTAZIDIMEAVIBACTAM'],
    ];
    $keys = [$pk];
    if (isset($alias[$pk])) {
        $keys = array_merge($keys, $alias[$pk]);
    }
    foreach ($keys as $k) {
        if (isset($idx[$k])) {
            return $idx[$k];
        }
    }
    foreach ($idx as $ik => $val) {
        if ($ik === '' || (strlen($ik) < 6 && strlen($pk) < 6)) {
            continue;
        }
        if (strpos($ik, $pk) === 0 || strpos($pk, $ik) === 0) {
            return $val;
        }
    }
    return ['sir' => '', 'mic' => ''];
}

function amr_mlab_lis_index_ast(array $ast_rows) {
    $rank = ['R' => 3, 'I' => 2, 'S' => 1];
    $idx = [];
    foreach ($ast_rows as $a) {
        $drug = rtrim(trim((string)($a['drug'] ?? '')), '.');
        if ($drug === '') {
            continue;
        }
        $sir = strtoupper(substr(trim((string)($a['sir'] ?? '')), 0, 1));
        $mic = trim((string)($a['mic'] ?? ''));
        if ($mic === '') {
            $mic = trim((string)($a['zone'] ?? ''));
        }
        if (!in_array($sir, ['S', 'I', 'R'], true) && $mic === '') {
            continue;
        }
        $keys = array_unique(array_filter([
            amr_mlab_drug_key($drug),
            amr_mlab_drug_key(amr_mlab_lis_short_name($drug)),
        ]));
        foreach ($keys as $k) {
            if (!isset($idx[$k])) {
                $idx[$k] = ['sir' => '', 'mic' => '', 'used' => false, 'drug' => $drug];
            }
            if (in_array($sir, ['S', 'I', 'R'], true)
                && ($rank[$sir] ?? 0) >= ($rank[$idx[$k]['sir']] ?? 0)) {
                $idx[$k]['sir'] = $sir;
            }
            if ($mic !== '') {
                $idx[$k]['mic'] = $mic;
            }
        }
    }
    return $idx;
}

function amr_mlab_append_ordered($text, $date, $time) {
    $text = rtrim((string)$text);
    $ord = amr_mlab_format_dmy($date, $time);
    if ($ord === '' || preg_match('/ORDERED\s*:/i', $text)) {
        return $text;
    }
    if (preg_match('/RELEASED\s*:/i', $text)) {
        return $text . "\n ORDERED  : " . str_replace('/', '-', $ord);
    }
    return $text . "\n ORDERED:  " . $ord;
}

function amr_mlab_case_result_text(array $lab, array $row = []) {
    $spec = trim((string)($lab['specimen'] ?? ''));
    if ($spec === '') {
        $spec = trim((string)($row['Specimen'] ?? ''));
    }
    $org_full = trim((string)($lab['organism'] ?? ''));
    $org_label = trim((string)($row['microtype'] ?? ''));
    $pheno = trim((string)($row['result'] ?? ''));
    if ($org_full === '') {
        $org_full = $org_label;
    }
    $no_growth = ($org_full === '' || preg_match('/no\s*growth/i', $org_full)
        || (($org_full === 'อื่นๆ' || $org_label === 'อื่นๆ') && empty($lab['ast'])));
    if ($no_growth) {
        $org_full = 'No growth';
        $pheno = '';
    }
    $culture = $org_full;
    if ($pheno !== '' && stripos($culture, '(' . $pheno . ')') === false) {
        $culture .= '..(' . $pheno . ')';
    }
    $rel = amr_mlab_format_dmy($lab['report_date'] ?? ($row['report_date'] ?? ''), $lab['report_time'] ?? ($row['report_time'] ?? ''));
    $ord = amr_mlab_format_dmy($lab['order_date'] ?? ($row['order_date'] ?? ''), $lab['order_time'] ?? ($row['order_time'] ?? ''));
    $rule = str_repeat('-', 104);

    $lines = [];
    $lines[] = $spec !== '' ? $spec : 'SPECIMEN: -';
    $lines[] = ' ' . $rule;
    $lines[] = '  | Aerobic Culture |';
    $lines[] = '';
    $lines[] = '         1. ' . ($no_growth ? 'No growth' : $culture);
    $lines[] = '';

    if (!$no_growth) {
        $idx = amr_mlab_lis_index_ast($lab['ast'] ?? []);
        $lines[] = ' --------------1.MIC------SIR  ---------------1.MIC------SIR  ---------------1.MIC------SIR';
        foreach (amr_mlab_lis_panel_rows() as $triple) {
            $cells = [];
            foreach ($triple as $name) {
                $hit = amr_mlab_lis_lookup($idx, $name);
                if ($name !== '') {
                    amr_mlab_lis_mark_used($idx, $name, $hit);
                }
                $cells[] = amr_mlab_lis_cell($name, $hit['mic'], $hit['sir']);
            }
            $lines[] = ' ' . rtrim(implode('', $cells));
        }
        $extra = [];
        $extra_seen = [];
        foreach ($idx as $v) {
            if (!empty($v['used']) || ($v['sir'] === '' && $v['mic'] === '')) {
                continue;
            }
            $ek = amr_mlab_drug_key($v['drug'] ?? '');
            if ($ek === '' || isset($extra_seen[$ek])) {
                continue;
            }
            $extra_seen[$ek] = true;
            $extra[] = $v;
        }
        if ($extra) {
            $chunk = array_chunk($extra, 3);
            foreach ($chunk as $group) {
                $cells = [];
                for ($i = 0; $i < 3; $i++) {
                    if (!isset($group[$i])) {
                        $cells[] = amr_mlab_lis_cell('', '', '');
                        continue;
                    }
                    $g = $group[$i];
                    $cells[] = amr_mlab_lis_cell(amr_mlab_lis_short_name($g['drug']), $g['mic'], $g['sir']);
                }
                $lines[] = ' ' . rtrim(implode('', $cells));
            }
        }
        $lines[] = ' ' . $rule;
    }

    $lines[] = ' APPROVED';
    if ($rel !== '') {
        $lines[] = ' RELEASED : ' . str_replace('/', '-', $rel);
    }
    if ($ord !== '') {
        $lines[] = ' ORDERED  : ' . str_replace('/', '-', $ord);
    }
    $lines[] = '                       S=Susceptible  I=Intermediate  R=Resistant  N=Nonsusceptible';
    return implode("\n", $lines);
}

function amr_mlab_enrich_row_hosxp(array $row, array $lab, $hos, array $overlay = [], array $patients = [], array $stays = [], array $byAn = []) {
    $key = (string)($row['lab_order_number'] ?? '');
    if ($key !== '' && isset($overlay[$key])) {
        $ov = $overlay[$key];
        if (trim((string)($ov['an'] ?? '')) !== '') {
            $row['an'] = trim((string)$ov['an']);
        }
        $pt = trim((string)($ov['ptname'] ?? ''));
        if ($pt !== '') {
            $row['ptname'] = $pt;
        }
        $w = trim((string)($ov['ward'] ?? ''));
        if ($w !== '') {
            $row['ward'] = $w;
        }
        $dc = trim((string)($ov['DCstatus'] ?? ''));
        if ($dc !== '') {
            $row['DCstatus'] = $dc;
        }
        if (trim((string)($ov['result'] ?? '')) !== '' && trim((string)($row['result'] ?? '')) === '') {
            $row['result'] = trim((string)$ov['result']);
        }
    }
    $row = amr_mlab_apply_hosxp_patient($row, $patients);
    if (!empty($row['an']) && !empty($byAn)) {
        $row = amr_mlab_apply_ipt_an($row, $byAn);
        $row = amr_mlab_apply_hosxp_patient($row, $patients);
    }
    if (empty($row['_ipd']) && !empty($stays)) {
        $row = amr_mlab_apply_ipt_stay($row, $stays);
        $row = amr_mlab_apply_hosxp_patient($row, $patients);
    }
    return $row;
}

function amr_mlab_fetch_header($con, $order_number, $hos = null) {
    $esc = mysqli_real_escape_string($con, (string)$order_number);
    $q = mysqli_query($con, "SELECT lab_key, hn, an, vn, ptname, ward, specimen, organism,
            order_date, order_time, report_date, report_time, result_text
        FROM amr_mlab_lab WHERE lab_key='$esc' LIMIT 1");
    $lab = ($q && ($r = mysqli_fetch_assoc($q))) ? $r : [];
    if (!$lab) {
        return [];
    }
    $lab['ast'] = [];
    $aq = mysqli_query($con, "SELECT organism, drug, sir, mic, zone FROM amr_mlab_ast WHERE lab_key='$esc' ORDER BY id");
    if ($aq) {
        while ($a = mysqli_fetch_assoc($aq)) {
            $lab['ast'][] = $a;
        }
    }
    $row = amr_mlab_pack_case($lab, false);
    if (!$row) {
        return [];
    }
    if ($hos) {
        $overlay = amr_mlab_hosxp_overlay($hos, [$row['lab_order_number']]);
        $patients = amr_mlab_fetch_hosxp_patients($hos, [$row['hn'], $lab['hn'] ?? '']);
        $stays = amr_mlab_fetch_ipt_stays($hos, [$row['hn'], $lab['hn'] ?? ''], $row['order_date'], $row['order_date']);
        $ans = [];
        if (!empty($row['an'])) {
            $ans[] = $row['an'];
        }
        foreach ($overlay as $ov) {
            if (!empty($ov['an'])) {
                $ans[] = $ov['an'];
            }
        }
        $byAn = amr_mlab_fetch_ipt_by_an($hos, $ans);
        $row = amr_mlab_enrich_row_hosxp($row, $lab, $hos, $overlay, $patients, $stays, $byAn);
        $hos_text = function_exists('amr_sens_fetch_result_text')
            ? amr_sens_fetch_result_text($hos, $order_number)
            : '';
        if ($hos_text !== '' && function_exists('amr_sens_parse_ast')) {
            $lab['ast'] = amr_mlab_ast_fill_mic($lab['ast'], amr_sens_parse_ast($hos_text));
        }
        if (amr_mlab_is_lis_print($hos_text)) {
            $row['_lis_text'] = amr_mlab_append_ordered(
                $hos_text,
                $lab['order_date'] ?? '',
                $lab['order_time'] ?? ''
            );
        }
    }
    return [
        'lab_order_number' => $row['lab_order_number'],
        'ordertime' => $row['ordertime'],
        'reportdatetime' => $row['reportdatetime'],
        'hn' => $row['hn'],
        'an' => $row['an'],
        'vn' => (string)($lab['vn'] ?? ''),
        'ptname' => $row['ptname'],
        'Wname' => $row['ward'],
        'microtype' => $row['microtype'],
        'result' => $row['result'],
        'Specimen' => $row['Specimen'] ?? ($lab['specimen'] ?? ''),
        'order_date' => $row['order_date'] ?? '',
        'order_time' => $row['order_time'] ?? '',
        'report_date' => $row['report_date'] ?? '',
        'report_time' => $row['report_time'] ?? '',
        '_ast_raw' => $lab['ast'],
        '_result_text' => !empty($row['_lis_text'])
            ? $row['_lis_text']
            : amr_mlab_case_result_text($lab, $row),
    ];
}

function amr_mlab_fetch_result_text($con, $order_number) {
    $esc = mysqli_real_escape_string($con, (string)$order_number);
    $q = mysqli_query($con, "SELECT lab_key, specimen, organism, result_text,
            order_date, order_time, report_date, report_time
        FROM amr_mlab_lab WHERE lab_key='$esc' LIMIT 1");
    $lab = ($q && ($r = mysqli_fetch_assoc($q))) ? $r : [];
    if (!$lab) {
        return '';
    }
    $lab['ast'] = [];
    $aq = mysqli_query($con, "SELECT organism, drug, sir, mic, zone FROM amr_mlab_ast WHERE lab_key='$esc' ORDER BY id");
    if ($aq) {
        while ($a = mysqli_fetch_assoc($aq)) {
            $lab['ast'][] = $a;
        }
    }
    $row = amr_mlab_pack_case($lab, false) ?: [];
    return amr_mlab_case_result_text($lab, $row);
}
