<?php
/**
 * บันทึกความคลาดเคลื่อนทางยา (Medication Error) — โครงสร้างตารางและตัวเลือก
 */

function med_error_intervention_modules() {
    return [
        'Monitor Lab ไต' => 'Monitor Lab ไต',
        'Monitor Lab ตับ' => 'Monitor Lab ตับ',
        'Monitor Lab อื่นๆ' => 'Monitor Lab อื่นๆ',
        'Monitor Interaction' => 'Monitor Interaction',
        'Monitor Drug Allergy' => 'Monitor Drug Allergy',
        'Monitor HLA' => 'Monitor ยีนแพ้ยา HLA',
        'Monitor วิธีใช้ยา' => 'Monitor วิธีใช้ยา',
        'Monitor Max Dose' => 'Monitor Max Dose / Duration',
        'Monitor Warfarin' => 'Monitor Warfarin',
        'Monitor mg to mL' => 'Monitor mg → mL',
        'Monitor ยาเด็ก' => 'Monitor ยาเด็ก',
        'Monitor Antibiotic' => 'Monitor Antibiotic',
        'Monitor จำนวนสั่งยา' => 'Monitor จำนวนสั่งยา (OPD)',
        'Monitor คู่ยาซ้ำซ้อน' => 'Monitor คู่ยาซ้ำซ้อน',
        'Smart Pharma' => 'Smart Pharma',
        'Drug Reconciliation' => 'Drug Reconciliation',
        'อื่นๆ' => 'อื่นๆ',
    ];
}

function med_error_default_types() {
    return [
        ['Prescribing Error', 'สั่งยาผิดชนิด'],
        ['Prescribing Error', 'สั่งยาผิดขนาด'],
        ['Prescribing Error', 'สั่งยาผิดความถี่'],
        ['Prescribing Error', 'สั่งยาผิดวิธีใช้ / เส้นทางให้ยา'],
        ['Prescribing Error', 'สั่งยาผิดระยะเวลา'],
        ['Prescribing Error', 'สั่งยาซ้ำ'],
        ['Prescribing Error', 'สั่งยาที่ผู้ป่วยแพ้ / ห้ามใช้'],
        ['Prescribing Error', 'ใบสั่งไม่ครบถ้วน / ไม่ชัดเจน'],
        ['Transcribing Error', 'คัดลอกยาผิดชนิด'],
        ['Transcribing Error', 'คัดลอกยาผิดขนาด'],
        ['Transcribing Error', 'คัดลอกยาผิดความถี่ / วิธีใช้'],
        ['Transcribing Error', 'ตกหล่น (Omission)'],
        ['Pre-dispensing error', 'จัดยาผิดชนิด'],
        ['Pre-dispensing error', 'จัดยาผิดขนาด / ความแรง'],
        ['Pre-dispensing error', 'ติดฉลากผิด'],
        ['Pre-dispensing error', 'เตรียมยาผิดจำนวน'],
        ['Dispensing Error', 'จ่ายยาผิดชนิด'],
        ['Dispensing Error', 'จ่ายยาผิดขนาด'],
        ['Dispensing Error', 'จ่ายยาผิดคน'],
        ['Dispensing Error', 'จ่ายยาผิดจำนวน'],
        ['Dispensing Error', 'จ่ายยาไม่ครบ'],
        ['Administration Error', 'ให้ยาผิดชนิด'],
        ['Administration Error', 'ให้ยาผิดขนาด'],
        ['Administration Error', 'ให้ยาผิดเวลา'],
        ['Administration Error', 'ให้ยาผิดเส้นทาง'],
        ['Administration Error', 'ให้ยาผิดคน'],
        ['Administration Error', 'ไม่ได้ให้ยา (Omission)'],
        ['Other', 'อื่นๆ'],
    ];
}

function med_error_ensure_tables($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }

    $sql_types = "CREATE TABLE IF NOT EXISTS med_error_types (
        id INT AUTO_INCREMENT PRIMARY KEY,
        category VARCHAR(100) NOT NULL,
        name VARCHAR(255) NOT NULL,
        UNIQUE KEY uk_med_error_cat_name (category, name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8";

    $sql_records = "CREATE TABLE IF NOT EXISTS med_error_records (
        id INT AUTO_INCREMENT PRIMARY KEY,
        hn VARCHAR(20) NULL DEFAULT NULL,
        patient_name VARCHAR(255) NULL DEFAULT NULL,
        patient_type VARCHAR(10) NULL DEFAULT NULL,
        an VARCHAR(20) NULL DEFAULT NULL,
        vn VARCHAR(20) NULL DEFAULT NULL,
        order_doctor_code VARCHAR(30) NULL DEFAULT NULL,
        order_doctor_name VARCHAR(255) NULL DEFAULT NULL,
        order_doctor_group VARCHAR(20) NULL DEFAULT NULL,
        reporting_dept VARCHAR(255) NULL DEFAULT NULL,
        error_dept VARCHAR(255) NULL DEFAULT NULL,
        error_drugs TEXT NULL,
        correct_drugs TEXT NULL,
        is_had VARCHAR(5) NOT NULL DEFAULT 'NO',
        is_robot VARCHAR(5) NOT NULL DEFAULT 'NO',
        rx_type VARCHAR(20) NULL DEFAULT NULL,
        record_kind VARCHAR(20) NOT NULL DEFAULT 'error',
        incident_date DATETIME NOT NULL,
        error_type_id INT NULL DEFAULT NULL,
        error_level VARCHAR(5) NULL DEFAULT NULL,
        description TEXT NULL,
        solution TEXT NULL,
        reporter_id INT NOT NULL DEFAULT 0,
        intervention_module VARCHAR(100) NULL DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_med_error_incident (incident_date),
        KEY idx_med_error_hn (hn),
        KEY idx_med_error_type (error_type_id),
        KEY idx_med_error_doctor (order_doctor_code),
        KEY idx_med_error_doctor_group (order_doctor_group)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8";

    $sql_had = "CREATE TABLE IF NOT EXISTS med_error_had_drugs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        icode VARCHAR(30) NOT NULL,
        name VARCHAR(255) NOT NULL DEFAULT '',
        strength VARCHAR(100) NULL DEFAULT NULL,
        UNIQUE KEY uk_med_error_had_icode (icode)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8";

    $sql_memory = "CREATE TABLE IF NOT EXISTS med_error_drug_memory (
        id INT AUTO_INCREMENT PRIMARY KEY,
        phrase VARCHAR(190) NOT NULL,
        icode VARCHAR(30) NOT NULL,
        name VARCHAR(255) NOT NULL DEFAULT '',
        strength VARCHAR(100) NULL DEFAULT NULL,
        hit_count INT NOT NULL DEFAULT 1,
        last_used_at DATETIME NOT NULL,
        UNIQUE KEY uk_med_error_mem_phrase_icode (phrase, icode),
        KEY idx_med_error_mem_phrase (phrase)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8";

    $sql_doctors = "CREATE TABLE IF NOT EXISTS med_error_doctor_groups (
        id INT AUTO_INCREMENT PRIMARY KEY,
        doctor_code VARCHAR(30) NOT NULL,
        doctor_name VARCHAR(255) NOT NULL DEFAULT '',
        group_key VARCHAR(20) NOT NULL,
        UNIQUE KEY uk_med_error_doc_code (doctor_code),
        KEY idx_med_error_doc_group (group_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8";

    if (!mysqli_query($con, $sql_types) || !mysqli_query($con, $sql_records) || !mysqli_query($con, $sql_had) || !mysqli_query($con, $sql_memory) || !mysqli_query($con, $sql_doctors)) {
        return false;
    }

    $extra = [
        'patient_name' => "ALTER TABLE med_error_records ADD COLUMN patient_name VARCHAR(255) NULL DEFAULT NULL AFTER hn",
        'patient_type' => "ALTER TABLE med_error_records ADD COLUMN patient_type VARCHAR(10) NULL DEFAULT NULL AFTER patient_name",
        'an' => "ALTER TABLE med_error_records ADD COLUMN an VARCHAR(20) NULL DEFAULT NULL AFTER patient_type",
        'vn' => "ALTER TABLE med_error_records ADD COLUMN vn VARCHAR(20) NULL DEFAULT NULL AFTER an",
        'order_doctor_code' => "ALTER TABLE med_error_records ADD COLUMN order_doctor_code VARCHAR(30) NULL DEFAULT NULL AFTER vn",
        'order_doctor_name' => "ALTER TABLE med_error_records ADD COLUMN order_doctor_name VARCHAR(255) NULL DEFAULT NULL AFTER order_doctor_code",
        'order_doctor_group' => "ALTER TABLE med_error_records ADD COLUMN order_doctor_group VARCHAR(20) NULL DEFAULT NULL AFTER order_doctor_name",
        'reporting_dept' => "ALTER TABLE med_error_records ADD COLUMN reporting_dept VARCHAR(255) NULL DEFAULT NULL AFTER vn",
        'error_dept' => "ALTER TABLE med_error_records ADD COLUMN error_dept VARCHAR(255) NULL DEFAULT NULL AFTER reporting_dept",
        'error_drugs' => "ALTER TABLE med_error_records ADD COLUMN error_drugs TEXT NULL AFTER error_dept",
        'correct_drugs' => "ALTER TABLE med_error_records ADD COLUMN correct_drugs TEXT NULL AFTER error_drugs",
        'is_had' => "ALTER TABLE med_error_records ADD COLUMN is_had VARCHAR(5) NOT NULL DEFAULT 'NO' AFTER correct_drugs",
        'is_robot' => "ALTER TABLE med_error_records ADD COLUMN is_robot VARCHAR(5) NOT NULL DEFAULT 'NO' AFTER is_had",
        'rx_type' => "ALTER TABLE med_error_records ADD COLUMN rx_type VARCHAR(20) NULL DEFAULT NULL AFTER is_robot",
        'record_kind' => "ALTER TABLE med_error_records ADD COLUMN record_kind VARCHAR(20) NOT NULL DEFAULT 'error' AFTER rx_type",
        'solution' => "ALTER TABLE med_error_records ADD COLUMN solution TEXT NULL AFTER description",
        'intervention_module' => "ALTER TABLE med_error_records ADD COLUMN intervention_module VARCHAR(100) NULL DEFAULT NULL AFTER reporter_id",
        'created_at' => "ALTER TABLE med_error_records ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER intervention_module",
        'updated_at' => "ALTER TABLE med_error_records ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at",
    ];
    foreach ($extra as $col => $alter) {
        $q = mysqli_query($con, "SHOW COLUMNS FROM med_error_records LIKE '" . mysqli_real_escape_string($con, $col) . "'");
        if ($q && mysqli_num_rows($q) === 0) {
            mysqli_query($con, $alter);
        }
    }

    $nullable = [
        'hn' => "ALTER TABLE med_error_records MODIFY hn VARCHAR(20) NULL DEFAULT NULL",
        'error_type_id' => "ALTER TABLE med_error_records MODIFY error_type_id INT NULL DEFAULT NULL",
        'error_level' => "ALTER TABLE med_error_records MODIFY error_level VARCHAR(5) NULL DEFAULT NULL",
    ];
    foreach ($nullable as $col => $alter) {
        $q = mysqli_query($con, "SHOW COLUMNS FROM med_error_records LIKE '" . mysqli_real_escape_string($con, $col) . "'");
        if ($q && ($c = mysqli_fetch_assoc($q)) && strtoupper((string)$c['Null']) === 'NO') {
            mysqli_query($con, $alter);
        }
    }

    $cnt = 0;
    $qc = mysqli_query($con, "SELECT COUNT(*) AS c FROM med_error_types");
    if ($qc && ($r = mysqli_fetch_assoc($qc))) {
        $cnt = (int)$r['c'];
    }
    if ($cnt === 0) {
        foreach (med_error_default_types() as $row) {
            $cat = mysqli_real_escape_string($con, $row[0]);
            $name = mysqli_real_escape_string($con, $row[1]);
            mysqli_query($con, "INSERT IGNORE INTO med_error_types (category, name) VALUES ('$cat', '$name')");
        }
    }

    med_error_memory_backfill($con);

    $ready = true;
    return true;
}

function med_error_sanitize_yes_no($value, $default = 'NO') {
    $value = strtoupper(trim((string)$value));
    if (in_array($value, ['YES', 'Y', '1'], true)) {
        return 'YES';
    }
    if (in_array($value, ['NO', 'N', '0'], true)) {
        return 'NO';
    }
    return $default;
}

function med_error_list_had_drugs($con) {
    $out = [];
    $q = mysqli_query($con, "SELECT id, icode, name, strength FROM med_error_had_drugs ORDER BY name ASC, icode ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $icode = trim((string)($r['icode'] ?? ''));
            $name = trim((string)($r['name'] ?? ''));
            $strength = trim((string)($r['strength'] ?? ''));
            $out[] = [
                'id' => (int)$r['id'],
                'icode' => $icode,
                'name' => $name,
                'strength' => $strength,
                'label' => med_error_drug_label($name !== '' ? $name : $icode, $strength),
            ];
        }
    }
    return $out;
}

function med_error_had_maps($con) {
    $icodes = [];
    $labels = [];
    foreach (med_error_list_had_drugs($con) as $d) {
        if ($d['icode'] !== '') {
            $icodes[$d['icode']] = true;
        }
        $lab = function_exists('mb_strtolower')
            ? mb_strtolower(trim($d['label']), 'UTF-8')
            : strtolower(trim($d['label']));
        if ($lab !== '') {
            $labels[$lab] = true;
        }
    }
    return ['icodes' => $icodes, 'labels' => $labels];
}

function med_error_drugs_are_had($con, array $drugs) {
    $maps = med_error_had_maps($con);
    foreach ($drugs as $d) {
        $icode = trim((string)($d['icode'] ?? ''));
        if ($icode !== '' && isset($maps['icodes'][$icode])) {
            return true;
        }
        $label = trim((string)($d['label'] ?? $d['name'] ?? ''));
        $lab = function_exists('mb_strtolower') ? mb_strtolower($label, 'UTF-8') : strtolower($label);
        if ($lab !== '' && isset($maps['labels'][$lab])) {
            return true;
        }
    }
    return false;
}

function med_error_add_had_drug($con, $icode, $name = '', $strength = '') {
    $icode = trim((string)$icode);
    $name = trim((string)$name);
    $strength = trim((string)$strength);
    if ($icode === '') {
        return ['ok' => false, 'message' => 'ไม่พบรหัสยา'];
    }
    $icode_sql = mysqli_real_escape_string($con, $icode);
    $name_sql = mysqli_real_escape_string($con, $name !== '' ? $name : $icode);
    $strength_sql = $strength !== '' ? ("'" . mysqli_real_escape_string($con, $strength) . "'") : 'NULL';
    $chk = mysqli_query($con, "SELECT id FROM med_error_had_drugs WHERE icode='$icode_sql' LIMIT 1");
    if ($chk && ($row = mysqli_fetch_assoc($chk))) {
        return [
            'ok' => false,
            'message' => 'ยานี้อยู่ในรายการ HAD แล้ว',
            'id' => (int)$row['id'],
            'icode' => $icode,
        ];
    }
    $ok = mysqli_query($con, "INSERT INTO med_error_had_drugs (icode, name, strength) VALUES ('$icode_sql', '$name_sql', $strength_sql)");
    if (!$ok) {
        return ['ok' => false, 'message' => 'ไม่สามารถเพิ่มยา HAD ได้'];
    }
    return [
        'ok' => true,
        'id' => (int)mysqli_insert_id($con),
        'icode' => $icode,
        'name' => $name !== '' ? $name : $icode,
        'strength' => $strength,
        'label' => med_error_drug_label($name !== '' ? $name : $icode, $strength),
        'message' => 'เพิ่มยา HAD สำเร็จ',
    ];
}

function med_error_delete_had_drug($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "DELETE FROM med_error_had_drugs WHERE id=$id");
}

/** HOSxP drugitems.displaycolor เป็น TColor (BGR) — HAD ใช้สีแดง เช่น clRed = 255 */
function med_error_displaycolor_is_red($color) {
    $c = (int)$color;
    $r = $c & 255;
    $g = ($c >> 8) & 255;
    $b = ($c >> 16) & 255;
    return $r >= 200 && $g <= 40 && $b <= 40;
}

function med_error_fetch_hosxp_had_drugs($hos) {
    $sql = "SELECT d.icode,
                   CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS name,
                   CAST(CONVERT(IFNULL(d.strength,'') USING utf8) AS CHAR) AS strength,
                   d.displaycolor
            FROM drugitems d
            WHERE d.istatus = 'Y'
              AND d.displaycolor IS NOT NULL
              AND (d.displaycolor & 255) >= 200
              AND ((d.displaycolor >> 8) & 255) <= 40
              AND ((d.displaycolor >> 16) & 255) <= 40
            ORDER BY d.name ASC, d.icode ASC";
    $q = @mysqli_query($hos, $sql);
    $list = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            if (!med_error_displaycolor_is_red($r['displaycolor'] ?? 0)) {
                continue;
            }
            $d = med_error_map_drug_row($r);
            if (!$d) {
                continue;
            }
            $nm = $d['name'] . ' ' . $d['label'];
            if (preg_match('/ตั้งครรภ์/u', $nm) && !preg_match('/\b(inj|tab|mg|ml|iu)\b/i', $nm)) {
                continue;
            }
            $list[] = $d;
        }
    }
    return $list;
}

function med_error_sync_had_from_hosxp($con) {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = hosxp_connect($con);
    if (!$hos) {
        return ['ok' => false, 'message' => 'เชื่อมต่อ HOSxP ไม่สำเร็จ', 'added' => 0, 'updated' => 0, 'total' => 0];
    }
    mysqli_set_charset($hos, 'utf8');
    $drugs = med_error_fetch_hosxp_had_drugs($hos);
    mysqli_close($hos);

    $added = 0;
    $updated = 0;
    foreach ($drugs as $d) {
        $icode_sql = mysqli_real_escape_string($con, $d['icode']);
        $name_sql = mysqli_real_escape_string($con, $d['name']);
        $strength_sql = $d['strength'] !== ''
            ? ("'" . mysqli_real_escape_string($con, $d['strength']) . "'")
            : 'NULL';
        $chk = mysqli_query($con, "SELECT id FROM med_error_had_drugs WHERE icode='$icode_sql' LIMIT 1");
        if ($chk && ($row = mysqli_fetch_assoc($chk))) {
            mysqli_query($con, "UPDATE med_error_had_drugs SET name='$name_sql', strength=$strength_sql WHERE id=" . (int)$row['id']);
            $updated++;
        } else {
            $ok = mysqli_query($con, "INSERT INTO med_error_had_drugs (icode, name, strength) VALUES ('$icode_sql', '$name_sql', $strength_sql)");
            if ($ok) {
                $added++;
            }
        }
    }
    $total = count($drugs);
    return [
        'ok' => true,
        'added' => $added,
        'updated' => $updated,
        'total' => $total,
        'message' => "ดึงยา HAD จาก HOSxP (Font สีแดง) สำเร็จ {$total} รายการ (เพิ่มใหม่ {$added}, มีอยู่แล้ว {$updated})",
    ];
}

function med_error_sanitize_patient_type($value) {
    $value = strtoupper(trim((string)$value));
    return ($value === 'IPD' || $value === 'OPD') ? $value : '';
}

function med_error_record_kinds() {
    return [
        'error' => 'ความคลาดเคลื่อนจริง',
        'consult' => 'ไม่ใช่ความคลาดเคลื่อนจริง (บันทึกการ Consult)',
    ];
}

function med_error_sanitize_record_kind($value) {
    $value = strtolower(trim((string)$value));
    return isset(med_error_record_kinds()[$value]) ? $value : 'error';
}

function med_error_record_kind_label($value) {
    $map = med_error_record_kinds();
    $value = med_error_sanitize_record_kind($value);
    return $map[$value] ?? $map['error'];
}

function med_error_doctor_group_keys() {
    return [
        'staff' => 'Staff',
        'intern' => 'Intern',
        'extern' => 'Extern',
    ];
}

function med_error_sanitize_doctor_group($value) {
    $value = strtolower(trim((string)$value));
    return isset(med_error_doctor_group_keys()[$value]) ? $value : '';
}

function med_error_doctor_group_label($value) {
    $map = med_error_doctor_group_keys();
    $value = med_error_sanitize_doctor_group($value);
    return $map[$value] ?? '';
}

function med_error_list_doctor_groups($con) {
    $out = [];
    $q = mysqli_query($con, "SELECT id, doctor_code, doctor_name, group_key FROM med_error_doctor_groups ORDER BY group_key ASC, doctor_name ASC, doctor_code ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $code = trim((string)($r['doctor_code'] ?? ''));
            $name = trim((string)($r['doctor_name'] ?? ''));
            $group = med_error_sanitize_doctor_group($r['group_key'] ?? '');
            $out[] = [
                'id' => (int)$r['id'],
                'code' => $code,
                'name' => $name,
                'group' => $group,
                'group_label' => med_error_doctor_group_label($group),
                'text' => $name . ($code !== '' ? ' (' . $code . ')' : ''),
            ];
        }
    }
    return $out;
}

function med_error_doctor_group_map($con) {
    $by_code = [];
    $by_name = [];
    foreach (med_error_list_doctor_groups($con) as $d) {
        if ($d['code'] !== '') {
            $by_code[$d['code']] = $d;
        }
        $nkey = function_exists('mb_strtolower')
            ? mb_strtolower($d['name'], 'UTF-8')
            : strtolower($d['name']);
        if ($nkey !== '') {
            $by_name[$nkey] = $d;
        }
    }
    return ['by_code' => $by_code, 'by_name' => $by_name];
}

function med_error_lookup_doctor_group($con, $code, $name = '') {
    $code = trim((string)$code);
    $name = trim((string)$name);
    if ($code !== '') {
        $esc = mysqli_real_escape_string($con, $code);
        $q = mysqli_query($con, "SELECT group_key FROM med_error_doctor_groups WHERE doctor_code='$esc' LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            return med_error_sanitize_doctor_group($r['group_key'] ?? '');
        }
    }
    if ($name !== '') {
        $esc = mysqli_real_escape_string($con, $name);
        $q = mysqli_query($con, "SELECT group_key FROM med_error_doctor_groups WHERE doctor_name='$esc' LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            return med_error_sanitize_doctor_group($r['group_key'] ?? '');
        }
    }
    return '';
}

function med_error_save_doctor_group($con, $code, $name, $group) {
    $code = trim((string)$code);
    $name = trim((string)$name);
    $group = med_error_sanitize_doctor_group($group);
    if ($code === '') {
        return ['ok' => false, 'message' => 'กรุณาเลือกแพทย์จาก HOSxP'];
    }
    if ($group === '') {
        return ['ok' => false, 'message' => 'กรุณาเลือกกลุ่ม Staff / Intern / Extern'];
    }
    $code_sql = mysqli_real_escape_string($con, $code);
    $name_sql = mysqli_real_escape_string($con, $name !== '' ? $name : $code);
    $group_sql = mysqli_real_escape_string($con, $group);
    $chk = mysqli_query($con, "SELECT id FROM med_error_doctor_groups WHERE doctor_code='$code_sql' LIMIT 1");
    if ($chk && ($row = mysqli_fetch_assoc($chk))) {
        $id = (int)$row['id'];
        $ok = mysqli_query($con, "UPDATE med_error_doctor_groups SET doctor_name='$name_sql', group_key='$group_sql' WHERE id=$id");
        if (!$ok) {
            return ['ok' => false, 'message' => 'ไม่สามารถอัปเดตกลุ่มแพทย์ได้'];
        }
        return [
            'ok' => true,
            'id' => $id,
            'code' => $code,
            'name' => $name !== '' ? $name : $code,
            'group' => $group,
            'group_label' => med_error_doctor_group_label($group),
            'message' => 'อัปเดตกลุ่มแพทย์สำเร็จ',
        ];
    }
    $ok = mysqli_query($con, "INSERT INTO med_error_doctor_groups (doctor_code, doctor_name, group_key) VALUES ('$code_sql', '$name_sql', '$group_sql')");
    if (!$ok) {
        return ['ok' => false, 'message' => 'ไม่สามารถบันทึกกลุ่มแพทย์ได้'];
    }
    return [
        'ok' => true,
        'id' => (int)mysqli_insert_id($con),
        'code' => $code,
        'name' => $name !== '' ? $name : $code,
        'group' => $group,
        'group_label' => med_error_doctor_group_label($group),
        'message' => 'บันทึกกลุ่มแพทย์สำเร็จ',
    ];
}

function med_error_delete_doctor_group($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "DELETE FROM med_error_doctor_groups WHERE id=$id");
}

function med_error_empty_visit_context() {
    return [
        'an' => '',
        'vn' => '',
        'suggested_type' => '',
        'ward_name' => '',
        'has_an' => false,
        'has_vn' => false,
        'visit_rooms' => [],
        'preferred_room' => '',
        'order_doctor_code' => '',
        'order_doctor_name' => '',
        'order_doctor_group' => '',
    ];
}

function med_error_lookup_doctor_by_code($hos, $code) {
    $code = trim((string)$code);
    if ($code === '') {
        return ['code' => '', 'name' => ''];
    }
    $esc = mysqli_real_escape_string($hos, $code);
    $row = med_error_query_one($hos, "
        SELECT d.code,
               CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS doctor_name
        FROM doctor d
        WHERE d.code = '$esc'
        LIMIT 1
    ");
    if (!$row) {
        $row = med_error_query_one($hos, "
            SELECT code, name AS doctor_name
            FROM doctor
            WHERE code = '$esc'
            LIMIT 1
        ");
    }
    if (!$row) {
        return ['code' => $code, 'name' => ''];
    }
    return [
        'code' => trim((string)($row['code'] ?? $code)),
        'name' => trim((string)($row['doctor_name'] ?? '')),
    ];
}

function med_error_search_hosxp_doctors($hos, $term, $limit = 40) {
    $term = trim((string)$term);
    $limit = (int)$limit;
    if ($limit <= 0 || $limit > 80) {
        $limit = 40;
    }
    $out = [];
    if ($term === '') {
        return $out;
    }
    $esc = mysqli_real_escape_string($hos, $term);
    $like = '%' . $esc . '%';
    $sql = "
        SELECT doc.code,
               CAST(CONVERT(IFNULL(doc.name,'') USING utf8) AS CHAR) AS doctor_name
        FROM doctor doc
        WHERE doc.name LIKE '$like'
           OR doc.code LIKE '$like'
           OR CAST(CONVERT(CONCAT(IFNULL(doc.name,''), IFNULL(doc.licenseno,'')) USING utf8) AS CHAR) LIKE '$like'
        ORDER BY doc.name ASC
        LIMIT $limit
    ";
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        $q = @mysqli_query($hos, "
            SELECT code, name AS doctor_name
            FROM doctor
            WHERE name LIKE '$like' OR code LIKE '$like'
            ORDER BY name ASC
            LIMIT $limit
        ");
    }
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $name = trim((string)($r['doctor_name'] ?? ''));
            $code = trim((string)($r['code'] ?? ''));
            if ($name === '' && $code === '') {
                continue;
            }
            if ($name === '') {
                $name = $code;
            }
            $out[] = [
                'code' => $code,
                'name' => $name,
                'text' => $name . ($code !== '' ? ' (' . $code . ')' : ''),
            ];
        }
    }
    return $out;
}

function med_error_fetch_order_doctor($hos, $in_sql, $date, $vn = '', $an = '') {
    $empty = ['code' => '', 'name' => ''];
    if ($in_sql === '') {
        return $empty;
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$date)) {
        $date = date('Y-m-d');
    }
    $d = mysqli_real_escape_string($hos, $date);
    $vn = trim((string)$vn);
    $an = trim((string)$an);
    $vn_sql = $vn !== '' ? mysqli_real_escape_string($hos, $vn) : '';
    $an_sql = $an !== '' ? mysqli_real_escape_string($hos, $an) : '';

    $extras = [];
    if ($vn_sql !== '') {
        $extras[] = "o.vn = '$vn_sql'";
    }
    if ($an_sql !== '') {
        $extras[] = "o.an = '$an_sql'";
    }
    $extras[] = "o.vstdate = '$d'";

    $seen = [];
    foreach ($extras as $extra) {
        if (isset($seen[$extra])) {
            continue;
        }
        $seen[$extra] = true;
        $row = med_error_query_one($hos, "
            SELECT o.doctor AS code,
                   CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS doctor_name
            FROM opitemrece o
            INNER JOIN drugitems di ON di.icode = o.icode
            LEFT JOIN doctor d ON d.code = o.doctor
            WHERE o.hn IN ($in_sql)
              AND o.doctor IS NOT NULL AND TRIM(o.doctor) <> ''
              AND $extra
            ORDER BY o.vstdate DESC, IFNULL(o.rxdate, o.vstdate) DESC
            LIMIT 1
        ");
        if (!$row) {
            $row = med_error_query_one($hos, "
                SELECT o.doctor AS code,
                       CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS doctor_name
                FROM opitemrece o
                LEFT JOIN doctor d ON d.code = o.doctor
                WHERE o.hn IN ($in_sql)
                  AND o.doctor IS NOT NULL AND TRIM(o.doctor) <> ''
                  AND $extra
                ORDER BY o.vstdate DESC
                LIMIT 1
            ");
        }
        $code = is_array($row) ? trim((string)($row['code'] ?? '')) : '';
        if ($code === '') {
            continue;
        }
        $name = trim((string)($row['doctor_name'] ?? ''));
        if ($name === '') {
            $look = med_error_lookup_doctor_by_code($hos, $code);
            $name = $look['name'];
        }
        return ['code' => $code, 'name' => $name !== '' ? $name : $code];
    }

    if ($vn_sql !== '') {
        $row = med_error_query_one($hos, "
            SELECT o.doctor AS code,
                   CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS doctor_name
            FROM ovst o
            LEFT JOIN doctor d ON d.code = o.doctor
            WHERE o.vn = '$vn_sql'
              AND o.doctor IS NOT NULL AND TRIM(o.doctor) <> ''
            LIMIT 1
        ");
        $code = is_array($row) ? trim((string)($row['code'] ?? '')) : '';
        if ($code !== '') {
            $name = trim((string)($row['doctor_name'] ?? ''));
            if ($name === '') {
                $look = med_error_lookup_doctor_by_code($hos, $code);
                $name = $look['name'];
            }
            return ['code' => $code, 'name' => $name !== '' ? $name : $code];
        }
    }

    if ($an_sql !== '') {
        foreach (['admdoctor', 'doctor'] as $col) {
            $row = med_error_query_one($hos, "
                SELECT i.`$col` AS code,
                       CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS doctor_name
                FROM ipt i
                LEFT JOIN doctor d ON d.code = i.`$col`
                WHERE i.an = '$an_sql'
                  AND i.`$col` IS NOT NULL AND TRIM(i.`$col`) <> ''
                LIMIT 1
            ");
            $code = is_array($row) ? trim((string)($row['code'] ?? '')) : '';
            if ($code === '') {
                continue;
            }
            $name = trim((string)($row['doctor_name'] ?? ''));
            if ($name === '') {
                $look = med_error_lookup_doctor_by_code($hos, $code);
                $name = $look['name'];
            }
            return ['code' => $code, 'name' => $name !== '' ? $name : $code];
        }
    }

    return $empty;
}

function med_error_report_filters_from_request(array $src) {
    $kind = strtolower(trim((string)($src['record_kind'] ?? '')));
    if ($kind !== 'error' && $kind !== 'consult') {
        $kind = '';
    }
    $ptype = med_error_sanitize_patient_type($src['patient_type'] ?? '');
    $category = trim((string)($src['category'] ?? ''));
    $level = strtoupper(trim((string)($src['error_level'] ?? '')));
    if (!in_array($level, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'], true)) {
        $level = '';
    }
    $had = strtoupper(trim((string)($src['is_had'] ?? '')));
    if ($had !== 'YES' && $had !== 'NO') {
        $had = '';
    }
    $robot = strtoupper(trim((string)($src['is_robot'] ?? '')));
    if ($robot !== 'YES' && $robot !== 'NO') {
        $robot = '';
    }
    $rx = strtolower(trim((string)($src['rx_type'] ?? '')));
    if (!isset(med_error_rx_types()[$rx])) {
        $rx = '';
    }
    $reporter = isset($src['reporter_id']) ? (int)$src['reporter_id'] : 0;
    if ($reporter < 0) {
        $reporter = 0;
    }
    $doc_group = strtolower(trim((string)($src['doctor_group'] ?? '')));
    if ($doc_group !== 'none' && !isset(med_error_doctor_group_keys()[$doc_group])) {
        $doc_group = '';
    }
    return [
        'record_kind' => $kind,
        'patient_type' => $ptype,
        'category' => $category,
        'error_level' => $level,
        'is_had' => $had,
        'is_robot' => $robot,
        'rx_type' => $rx,
        'reporter_id' => $reporter,
        'doctor_group' => $doc_group,
    ];
}

function med_error_report_filter_sql($con, array $filters, $alias = 'm') {
    $parts = [];
    if (($filters['record_kind'] ?? '') !== '') {
        $k = mysqli_real_escape_string($con, $filters['record_kind']);
        $parts[] = "IFNULL({$alias}.record_kind,'error') = '$k'";
    }
    if (($filters['patient_type'] ?? '') !== '') {
        $p = mysqli_real_escape_string($con, $filters['patient_type']);
        $parts[] = "{$alias}.patient_type = '$p'";
    }
    if (($filters['category'] ?? '') !== '') {
        $c = mysqli_real_escape_string($con, $filters['category']);
        $parts[] = "t.category = '$c'";
    }
    if (($filters['error_level'] ?? '') !== '') {
        $l = mysqli_real_escape_string($con, $filters['error_level']);
        $parts[] = "{$alias}.error_level = '$l'";
    }
    if (($filters['is_had'] ?? '') !== '') {
        $h = mysqli_real_escape_string($con, $filters['is_had']);
        $parts[] = "IFNULL({$alias}.is_had,'NO') = '$h'";
    }
    if (($filters['is_robot'] ?? '') !== '') {
        $r = mysqli_real_escape_string($con, $filters['is_robot']);
        $parts[] = "IFNULL({$alias}.is_robot,'NO') = '$r'";
    }
    if (($filters['rx_type'] ?? '') !== '') {
        $x = mysqli_real_escape_string($con, $filters['rx_type']);
        $parts[] = "{$alias}.rx_type = '$x'";
    }
    if (!empty($filters['reporter_id'])) {
        $parts[] = "{$alias}.reporter_id = " . (int)$filters['reporter_id'];
    }
    $dg = strtolower(trim((string)($filters['doctor_group'] ?? '')));
    if ($dg === 'none') {
        $parts[] = "IFNULL({$alias}.order_doctor_group,'') = ''";
    } elseif (isset(med_error_doctor_group_keys()[$dg])) {
        $g = mysqli_real_escape_string($con, $dg);
        $parts[] = "{$alias}.order_doctor_group = '$g'";
    }
    return $parts;
}

function med_error_report_query_string($start_date, $end_date, array $filters) {
    $q = [
        'start_date' => $start_date,
        'end_date' => $end_date,
    ];
    foreach ($filters as $k => $v) {
        if ($v === '' || $v === 0 || $v === '0') {
            continue;
        }
        $q[$k] = $v;
    }
    return http_build_query($q);
}

function med_error_report_filter_label(array $filters, $reporter_name = '') {
    $bits = [];
    if (($filters['record_kind'] ?? '') !== '') {
        $bits[] = med_error_record_kind_label($filters['record_kind']);
    }
    if (($filters['patient_type'] ?? '') === 'IPD') {
        $bits[] = 'ผู้ป่วยใน';
    } elseif (($filters['patient_type'] ?? '') === 'OPD') {
        $bits[] = 'ผู้ป่วยนอก';
    }
    if (($filters['category'] ?? '') !== '') {
        $bits[] = $filters['category'];
    }
    if (($filters['error_level'] ?? '') !== '') {
        $bits[] = 'Level ' . $filters['error_level'];
    }
    if (($filters['is_had'] ?? '') !== '') {
        $bits[] = 'HAD ' . $filters['is_had'];
    }
    if (($filters['is_robot'] ?? '') !== '') {
        $bits[] = 'Robot ' . $filters['is_robot'];
    }
    if (($filters['rx_type'] ?? '') !== '') {
        $rx = med_error_rx_type_label($filters['rx_type']);
        if ($rx !== '') {
            $bits[] = $rx;
        }
    }
    $reporter_name = trim((string)$reporter_name);
    if ($reporter_name !== '') {
        $bits[] = $reporter_name;
    }
    $dg = strtolower(trim((string)($filters['doctor_group'] ?? '')));
    if ($dg === 'none') {
        $bits[] = 'แพทย์ยังไม่จัดกลุ่ม';
    } elseif (isset(med_error_doctor_group_keys()[$dg])) {
        $bits[] = 'แพทย์ ' . med_error_doctor_group_label($dg);
    }
    return $bits;
}

function med_error_reporter_summary($con, $start_date, $end_date, array $filters = []) {
    $start = mysqli_real_escape_string($con, $start_date);
    $end = mysqli_real_escape_string($con, $end_date);
    $filter_sql = med_error_report_filter_sql($con, $filters);
    $extra = $filter_sql ? (' AND ' . implode(' AND ', $filter_sql)) : '';
    $join_type = (($filters['category'] ?? '') !== '')
        ? ' LEFT JOIN med_error_types t ON m.error_type_id = t.id '
        : '';
    $sql = "SELECT m.reporter_id,
                   MAX(IFNULL(NULLIF(TRIM(u.full_name), ''), '')) AS reporter_name,
                   SUM(CASE WHEN IFNULL(m.record_kind,'error') = 'consult' THEN 1 ELSE 0 END) AS consult_count,
                   SUM(CASE WHEN IFNULL(m.record_kind,'error') <> 'consult' THEN 1 ELSE 0 END) AS me_count,
                   COUNT(*) AS total_count
            FROM med_error_records m
            LEFT JOIN users u ON u.id = m.reporter_id
            $join_type
            WHERE DATE(m.incident_date) BETWEEN '$start' AND '$end'
            $extra
            GROUP BY m.reporter_id
            ORDER BY total_count DESC, reporter_name ASC, m.reporter_id ASC";
    $rows = [];
    $q = mysqli_query($con, $sql);
    if (!$q) {
        return $rows;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $rid = (int)($r['reporter_id'] ?? 0);
        $name = trim((string)($r['reporter_name'] ?? ''));
        if ($name === '') {
            $name = $rid > 0 ? ('ผู้ใช้ #' . $rid) : 'ไม่ระบุผู้บันทึก';
        }
        $me = (int)($r['me_count'] ?? 0);
        $consult = (int)($r['consult_count'] ?? 0);
        $rows[] = [
            'reporter_id' => $rid,
            'reporter_name' => $name,
            'me_count' => $me,
            'consult_count' => $consult,
            'total_count' => (int)($r['total_count'] ?? ($me + $consult)),
        ];
    }
    return $rows;
}

function med_error_report_default_rates() {
    return [
        'error' => 15.0,
        'consult' => 0.0,
    ];
}

function med_error_report_sanitize_rate($raw, $default) {
    $default = (float)$default;
    if ($raw === null || $raw === '') {
        return $default;
    }
    $n = (float)str_replace([',', ' '], '', (string)$raw);
    if (!is_finite($n) || $n < 0) {
        return $default;
    }
    if ($n > 10000) {
        $n = 10000;
    }
    return round($n, 2);
}

function med_error_report_get_rates($con) {
    $def = med_error_report_default_rates();
    $out = $def;
    $q = @mysqli_query($con, "SELECT config_name, config_value FROM sys_config
        WHERE config_name IN ('me_report_rate_error','me_report_rate_consult')");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            if (($r['config_name'] ?? '') === 'me_report_rate_error') {
                $out['error'] = med_error_report_sanitize_rate($r['config_value'] ?? '', $def['error']);
            }
            if (($r['config_name'] ?? '') === 'me_report_rate_consult') {
                $out['consult'] = med_error_report_sanitize_rate($r['config_value'] ?? '', $def['consult']);
            }
        }
    }
    return $out;
}

function med_error_report_save_rates($con, $error_rate, $consult_rate) {
    $def = med_error_report_default_rates();
    $error_rate = med_error_report_sanitize_rate($error_rate, $def['error']);
    $consult_rate = med_error_report_sanitize_rate($consult_rate, $def['consult']);
    $pairs = [
        'me_report_rate_error' => (string)$error_rate,
        'me_report_rate_consult' => (string)$consult_rate,
    ];
    foreach ($pairs as $key => $val) {
        $k = mysqli_real_escape_string($con, $key);
        $v = mysqli_real_escape_string($con, $val);
        $chk = @mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            $ok = mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$k'");
        } else {
            $ok = mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
        }
        if (!$ok) {
            return ['ok' => false, 'error' => 'บันทึกค่าต่อเคสไม่สำเร็จ', 'rates' => ['error' => $error_rate, 'consult' => $consult_rate]];
        }
    }
    return ['ok' => true, 'rates' => ['error' => $error_rate, 'consult' => $consult_rate]];
}

function med_error_report_format_baht($n) {
    $n = (float)$n;
    if (abs($n - round($n)) < 0.001) {
        return number_format($n, 0);
    }
    return number_format($n, 2);
}

function med_error_rx_types() {
    return [
        'new' => 'ยาสั่งใหม่',
        'home' => 'ยากลับบ้าน',
        'continue' => 'ยา Continue',
    ];
}

function med_error_sanitize_rx_type($value, $patient_type = '') {
    if (med_error_sanitize_patient_type($patient_type) !== 'IPD') {
        return '';
    }
    $value = strtolower(trim((string)$value));
    $map = med_error_rx_types();
    return isset($map[$value]) ? $value : '';
}

function med_error_rx_type_label($value) {
    $value = strtolower(trim((string)$value));
    $map = med_error_rx_types();
    return $map[$value] ?? '';
}

function med_error_post_dept($key) {
    $v = trim((string)($_POST[$key] ?? ''));
    if ($v === '__ward__') {
        $v = trim((string)($_POST[$key . '_ward'] ?? ''));
    } elseif ($v === '__other__') {
        $v = trim((string)($_POST[$key . '_other'] ?? ''));
    }
    return $v;
}

function med_error_pharmacy_ipd() {
    return 'ห้องจ่ายยาผู้ป่วยใน';
}

function med_error_pharmacy_opd() {
    return 'ห้องจ่ายยาผู้ป่วยนอก';
}

function med_error_unique_rooms(array $rooms) {
    $out = [];
    $seen = [];
    foreach ($rooms as $r) {
        $name = trim((string)($r['name'] ?? ''));
        if ($name === '') {
            continue;
        }
        $key = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = [
            'code' => trim((string)($r['code'] ?? '')),
            'name' => $name,
            'time' => trim((string)($r['time'] ?? '')),
        ];
    }
    return $out;
}

function med_error_fetch_ward_name($hos, $an, $date) {
    $an = trim((string)$an);
    if ($an === '') {
        return '';
    }
    $an_esc = mysqli_real_escape_string($hos, $an);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$date)) {
        $date = date('Y-m-d');
    }
    $d = mysqli_real_escape_string($hos, $date);

    $adm = med_error_query_one($hos, "
        SELECT CAST(CONVERT(IFNULL(w.name, adm.ward) USING utf8) AS CHAR) AS ward_name
        FROM iptadm adm
        LEFT JOIN ward w ON w.ward = adm.ward
        WHERE adm.an = '$an_esc'
          AND adm.indate <= '$d'
          AND (adm.outdate IS NULL OR adm.outdate = '0000-00-00' OR adm.outdate >= '$d')
        ORDER BY adm.indate DESC, adm.intime DESC
        LIMIT 1
    ");
    if ($adm && trim((string)($adm['ward_name'] ?? '')) !== '') {
        return trim((string)$adm['ward_name']);
    }

    $ipt = med_error_query_one($hos, "
        SELECT CAST(CONVERT(IFNULL(w.name, i.ward) USING utf8) AS CHAR) AS ward_name
        FROM ipt i
        LEFT JOIN ward w ON w.ward = i.ward
        WHERE i.an = '$an_esc'
        LIMIT 1
    ");
    return $ipt ? trim((string)($ipt['ward_name'] ?? '')) : '';
}

function med_error_list_wards($con) {
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $cache = [];
    if (!function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    }
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 8) : null;
    if (!$hos) {
        return $cache;
    }
    $q = @mysqli_query($hos, "SELECT CAST(CONVERT(IFNULL(NULLIF(TRIM(name), ''), ward) USING utf8) AS CHAR) AS name
        FROM ward
        WHERE (name IS NOT NULL AND TRIM(name) <> '') OR (ward IS NOT NULL AND TRIM(ward) <> '')
        ORDER BY name");
    $seen = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $n = trim((string)($r['name'] ?? ''));
            if ($n === '') {
                continue;
            }
            $key = function_exists('mb_strtolower') ? mb_strtolower($n, 'UTF-8') : strtolower($n);
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $cache[] = $n;
        }
    }
    @mysqli_close($hos);
    return $cache;
}

function med_error_fetch_visit_rooms($hos, $vn) {
    $vn = trim((string)$vn);
    if ($vn === '') {
        return ['rooms' => [], 'preferred' => ''];
    }
    $vn_esc = mysqli_real_escape_string($hos, $vn);
    $rooms = [];

    $ost_sqls = [
        "SELECT TRIM(os.department) AS depcode,
                CAST(CONVERT(COALESCE(NULLIF(TRIM(k.department),''), os.department) USING utf8) AS CHAR) AS dep_name,
                IFNULL(os.vsttime,'') AS vsttime
         FROM ovstost os
         LEFT JOIN kskdepartment k ON k.depcode = os.department
         WHERE os.vn = '$vn_esc'
           AND os.department IS NOT NULL AND TRIM(os.department) <> ''
         ORDER BY os.vsttime, os.department",
        "SELECT TRIM(os.depcode) AS depcode,
                CAST(CONVERT(COALESCE(NULLIF(TRIM(k.department),''), os.depcode) USING utf8) AS CHAR) AS dep_name,
                IFNULL(os.vsttime,'') AS vsttime
         FROM ovstost os
         LEFT JOIN kskdepartment k ON k.depcode = os.depcode
         WHERE os.vn = '$vn_esc'
           AND os.depcode IS NOT NULL AND TRIM(os.depcode) <> ''
         ORDER BY os.vsttime, os.depcode",
    ];
    foreach ($ost_sqls as $sql) {
        $q = @mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        $got = false;
        while ($r = mysqli_fetch_assoc($q)) {
            $got = true;
            $rooms[] = [
                'code' => trim((string)($r['depcode'] ?? '')),
                'name' => trim((string)($r['dep_name'] ?? '')),
                'time' => substr(trim((string)($r['vsttime'] ?? '')), 0, 8),
            ];
        }
        if ($got) {
            break;
        }
    }

    $ov = med_error_query_one($hos, "
        SELECT TRIM(IFNULL(o.main_dep,'')) AS main_dep,
               TRIM(IFNULL(o.cur_dep,'')) AS cur_dep,
               CAST(CONVERT(IFNULL(km.department,'') USING utf8) AS CHAR) AS main_name,
               CAST(CONVERT(IFNULL(kc.department,'') USING utf8) AS CHAR) AS cur_name,
               CAST(CONVERT(IFNULL(sp.name,'') USING utf8) AS CHAR) AS spclty_name
        FROM ovst o
        LEFT JOIN kskdepartment km ON km.depcode = o.main_dep
        LEFT JOIN kskdepartment kc ON kc.depcode = o.cur_dep
        LEFT JOIN spclty sp ON sp.spclty = o.spclty
        WHERE o.vn = '$vn_esc'
        LIMIT 1
    ");
    $preferred = '';
    if ($ov) {
        $cur_name = trim((string)($ov['cur_name'] ?? ''));
        $main_name = trim((string)($ov['main_name'] ?? ''));
        $sp_name = trim((string)($ov['spclty_name'] ?? ''));
        if ($cur_name !== '') {
            $rooms[] = ['code' => trim((string)$ov['cur_dep']), 'name' => $cur_name, 'time' => ''];
            $preferred = $cur_name;
        }
        if ($main_name !== '') {
            $rooms[] = ['code' => trim((string)$ov['main_dep']), 'name' => $main_name, 'time' => ''];
            if ($preferred === '') {
                $preferred = $main_name;
            }
        }
        if ($sp_name !== '' && $preferred === '') {
            $rooms[] = ['code' => '', 'name' => $sp_name, 'time' => ''];
            $preferred = $sp_name;
        }
    }

    $qdep = @mysqli_query($hos, "
        SELECT TRIM(o.dep_code) AS depcode,
               CAST(CONVERT(IFNULL(k.department, o.dep_code) USING utf8) AS CHAR) AS dep_name
        FROM opitemrece o
        LEFT JOIN kskdepartment k ON k.depcode = o.dep_code
        WHERE o.vn = '$vn_esc'
          AND o.dep_code IS NOT NULL AND TRIM(o.dep_code) <> ''
        GROUP BY o.dep_code
        LIMIT 20
    ");
    if ($qdep) {
        while ($r = mysqli_fetch_assoc($qdep)) {
            $rooms[] = [
                'code' => trim((string)($r['depcode'] ?? '')),
                'name' => trim((string)($r['dep_name'] ?? '')),
                'time' => '',
            ];
        }
    }

    $rooms = med_error_unique_rooms($rooms);
    if ($preferred === '' && $rooms) {
        $preferred = $rooms[0]['name'];
    }
    return ['rooms' => $rooms, 'preferred' => $preferred];
}

function med_error_query_one($hos, $sql) {
    $q = @mysqli_query($hos, $sql);
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return $r;
    }
    return null;
}

function med_error_hn_in_sql($hos, $hn) {
    $variants = med_error_hn_variants($hn);
    if (empty($variants)) {
        return '';
    }
    $in = [];
    foreach ($variants as $v) {
        $in[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return implode(',', $in);
}

function med_error_fetch_visit_context($hos, $in_sql, $date) {
    $empty = med_error_empty_visit_context();
    if ($in_sql === '') {
        return $empty;
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$date)) {
        $date = date('Y-m-d');
    }
    $d = mysqli_real_escape_string($hos, $date);

    $ipt_on_date = med_error_query_one($hos, "
        SELECT i.an, IFNULL(i.vn,'') AS vn,
               CAST(CONVERT(IFNULL(w.name,'') USING utf8) AS CHAR) AS ward_name
        FROM ipt i
        LEFT JOIN ward w ON w.ward = i.ward
        WHERE i.hn IN ($in_sql)
          AND i.an IS NOT NULL AND TRIM(i.an) <> ''
          AND i.regdate IS NOT NULL AND i.regdate != '0000-00-00'
          AND i.regdate <= '$d'
          AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00' OR i.dchdate >= '$d')
        ORDER BY i.regdate DESC, i.an DESC
        LIMIT 1
    ");
    $ovst_on_date = med_error_query_one($hos, "
        SELECT o.vn, IFNULL(o.an,'') AS an
        FROM ovst o
        WHERE o.hn IN ($in_sql)
          AND o.vstdate = '$d'
        ORDER BY CASE WHEN o.an IS NULL OR TRIM(o.an) = '' THEN 0 ELSE 1 END, o.vn DESC
        LIMIT 1
    ");

    $ipt = $ipt_on_date;
    $ovst = $ovst_on_date;
    if (!$ipt && !$ovst) {
        $ipt = med_error_query_one($hos, "
            SELECT i.an, IFNULL(i.vn,'') AS vn,
                   CAST(CONVERT(IFNULL(w.name,'') USING utf8) AS CHAR) AS ward_name
            FROM ipt i
            LEFT JOIN ward w ON w.ward = i.ward
            WHERE i.hn IN ($in_sql)
              AND i.an IS NOT NULL AND TRIM(i.an) <> ''
              AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00')
            ORDER BY i.regdate DESC, i.an DESC
            LIMIT 1
        ");
        if (!$ipt) {
            $ovst = med_error_query_one($hos, "
                SELECT o.vn, IFNULL(o.an,'') AS an
                FROM ovst o
                WHERE o.hn IN ($in_sql)
                ORDER BY o.vstdate DESC, o.vn DESC
                LIMIT 1
            ");
        }
    }

    $an = trim((string)(($ipt['an'] ?? '') ?: ''));
    $vn = trim((string)(($ovst['vn'] ?? '') ?: ''));
    if ($vn === '' && $ipt) {
        $vn = trim((string)($ipt['vn'] ?? ''));
    }
    $ovst_an = $ovst ? trim((string)($ovst['an'] ?? '')) : '';
    if ($an === '' && $ovst_an !== '') {
        $an = $ovst_an;
    }

    $has_an = $an !== '';
    $has_vn = $vn !== '';
    $suggested = '';
    if ($has_an) {
        $suggested = 'IPD';
    } elseif ($has_vn) {
        $suggested = 'OPD';
    }

    $ward_name = '';
    if ($an !== '') {
        $ward_name = med_error_fetch_ward_name($hos, $an, $date);
    }
    if ($ward_name === '' && $ipt) {
        $ward_name = trim((string)($ipt['ward_name'] ?? ''));
    }
    $room_info = $vn !== ''
        ? med_error_fetch_visit_rooms($hos, $vn)
        : ['rooms' => [], 'preferred' => ''];

    $doc = med_error_fetch_order_doctor($hos, $in_sql, $date, $vn, $an);

    return [
        'an' => $an,
        'vn' => $vn,
        'suggested_type' => $suggested,
        'ward_name' => $ward_name,
        'has_an' => $has_an,
        'has_vn' => $has_vn,
        'visit_rooms' => $room_info['rooms'],
        'preferred_room' => $room_info['preferred'],
        'order_doctor_code' => $doc['code'],
        'order_doctor_name' => $doc['name'],
        'order_doctor_group' => '',
    ];
}

function med_error_sanitize_intervention_module($value) {
    $value = trim((string)$value);
    if ($value === '') {
        return '';
    }
    $valid = med_error_intervention_modules();
    return isset($valid[$value]) ? $value : '';
}

function med_error_module_options_html($selected = '') {
    $html = '<option value="">- ไม่ระบุ / ไม่ใช่ Intervention log -</option>';
    foreach (med_error_intervention_modules() as $value => $label) {
        $sel = ($selected === $value) ? ' selected' : '';
        $html .= '<option value="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '"' . $sel . '>'
            . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</option>';
    }
    return $html;
}

function med_error_text_has_keyword($haystack, array $keywords) {
    $haystack = med_error_norm_text($haystack);
    if ($haystack === '') {
        return false;
    }
    foreach ($keywords as $kw) {
        $kw = med_error_norm_text($kw);
        if ($kw === '') {
            continue;
        }
        if (function_exists('mb_strpos')) {
            if (mb_strpos($haystack, $kw, 0, 'UTF-8') !== false) {
                return true;
            }
        } elseif (strpos($haystack, $kw) !== false) {
            return true;
        }
    }
    return false;
}

/**
 * กติกา map Med Error → Intervention module
 * เรียงจากเฉพาะเจาะจงไปกว้าง — กฎแรกที่เข้าเงื่อนไขจะถูกใช้
 * เพิ่มฟังก์ชันในอนาคต: ใส่ rule ใหม่ที่นี่ (module ต้องตรงกับ med_error_intervention_modules)
 *
 * คีย์ที่ใช้ได้:
 *   drug_keywords, type_keywords, desc_keywords  = อย่างน้อย 1 กลุ่มต้องตรง (ถ้ามี)
 *   patient_types, rx_types, had                 = ตัวกรอง ต้องตรงทุกข้อที่ระบุ
 */
function med_error_intervention_map_rules() {
    return [
        [
            'module' => 'Monitor Warfarin',
            'drug_keywords' => ['warfarin'],
        ],
        [
            'module' => 'Monitor HLA',
            'drug_keywords' => ['carbamazepine', 'allopurinol', 'abacavir', 'phenytoin', 'lamotrigine'],
            'desc_keywords' => ['hla', 'hla-b', 'ยีนแพ้ยา'],
        ],
        [
            'module' => 'Monitor Drug Allergy',
            'type_keywords' => ['แพ้', 'ห้ามใช้'],
            'desc_keywords' => ['แพ้ยา', 'drug allergy', 'allergy'],
        ],
        [
            'module' => 'Monitor Interaction',
            'desc_keywords' => ['interaction', 'อันตรกิริยา', 'drug interaction'],
        ],
        [
            'module' => 'Monitor คู่ยาซ้ำซ้อน',
            'type_keywords' => ['สั่งยาซ้ำ', 'ซ้ำซ้อน'],
            'desc_keywords' => ['duplicate', 'ซ้ำซ้อน', 'สั่งซ้ำ'],
        ],
        [
            'module' => 'Monitor วิธีใช้ยา',
            'type_keywords' => ['วิธีใช้', 'เส้นทาง'],
            'desc_keywords' => ['วิธีใช้ยา', 'route of administration'],
        ],
        [
            'module' => 'Monitor Max Dose',
            'type_keywords' => ['ผิดขนาด', 'ผิดความถี่', 'ผิดระยะเวลา'],
            'desc_keywords' => ['max dose', 'overdose', 'เกินขนาด'],
        ],
        [
            'module' => 'Monitor mg to mL',
            'desc_keywords' => ['mg to ml', 'mg/ml', 'แปลงหน่วย', 'mg → ml', 'mg->ml'],
        ],
        [
            'module' => 'Monitor ยาเด็ก',
            'desc_keywords' => ['ยาเด็ก', 'pediatric'],
        ],
        [
            'module' => 'Monitor Lab ไต',
            'desc_keywords' => ['ไต', 'egfr', 'creatinine', 'crcl', 'renal'],
        ],
        [
            'module' => 'Monitor Lab ตับ',
            'desc_keywords' => ['ตับ', 'alt', 'ast', 'liver'],
        ],
        [
            'module' => 'Monitor Antibiotic',
            'desc_keywords' => ['antibiotic', 'ยาปฏิชีวนะ'],
        ],
        [
            'module' => 'Monitor จำนวนสั่งยา',
            'patient_types' => ['OPD'],
            'type_keywords' => ['ผิดจำนวน', 'ไม่ครบ', 'เตรียมยาผิดจำนวน'],
        ],
        [
            'module' => 'Drug Reconciliation',
            'rx_types' => ['home'],
        ],
        [
            'module' => 'Smart Pharma',
            'desc_keywords' => ['smart pharma'],
        ],
    ];
}

function med_error_intervention_rule_match(array $rule, array $ctx) {
    if (!empty($rule['patient_types']) && !in_array($ctx['patient_type'] ?? '', $rule['patient_types'], true)) {
        return false;
    }
    if (!empty($rule['rx_types']) && !in_array($ctx['rx_type'] ?? '', $rule['rx_types'], true)) {
        return false;
    }
    if (!empty($rule['had']) && ($ctx['is_had'] ?? 'NO') !== 'YES') {
        return false;
    }

    $has_keyword = !empty($rule['drug_keywords']) || !empty($rule['type_keywords']) || !empty($rule['desc_keywords']);
    if (!$has_keyword) {
        return true;
    }

    if (!empty($rule['drug_keywords']) && med_error_text_has_keyword($ctx['drug_text'] ?? '', $rule['drug_keywords'])) {
        return true;
    }
    if (!empty($rule['type_keywords']) && med_error_text_has_keyword($ctx['type_text'] ?? '', $rule['type_keywords'])) {
        return true;
    }
    if (!empty($rule['desc_keywords']) && med_error_text_has_keyword($ctx['desc_text'] ?? '', $rule['desc_keywords'])) {
        return true;
    }
    return false;
}

function med_error_auto_map_intervention_module(array $ctx) {
    $drugs = is_array($ctx['drugs'] ?? null) ? $ctx['drugs'] : [];
    $drug_parts = [];
    foreach ($drugs as $d) {
        $drug_parts[] = trim((string)($d['label'] ?? ''));
        $drug_parts[] = trim((string)($d['name'] ?? ''));
        $drug_parts[] = trim((string)($d['strength'] ?? ''));
    }
    $packed = [
        'patient_type' => (string)($ctx['patient_type'] ?? ''),
        'rx_type' => (string)($ctx['rx_type'] ?? ''),
        'is_had' => (string)($ctx['is_had'] ?? 'NO'),
        'drug_text' => implode(' ', $drug_parts),
        'type_text' => trim((string)($ctx['category'] ?? '') . ' ' . (string)($ctx['type_name'] ?? '')),
        'desc_text' => trim((string)($ctx['description'] ?? '') . ' ' . (string)($ctx['solution'] ?? '')),
    ];
    foreach (med_error_intervention_map_rules() as $rule) {
        $module = med_error_sanitize_intervention_module($rule['module'] ?? '');
        if ($module === '') {
            continue;
        }
        if (med_error_intervention_rule_match($rule, $packed)) {
            return $module;
        }
    }
    return '';
}

function med_error_lookup_error_type($con, $type_id) {
    $type_id = (int)$type_id;
    if ($type_id <= 0) {
        return ['category' => '', 'name' => ''];
    }
    $q = mysqli_query($con, "SELECT category, name FROM med_error_types WHERE id=$type_id LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return [
            'category' => trim((string)($r['category'] ?? '')),
            'name' => trim((string)($r['name'] ?? '')),
        ];
    }
    return ['category' => '', 'name' => ''];
}

function med_error_hn_variants($hn) {
    $hn = trim((string)$hn);
    $out = [];
    if ($hn === '') {
        return $out;
    }
    $out[] = $hn;
    if (ctype_digit($hn)) {
        $pad = str_pad($hn, 9, '0', STR_PAD_LEFT);
        $trim = ltrim($hn, '0');
        if ($trim === '') {
            $trim = '0';
        }
        $out[] = $pad;
        $out[] = $trim;
    }
    return array_values(array_unique($out));
}

function med_error_fetch_patient_from_hosxp($con, $hn, $date = '') {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = hosxp_connect($con);
    if (!$hos) {
        return null;
    }
    mysqli_set_charset($hos, 'utf8');
    $in_sql = med_error_hn_in_sql($hos, $hn);
    if ($in_sql === '') {
        mysqli_close($hos);
        return null;
    }
    $sql = "SELECT hn,
                   CAST(CONVERT(IFNULL(pname,'') USING utf8) AS CHAR) AS pname,
                   CAST(CONVERT(IFNULL(fname,'') USING utf8) AS CHAR) AS fname,
                   CAST(CONVERT(IFNULL(lname,'') USING utf8) AS CHAR) AS lname
            FROM patient
            WHERE hn IN ($in_sql)
            LIMIT 1";
    $q = mysqli_query($hos, $sql);
    $row = ($q && mysqli_num_rows($q) > 0) ? mysqli_fetch_assoc($q) : null;
    $visit = $row ? med_error_fetch_visit_context($hos, $in_sql, $date) : med_error_empty_visit_context();
    mysqli_close($hos);
    if (!$row) {
        return null;
    }
    $pname = trim((string)($row['pname'] ?? ''));
    $fname = trim((string)($row['fname'] ?? ''));
    $lname = trim((string)($row['lname'] ?? ''));
    return array_merge([
        'hn' => (string)$row['hn'],
        'pname' => $pname,
        'fname' => $fname,
        'lname' => $lname,
        'full_name' => trim($pname . $fname . ' ' . $lname),
    ], $visit);
}

function med_error_lookup_patient_name($con, $hn) {
    $pt = med_error_fetch_patient_from_hosxp($con, $hn);
    return $pt ? $pt['full_name'] : '';
}

function med_error_fetch_consult_history($con, $hn, $limit = 20) {
    if (!$con) {
        return [];
    }
    $in = med_error_hn_in_sql($con, $hn);
    if ($in === '') {
        return [];
    }
    $lim = max(1, min(50, (int)$limit));
    $sql = "SELECT m.id, m.incident_date, m.description, m.solution, m.patient_type, m.an, m.vn,
                   m.order_doctor_name, m.reporting_dept, m.error_dept, u.full_name AS reporter_name
            FROM med_error_records m
            LEFT JOIN users u ON m.reporter_id = u.id
            WHERE IFNULL(m.record_kind,'error') = 'consult'
              AND m.hn IN ($in)
            ORDER BY m.incident_date DESC, m.id DESC
            LIMIT {$lim}";
    $q = @mysqli_query($con, $sql);
    $out = [];
    if (!$q) {
        return $out;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $ts = !empty($r['incident_date']) ? strtotime($r['incident_date']) : false;
        $be = '';
        $tm = '';
        if ($ts) {
            $be = date('d/m/', $ts) . ((int)date('Y', $ts) + 543);
            $tm = date('H:i', $ts);
        }
        $ptype = strtoupper(trim((string)($r['patient_type'] ?? '')));
        $out[] = [
            'id' => (int)($r['id'] ?? 0),
            'incident_date' => $ts ? date('Y-m-d', $ts) : '',
            'incident_time' => $tm,
            'incident_date_th' => $be,
            'patient_type' => $ptype,
            'an' => trim((string)($r['an'] ?? '')),
            'vn' => trim((string)($r['vn'] ?? '')),
            'doctor_name' => trim((string)($r['order_doctor_name'] ?? '')),
            'place' => trim((string)($r['reporting_dept'] ?? '')),
            'error_dept' => trim((string)($r['error_dept'] ?? '')),
            'description' => trim((string)($r['description'] ?? '')),
            'solution' => trim((string)($r['solution'] ?? '')),
            'reporter_name' => trim((string)($r['reporter_name'] ?? '')),
        ];
    }
    return $out;
}

function med_error_drug_label($name, $strength) {
    $name = trim((string)$name);
    $strength = trim((string)$strength);
    if ($name === '') {
        return $strength;
    }
    if ($strength !== '' && stripos($name, $strength) === false) {
        return trim($name . ' ' . $strength);
    }
    return $name;
}

function med_error_map_drug_row(array $r) {
    $icode = trim((string)($r['icode'] ?? ''));
    $name = trim((string)($r['name'] ?? ''));
    $strength = trim((string)($r['strength'] ?? ''));
    $label = med_error_drug_label($name, $strength);
    if ($icode === '' || $label === '') {
        return null;
    }
    return [
        'icode' => $icode,
        'name' => $name,
        'strength' => $strength,
        'label' => $label,
    ];
}

function med_error_parse_drugs($raw) {
    if (is_array($raw)) {
        $decoded = $raw;
    } else {
        $raw = trim((string)$raw);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return [];
        }
    }
    $out = [];
    $seen = [];
    foreach ($decoded as $row) {
        if (!is_array($row)) {
            continue;
        }
        $d = med_error_map_drug_row([
            'icode' => $row['icode'] ?? '',
            'name' => $row['name'] ?? ($row['label'] ?? ''),
            'strength' => $row['strength'] ?? '',
        ]);
        if (!$d) {
            continue;
        }
        if (isset($seen[$d['icode']])) {
            continue;
        }
        $seen[$d['icode']] = true;
        $out[] = $d;
    }
    return $out;
}

function med_error_drugs_json(array $drugs) {
    return json_encode(array_values($drugs), JSON_UNESCAPED_UNICODE);
}

function med_error_drugs_list_text(array $drugs) {
    $names = [];
    foreach ($drugs as $d) {
        $label = trim((string)($d['label'] ?? $d['name'] ?? ''));
        if ($label !== '') {
            $names[] = $label;
        }
    }
    return implode(', ', $names);
}

function med_error_norm_text($text) {
    $text = function_exists('mb_strtolower') ? mb_strtolower(trim((string)$text), 'UTF-8') : strtolower(trim((string)$text));
    $text = preg_replace('/\s+/u', ' ', $text);
    return trim((string)$text);
}

function med_error_text_tokens($text) {
    $text = preg_replace('/[^\p{L}\p{N}\.\-\+\/%]+/u', ' ', (string)$text);
    $parts = preg_split('/\s+/u', trim((string)$text));
    $out = [];
    $clean = [];
    foreach ($parts as $p) {
        $p = trim((string)$p);
        if ($p === '') {
            continue;
        }
        $clean[] = $p;
        $len = function_exists('mb_strlen') ? mb_strlen($p, 'UTF-8') : strlen($p);
        if ($len >= 4) {
            $out[] = $p;
        }
    }
    $n = count($clean);
    for ($i = 0; $i < $n - 1; $i++) {
        $combo = $clean[$i] . ' ' . $clean[$i + 1];
        $len = function_exists('mb_strlen') ? mb_strlen($combo, 'UTF-8') : strlen($combo);
        if ($len >= 5) {
            $out[] = $combo;
        }
    }
    return array_values(array_unique($out));
}

function med_error_search_drugs($hos, $term, $limit = 30) {
    $term = trim((string)$term);
    if ($term === '') {
        return [];
    }
    $t = mysqli_real_escape_string($hos, $term);
    $limit = max(1, min(40, (int)$limit));
    $sql = "SELECT d.icode,
                   CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS name,
                   CAST(CONVERT(IFNULL(d.strength,'') USING utf8) AS CHAR) AS strength
            FROM drugitems d
            WHERE d.istatus = 'Y'
              AND (d.name LIKE '%$t%' OR IFNULL(d.strength,'') LIKE '%$t%' OR d.icode LIKE '%$t%')
            ORDER BY d.name ASC
            LIMIT $limit";
    $q = @mysqli_query($hos, $sql);
    $list = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $d = med_error_map_drug_row($r);
            if ($d) {
                $list[] = $d;
            }
        }
    }
    return $list;
}

function med_error_visit_drugs($hos, $hn, $an, $vn, $date) {
    $where = [];
    $hn_sql = med_error_hn_in_sql($hos, $hn);
    if ($hn_sql !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$date)) {
        $d = mysqli_real_escape_string($hos, $date);
        $where[] = "(o.hn IN ($hn_sql) AND o.vstdate = '$d')";
    }
    $an = trim((string)$an);
    if ($an !== '') {
        $where[] = "o.an = '" . mysqli_real_escape_string($hos, $an) . "'";
    }
    $vn = trim((string)$vn);
    if ($vn !== '') {
        $where[] = "o.vn = '" . mysqli_real_escape_string($hos, $vn) . "'";
    }
    if (!$where) {
        return [];
    }
    $sql = "SELECT DISTINCT d.icode,
                   CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS name,
                   CAST(CONVERT(IFNULL(d.strength,'') USING utf8) AS CHAR) AS strength
            FROM opitemrece o
            INNER JOIN drugitems d ON d.icode = o.icode
            WHERE o.qty > 0
              AND (" . implode(' OR ', $where) . ")
            LIMIT 80";
    $q = @mysqli_query($hos, $sql);
    $list = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $d = med_error_map_drug_row($r);
            if ($d) {
                $list[] = $d;
            }
        }
    }
    return $list;
}

function med_error_mb_pos($haystack, $needle) {
    if ($needle === '' || $haystack === '') {
        return false;
    }
    if (function_exists('mb_strpos')) {
        return mb_strpos($haystack, $needle, 0, 'UTF-8');
    }
    $p = strpos($haystack, $needle);
    return $p === false ? false : $p;
}

function med_error_strength_number($strength) {
    $s = trim((string)$strength);
    if ($s === '') {
        return '';
    }
    if (preg_match('/(\d+(?:[.,]\d+)?)/u', $s, $m)) {
        return str_replace(',', '.', $m[1]);
    }
    return '';
}

function med_error_text_has_number($text, $num) {
    $num = trim((string)$num);
    if ($num === '') {
        return true;
    }
    $q = preg_quote($num, '/');
    return (bool)preg_match('/(?<!\d)' . $q . '(?:\.0+)?(?!\d)/u', (string)$text);
}

function med_error_drug_base_key(array $d) {
    $name = med_error_norm_text($d['name'] ?? $d['label'] ?? '');
    $name = preg_replace('/\d+(?:[.,]\d+)?/u', ' ', $name);
    $name = preg_replace('/\b(mg|mcg|g|ml|tab|cap|inj)\b/iu', ' ', $name);
    $name = preg_replace('/\s+/u', ' ', $name);
    return trim($name);
}

function med_error_spell_variants($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return [];
    }
    $out = [$text];
    $pairs = [
        'acyclovir' => 'aciclovir',
        'aciclovir' => 'acyclovir',
        'amoxycillin' => 'amoxicillin',
        'amoxicillin' => 'amoxycillin',
        'paracetamol' => 'acetaminophen',
        'acetaminophen' => 'paracetamol',
        'frusemide' => 'furosemide',
        'furosemide' => 'frusemide',
        'salbutamol' => 'albuterol',
        'albuterol' => 'salbutamol',
        'co-amoxiclav' => 'amoxicillin clavulanate',
        'augmentin' => 'amoxicillin clavulanate',
    ];
    $lower = med_error_norm_text($text);
    foreach ($pairs as $from => $to) {
        if (med_error_mb_pos($lower, $from) !== false) {
            $out[] = preg_replace('/' . preg_quote($from, '/') . '/iu', $to, $text);
        }
    }
    return array_values(array_unique($out));
}

function med_error_alpha_tokens($text) {
    $norm = med_error_norm_text($text);
    $norm = preg_replace('/[^a-z0-9ก-๙\s]/u', ' ', $norm);
    $parts = preg_split('/\s+/u', trim((string)$norm));
    $out = [];
    foreach ($parts as $p) {
        $p = trim((string)$p);
        $len = function_exists('mb_strlen') ? mb_strlen($p, 'UTF-8') : strlen($p);
        if ($p === '' || $len < 4) {
            continue;
        }
        if (preg_match('/^\d/', $p)) {
            continue;
        }
        $out[] = $p;
    }
    return array_values(array_unique($out));
}

function med_error_text_has_strength_hint($text) {
    return (bool)preg_match('/\d+(?:[.,]\d+)?\s*(mg|mcg|g|ml|iu|หน่วย)?/iu', (string)$text);
}

function med_error_name_token_in_text(array $d, $norm) {
    $chunks = [
        (string)($d['name'] ?? ''),
        (string)($d['label'] ?? ''),
        med_error_drug_base_key($d),
    ];
    foreach ($chunks as $chunk) {
        foreach (med_error_alpha_tokens($chunk) as $tok) {
            if (preg_match('/(?<![\p{L}\p{N}])' . preg_quote($tok, '/') . '(?![\p{L}\p{N}])/u', $norm)) {
                return true;
            }
        }
    }
    return false;
}

function med_error_memory_phrase_ok($phrase) {
    $phrase = med_error_norm_text($phrase);
    $len = function_exists('mb_strlen') ? mb_strlen($phrase, 'UTF-8') : strlen($phrase);
    if ($len < 3 || $len > 120) {
        return false;
    }
    if (strpos($phrase, '__') === 0) {
        return false;
    }
    static $stop = [
        'แต่' => true, 'จ่าย' => true, 'สั่ง' => true, 'แพทย์' => true, 'ยา' => true,
        'เป็น' => true, 'ควร' => true, 'mg' => true, 'tab' => true, 'cap' => true,
        'และ' => true, 'หรือ' => true, 'ให้' => true, 'ได้' => true, 'คือ' => true,
    ];
    return empty($stop[$phrase]);
}

function med_error_memory_keys($text) {
    $keys = [];
    foreach (med_error_spell_variants($text) as $v) {
        $n = med_error_norm_text($v);
        if (med_error_memory_phrase_ok($n)) {
            $keys[] = $n;
        }
        foreach (med_error_alpha_tokens($v) as $tok) {
            if (med_error_memory_phrase_ok($tok)) {
                $keys[] = $tok;
            }
        }
    }
    return array_values(array_unique($keys));
}

function med_error_memory_learn_phrase($con, $phrase, array $d) {
    $phrase = med_error_norm_text($phrase);
    if (!med_error_memory_phrase_ok($phrase) || empty($d['icode'])) {
        return;
    }
    $icode = mysqli_real_escape_string($con, (string)$d['icode']);
    $name = mysqli_real_escape_string($con, (string)($d['name'] ?? ''));
    $strength = mysqli_real_escape_string($con, (string)($d['strength'] ?? ''));
    $ph = mysqli_real_escape_string($con, $phrase);
    mysqli_query($con, "INSERT INTO med_error_drug_memory (phrase, icode, name, strength, hit_count, last_used_at)
        VALUES ('$ph', '$icode', '$name', '$strength', 1, NOW())
        ON DUPLICATE KEY UPDATE
            hit_count = hit_count + 1,
            last_used_at = NOW(),
            name = VALUES(name),
            strength = VALUES(strength)");
}

function med_error_memory_learn_side($con, $text, array $drugs) {
    if (!$drugs) {
        return;
    }
    $keys = med_error_memory_keys($text);
    foreach ($drugs as $d) {
        if (!is_array($d) || empty($d['icode'])) {
            continue;
        }
        $mapped = med_error_map_drug_row($d) ?: $d;
        foreach ($keys as $k) {
            med_error_memory_learn_phrase($con, $k, $mapped);
        }
        med_error_memory_learn_phrase($con, $mapped['label'] ?? '', $mapped);
        med_error_memory_learn_phrase($con, $mapped['name'] ?? '', $mapped);
        med_error_memory_learn_phrase($con, med_error_drug_base_key($mapped), $mapped);
        $toks = med_error_alpha_tokens($mapped['name'] ?? $mapped['label'] ?? '');
        if (!empty($toks[0])) {
            med_error_memory_learn_phrase($con, $toks[0], $mapped);
        }
    }
}

function med_error_memory_learn($con, $description, $solution, array $error_drugs, array $correct_drugs) {
    if (!$con) {
        return;
    }
    $split = med_error_split_desc_for_drugs($description, $solution);
    med_error_memory_learn_side($con, $split['error'], $error_drugs);
    med_error_memory_learn_side($con, $split['correct'] !== '' ? $split['correct'] : $solution, $correct_drugs);
}

function med_error_memory_candidates($con, $text) {
    if (!$con) {
        return [];
    }
    $keys = med_error_memory_keys($text);
    if (!$keys) {
        return [];
    }
    $in = [];
    foreach ($keys as $k) {
        $in[] = "'" . mysqli_real_escape_string($con, $k) . "'";
    }
    $sql = "SELECT icode, name, strength, hit_count
            FROM med_error_drug_memory
            WHERE phrase IN (" . implode(',', $in) . ")
            ORDER BY hit_count DESC, last_used_at DESC
            LIMIT 40";
    $q = mysqli_query($con, $sql);
    $out = [];
    $seen = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            if (trim((string)($r['icode'] ?? '')) === '-' || (int)($r['hit_count'] ?? 0) <= 0) {
                continue;
            }
            $d = med_error_map_drug_row($r);
            if (!$d || isset($seen[$d['icode']])) {
                continue;
            }
            $seen[$d['icode']] = true;
            $d['hit_count'] = (int)($r['hit_count'] ?? 1);
            $out[] = $d;
        }
    }
    return $out;
}

function med_error_memory_backfill($con) {
    static $done = false;
    if ($done || !$con) {
        return;
    }
    $done = true;
    $qc = @mysqli_query($con, "SELECT COUNT(*) AS c FROM med_error_drug_memory");
    if ($qc && ($rr = mysqli_fetch_assoc($qc)) && (int)$rr['c'] > 0) {
        return;
    }
    $q = @mysqli_query($con, "SELECT description, solution, error_drugs, correct_drugs, record_kind
        FROM med_error_records
        ORDER BY id ASC
        LIMIT 2000");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            if (med_error_sanitize_record_kind($r['record_kind'] ?? 'error') === 'consult') {
                continue;
            }
            med_error_memory_learn(
                $con,
                (string)($r['description'] ?? ''),
                (string)($r['solution'] ?? ''),
                med_error_parse_drugs($r['error_drugs'] ?? '[]'),
                med_error_parse_drugs($r['correct_drugs'] ?? '[]')
            );
        }
    }
    $qc2 = @mysqli_query($con, "SELECT COUNT(*) AS c FROM med_error_drug_memory");
    if ($qc2 && ($rr2 = mysqli_fetch_assoc($qc2)) && (int)$rr2['c'] === 0) {
        mysqli_query($con, "INSERT IGNORE INTO med_error_drug_memory (phrase, icode, name, strength, hit_count, last_used_at)
            VALUES ('__seeded__', '-', '', '', 0, NOW())");
    }
}

function med_error_drug_match_score(array $d, $norm, $text_has_strength = true, array $preferred = []) {
    $name = med_error_norm_text($d['name'] ?? '');
    $label = med_error_norm_text($d['label'] ?? '');
    $strength = trim((string)($d['strength'] ?? ''));
    $nlen = function_exists('mb_strlen') ? mb_strlen($name, 'UTF-8') : strlen($name);
    if ($nlen < 4 && $label === '') {
        return 0;
    }
    $has_label = $label !== '' && med_error_mb_pos($norm, $label) !== false;
    $has_name = $name !== '' && med_error_mb_pos($norm, $name) !== false;
    $word_hit = med_error_name_token_in_text($d, $norm);
    if (!$has_label && !$has_name && !$word_hit) {
        return 0;
    }
    $num = med_error_strength_number($strength !== '' ? $strength : $label);
    $has_str = med_error_text_has_number($norm, $num);
    $score = 0;
    if ($has_label && $has_str) {
        $score = 100;
    } elseif ($has_name && $has_str && $num !== '') {
        $score = 90;
    } elseif ($word_hit && $has_str && $num !== '' && $text_has_strength) {
        $score = 88;
    } elseif (($has_name || $word_hit) && !$text_has_strength) {
        $score = 78;
    } elseif ($has_name && $num === '') {
        $score = 78;
    } elseif ($has_label) {
        $score = 40;
    } elseif ($word_hit) {
        $score = 25;
    }
    $icode = (string)($d['icode'] ?? '');
    if ($score >= 70 && $icode !== '' && isset($preferred[$icode])) {
        $score += 15;
    }
    return $score;
}

function med_error_pick_drugs_from_candidates($text, array $candidates, array $preferred = []) {
    $norm = med_error_norm_text($text);
    if ($norm === '') {
        return [];
    }
    $text_has_strength = med_error_text_has_strength_hint($text);
    $best = [];
    foreach ($candidates as $d) {
        if (!is_array($d) || empty($d['icode'])) {
            continue;
        }
        $score = med_error_drug_match_score($d, $norm, $text_has_strength, $preferred);
        if ($score < 70) {
            continue;
        }
        $key = med_error_drug_base_key($d);
        if ($key === '') {
            $key = $d['icode'];
        }
        $label = (string)($d['label'] ?? $d['name'] ?? '');
        $llen = function_exists('mb_strlen') ? mb_strlen($label, 'UTF-8') : strlen($label);
        $pref = isset($preferred[$d['icode']]) ? 0 : 1;
        $hits = -1 * (int)($d['hit_count'] ?? 0);
        $rank = [$pref, $hits, $llen];
        if (!isset($best[$key]) || $score > $best[$key]['score'] || ($score === $best[$key]['score'] && $rank < $best[$key]['rank'])) {
            $best[$key] = ['score' => $score, 'rank' => $rank, 'drug' => $d];
        }
    }
    $out = [];
    $seen = [];
    foreach ($best as $row) {
        $icode = $row['drug']['icode'];
        if (isset($seen[$icode])) {
            continue;
        }
        $seen[$icode] = true;
        $out[] = $row['drug'];
    }
    return $out;
}

function med_error_clean_drug_phrase($text) {
    $text = trim((string)$text);
    $text = preg_replace('/^(?:ยา|เป็นยา|เป็น|คือ|ว่า)\s*/iu', '', $text);
    $text = preg_replace('/\s*(?:แทน|ให้ผู้ป่วย|แก่ผู้ป่วย|ไปแล้ว|แล้ว)$/iu', '', $text);
    return trim($text);
}

function med_error_split_desc_for_drugs($description, $solution = '') {
    $description = trim((string)$description);
    $solution = trim((string)$solution);
    $error_text = $description;
    $correct_text = $solution;

    $rules = [
        [
            're' => '/(?:แพทย์\s*)?(?:ได้\s*)?(?:สั่ง(?:ยา)?|order(?:ed)?|prescribe[d]?|ควรได้(?:รับ)?(?:ยา)?|ควรเป็น)\s*(.+?)\s*(?:แต่|,|แล้ว)\s*(?:ไป)?(?:จ่าย|จัด|ได้(?:รับ)?|ให้|dispense[d]?)\s*(?:เป็น|ยา)?\s*(.+)$/iu',
            'correct' => 1,
            'error' => 2,
        ],
        [
            're' => '/(?:จ่าย|จัด|ให้)(?:ยา)?(?:ผิด)?\s*(?:เป็น)?\s*(.+?)\s*(?:แต่|,)\s*(?:ควรได้(?:รับ)?(?:ยา)?|ควรเป็น|ที่ถูกต้อง(?:คือ)?|ถูกต้องคือ|ยาที่ถูกต้อง(?:คือ)?)\s*(.+)$/iu',
            'error' => 1,
            'correct' => 2,
        ],
        [
            're' => '/(?:จ่าย|จัด|ให้)(?:ยา)?\s*(?:เป็น)?\s*(.+?)\s*(?:แทน(?:ที่)?(?:ด้วย)?|แทนยา)\s*(.+)$/iu',
            'error' => 1,
            'correct' => 2,
        ],
        [
            're' => '/^(.+?)\s*แต่(?:ไป)?(?:จ่าย|จัด|ให้)(?:ยา)?\s*(?:เป็น)?\s*(.+)$/iu',
            'correct' => 1,
            'error' => 2,
        ],
        [
            're' => '/^(.*?)(?:ควรได้รับ|ควรได้เป็น|ควรเป็น|ที่ถูกต้องคือ|ยาที่ถูกต้อง|ชื่อยาที่ถูกต้อง|ถูกต้องคือ|ถูกคือ|ถูกเป็น|เปลี่ยนเป็น|แก้เป็น|แก้ไขเป็น|แทนด้วย|แทนที่ด้วย|แทนยา|แทน)\s*(.+)$/iu',
            'error' => 1,
            'correct' => 2,
        ],
    ];

    foreach ($rules as $rule) {
        if ($description === '' || !preg_match($rule['re'], $description, $m)) {
            continue;
        }
        $err = med_error_clean_drug_phrase($m[$rule['error']] ?? '');
        $ok = med_error_clean_drug_phrase($m[$rule['correct']] ?? '');
        if ($err === '' && $ok === '') {
            continue;
        }
        if ($err !== '') {
            $error_text = $err;
        }
        if ($ok !== '') {
            $correct_text = trim($ok . ' ' . $solution);
        }
        break;
    }

    return [
        'error' => $error_text,
        'correct' => $correct_text,
    ];
}

function med_error_drugs_from_text($hos, $text, $hn = '', $an = '', $vn = '', $date = '', $con = null) {
    $text = trim((string)$text);
    if ($text === '') {
        return [];
    }
    $candidates = med_error_visit_drugs($hos, $hn, $an, $vn, $date);
    $preferred = [];
    $memory = med_error_memory_candidates($con, $text);
    foreach ($memory as $d) {
        $candidates[] = $d;
        $preferred[$d['icode']] = true;
    }
    $terms = [];
    foreach (med_error_spell_variants($text) as $v) {
        $plain = preg_replace('/\s+/u', ' ', $v);
        if ($plain !== '') {
            $terms[] = $plain;
        }
        foreach (med_error_text_tokens($v) as $tok) {
            if (!preg_match('/^\d+(?:[.,]\d+)?(?:\s*(mg|mcg|g|ml))?$/iu', $tok)) {
                $terms[] = $tok;
            }
        }
        foreach (med_error_alpha_tokens($v) as $tok) {
            $terms[] = $tok;
        }
    }
    $likes = [];
    foreach (array_slice(array_unique($terms), 0, 16) as $tok) {
        $e = mysqli_real_escape_string($hos, $tok);
        $likes[] = "d.name LIKE '%$e%'";
        $likes[] = "CONCAT(IFNULL(d.name,''),' ',IFNULL(d.strength,'')) LIKE '%$e%'";
    }
    if ($likes) {
        $sql = "SELECT d.icode,
                       CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS name,
                       CAST(CONVERT(IFNULL(d.strength,'') USING utf8) AS CHAR) AS strength
                FROM drugitems d
                WHERE d.istatus = 'Y'
                  AND (" . implode(' OR ', $likes) . ")
                ORDER BY CHAR_LENGTH(d.name) ASC
                LIMIT 80";
        $q = @mysqli_query($hos, $sql);
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $d = med_error_map_drug_row($r);
                if ($d) {
                    $candidates[] = $d;
                }
            }
        }
    }
    return med_error_pick_drugs_from_candidates($text, $candidates, $preferred);
}
