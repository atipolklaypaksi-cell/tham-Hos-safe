<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/med_error_helper.php';
mysqli_set_charset($con, 'utf8');
med_error_ensure_tables($con);

$action = isset($_POST['action']) ? $_POST['action'] : (isset($_GET['action']) ? $_GET['action'] : '');

if ($action === 'add') {
    $category = mysqli_real_escape_string($con, trim((string)($_POST['category'] ?? '')));
    $name = mysqli_real_escape_string($con, trim((string)($_POST['name'] ?? '')));
    if ($category === '' || $name === '') {
        echo "<script>alert('กรุณาระบุหมวดหมู่และชื่อหัวข้อ'); window.location.href='med_error.php';</script>";
        exit;
    }
    $chk = mysqli_query($con, "SELECT id FROM med_error_types WHERE category='$category' AND name='$name' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        echo "<script>alert('มีหัวข้อนี้ในระบบแล้ว'); window.location.href='med_error.php';</script>";
        exit;
    }
    mysqli_query($con, "INSERT INTO med_error_types (category, name) VALUES ('$category', '$name')");
    echo "<script>alert('เพิ่มหัวข้อสำเร็จ'); window.location.href='med_error.php';</script>";
} elseif ($action === 'edit') {
    $id = (int)($_POST['type_id'] ?? 0);
    $category = mysqli_real_escape_string($con, trim((string)($_POST['category'] ?? '')));
    $name = mysqli_real_escape_string($con, trim((string)($_POST['name'] ?? '')));
    if ($id <= 0 || $category === '' || $name === '') {
        echo "<script>alert('ข้อมูลไม่ครบถ้วน'); window.location.href='med_error.php';</script>";
        exit;
    }
    mysqli_query($con, "UPDATE med_error_types SET category='$category', name='$name' WHERE id=$id");
    echo "<script>alert('แก้ไขหัวข้อสำเร็จ'); window.location.href='med_error.php';</script>";
} elseif ($action === 'delete') {
    $id = (int)($_GET['id'] ?? 0);
    $chk = mysqli_query($con, "SELECT id FROM med_error_records WHERE error_type_id=$id LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        echo "<script>alert('ไม่สามารถลบได้ เพราะหัวข้อนี้ถูกใช้บันทึกประวัติแล้ว แนะนำให้แก้ไขชื่อแทน'); window.location.href='med_error.php';</script>";
    } else {
        mysqli_query($con, "DELETE FROM med_error_types WHERE id=$id");
        echo "<script>alert('ลบหัวข้อสำเร็จ'); window.location.href='med_error.php';</script>";
    }
} elseif ($action === 'had_add') {
    $ajax = (isset($_POST['ajax']) && (string)$_POST['ajax'] === '1')
        || (isset($_GET['ajax']) && (string)$_GET['ajax'] === '1');
    $res = med_error_add_had_drug(
        $con,
        $_POST['icode'] ?? '',
        $_POST['name'] ?? '',
        $_POST['strength'] ?? ''
    );
    if ($ajax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($res, JSON_UNESCAPED_UNICODE);
        mysqli_close($con);
        exit;
    }
    $msg = $res['message'] ?? (($res['ok'] ?? false) ? 'เพิ่มยา HAD สำเร็จ' : 'ไม่สามารถเพิ่มยา HAD ได้');
    echo "<script>alert(" . json_encode($msg, JSON_UNESCAPED_UNICODE) . "); window.location.href='med_error.php';</script>";
} elseif ($action === 'had_delete') {
    $ajax = (isset($_POST['ajax']) && (string)$_POST['ajax'] === '1')
        || (isset($_GET['ajax']) && (string)$_GET['ajax'] === '1');
    $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
    $ok = med_error_delete_had_drug($con, $id);
    if ($ajax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'ok' => $ok,
            'id' => $id,
            'message' => $ok ? 'ลบยา HAD สำเร็จ' : 'ไม่สามารถลบยา HAD ได้',
        ], JSON_UNESCAPED_UNICODE);
        mysqli_close($con);
        exit;
    }
    echo "<script>alert(" . json_encode($ok ? 'ลบยา HAD สำเร็จ' : 'ไม่สามารถลบยา HAD ได้', JSON_UNESCAPED_UNICODE) . "); window.location.href='med_error.php';</script>";
} elseif ($action === 'had_sync') {
    $res = med_error_sync_had_from_hosxp($con);
    $msg = $res['message'] ?? (($res['ok'] ?? false) ? 'ดึงยา HAD สำเร็จ' : 'ดึงยา HAD ไม่สำเร็จ');
    echo "<script>alert(" . json_encode($msg, JSON_UNESCAPED_UNICODE) . "); window.location.href='med_error.php';</script>";
} elseif ($action === 'doctor_group_save') {
    $ajax = (isset($_POST['ajax']) && (string)$_POST['ajax'] === '1')
        || (isset($_GET['ajax']) && (string)$_GET['ajax'] === '1');
    $res = med_error_save_doctor_group(
        $con,
        $_POST['doctor_code'] ?? '',
        $_POST['doctor_name'] ?? '',
        $_POST['group_key'] ?? ''
    );
    if ($ajax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($res, JSON_UNESCAPED_UNICODE);
        mysqli_close($con);
        exit;
    }
    $msg = $res['message'] ?? (($res['ok'] ?? false) ? 'บันทึกกลุ่มแพทย์สำเร็จ' : 'ไม่สามารถบันทึกกลุ่มแพทย์ได้');
    echo "<script>alert(" . json_encode($msg, JSON_UNESCAPED_UNICODE) . "); window.location.href='med_error.php';</script>";
} elseif ($action === 'doctor_group_delete') {
    $ajax = (isset($_POST['ajax']) && (string)$_POST['ajax'] === '1')
        || (isset($_GET['ajax']) && (string)$_GET['ajax'] === '1');
    $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
    $ok = med_error_delete_doctor_group($con, $id);
    if ($ajax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'ok' => $ok,
            'id' => $id,
            'message' => $ok ? 'ลบกลุ่มแพทย์สำเร็จ' : 'ไม่สามารถลบกลุ่มแพทย์ได้',
        ], JSON_UNESCAPED_UNICODE);
        mysqli_close($con);
        exit;
    }
    echo "<script>alert(" . json_encode($ok ? 'ลบกลุ่มแพทย์สำเร็จ' : 'ไม่สามารถลบกลุ่มแพทย์ได้', JSON_UNESCAPED_UNICODE) . "); window.location.href='med_error.php';</script>";
} else {
    header('Location: med_error.php');
}
mysqli_close($con);
