<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
// เมนู Monitor UA ถูกถอดออกจากระบบ
header('Location: home.php');
exit;
