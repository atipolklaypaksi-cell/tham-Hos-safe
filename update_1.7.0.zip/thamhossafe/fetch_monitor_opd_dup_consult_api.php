<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
session_write_close();
include(__DIR__ . '/monitor_opd_dup_consult_helper.php');
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
mysqli_set_charset($con, 'utf8');

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

$actor_id = (int)($_SESSION['user_id'] ?? 0);
$actor_name = trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? ''));
$action = $_POST['action'] ?? $_GET['action'] ?? '';

mopdc_ensure_tables($con);

function mopdc_api_parse_cases() {
    $cases = [];
    if (!empty($_POST['cases_json'])) {
        $decoded = json_decode((string)$_POST['cases_json'], true);
        if (is_array($decoded)) {
            $cases = $decoded;
        }
    }
    if (empty($cases)) {
        $cases[] = $_POST;
    }
    return $cases;
}

function mopdc_api_ensure_id($con, array $case, $actor_id) {
    $id = (int)($case['consult_id'] ?? 0);
    if ($id > 0) {
        return $id;
    }
    $up = mopdc_upsert_from_case($con, $case, [
        'created_by' => $actor_id,
        'updated_by' => $actor_id,
    ]);
    return !empty($up['ok']) ? (int)$up['id'] : 0;
}

if ($action === 'pharmacists') {
    ob_clean();
    echo json_encode([
        'status' => 'success',
        'pharmacists' => mopdc_list_pharmacists($con, $actor_id),
        'current_user_id' => $actor_id,
        'current_user_name' => $actor_name,
        'reply_wait_days' => mopdc_get_reply_wait_days($con),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'history') {
    $rows = mopdc_list_history($con, [
        'consult_id' => (int)($_GET['consult_id'] ?? $_POST['consult_id'] ?? 0),
        'hn' => $_GET['hn'] ?? $_POST['hn'] ?? '',
        'limit' => (int)($_GET['limit'] ?? $_POST['limit'] ?? 100),
    ]);
    ob_clean();
    echo json_encode(['status' => 'success', 'history' => $rows, 'count' => count($rows)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'start' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $pharmacist_id = (int)($_POST['pharmacist_user_id'] ?? $actor_id);
    $pharmacist_name = trim((string)($_POST['pharmacist_name'] ?? ''));
    $note = trim((string)($_POST['consult_note'] ?? ''));
    $wait = isset($_POST['reply_wait_days'])
        ? mopdc_normalize_reply_wait_days($_POST['reply_wait_days'])
        : mopdc_get_reply_wait_days($con);
    $ids = [];
    $consults = [];
    $errors = [];
    foreach (mopdc_api_parse_cases() as $case) {
        if (!is_array($case)) {
            continue;
        }
        $res = mopdc_start_consult($con, $case, $pharmacist_id, $pharmacist_name, $note, $actor_id, $wait, $actor_name);
        if (!empty($res['ok'])) {
            $ids[] = (int)$res['id'];
            $consults[] = $res['consult'];
        } else {
            $errors[] = $res['error'] ?? 'ไม่สำเร็จ';
        }
    }
    if (empty($ids)) {
        ob_clean();
        echo json_encode([
            'status' => 'error',
            'message' => $errors ? implode('; ', $errors) : 'ไม่สามารถเริ่ม Consult ได้',
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $synced = sp_sync_consult_to_intervention($con, 'opd_dup', $consults, [
        'actor_id' => $actor_id,
        'actor_name' => $actor_name !== '' ? $actor_name : $pharmacist_name,
        'action' => 'start',
        'note' => $note,
        'note_text' => trim((string)($_POST['note_text'] ?? '')),
        'intervention_type' => trim((string)($_POST['intervention_type'] ?? 'recommend')),
        'deviation_category' => trim((string)($_POST['deviation_category'] ?? '')),
        'consult_result' => trim((string)($_POST['consult_result'] ?? '')),
        'force_new' => true,
    ]);
    $mute_case = $consults[0] ?? [];
    $mute_msg = sp_alert_mute_from_intervention($con, [
        'deviation_category' => $_POST['deviation_category'] ?? '',
        'mute_visit' => $_POST['mute_visit'] ?? 0,
        'hn' => $mute_case['hn'] ?? '',
        'vn' => $mute_case['vn'] ?? '',
        'an' => $mute_case['an'] ?? '',
        'patient_type' => 'OPD',
    ], $actor_id, $actor_name !== '' ? $actor_name : $pharmacist_name);
    if (empty($synced['ok'])) {
        ob_clean();
        echo json_encode([
            'status' => 'error',
            'message' => $synced['message'] ?? 'บันทึก Intervention ไม่สำเร็จ',
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    ob_clean();
    echo json_encode([
        'status' => 'success',
        'message' => 'บันทึก Intervention ' . (int)($synced['count'] ?? 1) . ' รายการแล้ว' . ($mute_msg !== '' ? ' — ' . $mute_msg : ''),
        'intervention_count' => (int)($synced['count'] ?? 0),
        'ids' => $ids,
        'consults' => $consults,
        'print_url' => 'monitor_opd_dup_consult_print.php?ids=' . implode(',', $ids),
        'id' => $ids[0],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'close' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $pharmacist_id = (int)($_POST['pharmacist_user_id'] ?? $actor_id);
    $pharmacist_name = trim((string)($_POST['pharmacist_name'] ?? ''));
    $note = trim((string)($_POST['consult_note'] ?? ''));
    $doctor_reply = trim((string)($_POST['doctor_reply'] ?? ''));
    $done = 0;
    $last = null;
    $consults = [];
    foreach (mopdc_api_parse_cases() as $case) {
        if (!is_array($case)) {
            continue;
        }
        $id = mopdc_api_ensure_id($con, $case, $actor_id);
        if ($id <= 0) {
            continue;
        }
        $res = mopdc_close_consult($con, $id, $note, $doctor_reply, $actor_id, $actor_name, $pharmacist_id, $pharmacist_name);
        if (!empty($res['ok'])) {
            $done++;
            $last = $res;
            if (!empty($res['consult'])) {
                $consults[] = $res['consult'];
            }
        }
    }
    if ($done > 0) {
        sp_sync_consult_to_intervention($con, 'opd_dup', $consults, [
            'actor_id' => $actor_id,
            'actor_name' => $actor_name !== '' ? $actor_name : $pharmacist_name,
            'action' => 'close',
            'note' => $note !== '' ? $note : $doctor_reply,
        ]);
    }
    ob_clean();
    echo json_encode([
        'status' => $done > 0 ? 'success' : 'error',
        'message' => $done > 0 ? ('ปิด Consult ' . $done . ' รายการแล้ว') : ($last['error'] ?? 'ปิดไม่สำเร็จ'),
        'consult' => $last['consult'] ?? null,
        'count' => $done,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_result' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $pharmacist_id = (int)($_POST['pharmacist_user_id'] ?? $actor_id);
    $pharmacist_name = trim((string)($_POST['pharmacist_name'] ?? ''));
    $note = trim((string)($_POST['consult_note'] ?? ''));
    $doctor_reply = trim((string)($_POST['doctor_reply'] ?? ''));
    $done = 0;
    $last = null;
    $consults = [];
    foreach (mopdc_api_parse_cases() as $case) {
        if (!is_array($case)) {
            continue;
        }
        $id = mopdc_api_ensure_id($con, $case, $actor_id);
        if ($id <= 0) {
            continue;
        }
        $res = mopdc_save_result($con, $id, $note, $doctor_reply, $actor_id, $actor_name, $pharmacist_id, $pharmacist_name);
        if (!empty($res['ok'])) {
            $done++;
            $last = $res;
            if (!empty($res['consult'])) {
                $consults[] = $res['consult'];
            }
        }
    }
    if ($done > 0) {
        sp_sync_consult_to_intervention($con, 'opd_dup', $consults, [
            'actor_id' => $actor_id,
            'actor_name' => $actor_name !== '' ? $actor_name : $pharmacist_name,
            'action' => 'save_result',
            'note' => $note !== '' ? $note : $doctor_reply,
        ]);
    }
    ob_clean();
    echo json_encode([
        'status' => $done > 0 ? 'success' : 'error',
        'message' => $done > 0 ? ('บันทึกผล Consult ' . $done . ' รายการแล้ว') : ($last['error'] ?? 'บันทึกไม่สำเร็จ'),
        'consult' => $last['consult'] ?? null,
        'count' => $done,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'reset_waiting' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $note = trim((string)($_POST['consult_note'] ?? ''));
    $done = 0;
    $last = null;
    foreach (mopdc_api_parse_cases() as $case) {
        if (!is_array($case)) {
            continue;
        }
        $id = mopdc_api_ensure_id($con, $case, $actor_id);
        if ($id <= 0) {
            continue;
        }
        $res = mopdc_reset_waiting($con, $id, $actor_id, $note, $actor_name);
        if (!empty($res['ok'])) {
            $done++;
            $last = $res;
        }
    }
    ob_clean();
    echo json_encode([
        'status' => $done > 0 ? 'success' : 'error',
        'message' => $done > 0 ? ('ตั้งเป็นรอ Consult ' . $done . ' รายการแล้ว') : ($last['error'] ?? 'ไม่สำเร็จ'),
        'consult' => $last['consult'] ?? null,
        'count' => $done,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

ob_clean();
echo json_encode(['status' => 'error', 'message' => 'Unknown action'], JSON_UNESCAPED_UNICODE);
exit;
