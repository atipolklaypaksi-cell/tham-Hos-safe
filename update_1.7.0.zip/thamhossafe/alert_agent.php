<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/alert_agent_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}

$files = tham_alert_agent_list_files();
$h = function ($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
};
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ดาวน์โหลด THAM Notify - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .agent-card { border: none; border-radius: 14px; box-shadow: 0 4px 14px rgba(0,0,0,.06); }
        .step-num {
            width: 28px; height: 28px; border-radius: 50%;
            background: #dcfce7; color: #166534; font-weight: 800;
            display: inline-flex; align-items: center; justify-content: center;
            font-size: .85rem;
        }
        pre.cfg {
            background: #0f2419; color: #bbf7d0; border-radius: 10px;
            padding: 14px 16px; font-size: .82rem; overflow: auto;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-3">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
                <div>
                    <h4 class="fw-bold mb-1"><i class="fas fa-bell me-2 text-success"></i>THAM Notify</h4>
                    <div class="text-muted">โปรแกรมแจ้งเตือนบนเครื่อง — เปิดใช้เองแบบ SCPH Notify รับ consult / เตือนยา แม้ไม่ได้เปิดเว็บ THAM Hos-Safe</div>
                </div>
            </div>

            <div class="alert alert-success border-0 shadow-sm">
                <div class="fw-bold mb-1">ใช้แบบเดียวกับ SCPH Notify</div>
                <div>ดาวน์โหลดแล้ว <strong>เปิดโปรแกรมครั้งแรก</strong> จะขึ้นหน้าต่างและถาดระบบ และเปิดพร้อม Windows ครั้งถัดไป — กดปิดหน้าต่างแล้วยังทำงานอยู่ที่ถาดระบบ คนที่ไม่ได้อยู่หน้าเครื่องใช้ <strong>Telegram</strong></div>
            </div>

            <div class="card agent-card mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-2"><i class="fas fa-download me-2 text-success"></i>ดาวน์โหลด THAM Notify</h6>
                    <?php if ($files): ?>
                    <?php
                    $notify = [];
                    $bestVer = '';
                    foreach ($files as $cand) {
                        if (stripos($cand['name'], 'THAM-Notify') === false || stripos($cand['name'], 'Alert-Agent') !== false) {
                            continue;
                        }
                        $cand['version'] = tham_alert_agent_parse_version($cand['name']);
                        if ($cand['version'] !== '' && ($bestVer === '' || version_compare($cand['version'], $bestVer, '>'))) {
                            $bestVer = $cand['version'];
                        }
                        $notify[] = $cand;
                    }
                    $latest = null;
                    foreach ($notify as $cand) {
                        if ($bestVer !== '' && $cand['version'] !== $bestVer) {
                            continue;
                        }
                        if (!$latest) {
                            $latest = $cand;
                            continue;
                        }
                        $ext = strtolower(pathinfo($cand['name'], PATHINFO_EXTENSION));
                        $cur = strtolower(pathinfo($latest['name'], PATHINFO_EXTENSION));
                        if ($ext === 'zip' && $cur !== 'zip') {
                            $latest = $cand;
                        }
                    }
                    if (!$latest) {
                        $latest = $files[0];
                    }
                    $latestVer = tham_alert_agent_parse_version($latest['name']);
                    $latestExt = strtolower(pathinfo($latest['name'], PATHINFO_EXTENSION));
                    $older = array_values(array_filter($files, function ($f) use ($latest) {
                        return $f['name'] !== $latest['name'];
                    }));
                    ?>
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>ไฟล์</th>
                                    <th>ขนาด</th>
                                    <th>อัปเดต</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="table-success">
                                    <td>
                                        <span class="badge bg-success me-1">ส่งให้ IT</span>
                                        <span class="fw-bold"><?php echo $h($latest['name']); ?></span>
                                    </td>
                                    <td><?php echo $h(tham_alert_agent_format_size($latest['size'])); ?></td>
                                    <td><?php echo $latest['mtime'] ? date('d/m/Y H:i', $latest['mtime']) : '—'; ?></td>
                                    <td class="text-end">
                                        <a class="btn btn-success btn-sm fw-bold" href="alert_agent_file.php?file=<?php echo rawurlencode($latest['name']); ?>">
                                            <i class="fas fa-download me-1"></i>ดาวน์โหลด
                                        </a>
                                    </td>
                                </tr>
                            <?php foreach ($older as $f): ?>
                                <tr class="text-muted">
                                    <td>
                        <span class="badge bg-secondary me-1">เวอร์ชันเก่า</span>
                        <?php echo $h($f['name']); ?>
                        <div class="small"><?php
                            if (strpos($f['name'], 'Alert-Agent') !== false) {
                                echo 'ชุดเก่าที่ AV จับพฤติกรรม — อย่าใช้';
                            } elseif (strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) === 'exe') {
                                echo 'ไฟล์ .exe — Chrome มักบล็อกเพราะเว็บเป็น HTTP';
                            } else {
                                echo 'ไม่ต้องส่งให้ IT';
                            }
                        ?></div>
                                    </td>
                                    <td><?php echo $h(tham_alert_agent_format_size($f['size'])); ?></td>
                                    <td><?php echo $f['mtime'] ? date('d/m/Y H:i', $f['mtime']) : '—'; ?></td>
                                    <td class="text-end">
                                        <a class="btn btn-outline-secondary btn-sm" href="alert_agent_file.php?file=<?php echo rawurlencode($f['name']); ?>">ดาวน์โหลด</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-muted">
                        ยังไม่มีไฟล์ติดตั้งในระบบ วางไฟล์ <code>.exe</code> / <code>.msi</code> / <code>.zip</code>
                        ในโฟลเดอร์ <code>downloads/</code> ของเซิร์ฟเวอร์ แล้วรีเฟรชหน้านี้
                    </div>
                    <?php endif; ?>
                    <div class="small text-muted mt-3">
                        เวอร์ชันล่าสุดคือ <strong><?php echo $h($latestVer !== '' ? $latestVer : $latest['name']); ?></strong>
                        ให้โหลด <code><?php echo $h($latest['name']); ?></code>
                        <?php echo $latestExt === 'zip' ? 'แล้วแตกไฟล์ เปิดไฟล์ .exe ข้างใน' : 'แล้วเปิดไฟล์'; ?>
                        ครั้งแรก จากนั้นจะเปิดพร้อม Windows กดออกแล้วยังทำงาน และอัปเดตเองเมื่อมีเวอร์ชันใหม่
                    </div>
                    <div class="alert alert-info mt-3 mb-0">
                        <div class="fw-bold mb-2">เวอร์ชัน 1.1.4 กดออกจากโปรแกรมแล้วยังทำงาน และถูกเปิดกลับทุก 5 นาที</div>
                        <ul class="mb-2 ps-3">
                            <li>มีเสียงเมื่อมี Alert และแถบใหญ่สีเหลืองมุมขวาล่าง ค้าง 25 วินาที หรือคลิกเพื่อปิด</li>
                            <li>เมื่อเซิร์ฟเวอร์มีเวอร์ชันใหม่กว่า เครื่องจะโหลดแล้วเปิดใหม่เองที่ถาดระบบ</li>
                            <li>เปิดครั้งแรกแล้วเริ่มพร้อม Windows กดปิดแล้วยังทำงานที่ถาดระบบ</li>
                        </ul>
                        <div class="small">ส่งให้ IT: <code><?php echo $h($latest['name']); ?></code> คู่กับใบ <code>THAM-Notify-IT.txt</code> — อย่าส่ง THAM-Alert-Agent-1.0.x (ชุดเก่าที่ Kaspersky จับพฤติกรรม) และอย่าส่งไฟล์ zip ของเวอร์ชันเก่ากว่า</div>
                    </div>
                    <div class="alert alert-warning mt-3 mb-0">
                        <div class="fw-bold mb-2">ทำไมไฟล์ .exe ถูก Block แต่ SCPH Notify ไม่โดน</div>
                        <ol class="mb-0 ps-3">
                            <li class="mb-1">หน้านี้เป็น <b>HTTP ไม่ใช่ HTTPS</b> Chrome จึงบล็อกการโหลดไฟล์ <b>.exe</b> ที่ยังไม่ได้ลงนาม (ขึ้น Needs permission to download)</li>
                            <li class="mb-1"><b>SCPH Notify</b> ติดตั้งไว้ในเครื่องแล้ว และถูกตั้งให้เปิดพร้อม Windows อยู่แล้ว จึงไม่ต้องโหลด .exe จากหน้านี้ซ้ำ</li>
                            <li>ให้โหลด <b><?php echo $h($latest['name']); ?></b><?php echo $latestExt === 'zip' ? ' แล้วแตกไฟล์ เปิดไฟล์ .exe ข้างใน' : ''; ?> ครั้งเดียว ถ้า Windows ถาม กด <b>More info</b> แล้ว <b>Run anyway</b> ไฟล์ที่ส่งคือ .zip ของเวอร์ชันล่าสุด เพื่อไม่ให้ Chrome และโปรแกรมกันไวรัสบล็อกตอนดาวน์โหลด</li>
                        </ol>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-md-6 col-xl-3">
                    <div class="card agent-card h-100">
                        <div class="card-body">
                            <div class="fw-bold"><i class="fas fa-procedures me-1 text-danger"></i> Ward</div>
                            <div class="small text-muted mt-1">จอหอผู้ป่วย — รับ consult จากเภสัชกรที่ส่งจากเว็บ THAM</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="card agent-card h-100">
                        <div class="card-body">
                            <div class="fw-bold"><i class="fas fa-user-md me-1 text-primary"></i> Doctor</div>
                            <div class="small text-muted mt-1">เครื่องแพทย์ที่เปิด HOSxP OPD — รับเตือนขณะคีย์ยา / รับ consult</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="card agent-card h-100">
                        <div class="card-body">
                            <div class="fw-bold"><i class="fas fa-pills me-1 text-success"></i> Pharmacy OPD</div>
                            <div class="small text-muted mt-1">ช่องจ่ายยาผู้ป่วยนอก — เตือนเมื่อใบยาเข้าเงื่อนไข</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="card agent-card h-100">
                        <div class="card-body">
                            <div class="fw-bold"><i class="fas fa-hospital me-1 text-warning"></i> Pharmacy IPD</div>
                            <div class="small text-muted mt-1">ห้องยาผู้ป่วยใน — เตือนขณะคีย์คำสั่งใช้ยา</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card agent-card mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-3">ควรทำเป็นระยะ</h6>
                    <div class="d-flex gap-2 mb-2"><span class="step-num">1</span><div><strong>Consult จากเว็บ THAM</strong> — กดส่งเคสแล้วยิงไปจอหอผู้ป่วย / เครื่องแพทย์ / Telegram โดยไม่ต้องอ่าน HOSxP Master</div></div>
                    <div class="d-flex gap-2 mb-2"><span class="step-num">2</span><div><strong>เปิด THAM Notify ที่เครื่องครั้งแรก</strong> — หน้าต่าง + ถาดระบบ เปิดพร้อม Windows ให้แล้ว กดปิดหน้าต่างแล้วยังทำงานอยู่ ผูกห้อง (Ward) หรือชื่อเครื่อง</div></div>
                    <div class="d-flex gap-2"><span class="step-num">3</span><div><strong>ดักการคีย์ยา HOSxP</strong> — Master อ่าน icode ช่วงวินาทีล่าสุด, Slave เติมชื่อ/แล็บ — เปิดปิดได้ที่ <a href="alert_settings.php">Alert pipelines</a></div></div>
                </div>
            </div>

            <div class="card agent-card mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-2">ตัวอย่างค่าตั้งที่เครื่อง</h6>
                    <pre class="cfg mb-2">{
  "ServerUrl": "http://<?php echo $h($_SERVER['HTTP_HOST'] ?? 'tham-server'); ?><?php echo $h(rtrim(dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/thamhossafe')), '/')); ?>/fetch_tham_alert_api.php",
  "ClientType": "Doctor",
  "StationId": "AUTO_MACHINE_NAME",
  "GroupName": "WARD_MED_1"
}</pre>
                    <div class="small text-muted">
                        — รายการเครื่องที่ติดตั้งอยู่ที่ <a href="alert_agent_machines.php">ตั้งค่าระบบ → เครื่อง Alert Agent</a>
                        · เปิด/ปิด pipeline ที่ <a href="alert_settings.php">Alert pipelines</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
