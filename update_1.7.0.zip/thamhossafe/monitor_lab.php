<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) { header("Location: login.php"); exit; }

$organ = $MONITOR_LAB_ORGAN ?? null;
if ($organ === null) {
    $redirect = 'monitor_lab_renal.php';
    if (isset($_GET['tab'])) {
        $redirect .= '?tab=' . urlencode($_GET['tab']);
        if (isset($_GET['del'])) {
            $redirect .= '&del=' . urlencode($_GET['del']);
        }
    }
    header("Location: $redirect");
    exit;
}
if (!in_array($organ, ['renal', 'hepatic', 'other'], true)) {
    header("Location: monitor_lab_renal.php");
    exit;
}

include('connect.php');
include('hosxp_tmt_drug_helper.php');
require_once __DIR__ . '/monitor_lab_renal_dosing_helper.php';
require_once __DIR__ . '/monitor_lab_hepatic_dosing_helper.php';
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
mysqli_set_charset($con, "utf8");
ensure_drug_safety_rules_duration_columns($con);
ensure_drug_safety_rules_dose_per_admin_columns($con);
ensure_drug_safety_rules_exempt_method_columns($con);
ensure_drug_safety_rules_first_order_columns($con);

function monitor_lab_resolve_drug_id($con, $icode) {
    $icode_esc = mysqli_real_escape_string($con, $icode);
    $q = mysqli_query($con, "SELECT id FROM drugitems WHERE icode = '$icode_esc' LIMIT 1");
    if ($q && $r = mysqli_fetch_assoc($q)) {
        return (int)$r['id'];
    }
    return 0;
}

function monitor_lab_parse_drug_post($con) {
    $parsed = hosxp_parse_drug_option($_POST['drug_hosxp'] ?? '');
    if ($parsed['icode'] === '') {
        return null;
    }
    return [
        'icode' => mysqli_real_escape_string($con, $parsed['icode']),
        'name' => mysqli_real_escape_string($con, $parsed['name']),
        'drug_id' => monitor_lab_resolve_drug_id($con, $parsed['icode']),
    ];
}

function monitor_lab_parse_lab_post($con) {
    $parsed = hosxp_parse_lab_option($_POST['lab_hosxp'] ?? '');
    if ($parsed['code'] === '') {
        return null;
    }
    $codes = monitor_lab_parse_codes($parsed['code']);
    $extra = monitor_lab_parse_codes($_POST['lab_extra_codes'] ?? '');
    if (!empty($extra)) {
        $codes = array_values(array_unique(array_merge($codes, $extra)));
    }
    return [
        'code' => mysqli_real_escape_string($con, implode(',', $codes)),
        'name' => mysqli_real_escape_string($con, $parsed['name']),
    ];
}

function monitor_lab_allowed_condition_types() {
    return ['range', 'regex', 'contains', 'less_than', 'greater_than'];
}

function monitor_lab_parse_condition_post($con) {
    $type = trim($_POST['lab_condition_type'] ?? 'range');
    if (!in_array($type, monitor_lab_allowed_condition_types(), true)) {
        $type = 'range';
    }
    $value = trim($_POST['lab_condition_value'] ?? '');
    if ($type !== 'range' && $value === '') {
        return null;
    }
    return [
        'type' => mysqli_real_escape_string($con, $type),
        'value' => mysqli_real_escape_string($con, $value),
    ];
}

$is_renal = ($organ === 'renal');
$is_hepatic = ($organ === 'hepatic');
$is_other = ($organ === 'other');
$page_file = $is_renal ? 'monitor_lab_renal.php' : ($is_hepatic ? 'monitor_lab_hepatic.php' : 'monitor_lab_other.php');
$page_title = $is_renal ? 'Monitor Lab ไต (Renal)' : ($is_hepatic ? 'Monitor Lab ตับ (Hepatic)' : 'Monitor Lab อื่นๆ');
$page_icon = $is_renal ? 'fa-heartbeat text-primary' : ($is_hepatic ? 'fa-lungs text-warning' : 'fa-vial text-info');
$lab_value_col = $is_renal ? 'ค่า GFR ล่าสุด' : ($is_hepatic ? 'ค่าตับล่าสุด' : 'ค่า Lab ล่าสุด');
$lab_col_w = $is_hepatic ? '20%' : '12%';
$lab_col_w_rx = $is_hepatic ? '22%' : '14%';
$table_class = $is_renal ? 'table-renal' : ($is_hepatic ? 'table-hepatic' : 'table-other');
$form_border = $is_renal ? 'border-primary' : ($is_hepatic ? 'border-warning' : 'border-info');
$form_header_bg = $is_renal ? 'bg-primary' : ($is_hepatic ? 'bg-warning text-dark' : 'bg-info text-dark');
$summary_border = $is_renal ? '#0d6efd' : ($is_hepatic ? '#ffc107' : '#0dcaf0');

function monitor_lab_page_url($query = '') {
    global $page_file;
    return $page_file . ($query !== '' ? '?' . $query : '');
}

$lab_page_tab = 'monitor';
if (isset($_GET['tab']) && $_GET['tab'] === 'settings') {
    $lab_page_tab = 'settings';
} elseif ($is_hepatic && isset($_GET['tab']) && $_GET['tab'] === 'scores') {
    $lab_page_tab = 'scores';
}
$lab_settings_tab = ($lab_page_tab === 'settings');
$lab_scores_tab = ($lab_page_tab === 'scores');

$lab_type_labels = [
    'GFR' => 'CrCl',
    'CKD_EPI' => 'CKD-EPI',
    'SERUM_CR' => 'Serum Cr',
    'Bilirubin' => 'T.Bili',
    'Bilirubin_xULN' => 'T.Bili×ULN',
    'DirectBilirubin' => 'D.Bili',
    'IndirectBilirubin' => 'I.Bili',
    'AST' => 'AST',
    'ALT' => 'ALT',
    'AST_xULN' => 'AST×ULN',
    'ALT_xULN' => 'ALT×ULN',
    'AST_ALT_xULN' => 'Max×ULN',
    'CHILD_PUGH' => 'Child-Pugh',
    'MELD_NA' => 'MELD-Na',
    'CUSTOM' => 'Lab อื่นๆ',
];

$renal_lab_types = ['GFR', 'CKD_EPI', 'SERUM_CR'];
$hepatic_lab_types = ['Bilirubin', 'Bilirubin_xULN', 'DirectBilirubin', 'IndirectBilirubin', 'AST', 'ALT', 'AST_xULN', 'ALT_xULN', 'AST_ALT_xULN', 'CHILD_PUGH', 'MELD_NA'];
$other_lab_types = ['CUSTOM'];
$organ_lab_types = $is_renal ? $renal_lab_types : ($is_hepatic ? $hepatic_lab_types : $other_lab_types);
$organ_lab_types_sql = "'" . implode("','", array_map(function ($t) use ($con) {
    return mysqli_real_escape_string($con, $t);
}, $organ_lab_types)) . "'";

function buildDoseSql($con, $use_dose) {
    if (!$use_dose) {
        return ['dose_min' => 'NULL', 'dose_max' => 'NULL', 'dose_unit' => 'NULL'];
    }
    $dose_min = mysqli_real_escape_string($con, $_POST['dose_min'] ?? '');
    $dose_max = mysqli_real_escape_string($con, $_POST['dose_max'] ?? '');
    return [
        'dose_min' => ($dose_min !== '') ? "'$dose_min'" : 'NULL',
        'dose_max' => ($dose_max !== '') ? "'$dose_max'" : 'NULL',
        'dose_unit' => "'mg'",
    ];
}

function buildDosePerAdminSql($con, $use_dose_per_admin) {
    if (!$use_dose_per_admin) {
        return ['dose_per_admin_min' => 'NULL', 'dose_per_admin_max' => 'NULL'];
    }
    $dose_min = mysqli_real_escape_string($con, $_POST['dose_per_admin_min'] ?? '');
    $dose_max = mysqli_real_escape_string($con, $_POST['dose_per_admin_max'] ?? '');
    return [
        'dose_per_admin_min' => ($dose_min !== '') ? "'$dose_min'" : 'NULL',
        'dose_per_admin_max' => ($dose_max !== '') ? "'$dose_max'" : 'NULL',
    ];
}

function buildDurationSql($con, $use_duration) {
    if (!$use_duration) {
        return ['duration_min' => 'NULL', 'duration_max' => 'NULL'];
    }
    $duration_min = mysqli_real_escape_string($con, $_POST['duration_min'] ?? '');
    $duration_max = mysqli_real_escape_string($con, $_POST['duration_max'] ?? '');
    return [
        'duration_min' => ($duration_min !== '') ? "'$duration_min'" : 'NULL',
        'duration_max' => ($duration_max !== '') ? "'$duration_max'" : 'NULL',
    ];
}

function buildPatientExtraSql($con, $is_renal) {
    if (!$is_renal) {
        return [
            'use_age' => '0', 'age_min' => 'NULL', 'age_max' => 'NULL',
            'use_weight' => '0', 'weight_min' => 'NULL', 'weight_max' => 'NULL',
        ];
    }
    $use_age = isset($_POST['use_age_condition']) ? 1 : 0;
    $use_weight = isset($_POST['use_weight_condition']) ? 1 : 0;
    $age_min = mysqli_real_escape_string($con, $_POST['age_min'] ?? '');
    $age_max = mysqli_real_escape_string($con, $_POST['age_max'] ?? '');
    $weight_min = mysqli_real_escape_string($con, $_POST['weight_min'] ?? '');
    $weight_max = mysqli_real_escape_string($con, $_POST['weight_max'] ?? '');
    return [
        'use_age' => "'$use_age'",
        'age_min' => ($age_min !== '') ? "'$age_min'" : 'NULL',
        'age_max' => ($age_max !== '') ? "'$age_max'" : 'NULL',
        'use_weight' => "'$use_weight'",
        'weight_min' => ($weight_min !== '') ? "'$weight_min'" : 'NULL',
        'weight_max' => ($weight_max !== '') ? "'$weight_max'" : 'NULL',
    ];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'import_egfr' && $is_renal) {
    $con_hosxp = hosxp_connect($con);
    if (!$con_hosxp) {
        $_SESSION['error'] = 'ไม่สามารถเชื่อมต่อ HOSxP ได้ — ตรวจสอบที่ตั้งค่า HOSxP';
        header("Location: " . monitor_lab_page_url('tab=settings')); exit;
    }
    $res = monitor_lab_import_egfr_from_hosxp($con, $con_hosxp);
    mysqli_close($con_hosxp);
    if (!empty($res['ok'])) {
        $msg = 'นำเข้า Lab eGFR จาก HOSxP — เพิ่ม ' . (int)$res['inserted'] . ' รายการ (ข้ามที่มีแล้ว ' . (int)$res['skipped'] . ')';
        if (!empty($res['unmatched_names'])) {
            $msg .= ' · ไม่พบยาที่เปิดใช้: ' . implode(', ', $res['unmatched_names']);
        }
        if (!empty($res['ckd_epi_codes'])) {
            $msg .= ' · รหัส Lab CKD-EPI: ' . $res['ckd_epi_codes'];
        }
        $_SESSION['msg'] = $msg;
        sp_monitor_settings_changed($con, 'lab_renal');
    } else {
        $_SESSION['error'] = $res['message'] ?? 'นำเข้าไม่สำเร็จ';
    }
    header("Location: " . monitor_lab_page_url('tab=settings')); exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'import_renal_dosing' && $is_renal) {
    $con_hosxp = hosxp_connect($con);
    if (!$con_hosxp) {
        $_SESSION['error'] = 'ไม่สามารถเชื่อมต่อ HOSxP ได้ — ตรวจสอบที่ตั้งค่า HOSxP';
        header("Location: " . monitor_lab_page_url('tab=settings')); exit;
    }
    $res = monitor_lab_import_renal_dosing_catalog($con, $con_hosxp);
    mysqli_close($con_hosxp);
    if (!empty($res['ok'])) {
        $msg = 'นำเข้ายาที่ต้องปรับในผู้ป่วยไต — เพิ่ม ' . (int)$res['inserted'] . ' รายการ (ข้ามที่มีแล้ว ' . (int)$res['skipped'] . ')';
        if (!empty($res['unmatched_names'])) {
            $msg .= ' · ไม่พบยา: ' . implode(', ', $res['unmatched_names']);
        }
        $_SESSION['msg'] = $msg;
        sp_monitor_settings_changed($con, 'lab_renal');
    } else {
        $_SESSION['error'] = $res['message'] ?? 'นำเข้าไม่สำเร็จ';
    }
    header("Location: " . monitor_lab_page_url('tab=settings')); exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'import_hepatic_dosing' && $is_hepatic) {
    $con_hosxp = hosxp_connect($con);
    if (!$con_hosxp) {
        $_SESSION['error'] = 'ไม่สามารถเชื่อมต่อ HOSxP ได้ — ตรวจสอบที่ตั้งค่า HOSxP';
        header("Location: " . monitor_lab_page_url('tab=settings')); exit;
    }
    $res = monitor_lab_import_hepatic_dosing_catalog($con, $con_hosxp);
    mysqli_close($con_hosxp);
    if (!empty($res['ok'])) {
        $msg = 'นำเข้ายาที่ต้องปรับ/ห้ามใช้ตาม Child-Pugh และ MELD-Na — เพิ่ม ' . (int)$res['inserted'] . ' รายการ (ข้ามที่มีแล้ว ' . (int)$res['skipped'] . ')';
        if (!empty($res['unmatched_names'])) {
            $msg .= ' · ไม่พบยา: ' . implode(', ', $res['unmatched_names']);
        }
        $_SESSION['msg'] = $msg;
        sp_monitor_settings_changed($con, 'lab_hepatic');
    } else {
        $_SESSION['error'] = $res['message'] ?? 'นำเข้าไม่สำเร็จ';
    }
    header("Location: " . monitor_lab_page_url('tab=settings')); exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $lab_type_raw = $is_other ? 'CUSTOM' : ($_POST['lab_type'] ?? '');
    if (!in_array($lab_type_raw, $organ_lab_types, true)) {
        $_SESSION['error'] = 'ประเภท Lab ไม่ถูกต้องสำหรับหน้านี้';
        header("Location: " . monitor_lab_page_url('tab=settings')); exit;
    }
    $drug = monitor_lab_parse_drug_post($con);
    if ($drug === null) {
        $_SESSION['error'] = 'กรุณาเลือกรายการยาจาก HOSxP';
        header("Location: " . monitor_lab_page_url('tab=settings')); exit;
    }
    $lab_items_sql = '';
    $lab_cond_sql = '';
    $lab_cond_vals = '';
    if ($is_other) {
        $lab_item = monitor_lab_parse_lab_post($con);
        if ($lab_item === null) {
            $_SESSION['error'] = 'กรุณาเลือกรายการ Lab จาก HOSxP';
            header("Location: " . monitor_lab_page_url('tab=settings')); exit;
        }
        $lab_items_sql = ", lab_items_code, lab_items_name";
        $lab_items_vals = ", '{$lab_item['code']}', '{$lab_item['name']}'";
        $lab_cond = monitor_lab_parse_condition_post($con);
        if ($lab_cond === null) {
            $_SESSION['error'] = 'กรุณาระบุค่าที่ต้องการดักจับสำหรับเงื่อนไขข้อความ';
            header("Location: " . monitor_lab_page_url('tab=settings')); exit;
        }
        $lab_cond_sql = ', lab_condition_type, lab_condition_value';
        $lab_cond_vals = ", '{$lab_cond['type']}', " . ($lab_cond['value'] !== '' ? "'{$lab_cond['value']}'" : 'NULL');
    } else {
        $lab_items_vals = '';
    }
    $lab_type = mysqli_real_escape_string($con, $lab_type_raw);
    $min_val = mysqli_real_escape_string($con, $_POST['min_val'] ?? '0');
    $max_val = mysqli_real_escape_string($con, $_POST['max_val']);
    $action_type = mysqli_real_escape_string($con, $_POST['action_type']);
    $action_value = mysqli_real_escape_string($con, $_POST['action_value'] ?? 0);
    $msg = mysqli_real_escape_string($con, $_POST['suggestion_msg']);
    $alert_level = (($_POST['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
    $use_dose = isset($_POST['use_dose_condition']) ? 1 : 0;
    $dose = buildDoseSql($con, $use_dose);
    $use_dose_per_admin = isset($_POST['use_dose_per_admin_condition']) ? 1 : 0;
    $dose_per_admin = buildDosePerAdminSql($con, $use_dose_per_admin);
    $use_duration = isset($_POST['use_duration_condition']) ? 1 : 0;
    $duration = buildDurationSql($con, $use_duration);
    $exempt_patterns = monitor_lab_normalize_exempt_patterns($_POST['exempt_method_patterns'] ?? '');
    $exempt_sql = $exempt_patterns !== '' ? "'" . mysqli_real_escape_string($con, $exempt_patterns) . "'" : 'NULL';
    $extra = buildPatientExtraSql($con, $is_renal);
    $active_status = isset($_POST['active_status']) ? 1 : 0;
    $first_order_only = isset($_POST['first_order_only']) ? 1 : 0;
    $first_order_lookback = $first_order_only ? max(0, (int)($_POST['first_order_lookback_days'] ?? 0)) : 0;

    $sql = "INSERT INTO drug_safety_rules (drug_id, drug_icode, drug_name, lab_type, min_val, max_val, use_dose_condition, dose_min, dose_max, dose_unit, use_dose_per_admin_condition, dose_per_admin_min, dose_per_admin_max, use_duration_condition, duration_min, duration_max, exempt_method_patterns, first_order_only, first_order_lookback_days, use_age_condition, age_min, age_max, use_weight_condition, weight_min, weight_max, action_type, action_value, suggestion_msg, alert_level, active_status{$lab_items_sql}{$lab_cond_sql}) 
            VALUES ('{$drug['drug_id']}', '{$drug['icode']}', '{$drug['name']}', '$lab_type', '$min_val', '$max_val', '$use_dose', {$dose['dose_min']}, {$dose['dose_max']}, {$dose['dose_unit']}, '$use_dose_per_admin', {$dose_per_admin['dose_per_admin_min']}, {$dose_per_admin['dose_per_admin_max']}, '$use_duration', {$duration['duration_min']}, {$duration['duration_max']}, $exempt_sql, '$first_order_only', '$first_order_lookback', {$extra['use_age']}, {$extra['age_min']}, {$extra['age_max']}, {$extra['use_weight']}, {$extra['weight_min']}, {$extra['weight_max']}, '$action_type', '$action_value', '$msg', '$alert_level', '$active_status'{$lab_items_vals}{$lab_cond_vals})";
    if (mysqli_query($con, $sql)) {
        monitor_lab_sync_exempt_patterns($con, $drug['icode'], $exempt_patterns);
        $_SESSION['msg'] = "บันทึกกฎความปลอดภัยสำเร็จ";
        sp_monitor_settings_changed($con, 'lab_' . $organ);
    } else {
        $_SESSION['error'] = "เกิดข้อผิดพลาด: " . mysqli_error($con);
    }
    header("Location: " . monitor_lab_page_url('tab=settings')); exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'edit') {
    $id = (int)($_POST['rule_id'] ?? 0);
    if ($id <= 0) {
        $_SESSION['error'] = "ไม่พบรหัสกฎที่ต้องการแก้ไข";
        header("Location: " . monitor_lab_page_url('tab=settings')); exit;
    }
    $lab_type_raw = $is_other ? 'CUSTOM' : ($_POST['lab_type'] ?? '');
    if (!in_array($lab_type_raw, $organ_lab_types, true)) {
        $_SESSION['error'] = 'ประเภท Lab ไม่ถูกต้องสำหรับหน้านี้';
        header("Location: " . monitor_lab_page_url('tab=settings')); exit;
    }
    $drug = monitor_lab_parse_drug_post($con);
    if ($drug === null) {
        $_SESSION['error'] = 'กรุณาเลือกรายการยาจาก HOSxP';
        header("Location: " . monitor_lab_page_url('tab=settings')); exit;
    }
    $lab_items_set = '';
    $lab_cond_set = '';
    if ($is_other) {
        $lab_item = monitor_lab_parse_lab_post($con);
        if ($lab_item === null) {
            $_SESSION['error'] = 'กรุณาเลือกรายการ Lab จาก HOSxP';
            header("Location: " . monitor_lab_page_url('tab=settings')); exit;
        }
        $lab_items_set = ", lab_items_code='{$lab_item['code']}', lab_items_name='{$lab_item['name']}'";
        $lab_cond = monitor_lab_parse_condition_post($con);
        if ($lab_cond === null) {
            $_SESSION['error'] = 'กรุณาระบุค่าที่ต้องการดักจับสำหรับเงื่อนไขข้อความ';
            header("Location: " . monitor_lab_page_url('tab=settings')); exit;
        }
        $lab_cond_set = ", lab_condition_type='{$lab_cond['type']}', lab_condition_value=" . ($lab_cond['value'] !== '' ? "'{$lab_cond['value']}'" : 'NULL');
    }
    $lab_type = mysqli_real_escape_string($con, $lab_type_raw);
    $min_val = mysqli_real_escape_string($con, $_POST['min_val'] ?? '0');
    $max_val = mysqli_real_escape_string($con, $_POST['max_val']);
    $action_type = mysqli_real_escape_string($con, $_POST['action_type']);
    $action_value = mysqli_real_escape_string($con, $_POST['action_value'] ?? 0);
    $msg = mysqli_real_escape_string($con, $_POST['suggestion_msg']);
    $alert_level = (($_POST['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
    $use_dose = isset($_POST['use_dose_condition']) ? 1 : 0;
    $dose = buildDoseSql($con, $use_dose);
    $use_dose_per_admin = isset($_POST['use_dose_per_admin_condition']) ? 1 : 0;
    $dose_per_admin = buildDosePerAdminSql($con, $use_dose_per_admin);
    $use_duration = isset($_POST['use_duration_condition']) ? 1 : 0;
    $duration = buildDurationSql($con, $use_duration);
    $exempt_patterns = monitor_lab_normalize_exempt_patterns($_POST['exempt_method_patterns'] ?? '');
    $exempt_sql = $exempt_patterns !== '' ? "'" . mysqli_real_escape_string($con, $exempt_patterns) . "'" : 'NULL';
    $extra = buildPatientExtraSql($con, $is_renal);
    $active_status = isset($_POST['active_status']) ? 1 : 0;
    $first_order_only = isset($_POST['first_order_only']) ? 1 : 0;
    $first_order_lookback = $first_order_only ? max(0, (int)($_POST['first_order_lookback_days'] ?? 0)) : 0;

    $sql = "UPDATE drug_safety_rules SET 
            drug_id='{$drug['drug_id']}', drug_icode='{$drug['icode']}', drug_name='{$drug['name']}', lab_type='$lab_type', min_val='$min_val', max_val='$max_val',
            use_dose_condition='$use_dose', dose_min={$dose['dose_min']}, dose_max={$dose['dose_max']}, dose_unit={$dose['dose_unit']},
            use_dose_per_admin_condition='$use_dose_per_admin', dose_per_admin_min={$dose_per_admin['dose_per_admin_min']}, dose_per_admin_max={$dose_per_admin['dose_per_admin_max']},
            use_duration_condition='$use_duration', duration_min={$duration['duration_min']}, duration_max={$duration['duration_max']},
            exempt_method_patterns=$exempt_sql,
            first_order_only='$first_order_only', first_order_lookback_days='$first_order_lookback',
            use_age_condition={$extra['use_age']}, age_min={$extra['age_min']}, age_max={$extra['age_max']},
            use_weight_condition={$extra['use_weight']}, weight_min={$extra['weight_min']}, weight_max={$extra['weight_max']},
            action_type='$action_type', action_value='$action_value', suggestion_msg='$msg', alert_level='$alert_level', active_status='$active_status'{$lab_items_set}{$lab_cond_set}
            WHERE id='$id'";
    if (mysqli_query($con, $sql)) {
        monitor_lab_sync_exempt_patterns($con, $drug['icode'], $exempt_patterns);
        $_SESSION['msg'] = "แก้ไขกฎความปลอดภัยสำเร็จ";
        sp_monitor_settings_changed($con, 'lab_' . $organ);
    } else {
        $_SESSION['error'] = "เกิดข้อผิดพลาด: " . mysqli_error($con);
    }
    header("Location: " . monitor_lab_page_url('tab=settings')); exit;
}

if (isset($_GET['del'])) {
    $id = mysqli_real_escape_string($con, $_GET['del']);
    mysqli_query($con, "DELETE FROM drug_safety_rules WHERE id = '$id'");
    sp_monitor_settings_changed($con, 'lab_' . $organ);
    $_SESSION['msg'] = "ลบกฎความปลอดภัยสำเร็จ";
    header("Location: " . monitor_lab_page_url('tab=settings')); exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'toggle') {
    $id = (int)($_POST['rule_id'] ?? 0);
    $active = isset($_POST['active']) ? 1 : 0;
    if ($id <= 0) {
        $_SESSION['error'] = 'ไม่พบรหัสกฎที่ต้องการเปลี่ยนสถานะ';
        header("Location: " . monitor_lab_page_url('tab=settings')); exit;
    }
    $ok = mysqli_query($con, "UPDATE drug_safety_rules SET active_status=$active
        WHERE id=$id AND lab_type IN ($organ_lab_types_sql)");
    if ($ok && mysqli_affected_rows($con) > 0) {
        $_SESSION['msg'] = $active
            ? 'เปิดใช้งานกฎแล้ว — จะกลับมาเฝ้าระวังในหน้า Monitor / Smart Pharma / Telegram'
            : 'ปิดใช้งานกฎแล้ว — จะไม่แสดงในหน้า Monitor และไม่แจ้ง Intervention Log / Telegram';
        sp_monitor_settings_changed($con, 'lab_' . $organ);
    } else {
        $_SESSION['error'] = 'ไม่พบกฎในหน้านี้ หรือสถานะไม่เปลี่ยน';
    }
    header("Location: " . monitor_lab_page_url('tab=settings') . '#rule-' . $id); exit;
}

$has_drug_icode_col = ensure_drug_safety_rules_hosxp_columns($con);
$has_alert_level_col = ensure_drug_safety_rules_alert_level_column($con);
$has_lab_items_col = ensure_drug_safety_rules_lab_items_columns($con);
$has_lab_condition_col = ensure_drug_safety_rules_lab_condition_columns($con);
$has_patient_extra_col = ensure_drug_safety_rules_patient_extra_columns($con);
$has_duration_col = ensure_drug_safety_rules_duration_columns($con);
$has_dose_per_admin_col = ensure_drug_safety_rules_dose_per_admin_columns($con);
$has_exempt_col = ensure_drug_safety_rules_exempt_method_columns($con);
$has_first_order_col = ensure_drug_safety_rules_first_order_columns($con);
$lab_condition_labels = [
    'range' => 'ช่วงตัวเลข',
    'regex' => 'Regex (ข้อความ)',
    'contains' => 'มีคำว่า... (Text)',
    'less_than' => 'น้อยกว่า <',
    'greater_than' => 'มากกว่า >',
];

function monitor_lab_alert_level_from_row($row) {
    return monitor_lab_alert_level_from_rule($row);
}

function monitor_lab_alert_level_badge($level) {
    if ($level === 'hard') {
        return '<span class="badge bg-danger">Hard Alert</span>';
    }
    return '<span class="badge bg-warning text-dark">Soft Alert</span>';
}

$hosxp_drugs = [];
$has_hosxp_drugs = false;
$opt_hosxp_drugs = "<option value=''>- เลือกรายการยาจาก HOSxP (TMT) -</option>";
if ($lab_settings_tab) {
    $con_hosxp = hosxp_connect($con);
    if ($con_hosxp) {
        $hosxp_drugs = hosxp_fetch_active_drugs_tmt($con_hosxp);
        mysqli_close($con_hosxp);
        if (!empty($hosxp_drugs)) {
            $has_hosxp_drugs = true;
            $opt_hosxp_drugs = hosxp_build_drug_options_html($hosxp_drugs, '- เลือกรายการยาจาก HOSxP (TMT) -');
        }
    }
}

$dose_unit_fixed = 'mg';

function monitor_lab_rules_sql($organ_lab_types_sql, $has_drug_icode_col) {
    if ($has_drug_icode_col) {
        return "SELECT r.*,
                COALESCE(NULLIF(TRIM(r.drug_name), ''), d.name) AS display_drug_name,
                COALESCE(NULLIF(TRIM(r.drug_icode), ''), d.icode) AS display_icode
            FROM drug_safety_rules r
            LEFT JOIN drugitems d ON r.drug_id = d.id
            WHERE r.lab_type IN ($organ_lab_types_sql)
            ORDER BY display_drug_name, r.lab_type, r.min_val";
    }
    return "SELECT r.*, d.name AS display_drug_name, d.icode AS display_icode
        FROM drug_safety_rules r
        INNER JOIN drugitems d ON r.drug_id = d.id
        WHERE r.lab_type IN ($organ_lab_types_sql)
        ORDER BY d.name, r.lab_type, r.min_val";
}

function monitor_lab_active_rules_sql($organ_lab_types_sql, $has_drug_icode_col, $has_lab_items_col = false, $has_lab_condition_col = false) {
    $lab_cols = $has_lab_items_col ? ', r.lab_items_code, r.lab_items_name' : '';
    $lab_cols .= $has_lab_condition_col ? ', r.lab_condition_type, r.lab_condition_value' : '';
    if ($has_drug_icode_col) {
        return "SELECT r.id,
                COALESCE(NULLIF(TRIM(r.drug_name), ''), d.name) AS drug_name,
                COALESCE(NULLIF(TRIM(r.drug_icode), ''), d.icode) AS icode,
                r.lab_type, r.min_val, r.max_val, r.alert_level{$lab_cols}
            FROM drug_safety_rules r
            LEFT JOIN drugitems d ON r.drug_id = d.id
            WHERE r.active_status = 1
              AND r.lab_type IN ($organ_lab_types_sql)
              AND COALESCE(NULLIF(TRIM(r.drug_icode), ''), d.icode, '') <> ''
            ORDER BY drug_name, r.lab_type, r.min_val";
    }
    return "SELECT r.id, d.name AS drug_name, d.icode AS icode,
                r.lab_type, r.min_val, r.max_val, r.alert_level{$lab_cols}
            FROM drug_safety_rules r
            INNER JOIN drugitems d ON r.drug_id = d.id
            WHERE r.active_status = 1
              AND r.lab_type IN ($organ_lab_types_sql)
            ORDER BY d.name, r.lab_type, r.min_val";
}

$monitor_rules = [];
if ($lab_page_tab === 'monitor') {
    $q_mon_rules = mysqli_query($con, monitor_lab_active_rules_sql($organ_lab_types_sql, $has_drug_icode_col, $has_lab_items_col, $has_lab_condition_col));
    if ($q_mon_rules) {
        while ($mr = mysqli_fetch_assoc($q_mon_rules)) {
            $monitor_rules[] = $mr;
        }
    }
}

$current_user_id = (int)($_SESSION['user_id'] ?? 0);
$pharmacist_options = [];
$mlc_reply_wait_days = 0;
if ($lab_page_tab === 'monitor') {
    require_once __DIR__ . '/monitor_lab_consult_helper.php';
    mlc_ensure_tables($con);
    $pharmacist_options = mlc_list_pharmacists($con, $current_user_id);
    $mlc_reply_wait_days = mlc_get_reply_wait_days($con);
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($page_title); ?> - THAM CYTO</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/select2.min.css" rel="stylesheet">
    <link href="css/select2-bootstrap-5-theme.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .nav-tabs .nav-link.active.tab-renal { color: #0d6efd; border-bottom: 3px solid #0d6efd; font-weight: bold; }
        .nav-tabs .nav-link.active.tab-hepatic { color: #ffc107; border-bottom: 3px solid #ffc107; font-weight: bold; text-shadow: 0 0 1px #ffc107;}
        .nav-tabs .nav-link.active.tab-other { color: #0dcaf0; border-bottom: 3px solid #0dcaf0; font-weight: bold; }
        .table-renal thead { background-color: #e8f4fd; color: #0d6efd; }
        .table-hepatic thead { background-color: #fffcf0; color: #d39e00; }
        .table-other thead { background-color: #e8fcff; color: #0aa2c0; }
        .btn-glow { animation: glow 1.2s infinite alternate; }
        @keyframes glow { from { box-shadow: 0 0 2px #0dcaf0; } to { box-shadow: 0 0 10px #0dcaf0; } }
        .dose-box { background-color: #f8f9fa; border-radius: 6px; padding: 6px; margin-top: 5px; border: 1px solid #e9ecef; }
        .chart-container { position: relative; height: 200px; width: 100%; }
        .summary-card { border-radius: 12px; border: none; border-top: 4px solid <?php echo $summary_border; ?>; }
        .dose-fields { transition: opacity 0.2s; }
        .dose-per-admin-fields { transition: opacity 0.2s; }
        .duration-fields { transition: opacity 0.2s; }
        .dose-fields.disabled-section, .dose-per-admin-fields.disabled-section, .duration-fields.disabled-section { opacity: 0.45; pointer-events: none; }
        .age-fields, .weight-fields { transition: opacity 0.2s; }
        .age-fields.disabled-section, .weight-fields.disabled-section { opacity: 0.45; pointer-events: none; }
        #formCard.edit-mode .card-header { background-color: #0d6efd !important; border-color: #0d6efd; }
        #formCard.copy-mode .card-header { background-color: #6c757d !important; border-color: #6c757d; }
        tr.editing-row { background-color: #fff3cd !important; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .section-hard { border-left: 4px solid #dc3545; padding-left: 12px; }
        .section-soft { border-left: 4px solid #ffc107; padding-left: 12px; }
        #labRuleFilterBox .lab-rule-cb-label { cursor: pointer; }
        .mlc-outcome-group { gap: .35rem 1.1rem; }
        .mlc-outcome-group .form-check { min-width: 7.5rem; }
    </style>
</head>
<body>

<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">

            <h4 class="fw-bold mb-2 text-dark"><i class="fas <?php echo $page_icon; ?> me-2"></i><?php echo htmlspecialchars($page_title); ?></h4>
            <?php if ($is_hepatic): ?>
            <p class="text-muted small mb-3">
                ประเมินการทำงานของตับเพื่อปรับขนาดยาด้วย <b>Child-Pugh</b> (เกณฑ์หลักใน FDA/EMA labelling)
                และ <b>MELD-Na</b> (ความเสี่ยงเสียชีวิตระยะสั้น / HRS) —
                Severe = Child-Pugh B/C, Decompensated หรือ MELD-Na ≥ 15
            </p>
            <?php endif; ?>

            <ul class="nav nav-tabs fw-bold mb-0" id="labMainTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link <?php echo $lab_page_tab === 'monitor' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars(monitor_lab_page_url()); ?>"><i class="fas fa-desktop me-1"></i> รายการเฝ้าระวังหน้างาน</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $lab_settings_tab ? 'active' : ''; ?>" href="<?php echo htmlspecialchars(monitor_lab_page_url('tab=settings')); ?>"><i class="fas fa-cogs me-1"></i> ตั้งค่ายาเฝ้าระวัง</a>
                </li>
                <?php if ($is_hepatic): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo $lab_scores_tab ? 'active' : ''; ?>" href="<?php echo htmlspecialchars(monitor_lab_page_url('tab=scores')); ?>"><i class="fas fa-table me-1"></i> เกณฑ์คะแนน Child-Pugh / MELD-Na</a>
                </li>
                <?php endif; ?>
            </ul>

            <?php if ($lab_page_tab === 'monitor'): ?>

            <div class="tab-content border border-top-0">
                <div class="p-0" id="mainMonitor">

            <div class="filter-box p-3 mb-3">
                <div class="row g-2 align-items-end">
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">ช่วงวันที่สั่งยา ตั้งแต่</label>
                        <input type="text" id="filter_start" class="form-control form-control-sm bg-white">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">ถึงวันที่</label>
                        <input type="text" id="filter_end" class="form-control form-control-sm bg-white">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold mb-1">ช่วงเวลาเร็ว</label>
                        <div class="btn-group w-100" role="group">
                            <button type="button" class="btn btn-outline-secondary btn-sm fw-bold lab-range-btn" data-days="1" onclick="setLabDateRange(1)">วันนี้</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm fw-bold lab-range-btn active" data-days="3" onclick="setLabDateRange(3)">3 วัน</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm fw-bold lab-range-btn" data-days="7" onclick="setLabDateRange(7)">7 วัน</button>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">HN (ไม่บังคับ)</label>
                        <input type="text" id="filter_hn" class="form-control form-control-sm bg-white" placeholder="ทุก HN" autocomplete="off">
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-primary btn-sm fw-bold shadow-sm w-100" type="button" id="btnFetchLab" onclick="fetchLabMonitorData()">
                            <i class="fas fa-sync-alt me-1"></i> ประมวลผล / ดึงผล Lab
                        </button>
                    </div>
                </div>
                <div class="small text-muted mt-2"><i class="fas fa-info-circle me-1"></i> <?php echo $is_hepatic ? 'ดึง Lab/ICD ทั้งชุดในคำขอเดียว — ' : 'ตรวจทีละยาแบบ <b>monitor mg→mL</b> — '; ?>แนะนำเริ่มที่ <b>3 วัน</b> และย่อช่วงวันที่ถ้ายังช้า · เปิดจาก Smart Pharma จะกรองตาม HN อัตโนมัติ</div>
                <div id="hnFocusBanner" class="alert alert-warning py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                <div id="reportMeta" class="alert alert-info py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                <?php if ($is_hepatic): ?>
                <div class="alert alert-light border py-2 px-3 mt-2 mb-0 small">
                    <b>Child-Pugh</b> (T.Bili + Albumin + INR ± Ascites/HE จาก ICD) ใช้ปรับขนาดยาตาม labelling ·
                    <b>MELD-Na</b> (Cr + T.Bili + INR + Na) ใช้ดูความเสี่ยงเสียชีวิตระยะสั้นและ HRS ·
                    ยาเสี่ยงใน Severe: NSAIDs/COX-2, Oral Ketoconazole, PZA, Long-acting BZD, ACEI/ARB
                </div>
                <?php endif; ?>
            </div>

            <div class="border rounded p-3 mb-3" id="labRuleFilterBox">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                    <label class="form-label fw-bold small mb-0">
                        <i class="fas fa-filter me-1 text-primary"></i> เลือกรายการยาที่ต้องการรายงาน
                        <span class="text-muted fw-normal" id="labRuleSelectedCount"></span>
                    </label>
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-primary fw-bold" onclick="labSelectAllRules(true)">เลือกทั้งหมด</button>
                        <button type="button" class="btn btn-outline-secondary fw-bold" onclick="labSelectAllRules(false)">ยกเลิกทั้งหมด</button>
                    </div>
                </div>
                <?php if (empty($monitor_rules)): ?>
                <div class="small text-muted">ยังไม่มีกฎที่เปิดใช้งาน — ไปที่แท็บ <b>ตั้งค่ายาเฝ้าระวัง</b> เพื่อเพิ่มกฎ</div>
                <?php else: ?>
                <div class="mb-2">
                    <input type="text" id="labRuleSearch" class="form-control form-control-sm" placeholder="ค้นหายาในรายการ...">
                    <div class="form-text small"><?php echo $is_hepatic ? 'ระบบตรวจยาเป็นกลุ่ม และดึง Lab Child-Pugh/MELD รวมเป็นชุด — ย่อช่วงวันที่ถ้ายังช้า' : 'ระบบตรวจทีละยาพร้อมกันหลายรายการ — ย่อช่วงวันที่ถ้ายังช้า'; ?></div>
                </div>
                <div class="row g-2" id="labRuleCheckboxes">
                    <?php foreach ($monitor_rules as $mr):
                        $lvl = monitor_lab_alert_level_from_row($mr);
                        $lvl_badge = $lvl === 'hard'
                            ? '<span class="badge bg-danger ms-1">Hard</span>'
                            : '<span class="badge bg-warning text-dark ms-1">Soft</span>';
                        $lab_lbl = htmlspecialchars($lab_type_labels[$mr['lab_type']] ?? $mr['lab_type']);
                        $lab_code_disp = !empty($mr['lab_items_code']) ? htmlspecialchars($mr['lab_items_code']) : '';
                        $lab_name_disp = !empty($mr['lab_items_name']) ? htmlspecialchars($mr['lab_items_name']) : '';
                        $cond_type_mr = $mr['lab_condition_type'] ?? 'range';
                        $cond_val_mr = $mr['lab_condition_value'] ?? '';
                    ?>
                    <div class="col-md-6 col-xl-4 lab-rule-item">
                        <div class="form-check border rounded px-2 py-1 bg-white h-100">
                            <input class="form-check-input lab-rule-cb" type="checkbox"
                                   value="<?php echo (int)$mr['id']; ?>"
                                   data-icode="<?php echo htmlspecialchars($mr['icode'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                   data-drug="<?php echo htmlspecialchars($mr['drug_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                   id="lab_rule_cb_<?php echo (int)$mr['id']; ?>" checked>
                            <label class="form-check-label small lab-rule-cb-label" for="lab_rule_cb_<?php echo (int)$mr['id']; ?>">
                                <span class="text-primary fw-bold"><?php echo htmlspecialchars($mr['drug_name']); ?></span>
                                <?php if ($is_other && $lab_code_disp !== ''): ?>
                                <span class="badge bg-secondary ms-1"><?php echo $lab_code_disp; ?></span>
                                <span class="text-dark"><?php echo $lab_name_disp; ?></span>
                                <?php if ($cond_type_mr !== 'range' && $cond_val_mr !== ''): ?>
                                <br><span class="text-primary"><?php echo htmlspecialchars($lab_condition_labels[$cond_type_mr] ?? $cond_type_mr); ?>: <?php echo htmlspecialchars($cond_val_mr); ?></span>
                                <?php else: ?>
                                <span class="text-muted"> <?php echo htmlspecialchars($mr['min_val']); ?>–<?php echo htmlspecialchars($mr['max_val']); ?></span>
                                <?php endif; ?>
                                <?php else: ?>
                                <span class="badge bg-info text-dark ms-1"><?php echo $lab_lbl; ?></span>
                                <?php endif; ?>
                                <span class="text-muted"><?php echo htmlspecialchars($mr['min_val']); ?>–<?php echo htmlspecialchars($mr['max_val']); ?></span>
                                <?php echo $lvl_badge; ?>
                            </label>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <div class="card shadow-sm mb-4 summary-card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-5 border-end">
                            <h6 class="fw-bold text-success mb-3"><i class="fas fa-chart-pie me-2"></i>สรุปการปรับขนาดยา (Dose Adjustment)</h6>
                            <div class="chart-container">
                                <canvas id="summaryChart"></canvas>
                            </div>
                        </div>
                        <div class="col-md-7 ps-4">
                            <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-clipboard-check me-2"></i>สรุปผลการตรวจ</h6>
                            <div class="row text-center">
                                <div class="col-6">
                                    <div class="p-3 bg-success bg-opacity-10 rounded text-success fw-bold border border-success">
                                        ผ่านเกณฑ์: <span id="count_pass" class="fs-4">0</span>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="p-3 bg-danger bg-opacity-10 rounded text-danger fw-bold border border-danger">
                                        ไม่ผ่านเกณฑ์: <span id="count_fail" class="fs-4">0</span>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-3 p-3 bg-light rounded border text-center">
                                <div class="small text-muted mb-1">อัตราไม่ผ่าน = ไม่ผ่านเกณฑ์ / รายงานการสั่งใช้ยา × 100</div>
                                <div class="fw-bold fs-4 text-danger"><span id="fail_percent">0.00%</span></div>
                                <div class="small text-secondary mt-1">(<span id="count_fail_formula">0</span> / <span id="count_rx_total">0</span>)</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <ul class="nav nav-tabs fw-bold mb-0" id="labReportTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active <?php echo $is_other ? 'tab-other' : ($is_hepatic ? 'tab-hepatic' : 'tab-renal'); ?>" id="tab-alerts-btn" data-bs-toggle="tab" data-bs-target="#tabAlerts" type="button" role="tab">
                        <i class="fas fa-bell me-1"></i> Soft / Hard Alert
                        <span class="badge bg-secondary ms-1" id="alertTabCount">0</span>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo $is_other ? 'tab-other' : ($is_hepatic ? 'tab-hepatic' : 'tab-renal'); ?>" id="tab-rx-btn" data-bs-toggle="tab" data-bs-target="#tabPrescriptions" type="button" role="tab">
                        <i class="fas fa-prescription-bottle-alt me-1"></i> รายงานการสั่งใช้ยา
                        <span class="badge bg-primary ms-1" id="rxTabCount">0</span>
                    </button>
                </li>
            </ul>

            <div class="tab-content border border-top-0 bg-white p-3 rounded-bottom shadow-sm mb-4">
                <div class="tab-pane fade show active" id="tabAlerts" role="tabpanel">
                    <div class="section-hard mb-4">
                        <h6 class="fw-bold text-danger mb-2"><i class="fas fa-exclamation-circle me-2"></i>Hard Alert <span id="hardCount" class="badge bg-danger">0</span></h6>
                        <div class="bg-white border p-3 rounded shadow-sm">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle border mb-0 <?php echo $table_class; ?>">
                                    <thead class="text-center">
                                        <tr>
                                            <th width="8%">HN</th>
                                            <th width="15%" class="text-start">ชื่อ-สกุล</th>
                                            <th width="22%" class="text-start">รายการยา / ขนาดยา (Dose)</th>
                                            <th width="<?php echo $lab_col_w; ?>"><?php echo htmlspecialchars($lab_value_col); ?></th>
                                            <th width="16%">เงื่อนไขที่ละเมิด</th>
                                            <th width="12%">สรุป (Dose)</th>
                                            <th width="14%">Consult</th>
                                        </tr>
                                    </thead>
                                    <tbody id="hardTbody">
                                        <tr><td colspan="7" class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="section-soft mb-2">
                        <h6 class="fw-bold text-warning mb-2"><i class="fas fa-exclamation-triangle me-2"></i>Soft Alert <span id="softCount" class="badge bg-warning text-dark">0</span></h6>
                        <div class="bg-white border p-3 rounded shadow-sm">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle border mb-0 <?php echo $table_class; ?>">
                                    <thead class="text-center">
                                        <tr>
                                            <th width="8%">HN</th>
                                            <th width="15%" class="text-start">ชื่อ-สกุล</th>
                                            <th width="22%" class="text-start">รายการยา / ขนาดยา (Dose)</th>
                                            <th width="<?php echo $lab_col_w; ?>"><?php echo htmlspecialchars($lab_value_col); ?></th>
                                            <th width="16%">เงื่อนไขที่ละเมิด</th>
                                            <th width="12%">สรุป (Dose)</th>
                                            <th width="14%">Consult</th>
                                        </tr>
                                    </thead>
                                    <tbody id="softTbody">
                                        <tr><td colspan="7" class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="tabPrescriptions" role="tabpanel">
                    <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
                        <span class="small fw-bold text-muted me-1">กรองสถานะ:</span>
                        <div class="btn-group btn-group-sm" role="group">
                            <button type="button" class="btn btn-outline-secondary active fw-bold" data-rx-filter="all" onclick="setRxFilter('all', this)">ทั้งหมด <span id="rxCountAll" class="badge bg-secondary">0</span></button>
                            <button type="button" class="btn btn-outline-success fw-bold" data-rx-filter="ok" onclick="setRxFilter('ok', this)">เหมาะสม <span id="rxCountOk" class="badge bg-success">0</span></button>
                            <button type="button" class="btn btn-outline-warning fw-bold" data-rx-filter="alert" onclick="setRxFilter('alert', this)">เข้า Alert <span id="rxCountAlert" class="badge bg-warning text-dark">0</span></button>
                            <button type="button" class="btn btn-outline-secondary fw-bold" data-rx-filter="no_lab" onclick="setRxFilter('no_lab', this)">ไม่มี Lab <span id="rxCountNoLab" class="badge bg-dark">0</span></button>
                        </div>
                        <span class="small text-muted ms-2"><i class="fas fa-info-circle me-1"></i>รวมทุกรายการสั่งยาของยาที่เลือก — ไม่จำกัดเฉพาะที่เข้าเงื่อนไข Alert</span>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle border mb-0 <?php echo $table_class; ?>">
                            <thead class="text-center table-light">
                                <tr>
                                    <th width="8%">HN</th>
                                    <th width="14%" class="text-start">ชื่อ-สกุล</th>
                                    <th width="22%" class="text-start">รายการยา / ขนาดยา</th>
                                    <th width="<?php echo $lab_col_w_rx; ?>"><?php echo htmlspecialchars($lab_value_col); ?></th>
                                    <th width="14%">เงื่อนไขเฝ้าระวัง</th>
                                    <th width="14%">สถานะ</th>
                                </tr>
                            </thead>
                            <tbody id="rxTbody">
                                <tr><td colspan="6" class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

                </div>
            </div>

            <div class="modal fade" id="mlcConsultModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold"><i class="fas fa-notes-medical me-2 text-danger"></i>บันทึก Intervention — <?php echo $is_renal ? 'Lab ไต' : ($is_hepatic ? 'Lab ตับ' : 'Lab อื่นๆ'); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="small text-muted mb-2" id="mlcConsultCaseInfo"></div>
                            <div class="border rounded p-2 mb-3 bg-light" id="mlcDrugSelectBox">
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                                    <label class="form-label small fw-bold mb-0">
                                        <i class="fas fa-pills me-1 text-success"></i>
                                        เลือกยาที่จะปรึกษา (HN เดียวกัน)
                                    </label>
                                    <div class="btn-group btn-group-sm">
                                        <button type="button" class="btn btn-outline-secondary" onclick="mlcToggleDrugChecks(true)">เลือกทั้งหมด</button>
                                        <button type="button" class="btn btn-outline-secondary" onclick="mlcToggleDrugChecks(false)">ยกเลิกทั้งหมด</button>
                                    </div>
                                </div>
                                <div id="mlcDrugCheckList" class="small"></div>
                                <div class="form-text mb-0">ค่าเริ่มต้นเลือกทั้งหมด — ติ๊กเฉพาะยาที่ต้องการปรึกษาในใบนี้</div>
                            </div>
                            <div class="row g-2">
                                <div class="col-md-8">
                                    <label class="form-label small fw-bold">เภสัชกรที่ Consult</label>
                                    <select id="mlcPharmacist" class="form-select form-select-sm">
                                        <?php if (empty($pharmacist_options)): ?>
                                        <option value="">— ไม่พบผู้ใช้ตำแหน่งเภสัชกร —</option>
                                        <?php else: ?>
                                        <?php foreach ($pharmacist_options as $ph):
                                            $ph_name = trim((string)($ph['full_name'] ?: $ph['username']));
                                            $ph_pos = trim((string)($ph['entryposition'] ?? ''));
                                            $ph_label = $ph_pos !== '' ? ($ph_name . ' (' . $ph_pos . ')') : $ph_name;
                                        ?>
                                        <option value="<?php echo (int)$ph['id']; ?>"
                                            <?php echo ((int)$ph['id'] === $current_user_id) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($ph_label); ?>
                                        </option>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label small fw-bold">รอตอบกลับ</label>
                                    <select id="mlcReplyWait" class="form-select form-select-sm">
                                        <option value="0"<?php echo ((int)$mlc_reply_wait_days === 0) ? ' selected' : ''; ?>>ทันที</option>
                                        <?php for ($d = 1; $d <= 7; $d++): ?>
                                        <option value="<?php echo $d; ?>"<?php echo ((int)$mlc_reply_wait_days === $d) ? ' selected' : ''; ?>><?php echo $d; ?> วัน</option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">การแทรกแซง</label>
                                    <select id="mlcIvType" class="form-select form-select-sm">
                                        <option value="recommend">แนะนำ / Consult</option>
                                        <option value="adjust">ปรับยา</option>
                                        <option value="reject">ไม่จ่าย / Hold</option>
                                        <option value="followup">ติดตาม</option>
                                        <option value="document">บันทึกเท่านั้น</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">ใช่ความคลาดเคลื่อนไหม</label>
                                    <select id="mlcIvDeviation" class="form-select form-select-sm" onchange="AlertMute.sync('mlcIvDeviation')">
                                        <option value="">— ไม่ระบุ —</option>
                                        <option value="ความคลาดเคลื่อนจริง">ความคลาดเคลื่อนจริง</option>
                                        <option value="ไม่ใช่ความคลาดเคลื่อน">ไม่ใช่ความคลาดเคลื่อน</option>
                                    </select>
                                    <?php require_once __DIR__ . '/monitor_alert_mute_ui.php'; monitor_alert_mute_box('mlcIvDeviation'); ?>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold">หมายเหตุ</label>
                                    <textarea id="mlcConsultNote" class="form-control form-control-sm" rows="2" placeholder="รายละเอียดที่ต้องการบันทึกใน Intervention และใส่ในใบปรึกษา"></textarea>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold">รายละเอียดหลัง Consult <span class="fw-normal text-muted">(บันทึกภายหลังได้ใน Intervention Report)</span></label>
                                    <div class="d-flex flex-wrap gap-1 mb-1">
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mlcChip('แพทย์ Off')">แพทย์ Off</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mlcChip('แพทย์ Hold')">แพทย์ Hold</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mlcChip('แพทย์ลดขนาดยา')">แพทย์ลดขนาดยา</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mlcChip('แพทย์ให้ยาต่อ')">แพทย์ให้ยาต่อ</button>
                                        <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="mlcChip('')">อื่นๆ</button>
                                    </div>
                                    <textarea id="mlcIvConsult" class="form-control form-control-sm" rows="2" placeholder="เลือกตัวช่วยด้านบน หรือพิมพ์รายละเอียดเอง"></textarea>
                                </div>
                            </div>
                            <div id="mlcConsultMsg" class="alert mt-3 mb-0 py-2 small d-none"></div>
                        </div>
                        <div class="modal-footer flex-wrap">
                            <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิดหน้าต่าง</button>
                            <button type="button" class="btn btn-outline-info btn-sm fw-bold" onclick="mlcOpenHistory()">
                                <i class="fas fa-history me-1"></i> เปิดดูประวัติ
                            </button>
                            <button type="button" class="btn btn-outline-warning btn-sm fw-bold" onclick="mlcResetWaiting()">
                                ตั้งเป็นรอ Consult
                            </button>
                            <button type="button" class="btn btn-outline-success btn-sm fw-bold" onclick="mlcCloseConsult()">
                                ปิดการ Consult
                            </button>
                            <button type="button" class="btn btn-success btn-sm fw-bold" onclick="mlcSaveIntervention(true)">
                                <i class="fas fa-print me-1"></i> บันทึกและพิมพ์ใบปรึกษาแพทย์
                            </button>
                            <button type="button" class="btn btn-sm fw-bold text-white" style="background:#0d9488;" onclick="mlcSaveIntervention(false)">บันทึก Intervention</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mlcHistoryModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-scrollable">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold"><i class="fas fa-history me-2 text-info"></i>ประวัติ Consult</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="small text-muted mb-2" id="mlcHistoryInfo"></div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>เวลา</th>
                                            <th>ยา</th>
                                            <th>การดำเนินการ</th>
                                            <th>สถานะ</th>
                                            <th>กำหนดตอบกลับ</th>
                                            <th>ผู้ทำ</th>
                                            <th>หมายเหตุ</th>
                                        </tr>
                                    </thead>
                                    <tbody id="mlcHistoryBody">
                                        <tr><td colspan="7" class="text-center text-muted py-3">ยังไม่มีประวัติ</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">ปิด</button>
                        </div>
                    </div>
                </div>
            </div>

            <?php elseif ($lab_scores_tab): ?>
            <?php monitor_lab_hepatic_render_scores_tab(); ?>
            <?php else: ?>

            <div class="bg-white border border-top-0 p-4 rounded-bottom shadow-sm" id="mainSettings">

                    <?php if (isset($_SESSION['msg'])) { echo "<div class='alert alert-success fw-bold'><i class='fas fa-check-circle'></i> {$_SESSION['msg']}</div>"; unset($_SESSION['msg']); } ?>
                    <?php if (isset($_SESSION['error'])) { echo "<div class='alert alert-danger fw-bold'><i class='fas fa-times-circle'></i> {$_SESSION['error']}</div>"; unset($_SESSION['error']); } ?>

                    <div class="alert alert-light border small mb-4">
                        <i class="fas fa-info-circle text-primary me-2"></i>
                        <?php if ($is_renal): ?>
                        กำหนดกฎลดขนาดยาตามผล Lab ไต (CrCl / CKD-EPI / Serum Cr) — เลือก <b>รายการยาจาก HOSxP (TMT)</b> ใช้ประกอบการเฝ้าระวังในแท็บ <b>รายการเฝ้าระวังหน้างาน</b>
                        <br><span class="text-muted">CrCl คำนวณจาก Serum Cr · CKD-EPI / Serum Cr ดึงจากรหัส Lab ที่ตั้งใน hosxp_setting · รองรับเงื่อนไขเพิ่มเติม <b>อายุ และ/หรือ น้ำหนัก</b> (เช่น Apixaban: Serum Cr ≥1.5 และ อายุ ≥80 หรือ นน. ≤60)</span>
                        <form method="post" action="<?php echo htmlspecialchars(monitor_lab_page_url('tab=settings')); ?>" class="mt-3 mb-0" onsubmit="return confirm('นำเข้ากฎคัดกรองผู้ป่วยไตจากตาราง drug_lab_alerted_pharma (Lab eGFR) ใน HOSxP?\nจะจับคู่ยาที่ยังเปิดใช้ และข้ามกฎที่มีอยู่แล้ว');">
                            <input type="hidden" name="action" value="import_egfr">
                            <button type="submit" class="btn btn-sm btn-outline-primary fw-bold" <?php echo ($has_drug_icode_col && $has_hosxp_drugs) ? '' : 'disabled'; ?>>
                                <i class="fas fa-file-import me-1"></i> นำเข้าจาก HOSxP (Lab eGFR)
                            </button>
                            <span class="text-muted small ms-2">จาก Navicat: <code>drug_lab_alerted_pharma</code> ที่เป็น eGFR — จับคู่ยาที่เปิดใช้ ไม่ทับกฎเดิม</span>
                        </form>
                        <form method="post" action="<?php echo htmlspecialchars(monitor_lab_page_url('tab=settings')); ?>" class="mt-2 mb-0" onsubmit="return confirm('นำเข้ายาที่ต้องปรับในผู้ป่วยไตจากตารางปรับขนาดยา?\nห้ามใช้ = Hard Alert · ปรับขนาดยา = Soft Alert\nข้ามกฎที่มีอยู่แล้ว');">
                            <input type="hidden" name="action" value="import_renal_dosing">
                            <button type="submit" class="btn btn-sm btn-outline-danger fw-bold" <?php echo ($has_drug_icode_col && $has_hosxp_drugs) ? '' : 'disabled'; ?>>
                                <i class="fas fa-file-import me-1"></i> นำเข้ายาที่ต้องปรับในผู้ป่วยไต
                            </button>
                            <span class="text-muted small ms-2">ห้ามใช้ = <b>Hard Alert</b> · ปรับขนาดยา = <b>Soft Alert</b> — ไม่ทับกฎเดิม</span>
                        </form>
                        <?php elseif ($is_hepatic): ?>
                        กำหนดกฎลดขนาดยาตามผล Lab ตับ (Bilirubin / T.Bili×ULN / AST·ALT×ULN / <b>Child-Pugh</b> / <b>MELD-Na</b>) — เลือก <b>รายการยาจาก HOSxP (TMT)</b> ใช้ประกอบการเฝ้าระวังในแท็บ <b>รายการเฝ้าระวังหน้างาน</b>
                        <br><span class="text-muted">Child-Pugh เป็นเกณฑ์หลักใน FDA/EMA labelling สำหรับปรับขนาดยา · MELD-Na ประเมินความเสี่ยงเสียชีวิตระยะสั้นและ HRS · Severe = Child-Pugh B/C, Decompensated หรือ MELD-Na ≥ 15 — ตั้งรหัส Albumin / Na / INR / Cr ที่ <a href="hosxp_setting.php">ตั้งค่า HOSxP</a></span>
                        <form method="post" action="<?php echo htmlspecialchars(monitor_lab_page_url('tab=settings')); ?>" class="mt-3 mb-0" onsubmit="return confirm('นำเข้ายาที่ห้ามใช้หรือต้องปรับใน Severe liver dysfunction?\nNSAIDs/COX-2, Oral Ketoconazole, PZA, Long-acting BZD, ACEI/ARB\nChild-Pugh B/C หรือ MELD-Na ≥ 15 = Hard Alert (PZA Child-Pugh B = Soft)\nข้ามกฎที่มีอยู่แล้ว');">
                            <input type="hidden" name="action" value="import_hepatic_dosing">
                            <button type="submit" class="btn btn-sm btn-outline-warning fw-bold text-dark" <?php echo ($has_drug_icode_col && $has_hosxp_drugs) ? '' : 'disabled'; ?>>
                                <i class="fas fa-file-import me-1"></i> นำเข้ายาตาม Child-Pugh / MELD-Na
                            </button>
                            <span class="text-muted small ms-2">ห้ามใช้ใน Severe liver dysfunction = <b>Hard Alert</b> — ไม่ทับกฎเดิม</span>
                        </form>
                        <?php else: ?>
                        กำหนดกฎลดขนาดยาตามผล Lab อื่นๆ — เลือก <b>รายการยาจาก HOSxP (TMT)</b> และ <b>รายการ Lab จากตาราง lab_items</b> (แสดงรหัส Lab)
                        <br><span class="text-muted">รองรับ <b>ช่วงตัวเลข (min-max)</b> หรือ <b>เงื่อนไขข้อความ</b> แบบ Monitor UA — Regex / มีคำว่า / มากกว่า / น้อยกว่า</span>
                        <?php endif; ?>
                    </div>
                    <?php if (!$has_drug_icode_col): ?>
                    <div class="alert alert-danger fw-bold mb-4">
                        <i class="fas fa-database me-2"></i>ไม่สามารถปรับโครงสร้างตาราง drug_safety_rules ได้ — ลองรัน <a href="upgrade.php">อัปเกรดระบบ</a>
                    </div>
                    <?php elseif (!$has_hosxp_drugs): ?>
                    <div class="alert alert-warning fw-bold mb-4">
                        <i class="fas fa-exclamation-triangle me-2"></i>ไม่สามารถดึงรายการยาจาก HOSxP ได้ — ตรวจสอบที่ <a href="hosxp_setting.php">ตั้งค่า HOSxP</a>
                    </div>
                    <?php elseif ($is_other && !$has_lab_items_col): ?>
                    <div class="alert alert-danger fw-bold mb-4">
                        <i class="fas fa-database me-2"></i>ยังไม่มีคอลัมน์ lab_items ในตาราง drug_safety_rules — ลองรัน <a href="upgrade.php">อัปเกรดระบบ</a>
                    </div>
                    <?php elseif ($is_other && !$has_lab_condition_col): ?>
                    <div class="alert alert-danger fw-bold mb-4">
                        <i class="fas fa-database me-2"></i>ยังไม่มีคอลัมน์ lab_condition ในตาราง drug_safety_rules — ลองรัน <a href="upgrade.php">อัปเกรดระบบ</a>
                    </div>
                    <?php elseif ($is_other): ?>
                    <div class="alert alert-light border small mb-4">
                        <i class="fas fa-lightbulb text-warning me-2"></i><b>เงื่อนไขข้อความ (แบบ Monitor UA):</b><br>
                        - <b>Regex:</b> รวมหลายรูปแบบด้วย <code>|</code> เช่น <code>2\+|3\+|4\+</code> ดักจับ 2+, 3+, 4+<br>
                        - <b>มีคำว่า:</b> หาคำเดียวต่อครั้ง — หลายคำแบบ OR ให้ใช้ Regex<br>
                        - <b>มากกว่า / น้อยกว่า:</b> เปรียบเทียบตัวเลขจากผล Lab (float)<br>
                        - <b>รหัส Lab ซ้ำซ้อน:</b> ถ้ารพ.ใช้หลาย code สำหรับรายการเดียวกัน (เช่น Potassium <code>132</code> และ <code>1100</code>) ให้ใส่รหัสเพิ่มเติมคั่นด้วย comma
                    </div>
                    <?php endif; ?>

                    <div class="card shadow-sm <?php echo $form_border; ?> mb-4" id="formCard">
                        <div class="card-header <?php echo $form_header_bg; ?> py-2 fw-bold" id="formCardHeader">
                            <i class="fas fa-plus-circle me-1" id="formCardIcon"></i> <span id="formCardTitle">เพิ่มเงื่อนไขใหม่</span>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo htmlspecialchars(monitor_lab_page_url('tab=settings')); ?>" id="ruleForm">
                                <input type="hidden" name="action" id="form_action" value="add">
                                <input type="hidden" name="rule_id" id="rule_id" value="">
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <label class="form-label fw-bold">เลือกรายการยา — จาก HOSxP (TMT)</label>
                                        <select name="drug_hosxp" id="drug_hosxp" class="form-select select2-hosxp" <?php echo ($has_drug_icode_col && $has_hosxp_drugs) ? 'required' : 'disabled'; ?>><?php echo $opt_hosxp_drugs; ?></select>
                                    </div>
                                    <?php if ($is_other): ?>
                                    <div class="col-md-4">
                                        <label class="form-label fw-bold">เลือกรายการ Lab — จาก HOSxP (lab_items)</label>
                                        <select name="lab_hosxp" id="lab_hosxp" class="form-select select2-lab" <?php echo ($has_drug_icode_col && $has_lab_items_col) ? 'required' : 'disabled'; ?>></select>
                                        <label class="form-label small text-muted mt-2 mb-1">รหัส Lab เพิ่มเติม (ถ้ามีหลาย code ในรพ.)</label>
                                        <input type="text" name="lab_extra_codes" id="lab_extra_codes" class="form-control form-control-sm" placeholder="เช่น 1100 หรือ 1100,132">
                                        <input type="hidden" name="lab_type" value="CUSTOM">
                                    </div>
                                    <?php else: ?>
                                    <div class="col-md-2">
                                        <label class="form-label fw-bold">ผล Lab อ้างอิง</label>
                                        <select name="lab_type" id="lab_type" class="form-select border-primary" required>
                                            <?php if ($is_renal): ?>
                                            <option value="GFR">ค่าไต: CrCl (ml/min)</option>
                                            <option value="CKD_EPI">ค่าไต: CKD-EPI eGFR (ml/min/1.73m²)</option>
                                            <option value="SERUM_CR">ค่าไต: Serum Creatinine (mg/dL)</option>
                                            <?php else: ?>
                                            <option value="Bilirubin">ค่าตับ: T.Bilirubin (mg/dL)</option>
                                            <option value="Bilirubin_xULN">ค่าตับ: T.Bilirubin (เท่าของ ULN)</option>
                                            <option value="DirectBilirubin">ค่าตับ: Direct Bilirubin (mg/dL)</option>
                                            <option value="IndirectBilirubin">ค่าตับ: Indirect Bilirubin (mg/dL)</option>
                                            <option value="AST">ค่าตับ: AST (ค่าจริง U/L)</option>
                                            <option value="ALT">ค่าตับ: ALT (ค่าจริง U/L)</option>
                                            <option value="AST_xULN">ค่าตับ: AST (เท่าของ ULN)</option>
                                            <option value="ALT_xULN">ค่าตับ: ALT (เท่าของ ULN)</option>
                                            <option value="AST_ALT_xULN">ค่าตับ: AST/ALT สูงสุด (เท่าของ ULN)</option>
                                            <option value="CHILD_PUGH">ค่าตับ: Child-Pugh (คะแนน 5–15)</option>
                                            <option value="MELD_NA">ค่าตับ: MELD-Na (คะแนน)</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <?php endif; ?>
                                    <?php if ($is_other): ?>
                                    <div class="col-md-12">
                                        <div class="row g-2 align-items-end" id="otherConditionBlock">
                                            <div class="col-md-4">
                                                <label class="form-label fw-bold">รูปแบบเงื่อนไข</label>
                                                <select name="lab_condition_type" id="lab_condition_type" class="form-select border-info">
                                                    <?php foreach ($lab_condition_labels as $ck => $clbl): ?>
                                                    <option value="<?php echo htmlspecialchars($ck); ?>"><?php echo htmlspecialchars($clbl); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="col-md-8" id="otherTextCondWrap">
                                                <label class="form-label fw-bold">ค่าที่ต้องการดักจับ</label>
                                                <input type="text" class="form-control" name="lab_condition_value" id="lab_condition_value" placeholder="เช่น 2\+|3\+|4\+ หรือ Positive">
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <div class="col-md-12">
                                        <div id="lab_range_hint" class="form-text text-primary fw-bold"></div>
                                    </div>
                                    <div class="col-md-2 other-range-field">
                                        <label class="form-label fw-bold text-danger">ช่วง Lab ต่ำสุด</label>
                                        <input type="number" step="0.01" class="form-control" name="min_val" id="min_val" placeholder="เช่น 45" <?php echo $is_other ? '' : 'required'; ?>>
                                    </div>
                                    <div class="col-md-2 other-range-field">
                                        <label class="form-label fw-bold text-danger">ช่วง Lab สูงสุด</label>
                                        <input type="number" step="0.01" class="form-control" name="max_val" id="max_val" placeholder="เช่น 60" <?php echo $is_other ? '' : 'required'; ?>>
                                    </div>
                                    <div class="col-md-3 other-range-field">
                                        <label class="form-label fw-bold text-success">รูปแบบการปรับลด</label>
                                        <select name="action_type" id="action_type" class="form-select border-success" <?php echo $is_other ? '' : 'required'; ?>>
                                            <option value="percent">ลดลงตามเปอร์เซ็นต์ (%)</option>
                                            <option value="fixed">กำหนด Fix Dose คงที่</option>
                                            <option value="omit">OMIT (หลีกเลี่ยงการใช้)</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2 other-range-field">
                                        <label class="form-label fw-bold">ตัวเลข (% หรือ Fix)</label>
                                        <input type="number" step="0.01" class="form-control" name="action_value" id="action_value" placeholder="เช่น 25" value="0">
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label fw-bold">ระดับการเตือน</label>
                                        <select name="alert_level" id="alert_level" class="form-select fw-bold" required>
                                            <option value="soft" class="text-warning">Soft Alert</option>
                                            <option value="hard" class="text-danger">Hard Alert</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-bold">ข้อความแนะนำแพทย์ (แสดงที่ป้ายเตือน)</label>
                                        <input type="text" class="form-control" name="suggestion_msg" id="suggestion_msg" placeholder="เช่น ลด dose 25% เนื่องจาก CrCl 45-60" required>
                                    </div>
                                </div>
                                <div class="border rounded p-3 mt-3 bg-white">
                                    <div class="form-check form-switch mb-2">
                                        <input class="form-check-input" type="checkbox" role="switch" id="use_dose_condition" name="use_dose_condition" value="1">
                                        <label class="form-check-label fw-bold text-primary" for="use_dose_condition">
                                            <i class="fas fa-pills me-1"></i> กำหนดเงื่อนไขขนาดยาที่สั่งใช้ (mg/วัน)
                                        </label>
                                        <small class="text-muted d-block ms-4">เปิดใช้เมื่อต้องการแยกกฎตามขนาดยาจริงที่สั่ง — เช่น eGFR 30–45 + metformin สูงสุด 1000 mg/วัน (ปิด = ใช้เฉพาะ Lab)</small>
                                    </div>
                                    <div class="row g-3 dose-fields disabled-section" id="doseFields">
                                        <div class="col-md-3">
                                            <label class="form-label fw-bold text-primary">ขนาดยาต่ำสุด (mg/วัน)</label>
                                            <input type="number" step="1" min="0" class="form-control" name="dose_min" id="dose_min" placeholder="เช่น 0">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label fw-bold text-primary">ขนาดยาสูงสุด (mg/วัน)</label>
                                            <input type="number" step="1" min="0" class="form-control" name="dose_max" id="dose_max" placeholder="เช่น 1000">
                                        </div>
                                        <div class="col-md-2 d-flex align-items-end">
                                            <div class="form-control bg-light text-center fw-bold text-secondary">mg/วัน</div>
                                            <input type="hidden" name="dose_unit" id="dose_unit" value="<?php echo htmlspecialchars($dose_unit_fixed); ?>">
                                        </div>
                                    </div>
                                </div>
                                <?php if ($has_dose_per_admin_col): ?>
                                <div class="border rounded p-3 mt-3 bg-white">
                                    <div class="form-check form-switch mb-2">
                                        <input class="form-check-input" type="checkbox" role="switch" id="use_dose_per_admin_condition" name="use_dose_per_admin_condition" value="1">
                                        <label class="form-check-label fw-bold text-primary" for="use_dose_per_admin_condition">
                                            <i class="fas fa-syringe me-1"></i> กำหนดเงื่อนไขขนาดยาต่อครั้ง (mg/ครั้ง)
                                        </label>
                                        <small class="text-muted d-block ms-4">เปิดเมื่อต้องการแยกกฎตามขนาดต่อครั้งจากวิธีใช้ — เช่น Tazocin 2.25 g q8h ที่ eGFR &lt; 20 (ไม่คูณจำนวนครั้งต่อวัน)</small>
                                    </div>
                                    <div class="row g-3 dose-per-admin-fields disabled-section" id="dosePerAdminFields">
                                        <div class="col-md-3">
                                            <label class="form-label fw-bold text-primary">ขนาดยาต่ำสุด (mg/ครั้ง)</label>
                                            <input type="number" step="1" min="0" class="form-control" name="dose_per_admin_min" id="dose_per_admin_min" placeholder="เช่น 0">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label fw-bold text-primary">ขนาดยาสูงสุด (mg/ครั้ง)</label>
                                            <input type="number" step="1" min="0" class="form-control" name="dose_per_admin_max" id="dose_per_admin_max" placeholder="เช่น 2250">
                                        </div>
                                        <div class="col-md-2 d-flex align-items-end">
                                            <div class="form-control bg-light text-center fw-bold text-secondary">mg/ครั้ง</div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if ($has_duration_col): ?>
                                <div class="border rounded p-3 mt-3 bg-white">
                                    <div class="form-check form-switch mb-2">
                                        <input class="form-check-input" type="checkbox" role="switch" id="use_duration_condition" name="use_duration_condition" value="1">
                                        <label class="form-check-label fw-bold text-success" for="use_duration_condition">
                                            <i class="fas fa-clock me-1"></i> กำหนดเงื่อนไข Duration / ช่วงให้ยา (ชั่วโมง)
                                        </label>
                                        <small class="text-muted d-block ms-4">ช่วงให้ยาที่แนะนำ — เตือนเมื่อวิธีใช้จริงไม่อยู่ในช่วงนี้ เช่น Amikacin eGFR &lt; 10 ต้อง q 48 ชม. ให้ตั้งต่ำสุด 48 สูงสุด 48</small>
                                    </div>
                                    <div class="row g-3 duration-fields disabled-section" id="durationFields">
                                        <div class="col-md-3">
                                            <label class="form-label fw-bold text-success">Duration ต่ำสุด (ชั่วโมง)</label>
                                            <input type="number" step="1" min="0" class="form-control" name="duration_min" id="duration_min" placeholder="เช่น 48">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label fw-bold text-success">Duration สูงสุด (ชั่วโมง)</label>
                                            <input type="number" step="1" min="0" class="form-control" name="duration_max" id="duration_max" placeholder="เช่น 48">
                                        </div>
                                        <div class="col-md-2 d-flex align-items-end">
                                            <div class="form-control bg-light text-center fw-bold text-secondary">ชั่วโมง</div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if ($has_exempt_col): ?>
                                <div class="border rounded p-3 mt-3 bg-white">
                                    <label class="form-label fw-bold text-secondary mb-1">
                                        <i class="fas fa-ban me-1"></i> ข้อยกเว้นในวิธีใช้ (ไม่เตือนถ้าพบคำเหล่านี้)
                                    </label>
                                    <textarea class="form-control" name="exempt_method_patterns" id="exempt_method_patterns"
                                           rows="3" placeholder="เช่น ADD PD&#10;CYCLE / DAY&#10;ATB lock"></textarea>
                                    <small class="text-muted d-block mt-1">
                                        คั่นด้วยจุลภาค หรือขึ้นบรรทัดใหม่ — เช่น <code>ADD PD</code>, <code>CYCLE / DAY</code> สำหรับยาใส่ถุงล้างไต (PD)<br>
                                        ใช้ร่วมกัน<b>ทุกกฎของยา icode เดียวกัน</b> ใส่ที่กฎใดกฎหนึ่งแล้วกด <b>บันทึก</b> ระบบจะคัดลอกให้ทุกช่วง eGFR ของยานี้<br>
                                        ต้องกดแก้ไขกฎยาที่มีอยู่ ไม่ใช่พิมพ์ในฟอร์มว่างแล้วบันทึกอย่างเดียว (ต้องมียา / ช่วง Lab / ข้อความแนะนำด้วย)
                                    </small>
                                </div>
                                <?php endif; ?>
                                <?php if ($has_first_order_col): ?>
                                <div class="border rounded p-3 mt-3 bg-white">
                                    <div class="form-check form-switch mb-2">
                                        <input class="form-check-input" type="checkbox" role="switch" id="first_order_only" name="first_order_only" value="1">
                                        <label class="form-check-label fw-bold text-danger" for="first_order_only">
                                            ดักเฉพาะการสั่งยาครั้งแรก (ห้ามเริ่มยา)
                                        </label>
                                    </div>
                                    <small class="text-muted d-block mb-2">
                                        ใช้เมื่อ<b>ห้ามเริ่มยา</b>ตามค่า Lab แต่<b>กินต่อได้</b>ถ้าเคยได้รับมาแล้ว
                                        เช่น Dapagliflozin เมื่อ eGFR &lt; 25 — เตือนเฉพาะผู้ป่วยที่ยังไม่เคยมีใบยานี้ใน HOSxP
                                    </small>
                                    <div class="row g-2 first-order-fields disabled-section" id="firstOrderFields">
                                        <div class="col-md-5">
                                            <label class="form-label small fw-bold mb-1">ถือว่าเริ่มใหม่ถ้าไม่มีใบยาก่อนหน้าภายใน (วัน)</label>
                                            <input type="number" min="0" step="1" class="form-control form-control-sm" name="first_order_lookback_days" id="first_order_lookback_days" placeholder="ว่างหรือ 0 = เคยมีใบยาใดๆ มาก่อนถือว่ากินต่อ">
                                        </div>
                                        <div class="col-md-7 d-flex align-items-end">
                                            <small class="text-muted">ตัวอย่าง 180 = ถ้าเว้นยาเกิน 180 วันแล้วสั่งใหม่ จะถือว่าเป็นการเริ่มยาและเตือนอีกครั้ง</small>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if ($is_renal && $has_patient_extra_col): ?>
                                <div class="border rounded p-3 mt-3 bg-white">
                                    <div class="small text-muted mb-2">
                                        <i class="fas fa-user-md me-1 text-primary"></i>
                                        เงื่อนไขเพิ่มเติม: ต้องพบเงื่อนไข Lab <b>และ</b> อย่างน้อยหนึ่งใน (อายุ <b>หรือ</b> น้ำหนัก) — ตัวอย่าง Apixaban: Serum Cr 1.5–99 + อายุ ≥80 หรือ นน. ≤60
                                    </div>
                                    <div class="row g-3">
                                        <div class="col-md-4">
                                            <div class="form-check form-switch mb-2">
                                                <input class="form-check-input" type="checkbox" role="switch" id="use_age_condition" name="use_age_condition" value="1">
                                                <label class="form-check-label fw-bold text-primary" for="use_age_condition">เงื่อนไขอายุ (ปี)</label>
                                            </div>
                                            <div class="row g-2 age-fields disabled-section" id="ageFields">
                                                <div class="col-6">
                                                    <label class="form-label small fw-bold">อายุต่ำสุด</label>
                                                    <input type="number" step="1" min="0" class="form-control form-control-sm" name="age_min" id="age_min" placeholder="เช่น 80">
                                                </div>
                                                <div class="col-6">
                                                    <label class="form-label small fw-bold">อายุสูงสุด</label>
                                                    <input type="number" step="1" min="0" class="form-control form-control-sm" name="age_max" id="age_max" placeholder="เช่น 999">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-check form-switch mb-2">
                                                <input class="form-check-input" type="checkbox" role="switch" id="use_weight_condition" name="use_weight_condition" value="1">
                                                <label class="form-check-label fw-bold text-primary" for="use_weight_condition">เงื่อนไขน้ำหนัก (kg)</label>
                                            </div>
                                            <div class="row g-2 weight-fields disabled-section" id="weightFields">
                                                <div class="col-6">
                                                    <label class="form-label small fw-bold">น้ำหนักต่ำสุด</label>
                                                    <input type="number" step="0.1" min="0" class="form-control form-control-sm" name="weight_min" id="weight_min" placeholder="เช่น 0">
                                                </div>
                                                <div class="col-6">
                                                    <label class="form-label small fw-bold">น้ำหนักสูงสุด</label>
                                                    <input type="number" step="0.1" min="0" class="form-control form-control-sm" name="weight_max" id="weight_max" placeholder="เช่น 60">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div class="row mt-3 g-2 align-items-center">
                                    <div class="col-md-4">
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" name="active_status" id="active_status" value="1" checked>
                                            <label class="form-check-label fw-bold" for="active_status">เปิดใช้งานกฎนี้</label>
                                        </div>
                                        <div class="form-text">ปิดแล้วจะไม่เฝ้าระวัง ไม่เข้า Intervention Log และไม่แจ้ง Telegram — กฎยังอยู่ในรายการนี้</div>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn <?php echo $is_renal ? 'btn-danger' : ($is_hepatic ? 'btn-warning text-dark' : 'btn-info'); ?> w-100 fw-bold" id="btnSubmit"><i class="fas fa-save me-1"></i> บันทึกกฎ</button>
                                    </div>
                                    <div class="col-md-2 d-none" id="btnCancelWrap">
                                        <button type="button" class="btn btn-secondary w-100 fw-bold" id="btnCancelEdit"><i class="fas fa-times me-1"></i> ยกเลิก</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h6 class="fw-bold text-secondary mb-2"><i class="fas fa-list me-2"></i>รายการกฎที่ตั้งไว้</h6>
                            <p class="small text-muted mb-3">กดปุ่ม <b>เปิด/ปิด</b> ทีละรายการได้โดยไม่ต้องลบกฎ — กฎที่ปิดจะไม่เฝ้าระวัง ไม่เข้า Intervention Log และไม่แจ้ง Telegram</p>
                            <table class="table table-bordered table-striped align-middle text-center">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ชื่อยา</th><th><?php echo $is_other ? 'รายการ Lab (รหัส)' : 'เงื่อนไข Lab'; ?></th><th>ต่ำสุด</th><th>สูงสุด</th>
                                        <?php if ($is_renal && $has_patient_extra_col): ?><th>อายุ/นน.</th><?php endif; ?>
                                        <th>เงื่อนไข Dose</th><?php if ($has_duration_col): ?><th>Duration</th><?php endif; ?><th>Action</th><th>Alert</th><th>ข้อความเตือน</th><th>เปิด</th><th>จัดการ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $exempt_by_icode = [];
                                    if ($has_exempt_col) {
                                        $eq = mysqli_query($con, "SELECT drug_icode, exempt_method_patterns
                                            FROM drug_safety_rules
                                            WHERE lab_type IN ($organ_lab_types_sql)
                                              AND TRIM(IFNULL(exempt_method_patterns,'')) <> ''");
                                        $chunks = [];
                                        while ($eq && ($er = mysqli_fetch_assoc($eq))) {
                                            $ic = trim((string)($er['drug_icode'] ?? ''));
                                            $s = trim((string)($er['exempt_method_patterns'] ?? ''));
                                            if ($ic === '' || $s === '') {
                                                continue;
                                            }
                                            if (!isset($chunks[$ic])) {
                                                $chunks[$ic] = [];
                                            }
                                            $chunks[$ic][] = $s;
                                        }
                                        foreach ($chunks as $ic => $list) {
                                            $exempt_by_icode[$ic] = monitor_lab_normalize_exempt_patterns(implode(', ', $list));
                                        }
                                    }
                                    $sql = monitor_lab_rules_sql($organ_lab_types_sql, $has_drug_icode_col);
                                    $q = mysqli_query($con, $sql);
                                    if ($q):
                                    while ($row = mysqli_fetch_assoc($q)):
                                        $action = $row['action_type'] == 'percent' ? "ลด {$row['action_value']}%" : ($row['action_type'] == 'fixed' ? "Fix: {$row['action_value']}" : "OMIT");
                                        $badge = $row['action_type'] == 'omit' ? 'bg-dark' : 'bg-warning text-dark';
                                        $dose_cond = '-';
                                        $dose_parts = [];
                                        if (!empty($row['use_dose_condition'])) {
                                            $dose_parts[] = "{$row['dose_min']} – {$row['dose_max']} mg/วัน";
                                        }
                                        if ($has_dose_per_admin_col && !empty($row['use_dose_per_admin_condition'])) {
                                            $dose_parts[] = "{$row['dose_per_admin_min']} – {$row['dose_per_admin_max']} mg/ครั้ง";
                                        }
                                        if (!empty($dose_parts)) {
                                            $dose_cond = implode('<br>', $dose_parts);
                                        }
                                        $duration_cond = '-';
                                        if ($has_duration_col && !empty($row['use_duration_condition'])) {
                                            $dmin = ($row['duration_min'] !== '' && $row['duration_min'] !== null) ? (float)$row['duration_min'] : 0;
                                            $dmax = ($row['duration_max'] !== '' && $row['duration_max'] !== null) ? (float)$row['duration_max'] : PHP_FLOAT_MAX;
                                            $duration_cond = hosxp_format_interval_range($dmin, $dmax);
                                        }
                                        $patient_extra_cond = '-';
                                        if ($is_renal && $has_patient_extra_col) {
                                            $parts = [];
                                            if (!empty($row['use_age_condition'])) {
                                                $parts[] = 'อายุ ' . $row['age_min'] . '–' . $row['age_max'] . ' ปี';
                                            }
                                            if (!empty($row['use_weight_condition'])) {
                                                $parts[] = 'นน. ' . $row['weight_min'] . '–' . $row['weight_max'] . ' kg';
                                            }
                                            if (!empty($parts)) {
                                                $patient_extra_cond = implode(' <b>หรือ</b> ', $parts);
                                            }
                                        }
                                        $drug_hosxp_val = trim($row['display_icode'] ?? '') . '|' . trim($row['display_drug_name'] ?? '');
                                        $lab_code_parts = monitor_lab_parse_codes($row['lab_items_code'] ?? '');
                                        $lab_primary = $lab_code_parts[0] ?? '';
                                        $lab_extra_codes = implode(',', array_slice($lab_code_parts, 1));
                                        $lab_hosxp_val = $lab_primary . '|' . trim($row['lab_items_name'] ?? '');
                                        $lvl = monitor_lab_alert_level_from_row($row);
                                        $rule_payload = [
                                            'id' => $row['id'], 'drug_hosxp' => $drug_hosxp_val, 'lab_type' => $row['lab_type'],
                                            'min_val' => $row['min_val'], 'max_val' => $row['max_val'],
                                            'use_dose_condition' => (int)$row['use_dose_condition'],
                                            'dose_min' => $row['dose_min'], 'dose_max' => $row['dose_max'], 'dose_unit' => $row['dose_unit'] ?? '',
                                            'use_dose_per_admin_condition' => (int)($row['use_dose_per_admin_condition'] ?? 0),
                                            'dose_per_admin_min' => $row['dose_per_admin_min'] ?? '',
                                            'dose_per_admin_max' => $row['dose_per_admin_max'] ?? '',
                                            'use_duration_condition' => (int)($row['use_duration_condition'] ?? 0),
                                            'duration_min' => $row['duration_min'] ?? '',
                                            'duration_max' => $row['duration_max'] ?? '',
                                            'exempt_method_patterns' => $exempt_by_icode[trim((string)($row['display_icode'] ?? $row['drug_icode'] ?? ''))] ?? ($row['exempt_method_patterns'] ?? ''),
                                            'first_order_only' => (int)($row['first_order_only'] ?? 0),
                                            'first_order_lookback_days' => (int)($row['first_order_lookback_days'] ?? 0),
                                            'action_type' => $row['action_type'], 'action_value' => $row['action_value'],
                                            'suggestion_msg' => $row['suggestion_msg'],
                                            'alert_level' => $lvl,
                                            'active_status' => (int)!empty($row['active_status']),
                                        ];
                                        if ($is_renal && $has_patient_extra_col) {
                                            $rule_payload['use_age_condition'] = (int)($row['use_age_condition'] ?? 0);
                                            $rule_payload['age_min'] = $row['age_min'];
                                            $rule_payload['age_max'] = $row['age_max'];
                                            $rule_payload['use_weight_condition'] = (int)($row['use_weight_condition'] ?? 0);
                                            $rule_payload['weight_min'] = $row['weight_min'];
                                            $rule_payload['weight_max'] = $row['weight_max'];
                                        }
                                        if ($is_other) {
                                            $rule_payload['lab_hosxp'] = $lab_hosxp_val;
                                            $rule_payload['lab_extra_codes'] = $lab_extra_codes;
                                            $rule_payload['lab_items_code'] = trim($row['lab_items_code'] ?? '');
                                            $rule_payload['lab_condition_type'] = $row['lab_condition_type'] ?? 'range';
                                            $rule_payload['lab_condition_value'] = $row['lab_condition_value'] ?? '';
                                        }
                                        $rule_json = htmlspecialchars(json_encode($rule_payload, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
                                        $rule_active = !empty($row['active_status']);
                                    ?>
                                    <tr id="rule-<?php echo (int)$row['id']; ?>" data-rule-id="<?php echo $row['id']; ?>" class="<?php echo $rule_active ? '' : 'table-secondary'; ?>">
                                        <td class="fw-bold text-primary text-start">
                                            <?php echo htmlspecialchars($row['display_drug_name']); ?>
                                            <?php if (!empty($row['display_icode'])): ?>
                                            <br><small class="text-muted">icode: <?php echo htmlspecialchars($row['display_icode']); ?></small>
                                            <?php endif; ?>
                                            <?php
                                            $row_exempt = $exempt_by_icode[trim((string)($row['display_icode'] ?? $row['drug_icode'] ?? ''))] ?? trim((string)($row['exempt_method_patterns'] ?? ''));
                                            if ($has_exempt_col && $row_exempt !== ''):
                                            ?>
                                            <div class="small text-secondary mt-1"><i class="fas fa-ban me-1"></i>ยกเว้นวิธีใช้: <?php echo htmlspecialchars($row_exempt); ?></div>
                                            <?php endif; ?>
                                            <?php if ($has_first_order_col && !empty($row['first_order_only'])): ?>
                                            <div class="mt-1"><span class="badge bg-danger">ครั้งแรกเท่านั้น<?php
                                                $lb = (int)($row['first_order_lookback_days'] ?? 0);
                                                echo $lb > 0 ? ' (' . $lb . ' วัน)' : '';
                                            ?></span></div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($is_other && !empty($row['lab_items_code'])): ?>
                                            <span class="badge bg-secondary"><?php echo htmlspecialchars($row['lab_items_code']); ?></span>
                                            <div class="small text-dark mt-1"><?php echo htmlspecialchars($row['lab_items_name'] ?? ''); ?></div>
                                            <?php
                                            $row_cond_type = $row['lab_condition_type'] ?? 'range';
                                            if ($row_cond_type !== 'range' && ($row['lab_condition_value'] ?? '') !== ''): ?>
                                            <div class="small text-primary mt-1"><?php echo htmlspecialchars($lab_condition_labels[$row_cond_type] ?? $row_cond_type); ?>: <?php echo htmlspecialchars($row['lab_condition_value']); ?></div>
                                            <?php else: ?>
                                            <div class="small text-muted mt-1">ช่วง <?php echo htmlspecialchars($row['min_val']); ?>–<?php echo htmlspecialchars($row['max_val']); ?></div>
                                            <?php endif; ?>
                                            <?php else: ?>
                                            <span class="badge bg-info text-dark"><?php echo htmlspecialchars($lab_type_labels[$row['lab_type']] ?? $row['lab_type']); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-danger fw-bold"><?php echo $row['min_val']; ?></td>
                                        <td class="text-danger fw-bold"><?php echo $row['max_val']; ?></td>
                                        <?php if ($is_renal && $has_patient_extra_col): ?>
                                        <td class="small"><?php if ($patient_extra_cond !== '-'): ?><span class="badge bg-secondary"><?php echo $patient_extra_cond; ?></span><?php else: ?><span class="text-muted">ไม่กำหนด</span><?php endif; ?></td>
                                        <?php endif; ?>
                                        <td><?php if (empty($dose_parts)): ?><span class="text-muted">ไม่กำหนด</span><?php else: ?><?php foreach ($dose_parts as $dp): ?><div class="mb-1"><span class="badge bg-primary"><?php echo htmlspecialchars($dp); ?></span></div><?php endforeach; ?><?php endif; ?></td>
                                        <?php if ($has_duration_col): ?>
                                        <td><?php if (!empty($row['use_duration_condition'])): ?><span class="badge bg-success"><?php echo htmlspecialchars($duration_cond); ?></span><?php else: ?><span class="text-muted">ไม่กำหนด</span><?php endif; ?>
                                        </td>
                                        <?php endif; ?>
                                        <td><span class="badge <?php echo $badge; ?>"><?php echo $action; ?></span></td>
                                        <td><?php echo monitor_lab_alert_level_badge($lvl); ?></td>
                                        <td class="text-start"><?php echo htmlspecialchars($row['suggestion_msg']); ?></td>
                                        <td>
                                            <form method="POST" action="<?php echo htmlspecialchars(monitor_lab_page_url('tab=settings')); ?>" class="d-inline">
                                                <input type="hidden" name="action" value="toggle">
                                                <input type="hidden" name="rule_id" value="<?php echo (int)$row['id']; ?>">
                                                <?php if ($rule_active): ?>
                                                <button type="submit" class="btn btn-sm btn-success fw-bold" title="คลิกเพื่อปิดกฎนี้">เปิด</button>
                                                <?php else: ?>
                                                <input type="hidden" name="active" value="1">
                                                <button type="submit" class="btn btn-sm btn-outline-secondary fw-bold" title="คลิกเพื่อเปิดกฎนี้">ปิด</button>
                                                <?php endif; ?>
                                            </form>
                                        </td>
                                        <td class="text-nowrap">
                                            <button type="button" class="btn btn-sm btn-outline-primary btn-edit-rule me-1" title="แก้ไข" data-rule="<?php echo $rule_json; ?>"><i class="fas fa-edit"></i></button>
                                            <button type="button" class="btn btn-sm btn-outline-secondary btn-copy-rule me-1" title="คัดลอก" data-rule="<?php echo $rule_json; ?>"><i class="fas fa-copy"></i></button>
                                            <a href="<?php echo htmlspecialchars(monitor_lab_page_url('tab=settings&del=' . $row['id'])); ?>" class="btn btn-sm btn-outline-danger" title="ลบ" onclick="return confirm('ยืนยันการลบเงื่อนไขนี้?')"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                    <?php endwhile; else: ?>
                                    <tr><td colspan="<?php echo (($is_renal && $has_patient_extra_col) ? 11 : 10) + ($has_duration_col ? 1 : 0); ?>" class="text-center text-danger py-3">ไม่สามารถโหลดรายการกฎได้ — กรุณารัน <a href="upgrade.php">อัปเกรดระบบ</a></td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

            </div><!-- /mainSettings -->

            <?php endif; ?>

        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/monitor_hn_filter.js"></script>
<?php if ($lab_page_tab === 'monitor'): ?>
<script src="js/chart.min.js"></script>
<script src="js/flatpickr.min.js"></script>
<?php elseif ($lab_settings_tab): ?>
<script src="js/select2.min.js"></script>
<?php endif; ?>
<script>
    const LAB_PAGE_TAB = <?php echo json_encode($lab_page_tab); ?>;
    const LAB_SETTINGS_TAB = <?php echo $lab_settings_tab ? 'true' : 'false'; ?>;
    const MONITOR_ORGAN = <?php echo json_encode($organ); ?>;
    const MLC_CURRENT_USER_ID = <?php echo (int)$current_user_id; ?>;
    const MLC_REPLY_WAIT = <?php echo (int)$mlc_reply_wait_days; ?>;
    const IS_OTHER_LAB = <?php echo $is_other ? 'true' : 'false'; ?>;
    const IS_RENAL_LAB = <?php echo $is_renal ? 'true' : 'false'; ?>;
    let summaryChart = null;

    const LAB_TYPE_HINTS_ALL = {
        'GFR': { min: '45', max: '60', text: 'ช่วง CrCl (ml/min) — คำนวณจาก Serum Cr' },
        'CKD_EPI': { min: '45', max: '60', text: 'ช่วง eGFR CKD-EPI (ml/min/1.73m²) — ดึงจาก HOSxP' },
        'SERUM_CR': { min: '1.5', max: '99', text: 'ช่วง Serum Creatinine (mg/dL) — ดึงจาก HOSxP (เช่น Apixaban ≥1.5)' },
        'Bilirubin': { min: '1.2', max: '3', text: 'ช่วง T.Bilirubin (mg/dL)' },
        'Bilirubin_xULN': { min: '1.25', max: '5', text: 'ช่วง T.Bilirubin เป็นเท่าของ ULN (เช่น 1.25–2× = ลด dose, ≥5× = OMIT)' },
        'DirectBilirubin': { min: '0.3', max: '1.5', text: 'ช่วง Direct Bilirubin (mg/dL)' },
        'IndirectBilirubin': { min: '1', max: '5', text: 'ช่วง Indirect Bilirubin (mg/dL)' },
        'AST': { min: '40', max: '200', text: 'ช่วงค่า AST จริง (U/L)' },
        'ALT': { min: '40', max: '200', text: 'ช่วงค่า ALT จริง (U/L)' },
        'AST_xULN': { min: '2', max: '10', text: 'ช่วงเป็นจำนวนเท่าของ ULN (เช่น 2–10× ULN)' },
        'ALT_xULN': { min: '2', max: '10', text: 'ช่วงเป็นจำนวนเท่าของ ULN (เช่น 2–10× ULN)' },
        'AST_ALT_xULN': { min: '10', max: '99', text: 'ช่วง Max(AST,ALT)/ULN — เช่น ≥10× = ต่ำสุด 10 สูงสุด 99' },
        'CHILD_PUGH': { min: '7', max: '15', text: 'คะแนน Child-Pugh 5–15 (A 5–6, B 7–9, C 10–15) — Severe เริ่มที่ 7 (class B) หรือเทียบเท่า MELD-Na ≥ 15 / Decompensated' },
        'MELD_NA': { min: '15', max: '40', text: 'คะแนน MELD-Na — ≥ 15 = ความเสี่ยงเสียชีวิตระยะสั้นสูงและเสี่ยง HRS' }
    };
    const LAB_TYPE_HINTS = LAB_TYPE_HINTS_ALL;
    const LAB_TYPE_DISPLAY = <?php echo json_encode($lab_type_labels, JSON_UNESCAPED_UNICODE); ?>;

    function ensureHosxpSelectOption($sel, val, label) {
        if (!val) return;
        if ($sel.find('option').filter(function() { return this.value === val; }).length === 0) {
            $sel.append(new Option(label || val, val, true, true));
        }
    }

    function ensureLabSelectOption($sel, val, label) {
        ensureHosxpSelectOption($sel, val, label);
    }

    function initLabSelect2() {
        if (!IS_OTHER_LAB || !$('#lab_hosxp').length) return;
        $('#lab_hosxp').select2({
            theme: 'bootstrap-5',
            width: '100%',
            placeholder: 'ค้นหารหัสหรือชื่อ Lab จาก HOSxP...',
            allowClear: true,
            minimumInputLength: 1,
            ajax: {
                url: 'search_lab_items_api.php',
                dataType: 'json',
                delay: 250,
                data: params => ({ q: params.term || '' }),
                processResults: data => data
            }
        });
    }

    function toggleOtherConditionMode() {
        if (!IS_OTHER_LAB) return;
        const mode = $('#lab_condition_type').val() || 'range';
        const isRange = mode === 'range';
        $('.other-range-field').toggle(isRange);
        $('#otherTextCondWrap').toggle(!isRange);
        $('#lab_condition_value').prop('required', !isRange);
        $('#min_val, #max_val').prop('required', isRange);
        if (!isRange) {
            $('#min_val, #max_val').val('0');
            $('#action_type').val('omit');
            $('#action_value').val('0');
        }
        updateLabRangeHint();
    }

    function updateLabRangeHint() {
        if (IS_OTHER_LAB) {
            const mode = $('#lab_condition_type').val() || 'range';
            if (mode === 'range') {
                $('#lab_range_hint').html('<i class="fas fa-info-circle me-1"></i>กำหนดช่วงค่าผล Lab ตามหน่วยของรายการที่เลือก (ค่าตัวเลขจาก lab_order_result)');
                if ($('#form_action').val() === 'add') {
                    $('#min_val').attr('placeholder', 'เช่น 0');
                    $('#max_val').attr('placeholder', 'เช่น 100');
                }
            } else if (mode === 'regex') {
                $('#lab_range_hint').html('<i class="fas fa-info-circle me-1"></i>Regex — รวมหลายรูปแบบด้วย <code>|</code> เช่น <code>2\\+|3\\+|4\\+</code>');
            } else if (mode === 'contains') {
                $('#lab_range_hint').html('<i class="fas fa-info-circle me-1"></i>มีคำว่า — หาคำเดียวต่อครั้ง (หลายคำให้ใช้ Regex)');
            } else {
                $('#lab_range_hint').html('<i class="fas fa-info-circle me-1"></i>เปรียบเทียบตัวเลขจากผล Lab (float)');
            }
            return;
        }
        const t = $('#lab_type').val();
        const h = LAB_TYPE_HINTS[t];
        if (!h) {
            $('#lab_range_hint').text('');
            return;
        }
        $('#lab_range_hint').html('<i class="fas fa-info-circle me-1"></i>' + h.text);
        if ($('#form_action').val() === 'add') {
            $('#min_val').attr('placeholder', h.min);
            $('#max_val').attr('placeholder', h.max);
        }
    }

    function toggleDoseFields() {
        const on = $('#use_dose_condition').is(':checked');
        const $sec = $('#doseFields');
        if (on) {
            $sec.removeClass('disabled-section');
            $('#dose_min, #dose_max').prop('required', true);
        } else {
            $sec.addClass('disabled-section');
            $('#dose_min, #dose_max').prop('required', false);
        }
    }

    function toggleDosePerAdminFields() {
        if (!$('#use_dose_per_admin_condition').length) return;
        const on = $('#use_dose_per_admin_condition').is(':checked');
        const $sec = $('#dosePerAdminFields');
        if (on) {
            $sec.removeClass('disabled-section');
            $('#dose_per_admin_min, #dose_per_admin_max').prop('required', true);
        } else {
            $sec.addClass('disabled-section');
            $('#dose_per_admin_min, #dose_per_admin_max').prop('required', false);
        }
    }

    function toggleDurationFields() {
        if (!$('#use_duration_condition').length) return;
        const on = $('#use_duration_condition').is(':checked');
        const $sec = $('#durationFields');
        if (on) {
            $sec.removeClass('disabled-section');
            $('#duration_min, #duration_max').prop('required', true);
        } else {
            $sec.addClass('disabled-section');
            $('#duration_min, #duration_max').prop('required', false);
        }
    }

    function toggleFirstOrderFields() {
        if (!$('#first_order_only').length) return;
        const on = $('#first_order_only').is(':checked');
        const $sec = $('#firstOrderFields');
        if (on) {
            $sec.removeClass('disabled-section');
        } else {
            $sec.addClass('disabled-section');
        }
    }

    function toggleAgeFields() {
        if (!IS_RENAL_LAB || !$('#use_age_condition').length) return;
        const on = $('#use_age_condition').is(':checked');
        const $sec = $('#ageFields');
        if (on) {
            $sec.removeClass('disabled-section');
            $('#age_min, #age_max').prop('required', true);
        } else {
            $sec.addClass('disabled-section');
            $('#age_min, #age_max').prop('required', false);
        }
    }

    function toggleWeightFields() {
        if (!IS_RENAL_LAB || !$('#use_weight_condition').length) return;
        const on = $('#use_weight_condition').is(':checked');
        const $sec = $('#weightFields');
        if (on) {
            $sec.removeClass('disabled-section');
            $('#weight_min, #weight_max').prop('required', true);
        } else {
            $sec.addClass('disabled-section');
            $('#weight_min, #weight_max').prop('required', false);
        }
    }

    function parseLabRuleData(el) {
        let raw = $(el).attr('data-rule');
        if (!raw) {
            raw = $(el).data('rule');
        }
        let rule = raw;
        if (typeof rule === 'string') {
            try { rule = JSON.parse(rule); } catch (e) { return null; }
        }
        return rule && (rule.lab_type || rule.lab_hosxp) ? rule : null;
    }

    function fillRuleForm(rule) {
        const drugParts = (rule.drug_hosxp || '').split('|');
        const drugLabel = drugParts.length > 1
            ? drugParts[1] + ' (icode: ' + drugParts[0] + ')'
            : rule.drug_hosxp;
        ensureHosxpSelectOption($('#drug_hosxp'), rule.drug_hosxp, drugLabel);
        $('#drug_hosxp').val(rule.drug_hosxp).trigger('change');
        if (IS_OTHER_LAB) {
            const labParts = (rule.lab_hosxp || '').split('|');
            const labLabel = labParts.length > 1
                ? '[' + labParts[0] + '] ' + labParts[1]
                : rule.lab_hosxp;
            ensureLabSelectOption($('#lab_hosxp'), rule.lab_hosxp, labLabel);
            $('#lab_hosxp').val(rule.lab_hosxp).trigger('change');
            $('#lab_extra_codes').val(rule.lab_extra_codes || '');
            $('#lab_condition_type').val(rule.lab_condition_type || 'range');
            $('#lab_condition_value').val(rule.lab_condition_value || '');
            toggleOtherConditionMode();
        } else {
            $('#lab_type').val(rule.lab_type);
        }
        updateLabRangeHint();
        $('#min_val').val(rule.min_val);
        $('#max_val').val(rule.max_val);
        $('#action_type').val(rule.action_type);
        $('#action_value').val(rule.action_value);
        $('#suggestion_msg').val(rule.suggestion_msg);
        $('#alert_level').val(rule.alert_level === 'hard' ? 'hard' : 'soft');
        $('#active_status').prop('checked', rule.active_status != 0);
        $('#use_dose_condition').prop('checked', rule.use_dose_condition == 1);
        $('#dose_min').val(rule.dose_min ?? '');
        $('#dose_max').val(rule.dose_max ?? '');
        $('#dose_unit').val('mg');
        toggleDoseFields();
        if ($('#use_dose_per_admin_condition').length) {
            $('#use_dose_per_admin_condition').prop('checked', rule.use_dose_per_admin_condition == 1);
            $('#dose_per_admin_min').val(rule.dose_per_admin_min ?? '');
            $('#dose_per_admin_max').val(rule.dose_per_admin_max ?? '');
            toggleDosePerAdminFields();
        }
        if ($('#use_duration_condition').length) {
            $('#use_duration_condition').prop('checked', rule.use_duration_condition == 1);
            $('#duration_min').val(rule.duration_min ?? '');
            $('#duration_max').val(rule.duration_max ?? '');
            toggleDurationFields();
        }
        if ($('#exempt_method_patterns').length) {
            $('#exempt_method_patterns').val(rule.exempt_method_patterns || '');
        }
        if ($('#first_order_only').length) {
            $('#first_order_only').prop('checked', rule.first_order_only == 1);
            $('#first_order_lookback_days').val(rule.first_order_lookback_days || '');
            toggleFirstOrderFields();
        }
        if (IS_RENAL_LAB && $('#use_age_condition').length) {
            $('#use_age_condition').prop('checked', rule.use_age_condition == 1);
            $('#age_min').val(rule.age_min ?? '');
            $('#age_max').val(rule.age_max ?? '');
            $('#use_weight_condition').prop('checked', rule.use_weight_condition == 1);
            $('#weight_min').val(rule.weight_min ?? '');
            $('#weight_max').val(rule.weight_max ?? '');
            toggleAgeFields();
            toggleWeightFields();
        }
    }

    function setAddMode() {
        $('#form_action').val('add');
        $('#rule_id').val('');
        $('#formCard').removeClass('edit-mode copy-mode');
        $('#formCardHeader').removeClass('bg-primary bg-secondary bg-warning text-dark').addClass('<?php echo $form_header_bg; ?>');
        $('#formCardIcon').removeClass('fa-edit fa-copy').addClass('fa-plus-circle');
        $('#formCardTitle').text('เพิ่มเงื่อนไขใหม่');
        $('#btnSubmit').removeClass('btn-primary').addClass('<?php echo $is_renal ? 'btn-danger' : ($is_hepatic ? 'btn-warning text-dark' : 'btn-info'); ?>').html('<i class="fas fa-save me-1"></i> บันทึกกฎ');
        $('#btnCancelWrap').addClass('d-none');
        $('tr.editing-row').removeClass('editing-row');
        document.getElementById('ruleForm').reset();
        $('#active_status').prop('checked', true);
        $('#drug_hosxp').val('').trigger('change');
        if (IS_OTHER_LAB) {
            $('#lab_hosxp').val(null).trigger('change');
            $('#lab_extra_codes').val('');
            $('#lab_condition_type').val('range');
            $('#lab_condition_value').val('');
            toggleOtherConditionMode();
        }
        $('#use_dose_condition').prop('checked', false);
        toggleDoseFields();
        if ($('#use_dose_per_admin_condition').length) {
            $('#use_dose_per_admin_condition').prop('checked', false);
            $('#dose_per_admin_min, #dose_per_admin_max').val('');
            toggleDosePerAdminFields();
        }
        if ($('#use_duration_condition').length) {
            $('#use_duration_condition').prop('checked', false);
            $('#duration_min, #duration_max').val('');
            toggleDurationFields();
        }
        if ($('#exempt_method_patterns').length) {
            $('#exempt_method_patterns').val('');
        }
        if ($('#first_order_only').length) {
            $('#first_order_only').prop('checked', false);
            $('#first_order_lookback_days').val('');
            toggleFirstOrderFields();
        }
        if (IS_RENAL_LAB && $('#use_age_condition').length) {
            $('#use_age_condition, #use_weight_condition').prop('checked', false);
            $('#age_min, #age_max, #weight_min, #weight_max').val('');
            toggleAgeFields();
            toggleWeightFields();
        }
        updateLabRangeHint();
    }

    function setEditMode(rule) {
        $('#form_action').val('edit');
        $('#rule_id').val(rule.id);
        $('#formCard').removeClass('copy-mode').addClass('edit-mode');
        $('#formCardHeader').removeClass('<?php echo $form_header_bg; ?> bg-secondary').addClass('bg-primary');
        $('#formCardIcon').removeClass('fa-plus-circle fa-copy').addClass('fa-edit');
        $('#formCardTitle').text('แก้ไขเงื่อนไข (ID: ' + rule.id + ')');
        $('#btnSubmit').removeClass('btn-danger btn-warning text-dark btn-secondary btn-info').addClass('btn-primary').html('<i class="fas fa-save me-1"></i> บันทึกการแก้ไข');
        $('#btnCancelWrap').removeClass('d-none');
        fillRuleForm(rule);
        $('tr.editing-row').removeClass('editing-row');
        $('tr[data-rule-id="' + rule.id + '"]').addClass('editing-row');
        document.getElementById('formCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function setCopyMode(rule) {
        $('#form_action').val('add');
        $('#rule_id').val('');
        $('#formCard').removeClass('edit-mode').addClass('copy-mode');
        $('#formCardHeader').removeClass('<?php echo $form_header_bg; ?> bg-primary').addClass('bg-secondary');
        $('#formCardIcon').removeClass('fa-plus-circle fa-edit').addClass('fa-copy');
        $('#formCardTitle').text('คัดลอกเงื่อนไขจาก ID: ' + rule.id);
        $('#btnSubmit').removeClass('btn-danger btn-warning text-dark btn-primary btn-info').addClass('btn-secondary').html('<i class="fas fa-save me-1"></i> บันทึกกฎใหม่');
        $('#btnCancelWrap').removeClass('d-none');
        fillRuleForm(rule);
        $('tr.editing-row').removeClass('editing-row');
        $('tr[data-rule-id="' + rule.id + '"]').addClass('editing-row');
        document.getElementById('formCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    $(document).ready(function() {
        if (LAB_PAGE_TAB === 'scores') {
            return;
        }
        if (LAB_SETTINGS_TAB) {
            $('.select2-hosxp').select2({ theme: 'bootstrap-5', width: '100%' });
            initLabSelect2();
            $('#use_dose_condition').on('change', toggleDoseFields);
            $('#use_dose_per_admin_condition').on('change', toggleDosePerAdminFields);
            $('#use_duration_condition').on('change', toggleDurationFields);
            toggleDurationFields();
            toggleDosePerAdminFields();
            if ($('#first_order_only').length) {
                $('#first_order_only').on('change', toggleFirstOrderFields);
                toggleFirstOrderFields();
            }
            if (IS_RENAL_LAB) {
                $('#use_age_condition').on('change', toggleAgeFields);
                $('#use_weight_condition').on('change', toggleWeightFields);
                toggleAgeFields();
                toggleWeightFields();
            }
            if (IS_OTHER_LAB) {
                $('#lab_condition_type').on('change', toggleOtherConditionMode);
                toggleOtherConditionMode();
            } else {
                $('#lab_type').on('change', updateLabRangeHint);
            }
            toggleDoseFields();
            updateLabRangeHint();
            $(document).on('click', '.btn-edit-rule', function() {
                const rule = parseLabRuleData(this);
                if (!rule) return;
                setEditMode(rule);
            });
            $(document).on('click', '.btn-copy-rule', function() {
                const rule = parseLabRuleData(this);
                if (!rule) return;
                setCopyMode(rule);
            });
            $('#btnCancelEdit').on('click', setAddMode);
            $('#ruleForm').on('submit', function (e) {
                $(this).find('.disabled-section input[required], .disabled-section select[required]').prop('required', false);
                const drugVal = ($('#drug_hosxp').val() || '').toString().trim();
                if ($('#drug_hosxp').prop('required') && !drugVal) {
                    e.preventDefault();
                    alert('กรุณาเลือกรายการยาจาก HOSxP ก่อนบันทึก — ถ้าต้องการใส่ข้อยกเว้นวิธีใช้ ให้กดปุ่มแก้ไขที่กฎยานั้นก่อน');
                    if ($('#drug_hosxp').hasClass('select2-hidden-accessible')) {
                        $('#drug_hosxp').select2('open');
                    }
                    return false;
                }
                if (!this.checkValidity()) {
                    e.preventDefault();
                    const first = this.querySelector(':invalid');
                    let msg = 'กรุณากรอกข้อมูลที่จำเป็นให้ครบก่อนบันทึก (ยา, ช่วง Lab, ข้อความแนะนำ)';
                    if (first) {
                        const lab = $(first).closest('[class*="col-"], .border').find('label').first().text().replace(/\s+/g, ' ').trim();
                        if (lab) {
                            msg = 'ยังกรอกไม่ครบ: ' + lab;
                        }
                    }
                    alert(msg);
                    if (first) {
                        if ($(first).hasClass('select2-hidden-accessible')) {
                            $(first).select2('open');
                        } else {
                            first.reportValidity();
                            first.focus();
                        }
                    }
                    return false;
                }
            });
        } else {
            flatpickr('#filter_start', { dateFormat: 'Y-m-d' });
            flatpickr('#filter_end', { dateFormat: 'Y-m-d' });
            initChart();
            setLabDateRange(3);
            $(document).on('change', '.lab-rule-cb', labUpdateRuleSelectedCount);
            $(document).on('input', '#labRuleSearch', function() {
                const q = (($(this).val() || '') + '').toLowerCase();
                $('.lab-rule-item').each(function() {
                    const t = (($(this).text() || '') + '').toLowerCase();
                    $(this).toggle(!q || t.indexOf(q) !== -1);
                });
            });
            labUpdateRuleSelectedCount();
            monitorInitHnFilter({
                clearHref: <?php echo json_encode($page_file, JSON_UNESCAPED_UNICODE); ?>,
                fetchFn: fetchLabMonitorData,
                autofetch: fetchLabMonitorData
            });
        }
    });

    function setLabDateRange(days) {
        const end = new Date();
        const start = new Date();
        if (days <= 1) {
            start.setHours(0, 0, 0, 0);
        } else {
            start.setDate(end.getDate() - (days - 1));
        }
        const fmt = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
        const fpStart = document.getElementById('filter_start')._flatpickr;
        const fpEnd = document.getElementById('filter_end')._flatpickr;
        if (fpStart) fpStart.setDate(fmt(start), true); else $('#filter_start').val(fmt(start));
        if (fpEnd) fpEnd.setDate(fmt(end), true); else $('#filter_end').val(fmt(end));
        $('.lab-range-btn').removeClass('active');
        $('.lab-range-btn[data-days="' + days + '"]').addClass('active');
    }

    function initChart() {
        const ctx = document.getElementById('summaryChart').getContext('2d');
        summaryChart = new Chart(ctx, {
            type: 'doughnut',
            data: { labels: ['ผ่านเกณฑ์', 'ไม่ผ่าน (คลาดเคลื่อน)'], datasets: [{ data: [0, 0], backgroundColor: ['#198754', '#dc3545'], borderWidth: 0 }] },
            options: { responsive: true, maintainAspectRatio: false, cutout: '70%', plugins: { legend: { position: 'right' } } }
        });
    }

    function updateChart(passCount, failCount, rxTotal) {
        rxTotal = Math.max(0, parseInt(rxTotal, 10) || 0);
        failCount = Math.max(0, parseInt(failCount, 10) || 0);
        passCount = Math.max(0, parseInt(passCount, 10) || 0);
        summaryChart.data.datasets[0].data = [passCount, failCount];
        summaryChart.update();
        $('#count_pass').text(passCount);
        $('#count_fail').text(failCount);
        $('#count_fail_formula').text(failCount);
        $('#count_rx_total').text(rxTotal);
        const pct = rxTotal > 0 ? (failCount / rxTotal * 100) : 0;
        $('#fail_percent').text(pct.toFixed(2) + '%');
    }

    function getSelectedLabRuleIds() {
        return $('.lab-rule-cb:checked').map(function() { return this.value; }).get();
    }

    function labSelectAllRules(checked) {
        $('.lab-rule-cb').prop('checked', checked);
        labUpdateRuleSelectedCount();
    }

    function labUpdateRuleSelectedCount() {
        const total = $('.lab-rule-cb').length;
        const sel = getSelectedLabRuleIds().length;
        $('#labRuleSelectedCount').text(total > 0 ? '(เลือก ' + sel + ' / ' + total + ' รายการ)' : '');
    }

    let lastPrescriptions = [];
    let lastHard = [];
    let lastSoft = [];
    let currentRxFilter = 'all';
    let mlcCurrentCase = null;
    let mlcHnCases = [];
    let mlcConsultModal = null;

    function setRxFilter(filter, btn) {
        currentRxFilter = filter || 'all';
        $('#tabPrescriptions [data-rx-filter]').removeClass('active');
        if (btn) {
            $(btn).addClass('active');
        } else {
            $(`#tabPrescriptions [data-rx-filter="${currentRxFilter}"]`).addClass('active');
        }
        renderPrescriptionTable(lastPrescriptions);
    }

    const LAB_PARALLEL = MONITOR_ORGAN === 'hepatic' ? 1 : 3;
    const LAB_JOB_BATCH = MONITOR_ORGAN === 'hepatic' ? 500 : 1;
    let labFetchGen = 0;
    let labAbortCtl = null;

    function getSelectedLabDrugJobs() {
        const byKey = {};
        $('.lab-rule-cb:checked').each(function() {
            const id = String($(this).val() || '');
            const icode = String($(this).data('icode') || '').trim();
            const name = String($(this).data('drug') || '').trim();
            const key = icode !== '' ? icode : ('id:' + id);
            if (!byKey[key]) {
                byKey[key] = { icode: icode, name: name, ids: [] };
            }
            byKey[key].ids.push(id);
            if (name && !byKey[key].name) {
                byKey[key].name = name;
            }
        });
        return Object.keys(byKey).map(function(k) { return byKey[k]; });
    }

    function packLabDrugJobs(jobs) {
        const size = LAB_JOB_BATCH;
        if (!size || size <= 1 || jobs.length <= 1) {
            return jobs;
        }
        const packed = [];
        for (let i = 0; i < jobs.length; i += size) {
            const slice = jobs.slice(i, i + size);
            const ids = [];
            slice.forEach(function (j) {
                (j.ids || []).forEach(function (id) { ids.push(id); });
            });
            packed.push({
                icode: slice.map(function (j) { return j.icode; }).filter(Boolean).join(','),
                name: slice.length === 1
                    ? (slice[0].name || slice[0].icode)
                    : ((slice[0].name || slice[0].icode || 'ยา') + ' +' + (slice.length - 1)),
                ids: ids,
                count: slice.length
            });
        }
        return packed;
    }

    function labFriendlyFetchError(text, status) {
        const raw = String(text || '');
        if (status === 504 || /504|Gateway Time-out/i.test(raw)) {
            return 'ประมวลผลนานเกินกำหนด (504) — ลองย่อช่วงวันที่ หรือเลือกยาน้อยลง';
        }
        if (status === 502 || /Bad Gateway/i.test(raw)) {
            return 'เซิร์ฟเวอร์ไม่ตอบ (502) — ลองใหม่ในอีกสักครู่';
        }
        const stripped = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        return (stripped || ('HTTP ' + status)).substring(0, 240);
    }

    function labCountRx(rows) {
        let ok = 0, alertN = 0, noLab = 0;
        (rows || []).forEach(function(item) {
            const st = item.match_status || '';
            if (st === 'ok') ok++;
            else if (st === 'no_lab') noLab++;
            else alertN++;
        });
        return { ok: ok, alert: alertN, no_lab: noLab };
    }

    function labPaintMonitor(agg, isFinal) {
        lastPrescriptions = agg.prescriptions;
        lastHard = agg.hard || [];
        lastSoft = agg.soft || [];
        const hard = lastHard;
        const soft = lastSoft;
        const rx = labCountRx(agg.prescriptions);
        $('#hardCount').text(hard.length);
        $('#softCount').text(soft.length);
        $('#alertTabCount').text(hard.length + soft.length);
        $('#rxTabCount').text(agg.prescriptions.length);
        $('#rxCountAll').text(agg.prescriptions.length);
        $('#rxCountOk').text(rx.ok);
        $('#rxCountAlert').text(rx.alert);
        $('#rxCountNoLab').text(rx.no_lab);
        if (hard.length === 0) {
            $('#hardTbody').html(isFinal
                ? '<tr><td colspan="7" class="text-center py-4 text-muted">ไม่พบรายการ Hard Alert ในช่วงเวลานี้</td></tr>'
                : '<tr><td colspan="7" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังตรวจ...</td></tr>');
        } else {
            renderTable('hardTbody', hard, 'ไม่พบรายการ Hard Alert ในช่วงเวลานี้');
        }
        if (soft.length === 0) {
            $('#softTbody').html(isFinal
                ? '<tr><td colspan="7" class="text-center py-4 text-muted">ไม่พบรายการ Soft Alert ในช่วงเวลานี้</td></tr>'
                : '<tr><td colspan="7" class="text-center py-4 text-muted">กำลังตรวจ...</td></tr>');
        } else {
            renderTable('softTbody', soft, 'ไม่พบรายการ Soft Alert ในช่วงเวลานี้');
        }
        if (agg.prescriptions.length === 0) {
            $('#rxTbody').html(isFinal
                ? '<tr><td colspan="6" class="text-center py-4 text-muted">ไม่พบรายการสั่งใช้ยาในช่วงเวลานี้</td></tr>'
                : '<tr><td colspan="6" class="text-center py-4 text-muted">กำลังตรวจ...</td></tr>');
        } else {
            renderPrescriptionTable(agg.prescriptions);
        }
        let totalFail = 0;
        hard.concat(soft).forEach(function(item) {
            if (!item.is_pass) totalFail++;
        });
        const rxTotal = agg.prescriptions.length;
        const totalPass = Math.max(0, rxTotal - totalFail);
        updateChart(totalPass, totalFail, rxTotal);
    }

    async function labPostDrug(job, signal) {
        const r = await fetch('fetch_monitor_lab_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            signal: signal,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: new URLSearchParams(monitorAppendHn({
                start_date: $('#filter_start').val() || '',
                end_date: $('#filter_end').val() || '',
                organ: MONITOR_ORGAN,
                rule_ids: job.ids.join(',')
            }))
        });
        const text = await r.text();
        try {
            return JSON.parse(text);
        } catch (e) {
            throw new Error(labFriendlyFetchError(text, r.status));
        }
    }

    async function fetchLabMonitorData() {
        const jobs = packLabDrugJobs(getSelectedLabDrugJobs());
        if (jobs.length === 0) {
            alert('กรุณาเลือกอย่างน้อย 1 รายการยาที่ต้องการรายงาน');
            return;
        }

        const gen = ++labFetchGen;
        if (labAbortCtl) {
            try { labAbortCtl.abort(); } catch (e) {}
        }
        const ac = new AbortController();
        labAbortCtl = ac;

        const t0 = Date.now();
        const agg = {
            hard: [],
            soft: [],
            prescriptions: [],
            orders_scanned: 0,
            orders_unique: 0,
            patients: {},
            truncated: false,
            prescriptions_truncated: false,
            rules_selected: 0,
            rules_total: 0,
            score_details: {}
        };
        const failed = [];
        let done = 0;
        let lastPaint = 0;
        const unitLabel = LAB_JOB_BATCH > 1 ? 'กลุ่มยา' : 'ยา';
        const workers = Math.min(LAB_PARALLEL, jobs.length);
        const loadingAlert = '<tr><td colspan="7" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังตรวจ (พร้อมกัน ' + workers + ' รายการ)...</td></tr>';
        const loadingRx = '<tr><td colspan="6" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังตรวจ (พร้อมกัน ' + workers + ' รายการ)...</td></tr>';

        $('#btnFetchLab').prop('disabled', true);
        $('#hardTbody, #softTbody').html(loadingAlert);
        $('#rxTbody').html(loadingRx);
        $('#hardCount, #softCount, #alertTabCount, #rxTabCount, #rxCountAll, #rxCountOk, #rxCountAlert, #rxCountNoLab').text(0);
        updateChart(0, 0, 0);
        $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info')
            .html('<i class="fas fa-spinner fa-spin me-1"></i> เริ่มตรวจ 0/' + jobs.length + ' ' + unitLabel + ' (พร้อมกัน ' + workers + ' รายการ)');

        function updateMeta(currentName, isFinal) {
            if (gen !== labFetchGen) return;
            const sec = ((Date.now() - t0) / 1000).toFixed(1);
            const rx = labCountRx(agg.prescriptions);
            let html = '<i class="fas fa-info-circle me-1"></i> ตรวจแล้ว ' + done + '/' + jobs.length + ' ' + unitLabel
                + ' | พร้อมกัน ' + workers + ' รายการ'
                + ' | Hard: ' + agg.hard.length
                + ' | Soft: ' + agg.soft.length
                + ' | สั่งใช้ยา: ' + agg.prescriptions.length
                + ' (เหมาะสม ' + rx.ok
                + ', Alert ' + rx.alert
                + ', ไม่มี Lab ' + rx.no_lab + ')'
                + ' | สแกน order: ' + agg.orders_scanned
                + ' | ' + sec + ' วินาที';
            if (!isFinal && currentName) html += ' | ล่าสุด: ' + labEsc(currentName);
            if (agg.truncated) html += ' <span class="text-danger">(บางยามีใบยาถึงขีดจำกัด)</span>';
            if (agg.prescriptions_truncated) html += ' <span class="text-danger">(รายงานการสั่งใช้ยาเกิน limit)</span>';
            if (failed.length) html += ' | <span class="text-danger">ไม่สำเร็จ ' + failed.length + ' ยา</span>';
            if (isFinal && failed.length) {
                html += '<div class="small fw-normal mt-1">' + failed.map(function(f) { return labEsc(f); }).join('<br>') + '</div>';
            }
            $('#reportMeta').toggleClass('alert-danger', failed.length > 0 && isFinal)
                .toggleClass('alert-info', !(failed.length > 0 && isFinal))
                .removeClass('d-none')
                .html(html);
        }

        async function runOne(job) {
            const data = await labPostDrug(job, ac.signal);
            if (data.status !== 'success') {
                throw new Error(data.message || 'เกิดข้อผิดพลาด');
            }
            const m = data.meta || {};
            const scores = data.score_details || {};
            Object.keys(scores).forEach(function(k) { agg.score_details[k] = scores[k]; });
            (data.hard_alerts || []).forEach(function(row) { agg.hard.push(labBindScore(row, scores)); });
            (data.soft_alerts || []).forEach(function(row) { agg.soft.push(labBindScore(row, scores)); });
            (data.prescriptions || []).forEach(function(row) { agg.prescriptions.push(labBindScore(row, scores)); });
            agg.orders_scanned += m.orders_scanned || 0;
            agg.orders_unique += m.orders_unique || 0;
            agg.rules_selected += m.rules_selected || m.rule_count || 0;
            if (m.rules_total) agg.rules_total = m.rules_total;
            if (m.truncated) agg.truncated = true;
            if (m.prescriptions_truncated) agg.prescriptions_truncated = true;
        }

        let next = 0;
        async function worker() {
            while (next < jobs.length) {
                if (gen !== labFetchGen) return;
                const job = jobs[next++];
                try {
                    await runOne(job);
                } catch (err) {
                    if (err && err.name === 'AbortError') throw err;
                    failed.push((job.name || job.icode || job.ids.join(',')) + ' — ' + (err && err.message ? err.message : 'เชื่อมต่อไม่สำเร็จ'));
                }
                done++;
                updateMeta(job.name, false);
                if (done - lastPaint >= 3 || done === jobs.length) {
                    lastPaint = done;
                    labPaintMonitor(agg, false);
                }
            }
        }

        try {
            await Promise.all(Array.from({ length: workers }, worker));
        } catch (err) {
            if (err && err.name === 'AbortError') return;
            if (gen !== labFetchGen) return;
            $('#btnFetchLab').prop('disabled', false);
            $('#hardTbody, #softTbody').html('<tr><td colspan="7" class="text-center text-danger py-4">' + labEsc(err.message || 'เชื่อมต่อ API ไม่สำเร็จ') + '</td></tr>');
            $('#rxTbody').html('<tr><td colspan="6" class="text-center text-danger py-4">' + labEsc(err.message || 'เชื่อมต่อ API ไม่สำเร็จ') + '</td></tr>');
            return;
        }

        if (gen !== labFetchGen) return;
        $('#btnFetchLab').prop('disabled', false);
        labPaintMonitor(agg, true);
        updateMeta('', true);
    }

    function labBindScore(item, scoreMap) {
        if (!item) return item;
        const k = item.score_key || '';
        if (k && scoreMap && scoreMap[k]) {
            if (!item.lab_components || !item.lab_components.length) {
                item.lab_components = scoreMap[k].components || [];
            }
            if (!item.lab_display && scoreMap[k].display) {
                item.lab_display = scoreMap[k].display;
            }
        }
        return item;
    }

    function labEsc(str) {
        if (!str) return '';
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function labScoreDetailHtml(item) {
        const rows = item && Array.isArray(item.lab_components) ? item.lab_components : [];
        if (!rows.length) {
            const labWhen = (item && item.lab_date && item.lab_date !== '-')
                ? (item.lab_time ? (item.lab_date + ' <span class="text-dark">' + item.lab_time + '</span>') : item.lab_date)
                : '-';
            return '<div class="text-secondary fw-bold" style="font-size: 0.75rem;"><i class="fas fa-vial me-1"></i> เจาะเมื่อ: ' + labWhen + '</div>';
        }
        let html = '<div class="text-start mt-1" style="font-size: 0.72rem; line-height: 1.35;">';
        let lastGroup = '';
        rows.forEach(function(r) {
            const group = String(r.group || '');
            if (group && group !== lastGroup) {
                html += '<div class="fw-bold text-dark mt-1">' + labEsc(group) + '</div>';
                lastGroup = group;
            }
            const bits = [];
            bits.push(labEsc(r.label || ''));
            if (r.value) {
                bits.push('<b>' + labEsc(String(r.value)) + (r.unit ? ' ' + labEsc(r.unit) : '') + '</b>');
            }
            if (r.points != null && r.points !== '') {
                bits.push('→ ' + labEsc(String(r.points)));
            }
            let line = bits.join(' ');
            if (r.when) {
                line += ' <span class="text-secondary">· ' + labEsc(r.when) + '</span>';
            }
            if (r.note) {
                line += ' <span class="text-muted">' + labEsc(r.note) + '</span>';
            }
            html += '<div>' + line + '</div>';
        });
        html += '</div>';
        return html;
    }

    function labScoreDetailText(item) {
        const rows = item && Array.isArray(item.lab_components) ? item.lab_components : [];
        if (!rows.length) return '';
        const lines = [];
        let lastGroup = '';
        rows.forEach(function(r) {
            const group = String(r.group || '');
            if (group === 'Clinical') return;
            if (group && group !== lastGroup) {
                lines.push(group);
                lastGroup = group;
            }
            let line = String(r.label || '');
            if (r.value) {
                line += (line ? ' ' : '') + String(r.value) + (r.unit ? ' ' + r.unit : '');
            }
            if (r.points != null && r.points !== '') {
                line += ' → ' + r.points;
            }
            if (r.when) {
                line += ' · ' + r.when;
            }
            if (r.note) {
                line += ' ' + r.note;
            }
            line = line.trim();
            if (line) lines.push(line);
        });
        return lines.join('\n');
    }

    function labVisitTypeHtml(item) {
        const t = (item && item.type_patient === 'IPD') ? 'IPD' : 'OPD';
        const cls = t === 'IPD' ? 'bg-secondary' : 'bg-info text-dark';
        let html = '<span class="badge ' + cls + '">' + t + '</span>';
        if (t === 'IPD' && item.ward_name) {
            html += ' <span class="text-muted small">' + labEsc(item.ward_name) + '</span>';
        }
        return html;
    }

    function renderPrescriptionTable(rows) {
        const list = Array.isArray(rows) ? rows : [];
        const filtered = list.filter(item => {
            const st = item.match_status || '';
            if (currentRxFilter === 'ok') return st === 'ok';
            if (currentRxFilter === 'no_lab') return st === 'no_lab';
            if (currentRxFilter === 'alert') return st === 'alert_soft' || st === 'alert_hard';
            return true;
        });
        if (filtered.length === 0) {
            $('#rxTbody').html('<tr><td colspan="6" class="text-center py-4 text-muted">ไม่พบรายการสั่งใช้ยาในช่วงเวลานี้</td></tr>');
            return;
        }
        let html = '';
        filtered.forEach(item => {
            let badgeClass = MONITOR_ORGAN === 'other' ? 'bg-info text-dark'
                : ((item.lab_type === 'GFR' || item.lab_type === 'CKD_EPI' || item.lab_type === 'SERUM_CR') ? 'bg-primary' : 'bg-warning text-dark');
            let labLabel = MONITOR_ORGAN === 'other'
                ? '[' + (item.lab_items_code || '') + '] ' + (item.lab_items_name || 'Lab')
                : (LAB_TYPE_DISPLAY[item.lab_type] || item.lab_type);
            let labValText = (item.lab_value === '' || item.lab_value === null || item.lab_value === undefined) ? '-' : item.lab_value;
            if (!item.lab_value_is_text && item.lab_type && String(item.lab_type).indexOf('xULN') !== -1 && labValText !== '-') {
                labValText = parseFloat(item.lab_value).toFixed(2) + '× ULN';
            }
            if (item.lab_display) {
                labValText = item.lab_display;
            }
            const orderWhen = item.order_time
                ? `${item.order_date} <span class="text-dark">${item.order_time}</span>`
                : item.order_date;
            const methodText = labEsc(item.drug_method || '-');
            let statusBadge = '';
            if (item.match_status === 'ok') {
                statusBadge = `<span class="badge bg-success w-100 py-2 shadow-sm"><i class="fas fa-check-circle me-1"></i>${labEsc(item.status_text || 'เหมาะสม')}</span>`;
            } else if (item.match_status === 'alert_hard') {
                statusBadge = `<span class="badge bg-danger w-100 py-2 shadow-sm"><i class="fas fa-exclamation-circle me-1"></i>${labEsc(item.status_text || 'Hard Alert')}</span>`;
            } else if (item.match_status === 'alert_soft') {
                statusBadge = `<span class="badge bg-warning text-dark w-100 py-2 shadow-sm"><i class="fas fa-exclamation-triangle me-1"></i>${labEsc(item.status_text || 'Soft Alert')}</span>`;
            } else {
                statusBadge = `<span class="badge bg-secondary w-100 py-2 shadow-sm"><i class="fas fa-question-circle me-1"></i>${labEsc(item.status_text || 'ไม่มี Lab')}</span>`;
            }
            html += `<tr>
                <td class="text-center fw-bold text-dark">${labEsc(item.hn)}</td>
                <td><div>${labEsc(item.ptname)}</div><div class="mt-1">${labVisitTypeHtml(item)}</div><div class="text-muted small mt-1"><i class="fas fa-calendar-plus"></i> สั่งยา: ${orderWhen}</div></td>
                <td><div class="fw-bold text-primary"><i class="fas fa-pills me-1"></i>${labEsc(item.drug_name)}</div>
                    <div class="dose-box">
                        <div class="small mb-1 text-muted"><i class="fas fa-info-circle me-1"></i>วิธีใช้: <span class="text-dark">${methodText}</span></div>
                        <div class="small mb-1">สั่งใช้จริง: <span class="text-danger fw-bold">${item.actual_dose || '-'}</span></div>
                        ${item.actual_dose_per_admin ? `<div class="small mb-1">ต่อครั้ง: <span class="text-danger fw-bold">${item.actual_dose_per_admin}</span></div>` : ''}
                        ${item.recommended_duration ? `<div class="small mb-1">ช่วงให้ยาจริง: <span class="text-danger fw-bold">${labEsc(item.actual_interval || '-')}</span></div>
                        <div class="small">ช่วงให้ยาแนะนำ: <span class="text-success fw-bold bg-success bg-opacity-10 px-2 py-1 rounded border border-success">${labEsc(item.recommended_duration)}</span></div>` : ''}
                    </div></td>
                <td class="text-center"><div class="badge ${badgeClass} fs-6 px-3 py-2 shadow-sm mb-1">${labEsc(labLabel)}: ${labEsc(String(labValText))}</div>
                    ${labScoreDetailHtml(item)}</td>
                <td class="text-center small fw-bold">${labEsc(item.lab_condition_summary || '-')}</td>
                <td class="text-center">${statusBadge}</td>
            </tr>`;
        });
        $('#rxTbody').html(html);
    }

    function renderTable(tbodyId, alerts, emptyText) {
        if (alerts.length === 0) {
            $(`#${tbodyId}`).html(`<tr><td colspan="7" class="text-center py-4 text-muted">${emptyText || 'ไม่พบรายการในช่วงเวลานี้'}</td></tr>`);
            return;
        }
        let html = '';
        alerts.forEach((item, idx) => {
            let badgeClass = MONITOR_ORGAN === 'other' ? 'bg-info text-dark'
                : ((item.lab_type === 'GFR' || item.lab_type === 'CKD_EPI' || item.lab_type === 'SERUM_CR') ? 'bg-primary' : 'bg-warning text-dark');
            let labLabel = MONITOR_ORGAN === 'other'
                ? '[' + (item.lab_items_code || '') + '] ' + (item.lab_items_name || 'Lab')
                : (LAB_TYPE_DISPLAY[item.lab_type] || item.lab_type);
            let labValText = item.lab_value_is_text ? item.lab_value : item.lab_value;
            if (!item.lab_value_is_text && item.lab_type && item.lab_type.indexOf('xULN') !== -1) {
                labValText = parseFloat(item.lab_value).toFixed(2) + '× ULN';
            }
            if (item.lab_display) {
                labValText = item.lab_display;
            }
            if (item.lab_condition_type && item.lab_condition_type !== 'range' && item.lab_condition_value) {
                labLabel += '<div class="small text-muted mt-1">' + labEsc(item.lab_condition_type) + ': ' + labEsc(item.lab_condition_value) + '</div>';
            }
            if (item.patient_extra_text) {
                labLabel += '<div class="small text-dark mt-1">' + labEsc(item.patient_extra_text) + '</div>';
            }
            let passBadge = item.is_pass
                ? `<span class="badge bg-success w-100 py-2 shadow-sm"><i class="fas fa-check-circle me-1"></i> ${item.pass_text}</span>`
                : `<span class="badge bg-danger w-100 py-2 shadow-sm"><i class="fas fa-times-circle me-1"></i> ${item.pass_text}</span>`;
            const orderWhen = item.order_time
                ? `${item.order_date} <span class="text-dark">${item.order_time}</span>`
                : item.order_date;
            const methodText = labEsc(item.drug_method || '-');
            html += `<tr>
                <td class="text-center fw-bold text-dark">${item.hn}</td>
                <td><div>${item.ptname}</div><div class="mt-1">${labVisitTypeHtml(item)}</div><div class="text-muted small mt-1"><i class="fas fa-calendar-plus"></i> สั่งยา: ${orderWhen}</div></td>
                <td><div class="fw-bold text-primary"><i class="fas fa-pills me-1"></i>${item.drug_name}</div>
                    <div class="dose-box">
                        <div class="small mb-1 text-muted"><i class="fas fa-info-circle me-1"></i>วิธีใช้: <span class="text-dark">${methodText}</span></div>
                        <div class="small mb-1">สั่งใช้จริง: <span class="text-danger fw-bold">${item.actual_dose}</span></div>
                        ${item.actual_dose_per_admin ? `<div class="small mb-1">ต่อครั้ง: <span class="text-danger fw-bold">${item.actual_dose_per_admin}</span></div>` : ''}
                        <div class="small">แนะนำ: <span class="text-success fw-bold bg-success bg-opacity-10 px-2 py-1 rounded border border-success">${item.recommended_dose}</span></div>
                        ${item.recommended_duration ? `<div class="small mt-1">ช่วงให้ยาจริง: <span class="text-danger fw-bold">${labEsc(item.actual_interval || '-')}</span></div>
                        <div class="small">ช่วงให้ยาแนะนำ: <span class="text-success fw-bold bg-success bg-opacity-10 px-2 py-1 rounded border border-success">${labEsc(item.recommended_duration)}</span></div>` : ''}
                    </div></td>
                <td class="text-center"><div class="badge ${badgeClass} fs-6 px-3 py-2 shadow-sm mb-1">${labLabel}: ${labEsc(String(labValText))}</div>
                    ${labScoreDetailHtml(item)}</td>
                <td class="text-center text-danger fw-bold"><small>${item.warning_msg}</small></td>
                <td class="text-center">${passBadge}</td>
                <td class="text-center text-nowrap">
                    <div class="mb-1">${mlcConsultBadge(item.consult)}</div>
                    <button type="button" class="btn btn-sm btn-success fw-bold me-1" onclick="mlcOpenConsult('${tbodyId}', ${idx})">
                        <i class="fas fa-notes-medical me-1"></i>บันทึก Intervention</button>
                    <button type="button" class="btn btn-sm btn-outline-info" title="ประวัติการปรึกษาแพทย์" onclick="mlcOpenHistoryFromRow('${tbodyId}', ${idx})">
                        <i class="fas fa-history"></i></button>
                </td>
            </tr>`;
        });
        $(`#${tbodyId}`).html(html);
    }

    function mlcConsultBadge(c) {
        c = c || {};
        var st = c.status || 'waiting';
        var label = c.status_label || st;
        var cls = 'bg-warning text-dark';
        var extra = '';
        if (st === 'in_progress') {
            cls = 'bg-primary';
            if (c.reply_due_at) {
                extra = '<div class="small text-muted">ตอบภายใน ' + labEsc(c.reply_due_at) + '</div>';
            } else if (Number(c.reply_wait_days) === 0) {
                extra = '<div class="small text-muted">ทันที</div>';
            }
        } else if (st === 'closed') {
            cls = 'bg-success';
        }
        return '<span class="badge ' + cls + '">' + labEsc(label) + '</span>' + extra;
    }
    function mlcItemFromRow(tbodyId, idx) {
        var arr = tbodyId === 'hardTbody' ? lastHard : lastSoft;
        return (arr || [])[idx] || null;
    }
    function mlcAllAlerts() {
        return (lastHard || []).concat(lastSoft || []);
    }
    function mlcRerenderAlerts() {
        if (!lastHard.length) {
            $('#hardTbody').html('<tr><td colspan="7" class="text-center py-4 text-muted">ไม่พบรายการ Hard Alert ในช่วงเวลานี้</td></tr>');
        } else {
            renderTable('hardTbody', lastHard, 'ไม่พบรายการ Hard Alert ในช่วงเวลานี้');
        }
        if (!lastSoft.length) {
            $('#softTbody').html('<tr><td colspan="7" class="text-center py-4 text-muted">ไม่พบรายการ Soft Alert ในช่วงเวลานี้</td></tr>');
        } else {
            renderTable('softTbody', lastSoft, 'ไม่พบรายการ Soft Alert ในช่วงเวลานี้');
        }
    }
    function mlcToggleDrugChecks(on) {
        document.querySelectorAll('.mlc-drug-cb').forEach(function(cb) { cb.checked = !!on; });
    }
    function mlcRenderDrugChecks(cases) {
        var box = document.getElementById('mlcDrugCheckList');
        if (!box) return;
        if (!cases.length) {
            box.innerHTML = '<div class="text-muted">ไม่พบยา</div>';
            return;
        }
        var html = '';
        cases.forEach(function(it, i) {
            var id = 'mlcDrugCb' + i;
            var st = (it.consult && it.consult.status_label) ? it.consult.status_label : 'รอ Consult';
            var labVal = it.lab_display || it.lab_value;
            var lab = (it.lab_type || '') + (labVal != null && labVal !== '' ? ': ' + labVal : '');
            html += '<div class="form-check border-bottom py-1">'
                + '<input class="form-check-input mlc-drug-cb" type="checkbox" id="' + id + '" data-idx="' + i + '" checked>'
                + '<label class="form-check-label" for="' + id + '">'
                + '<b>' + labEsc(it.drug_name) + '</b>'
                + ' <span class="text-muted">· ' + labEsc(it.drug_method || '-') + '</span>'
                + (lab ? ' <span class="badge bg-secondary">' + labEsc(lab) + '</span>' : '')
                + ' <span class="text-muted">(' + labEsc(st) + ')</span>'
                + '</label></div>';
        });
        box.innerHTML = html;
    }
    function mlcOpenConsult(tbodyId, idx) {
        var it = mlcItemFromRow(tbodyId, idx);
        if (!it) return;
        mlcCurrentCase = it;
        mlcHnCases = mlcAllAlerts().filter(function(x) {
            return String(x.hn || '') === String(it.hn || '');
        });
        if (!mlcHnCases.length) mlcHnCases = [it];
        var c = it.consult || {};
        document.getElementById('mlcConsultCaseInfo').innerHTML =
            '<b>HN ' + labEsc(it.hn) + '</b> · ' + labEsc(it.ptname)
            + ' · ' + labVisitTypeHtml(it)
            + '<br>พบ Alert ในช่วงนี้ <b>' + mlcHnCases.length + '</b> รายการ — เลือกยาที่จะใส่ในใบปรึกษาด้านล่าง';
        mlcRenderDrugChecks(mlcHnCases);
        mlcApplyOutcomeNote(c.consult_note || c.doctor_reply || '');
        document.getElementById('mlcReplyWait').value = String(MLC_REPLY_WAIT);
        var sel = document.getElementById('mlcPharmacist');
        if (c.pharmacist_user_id && sel.querySelector('option[value="' + c.pharmacist_user_id + '"]')) {
            sel.value = String(c.pharmacist_user_id);
        } else {
            sel.value = String(MLC_CURRENT_USER_ID);
        }
        if (window.AlertMute) {
            AlertMute.set('mlcIvDeviation', {
                hn: it.hn || '',
                vn: it.vn || '',
                an: it.an || '',
                patient_type: it.type_patient || it.patient_type || (it.an ? 'IPD' : 'OPD')
            });
        }
        document.getElementById('mlcConsultMsg').className = 'alert mt-3 mb-0 py-2 small d-none';
        if (!mlcConsultModal) {
            mlcConsultModal = new bootstrap.Modal(document.getElementById('mlcConsultModal'));
        }
        mlcConsultModal.show();
    }
    function mlcSelectedCases() {
        var selected = [];
        document.querySelectorAll('.mlc-drug-cb:checked').forEach(function(cb) {
            var i = parseInt(cb.getAttribute('data-idx'), 10);
            if (!isNaN(i) && mlcHnCases[i]) selected.push(mlcHnCases[i]);
        });
        return selected;
    }
    function mlcCasesPayloadList() {
        return mlcSelectedCases().map(function(it) {
            return {
                organ: it.organ || MONITOR_ORGAN,
                hn: it.hn || '',
                an: it.an || '',
                vn: it.vn || '',
                icode: it.icode || '',
                drug_name: it.drug_name || '',
                drug_method: it.drug_method || '',
                qty: it.qty || '',
                ward_name: it.ward_name || '',
                ptname: it.ptname || '',
                order_date_iso: it.order_date_iso || it.order_date || '',
                order_time: it.order_time || '',
                lab_type: it.lab_type || '',
                lab_items_code: it.lab_items_code || '',
                lab_value: (function() {
                    var summary = String(it.lab_display || (it.lab_value != null ? it.lab_value : '') || '').trim();
                    var detail = String(it.lab_detail || labScoreDetailText(it) || '').trim();
                    if (detail && summary && detail.indexOf(summary) === 0) {
                        return detail;
                    }
                    if (summary && detail) {
                        return summary + '\n' + detail;
                    }
                    return summary || detail;
                })(),
                warning_msg: it.warning_msg || '',
                alert_level: it.alert_level || 'soft',
                actual_dose: it.actual_dose || '',
                recommended_dose: it.recommended_dose || '',
                case_key: it.case_key || '',
                consult_id: (it.consult && it.consult.id) ? it.consult.id : 0
            };
        });
    }
    function mlcChip(text) {
        var box = document.getElementById('mlcIvConsult');
        if (!box) return;
        var phrase = String(text || '').trim();
        if (!phrase) { box.focus(); return; }
        var cur = box.value.replace(/\s+$/, '');
        if (!cur) box.value = phrase + ' ';
        else if (cur.indexOf(phrase) === -1) box.value = cur + '\n' + phrase + ' ';
        box.focus();
    }
    function mlcComposeNote() {
        var note = String((document.getElementById('mlcConsultNote') || {}).value || '').trim();
        var after = String((document.getElementById('mlcIvConsult') || {}).value || '').trim();
        var lines = [];
        if (note) lines.push(note);
        if (after) lines.push('หลัง Consult: ' + after);
        return lines.join('\n');
    }
    function mlcApplyOutcomeNote(text) {
        var typeEl = document.getElementById('mlcIvType');
        var devEl = document.getElementById('mlcIvDeviation');
        var noteEl = document.getElementById('mlcConsultNote');
        var consultEl = document.getElementById('mlcIvConsult');
        if (typeEl) typeEl.value = 'recommend';
        if (devEl) devEl.value = '';
        if (window.AlertMute) AlertMute.sync('mlcIvDeviation');
        if (noteEl) noteEl.value = String(text || '');
        if (consultEl) consultEl.value = '';
    }
    function mlcCommonPayload() {
        var sel = document.getElementById('mlcPharmacist');
        var opt = sel.options[sel.selectedIndex];
        var note = mlcComposeNote();
        return {
            pharmacist_user_id: sel.value,
            pharmacist_name: opt ? opt.text.replace(/\s*\([^)]*\)\s*$/, '').trim() : '',
            consult_note: note,
            doctor_reply: note,
            reply_wait_days: document.getElementById('mlcReplyWait').value,
            intervention_type: (document.getElementById('mlcIvType') || {}).value || 'recommend',
            deviation_category: (document.getElementById('mlcIvDeviation') || {}).value || '',
            mute_visit: (window.AlertMute && AlertMute.checked('mlcIvDeviation')) ? 1 : 0,
            note_text: String((document.getElementById('mlcConsultNote') || {}).value || '').trim(),
            consult_result: String((document.getElementById('mlcIvConsult') || {}).value || '').trim(),
            organ: MONITOR_ORGAN,
            cases_json: JSON.stringify(mlcCasesPayloadList())
        };
    }
    function mlcShowMsg(ok, text) {
        var el = document.getElementById('mlcConsultMsg');
        el.className = 'alert mt-3 mb-0 py-2 small ' + (ok ? 'alert-success' : 'alert-danger');
        el.textContent = text || '';
    }
    function mlcApplyConsults(consults) {
        var map = {};
        (consults || []).forEach(function(c) {
            if (c && c.case_key) map[c.case_key] = c;
            if (c && c.id) {
                mlcAllAlerts().forEach(function(it) {
                    if (it.consult && Number(it.consult.id) === Number(c.id)) {
                        it.consult = c;
                    }
                });
            }
        });
        mlcAllAlerts().forEach(function(it) {
            if (it.case_key && map[it.case_key]) it.consult = map[it.case_key];
        });
        mlcRerenderAlerts();
    }
    function mlcPatchSelectedConsult(extra) {
        extra = extra || {};
        mlcSelectedCases().forEach(function(it) {
            it.consult = Object.assign({}, it.consult || {}, extra);
        });
        mlcRerenderAlerts();
    }
    function mlcPostConsult(action) {
        var cases = mlcSelectedCases();
        if (!cases.length) {
            return Promise.resolve({ status: 'error', message: 'กรุณาเลือกอย่างน้อย 1 รายการยา' });
        }
        var data = Object.assign(mlcCommonPayload(), { action: action });
        var body = new URLSearchParams();
        Object.keys(data).forEach(function(k) { body.append(k, data[k] == null ? '' : data[k]); });
        return fetch('fetch_monitor_lab_consult_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        }).then(function(r) { return r.json(); });
    }
    function mlcSaveIntervention(andPrint) {
        var printWin = null;
        if (andPrint) printWin = window.open('about:blank', '_blank');
        mlcPostConsult('start').then(function(res) {
            if (res.status !== 'success') {
                if (printWin) printWin.close();
                mlcShowMsg(false, res.message || 'บันทึกไม่สำเร็จ');
                return;
            }
            mlcShowMsg(true, andPrint ? 'บันทึก Intervention และเปิดใบปรึกษาแล้ว' : 'บันทึก Intervention แล้ว');
            if (res.consults) mlcApplyConsults(res.consults);
            else if (res.consult) mlcApplyConsults([res.consult]);
            if (andPrint && res.print_url && printWin) {
                printWin.location = res.print_url + (res.print_url.indexOf('?') >= 0 ? '&' : '?') + 'autoprint=1';
            } else if (printWin) {
                printWin.close();
            }
        }).catch(function(e) {
            if (printWin) printWin.close();
            mlcShowMsg(false, String(e));
        });
    }
    function mlcStartAndPrint() {
        mlcSaveIntervention(true);
    }
    function mlcCloseConsult() {
        var n = mlcSelectedCases().length;
        if (!n) { mlcShowMsg(false, 'กรุณาเลือกอย่างน้อย 1 รายการยา'); return; }
        if (!confirm('ปิด Consult ' + n + ' รายการ?')) return;
        mlcPostConsult('close').then(function(res) {
            mlcShowMsg(res.status === 'success', res.message || '');
            if (res.status === 'success') {
                mlcPatchSelectedConsult({ status: 'closed', status_label: 'ปิด Consult', reply_due_at: '' });
                if (res.consult) mlcApplyConsults([res.consult]);
            }
        }).catch(function(e) { mlcShowMsg(false, String(e)); });
    }
    function mlcSaveResult() {
        mlcSaveIntervention(false);
    }
    function mlcResetWaiting() {
        var n = mlcSelectedCases().length;
        if (!n) { mlcShowMsg(false, 'กรุณาเลือกอย่างน้อย 1 รายการยา'); return; }
        mlcPostConsult('reset_waiting').then(function(res) {
            mlcShowMsg(res.status === 'success', res.message || '');
            if (res.status === 'success') {
                mlcPatchSelectedConsult({ status: 'waiting', status_label: 'รอ Consult', reply_due_at: '' });
                if (res.consult) mlcApplyConsults([res.consult]);
            }
        }).catch(function(e) { mlcShowMsg(false, String(e)); });
    }
    function mlcRenderHistory(rows) {
        var tbody = document.getElementById('mlcHistoryBody');
        if (!rows || !rows.length) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted py-3">ยังไม่มีประวัติ</td></tr>';
            return;
        }
        var html = '';
        rows.forEach(function(h) {
            var dayInfo = '-';
            if (h.reply_due_at) {
                dayInfo = 'ตอบภายใน<br><span class="text-muted">' + labEsc(h.reply_due_at) + '</span>';
            }
            var note = [];
            if (h.note_text) note.push(labEsc(h.note_text));
            if (h.doctor_reply && h.doctor_reply !== h.note_text) note.push(labEsc(h.doctor_reply));
            html += '<tr>'
                + '<td class="small text-nowrap">' + labEsc(h.created_at) + '</td>'
                + '<td class="small">' + labEsc(h.drug_name) + '</td>'
                + '<td class="small fw-bold">' + labEsc(h.action_label || h.action_key) + '</td>'
                + '<td class="small">' + labEsc(h.status_before_label || h.status_before || '-')
                + ' → ' + labEsc(h.status_after_label || h.status_after || '-') + '</td>'
                + '<td class="small">' + dayInfo + '</td>'
                + '<td class="small">' + labEsc(h.actor_name || h.pharmacist_name || '-') + '</td>'
                + '<td class="small">' + (note.length ? note.join('<br>') : '-') + '</td>'
                + '</tr>';
        });
        tbody.innerHTML = html;
    }
    function mlcOpenHistoryFromRow(tbodyId, idx) {
        var it = mlcItemFromRow(tbodyId, idx);
        if (!it) return;
        mlcCurrentCase = it;
        mlcHnCases = mlcAllAlerts().filter(function(x) {
            return String(x.hn || '') === String(it.hn || '');
        });
        mlcOpenHistory();
    }
    function mlcOpenHistory() {
        var it = mlcCurrentCase || (mlcHnCases && mlcHnCases[0]) || null;
        if (!it) {
            alert('ไม่พบข้อมูลผู้ป่วย');
            return;
        }
        document.getElementById('mlcHistoryInfo').innerHTML =
            '<b>HN ' + labEsc(it.hn) + '</b> · ' + labEsc(it.ptname)
            + ' · ' + labVisitTypeHtml(it);
        var params = new URLSearchParams({
            action: 'history',
            hn: it.hn || '',
            organ: it.organ || MONITOR_ORGAN,
            limit: '150'
        });
        fetch('fetch_monitor_lab_consult_api.php?' + params.toString(), { credentials: 'same-origin' })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                mlcRenderHistory(res.history || []);
                var modalEl = document.getElementById('mlcHistoryModal');
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            })
            .catch(function(e) { alert('โหลดประวัติไม่สำเร็จ: ' + e); });
    }
</script>
</body>
</html>
