<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/med_error_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
tham_menu_ensure_page_access('report_med_error.php');
med_error_ensure_tables($con);

$h = function ($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
};

$parse_date = function ($src, $key, $fallback) {
    $raw = isset($src[$key]) ? trim((string)$src[$key]) : '';
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw) ? $raw : $fallback;
};

$saved_rates = med_error_report_get_rates($con);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['save_rates']) || (string)($_POST['action'] ?? '') === 'save_rates')) {
    $res = med_error_report_save_rates($con, $_POST['rate_error'] ?? '', $_POST['rate_consult'] ?? '');
    $redir_start = $parse_date($_POST, 'start_date', date('Y-m-01'));
    $redir_end = $parse_date($_POST, 'end_date', date('Y-m-d'));
    if ($redir_start > $redir_end) {
        $tmp = $redir_start;
        $redir_start = $redir_end;
        $redir_end = $tmp;
    }
    $redir_filters = med_error_report_filters_from_request($_POST);
    $qs = med_error_report_query_string($redir_start, $redir_end, $redir_filters);
    $rates = $res['rates'] ?? $saved_rates;
    $qs .= '&rate_error=' . rawurlencode((string)$rates['error']);
    $qs .= '&rate_consult=' . rawurlencode((string)$rates['consult']);
    $qs .= !empty($res['ok']) ? '&saved=1' : '&saved=0';
    header('Location: report_med_error.php?' . $qs);
    exit;
}

$has_start = isset($_GET['start_date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', trim((string)$_GET['start_date']));
$has_end = isset($_GET['end_date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', trim((string)$_GET['end_date']));
$start_date = $has_start ? trim((string)$_GET['start_date']) : date('Y-m-01');
$end_date = $has_end ? trim((string)$_GET['end_date']) : date('Y-m-d');
$all_start = date('Y-m-01');
$all_end = date('Y-m-d');
$q_range = mysqli_query($con, "SELECT MIN(DATE(incident_date)) AS dmin, MAX(DATE(incident_date)) AS dmax FROM med_error_records");
if ($q_range && ($rr = mysqli_fetch_assoc($q_range))) {
    if (!empty($rr['dmin']) && $rr['dmin'] !== '0000-00-00') {
        $all_start = $rr['dmin'];
    }
    if (!empty($rr['dmax']) && $rr['dmax'] !== '0000-00-00') {
        $all_end = $rr['dmax'];
        if ($all_end < date('Y-m-d')) {
            $all_end = date('Y-m-d');
        }
    }
}
if ($start_date > $end_date) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$report_filters = med_error_report_filters_from_request($_GET);

$rate_error = array_key_exists('rate_error', $_GET)
    ? med_error_report_sanitize_rate($_GET['rate_error'], $saved_rates['error'])
    : $saved_rates['error'];
$rate_consult = array_key_exists('rate_consult', $_GET)
    ? med_error_report_sanitize_rate($_GET['rate_consult'], $saved_rates['consult'])
    : $saved_rates['consult'];

$categories = [];
$q_cat = mysqli_query($con, "SELECT DISTINCT category FROM med_error_types WHERE IFNULL(category,'') <> '' ORDER BY category ASC");
if ($q_cat) {
    while ($rc = mysqli_fetch_assoc($q_cat)) {
        $categories[] = (string)$rc['category'];
    }
}
if ($report_filters['category'] !== '' && !in_array($report_filters['category'], $categories, true)) {
    $report_filters['category'] = '';
}

$opt_filter_reporters = '<option value="">ทั้งหมด</option>';
$filter_reporter_name = '';
$q_users = mysqli_query($con, "SELECT id, full_name FROM users ORDER BY full_name ASC");
if ($q_users) {
    while ($ru = mysqli_fetch_assoc($q_users)) {
        $uid = (int)$ru['id'];
        $uname = htmlspecialchars($ru['full_name'], ENT_QUOTES, 'UTF-8');
        $sel_filter = ($uid === (int)$report_filters['reporter_id']) ? ' selected' : '';
        $opt_filter_reporters .= '<option value="' . $uid . '"' . $sel_filter . '>' . $uname . '</option>';
        if ($uid === (int)$report_filters['reporter_id']) {
            $filter_reporter_name = (string)$ru['full_name'];
        }
    }
}

$filter_bits = med_error_report_filter_label($report_filters, $filter_reporter_name);
$range_label = $start_date . ' ถึง ' . $end_date;
if ($filter_bits) {
    $range_label .= ' · ' . implode(' · ', $filter_bits);
}

$rows = med_error_reporter_summary($con, $start_date, $end_date, $report_filters);
$sum_me = 0;
$sum_consult = 0;
$sum_total = 0;
$sum_me_baht = 0.0;
$sum_consult_baht = 0.0;
$sum_baht = 0.0;
$max_total = 0;
foreach ($rows as $r) {
    $sum_me += (int)$r['me_count'];
    $sum_consult += (int)$r['consult_count'];
    $sum_total += (int)$r['total_count'];
    if ((int)$r['total_count'] > $max_total) {
        $max_total = (int)$r['total_count'];
    }
}
$sum_me_baht = $sum_me * $rate_error;
$sum_consult_baht = $sum_consult * $rate_consult;
$sum_baht = $sum_me_baht + $sum_consult_baht;
$reporter_n = count($rows);

$qs_rates = 'rate_error=' . rawurlencode((string)$rate_error) . '&rate_consult=' . rawurlencode((string)$rate_consult);
$qs_self = function ($s, $e) use ($report_filters, $qs_rates) {
    return 'report_med_error.php?' . med_error_report_query_string($s, $e, $report_filters) . '&' . $qs_rates;
};

$rf_sel = function ($key, $val) use ($report_filters) {
    return ((string)($report_filters[$key] ?? '') === (string)$val) ? ' selected' : '';
};

$saved_flash = isset($_GET['saved']) && (string)$_GET['saved'] === '1';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายงาน ME/Consult รายบุคคล - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .kpi-card { border-radius: 12px; border: none; box-shadow: 0 4px 12px rgba(0,0,0,.06); }
        .kpi-value { font-size: 1.85rem; font-weight: 800; line-height: 1.1; }
        .kpi-sub { font-size: .75rem; color: #64748b; }
        .me-table thead th { background: #b42318; color: #fff; font-size: .82rem; white-space: nowrap; }
        .me-table tbody td { vertical-align: middle; }
        .bar-track { height: 8px; border-radius: 99px; background: #f1f5f9; overflow: hidden; display: flex; }
        .bar-me { background: #dc3545; height: 100%; }
        .bar-consult { background: #0aa2c0; height: 100%; }
        .count-link { font-weight: 800; text-decoration: none; }
        .count-link:hover { text-decoration: underline; }
        .rank-badge { display: inline-flex; width: 28px; height: 28px; align-items: center; justify-content: center; border-radius: 50%; background: #fee2e2; color: #9f1239; font-weight: 800; font-size: .8rem; }
        .me-self { background: #fff7ed; }
        .rate-box { background: #fff7ed; border: 1px solid #fed7aa; border-radius: 10px; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-3">
            <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                <div>
                    <h4 class="fw-bold mb-0 text-danger"><i class="fas fa-chart-bar me-2"></i>รายงาน ME/Consult</h4>
                    <div class="text-muted small mt-1">ประมวลผลรายบุคคล ตามผู้บันทึก — กรองรายงาน และคิดมูลค่าต่อเคสได้</div>
                </div>
                <a class="btn btn-outline-secondary btn-sm fw-bold" href="med_error.php"><i class="fas fa-edit me-1"></i> ไปหน้าบันทึก</a>
            </div>

            <?php if ($saved_flash): ?>
            <div class="alert alert-success py-2">บันทึกค่าต่อเคสเรียบร้อยแล้ว (Med error <?php echo $h(med_error_report_format_baht($rate_error)); ?> บาท · Consult <?php echo $h(med_error_report_format_baht($rate_consult)); ?> บาท)</div>
            <?php elseif (isset($_GET['saved']) && (string)$_GET['saved'] === '0'): ?>
            <div class="alert alert-danger py-2">บันทึกค่าต่อเคสไม่สำเร็จ</div>
            <?php endif; ?>

            <div class="card shadow-sm border-0 mb-3">
                <div class="card-header bg-white border-bottom py-2">
                    <h6 class="mb-0 fw-bold"><i class="fas fa-filter text-danger me-2"></i>ตัวกรองรายงาน</h6>
                </div>
                <div class="card-body py-3">
                    <form method="GET" action="report_med_error.php" class="row g-2 align-items-end">
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1"><i class="far fa-calendar-alt me-1"></i>ตั้งแต่วันที่</label>
                            <input type="date" name="start_date" class="form-control form-control-sm border-primary" value="<?php echo $h($start_date); ?>">
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1"><i class="far fa-calendar-alt me-1"></i>ถึงวันที่</label>
                            <input type="date" name="end_date" class="form-control form-control-sm border-primary" value="<?php echo $h($end_date); ?>">
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ประเภทความคลาดเคลื่อน</label>
                            <select name="record_kind" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="error"<?php echo $rf_sel('record_kind', 'error'); ?>>ความคลาดเคลื่อนจริง</option>
                                <option value="consult"<?php echo $rf_sel('record_kind', 'consult'); ?>>บันทึกการ Consult</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ประเภทผู้ป่วย</label>
                            <select name="patient_type" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="OPD"<?php echo $rf_sel('patient_type', 'OPD'); ?>>ผู้ป่วยนอก (OPD)</option>
                                <option value="IPD"<?php echo $rf_sel('patient_type', 'IPD'); ?>>ผู้ป่วยใน (IPD)</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">หมวดหมู่ (Category)</label>
                            <select name="category" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <?php foreach ($categories as $c): ?>
                                <option value="<?php echo $h($c); ?>"<?php echo $rf_sel('category', $c); ?>><?php echo $h($c); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ระดับความรุนแรง</label>
                            <select name="error_level" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <?php foreach (['A','B','C','D','E','F','G','H','I'] as $lv): ?>
                                <option value="<?php echo $lv; ?>"<?php echo $rf_sel('error_level', $lv); ?>>Level <?php echo $lv; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ยา HAD</label>
                            <select name="is_had" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="YES"<?php echo $rf_sel('is_had', 'YES'); ?>>Yes</option>
                                <option value="NO"<?php echo $rf_sel('is_had', 'NO'); ?>>No</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">Robot</label>
                            <select name="is_robot" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="YES"<?php echo $rf_sel('is_robot', 'YES'); ?>>Yes</option>
                                <option value="NO"<?php echo $rf_sel('is_robot', 'NO'); ?>>No</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ประเภทใบสั่งยา</label>
                            <select name="rx_type" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <?php foreach (med_error_rx_types() as $rx_key => $rx_label): ?>
                                <option value="<?php echo $h($rx_key); ?>"<?php echo $rf_sel('rx_type', $rx_key); ?>><?php echo $h($rx_label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ผู้บันทึก</label>
                            <select name="reporter_id" class="form-select form-select-sm">
                                <?php echo $opt_filter_reporters; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">กลุ่มแพทย์ผู้สั่งใช้ยา</label>
                            <select name="doctor_group" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="staff"<?php echo $rf_sel('doctor_group', 'staff'); ?>>Staff</option>
                                <option value="intern"<?php echo $rf_sel('doctor_group', 'intern'); ?>>Intern</option>
                                <option value="extern"<?php echo $rf_sel('doctor_group', 'extern'); ?>>Extern</option>
                                <option value="none"<?php echo $rf_sel('doctor_group', 'none'); ?>>ยังไม่จัดกลุ่ม</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold text-muted mb-1">ค้นหาชื่อในตาราง</label>
                            <input type="text" id="fltName" class="form-control form-control-sm" placeholder="ชื่อผู้บันทึก..." autocomplete="off">
                        </div>
                        <div class="col-12">
                            <div class="rate-box p-3">
                                <div class="fw-bold text-dark mb-2"><i class="fas fa-coins text-warning me-1"></i>ตั้งค่ามูลค่าต่อเคส (บาท)</div>
                                <div class="row g-2 align-items-end">
                                    <div class="col-6 col-md-3">
                                        <label class="form-label fw-bold text-muted mb-1">Med error / เคส</label>
                                        <div class="input-group input-group-sm">
                                            <input type="number" name="rate_error" class="form-control" min="0" max="10000" step="1" value="<?php echo $h((string)(int)round($rate_error)); ?>">
                                            <span class="input-group-text">บาท</span>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <label class="form-label fw-bold text-muted mb-1">Consult / เคส</label>
                                        <div class="input-group input-group-sm">
                                            <input type="number" name="rate_consult" class="form-control" min="0" max="10000" step="1" value="<?php echo $h((string)(int)round($rate_consult)); ?>">
                                            <span class="input-group-text">บาท</span>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-3 d-grid">
                                        <button type="submit" class="btn btn-danger btn-sm fw-bold"><i class="fas fa-search me-1"></i>ประมวลผล</button>
                                    </div>
                                    <div class="col-6 col-md-3 d-grid">
                                        <button type="submit" name="save_rates" value="1" formmethod="post" class="btn btn-outline-warning btn-sm fw-bold text-dark"><i class="fas fa-save me-1"></i>บันทึกเป็นค่าเริ่มต้น</button>
                                    </div>
                                    <div class="col-12 small text-muted">ค่าเริ่มต้นของระบบ: Med error 15 บาท · Consult 0 บาท — กดประมวลผลเพื่อคิดมูลค่าตามตัวเลขที่กรอก หรือบันทึกเป็นค่าเริ่มต้นสำหรับครั้งถัดไป</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-lg-2 d-grid">
                            <a href="report_med_error.php" class="btn btn-outline-secondary btn-sm">ล้างตัวกรอง</a>
                        </div>
                        <div class="col-md-10">
                            <div class="d-flex flex-wrap gap-1">
                                <a class="btn btn-sm btn-outline-secondary" href="<?php echo $h($qs_self(date('Y-m-01'), date('Y-m-d'))); ?>">เดือนนี้</a>
                                <a class="btn btn-sm btn-outline-secondary" href="<?php echo $h($qs_self(date('Y-01-01'), date('Y-m-d'))); ?>">ตั้งแต่ต้นปี</a>
                                <a class="btn btn-sm btn-outline-secondary" href="<?php echo $h($qs_self($all_start, $all_end)); ?>">ทั้งหมด</a>
                            </div>
                        </div>
                        <div class="col-12">
                            <span class="badge bg-light text-dark border px-3 py-2 text-wrap text-start">
                                <i class="fas fa-filter me-1 text-danger"></i>ช่วงรายงาน: <?php echo $h($range_label); ?>
                            </span>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-6 col-lg-3">
                    <div class="card kpi-card p-3">
                        <div class="text-muted small">จำนวนผู้บันทึก</div>
                        <div class="kpi-value text-dark"><?php echo number_format($reporter_n); ?></div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card kpi-card p-3">
                        <div class="text-muted small">ME (ความคลาดเคลื่อนจริง)</div>
                        <div class="kpi-value text-danger"><?php echo number_format($sum_me); ?></div>
                        <div class="kpi-sub"><?php echo $h(med_error_report_format_baht($sum_me_baht)); ?> บาท (<?php echo $h(med_error_report_format_baht($rate_error)); ?> บาท/เคส)</div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card kpi-card p-3">
                        <div class="text-muted small">Consult</div>
                        <div class="kpi-value" style="color:#0aa2c0;"><?php echo number_format($sum_consult); ?></div>
                        <div class="kpi-sub"><?php echo $h(med_error_report_format_baht($sum_consult_baht)); ?> บาท (<?php echo $h(med_error_report_format_baht($rate_consult)); ?> บาท/เคส)</div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card kpi-card p-3">
                        <div class="text-muted small">รวมทั้งหมด</div>
                        <div class="kpi-value text-dark"><?php echo number_format($sum_total); ?></div>
                        <div class="kpi-sub fw-bold text-dark"><?php echo $h(med_error_report_format_baht($sum_baht)); ?> บาท</div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm border-0">
                <div class="card-header bg-white border-bottom py-2 d-flex justify-content-between align-items-center">
                    <h6 class="mb-0 fw-bold"><i class="fas fa-user-check text-danger me-2"></i>สรุปรายบุคคล</h6>
                    <span class="small text-muted"><?php echo $h($start_date); ?> ถึง <?php echo $h($end_date); ?></span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0 me-table" id="rptTable">
                            <thead>
                                <tr>
                                    <th class="text-center" style="width:56px;">#</th>
                                    <th>ผู้บันทึก</th>
                                    <th class="text-center">ME</th>
                                    <th class="text-center">Consult</th>
                                    <th class="text-center">รวม</th>
                                    <th class="text-end">ME (บาท)</th>
                                    <th class="text-end">Consult (บาท)</th>
                                    <th class="text-end">รวม (บาท)</th>
                                    <th style="min-width:160px;">สัดส่วน</th>
                                    <th class="text-center">% ของทั้งหมด</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (!$rows): ?>
                                <tr>
                                    <td colspan="10" class="text-center text-muted py-5">ไม่พบรายการตามตัวกรองนี้</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($rows as $i => $r):
                                    $rid = (int)$r['reporter_id'];
                                    $me = (int)$r['me_count'];
                                    $consult = (int)$r['consult_count'];
                                    $total = (int)$r['total_count'];
                                    $me_baht = $me * $rate_error;
                                    $consult_baht = $consult * $rate_consult;
                                    $row_baht = $me_baht + $consult_baht;
                                    $pct_all = $sum_total > 0 ? round(($total / $sum_total) * 100, 1) : 0;
                                    $bar_w = $max_total > 0 ? round(($total / $max_total) * 100, 1) : 0;
                                    $me_w = $total > 0 ? round(($me / $total) * $bar_w, 1) : 0;
                                    $consult_w = max(0, $bar_w - $me_w);
                                    $row_filters = $report_filters;
                                    $row_filters['reporter_id'] = $rid;
                                    $link = 'med_error.php?' . med_error_report_query_string($start_date, $end_date, $row_filters);
                                    $f_me = $row_filters;
                                    $f_me['record_kind'] = 'error';
                                    $link_me = 'med_error.php?' . med_error_report_query_string($start_date, $end_date, $f_me);
                                    $f_consult = $row_filters;
                                    $f_consult['record_kind'] = 'consult';
                                    $link_consult = 'med_error.php?' . med_error_report_query_string($start_date, $end_date, $f_consult);
                                    $is_self = $rid > 0 && $rid === (int)($_SESSION['user_id'] ?? 0);
                                ?>
                                <tr class="<?php echo $is_self ? 'me-self' : ''; ?>" data-name="<?php echo $h(mb_strtolower($r['reporter_name'], 'UTF-8')); ?>">
                                    <td class="text-center"><span class="rank-badge"><?php echo $i + 1; ?></span></td>
                                    <td>
                                        <a class="fw-bold text-dark text-decoration-none" href="<?php echo $h($link); ?>"><?php echo $h($r['reporter_name']); ?></a>
                                        <?php if ($is_self): ?><span class="badge bg-warning text-dark ms-1">ฉัน</span><?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <a class="count-link text-danger" href="<?php echo $h($link_me); ?>"><?php echo number_format($me); ?></a>
                                    </td>
                                    <td class="text-center">
                                        <a class="count-link" style="color:#0aa2c0;" href="<?php echo $h($link_consult); ?>"><?php echo number_format($consult); ?></a>
                                    </td>
                                    <td class="text-center">
                                        <a class="count-link text-dark" href="<?php echo $h($link); ?>"><?php echo number_format($total); ?></a>
                                    </td>
                                    <td class="text-end"><?php echo $h(med_error_report_format_baht($me_baht)); ?></td>
                                    <td class="text-end"><?php echo $h(med_error_report_format_baht($consult_baht)); ?></td>
                                    <td class="text-end fw-bold"><?php echo $h(med_error_report_format_baht($row_baht)); ?></td>
                                    <td>
                                        <div class="bar-track" title="ME <?php echo $me; ?> · Consult <?php echo $consult; ?>">
                                            <span class="bar-me" style="width:<?php echo $me_w; ?>%;"></span>
                                            <span class="bar-consult" style="width:<?php echo $consult_w; ?>%;"></span>
                                        </div>
                                    </td>
                                    <td class="text-center fw-bold"><?php echo $pct_all; ?>%</td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                            <?php if ($rows): ?>
                            <tfoot>
                                <tr class="fw-bold" style="background:#fff5f5;">
                                    <td></td>
                                    <td>รวม</td>
                                    <td class="text-center text-danger"><?php echo number_format($sum_me); ?></td>
                                    <td class="text-center" style="color:#0aa2c0;"><?php echo number_format($sum_consult); ?></td>
                                    <td class="text-center"><?php echo number_format($sum_total); ?></td>
                                    <td class="text-end"><?php echo $h(med_error_report_format_baht($sum_me_baht)); ?></td>
                                    <td class="text-end"><?php echo $h(med_error_report_format_baht($sum_consult_baht)); ?></td>
                                    <td class="text-end"><?php echo $h(med_error_report_format_baht($sum_baht)); ?></td>
                                    <td></td>
                                    <td class="text-center">100%</td>
                                </tr>
                            </tfoot>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
(function () {
    const inp = document.getElementById('fltName');
    const rows = document.querySelectorAll('#rptTable tbody tr[data-name]');
    if (!inp) return;
    inp.addEventListener('input', function () {
        const q = (inp.value || '').trim().toLowerCase();
        rows.forEach(function (tr) {
            const name = tr.getAttribute('data-name') || '';
            tr.style.display = (!q || name.indexOf(q) !== -1) ? '' : 'none';
        });
    });
})();
</script>
</body>
</html>
