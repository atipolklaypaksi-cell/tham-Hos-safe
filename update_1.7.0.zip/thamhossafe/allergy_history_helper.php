<?php
/**
 * ประวัติแพ้ยาใน รพ. — ดึงจาก HOSxP opd_allergy
 */

function ah_utf8($expr) {
    return "CAST(CONVERT(IFNULL($expr,'') USING utf8) AS CHAR)";
}

function ah_truesymptom_sql($alias = 'o') {
    return "CASE
        WHEN $alias.symptom LIKE '%DRESS%' THEN 'DRESS'
        WHEN $alias.symptom LIKE '%Anaphylaxis%' THEN 'Anaphylaxis'
        WHEN $alias.symptom LIKE '%Anaphylac%' THEN 'Anaphylactic shock'
        WHEN $alias.symptom LIKE '%TEN%' AND $alias.symptom NOT LIKE '%reten%' AND $alias.symptom NOT LIKE '%tension%' THEN 'TEN'
        WHEN $alias.symptom LIKE '%MALA%' THEN 'MALA'
        WHEN $alias.symptom LIKE '%Metformin%' THEN 'MALA'
        WHEN $alias.symptom LIKE '%lactic acid%' THEN 'MALA'
        WHEN $alias.symptom LIKE '%SJS%' THEN 'SJS'
        WHEN $alias.symptom LIKE '%Steven%' THEN 'SJS'
        ELSE ''
    END";
}

function ah_true_types() {
    return [
        'DRESS' => 'DRESS',
        'SJS' => 'SJS',
        'TEN' => 'TEN',
        'Anaphylaxis' => 'Anaphylaxis',
        'Anaphylactic shock' => 'Anaphylactic shock',
        'MALA' => 'MALA',
    ];
}

function ah_table_columns($hos, $table) {
    static $cache = [];
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    if ($table === '') {
        return [];
    }
    if (isset($cache[$table])) {
        return $cache[$table];
    }
    $cols = [];
    $q = @mysqli_query($hos, "SHOW COLUMNS FROM `$table`");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cols[strtolower((string)($r['Field'] ?? ''))] = (string)($r['Field'] ?? '');
        }
    }
    $cache[$table] = $cols;
    return $cols;
}

function ah_col(array $cols, array $candidates, $fallback_sql = "''") {
    foreach ($candidates as $c) {
        $k = strtolower($c);
        if (isset($cols[$k])) {
            return $cols[$k];
        }
    }
    return $fallback_sql;
}

function ah_hospital_name($con, $hos = null) {
    $name = trim((string)($_SESSION['license_hospital_name'] ?? ''));
    if ($name !== '') {
        return $name;
    }
    if ($hos) {
        require_once __DIR__ . '/drug_center_helper.php';
        if (function_exists('drug_center_fetch_hosxp_hospital_meta')) {
            $meta = drug_center_fetch_hosxp_hospital_meta($hos);
            if (!empty($meta['hname'])) {
                return (string)$meta['hname'];
            }
        }
    }
    return 'โรงพยาบาล';
}

function ah_hn_display($hn) {
    $hn = trim((string)$hn);
    if ($hn !== '' && ctype_digit($hn)) {
        return ltrim($hn, '0') ?: '0';
    }
    return $hn;
}

function ah_build_address($row) {
    $addr = trim((string)($row['addrpart'] ?? ''));
    $moo = trim((string)($row['moopart'] ?? ''));
    $tmb = trim((string)($row['tambon'] ?? ''));
    $amp = trim((string)($row['district'] ?? ''));
    $chw = trim((string)($row['province'] ?? ''));
    $parts = [];
    if ($addr !== '') {
        $parts[] = $addr;
    }
    if ($moo !== '' && $moo !== '0') {
        $parts[] = 'หมู่ที่ ' . $moo;
    }
    if ($tmb !== '') {
        $parts[] = 'ต.' . $tmb;
    }
    if ($amp !== '') {
        $parts[] = 'อ.' . $amp;
    }
    if ($chw !== '') {
        $parts[] = 'จ.' . $chw;
    }
    return trim(implode(' ', $parts));
}

function ah_is_filled($v) {
    $v = trim((string)$v);
    return $v !== '' && $v !== '-' && $v !== '0000-00-00' && strtolower($v) !== 'null';
}

function ah_is_yes($v) {
    $v = strtoupper(trim((string)$v));
    return $v === 'Y' || $v === '1' || $v === 'YES';
}

function ah_is_no($v) {
    $v = strtoupper(trim((string)$v));
    return $v === 'N' || $v === '0' || $v === 'NO';
}

function ah_completeness_fields() {
    return [
        'agent' => 'ยาที่แพ้',
        'symptom' => 'อาการที่แพ้',
        'seriousness_name' => 'ความรุนแรง',
        'relation_name' => 'ความสัมพันธ์',
        'source_name' => 'แหล่งข้อมูล',
        'evaluator_name' => 'ผู้ประเมิน',
    ];
}

function ah_assess_row(array $r) {
    $missing = [];
    foreach (ah_completeness_fields() as $key => $label) {
        if (!ah_is_filled($r[$key] ?? '')) {
            $missing[] = $label;
        }
    }
    $warnings = [];
    $preventable = ah_is_yes($r['preventable'] ?? '');
    $not_preventable = ah_is_no($r['preventable'] ?? '');
    $no_alert = ah_is_yes($r['no_alert'] ?? '');
    $forbid = ah_is_yes($r['force_no_order'] ?? '');
    $forbid_off = ah_is_no($r['force_no_order'] ?? '');
    $alert_type = trim((string)($r['alert_type_name'] ?? ''));
    $true_sym = trim((string)($r['true_symptom'] ?? ''));
    $naranjo = trim((string)($r['naranjo'] ?? ''));
    $score = (int)($r['preventable_score'] ?? 0);

    if ($true_sym !== '' && !ah_is_filled($naranjo)) {
        $warnings[] = 'อาการรุนแรงแต่ยังไม่มีผล Naranjo';
    }
    if ($no_alert && ($true_sym !== '' || $alert_type === 'แพ้ยา')) {
        $warnings[] = 'ปิดการแจ้งเตือนทั้งที่เป็นแพ้ยา/อาการรุนแรง';
    }
    if ($forbid_off && ($alert_type === 'แพ้ยา' || $true_sym !== '')) {
        $warnings[] = 'แพ้ยาแต่ไม่ได้ห้ามสั่งใช้';
    }
    if ($preventable && $score <= 0) {
        $warnings[] = 'Preventable แต่ยังไม่มีคะแนนแบบทดสอบ';
    }

    $alert_bits = [];
    if ($forbid) {
        $alert_bits[] = 'ห้ามสั่งใช้';
    } elseif ($forbid_off) {
        $alert_bits[] = 'ไม่ห้ามสั่งใช้';
    }
    if ($no_alert) {
        $alert_bits[] = 'ไม่แจ้งเตือน';
    }
    if ($alert_type !== '') {
        $alert_bits[] = $alert_type;
    }

    if ($preventable) {
        $prev_label = 'Preventable';
        if ($score > 0) {
            $prev_label .= ' (' . $score . ')';
        }
    } elseif ($not_preventable) {
        $prev_label = 'Not preventable';
    } else {
        $prev_label = '-';
    }

    $r['is_complete'] = empty($missing) ? 1 : 0;
    $r['completeness_label'] = empty($missing) ? 'สมบูรณ์' : 'ไม่สมบูรณ์';
    $r['missing_fields'] = $missing;
    $r['warnings'] = $warnings;
    $r['is_preventable'] = $preventable ? 1 : 0;
    $r['is_no_alert'] = $no_alert ? 1 : 0;
    $r['is_forbid_order'] = $forbid ? 1 : 0;
    $r['has_warning'] = (!empty($missing) || !empty($warnings) || $preventable || $no_alert) ? 1 : 0;
    $r['preventable_label'] = $prev_label;
    $r['alert_label'] = $alert_bits ? implode(' · ', $alert_bits) : '-';
    $r['alert_bits'] = $alert_bits;
    return $r;
}

function ah_fetch_rows($hos, array $filters) {
    $start = $filters['start_date'] ?? date('Y-m-01');
    $end = $filters['end_date'] ?? date('Y-m-d');
    $qtext = trim((string)($filters['q'] ?? ''));
    $severe_only = !empty($filters['severe_only']);
    $true_type = trim((string)($filters['true_type'] ?? ''));
    $unique_cid = !empty($filters['unique_cid']);
    $limit = max(50, min(3000, (int)($filters['limit'] ?? 1500)));

    $oa = ah_table_columns($hos, 'opd_allergy');
    if (empty($oa)) {
        return ['ok' => false, 'error' => 'ไม่พบตาราง opd_allergy ใน HOSxP', 'rows' => [], 'hosname' => ''];
    }
    $ser_cols = ah_table_columns($hos, 'allergy_seriousness');
    $ser_name = ah_col($ser_cols, ['seriousness_name', 'seiousness_name', 'name'], '');
    $onset_col = ah_col($oa, ['symptom_date', 'begin_date', 'allergy_date', 'onset_date'], '');
    $id_col = ah_col($oa, ['opd_allergy_id', 'allergy_id'], '0');

    $true_sql = ah_truesymptom_sql('o');
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $where = ["o.report_date BETWEEN '$start_esc' AND '$end_esc'"];

    if ($severe_only) {
        $where[] = "($true_sql) <> ''";
    }
    if ($true_type !== '' && isset(ah_true_types()[$true_type])) {
        $where[] = "($true_sql) = '" . mysqli_real_escape_string($hos, $true_type) . "'";
    }

    $onset_select = $onset_col !== '' && $onset_col !== "''"
        ? "o.`$onset_col` AS onset_date"
        : "NULL AS onset_date";
    $id_select = ($id_col !== '0') ? "o.`$id_col` AS opd_allergy_id" : '0 AS opd_allergy_id';
    $ser_select = $ser_name !== ''
        ? ah_utf8("al.`$ser_name`") . ' AS seriousness_name'
        : "'' AS seriousness_name";

    $has_ksk = ah_table_columns($hos, 'kskdepartment');
    $ksk_name = ah_col($has_ksk, ['department', 'name', 'department_name'], '');
    $dept_join = ($ksk_name !== '')
        ? "LEFT JOIN kskdepartment kd ON kd.depcode = o.department"
        : '';
    $dept_select = ($ksk_name !== '')
        ? 'COALESCE(' . ah_utf8("kd.`$ksk_name`") . ', ' . ah_utf8('o.department') . ') AS department_name'
        : ah_utf8('o.department') . ' AS department_name';

    $doc_cols = ah_table_columns($hos, 'doctor');
    $doc_code = ah_col($doc_cols, ['code'], '');
    $doc_join = ($doc_code !== '') ? "LEFT JOIN doctor d ON o.reporter = d.`$doc_code`" : '';
    $doc_select = ($doc_code !== '')
        ? ah_utf8("CONCAT(IFNULL(d.pname,''), IFNULL(d.name,''))") . ' AS reporter_name'
        : "'' AS reporter_name";

    $ou_cols = ah_table_columns($hos, 'opduser');
    $ou_login = ah_col($ou_cols, ['loginname'], '');
    $ou_name = ah_col($ou_cols, ['name'], '');
    $ou_join = ($ou_login !== '') ? "LEFT JOIN opduser ou ON TRIM(ou.`$ou_login`) = TRIM(o.reporter)" : '';

    $of_cols = ah_table_columns($hos, 'officer');
    $of_login = ah_col($of_cols, ['officer_login_name'], '');
    $of_name = ah_col($of_cols, ['officer_name'], '');
    $of_join = ($of_login !== '') ? "LEFT JOIN officer ofc ON TRIM(ofc.`$of_login`) = TRIM(o.reporter)" : '';

    $eval_parts = [];
    if ($ou_name !== '' && $ou_name !== "''") {
        $eval_parts[] = 'NULLIF(TRIM(' . ah_utf8("ou.`$ou_name`") . "), '')";
    }
    if ($of_name !== '' && $of_name !== "''") {
        if (isset($of_cols['officer_fname']) && isset($of_cols['officer_lname'])) {
            $pn = isset($of_cols['officer_pname']) ? "IFNULL(ofc.officer_pname,'')" : "''";
            $eval_parts[] = 'NULLIF(TRIM(' . ah_utf8("CONCAT($pn, IFNULL(ofc.officer_fname,''), ' ', IFNULL(ofc.officer_lname,''))") . "), '')";
        }
        $eval_parts[] = 'NULLIF(TRIM(' . ah_utf8("ofc.`$of_name`") . "), '')";
    }
    if ($doc_code !== '') {
        $eval_parts[] = 'NULLIF(TRIM(' . ah_utf8("CONCAT(IFNULL(d.pname,''), IFNULL(d.name,''))") . "), '')";
    }
    $eval_parts[] = 'NULLIF(TRIM(' . ah_utf8('o.reporter') . "), '')";
    $eval_select = 'COALESCE(' . implode(', ', $eval_parts) . ", '') AS evaluator_name";

    $extra_selects = [];
    $extra_joins = [];
    $extra_selects[] = isset($oa['preventable'])
        ? ah_utf8('o.preventable') . ' AS preventable'
        : "'' AS preventable";
    $extra_selects[] = isset($oa['adr_preventable_score'])
        ? 'IFNULL(o.adr_preventable_score,0) AS preventable_score'
        : '0 AS preventable_score';
    $extra_selects[] = isset($oa['force_no_order'])
        ? ah_utf8('o.force_no_order') . ' AS force_no_order'
        : "'' AS force_no_order";
    $extra_selects[] = isset($oa['no_alert'])
        ? ah_utf8('o.no_alert') . ' AS no_alert'
        : "'' AS no_alert";

    $naranjo_select = "'' AS naranjo";
    $nr_cols = ah_table_columns($hos, 'naranjo_result');
    if (isset($oa['naranjo_result_id']) && !empty($nr_cols)) {
        $nr_name = ah_col($nr_cols, ['naranjo_result_name', 'name'], '');
        if ($nr_name !== '' && $nr_name !== "''") {
            $extra_joins[] = 'LEFT JOIN naranjo_result nr ON nr.naranjo_result_id = o.naranjo_result_id';
            $naranjo_select = ah_utf8("nr.`$nr_name`") . ' AS naranjo';
        }
    }

    $at_cols = ah_table_columns($hos, 'opd_allergy_alert_type');
    if (isset($oa['opd_allergy_alert_type_id']) && !empty($at_cols)) {
        $at_name = ah_col($at_cols, ['opd_allergy_alert_type_name', 'name'], '');
        if ($at_name !== '' && $at_name !== "''") {
            $extra_joins[] = 'LEFT JOIN opd_allergy_alert_type oat ON oat.opd_allergy_alert_type_id = o.opd_allergy_alert_type_id';
            $extra_selects[] = ah_utf8("oat.`$at_name`") . ' AS alert_type_name';
        } else {
            $extra_selects[] = "'' AS alert_type_name";
        }
    } else {
        $extra_selects[] = "'' AS alert_type_name";
    }

    $ty_cols = ah_table_columns($hos, 'opd_allergy_type');
    if (isset($oa['opd_allergy_type_id']) && !empty($ty_cols)) {
        $ty_name = ah_col($ty_cols, ['opd_allergy_type_name', 'name'], '');
        if ($ty_name !== '' && $ty_name !== "''") {
            $extra_joins[] = 'LEFT JOIN opd_allergy_type oty ON oty.opd_allergy_type_id = o.opd_allergy_type_id';
            $extra_selects[] = ah_utf8("oty.`$ty_name`") . ' AS allergy_type_name';
        } else {
            $extra_selects[] = "'' AS allergy_type_name";
        }
    } else {
        $extra_selects[] = "'' AS allergy_type_name";
    }
    $extra_sql = implode(",\n            ", $extra_selects);
    $extra_join_sql = implode("\n        ", $extra_joins);

    if ($qtext !== '') {
        $like = '%' . mysqli_real_escape_string($hos, $qtext) . '%';
        $hn_esc = mysqli_real_escape_string($hos, preg_replace('/\s+/', '', $qtext));
        $search = "(o.hn LIKE '%$hn_esc%' OR p.cid LIKE '%$hn_esc%'
            OR " . ah_utf8('o.agent') . " LIKE '$like'
            OR " . ah_utf8('o.symptom') . " LIKE '$like'
            OR " . ah_utf8('o.reporter') . " LIKE '$like'
            OR CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), IFNULL(p.lname,'')) LIKE '$like'";
        if ($ou_name !== '' && $ou_name !== "''") {
            $search .= ' OR ' . ah_utf8("ou.`$ou_name`") . " LIKE '$like'";
        }
        if ($of_name !== '' && $of_name !== "''") {
            $search .= ' OR ' . ah_utf8("ofc.`$of_name`") . " LIKE '$like'";
        }
        $search .= ')';
        $where[] = $search;
    }

    $sql = "
        SELECT
            $id_select,
            o.hn,
            o.report_date,
            $onset_select,
            " . ah_utf8('o.agent') . " AS agent,
            " . ah_utf8('o.symptom') . " AS symptom,
            " . ah_utf8('o.note') . " AS note,
            $true_sql AS true_symptom,
            $naranjo_select,
            p.cid AS cid,
            " . ah_utf8("CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,''))") . " AS fullname,
            $dept_select,
            " . ah_utf8('ol.relation_name') . " AS relation_name,
            $ser_select,
            " . ah_utf8('os.opd_allergy_source_name') . " AS source_name,
            " . ah_utf8('p.addrpart') . " AS addrpart,
            " . ah_utf8('p.moopart') . " AS moopart,
            " . ah_utf8('t3.name') . " AS tambon,
            " . ah_utf8('t2.name') . " AS district,
            " . ah_utf8('t1.name') . " AS province,
            $doc_select,
            $eval_select,
            $extra_sql
        FROM opd_allergy o
        LEFT JOIN patient p ON p.hn = o.hn
        LEFT JOIN allergy_relation ol ON ol.allergy_relation_id = o.allergy_relation_id
        LEFT JOIN allergy_seriousness al ON al.seriousness_id = o.seriousness_id
        LEFT JOIN opd_allergy_source os ON os.opd_allergy_source_id = o.opd_allergy_source_id
        LEFT JOIN thaiaddress t1 ON t1.chwpart = p.chwpart AND t1.amppart = '00' AND t1.tmbpart = '00'
        LEFT JOIN thaiaddress t2 ON t2.chwpart = p.chwpart AND t2.amppart = p.amppart AND t2.tmbpart = '00'
        LEFT JOIN thaiaddress t3 ON t3.chwpart = p.chwpart AND t3.amppart = p.amppart AND t3.tmbpart = p.tmbpart
        $dept_join
        $doc_join
        $ou_join
        $of_join
        $extra_join_sql
        WHERE " . implode(' AND ', $where) . "
        ORDER BY o.report_date DESC, o.hn DESC
        LIMIT $limit
    ";

    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        $drop = array_filter([$dept_join, $doc_join, $ou_join, $of_join, $extra_join_sql], function ($s) {
            return $s !== '';
        });
        if ($drop) {
            $sql = str_replace(array_values($drop), array_fill(0, count($drop), ''), $sql);
            $sql = str_replace(
                [$dept_select, $doc_select, $eval_select],
                [
                    ah_utf8('o.department') . ' AS department_name',
                    "'' AS reporter_name",
                    ah_utf8('o.reporter') . ' AS evaluator_name',
                ],
                $sql
            );
            $q = @mysqli_query($hos, $sql);
        }
    }
    if (!$q) {
        return ['ok' => false, 'error' => 'ดึงข้อมูลไม่สำเร็จ: ' . mysqli_error($hos), 'rows' => [], 'hosname' => ''];
    }
    $rows = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $r['hn_display'] = ah_hn_display($r['hn'] ?? '');
        $r['fulladdress'] = ah_build_address($r);
        $r['true_symptom'] = trim((string)($r['true_symptom'] ?? ''));
        $r['evaluator_name'] = trim((string)($r['evaluator_name'] ?? ''));
        if ($r['evaluator_name'] === '' || preg_match('/^\d+$/', $r['evaluator_name'])) {
            $from_staff = trim((string)($r['reporter_name'] ?? ''));
            if ($from_staff !== '' && !preg_match('/^\d+$/', $from_staff)) {
                $r['evaluator_name'] = $from_staff;
            }
        }
        $r['reporter_name'] = $r['evaluator_name'];
        $r = ah_assess_row($r);
        $rows[] = $r;
    }
    if ($unique_cid) {
        $seen = [];
        $uniq = [];
        foreach ($rows as $r) {
            $key = trim((string)($r['cid'] ?? ''));
            if ($key === '') {
                $key = 'hn:' . (string)($r['hn'] ?? '');
            }
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $uniq[] = $r;
        }
        $rows = $uniq;
    }
    return ['ok' => true, 'error' => '', 'rows' => $rows];
}

function ah_summarize(array $rows) {
    $types = ah_true_types();
    $counts = array_fill_keys(array_keys($types), 0);
    $hn = [];
    $cid = [];
    $severe = 0;
    $incomplete = 0;
    $preventable = 0;
    $no_alert = 0;
    $warnings = 0;
    foreach ($rows as $r) {
        $h = (string)($r['hn'] ?? '');
        if ($h !== '') {
            $hn[$h] = true;
        }
        $c = trim((string)($r['cid'] ?? ''));
        if ($c !== '') {
            $cid[$c] = true;
        }
        $t = (string)($r['true_symptom'] ?? '');
        if ($t !== '') {
            $severe++;
            if (isset($counts[$t])) {
                $counts[$t]++;
            }
        }
        if (empty($r['is_complete'])) {
            $incomplete++;
        }
        if (!empty($r['is_preventable'])) {
            $preventable++;
        }
        if (!empty($r['is_no_alert'])) {
            $no_alert++;
        }
        if (!empty($r['warnings'])) {
            $warnings++;
        }
    }
    return [
        'total' => count($rows),
        'patients' => count($hn),
        'cid_count' => count($cid),
        'severe' => $severe,
        'incomplete' => $incomplete,
        'complete' => count($rows) - $incomplete,
        'preventable' => $preventable,
        'no_alert' => $no_alert,
        'warning_rows' => $warnings,
        'by_type' => $counts,
    ];
}
