<?php
/**
 * ประเมินการทำงานของตับเพื่อปรับขนาดยา (Dose Adjustment)
 * Child-Pugh = เกณฑ์หลักใน FDA/EMA labelling
 * MELD-Na = ความเสี่ยงเสียชีวิตระยะสั้น และ HRS
 *
 * Severe: Child-Pugh B/C, Decompensated, หรือ MELD-Na ≥ 15
 */

function monitor_lab_hepatic_lab_types() {
    return ['CHILD_PUGH', 'MELD_NA'];
}

function monitor_lab_hepatic_is_score_type($lab_type) {
    return $lab_type === 'CHILD_PUGH' || $lab_type === 'MELD_NA';
}

function monitor_lab_hepatic_dosing_catalog() {
    $topical = '/cream|ointment|gel|lotion|shampoo|ยาทา|แชมพู|ยาหยอด|eye\s*drop|eardrop/i';
    $nsaid_msg = 'ห้ามใช้ NSAIDs/COX-2 ใน Cirrhosis (AASLD/EASL) — ยับยั้ง renal prostaglandins ทำให้ AKI, เหนี่ยวนำ HRS และเพิ่มการเสียชีวิตจาก variceal bleeding';
    $bzd_msg = 'งด Long-acting benzodiazepine ในตับวาย/ตับแข็ง — half-life ยืดจาก hepatic clearance ที่ลดลง และสมองไวต่อ GABA สูงขึ้น เป็น precipitating factor ของ oversedation และ hepatic encephalopathy';
    $ace_msg = 'งด ACEI/ARB เมื่อเข้าสู่ decompensated cirrhosis หรือ refractory ascites — ความดันโลหิตและ renal perfusion พึ่ง angiotensin II หากถูกบล็อกจะเกิด renal hypoperfusion และ HRS';

    $nsaids = [
        ['name' => 'IBUPROFEN', 'generic' => ['IBUPROFEN']],
        ['name' => 'DICLOFENAC', 'generic' => ['DICLOFENAC']],
        ['name' => 'NAPROXEN', 'generic' => ['NAPROXEN']],
        ['name' => 'MEFENAMIC', 'generic' => ['MEFENAMIC']],
        ['name' => 'INDOMETHACIN', 'generic' => ['INDOMETHACIN', 'INDOMETACIN']],
        ['name' => 'PIROXICAM', 'generic' => ['PIROXICAM']],
        ['name' => 'MELOXICAM', 'generic' => ['MELOXICAM']],
        ['name' => 'KETOROLAC', 'generic' => ['KETOROLAC']],
        ['name' => 'ACECLOFENAC', 'generic' => ['ACECLOFENAC']],
        ['name' => 'ETORICOXIB', 'generic' => ['ETORICOXIB']],
        ['name' => 'CELECOXIB', 'generic' => ['CELECOXIB']],
        ['name' => 'PARECOXIB', 'generic' => ['PARECOXIB']],
        ['name' => 'ASPIRIN', 'generic' => ['ASPIRIN', 'ACETYLSALICYLIC']],
        ['name' => 'SULINDAC', 'generic' => ['SULINDAC']],
        ['name' => 'KETOPROFEN', 'generic' => ['KETOPROFEN']],
        ['name' => 'LOXOPROFEN', 'generic' => ['LOXOPROFEN']],
        ['name' => 'NIMESULIDE', 'generic' => ['NIMESULIDE']],
        ['name' => 'DEXKETOPROFEN', 'generic' => ['DEXKETOPROFEN']],
    ];
    $aceis = [
        ['name' => 'ENALAPRIL', 'generic' => ['ENALAPRIL']],
        ['name' => 'LISINOPRIL', 'generic' => ['LISINOPRIL']],
        ['name' => 'RAMIPRIL', 'generic' => ['RAMIPRIL']],
        ['name' => 'CAPTOPRIL', 'generic' => ['CAPTOPRIL']],
        ['name' => 'PERINDOPRIL', 'generic' => ['PERINDOPRIL']],
        ['name' => 'QUINAPRIL', 'generic' => ['QUINAPRIL']],
        ['name' => 'FOSINOPRIL', 'generic' => ['FOSINOPRIL']],
        ['name' => 'BENAZEPRIL', 'generic' => ['BENAZEPRIL']],
        ['name' => 'CILAZAPRIL', 'generic' => ['CILAZAPRIL']],
        ['name' => 'IMIDAPRIL', 'generic' => ['IMIDAPRIL']],
    ];
    $arbs = [
        ['name' => 'LOSARTAN', 'generic' => ['LOSARTAN']],
        ['name' => 'VALSARTAN', 'generic' => ['VALSARTAN']],
        ['name' => 'IRBESARTAN', 'generic' => ['IRBESARTAN']],
        ['name' => 'CANDESARTAN', 'generic' => ['CANDESARTAN']],
        ['name' => 'TELMISARTAN', 'generic' => ['TELMISARTAN']],
        ['name' => 'OLMESARTAN', 'generic' => ['OLMESARTAN']],
        ['name' => 'AZILSARTAN', 'generic' => ['AZILSARTAN']],
        ['name' => 'EPROSARTAN', 'generic' => ['EPROSARTAN']],
    ];
    $bzds = [
        ['name' => 'DIAZEPAM', 'generic' => ['DIAZEPAM']],
        ['name' => 'CHLORDIAZEPOXIDE', 'generic' => ['CHLORDIAZEPOXIDE']],
        ['name' => 'FLURAZEPAM', 'generic' => ['FLURAZEPAM']],
        ['name' => 'CLONAZEPAM', 'generic' => ['CLONAZEPAM']],
        ['name' => 'CLORAZEPATE', 'generic' => ['CLORAZEPATE']],
        ['name' => 'NITRAZEPAM', 'generic' => ['NITRAZEPAM']],
        ['name' => 'MEDAZEPAM', 'generic' => ['MEDAZEPAM']],
    ];

    $out = [];
    foreach ($nsaids as $d) {
        $out[] = [
            'name' => $d['name'],
            'generic' => $d['generic'],
            'exclude_name' => $topical,
            'rules' => [
                ['lab_type' => 'CHILD_PUGH', 'min' => 7, 'max' => 15, 'level' => 'hard', 'msg' => $nsaid_msg],
            ],
        ];
    }
    $out[] = [
        'name' => 'KETOCONAZOLE (oral)',
        'generic' => ['KETOCONAZOLE'],
        'skip_combo' => true,
        'exclude_name' => $topical,
        'rules' => [
            [
                'lab_type' => 'CHILD_PUGH',
                'min' => 5,
                'max' => 15,
                'level' => 'hard',
                'msg' => 'ห้ามใช้ Oral Ketoconazole ในผู้ป่วยโรคตับ — Black Box Warning / ถอนข้อบ่งใช้ systemic (US FDA, Thai FDA) จาก fatal hepatotoxicity',
            ],
        ],
    ];
    $out[] = [
        'name' => 'PYRAZINAMIDE',
        'generic' => ['PYRAZINAMIDE'],
        'rules' => [
            [
                'lab_type' => 'CHILD_PUGH',
                'min' => 7,
                'max' => 9.99,
                'level' => 'soft',
                'msg' => 'พิจารณาตัด Pyrazinamide จากสูตรวัณโรคเมื่อตับเป็น Child-Pugh B — DILI จาก PZA สูงสุดใน first-line anti-TB (ATS/CDC/IDSA)',
            ],
            [
                'lab_type' => 'CHILD_PUGH',
                'min' => 10,
                'max' => 15,
                'level' => 'hard',
                'msg' => 'ตัด Pyrazinamide ออกจากสูตรวัณโรคใน Severe liver disease / Child-Pugh C เป็นตัวแรก (ATS/CDC/IDSA) — drug-induced hepatitis สูงสุดใน first-line anti-TB',
            ],
        ],
    ];
    foreach ($bzds as $d) {
        $out[] = [
            'name' => $d['name'],
            'generic' => $d['generic'],
            'skip_combo' => true,
            'exclude_name' => $topical,
            'rules' => [
                ['lab_type' => 'CHILD_PUGH', 'min' => 7, 'max' => 15, 'level' => 'hard', 'msg' => $bzd_msg],
            ],
        ];
    }
    foreach (array_merge($aceis, $arbs) as $d) {
        $out[] = [
            'name' => $d['name'],
            'generic' => $d['generic'],
            'skip_combo' => true,
            'rules' => [
                ['lab_type' => 'CHILD_PUGH', 'min' => 7, 'max' => 15, 'level' => 'hard', 'msg' => $ace_msg],
            ],
        ];
    }
    return $out;
}

function monitor_lab_hepatic_points_bili($tbili) {
    if ($tbili === null || $tbili <= 0) {
        return null;
    }
    if ($tbili < 2) {
        return 1;
    }
    if ($tbili <= 3) {
        return 2;
    }
    return 3;
}

function monitor_lab_hepatic_points_albumin($alb) {
    if ($alb === null || $alb <= 0) {
        return null;
    }
    if ($alb > 3.5) {
        return 1;
    }
    if ($alb >= 2.8) {
        return 2;
    }
    return 3;
}

function monitor_lab_hepatic_points_inr($inr) {
    if ($inr === null || $inr <= 0) {
        return null;
    }
    if ($inr < 1.7) {
        return 1;
    }
    if ($inr <= 2.3) {
        return 2;
    }
    return 3;
}

function monitor_lab_hepatic_class_from_score($score) {
    $score = (int)$score;
    if ($score < 5) {
        return '';
    }
    if ($score <= 6) {
        return 'A';
    }
    if ($score <= 9) {
        return 'B';
    }
    return 'C';
}

function monitor_lab_hepatic_compute_meld($cr, $tbili, $inr, $na = null) {
    if ($cr === null || $tbili === null || $inr === null || $cr <= 0 || $tbili <= 0 || $inr <= 0) {
        return ['meld' => null, 'meld_na' => null];
    }
    $cr_b = max(1.0, min(4.0, (float)$cr));
    $bili_b = max(1.0, (float)$tbili);
    $inr_b = max(1.0, (float)$inr);
    $meld = (int)round(10 * (0.957 * log($cr_b) + 0.378 * log($bili_b) + 1.120 * log($inr_b) + 0.643));
    if ($meld < 6) {
        $meld = 6;
    }
    if ($meld > 40) {
        $meld = 40;
    }
    $meld_na = $meld;
    if ($na !== null && $na > 0 && $meld > 11) {
        $na_b = max(125.0, min(137.0, (float)$na));
        $meld_na = (int)round($meld + 1.32 * (137 - $na_b) - (0.033 * $meld * (137 - $na_b)));
        if ($meld_na < 6) {
            $meld_na = 6;
        }
        if ($meld_na > 40) {
            $meld_na = 40;
        }
    }
    return ['meld' => $meld, 'meld_na' => $meld_na];
}

function monitor_lab_hepatic_lab_num($lab) {
    if (!is_array($lab)) {
        return null;
    }
    $v = isset($lab['value']) ? (float)$lab['value'] : (float)($lab['val'] ?? 0);
    return $v > 0 ? $v : null;
}

function monitor_lab_hepatic_lab_when($lab) {
    if (!is_array($lab)) {
        return ['date' => '-', 'time' => ''];
    }
    return [
        'date' => $lab['date'] ?? '-',
        'time' => $lab['time'] ?? '',
    ];
}

function monitor_lab_hepatic_fmt_num($v, $dec = 2) {
    if ($v === null) {
        return '';
    }
    $s = number_format((float)$v, $dec, '.', '');
    if (strpos($s, '.') !== false) {
        $s = rtrim(rtrim($s, '0'), '.');
    }
    return $s;
}

function monitor_lab_hepatic_when_text($lab) {
    $when = monitor_lab_hepatic_lab_when($lab);
    $date = trim((string)$when['date']);
    $time = trim((string)$when['time']);
    if ($date === '' || $date === '-') {
        return '';
    }
    return $time !== '' ? ($date . ' ' . $time) : $date;
}

function monitor_lab_hepatic_component($group, $label, $value, $unit, $points, $when, $note = '') {
    return [
        'group' => (string)$group,
        'label' => (string)$label,
        'value' => (string)$value,
        'unit' => (string)$unit,
        'points' => $points,
        'when' => (string)$when,
        'note' => (string)$note,
    ];
}

function monitor_lab_hepatic_build_detail_text(array $components, $display = '') {
    $lines = [];
    $display = trim((string)$display);
    if ($display !== '') {
        $lines[] = $display;
    }
    $last = '';
    foreach ($components as $r) {
        $g = trim((string)($r['group'] ?? ''));
        if ($g === 'Clinical') {
            continue;
        }
        if ($g !== '' && $g !== $last) {
            $lines[] = $g;
            $last = $g;
        }
        $bit = trim((string)($r['label'] ?? ''));
        $val = trim((string)($r['value'] ?? ''));
        $unit = trim((string)($r['unit'] ?? ''));
        if ($val !== '') {
            $bit .= ' ' . $val . ($unit !== '' ? ' ' . $unit : '');
        }
        if ($r['points'] !== null && $r['points'] !== '') {
            $bit .= ' → ' . $r['points'];
        }
        $when = trim((string)($r['when'] ?? ''));
        if ($when !== '') {
            $bit .= ' · ' . $when;
        }
        $note = trim((string)($r['note'] ?? ''));
        if ($note !== '') {
            $bit .= ' ' . $note;
        }
        if ($bit !== '') {
            $lines[] = $bit;
        }
    }
    return implode("\n", $lines);
}

/**
 * @param array $inputs tbili,albumin,inr,scr,na as lab arrays; clinical ascites/he 1-3
 */
function monitor_lab_hepatic_compute_scores(array $inputs, array $clinical = []) {
    $tbili = monitor_lab_hepatic_lab_num($inputs['tbili'] ?? null);
    $alb = monitor_lab_hepatic_lab_num($inputs['albumin'] ?? null);
    $inr = monitor_lab_hepatic_lab_num($inputs['inr'] ?? null);
    $cr = monitor_lab_hepatic_lab_num($inputs['scr'] ?? null);
    $na = monitor_lab_hepatic_lab_num($inputs['na'] ?? null);

    $bili_pt = monitor_lab_hepatic_points_bili($tbili);
    $alb_pt = monitor_lab_hepatic_points_albumin($alb);
    $inr_pt = monitor_lab_hepatic_points_inr($inr);
    $asc_pt = (int)($clinical['ascites_pts'] ?? 1);
    $he_pt = (int)($clinical['he_pts'] ?? 1);
    if ($asc_pt < 1 || $asc_pt > 3) {
        $asc_pt = 1;
    }
    if ($he_pt < 1 || $he_pt > 3) {
        $he_pt = 1;
    }

    $cp_score = null;
    $cp_class = '';
    $cp_complete = ($bili_pt !== null && $alb_pt !== null && $inr_pt !== null);
    if ($cp_complete) {
        $cp_score = $bili_pt + $alb_pt + $inr_pt + $asc_pt + $he_pt;
        $cp_class = monitor_lab_hepatic_class_from_score($cp_score);
    }

    $meld = monitor_lab_hepatic_compute_meld($cr, $tbili, $inr, $na);
    $decompensated = !empty($clinical['decompensated']);
    $meld_na = $meld['meld_na'];
    $severe = ($cp_class === 'B' || $cp_class === 'C')
        || $decompensated
        || ($meld_na !== null && $meld_na >= 15)
        || ($meld['meld'] !== null && $meld_na === null && $meld['meld'] >= 15);

    $when = monitor_lab_hepatic_lab_when($inputs['tbili'] ?? null);
    if ($when['date'] === '-' || $when['date'] === '') {
        $when = monitor_lab_hepatic_lab_when($inputs['inr'] ?? null);
    }

    $missing = [];
    if ($tbili === null) {
        $missing[] = 'T.Bili';
    }
    if ($alb === null) {
        $missing[] = 'Albumin';
    }
    if ($inr === null) {
        $missing[] = 'INR';
    }
    if ($cr === null) {
        $missing[] = 'Cr';
    }
    if ($na === null) {
        $missing[] = 'Na';
    }

    $display_cp = $cp_complete
        ? ('Child-Pugh ' . $cp_class . ' (' . $cp_score . ')')
        : '';
    $display_meld = '';
    if ($meld_na !== null) {
        $display_meld = 'MELD-Na ' . $meld_na;
        if ($na === null) {
            $display_meld = 'MELD ' . $meld['meld'];
        }
    } elseif ($meld['meld'] !== null) {
        $display_meld = 'MELD ' . $meld['meld'];
    }
    $parts = array_filter([$display_cp, $display_meld]);
    $display = $parts ? implode(' · ', $parts) : '';
    if ($decompensated && $display === '') {
        $display = 'Decompensated (ICD)';
    }

    $clinical_note = trim((string)($clinical['note'] ?? ''));
    $has_ascites_icd = (stripos($clinical_note, 'Ascites') !== false) || $asc_pt >= 2;
    $has_he_icd = (preg_match('/\bHE\b/', $clinical_note) === 1) || $he_pt >= 2;

    $components = [
        monitor_lab_hepatic_component(
            'Child-Pugh',
            'T.Bili',
            $tbili !== null ? monitor_lab_hepatic_fmt_num($tbili, 2) : '',
            'mg/dL',
            $bili_pt,
            monitor_lab_hepatic_when_text($inputs['tbili'] ?? null),
            $tbili === null ? 'ไม่มีผล' : ''
        ),
        monitor_lab_hepatic_component(
            'Child-Pugh',
            'Albumin',
            $alb !== null ? monitor_lab_hepatic_fmt_num($alb, 1) : '',
            'g/dL',
            $alb_pt,
            monitor_lab_hepatic_when_text($inputs['albumin'] ?? null),
            $alb === null ? 'ไม่มีผล' : ''
        ),
        monitor_lab_hepatic_component(
            'Child-Pugh',
            'INR',
            $inr !== null ? monitor_lab_hepatic_fmt_num($inr, 2) : '',
            '',
            $inr_pt,
            monitor_lab_hepatic_when_text($inputs['inr'] ?? null),
            $inr === null ? 'ไม่มีผล' : ''
        ),
        monitor_lab_hepatic_component(
            'Child-Pugh',
            'Ascites',
            $has_ascites_icd ? 'มี' : 'ไม่มี',
            '',
            $asc_pt,
            '',
            $has_ascites_icd ? 'จาก ICD' : 'ไม่มี ICD (นับ 1)'
        ),
        monitor_lab_hepatic_component(
            'Child-Pugh',
            'HE',
            $has_he_icd ? 'มี' : 'ไม่มี',
            '',
            $he_pt,
            '',
            $has_he_icd ? 'จาก ICD' : 'ไม่มี ICD (นับ 1)'
        ),
        monitor_lab_hepatic_component(
            'MELD-Na',
            'Cr',
            $cr !== null ? monitor_lab_hepatic_fmt_num($cr, 2) : '',
            'mg/dL',
            null,
            monitor_lab_hepatic_when_text($inputs['scr'] ?? null),
            $cr === null ? 'ไม่มีผล' : ''
        ),
        monitor_lab_hepatic_component(
            'MELD-Na',
            'T.Bili',
            $tbili !== null ? monitor_lab_hepatic_fmt_num($tbili, 2) : '',
            'mg/dL',
            null,
            monitor_lab_hepatic_when_text($inputs['tbili'] ?? null),
            $tbili === null ? 'ไม่มีผล' : ''
        ),
        monitor_lab_hepatic_component(
            'MELD-Na',
            'INR',
            $inr !== null ? monitor_lab_hepatic_fmt_num($inr, 2) : '',
            '',
            null,
            monitor_lab_hepatic_when_text($inputs['inr'] ?? null),
            $inr === null ? 'ไม่มีผล' : ''
        ),
        monitor_lab_hepatic_component(
            'MELD-Na',
            'Na',
            $na !== null ? monitor_lab_hepatic_fmt_num($na, 1) : '',
            'mmol/L',
            null,
            monitor_lab_hepatic_when_text($inputs['na'] ?? null),
            $na === null ? 'ไม่มีผล (ใช้ MELD โดยไม่ปรับ Na)' : (($meld['meld'] !== null && $meld['meld'] <= 11) ? 'MELD ≤ 11 ไม่ปรับด้วย Na' : '')
        ),
    ];
    if ($clinical_note !== '') {
        $components[] = monitor_lab_hepatic_component('Clinical', 'ICD', $clinical_note, '', null, '', $decompensated ? 'Decompensated' : '');
    }
    $detail_text = monitor_lab_hepatic_build_detail_text($components, $display);

    return [
        'tbili' => $tbili,
        'albumin' => $alb,
        'inr' => $inr,
        'scr' => $cr,
        'na' => $na,
        'bili_pts' => $bili_pt,
        'alb_pts' => $alb_pt,
        'inr_pts' => $inr_pt,
        'ascites_pts' => $asc_pt,
        'he_pts' => $he_pt,
        'cp_score' => $cp_score,
        'cp_class' => $cp_class,
        'cp_complete' => $cp_complete,
        'meld' => $meld['meld'],
        'meld_na' => $meld_na,
        'decompensated' => $decompensated,
        'severe' => $severe,
        'clinical_note' => $clinical_note,
        'missing' => $missing,
        'display' => $display,
        'components' => $components,
        'detail_text' => $detail_text,
        'date' => $when['date'],
        'time' => $when['time'],
    ];
}

function monitor_lab_hepatic_score_lab_slots(array $score) {
    $cp_val = 0.0;
    if (!empty($score['cp_score'])) {
        $cp_val = (float)$score['cp_score'];
    }
    if (!empty($score['severe'])) {
        $cp_val = max($cp_val, 10.0);
    } elseif (!empty($score['cp_class']) && $score['cp_class'] === 'A') {
        $cp_val = max($cp_val, 5.0);
    } elseif (($score['meld_na'] ?? null) !== null && $score['meld_na'] >= 10) {
        $cp_val = max($cp_val, 5.0);
    } elseif (($score['meld'] ?? null) !== null && $score['meld'] >= 10) {
        $cp_val = max($cp_val, 5.0);
    }

    $meld_val = 0.0;
    if (($score['meld_na'] ?? null) !== null) {
        $meld_val = (float)$score['meld_na'];
    } elseif (($score['meld'] ?? null) !== null) {
        $meld_val = (float)$score['meld'];
    }

    $display = trim((string)($score['display'] ?? ''));
    $has = $display !== '' || $cp_val > 0 || $meld_val > 0;
    $date = $has ? ($score['date'] ?? '-') : '-';
    $time = $has ? ($score['time'] ?? '') : '';
    $components = is_array($score['components'] ?? null) ? $score['components'] : [];
    $detail = trim((string)($score['detail_text'] ?? ''));

    return [
        'CHILD_PUGH' => [
            'val' => $cp_val,
            'raw' => $display !== '' ? $display : (string)$cp_val,
            'date' => $date,
            'time' => $time,
            'display' => $display,
            'components' => $components,
            'detail' => $detail,
        ],
        'MELD_NA' => [
            'val' => $meld_val,
            'raw' => $display !== '' ? $display : (string)$meld_val,
            'date' => $date,
            'time' => $time,
            'display' => $display,
            'components' => $components,
            'detail' => $detail,
        ],
    ];
}

function monitor_lab_hepatic_fetch_score_inputs($hos, array &$memo, $hn, array $sys, $order_date, $order_time, $order_lab_min, $vstdate) {
    $empty = ['value' => 0, 'raw' => '', 'date' => '-', 'time' => ''];
    $pick = static function ($key) use ($hos, &$memo, $hn, $sys, $order_date, $order_time, $order_lab_min, $vstdate, $empty) {
        $code = trim((string)($sys[$key] ?? ''));
        if ($code === '') {
            return $empty;
        }
        return monitor_lab_get_lab_for_order($hos, $memo, $hn, $code, $order_date, $order_time, $order_lab_min, $vstdate);
    };
    return [
        'tbili' => $pick('h_code_tbili'),
        'albumin' => $pick('h_code_albumin'),
        'inr' => $pick('h_code_inr'),
        'scr' => $pick('h_code_scr'),
        'na' => $pick('h_code_na'),
    ];
}

function monitor_lab_hepatic_icd_norm($icd) {
    return strtoupper(str_replace(['.', ' '], '', trim((string)$icd)));
}

function monitor_lab_hepatic_icd_flags(array $icds) {
    $ascites = false;
    $he = false;
    $bleed = false;
    $hrs = false;
    $cirrhosis = false;
    $notes = [];
    foreach ($icds as $raw) {
        $c = monitor_lab_hepatic_icd_norm($raw);
        if ($c === '') {
            continue;
        }
        if (strpos($c, 'R18') === 0 || $c === 'K7031' || $c === 'K7011' || $c === 'K652' || $c === 'K7151') {
            $ascites = true;
            $notes['ascites'] = true;
        }
        if (strpos($c, 'K72') === 0 || strpos($c, 'G934') === 0 || $c === 'K7041') {
            $he = true;
            $notes['he'] = true;
        }
        if (strpos($c, 'I850') === 0 || strpos($c, 'I864') === 0 || strpos($c, 'I983') === 0) {
            $bleed = true;
            $notes['variceal'] = true;
        }
        if (strpos($c, 'K767') === 0) {
            $hrs = true;
            $notes['hrs'] = true;
        }
        if (strpos($c, 'K703') === 0 || strpos($c, 'K746') === 0 || strpos($c, 'K743') === 0
            || strpos($c, 'K744') === 0 || strpos($c, 'K745') === 0 || strpos($c, 'K717') === 0) {
            $cirrhosis = true;
        }
    }
    $decompensated = $ascites || $he || $bleed || $hrs;
    $note_bits = [];
    if (!empty($notes['ascites'])) {
        $note_bits[] = 'Ascites';
    }
    if (!empty($notes['he'])) {
        $note_bits[] = 'HE';
    }
    if (!empty($notes['variceal'])) {
        $note_bits[] = 'Variceal bleed';
    }
    if (!empty($notes['hrs'])) {
        $note_bits[] = 'HRS';
    }
    return [
        'ascites_pts' => $ascites ? 2 : 1,
        'he_pts' => $he ? 2 : 1,
        'decompensated' => $decompensated,
        'cirrhosis' => $cirrhosis,
        'note' => implode(', ', $note_bits),
    ];
}

function monitor_lab_hepatic_icd_where($col = 'd.icd10') {
    $c = preg_match('/^[A-Za-z0-9_.]+$/', (string)$col) ? $col : 'd.icd10';
    return "($c LIKE 'R18%' OR $c LIKE 'K72%' OR $c LIKE 'G934%' OR $c LIKE 'G93.4%'
        OR $c LIKE 'I850%' OR $c LIKE 'I85.0%' OR $c LIKE 'I864%' OR $c LIKE 'I86.4%'
        OR $c LIKE 'I983%' OR $c LIKE 'I98.3%' OR $c LIKE 'K767%' OR $c LIKE 'K76.7%'
        OR $c LIKE 'K703%' OR $c LIKE 'K70.3%' OR $c LIKE 'K7011%' OR $c LIKE 'K70.11%'
        OR $c LIKE 'K7031%' OR $c LIKE 'K70.31%' OR $c LIKE 'K7041%' OR $c LIKE 'K70.41%'
        OR $c LIKE 'K652%' OR $c LIKE 'K65.2%' OR $c LIKE 'K7151%' OR $c LIKE 'K71.51%'
        OR $c LIKE 'K746%' OR $c LIKE 'K74.6%')";
}

function monitor_lab_hepatic_prefetch_clinical($hos, array $hns, $end_date) {
    $out = [];
    $keys = [];
    foreach ($hns as $hn) {
        $hn = trim((string)$hn);
        if ($hn === '') {
            continue;
        }
        $trim = ltrim($hn, '0');
        if ($trim === '') {
            $trim = '0';
        }
        $keys[str_pad($trim, 9, '0', STR_PAD_LEFT)] = true;
        $keys[$trim] = true;
    }
    if (empty($keys) || !$hos) {
        return $out;
    }
    $end = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$end_date) ? $end_date : date('Y-m-d');
    $start = date('Y-m-d', strtotime($end . ' -180 days'));
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $icd_ipt = monitor_lab_hepatic_icd_where('d.icd10');
    $icd_opd = monitor_lab_hepatic_icd_where('d.icd10');
    $by_hn = [];

    foreach (array_chunk(array_keys($keys), 80) as $chunk) {
        $in_sql = "'" . implode("','", array_map(static function ($v) use ($hos) {
            return mysqli_real_escape_string($hos, $v);
        }, $chunk)) . "'";

        $qi = mysqli_query(
            $hos,
            "SELECT i.hn, TRIM(d.icd10) AS icd10
             FROM ipt i
             INNER JOIN iptdiag d ON d.an = i.an
             WHERE i.hn IN ({$in_sql})
               AND i.regdate BETWEEN '{$start_esc}' AND '{$end_esc}'
               AND {$icd_ipt}"
        );
        if ($qi) {
            while ($r = mysqli_fetch_assoc($qi)) {
                $hn = trim((string)($r['hn'] ?? ''));
                $icd = trim((string)($r['icd10'] ?? ''));
                if ($hn !== '' && $icd !== '') {
                    $by_hn[$hn][] = $icd;
                }
            }
        }
        $icd_od = monitor_lab_hepatic_icd_where('icd10');
        $qo = mysqli_query(
            $hos,
            "SELECT hn, TRIM(icd10) AS icd10
             FROM ovstdiag
             WHERE hn IN ({$in_sql})
               AND vstdate BETWEEN '{$start_esc}' AND '{$end_esc}'
               AND {$icd_od}"
        );
        if (!$qo) {
            $qo = mysqli_query(
                $hos,
                "SELECT o.hn, TRIM(d.icd10) AS icd10
                 FROM ovst o
                 INNER JOIN ovstdiag d ON d.vn = o.vn
                 WHERE o.hn IN ({$in_sql})
                   AND o.vstdate BETWEEN '{$start_esc}' AND '{$end_esc}'
                   AND {$icd_opd}"
            );
        }
        if ($qo) {
            while ($r = mysqli_fetch_assoc($qo)) {
                $hn = trim((string)($r['hn'] ?? ''));
                $icd = trim((string)($r['icd10'] ?? ''));
                if ($hn !== '' && $icd !== '') {
                    $by_hn[$hn][] = $icd;
                }
            }
        }
    }

    foreach ($by_hn as $hn => $icds) {
        $flags = monitor_lab_hepatic_icd_flags($icds);
        $out[$hn] = $flags;
        $out[ltrim($hn, '0')] = $flags;
    }
    return $out;
}

function monitor_lab_hepatic_clinical_for_hn(array $cache, $hn) {
    $hn = trim((string)$hn);
    if ($hn === '') {
        return ['ascites_pts' => 1, 'he_pts' => 1, 'decompensated' => false, 'note' => ''];
    }
    if (isset($cache[$hn])) {
        return $cache[$hn];
    }
    $trim = ltrim($hn, '0');
    if (isset($cache[$trim])) {
        return $cache[$trim];
    }
    return ['ascites_pts' => 1, 'he_pts' => 1, 'decompensated' => false, 'note' => ''];
}

function monitor_lab_insert_hepatic_rule($con, array $drug, array $rule) {
    $icode_esc = mysqli_real_escape_string($con, $drug['icode']);
    $lab_type = trim((string)($rule['lab_type'] ?? 'CHILD_PUGH'));
    if (!in_array($lab_type, ['CHILD_PUGH', 'MELD_NA'], true)) {
        $lab_type = 'CHILD_PUGH';
    }
    $lab_esc = mysqli_real_escape_string($con, $lab_type);
    $min_val = number_format((float)$rule['min'], 2, '.', '');
    $max_val = number_format((float)$rule['max'], 2, '.', '');
    $exists = mysqli_query(
        $con,
        "SELECT id FROM drug_safety_rules
         WHERE drug_icode = '$icode_esc'
           AND lab_type = '$lab_esc'
           AND min_val = '$min_val'
           AND max_val = '$max_val'
         LIMIT 1"
    );
    if ($exists && mysqli_num_rows($exists) > 0) {
        return 'skipped';
    }
    $name = trim((string)($drug['name_tmt'] ?? ''));
    if ($name === '') {
        $name = trim((string)($drug['name_local'] ?? ''));
    }
    $name_esc = mysqli_real_escape_string($con, $name);
    $msg_esc = mysqli_real_escape_string($con, (string)$rule['msg']);
    $level = (($rule['level'] ?? 'soft') === 'hard') ? 'hard' : 'soft';
    $sql = "INSERT INTO drug_safety_rules
        (drug_id, drug_icode, drug_name, lab_type, min_val, max_val,
         use_dose_condition, dose_min, dose_max, dose_unit,
         use_age_condition, age_min, age_max,
         use_weight_condition, weight_min, weight_max,
         action_type, action_value, suggestion_msg, alert_level, active_status, lab_condition_type)
        VALUES
        (0, '$icode_esc', '$name_esc', '$lab_esc', '$min_val', '$max_val',
         0, NULL, NULL, NULL,
         0, NULL, NULL,
         0, NULL, NULL,
         'omit', 0, '$msg_esc', '$level', 1, 'range')";
    return mysqli_query($con, $sql) ? 'inserted' : 'error';
}

function monitor_lab_import_hepatic_dosing_catalog($con, $hos) {
    $empty = [
        'ok' => false,
        'inserted' => 0,
        'skipped' => 0,
        'unmatched' => 0,
        'unmatched_names' => [],
        'message' => 'นำเข้าไม่สำเร็จ',
    ];
    if (!$hos) {
        $empty['message'] = 'ไม่สามารถเชื่อมต่อ HOSxP';
        return $empty;
    }
    ensure_drug_safety_rules_hosxp_columns($con);
    ensure_drug_safety_rules_alert_level_column($con);
    ensure_drug_safety_rules_lab_condition_columns($con);
    ensure_drug_safety_rules_patient_extra_columns($con);
    ensure_drug_safety_rules_duration_columns($con);
    ensure_drug_safety_rules_exempt_method_columns($con);

    $drugs = monitor_lab_fetch_active_drugs_for_egfr($hos);
    $inserted = 0;
    $skipped = 0;
    $unmatched_names = [];

    foreach (monitor_lab_hepatic_dosing_catalog() as $item) {
        $hits = [];
        $inactive_hits = [];
        foreach ($drugs as $d) {
            if (($d['icode'] ?? '') === '') {
                continue;
            }
            if (!monitor_lab_catalog_drug_matches($item, $d)) {
                continue;
            }
            if (($d['istatus'] ?? '') === 'Y') {
                $hits[$d['icode']] = $d;
            } else {
                $inactive_hits[$d['icode']] = $d;
            }
        }
        if (empty($hits)) {
            $hits = $inactive_hits;
        }
        if (empty($hits)) {
            $unmatched_names[] = $item['name'];
            continue;
        }
        foreach ($item['rules'] as $rule) {
            foreach ($hits as $d) {
                $res = monitor_lab_insert_hepatic_rule($con, $d, $rule);
                if ($res === 'inserted') {
                    $inserted++;
                } elseif ($res === 'skipped') {
                    $skipped++;
                }
            }
        }
    }

    return [
        'ok' => true,
        'inserted' => $inserted,
        'skipped' => $skipped,
        'unmatched' => count($unmatched_names),
        'unmatched_names' => $unmatched_names,
        'message' => 'ok',
    ];
}

function monitor_lab_hepatic_render_scores_tab() {
    ?>
            <div class="bg-white border border-top-0 p-4 rounded-bottom shadow-sm" id="mainScoreGuide">
                <div class="alert alert-light border small mb-4">
                    เกณฑ์ที่ใช้ใน <b>monitor_lab_hepatic</b> สำหรับปรับขนาดยา —
                    <b>Child-Pugh</b> เป็นเกณฑ์หลักใน FDA/EMA labelling ·
                    <b>MELD-Na</b> ใช้ดูความเสี่ยงเสียชีวิตระยะสั้นและ HRS ·
                    Severe = Child-Pugh B/C, Decompensated (ICD) หรือ MELD-Na ≥ 15
                </div>
                <div class="row g-4">
                    <div class="col-lg-7">
                        <h5 class="fw-bold mb-3"><i class="fas fa-notes-medical me-2 text-warning"></i>Child-Pugh</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm align-middle mb-2">
                                <thead class="table-light text-center">
                                    <tr>
                                        <th>ตัวแปร</th>
                                        <th>1 คะแนน</th>
                                        <th>2 คะแนน</th>
                                        <th>3 คะแนน</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="fw-bold">T.Bilirubin (mg/dL)</td>
                                        <td class="text-center">&lt; 2</td>
                                        <td class="text-center">2 – 3</td>
                                        <td class="text-center">&gt; 3</td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Albumin (g/dL)</td>
                                        <td class="text-center">&gt; 3.5</td>
                                        <td class="text-center">2.8 – 3.5</td>
                                        <td class="text-center">&lt; 2.8</td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">INR</td>
                                        <td class="text-center">&lt; 1.7</td>
                                        <td class="text-center">1.7 – 2.3</td>
                                        <td class="text-center">&gt; 2.3</td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Ascites</td>
                                        <td class="text-center">ไม่มี</td>
                                        <td class="text-center">เล็กน้อย / ควบคุมได้</td>
                                        <td class="text-center">ปานกลาง–รุนแรง</td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Hepatic encephalopathy</td>
                                        <td class="text-center">ไม่มี</td>
                                        <td class="text-center">Grade 1–2</td>
                                        <td class="text-center">Grade 3–4</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="table-responsive mb-3">
                            <table class="table table-bordered table-sm text-center mb-0">
                                <thead class="table-light">
                                    <tr><th>Class</th><th>คะแนนรวม</th><th>ความหมายในระบบนี้</th></tr>
                                </thead>
                                <tbody>
                                    <tr><td class="fw-bold">A</td><td>5–6</td><td>ไม่เข้า Severe จาก Child-Pugh</td></tr>
                                    <tr class="table-warning"><td class="fw-bold">B</td><td>7–9</td><td>Severe — ปรับ/งดยาตาม labelling</td></tr>
                                    <tr class="table-danger"><td class="fw-bold">C</td><td>10–15</td><td>Severe — งดยาความเสี่ยงสูง</td></tr>
                                </tbody>
                            </table>
                        </div>
                        <p class="small text-muted mb-0">
                            Lab ใช้ผลล่าสุดที่เจาะ<b>ก่อนเวลาสั่งยา</b> ·
                            Ascites / HE ในระบบนี้ดูจาก ICD (มี = 2 คะแนน, ไม่มี ICD = นับ 1 คือไม่มี)
                            จึงอาจ underestimate ถ้ามีอาการแต่ไม่ได้ลงรหัส
                        </p>
                    </div>
                    <div class="col-lg-5">
                        <h5 class="fw-bold mb-3"><i class="fas fa-heartbeat me-2 text-danger"></i>MELD / MELD-Na</h5>
                        <div class="border rounded p-3 mb-3 bg-light small">
                            <div class="fw-bold mb-2">MELD (OPTN)</div>
                            <code class="d-block mb-2" style="white-space: normal;">
                                MELD = 10 × [ 0.957 ln(Cr) + 0.378 ln(T.Bili) + 1.120 ln(INR) + 0.643 ]
                            </code>
                            <ul class="mb-0 ps-3">
                                <li>Cr, T.Bili, INR ต่ำสุดที่นับ = 1.0 · Cr สูงสุด = 4.0</li>
                                <li>ปัดเป็นจำนวนเต็ม แล้วจำกัดช่วง 6–40</li>
                            </ul>
                        </div>
                        <div class="border rounded p-3 mb-3 bg-light small">
                            <div class="fw-bold mb-2">MELD-Na (เมื่อ MELD &gt; 11)</div>
                            <code class="d-block mb-2" style="white-space: normal;">
                                MELD-Na = MELD + 1.32×(137−Na) − 0.033×MELD×(137−Na)
                            </code>
                            <ul class="mb-0 ps-3">
                                <li>Na จำกัด 125–137 mmol/L</li>
                                <li>ถ้า MELD ≤ 11 จะไม่ปรับด้วย Na (แสดงเป็น MELD-Na = MELD)</li>
                                <li>ช่วงคะแนน 6–40</li>
                            </ul>
                        </div>
                        <div class="border rounded p-3 mb-0 small">
                            <div class="fw-bold mb-2">Severe ในระบบนี้เมื่อใดก็ได้ข้อใดข้อหนึ่ง</div>
                            <ul class="mb-0 ps-3">
                                <li>Child-Pugh <b>B หรือ C</b> (คะแนน ≥ 7)</li>
                                <li><b>Decompensated</b> จาก ICD: ascites, HE, variceal bleed, HRS</li>
                                <li><b>MELD-Na ≥ 15</b></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <hr>
                <h6 class="fw-bold mb-2">ICD ที่ระบบใช้ประกอบ Child-Pugh / Decompensated</h6>
                <div class="table-responsive">
                    <table class="table table-sm table-bordered small mb-0">
                        <thead class="table-light">
                            <tr><th>กลุ่ม</th><th>รหัส (ตัวอย่าง)</th><th>ผลต่อคะแนน</th></tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="fw-bold">Ascites</td>
                                <td>R18, K70.31, K70.11, K65.2, K71.51</td>
                                <td>Ascites = 2 คะแนน และนับ Decompensated</td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Hepatic encephalopathy</td>
                                <td>K72, G93.4, K70.41</td>
                                <td>HE = 2 คะแนน และนับ Decompensated</td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Variceal bleed</td>
                                <td>I85.0, I86.4, I98.3</td>
                                <td>Decompensated (ไม่เพิ่มคะแนน Child-Pugh)</td>
                            </tr>
                            <tr>
                                <td class="fw-bold">HRS</td>
                                <td>K76.7</td>
                                <td>Decompensated (ไม่เพิ่มคะแนน Child-Pugh)</td>
                            </tr>
                            <tr>
                                <td class="fw-bold">Cirrhosis</td>
                                <td>K70.3, K74.6</td>
                                <td>บันทึกว่ามี cirrhosis — ยังไม่ขึ้น Severe ถ้าไม่มี B/C, decomp หรือ MELD-Na ≥ 15</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p class="small text-muted mt-3 mb-0">
                    ยาที่นำเข้าตามเกณฑ์นี้: NSAIDs/COX-2, Oral Ketoconazole, Pyrazinamide, Long-acting BZD, ACEI/ARB —
                    Hard Alert เมื่อเข้า Severe (PZA ใน Child-Pugh B เป็น Soft)
                </p>
            </div>
    <?php
}
