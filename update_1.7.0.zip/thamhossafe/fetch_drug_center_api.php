<?php
/**
 * Backend proxy สำหรับ Drugs Center API (ไม่เปิด secret ฝั่ง browser)
 */
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

require_once __DIR__ . '/connect.php';
session_write_close();
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/drug_center_helper.php';
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'status'));

if ($action === 'status') {
    $oauth = provider_oauth_status_summary();
    echo json_encode([
        'status' => 'ok',
        'oauth' => $oauth,
        'drug_center_configured' => drug_center_is_configured(),
        'base_url' => drug_center_is_configured() ? drug_center_base_url() : '',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'search') {
    $keyword = trim((string)($input['keyword'] ?? ''));
    $page = (int)($input['page'] ?? 1);
    $row = (int)($input['row'] ?? 10);
    $res = drug_center_search_drugs($keyword, $page, $row);
    echo json_encode([
        'status' => $res['ok'] ? 'ok' : 'error',
        'message' => $res['message'],
        'code' => $res['code'],
        'data' => $res['data'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'contrast' || $action === 'allergy' || $action === 'safety_check') {
    $codes = $input['code'] ?? $input['codes'] ?? [];
    if (is_string($codes)) {
        $codes = array_filter(array_map('trim', explode(',', $codes)));
    }
    if (!is_array($codes)) {
        $codes = [];
    }
    $cid = preg_replace('/\D+/', '', (string)($input['cid'] ?? ''));
    $hn = trim((string)($input['hn'] ?? ''));
    $opts = [
        'hcode' => $input['hcode'] ?? null,
        'history_mode' => $input['history_mode'] ?? '',
        'page' => $input['page'] ?? 1,
        'row' => $input['row'] ?? 50,
    ];

    // รองรับส่ง icode แล้วแปลงเป็น TPU
    $icodes = $input['icodes'] ?? [];
    if (is_string($icodes)) {
        $icodes = array_filter(array_map('trim', explode(',', $icodes)));
    }
    if (!empty($icodes) && is_array($icodes)) {
        $hos = hosxp_connect($con, 30);
        if ($hos) {
            $map = drug_center_map_icodes_to_tpu($hos, $icodes);
            $codes = array_values(array_unique(array_merge($codes, array_values($map))));
            if ($cid === '' && $hn !== '') {
                $cid = drug_center_fetch_patient_cid($hos, $hn);
            }
            mysqli_close($hos);
        }
    }

    if (empty($codes)) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ code (TPU) หรือ icodes'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($cid === '') {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ cid หรือ hn'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($action === 'contrast') {
        $res = drug_center_check_contrast($codes, $cid, $opts);
    } elseif ($action === 'allergy') {
        $res = drug_center_check_allergy($codes, $cid, $opts);
    } else {
        $res = drug_center_safety_check($codes, $cid, $opts);
    }

    echo json_encode([
        'status' => $res['ok'] ? 'ok' : 'error',
        'message' => $res['message'],
        'code' => $res['code'],
        'data' => $res['data'],
        'request_codes' => $codes,
        'cid' => $cid,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'med_reconcile') {
    $cid = preg_replace('/\D+/', '', (string)($input['cid'] ?? ''));
    $hn = trim((string)($input['hn'] ?? ''));
    $hos = hosxp_connect($con, 30);
    if ($hn !== '' && $hos) {
        $pt = drug_center_find_patient_by_hn($hos, $hn);
        if ($pt) {
            $hn = $pt['hn'];
            if ($cid === '' && !empty($pt['cid'])) {
                $cid = $pt['cid'];
            }
        } else {
            $hn = drug_center_canonical_hn($hn);
        }
    }
    if ($hn === '' && $cid !== '' && $hos) {
        $cid_esc = mysqli_real_escape_string($hos, $cid);
        $q = @mysqli_query($hos, "SELECT hn FROM patient WHERE REPLACE(cid,'-','') = '$cid_esc' LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            $hn = trim((string)($r['hn'] ?? ''));
        }
    }
    if ($hos) {
        mysqli_close($hos);
    }
    if ($cid === '' && $hn === '') {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ CID หรือ HN'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $opts = [
        'hcode' => $input['hcode'] ?? null,
        'history_mode' => $input['history_mode'] ?? '',
        'page' => $input['page'] ?? 1,
        'row' => $input['row'] ?? 100,
    ];
    $res = ['ok' => false, 'message' => '', 'code' => 0, 'data' => null];
    if ($cid !== '') {
        $res = drug_center_med_reconcile($cid, $opts);
    }
    $api_rows = [];
    if (!empty($res['ok']) && is_array($res['data']) && isset($res['data']['data']) && is_array($res['data']['data'])) {
        $api_rows = $res['data']['data'];
    }
    $enriched = drug_center_enrich_med_reconcile_rows($con, $api_rows, [
        'hn' => $hn,
        'cid' => $cid,
        'history_mode' => $opts['history_mode'],
    ]);
    $ok = !empty($res['ok']) || !empty($enriched['hosxp_used']);
    $data = is_array($res['data']) ? $res['data'] : [];
    $data['data'] = $enriched['rows'];
    if (!isset($data['pagination']) || !is_array($data['pagination'])) {
        $data['pagination'] = [];
    }
    $data['pagination']['total'] = count($enriched['rows']);
    $data['pagination']['hosxp_count'] = $enriched['hosxp_count'];
    $data['pagination']['phr_dropped'] = $enriched['phr_dropped'] ?? 0;

    $msg_bits = [];
    if (!empty($enriched['hosxp_used'])) {
        $msg_bits[] = 'รวมข้อมูล HOSxP ท้องถิ่นแล้ว';
    }
    if (!empty($enriched['phr_dropped'])) {
        $msg_bits[] = 'ตัด PHR ซ้ำ ' . (int)$enriched['phr_dropped'] . ' รายการ';
    }
    $msg_prefix = $msg_bits ? (implode(' · ', $msg_bits) . ' · ') : '';

    echo json_encode([
        'status' => $ok ? 'ok' : 'error',
        'message' => $ok
            ? ($msg_prefix . ($res['message'] ?: 'สำเร็จ'))
            : ($res['message'] ?: 'ไม่สำเร็จ'),
        'code' => $ok ? 200 : ($res['code'] ?? 400),
        'data' => $data,
        'cid' => $cid,
        'hn' => $enriched['hn'] ?: $hn,
        'hosxp_used' => $enriched['hosxp_used'],
        'hosxp_count' => $enriched['hosxp_count'],
        'phr_dropped' => $enriched['phr_dropped'] ?? 0,
        'local_hcodes' => $enriched['local_hcodes'],
        'local_hname' => $enriched['local_hname'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'check_all') {
    $codes = $input['code'] ?? $input['codes'] ?? [];
    if (is_string($codes)) {
        $codes = array_filter(array_map('trim', explode(',', $codes)));
    }
    if (!is_array($codes)) {
        $codes = [];
    }
    $cid = preg_replace('/\D+/', '', (string)($input['cid'] ?? ''));
    $hn = trim((string)($input['hn'] ?? ''));
    $opts = [
        'hcode' => $input['hcode'] ?? null,
        'history_mode' => $input['history_mode'] ?? '',
        'med_reconcile_history' => $input['med_reconcile_history'] ?? '6M',
    ];

    $icodes = $input['icodes'] ?? [];
    if (is_string($icodes)) {
        $icodes = array_filter(array_map('trim', explode(',', $icodes)));
    }
    $load_recent = !empty($input['load_recent_from_hn']);

    if ($hn !== '' && ($cid === '' || $load_recent || (!empty($icodes) && is_array($icodes)))) {
        $hos = hosxp_connect($con, 30);
        if ($hos) {
            if ($cid === '') {
                $cid = drug_center_fetch_patient_cid($hos, $hn);
            }
            if ($load_recent) {
                $recent = drug_center_recent_tpu_by_hn($hos, $hn, (int)($input['recent_days'] ?? 7));
                if ($cid === '' && !empty($recent['cid'])) {
                    $cid = $recent['cid'];
                }
                $codes = array_values(array_unique(array_merge($codes, $recent['codes'])));
            }
            if (!empty($icodes) && is_array($icodes)) {
                $map = drug_center_map_icodes_to_tpu($hos, $icodes);
                $codes = array_values(array_unique(array_merge($codes, array_values($map))));
            }
            mysqli_close($hos);
        }
    }

    if ($cid === '') {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ CID หรือ HN'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (empty($codes)) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุรหัสยา (TPU) หรือโหลดจาก HN'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $res = drug_center_check_all($codes, $cid, $opts);
    if (!empty($res['ok']) && is_array($res['data']) && isset($res['data']['med_reconcile']) && is_array($res['data']['med_reconcile'])) {
        $enriched = drug_center_enrich_med_reconcile_rows($con, $res['data']['med_reconcile'], [
            'hn' => $hn,
            'cid' => $cid,
            'history_mode' => $opts['med_reconcile_history'] ?: ($opts['history_mode'] ?? '6M'),
        ]);
        $res['data']['med_reconcile'] = $enriched['rows'];
    }
    // เติมชื่อสถานพยาบาลใน contrast/allergy organization fields ถ้ามี
    if (!empty($res['ok']) && is_array($res['data'])) {
        $name_map = drug_center_hospital_name_map($con);
        $need_codes = [];
        foreach (['contrast', 'allergy'] as $section) {
            if (empty($res['data'][$section]) || !is_array($res['data'][$section])) {
                continue;
            }
            foreach ($res['data'][$section] as $row) {
                if (!is_array($row)) {
                    continue;
                }
                foreach (['contrast_organization_code', 'organization_code'] as $ck) {
                    $c = drug_center_normalize_hcode($row[$ck] ?? '');
                    if ($c !== '') {
                        $need_codes[$c] = true;
                    }
                }
            }
        }
        if (!empty($need_codes)) {
            $hos_nm = hosxp_connect($con, 15);
            if ($hos_nm) {
                foreach (drug_center_lookup_hospcode_names($hos_nm, array_keys($need_codes)) as $c => $n) {
                    if (!isset($name_map[$c]) || $name_map[$c] === '') {
                        $name_map[$c] = $n;
                    }
                }
                mysqli_close($hos_nm);
            }
        }
        foreach (['contrast', 'allergy'] as $section) {
            if (empty($res['data'][$section]) || !is_array($res['data'][$section])) {
                continue;
            }
            foreach ($res['data'][$section] as &$row) {
                if (!is_array($row)) {
                    continue;
                }
                foreach (['contrast_organization_code', 'organization_code'] as $ck) {
                    if (empty($row[$ck])) {
                        continue;
                    }
                    $code = drug_center_normalize_hcode($row[$ck]);
                    $row[$ck] = $code;
                    $nm_key = str_replace('_code', '_name', $ck);
                    $disp = drug_center_hospital_display_name($con, $code, $name_map);
                    if ($disp === '' && isset($name_map[$code])) {
                        $disp = $name_map[$code];
                    }
                    if ($disp === '' && !empty($row[$nm_key]) && !preg_match('/^(รหัส\s*)?\d+$/u', trim((string)$row[$nm_key]))) {
                        $disp = trim((string)$row[$nm_key]);
                    }
                    $row[$nm_key] = $disp !== '' ? $disp : ('รหัส ' . $code);
                }
            }
            unset($row);
        }
    }
    echo json_encode([
        'status' => $res['ok'] ? 'ok' : 'error',
        'message' => $res['message'],
        'code' => $res['code'],
        'data' => $res['data'],
        'request_codes' => $codes,
        'cid' => $cid,
        'hn' => $hn,
        'hcode' => drug_center_resolve_hcode($opts['hcode'] ?? null),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'lookup_hn') {
    $hn = trim((string)($input['hn'] ?? ''));
    if ($hn === '') {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ HN'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $hos = hosxp_connect($con, 20);
    if (!$hos) {
        echo json_encode(['status' => 'error', 'message' => 'เชื่อมต่อ HOSxP ไม่ได้'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $patient = drug_center_find_patient_by_hn($hos, $hn);
    $hn_found = $patient ? $patient['hn'] : drug_center_canonical_hn($hn);
    $recent = drug_center_recent_tpu_by_hn($hos, $hn_found, (int)($input['recent_days'] ?? 7));
    $ptname = $patient ? ($patient['ptname'] ?? '') : '';
    $cid = $patient ? ($patient['cid'] ?? '') : ($recent['cid'] ?? '');
    if ($cid === '' && !empty($recent['cid'])) {
        $cid = $recent['cid'];
    }
    mysqli_close($hos);
    echo json_encode([
        'status' => $patient ? 'ok' : 'error',
        'message' => $patient ? '' : 'ไม่พบ HN นี้ใน HOSxP',
        'hn' => $hn_found,
        'cid' => $cid,
        'ptname' => $ptname,
        'codes' => $recent['codes'] ?? [],
        'items' => $recent['items'] ?? [],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'smart_drug_dc') {
    $hn = trim((string)($input['hn'] ?? ''));
    $cid = preg_replace('/\D+/', '', (string)($input['cid'] ?? ''));
    $months = (int)($input['months'] ?? 6);
    $mode_map = [3 => '3M', 6 => '6M', 12 => '1Y', 36 => '1Y', 60 => '1Y', 0 => '1Y'];
    $history_mode = trim((string)($input['history_mode'] ?? ''));
    if ($history_mode === '') {
        $history_mode = $mode_map[$months] ?? '6M';
    }
    $bundle = drug_center_smart_drug_bundle($con, $hn, $cid, $history_mode);
    echo json_encode([
        'status' => !empty($bundle['ok']) ? 'ok' : 'error',
        'message' => $bundle['message'] ?? '',
        'need_provider' => !empty($bundle['need_provider']),
        'oauth' => provider_oauth_status_summary(),
        'cid' => $bundle['cid'] ?? $cid,
        'hn' => $bundle['hn'] ?? $hn,
        'history' => $bundle['history'] ?? [],
        'visits' => $bundle['visits'] ?? [],
        'allergy' => $bundle['allergy'] ?? ['has_allergy' => false, 'text' => '', 'agents' => []],
        'meta' => [
            'hosxp_count' => $bundle['hosxp_count'] ?? 0,
            'phr_dropped' => $bundle['phr_dropped'] ?? 0,
            'history_mode' => $history_mode,
        ],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Unknown action'], JSON_UNESCAPED_UNICODE);
