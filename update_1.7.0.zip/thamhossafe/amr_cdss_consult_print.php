<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('amr_cdss_consult_helper.php');
mysqli_set_charset($con, 'utf8');

if (!function_exists('acc_print_aware_meta')) {
    function acc_print_aware_meta(array $d) {
        $who = trim((string)($d['who_aware'] ?? ''));
        $hosp = trim((string)($d['aware'] ?? ''));
        if ($who !== '' && $hosp !== '' && $who !== $hosp) {
            return 'WHO ' . $who . ' / รพ. ' . $hosp;
        }
        if ($hosp !== '') {
            return 'รพ. ' . $hosp . ($who !== '' ? ' (WHO ' . $who . ')' : '');
        }
        return $who !== '' ? ('WHO ' . $who) : '';
    }
}

acc_ensure_tables($con);

$ids = [];
if (!empty($_GET['ids'])) {
    foreach (preg_split('/[,\s]+/', (string)$_GET['ids']) as $p) {
        $n = (int)$p;
        if ($n > 0) {
            $ids[$n] = true;
        }
    }
}
$id_one = (int)($_GET['id'] ?? 0);
if ($id_one > 0) {
    $ids[$id_one] = true;
}
$ids = array_keys($ids);

$rows = [];
foreach ($ids as $id) {
    $row = acc_get_consult($con, $id);
    if ($row) {
        acc_mark_printed($con, $id);
        $rows[] = acc_format_consult_row($row);
    }
}
if (empty($rows)) {
    die('ไม่พบใบปรึกษา — กรุณาเริ่ม Consult จากหน้า CDSS for Antibiotic ก่อน');
}

$primary = $rows[0];
$print_date = date('d/m/Y H:i');
$pharm_name = '';
foreach ($rows as $r) {
    if (trim((string)$r['pharmacist_name']) !== '') {
        $pharm_name = $r['pharmacist_name'];
        break;
    }
}
$reply_wait = (int)($primary['reply_wait_days'] ?: 0);
$reply_due = '';
foreach ($rows as $r) {
    if (($r['status'] ?? '') === 'in_progress' && !empty($r['reply_due_at'])) {
        $reply_due = $r['reply_due_at'];
        $reply_wait = (int)$r['reply_wait_days'];
        break;
    }
}
$note = '';
foreach ($rows as $r) {
    if (trim((string)$r['consult_note']) !== '') {
        $note = $r['consult_note'];
        break;
    }
}

function acc_print_esc($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function acc_print_sir_class($sir) {
    $s = strtoupper(trim((string)$sir));
    if ($s === 'S') {
        return 'sir-s';
    }
    if ($s === 'I') {
        return 'sir-i';
    }
    if ($s === 'R') {
        return 'sir-r';
    }
    return 'sir-u';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ใบปรึกษาแพทย์ — CDSS for Antibiotic</title>
    <style>
        @page { size: A4 portrait; margin: 10mm 12mm; }
        * { box-sizing: border-box; }
        body {
            font-family: 'Sarabun', Tahoma, sans-serif;
            font-size: 11.5px;
            color: #111;
            background: #fff;
            margin: 0;
            line-height: 1.35;
        }
        .sheet { width: 100%; max-width: 190mm; margin: 0 auto; padding: 8px 4px; }
        .print-header {
            border-bottom: 2px solid #b91c1c;
            margin-bottom: 8px;
            padding-bottom: 6px;
            text-align: center;
        }
        .print-header .brand { font-size: 11px; color: #64748b; }
        .print-header h1 {
            margin: 2px 0;
            font-size: 18px;
            font-weight: 800;
            color: #991b1b;
        }
        .print-header .sub { font-size: 12px; font-weight: 700; }
        .print-header .meta { font-size: 10.5px; margin-top: 2px; }
        .badge-st {
            display: inline-block;
            border: 1px solid #64748b;
            border-radius: 3px;
            padding: 1px 6px;
            font-size: 10px;
        }
        .info-grid {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 6px;
        }
        .info-grid td { padding: 2px 4px; vertical-align: top; }
        .info-grid .lbl { font-weight: 700; width: 88px; color: #334155; white-space: nowrap; }
        .drug-table {
            width: 100%;
            border-collapse: collapse;
            margin: 6px 0 8px;
            font-size: 11px;
        }
        .drug-table th, .drug-table td {
            border: 1px solid #334155;
            padding: 4px 5px;
            vertical-align: top;
        }
        .drug-table th {
            background: #fef2f2;
            text-align: center;
            font-weight: 700;
        }
        .drug-table th.ok { background: #ecfdf5; }
        .drug-table td.num { text-align: center; white-space: nowrap; }
        .sir {
            display: inline-block;
            min-width: 18px;
            text-align: center;
            font-weight: 800;
            border-radius: 3px;
            padding: 0 5px;
        }
        .sir-r { background: #fee2e2; color: #991b1b; }
        .sir-i { background: #fef3c7; color: #92400e; }
        .sir-s { background: #dcfce7; color: #166534; }
        .sir-u { background: #e2e8f0; color: #334155; }
        .box {
            border: 1px solid #334155;
            border-radius: 4px;
            padding: 6px 8px;
            margin-top: 6px;
        }
        .box-title { font-weight: 700; margin-bottom: 3px; color: #991b1b; font-size: 11.5px; }
        .box-title.ok { color: #047857; }
        .doctor-box { min-height: 72px; }
        .doctor-lines { margin-top: 8px; }
        .doctor-lines div {
            border-bottom: 1px dotted #64748b;
            height: 18px;
            margin-top: 2px;
        }
        .sign-row {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            margin-top: 14px;
        }
        .sign-box { flex: 1; text-align: center; font-size: 11px; }
        .sign-line {
            margin-top: 28px;
            border-top: 1px solid #333;
            padding-top: 4px;
        }
        .hint { font-size: 10px; color: #475569; }
        @media print {
            .no-print { display: none !important; }
            body { margin: 0; }
            .sheet { padding: 0; max-width: none; }
            a { color: inherit; text-decoration: none; }
        }
        @media screen {
            body { background: #e2e8f0; padding: 16px; }
            .sheet {
                background: #fff;
                box-shadow: 0 1px 8px rgba(0,0,0,.12);
                padding: 14px 18px;
                min-height: 260mm;
            }
        }
    </style>
</head>
<body>
<div class="sheet">
    <div class="no-print" style="margin-bottom:10px;">
        <button onclick="window.print()" style="padding:6px 12px;font-weight:700;">พิมพ์</button>
        <button onclick="window.close()" style="padding:6px 12px;">ปิด</button>
        <a href="amr_sensitivity.php?order=<?php echo urlencode($primary['lab_order_number']); ?>" style="margin-left:8px;">กลับ CDSS</a>
        <span class="hint" style="margin-left:12px;">แนะนำ: กระดาษ A4 · แนวตั้ง (Portrait) · ขนาด 100%</span>
    </div>

    <div class="print-header">
        <div class="brand">THAM Hos-Safe · CDSS for Antibiotic</div>
        <h1>ใบปรึกษาแพทย์</h1>
        <div class="sub">เรื่อง ยาปฏิชีวนะไม่เหมาะสมต่อผล Sensitivity (ผล R)</div>
        <div class="meta">
            สถานะ: <span class="badge-st"><?php echo acc_print_esc($primary['status_label']); ?></span>
            · วันที่พิมพ์ <?php echo acc_print_esc($print_date); ?>
            · Lab order <?php echo acc_print_esc($primary['lab_order_number']); ?>
        </div>
    </div>

    <table class="info-grid">
        <tr>
            <td class="lbl">HN</td>
            <td><strong><?php echo acc_print_esc($primary['hn']); ?></strong></td>
            <td class="lbl">AN</td>
            <td><?php echo acc_print_esc($primary['an']); ?></td>
        </tr>
        <tr>
            <td class="lbl">ชื่อผู้ป่วย</td>
            <td colspan="3"><?php echo acc_print_esc($primary['ptname']); ?></td>
        </tr>
        <tr>
            <td class="lbl">Ward</td>
            <td><?php echo acc_print_esc($primary['ward_name']); ?></td>
            <td class="lbl">Specimen</td>
            <td><?php echo acc_print_esc($primary['specimen'] !== '' ? $primary['specimen'] : '-'); ?></td>
        </tr>
        <tr>
            <td class="lbl">เชื้อ</td>
            <td colspan="3">
                <strong><?php echo acc_print_esc($primary['organism'] !== '' ? $primary['organism'] : '-'); ?></strong>
                <?php if ($primary['phenotype'] !== ''): ?>
                    · <?php echo acc_print_esc($primary['phenotype']); ?>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td class="lbl">วันที่รายงาน</td>
            <td><?php echo acc_print_esc($primary['report_date'] !== '' ? $primary['report_date'] : '-'); ?></td>
            <td class="lbl">eGFR</td>
            <td>
                <?php
                echo $primary['egfr'] !== ''
                    ? acc_print_esc($primary['egfr']) . ($primary['egfr_date'] !== '' ? ' (' . acc_print_esc($primary['egfr_date']) . ')' : '')
                    : '-';
                ?>
            </td>
        </tr>
        <tr>
            <td class="lbl">เภสัชกร</td>
            <td colspan="3"><strong><?php echo acc_print_esc($pharm_name !== '' ? $pharm_name : '-'); ?></strong></td>
        </tr>
        <?php if ($reply_due !== ''): ?>
        <tr>
            <td class="lbl">รอตอบกลับ</td>
            <td colspan="3"><?php echo $reply_wait; ?> วัน (ถึง <?php echo acc_print_esc($reply_due); ?>)</td>
        </tr>
        <?php endif; ?>
    </table>

    <?php if (trim((string)$primary['verdict_title']) !== ''): ?>
    <div class="box">
        <div class="box-title">สรุปจาก CDSS</div>
        <div><?php echo acc_print_esc($primary['verdict_title']); ?></div>
    </div>
    <?php endif; ?>

    <?php
    $current = is_array($primary['current_drugs']) ? $primary['current_drugs'] : [];
    $recs = is_array($primary['recommend']) ? $primary['recommend'] : [];
    ?>

    <div class="box-title" style="margin-top:8px;">ยาที่กำลังให้ (ยาไม่เหมาะสม = ผล R)</div>
    <table class="drug-table">
        <thead>
            <tr>
                <th style="width:28px;">#</th>
                <th>ยา</th>
                <th style="width:42px;">SIR</th>
                <th style="width:70px;">MIC</th>
                <th>วิธีใช้ / AWaRe</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!$current): ?>
            <tr><td colspan="5" class="hint">ไม่มีรายการยาปัจจุบัน</td></tr>
            <?php else: ?>
            <?php foreach ($current as $i => $d): ?>
            <?php
                $sir = strtoupper((string)($d['sir'] ?? ''));
                $name = trim((string)($d['drugName'] ?? $d['drug'] ?? ''));
                $meta = [];
                if (!empty($d['method'])) {
                    $meta[] = $d['method'];
                }
                $aw = acc_print_aware_meta($d);
                if ($aw !== '') {
                    $meta[] = $aw;
                }
                if (!empty($d['class'])) {
                    $meta[] = $d['class'];
                }
            ?>
            <tr>
                <td class="num"><?php echo $i + 1; ?></td>
                <td>
                    <strong><?php echo acc_print_esc($name); ?></strong>
                    <?php if (!empty($d['icode'])): ?>
                    <span class="hint">(<?php echo acc_print_esc($d['icode']); ?>)</span>
                    <?php endif; ?>
                </td>
                <td class="num"><span class="sir <?php echo acc_print_sir_class($sir); ?>"><?php echo acc_print_esc($sir !== '' ? $sir : '?'); ?></span></td>
                <td class="num"><?php echo acc_print_esc(!empty($d['mic']) ? $d['mic'] : '—'); ?></td>
                <td><?php echo acc_print_esc($meta ? implode(' · ', $meta) : '—'); ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="box-title ok">ยาที่แนะนำ (ผล S)</div>
    <table class="drug-table">
        <thead>
            <tr>
                <th style="width:28px;">#</th>
                <th class="ok">ยา</th>
                <th class="ok" style="width:70px;">MIC</th>
                <th class="ok">AWaRe / กลุ่ม / ขนาดตามไต</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!$recs): ?>
            <tr><td colspan="4" class="hint">ไม่มียาที่แนะนำ</td></tr>
            <?php else: ?>
            <?php foreach ($recs as $i => $d): ?>
            <?php
                $name = trim((string)($d['drug'] ?? $d['drugName'] ?? ''));
                $meta = [];
                $aw = acc_print_aware_meta($d);
                if ($aw !== '') {
                    $meta[] = $aw;
                }
                if (!empty($d['class'])) {
                    $meta[] = $d['class'];
                }
                $renal = isset($d['renal']) && is_array($d['renal']) ? $d['renal'] : [];
                if (!empty($renal['msg'])) {
                    $meta[] = $renal['msg'];
                }
            ?>
            <tr>
                <td class="num"><?php echo $i + 1; ?></td>
                <td><strong><?php echo acc_print_esc($name); ?></strong></td>
                <td class="num"><?php echo acc_print_esc(!empty($d['mic']) ? $d['mic'] : '—'); ?></td>
                <td><?php echo acc_print_esc($meta ? implode(' · ', $meta) : '—'); ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <?php if (trim($note) !== ''): ?>
    <div class="box">
        <div class="box-title">หมายเหตุจากเภสัชกร</div>
        <div><?php echo nl2br(acc_print_esc($note)); ?></div>
    </div>
    <?php endif; ?>

    <div class="box doctor-box">
        <div class="box-title">ความเห็น / คำสั่งแพทย์</div>
        <div class="hint">
            ☐ เปลี่ยนยาตามที่แนะนำ &nbsp;&nbsp;
            ☐ ปรับขนาดยา &nbsp;&nbsp;
            ☐ จำเป็นต้องใช้ยาเดิมต่อ ……… วัน &nbsp;&nbsp;
            ☐ อื่นๆ ………………
        </div>
        <div class="doctor-lines">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <div class="sign-row">
        <div class="sign-box">
            <div class="sign-line">
                เภสัชกรผู้ Consult<br>
                (<?php echo acc_print_esc($pharm_name !== '' ? $pharm_name : '................................'); ?>)<br>
                วันที่ ....../....../..........
            </div>
        </div>
        <div class="sign-box">
            <div class="sign-line">
                แพทย์ผู้รับปรึกษา<br>
                (................................................)<br>
                วันที่ ....../....../..........
            </div>
        </div>
    </div>
</div>
<script>
window.addEventListener('load', function() {
    if (location.search.indexOf('autoprint=1') >= 0) {
        setTimeout(function() { window.print(); }, 250);
    }
});
</script>
</body>
</html>
