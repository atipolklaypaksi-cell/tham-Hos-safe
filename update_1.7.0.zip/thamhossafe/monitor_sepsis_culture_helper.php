<?php
/**
 * Monitor Sepsis by culture — ผลเพาะเลือดที่พบเชื้อ + ตรวจว่าได้ยาปฏิชีวนะแล้วหรือยัง
 */

function msc_is_blood_specimen($spec) {
    if (function_exists('amr_abg_specimen_class')) {
        return amr_abg_specimen_class($spec) === 'blood';
    }
    return (bool)preg_match('/blood|hemoculture|haemoculture|\bh\/c\b|bactec|เลือด|hemocul/i', (string)$spec);
}

function msc_is_no_growth($micro, $org = '') {
    $t = trim((string)$micro . ' ' . (string)$org);
    if ($t === '') {
        return true;
    }
    return (bool)preg_match('/no\s*growth|ไม่พบเชื้อ|no\s*organism/i', $t);
}

function msc_lookback_range($raw, $default_days = 7) {
    $s = strtolower(trim((string)$raw));
    $days = $default_days;
    if (preg_match('/^(\d+)\s*d$/', $s, $m) || preg_match('/^(\d+)$/', $s, $m)) {
        $days = (int)$m[1];
    }
    $days = max(1, min(30, $days));
    $end = date('Y-m-d');
    $start = date('Y-m-d', strtotime('-' . ($days - 1) . ' days'));
    return [$start, $end, $days];
}

function msc_inpatient_flag(array $row) {
    $dch = trim((string)($row['dchdate'] ?? ''));
    if ($dch !== '' && $dch !== '0000-00-00') {
        return false;
    }
    $an = preg_replace('/\D+/', '', (string)($row['an'] ?? ''));
    return $an !== '';
}

function msc_is_preliminary_organism($name) {
    $s = strtoupper(trim(preg_replace('/\s+/', ' ', (string)$name)));
    if ($s === '') {
        return true;
    }
    $s = trim(preg_replace('/[().\/,\-]+/', ' ', $s));
    $s = trim(preg_replace('/\s+/', ' ', $s));
    static $codes = [
        'NLF' => 1, 'LF' => 1, 'GPC' => 1, 'GNB' => 1, 'GNC' => 1, 'GPB' => 1,
        'GNCB' => 1, 'GNR' => 1, 'GPR' => 1, 'GNDC' => 1, 'GPDC' => 1,
        'YEAST' => 1, 'FUNGUS' => 1,
    ];
    if (isset($codes[$s])) {
        return true;
    }
    if (preg_match('/^GRAM\s+(POSITIVE|NEGATIVE)\b/', $s)) {
        return true;
    }
    if (preg_match('/\b(NON\s*LACTOSE|LACTOSE)\s+FERMENT/', $s)) {
        return true;
    }
    return false;
}

function msc_fetch_hosxp_org_map($hos, array $lab_keys) {
    if (!$hos || empty($lab_keys)) {
        return [];
    }
    if (!function_exists('amr_sens_organism_from_text')) {
        require_once __DIR__ . '/amr_sensitivity_helper.php';
    }
    if (!function_exists('amr_sens_sql_result_text')) {
        return [];
    }
    $ids = [];
    foreach ($lab_keys as $k) {
        $k = trim((string)$k);
        if (preg_match('/^\d{4,14}$/', $k)) {
            $ids[$k] = "'" . mysqli_real_escape_string($hos, $k) . "'";
        }
    }
    if (!$ids) {
        return [];
    }
    $map = [];
    $rtf = amr_sens_sql_result_text();
    foreach (array_chunk(array_values($ids), 120) as $part) {
        $sql = "SELECT lh.lab_order_number, $rtf AS rst
                FROM lab_head lh
                WHERE lh.lab_order_number IN (" . implode(',', $part) . ")";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $id = trim((string)($r['lab_order_number'] ?? ''));
            if ($id === '') {
                continue;
            }
            $text = function_exists('amr_sens_clean_rtf')
                ? amr_sens_clean_rtf($r['rst'] ?? '')
                : (string)($r['rst'] ?? '');
            $raw = amr_sens_organism_from_text($text);
            $label = function_exists('amr_sens_format_organism_label')
                ? amr_sens_format_organism_label($raw, '')
                : trim($raw);
            $ast = function_exists('amr_sens_parse_ast') ? amr_sens_parse_ast($text) : [];
            $map[$id] = [
                'org' => $label,
                'ast' => $ast,
            ];
        }
    }
    return $map;
}

function msc_is_final_organism($name) {
    $s = trim((string)$name);
    if ($s === '' || msc_is_preliminary_organism($s)) {
        return false;
    }
    if (preg_match('/will be followed|identification and susceptibility|positive culture|pending|awaiting/i', $s)) {
        return false;
    }
    return true;
}

function msc_prefer_final_organism($current, $from_hos) {
    $from_hos = trim((string)$from_hos);
    if (!msc_is_final_organism($from_hos)) {
        return $current;
    }
    $current = trim((string)$current);
    if ($current !== '' && !msc_is_preliminary_organism($current)) {
        return $current;
    }
    if (function_exists('amr_mlab_org_label')) {
        return amr_mlab_org_label($from_hos, $from_hos);
    }
    return $from_hos;
}

function msc_merge_ast(array $mlab, array $hos) {
    $mlab_ok = [];
    foreach ($mlab as $a) {
        $sir = strtoupper(substr(trim((string)($a['sir'] ?? '')), 0, 1));
        if (in_array($sir, ['S', 'I', 'R'], true) && trim((string)($a['drug'] ?? '')) !== '') {
            $mlab_ok[] = $a;
        }
    }
    if (!$hos) {
        return $mlab_ok;
    }
    if (!$mlab_ok) {
        return $hos;
    }
    $out = $mlab_ok;
    foreach ($hos as $h) {
        $drug = trim((string)($h['drug'] ?? $h['label'] ?? ''));
        if ($drug === '') {
            continue;
        }
        $hit = function_exists('amr_sens_sir_for_atb_name')
            ? amr_sens_sir_for_atb_name($out, $drug)
            : null;
        if (!empty($hit['sir'])) {
            continue;
        }
        $out[] = $h;
    }
    return $out;
}

function msc_hosxp_map_org($entry) {
    if (is_array($entry)) {
        return trim((string)($entry['org'] ?? ''));
    }
    return trim((string)$entry);
}

function msc_hosxp_map_ast($entry) {
    if (is_array($entry) && !empty($entry['ast']) && is_array($entry['ast'])) {
        return $entry['ast'];
    }
    return [];
}

function msc_fetch_blood_mlab($con, $hos, $start, $end) {
    if (!function_exists('amr_mlab_load_labs')) {
        require_once __DIR__ . '/amr_mlab_helper.php';
    }
    amr_mlab_ensure_tables($con);
    if (function_exists('amr_dict_prime')) {
        amr_dict_prime($con);
    }
    $loaded = amr_mlab_load_labs($con, $start, $end, ['light' => true]);
    if (($loaded['error'] ?? '') !== '') {
        return ['error' => $loaded['error'], 'rows' => []];
    }
    $labs = $loaded['labs'] ?? [];
    if (!$labs) {
        return ['error' => '', 'rows' => []];
    }
    $lab_keys = [];
    $hns = [];
    foreach ($labs as $lab) {
        $lab_keys[] = $lab['lab_key'] ?? '';
        if (trim((string)($lab['hn'] ?? '')) !== '') {
            $hns[$lab['hn']] = true;
        }
    }
    $overlay = $hos ? amr_mlab_hosxp_overlay($hos, $lab_keys, ['light' => true]) : [];
    $ans = [];
    foreach ($overlay as $ov) {
        if (!empty($ov['an'])) {
            $ans[] = $ov['an'];
        }
    }
    $byAn = $hos ? amr_mlab_fetch_ipt_by_an($hos, $ans) : [];
    $stays = $hos ? amr_mlab_fetch_ipt_stays($hos, array_keys($hns), $start, $end) : [];
    $patients = $hos ? amr_mlab_fetch_hosxp_patients($hos, array_keys($hns)) : [];
    $blood_keys = [];
    foreach ($labs as $lab) {
        if (msc_is_blood_specimen($lab['specimen'] ?? '')) {
            $k = trim((string)($lab['lab_key'] ?? ''));
            if ($k !== '') {
                $blood_keys[] = $k;
            }
        }
    }
    $org_map = $hos ? msc_fetch_hosxp_org_map($hos, $blood_keys) : [];
    $out = [];
    foreach ($labs as $lab) {
        $spec = trim((string)($lab['specimen'] ?? ''));
        if (!msc_is_blood_specimen($spec)) {
            continue;
        }
        $ord = trim((string)($lab['lab_key'] ?? ''));
        $hos_entry = ($ord !== '' && isset($org_map[$ord])) ? $org_map[$ord] : null;
        $lab['ast'] = msc_merge_ast($lab['ast'] ?? [], msc_hosxp_map_ast($hos_entry));
        $row = amr_mlab_pack_case($lab, false);
        if (!$row) {
            continue;
        }
        if ($ord !== '') {
            $row['microtype'] = msc_prefer_final_organism($row['microtype'] ?? '', msc_hosxp_map_org($hos_entry));
        }
        $ov = $overlay[$row['lab_order_number']] ?? null;
        if (is_array($ov)) {
            if (trim((string)($ov['an'] ?? '')) !== '') {
                $row['an'] = trim((string)$ov['an']);
                $row['_ipd'] = true;
            }
            if (trim((string)($ov['Typeinfect'] ?? '')) !== '') {
                $row['Typeinfect'] = trim((string)$ov['Typeinfect']);
            }
            $wname = trim((string)($ov['ward'] ?? ''));
            if ($wname !== '') {
                $row['ward'] = $wname;
            }
            $dc = trim((string)($ov['DCstatus'] ?? ''));
            if ($dc !== '') {
                $row['DCstatus'] = $dc;
            }
        }
        $row = amr_mlab_apply_hosxp_patient($row, $patients);
        if (!empty($row['an']) && !empty($byAn)) {
            $row = amr_mlab_apply_ipt_an($row, $byAn);
            $stay = $byAn[$row['an']] ?? [];
            $row['dchdate'] = substr((string)($stay['dchdate'] ?? ''), 0, 10);
            $row = amr_mlab_apply_hosxp_patient($row, $patients);
        }
        if (empty($row['_ipd']) && !empty($stays)) {
            $row = amr_mlab_apply_ipt_stay($row, $stays);
            $row = amr_mlab_apply_hosxp_patient($row, $patients);
        }
        if (trim((string)($row['dchdate'] ?? '')) === '') {
            $norm = function_exists('amr_mlab_hn_norm') ? amr_mlab_hn_norm($row['hn'] ?? '') : '';
            $an = trim((string)($row['an'] ?? ''));
            foreach (($stays[$norm] ?? []) as $s) {
                if ($an !== '' && trim((string)($s['an'] ?? '')) === $an) {
                    $row['dchdate'] = substr((string)($s['dchdate'] ?? ''), 0, 10);
                    break;
                }
            }
            if (trim((string)($row['dchdate'] ?? '')) === '' && $an !== '' && !empty($byAn[$an])) {
                $row['dchdate'] = substr((string)($byAn[$an]['dchdate'] ?? ''), 0, 10);
            }
        }
        if (msc_is_no_growth($row['microtype'] ?? '', $lab['organism'] ?? '')) {
            continue;
        }
        $row['inpatient'] = msc_inpatient_flag($row);
        $row['_ast'] = $lab['ast'] ?? [];
        unset($row['_ipd'], $row['_opd_ward']);
        $out[] = $row;
    }
    usort($out, function ($a, $b) {
        return strcmp((string)($b['reportdatetime'] ?? ''), (string)($a['reportdatetime'] ?? ''));
    });
    return ['error' => '', 'rows' => $out];
}

function msc_fetch_blood_hosxp($hos, $start, $end) {
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $microtype_sql = function_exists('amr_sql_microtype_case') ? amr_sql_microtype_case('lh.result_rtf', $hos) : "''";
    $result_sql = function_exists('amr_sql_result_case') ? amr_sql_result_case('lh.result_rtf', $hos) : "''";
    $specimen_sql = function_exists('amr_sql_specimen_case') ? amr_sql_specimen_case('lh.result_rtf', $hos) : "''";
    $rst_sql = function_exists('amr_sens_sql_result_text') ? amr_sens_sql_result_text() : "''";
    $ptname = amr_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))");
    $ward = amr_sql_utf8("IFNULL(w.name,'')");
    $dc = amr_sql_utf8("IFNULL(ds.name,'')");
    $sql = "
        SELECT
            MAX($ward) AS ward,
            MAX(IF((lh.order_date - i.regdate) > 2, 'NI', 'CI')) AS Typeinfect,
            MAX(CONCAT(lh.order_date, ' ', IFNULL(lh.order_time, ''))) AS ordertime,
            MAX(CONCAT(IFNULL(lh.report_date, ''), ' ', IFNULL(lh.report_time, ''))) AS reportdatetime,
            MAX(IFNULL(lh.order_time, '')) AS order_time,
            MAX(IFNULL(lh.report_date, '')) AS report_date,
            MAX(IFNULL(lh.report_time, '')) AS report_time,
            MAX(COALESCE(NULLIF(i.hn, ''), lh.hn)) AS hn,
            MAX(COALESCE(i.an, lh.vn)) AS an,
            MAX($ptname) AS ptname,
            MAX(IFNULL(ia.bedno, '')) AS bedno,
            lh.lab_order_number,
            MAX(lh.order_date) AS order_date,
            MAX($microtype_sql) AS microtype,
            MAX($result_sql) AS result,
            MAX($specimen_sql) AS Specimen,
            MAX($rst_sql) AS result_text,
            MAX($dc) AS DCstatus,
            MAX(IFNULL(i.dchdate, '')) AS dchdate
        FROM lab_head lh
        LEFT JOIN ipt i ON i.an = lh.vn
        LEFT JOIN iptadm ia ON ia.an = i.an
        LEFT JOIN patient pt ON pt.hn = COALESCE(NULLIF(i.hn, ''), lh.hn)
        LEFT JOIN ward w ON w.ward = i.ward
        LEFT JOIN dchstts ds ON ds.dchstts = i.dchstts
        WHERE lh.order_date BETWEEN '$start_esc' AND '$end_esc'
          AND lh.result_rtf IS NOT NULL
          AND TRIM(lh.result_rtf) <> ''
          AND (lh.result_rtf LIKE '%MIC%' OR lh.result_rtf LIKE '%SIR%' OR lh.result_rtf LIKE '%APPROVED%' OR lh.result_rtf LIKE '%Culture%')
          AND (lh.result_rtf LIKE '%Blood-Hemoculture%' OR lh.result_rtf LIKE '%Hemoculture%'
               OR lh.result_rtf LIKE '%SPECIMEN: Blood%' OR lh.result_rtf LIKE '%Hemouculture%')
        GROUP BY lh.lab_order_number
        ORDER BY lh.report_date DESC, lh.report_time DESC
        LIMIT 800
    ";
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return ['error' => mysqli_error($hos), 'rows' => []];
    }
    $out = [];
    while ($r = mysqli_fetch_assoc($q)) {
        if (!msc_is_blood_specimen($r['Specimen'] ?? '')) {
            continue;
        }
        if (msc_is_no_growth($r['microtype'] ?? '')) {
            continue;
        }
        $r['inpatient'] = msc_inpatient_flag($r);
        $text = function_exists('amr_sens_clean_rtf')
            ? amr_sens_clean_rtf($r['result_text'] ?? '')
            : (string)($r['result_text'] ?? '');
        $r['_ast'] = function_exists('amr_sens_parse_ast') ? amr_sens_parse_ast($text) : [];
        unset($r['result_text']);
        $out[] = $r;
    }
    return ['error' => '', 'rows' => $out];
}

function msc_sql_medplan_active($alias = 'mp') {
    return "($alias.offdate IS NULL
        OR $alias.offdate = '0000-00-00'
        OR $alias.offdate = '0000-00-00 00:00:00'
        OR DATE($alias.offdate) >= CURDATE())";
}

function msc_sql_tmt_join() {
    return function_exists('hosxp_sql_tmt_join') ? (' ' . hosxp_sql_tmt_join('d', 'tm')) : '';
}

/** ชื่อแสดงผล = TMT active_ingredient+strength ถ้ามี ไม่งั้นชื่อใน drugitems */
function msc_sql_drug_select() {
    $local = amr_sql_utf8("TRIM(CONCAT(IFNULL(NULLIF(d.name,''), IFNULL(d.generic_name,'')), ' ', IFNULL(d.strength,'')))");
    $ing = amr_sql_utf8("IFNULL(tm.active_ingredient,'')");
    $gen = amr_sql_utf8("IFNULL(d.generic_name,'')");
    $disp = function_exists('hosxp_sql_tmt_drug_name')
        ? hosxp_sql_tmt_drug_name('d', 'tm')
        : $local;
    return "MAX($disp) AS drugName,
            MAX($ing) AS tmt_ingredient,
            MAX($local) AS name_local,
            MAX($gen) AS generic_name";
}

function msc_pack_atb_row(array $r, array $extra = []) {
    return array_merge([
        'icode' => $r['icode'] ?? '',
        'drugName' => trim((string)($r['drugName'] ?? '')),
        'tmt_ingredient' => trim((string)($r['tmt_ingredient'] ?? '')),
        'name_local' => trim((string)($r['name_local'] ?? '')),
        'generic_name' => trim((string)($r['generic_name'] ?? '')),
    ], $extra);
}

function msc_group_current_atb($hos, $con, array $ans) {
    $map = [];
    if (!$hos || !$ans) {
        return $map;
    }
    $atb_flag = function_exists('amr_sens_atb_icode_sql')
        ? amr_sens_atb_icode_sql($hos, $con, 'd')
        : "UPPER(TRIM(IFNULL(d.antibiotic, ''))) = 'Y'";
    $names = msc_sql_drug_select();
    $tmt_join = msc_sql_tmt_join();
    $today = date('Y-m-d');
    $active = msc_sql_medplan_active('mp');
    $chunks = array_chunk(array_values(array_unique($ans)), 80);
    foreach ($chunks as $part) {
        $in = [];
        foreach ($part as $an) {
            $an = preg_replace('/\D+/', '', (string)$an);
            if ($an !== '') {
                $in[] = "'" . mysqli_real_escape_string($hos, $an) . "'";
            }
        }
        if (!$in) {
            continue;
        }
        $in_sql = implode(',', $in);
        $sql = "SELECT o.an, o.icode, $names,
                       DATE_FORMAT(MAX(o.rxdate), '%Y-%m-%d') AS rxdate
                FROM opitemrece o
                INNER JOIN drugitems d ON d.icode = o.icode AND $atb_flag
                $tmt_join
                WHERE o.an IN ($in_sql)
                  AND o.rxdate = '$today'
                  AND o.qty > 0
                GROUP BY o.an, o.icode";
        $q = @mysqli_query($hos, $sql);
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $an = preg_replace('/\D+/', '', (string)($r['an'] ?? ''));
                if ($an === '') {
                    continue;
                }
                $map[$an][] = msc_pack_atb_row($r, [
                    'rxdate' => $r['rxdate'] ?? $today,
                    'source' => 'dispense',
                ]);
            }
        }
        $sql2 = "SELECT mp.an, mp.icode, $names,
                        DATE_FORMAT(MAX(mp.orderdate), '%Y-%m-%d') AS orderdate
                 FROM medplan_ipd mp
                 INNER JOIN drugitems d ON d.icode = mp.icode AND $atb_flag
                 $tmt_join
                 WHERE mp.an IN ($in_sql)
                   AND mp.qty > 0
                   AND $active
                 GROUP BY mp.an, mp.icode";
        $q2 = @mysqli_query($hos, $sql2);
        if (!$q2) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q2)) {
            $an = preg_replace('/\D+/', '', (string)($r['an'] ?? ''));
            $ic = trim((string)($r['icode'] ?? ''));
            if ($an === '' || $ic === '') {
                continue;
            }
            $dup = false;
            foreach ($map[$an] ?? [] as $ex) {
                if (($ex['icode'] ?? '') === $ic) {
                    $dup = true;
                    break;
                }
            }
            if ($dup) {
                continue;
            }
            $map[$an][] = msc_pack_atb_row($r, [
                'orderdate' => $r['orderdate'] ?? '',
                'source' => 'medplan',
            ]);
        }
    }
    return $map;
}

function msc_fetch_atb_history($hos, $con, array $ans, $start) {
    $map = [];
    if (!$hos || !$ans) {
        return $map;
    }
    $atb_flag = function_exists('amr_sens_atb_icode_sql')
        ? amr_sens_atb_icode_sql($hos, $con, 'd')
        : "UPPER(TRIM(IFNULL(d.antibiotic, ''))) = 'Y'";
    $drug = amr_sql_utf8("TRIM(CONCAT(IFNULL(NULLIF(d.name,''), IFNULL(d.generic_name,'')), ' ', IFNULL(d.strength,'')))");
    $start_esc = mysqli_real_escape_string($hos, date('Y-m-d', strtotime($start . ' -2 days')));
    $chunks = array_chunk(array_values(array_unique($ans)), 80);
    foreach ($chunks as $part) {
        $in = [];
        foreach ($part as $an) {
            $an = preg_replace('/\D+/', '', (string)$an);
            if ($an !== '') {
                $in[] = "'" . mysqli_real_escape_string($hos, $an) . "'";
            }
        }
        if (!$in) {
            continue;
        }
        $sql = "SELECT o.an, DATE_FORMAT(MIN(o.rxdate), '%Y-%m-%d') AS first_rx,
                       DATE_FORMAT(MAX(o.rxdate), '%Y-%m-%d') AS last_rx,
                       COUNT(DISTINCT o.icode) AS drug_n
                FROM opitemrece o
                INNER JOIN drugitems d ON d.icode = o.icode AND $atb_flag
                WHERE o.an IN (" . implode(',', $in) . ")
                  AND o.qty > 0
                  AND o.rxdate >= '$start_esc'
                GROUP BY o.an";
        $q = @mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $an = preg_replace('/\D+/', '', (string)($r['an'] ?? ''));
            if ($an !== '') {
                $map[$an] = $r;
            }
        }
    }
    return $map;
}

function msc_fetch_hn_atb_today($hos, $con, array $hns) {
    $map = [];
    if (!$hos || !$hns) {
        return $map;
    }
    $atb_flag = function_exists('amr_sens_atb_icode_sql')
        ? amr_sens_atb_icode_sql($hos, $con, 'd')
        : "UPPER(TRIM(IFNULL(d.antibiotic, ''))) = 'Y'";
    $names = msc_sql_drug_select();
    $tmt_join = msc_sql_tmt_join();
    $today = date('Y-m-d');
    $keys = [];
    foreach ($hns as $hn) {
        if (function_exists('amr_mlab_hn_keys')) {
            foreach (amr_mlab_hn_keys($hn) as $v) {
                $keys[$v] = true;
            }
        } else {
            $d = preg_replace('/\D+/', '', (string)$hn);
            if ($d !== '') {
                $keys[$d] = true;
            }
        }
    }
    $list = array_keys($keys);
    for ($i = 0; $i < count($list); $i += 80) {
        $part = array_slice($list, $i, 80);
        $in = [];
        foreach ($part as $hn) {
            $in[] = "'" . mysqli_real_escape_string($hos, $hn) . "'";
        }
        if (!$in) {
            continue;
        }
        $sql = "SELECT o.hn, o.icode, $names
                FROM opitemrece o
                INNER JOIN drugitems d ON d.icode = o.icode AND $atb_flag
                $tmt_join
                WHERE o.hn IN (" . implode(',', $in) . ")
                  AND o.rxdate = '$today'
                  AND o.qty > 0
                GROUP BY o.hn, o.icode";
        $q = @mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $norm = function_exists('amr_mlab_hn_norm')
                ? amr_mlab_hn_norm($r['hn'] ?? '')
                : ltrim(preg_replace('/\D+/', '', (string)($r['hn'] ?? '')), '0');
            if ($norm === '') {
                continue;
            }
            if (!isset($map[$norm])) {
                $map[$norm] = [];
            }
            $map[$norm][] = msc_pack_atb_row($r);
        }
    }
    return $map;
}

function msc_gram_cover_group_keys() {
    return ['gpc_cluster', 'gpc_chain', 'enterococcus', 'gpb', 'gnb', 'gnc', 'yeast'];
}

function msc_gram_cover_groups() {
    return [
        'gpc_cluster' => 'GPC cluster (Staph)',
        'gpc_chain' => 'GPC คู่/สาย (Strep)',
        'enterococcus' => 'Enterococcus',
        'gpb' => 'GPB (Gram + bacilli)',
        'gnb' => 'GNB (Gram − bacilli)',
        'gnc' => 'GNC (Gram − cocci)',
        'yeast' => 'Yeast / Fungus',
    ];
}

function msc_gram_cover_pack_flags($name, $aliases, array $flags, $sort = 0) {
    $keys = msc_gram_cover_group_keys();
    $row = [
        'id' => 0,
        'drug_name' => $name,
        'aliases' => $aliases,
        'sort_order' => $sort,
        'is_active' => 1,
    ];
    foreach ($keys as $i => $k) {
        $row['cover_' . $k] = !empty($flags[$i]) ? 1 : 0;
    }
    return $row;
}

function msc_gram_cover_defaults() {
    /* Sanford / IDSA empiric for bacteremia — Enterococcus แยกจาก Strep เพราะดื้อ cephalosporin โดยกำเนิด */
    $rows = [
        ['Vancomycin', 'VANCO,VANCOMYCIN', [1, 1, 1, 1, 0, 0, 0]],
        ['Teicoplanin', 'TARGOCID,TEICO', [1, 1, 1, 1, 0, 0, 0]],
        ['Linezolid', 'ZYVOX', [1, 1, 1, 1, 0, 0, 0]],
        ['Daptomycin', 'CUBICIN', [1, 1, 1, 0, 0, 0, 0]],
        ['Cloxacillin', 'CLOXA,OXACILLIN,FLUCLOXACILLIN', [1, 0, 0, 0, 0, 0, 0]],
        ['Cefazolin', 'KEFZOL,CEFAZOLIN', [1, 0, 0, 0, 0, 0, 0]],
        ['Ampicillin', 'AMPICILLIN', [0, 1, 1, 1, 0, 0, 0]],
        ['Amoxicillin', 'AMOXICILLIN', [0, 1, 1, 0, 0, 0, 0]],
        ['Penicillin', 'PEN G,BENZYLPENICILLIN', [0, 1, 1, 1, 0, 1, 0]],
        ['Ceftriaxone', 'CEF-3,ROCEPHIN,CEFTRIAXONE', [0, 1, 0, 0, 1, 1, 0]],
        ['Cefotaxime', 'CEFOTAXIME', [0, 1, 0, 0, 1, 1, 0]],
        ['Ceftazidime', 'FORTUM,CEFTAZIDIME', [0, 0, 0, 0, 1, 0, 0]],
        ['Cefepime', 'MAXIPIME,CEFEPIME', [0, 0, 0, 0, 1, 0, 0]],
        ['Piperacillin/Tazobactam', 'TAZOCIN,PIPERACILLIN + TAZOBACTAM', [0, 1, 0, 1, 1, 0, 0]],
        ['Cefoperazone/Sulbactam', 'SULPERAZON,CEFOPERAZONE + SULBACTAM', [0, 0, 0, 0, 1, 0, 0]],
        ['Ampicillin/Sulbactam', 'UNASYN,AMPICILLIN + SULBACTAM', [0, 1, 1, 1, 1, 0, 0]],
        ['Amoxicillin/Clavulanate', 'AUGMENTIN,AMOXICILLIN + CLAVULANIC ACID', [0, 1, 1, 0, 1, 0, 0]],
        ['Meropenem', 'MERONEM,MEROPENEM', [0, 1, 0, 1, 1, 0, 0]],
        ['Imipenem', 'TIENAM,IMIPENEM', [0, 1, 0, 1, 1, 0, 0]],
        ['Ertapenem', 'INVANZ,ERTAPENEM', [0, 1, 0, 0, 1, 0, 0]],
        ['Doripenem', 'DORIBAX', [0, 0, 0, 0, 1, 0, 0]],
        ['Amikacin', 'AMIKACIN', [0, 0, 0, 0, 1, 0, 0]],
        ['Gentamicin', 'GENTAMICIN', [0, 0, 0, 0, 1, 0, 0]],
        ['Ciprofloxacin', 'CIPRO,CIPROFLOXACIN', [0, 0, 0, 0, 1, 1, 0]],
        ['Levofloxacin', 'CRAVIT,LEVO,LEVOFLOXACIN', [0, 0, 0, 0, 1, 0, 0]],
        ['Aztreonam', 'AZACTAM', [0, 0, 0, 0, 1, 0, 0]],
        ['Colistin', 'COLISTIMETHATE,POLYMYXIN', [0, 0, 0, 0, 1, 0, 0]],
        ['Ceftazidime/Avibactam', 'ZAVICEFTA,CEFTAZIDIME + AVIBACTAM', [0, 0, 0, 0, 1, 0, 0]],
        ['Fluconazole', 'DIFLUCAN', [0, 0, 0, 0, 0, 0, 1]],
        ['Caspofungin', 'CANCIDAS', [0, 0, 0, 0, 0, 0, 1]],
        ['Micafungin', 'MYCAMINE', [0, 0, 0, 0, 0, 0, 1]],
        ['Amphotericin B', 'AMBISOME,FUNGIZONE,AMPHOTERICIN', [0, 0, 0, 0, 0, 0, 1]],
    ];
    $out = [];
    $i = 10;
    foreach ($rows as $r) {
        $out[] = msc_gram_cover_pack_flags($r[0], $r[1], $r[2], $i);
        $i += 10;
    }
    return $out;
}

function msc_gram_cover_ensure($con) {
    if (!$con) {
        return false;
    }
    $ok = @mysqli_query($con, "CREATE TABLE IF NOT EXISTS amr_gram_atb_cover (
        id INT AUTO_INCREMENT PRIMARY KEY,
        drug_name VARCHAR(120) NOT NULL,
        aliases VARCHAR(255) NOT NULL DEFAULT '',
        cover_gpc_cluster TINYINT(1) NOT NULL DEFAULT 0,
        cover_gpc_chain TINYINT(1) NOT NULL DEFAULT 0,
        cover_enterococcus TINYINT(1) NOT NULL DEFAULT 0,
        cover_gpb TINYINT(1) NOT NULL DEFAULT 0,
        cover_gnb TINYINT(1) NOT NULL DEFAULT 0,
        cover_gnc TINYINT(1) NOT NULL DEFAULT 0,
        cover_yeast TINYINT(1) NOT NULL DEFAULT 0,
        sort_order INT NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        UNIQUE KEY uq_gram_atb_drug (drug_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    if (!$ok) {
        return false;
    }
    $chk = @mysqli_query($con, "SHOW COLUMNS FROM amr_gram_atb_cover LIKE 'cover_enterococcus'");
    if ($chk && mysqli_num_rows($chk) === 0) {
        @mysqli_query($con, "ALTER TABLE amr_gram_atb_cover
            ADD COLUMN cover_enterococcus TINYINT(1) NOT NULL DEFAULT 0 AFTER cover_gpc_chain");
        msc_gram_cover_backfill_enterococcus($con);
    }
    $q = @mysqli_query($con, "SELECT COUNT(*) AS c FROM amr_gram_atb_cover");
    $n = 0;
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $n = (int)($r['c'] ?? 0);
    }
    if ($n === 0) {
        msc_gram_cover_seed($con, msc_gram_cover_defaults());
    }
    return true;
}

function msc_gram_cover_backfill_enterococcus($con) {
    if (!$con) {
        return;
    }
    $q = @mysqli_query($con, "SELECT IFNULL(SUM(cover_enterococcus),0) AS s FROM amr_gram_atb_cover");
    $sum = 0;
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $sum = (int)($r['s'] ?? 0);
    }
    if ($sum > 0) {
        return;
    }
    foreach (msc_gram_cover_defaults() as $row) {
        $name = mysqli_real_escape_string($con, $row['drug_name']);
        $v = !empty($row['cover_enterococcus']) ? 1 : 0;
        @mysqli_query($con, "UPDATE amr_gram_atb_cover SET cover_enterococcus = $v WHERE drug_name = '$name'");
    }
}

function msc_gram_cover_seed($con, array $rows) {
    if (!$con) {
        return false;
    }
    $keys = msc_gram_cover_group_keys();
    $cols = ['drug_name', 'aliases'];
    foreach ($keys as $k) {
        $cols[] = 'cover_' . $k;
    }
    $cols[] = 'sort_order';
    $cols[] = 'is_active';
    $col_sql = implode(', ', $cols);
    $upd = [];
    foreach ($cols as $c) {
        if ($c === 'drug_name') {
            continue;
        }
        $upd[] = "$c = VALUES($c)";
    }
    $upd_sql = implode(', ', $upd);
    foreach ($rows as $row) {
        $name = trim((string)($row['drug_name'] ?? ''));
        if ($name === '') {
            continue;
        }
        $vals = [];
        $vals[] = "'" . mysqli_real_escape_string($con, $name) . "'";
        $vals[] = "'" . mysqli_real_escape_string($con, trim((string)($row['aliases'] ?? ''))) . "'";
        foreach ($keys as $k) {
            $vals[] = !empty($row['cover_' . $k]) ? '1' : '0';
        }
        $vals[] = (string)((int)($row['sort_order'] ?? 0));
        $vals[] = isset($row['is_active']) ? (!empty($row['is_active']) ? '1' : '0') : '1';
        @mysqli_query($con, "INSERT INTO amr_gram_atb_cover ($col_sql)
            VALUES (" . implode(', ', $vals) . ")
            ON DUPLICATE KEY UPDATE $upd_sql");
    }
    return true;
}

function msc_gram_cover_list($con, $active_only = false) {
    if (!msc_gram_cover_ensure($con)) {
        return msc_gram_cover_defaults();
    }
    $where = $active_only ? 'WHERE is_active = 1' : '';
    $q = mysqli_query($con, "SELECT * FROM amr_gram_atb_cover $where ORDER BY sort_order ASC, drug_name ASC");
    $out = [];
    $keys = msc_gram_cover_group_keys();
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $item = [
                'id' => (int)($r['id'] ?? 0),
                'drug_name' => $r['drug_name'] ?? '',
                'aliases' => $r['aliases'] ?? '',
                'sort_order' => (int)($r['sort_order'] ?? 0),
                'is_active' => (int)($r['is_active'] ?? 1),
            ];
            foreach ($keys as $k) {
                $item['cover_' . $k] = (int)($r['cover_' . $k] ?? 0);
            }
            $out[] = $item;
        }
    }
    return $out;
}

function msc_gram_cover_save($con, array $rows) {
    if (!msc_gram_cover_ensure($con)) {
        return ['error' => 'สร้างตารางตั้งค่าไม่ได้', 'rows' => []];
    }
    @mysqli_query($con, 'DELETE FROM amr_gram_atb_cover');
    $clean = [];
    $keys = msc_gram_cover_group_keys();
    $i = 10;
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $name = trim((string)($row['drug_name'] ?? ''));
        if ($name === '') {
            continue;
        }
        $item = [
            'drug_name' => $name,
            'aliases' => trim((string)($row['aliases'] ?? '')),
            'sort_order' => isset($row['sort_order']) ? (int)$row['sort_order'] : $i,
            'is_active' => isset($row['is_active']) ? (!empty($row['is_active']) ? 1 : 0) : 1,
        ];
        foreach ($keys as $k) {
            $item['cover_' . $k] = !empty($row['cover_' . $k]) ? 1 : 0;
        }
        $clean[] = $item;
        $i += 10;
    }
    msc_gram_cover_seed($con, $clean);
    return ['error' => '', 'rows' => msc_gram_cover_list($con, false)];
}

function msc_gram_cover_reset($con) {
    if (!msc_gram_cover_ensure($con)) {
        return ['error' => 'สร้างตารางตั้งค่าไม่ได้', 'rows' => []];
    }
    @mysqli_query($con, 'DELETE FROM amr_gram_atb_cover');
    msc_gram_cover_seed($con, msc_gram_cover_defaults());
    return ['error' => '', 'rows' => msc_gram_cover_list($con, false)];
}

function msc_gram_group($organism) {
    $s = strtoupper(trim(preg_replace('/\s+/', ' ', (string)$organism)));
    $s = trim(preg_replace('/[().\/,\-]+/', ' ', $s));
    $s = trim(preg_replace('/\s+/', ' ', $s));
    if ($s === '') {
        return '';
    }
    if (preg_match('/\b(YEAST|FUNGUS|CANDIDA|CRYPTOCOCCUS|MALASSEZIA)\b/', $s)) {
        return 'yeast';
    }
    if (preg_match('/ENTEROCOCC|FAECALIS|FAECIUM/', $s)) {
        return 'enterococcus';
    }
    if (preg_match('/STAPHYLOCOCC|\bSTAPH\b|S AUREUS|S HAEMOLYTIC|S HOMINIS|S EPIDERMID|S CAPITIS|S LUGDUNENS|COAGULASE\s*NEG|\bCONS\b/', $s)) {
        return 'gpc_cluster';
    }
    if (preg_match('/STREPTOC|PNEUMOCOCC|VIRIDANS|S PNEUMONIAE|S AGALACT|S PYOGEN|S BOVIS|S GALLOLYT|GROUP [ABF] STREP/', $s)) {
        return 'gpc_chain';
    }
    if ($s === 'GNC' || $s === 'GNDC'
        || preg_match('/GRAM\s+NEGATIVE\s+(COCCI|DIPLOCOCCI)/', $s)
        || preg_match('/NEISSERIA|MORAXELLA|M CATARRHALIS/', $s)
    ) {
        return 'gnc';
    }
    if ($s === 'GPB' || $s === 'GPR'
        || preg_match('/GRAM\s+POSITIVE\s+(BACILL|ROD)/', $s)
        || preg_match('/BACILLUS|CORYNEBACT|DIPHTHEROID|LISTERIA|CLOSTRIDIUM|CUTIBACTERIUM|PROPIONIBACT/', $s)
    ) {
        return 'gpb';
    }
    if ($s === 'GNB' || $s === 'GNR' || $s === 'GNCB' || $s === 'NLF' || $s === 'LF'
        || preg_match('/GRAM\s+NEGATIVE\s+(BACILL|ROD)/', $s)
        || preg_match('/(NON\s*LACTOSE|LACTOSE)\s+FERMENT/', $s)
        || preg_match('/ESCHERICHIA|\bE COLI\b|KLEBSIELLA|K PNEUM|PSEUDOMONAS|ACINETOBACTER|PROTEUS|ENTEROBACTER|SERRATIA|CITROBACTER|SALMONELLA|MORGANELLA|STENOTROPHOMONAS|AEROMONAS|HAEMOPHILUS|BURKHOLDERIA|PROVIDENCIA|P AERUGINOSA|A BAUMANNII/', $s)
    ) {
        return 'gnb';
    }
    if ($s === 'GPC' || $s === 'GPDC' || preg_match('/GRAM\s+POSITIVE\s+COCCI/', $s)) {
        if (preg_match('/CLUSTER/', $s)) {
            return 'gpc_cluster';
        }
        if (preg_match('/PAIR|CHAIN|SINGLE/', $s)) {
            return 'gpc_chain';
        }
        return 'gpc_cluster';
    }
    if (preg_match('/GRAM\s+NEGATIVE/', $s)) {
        return 'gnb';
    }
    if (preg_match('/GRAM\s+POSITIVE/', $s)) {
        return 'gpc_cluster';
    }
    return '';
}

function msc_drug_match_texts(array $d) {
    $out = [];
    foreach (['tmt_ingredient', 'drugName', 'generic_name', 'name_local'] as $k) {
        $v = trim((string)($d[$k] ?? ''));
        if ($v !== '') {
            $out[$v] = $v;
        }
    }
    return array_values($out);
}

function msc_cover_row_terms(array $row) {
    $parts = [$row['drug_name'] ?? ''];
    foreach (preg_split('/[,;]+/', (string)($row['aliases'] ?? '')) as $a) {
        $parts[] = $a;
    }
    $out = [];
    foreach ($parts as $t) {
        $t = trim((string)$t);
        if ($t !== '') {
            $out[] = $t;
        }
    }
    return $out;
}

function msc_norm_token($s) {
    return function_exists('amr_sens_ast_norm')
        ? amr_sens_ast_norm($s)
        : strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)$s));
}

function msc_is_combo_name($raw, $norm = '') {
    if (preg_match('/\+|\/|&/', (string)$raw) || preg_match('/\band\b/i', (string)$raw)) {
        return true;
    }
    $n = $norm !== '' ? $norm : msc_norm_token($raw);
    return (bool)preg_match('/CLAVULAN|TAZOBACTAM|SULBACTAM|AVIBACTAM|VABORBACTAM|RELEBACTAM/', $n);
}

function msc_drug_matches_cover_row($drug_name, array $row) {
    return msc_cover_row_score($drug_name, $row) > 0;
}

/** คะแนนสูงกว่า = ตรงกว่า (ยาผสมชนะยาเดี่ยวที่ชื่อซ้อนกัน) */
function msc_cover_row_score($drug_name, array $row) {
    $best = 0;
    $b = msc_norm_token($drug_name);
    if (strlen($b) < 4) {
        return 0;
    }
    $combo_b = msc_is_combo_name($drug_name, $b);
    foreach (msc_cover_row_terms($row) as $t) {
        $hit = false;
        if (function_exists('amr_sens_ast_matches_atb') && amr_sens_ast_matches_atb($t, $drug_name)) {
            $hit = true;
        }
        $a = msc_norm_token($t);
        if (!$hit && strlen($a) >= 4 && (strpos($b, $a) !== false || strpos($a, $b) !== false)) {
            $hit = true;
        }
        if (!$hit) {
            continue;
        }
        $score = min(strlen($a), strlen($b));
        $combo_a = msc_is_combo_name($t, $a);
        if ($combo_a && $combo_b) {
            $score += 40;
        } elseif ($combo_a !== $combo_b) {
            $score -= 40;
        }
        if ($score > $best) {
            $best = $score;
        }
    }
    return $best;
}

function msc_cover_match_score(array $d, array $row) {
    $best = 0;
    foreach (msc_drug_match_texts($d) as $name) {
        $n = msc_cover_row_score($name, $row);
        if ($n > $best) {
            $best = $n;
        }
    }
    return $best;
}

function msc_drug_matches_cover(array $d, array $row) {
    return msc_cover_match_score($d, $row) > 0;
}

function msc_best_cover_row(array $d, array $cover_rows, $col = '') {
    $best = null;
    $best_n = 0;
    foreach ($cover_rows as $row) {
        if (isset($row['is_active']) && (int)$row['is_active'] !== 1) {
            continue;
        }
        if ($col !== '' && empty($row[$col])) {
            continue;
        }
        $n = msc_cover_match_score($d, $row);
        if ($n > $best_n) {
            $best_n = $n;
            $best = $row;
        }
    }
    return $best;
}

function msc_gram_screen(array $drugs, $organism, array $cover_rows) {
    $group = msc_gram_group($organism);
    if ($group === '' || !$drugs || !$cover_rows) {
        return ['mode' => '', 'screen' => '', 'group' => $group, 'matched' => []];
    }
    $col = 'cover_' . $group;
    $matched = [];
    foreach ($drugs as $d) {
        $texts = msc_drug_match_texts($d);
        if (!$texts) {
            continue;
        }
        $row = msc_best_cover_row($d, $cover_rows, $col);
        if (!$row) {
            continue;
        }
        $label = trim((string)($d['tmt_ingredient'] ?? '')) !== ''
            ? $d['tmt_ingredient']
            : ($texts[0] ?? ($row['drug_name'] ?? ''));
        $matched[$label] = $row['drug_name'] ?? $label;
    }
    return [
        'mode' => 'gram',
        'screen' => $matched ? 'cover' : 'gap',
        'group' => $group,
        'matched' => array_values($matched),
        'suggest' => $matched ? [] : msc_suggest_for_group($group, $cover_rows, $drugs, 4),
    ];
}

function msc_suggest_priority($group) {
    $map = [
        'enterococcus' => ['Ampicillin', 'Vancomycin', 'Amoxicillin', 'Teicoplanin', 'Linezolid', 'Daptomycin', 'Ampicillin/Sulbactam'],
        'gpc_cluster' => ['Vancomycin', 'Cloxacillin', 'Cefazolin', 'Teicoplanin', 'Linezolid', 'Daptomycin'],
        'gpc_chain' => ['Ceftriaxone', 'Ampicillin', 'Penicillin', 'Vancomycin', 'Amoxicillin'],
        'gpb' => ['Vancomycin', 'Ampicillin', 'Penicillin', 'Meropenem'],
        'gnb' => ['Ceftriaxone', 'Piperacillin/Tazobactam', 'Ceftazidime', 'Cefepime', 'Meropenem', 'Amikacin'],
        'gnc' => ['Ceftriaxone', 'Cefotaxime', 'Penicillin'],
        'yeast' => ['Fluconazole', 'Caspofungin', 'Micafungin', 'Amphotericin B'],
    ];
    return $map[$group] ?? [];
}

function msc_drugs_already_include(array $drugs, $name) {
    $row = ['drug_name' => $name, 'aliases' => ''];
    foreach ($drugs as $d) {
        if (msc_cover_match_score($d, $row) > 0) {
            return true;
        }
    }
    return false;
}

function msc_suggest_for_group($group, array $cover_rows, array $drugs, $limit = 4) {
    $col = 'cover_' . $group;
    $by_name = [];
    foreach ($cover_rows as $row) {
        if (isset($row['is_active']) && (int)$row['is_active'] !== 1) {
            continue;
        }
        if (empty($row[$col])) {
            continue;
        }
        $name = trim((string)($row['drug_name'] ?? ''));
        if ($name === '' || msc_drugs_already_include($drugs, $name)) {
            continue;
        }
        $by_name[$name] = $row;
    }
    if (!$by_name) {
        return [];
    }
    $out = [];
    foreach (msc_suggest_priority($group) as $pref) {
        foreach ($by_name as $name => $row) {
            if (isset($out[$name])) {
                continue;
            }
            if (strcasecmp($name, $pref) === 0 || msc_cover_row_score($pref, $row) > 0) {
                $out[$name] = $name;
                if (count($out) >= $limit) {
                    return array_values($out);
                }
            }
        }
    }
    foreach ($by_name as $name => $_row) {
        if (!isset($out[$name])) {
            $out[$name] = $name;
        }
        if (count($out) >= $limit) {
            break;
        }
    }
    return array_values($out);
}

function msc_suggest_from_ast(array $ast, array $drugs, $limit = 4) {
    if (!$ast || !function_exists('amr_sens_sir_for_atb_name')) {
        return [];
    }
    $s = [];
    $i = [];
    foreach ($ast as $a) {
        $sir = strtoupper(substr(trim((string)($a['sir'] ?? '')), 0, 1));
        $drug = trim((string)($a['drug'] ?? $a['label'] ?? ''));
        if ($drug === '' || !in_array($sir, ['S', 'I'], true)) {
            continue;
        }
        if (msc_drugs_already_include($drugs, $drug)) {
            continue;
        }
        if ($sir === 'S') {
            $s[$drug] = $drug;
        } else {
            $i[$drug] = $drug;
        }
    }
    $out = array_values($s);
    if (count($out) < $limit) {
        $out = array_merge($out, array_values($i));
    }
    return array_slice($out, 0, $limit);
}

function msc_cover_sir(array $drugs, array $ast) {
    if (!$drugs || !$ast || !function_exists('amr_sens_sir_for_atb_name')) {
        return '';
    }
    $rank = ['R' => 3, 'I' => 2, 'S' => 1];
    $best = '';
    $best_n = 0;
    foreach ($drugs as $d) {
        foreach (msc_drug_match_texts($d) as $name) {
            $hit = amr_sens_sir_for_atb_name($ast, $name);
            $sir = strtoupper((string)($hit['sir'] ?? ''));
            $n = $rank[$sir] ?? 0;
            if ($n > $best_n) {
                $best_n = $n;
                $best = $sir;
            }
        }
    }
    return $best;
}

function msc_scan($con, $hos, $lookback = '7d') {
    list($start, $end, $days) = msc_lookback_range($lookback, 7);
    $use_mlab = function_exists('amr_mlab_using_direct') && amr_mlab_using_direct($con);
    $blood = msc_fetch_blood_mlab($con, $hos, $start, $end);
    if (($blood['error'] ?? '') !== '') {
        return $blood;
    }
    if (empty($blood['rows']) && $hos) {
        $blood = msc_fetch_blood_hosxp($hos, $start, $end);
        $use_mlab = false;
    }
    if (($blood['error'] ?? '') !== '') {
        return $blood;
    }
    $rows = $blood['rows'] ?? [];
    $ans = [];
    $hns_no_an = [];
    foreach ($rows as $r) {
        $an = preg_replace('/\D+/', '', (string)($r['an'] ?? ''));
        if ($an !== '') {
            $ans[$an] = $an;
        } elseif (trim((string)($r['hn'] ?? '')) !== '') {
            $hns_no_an[] = $r['hn'];
        }
    }
    $now_map = $hos ? msc_group_current_atb($hos, $con, array_values($ans)) : [];
    $hist_map = $hos ? msc_fetch_atb_history($hos, $con, array_values($ans), $start) : [];
    $hn_now = $hos ? msc_fetch_hn_atb_today($hos, $con, $hns_no_an) : [];
    $gram_rows = msc_gram_cover_list($con, true);

    $meta = [
        'blood_n' => 0,
        'none_n' => 0,
        'off_n' => 0,
        'now_n' => 0,
        'resistant_n' => 0,
        'ipd_n' => 0,
        'gap_n' => 0,
        'start_date' => $start,
        'end_date' => $end,
        'days' => $days,
        'source' => $use_mlab ? 'mlab' : 'hosxp',
    ];
    $out = [];
    foreach ($rows as $r) {
        $an = preg_replace('/\D+/', '', (string)($r['an'] ?? ''));
        $hn_norm = function_exists('amr_mlab_hn_norm')
            ? amr_mlab_hn_norm($r['hn'] ?? '')
            : ltrim(preg_replace('/\D+/', '', (string)($r['hn'] ?? '')), '0');
        $drugs = [];
        if ($an !== '' && !empty($now_map[$an])) {
            $drugs = $now_map[$an];
        } elseif ($an === '' && $hn_norm !== '' && !empty($hn_now[$hn_norm])) {
            $drugs = $hn_now[$hn_norm];
        }
        $hist = ($an !== '' && !empty($hist_map[$an])) ? $hist_map[$an] : [];
        $has_now = !empty($drugs);
        $has_hist = !empty($hist['first_rx']);
        if ($has_now) {
            $status = 'now';
        } elseif ($has_hist) {
            $status = 'off';
        } else {
            $status = 'none';
        }
        $names = [];
        foreach ($drugs as $d) {
            $n = trim((string)($d['drugName'] ?? ''));
            if ($n !== '') {
                $names[$n] = $n;
            }
        }
        $cover = msc_cover_sir($drugs, $r['_ast'] ?? []);
        $gram = ['mode' => '', 'screen' => '', 'group' => '', 'matched' => [], 'suggest' => []];
        $cover_mode = '';
        $suggest = [];
        if ($cover !== '') {
            $cover_mode = 'ast';
            if ($cover === 'R') {
                $suggest = msc_suggest_from_ast($r['_ast'] ?? [], $drugs, 4);
                if (!$suggest) {
                    $g = msc_gram_group($r['microtype'] ?? '');
                    $suggest = $g !== '' ? msc_suggest_for_group($g, $gram_rows, $drugs, 4) : [];
                }
            }
        } elseif ($has_now) {
            $gram = msc_gram_screen($drugs, $r['microtype'] ?? '', $gram_rows);
            if (($gram['mode'] ?? '') === 'gram') {
                $cover_mode = 'gram';
                $suggest = $gram['suggest'] ?? [];
            }
        }
        $ipd = !empty($r['inpatient']);
        $item = [
            'lab_order_number' => $r['lab_order_number'] ?? '',
            'hn' => $r['hn'] ?? '',
            'an' => $r['an'] ?? '',
            'ptname' => $r['ptname'] ?? '',
            'ward' => $r['ward'] ?? '',
            'bedno' => $r['bedno'] ?? '',
            'microtype' => $r['microtype'] ?? '',
            'result' => $r['result'] ?? '',
            'Specimen' => $r['Specimen'] ?? '',
            'Typeinfect' => $r['Typeinfect'] ?? '',
            'DCstatus' => $r['DCstatus'] ?? '',
            'dchdate' => $r['dchdate'] ?? '',
            'inpatient' => $ipd ? 1 : 0,
            'order_date' => substr((string)($r['order_date'] ?? ''), 0, 10),
            'order_time' => $r['order_time'] ?? '',
            'report_date' => substr((string)($r['report_date'] ?? ''), 0, 10),
            'report_time' => $r['report_time'] ?? '',
            'reportdatetime' => $r['reportdatetime'] ?? '',
            'ordertime' => $r['ordertime'] ?? '',
            'atb_status' => $status,
            'atb_now' => array_values($names),
            'atb_cover' => $cover,
            'cover_mode' => $cover_mode,
            'atb_screen' => $gram['screen'] ?? '',
            'gram_group' => $gram['group'] ?? '',
            'gram_matched' => $gram['matched'] ?? [],
            'atb_suggest' => $suggest,
            'atb_first_rx' => $hist['first_rx'] ?? '',
            'atb_last_rx' => $hist['last_rx'] ?? '',
        ];
        unset($r['_ast']);
        $meta['blood_n']++;
        if ($ipd) {
            $meta['ipd_n']++;
        }
        if ($status === 'none') {
            $meta['none_n']++;
        } elseif ($status === 'off') {
            $meta['off_n']++;
        } else {
            $meta['now_n']++;
        }
        if ($status !== 'now' && $ipd) {
            $meta['gap_n']++;
        }
        if (trim((string)$item['result']) !== '') {
            $meta['resistant_n']++;
        }
        $out[] = $item;
    }
    return ['error' => '', 'rows' => $out, 'meta' => $meta];
}
