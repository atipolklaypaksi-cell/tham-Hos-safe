<?php
/**
 * Smart Lab helpers — ใช้ร่วมกันระหว่างหน้าและ API
 */

require_once __DIR__ . '/hospital_ds_helper.php';
require_once __DIR__ . '/display_mask_helper.php';

function smart_lab_format_time($time) {
    $time = trim((string)$time);
    if ($time === '') {
        return '';
    }
    if (preg_match('/^(\d{1,2}):(\d{2})(?::\d{2})?$/', $time, $m)) {
        return sprintf('%02d:%02d', (int)$m[1], (int)$m[2]);
    }
    if (preg_match('/^\d{6}$/', $time)) {
        return substr($time, 0, 2) . ':' . substr($time, 2, 2);
    }
    if (preg_match('/^\d{5}$/', $time)) {
        return '0' . substr($time, 0, 1) . ':' . substr($time, 1, 2);
    }
    return $time;
}

function smart_lab_dt_label(array $row) {
    $date = trim((string)($row['report_date'] ?? ''));
    if ($date === '' || $date === '0000-00-00') {
        $date = trim((string)($row['order_date'] ?? ''));
    }
    $time = trim((string)($row['report_time'] ?? ''));
    if ($time === '') {
        $time = trim((string)($row['order_time'] ?? ''));
    }
    if ($date === '' || $date === '0000-00-00') {
        return '-';
    }
    $date_fmt = date('d/m/Y', strtotime($date));
    $time_fmt = smart_lab_format_time($time);
    return $time_fmt !== '' ? $date_fmt . ' ' . $time_fmt : $date_fmt;
}

function smart_lab_order_date_label(array $row) {
    $od = trim((string)($row['order_date'] ?? ''));
    if ($od === '' || $od === '0000-00-00') {
        return '-';
    }
    $tm = smart_lab_format_time($row['order_time'] ?? '');
    return date('d/m/Y', strtotime($od)) . ($tm !== '' ? ' (' . $tm . ' น.)' : '');
}

function smart_lab_json($data) {
    $flags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    } elseif (defined('JSON_PARTIAL_OUTPUT_ON_ERROR')) {
        $flags |= JSON_PARTIAL_OUTPUT_ON_ERROR;
    }
    $json = json_encode($data, $flags);
    if ($json === false) {
        return '{}';
    }
    return str_replace(['</', '<!--'], ['<\/', '<\!--'], $json);
}

/**
 * ดึงตัวเลขสำหรับกราฟแนวโน้ม จากผล Lab ที่อาจมีข้อความต่อท้าย
 * เช่น 53.03[Stage=3A] → 53.03, >100 → 100, 12.5 mg/dL → 12.5
 * ไม่ดึงเลขจาก annotation อย่าง Stage=3A
 *
 * @return float|null
 */
function smart_lab_parse_numeric($raw) {
    $s = trim((string)$raw);
    if ($s === '') {
        return null;
    }
    $s = str_replace([',', ' '], '', $s);
    // ตัวเลขนำหน้า (อาจมี < > =) แล้วตามด้วยข้อความอื่นได้
    if (preg_match('/^[<>=]*([-+]?\d+(?:\.\d+)?)/', $s, $m)) {
        return (float)$m[1];
    }
    // กรณีมีคำนำหน้าสั้น ๆ ก่อนตัวเลข เช่น eGFR:53.03
    if (preg_match('/^[A-Za-zก-๙:%\/().+-]*([-+]?\d+(?:\.\d+)?)/u', $s, $m)) {
        return (float)$m[1];
    }
    return null;
}

function smart_lab_prepare_item($con, array $item, $hospital_code) {
    $name = (string)($item['lab_items_name_ref'] ?? '');
    $masked = dm_should_mask_lab($con, $name, $hospital_code);
    return [
        'lab_items_code' => (string)($item['lab_items_code'] ?? ''),
        'lab_items_name_ref' => $name,
        'lab_order_result' => $masked
            ? dm_mask_message()
            : (string)($item['lab_order_result'] ?? '-'),
        'lab_items_normal_value' => $masked ? '' : (string)($item['lab_items_normal_value'] ?? ''),
        'tmlt_code' => $masked ? '' : trim((string)($item['tmlt_code'] ?? '')),
        'loinc_code' => trim((string)($item['loinc_code'] ?? '')),
        'is_masked' => $masked,
    ];
}

function smart_lab_pack_order_meta(array $row, $hospital_code, $hospital_name, $matched_hn = '') {
    $ord = trim((string)($row['lab_order_number'] ?? ''));
    $od = trim((string)($row['order_date'] ?? ''));
    if (function_exists('hds_norm_sql_date')) {
        $odn = hds_norm_sql_date($od);
        if ($odn !== '') {
            $od = $odn;
        }
    }
    $ot = trim((string)($row['order_time'] ?? ''));
    if (function_exists('hds_norm_sql_time')) {
        $otn = hds_norm_sql_time($ot);
        if ($otn !== '') {
            $ot = $otn;
        }
    }
    $form = trim((string)($row['form_name'] ?? ''));
    $hosp_short = preg_replace('/^รพ\./u', '', (string)$hospital_name);
    $meta = [
        'order_key' => $hospital_code . ':' . $ord,
        'lab_order_number' => $ord,
        'order_date' => $od,
        'order_time' => $ot,
        'date_show' => ($od !== '' && $od !== '0000-00-00') ? date('d/m/Y', strtotime($od)) : '-',
        'time_show' => smart_lab_format_time($ot),
        'date_label' => smart_lab_order_date_label(['order_date' => $od, 'order_time' => $ot]),
        'form_name' => $form,
        'hospital_code' => (string)$hospital_code,
        'hospital_name' => (string)$hospital_name,
        'hospital_short' => $hosp_short,
        'matched_hn' => (string)$matched_hn,
        'item_count' => 0,
    ];
    return $meta;
}

/** SQL ดึงผล Lab ทั้งใบ (head+items) ตาม HN — สำหรับเครือข่ายใช้ HEX */
function smart_lab_bundle_by_hn_sql($hn, $months, $limit_orders = 80, $hex_text = true) {
    $hn_esc = hds_sql_quote($hn);
    $date_sql = hds_date_filter_sql('h2.order_date', $months);
    $limit_orders = max(20, min(120, (int)$limit_orders));
    if ($hex_text) {
        $form = hds_sql_th("IFNULL(h.form_name,'')") . ' AS form_name';
        $name = hds_sql_th('o.lab_items_name_ref') . ' AS lab_items_name_ref';
        $result = hds_sql_th('o.lab_order_result') . ' AS lab_order_result';
        $normal = hds_sql_th('i.lab_items_normal_value') . ' AS lab_items_normal_value';
    } else {
        $form = "CAST(CONVERT(IFNULL(h.form_name,'') USING utf8) AS CHAR) AS form_name";
        $name = "CAST(CONVERT(IFNULL(o.lab_items_name_ref,'') USING utf8) AS CHAR) AS lab_items_name_ref";
        $result = "CAST(CONVERT(IFNULL(o.lab_order_result,'') USING utf8) AS CHAR) AS lab_order_result";
        $normal = "CAST(CONVERT(IFNULL(i.lab_items_normal_value,'') USING utf8) AS CHAR) AS lab_items_normal_value";
    }
    return "SELECT h.lab_order_number, h.order_date, h.order_time, h.hn AS matched_hn, $form,
                   o.lab_items_code, $name, $result, $normal, i.tmlt_code, i.loinc_code
            FROM lab_head h
            INNER JOIN (
                SELECT lab_order_number
                FROM lab_head h2
                WHERE h2.hn = $hn_esc
                  AND h2.confirm_report = 'Y'
                  $date_sql
                ORDER BY h2.order_date DESC, h2.order_time DESC
                LIMIT $limit_orders
            ) lim ON lim.lab_order_number = h.lab_order_number
            INNER JOIN lab_order o ON o.lab_order_number = h.lab_order_number
            LEFT JOIN lab_items i ON i.lab_items_code = o.lab_items_code
            ORDER BY h.order_date DESC, h.order_time DESC, o.lab_items_name_ref ASC";
}

function smart_lab_pack_bundle_rows(array $rows, $hospital_code, $hospital_name, $con, $hex_text = false) {
    $orders = [];
    $items_by_order = [];
    foreach ($rows as $r) {
        $ord = trim((string)($r['lab_order_number'] ?? ''));
        if ($ord === '') {
            continue;
        }
        $key = $hospital_code . ':' . $ord;
        if ($hex_text) {
            $r['form_name'] = hds_unhex_utf8($r['form_name'] ?? '');
            $r['lab_items_name_ref'] = hds_unhex_utf8($r['lab_items_name_ref'] ?? '');
            $r['lab_order_result'] = hds_unhex_utf8($r['lab_order_result'] ?? '');
            $r['lab_items_normal_value'] = hds_unhex_utf8($r['lab_items_normal_value'] ?? '');
        }
        if (!isset($orders[$key])) {
            $orders[$key] = smart_lab_pack_order_meta($r, $hospital_code, $hospital_name, trim((string)($r['matched_hn'] ?? '')));
            $items_by_order[$key] = [];
        }
        $code = trim((string)($r['lab_items_code'] ?? ''));
        $name = trim((string)($r['lab_items_name_ref'] ?? ''));
        if ($code === '' && $name === '') {
            continue;
        }
        $items_by_order[$key][] = smart_lab_prepare_item($con, $r, $hospital_code);
        $orders[$key]['item_count'] = count($items_by_order[$key]);
    }
    return [array_values($orders), $items_by_order];
}

/**
 * ดึง Lab ทั้งก้อนแบบ Smart Drug: orders + items_by_order ในครั้งเดียว
 */
function smart_lab_fetch_bundle($hos_con, $con, $hn, $months = 12, $include_network = true) {
    dm_ensure_tables($con);
    $t0 = microtime(true);
    $months = hds_lookback_months($months, 12);
    $local_name = hds_local_hospital_name();
    $hn_variants = hds_hn_variants($hn);
    $hn_sql = $hn_variants ? $hn_variants[0] : $hn;

    $patient = ['hn' => $hn_sql, 'fullname' => '', 'cid' => ''];
    $hn_esc = mysqli_real_escape_string($hos_con, $hn_sql);
    $q_pt = mysqli_query($hos_con, "SELECT CONCAT(pname, fname, ' ', lname) AS fullname, cid
                                    FROM patient WHERE hn = '$hn_esc' LIMIT 1");
    if ($q_pt && ($pt = mysqli_fetch_assoc($q_pt))) {
        $patient['fullname'] = (string)($pt['fullname'] ?? '');
        $patient['cid'] = preg_replace('/\D+/', '', (string)($pt['cid'] ?? ''));
    }

    $orders = [];
    $items_by_order = [];
    $local_ms = 0;
    $network_ms = 0;
    $sources = [];

    // ---- Local: 1 query ได้ทั้งหัวใบ + รายการ ----
    $t_local = microtime(true);
    $sql_local = smart_lab_bundle_by_hn_sql($hn_sql, $months, 80, false);
    // ลองทุก HN variant ถ้ายังไม่เจอ
    $local_rows = [];
    foreach ($hn_variants as $try_hn) {
        $sql_try = smart_lab_bundle_by_hn_sql($try_hn, $months, 80, false);
        $q = mysqli_query($hos_con, $sql_try);
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $local_rows[] = $r;
            }
        }
        if ($local_rows) {
            $patient['hn'] = $try_hn;
            break;
        }
    }
    list($local_orders, $local_items) = smart_lab_pack_bundle_rows($local_rows, 'local', $local_name, $con, false);
    foreach ($local_orders as $o) {
        $orders[] = $o;
    }
    foreach ($local_items as $k => $items) {
        $items_by_order[$k] = $items;
    }
    $local_ms = (int)round((microtime(true) - $t_local) * 1000);

    // ---- Network: parallel lookup + ดึง head+items ต่อรพ. ----
    if ($include_network) {
        $t_net = microtime(true);
        $net = smart_lab_fetch_network_bundle($con, $hn_variants, $patient['cid'], $months, 80);
        $network_ms = (int)round((microtime(true) - $t_net) * 1000);
        $sources = $net['sources'] ?? [];
        foreach ($net['orders'] ?? [] as $o) {
            $orders[] = $o;
        }
        foreach ($net['items_by_order'] ?? [] as $k => $items) {
            $items_by_order[$k] = $items;
        }
    }

    usort($orders, function ($a, $b) {
        $da = (string)($a['order_date'] ?? '');
        $db = (string)($b['order_date'] ?? '');
        if ($da !== $db) {
            return strcmp($db, $da);
        }
        return strcmp((string)($b['order_time'] ?? ''), (string)($a['order_time'] ?? ''));
    });

    $total_ms = (int)round((microtime(true) - $t0) * 1000);
    $network_hit = 0;
    foreach ($sources as $s) {
        if (!empty($s['ok']) && (int)($s['rows'] ?? 0) > 0) {
            $network_hit++;
        }
    }

    return [
        'status' => 'success',
        'patient' => $patient,
        'orders' => $orders,
        'items_by_order' => $items_by_order,
        'meta' => [
            'months' => $months,
            'lookback_label' => hds_lookback_label($months),
            'order_count' => count($orders),
            'local_hospital' => ['code' => 'local', 'name' => $local_name],
            'network' => $sources,
            'network_ok' => $include_network,
            'network_hit' => $network_hit,
            'timing' => [
                'total_ms' => $total_ms,
                'local_ms' => $local_ms,
                'network_ms' => $network_ms,
                'parallel' => $include_network,
            ],
        ],
    ];
}

/**
 * ดึง Lab รพ.เครือข่ายแบบขนาน — ได้ทั้ง orders + items ใน query เดียวต่อรพ.
 */
function smart_lab_fetch_network_bundle($con, array $hn_variants, $cid, $months = 12, $limit_each = 80) {
    $out = ['sources' => [], 'orders' => [], 'items_by_order' => []];
    list($grafana_rows, $direct, $skipped) = hds_split_remote_sources($con);
    foreach ($skipped as $row) {
        $item = hds_source_stub($row);
        unset($item['visits']);
        $item['error'] = 'ยังไม่มี UID Grafana — กดซิงก์ที่หน้าเชื่อมต่อรพ.';
        $out['sources'][] = $item;
    }
    if (!$grafana_rows && !$direct) {
        return $out;
    }
    $months = hds_lookback_months($months, 12);
    $limit_each = max(20, min(120, (int)$limit_each));
    $lookup_sql = hds_patient_lookup_sql($cid, $hn_variants);
    $cfg = $grafana_rows ? hds_grafana_get_config($con) : null;

    $apply_rows = function (array $row, array $res) use (&$out, $con) {
        $item = hds_source_stub($row);
        unset($item['visits']);
        $item['ms'] = (int)($res['ms'] ?? 0);
        $item['via'] = $res['via'] ?? $item['via'];
        $code = $item['code'];
        $name = $item['name'];
        if (empty($res['ok'])) {
            $item['error'] = $res['error'] ?? 'คิวรีไม่สำเร็จ';
            $out['sources'][] = $item;
            return;
        }
        $item['ok'] = true;
        $hex = (($res['via'] ?? '') === 'grafana');
        list($orders, $items_map) = smart_lab_pack_bundle_rows($res['rows'] ?? [], $code, $name, $con, $hex);
        foreach ($orders as $o) {
            $out['orders'][] = $o;
            $item['rows']++;
        }
        foreach ($items_map as $k => $items) {
            $out['items_by_order'][$k] = $items;
        }
        if ($orders && $item['matched_hn'] === '') {
            $item['matched_hn'] = (string)($orders[0]['matched_hn'] ?? '');
        }
        $out['sources'][] = $item;
    };

    $lookup_jobs = [];
    foreach ($grafana_rows as $code => $row) {
        $lookup_jobs[$code] = ['uid' => $row['grafana_ds_uid'], 'sql' => $lookup_sql];
    }
    $lookup_res = [];
    if ($lookup_jobs) {
        $t0 = microtime(true);
        $lookup_res = hds_grafana_query_multi($cfg, $lookup_jobs, [
            'timeout' => 8,
            'max_points' => 4,
        ]);
        $lookup_res = hds_grafana_fill_ms($lookup_res, (int)round((microtime(true) - $t0) * 1000));
    }

    $phase2 = [];
    foreach ($grafana_rows as $code => $row) {
        $res = $lookup_res[$code] ?? ['ok' => false, 'error' => 'ไม่มีผลลัพธ์', 'rows' => [], 'ms' => 0];
        $res['via'] = 'grafana';
        if (empty($res['ok'])) {
            $apply_rows($row, $res);
            continue;
        }
        $remote_hn = hds_row_hn($res);
        if ($remote_hn === '') {
            $res['rows'] = [];
            $apply_rows($row, $res);
            continue;
        }
        $phase2[$code] = [
            'uid' => $row['grafana_ds_uid'],
            'sql' => smart_lab_bundle_by_hn_sql($remote_hn, $months, $limit_each, true),
            'lookup_ms' => (int)($res['ms'] ?? 0),
        ];
    }
    if ($phase2) {
        $jobs = [];
        foreach ($phase2 as $code => $job) {
            $jobs[$code] = ['uid' => $job['uid'], 'sql' => $job['sql']];
        }
        $t0 = microtime(true);
        // max_points สูงขึ้นเพราะเป็นรายการ lab items
        $hist = hds_grafana_query_multi($cfg, $jobs, ['timeout' => 18, 'max_points' => 2500]);
        $hist = hds_grafana_fill_ms($hist, (int)round((microtime(true) - $t0) * 1000));
        foreach ($phase2 as $code => $job) {
            $res = $hist[$code] ?? ['ok' => false, 'error' => 'ไม่มีผลลัพธ์', 'rows' => [], 'ms' => 0];
            $res['via'] = 'grafana';
            $res['ms'] = (int)$job['lookup_ms'] + (int)($res['ms'] ?? 0);
            $apply_rows($grafana_rows[$code], $res);
        }
    }

    foreach ($direct as $row) {
        $t0 = microtime(true);
        $look = hds_query_sql($con, $row, $lookup_sql, ['timeout' => 8, 'max_points' => 4]);
        $look['via'] = 'direct';
        if (empty($look['ok'])) {
            $look['ms'] = (int)round((microtime(true) - $t0) * 1000);
            $apply_rows($row, $look);
            continue;
        }
        $remote_hn = hds_row_hn($look);
        if ($remote_hn === '') {
            $look['rows'] = [];
            $look['ms'] = (int)round((microtime(true) - $t0) * 1000);
            $apply_rows($row, $look);
            continue;
        }
        $res = hds_query_sql($con, $row, smart_lab_bundle_by_hn_sql($remote_hn, $months, $limit_each, true), [
            'timeout' => 18,
            'max_points' => 2500,
        ]);
        $res['via'] = 'direct';
        $res['ms'] = (int)round((microtime(true) - $t0) * 1000);
        $apply_rows($row, $res);
    }
    return $out;
}
