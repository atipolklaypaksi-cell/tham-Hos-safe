<?php
/**
 * Monitor Sepsis — qSOFA / SIRS / SOFA (มาตรฐาน) และ Modified score ที่ตั้งค่าได้
 *
 * qSOFA: Singer et al., JAMA 2016 (Sepsis-3)
 * SIRS: Bone et al., Chest 1992
 * SOFA: Vincent et al., Intensive Care Med 1996
 */

function msp_ensure_config($con) {
    if (!$con) {
        return false;
    }
    $ok = @mysqli_query($con, "CREATE TABLE IF NOT EXISTS sepsis_monitor_config (
        id INT AUTO_INCREMENT PRIMARY KEY,
        config_key VARCHAR(64) NOT NULL,
        config_json MEDIUMTEXT NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uk_key (config_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    return (bool)$ok;
}

function msp_default_modified_items() {
    return [
        ['id' => 'rr', 'label' => 'RR ≥ 22 /min', 'field' => 'rr', 'op' => '>=', 'value' => 22, 'points' => 1, 'on' => 1],
        ['id' => 'sbp', 'label' => 'SBP ≤ 100 mmHg', 'field' => 'sbp', 'op' => '<=', 'value' => 100, 'points' => 1, 'on' => 1],
        ['id' => 'gcs', 'label' => 'GCS < 15', 'field' => 'gcs', 'op' => '<', 'value' => 15, 'points' => 1, 'on' => 1],
        ['id' => 'temp_hi', 'label' => 'อุณหภูมิ > 38 °C', 'field' => 'temp', 'op' => '>', 'value' => 38, 'points' => 1, 'on' => 1],
        ['id' => 'temp_lo', 'label' => 'อุณหภูมิ < 36 °C', 'field' => 'temp', 'op' => '<', 'value' => 36, 'points' => 1, 'on' => 1],
        ['id' => 'hr', 'label' => 'HR > 90 /min', 'field' => 'hr', 'op' => '>', 'value' => 90, 'points' => 1, 'on' => 1],
        ['id' => 'wbc_hi', 'label' => 'WBC > 12,000', 'field' => 'wbc', 'op' => '>', 'value' => 12000, 'points' => 1, 'on' => 1],
        ['id' => 'wbc_lo', 'label' => 'WBC < 4,000', 'field' => 'wbc', 'op' => '<', 'value' => 4000, 'points' => 1, 'on' => 1],
        ['id' => 'lactate', 'label' => 'Lactate ≥ 2 mmol/L', 'field' => 'lactate', 'op' => '>=', 'value' => 2, 'points' => 2, 'on' => 1],
    ];
}

function msp_default_config() {
    return [
        'vitals_hours' => 24,
        'labs_hours' => 72,
        'gcs_missing' => 15,
        'qsofa_positive' => 2,
        'sirs_positive' => 2,
        'sofa_positive' => 2,
        'modified_positive' => 2,
        'lab_codes' => [
            'plt' => '',
            'bili' => '',
            'cr' => '',
            'wbc' => '',
            'bands' => '',
            'po2' => '',
            'pco2' => '',
            'lactate' => '',
            'fio2' => '',
        ],
        'modified_name' => 'Modified Sepsis Score',
        'modified_items' => msp_default_modified_items(),
    ];
}

function msp_config_get($con) {
    $cfg = msp_default_config();
    msp_ensure_config($con);
    if (!$con) {
        return $cfg;
    }
    $q = @mysqli_query($con, "SELECT config_json FROM sepsis_monitor_config WHERE config_key = 'main' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $raw = json_decode((string)$r['config_json'], true);
        if (is_array($raw)) {
            foreach ($cfg as $k => $v) {
                if (!array_key_exists($k, $raw)) {
                    continue;
                }
                if ($k === 'lab_codes' && is_array($raw[$k])) {
                    $cfg['lab_codes'] = array_merge($cfg['lab_codes'], $raw[$k]);
                } elseif ($k === 'modified_items' && is_array($raw[$k]) && $raw[$k]) {
                    $cfg['modified_items'] = $raw[$k];
                } else {
                    $cfg[$k] = $raw[$k];
                }
            }
        }
    }
    $cfg['vitals_hours'] = max(6, min(72, (int)$cfg['vitals_hours']));
    $cfg['labs_hours'] = max(12, min(168, (int)$cfg['labs_hours']));
    $cfg['qsofa_positive'] = max(1, min(3, (int)$cfg['qsofa_positive']));
    $cfg['sirs_positive'] = max(1, min(4, (int)$cfg['sirs_positive']));
    $cfg['sofa_positive'] = max(1, min(24, (int)$cfg['sofa_positive']));
    $cfg['modified_positive'] = max(1, min(20, (int)$cfg['modified_positive']));
    if ($cfg['gcs_missing'] === '' || $cfg['gcs_missing'] === null) {
        $cfg['gcs_missing'] = null;
    } else {
        $cfg['gcs_missing'] = max(3, min(15, (int)$cfg['gcs_missing']));
    }
    return $cfg;
}

function msp_config_save($con, array $src) {
    msp_ensure_config($con);
    $cfg = msp_config_get($con);
    foreach (['vitals_hours', 'labs_hours', 'gcs_missing', 'qsofa_positive', 'sirs_positive', 'sofa_positive', 'modified_positive', 'modified_name'] as $k) {
        if (array_key_exists($k, $src)) {
            $cfg[$k] = $src[$k];
        }
    }
    if (isset($src['lab_codes']) && is_array($src['lab_codes'])) {
        foreach ($cfg['lab_codes'] as $k => $_) {
            if (isset($src['lab_codes'][$k])) {
                $cfg['lab_codes'][$k] = trim((string)$src['lab_codes'][$k]);
            }
        }
    }
    if (isset($src['modified_items']) && is_array($src['modified_items'])) {
        $items = [];
        foreach ($src['modified_items'] as $it) {
            if (!is_array($it)) {
                continue;
            }
            $field = trim((string)($it['field'] ?? ''));
            if ($field === '') {
                continue;
            }
            $items[] = [
                'id' => preg_replace('/[^a-z0-9_]/', '', strtolower((string)($it['id'] ?? $field))),
                'label' => trim((string)($it['label'] ?? $field)),
                'field' => $field,
                'op' => in_array($it['op'] ?? '', ['>=', '<=', '>', '<', '=='], true) ? $it['op'] : '>=',
                'value' => (float)($it['value'] ?? 0),
                'points' => max(0, min(5, (int)($it['points'] ?? 1))),
                'on' => empty($it['on']) ? 0 : 1,
            ];
        }
        if ($items) {
            $cfg['modified_items'] = $items;
        }
    }
    $json = mysqli_real_escape_string($con, json_encode($cfg, JSON_UNESCAPED_UNICODE));
    @mysqli_query($con, "INSERT INTO sepsis_monitor_config (config_key, config_json)
        VALUES ('main', '$json')
        ON DUPLICATE KEY UPDATE config_json = VALUES(config_json)");
    return msp_config_get($con);
}

function msp_config_reset($con) {
    msp_ensure_config($con);
    @mysqli_query($con, "DELETE FROM sepsis_monitor_config WHERE config_key = 'main'");
    return msp_config_get($con);
}

function msp_parse_number($raw) {
    $s = trim((string)$raw);
    if ($s === '' || strcasecmp($s, 'nd') === 0 || $s === '-') {
        return null;
    }
    $s = str_replace([',', ' '], '', $s);
    if (!preg_match('/[-+]?\d+(?:\.\d+)?/', $s, $m)) {
        return null;
    }
    return (float)$m[0];
}

function msp_wbc_cells($raw) {
    $n = msp_parse_number($raw);
    if ($n === null) {
        return null;
    }
    if ($n <= 200) {
        return $n * 1000;
    }
    return $n;
}

function msp_plt_k($raw) {
    $n = msp_parse_number($raw);
    if ($n === null) {
        return null;
    }
    if ($n >= 1000) {
        return $n / 1000;
    }
    return $n;
}

function msp_map_from_bp($sbp, $dbp) {
    if ($sbp === null) {
        return null;
    }
    if ($dbp === null) {
        return (float)$sbp * 0.7;
    }
    return (float)$dbp + ((float)$sbp - (float)$dbp) / 3.0;
}

function msp_cmp($val, $op, $th) {
    if ($val === null) {
        return false;
    }
    if ($op === '>=') {
        return $val >= $th;
    }
    if ($op === '<=') {
        return $val <= $th;
    }
    if ($op === '>') {
        return $val > $th;
    }
    if ($op === '<') {
        return $val < $th;
    }
    return abs($val - $th) < 0.0001;
}

/** qSOFA: RR≥22, SBP≤100, GCS<15 — positive ≥2 */
function msp_score_qsofa($rr, $sbp, $gcs, $positive_at = 2) {
    $items = [
        ['key' => 'rr', 'label' => 'RR ≥ 22', 'hit' => msp_cmp($rr, '>=', 22), 'value' => $rr],
        ['key' => 'sbp', 'label' => 'SBP ≤ 100', 'hit' => msp_cmp($sbp, '<=', 100), 'value' => $sbp],
        ['key' => 'gcs', 'label' => 'GCS < 15', 'hit' => msp_cmp($gcs, '<', 15), 'value' => $gcs],
    ];
    $score = 0;
    foreach ($items as $it) {
        if ($it['hit']) {
            $score++;
        }
    }
    return [
        'score' => $score,
        'max' => 3,
        'positive' => $score >= (int)$positive_at ? 1 : 0,
        'items' => $items,
    ];
}

/** SIRS: ≥2 of Temp>38 or <36, HR>90, RR>20 or PaCO2<32, WBC>12k or <4k or bands>10% */
function msp_score_sirs($temp, $hr, $rr, $pco2, $wbc, $bands, $positive_at = 2) {
    $temp_hit = msp_cmp($temp, '>', 38) || msp_cmp($temp, '<', 36);
    $hr_hit = msp_cmp($hr, '>', 90);
    $rr_hit = msp_cmp($rr, '>', 20) || msp_cmp($pco2, '<', 32);
    $wbc_hit = msp_cmp($wbc, '>', 12000) || msp_cmp($wbc, '<', 4000) || msp_cmp($bands, '>', 10);
    $items = [
        ['key' => 'temp', 'label' => 'Temp >38 หรือ <36 °C', 'hit' => $temp_hit, 'value' => $temp],
        ['key' => 'hr', 'label' => 'HR > 90', 'hit' => $hr_hit, 'value' => $hr],
        ['key' => 'rr', 'label' => 'RR > 20 หรือ PaCO2 < 32', 'hit' => $rr_hit, 'value' => $rr],
        ['key' => 'wbc', 'label' => 'WBC >12k หรือ <4k หรือ band >10%', 'hit' => $wbc_hit, 'value' => $wbc],
    ];
    $score = 0;
    foreach ($items as $it) {
        if ($it['hit']) {
            $score++;
        }
    }
    return [
        'score' => $score,
        'max' => 4,
        'positive' => $score >= (int)$positive_at ? 1 : 0,
        'items' => $items,
    ];
}

function msp_sofa_resp($pao2, $fio2, $vent = false) {
    if ($pao2 === null || $fio2 === null || $fio2 <= 0) {
        return ['pts' => null, 'label' => 'ไม่มี PaO2/FiO2', 'pf' => null];
    }
    $fi = $fio2 > 1.5 ? ($fio2 / 100.0) : $fio2;
    if ($fi < 0.21) {
        $fi = 0.21;
    }
    $pf = $pao2 / $fi;
    $pts = 0;
    if ($pf < 100 && $vent) {
        $pts = 4;
    } elseif ($pf < 200 && $vent) {
        $pts = 3;
    } elseif ($pf < 300) {
        $pts = 2;
    } elseif ($pf < 400) {
        $pts = 1;
    }
    return ['pts' => $pts, 'label' => 'PaO2/FiO2 ' . round($pf), 'pf' => round($pf, 1)];
}

function msp_sofa_coag($plt_k) {
    if ($plt_k === null) {
        return ['pts' => null, 'label' => 'ไม่มี Platelet'];
    }
    $pts = 0;
    if ($plt_k < 20) {
        $pts = 4;
    } elseif ($plt_k < 50) {
        $pts = 3;
    } elseif ($plt_k < 100) {
        $pts = 2;
    } elseif ($plt_k < 150) {
        $pts = 1;
    }
    return ['pts' => $pts, 'label' => 'Plt ' . round($plt_k, 1) . ' ×10³'];
}

function msp_sofa_liver($bili) {
    if ($bili === null) {
        return ['pts' => null, 'label' => 'ไม่มี Bilirubin'];
    }
    $pts = 0;
    if ($bili >= 12) {
        $pts = 4;
    } elseif ($bili >= 6) {
        $pts = 3;
    } elseif ($bili >= 2) {
        $pts = 2;
    } elseif ($bili >= 1.2) {
        $pts = 1;
    }
    return ['pts' => $pts, 'label' => 'Bili ' . round($bili, 2)];
}

function msp_sofa_cv($map, array $pressors) {
    $dose = ['dopa' => 0.0, 'dobu' => 0.0, 'epi' => 0.0, 'norepi' => 0.0];
    $any = false;
    foreach ($pressors as $p) {
        $name = strtoupper((string)($p['name'] ?? ''));
        $mcg = isset($p['mcg_kg_min']) ? (float)$p['mcg_kg_min'] : 0;
        $any = true;
        if (preg_match('/NOREPINE|NORADREN|LEVOPHED|NOREPI/', $name)) {
            $dose['norepi'] = max($dose['norepi'], $mcg > 0 ? $mcg : 0.05);
        } elseif (preg_match('/EPINEPH|ADRENALIN/', $name) && !preg_match('/NOR/', $name)) {
            $dose['epi'] = max($dose['epi'], $mcg > 0 ? $mcg : 0.05);
        } elseif (preg_match('/DOPAMINE/', $name)) {
            $dose['dopa'] = max($dose['dopa'], $mcg > 0 ? $mcg : 6);
        } elseif (preg_match('/DOBUTAM/', $name)) {
            $dose['dobu'] = max($dose['dobu'], $mcg > 0 ? $mcg : 1);
        } elseif (preg_match('/VASOPRESSIN|PHENYLEPH/', $name)) {
            $dose['norepi'] = max($dose['norepi'], 0.05);
        }
    }
    if (!$any && $map === null) {
        return ['pts' => null, 'label' => 'ไม่มี MAP / vasopressor'];
    }
    $pts = 0;
    $label = $map !== null ? ('MAP ' . round($map)) : 'ไม่มี MAP';
    if ($dose['dopa'] > 15 || $dose['epi'] > 0.1 || $dose['norepi'] > 0.1) {
        $pts = 4;
        $label .= ' + vasopressor ขนาดสูง';
    } elseif ($dose['dopa'] > 5 || $dose['epi'] > 0 || $dose['norepi'] > 0) {
        $pts = 3;
        $label .= ' + NE/Epi หรือ Dopa >5';
    } elseif ($dose['dopa'] > 0 || $dose['dobu'] > 0) {
        $pts = 2;
        $label .= ' + Dopa ≤5 หรือ Dobutamine';
    } elseif ($map !== null && $map < 70) {
        $pts = 1;
        $label .= ' < 70';
    } elseif ($any) {
        $pts = 3;
        $label .= ' + vasopressor';
    }
    return ['pts' => $pts, 'label' => $label];
}

function msp_sofa_cns($gcs) {
    if ($gcs === null) {
        return ['pts' => null, 'label' => 'ไม่มี GCS'];
    }
    $pts = 0;
    if ($gcs < 6) {
        $pts = 4;
    } elseif ($gcs <= 9) {
        $pts = 3;
    } elseif ($gcs <= 12) {
        $pts = 2;
    } elseif ($gcs <= 14) {
        $pts = 1;
    }
    return ['pts' => $pts, 'label' => 'GCS ' . (int)$gcs];
}

function msp_sofa_renal($cr, $uop_ml = null) {
    if ($cr === null && $uop_ml === null) {
        return ['pts' => null, 'label' => 'ไม่มี Creatinine'];
    }
    $pts = 0;
    $label = $cr !== null ? ('Cr ' . round($cr, 2)) : 'UOP';
    if ($uop_ml !== null && $uop_ml < 200) {
        $pts = 4;
        $label .= ' UOP <200';
    } elseif (($cr !== null && $cr >= 5.0) || ($uop_ml !== null && $uop_ml < 500)) {
        $pts = max($pts, $cr !== null && $cr >= 5.0 ? 4 : 3);
        if ($cr !== null && $cr >= 5.0) {
            $pts = 4;
        } else {
            $pts = 3;
        }
    } elseif ($cr !== null && $cr >= 3.5) {
        $pts = 3;
    } elseif ($cr !== null && $cr >= 2.0) {
        $pts = 2;
    } elseif ($cr !== null && $cr >= 1.2) {
        $pts = 1;
    }
    return ['pts' => $pts, 'label' => $label];
}

function msp_sofa_rule($key, $pts) {
    $pts = (int)$pts;
    $rules = [
        'resp' => [
            0 => 'PaO2/FiO2 ≥ 400',
            1 => 'PaO2/FiO2 < 400',
            2 => 'PaO2/FiO2 < 300',
            3 => 'PaO2/FiO2 < 200 + ventilator',
            4 => 'PaO2/FiO2 < 100 + ventilator',
        ],
        'coag' => [
            0 => 'Platelet ≥ 150 ×10³',
            1 => 'Platelet < 150 ×10³',
            2 => 'Platelet < 100 ×10³',
            3 => 'Platelet < 50 ×10³',
            4 => 'Platelet < 20 ×10³',
        ],
        'liver' => [
            0 => 'Bilirubin < 1.2 mg/dL',
            1 => 'Bilirubin ≥ 1.2 mg/dL',
            2 => 'Bilirubin ≥ 2.0 mg/dL',
            3 => 'Bilirubin ≥ 6.0 mg/dL',
            4 => 'Bilirubin ≥ 12 mg/dL',
        ],
        'cv' => [
            0 => 'MAP ≥ 70 ไม่ใช้ vasopressor',
            1 => 'MAP < 70 mmHg',
            2 => 'Dopamine ≤5 หรือ Dobutamine',
            3 => 'Dopamine >5 หรือ Epi/NE ≤0.1',
            4 => 'Dopamine >15 หรือ Epi/NE >0.1',
        ],
        'cns' => [
            0 => 'GCS 15',
            1 => 'GCS 13–14',
            2 => 'GCS 10–12',
            3 => 'GCS 6–9',
            4 => 'GCS < 6',
        ],
        'renal' => [
            0 => 'Creatinine < 1.2 mg/dL',
            1 => 'Creatinine ≥ 1.2 mg/dL',
            2 => 'Creatinine ≥ 2.0 mg/dL',
            3 => 'Creatinine ≥ 3.5 หรือ UOP < 500',
            4 => 'Creatinine ≥ 5.0 หรือ UOP < 200',
        ],
    ];
    return $rules[$key][$pts] ?? ('SOFA ' . $pts);
}

function msp_score_sofa(array $v) {
    $organs = [
        'resp' => msp_sofa_resp($v['po2'] ?? null, $v['fio2'] ?? null, !empty($v['vent'])),
        'coag' => msp_sofa_coag($v['plt'] ?? null),
        'liver' => msp_sofa_liver($v['bili'] ?? null),
        'cv' => msp_sofa_cv($v['map'] ?? null, $v['pressors'] ?? []),
        'cns' => msp_sofa_cns($v['gcs'] ?? null),
        'renal' => msp_sofa_renal($v['cr'] ?? null, $v['uop'] ?? null),
    ];
    $score = 0;
    $missing = [];
    $items = [];
    foreach ($organs as $k => $o) {
        $pts = $o['pts'];
        $hit = ($pts !== null && (int)$pts >= 1);
        $items[] = [
            'key' => $k,
            'label' => $o['label'],
            'pts' => $pts,
            'hit' => $hit ? 1 : 0,
            'missing' => $pts === null ? 1 : 0,
            'rule' => $pts === null ? (string)$o['label'] : msp_sofa_rule($k, $pts),
        ];
        if ($pts === null) {
            $missing[] = $k;
        } else {
            $score += (int)$pts;
        }
    }
    $positive_at = (int)($v['positive_at'] ?? 2);
    return [
        'score' => $score,
        'max' => 24,
        'positive' => $score >= $positive_at ? 1 : 0,
        'missing' => $missing,
        'items' => $items,
    ];
}

function msp_score_modified(array $fields, array $items, $positive_at = 2) {
    $out_items = [];
    $score = 0;
    foreach ($items as $it) {
        if (empty($it['on'])) {
            continue;
        }
        $field = (string)($it['field'] ?? '');
        $val = array_key_exists($field, $fields) ? $fields[$field] : null;
        $hit = msp_cmp($val, (string)($it['op'] ?? '>='), (float)($it['value'] ?? 0));
        $pts = $hit ? (int)($it['points'] ?? 1) : 0;
        $score += $pts;
        $out_items[] = [
            'id' => $it['id'] ?? $field,
            'label' => $it['label'] ?? $field,
            'hit' => $hit ? 1 : 0,
            'points' => $pts,
            'value' => $val,
        ];
    }
    return [
        'score' => $score,
        'positive' => $score >= (int)$positive_at ? 1 : 0,
        'items' => $out_items,
    ];
}

function msp_lab_patterns() {
    return [
        'plt' => ['/^plt\.?\s*count/i', '/^platelet count/i'],
        'bili' => ['/^total bilirubin/i', '/^bilirubin$/i'],
        'cr' => ['/^creatinine$/i', '/^creatinine \(blood\)/i'],
        'wbc' => ['/^wbc$/i'],
        'bands' => ['/^band form/i'],
        'po2' => ['/^po2$/i', '/^pao2$/i'],
        'pco2' => ['/^pco2$/i', '/^paco2$/i'],
        'lactate' => ['/^lactate$/i'],
        'fio2' => ['/fio2/i'],
    ];
}

function msp_auto_lab_codes($hos) {
    $out = [];
    foreach (array_keys(msp_lab_patterns()) as $k) {
        $out[$k] = '';
    }
    if (!$hos) {
        return $out;
    }
    $name_sql = function_exists('amr_sql_utf8')
        ? amr_sql_utf8('lab_items_name')
        : "CAST(CONVERT(lab_items_name USING utf8) AS CHAR)";
    $q = @mysqli_query($hos, "SELECT lab_items_code, $name_sql AS n FROM lab_items");
    if (!$q) {
        return $out;
    }
    $items = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $name = trim((string)$r['n']);
        $code = trim((string)$r['lab_items_code']);
        if ($name === '' || $code === '') {
            continue;
        }
        $items[] = ['code' => $code, 'n' => $name];
    }
    foreach (msp_lab_patterns() as $key => $pats) {
        foreach ($pats as $re) {
            foreach ($items as $it) {
                if (preg_match($re, $it['n'])) {
                    $out[$key] = $it['code'];
                    break 2;
                }
            }
        }
    }
    return $out;
}

function msp_split_codes($raw) {
    $out = [];
    foreach (preg_split('/[\s,;]+/', (string)$raw) as $c) {
        $c = trim($c);
        if ($c !== '') {
            $out[$c] = $c;
        }
    }
    return array_values($out);
}

function msp_fetch_ipd($hos) {
    $pt = function_exists('amr_sql_utf8')
        ? amr_sql_utf8("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))")
        : "CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))";
    $ward = function_exists('amr_sql_utf8')
        ? amr_sql_utf8("IFNULL(w.name, '')")
        : "IFNULL(w.name, '')";
    $sql = "
        SELECT i.an, i.hn, i.vn, i.ward, DATE_FORMAT(i.regdate, '%Y-%m-%d') AS regdate,
               $pt AS ptname, $ward AS wname, IFNULL(i.cur_bedno, '') AS bedno
        FROM ipt i
        LEFT JOIN patient pt ON pt.hn = i.hn
        LEFT JOIN ward w ON w.ward = i.ward
        WHERE i.dchdate IS NULL OR i.dchdate = '0000-00-00'
        ORDER BY wname ASC, ptname ASC
        LIMIT 800
    ";
    $rows = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return ['error' => mysqli_error($hos), 'rows' => []];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $r['hn'] = preg_replace('/\D+/', '', (string)($r['hn'] ?? ''));
        $r['an'] = preg_replace('/\D+/', '', (string)($r['an'] ?? ''));
        $r['ptname'] = trim((string)($r['ptname'] ?? ''));
        $r['wname'] = trim((string)($r['wname'] ?? ''));
        if ($r['hn'] === '' || $r['an'] === '') {
            continue;
        }
        $rows[] = $r;
    }
    return ['error' => '', 'rows' => $rows];
}

function msp_hn_in($hos, array $hns) {
    $vals = [];
    foreach ($hns as $hn) {
        $hn = preg_replace('/\D+/', '', (string)$hn);
        if ($hn === '') {
            continue;
        }
        $vals[$hn] = true;
        $vals[str_pad($hn, 9, '0', STR_PAD_LEFT)] = true;
        $vals[ltrim($hn, '0')] = true;
    }
    $out = [];
    foreach (array_keys($vals) as $v) {
        if ($v === '') {
            continue;
        }
        $out[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return implode(',', $out);
}

function msp_fetch_vitals($hos, array $hns, $hours) {
    $in = msp_hn_in($hos, $hns);
    if ($in === '') {
        return [];
    }
    $hours = max(6, min(72, (int)$hours));
    $sql = "
        SELECT hn, vstdate, vsttime, bps, bpd, pulse, hr, temperature, rr, spo2, o2sat
        FROM opdscreen
        WHERE hn IN ($in)
          AND vstdate >= DATE_SUB(CURDATE(), INTERVAL 3 DAY)
          AND (rr > 0 OR pulse > 0 OR hr > 0 OR bps > 0 OR temperature > 0)
        ORDER BY hn ASC, vstdate DESC, vsttime DESC
    ";
    $out = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return [];
    }
    $cutoff = time() - ($hours * 3600);
    while ($r = mysqli_fetch_assoc($q)) {
        $hn = ltrim(preg_replace('/\D+/', '', (string)$r['hn']), '0');
        if ($hn === '' || isset($out[$hn])) {
            continue;
        }
        $dt = trim((string)$r['vstdate'] . ' ' . (string)$r['vsttime']);
        $ts = strtotime($dt);
        if ($ts && $ts < $cutoff) {
            continue;
        }
        $sbp = msp_parse_number($r['bps'] ?? '');
        $dbp = msp_parse_number($r['bpd'] ?? '');
        $hr = msp_parse_number($r['hr'] ?? '') ?: msp_parse_number($r['pulse'] ?? '');
        $spo2 = msp_parse_number($r['spo2'] ?? '');
        if ($spo2 === null) {
            $spo2 = msp_parse_number($r['o2sat'] ?? '');
        }
        $out[$hn] = [
            'sbp' => $sbp,
            'dbp' => $dbp,
            'map' => msp_map_from_bp($sbp, $dbp),
            'hr' => $hr,
            'temp' => msp_parse_number($r['temperature'] ?? ''),
            'rr' => msp_parse_number($r['rr'] ?? ''),
            'spo2' => $spo2,
            'time' => $dt,
        ];
    }
    return $out;
}

function msp_fetch_gcs($hos, array $vns, array $hns) {
    $out = [];
    $vn_in = [];
    foreach ($vns as $vn) {
        $vn = trim((string)$vn);
        if ($vn !== '') {
            $vn_in[] = "'" . mysqli_real_escape_string($hos, $vn) . "'";
        }
    }
    if ($vn_in) {
        $in = implode(',', array_slice($vn_in, 0, 800));
        $sql = "
            SELECT vn, gcs, gcs_e, gcs_v, gcs_m, coma_score
            FROM er_nursing_detail
            WHERE vn IN ($in)
        ";
        $q = @mysqli_query($hos, $sql);
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $gcs = (int)($r['gcs'] ?? 0);
                if ($gcs <= 0) {
                    $gcs = (int)($r['coma_score'] ?? 0);
                }
                if ($gcs <= 0) {
                    $e = (int)($r['gcs_e'] ?? 0);
                    $v = (int)($r['gcs_v'] ?? 0);
                    $m = (int)($r['gcs_m'] ?? 0);
                    if ($e + $v + $m > 0) {
                        $gcs = $e + $v + $m;
                    }
                }
                if ($gcs >= 3 && $gcs <= 15) {
                    $out['vn:' . $r['vn']] = $gcs;
                }
            }
        }
        $sql = "
            SELECT vn, neuro_sign_e, neuro_sign_v, neuro_sign_m
            FROM er_regist_vital_sign_list
            WHERE vn IN ($in)
            ORDER BY vital_sign_date DESC, vital_sign_time DESC
        ";
        $q = @mysqli_query($hos, $sql);
        if ($q) {
            $seen = [];
            while ($r = mysqli_fetch_assoc($q)) {
                $vn = (string)$r['vn'];
                if (isset($seen[$vn]) || isset($out['vn:' . $vn])) {
                    continue;
                }
                $seen[$vn] = true;
                $gcs = (int)$r['neuro_sign_e'] + (int)$r['neuro_sign_v'] + (int)$r['neuro_sign_m'];
                if ($gcs >= 3 && $gcs <= 15) {
                    $out['vn:' . $vn] = $gcs;
                }
            }
        }
    }
    return $out;
}

function msp_fetch_labs($hos, array $hns, array $lab_codes, $hours) {
    $in = msp_hn_in($hos, $hns);
    $codes = [];
    $key_of = [];
    foreach ($lab_codes as $key => $raw) {
        foreach (msp_split_codes($raw) as $c) {
            $codes[$c] = true;
            $key_of[$c] = $key;
        }
    }
    if ($in === '' || !$codes) {
        return [];
    }
    $code_in = [];
    foreach (array_keys($codes) as $c) {
        $code_in[] = "'" . mysqli_real_escape_string($hos, $c) . "'";
    }
    $hours = max(12, min(168, (int)$hours));
    $days = max(1, (int)ceil($hours / 24));
    $val_sql = function_exists('amr_sql_utf8')
        ? amr_sql_utf8("IFNULL(lo.lab_order_result, '')")
        : "CAST(CONVERT(IFNULL(lo.lab_order_result, '') USING utf8) AS CHAR)";
    $sql = "
        SELECT lh.hn, lo.lab_items_code AS code, $val_sql AS val,
               CONCAT(IFNULL(lh.report_date,''), ' ', IFNULL(lh.report_time,'')) AS dt
        FROM lab_head lh
        INNER JOIN lab_order lo ON lo.lab_order_number = lh.lab_order_number
        WHERE lh.hn IN ($in)
          AND lh.report_date >= DATE_SUB(CURDATE(), INTERVAL $days DAY)
          AND lh.report_date > '0000-00-00'
          AND lo.lab_items_code IN (" . implode(',', $code_in) . ")
          AND lo.lab_order_result IS NOT NULL
          AND TRIM(lo.lab_order_result) <> ''
        ORDER BY lh.report_date DESC, lh.report_time DESC
    ";
    $out = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return [];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $hn = ltrim(preg_replace('/\D+/', '', (string)$r['hn']), '0');
        $code = (string)$r['code'];
        $key = $key_of[$code] ?? '';
        if ($hn === '' || $key === '') {
            continue;
        }
        if (isset($out[$hn][$key])) {
            continue;
        }
        $raw = $r['val'];
        if ($key === 'wbc') {
            $val = msp_wbc_cells($raw);
        } elseif ($key === 'plt') {
            $val = msp_plt_k($raw);
        } else {
            $val = msp_parse_number($raw);
        }
        if ($val === null) {
            continue;
        }
        $out[$hn][$key] = ['val' => $val, 'raw' => $raw, 'time' => $r['dt'], 'code' => $code];
    }
    return $out;
}

function msp_fetch_pressors($hos, array $ans) {
    $in = [];
    foreach ($ans as $an) {
        $an = preg_replace('/\D+/', '', (string)$an);
        if ($an !== '') {
            $in[] = "'" . mysqli_real_escape_string($hos, $an) . "'";
        }
    }
    if (!$in) {
        return [];
    }
    $today = date('Y-m-d');
    $drug = function_exists('amr_sql_utf8')
        ? amr_sql_utf8("TRIM(CONCAT(IFNULL(NULLIF(d.name,''), IFNULL(d.generic_name,'')), ' ', IFNULL(d.strength,'')))")
        : "d.name";
    $method = function_exists('amr_sens_atb_method_sql')
        ? amr_sens_atb_method_sql('o')
        : "IFNULL(o.sp_use,'')";
    $like = "(UPPER(CONCAT(IFNULL(d.name,''),' ',IFNULL(d.generic_name,''))) LIKE '%NOREPINE%'
        OR UPPER(CONCAT(IFNULL(d.name,''),' ',IFNULL(d.generic_name,''))) LIKE '%NORADREN%'
        OR UPPER(CONCAT(IFNULL(d.name,''),' ',IFNULL(d.generic_name,''))) LIKE '%LEVOPHED%'
        OR UPPER(CONCAT(IFNULL(d.name,''),' ',IFNULL(d.generic_name,''))) LIKE '%DOPAMINE%'
        OR UPPER(CONCAT(IFNULL(d.name,''),' ',IFNULL(d.generic_name,''))) LIKE '%DOBUTAM%'
        OR UPPER(CONCAT(IFNULL(d.name,''),' ',IFNULL(d.generic_name,''))) LIKE '%ADRENALIN%'
        OR UPPER(CONCAT(IFNULL(d.name,''),' ',IFNULL(d.generic_name,''))) LIKE '%EPINEPH%'
        OR UPPER(CONCAT(IFNULL(d.name,''),' ',IFNULL(d.generic_name,''))) LIKE '%VASOPRESSIN%'
        OR UPPER(CONCAT(IFNULL(d.name,''),' ',IFNULL(d.generic_name,''))) LIKE '%PHENYLEPH%'
        OR UPPER(CONCAT(IFNULL(d.name,''),' ',IFNULL(d.generic_name,''))) LIKE '%NOREPI%')";
    $sql = "
        SELECT mp.an, $drug AS drugName, CAST(CONVERT($method USING utf8) AS CHAR) AS method
        FROM medplan_ipd mp
        INNER JOIN opitemrece o ON o.an = mp.an AND o.icode = mp.icode AND o.rxdate = '$today' AND o.qty > 0
        INNER JOIN drugitems d ON d.icode = mp.icode AND $like
        LEFT JOIN drugusage du ON du.drugusage = o.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
        WHERE mp.an IN (" . implode(',', $in) . ")
          AND (mp.offdate IS NULL OR mp.offdate = '0000-00-00')
          AND mp.qty > 0
        GROUP BY mp.an, d.name, d.generic_name, d.strength, o.sp_use, o.drugusage,
                 du.name1, du.name2, du.name3, sp.name1, sp.name2, sp.name3
    ";
    $out = [];
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return [];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $an = preg_replace('/\D+/', '', (string)$r['an']);
        $name = trim((string)$r['drugName']);
        $method = trim((string)($r['method'] ?? ''));
        $mcg = null;
        if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|ug)\s*\/\s*kg\s*\/\s*min/i', $method, $m)) {
            $mcg = (float)$m[1];
        }
        $out[$an][] = ['name' => $name, 'method' => $method, 'mcg_kg_min' => $mcg];
    }
    return $out;
}

function msp_fetch_infection($hos, $con, array $ans, array $hns) {
    $atb = [];
    if (function_exists('mad_fetch_current_atb')) {
        $cur = mad_fetch_current_atb($hos, $con);
        foreach ($cur['rows'] ?? [] as $r) {
            $an = preg_replace('/\D+/', '', (string)($r['an'] ?? ''));
            if ($an !== '') {
                $atb[$an] = true;
            }
        }
    }
    $icd = [];
    $in = [];
    foreach ($ans as $an) {
        $an = preg_replace('/\D+/', '', (string)$an);
        if ($an !== '') {
            $in[] = "'" . mysqli_real_escape_string($hos, $an) . "'";
        }
    }
    if ($in) {
        $sql = "
            SELECT an, icd10 FROM iptdiag
            WHERE an IN (" . implode(',', $in) . ")
              AND (
                icd10 LIKE 'A40%' OR icd10 LIKE 'A41%' OR icd10 LIKE 'R65%'
                OR icd10 LIKE 'R572%' OR icd10 = 'R57.2'
                OR icd10 LIKE 'A021%' OR icd10 LIKE 'A327%' OR icd10 LIKE 'A39%'
                OR icd10 LIKE 'A483%' OR icd10 LIKE 'A02.1%'
              )
        ";
        $q = @mysqli_query($hos, $sql);
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $an = preg_replace('/\D+/', '', (string)$r['an']);
                $icd[$an][] = $r['icd10'];
            }
        }
    }
    return ['atb' => $atb, 'icd' => $icd];
}

function msp_alert_level(array $row) {
    $reasons = [];
    if (!empty($row['sepsis3'])) {
        $reasons[] = 'Sepsis-3 screen (สงสัยติดเชื้อ + SOFA ≥ 2)';
    }
    if (!empty($row['qsofa']['positive'])) {
        $reasons[] = 'qSOFA ' . $row['qsofa']['score'];
    }
    if (!empty($row['modified']['positive'])) {
        $reasons[] = ($row['modified_name'] ?? 'Modified') . ' ' . $row['modified']['score'];
    }
    if (!empty($row['sofa']['positive']) && empty($row['sepsis3'])) {
        $reasons[] = 'SOFA ' . $row['sofa']['score'];
    }
    if (!empty($row['sirs']['positive'])) {
        $reasons[] = 'SIRS ' . $row['sirs']['score'];
    }
    $level = 'none';
    if (!empty($row['sepsis3']) || !empty($row['qsofa']['positive'])) {
        $level = 'high';
    } elseif (!empty($row['modified']['positive']) || !empty($row['sofa']['positive'])) {
        $level = 'med';
    } elseif (!empty($row['sirs']['positive'])) {
        $level = 'low';
    }
    return ['level' => $level, 'reasons' => $reasons];
}

function msp_scan($hos, $con, array $cfg = null) {
    $cfg = $cfg ?: msp_config_get($con);
    if (trim(implode('', $cfg['lab_codes'])) === '') {
        $auto = msp_auto_lab_codes($hos);
        foreach ($auto as $k => $v) {
            if ($v !== '' && ($cfg['lab_codes'][$k] ?? '') === '') {
                $cfg['lab_codes'][$k] = $v;
            }
        }
    }
    $ipd = msp_fetch_ipd($hos);
    if ($ipd['error'] !== '') {
        return ['error' => $ipd['error'], 'rows' => [], 'meta' => [], 'config' => $cfg];
    }
    $patients = $ipd['rows'];
    $hns = [];
    $ans = [];
    $vns = [];
    foreach ($patients as $p) {
        $hns[] = $p['hn'];
        $ans[] = $p['an'];
        $vns[] = $p['vn'] ?? '';
    }
    $vitals = msp_fetch_vitals($hos, $hns, (int)$cfg['vitals_hours']);
    $gcs_map = msp_fetch_gcs($hos, $vns, $hns);
    $labs = msp_fetch_labs($hos, $hns, $cfg['lab_codes'], (int)$cfg['labs_hours']);
    $press = msp_fetch_pressors($hos, $ans);
    $inf = msp_fetch_infection($hos, $con, $ans, $hns);

    $rows = [];
    $meta = [
        'ipd' => count($patients),
        'with_vitals' => 0,
        'qsofa' => 0,
        'sirs' => 0,
        'sofa' => 0,
        'modified' => 0,
        'sepsis3' => 0,
        'as_of' => date('Y-m-d H:i'),
    ];
    foreach ($patients as $p) {
        $hnk = ltrim($p['hn'], '0');
        $vs = $vitals[$hnk] ?? [];
        $lb = $labs[$hnk] ?? [];
        $gcs = $gcs_map['vn:' . ($p['vn'] ?? '')] ?? null;
        $gcs_assumed = 0;
        if ($gcs === null && $cfg['gcs_missing'] !== null) {
            $gcs = (int)$cfg['gcs_missing'];
            $gcs_assumed = 1;
        }
        $fields = [
            'rr' => $vs['rr'] ?? null,
            'sbp' => $vs['sbp'] ?? null,
            'dbp' => $vs['dbp'] ?? null,
            'map' => $vs['map'] ?? null,
            'hr' => $vs['hr'] ?? null,
            'temp' => $vs['temp'] ?? null,
            'spo2' => $vs['spo2'] ?? null,
            'gcs' => $gcs,
            'wbc' => $lb['wbc']['val'] ?? null,
            'bands' => $lb['bands']['val'] ?? null,
            'plt' => $lb['plt']['val'] ?? null,
            'bili' => $lb['bili']['val'] ?? null,
            'cr' => $lb['cr']['val'] ?? null,
            'po2' => $lb['po2']['val'] ?? null,
            'pco2' => $lb['pco2']['val'] ?? null,
            'lactate' => $lb['lactate']['val'] ?? null,
            'fio2' => $lb['fio2']['val'] ?? null,
        ];
        if ($fields['fio2'] !== null && $fields['fio2'] > 1.5) {
            $fields['fio2'] = $fields['fio2'] / 100.0;
        }
        $qsofa = msp_score_qsofa($fields['rr'], $fields['sbp'], $fields['gcs'], (int)$cfg['qsofa_positive']);
        $sirs = msp_score_sirs(
            $fields['temp'], $fields['hr'], $fields['rr'], $fields['pco2'],
            $fields['wbc'], $fields['bands'], (int)$cfg['sirs_positive']
        );
        $sofa = msp_score_sofa([
            'po2' => $fields['po2'],
            'fio2' => $fields['fio2'],
            'plt' => $fields['plt'],
            'bili' => $fields['bili'],
            'map' => $fields['map'],
            'pressors' => $press[$p['an']] ?? [],
            'gcs' => $gcs_assumed ? null : $gcs,
            'cr' => $fields['cr'],
            'positive_at' => (int)$cfg['sofa_positive'],
        ]);
        if ($gcs_assumed && $gcs !== null) {
            $cns = msp_sofa_cns($gcs);
            $sofa['items'][] = ['key' => 'cns_assumed', 'label' => 'GCS ถือเป็น ' . $gcs . ' (ไม่พบในระบบ)', 'pts' => 0];
        }
        $mod = msp_score_modified($fields, $cfg['modified_items'], (int)$cfg['modified_positive']);
        $on_atb = !empty($inf['atb'][$p['an']]);
        $icd = $inf['icd'][$p['an']] ?? [];
        $suspected = $on_atb || !empty($icd);
        $sepsis3 = ($suspected && !empty($sofa['positive'])) ? 1 : 0;
        if ($vs) {
            $meta['with_vitals']++;
        }
        if ($qsofa['positive']) {
            $meta['qsofa']++;
        }
        if ($sirs['positive']) {
            $meta['sirs']++;
        }
        if ($sofa['positive']) {
            $meta['sofa']++;
        }
        if ($mod['positive']) {
            $meta['modified']++;
        }
        if ($sepsis3) {
            $meta['sepsis3']++;
        }
        $row = [
            'an' => $p['an'],
            'hn' => $p['hn'],
            'vn' => $p['vn'] ?? '',
            'ptname' => $p['ptname'],
            'wname' => $p['wname'],
            'bedno' => $p['bedno'],
            'regdate' => $p['regdate'],
            'vitals' => $vs,
            'gcs' => $gcs,
            'gcs_assumed' => $gcs_assumed,
            'labs' => $lb,
            'pressors' => $press[$p['an']] ?? [],
            'on_atb' => $on_atb ? 1 : 0,
            'icd' => $icd,
            'suspected' => $suspected ? 1 : 0,
            'qsofa' => $qsofa,
            'sirs' => $sirs,
            'sofa' => $sofa,
            'modified' => $mod,
            'modified_name' => $cfg['modified_name'],
            'sepsis3' => $sepsis3,
        ];
        $row['alert'] = msp_alert_level($row);
        $rows[] = $row;
    }
    usort($rows, static function ($a, $b) {
        $rank = ['high' => 0, 'med' => 1, 'low' => 2, 'none' => 3];
        $ra = $rank[$a['alert']['level'] ?? 'none'] ?? 9;
        $rb = $rank[$b['alert']['level'] ?? 'none'] ?? 9;
        if ($ra !== $rb) {
            return $ra - $rb;
        }
        $sa = (int)($a['sofa']['score'] ?? 0) + (int)($a['qsofa']['score'] ?? 0);
        $sb = (int)($b['sofa']['score'] ?? 0) + (int)($b['qsofa']['score'] ?? 0);
        if ($sa !== $sb) {
            return $sb - $sa;
        }
        return strcmp((string)$a['wname'], (string)$b['wname']);
    });
    return ['error' => '', 'rows' => $rows, 'meta' => $meta, 'config' => $cfg];
}
