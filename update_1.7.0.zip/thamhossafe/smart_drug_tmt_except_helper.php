<?php

function sd_tmt_except_norm($name) {
    $s = strtolower(trim(preg_replace('/\s+/u', ' ', (string)$name)));
    return $s;
}

function sd_tmt_except_ensure($con) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    mysqli_query($con, "CREATE TABLE IF NOT EXISTS smart_drug_tmt_except (
        id INT NOT NULL AUTO_INCREMENT,
        icode VARCHAR(24) NOT NULL DEFAULT '',
        tpu_code VARCHAR(40) NOT NULL DEFAULT '',
        name_local VARCHAR(255) NOT NULL DEFAULT '',
        name_tmt VARCHAR(255) NOT NULL DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_name_tmt (name_tmt),
        KEY idx_tpu (tpu_code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // ย้ายจาก unique icode → unique ชื่อ TMT (รองรับรพ.เครือข่าย)
    $idx = mysqli_query($con, "SHOW INDEX FROM smart_drug_tmt_except");
    $has_icode = false;
    $has_tmt = false;
    if ($idx) {
        while ($r = mysqli_fetch_assoc($idx)) {
            $key = (string)($r['Key_name'] ?? '');
            if ($key === 'uk_icode') {
                $has_icode = true;
            }
            if ($key === 'uk_name_tmt') {
                $has_tmt = true;
            }
        }
    }
    if ($has_icode) {
        @mysqli_query($con, "ALTER TABLE smart_drug_tmt_except DROP INDEX uk_icode");
    }
    // รวมแถวที่ชื่อ TMT ซ้ำ เก็บแถว id น้อยสุด
    $dup = mysqli_query($con, "SELECT name_tmt, MIN(id) AS keep_id, COUNT(*) AS c
        FROM smart_drug_tmt_except
        WHERE TRIM(name_tmt) <> ''
        GROUP BY name_tmt
        HAVING c > 1");
    if ($dup) {
        while ($d = mysqli_fetch_assoc($dup)) {
            $keep = (int)$d['keep_id'];
            $tmt = mysqli_real_escape_string($con, (string)$d['name_tmt']);
            mysqli_query($con, "DELETE FROM smart_drug_tmt_except
                WHERE name_tmt='$tmt' AND id<>$keep");
        }
    }
    // ลบแถวที่ไม่มีชื่อ TMT (ใช้ไม่ได้กับโหมดใหม่)
    mysqli_query($con, "DELETE FROM smart_drug_tmt_except WHERE TRIM(IFNULL(name_tmt,'')) = ''");
    if (!$has_tmt) {
        @mysqli_query($con, "ALTER TABLE smart_drug_tmt_except
            MODIFY icode VARCHAR(24) NOT NULL DEFAULT '',
            ADD UNIQUE KEY uk_name_tmt (name_tmt)");
    }
}

function sd_tmt_except_list($con) {
    sd_tmt_except_ensure($con);
    $rows = [];
    $q = mysqli_query($con, "SELECT id, icode, tpu_code, name_local, name_tmt
        FROM smart_drug_tmt_except
        ORDER BY name_tmt ASC, id ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'id' => (int)$r['id'],
                'icode' => (string)$r['icode'],
                'tpu_code' => (string)$r['tpu_code'],
                'name_local' => (string)$r['name_local'],
                'name_tmt' => (string)$r['name_tmt'],
            ];
        }
    }
    return $rows;
}

function sd_tmt_except_add($con, array $in) {
    sd_tmt_except_ensure($con);
    $icode = trim((string)($in['icode'] ?? ''));
    $tpu = trim((string)($in['tpu_code'] ?? ''));
    $local = trim((string)($in['name_local'] ?? ''));
    $tmt = trim((string)($in['name_tmt'] ?? ''));
    if ($tmt === '') {
        return ['ok' => false, 'message' => 'ไม่พบชื่อยาจาก TMT'];
    }
    $esc = function ($v) use ($con) {
        return mysqli_real_escape_string($con, $v);
    };
    $ok = mysqli_query($con, "INSERT INTO smart_drug_tmt_except (icode, tpu_code, name_local, name_tmt)
        VALUES ('" . $esc($icode) . "', '" . $esc($tpu) . "', '" . $esc($local) . "', '" . $esc($tmt) . "')
        ON DUPLICATE KEY UPDATE
            icode=IF(VALUES(icode)<>'', VALUES(icode), icode),
            tpu_code=IF(VALUES(tpu_code)<>'', VALUES(tpu_code), tpu_code),
            name_local=IF(VALUES(name_local)<>'', VALUES(name_local), name_local)");
    return ['ok' => (bool)$ok, 'message' => $ok ? '' : 'บันทึกไม่สำเร็จ'];
}

function sd_tmt_except_delete($con, $id) {
    sd_tmt_except_ensure($con);
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "DELETE FROM smart_drug_tmt_except WHERE id=$id LIMIT 1");
}
