<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor Sepsis by score — qSOFA / SOFA / SIRS</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: #e8f1ec; }
        #content.msp-content {
            background:
                radial-gradient(1000px 380px at 100% -8%, rgba(220,38,38,.10), transparent 55%),
                #e8f1ec;
            min-height: 100vh;
        }
        .msp-hero { display: flex; justify-content: space-between; align-items: flex-end; gap: 16px; flex-wrap: wrap; margin-bottom: 16px; }
        .msp-kicker {
            display: inline-flex; align-items: center; gap: 8px;
            font-size: .75rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase;
            color: #991b1b; background: rgba(220,38,38,.12); border: 1px solid rgba(153,27,27,.15);
            border-radius: 999px; padding: 4px 10px; margin-bottom: 8px;
        }
        .msp-title { font-size: 1.45rem; font-weight: 800; color: #12261c; margin: 0; }
        .msp-sub { color: #5f7468; font-size: .9rem; margin: .2rem 0 0; }
        .msp-panel {
            background: #fff; border: 1px solid #d7e4dc; border-radius: 14px;
            padding: 1rem 1.1rem; box-shadow: 0 8px 24px rgba(18,38,28,.04);
        }
        .msp-kpi { display: grid; grid-template-columns: repeat(auto-fit, minmax(132px, 1fr)); gap: 10px; margin-bottom: 14px; }
        .msp-kpi-card { background: #fff; border: 1px solid #d7e4dc; border-radius: 12px; padding: .75rem .9rem; }
        .msp-kpi-card .lbl { font-size: .72rem; color: #5f7468; font-weight: 700; }
        .msp-kpi-card .num { font-size: 1.55rem; font-weight: 800; line-height: 1.1; color: #12261c; }
        .msp-kpi-card.is-high .num { color: #dc2626; }
        .msp-kpi-card.is-med .num { color: #b45309; }
        .msp-kpi-card.is-ok .num { color: #166534; }
        .msp-table { font-size: .8rem; margin: 0; }
        .msp-table thead th {
            background: #f6faf8; color: #146c4a; font-weight: 700; white-space: nowrap;
            border-bottom: 1px solid #d7e4dc; position: sticky; top: 0; z-index: 1;
        }
        .msp-table tbody tr { cursor: pointer; }
        .msp-table tbody tr:hover { background: #f5fbf8; }
        .msp-table tbody tr.is-active { background: #e7f8ee; }
        .msp-table tbody tr.lv-high { box-shadow: inset 4px 0 0 #dc2626; }
        .msp-table tbody tr.lv-med { box-shadow: inset 4px 0 0 #d97706; }
        .msp-empty { color: #7a8c84; text-align: center; padding: 1.6rem .5rem; }
        .score-pill {
            display: inline-flex; align-items: center; justify-content: center;
            min-width: 1.7rem; height: 1.45rem; border-radius: 6px;
            font-weight: 800; font-size: .75rem; padding: 0 .35rem;
            background: #e5eee9; color: #334155;
        }
        .score-pill.on { background: #dc2626; color: #fff; }
        .score-pill.warn { background: #eab308; color: #1c1917; }
        .score-pill.ok { background: #16a34a; color: #fff; }
        .msp-status { font-size: .82rem; color: #5f7468; }
        .msp-status.is-error { color: #b91c1c; }
        .table-scroll { max-height: 58vh; overflow: auto; }
        .msp-toolbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
        .msp-toolbar .form-select, .msp-toolbar .form-control { font-size: .82rem; }
        .org-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 8px; }
        .org-card { border: 1px solid #d7e4dc; border-radius: 10px; padding: .5rem .65rem; background: #fff; }
        .org-card .pts { font-size: 1.2rem; font-weight: 800; }
        .org-card.miss { opacity: .55; }
        .org-card.hit { border-color: #fecaca; background: #fff7f7; }
        .org-card.hit .pts { color: #991b1b; }
        .chip { display: inline-block; font-size: .68rem; font-weight: 700; border-radius: 999px; padding: 2px 8px; margin: 0 4px 4px 0; }
        .chip-hi { background: #fee2e2; color: #991b1b; }
        a.chip-link {
            text-decoration: none; cursor: pointer; border: 1px solid #fecaca;
        }
        a.chip-link:hover { background: #dc2626; color: #fff; border-color: #dc2626; }
        .chip-ok { background: #dcfce7; color: #166534; }
        .chip-muted { background: #f1f5f9; color: #475569; }
        .rank-row { display: flex; gap: 8px; align-items: center; border: 1px solid #d7e4dc; border-radius: 8px; padding: .4rem .55rem; margin-bottom: .35rem; background: #fff; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content msp-content">
        <div class="container-fluid py-3">
            <div class="msp-hero">
                <div>
                    <div class="msp-kicker"><i class="fas fa-heartbeat"></i> AMR · Monitor Sepsis by score</div>
                    <h1 class="msp-title">Monitor Sepsis by score</h1>
                    <p class="msp-sub">ประเมินผู้ป่วย IPD ตาม <strong>qSOFA</strong>, <strong>SIRS</strong>, <strong>SOFA</strong> และคะแนนที่ตั้งค่าเอง — สูตรมาตรฐาน Sepsis-3 / Bone 1992 / Vincent 1996</p>
                </div>
                <div class="msp-toolbar">
                    <select id="mspFilter" class="form-select form-select-sm" style="width:auto;">
                        <option value="alert" selected>เข้าเกณฑ์ (qSOFA / SOFA / SIRS / Modified)</option>
                        <option value="high">เสี่ยงสูง (qSOFA+ หรือ Sepsis-3)</option>
                        <option value="qsofa">qSOFA ถึงเกณฑ์</option>
                        <option value="sofa">SOFA ถึงเกณฑ์</option>
                        <option value="sirs">SIRS ถึงเกณฑ์</option>
                        <option value="mod">Modified ถึงเกณฑ์</option>
                        <option value="all">ผู้ป่วย IPD ทั้งหมด</option>
                    </select>
                    <input type="search" id="mspQ" class="form-control form-control-sm" placeholder="ค้นหา HN / ชื่อ / หอ" style="min-width:180px;">
                    <button type="button" class="btn btn-outline-success btn-sm" id="mspCfgBtn">
                        <i class="fas fa-sliders-h me-1"></i>ตั้งค่าเกณฑ์
                    </button>
                    <button type="button" class="btn btn-danger btn-sm" id="mspReload">
                        <i class="fas fa-sync-alt me-1"></i>โหลดใหม่
                    </button>
                </div>
            </div>

            <div class="msp-kpi">
                <div class="msp-kpi-card">
                    <div class="lbl">ผู้ป่วย IPD</div>
                    <div class="num" id="kpiIpd">—</div>
                </div>
                <div class="msp-kpi-card is-high">
                    <div class="lbl">Sepsis-3 screen</div>
                    <div class="num" id="kpiSepsis3">—</div>
                </div>
                <div class="msp-kpi-card is-high">
                    <div class="lbl">qSOFA ถึงเกณฑ์</div>
                    <div class="num" id="kpiQsofa">—</div>
                </div>
                <div class="msp-kpi-card is-med">
                    <div class="lbl">SOFA ถึงเกณฑ์</div>
                    <div class="num" id="kpiSofa">—</div>
                </div>
                <div class="msp-kpi-card is-med">
                    <div class="lbl">SIRS ถึงเกณฑ์</div>
                    <div class="num" id="kpiSirs">—</div>
                </div>
                <div class="msp-kpi-card is-ok">
                    <div class="lbl">Modified ถึงเกณฑ์</div>
                    <div class="num" id="kpiMod">—</div>
                </div>
            </div>

            <div class="msp-panel mb-3" id="mspCfgBox" style="display:none;">
                <h2 class="h6 fw-bold">ตั้งค่าเกณฑ์และลำดับคะแนน Modified</h2>
                <p class="small text-muted mb-2">qSOFA / SIRS / SOFA ใช้สูตรมาตรฐาน — ปรับได้เฉพาะคะแนนที่ถือว่า “ถึงเกณฑ์” และ mapping รหัส lab / รายการ Modified</p>
                <div class="row g-2 mb-2">
                    <div class="col-md-2">
                        <label class="form-label small mb-1">Vital ย้อนหลัง (ชม.)</label>
                        <input type="number" class="form-control form-control-sm" id="cfgVitalsH" min="6" max="72">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-1">Lab ย้อนหลัง (ชม.)</label>
                        <input type="number" class="form-control form-control-sm" id="cfgLabsH" min="12" max="168">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-1">qSOFA ถึงเกณฑ์</label>
                        <input type="number" class="form-control form-control-sm" id="cfgQsofaAt" min="1" max="3">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-1">SIRS ถึงเกณฑ์</label>
                        <input type="number" class="form-control form-control-sm" id="cfgSirsAt" min="1" max="4">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-1">SOFA ถึงเกณฑ์</label>
                        <input type="number" class="form-control form-control-sm" id="cfgSofaAt" min="1" max="24">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-1">Modified ถึงเกณฑ์</label>
                        <input type="number" class="form-control form-control-sm" id="cfgModAt" min="1" max="20">
                    </div>
                </div>
                <div class="row g-2 mb-2">
                    <div class="col-md-3">
                        <label class="form-label small mb-1">GCS ถ้าไม่พบในระบบ</label>
                        <input type="number" class="form-control form-control-sm" id="cfgGcsMiss" min="3" max="15" placeholder="15">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small mb-1">ชื่อ Modified score</label>
                        <input type="text" class="form-control form-control-sm" id="cfgModName">
                    </div>
                </div>
                <h3 class="h6 mt-2">รหัส Lab HOSxP (คั่นด้วยจุลภาคได้หลายรหัส)</h3>
                <div class="row g-2 mb-2" id="cfgLabWrap"></div>
                <button type="button" class="btn btn-outline-success btn-sm mb-3" id="cfgLabDetect">ดึงรหัส lab จากชื่อมาตรฐาน</button>
                <h3 class="h6">รายการ Modified score (เปิด/ปิด และกำหนดแต้ม)</h3>
                <div id="cfgModItems"></div>
                <div class="d-flex gap-2 mt-2">
                    <button type="button" class="btn btn-success btn-sm" id="cfgSave"><i class="fas fa-save me-1"></i>บันทึก</button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="cfgReset">คืนค่าเริ่มต้น</button>
                    <span class="small text-muted align-self-center" id="cfgHint"></span>
                </div>
            </div>

            <div class="msp-panel mb-3" id="mspDetail" style="display:none;"></div>

            <div class="msp-panel">
                <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                    <h2 class="h6 fw-bold mb-0">รายการประเมิน</h2>
                    <span class="msp-status" id="mspStatus">กำลังโหลด...</span>
                </div>
                <div class="table-scroll">
                    <table class="table table-sm msp-table">
                        <thead>
                            <tr>
                                <th>หอผู้ป่วย</th>
                                <th>HN</th>
                                <th>AN</th>
                                <th>ชื่อ-สกุล</th>
                                <th>Vital</th>
                                <th>qSOFA</th>
                                <th>SIRS</th>
                                <th>SOFA</th>
                                <th>Modified</th>
                                <th>สงสัยติดเชื้อ</th>
                                <th>สรุป</th>
                            </tr>
                        </thead>
                        <tbody id="mspBody">
                            <tr><td colspan="11" class="msp-empty">กำลังโหลด</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const MSP_API = 'fetch_monitor_sepsis_api.php';
const LAB_LABELS = {
    plt: 'Platelet', bili: 'Total Bilirubin', cr: 'Creatinine', wbc: 'WBC',
    bands: 'Band form', po2: 'PaO2 / pO2', pco2: 'PaCO2 / pCO2', lactate: 'Lactate', fio2: 'FiO2'
};
let lastRows = [];
let lastCfg = null;
let activeAn = '';

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function setStatus(msg, isError) {
    const el = document.getElementById('mspStatus');
    el.textContent = msg;
    el.classList.toggle('is-error', !!isError);
}

function pill(score, on) {
    return '<span class="score-pill' + (on ? ' on' : '') + '">' + esc(score) + '</span>';
}

function vitalsTxt(v) {
    if (!v || (!v.rr && !v.hr && !v.sbp && !v.temp)) return '—';
    const bits = [];
    if (v.temp != null) bits.push('T ' + v.temp);
    if (v.hr != null) bits.push('HR ' + v.hr);
    if (v.rr != null) bits.push('RR ' + v.rr);
    if (v.sbp != null) bits.push('BP ' + v.sbp + (v.dbp != null ? '/' + v.dbp : ''));
    if (v.spo2 != null) bits.push('SpO2 ' + v.spo2);
    return bits.join(' · ');
}

function filteredRows() {
    const mode = document.getElementById('mspFilter').value;
    const q = (document.getElementById('mspQ').value || '').trim().toLowerCase();
    return lastRows.filter(function (r) {
        const lv = (r.alert && r.alert.level) || 'none';
        if (mode === 'alert' && lv === 'none') return false;
        if (mode === 'high' && lv !== 'high') return false;
        if (mode === 'qsofa' && !(r.qsofa && r.qsofa.positive)) return false;
        if (mode === 'sofa' && !(r.sofa && r.sofa.positive)) return false;
        if (mode === 'sirs' && !(r.sirs && r.sirs.positive)) return false;
        if (mode === 'mod' && !(r.modified && r.modified.positive)) return false;
        if (!q) return true;
        return [r.hn, r.an, r.ptname, r.wname].join(' ').toLowerCase().indexOf(q) !== -1;
    });
}

function localIso(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + day;
}

function cdssHref(r) {
    const start = new Date();
    start.setDate(start.getDate() - 30);
    const p = new URLSearchParams();
    if (r.hn) p.set('hn', String(r.hn));
    if (r.an) p.set('an', String(r.an));
    p.set('start_date', localIso(start));
    p.set('end_date', localIso(new Date()));
    p.set('scope', 'all');
    return 'amr_sensitivity.php?' + p.toString();
}

function infCell(r) {
    if (r.on_atb) {
        return '<a class="chip chip-hi chip-link" href="' + cdssHref(r) + '"'
            + ' title="ดูประวัติยาปฏิชีวนะใน CDSS for Antibiotic"'
            + ' onclick="event.stopPropagation()"><i class="fas fa-pills me-1"></i>ยา ATB</a>';
    }
    if (r.suspected) {
        return '<span class="chip chip-hi">ICD</span>';
    }
    return '<span class="chip chip-muted">ยังไม่ชัด</span>';
}

function renderRows() {
    const rows = filteredRows();
    const body = document.getElementById('mspBody');
    if (!rows.length) {
        body.innerHTML = '<tr><td colspan="11" class="msp-empty">ไม่พบรายการตามตัวกรอง</td></tr>';
        return;
    }
    body.innerHTML = rows.map(function (r) {
        const lv = (r.alert && r.alert.level) || 'none';
        const inf = infCell(r);
        const why = ((r.alert && r.alert.reasons) || []).join(' · ') || '—';
        return '<tr class="lv-' + lv + (r.an === activeAn ? ' is-active' : '') + '" data-an="' + esc(r.an) + '">'
            + '<td>' + esc(r.wname) + (r.bedno ? '<div class="small text-muted">' + esc(r.bedno) + '</div>' : '') + '</td>'
            + '<td class="fw-bold">' + esc(r.hn) + '</td>'
            + '<td>' + esc(r.an) + '</td>'
            + '<td>' + esc(r.ptname) + '</td>'
            + '<td>' + esc(vitalsTxt(r.vitals)) + '</td>'
            + '<td>' + pill(r.qsofa ? r.qsofa.score : 0, r.qsofa && r.qsofa.positive) + '</td>'
            + '<td>' + pill(r.sirs ? r.sirs.score : 0, r.sirs && r.sirs.positive) + '</td>'
            + '<td>' + pill(r.sofa ? r.sofa.score : 0, r.sofa && r.sofa.positive) + '</td>'
            + '<td>' + pill(r.modified ? r.modified.score : 0, r.modified && r.modified.positive) + '</td>'
            + '<td>' + inf + '</td>'
            + '<td>' + esc(why) + '</td>'
            + '</tr>';
    }).join('');
    body.querySelectorAll('tr[data-an]').forEach(function (tr) {
        tr.addEventListener('click', function () { showDetail(tr.getAttribute('data-an')); });
    });
}

function showDetail(an) {
    activeAn = an;
    const r = lastRows.find(function (x) { return x.an === an; });
    const box = document.getElementById('mspDetail');
    if (!r) { box.style.display = 'none'; return; }
    renderRows();
    const organs = (r.sofa && r.sofa.items) || [];
    const organNames = {
        resp: 'Respiration', coag: 'Coagulation', liver: 'Liver',
        cv: 'Cardiovascular', cns: 'CNS', renal: 'Renal'
    };
    const organHtml = organs.filter(function (o) { return o.key !== 'cns_assumed'; }).map(function (o) {
        const miss = o.pts == null;
        const hit = !miss && Number(o.pts) >= 1;
        return '<div class="org-card' + (miss ? ' miss' : '') + (hit ? ' hit' : '') + '"><div class="small text-muted">'
            + esc(organNames[o.key] || o.key)
            + '</div><div class="pts">' + (miss ? '—' : esc(o.pts)) + '</div><div class="small">'
            + esc(o.rule || o.label) + (o.label && o.rule && o.label !== o.rule ? ' · ' + esc(o.label) : '')
            + '</div></div>';
    }).join('');
    function listHits(block) {
        return ((block && block.items) || []).map(function (it) {
            return '<span class="chip ' + (it.hit ? 'chip-hi' : 'chip-ok') + '">' + esc(it.label)
                + (it.value != null ? ' (' + esc(it.value) + ')' : '') + '</span>';
        }).join('');
    }
    function sofaHits(block) {
        return ((block && block.items) || []).filter(function (it) { return it.key !== 'cns_assumed'; }).map(function (it) {
            const title = organNames[it.key] || it.key;
            if (it.pts == null || Number(it.missing)) {
                return '<span class="chip chip-muted">' + esc(title) + ' · ' + esc(it.label || 'ไม่มีข้อมูล') + '</span>';
            }
            const hit = Number(it.pts) >= 1 || Number(it.hit);
            const rule = it.rule || it.label || '';
            return '<span class="chip ' + (hit ? 'chip-hi' : 'chip-ok') + '">'
                + esc(title) + ' +' + esc(it.pts)
                + (rule ? ' · ' + esc(rule) : '')
                + (it.label && it.label !== rule ? ' (' + esc(it.label) + ')' : '')
                + '</span>';
        }).join('');
    }
    box.style.display = '';
    box.innerHTML = '<div class="d-flex justify-content-between flex-wrap gap-2 mb-2">'
        + '<div><strong>' + esc(r.ptname) + '</strong> · HN ' + esc(r.hn) + ' · AN ' + esc(r.an)
        + ' · ' + esc(r.wname) + '</div>'
        + '<a class="btn btn-sm btn-outline-success" href="' + cdssHref(r) + '">'
        + '<i class="fas fa-pills me-1"></i>CDSS for Antibiotic</a></div>'
        + '<div class="small text-muted mb-2">Vital: ' + esc(vitalsTxt(r.vitals))
        + ' · GCS ' + (r.gcs != null ? esc(r.gcs) : '—') + (r.gcs_assumed ? ' (สมมติ)' : '')
        + ' · SOFA ' + esc((r.sofa && r.sofa.score) != null ? r.sofa.score : '—') + '/24</div>'
        + '<div class="org-grid mb-2">' + organHtml + '</div>'
        + '<div class="small mb-1"><strong>qSOFA</strong> ' + listHits(r.qsofa) + '</div>'
        + '<div class="small mb-1"><strong>SIRS</strong> ' + listHits(r.sirs) + '</div>'
        + '<div class="small mb-1"><strong>SOFA</strong> ' + sofaHits(r.sofa) + '</div>'
        + '<div class="small mb-1"><strong>' + esc(r.modified_name || 'Modified') + '</strong> '
        + ((r.modified && r.modified.items) || []).map(function (it) {
            return '<span class="chip ' + (it.hit ? 'chip-hi' : 'chip-ok') + '">' + esc(it.label)
                + (it.points ? ' +' + it.points : '') + '</span>';
        }).join('') + '</div>';
}

function fillConfig(cfg) {
    lastCfg = cfg;
    document.getElementById('cfgVitalsH').value = cfg.vitals_hours;
    document.getElementById('cfgLabsH').value = cfg.labs_hours;
    document.getElementById('cfgQsofaAt').value = cfg.qsofa_positive;
    document.getElementById('cfgSirsAt').value = cfg.sirs_positive;
    document.getElementById('cfgSofaAt').value = cfg.sofa_positive;
    document.getElementById('cfgModAt').value = cfg.modified_positive;
    document.getElementById('cfgGcsMiss').value = cfg.gcs_missing != null ? cfg.gcs_missing : 15;
    document.getElementById('cfgModName').value = cfg.modified_name || '';
    const wrap = document.getElementById('cfgLabWrap');
    wrap.innerHTML = Object.keys(LAB_LABELS).map(function (k) {
        return '<div class="col-md-3"><label class="form-label small mb-1">' + esc(LAB_LABELS[k]) + '</label>'
            + '<input class="form-control form-control-sm" data-lab="' + k + '" value="'
            + esc((cfg.lab_codes && cfg.lab_codes[k]) || '') + '"></div>';
    }).join('');
    const host = document.getElementById('cfgModItems');
    host.innerHTML = (cfg.modified_items || []).map(function (it, i) {
        return '<div class="rank-row">'
            + '<input type="checkbox" data-mod-on="' + i + '"' + (it.on ? ' checked' : '') + '>'
            + '<span class="flex-grow-1 small">' + esc(it.label) + ' <span class="text-muted">'
            + esc(it.field) + ' ' + esc(it.op) + ' ' + esc(it.value) + '</span></span>'
            + '<input type="number" class="form-control form-control-sm" style="width:70px" data-mod-pts="' + i
            + '" value="' + esc(it.points) + '" min="0" max="5">'
            + '</div>';
    }).join('');
}

function readConfig() {
    const cfg = JSON.parse(JSON.stringify(lastCfg || {}));
    cfg.vitals_hours = +document.getElementById('cfgVitalsH').value;
    cfg.labs_hours = +document.getElementById('cfgLabsH').value;
    cfg.qsofa_positive = +document.getElementById('cfgQsofaAt').value;
    cfg.sirs_positive = +document.getElementById('cfgSirsAt').value;
    cfg.sofa_positive = +document.getElementById('cfgSofaAt').value;
    cfg.modified_positive = +document.getElementById('cfgModAt').value;
    cfg.gcs_missing = +document.getElementById('cfgGcsMiss').value;
    cfg.modified_name = document.getElementById('cfgModName').value;
    cfg.lab_codes = cfg.lab_codes || {};
    document.querySelectorAll('#cfgLabWrap [data-lab]').forEach(function (el) {
        cfg.lab_codes[el.getAttribute('data-lab')] = el.value;
    });
    (cfg.modified_items || []).forEach(function (it, i) {
        const on = document.querySelector('[data-mod-on="' + i + '"]');
        const pts = document.querySelector('[data-mod-pts="' + i + '"]');
        it.on = on && on.checked ? 1 : 0;
        if (pts) it.points = +pts.value;
    });
    return cfg;
}

async function loadList() {
    const btn = document.getElementById('mspReload');
    btn.disabled = true;
    setStatus('กำลังประเมิน SOFA / qSOFA / SIRS...');
    try {
        const res = await fetch(MSP_API + '?action=list');
        const data = await res.json();
        if (data.status !== 'success') throw new Error(data.message || 'โหลดไม่สำเร็จ');
        lastRows = data.rows || [];
        lastCfg = data.config || lastCfg;
        const m = data.meta || {};
        document.getElementById('kpiIpd').textContent = String(m.ipd != null ? m.ipd : lastRows.length);
        document.getElementById('kpiSepsis3').textContent = String(m.sepsis3 != null ? m.sepsis3 : 0);
        document.getElementById('kpiQsofa').textContent = String(m.qsofa != null ? m.qsofa : 0);
        document.getElementById('kpiSofa').textContent = String(m.sofa != null ? m.sofa : 0);
        document.getElementById('kpiSirs').textContent = String(m.sirs != null ? m.sirs : 0);
        document.getElementById('kpiMod').textContent = String(m.modified != null ? m.modified : 0);
        if (lastCfg) fillConfig(lastCfg);
        renderRows();
        setStatus('IPD ' + (m.ipd || 0) + ' · มี vital ' + (m.with_vitals || 0)
            + ' · Sepsis-3 ' + (m.sepsis3 || 0) + ' · ' + (m.as_of || ''));
    } catch (e) {
        lastRows = [];
        document.getElementById('mspBody').innerHTML = '<tr><td colspan="11" class="msp-empty">' + esc(e.message || String(e)) + '</td></tr>';
        setStatus(e.message || String(e), true);
    } finally {
        btn.disabled = false;
    }
}

document.getElementById('mspReload').addEventListener('click', loadList);
document.getElementById('mspFilter').addEventListener('change', renderRows);
document.getElementById('mspQ').addEventListener('input', renderRows);
document.getElementById('mspCfgBtn').addEventListener('click', function () {
    const box = document.getElementById('mspCfgBox');
    box.style.display = box.style.display === 'none' ? '' : 'none';
    if (box.style.display !== 'none' && lastCfg) fillConfig(lastCfg);
});
document.getElementById('cfgSave').addEventListener('click', async function () {
    this.disabled = true;
    try {
        const res = await fetch(MSP_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'config_save', config: readConfig() })
        });
        const data = await res.json();
        if (data.status !== 'success') throw new Error(data.message || 'บันทึกไม่สำเร็จ');
        fillConfig(data.config);
        document.getElementById('cfgHint').textContent = data.message || 'บันทึกแล้ว';
        await loadList();
    } catch (e) {
        alert(e.message || String(e));
    } finally {
        this.disabled = false;
    }
});
document.getElementById('cfgReset').addEventListener('click', async function () {
    if (!confirm('คืนเกณฑ์มาตรฐาน qSOFA / SIRS / SOFA และ Modified เริ่มต้น?')) return;
    const res = await fetch(MSP_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'config_reset' })
    });
    const data = await res.json();
    if (data.status !== 'success') { alert(data.message || 'ไม่สำเร็จ'); return; }
    fillConfig(data.config);
    await loadList();
});
document.getElementById('cfgLabDetect').addEventListener('click', async function () {
    const res = await fetch(MSP_API + '?action=lab_detect');
    const data = await res.json();
    if (data.status !== 'success') { alert(data.message || 'ไม่สำเร็จ'); return; }
    if (lastCfg) lastCfg.lab_codes = Object.assign({}, lastCfg.lab_codes, data.lab_codes || {});
    fillConfig(lastCfg);
    document.getElementById('cfgHint').textContent = 'ดึงรหัส lab จากชื่อใน HOSxP แล้ว — กดบันทึกเพื่อใช้';
});
loadList();
</script>
</body>
</html>
