<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
include('connect.php');
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/server_health_helper.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.server_health')) {
    echo json_encode(['status' => 'error', 'msg' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'snapshot'));

if ($action === 'save_cron') {
    $n = sh_jobs_save($con, $input['jobs'] ?? []);
    $snap = sh_collect_snapshot($con);
    echo json_encode([
        'status' => $n > 0 ? 'success' : 'error',
        'msg' => $n > 0 ? 'บันทึกการตั้งค่า Cron แล้ว' : 'ไม่มีงานที่บันทึก',
        'data' => $snap,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$snap = sh_collect_snapshot($con);
echo json_encode(['status' => 'success', 'data' => $snap], JSON_UNESCAPED_UNICODE);
