<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
tham_menu_ensure_page_access('med_reconcile_discharge.php');
$prefill_hn = htmlspecialchars($_GET['hn'] ?? '', ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Med Reconcile ยากลับบ้าน - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: #f4f7f6; }
        .patient-bar { background: #eef7f3; border: 1px solid #c5d4a0; border-radius: 10px; }
        .allergy-ok { color: #198754; font-weight: 800; font-size: .85rem; }
        .allergy-yes { color: #b02a37; font-weight: 800; font-size: .85rem; }
        .visit-box {
            max-height: 280px; overflow: auto; border: 1px solid #dee2e6;
            border-radius: 8px; background: #fff;
        }
        .visit-row {
            display: flex; gap: 8px; align-items: flex-start;
            padding: 8px 10px; border-bottom: 1px solid #f1f3f5; cursor: pointer;
        }
        .visit-row:hover { background: #e8f4fd; }
        .visit-row:last-child { border-bottom: 0; }
        .mrd-table-wrap { max-height: 620px; overflow: auto; background: #fff; }
        .mrd-table th { position: sticky; top: 0; z-index: 2; background: #eef5f1; font-size: .78rem; white-space: nowrap; }
        .mrd-table td { font-size: .82rem; vertical-align: top; }
        .mrd-drug { font-weight: 800; color: #0d6efd; }
        .mrd-method { white-space: pre-wrap; line-height: 1.35; color: #212529; }
        .mrd-empty { color: #adb5bd; }
        .badge-cont { background: #198754; }
        .badge-change { background: #fd7e14; }
        .badge-off { background: #dc3545; }
        .badge-up { background: #0d6efd; }
        .badge-down { background: #e83e8c; }
        .badge-new { background: #6f42c1; }
        .badge-none { background: #adb5bd; }
        .mrd-action-fixed {
            display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap;
        }
        .mrd-action-fixed .badge {
            font-size: .78rem; font-weight: 800; padding: .4em .65em; letter-spacing: .02em;
        }
        .mrd-action-fixed .auto-tag {
            font-size: .68rem; font-weight: 700; color: #6c757d; text-transform: uppercase;
        }
        .src-chip {
            display: inline-block; font-size: .72rem; font-weight: 700;
            padding: 2px 8px; border-radius: 999px; background: #e9ecef; color: #495057;
        }
        .src-chip.smart { background: #cff4fc; color: #055160; }
        .src-chip.hosxp { background: #d1e7dd; color: #0f5132; }
        .src-chip.visit { background: #e2e3e5; color: #41464b; }
        .col-pre { background: #fffaf0; }
        .col-admit { background: #f0f7ff; }
        .col-hme { background: #f0fff4; }
        .order-type-tag {
            display: inline-block; font-size: .68rem; font-weight: 800;
            padding: 1px 6px; border-radius: 4px; margin-top: 2px;
        }
        .order-type-tag.bch { background: #cfe2ff; color: #084298; }
        .order-type-tag.irx { background: #ffe5d0; color: #984c0c; }
        .order-type-tag.other { background: #e9ecef; color: #495057; }
        .action-group label { font-size: .75rem; margin-right: 4px; white-space: nowrap; }
        .visit-row.is-focus {
            background: #fff3cd !important;
            outline: 2px solid #ffc107;
        }
        .visit-row.is-blink {
            animation: mrdVisitBlink 0.85s ease-in-out 2;
        }
        .mrd-table tr.mrd-hl-pre td.col-pre {
            background: #fff3cd !important;
            box-shadow: inset 0 0 0 2px #ffc107;
        }
        .mrd-table tr.mrd-hl-pre {
            outline: 2px solid #0d6efd;
            outline-offset: -2px;
        }
        .mrd-table tr.mrd-hl-pre.is-blink td.col-pre {
            animation: mrdPreBlink 0.9s ease-in-out 2;
        }
        @keyframes mrdVisitBlink {
            0%, 100% { background: #fff3cd; }
            50% { background: #ffe069; }
        }
        @keyframes mrdPreBlink {
            0%, 100% { background: #fff3cd; box-shadow: inset 0 0 0 2px #ffc107; }
            50% { background: #ffe8a3; box-shadow: inset 0 0 0 2px #fd7e14; }
        }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
                <div>
                    <h4 class="fw-bold mb-1 text-dark">
                        <i class="fas fa-house-user me-2 text-success"></i>Med Reconcile ยากลับบ้าน
                    </h4>
                    <p class="text-muted small mb-0">
                        เทียบยา <b>ก่อน Admit</b> (เลือก Visit / จาก Smart Drug Med Recon) ·
                        <b>ขณะ Admit</b> (วิธีใช้ล่าสุด) · <b>HME ยากลับบ้าน</b> (ถ้ามี)
                    </p>
                </div>
                <a href="smart_drug.php" class="btn btn-outline-secondary btn-sm">
                    <i class="fas fa-capsules me-1"></i> ไป Smart Drug Med Recon
                </a>
            </div>

            <ul class="nav nav-tabs mb-3" id="mrdTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active fw-bold" id="tab-compare-btn" data-bs-toggle="tab" data-bs-target="#tabCompare" type="button" role="tab">
                        <i class="fas fa-balance-scale me-1"></i>เปรียบเทียบ
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold" id="tab-settings-btn" data-bs-toggle="tab" data-bs-target="#tabSettings" type="button" role="tab" onclick="loadMrdSettings()">
                        <i class="fas fa-cog me-1"></i>ตั้งค่า
                    </button>
                </li>
            </ul>

            <div class="tab-content">
            <div class="tab-pane fade show active" id="tabCompare" role="tabpanel">

            <div class="card shadow-sm border-0 mb-3">
                <div class="card-body">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-4">
                            <label class="form-label fw-bold mb-1">HN</label>
                            <div class="input-group">
                                <input type="text" id="searchHn" class="form-control form-control-lg fw-bold text-primary"
                                       placeholder="ระบุ HN" value="<?php echo $prefill_hn; ?>"
                                       onkeypress="if(event.keyCode===13) lookupPatient()">
                                <button class="btn btn-primary fw-bold" type="button" onclick="lookupPatient()">
                                    <i class="fas fa-search me-1"></i>ค้นหา
                                </button>
                            </div>
                        </div>
                        <div class="col-md-8" id="patientBar" style="display:none;">
                            <div class="patient-bar p-3">
                                <div class="d-flex flex-wrap gap-3 align-items-center">
                                    <div><span class="text-muted small">ชื่อ</span><div class="fw-bold" id="ptName">-</div></div>
                                    <div><span class="text-muted small">HN</span><div class="fw-bold" id="ptHn">-</div></div>
                                    <div style="min-width:160px">
                                        <span class="text-muted small">AN (Admit ที่เทียบ)</span>
                                        <select id="ptAnSelect" class="form-select form-select-sm fw-bold" onchange="onAdmitAnChange()">
                                            <option value="">— เลือก AN —</option>
                                        </select>
                                    </div>
                                    <div><span class="text-muted small">หอผู้ป่วย</span><div class="fw-bold" id="ptWard">-</div></div>
                                    <div><span class="text-muted small">Admit</span><div class="fw-bold" id="ptAdmit">-</div></div>
                                    <div><span class="text-muted small">แพ้ยา</span><div id="ptAllergy">-</div></div>
                                </div>
                                <div class="small text-muted mt-1" id="anSourceHint"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-3" id="workspace" style="display:none;">
                <div class="col-lg-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white fw-bold">
                            <i class="fas fa-list-check me-1"></i> ยา ก่อน Admit — เลือก Visit
                        </div>
                        <div class="card-body">
                            <div class="mb-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="preSmart" value="smart">
                                    <label class="form-check-label" for="preSmart">
                                        ใช้จาก <b>Smart Drug Med Recon</b>
                                        <span class="badge bg-secondary" id="smartReconCount">0</span>
                                    </label>
                                    <select id="smartReconPick" class="form-select form-select-sm mt-1" style="display:none"></select>
                                    <div class="small text-muted" id="smartReconHint"></div>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="preHosxp" value="hosxp">
                                    <label class="form-check-label" for="preHosxp">
                                        ใช้จาก <b>Med Recon HOSxP</b>
                                        <span class="badge bg-secondary" id="hosxpReconCount">0</span>
                                    </label>
                                </div>
                                <div class="small text-muted">ติ๊ก Visit ด้านล่างเพื่อเพิ่มยาที่ Med Recon ยังไม่มี ยาที่ซ้ำจะคงรายการจาก Med Recon</div>
                            </div>
                            <div class="d-flex gap-2 mb-2">
                                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="selectVisits(true)">ทั้งหมด</button>
                                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="selectVisits(false)">ล้าง</button>
                            </div>
                            <div id="visitList" class="visit-box"></div>
                            <button type="button" class="btn btn-success fw-bold w-100 mt-3" onclick="runCompare()">
                                <i class="fas fa-balance-scale me-1"></i> เปรียบเทียบกับยา Admit / HME
                            </button>
                            <div class="small text-muted mt-2" id="compareHint"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="card shadow-sm border-0">
                        <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <div class="fw-bold"><i class="fas fa-table me-1"></i> ตารางเปรียบเทียบ</div>
                            <div class="d-flex align-items-center gap-2 flex-wrap">
                                <div class="small text-muted" id="compareMeta"></div>
                                <button type="button" class="btn btn-warning btn-sm fw-bold text-dark" id="btnPrintMrd" onclick="printMrdSummary()" disabled>
                                    <i class="fas fa-file-pdf me-1"></i>พิมพ์ PDF สรุป
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="mrd-table-wrap">
                                <table class="table table-bordered table-sm mb-0 mrd-table">
                                    <thead>
                                    <tr>
                                        <th style="min-width:180px">รายการยา</th>
                                        <th class="col-pre" style="min-width:160px">วิธีใช้ก่อน Admit</th>
                                        <th class="col-admit" style="min-width:160px">วิธีใช้ขณะ Admit</th>
                                        <th class="col-hme" style="min-width:160px">วิธีใช้กลับบ้าน (HME)</th>
                                        <th style="min-width:110px">คำสั่ง (auto)</th>
                                        <th style="min-width:120px">หมายเหตุ</th>
                                        <th style="width:52px"></th>
                                    </tr>
                                    </thead>
                                    <tbody id="compareBody">
                                    <tr><td colspan="7" class="text-center text-muted py-4">ค้นหา HN แล้วกดเปรียบเทียบ</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div><!-- /tabCompare -->

            <div class="tab-pane fade" id="tabSettings" role="tabpanel">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold">
                        <i class="fas fa-cog me-1"></i> ตั้งค่าคำสั่ง auto จากวิธีใช้
                    </div>
                    <div class="card-body">
                        <p class="text-muted small mb-3">
                            ถ้าข้อความวิธีใช้ (โดยเฉพาะ HME) มีคำเหล่านี้ ระบบจะตั้งคำสั่งเป็น <span class="badge badge-off">OFF</span> อัตโนมัติ
                            เช่น <code>hold off</code>, <code>งด</code>
                        </p>
                        <label class="form-label fw-bold">คำสำคัญที่ถือว่า OFF <span class="text-muted fw-normal">(บรรทัดละ 1 คำ หรือคั่นด้วยจุลภาค)</span></label>
                        <textarea id="offKeywordsInput" class="form-control font-monospace" rows="8" placeholder="hold off&#10;งด&#10;หยุดใช้"></textarea>
                        <div class="d-flex flex-wrap gap-2 mt-3">
                            <button type="button" class="btn btn-success fw-bold" onclick="saveMrdSettings()">
                                <i class="fas fa-save me-1"></i>บันทึกตั้งค่า
                            </button>
                            <button type="button" class="btn btn-outline-secondary" onclick="resetMrdSettingsDefaults()">
                                คืนค่าเริ่มต้น
                            </button>
                            <span class="small text-muted align-self-center" id="settingsSaveMsg"></span>
                        </div>
                        <div class="alert alert-light border mt-3 mb-0 small">
                            <div class="fw-bold mb-1">ค่าเริ่มต้น</div>
                            <div id="settingsDefaultsHint">hold off, holdoff, งด, หยุดใช้, หยุดยา, hold</div>
                        </div>
                    </div>
                </div>
            </div><!-- /tabSettings -->
            </div><!-- /tab-content -->
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const SMART_RECON_KEY = 'tham_smart_medrecon_v1';
let patient = null;
let visits = [];
let ipdVisits = [];
let hosxpMedrecon = [];
let smartReconRows = [];
let smartMedreconItems = [];
let compareTimer = null;
let activeFocusVisitKey = '';
let compareSeq = 0;
let mrdSettings = null;
let mrdSettingsDefaults = null;
let lastCompareData = null;
let removedRowKeys = {};
let keptRemarks = {};

async function loadMrdSettings() {
    try {
        const res = await fetch('fetch_med_reconcile_discharge_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'get_settings' })
        });
        const data = await res.json();
        if (data.status !== 'success') {
            $('#settingsSaveMsg').text(data.message || 'โหลดตั้งค่าไม่สำเร็จ');
            return;
        }
        mrdSettings = data.settings || {};
        mrdSettingsDefaults = data.defaults || {};
        const kws = (mrdSettings.off_keywords || []).join('\n');
        $('#offKeywordsInput').val(kws);
        $('#settingsDefaultsHint').text((mrdSettingsDefaults.off_keywords || []).join(', '));
        $('#settingsSaveMsg').text('');
    } catch (e) {
        console.error(e);
        $('#settingsSaveMsg').text('เกิดข้อผิดพลาดในการโหลดตั้งค่า');
    }
}

async function saveMrdSettings() {
    const raw = $('#offKeywordsInput').val() || '';
    const parts = raw.split(/[\n,;]+/).map(s => s.trim()).filter(Boolean);
    try {
        const res = await fetch('fetch_med_reconcile_discharge_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'save_settings', settings: { off_keywords: parts } })
        });
        const data = await res.json();
        if (data.status !== 'success') {
            alert(data.message || 'บันทึกไม่สำเร็จ');
            return;
        }
        mrdSettings = data.settings || {};
        $('#offKeywordsInput').val((mrdSettings.off_keywords || []).join('\n'));
        $('#settingsSaveMsg').html('<span class="text-success">บันทึกแล้ว — กดเปรียบเทียบอีกครั้งเพื่อใช้ค่าใหม่</span>');
        if (patient) runCompare({ quiet: true });
    } catch (e) {
        console.error(e);
        alert('เกิดข้อผิดพลาดในการบันทึก');
    }
}

function resetMrdSettingsDefaults() {
    const defs = (mrdSettingsDefaults && mrdSettingsDefaults.off_keywords)
        ? mrdSettingsDefaults.off_keywords
        : ['hold off', 'holdoff', 'งด', 'หยุดใช้', 'หยุดยา', 'hold'];
    $('#offKeywordsInput').val(defs.join('\n'));
}

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function selectedAdmitAn() {
    return ($('#ptAnSelect').val() || (patient && patient.an) || '').trim();
}

function fillAdmitAnSelect(list, selectedAn) {
    ipdVisits = list || [];
    let html = '<option value="">— เลือก AN —</option>';
    ipdVisits.forEach(v => {
        const an = v.an || '';
        if (!an) return;
        const label = 'AN ' + an + ' · ' + (v.vstdate_display || '') +
            (v.is_active ? ' · ค้างAdmit' : '') +
            (v.ward_name ? ' · ' + v.ward_name : '');
        const sel = (selectedAn && String(selectedAn) === String(an)) ? ' selected' : '';
        html += `<option value="${esc(an)}"${sel}>${esc(label)}</option>`;
    });
    $('#ptAnSelect').html(html);
    if (selectedAn && $('#ptAnSelect option[value="' + selectedAn + '"]').length) {
        $('#ptAnSelect').val(selectedAn);
    } else if (ipdVisits.length && ipdVisits[0].an) {
        $('#ptAnSelect').val(ipdVisits[0].an);
    }
}

function onAdmitAnChange() {
    const an = selectedAdmitAn();
    if (!patient) return;
    patient.an = an;
    const v = ipdVisits.find(x => String(x.an) === String(an));
    if (v) {
        $('#ptWard').text(v.ward_name || '-');
        $('#ptAdmit').text((v.vstdate_display || '-') + (v.vsttime_display ? ' ' + String(v.vsttime_display).substring(0,5) : ''));
        $('#anSourceHint').text(v.is_active ? 'IPD ที่ยังค้าง Admit · วิธีใช้ขณะ Admit จาก BCH+IRx ล่าสุด' : 'ใช้ IPD นี้เทียบ (อาจจำหน่ายแล้ว) · วิธีใช้ขณะ Admit จาก BCH+IRx ล่าสุด');
        if (v.vstdate_iso) patient.admit_date = v.vstdate_iso;
    }
    removedRowKeys = {};
    keptRemarks = {};
    if (applyAdmitSmartDefault()) {
        $('#preHosxp').prop('checked', false);
        clearVisitChecks();
    } else {
        $('#preSmart').prop('checked', false);
        $('#preHosxp').prop('checked', hosxpMedrecon.length > 0);
        clearVisitChecks();
    }
    runCompare();
}

function applySmartPick() {
    const id = String($('#smartReconPick').val() || '');
    const it = smartMedreconItems.find(x => String(x.id) === id);
    smartReconRows = (it && Array.isArray(it.rows)) ? it.rows : [];
}

function smartItemDuringAdmit(it) {
    const an = String(selectedAdmitAn() || (patient && patient.an) || '');
    if (!an || !it) return false;
    if (it.an && String(it.an) === an) return true;
    if (it.vn && String(it.vn) === an) return true;
    const visit = ipdVisits.find(x => String(x.an) === an);
    const admit = String((visit && visit.vstdate_iso) || (patient && patient.admit_date) || '');
    const saved = String(it.saved_at || '').substring(0, 10);
    return !!(admit && saved && saved >= admit);
}

function applyAdmitSmartDefault() {
    const match = smartMedreconItems.find(smartItemDuringAdmit);
    if (!match) return false;
    $('#smartReconPick').val(match.id);
    applySmartPick();
    $('#preSmart').prop('checked', true);
    return true;
}

function renderSmartReconPick(items) {
    smartMedreconItems = items || [];
    if (!smartMedreconItems.length) {
        $('#smartReconPick').hide().html('');
        $('#smartReconHint').text('ยังไม่มีประวัติ Medication Reconciliation ที่บันทึกจาก Smart Drug');
        smartReconRows = [];
        return;
    }
    let html = '';
    smartMedreconItems.forEach(it => {
        const bits = [it.saved_at_th || 'ไม่ทราบวัน'];
        bits.push((it.drug_count || 0) + ' รายการ');
        if (it.vn) bits.push('VN ' + it.vn);
        if (it.an) bits.push('AN ' + it.an);
        if (it.saved_name) bits.push(it.saved_name);
        html += `<option value="${esc(it.id)}">${esc(bits.join(' · '))}</option>`;
    });
    $('#smartReconPick').html(html).show();
    $('#smartReconHint').text('เลือกประวัติที่ทำแล้วจาก Smart Drug');
    applySmartPick();
}

function loadSmartRecon(hn) {
    try {
        const raw = localStorage.getItem(SMART_RECON_KEY);
        if (!raw) return [];
        const all = JSON.parse(raw) || {};
        const pack = all[String(hn).replace(/^0+/, '')] || all[hn] || null;
        if (!pack || !Array.isArray(pack.rows)) return [];
        return pack.rows;
    } catch (e) {
        return [];
    }
}

function hnVariants(hn) {
    const h = String(hn || '').trim();
    if (!h) return [];
    const out = [h];
    if (/^\d+$/.test(h)) {
        out.push(h.padStart(9, '0'));
        out.push(String(parseInt(h, 10)));
    }
    return [...new Set(out)];
}

async function lookupPatient() {
    const hn = $('#searchHn').val().trim();
    if (!hn) { alert('กรุณาระบุ HN'); return; }
    $('#compareBody').html('<tr><td colspan="7" class="text-center text-muted py-4"><i class="fas fa-spinner fa-spin me-1"></i>กำลังโหลด...</td></tr>');
    try {
        const res = await fetch('fetch_med_reconcile_discharge_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'lookup', hn })
        });
        const data = await res.json();
        if (data.status !== 'success') {
            alert(data.message || 'โหลดไม่สำเร็จ');
            return;
        }
        patient = data.patient;
        visits = data.visits || [];
        hosxpMedrecon = data.hosxp_medrecon || [];
        removedRowKeys = {};
        keptRemarks = {};

        let smartItems = data.smart_medrecon || [];
        if (!smartItems.length) {
            let localRows = [];
            hnVariants(patient.hn).forEach(v => {
                const rows = loadSmartRecon(v);
                if (rows.length && !localRows.length) localRows = rows;
            });
            if (localRows.length) {
                smartItems = [{
                    id: 'browser',
                    saved_at_th: 'ในเบราว์เซอร์นี้',
                    drug_count: localRows.length,
                    rows: localRows
                }];
            }
        }
        renderSmartReconPick(smartItems);

        $('#ptName').text(patient.full_name || '-');
        $('#ptHn').text(patient.hn || '-');
        fillAdmitAnSelect(data.ipd_visits || [], patient.an || '');
        if (selectedAdmitAn()) patient.an = selectedAdmitAn();
        $('#ptWard').text(patient.ward_name || '-');
        $('#ptAdmit').text((patient.admit_date || '-') + (patient.admit_time ? ' ' + String(patient.admit_time).substring(0,5) : ''));
        const srcHint = {
            active: 'พบ IPD ที่ยังค้าง Admit · วิธีใช้ขณะ Admit จาก BCH+IRx ล่าสุด',
            latest_ipd: 'ไม่พบค้าง Admit — ใช้ IPD ล่าสุดเทียบ · วิธีใช้ขณะ Admit จาก BCH+IRx ล่าสุด',
            selected: 'ใช้ AN ที่เลือก · วิธีใช้ขณะ Admit จาก BCH+IRx ล่าสุด'
        };
        $('#anSourceHint').text(
            patient.an
                ? ((srcHint[patient.an_source] || 'พร้อมเทียบยา Admit/HME') + ' · AN ' + patient.an)
                : 'ไม่พบ IPD — เลือก AN จากรายการ Visit ประเภท IPD หรือตรวจว่ามี admit ใน HOSxP'
        );
        const al = patient.allergy || {};
        if (al.has_allergy) {
            $('#ptAllergy').html('<span class="allergy-yes">Yes — ' + esc(al.text || '') + '</span>');
        } else {
            $('#ptAllergy').html('<span class="allergy-ok">NO<br>ไม่แพ้ยา (HOSxP)</span>');
        }
        $('#patientBar').show();
        $('#workspace').show();
        $('#smartReconCount').text(String(smartMedreconItems.length));
        $('#hosxpReconCount').text(String((data.hosxp_medrecon_count || hosxpMedrecon.length || 0)));

        const useSmart = applyAdmitSmartDefault();
        if (!useSmart) {
            $('#preSmart').prop('checked', false);
            $('#preHosxp').prop('checked', hosxpMedrecon.length > 0);
        } else {
            $('#preHosxp').prop('checked', false);
        }

        renderVisits((useSmart || $('#preHosxp').prop('checked')) ? [] : (data.default_visit_keys || []));
        $('#compareHint').text('ใช้ Smart Drug แล้วติ๊ก Visit เพิ่มได้ · ยาที่ซ้ำคงรายการจาก Med Recon · กดลบที่แถวเพื่อเอารายการออก');
        runCompare();
    } catch (e) {
        console.error(e);
        alert('เกิดข้อผิดพลาดในการเชื่อมต่อ');
    }
}

function renderVisits(defaultKeys) {
    const set = {};
    (defaultKeys || []).forEach(k => { set[k] = true; });
    if (!visits.length) {
        $('#visitList').html('<div class="p-3 text-muted small">ไม่พบ Visit OPD มียา หรือ IPD ที่มี HME</div>');
        return;
    }
    let html = '';
    visits.forEach(v => {
        const checked = set[v.visit_key] ? ' checked' : '';
        const type = v.visit_type === 'ipd' ? 'IPD·HME' : 'OPD';
        const badge = v.visit_type === 'ipd' ? 'bg-warning text-dark' : 'bg-primary';
        const active = v.is_active ? ' · ค้างAdmit' : '';
        const countLabel = v.visit_type === 'ipd'
            ? ((v.hme_count || 0) + ' HME')
            : ((v.drug_count || 0) + ' ยา');
        const apptHtml = v.nextdate_display
            ? `<span class="text-success small ms-1">นัดมา ${esc(v.nextdate_display)}</span>`
            : '';
        html += `<label class="visit-row mb-0" data-visit-key="${esc(v.visit_key)}">
            <input type="checkbox" class="form-check-input mt-1 visit-cb" value="${esc(v.visit_key)}"${checked}>
            <span class="flex-grow-1">
                <span class="fw-bold">${esc(v.vstdate_display || '-')}</span>
                <span class="text-muted small ms-1">${esc((v.vsttime_display || '').substring(0,5))}</span>
                ${apptHtml}
                <span class="badge ${badge} ms-1">${type}</span>${active}
                <div class="small text-muted">${v.visit_type === 'ipd' ? ('AN ' + esc(v.an)) : ('VN ' + esc(v.vn))}
                    · ${countLabel}${v.ward_name ? ' · ' + esc(v.ward_name) : ''}</div>
            </span>
        </label>`;
    });
    $('#visitList').html(html);
}

function markFocusVisitRow(visitKey, doBlink) {
    $('#visitList .visit-row').removeClass('is-focus is-blink');
    if (!visitKey) return;
    const $row = $('#visitList .visit-row').filter(function () {
        return $(this).attr('data-visit-key') === visitKey;
    });
    $row.addClass('is-focus');
    if (doBlink) {
        void $row[0] && $row[0].offsetWidth;
        $row.addClass('is-blink');
        setTimeout(() => $row.removeClass('is-blink'), 1800);
    }
}

function scheduleCompareFromVisit(visitKey) {
    activeFocusVisitKey = visitKey || '';
    if (visitKey) markFocusVisitRow(visitKey, true);
    if (compareTimer) clearTimeout(compareTimer);
    compareTimer = setTimeout(() => {
        runCompare({ quiet: true, focusVisitKey: activeFocusVisitKey, blink: true });
    }, 180);
}

function clearVisitChecks() {
    $('#visitList .visit-cb').prop('checked', false);
    activeFocusVisitKey = '';
    markFocusVisitRow('', false);
}

function selectVisits(all) {
    $('#visitList .visit-cb').prop('checked', !!all);
    activeFocusVisitKey = '';
    markFocusVisitRow('', false);
    if (compareTimer) clearTimeout(compareTimer);
    compareTimer = setTimeout(() => runCompare({ quiet: true }), 180);
}

function selectedVisitKeys() {
    const keys = [];
    $('#visitList .visit-cb:checked').each(function () { keys.push(this.value); });
    return keys;
}

function actionLabel(action) {
    const map = { continue: 'Cont', off: 'OFF', up: 'UP', down: 'Down', change: 'Change', new: 'New' };
    return map[action] || '—';
}

function collectRemarksFromTable() {
    const remarks = [];
    $('#compareBody tr').each(function () {
        const v = $(this).find('input[type="text"]').val();
        remarks.push(v == null ? '' : String(v));
    });
    return remarks;
}

function buildMrdPrintHtml(data) {
    const p = data.patient || patient || {};
    const sum = data.summary || {};
    const rows = data.rows || [];
    const remarks = collectRemarksFromTable();
    const now = new Date();
    const printAt = now.toLocaleString('th-TH', { dateStyle: 'medium', timeStyle: 'short' });
    const allergy = p.allergy || {};
    const allergyText = allergy.has_allergy
        ? ('Yes — ' + (allergy.text || ''))
        : 'NO ไม่แพ้ยา (HOSxP)';
    const preSrc = preSourceText(data.pre_source);
    let bchLine = '';
    if (data.bch_order && data.bch_order.order_no) {
        bchLine += 'BCH ' + data.bch_order.order_no;
        if (data.bch_order.rxdate) bchLine += ' (' + data.bch_order.rxdate + ')';
    }
    if (data.irx_order && data.irx_order.order_no) {
        bchLine += (bchLine ? ' · ' : '') + 'IRx ' + data.irx_order.order_no;
        if (data.irx_order.rxdate) bchLine += ' (' + data.irx_order.rxdate + ')';
    }
    if (!bchLine) bchLine = '-';

    let body = '';
    rows.forEach((r, i) => {
        const remark = remarks[i] != null ? remarks[i] : (r.remark || '');
        const act = actionLabel(r.action || '');
        const actClass = (r.action === 'off') ? 'act-off'
            : (r.action === 'continue') ? 'act-cont'
            : (r.action === 'up') ? 'act-up'
            : (r.action === 'down') ? 'act-down'
            : (r.action === 'change') ? 'act-change'
            : (r.action === 'new') ? 'act-new' : '';
        const admitTag = r.admit_order_type ? `<div class="tag">${esc(r.admit_order_type)}</div>` : '';
        body += `<tr>
            <td class="n">${i + 1}</td>
            <td class="drug"><div class="dn">${esc(r.display_name || '-')}</div>
                ${r.icode ? `<div class="meta">icode ${esc(r.icode)}</div>` : ''}</td>
            <td class="pre">${r.pre_method ? esc(r.pre_method) : '—'}${r.pre_hospital ? `<div class="meta">${esc(r.pre_hospital)}</div>` : ''}</td>
            <td class="admit">${r.admit_method ? esc(r.admit_method) : '—'}${admitTag}</td>
            <td class="hme">${r.hme_method ? esc(r.hme_method) : '—'}</td>
            <td class="act ${actClass}">${esc(act)}</td>
            <td class="note">${esc(remark)}</td>
        </tr>`;
    });
    if (!rows.length) {
        body = '<tr><td colspan="7" class="empty">ไม่พบรายการยา</td></tr>';
    }

    return `<!DOCTYPE html>
<html lang="th"><head><meta charset="UTF-8">
<title>Med Reconcile สรุป — ${esc(p.hn || '')}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Sarabun:wght@400;600;700&display=swap');
*{box-sizing:border-box}
body{font-family:'Sarabun',Tahoma,sans-serif;font-size:11px;color:#111;margin:12px;background:#fff}
.no-print{margin-bottom:10px}
.btn-print{background:#ffc107;border:0;padding:8px 14px;font-weight:800;border-radius:6px;cursor:pointer}
h1{font-size:18px;margin:0 0 2px;font-weight:800}
.sub{color:#555;margin-bottom:10px}
.meta{display:grid;grid-template-columns:1fr 1fr;gap:8px 16px;border:1px solid #333;padding:8px 10px;margin-bottom:10px;border-radius:4px}
.meta .k{color:#555;font-size:10px}
.meta .v{font-weight:700;font-size:12px}
.stats{margin-bottom:8px;font-size:11px}
.stats b{margin-right:6px}
table{width:100%;border-collapse:collapse;table-layout:fixed}
th,td{border:1px solid #333;padding:4px 5px;vertical-align:top;word-wrap:break-word}
th{background:#eef5f1;font-size:10px;text-align:center}
td.n{width:28px;text-align:center}
td.drug{width:18%}
td.pre,td.admit,td.hme{width:18%}
td.act{width:8%;text-align:center;font-weight:800}
td.note{width:12%}
.dn{font-weight:700;color:#0b5ed7}
.meta,.tag{font-size:9px;color:#666}
.tag{display:inline-block;background:#e7f1ff;border:1px solid #9ec5fe;padding:0 4px;border-radius:3px;margin-top:2px;font-weight:700;color:#084298}
.act-off{background:#f8d7da;color:#842029}
.act-cont{background:#d1e7dd;color:#0f5132}
.act-up{background:#cfe2ff;color:#084298}
.act-down{background:#f7d6e6;color:#a4133c}
.act-change{background:#ffe5d0;color:#984c0c}
.act-new{background:#e2d9f3;color:#59359a}
.empty{text-align:center;color:#888;padding:16px}
.sign{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-top:18px}
.sign .box{border-top:1px solid #333;padding-top:6px;text-align:center;min-height:54px}
.foot{margin-top:10px;font-size:10px;color:#555}
@media print{
  .no-print{display:none!important}
  body{margin:6mm}
  @page{size:A4 landscape;margin:8mm}
}
</style></head><body>
<div class="no-print"><button class="btn-print" onclick="window.print()">พิมพ์ / บันทึก PDF</button>
<span style="margin-left:8px;color:#666">เลือกเครื่องพิมพ์เป็น “Save as PDF” ได้</span></div>
<h1>สรุป Medication Reconciliation (ยากลับบ้าน)</h1>
<div class="sub">THAM Hos-Safe · พิมพ์เมื่อ ${esc(printAt)}</div>
<div class="meta">
  <div><div class="k">ชื่อผู้ป่วย</div><div class="v">${esc(p.full_name || '-')}</div></div>
  <div><div class="k">HN / AN</div><div class="v">${esc(p.hn || '-')} / ${esc(data.an || p.an || '-')}</div></div>
  <div><div class="k">หอผู้ป่วย</div><div class="v">${esc(p.ward_name || '-')}</div></div>
  <div><div class="k">Admit</div><div class="v">${esc((p.admit_date || '-') + (p.admit_time ? ' ' + String(p.admit_time).substring(0,5) : ''))}</div></div>
  <div><div class="k">แพ้ยา</div><div class="v">${esc(allergyText)}</div></div>
  <div><div class="k">แหล่งก่อน Admit / Order Admit</div><div class="v">${esc(preSrc)} · ${esc(bchLine)}</div></div>
</div>
<div class="stats">
  <b>ก่อน Admit:</b>${sum.pre_count || 0}
  <b>Admit:</b>${sum.admit_count || 0}
  <b>HME:</b>${sum.hme_count || 0}
  <b>รวม:</b>${sum.row_count || 0} แถว
  · Cont ${sum.auto_cont || 0} / OFF ${sum.auto_off || 0} / UP ${sum.auto_up || 0} / Down ${sum.auto_down || 0} / Change ${sum.auto_change || 0} / New ${sum.auto_new || 0}
</div>
<table>
  <thead>
    <tr>
      <th>#</th>
      <th>รายการยา</th>
      <th>วิธีใช้ก่อน Admit</th>
      <th>วิธีใช้ขณะ Admit</th>
      <th>วิธีใช้กลับบ้าน (HME)</th>
      <th>คำสั่ง</th>
      <th>หมายเหตุ</th>
    </tr>
  </thead>
  <tbody>${body}</tbody>
</table>
<div class="sign">
  <div class="box">ผู้จัดทำ Med Reconcile<br>.............................</div>
  <div class="box">เภสัชกรผู้ตรวจสอบ<br>.............................</div>
  <div class="box">แพทย์ผู้สั่งกลับบ้าน<br>.............................</div>
</div>
<div class="foot">เอกสารสรุปจากระบบ THAM Hos-Safe — ใช้ประกอบการจำหน่ายผู้ป่วย / Medication Reconciliation</div>
<script>window.onload=function(){setTimeout(function(){window.print();},350);};<\/script>
</body></html>`;
}

function printMrdSummary() {
    if (!patient) {
        alert('กรุณาค้นหา HN และเปรียบเทียบก่อน');
        return;
    }
    if (!lastCompareData || !(lastCompareData.rows || []).length) {
        if (!confirm('ยังไม่มีรายการเปรียบเทียบ — พิมพ์แบบฟอร์มว่างหรือไม่?')) return;
    }
    try {
        const payload = lastCompareData || {
            patient: patient,
            an: selectedAdmitAn() || patient.an || '',
            rows: [],
            summary: {},
            pre_source: '',
            bch_order: null,
            irx_order: null
        };
        payload.patient = Object.assign({}, patient, payload.patient || {});
        const html = buildMrdPrintHtml(payload);
        const w = window.open('', '_blank');
        if (w) {
            w.document.open();
            w.document.write(html);
            w.document.close();
            return;
        }
        // fallback iframe
        let iframe = document.getElementById('mrdPrintFrame');
        if (!iframe) {
            iframe = document.createElement('iframe');
            iframe.id = 'mrdPrintFrame';
            iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
            document.body.appendChild(iframe);
        }
        const doc = iframe.contentWindow || iframe.contentDocument;
        const idoc = doc.document || doc;
        idoc.open();
        idoc.write(html);
        idoc.close();
    } catch (e) {
        console.error(e);
        alert('พิมพ์ไม่สำเร็จ: ' + (e && e.message ? e.message : String(e)));
    }
}

function actionBadgeFixed(selected, reason) {
    const map = {
        continue: { l: 'Cont', cls: 'badge-cont' },
        off: { l: 'OFF', cls: 'badge-off' },
        up: { l: 'UP', cls: 'badge-up' },
        down: { l: 'Down', cls: 'badge-down' },
        change: { l: 'Change', cls: 'badge-change' },
        new: { l: 'New', cls: 'badge-new' }
    };
    const m = map[selected] || { l: '—', cls: 'badge-none' };
    const tip = reason ? ` title="${esc(reason)}"` : '';
    return `<span class="badge ${m.cls}"${tip}>${m.l}</span>`;
}

function methodCell(text, qty, date, orderType) {
    if (!text && (qty == null || qty === '') && !orderType) {
        return '<span class="mrd-empty">—</span>';
    }
    let h = '';
    h += text ? `<div class="mrd-method">${esc(text)}</div>` : '<span class="mrd-empty">—</span>';
    const meta = [];
    if (qty != null && qty !== '' && !isNaN(qty) && Number(qty) > 0) meta.push('qty ' + qty);
    if (date) meta.push(String(date));
    if (meta.length) h += `<div class="small text-muted">${esc(meta.join(' · '))}</div>`;
    const ot = String(orderType || '').trim();
    if (ot) {
        const cls = ot.toUpperCase() === 'BCH' ? 'bch' : (ot.toUpperCase() === 'IRX' ? 'irx' : 'other');
        h += `<div class="mt-1"><span class="order-type-tag ${cls}">${esc(ot)}</span></div>`;
    }
    return h;
}

function orderChip(order, label) {
    if (!order || !order.order_no) return '';
    const bt = order.rxtime ? String(order.rxtime).substring(0,5) : '';
    return ` <span class="src-chip hosxp">${esc(label)} ${esc(order.order_no)}${order.rxdate ? (' · ' + esc(order.rxdate) + (bt ? ' ' + esc(bt) : '')) : ''}</span>`;
}

function preSourceText(code) {
    const map = {
        smart_drug_medrecon: 'Smart Drug Med Recon',
        hosxp_medrecon: 'Med Recon HOSxP',
        visit: 'Visit ที่เลือก'
    };
    const parts = String(code || '').split('+').filter(Boolean).map(k => map[k] || k);
    return parts.length ? parts.join(' + ') : '-';
}

function rowRemoveKey(r) {
    return String((r && (r.row_key || r.icode || r.display_name)) || '');
}

function summaryFromRows(rows, base) {
    const s = Object.assign({}, base || {});
    const list = rows || [];
    const n = (pred) => list.filter(pred).length;
    s.row_count = list.length;
    s.pre_count = n(r => r.flags && r.flags.has_pre);
    s.admit_count = n(r => r.flags && r.flags.has_admit);
    s.hme_count = n(r => r.flags && r.flags.has_hme);
    s.with_hme = s.hme_count;
    s.pre_only = n(r => r.flags && r.flags.has_pre && !r.flags.has_admit && !r.flags.has_hme);
    s.auto_cont = n(r => r.action === 'continue');
    s.auto_off = n(r => r.action === 'off');
    s.auto_up = n(r => r.action === 'up');
    s.auto_down = n(r => r.action === 'down');
    s.auto_change = n(r => r.action === 'change');
    s.auto_new = n(r => r.action === 'new');
    return s;
}

function visibleCompareRows(rows) {
    return (rows || []).filter(r => !removedRowKeys[rowRemoveKey(r)]);
}

function syncRemarksInto(rows) {
    const list = rows || [];
    $('#compareBody tr').each(function (i) {
        if (!list[i]) return;
        const v = $(this).find('input[type="text"]').val();
        list[i].remark = v == null ? '' : String(v);
    });
}

function paintCompareTable(focusKey, doBlink) {
    const data = lastCompareData || {};
    const sum = data.summary || {};
    const anUsed = data.an || selectedAdmitAn() || '';
    let admitHint = '';
    if (sum.admit_missing && anUsed) {
        admitHint = ' <span class="text-danger">· ยังไม่พบยา Admit (BCH/IRx) ของ AN ' + esc(anUsed) + ' — ลองเปลี่ยน AN ด้านบน</span>';
    }
    let bchChip = orderChip(data.bch_order, 'BCH') + orderChip(data.irx_order, 'IRx');
    if (!bchChip && data.admit_source === 'medplan') {
        bchChip = ' <span class="src-chip visit">Admit = Medplan (ไม่มี BCH/IRx)</span>';
    }
    $('#compareMeta').html(
        (data.src_chips || '') +
        bchChip +
        ` · AN ${esc(anUsed || '-')}` +
        ` · ก่อน ${sum.pre_count || 0} · Admit ${sum.admit_count || 0} · HME ${sum.hme_count || 0} · รวม ${sum.row_count || 0} แถว` +
        ` · auto Cont ${sum.auto_cont || 0} / OFF ${sum.auto_off || 0} / UP ${sum.auto_up || 0} / Down ${sum.auto_down || 0} / Change ${sum.auto_change || 0} / New ${sum.auto_new || 0}` +
        admitHint
    );
    const rows = data.rows || [];
    $('#btnPrintMrd').prop('disabled', !rows.length);
    if (!rows.length) {
        $('#compareBody').html('<tr><td colspan="7" class="text-center text-muted py-4">ไม่พบรายการยา</td></tr>');
        return;
    }
    let html = '';
    rows.forEach((r) => {
        const tipReason = r.action_reason
            ? `${r.action_reason}${r.admit_mg != null || r.hme_mg != null ? (' · Admit ' + (r.admit_mg != null ? r.admit_mg : '-') + ' / HME ' + (r.hme_mg != null ? r.hme_mg : '-') + ' mg/วัน') : ''}`
            : '';
        const pvk = r.pre_visit_key || '';
        const key = rowRemoveKey(r);
        const hlCls = (focusKey && pvk && pvk === focusKey) ? ' mrd-hl-pre' : '';
        const blinkCls = (hlCls && doBlink) ? ' is-blink' : '';
        html += `<tr class="${(hlCls + blinkCls).trim()}" data-pre-visit="${esc(pvk)}" data-row-key="${esc(key)}">
            <td><div class="mrd-drug">${esc(r.display_name || '-')}</div>
                ${r.icode ? `<div class="small text-muted">icode ${esc(r.icode)}</div>` : ''}
                ${r.pre_source ? `<div class="small text-muted">${esc(r.pre_source)}</div>` : ''}
            </td>
            <td class="col-pre">${methodCell(r.pre_method, r.pre_qty, r.pre_date)}${r.pre_hospital ? `<div class="small fw-bold text-primary">${esc(r.pre_hospital)}</div>` : ''}</td>
            <td class="col-admit">${methodCell(r.admit_method, r.admit_qty, r.admit_date, r.admit_order_type)}</td>
            <td class="col-hme">${methodCell(r.hme_method, r.hme_qty, r.hme_date)}</td>
            <td>${actionBadgeFixed(r.action || '', tipReason)}</td>
            <td><input type="text" class="form-control form-control-sm" value="${esc(r.remark || '')}"></td>
            <td class="text-center"><button type="button" class="btn btn-outline-danger btn-sm mrd-row-del" data-row-key="${esc(key)}" title="เอารายการนี้ออก">ลบ</button></td>
        </tr>`;
    });
    $('#compareBody').html(html);
}

function removeCompareRow(key) {
    if (!lastCompareData || !key) return;
    syncRemarksInto(lastCompareData.rows);
    const keptRemark = {};
    (lastCompareData.rows || []).forEach(r => {
        const k = rowRemoveKey(r);
        if (k && k !== key) keptRemark[k] = r.remark || '';
    });
    removedRowKeys[key] = true;
    const rows = visibleCompareRows(lastCompareData.raw_rows || lastCompareData.rows || []).map(r => {
        const k = rowRemoveKey(r);
        if (keptRemark[k] != null) r.remark = keptRemark[k];
        return r;
    });
    lastCompareData.rows = rows;
    const missing = lastCompareData.summary && lastCompareData.summary.admit_missing;
    lastCompareData.summary = summaryFromRows(rows, lastCompareData.summary || {});
    if (missing) lastCompareData.summary.admit_missing = 1;
    paintCompareTable(activeFocusVisitKey, false);
}

async function runCompare(opts) {
    opts = opts || {};
    if (!patient) {
        if (!opts.quiet) alert('กรุณาค้นหา HN ก่อน');
        return;
    }
    const body = {
        action: 'compare',
        hn: patient.hn,
        an: selectedAdmitAn() || patient.an || '',
        visit_keys: selectedVisitKeys(),
        prefer_smart_recon: $('#preSmart').prop('checked') ? 1 : 0,
        prefer_hosxp_recon: $('#preHosxp').prop('checked') ? 1 : 0,
        smart_recon_rows: $('#preSmart').prop('checked') ? smartReconRows : []
    };
    if (!body.an) {
        if (!opts.quiet) {
            alert('ไม่พบ AN สำหรับเทียบยา Admit — กรุณาเลือก AN จากช่อง AN (Admit ที่เทียบ) หรือมี Visit ประเภท IPD');
        }
        return;
    }
    $('#compareBody tr').each(function () {
        const k = $(this).attr('data-row-key') || '';
        if (!k) return;
        keptRemarks[k] = $(this).find('input[type="text"]').val() || '';
    });
    const seq = ++compareSeq;
    const focusKey = opts.focusVisitKey || activeFocusVisitKey || '';
    const doBlink = !!opts.blink;
    if (!opts.quiet) {
        $('#compareBody').html('<tr><td colspan="7" class="text-center text-muted py-4"><i class="fas fa-spinner fa-spin me-1"></i>กำลังเปรียบเทียบ...</td></tr>');
    }
    try {
        const res = await fetch('fetch_med_reconcile_discharge_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const data = await res.json();
        if (seq !== compareSeq) return;
        if (data.status !== 'success') {
            if (!opts.quiet) alert(data.message || 'เปรียบเทียบไม่สำเร็จ');
            return;
        }
        const srcMap = {
            smart_drug_medrecon: '<span class="src-chip smart">ก่อน Admit = Smart Drug Med Recon</span>',
            hosxp_medrecon: '<span class="src-chip hosxp">ก่อน Admit = Med Recon HOSxP</span>',
            visit: '<span class="src-chip visit">ก่อน Admit = Visit ที่เลือก</span>'
        };
        const srcChips = String(data.pre_source || '').split('+').filter(Boolean).map(k => srcMap[k] || '').join(' ');
        if (data.patient) {
            patient = Object.assign({}, patient, data.patient);
            if (data.an) patient.an = data.an;
            $('#ptWard').text(patient.ward_name || '-');
            $('#ptAdmit').text((patient.admit_date || '-') + (patient.admit_time ? ' ' + String(patient.admit_time).substring(0,5) : ''));
            if (data.an && $('#ptAnSelect option[value="' + data.an + '"]').length) {
                $('#ptAnSelect').val(data.an);
            }
        }
        const serverSum = data.summary || {};
        const rows = visibleCompareRows(data.rows || []).map(r => {
            const k = rowRemoveKey(r);
            if (k && keptRemarks[k] != null && keptRemarks[k] !== '') r.remark = keptRemarks[k];
            return r;
        });
        const sum = summaryFromRows(rows, serverSum);
        if (!(serverSum.admit_count > 0)) sum.admit_missing = 1;
        lastCompareData = {
            patient: data.patient || patient,
            an: data.an || selectedAdmitAn() || '',
            pre_source: data.pre_source || '',
            bch_order: data.bch_order || null,
            irx_order: data.irx_order || null,
            admit_source: data.admit_source || '',
            src_chips: srcChips,
            summary: sum,
            raw_rows: data.rows || [],
            rows: rows
        };
        paintCompareTable(focusKey, doBlink);
        if (focusKey) {
            markFocusVisitRow(focusKey, doBlink);
            const $hl = $('#compareBody tr.mrd-hl-pre');
            if ($hl.length) {
                const wrap = document.querySelector('.mrd-table-wrap');
                if (wrap && $hl[0]) {
                    wrap.scrollTop = Math.max(0, $hl[0].offsetTop - 40);
                }
                if (doBlink) {
                    setTimeout(() => $hl.removeClass('is-blink'), 2000);
                }
            }
        }
    } catch (e) {
        console.error(e);
        if (!opts.quiet) alert('เกิดข้อผิดพลาดในการเปรียบเทียบ');
    }
}

$(function () {
    $(document).on('change', '#visitList .visit-cb', function () {
        const key = $(this).val() || '';
        if (!$(this).is(':checked') && activeFocusVisitKey === key) {
            // ยกเลิกติ๊ก Visit ที่โฟกัสอยู่ — ค้างไฮไลต์ถ้ายังมี Visit อื่นที่ติ๊กไว้ล่าสุด
            const remain = selectedVisitKeys();
            activeFocusVisitKey = remain.length ? remain[remain.length - 1] : '';
            markFocusVisitRow(activeFocusVisitKey, false);
            if (compareTimer) clearTimeout(compareTimer);
            compareTimer = setTimeout(() => {
                runCompare({ quiet: true, focusVisitKey: activeFocusVisitKey, blink: false });
            }, 180);
            return;
        }
        scheduleCompareFromVisit(key);
    });
    $(document).on('change', '#smartReconPick', function () {
        applySmartPick();
        $('#preSmart').prop('checked', true);
        if (compareTimer) clearTimeout(compareTimer);
        compareTimer = setTimeout(() => runCompare({ quiet: true }), 120);
    });
    $(document).on('change', '#preSmart, #preHosxp', function () {
        if (compareTimer) clearTimeout(compareTimer);
        compareTimer = setTimeout(() => runCompare({ quiet: true }), 120);
    });
    $(document).on('click', '.mrd-row-del', function () {
        removeCompareRow(String($(this).attr('data-row-key') || ''));
    });
    if ($('#searchHn').val().trim()) lookupPatient();
});
</script>
</body>
</html>
