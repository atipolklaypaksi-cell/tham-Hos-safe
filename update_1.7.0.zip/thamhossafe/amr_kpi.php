<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/amr_kpi_helper.php';
mysqli_set_charset($con, 'utf8');
$settings = amr_kpi_settings_get($con);
$year_now = (int)date('Y');
$cal_now_be = $year_now + 543;
$default_start = sprintf('%04d-01-01', $year_now);
$default_end = date('Y-m-d');
$cal_buttons = [2567, 2568, 2569, 2570];
if (!in_array($cal_now_be, $cal_buttons, true)) {
    $cal_buttons[] = $cal_now_be;
    sort($cal_buttons);
}
session_write_close();

function amr_kpi_icd_textarea(array $rows) {
    $lines = [];
    foreach ($rows as $r) {
        if (isset($r['active']) && !(int)$r['active']) {
            continue;
        }
        $p = trim((string)($r['icd_prefix'] ?? ''));
        if ($p === '') {
            continue;
        }
        $label = trim((string)($r['label'] ?? ''));
        $lines[] = $label !== '' ? ($p . ' | ' . $label) : $p;
    }
    return implode("\n", $lines);
}
$cap_text = amr_kpi_icd_textarea($settings['cap_icd'] ?? []);
$immuno_text = amr_kpi_icd_textarea($settings['immuno_icd'] ?? []);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>KPI AMR — CAP Medium watch</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        :root {
            --amr-ink: #12261c;
            --amr-muted: #5f7468;
            --amr-line: #d7e4dc;
            --amr-card: #ffffff;
            --amr-soft: #eef6f1;
            --amr-page: #e8f1ec;
            --amr-teal: #0f766e;
            --amr-ok: #059669;
            --amr-amber: #d97706;
            --amr-rose: #e11d48;
        }
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: var(--amr-page); color: var(--amr-ink); }
        #content.amr-content { background: var(--amr-page); }
        .abg-hero { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; flex-wrap: wrap; margin-bottom: 18px; }
        .abg-kicker { font-size: .78rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: var(--amr-teal); }
        .abg-title { font-size: 1.7rem; font-weight: 800; margin: 0; }
        .abg-sub { color: var(--amr-muted); margin: 4px 0 0; max-width: 54rem; }
        .kpi-def {
            background: #f4faf7; border: 1px solid var(--amr-line); border-radius: 16px;
            padding: 16px 18px; margin-bottom: 16px;
        }
        .kpi-def h2 { font-size: .95rem; font-weight: 800; margin: 0 0 6px; color: var(--amr-teal); }
        .kpi-def .def-code { font-size: .78rem; font-weight: 700; color: var(--amr-muted); margin-bottom: 2px; }
        .kpi-def .def-name { font-size: 1.05rem; font-weight: 800; margin: 0 0 2px; }
        .kpi-def .def-en { font-size: .82rem; color: var(--amr-muted); font-style: italic; margin: 0 0 10px; }
        .kpi-def .def-formula {
            background: #fff; border: 1px dashed var(--amr-line); border-radius: 10px;
            padding: 8px 12px; font-weight: 700; font-size: .88rem; margin: 8px 0 12px;
        }
        .kpi-def dl { margin: 0; }
        .kpi-def dt { font-size: .72rem; font-weight: 700; color: var(--amr-muted); text-transform: uppercase; letter-spacing: .04em; margin-top: 8px; }
        .kpi-def dd { margin: 2px 0 0; font-size: .88rem; }
        .kpi-def ul { margin: 4px 0 0; padding-left: 1.15rem; }
        .kpi-def li { margin-bottom: 3px; }
        .kpi-def .meta-row { font-size: .8rem; color: var(--amr-muted); margin-bottom: 8px; }
        .kpi-def table.tgt { font-size: .78rem; margin-top: 6px; }
        .kpi-def table.tgt th { background: #0f766e; color: #fff; font-weight: 700; }
        .kpi-local { font-size: .82rem; background: #fff; border-radius: 10px; padding: 8px 12px; margin-top: 10px; }
        .abg-card {
            background: var(--amr-card); border: 1px solid var(--amr-line); border-radius: 16px;
            padding: 16px 18px; margin-bottom: 16px; box-shadow: 0 8px 24px rgba(15, 36, 25, .04);
        }
        .abg-label { font-size: .72rem; font-weight: 700; color: var(--amr-muted); text-transform: uppercase; letter-spacing: .04em; margin-bottom: 4px; }
        .abg-card .form-control, .abg-card .form-select { border-radius: 10px; border-color: var(--amr-line); background: var(--amr-soft); }
        .abg-range-btn { border-radius: 999px !important; font-weight: 700; font-size: .8rem; }
        .abg-range-btn.active { background: var(--amr-teal); border-color: var(--amr-teal); color: #fff; }
        .kpi-box { text-align: center; padding: 12px 8px; }
        .kpi-box .n { font-size: 1.85rem; font-weight: 800; line-height: 1.1; color: var(--amr-teal); }
        .kpi-box .n.rose { color: var(--amr-rose); }
        .kpi-box .l { font-size: .8rem; color: var(--amr-muted); font-weight: 600; margin-top: 4px; }
        .kpi-box .s { font-size: .75rem; color: var(--amr-ink); font-weight: 700; }
        .pop-pill { display: inline-block; background: var(--amr-soft); border: 1px solid var(--amr-line); border-radius: 999px; padding: 4px 10px; font-size: .78rem; font-weight: 700; margin: 0 4px 6px 0; }
        .abg-note { font-size: .82rem; color: var(--amr-muted); }
        .abg-status.err { color: var(--amr-rose); }
        .abg-tabs .btn { border-radius: 999px; font-weight: 700; font-size: .8rem; }
        table.kpi-table { font-size: .82rem; }
        table.kpi-table th { background: #0f766e; color: #fff; font-weight: 700; white-space: nowrap; }
        table.kpi-table td { vertical-align: middle; }
        .tag-yes { color: var(--amr-rose); font-weight: 800; }
        .tag-no { color: var(--amr-ok); font-weight: 700; }
        .icd-area { font-family: ui-monospace, Menlo, Consolas, monospace; font-size: .8rem; min-height: 220px; }
        .verdict { border-radius: 16px; padding: 16px 18px; margin-bottom: 16px; border: 1px solid var(--amr-line); }
        .verdict.pass { background: #ecfdf5; border-color: #a7f3d0; }
        .verdict.fail { background: #fef2f2; border-color: #fecaca; }
        .verdict.wait { background: #fffbeb; border-color: #fde68a; }
        .verdict .v-title { font-size: 1.05rem; font-weight: 800; margin-bottom: 4px; }
        .verdict.pass .v-title { color: #047857; }
        .verdict.fail .v-title { color: #be123c; }
        .verdict.wait .v-title { color: #b45309; }
        .verdict .v-sub { font-size: .85rem; color: var(--amr-muted); }
        table.judge-table { font-size: .82rem; }
        table.judge-table th { background: #0f766e; color: #fff; }
        table.judge-table tr.fy-now { background: #ecfdf5; }
        .fy-hint { background: #fff; border: 1px dashed var(--amr-line); border-radius: 10px; padding: 8px 12px; font-size: .82rem; margin-top: 8px; }
        .badge-pass { background: #d1fae5; color: #047857; font-weight: 800; border-radius: 999px; padding: 2px 8px; font-size: .75rem; }
        .badge-fail { background: #fee2e2; color: #be123c; font-weight: 800; border-radius: 999px; padding: 2px 8px; font-size: .75rem; }
        .badge-na { background: #e2e8f0; color: #475569; font-weight: 700; border-radius: 999px; padding: 2px 8px; font-size: .75rem; }
        .delta-up { color: #be123c; font-weight: 800; }
        .delta-down { color: #047857; font-weight: 800; }
        .delta-flat { color: #64748b; font-weight: 700; }
        .cmp-title { font-size: .9rem; font-weight: 800; color: var(--amr-teal); margin: 0 0 8px; }
        .cmp-grid .kpi-box { border: 1px solid var(--amr-line); border-radius: 12px; background: var(--amr-soft); height: 100%; }
        .cmp-grid .kpi-box .n { font-size: 1.35rem; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content amr-content">
        <div class="container-fluid py-4">
            <div class="abg-hero">
                <div>
                    <div class="abg-kicker"><i class="fas fa-bacteria"></i> AMR · AMS Quality · CAP non-MDR risk</div>
                    <h1 class="abg-title">KPI AMR</h1>
                    <p class="abg-sub">ตัวชี้วัดหลักตามข้อสั่งการ: สัดส่วน Medium watch ในผู้ป่วย CAP กลุ่ม non-MDR risk (ไม่ immuno และไม่เคย admit ใน 3 เดือน) และต้องไม่ผลักภาระไปยา Reserve</p>
                </div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <button type="button" class="btn btn-sm btn-outline-danger fw-bold" style="border-radius:999px;" id="btnPdf" disabled onclick="printPdf()">
                        <i class="fas fa-file-pdf me-1"></i>พิมพ์ PDF
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-secondary fw-bold" style="border-radius:999px;" id="btnCsv" disabled onclick="exportCsv()">
                        <i class="fas fa-file-csv me-1"></i>CSV รายชื่อ
                    </button>
                </div>
            </div>

            <div class="kpi-def">
                <h2><i class="fas fa-book-medical me-1"></i> นิยามตัวชี้วัดตามข้อสั่งการ (AMS Quality)</h2>
                <div class="def-code">การใช้ยาในผู้ป่วย CAP · กลุ่ม non-MDR risk · สูตรแม่แบบ AMR-SP 02</div>
                <p class="def-name">ร้อยละผู้ป่วย CAP กลุ่ม non-MDR risk ที่ได้รับยากลุ่ม Medium-Watch</p>
                <p class="def-en">Proportion of non-MDR-risk CAP patients receiving Medium-Watch antibiotics (AWaRe)</p>
                <div class="row g-3">
                    <div class="col-lg-7">
                        <dl>
                            <dt>ประชากรเป้าหมาย (ตัวส่วน B)</dt>
                            <dd>
                                ผู้ป่วยในที่มี ICD ปอดอักเสบ (ค่าเริ่มต้นตามแม่แบบ J13, J14, J15.0, J15.1, J18.0, J18.9)
                                ที่ได้รับยาปฏิชีวนะ และเป็นกลุ่ม <b>non-MDR risk</b> คือ
                                <ul>
                                    <li>ไม่เคย admit IPD ใน 3 เดือนก่อนหน้า</li>
                                    <li>ไม่เป็น immunocompromised (ICD ในประวัติ 2 ปี ตั้งค่าได้)</li>
                                </ul>
                                กลุ่มนี้ไม่ควรได้ยา broad-spectrum / Medium watch หากไม่มีข้อบ่งชี้
                            </dd>
                            <dt>ตัวเศษ (A)</dt>
                            <dd>ผู้ป่วยในตัวส่วนที่ได้รับยาปฏิชีวนะกลุ่ม <b>Medium watch</b> ตาม WHO AWaRe</dd>
                        </dl>
                        <div class="def-formula">ร้อยละ = (A / B) × 100 · เกณฑ์: ลดลงตามระดับโรงพยาบาล และต้องไม่ดันไปยา Reserve</div>
                        <dl>
                            <dt>ข้อพิจารณาความเป็นไปได้</dt>
                            <dd>
                                <ul>
                                    <li>นิยามกลุ่ม non-MDR risk ให้ชัด แยกจากกลุ่มเสี่ยง (immuno / admit 3 เดือน)</li>
                                    <li>เมื่อ Medium watch ลด ต้องยืนยันว่าไม่ได้ผลักภาระไปยา <b>Reserve</b></li>
                                    <li>ข้อสั่งการให้เริ่มกำกับที่ รพช./M2 — หน้านี้รายงานผู้ป่วยในของโรงพยาบาลนี้ (HIS นี้ไม่มีข้อมูลเครือข่าย รพช.)</li>
                                </ul>
                            </dd>
                        </dl>
                    </div>
                    <div class="col-lg-5">
                        <dl>
                            <dt>เกณฑ์ระดับโรงพยาบาล</dt>
                            <dd>ปีปฏิทิน 67–68 ต้องเทียบ <b>รพ. ระดับเดียวกัน</b> ซึ่งระบบนี้ไม่มีค่าอ้างอิง จึง<b>ประเมินไม่ได้</b> · ปีปฏิทิน 69–70 ใช้ baseline ของโรงพยาบาลนี้ · ปีปฏิทิน = 1 ม.ค. ถึง 31 ธ.ค. · แบ่งดึงเป็นช่วง 6 เดือน</dd>
                        </dl>
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered tgt mb-0">
                                <thead>
                                    <tr>
                                        <th>ปีปฏิทิน</th>
                                        <th>ช่วงที่ดึง</th>
                                        <th>เกณฑ์เป้าหมาย</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr><td>67</td><td>ม.ค. – ธ.ค. 67 · แบ่ง 6 เดือน</td><td>≤ 30% ของ รพ. ระดับเดียวกัน · ประเมินไม่ได้ (ไม่มีค่าอ้างอิง)</td></tr>
                                    <tr><td>68</td><td>ม.ค. – ธ.ค. 68 · แบ่ง 6 เดือน</td><td>≤ 25% ของ รพ. ระดับเดียวกัน · ประเมินไม่ได้ (ไม่มีค่าอ้างอิง)</td></tr>
                                    <tr><td>69</td><td>ม.ค. – ธ.ค. 69 · แบ่ง 6 เดือน</td><td>ลด ≥ 10% จากปีปฏิทิน 67 และ Reserve ไม่เพิ่ม</td></tr>
                                    <tr><td>70</td><td>ม.ค. – ธ.ค. 70 · แบ่ง 6 เดือน</td><td>ลด ≥ 10% จากปีปฏิทิน 68 และ Reserve ไม่เพิ่ม</td></tr>
                                </tbody>
                            </table>
                        </div>
                        <dl>
                            <dt>กลุ่มที่ดึงเปรียบเทียบ</dt>
                            <dd>CAP ทั้งหมด และกลุ่มเสี่ยง (immuno และ/หรือ admit 3 เดือน) แสดงแยก ไม่นับในตัวชี้วัดหลัก</dd>
                        </dl>
                    </div>
                </div>
            </div>

            <div class="abg-card">
                <div class="row g-2 align-items-end">
                    <div class="col-6 col-md-2">
                        <div class="abg-label">วันที่เริ่ม (admit)</div>
                        <input type="text" class="form-control form-control-sm" id="filterStart" value="<?php echo htmlspecialchars($default_start, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="abg-label">วันที่สิ้นสุด</div>
                        <input type="text" class="form-control form-control-sm" id="filterEnd" value="<?php echo htmlspecialchars($default_end, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-12 col-md-auto">
                        <div class="abg-label">ปีปฏิทิน / ช่วงด่วน</div>
                        <div class="btn-group flex-wrap">
                            <?php foreach ($cal_buttons as $cal_be) {
                                $cal_short = $cal_be - 2500;
                                $active = ($cal_be === $cal_now_be) ? ' active' : '';
                                echo '<button type="button" class="btn btn-outline-secondary abg-range-btn' . $active . '" data-range="cal-' . (int)$cal_be . '" onclick="setRange(\'cal-' . (int)$cal_be . '\')">ปี ' . (int)$cal_short . '</button>';
                            } ?>
                            <button type="button" class="btn btn-outline-secondary abg-range-btn" data-range="6m" onclick="setRange('6m')">6 เดือน</button>
                            <button type="button" class="btn btn-outline-secondary abg-range-btn" data-range="12m" onclick="setRange('12m')">12 เดือน</button>
                            <button type="button" class="btn btn-outline-secondary abg-range-btn" data-range="ytd" onclick="setRange('ytd')">ปีปฏิทินนี้</button>
                        </div>
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="abg-label">ย้อนหลัง immuno (วัน)</div>
                        <input type="number" class="form-control form-control-sm" id="filterLookback" min="30" max="1825" value="<?php echo (int)$settings['lookback_days']; ?>">
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="abg-label">admit ก่อนหน้า (วัน)</div>
                        <input type="number" class="form-control form-control-sm" id="filterPrior" min="7" max="365" value="<?php echo (int)$settings['prior_admit_days']; ?>">
                    </div>
                    <div class="col-12 col-md-auto">
                        <div class="form-check mt-4">
                            <input class="form-check-input" type="checkbox" id="filterPrincipal" <?php echo !empty($settings['principal_only']) ? 'checked' : ''; ?>>
                            <label class="form-check-label small fw-bold" for="filterPrincipal">ใช้เฉพาะวินิจฉัยหลัก</label>
                        </div>
                    </div>
                    <div class="col-12 col-md-auto">
                        <div class="form-check mt-4">
                            <input class="form-check-input" type="checkbox" id="filterEvalYears">
                            <label class="form-check-label small fw-bold" for="filterEvalYears">เทียบหลายปีปฏิทิน 67–70 (ดึงขนาน · แบ่ง 6 เดือน)</label>
                        </div>
                    </div>
                    <div class="col-12 col-md-auto">
                        <button type="button" class="btn btn-success fw-bold" id="btnRun" onclick="runKpi()" style="border-radius:999px; background:#0f766e; border-color:#0f766e;">
                            <i class="fas fa-play me-1"></i>ดึงข้อมูล
                        </button>
                    </div>
                </div>
                <div class="fy-hint" id="fyTargetHint"></div>
                <div class="abg-note mt-2" id="kpiStatus">เลือกปีปฏิทินหรือช่วง 6/12 เดือน แล้วกดดึงข้อมูล — จะเทียบเกณฑ์ระดับโรงพยาบาลของปีนั้น</div>
            </div>

            <div id="kpiIdle" class="abg-card">
                <p class="abg-note mb-0">เลือก <b>ปีปฏิทิน</b> (หรือช่วง 6 เดือน / 12 เดือน) แล้วกดดึงข้อมูล เพื่อเทียบร้อยละ Medium watch ตามเกณฑ์ระดับโรงพยาบาล</p>
            </div>

            <div id="kpiResult" class="d-none">
                <div id="kpiVerdict"></div>
                <div class="abg-card">
                    <div class="row g-2">
                        <div class="col-md-4">
                            <div class="kpi-box">
                                <div class="n" id="kpiCommunityPct">–</div>
                                <div class="l">% Medium watch · CAP ชุมชน (ตัวชี้วัดหลัก · non-MDR risk)</div>
                                <div class="s" id="kpiCommunityN"></div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="kpi-box">
                                <div class="n rose" id="kpiRiskPct">–</div>
                                <div class="l">% Medium watch · กลุ่มเสี่ยง (ไม่นับในตัวชี้วัดหลัก)</div>
                                <div class="s" id="kpiRiskN"></div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="kpi-box">
                                <div class="n" id="kpiAllPct">–</div>
                                <div class="l">% Medium watch · CAP ทั้งหมด (เปรียบเทียบ)</div>
                                <div class="s" id="kpiAllN"></div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-2" id="kpiPills"></div>
                    <div class="mt-3 d-none" id="kpiCompare"></div>
                </div>

                <div class="abg-card">
                    <div class="abg-tabs btn-group mb-3" role="group">
                        <button type="button" class="btn btn-outline-secondary active" data-tab="community" onclick="showTab('community')">CAP ชุมชน (ตัวชี้วัดหลัก)</button>
                        <button type="button" class="btn btn-outline-secondary" data-tab="risk" onclick="showTab('risk')">กลุ่มเสี่ยง AND</button>
                        <button type="button" class="btn btn-outline-secondary" data-tab="all" onclick="showTab('all')">CAP ทั้งหมด</button>
                        <button type="button" class="btn btn-outline-secondary" data-tab="mix" onclick="showTab('mix')">ยา Medium / Reserve</button>
                    </div>
                    <div id="tabCommunity" class="tab-pane"></div>
                    <div id="tabRisk" class="tab-pane d-none"></div>
                    <div id="tabAll" class="tab-pane d-none"></div>
                    <div id="tabMix" class="tab-pane d-none"></div>
                </div>
            </div>

            <div class="abg-card">
                <h2 class="h6 fw-bold mb-2">ตั้งค่า ICD และช่วงย้อนหลัง</h2>
                <p class="abg-note">ตามแม่แบบ AMR-SP 02 ใช้ ICD-10 = <b>J13, J14, J15.0, J15.1, J18.0, J18.9</b> · หนึ่งบรรทัดต่อรหัส · prefix เช่น <code>J18.0</code> คั่นคำอธิบายด้วย <code>|</code></p>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="abg-label">ICD ปอดอักเสบ (CAP)</div>
                        <textarea class="form-control icd-area" id="setCapIcd"><?php echo htmlspecialchars($cap_text, ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <div class="abg-label">ICD immunocompromised (ย้อนหลังตามจำนวนวันด้านบน)</div>
                        <textarea class="form-control icd-area" id="setImmunoIcd"><?php echo htmlspecialchars($immuno_text, ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>
                </div>
                <div class="mt-3 d-flex gap-2 flex-wrap">
                    <button type="button" class="btn btn-sm btn-success fw-bold" style="border-radius:999px; background:#0f766e; border-color:#0f766e;" onclick="saveSettings()">
                        <i class="fas fa-save me-1"></i>บันทึกการตั้งค่า
                    </button>
                    <span class="abg-note align-self-center" id="setStatus"></span>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/flatpickr.min.js"></script>

<div class="modal fade" id="printOptModal" tabindex="-1" aria-labelledby="printOptModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius:16px;">
            <div class="modal-header">
                <h5 class="modal-title fw-bold" id="printOptModalLabel"><i class="fas fa-file-pdf me-1 text-danger"></i>ตัวเลือกพิมพ์ PDF</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="abg-note mb-3">เลือกว่าจะแสดงชื่อผู้ป่วยในรายงานหรือไม่ ก่อนบันทึกเป็น PDF</p>
                <div class="form-check mb-2">
                    <input class="form-check-input" type="radio" name="printMaskName" id="printMaskYes" value="1" checked>
                    <label class="form-check-label fw-bold" for="printMaskYes">ปกปิดชื่อผู้ป่วย</label>
                    <div class="abg-note">แสดงเป็น «ผู้ป่วย» แทนชื่อจริง (แนะนำเมื่อแชร์รายงาน)</div>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="printMaskName" id="printMaskNo" value="0">
                    <label class="form-check-label fw-bold" for="printMaskNo">แสดงชื่อผู้ป่วย</label>
                    <div class="abg-note">ใช้ชื่อตามที่ดึงจากระบบ (สำหรับใช้งานภายใน)</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="button" class="btn btn-danger fw-bold" onclick="confirmPrintPdf()">
                    <i class="fas fa-print me-1"></i>พิมพ์ / บันทึก PDF
                </button>
            </div>
        </div>
    </div>
</div>
<script>
const YEAR_NOW = <?php echo $year_now; ?>;
const CAL_NOW_BE = <?php echo (int)$cal_now_be; ?>;
let lastPayload = null;
let fpStart = null, fpEnd = null;

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}
function setStatus(msg, err) {
    const el = document.getElementById('kpiStatus');
    el.classList.toggle('err', !!err);
    el.innerHTML = msg;
}
function setRange(kind) {
    document.querySelectorAll('.abg-range-btn').forEach(b => b.classList.toggle('active', b.getAttribute('data-range') === kind));
    const today = todayIso();
    let start = today, end = today;
    if (String(kind).indexOf('cal-') === 0) {
        const b = calBounds(Number(String(kind).slice(4)));
        start = b.start;
        end = minDate(b.end, today);
        if (start > today) {
            start = b.start;
            end = b.start;
        }
    } else if (kind === '6m') {
        const d = new Date();
        start = fmt(new Date(d.getFullYear(), d.getMonth() - 6, d.getDate()));
        end = today;
    } else if (kind === '12m') {
        const d = new Date();
        start = fmt(new Date(d.getFullYear(), d.getMonth() - 12, d.getDate()));
        end = today;
    } else if (kind === '3m') {
        const d = new Date();
        start = fmt(new Date(d.getFullYear(), d.getMonth() - 3, d.getDate()));
        end = today;
    } else if (kind === 'ytd') {
        start = YEAR_NOW + '-01-01';
        end = today;
    } else if (kind === 'lastyear') {
        start = (YEAR_NOW - 1) + '-01-01';
        end = (YEAR_NOW - 1) + '-12-31';
    }
    if (fpStart) fpStart.setDate(start, true); else document.getElementById('filterStart').value = start;
    if (fpEnd) fpEnd.setDate(end, true); else document.getElementById('filterEnd').value = end;
    updateFyHint();
}
function fmt(d) {
    const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), dd = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + dd;
}
function pct(v) { return v == null ? '–' : (Number(v).toFixed(1) + '%'); }
function frac(c) { return (c.numerator || 0) + ' / ' + (c.denominator || 0) + ' ราย'; }
function toBE(y) { return Number(y) + 543; }
function shiftYear(iso, dy) {
    const p = String(iso || '').split('-');
    if (p.length < 3) return iso;
    return String(Number(p[0]) + dy) + '-' + p[1] + '-' + p[2];
}
function todayIso() {
    const d = new Date();
    return fmt(d);
}
function minDate(a, b) { return a < b ? a : b; }
function maxDate(a, b) { return a > b ? a : b; }

function calendarYearOf(iso) {
    const p = String(iso || '').split('-');
    const y = Number(p[0] || YEAR_NOW);
    return y + 543;
}
function calBounds(be) {
    const y = Number(be) - 543;
    return { be: Number(be), start: y + '-01-01', end: y + '-12-31' };
}
function fyShort(be) { return Number(be) - 2500; }
function fyRule(be) {
    const n = Number(be);
    if (n <= 2567) {
        return {
            kind: 'peer', max: 30,
            title: 'ปีปฏิทิน ' + fyShort(n),
            label: '≤ 30% ของ รพ. ระดับเดียวกัน — ประเมินไม่ได้ (ไม่มีค่าอ้างอิง)',
            baselineCal: null
        };
    }
    if (n === 2568) {
        return {
            kind: 'peer', max: 25,
            title: 'ปีปฏิทิน ' + fyShort(n),
            label: '≤ 25% ของ รพ. ระดับเดียวกัน — ประเมินไม่ได้ (ไม่มีค่าอ้างอิง)',
            baselineCal: null
        };
    }
    const baseBe = n - 2;
    return {
        kind: 'drop', minDrop: 10,
        title: 'ปีปฏิทิน ' + fyShort(n),
        label: 'ร้อยละ Medium watch ลดลง ≥ 10% จากปีปฏิทิน ' + fyShort(baseBe) + ' ของโรงพยาบาลนี้',
        baselineCal: baseBe - 543,
        baselineBe: baseBe
    };
}
function selectedFyBe() {
    const btn = document.querySelector('.abg-range-btn.active');
    const r = btn ? btn.getAttribute('data-range') : '';
    if (r && r.indexOf('cal-') === 0) return Number(r.slice(4));
    if (r && r.indexOf('fy-') === 0) return Number(r.slice(3));
    return calendarYearOf(document.getElementById('filterEnd').value || todayIso());
}
/** แบ่งปีปฏิทินเป็นช่วงละ 6 เดือน (ม.ค.–มิ.ย. / ก.ค.–ธ.ค.) */
function fyChunks(be, today) {
    const y = Number(be) - 543;
    return yearChunks(y, today).map(c => Object.assign({}, c, { fy: be }));
}
function updateFyHint() {
    const el = document.getElementById('fyTargetHint');
    if (!el) return;
    const fy = selectedFyBe();
    const rule = fyRule(fy);
    const b = calBounds(fy);
    const today = todayIso();
    const start = document.getElementById('filterStart').value;
    const end = document.getElementById('filterEnd').value;
    const incomplete = end < b.end;
    const notStarted = start > today;
    let extra = '';
    if (notStarted) extra = ' · ยังไม่ถึงช่วงปีนี้';
    else if (incomplete) extra = ' · ข้อมูลถึงวันนี้ ยังไม่ครบปีปฏิทิน';
    const chunks = fyChunks(fy, today);
    const chunkTxt = chunks.length
        ? chunks.map(c => esc(c.start) + '–' + esc(c.end)).join(' · ')
        : '–';
    el.innerHTML = '<b>เกณฑ์ระดับโรงพยาบาล · ' + esc(rule.title) + '</b> — ' + esc(rule.label)
        + '<br>ช่วงปีปฏิทิน: ' + esc(b.start) + ' ถึง ' + esc(b.end)
        + ' · ช่วงที่ดึง: ' + esc(start) + ' ถึง ' + esc(end) + extra
        + '<br>แบ่งช่วง 6 เดือน: ' + chunkTxt
        + (rule.baselineCal ? ' · จะดึงปีปฏิทิน ' + fyShort(rule.baselineBe) + ' เป็น baseline ของโรงพยาบาลนี้' : '');
}

function mergeOfficial(parts) {
    const out = { cap_n: 0, a: 0, b: 0, reserve_n: 0, pct: null, reserve_pct: null };
    (parts || []).forEach(p => {
        if (!p) return;
        out.cap_n += Number(p.cap_n || 0);
        out.a += Number(p.a || 0);
        out.b += Number(p.b || 0);
        out.reserve_n += Number(p.reserve_n || 0);
    });
    out.pct = out.b > 0 ? Math.round(1000 * out.a / out.b) / 10 : null;
    out.reserve_pct = out.b > 0 ? Math.round(1000 * out.reserve_n / out.b) / 10 : null;
    return out;
}

function dropPct(base, curr) {
    if (base == null || curr == null || Number(base) <= 0) return null;
    return Math.round(10 * (Number(base) - Number(curr)) / Number(base) * 100) / 10;
}

function deltaHtml(curr, prev, invertGood) {
    if (curr == null || prev == null) return '<span class="delta-flat">–</span>';
    const d = Math.round(10 * (Number(curr) - Number(prev))) / 10;
    if (Math.abs(d) < 0.05) return '<span class="delta-flat">0.0</span>';
    const good = invertGood ? (d < 0) : (d > 0);
    const cls = good ? 'delta-down' : 'delta-up';
    const sign = d > 0 ? '+' : '';
    return '<span class="' + cls + '">' + sign + d.toFixed(1) + '</span>';
}

function pickOfficial(data) {
    return (data && data.official_community) ? data.official_community : ((data && data.official) ? data.official : {});
}

function judgeReserveShift(curr, base) {
    if (!curr || !base || base.reserve_pct == null || curr.reserve_pct == null) {
        return { ok: null, label: 'รอข้อมูล Reserve', detail: '' };
    }
    const up = Number(curr.reserve_pct) > Number(base.reserve_pct) + 0.05;
    if (up) {
        return {
            ok: false,
            label: 'ผลัก Reserve',
            detail: 'Reserve ' + pct(base.reserve_pct) + ' → ' + pct(curr.reserve_pct) + ' (เพิ่มขึ้น ทั้งที่ต้องไม่ผลักภาระจาก Medium watch)'
        };
    }
    return {
        ok: true,
        label: 'Reserve ไม่เพิ่ม',
        detail: 'Reserve ' + pct(curr.reserve_pct) + ' (baseline ' + pct(base.reserve_pct) + ')'
    };
}

function judgePeerMissing(pctVal, maxPct) {
    return {
        pass: null,
        label: 'ประเมินไม่ได้',
        detail: (pctVal == null ? '' : ('ร้อยละของโรงพยาบาลนี้ ' + pct(pctVal) + ' · '))
            + 'เกณฑ์ปีนี้คือ ≤ ' + maxPct + '% ของ รพ. ระดับเดียวกัน แต่ระบบนี้ไม่มีค่าอ้างอิงนั้น จึงตัดสินผ่าน/ไม่ผ่านไม่ได้'
    };
}

function judgeCap(pctVal, maxPct) {
    if (pctVal == null) return { pass: null, label: 'ไม่มีข้อมูล', detail: '' };
    const pass = Number(pctVal) <= Number(maxPct);
    return {
        pass,
        label: pass ? 'ผ่าน' : 'ไม่ผ่าน',
        detail: pct(pctVal) + ' เทียบเพดาน ≤ ' + maxPct + '% (ไม่มีข้อมูลเปรียบเทียบ รพ. ระดับเดียวกัน จึงใช้เพดานร้อยละของโรงพยาบาลนี้)'
    };
}

function judgeDrop(curr, base, minDrop) {
    if (curr == null || base == null) return { pass: null, label: 'รอข้อมูล', detail: 'ยังไม่มี baseline' };
    const d = dropPct(base, curr);
    const pass = d != null && d >= minDrop;
    const dir = d == null ? '' : (d >= 0 ? 'ลดลง ' + d + '%' : 'เพิ่มขึ้น ' + Math.abs(d) + '%');
    return {
        pass,
        label: pass ? 'ผ่าน' : (d == null ? 'รอข้อมูล' : 'ไม่ผ่าน'),
        detail: 'ปัจจุบัน ' + pct(curr) + ' · baseline ' + pct(base) + ' · ' + dir + ' (ต้องลด ≥ ' + minDrop + '%)',
        drop: d
    };
}

function yearChunks(year, today) {
    const y1s = year + '-01-01';
    const y1e = year + '-06-30';
    const y2s = year + '-07-01';
    const y2e = minDate(year + '-12-31', today);
    const out = [{ start: y1s, end: y1e, year }];
    if (y2s <= today) out.push({ start: y2s, end: y2e, year });
    return out.filter(c => c.start <= today && c.start <= c.end);
}

function commonFilter() {
    return {
        lookback_days: Number(document.getElementById('filterLookback').value || 730),
        prior_admit_days: Number(document.getElementById('filterPrior').value || 90),
        principal_only: document.getElementById('filterPrincipal').checked ? 1 : 0
    };
}

async function mapPool(items, limit, fn) {
    const out = new Array(items.length);
    let i = 0;
    async function worker() {
        while (i < items.length) {
            const idx = i++;
            out[idx] = await fn(items[idx], idx);
        }
    }
    const n = Math.min(Math.max(1, limit), items.length);
    await Promise.all(Array.from({ length: n }, () => worker()));
    return out;
}

async function fetchKpi(body, timeoutMs) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs || 170000);
    try {
        const r = await fetch('fetch_amr_kpi_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            signal: ctrl.signal
        });
        const data = await r.json();
        if (!r.ok || data.status !== 'success') throw new Error(data.message || ('HTTP ' + r.status));
        return data;
    } finally {
        clearTimeout(t);
    }
}

function verdictHtml(detail, ctx) {
    ctx = ctx || {};
    const fyBe = ctx.fyBe || selectedFyBe();
    const rule = fyRule(fyBe);
    const fyMap = ctx.fyMap || {};
    const calMap = ctx.calMap || {};
    const evalYears = !!ctx.evalYears;
    const off = pickOfficial(detail);
    const offAll = detail.official || {};
    const bounds = calBounds(fyBe);
    const end = (detail.meta || {}).end || document.getElementById('filterEnd').value;
    const curr = (fyMap[fyBe] && fyMap[fyBe].pct != null) ? fyMap[fyBe] : off;
    const base = rule.baselineCal ? (calMap[rule.baselineCal] || null) : null;
    let primary;
    let res = { ok: null, label: '', detail: '' };
    if (rule.kind === 'peer') {
        primary = judgePeerMissing(curr.pct, rule.max);
        primary.rule = rule.title + ' · ' + rule.label;
    } else if (rule.kind === 'cap') {
        primary = judgeCap(curr.pct, rule.max);
        primary.rule = rule.title + ' · ' + rule.label;
    } else {
        primary = judgeDrop(curr.pct, base && base.pct, rule.minDrop);
        primary.rule = rule.title + ' · ' + rule.label;
        res = judgeReserveShift(curr, base);
        if (primary.pass === true && res.ok === false) {
            primary.pass = false;
            primary.label = 'ไม่ผ่าน';
            primary.detail += ' · ' + res.detail;
            primary.rule += ' และ Reserve ต้องไม่เพิ่ม';
        }
    }
    const cls = primary.pass === true ? 'pass' : (primary.pass === false ? 'fail' : 'wait');
    const title = primary.pass === true
        ? 'ผ่านเกณฑ์'
        : (primary.pass === false ? 'ไม่ผ่านเกณฑ์' : (rule.kind === 'peer' ? 'ประเมินไม่ได้' : 'ยังสรุปไม่ได้'));
    const icon = primary.pass === true ? 'fa-check-circle' : (primary.pass === false ? 'fa-times-circle' : 'fa-minus-circle');
    const incomplete = end && bounds.end && end < bounds.end;
    let h = '<div class="verdict ' + cls + '">';
    h += '<div class="v-title"><i class="fas ' + icon + ' me-1"></i>' + esc(title) + ' · ' + esc(primary.rule) + '</div>';
    h += '<div class="v-sub mb-2">ตัวชี้วัดหลัก = CAP ชุมชน (non-MDR risk) ปีปฏิทิน ' + fyShort(fyBe)
        + ' (' + esc(bounds.start) + ' ถึง ' + esc(minDate(bounds.end, end || bounds.end)) + ')'
        + (incomplete ? ' · ยังไม่ครบปีปฏิทิน' : '')
        + ' · A/B ' + pct(curr.pct) + ' (' + (curr.a || 0) + '/' + (curr.b || 0) + ')'
        + ' · Reserve ' + pct(curr.reserve_pct) + ' (' + (curr.reserve_n || 0) + ' ราย)</div>';
    h += '<div class="v-sub mb-2">' + esc(primary.detail) + '</div>';
    if (res.detail) {
        h += '<div class="v-sub mb-2">' + esc(res.detail) + '</div>';
    }
    if (offAll.pct != null) {
        h += '<div class="v-sub mb-2">CAP ทั้งหมด (เปรียบเทียบ ไม่ใช่ตัวชี้วัดหลัก): ' + pct(offAll.pct) + ' (' + (offAll.a || 0) + '/' + (offAll.b || 0) + ')</div>';
    }
    const tableFys = evalYears ? [2567, 2568, 2569, 2570] : [fyBe];
    h += '<div class="table-responsive"><table class="table table-sm table-bordered judge-table mb-0"><thead><tr>'
        + '<th>ปีปฏิทิน</th><th>เกณฑ์ระดับ รพ.</th><th>ช่วงปี</th><th>A / B</th><th>Medium %</th><th>Δ Medium</th>'
        + '<th>Reserve %</th><th>Δ Reserve</th><th>Baseline</th><th>ผลัก Reserve</th><th>ผล</th>'
        + '</tr></thead><tbody>';
    let prevCur = null;
    tableFys.forEach(be => {
        const r = fyRule(be);
        const b = calBounds(be);
        const cur = (be === fyBe) ? curr : (fyMap[be] || null);
        const bs = r.baselineCal ? (calMap[r.baselineCal] || null) : null;
        let j, rs = { ok: null, label: '–', detail: '' };
        if (r.kind === 'peer') {
            j = judgePeerMissing(cur && cur.pct, r.max);
        } else if (r.kind === 'cap') {
            j = judgeCap(cur && cur.pct, r.max);
        } else {
            j = judgeDrop(cur && cur.pct, bs && bs.pct, r.minDrop);
            rs = judgeReserveShift(cur, bs);
            if (j.pass === true && rs.ok === false) {
                j.pass = false;
                j.label = 'ไม่ผ่าน';
            }
        }
        const badge = j.pass === true ? 'badge-pass' : (j.pass === false ? 'badge-fail' : 'badge-na');
        const rbadge = rs.ok === true ? 'badge-pass' : (rs.ok === false ? 'badge-fail' : 'badge-na');
        const ab = cur ? ((cur.a || 0) + ' / ' + (cur.b || 0)) : '–';
        const baseTxt = r.kind === 'peer'
            ? 'ไม่มีค่าอ้างอิง รพ. ระดับเดียวกัน'
            : (r.baselineCal
                ? ('ปีปฏิทิน ' + fyShort(r.baselineBe) + ' = ' + pct(bs && bs.pct)
                    + (bs && bs.reserve_pct != null ? (' · Reserve ' + pct(bs.reserve_pct)) : ''))
                : 'เพดาน ' + r.max + '%');
        h += '<tr class="' + (be === fyBe ? 'fy-now' : '') + '"><td>' + fyShort(be) + '</td><td>' + esc(r.label) + '</td>'
            + '<td>' + esc(b.start) + '<br>' + esc(minDate(b.end, todayIso())) + '</td>'
            + '<td>' + ab + '</td><td>' + pct(cur && cur.pct) + '</td>'
            + '<td>' + deltaHtml(cur && cur.pct, prevCur && prevCur.pct, true) + '</td>'
            + '<td>' + pct(cur && cur.reserve_pct) + '</td>'
            + '<td>' + deltaHtml(cur && cur.reserve_pct, prevCur && prevCur.reserve_pct, true) + '</td>'
            + '<td>' + esc(baseTxt) + '</td>'
            + '<td><span class="' + rbadge + '">' + esc(rs.label) + '</span></td>'
            + '<td><span class="' + badge + '">' + esc(j.label) + '</span></td></tr>';
        if (cur && cur.pct != null) prevCur = cur;
    });
    h += '</tbody></table></div>';
    const fys = Object.keys(fyMap).map(Number).sort();
    if (fys.length) {
        h += '<p class="abg-note mt-2 mb-0">แนวโน้มปีปฏิทิน (CAP ชุมชน): ' + fys.map(be => fyShort(be) + ' Medium ' + pct(fyMap[be].pct) + ' / Reserve ' + pct(fyMap[be].reserve_pct)).join(' · ') + '</p>';
    }
    if (evalYears) {
        const calYears = Object.keys(calMap).map(Number).sort();
        if (calYears.length) {
            h += '<div class="table-responsive mt-3"><table class="table table-sm table-bordered judge-table mb-0"><thead><tr>'
                + '<th>ปีปฏิทิน (baseline)</th><th>A / B</th><th>Medium %</th><th>Reserve %</th><th>ใช้เป็น baseline ของ</th>'
                + '</tr></thead><tbody>';
            calYears.forEach(y => {
                const c = calMap[y] || {};
                const usedBy = [2569, 2570].filter(be => {
                    const rr = fyRule(be);
                    return rr.baselineCal === y;
                }).map(be => 'ปี ' + fyShort(be)).join(', ') || '–';
                h += '<tr><td>' + fyShort(y + 543) + ' (' + y + ')</td>'
                    + '<td>' + ((c.a || 0) + ' / ' + (c.b || 0)) + '</td>'
                    + '<td>' + pct(c.pct) + '</td><td>' + pct(c.reserve_pct) + '</td>'
                    + '<td>' + esc(usedBy) + '</td></tr>';
            });
            h += '</tbody></table></div>';
        }
    }
    h += '</div>';
    return h;
}

function compareDetailHtml(ctx) {
    ctx = ctx || {};
    if (!ctx.evalYears) return '';
    const fyMap = ctx.fyMap || {};
    const calMap = ctx.calMap || {};
    const fyBe = ctx.fyBe || selectedFyBe();
    const fys = [2567, 2568, 2569, 2570].filter(be => be <= CAL_NOW_BE);
    let h = '<div class="cmp-title"><i class="fas fa-chart-line me-1"></i>รายละเอียดเปรียบเทียบหลายปีปฏิทิน (CAP ชุมชน · ตัวชี้วัดหลัก · แบ่งช่วง 6 เดือน)</div>';
    h += '<div class="row g-2 cmp-grid mb-3">';
    fys.forEach(be => {
        const cur = fyMap[be] || null;
        const rule = fyRule(be);
        const base = rule.baselineCal ? (calMap[rule.baselineCal] || null) : null;
        let j = { pass: null, label: '–', detail: '' };
        if (!cur || cur.pct == null) {
            j = { pass: null, label: 'ยังไม่มีข้อมูล', detail: '' };
        } else if (rule.kind === 'peer') {
            j = judgePeerMissing(cur.pct, rule.max);
        } else {
            j = judgeDrop(cur.pct, base && base.pct, rule.minDrop);
            const rs = judgeReserveShift(cur, base);
            if (j.pass === true && rs.ok === false) {
                j.pass = false;
                j.label = 'ไม่ผ่าน';
                j.detail = (j.detail || '') + ' · ' + rs.detail;
            }
        }
        const badge = j.pass === true ? 'badge-pass' : (j.pass === false ? 'badge-fail' : 'badge-na');
        h += '<div class="col-6 col-md-3"><div class="kpi-box' + (be === fyBe ? '' : '') + '">'
            + '<div class="l">ปี ' + fyShort(be) + (be === fyBe ? ' · ที่เลือก' : '') + '</div>'
            + '<div class="n">' + pct(cur && cur.pct) + '</div>'
            + '<div class="s">A/B ' + (cur ? ((cur.a || 0) + '/' + (cur.b || 0)) : '–') + '</div>'
            + '<div class="s">Reserve ' + pct(cur && cur.reserve_pct) + ' (' + ((cur && cur.reserve_n) || 0) + ')</div>'
            + '<div class="mt-1"><span class="' + badge + '">' + esc(j.label) + '</span></div>'
            + '</div></div>';
    });
    h += '</div>';

    h += '<div class="table-responsive"><table class="table table-sm table-bordered judge-table mb-2"><thead><tr>'
        + '<th>เปรียบเทียบ</th>';
    fys.forEach(be => { h += '<th class="text-center">ปี ' + fyShort(be) + '</th>'; });
    h += '</tr></thead><tbody>';
    const rows = [
        ['จำนวน CAP ชุมชนที่ได้ ATB (B)', be => { const c = fyMap[be]; return c ? String(c.b || 0) : '–'; }],
        ['ใช้ Medium watch (A)', be => { const c = fyMap[be]; return c ? String(c.a || 0) : '–'; }],
        ['Medium %', be => pct(fyMap[be] && fyMap[be].pct)],
        ['ใช้ Reserve', be => { const c = fyMap[be]; return c ? String(c.reserve_n || 0) : '–'; }],
        ['Reserve %', be => pct(fyMap[be] && fyMap[be].reserve_pct)],
        ['Δ Medium จากปีก่อน', (be, i) => {
            if (i === 0) return '–';
            return deltaHtml(fyMap[be] && fyMap[be].pct, fyMap[fys[i - 1]] && fyMap[fys[i - 1]].pct, true);
        }],
        ['Δ Reserve จากปีก่อน', (be, i) => {
            if (i === 0) return '–';
            return deltaHtml(fyMap[be] && fyMap[be].reserve_pct, fyMap[fys[i - 1]] && fyMap[fys[i - 1]].reserve_pct, true);
        }]
    ];
    rows.forEach(pair => {
        h += '<tr><td>' + esc(pair[0]) + '</td>';
        fys.forEach((be, i) => {
            const cell = pair[1](be, i);
            h += '<td class="text-center">' + cell + '</td>';
        });
        h += '</tr>';
    });
    h += '</tbody></table></div>';

    const notes = [];
    fys.forEach(be => {
        const rule = fyRule(be);
        const cur = fyMap[be];
        if (!cur || cur.pct == null) return;
        if (rule.kind === 'drop' && rule.baselineCal) {
            const bs = calMap[rule.baselineCal];
            const d = dropPct(bs && bs.pct, cur.pct);
            const rs = judgeReserveShift(cur, bs);
            notes.push('ปี ' + fyShort(be) + ': Medium ' + pct(cur.pct)
                + ' เทียบ baseline ปีปฏิทิน ' + fyShort(rule.baselineBe) + ' ' + pct(bs && bs.pct)
                + (d == null ? '' : (d >= 0 ? (' · ลดลง ' + d + '%') : (' · เพิ่มขึ้น ' + Math.abs(d) + '%')))
                + (rs.detail ? (' · ' + rs.detail) : ''));
        } else if (rule.kind === 'peer') {
            notes.push('ปี ' + fyShort(be) + ': Medium ' + pct(cur.pct) + ' · ' + rule.label);
        }
    });
    if (notes.length) {
        h += '<ul class="abg-note mb-0" style="padding-left:1.1rem;">'
            + notes.map(n => '<li>' + esc(n) + '</li>').join('')
            + '</ul>';
    }
    return h;
}

function render(data, ctx) {
    lastPayload = data;
    lastPayload.kpiCtx = ctx || {};
    document.getElementById('kpiIdle').classList.add('d-none');
    document.getElementById('kpiResult').classList.remove('d-none');
    document.getElementById('btnCsv').disabled = false;
    document.getElementById('btnPdf').disabled = false;
    document.getElementById('kpiVerdict').innerHTML = verdictHtml(data, ctx || {});
    const cs = data.cohorts || {};
    const com = cs.community || {};
    const risk = cs.risk_and || {};
    const all = cs.all || {};
    const oc = pickOfficial(data);
    const orisk = data.official_risk_and || {};
    const oall = data.official || {};
    document.getElementById('kpiCommunityPct').textContent = pct(oc.pct);
    document.getElementById('kpiCommunityN').textContent = (oc.a || 0) + ' / ' + (oc.b || 0) + ' ราย (A/B) · Reserve ' + pct(oc.reserve_pct);
    document.getElementById('kpiRiskPct').textContent = pct(orisk.pct != null ? orisk.pct : risk.pct);
    document.getElementById('kpiRiskN').textContent = (orisk.b != null)
        ? ((orisk.a || 0) + ' / ' + (orisk.b || 0) + ' ราย (A/B)')
        : frac(risk);
    document.getElementById('kpiAllPct').textContent = pct(oall.pct != null ? oall.pct : all.pct);
    document.getElementById('kpiAllN').textContent = (oall.b != null)
        ? ((oall.a || 0) + ' / ' + (oall.b || 0) + ' ราย (A/B)')
        : frac(all);
    const pills = [];
    pills.push('<span class="pop-pill">ปีปฏิทิน ' + fyShort((ctx && ctx.fyBe) || selectedFyBe()) + ' · ' + esc(fyRule((ctx && ctx.fyBe) || selectedFyBe()).label) + '</span>');
    pills.push('<span class="pop-pill">ตัวชี้วัดหลัก non-MDR risk: <b>' + (oc.a || 0) + ' / ' + (oc.b || 0) + '</b> = ' + pct(oc.pct) + ' · Reserve ' + pct(oc.reserve_pct) + '</span>');
    const order = ['all', 'community', 'risk_and', 'immuno_only', 'prior_only', 'risk_or'];
    order.forEach(k => {
        const c = cs[k];
        if (!c) return;
        pills.push('<span class="pop-pill">' + esc(c.label) + ': <b>' + (c.denominator || 0) + '</b></span>');
    });
    const off = data.official || {};
    if (off.pct != null) {
        pills.push('<span class="pop-pill">CAP ทั้งหมด (เปรียบเทียบ): <b>' + (off.a || 0) + ' / ' + (off.b || 0) + '</b> = ' + pct(off.pct) + '</span>');
    }
    document.getElementById('kpiPills').innerHTML = pills.join('');
    const cmpEl = document.getElementById('kpiCompare');
    if (cmpEl) {
        const cmp = compareDetailHtml(ctx || {});
        cmpEl.innerHTML = cmp;
        cmpEl.classList.toggle('d-none', !cmp);
    }
    const lim = (data.meta && data.meta.row_limit) ? data.meta.row_limit : 400;
    document.getElementById('tabCommunity').innerHTML = tableHtml(data.rows_community, 'ไม่พบ CAP ชุมชนในช่วงนี้')
        + '<p class="abg-note mt-2 mb-0">แสดงสูงสุด ' + lim + ' ราย</p>';
    document.getElementById('tabRisk').innerHTML = tableHtml(data.rows_risk_and, 'ไม่พบกลุ่มที่มีทั้ง immuno และ admit 3 เดือนก่อนหน้า')
        + '<p class="abg-note mt-2 mb-0">แสดงสูงสุด ' + lim + ' ราย</p>';
    document.getElementById('tabAll').innerHTML = tableHtml(data.rows_all, 'ไม่พบ IPD ปอดอักเสบในช่วงนี้')
        + '<p class="abg-note mt-2 mb-0">แสดงสูงสุด ' + lim + ' ราย</p>';
    document.getElementById('tabMix').innerHTML = mixHtml(data);
}

async function runKpi() {
    const btn = document.getElementById('btnRun');
    btn.disabled = true;
    lastPayload = null;
    document.getElementById('btnCsv').disabled = true;
    document.getElementById('btnPdf').disabled = true;
    updateFyHint();
    const start = document.getElementById('filterStart').value;
    const end = document.getElementById('filterEnd').value;
    const evalYears = document.getElementById('filterEvalYears').checked;
    const fyBe = selectedFyBe();
    const rule = fyRule(fyBe);
    const common = commonFilter();
    const today = todayIso();
    const jobs = [{ kind: 'detail', start, end }];
    const seen = {};
    function pushLite(job) {
        const k = job.kind + ':' + job.start + ':' + job.end;
        if (seen[k] || job.start > today || job.start > job.end) return;
        seen[k] = true;
        jobs.push(job);
    }
    const selB = calBounds(fyBe);
    const coversFy = start <= selB.start && end >= minDate(selB.end, today);
    if (evalYears) {
        [2567, 2568, 2569, 2570].forEach(be => {
            if (be > CAL_NOW_BE) return;
            if (be === fyBe && coversFy) return;
            fyChunks(be, today).forEach(c => pushLite({ kind: 'fy', fy: be, start: c.start, end: c.end }));
        });
        // baseline ปีปฏิทินสำหรับเกณฑ์ลด ≥10% (ปี 69→67, ปี 70→68)
        [2024, 2025].forEach(y => {
            if (y > YEAR_NOW) return;
            yearChunks(y, today).forEach(c => pushLite({ kind: 'cal', year: y, start: c.start, end: c.end }));
        });
    } else if (rule.kind === 'drop' && rule.baselineCal) {
        yearChunks(rule.baselineCal, today).forEach(c => pushLite({ kind: 'cal', year: c.year, start: c.start, end: c.end }));
    }
    setStatus('<i class="fas fa-spinner fa-spin me-1"></i> กำลังดึงปีปฏิทิน ' + fyShort(fyBe) + ' · ขนาน ' + jobs.length + ' ช่วง (แบ่ง 6 เดือน) จาก HOSxP...');
    try {
        const results = await mapPool(jobs, 5, async (j) => {
            if (j.kind === 'detail') {
                return fetchKpi(Object.assign({ action: 'list', start_date: j.start, end_date: j.end, lite: 0, include_rows: 1 }, common), 180000);
            }
            try {
                const d = await fetchKpi(Object.assign({ action: 'list', start_date: j.start, end_date: j.end, lite: 1, include_rows: 0 }, common), 120000);
                return {
                    kind: j.kind,
                    fy: j.fy,
                    year: j.year,
                    start: j.start,
                    end: j.end,
                    official: pickOfficial(d),
                    n: (d.meta && d.meta.n_all) || 0
                };
            } catch (err) {
                return { kind: j.kind, fy: j.fy, year: j.year, start: j.start, end: j.end, error: err.message || String(err), official: null };
            }
        });
        const detail = results[0];
        const fyParts = {};
        const calParts = {};
        results.slice(1).forEach(s => {
            if (!s || !s.official) return;
            if (s.kind === 'fy' && s.fy != null) {
                if (!fyParts[s.fy]) fyParts[s.fy] = [];
                fyParts[s.fy].push(s.official);
            }
            if (s.kind === 'cal' && s.year != null) {
                if (!calParts[s.year]) calParts[s.year] = [];
                calParts[s.year].push(s.official);
            }
        });
        const fyMap = {};
        Object.keys(fyParts).forEach(k => { fyMap[Number(k)] = mergeOfficial(fyParts[k]); });
        const calMap = {};
        Object.keys(calParts).forEach(k => { calMap[Number(k)] = mergeOfficial(calParts[k]); });
        fyMap[fyBe] = pickOfficial(detail);
        const ctx = { fyBe, evalYears, fyMap, calMap };
        const failed = results.slice(1).filter(s => s && s.error);
        render(detail, ctx);
        const m = detail.meta || {};
        const notes = (m.notes || []).length ? ' · ' + m.notes.join(' / ') : '';
        const failNote = failed.length ? ' · ช่วงที่ย่อไม่สำเร็จ ' + failed.length : '';
        const ruleTxt = rule.kind === 'drop'
            ? 'เทียบลด ≥ 10% จากปีปฏิทิน ' + fyShort(rule.baselineBe)
            : (rule.kind === 'peer'
                ? 'ประเมินไม่ได้ (ไม่มีค่าอ้างอิง รพ. ระดับเดียวกัน)'
                : 'เทียบเพดาน ≤ ' + rule.max + '%');
        setStatus('เสร็จแล้ว · ปีปฏิทิน ' + fyShort(fyBe) + ' · ' + ruleTxt + ' · admit ' + esc(m.start) + ' ถึง ' + esc(m.end) + ' · CAP ทั้งหมด ' + (m.n_all || 0) + ' ราย · ดึงขนาน ' + jobs.length + ' ช่วง' + notes + failNote);
    } catch (e) {
        const msg = (e && e.name === 'AbortError')
            ? 'ใช้เวลานานเกินกำหนด — ลองย่อช่วงวันที่ หรือดึงทีละปีปฏิทิน'
            : (e.message || String(e));
        setStatus(msg, true);
        document.getElementById('kpiResult').classList.add('d-none');
        document.getElementById('kpiIdle').classList.remove('d-none');
    }
    btn.disabled = false;
}

function showTab(id) {
    document.querySelectorAll('.abg-tabs [data-tab]').forEach(b => b.classList.toggle('active', b.getAttribute('data-tab') === id));
    document.getElementById('tabCommunity').classList.toggle('d-none', id !== 'community');
    document.getElementById('tabRisk').classList.toggle('d-none', id !== 'risk');
    document.getElementById('tabAll').classList.toggle('d-none', id !== 'all');
    document.getElementById('tabMix').classList.toggle('d-none', id !== 'mix');
}

function tableHtml(rows, emptyMsg) {
    if (!rows || !rows.length) return '<p class="abg-note mb-0">' + esc(emptyMsg) + '</p>';
    let h = '<div class="table-responsive"><table class="table table-sm table-hover kpi-table mb-0"><thead><tr>'
        + '<th>HN</th><th>AN</th><th>ชื่อ</th><th>อายุ</th><th>Admit</th><th>หอ</th><th>ICD CAP</th><th>Immuno</th><th>Admit ก่อน</th><th>Medium watch</th><th>Reserve</th><th>ยา ATB</th>'
        + '</tr></thead><tbody>';
    rows.forEach(r => {
        h += '<tr>'
            + '<td>' + esc(r.hn) + '</td>'
            + '<td>' + esc(r.an) + '</td>'
            + '<td>' + esc(r.pt_name) + '</td>'
            + '<td>' + esc(r.age_y) + (r.sex ? ' ' + esc(r.sex) : '') + '</td>'
            + '<td>' + esc(r.regdate) + (r.dchdate ? '<div class="text-muted" style="font-size:.72rem">' + esc(r.dchdate) + '</div>' : '') + '</td>'
            + '<td>' + esc(r.ward_name) + '</td>'
            + '<td>' + esc(r.cap_icds) + '</td>'
            + '<td>' + (r.immuno ? '<span class="tag-yes">มี</span><div class="text-muted" style="font-size:.72rem">' + esc(r.immuno_text) + '</div>' : '<span class="tag-no">ไม่มี</span>') + '</td>'
            + '<td>' + (r.prior_admit ? '<span class="tag-yes">มี</span><div class="text-muted" style="font-size:.72rem">' + esc(r.prior_text) + '</div>' : '<span class="tag-no">ไม่มี</span>') + '</td>'
            + '<td>' + (r.used_medium_watch ? '<span class="tag-yes">ใช้</span><div class="text-muted" style="font-size:.72rem">' + esc((r.medium_watch_drugs || []).join(', ')) + '</div>' : '<span class="tag-no">ไม่ใช้</span>') + '</td>'
            + '<td>' + (r.used_reserve ? '<span class="tag-yes">ใช้</span><div class="text-muted" style="font-size:.72rem">' + esc((r.reserve_drugs || []).join(', ')) + '</div>' : '<span class="tag-no">ไม่ใช้</span>') + '</td>'
            + '<td style="max-width:280px">' + esc(r.drug_text || '–') + '</td>'
            + '</tr>';
    });
    return h + '</tbody></table></div>';
}

function mixHtml(data) {
    const cs = data.cohorts || {};
    const oc = pickOfficial(data);
    const blocks = [
        ['community', 'CAP ชุมชน (ตัวชี้วัดหลัก)'],
        ['risk_and', 'กลุ่มเสี่ยง AND (เปรียบเทียบ)'],
        ['all', 'CAP ทั้งหมด (เปรียบเทียบ)']
    ];
    let h = '<p class="abg-note">กลุ่มหลัก A/B = ' + (oc.a || 0) + ' / ' + (oc.b || 0)
        + ' · Medium watch ' + pct(oc.pct) + ' · Reserve ' + pct(oc.reserve_pct)
        + ' — ถ้า Medium ลดแต่ Reserve เพิ่ม ถือว่าผลักภาระ</p>';
    h += '<div class="row g-3">';
    blocks.forEach(([key, label]) => {
        const c = cs[key] || {};
        const mix = c.medium_mix || [];
        const rmix = c.reserve_mix || [];
        const aware = c.aware_mix || [];
        h += '<div class="col-md-4"><div class="fw-bold mb-2">' + esc(label) + '</div>';
        if (aware.length) {
            h += '<table class="table table-sm kpi-table mb-2"><thead><tr><th>AWaRe</th><th class="text-end">รายการใช้</th></tr></thead><tbody>';
            aware.forEach(m => { h += '<tr><td>' + esc(m.aware) + '</td><td class="text-end">' + esc(m.n) + '</td></tr>'; });
            h += '</tbody></table>';
        }
        h += '<div class="small fw-bold mb-1">Medium watch</div>';
        if (!mix.length) {
            h += '<p class="abg-note">ยังไม่พบ Medium watch ในกลุ่มนี้</p>';
        } else {
            h += '<table class="table table-sm kpi-table mb-2"><thead><tr><th>ยา</th><th class="text-end">ราย</th></tr></thead><tbody>';
            mix.forEach(m => { h += '<tr><td>' + esc(m.name) + '</td><td class="text-end">' + esc(m.n) + '</td></tr>'; });
            h += '</tbody></table>';
        }
        h += '<div class="small fw-bold mb-1">Reserve</div>';
        if (!rmix.length) {
            h += '<p class="abg-note mb-0">ยังไม่พบยา Reserve ในกลุ่มนี้</p></div>';
            return;
        }
        h += '<table class="table table-sm kpi-table mb-0"><thead><tr><th>ยา</th><th class="text-end">ราย</th></tr></thead><tbody>';
        rmix.forEach(m => { h += '<tr><td>' + esc(m.name) + '</td><td class="text-end">' + esc(m.n) + '</td></tr>'; });
        h += '</tbody></table></div>';
    });
    return h + '</div>';
}

async function saveSettings() {
    const el = document.getElementById('setStatus');
    el.textContent = 'กำลังบันทึก...';
    try {
        const r = await fetch('fetch_amr_kpi_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'settings_save',
                lookback_days: Number(document.getElementById('filterLookback').value || 730),
                prior_admit_days: Number(document.getElementById('filterPrior').value || 90),
                principal_only: document.getElementById('filterPrincipal').checked ? 1 : 0,
                cap_icd: document.getElementById('setCapIcd').value,
                immuno_icd: document.getElementById('setImmunoIcd').value
            })
        });
        const data = await r.json();
        if (!r.ok || data.status !== 'success') throw new Error(data.message || 'บันทึกไม่สำเร็จ');
        el.textContent = data.message || 'บันทึกแล้ว';
    } catch (e) {
        el.textContent = e.message || String(e);
    }
}

function printPdf() {
    if (!lastPayload) {
        setStatus('กรุณาดึงข้อมูลก่อนพิมพ์ PDF', true);
        return;
    }
    const modalEl = document.getElementById('printOptModal');
    if (modalEl && window.bootstrap && bootstrap.Modal) {
        bootstrap.Modal.getOrCreateInstance(modalEl).show();
        return;
    }
    confirmPrintPdf();
}

function confirmPrintPdf() {
    if (!lastPayload) {
        setStatus('กรุณาดึงข้อมูลก่อนพิมพ์ PDF', true);
        return;
    }
    const maskEl = document.querySelector('input[name="printMaskName"]:checked');
    const maskNames = !maskEl || maskEl.value === '1';
    const payload = {
        data: lastPayload,
        kpiCtx: lastPayload.kpiCtx || { fyBe: selectedFyBe() },
        maskNames: maskNames,
        savedAt: new Date().toISOString()
    };
    try {
        sessionStorage.setItem('amr_kpi_print_payload_v1', JSON.stringify(payload));
    } catch (e) {
        setStatus('เก็บผลลัพธ์สำหรับพิมพ์ไม่สำเร็จ (ข้อมูลอาจใหญ่เกิน): ' + (e.message || e), true);
        return;
    }
    const modalEl = document.getElementById('printOptModal');
    if (modalEl && window.bootstrap && bootstrap.Modal) {
        const inst = bootstrap.Modal.getInstance(modalEl);
        if (inst) inst.hide();
    }
    window.open('amr_kpi_print.php', '_blank');
}

function exportCsv() {
    if (!lastPayload) return;
    const rows = [].concat(lastPayload.rows_community || [], lastPayload.rows_risk_and || []);
    const seen = {};
    const uniq = [];
    rows.forEach(r => {
        const k = r.an;
        if (seen[k]) return;
        seen[k] = true;
        uniq.push(r);
    });
    const extra = (lastPayload.rows_all || []).filter(r => !seen[r.an]);
    const all = uniq.concat(extra);
    const header = ['cohort','hn','an','name','age','sex','admit','discharge','ward','cap_icd','immuno','immuno_icd','prior_admit','prior_detail','medium_watch','reserve','atb'];
    const lines = [header.join(',')];
    function cohortOf(r) {
        if (r.immuno && r.prior_admit) return 'risk_and';
        if (!r.immuno && !r.prior_admit) return 'community';
        return 'other';
    }
    all.forEach(r => {
        const cols = [
            cohortOf(r), r.hn, r.an, r.pt_name, r.age_y, r.sex, r.regdate, r.dchdate, r.ward_name,
            r.cap_icds, r.immuno ? 1 : 0, r.immuno_text, r.prior_admit ? 1 : 0, r.prior_text,
            r.used_medium_watch ? 1 : 0, r.used_reserve ? 1 : 0, r.drug_text
        ].map(v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"');
        lines.push(cols.join(','));
    });
    const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'kpi_amr_cap.csv';
    a.click();
}

document.addEventListener('DOMContentLoaded', () => {
    if (window.flatpickr) {
        fpStart = flatpickr('#filterStart', { dateFormat: 'Y-m-d', onChange: updateFyHint });
        fpEnd = flatpickr('#filterEnd', { dateFormat: 'Y-m-d', onChange: updateFyHint });
    }
    updateFyHint();
});
</script>
</body>
</html>
