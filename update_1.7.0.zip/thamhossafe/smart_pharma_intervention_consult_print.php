<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/smart_pharma_helper.php';
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
require_once __DIR__ . '/monitor_lab_consult_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)($_SESSION['user_id'] ?? 0), $_SESSION['role'] ?? '');
}
tham_menu_ensure_page_access(basename(__FILE__));
sp_alert_log_ensure_tables($con);

function ivc_esc($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function ivc_be_date($ymd) {
    $ymd = substr(trim((string)$ymd), 0, 10);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $ymd)) {
        return $ymd;
    }
    $ts = strtotime($ymd);
    if (!$ts) {
        return $ymd;
    }
    return date('d/m/', $ts) . ((int)date('Y', $ts) + 543);
}

$id = (int)($_GET['id'] ?? 0);
$row = null;
if ($id > 0) {
    $q = mysqli_query($con, "SELECT i.*, m.label_th AS module_label, l.ptname, l.ward_display
        FROM pharmacist_interventions i
        LEFT JOIN smart_pharma_modules m ON m.module_key = i.module_key
        LEFT JOIN smart_pharma_alert_logs l ON l.id = i.alert_log_id
        WHERE i.id=$id LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
}
if (!$row) {
    die('ไม่พบ Intervention สำหรับพิมพ์ใบ Consult');
}

$hospital = 'โรงพยาบาล';
if (is_file(__DIR__ . '/amr_amass_helper.php')) {
    require_once __DIR__ . '/amr_amass_helper.php';
    if (function_exists('amr_amass_cover_info')) {
        $cover = amr_amass_cover_info($con);
        if (!empty($cover['hospital_name_th'])) {
            $hospital = $cover['hospital_name_th'];
        } elseif (!empty($cover['hospital_name'])) {
            $hospital = $cover['hospital_name'];
        }
    }
}

$hn = trim((string)($row['hn'] ?? ''));
$ptname = trim((string)($row['ptname'] ?? ''));
$vn = trim((string)($row['vn'] ?? ''));
$an = trim((string)($row['an'] ?? ''));
$visit_id = $an !== '' ? ('AN ' . $an) : ($vn !== '' ? ('VN ' . $vn) : '-');
$module = trim((string)($row['module_label'] ?? '')) ?: trim((string)($row['module_key'] ?? ''));
$level = (($row['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
$summary = trim((string)($row['alert_summary'] ?? ''));
$note = trim((string)($row['note_text'] ?? ''));
$consult = trim((string)($row['consult_result'] ?? ''));
$type_label = sp_intervention_type_label($row['intervention_type'] ?? '');
$pharm = trim((string)($row['recorded_name'] ?? ''));
if ($pharm === '') {
    $pharm = trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? ''));
}
$ward = trim((string)($row['ward_display'] ?? ''));
$ptype = trim((string)($row['patient_type'] ?? ''));
$visit = ivc_be_date($row['vstdate'] ?? '');
$print_date = date('d/m/') . ((int)date('Y') + 543) . ' ' . date('H:i');
$autoprint = (($_GET['autoprint'] ?? '') === '1');
$outcome_text = $consult !== '' ? $consult : $note;
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ใบปรึกษาแพทย์ — Intervention</title>
    <style>
        @page { size: A4 portrait; margin: 10mm 12mm; }
        * { box-sizing: border-box; }
        body {
            font-family: 'Sarabun', Tahoma, sans-serif;
            font-size: 12px;
            color: #111;
            background: #fff;
            margin: 0;
            line-height: 1.4;
        }
        .sheet { width: 100%; max-width: 190mm; margin: 0 auto; padding: 8px 4px; }
        .print-header {
            border-bottom: 2px solid #0f766e;
            margin-bottom: 8px;
            padding-bottom: 6px;
            text-align: center;
        }
        .print-header .brand { font-size: 11px; color: #64748b; }
        .print-header h1 { margin: 2px 0; font-size: 18px; font-weight: 800; color: #115e59; }
        .print-header .sub { font-size: 12px; font-weight: 700; }
        .print-header .meta { font-size: 10.5px; margin-top: 2px; }
        .badge-st {
            display: inline-block;
            border-radius: 3px;
            padding: 1px 6px;
            font-size: 10px;
            font-weight: 800;
            color: #fff;
            background: <?php echo $level === 'hard' ? '#dc2626' : '#d97706'; ?>;
        }
        .info-grid { width: 100%; border-collapse: collapse; margin-bottom: 6px; }
        .info-grid td { padding: 2px 4px; vertical-align: top; }
        .info-grid .lbl { font-weight: 700; width: 96px; color: #334155; white-space: nowrap; }
        .box {
            border: 1px solid #334155;
            border-radius: 4px;
            padding: 6px 8px;
            margin-top: 6px;
        }
        .box-title { font-weight: 700; margin-bottom: 3px; color: #115e59; }
        .doctor-box { min-height: 72px; }
        .doctor-lines { margin-top: 8px; }
        .doctor-lines div {
            border-bottom: 1px dotted #64748b;
            height: 18px;
            margin-top: 2px;
        }
        .sign-row { display: flex; justify-content: space-between; gap: 16px; margin-top: 14px; }
        .sign-box { flex: 1; text-align: center; font-size: 11px; }
        .sign-line { margin-top: 28px; border-top: 1px solid #333; padding-top: 4px; }
        .hint { font-size: 10px; color: #475569; }
        .toolbar { margin-bottom: 10px; }
        .toolbar a, .toolbar button {
            font-family: inherit;
            font-size: 12px;
            padding: 4px 10px;
            margin-right: 6px;
            border: 1px solid #64748b;
            background: #fff;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            color: #111;
        }
        @media print {
            .no-print { display: none !important; }
            body { margin: 0; }
            .sheet { padding: 0; max-width: none; }
        }
        @media screen {
            body { background: #e2e8f0; padding: 16px; }
            .sheet {
                background: #fff;
                padding: 16px 18px 22px;
                box-shadow: 0 8px 24px rgba(15, 23, 42, .12);
            }
        }
    </style>
</head>
<body>
<div class="sheet">
    <div class="toolbar no-print">
        <button type="button" onclick="window.print()">พิมพ์</button>
        <a href="smart_pharma_intervention_report.php">กลับ Intervention Report</a>
        <span class="hint" style="margin-left:12px;">แนะนำ: กระดาษ A4 · แนวตั้ง · ขนาด 100%</span>
    </div>
    <div class="print-header">
        <div class="brand"><?php echo ivc_esc($hospital); ?> · THAM Hos-Safe · Intervention</div>
        <h1>ใบปรึกษาแพทย์</h1>
        <div class="sub">เรื่อง <?php echo ivc_esc($module !== '' ? $module : 'การแทรกแซงทางเภสัชกรรม'); ?></div>
        <div class="meta">
            ระดับ: <span class="badge-st"><?php echo $level === 'hard' ? 'Hard Alert' : 'Soft Alert'; ?></span>
            · การแทรกแซง: <?php echo ivc_esc($type_label); ?>
            · วันที่พิมพ์ <?php echo ivc_esc($print_date); ?>
        </div>
    </div>
    <table class="info-grid">
        <tr>
            <td class="lbl">HN</td>
            <td><strong><?php echo ivc_esc($hn !== '' ? $hn : '-'); ?></strong></td>
            <td class="lbl">VN / AN</td>
            <td><?php echo ivc_esc($visit_id); ?></td>
        </tr>
        <tr>
            <td class="lbl">ชื่อผู้ป่วย</td>
            <td colspan="3"><?php echo ivc_esc($ptname !== '' ? $ptname : '-'); ?></td>
        </tr>
        <tr>
            <td class="lbl">ประเภท</td>
            <td><?php echo ivc_esc($ptype !== '' ? $ptype : '-'); ?><?php echo $ward !== '' ? ' · ' . ivc_esc($ward) : ''; ?></td>
            <td class="lbl">วันที่ตรวจ</td>
            <td><?php echo ivc_esc($visit !== '' ? $visit : '-'); ?></td>
        </tr>
        <tr>
            <td class="lbl">เภสัชกร</td>
            <td colspan="3"><strong><?php echo ivc_esc($pharm !== '' ? $pharm : '-'); ?></strong></td>
        </tr>
    </table>
    <div class="box">
        <div class="box-title">รายละเอียดที่พบ</div>
        <div><?php echo $summary !== '' ? nl2br(ivc_esc($summary)) : '—'; ?></div>
    </div>
    <div class="box">
        <div class="box-title">ข้อเสนอของเภสัชกร</div>
        <div><?php echo $note !== '' ? nl2br(ivc_esc($note)) : '—'; ?></div>
    </div>
    <?php if ($consult !== ''): ?>
    <div class="box">
        <div class="box-title">รายละเอียดหลัง Consult</div>
        <div><?php echo nl2br(ivc_esc($consult)); ?></div>
    </div>
    <?php endif; ?>
    <div class="box doctor-box">
        <div class="box-title">ผลการปรึกษา / คำสั่งแพทย์</div>
        <div class="hint"><?php echo mlc_consult_outcome_checked_html($outcome_text); ?></div>
        <div class="doctor-lines"><div></div><div></div><div></div></div>
    </div>
    <div class="sign-row">
        <div class="sign-box">
            <div class="sign-line">
                เภสัชกรผู้ Consult<br>
                (<?php echo ivc_esc($pharm !== '' ? $pharm : '................................'); ?>)<br>
                วันที่ ....../....../..........
            </div>
        </div>
        <div class="sign-box">
            <div class="sign-line">
                แพทย์ผู้รับปรึกษา<br>
                (................................................)<br>
                วันที่ ....../....../..........
            </div>
        </div>
    </div>
</div>
<script>
window.addEventListener('load', function() {
    if (<?php echo $autoprint ? 'true' : 'false'; ?>) {
        setTimeout(function() { window.print(); }, 250);
    }
});
</script>
</body>
</html>
