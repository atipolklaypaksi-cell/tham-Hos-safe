<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();
include __DIR__ . '/connect.php';
session_write_close();
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
mysqli_set_charset($con, 'utf8');
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

$allowed = [
    'hla', 'drug_usage', 'max_dose', 'warfarin', 'mg_ml', 'pediatric_dose',
    'home_med', 'dup_therapy', 'drug_allergy',
];
$action = trim((string)($_POST['action'] ?? ''));
if ($action !== 'start' || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'unknown action'], JSON_UNESCAPED_UNICODE);
    exit;
}

$module = trim((string)($_POST['module_key'] ?? ''));
if (!in_array($module, $allowed, true)) {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'โมดูลไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
    exit;
}

$hn = trim((string)($_POST['hn'] ?? ''));
if ($hn === '') {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'ไม่พบ HN'], JSON_UNESCAPED_UNICODE);
    exit;
}

function mon_iv_ymd($raw) {
    $s = trim((string)$raw);
    if (preg_match('/^(\d{4}-\d{2}-\d{2})/', $s, $m)) {
        return $m[1];
    }
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $s, $m)) {
        $y = (int)$m[3];
        if ($y > 2400) {
            $y -= 543;
        }
        return sprintf('%04d-%02d-%02d', $y, (int)$m[2], (int)$m[1]);
    }
    return date('Y-m-d');
}

function mon_iv_clip($s, $max) {
    $s = trim((string)$s);
    if ($s === '') {
        return '';
    }
    if (function_exists('mb_substr')) {
        return mb_substr($s, 0, $max, 'UTF-8');
    }
    return substr($s, 0, $max);
}

$drug = mon_iv_clip($_POST['drug_name'] ?? '', 180);
$finding = mon_iv_clip($_POST['alert_summary'] ?? '', 220);
$label = $drug;
if ($finding !== '' && $finding !== $drug) {
    $label = $drug !== '' ? ($drug . ' — ' . $finding) : $finding;
}
$an = trim((string)($_POST['an'] ?? ''));
$type = strtoupper(trim((string)($_POST['type_patient'] ?? '')));
if ($type !== 'IPD' && $type !== 'OPD') {
    $type = ($an !== '' && $an !== '0') ? 'IPD' : 'OPD';
}
$case = [
    'hn' => $hn,
    'vn' => trim((string)($_POST['vn'] ?? '')),
    'an' => $an,
    'ptname' => trim((string)($_POST['ptname'] ?? '')),
    'vstdate' => mon_iv_ymd($_POST['vstdate'] ?? ''),
    'alert_level' => (($_POST['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft',
    'drug_name' => $label,
    'ward_name' => trim((string)($_POST['ward_name'] ?? '')),
    'patient_type' => $type,
];
$actor_id = (int)($_SESSION['user_id'] ?? 0);
$actor_name = trim((string)($_POST['pharmacist_name'] ?? $_SESSION['full_name'] ?? $_SESSION['username'] ?? ''));
$synced = sp_sync_consult_to_intervention($con, $module, [$case], [
    'actor_id' => $actor_id,
    'actor_name' => $actor_name,
    'action' => 'start',
    'note_text' => trim((string)($_POST['note_text'] ?? '')),
    'intervention_type' => trim((string)($_POST['intervention_type'] ?? 'recommend')),
    'deviation_category' => trim((string)($_POST['deviation_category'] ?? '')),
    'consult_result' => trim((string)($_POST['consult_result'] ?? '')),
    'force_new' => true,
]);
$mute_msg = sp_alert_mute_from_intervention($con, [
    'deviation_category' => $_POST['deviation_category'] ?? '',
    'mute_visit' => $_POST['mute_visit'] ?? 0,
    'hn' => $hn,
    'vn' => $case['vn'] ?? '',
    'an' => $an,
    'patient_type' => $type,
], $actor_id, $actor_name);
if (empty($synced['ok'])) {
    ob_clean();
    echo json_encode([
        'status' => 'error',
        'message' => $synced['message'] ?? 'บันทึก Intervention ไม่สำเร็จ',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
$iv_id = (int)($synced['id'] ?? 0);
ob_clean();
echo json_encode([
    'status' => 'success',
    'message' => 'บันทึก Intervention ' . (int)($synced['count'] ?? 1) . ' รายการแล้ว' . ($mute_msg !== '' ? ' — ' . $mute_msg : ''),
    'id' => $iv_id,
    'print_url' => $iv_id > 0 ? ('smart_pharma_intervention_consult_print.php?id=' . $iv_id) : '',
], JSON_UNESCAPED_UNICODE);
