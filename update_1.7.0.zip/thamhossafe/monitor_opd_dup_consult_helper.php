<?php
/**
 * Monitor ยาเหลือ OPD — Consult / ใบปรึกษาแพทย์ + ประวัติ (แบบ Monitor Lab)
 */

require_once __DIR__ . '/monitor_lab_consult_helper.php';

function mopdc_consult_statuses() {
    return mlc_consult_statuses();
}

function mopdc_consult_normalize_status($status) {
    return mlc_consult_normalize_status($status);
}

function mopdc_consult_status_label($status) {
    return mlc_consult_status_label($status);
}

function mopdc_ensure_tables($con) {
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_opd_dup_consults.sql');
    if ($sql !== false && trim($sql) !== '') {
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
            if ($stmt === '') {
                continue;
            }
            @mysqli_query($con, $stmt);
        }
    }
    $chk = @mysqli_query($con, "SHOW TABLES LIKE 'monitor_opd_dup_consults'");
    return $chk && mysqli_num_rows($chk) > 0;
}

function mopdc_normalize_reply_wait_days($days) {
    return mlc_normalize_reply_wait_days($days);
}

function mopdc_get_reply_wait_days($con) {
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='mopd_reply_wait_days' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return mopdc_normalize_reply_wait_days((int)$r['config_value']);
    }
    @mysqli_query($con, "INSERT IGNORE INTO sys_config (config_name, config_value) VALUES ('mopd_reply_wait_days', '0')");
    return 0;
}

function mopdc_list_pharmacists($con, $prefer_user_id = 0) {
    return mlc_list_pharmacists($con, $prefer_user_id);
}

function mopdc_resolve_pharmacist($con, $user_id, $fallback_name = '') {
    return mlc_resolve_pharmacist($con, $user_id, $fallback_name);
}

function mopdc_ymd($date) {
    $date = substr(trim((string)$date), 0, 10);
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $date, $m)) {
        $date = sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[2], (int)$m[1]);
    }
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ? $date : '';
}

function mopdc_norm_hn($hn) {
    $hn = ltrim(trim((string)$hn), '0');
    return $hn === '' ? '0' : $hn;
}

function mopdc_case_key($hn, $vn, $icode, $order_date, $opd_date) {
    return mopdc_norm_hn($hn)
        . '|' . trim((string)$vn)
        . '|' . trim((string)$icode)
        . '|' . mopdc_ymd($order_date)
        . '|' . mopdc_ymd($opd_date);
}

function mopdc_item_icode(array $item) {
    $icode = trim((string)($item['hme_icode'] ?? $item['icode'] ?? ''));
    if ($icode !== '') {
        return $icode;
    }
    return trim((string)($item['hme_drug_name'] ?? $item['drug_name'] ?? ''));
}

function mopdc_case_key_from_item(array $item) {
    return mopdc_case_key(
        $item['hn'] ?? '',
        $item['vn'] ?? $item['an'] ?? '',
        mopdc_item_icode($item),
        $item['hme_date'] ?? $item['order_date'] ?? $item['order_date_iso'] ?? '',
        $item['opd_date'] ?? ''
    );
}

function mopdc_warning_from_item(array $item) {
    $msg = trim((string)($item['warning_msg'] ?? $item['alert_message'] ?? ''));
    if ($msg !== '') {
        return $msg;
    }
    $remain = trim((string)($item['remaining_text'] ?? ''));
    if ($remain !== '') {
        return 'ยา OPD เดิมยังเหลือประมาณ ' . $remain . ' ณ วันสั่งใหม่ — เสี่ยงจ่ายซ้ำสิ้นเปลือง';
    }
    return 'ยา OPD ซ้ำกับยาเดิมที่ยังเหลือ — เสี่ยงจ่ายซ้ำสิ้นเปลือง';
}

function mopdc_enrich_drug(array $patient, array $adm, array $d) {
    $d['hn'] = (string)($patient['hn'] ?? $d['hn'] ?? '');
    $d['hn_full'] = (string)($patient['hn_full'] ?? $d['hn_full'] ?? '');
    $d['ptname'] = (string)($patient['ptname'] ?? $d['ptname'] ?? '');
    $vn = trim((string)($adm['an'] ?? $d['vn'] ?? $d['an'] ?? ''));
    $d['vn'] = $vn;
    $d['an'] = $vn;
    $d['ward_name'] = (string)($adm['ward_display'] ?? $d['ward_name'] ?? '');
    $d['drug_name'] = (string)($d['hme_drug_name'] ?? $d['drug_name'] ?? '');
    $d['icode'] = (string)($d['hme_icode'] ?? $d['icode'] ?? '');
    $d['order_date'] = (string)($d['hme_date'] ?? $d['order_date'] ?? '');
    $d['order_time'] = (string)($d['hme_time'] ?? $d['order_time'] ?? '');
    $d['method_text'] = (string)($d['hme_method'] ?? $d['method_text'] ?? '');
    $d['qty'] = $d['hme_qty'] ?? $d['qty'] ?? '';
    $d['warning_msg'] = mopdc_warning_from_item($d);
    return $d;
}

function mopdc_get_consult($con, $id) {
    mopdc_ensure_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM monitor_opd_dup_consults WHERE id = $id LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function mopdc_find_by_key($con, $case_key) {
    mopdc_ensure_tables($con);
    $k = mysqli_real_escape_string($con, trim((string)$case_key));
    if ($k === '') {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM monitor_opd_dup_consults WHERE case_key = '$k' LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function mopdc_format_consult_row(array $r) {
    $status = mopdc_consult_normalize_status($r['status'] ?? 'waiting');
    return [
        'id' => (int)($r['id'] ?? 0),
        'case_key' => (string)($r['case_key'] ?? ''),
        'hn' => (string)($r['hn'] ?? ''),
        'an' => (string)($r['an'] ?? ''),
        'vn' => (string)($r['vn'] ?? ''),
        'icode' => (string)($r['icode'] ?? ''),
        'drug_name' => (string)($r['drug_name'] ?? ''),
        'method_text' => (string)($r['method_text'] ?? ''),
        'qty' => $r['qty'] ?? '',
        'ward_name' => (string)($r['ward_name'] ?? ''),
        'ptname' => (string)($r['ptname'] ?? ''),
        'order_date' => (string)($r['order_date'] ?? ''),
        'order_time' => (string)($r['order_time'] ?? ''),
        'opd_drug_name' => (string)($r['opd_drug_name'] ?? ''),
        'opd_date' => (string)($r['opd_date'] ?? ''),
        'remaining_text' => (string)($r['remaining_text'] ?? ''),
        'remaining_days' => isset($r['remaining_days']) && $r['remaining_days'] !== null && $r['remaining_days'] !== ''
            ? (int)$r['remaining_days'] : null,
        'warning_msg' => (string)($r['warning_msg'] ?? ''),
        'alert_level' => (string)($r['alert_level'] ?? 'soft'),
        'status' => $status,
        'status_label' => mopdc_consult_status_label($status),
        'pharmacist_user_id' => (int)($r['pharmacist_user_id'] ?? 0),
        'pharmacist_name' => (string)($r['pharmacist_name'] ?? ''),
        'consult_note' => (string)($r['consult_note'] ?? ''),
        'doctor_reply' => (string)($r['doctor_reply'] ?? ''),
        'reply_wait_days' => (int)($r['reply_wait_days'] ?? 0),
        'reply_due_at' => (string)($r['reply_due_at'] ?? ''),
        'started_at' => (string)($r['started_at'] ?? ''),
        'closed_at' => (string)($r['closed_at'] ?? ''),
        'printed_at' => (string)($r['printed_at'] ?? ''),
    ];
}

function mopdc_default_consult_virtual(array $item) {
    return [
        'id' => 0,
        'case_key' => mopdc_case_key_from_item($item),
        'hn' => (string)($item['hn'] ?? ''),
        'status' => 'waiting',
        'status_label' => mopdc_consult_status_label('waiting'),
        'consult_note' => '',
        'doctor_reply' => '',
        'pharmacist_name' => '',
        'reply_wait_days' => 0,
        'reply_due_at' => '',
        'printed_at' => '',
    ];
}

function mopdc_process_timeouts($con) {
    mopdc_ensure_tables($con);
    $q = mysqli_query($con, "SELECT * FROM monitor_opd_dup_consults
        WHERE status = 'in_progress' AND reply_due_at IS NOT NULL AND reply_due_at <= NOW()");
    if (!$q) {
        return 0;
    }
    $n = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $id = (int)$row['id'];
        if (mysqli_query($con, "UPDATE monitor_opd_dup_consults SET
            status='waiting', reply_due_at=NULL, updated_at=NOW() WHERE id=$id")) {
            $n++;
            $after = mopdc_get_consult($con, $id);
            mopdc_log_history($con, [
                'consult_id' => $id,
                'row' => $after ?: $row,
                'action_key' => 'timeout_reply',
                'action_label' => 'หมดเวลารอตอบ — กลับเป็นรอ Consult',
                'status_before' => 'in_progress',
                'status_after' => 'waiting',
                'actor_name' => 'ระบบ',
            ]);
        }
    }
    return $n;
}

function mopdc_index_by_keys($con, array $keys) {
    mopdc_ensure_tables($con);
    mopdc_process_timeouts($con);
    $map = [];
    $keys = array_values(array_unique(array_filter(array_map('trim', $keys))));
    if (empty($keys)) {
        return $map;
    }
    $in = [];
    foreach ($keys as $k) {
        $in[] = "'" . mysqli_real_escape_string($con, $k) . "'";
    }
    foreach (array_chunk($in, 200) as $chunk) {
        $q = mysqli_query($con, 'SELECT * FROM monitor_opd_dup_consults WHERE case_key IN (' . implode(',', $chunk) . ')');
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $map[$r['case_key']] = mopdc_format_consult_row($r);
        }
    }
    return $map;
}

function mopdc_attach_to_alerts($con, array $alerts) {
    $keys = [];
    foreach ($alerts as $it) {
        $keys[] = mopdc_case_key_from_item($it);
    }
    $map = mopdc_index_by_keys($con, $keys);
    foreach ($alerts as &$it) {
        $k = mopdc_case_key_from_item($it);
        $it['case_key'] = $k;
        $it['consult'] = $map[$k] ?? mopdc_default_consult_virtual($it);
    }
    unset($it);
    return $alerts;
}

function mopdc_attach_to_patients($con, array $patients) {
    $keys = [];
    foreach ($patients as $p) {
        foreach ($p['admissions'] ?? [] as $adm) {
            foreach ($adm['drugs'] ?? [] as $d) {
                if (empty($d['prior_opd'])) {
                    continue;
                }
                $keys[] = mopdc_case_key_from_item(mopdc_enrich_drug($p, $adm, $d));
            }
        }
    }
    $map = mopdc_index_by_keys($con, $keys);
    foreach ($patients as &$p) {
        foreach ($p['admissions'] as &$adm) {
            foreach ($adm['drugs'] as &$d) {
                $d = mopdc_enrich_drug($p, $adm, $d);
                $k = mopdc_case_key_from_item($d);
                $d['case_key'] = $k;
                $d['consult'] = !empty($d['prior_opd'])
                    ? ($map[$k] ?? mopdc_default_consult_virtual($d))
                    : null;
            }
            unset($d);
        }
        unset($adm);
    }
    unset($p);
    return $patients;
}

function mopdc_esc_date($con, $date) {
    $ymd = mopdc_ymd($date);
    if ($ymd === '') {
        return 'NULL';
    }
    return "'" . mysqli_real_escape_string($con, $ymd) . "'";
}

function mopdc_upsert_from_case($con, array $case, array $extra = []) {
    mopdc_ensure_tables($con);
    $key = trim((string)($case['case_key'] ?? ''));
    if ($key === '') {
        $key = mopdc_case_key_from_item($case);
    }
    if ($key === '' || trim((string)($case['hn'] ?? '')) === '') {
        return ['ok' => false, 'error' => 'ข้อมูลเคสไม่ครบ'];
    }
    $existing = mopdc_find_by_key($con, $key);
    $hn = mysqli_real_escape_string($con, mopdc_norm_hn($case['hn'] ?? ''));
    $vn = trim((string)($case['vn'] ?? $case['an'] ?? ''));
    $an = mysqli_real_escape_string($con, $vn);
    $vn_esc = mysqli_real_escape_string($con, $vn);
    $icode = mysqli_real_escape_string($con, mopdc_item_icode($case));
    $drug = mysqli_real_escape_string($con, trim((string)($case['drug_name'] ?? $case['hme_drug_name'] ?? '')));
    $method = mysqli_real_escape_string($con, trim((string)($case['method_text'] ?? $case['hme_method'] ?? $case['drug_method'] ?? '')));
    $qty = is_numeric($case['qty'] ?? $case['hme_qty'] ?? '') ? (float)($case['qty'] ?? $case['hme_qty']) : 'NULL';
    $ward = mysqli_real_escape_string($con, trim((string)($case['ward_name'] ?? $case['ward_display'] ?? '')));
    $ptname = mysqli_real_escape_string($con, trim((string)($case['ptname'] ?? '')));
    $odate = mopdc_esc_date($con, $case['order_date_iso'] ?? $case['order_date'] ?? $case['hme_date'] ?? '');
    $otime = mysqli_real_escape_string($con, substr(trim((string)($case['order_time'] ?? $case['hme_time'] ?? '')), 0, 12));
    $opd_name = mysqli_real_escape_string($con, trim((string)($case['opd_drug_name'] ?? '')));
    $opd_date = mopdc_esc_date($con, $case['opd_date'] ?? '');
    $remain = mysqli_real_escape_string($con, trim((string)($case['remaining_text'] ?? '')));
    $remain_days = is_numeric($case['remaining_days'] ?? '') ? (int)$case['remaining_days'] : 'NULL';
    $warn = mysqli_real_escape_string($con, mopdc_warning_from_item($case));
    $lvl = (($case['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
    $key_esc = mysqli_real_escape_string($con, $key);
    $updated_by = (int)($extra['updated_by'] ?? $extra['created_by'] ?? 0);
    $created_by = (int)($extra['created_by'] ?? $updated_by);

    $set = "hn='$hn', an='$an', vn='$vn_esc', icode='$icode', drug_name='$drug',
        method_text='$method', qty=" . ($qty === 'NULL' ? 'NULL' : $qty) . ", ward_name='$ward', ptname='$ptname',
        order_date=$odate, order_time='$otime', opd_drug_name='$opd_name', opd_date=$opd_date,
        remaining_text='$remain', remaining_days=" . ($remain_days === 'NULL' ? 'NULL' : $remain_days) . ",
        warning_msg='$warn', alert_level='$lvl',
        updated_by=" . ($updated_by > 0 ? $updated_by : 'NULL');

    if ($existing) {
        $id = (int)$existing['id'];
        if (!mysqli_query($con, "UPDATE monitor_opd_dup_consults SET $set WHERE id=$id")) {
            return ['ok' => false, 'error' => mysqli_error($con)];
        }
        return ['ok' => true, 'id' => $id, 'row' => mopdc_get_consult($con, $id)];
    }
    $sql = "INSERT INTO monitor_opd_dup_consults
        (case_key, hn, an, vn, icode, drug_name, method_text, qty, ward_name, ptname,
         order_date, order_time, opd_drug_name, opd_date, remaining_text, remaining_days,
         warning_msg, alert_level, status, created_by, updated_by)
        VALUES ('$key_esc', '$hn', '$an', '$vn_esc', '$icode', '$drug', '$method',
            " . ($qty === 'NULL' ? 'NULL' : $qty) . ", '$ward', '$ptname', $odate, '$otime',
            '$opd_name', $opd_date, '$remain', " . ($remain_days === 'NULL' ? 'NULL' : $remain_days) . ",
            '$warn', '$lvl', 'waiting',
            " . ($created_by > 0 ? $created_by : 'NULL') . ", " . ($updated_by > 0 ? $updated_by : 'NULL') . ")";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $id = (int)mysqli_insert_id($con);
    return ['ok' => true, 'id' => $id, 'row' => mopdc_get_consult($con, $id)];
}

function mopdc_start_consult($con, array $case, $pharmacist_user_id, $pharmacist_name, $note, $actor_user_id, $reply_wait_days = null, $actor_name = '') {
    $up = mopdc_upsert_from_case($con, $case, [
        'created_by' => $actor_user_id,
        'updated_by' => $actor_user_id,
    ]);
    if (empty($up['ok'])) {
        return $up;
    }
    $id = (int)$up['id'];
    $before = mopdc_get_consult($con, $id);
    $pharm = mopdc_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name);
    $wait = mopdc_normalize_reply_wait_days($reply_wait_days ?? mopdc_get_reply_wait_days($con));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $due_sql = $wait <= 0 ? 'NULL' : "DATE_ADD(NOW(), INTERVAL $wait DAY)";
    $sql = "UPDATE monitor_opd_dup_consults SET
        status='in_progress',
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'NULL') . ",
        pharmacist_name='$name_esc',
        consult_note='$note_esc',
        reply_wait_days=$wait,
        reply_due_at=$due_sql,
        closed_at=NULL,
        started_at=IFNULL(started_at, NOW()),
        printed_at=NOW(),
        updated_by=$actor
        WHERE id=$id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $row = mopdc_get_consult($con, $id);
    mopdc_log_history($con, [
        'consult_id' => $id,
        'row' => $row,
        'action_key' => 'start',
        'action_label' => 'เริ่ม Consult + พิมพ์ใบปรึกษา',
        'status_before' => $before['status'] ?? 'waiting',
        'status_after' => 'in_progress',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'reply_due_at' => $row['reply_due_at'] ?? null,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
        'meta' => ['reply_wait_days' => $wait],
    ]);
    return [
        'ok' => true,
        'id' => $id,
        'consult' => mopdc_format_consult_row($row),
        'print_url' => 'monitor_opd_dup_consult_print.php?id=' . $id,
        'message' => 'เริ่ม Consult แล้ว — รอตอบกลับ' . ($wait <= 0 ? 'ทันที' : ('ภายใน ' . $wait . ' วัน')),
    ];
}

function mopdc_close_consult($con, $consult_id, $note, $doctor_reply, $actor_user_id, $actor_name = '', $pharmacist_user_id = 0, $pharmacist_name = '') {
    $consult_id = (int)$consult_id;
    $row = mopdc_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $pharm = mopdc_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name !== '' ? $pharmacist_name : ($row['pharmacist_name'] ?? ''));
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $reply_esc = mysqli_real_escape_string($con, trim((string)$doctor_reply));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $sql = "UPDATE monitor_opd_dup_consults SET
        status='closed',
        closed_at=NOW(),
        reply_due_at=NULL,
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'pharmacist_user_id') . ",
        pharmacist_name=IF('$name_esc'='', pharmacist_name, '$name_esc'),
        consult_note=IF('$note_esc'='', consult_note, '$note_esc'),
        doctor_reply=IF('$reply_esc'='', doctor_reply, '$reply_esc'),
        updated_by=$actor
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = mopdc_get_consult($con, $consult_id);
    mopdc_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'close',
        'action_label' => 'ปิดการ Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => 'closed',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'doctor_reply' => $doctor_reply,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => mopdc_format_consult_row($after), 'message' => 'ปิด Consult แล้ว'];
}

function mopdc_save_result($con, $consult_id, $note, $doctor_reply, $actor_user_id, $actor_name = '', $pharmacist_user_id = 0, $pharmacist_name = '') {
    $consult_id = (int)$consult_id;
    $row = mopdc_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $pharm = mopdc_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $reply_esc = mysqli_real_escape_string($con, trim((string)$doctor_reply));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $sql = "UPDATE monitor_opd_dup_consults SET
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'pharmacist_user_id') . ",
        pharmacist_name=IF('$name_esc'='', pharmacist_name, '$name_esc'),
        consult_note=IF('$note_esc'='', consult_note, '$note_esc'),
        doctor_reply=IF('$reply_esc'='', doctor_reply, '$reply_esc'),
        updated_by=$actor
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = mopdc_get_consult($con, $consult_id);
    mopdc_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'save_result',
        'action_label' => 'บันทึกผล Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => $after['status'] ?? '',
        'pharmacist_name' => $pharm['name'] !== '' ? $pharm['name'] : ($row['pharmacist_name'] ?? ''),
        'note_text' => $note,
        'doctor_reply' => $doctor_reply,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => mopdc_format_consult_row($after), 'message' => 'บันทึกผล Consult เรียบร้อย'];
}

function mopdc_reset_waiting($con, $consult_id, $actor_user_id, $note = '', $actor_name = '') {
    $consult_id = (int)$consult_id;
    $row = mopdc_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $note_sql = $note_esc !== '' ? ", consult_note='$note_esc'" : '';
    $actor = (int)$actor_user_id;
    $sql = "UPDATE monitor_opd_dup_consults SET
        status='waiting', reply_due_at=NULL, closed_at=NULL, updated_by=$actor
        $note_sql
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = mopdc_get_consult($con, $consult_id);
    mopdc_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'reset',
        'action_label' => 'ตั้งเป็นรอ Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => 'waiting',
        'note_text' => $note,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => mopdc_format_consult_row($after)];
}

function mopdc_mark_printed($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "UPDATE monitor_opd_dup_consults SET printed_at=NOW() WHERE id=$id");
}

function mopdc_log_history($con, array $data) {
    mopdc_ensure_tables($con);
    $row = $data['row'] ?? [];
    $consult_id = (int)($data['consult_id'] ?? ($row['id'] ?? 0));
    $hn = mysqli_real_escape_string($con, (string)($row['hn'] ?? ''));
    $an = mysqli_real_escape_string($con, (string)($row['an'] ?? ''));
    $icode = mysqli_real_escape_string($con, (string)($row['icode'] ?? ''));
    $drug = mysqli_real_escape_string($con, (string)($row['drug_name'] ?? ''));
    $action_key = mysqli_real_escape_string($con, (string)($data['action_key'] ?? ''));
    $action_label = mysqli_real_escape_string($con, (string)($data['action_label'] ?? $action_key));
    $sb = mysqli_real_escape_string($con, (string)($data['status_before'] ?? ''));
    $sa = mysqli_real_escape_string($con, (string)($data['status_after'] ?? ''));
    $pharm = mysqli_real_escape_string($con, (string)($data['pharmacist_name'] ?? ($row['pharmacist_name'] ?? '')));
    $note = mysqli_real_escape_string($con, (string)($data['note_text'] ?? ''));
    $reply = mysqli_real_escape_string($con, (string)($data['doctor_reply'] ?? ''));
    $reply_due = !empty($data['reply_due_at'])
        ? "'" . mysqli_real_escape_string($con, (string)$data['reply_due_at']) . "'"
        : 'NULL';
    $meta = '';
    if (!empty($data['meta']) && is_array($data['meta'])) {
        $meta = mysqli_real_escape_string($con, json_encode($data['meta'], JSON_UNESCAPED_UNICODE));
    }
    $actor_id = (int)($data['actor_user_id'] ?? 0);
    $actor_name = mysqli_real_escape_string($con, (string)($data['actor_name'] ?? ''));
    $sql = "INSERT INTO monitor_opd_dup_consult_history
        (consult_id, hn, an, icode, drug_name, action_key, action_label,
         status_before, status_after, pharmacist_name, note_text, doctor_reply, reply_due_at, meta_json,
         actor_user_id, actor_name)
        VALUES
        ($consult_id, '$hn', '$an', '$icode', '$drug', '$action_key', '$action_label',
         '$sb', '$sa', '$pharm', '$note', '$reply', $reply_due, " . ($meta !== '' ? "'$meta'" : 'NULL') . ",
         " . ($actor_id > 0 ? $actor_id : 'NULL') . ", '$actor_name')";
    return (bool)@mysqli_query($con, $sql);
}

function mopdc_list_history($con, array $opts = []) {
    mopdc_ensure_tables($con);
    $where = ['1=1'];
    if (!empty($opts['consult_id'])) {
        $where[] = 'consult_id=' . (int)$opts['consult_id'];
    }
    if (!empty($opts['hn'])) {
        $where[] = "hn='" . mysqli_real_escape_string($con, mopdc_norm_hn($opts['hn'])) . "'";
    }
    $limit = max(1, min(500, (int)($opts['limit'] ?? 100)));
    $sql = 'SELECT * FROM monitor_opd_dup_consult_history WHERE ' . implode(' AND ', $where)
        . ' ORDER BY created_at DESC, id DESC LIMIT ' . $limit;
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'id' => (int)$r['id'],
                'consult_id' => (int)$r['consult_id'],
                'created_at' => $r['created_at'],
                'drug_name' => $r['drug_name'],
                'action_key' => $r['action_key'],
                'action_label' => $r['action_label'],
                'status_before' => $r['status_before'],
                'status_after' => $r['status_after'],
                'status_before_label' => mopdc_consult_status_label($r['status_before']),
                'status_after_label' => mopdc_consult_status_label($r['status_after']),
                'pharmacist_name' => $r['pharmacist_name'],
                'note_text' => $r['note_text'],
                'doctor_reply' => $r['doctor_reply'],
                'reply_due_at' => $r['reply_due_at'],
                'actor_name' => $r['actor_name'],
            ];
        }
    }
    return $rows;
}
