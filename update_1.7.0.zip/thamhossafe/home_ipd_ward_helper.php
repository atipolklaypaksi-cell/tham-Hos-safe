<?php
/**
 * สรุปเตียง IPD แบบเบา สำหรับ home.php (ห้องจ่ายยาผู้ป่วยใน)
 * — ไม่ใช้ 3D/WebGL; ดึงเฉพาะตัวเลขวันนี้ + cache 90 วินาที
 */

if (!function_exists('hosxp_connect')) {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
}
if (!function_exists('sp_backup_room_key') && is_file(__DIR__ . '/smart_pharma_backup_helper.php')) {
    require_once __DIR__ . '/smart_pharma_backup_helper.php';
}

function hiw_cache_ttl() {
    return 90;
}

function hiw_cache_path() {
    $dir = sys_get_temp_dir() . '/thamhossafe_hiw';
    if (!is_dir($dir)) {
        @mkdir($dir, 0700, true);
    }
    return $dir . '/ipd_ward_overview_v17.json';
}

function hiw_can_view($con = null) {
    $role = strtolower(trim((string)($_SESSION['role'] ?? '')));
    if (!in_array($role, ['admin', 'pharmacist', 'pharmacy_technician'], true)) {
        return false;
    }
    if (!function_exists('sp_backup_room_key')) {
        return false;
    }
    return sp_backup_room_key() === 'ipd';
}

function hiw_is_critical_ward($wardname) {
    return (bool)preg_match('/ICU|OBS/i', (string)$wardname);
}

/** หอที่ไม่แสดงบน campus (Home ward / PSY HM) */
function hiw_is_hidden_ward($wardname, $wardFull = '') {
    $n = strtoupper(trim(preg_replace('/\s+/', ' ', (string)$wardname)));
    $f = strtoupper(trim(preg_replace('/\s+/', ' ', (string)$wardFull)));
    if ($n === '' && $f === '') {
        return false;
    }
    // Home ward / HOME WARD
    if (preg_match('/\bHOME\b/', $n) || preg_match('/\bHOME\s*WARD\b/', $f)) {
        return true;
    }
    // PSY HM
    if (preg_match('/\bPSY\s*HM\b/', $n) || preg_match('/\bPSY\s*HM\b/', $f)) {
        return true;
    }
    return false;
}

function hiw_decode_text($s) {
    $s = (string)$s;
    if ($s === '') {
        return '';
    }
    // PHP 8+ โยน ValueError ถ้า encoding ไม่มีใน build — อย่าใส่รายชื่อรวมใน mb_convert_encoding
    if (function_exists('mb_check_encoding') && @mb_check_encoding($s, 'UTF-8')) {
        return trim($s);
    }
    if (function_exists('iconv')) {
        foreach (['UTF-8', 'Windows-874', 'ISO-8859-11', 'TIS-620'] as $from) {
            $try = @iconv($from, 'UTF-8//IGNORE', $s);
            if (is_string($try) && $try !== '' && (!function_exists('mb_check_encoding') || @mb_check_encoding($try, 'UTF-8'))) {
                return trim($try);
            }
        }
    }
    if (function_exists('mb_convert_encoding')) {
        foreach (['UTF-8', 'Windows-874', 'ISO-8859-11'] as $from) {
            try {
                $try = @mb_convert_encoding($s, 'UTF-8', $from);
            } catch (Throwable $e) {
                $try = false;
            }
            if (is_string($try) && $try !== '') {
                return trim($try);
            }
        }
    }
    return trim($s);
}

function hiw_read_cache() {
    $path = hiw_cache_path();
    if (!is_file($path)) {
        return null;
    }
    $raw = @file_get_contents($path);
    if ($raw === false || $raw === '') {
        return null;
    }
    $data = json_decode($raw, true);
    if (!is_array($data) || empty($data['fetched_at'])) {
        return null;
    }
    if ((time() - (int)$data['fetched_at']) > hiw_cache_ttl()) {
        return null;
    }
    return $data;
}

function hiw_write_cache(array $payload) {
    $path = hiw_cache_path();
    $payload['fetched_at'] = time();
    @file_put_contents($path, json_encode($payload, JSON_UNESCAPED_UNICODE), LOCK_EX);
}

/**
 * ดึงสรุป ward วันนี้ (ตัด Grafana time-range / VIP / stayRate ออกเพื่อเบา query)
 */
function hiw_query_wards($hos) {
    $sql = "
SELECT
  CAST(CONVERT(GROUP_CONCAT(DISTINCT w.shortname) USING utf8) AS CHAR) AS wardname,
  CAST(CONVERT(GROUP_CONCAT(DISTINCT w.name SEPARATOR ' / ') USING utf8) AS CHAR) AS ward_name,
  COALESCE((SELECT SUM(wx.bedcount) FROM ward wx WHERE wx.shortname = w.shortname), 0) AS maxbed,
  COUNT(DISTINCT CASE WHEN a.regdate = CURDATE() THEN a.an END) AS newAdmit,
  (
    SELECT COUNT(DISTINCT aa.an)
    FROM an_stat aa
    WHERE aa.ward IN (SELECT wx.ward FROM ward wx WHERE wx.shortname = w.shortname)
      AND aa.dchdate = CURDATE()
  ) AS discharge,
  COUNT(DISTINCT a.an) AS stay,
  COALESCE((SELECT SUM(wx.bedcount) FROM ward wx WHERE wx.shortname = w.shortname), 0)
    - COUNT(DISTINCT a.an) AS blank,
  MIN(w.sort) AS sort
FROM ward w
LEFT JOIN an_stat a
  ON w.ward = a.ward
 AND a.dchdate IS NULL
 AND a.an > 630000000
WHERE w.ward_active = 'Y'
  AND w.shortname NOT IN ('HI','HO','EXT','EXT2','CI','CI2')
GROUP BY w.shortname
ORDER BY sort, wardname
";
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return ['ok' => false, 'error' => mysqli_error($hos) ?: 'query failed', 'wards' => []];
    }
    $wards = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $name = hiw_decode_text($r['wardname'] ?? '');
        $full = hiw_decode_text($r['ward_name'] ?? '');
        if (hiw_is_hidden_ward($name, $full)) {
            continue;
        }
        $maxbed = (int)($r['maxbed'] ?? 0);
        $stay = (int)($r['stay'] ?? 0);
        $blank = (int)($r['blank'] ?? 0);
        $admit = (int)($r['newAdmit'] ?? 0);
        $dc = (int)($r['discharge'] ?? 0);
        $occ = $maxbed > 0 ? round(($stay / $maxbed) * 100, 1) : 0.0;
        $wards[] = [
            'wardname' => $name,
            'ward_name' => $full !== '' ? $full : $name,
            'maxbed' => $maxbed,
            'stay' => $stay,
            'blank' => $blank,
            'admit' => $admit,
            'discharge' => $dc,
            'occ_pct' => $occ,
            'critical' => hiw_is_critical_ward($name) ? 1 : 0,
            'sort' => (int)($r['sort'] ?? 0),
        ];
    }
    return ['ok' => true, 'error' => '', 'wards' => $wards];
}

function hiw_summarize(array $wards) {
    $sum = [
        'wards' => count($wards),
        'maxbed' => 0,
        'stay' => 0,
        'blank' => 0,
        'admit' => 0,
        'discharge' => 0,
        'critical_blank' => 0,
        'general_blank' => 0,
        'overcap' => 0,
    ];
    foreach ($wards as $w) {
        $sum['maxbed'] += (int)$w['maxbed'];
        $sum['stay'] += (int)$w['stay'];
        $sum['blank'] += (int)$w['blank'];
        $sum['admit'] += (int)$w['admit'];
        $sum['discharge'] += (int)$w['discharge'];
        if (!empty($w['critical'])) {
            $sum['critical_blank'] += (int)$w['blank'];
        } else {
            $sum['general_blank'] += (int)$w['blank'];
        }
        if ((int)$w['blank'] < 0) {
            $sum['overcap']++;
        }
    }
    $sum['occ_pct'] = $sum['maxbed'] > 0
        ? round(($sum['stay'] / $sum['maxbed']) * 100, 1)
        : 0.0;
    return $sum;
}

/**
 * สถิติ Order / ระยะเวลา
 * 1) Key   = Drug Viewer datescan → datesave
 * 2) Check = datesave → tham_pip_dispense.dispensed_at (Tham HOS-Safe)
 * 3) Total = datescan → dispensed_at
 */
function hiw_empty_order_stats($error = '') {
    $emptyMin = ['n' => 0, 'avg' => null, 'min' => null, 'max' => null];
    return [
        'ok' => false,
        'error' => (string)$error,
        'pending_total' => 0,
        'pending_by_type' => [],
        'pending_urgent' => 0,
        'pending_normal' => 0,
        'pending_home' => 0,
        'pending_urgent_over30' => 0,
        'keyed_today' => 0,
        'keyed_with_drugs' => 0,
        'waiting_pay' => 0,
        'waiting_pay_by_type' => [],
        'waiting_pay_urgent' => 0,
        'waiting_pay_normal' => 0,
        'waiting_pay_home' => 0,
        'waiting_pay_urgent_over30' => 0,
        'dispensed_today' => 0,
        'dispensed_from_keyed' => 0,
        'matched_pairs' => 0,
        'scanned_today' => 0,
        'key_minutes' => $emptyMin,
        'key_minutes_all_keyed' => $emptyMin,
        'check_minutes' => $emptyMin,
        'total_minutes' => $emptyMin,
        'timing_rows' => [],
        'timing_ward_options' => [],
        'timing_type_options' => [
            ['id' => 1, 'key' => 'urgent', 'name' => 'ยาเร่งด่วน'],
            ['id' => 2, 'key' => 'normal', 'name' => 'ยาปกติ'],
            ['id' => 3, 'key' => 'home', 'name' => 'ยากลับบ้าน'],
        ],
        'timing_consult_excluded' => 0,
        'timing_exclude_consult_default' => 1,
        'stats_date' => date('Y-m-d'),
    ];
}

function hiw_minute_stats_row($row) {
    $n = (int)($row['n'] ?? 0);
    if ($n <= 0) {
        return ['n' => 0, 'avg' => null, 'min' => null, 'max' => null];
    }
    return [
        'n' => $n,
        'avg' => isset($row['avg_m']) && $row['avg_m'] !== null ? round((float)$row['avg_m'], 1) : null,
        'min' => isset($row['min_m']) && $row['min_m'] !== null ? round((float)$row['min_m'], 1) : null,
        'max' => isset($row['max_m']) && $row['max_m'] !== null ? round((float)$row['max_m'], 1) : null,
    ];
}

function hiw_minute_stats_from_list(array $mins) {
    $mins = array_values(array_filter($mins, function ($v) {
        return is_numeric($v) && $v >= 0;
    }));
    $n = count($mins);
    if ($n <= 0) {
        return ['n' => 0, 'avg' => null, 'min' => null, 'max' => null];
    }
    return [
        'n' => $n,
        'avg' => round(array_sum($mins) / $n, 1),
        'min' => round((float)min($mins), 1),
        'max' => round((float)max($mins), 1),
    ];
}

function hiw_norm_an($an) {
    $an = trim((string)$an);
    if ($an === '') {
        return '';
    }
    $trim = ltrim($an, '0');
    return $trim === '' ? '0' : $trim;
}

/** ผู้ Key จาก Drug Viewer ที่เป็น Consult (เช่น Consult COM1-4) — ไม่นับในสถิติเวลา */
function hiw_is_consult_key_user($userName) {
    return (bool)preg_match('/consult/i', (string)$userName);
}

/**
 * จับคู่ scan (DV) กับรายการบันทึกผู้จ่าย (Tham) ตาม AN + เวลา
 * — scan.datesave ต้องไม่ช้ากว่า dispensed_at และใช้ใบที่ใกล้ที่สุด / ยังไม่ถูกใช้
 */
function hiw_pair_scan_dispense(array $scans, array $dispenses) {
    $byAn = [];
    foreach ($scans as $s) {
        $k = hiw_norm_an($s['an'] ?? '');
        if ($k === '' || empty($s['datesave_ts']) || empty($s['datescan_ts'])) {
            continue;
        }
        $byAn[$k][] = $s;
    }
    foreach ($byAn as &$list) {
        usort($list, function ($a, $b) {
            return ($a['datesave_ts'] <=> $b['datesave_ts']);
        });
    }
    unset($list);

    usort($dispenses, function ($a, $b) {
        return ($a['dispensed_ts'] <=> $b['dispensed_ts']);
    });

    $pairs = [];
    $usedScan = [];
    foreach ($dispenses as $d) {
        $k = hiw_norm_an($d['an'] ?? '');
        $dts = (int)($d['dispensed_ts'] ?? 0);
        if ($k === '' || $dts <= 0 || empty($byAn[$k])) {
            continue;
        }
        $bestIdx = -1;
        $bestGap = null;
        foreach ($byAn[$k] as $i => $s) {
            $sid = (int)($s['id'] ?? 0);
            if ($sid > 0 && isset($usedScan[$sid])) {
                continue;
            }
            $saveTs = (int)$s['datesave_ts'];
            if ($saveTs > $dts) {
                continue;
            }
            // Key → จ่าย ไม่เกิน 8 ชม.
            $gap = $dts - $saveTs;
            if ($gap > 8 * 3600) {
                continue;
            }
            if ($bestGap === null || $gap < $bestGap) {
                $bestGap = $gap;
                $bestIdx = $i;
            }
        }
        if ($bestIdx < 0) {
            continue;
        }
        $s = $byAn[$k][$bestIdx];
        $sid = (int)($s['id'] ?? 0);
        if ($sid > 0) {
            $usedScan[$sid] = true;
        }
        $pairs[] = [
            'scan_id' => $sid,
            'datescan_ts' => (int)$s['datescan_ts'],
            'datesave_ts' => (int)$s['datesave_ts'],
            'dispensed_ts' => $dts,
            'scr_type' => (int)($s['scr_type'] ?? 0),
            'ward' => (string)($s['ward'] ?? ''),
            'ward_name' => (string)($s['ward_name'] ?? ''),
            'user_id' => (int)($s['user_id'] ?? 0),
            'user_name' => (string)($s['user_name'] ?? ''),
            'is_consult' => !empty($s['is_consult']) ? 1 : 0,
        ];
    }
    return ['pairs' => $pairs, 'used_scan_ids' => $usedScan];
}

/** แปลง rxdate + rxtime ของ HOSxP เป็น unix timestamp */
function hiw_rx_datetime_ts($rxdate, $rxtime) {
    $d = substr(trim((string)$rxdate), 0, 10);
    if ($d === '' || $d === '0000-00-00' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) {
        return 0;
    }
    $t = trim((string)$rxtime);
    if ($t === '') {
        $t = '12:00:00';
    } elseif (preg_match('/^\d{1,2}:\d{2}$/', $t)) {
        $p = explode(':', $t);
        $t = sprintf('%02d:%02d:00', (int)$p[0], (int)$p[1]);
    } elseif (preg_match('/^\d{1,2}:\d{2}:\d{2}$/', $t)) {
        $p = explode(':', $t);
        $t = sprintf('%02d:%02d:%02d', (int)$p[0], (int)$p[1], (int)$p[2]);
    } else {
        $t = '12:00:00';
    }
    $ts = strtotime($d . ' ' . $t);
    return $ts ? (int)$ts : 0;
}

/**
 * ดึง Order ประเภท IRx / HME ที่มีรายการยา จาก HOSxP ตามรายการ AN
 * @return list<array{an:string,order_no:string,order_type:string,order_ts:int,drug_count:int,rxdate:string,rxtime:string}>
 */
function hiw_fetch_irx_hme_with_drugs($hos, array $anList, $dayFrom) {
    $out = [];
    if (!$hos || empty($anList)) {
        return $out;
    }
    if (!function_exists('pop_cols')) {
        require_once __DIR__ . '/patient_opd_helper.php';
    }
    $ocols = pop_cols($hos, 'ipt_order_no');
    $opcols = pop_cols($hos, 'opitemrece');
    if (!$ocols || !pop_has($ocols, 'an') || !pop_has($ocols, 'order_no') || !pop_has($ocols, 'order_type')) {
        return $out;
    }
    if (!$opcols || !pop_has($opcols, 'order_no') || !pop_has($opcols, 'an')) {
        return $out;
    }
    $rxdate = pop_has($ocols, 'rxdate') ? 'ion.rxdate' : (pop_has($ocols, 'order_date') ? 'ion.order_date' : '');
    $rxtime = pop_has($ocols, 'rxtime') ? 'ion.rxtime' : (pop_has($ocols, 'order_time') ? 'ion.order_time' : "''");
    if ($rxdate === '') {
        return $out;
    }
    $hasItemCount = pop_has($ocols, 'item_count');
    $dayFrom = substr(trim((string)$dayFrom), 0, 10);
    if ($dayFrom === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dayFrom)) {
        $dayFrom = date('Y-m-d', strtotime('-1 day'));
    }
    $dayEsc = mysqli_real_escape_string($hos, $dayFrom);

    $uniq = [];
    foreach ($anList as $an) {
        $an = trim((string)$an);
        if ($an !== '') {
            $uniq[$an] = true;
        }
    }
    $ans = array_keys($uniq);
    if (!$ans) {
        return $out;
    }

    $icodeCond = pop_has($opcols, 'icode')
        ? "TRIM(IFNULL(o.icode,'')) <> ''"
        : '1=1';

    foreach (array_chunk($ans, 80) as $chunk) {
        $in = [];
        foreach ($chunk as $an) {
            $in[] = "'" . mysqli_real_escape_string($hos, $an) . "'";
        }
        $inSql = implode(',', $in);
        $itemExpr = $hasItemCount ? 'IFNULL(ion.item_count, 0)' : '0';
        $rows = pop_query_all($hos, "
            SELECT ion.an AS an,
                   ion.order_no AS order_no,
                   UPPER(TRIM(IFNULL(ion.order_type,''))) AS order_type,
                   $rxdate AS rxdate,
                   $rxtime AS rxtime,
                   $itemExpr AS item_count,
                   COUNT(o.order_no) AS drug_rows
            FROM ipt_order_no ion
            LEFT JOIN opitemrece o
              ON o.an = ion.an
             AND o.order_no = ion.order_no
             AND $icodeCond
            WHERE ion.an IN ($inSql)
              AND UPPER(TRIM(IFNULL(ion.order_type,''))) IN ('IRX', 'HME')
              AND DATE($rxdate) >= '$dayEsc'
            GROUP BY ion.an, ion.order_no, ion.order_type, $rxdate, $rxtime" .
            ($hasItemCount ? ', ion.item_count' : '') . "
            HAVING ($itemExpr > 0 OR COUNT(o.order_no) > 0)
            ORDER BY $rxdate ASC, $rxtime ASC, ion.order_no ASC
            LIMIT 8000
        ");
        foreach ($rows as $r) {
            $an = trim((string)($r['an'] ?? ''));
            $on = trim((string)($r['order_no'] ?? ''));
            if ($an === '' || $on === '') {
                continue;
            }
            $drugCount = max((int)($r['item_count'] ?? 0), (int)($r['drug_rows'] ?? 0));
            if ($drugCount <= 0) {
                continue;
            }
            $ots = hiw_rx_datetime_ts($r['rxdate'] ?? '', $r['rxtime'] ?? '');
            if ($ots <= 0) {
                continue;
            }
            $out[] = [
                'an' => $an,
                'order_no' => $on,
                'order_type' => strtoupper(trim((string)($r['order_type'] ?? ''))),
                'order_ts' => $ots,
                'drug_count' => $drugCount,
                'rxdate' => substr(trim((string)($r['rxdate'] ?? '')), 0, 10),
                'rxtime' => trim((string)($r['rxtime'] ?? '')),
            ];
        }
    }
    return $out;
}

/**
 * จับคู่ใบ scan (Key แล้ว) กับ Order IRx/HME ที่มีรายการยา (1:1 ตาม AN + เวลา)
 * @return array<int, array> scan_id => order row
 */
function hiw_pair_scan_irx_hme(array $scans, array $orders) {
    $byAn = [];
    foreach ($orders as $o) {
        $k = hiw_norm_an($o['an'] ?? '');
        if ($k === '' || (int)($o['drug_count'] ?? 0) <= 0 || empty($o['order_ts'])) {
            continue;
        }
        $byAn[$k][] = $o;
    }
    foreach ($byAn as &$list) {
        usort($list, function ($a, $b) {
            return ((int)$a['order_ts'] <=> (int)$b['order_ts']);
        });
    }
    unset($list);

    $sorted = $scans;
    usort($sorted, function ($a, $b) {
        return ((int)($a['datesave_ts'] ?? 0) <=> (int)($b['datesave_ts'] ?? 0));
    });

    $map = [];
    $usedOrder = [];
    foreach ($sorted as $s) {
        $sid = (int)($s['id'] ?? 0);
        $k = hiw_norm_an($s['an'] ?? '');
        $scanTs = (int)($s['datescan_ts'] ?? 0);
        $saveTs = (int)($s['datesave_ts'] ?? 0);
        if ($sid <= 0 || $k === '' || $scanTs <= 0 || $saveTs <= 0 || empty($byAn[$k])) {
            continue;
        }
        $preferHme = ((int)($s['scr_type'] ?? 0) === 3);
        $bestIdx = -1;
        $bestScore = null;
        foreach ($byAn[$k] as $i => $o) {
            $okey = $k . '|' . trim((string)($o['order_no'] ?? ''));
            if ($okey === ($k . '|') || isset($usedOrder[$okey])) {
                continue;
            }
            $ots = (int)$o['order_ts'];
            // สแกนมักมาก่อนเวลา Order ใน HOSxP — อนุญาตก่อนสแกนเล็กน้อย / หลัง Key ไม่เกิน 8 ชม.
            if ($ots < ($scanTs - 30 * 60)) {
                continue;
            }
            if ($ots > ($saveTs + 8 * 3600)) {
                continue;
            }
            $gap = abs($ots - $saveTs);
            if ($gap > 8 * 3600) {
                continue;
            }
            $otype = strtoupper((string)($o['order_type'] ?? ''));
            $score = $gap;
            if ($preferHme && $otype === 'HME') {
                $score -= 180;
            } elseif (!$preferHme && $otype === 'IRX') {
                $score -= 180;
            }
            if ($ots >= $scanTs) {
                $score -= 60;
            }
            if ($bestScore === null || $score < $bestScore) {
                $bestScore = $score;
                $bestIdx = $i;
            }
        }
        if ($bestIdx < 0) {
            continue;
        }
        $o = $byAn[$k][$bestIdx];
        $okey = $k . '|' . trim((string)($o['order_no'] ?? ''));
        $usedOrder[$okey] = true;
        $map[$sid] = $o;
    }
    return $map;
}

/**
 * แผนที่ scan_id → IRx/HME ที่มียา สำหรับชุด scan ที่ Key แล้ว
 * @return array{map: array<int,array>, ok: bool, error: string}
 */
function hiw_build_scan_irx_hme_map($con, array $scans) {
    $empty = ['map' => [], 'ok' => false, 'error' => ''];
    if (empty($scans)) {
        return ['map' => [], 'ok' => true, 'error' => ''];
    }
    $ans = [];
    foreach ($scans as $s) {
        $an = trim((string)($s['an'] ?? ''));
        if ($an !== '') {
            $ans[] = $an;
        }
    }
    if (!$ans) {
        return ['map' => [], 'ok' => true, 'error' => ''];
    }
    $hos = hosxp_connect($con, 25);
    if (!$hos) {
        $empty['error'] = 'เชื่อมต่อ HOSxP ไม่ได้';
        return $empty;
    }
    $dayFrom = date('Y-m-d', strtotime('-1 day'));
    $orders = hiw_fetch_irx_hme_with_drugs($hos, $ans, $dayFrom);
    @mysqli_close($hos);
    return [
        'map' => hiw_pair_scan_irx_hme($scans, $orders),
        'ok' => true,
        'error' => '',
    ];
}

function hiw_fetch_order_stats($con) {
    if (!function_exists('drug_viewer_connect')) {
        require_once __DIR__ . '/drug_viewer_helper.php';
    }
    if (!function_exists('pip_ensure_dispense_table')) {
        require_once __DIR__ . '/patient_ipd_helper.php';
    }

    $out = hiw_empty_order_stats();
    $dv = drug_viewer_connect($con, 20);
    if (!$dv) {
        $out['error'] = 'เชื่อมต่อ Drug Viewer ไม่ได้';
        return $out;
    }

    $ipd = "an IS NOT NULL AND TRIM(an) <> ''";
    $pending = "(datesave IS NULL OR datesave = '0000-00-00 00:00:00' OR datesave < '2000-01-01')";
    $keyed = "(datesave IS NOT NULL AND datesave >= '2000-01-01')";

    $q = drug_viewer_query($dv, "
        SELECT COUNT(*) AS c FROM scan
        WHERE datescan >= CURDATE() AND $ipd
    ");
    $out['scanned_today'] = (int)(($q ? mysqli_fetch_assoc($q)['c'] : 0) ?? 0);

    $q = drug_viewer_query($dv, "
        SELECT COUNT(*) AS c FROM scan
        WHERE datescan >= CURDATE() AND $ipd AND $pending
    ");
    $out['pending_total'] = (int)(($q ? mysqli_fetch_assoc($q)['c'] : 0) ?? 0);

    $types = function_exists('drug_viewer_type_map') ? drug_viewer_type_map($dv) : [];
    $wardMap = function_exists('drug_viewer_ward_map') ? drug_viewer_ward_map($dv) : [];
    $userMap = function_exists('drug_viewer_user_map') ? drug_viewer_user_map($dv) : [];
    $q = drug_viewer_query($dv, "
        SELECT scr_type, COUNT(*) AS c FROM scan
        WHERE datescan >= CURDATE() AND $ipd AND $pending
        GROUP BY scr_type
        ORDER BY c DESC
    ");
    $by = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $tid = (int)($r['scr_type'] ?? 0);
            $by[] = [
                'id' => $tid,
                'name' => $types[$tid] ?? ('ประเภท ' . $tid),
                'count' => (int)($r['c'] ?? 0),
            ];
        }
    }
    $out['pending_by_type'] = $by;
    $pendingUrgent = 0;
    $pendingNormal = 0;
    $pendingHome = 0;
    foreach ($by as $row) {
        $tid = (int)($row['id'] ?? 0);
        $cnt = (int)($row['count'] ?? 0);
        if ($tid === 1) {
            $pendingUrgent += $cnt;
        } elseif ($tid === 3) {
            $pendingHome += $cnt;
        } elseif ($tid === 2) {
            $pendingNormal += $cnt;
        } else {
            $pendingNormal += $cnt;
        }
    }
    // ให้ผลรวมช่องย่อยตรงกับเลขรวมเสมอ
    $subSum = $pendingUrgent + $pendingNormal + $pendingHome;
    if ($subSum !== (int)$out['pending_total']) {
        $pendingNormal = max(0, (int)$out['pending_total'] - $pendingUrgent - $pendingHome);
    }
    $out['pending_urgent'] = $pendingUrgent;
    $out['pending_normal'] = $pendingNormal;
    $out['pending_home'] = $pendingHome;

    $q = drug_viewer_query($dv, "
        SELECT COUNT(*) AS c FROM scan
        WHERE datescan >= CURDATE() AND $ipd AND $pending
          AND scr_type = 1
          AND TIMESTAMPDIFF(MINUTE, datescan, NOW()) > 30
    ");
    $out['pending_urgent_over30'] = (int)(($q ? mysqli_fetch_assoc($q)['c'] : 0) ?? 0);

    $q = drug_viewer_query($dv, "
        SELECT COUNT(*) AS c FROM scan
        WHERE datesave >= CURDATE() AND $ipd AND $keyed
    ");
    $out['keyed_today'] = (int)(($q ? mysqli_fetch_assoc($q)['c'] : 0) ?? 0);

    $q = drug_viewer_query($dv, "
        SELECT COUNT(*) AS n,
               ROUND(AVG(TIMESTAMPDIFF(MINUTE, datescan, datesave)), 1) AS avg_m,
               MIN(TIMESTAMPDIFF(MINUTE, datescan, datesave)) AS min_m,
               MAX(TIMESTAMPDIFF(MINUTE, datescan, datesave)) AS max_m
        FROM scan
        WHERE datesave >= CURDATE() AND $ipd AND $keyed
          AND datescan IS NOT NULL AND datescan >= DATE_SUB(CURDATE(), INTERVAL 2 DAY)
          AND TIMESTAMPDIFF(MINUTE, datescan, datesave) BETWEEN 0 AND 480
    ");
    // เวลา Key ของทุกใบที่ Key วันนี้ (อาจคนละชุดกับ Check/Total)
    $out['key_minutes_all_keyed'] = hiw_minute_stats_row($q ? mysqli_fetch_assoc($q) : []);

    // สแกนที่ Key แล้ว (จับคู่ Check/Total ย้อนหลัง 8 วัน + คิวรอจ่ายวันนี้)
    $scans = [];
    $q = drug_viewer_query($dv, "
        SELECT id, an, datescan, datesave, scr_type, ward, user_id
        FROM scan
        WHERE $ipd AND $keyed
          AND datesave >= DATE_SUB(CURDATE(), INTERVAL 8 DAY)
          AND datescan IS NOT NULL AND datescan >= DATE_SUB(CURDATE(), INTERVAL 9 DAY)
        ORDER BY datesave ASC
        LIMIT 12000
    ");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $scanTs = strtotime((string)($r['datescan'] ?? ''));
            $saveTs = strtotime((string)($r['datesave'] ?? ''));
            if (!$scanTs || !$saveTs || $saveTs < $scanTs) {
                continue;
            }
            $wid = trim((string)($r['ward'] ?? ''));
            $uid = (int)($r['user_id'] ?? 0);
            $uname = $uid > 0 ? (string)($userMap[$uid] ?? '') : '';
            $scans[] = [
                'id' => (int)($r['id'] ?? 0),
                'an' => (string)($r['an'] ?? ''),
                'datescan_ts' => $scanTs,
                'datesave_ts' => $saveTs,
                'scr_type' => (int)($r['scr_type'] ?? 0),
                'ward' => $wid,
                'ward_name' => $wardMap[$wid] ?? $wid,
                'user_id' => $uid,
                'user_name' => $uname,
                'is_consult' => hiw_is_consult_key_user($uname) ? 1 : 0,
            ];
        }
    }
    drug_viewer_close($dv);

    // บันทึกผู้จ่ายย้อนหลัง 8 วันจาก Tham HOS-Safe (เทียบเมื่อวาน / เฉลี่ย 7 วัน)
    $dispenses = [];
    $dispensedToday = 0;
    $todayYmd = date('Y-m-d');
    if ($con) {
        pip_ensure_dispense_table($con);
        $dq = @mysqli_query($con, "
            SELECT an, order_no, dispensed_at
            FROM tham_pip_dispense
            WHERE dispensed_at >= DATE_SUB(CURDATE(), INTERVAL 8 DAY)
            ORDER BY dispensed_at ASC
            LIMIT 12000
        ");
        if ($dq) {
            while ($r = mysqli_fetch_assoc($dq)) {
                $dts = strtotime((string)($r['dispensed_at'] ?? ''));
                if (!$dts) {
                    continue;
                }
                if (date('Y-m-d', $dts) === $todayYmd) {
                    $dispensedToday++;
                }
                $dispenses[] = [
                    'an' => (string)($r['an'] ?? ''),
                    'order_no' => (string)($r['order_no'] ?? ''),
                    'dispensed_ts' => $dts,
                ];
            }
        }
    }
    $out['dispensed_today'] = $dispensedToday;

    $matched = hiw_pair_scan_dispense($scans, $dispenses);
    $pairs = $matched['pairs'] ?? [];
    $usedScanIds = $matched['used_scan_ids'] ?? [];
    $matchedTodayN = 0;
    foreach ($pairs as $p) {
        $dts = (int)($p['dispensed_ts'] ?? 0);
        if ($dts > 0 && date('Y-m-d', $dts) === $todayYmd) {
            $matchedTodayN++;
        }
    }
    $out['matched_pairs'] = $matchedTodayN;

    // จับคู่ scan ↔ IRx/HME ที่มีรายการยา — เฉพาะ Key วันนี้ (ไม่ดึงย้อนหลังทั้งก้อน)
    $todayStart = strtotime(date('Y-m-d 00:00:00'));
    $scansForIrx = [];
    foreach ($scans as $s) {
        if ((int)($s['datesave_ts'] ?? 0) >= $todayStart) {
            $scansForIrx[] = $s;
        }
    }
    $irxMapPack = hiw_build_scan_irx_hme_map($con, $scansForIrx);
    $scanIrxMap = $irxMapPack['map'] ?? [];
    $irxMapOk = !empty($irxMapPack['ok']);

    // เวลา Key / Check / Total ใช้ชุดออเดอร์จับคู่เดียวกัน → Total ≈ Key + Check
    // (ค่าสรุปรวมด้านล่าง = หลังยกเว้น Consult — UI สามารถสลับรวม/ยกเว้นได้จาก timing_rows)
    // การ์ดสรุปใช้เฉพาะคู่ที่จ่ายวันนี้ — คู่ย้อนหลังอยู่ใน timing_rows สำหรับเทียบเมื่อวาน/7 วัน
    $keyMins = [];
    $checkMins = [];
    $totalMins = [];
    $timingRows = [];
    $wardOpt = [];
    $consultExcluded = 0;
    foreach ($pairs as $p) {
        $key = ($p['datesave_ts'] - $p['datescan_ts']) / 60.0;
        $check = ($p['dispensed_ts'] - $p['datesave_ts']) / 60.0;
        $total = ($p['dispensed_ts'] - $p['datescan_ts']) / 60.0;
        if ($key < 0 || $key > 480 || $check < 0 || $check > 480 || $total < 0 || $total > 720) {
            continue;
        }

        $dispTs = (int)($p['dispensed_ts'] ?? 0);
        $dispDay = $dispTs > 0 ? date('Y-m-d', $dispTs) : '';
        $isTodayPair = ($dispDay !== '' && $dispDay === $todayYmd);

        $isConsult = !empty($p['is_consult']) || hiw_is_consult_key_user($p['user_name'] ?? '');
        if ($isConsult) {
            if ($isTodayPair) {
                $consultExcluded++;
            }
        } elseif ($isTodayPair) {
            $keyMins[] = $key;
            $checkMins[] = $check;
            $totalMins[] = $total;
        }

        $tid = (int)($p['scr_type'] ?? 0);
        if ($tid !== 1 && $tid !== 2 && $tid !== 3) {
            $tid = 2; // อื่นๆ นับรวมยาปกติ
        }
        $wid = trim((string)($p['ward'] ?? ''));
        $wname = trim((string)($p['ward_name'] ?? ''));
        if ($wname === '') {
            $wname = $wid !== '' ? (($wardMap[$wid] ?? $wid)) : 'ไม่ระบุหอ';
        }
        if ($wid === '') {
            $wid = '_none';
        }
        $scanTs = (int)($p['datescan_ts'] ?? 0);
        $timingRows[] = [
            't' => $tid,
            'w' => $wid,
            'wn' => $wname,
            'k' => round($key, 1),
            'c' => round($check, 1),
            'tot' => round($total, 1),
            'xc' => $isConsult ? 1 : 0, // 1 = Consult key (ยกเว้นได้)
            'un' => (string)($p['user_name'] ?? ''),
            'sh' => $scanTs > 0 ? (int)date('G', $scanTs) : -1, // ชั่วโมง scan 0-23 (กรองเวร)
            'dd' => $dispDay, // วันที่จ่าย (เทียบเมื่อวาน / 7 วัน)
        ];
        if (!isset($wardOpt[$wid])) {
            $wardOpt[$wid] = $wname;
        }
    }
    // การ์ดเวลา: จากชุดจับคู่เดียวกัน (avg Key + avg Check = avg Total) — ไม่รวม Consult
    $out['key_minutes'] = hiw_minute_stats_from_list($keyMins);
    $out['check_minutes'] = hiw_minute_stats_from_list($checkMins);
    $out['total_minutes'] = hiw_minute_stats_from_list($totalMins);
    $out['timing_rows'] = $timingRows;
    $out['timing_consult_excluded'] = $consultExcluded;
    $out['timing_exclude_consult_default'] = 1;

    $wardOptions = [];
    foreach ($wardOpt as $wid => $wname) {
        $wardOptions[] = ['id' => (string)$wid, 'name' => (string)$wname];
    }
    usort($wardOptions, function ($a, $b) {
        return strcasecmp($a['name'], $b['name']);
    });
    $out['timing_ward_options'] = $wardOptions;

    $typeOpts = [];
    foreach ([1 => 'urgent', 2 => 'normal', 3 => 'home'] as $tid => $tkey) {
        $defaultName = $tid === 1 ? 'ยาเร่งด่วน' : ($tid === 2 ? 'ยาปกติ' : 'ยากลับบ้าน');
        $typeOpts[] = [
            'id' => $tid,
            'key' => $tkey,
            'name' => $types[$tid] ?? $defaultName,
        ];
    }
    $out['timing_type_options'] = $typeOpts;

    // คิว Key มียาวันนี้ (ชุดเดียวกัน):
    //   มียา = รอจ่าย + บันทึกจ่าย(จับคู่แล้ว)
    // รอจ่าย = Key วันนี้ + Map IRx/HME มียา + ยังไม่จับคู่บันทึกผู้จ่าย
    // บันทึกจ่าย(คิว) = Key วันนี้มียา ที่จับคู่บันทึกผู้จ่ายแล้ว (ไม่ใช่จำนวนแถว Tham ทั้งหมด)
    // (ถ้าเชื่อม HOSxP ไม่ได้ → fallback นับทุกใบ Key เหมือนเดิม)
    $waitingPay = 0;
    $waitUrgent = 0;
    $waitNormal = 0;
    $waitHome = 0;
    $waitUrgentOver30 = 0;
    $waitByType = [];
    $keyedWithDrugs = 0;
    $dispensedFromKeyed = 0;
    $nowTs = time();
    foreach ($scans as $s) {
        $sid = (int)($s['id'] ?? 0);
        $saveTs = (int)($s['datesave_ts'] ?? 0);
        if ($sid <= 0 || $saveTs < $todayStart) {
            continue;
        }
        $hasDrugs = !$irxMapOk || isset($scanIrxMap[$sid]);
        if (!$hasDrugs) {
            continue;
        }
        $keyedWithDrugs++;
        // จับคู่กับบันทึกจ่ายแล้ว (ปกติ dispenseday = วันนี้ เพราะ Key วันนี้)
        if (isset($usedScanIds[$sid])) {
            $dispensedFromKeyed++;
            continue;
        }
        $waitingPay++;
        $tid = (int)($s['scr_type'] ?? 0);
        if (!isset($waitByType[$tid])) {
            $waitByType[$tid] = [
                'id' => $tid,
                'name' => $types[$tid] ?? ('ประเภท ' . $tid),
                'count' => 0,
            ];
        }
        $waitByType[$tid]['count']++;
        if ($tid === 1) {
            $waitUrgent++;
            if (($nowTs - $saveTs) > 30 * 60) {
                $waitUrgentOver30++;
            }
        } elseif ($tid === 3) {
            $waitHome++;
        } else {
            $waitNormal++;
        }
    }
    // กันเลขเพี้ยนจาก race/ข้อมูลค้าง — ให้สมการตรงเสมอ
    if (($waitingPay + $dispensedFromKeyed) !== $keyedWithDrugs) {
        $dispensedFromKeyed = max(0, $keyedWithDrugs - $waitingPay);
    }
    usort($waitByType, function ($a, $b) {
        return ($b['count'] <=> $a['count']);
    });
    $out['keyed_with_drugs'] = $keyedWithDrugs;
    $out['dispensed_from_keyed'] = $dispensedFromKeyed;
    $out['waiting_pay'] = $waitingPay;
    $out['waiting_pay_by_type'] = array_values($waitByType);
    $out['waiting_pay_urgent'] = $waitUrgent;
    $out['waiting_pay_normal'] = $waitNormal;
    $out['waiting_pay_home'] = $waitHome;
    $out['waiting_pay_urgent_over30'] = $waitUrgentOver30;

    $out['stats_date'] = date('Y-m-d');
    $out['ok'] = true;
    $out['error'] = '';
    return $out;
}

/**
 * ประวัติระยะเวลา Order ตามช่วงวันที่จ่าย (จับคู่ Scan→Key→จ่าย)
 * @return array{ok:bool,error:string,date_from:string,date_to:string,timing_rows:array,timing_type_options:array,timing_ward_options:array,pair_count:int}
 */
function hiw_fetch_timing_history($con, $dateFrom, $dateTo) {
    $today = date('Y-m-d');
    $dateFrom = substr(trim((string)$dateFrom), 0, 10);
    $dateTo = substr(trim((string)$dateTo), 0, 10);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
        $dateFrom = date('Y-m-d', strtotime('-6 days'));
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) {
        $dateTo = $today;
    }
    if ($dateTo > $today) {
        $dateTo = $today;
    }
    if ($dateFrom > $dateTo) {
        $tmp = $dateFrom;
        $dateFrom = $dateTo;
        $dateTo = $tmp;
    }
    $fromTs = strtotime($dateFrom . ' 00:00:00');
    $toTs = strtotime($dateTo . ' 00:00:00');
    if (!$fromTs || !$toTs) {
        return [
            'ok' => false,
            'error' => 'ช่วงวันที่ไม่ถูกต้อง',
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'timing_rows' => [],
            'timing_type_options' => [],
            'timing_ward_options' => [],
            'pair_count' => 0,
        ];
    }
    $spanDays = (int)round(($toTs - $fromTs) / 86400) + 1;
    if ($spanDays > 31) {
        $dateFrom = date('Y-m-d', strtotime($dateTo . ' -30 days'));
        $fromTs = strtotime($dateFrom . ' 00:00:00');
        $spanDays = (int)round(($toTs - $fromTs) / 86400) + 1;
    }

    if (!function_exists('drug_viewer_connect')) {
        require_once __DIR__ . '/drug_viewer_helper.php';
    }
    if (!function_exists('pip_ensure_dispense_table')) {
        require_once __DIR__ . '/patient_ipd_helper.php';
    }

    $emptyTypes = [
        ['id' => 1, 'key' => 'urgent', 'name' => 'ยาเร่งด่วน'],
        ['id' => 2, 'key' => 'normal', 'name' => 'ยาปกติ'],
        ['id' => 3, 'key' => 'home', 'name' => 'ยากลับบ้าน'],
    ];

    $dv = drug_viewer_connect($con, 25);
    if (!$dv) {
        return [
            'ok' => false,
            'error' => 'เชื่อมต่อ Drug Viewer ไม่ได้',
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'timing_rows' => [],
            'timing_type_options' => $emptyTypes,
            'timing_ward_options' => [],
            'pair_count' => 0,
        ];
    }

    $ipd = "an IS NOT NULL AND TRIM(an) <> ''";
    $keyed = "(datesave IS NOT NULL AND datesave >= '2000-01-01')";
    $types = drug_viewer_type_map($dv);
    $wardMap = drug_viewer_ward_map($dv);
    $userMap = drug_viewer_user_map($dv);

    $fromEsc = mysqli_real_escape_string($dv, $dateFrom);
    $toEsc = mysqli_real_escape_string($dv, $dateTo);
    // สแกนอาจ Key ก่อนวันจ่าย — เผื่อย้อนหลัง 2 วันจาก date_from
    $scanFromEsc = mysqli_real_escape_string($dv, date('Y-m-d', strtotime($dateFrom . ' -2 days')));

    $scans = [];
    $q = drug_viewer_query($dv, "
        SELECT id, an, datescan, datesave, scr_type, ward, user_id
        FROM scan
        WHERE $ipd AND $keyed
          AND datesave >= '$scanFromEsc 00:00:00'
          AND datesave < DATE_ADD('$toEsc', INTERVAL 1 DAY)
          AND datescan IS NOT NULL AND datescan >= '$scanFromEsc 00:00:00'
        ORDER BY datesave ASC
        LIMIT 20000
    ");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $scanTs = strtotime((string)($r['datescan'] ?? ''));
            $saveTs = strtotime((string)($r['datesave'] ?? ''));
            if (!$scanTs || !$saveTs || $saveTs < $scanTs) {
                continue;
            }
            $wid = trim((string)($r['ward'] ?? ''));
            $uid = (int)($r['user_id'] ?? 0);
            $uname = $uid > 0 ? (string)($userMap[$uid] ?? '') : '';
            $scans[] = [
                'id' => (int)($r['id'] ?? 0),
                'an' => (string)($r['an'] ?? ''),
                'datescan_ts' => $scanTs,
                'datesave_ts' => $saveTs,
                'scr_type' => (int)($r['scr_type'] ?? 0),
                'ward' => $wid,
                'ward_name' => $wardMap[$wid] ?? $wid,
                'user_id' => $uid,
                'user_name' => $uname,
                'is_consult' => hiw_is_consult_key_user($uname) ? 1 : 0,
            ];
        }
    }
    drug_viewer_close($dv);

    $dispenses = [];
    if ($con) {
        pip_ensure_dispense_table($con);
        $fromEscT = mysqli_real_escape_string($con, $dateFrom);
        $toEscT = mysqli_real_escape_string($con, $dateTo);
        $dq = @mysqli_query($con, "
            SELECT an, order_no, dispensed_at
            FROM tham_pip_dispense
            WHERE dispensed_at >= '$fromEscT 00:00:00'
              AND dispensed_at < DATE_ADD('$toEscT', INTERVAL 1 DAY)
            ORDER BY dispensed_at ASC
            LIMIT 20000
        ");
        if ($dq) {
            while ($r = mysqli_fetch_assoc($dq)) {
                $dts = strtotime((string)($r['dispensed_at'] ?? ''));
                if (!$dts) {
                    continue;
                }
                $dispenses[] = [
                    'an' => (string)($r['an'] ?? ''),
                    'order_no' => (string)($r['order_no'] ?? ''),
                    'dispensed_ts' => $dts,
                ];
            }
        }
    }

    $matched = hiw_pair_scan_dispense($scans, $dispenses);
    $pairs = $matched['pairs'] ?? [];
    $timingRows = [];
    $wardOpt = [];
    foreach ($pairs as $p) {
        $key = ($p['datesave_ts'] - $p['datescan_ts']) / 60.0;
        $check = ($p['dispensed_ts'] - $p['datesave_ts']) / 60.0;
        $total = ($p['dispensed_ts'] - $p['datescan_ts']) / 60.0;
        if ($key < 0 || $key > 480 || $check < 0 || $check > 480 || $total < 0 || $total > 720) {
            continue;
        }
        $dispTs = (int)($p['dispensed_ts'] ?? 0);
        $dispDay = $dispTs > 0 ? date('Y-m-d', $dispTs) : '';
        if ($dispDay === '' || $dispDay < $dateFrom || $dispDay > $dateTo) {
            continue;
        }
        $tid = (int)($p['scr_type'] ?? 0);
        if ($tid !== 1 && $tid !== 2 && $tid !== 3) {
            $tid = 2;
        }
        $wid = trim((string)($p['ward'] ?? ''));
        $wname = trim((string)($p['ward_name'] ?? ''));
        if ($wname === '') {
            $wname = $wid !== '' ? (($wardMap[$wid] ?? $wid)) : 'ไม่ระบุหอ';
        }
        if ($wid === '') {
            $wid = '_none';
        }
        $scanTs = (int)($p['datescan_ts'] ?? 0);
        $isConsult = !empty($p['is_consult']) || hiw_is_consult_key_user($p['user_name'] ?? '');
        $timingRows[] = [
            't' => $tid,
            'w' => $wid,
            'wn' => $wname,
            'k' => round($key, 1),
            'c' => round($check, 1),
            'tot' => round($total, 1),
            'xc' => $isConsult ? 1 : 0,
            'un' => (string)($p['user_name'] ?? ''),
            'sh' => $scanTs > 0 ? (int)date('G', $scanTs) : -1,
            'dd' => $dispDay,
        ];
        if (!isset($wardOpt[$wid])) {
            $wardOpt[$wid] = $wname;
        }
    }

    $wardOptions = [];
    foreach ($wardOpt as $wid => $wname) {
        $wardOptions[] = ['id' => (string)$wid, 'name' => (string)$wname];
    }
    usort($wardOptions, function ($a, $b) {
        return strcasecmp($a['name'], $b['name']);
    });

    $typeOpts = [];
    foreach ([1 => 'urgent', 2 => 'normal', 3 => 'home'] as $tid => $tkey) {
        $defaultName = $tid === 1 ? 'ยาเร่งด่วน' : ($tid === 2 ? 'ยาปกติ' : 'ยากลับบ้าน');
        $typeOpts[] = [
            'id' => $tid,
            'key' => $tkey,
            'name' => $types[$tid] ?? $defaultName,
        ];
    }

    return [
        'ok' => true,
        'error' => '',
        'date_from' => $dateFrom,
        'date_to' => $dateTo,
        'span_days' => $spanDays,
        'timing_rows' => $timingRows,
        'timing_type_options' => $typeOpts,
        'timing_ward_options' => $wardOptions,
        'pair_count' => count($timingRows),
    ];
}

/**
 * รายการคิว Order สำหรับ modal
 * @param string $kind pending_key|waiting_pay
 */
function hiw_list_order_queue($con, $kind = 'pending_key', $limit = 200) {
    $kind = trim((string)$kind);
    if (!in_array($kind, ['pending_key', 'waiting_pay'], true)) {
        return ['ok' => false, 'error' => 'ชนิดคิวไม่ถูกต้อง', 'kind' => $kind, 'items' => [], 'count' => 0];
    }
    $limit = max(1, min(500, (int)$limit));

    if (!function_exists('drug_viewer_connect')) {
        require_once __DIR__ . '/drug_viewer_helper.php';
    }
    if (!function_exists('pip_ensure_dispense_table')) {
        require_once __DIR__ . '/patient_ipd_helper.php';
    }

    $dv = drug_viewer_connect($con, 20);
    if (!$dv) {
        return ['ok' => false, 'error' => 'เชื่อมต่อ Drug Viewer ไม่ได้', 'kind' => $kind, 'items' => [], 'count' => 0];
    }

    $ipd = "an IS NOT NULL AND TRIM(an) <> ''";
    $pending = "(datesave IS NULL OR datesave = '0000-00-00 00:00:00' OR datesave < '2000-01-01')";
    $keyed = "(datesave IS NOT NULL AND datesave >= '2000-01-01')";
    $types = drug_viewer_type_map($dv);
    $wards = drug_viewer_ward_map($dv);
    $users = drug_viewer_user_map($dv);
    $now = time();
    $items = [];

    if ($kind === 'pending_key') {
        $q = drug_viewer_query($dv, "
            SELECT id, an, hn, patient, ward, datescan, datesave, scr_type, user_id
            FROM scan
            WHERE datescan >= CURDATE() AND $ipd AND $pending
            ORDER BY datescan ASC
            LIMIT $limit
        ");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $scanTs = strtotime((string)($r['datescan'] ?? ''));
                $tid = (int)($r['scr_type'] ?? 0);
                $wid = trim((string)($r['ward'] ?? ''));
                $uid = (int)($r['user_id'] ?? 0);
                $wait = ($scanTs && $scanTs <= $now) ? round(($now - $scanTs) / 60.0, 1) : null;
                $items[] = [
                    'id' => (int)($r['id'] ?? 0),
                    'an' => (string)($r['an'] ?? ''),
                    'hn' => (string)($r['hn'] ?? ''),
                    'patient' => hiw_decode_text($r['patient'] ?? ''),
                    'ward' => $wid,
                    'ward_name' => $wards[$wid] ?? $wid,
                    'datescan' => (string)($r['datescan'] ?? ''),
                    'datesave' => (string)($r['datesave'] ?? ''),
                    'scr_type' => $tid,
                    'type_name' => $types[$tid] ?? ('ประเภท ' . $tid),
                    'user_id' => $uid,
                    'user_name' => $users[$uid] ?? '',
                    'wait_minutes' => $wait,
                ];
            }
        }
        drug_viewer_close($dv);
        return [
            'ok' => true,
            'error' => '',
            'kind' => $kind,
            'title' => 'รายการรอ Key',
            'items' => $items,
            'count' => count($items),
        ];
    }

    // waiting_pay: Key วันนี้ ยังไม่ถูกจับคู่กับบันทึกผู้จ่าย
    $scans = [];
    $q = drug_viewer_query($dv, "
        SELECT id, an, hn, patient, ward, datescan, datesave, scr_type, user_id
        FROM scan
        WHERE datesave >= CURDATE() AND $ipd AND $keyed
          AND datescan IS NOT NULL AND datescan >= DATE_SUB(CURDATE(), INTERVAL 2 DAY)
        ORDER BY datesave ASC
        LIMIT 5000
    ");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $scanTs = strtotime((string)($r['datescan'] ?? ''));
            $saveTs = strtotime((string)($r['datesave'] ?? ''));
            if (!$scanTs || !$saveTs || $saveTs < $scanTs) {
                continue;
            }
            $scans[] = [
                'id' => (int)($r['id'] ?? 0),
                'an' => (string)($r['an'] ?? ''),
                'hn' => (string)($r['hn'] ?? ''),
                'patient' => (string)($r['patient'] ?? ''),
                'ward' => trim((string)($r['ward'] ?? '')),
                'datescan' => (string)($r['datescan'] ?? ''),
                'datesave' => (string)($r['datesave'] ?? ''),
                'scr_type' => (int)($r['scr_type'] ?? 0),
                'user_id' => (int)($r['user_id'] ?? 0),
                'datescan_ts' => $scanTs,
                'datesave_ts' => $saveTs,
            ];
        }
    }

    $dispenses = [];
    if ($con) {
        pip_ensure_dispense_table($con);
        $dq = @mysqli_query($con, "
            SELECT an, order_no, dispensed_at
            FROM tham_pip_dispense
            WHERE dispensed_at >= CURDATE()
            ORDER BY dispensed_at ASC
            LIMIT 5000
        ");
        if ($dq) {
            while ($r = mysqli_fetch_assoc($dq)) {
                $dts = strtotime((string)($r['dispensed_at'] ?? ''));
                if (!$dts) {
                    continue;
                }
                $dispenses[] = [
                    'an' => (string)($r['an'] ?? ''),
                    'order_no' => (string)($r['order_no'] ?? ''),
                    'dispensed_ts' => $dts,
                ];
            }
        }
    }

    $matched = hiw_pair_scan_dispense($scans, $dispenses);
    $used = $matched['used_scan_ids'] ?? [];
    $irxMapPack = hiw_build_scan_irx_hme_map($con, $scans);
    $scanIrxMap = $irxMapPack['map'] ?? [];
    $irxMapOk = !empty($irxMapPack['ok']);
    foreach ($scans as $s) {
        $sid = (int)($s['id'] ?? 0);
        if ($sid <= 0 || isset($used[$sid])) {
            continue;
        }
        if ($irxMapOk && !isset($scanIrxMap[$sid])) {
            continue;
        }
        if (count($items) >= $limit) {
            break;
        }
        $tid = (int)($s['scr_type'] ?? 0);
        $wid = (string)($s['ward'] ?? '');
        $uid = (int)($s['user_id'] ?? 0);
        $saveTs = (int)($s['datesave_ts'] ?? 0);
        $wait = ($saveTs && $saveTs <= $now) ? round(($now - $saveTs) / 60.0, 1) : null;
        $mapped = $scanIrxMap[$sid] ?? null;
        $mapType = strtoupper((string)(($mapped['order_type'] ?? '')));
        $mapLabel = $mapType === 'IRX' ? 'IRx' : ($mapType === 'HME' ? 'HME' : $mapType);
        $items[] = [
            'id' => $sid,
            'an' => (string)($s['an'] ?? ''),
            'hn' => (string)($s['hn'] ?? ''),
            'patient' => hiw_decode_text($s['patient'] ?? ''),
            'ward' => $wid,
            'ward_name' => $wards[$wid] ?? $wid,
            'datescan' => (string)($s['datescan'] ?? ''),
            'datesave' => (string)($s['datesave'] ?? ''),
            'scr_type' => $tid,
            'type_name' => $types[$tid] ?? ('ประเภท ' . $tid),
            'user_id' => $uid,
            'user_name' => $users[$uid] ?? '',
            'wait_minutes' => $wait,
            'mapped_order_no' => (string)(($mapped['order_no'] ?? '')),
            'mapped_order_type' => $mapLabel,
            'mapped_drug_count' => (int)(($mapped['drug_count'] ?? 0)),
        ];
    }
    drug_viewer_close($dv);

    return [
        'ok' => true,
        'error' => '',
        'kind' => $kind,
        'title' => 'รายการรอจ่าย (Key แล้ว · Map IRx/HME มียา · ยังไม่บันทึกผู้จ่าย)',
        'items' => $items,
        'count' => count($items),
    ];
}

/**
 * รวมยาเร่งด่วน (scr_type=1) ที่รอ Key / รอจ่าย > 30 นาที แยกตามหอ
 * คีย์ map = shortname ตัวพิมพ์ใหญ่ (เทียบกับ wardname ในแผนที่)
 */
function hiw_fetch_urgent_over30_by_ward($con) {
    $by = [];
    foreach (['pending_key', 'waiting_pay'] as $kind) {
        $q = hiw_list_order_queue($con, $kind, 500);
        if (empty($q['ok']) || empty($q['items']) || !is_array($q['items'])) {
            continue;
        }
        foreach ($q['items'] as $it) {
            if ((int)($it['scr_type'] ?? 0) !== 1) {
                continue;
            }
            $wait = (float)($it['wait_minutes'] ?? 0);
            if ($wait <= 30) {
                continue;
            }
            $wid = trim((string)($it['ward'] ?? ''));
            $wname = trim((string)($it['ward_name'] ?? ''));
            if ($wname === '') {
                $wname = $wid;
            }
            $key = strtoupper(preg_replace('/\s+/', ' ', $wname));
            if ($key === '') {
                $key = '_NONE';
            }
            if (!isset($by[$key])) {
                $by[$key] = [
                    'ward' => $wid,
                    'ward_name' => $wname,
                    'pending_key' => 0,
                    'waiting_pay' => 0,
                    'total' => 0,
                ];
            }
            $by[$key][$kind]++;
            $by[$key]['total']++;
        }
    }
    return $by;
}

function hiw_match_urgent_ward(array $byWard, $wardname, $wardFull = '') {
    $candidates = [];
    $n = strtoupper(trim(preg_replace('/\s+/', ' ', (string)$wardname)));
    $f = strtoupper(trim(preg_replace('/\s+/', ' ', (string)$wardFull)));
    if ($n !== '') {
        $candidates[] = $n;
    }
    if ($f !== '' && $f !== $n) {
        $candidates[] = $f;
    }
    foreach ($candidates as $c) {
        if (isset($byWard[$c])) {
            return $byWard[$c];
        }
    }
    foreach ($byWard as $k => $row) {
        foreach ($candidates as $c) {
            if ($c === '' || $k === '' || $k === '_NONE') {
                continue;
            }
            if (strpos($k, $c) !== false || strpos($c, $k) !== false) {
                return $row;
            }
        }
    }
    return null;
}

function hiw_attach_urgent_over30(array $wards, array $byWard) {
    foreach ($wards as &$w) {
        $hit = hiw_match_urgent_ward($byWard, $w['wardname'] ?? '', $w['ward_name'] ?? '');
        $w['urgent_over30'] = (int)($hit['total'] ?? 0);
        $w['urgent_over30_key'] = (int)($hit['pending_key'] ?? 0);
        $w['urgent_over30_pay'] = (int)($hit['waiting_pay'] ?? 0);
    }
    unset($w);
    return $wards;
}

function hiw_get_overview($con, $force = false) {
    if (!$force) {
        $cached = hiw_read_cache();
        if ($cached !== null) {
            $cached['cached'] = true;
            return $cached;
        }
    }

    $orders = hiw_fetch_order_stats($con);
    $urgentByWard = [];
    if (!empty($orders['ok'])) {
        $urgentByWard = hiw_fetch_urgent_over30_by_ward($con);
        $orders['urgent_over30_by_ward'] = array_values($urgentByWard);
    }

    $hos = hosxp_connect($con, 25);
    if (!$hos) {
        return [
            'ok' => !empty($orders['ok']),
            'error' => 'เชื่อมต่อ HOSxP ไม่ได้',
            'wards' => [],
            'summary' => hiw_summarize([]),
            'orders' => $orders,
            'cached' => false,
            'ttl' => hiw_cache_ttl(),
            'as_of' => date('Y-m-d H:i:s'),
            'fetched_at' => time(),
        ];
    }

    $res = hiw_query_wards($hos);
    @mysqli_close($hos);

    $wards = hiw_attach_urgent_over30($res['wards'] ?? [], $urgentByWard);

    $payload = [
        'ok' => !empty($res['ok']) || !empty($orders['ok']),
        'error' => (string)($res['error'] ?? ''),
        'wards' => $wards,
        'summary' => hiw_summarize($wards),
        'orders' => $orders,
        'cached' => false,
        'ttl' => hiw_cache_ttl(),
        'as_of' => date('Y-m-d H:i:s'),
    ];
    if ($payload['ok']) {
        hiw_write_cache($payload);
    }
    $payload['fetched_at'] = time();
    return $payload;
}
