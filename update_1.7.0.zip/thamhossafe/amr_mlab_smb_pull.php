<?php
/**
 * ดึงไฟล์ DBF จากแชร์ Windows mLAB มาเก็บในโฟลเดอร์บนเซิร์ฟเวอร์นี้
 * CLI: php amr_mlab_smb_pull.php [--inspect]
 */
ini_set('display_errors', 1);
error_reporting(E_ALL);
set_time_limit(300);

if (php_sapi_name() !== 'cli') {
    fwrite(STDERR, "CLI only\n");
    exit(1);
}

include __DIR__ . '/connect.php';
require_once __DIR__ . '/amr_mlab_helper.php';
mysqli_set_charset($con, 'utf8');

$cfg = amr_mlab_get_config($con);
$res = amr_mlab_smb_pull($cfg, true);
echo json_encode($res, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
if (empty($res['ok'])) {
    exit(1);
}
if (in_array('--inspect', $argv, true)) {
    $inspect = amr_mlab_dbf_inspect($res['local']);
    echo json_encode($inspect, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
}
