<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
$default_start = date('Y-01-01');
$default_end = date('Y-m-d');
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_GET['start_date'] ?? ''))) {
    $default_start = (string)$_GET['start_date'];
}
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_GET['end_date'] ?? ''))) {
    $default_end = (string)$_GET['end_date'];
}
$prefill_q = trim((string)($_GET['q'] ?? ''));
$prefill_view = trim((string)($_GET['view'] ?? 'all'));
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ประวัติแพ้ยาใน รพ. - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        :root { --ah-rose: #be123c; --ah-dark: #9f1239; }
        .ah-hero {
            background: linear-gradient(135deg, #9f1239 0%, #e11d48 50%, #fb7185 100%);
            color: #fff; border-radius: 12px; padding: 1.15rem 1.4rem;
            box-shadow: 0 8px 24px rgba(190, 18, 60, 0.25);
        }
        .ah-kpi { border: 0; border-radius: 12px; }
        .ah-kpi .num { font-size: 1.6rem; font-weight: 800; }
        .ah-table thead { background: #9f1239; color: #fff; font-size: 0.8rem; }
        .ah-row-incomplete { background: #fff7ed; }
        .ah-row-incomplete:hover { background: #ffedd5; }
        .ah-row-preventable td.ah-prev { font-weight: 700; }
        .ah-alert-bar { border-radius: 10px; }
        .kpi-click { cursor: pointer; transition: transform .12s; }
        .kpi-click:hover { transform: translateY(-2px); }
        .kpi-click.active-kpi { outline: 2px solid #be123c; }
        .ah-table { table-layout: fixed; width: 100%; }
        .ah-table thead th.ah-sort {
            cursor: pointer; user-select: none; white-space: normal; line-height: 1.2;
        }
        .ah-clip {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            word-break: break-word;
            overflow-wrap: anywhere;
            line-height: 1.3;
            max-height: 2.6em;
        }
        .ah-table thead th.ah-sort:hover { background: #be123c; }
        .ah-table thead th.ah-sort .sort-ico { font-size: 0.7rem; margin-left: 4px; opacity: 0.45; }
        .ah-table thead th.ah-sort.is-sorted .sort-ico { opacity: 1; }
        .ah-sort-hint { font-size: 0.78rem; color: #64748b; }
        .badge-true { font-size: 0.75rem; }
        .ah-row { cursor: pointer; }
        .ah-row:hover { background: #fff1f2; }
        .btn-ah { background: var(--ah-rose); color: #fff; border: 0; }
        .btn-ah:hover { background: var(--ah-dark); color: #fff; }
        .ah-dlg-label { font-size: 0.78rem; color: #64748b; font-weight: 700; }
        .ah-dlg-val { font-weight: 600; min-height: 1.4em; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="ah-hero mb-4 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <div class="small opacity-75 mb-1"><i class="fas fa-hospital me-1"></i>ระบบแพ้ยา · HOSxP opd_allergy</div>
                    <h4 class="fw-bold mb-1"><i class="fas fa-notes-medical me-2"></i>ประวัติแพ้ยาใน รพ.</h4>
                    <small id="ahHosname">ดึงจากบันทึกข้อมูลการแพ้ยา HOSxP</small>
                </div>
                <a href="allergy_followup.php" class="btn btn-light btn-sm fw-bold text-danger">
                    <i class="fas fa-book-medical me-1"></i> ไปติดตามการแพ้ยา
                </a>
            </div>

            <div class="row g-2 mb-3" id="ahKpis">
                <div class="col-6 col-lg"><div class="card ah-kpi shadow-sm kpi-click active-kpi" data-view="all"><div class="card-body py-3 text-center"><div class="text-muted small">รายการ</div><div class="num text-danger" id="kpiTotal">-</div></div></div></div>
                <div class="col-6 col-lg"><div class="card ah-kpi shadow-sm"><div class="card-body py-3 text-center"><div class="text-muted small">ผู้ป่วย</div><div class="num" id="kpiPt">-</div></div></div></div>
                <div class="col-6 col-lg"><div class="card ah-kpi shadow-sm kpi-click" data-view="incomplete"><div class="card-body py-3 text-center"><div class="text-muted small">ไม่สมบูรณ์</div><div class="num text-warning" id="kpiIncomplete">-</div></div></div></div>
                <div class="col-6 col-lg"><div class="card ah-kpi shadow-sm kpi-click" data-view="preventable"><div class="card-body py-3 text-center"><div class="text-muted small">Preventable ADR</div><div class="num text-danger" id="kpiPreventable">-</div></div></div></div>
                <div class="col-6 col-lg"><div class="card ah-kpi shadow-sm kpi-click" data-view="alerts"><div class="card-body py-3 text-center"><div class="text-muted small">ปิดการแจ้งเตือน</div><div class="num" id="kpiNoAlert">-</div></div></div></div>
            </div>
            <div id="ahAlertBar" class="mb-3"></div>
            <div class="mb-3 d-flex flex-wrap gap-1" id="ahTypePills"></div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body py-2">
                    <div class="row g-2 align-items-end">
                        <div class="col-6 col-md-2">
                            <label class="form-label small mb-0">จากวันที่รายงาน</label>
                            <input type="date" class="form-control form-control-sm" id="flt_start" value="<?= $default_start ?>">
                        </div>
                        <div class="col-6 col-md-2">
                            <label class="form-label small mb-0">ถึงวันที่</label>
                            <input type="date" class="form-control form-control-sm" id="flt_end" value="<?= $default_end ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small mb-0">อาการรุนแรง</label>
                            <select class="form-select form-select-sm" id="flt_true">
                                <option value="">ทั้งหมด</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small mb-0">ค้นหา HN / ชื่อ / ยา / อาการ / ผู้ประเมิน</label>
                            <input type="text" class="form-control form-control-sm" id="flt_q" placeholder="เช่น Penicillin, DRESS, HN, ชื่อผู้ประเมิน" value="<?= htmlspecialchars($prefill_q, ENT_QUOTES, 'UTF-8') ?>">
                        </div>
                        <div class="col-md-3">
                            <div class="form-check mb-1">
                                <input class="form-check-input" type="checkbox" id="flt_severe">
                                <label class="form-check-label small" for="flt_severe">เฉพาะอาการรุนแรง (DRESS/SJS/TEN/Anaphylaxis/MALA)</label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" id="flt_unique">
                                <label class="form-check-label small" for="flt_unique">นับคนละครั้งตาม CID</label>
                            </div>
                            <button type="button" class="btn btn-ah btn-sm fw-bold" id="btnLoad"><i class="fas fa-search me-1"></i>โหลด</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm" id="btnExport"><i class="fas fa-file-csv me-1"></i>CSV</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="d-flex justify-content-between align-items-center px-3 pt-2">
                    <div class="ah-sort-hint"><i class="fas fa-sort me-1"></i>คลิกหัวคอลัมน์เพื่อเรียง A-Z / Z-A</div>
                    <div class="small text-muted" id="ahSortLabel"></div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-sm align-middle mb-0 ah-table">
                        <colgroup id="ahColgroup"></colgroup>
                        <thead class="text-center">
                            <tr id="ahThead"></tr>
                        </thead>
                        <tbody id="ahTbody">
                            <tr><td colspan="13" class="text-center text-muted py-4">กดโหลดเพื่อดึงประวัติจาก HOSxP</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="ahModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header" style="background:#fff1f2;">
                <h5 class="modal-title fw-bold text-danger"><i class="fas fa-notes-medical me-2"></i>บันทึกข้อมูลการแพ้ยา</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="ahModalBody"></div>
            <div class="modal-footer">
                <a class="btn btn-ah btn-sm fw-bold" id="ahOpenFollow" href="allergy_report.php">แจ้งเคสแพ้ยา</a>
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิด</button>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const TRUE_COLOR = {
    DRESS: 'bg-danger', SJS: 'bg-danger', TEN: 'bg-dark',
    Anaphylaxis: 'bg-warning text-dark', 'Anaphylactic shock': 'bg-warning text-dark',
    MALA: 'bg-info text-dark'
};
let ahRows = [];
let ahModal;
let ahSort = { key: 'report_date', dir: 'desc' };
let ahView = <?= json_encode(in_array($prefill_view, ['all', 'incomplete', 'preventable', 'alerts'], true) ? $prefill_view : 'all') ?>;
const AH_COLS = [
    { key: 'report_date', label: 'วันที่รายงาน', type: 'date', w: '6%' },
    { key: 'hn_display', label: 'HN', type: 'hn', w: '6%' },
    { key: 'fullname', label: 'ชื่อ-สกุล', clip: true, w: '10%' },
    { key: 'agent', label: 'ยาที่แพ้', clip: true, w: '9%' },
    { key: 'symptom', label: 'อาการที่แพ้', clip: true, w: '10%' },
    { key: 'true_symptom', label: 'อาการรุนแรง', w: '7%' },
    { key: 'seriousness_name', label: 'ความรุนแรง', clip: true, w: '8%' },
    { key: 'relation_name', label: 'ความสัมพันธ์', clip: true, w: '8%' },
    { key: 'source_name', label: 'แหล่งข้อมูล', clip: true, w: '8%' },
    { key: 'evaluator_name', label: 'ผู้ประเมิน', clip: true, w: '10%' },
    { key: 'completeness_label', label: 'ความสมบูรณ์', w: '6%' },
    { key: 'preventable_label', label: 'Preventable', w: '6%' },
    { key: 'alert_label', label: 'การเตือน', w: '8%' }
];
const COLSPAN = AH_COLS.length;

function sortIcon(key) {
    if (ahSort.key !== key) return '<i class="fas fa-sort sort-ico"></i>';
    return ahSort.dir === 'asc'
        ? '<i class="fas fa-sort-alpha-down sort-ico"></i>'
        : '<i class="fas fa-sort-alpha-up sort-ico"></i>';
}
function clip(s) {
    const t = (s == null || s === '') ? '-' : String(s);
    return '<div class="ah-clip" title="' + esc(t) + '">' + esc(t) + '</div>';
}
function renderHead() {
    $('#ahColgroup').html(AH_COLS.map(c => '<col style="width:' + (c.w || 'auto') + '">').join(''));
    $('#ahThead').html(AH_COLS.map(c => {
        const on = ahSort.key === c.key ? ' is-sorted' : '';
        const title = ahSort.key === c.key
            ? (ahSort.dir === 'asc' ? 'เรียง A-Z (คลิกเพื่อ Z-A)' : 'เรียง Z-A (คลิกเพื่อ A-Z)')
            : 'คลิกเรียง A-Z';
        return '<th class="ah-sort' + on + '" data-sort="' + c.key + '" title="' + title + '">'
            + esc(c.label) + sortIcon(c.key) + '</th>';
    }).join(''));
    const col = AH_COLS.find(c => c.key === ahSort.key);
    $('#ahSortLabel').text(col ? (col.label + ' · ' + (ahSort.dir === 'asc' ? 'A → Z' : 'Z → A')) : '');
}
function cmpVal(a, b, type) {
    const va = (a == null ? '' : String(a)).trim();
    const vb = (b == null ? '' : String(b)).trim();
    if (va === '' && vb === '') return 0;
    if (va === '') return 1;
    if (vb === '') return -1;
    if (type === 'date') return va.localeCompare(vb);
    if (type === 'hn') {
        const na = parseInt(va.replace(/\D/g, ''), 10);
        const nb = parseInt(vb.replace(/\D/g, ''), 10);
        if (!isNaN(na) && !isNaN(nb) && na !== nb) return na - nb;
    }
    return va.localeCompare(vb, 'th', { numeric: true, sensitivity: 'base' });
}
function sortedRows() {
    const col = AH_COLS.find(c => c.key === ahSort.key) || AH_COLS[0];
    const dir = ahSort.dir === 'desc' ? -1 : 1;
    return ahRows.filter(function(r) {
        if (ahView === 'incomplete') return !r.is_complete;
        if (ahView === 'preventable') return !!r.is_preventable;
        if (ahView === 'alerts') return !!r.is_no_alert || (r.warnings && r.warnings.length);
        return true;
    }).slice().sort((a, b) => dir * cmpVal(a[col.key], b[col.key], col.type));
}
function completenessBadge(r) {
    if (r.is_complete) return '<span class="badge bg-success">สมบูรณ์</span>';
    const n = (r.missing_fields || []).length;
    return '<span class="badge bg-warning text-dark" title="' + esc((r.missing_fields || []).join(', ')) + '">ไม่สมบูรณ์' + (n ? ' ' + n : '') + '</span>';
}
function preventableBadge(r) {
    if (r.is_preventable) {
        return '<span class="badge bg-danger">' + esc(r.preventable_label || 'Preventable') + '</span>';
    }
    if ((r.preventable_label || '') === 'Not preventable') {
        return '<span class="badge bg-secondary">Not preventable</span>';
    }
    return '<span class="text-muted">-</span>';
}
function alertBadges(r) {
    const bits = r.alert_bits || [];
    const warns = r.warnings || [];
    if (!bits.length && !warns.length) return '<span class="text-muted">-</span>';
    let html = bits.map(function(b) {
        let cls = 'bg-secondary';
        if (b === 'ห้ามสั่งใช้' || b === 'แพ้ยา') cls = 'bg-danger';
        else if (b === 'ไม่แจ้งเตือน' || b === 'ไม่ห้ามสั่งใช้') cls = 'bg-warning text-dark';
        else if (b === 'เฝ้าระวังการใช้ยา') cls = 'bg-info text-dark';
        return '<span class="badge ' + cls + ' me-1">' + esc(b) + '</span>';
    }).join('');
    if (warns.length) {
        html += '<span class="badge bg-dark" title="' + esc(warns.join(' | ')) + '"><i class="fas fa-exclamation-triangle"></i> ' + warns.length + '</span>';
    }
    return html || '<span class="text-muted">-</span>';
}
function renderAlertBar(s) {
    const msgs = [];
    if ((s.incomplete || 0) > 0) {
        msgs.push('<div class="alert alert-warning ah-alert-bar py-2 mb-2"><i class="fas fa-exclamation-triangle me-1"></i><b>ลงแพ้ยาไม่สมบูรณ์ ' + s.incomplete + ' รายการ</b> — ขาดยา/อาการ/ความรุนแรง/ความสัมพันธ์/แหล่งข้อมูล/ผู้ประเมิน คลิกการ์ด «ไม่สมบูรณ์» เพื่อกรอง</div>');
    }
    if ((s.preventable || 0) > 0) {
        msgs.push('<div class="alert alert-danger ah-alert-bar py-2 mb-2"><i class="fas fa-shield-alt me-1"></i><b>Preventable ADR ' + s.preventable + ' รายการ</b> — มีการติ๊ก Preventable ใน HOSxP คลิกการ์ดเพื่อกรอง</div>');
    }
    if ((s.no_alert || 0) > 0) {
        msgs.push('<div class="alert alert-secondary ah-alert-bar py-2 mb-2"><i class="fas fa-bell-slash me-1"></i>มี ' + s.no_alert + ' รายการที่ติ๊ก <b>ไม่ต้องแจ้งเตือน</b></div>');
    }
    $('#ahAlertBar').html(msgs.join(''));
}
function emptyRow(msg, danger) {
    return '<tr><td colspan="' + COLSPAN + '" class="text-center ' + (danger ? 'text-danger' : 'text-muted') + ' py-4">' + msg + '</td></tr>';
}
function renderTable() {
    renderHead();
    if (!ahRows.length) {
        $('#ahTbody').html(emptyRow('ไม่พบประวัติแพ้ยาในช่วงที่เลือก'));
        return;
    }
    const rows = sortedRows();
    if (!rows.length) {
        $('#ahTbody').html(emptyRow('ไม่มีรายการในมุมมองที่เลือก'));
        return;
    }
    $('#ahTbody').html(rows.map(function(r) {
        const badge = r.true_symptom
            ? '<span class="badge ' + (TRUE_COLOR[r.true_symptom] || 'bg-secondary') + ' badge-true">' + esc(r.true_symptom) + '</span>'
            : '<span class="text-muted">-</span>';
        return '<tr class="ah-row' + (r.is_complete ? '' : ' ah-row-incomplete') + (r.is_preventable ? ' ah-row-preventable' : '') + '" data-i="' + r._i + '">'
            + '<td class="text-nowrap">' + esc(fmtDate(r.report_date)) + '</td>'
            + '<td class="fw-bold text-nowrap">' + esc(r.hn_display) + '</td>'
            + '<td>' + clip(r.fullname) + '</td>'
            + '<td>' + clip(r.agent) + '</td>'
            + '<td>' + clip(r.symptom) + '</td>'
            + '<td class="text-center">' + badge + '</td>'
            + '<td>' + clip(r.seriousness_name) + '</td>'
            + '<td>' + clip(r.relation_name) + '</td>'
            + '<td>' + clip(r.source_name) + '</td>'
            + '<td>' + clip(r.evaluator_name || r.reporter_name || '-') + '</td>'
            + '<td class="text-center">' + completenessBadge(r) + '</td>'
            + '<td class="text-center ah-prev">' + preventableBadge(r) + '</td>'
            + '<td>' + alertBadges(r) + '</td>'
            + '</tr>';
    }).join(''));
}

function esc(s) {
    return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function fmtDate(iso) {
    if (!iso || iso === '0000-00-00') return '-';
    const p = String(iso).slice(0, 10).split('-');
    return p.length === 3 ? (p[2] + '/' + p[1] + '/' + p[0]) : iso;
}
function qs() {
    const p = new URLSearchParams({
        start_date: $('#flt_start').val(),
        end_date: $('#flt_end').val(),
        q: $('#flt_q').val(),
        true_type: $('#flt_true').val()
    });
    if ($('#flt_severe').is(':checked')) p.set('severe_only', '1');
    if ($('#flt_unique').is(':checked')) p.set('unique_cid', '1');
    return p;
}

function loadData() {
    $('#ahTbody').html(emptyRow('<i class="fas fa-spinner fa-spin me-1"></i>กำลังดึงจาก HOSxP...'));
    fetch('fetch_allergy_history_api.php?action=list&' + qs().toString(), { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') {
                $('#ahTbody').html(emptyRow(esc(data.message || 'โหลดไม่สำเร็จ'), true));
                return;
            }
            $('#ahHosname').text(data.hosname || '');
            const s = data.summary || {};
            $('#kpiTotal').text(s.total || 0);
            $('#kpiPt').text(s.patients || 0);
            $('#kpiIncomplete').text(s.incomplete || 0);
            $('#kpiPreventable').text(s.preventable || 0);
            $('#kpiNoAlert').text(s.no_alert || 0);
            renderAlertBar(s);
            const pills = Object.keys(s.by_type || {}).filter(k => s.by_type[k] > 0)
                .map(k => '<span class="badge ' + (TRUE_COLOR[k] || 'bg-secondary') + ' badge-true me-1">' + esc(k) + ' ' + s.by_type[k] + '</span>').join('');
            $('#ahTypePills').html(pills);
            ahRows = (data.rows || []).map(function(r, i) { r._i = i; return r; });
            renderTable();
        })
        .catch(() => {
            $('#ahTbody').html(emptyRow('โหลดไม่สำเร็จ', true));
        });
}

function field(label, val) {
    return '<div class="col-md-6 mb-2"><div class="ah-dlg-label">' + esc(label) + '</div><div class="ah-dlg-val">' + (val ? esc(val) : '-') + '</div></div>';
}

function openRow(i) {
    const r = ahRows[i];
    if (!r) return;
    const trueHtml = r.true_symptom
        ? '<span class="badge ' + (TRUE_COLOR[r.true_symptom] || 'bg-secondary') + '">' + esc(r.true_symptom) + '</span>'
        : '-';
    $('#ahModalBody').html(
        (r.is_complete
            ? '<div class="alert alert-success py-2 small"><i class="fas fa-check-circle me-1"></i>ลงแพ้ยาครบตามเกณฑ์ (ยา, อาการ, ความรุนแรง, ความสัมพันธ์, แหล่งข้อมูล, ผู้ประเมิน)</div>'
            : '<div class="alert alert-warning py-2 small"><i class="fas fa-exclamation-triangle me-1"></i><b>ลงแพ้ยาไม่สมบูรณ์</b> ขาด: ' + esc((r.missing_fields || []).join(', ') || '-') + '</div>')
        + ((r.warnings || []).length ? '<div class="alert alert-danger py-2 small"><b>คำเตือน:</b> ' + esc(r.warnings.join(' · ')) + '</div>' : '')
        + '<div class="row">'
        + field('HN', r.hn_display)
        + field('ชื่อ-สกุล', r.fullname)
        + field('CID', r.cid)
        + field('วันที่รายงาน', fmtDate(r.report_date))
        + field('วันที่เริ่มมีอาการ', fmtDate(r.onset_date))
        + field('แหล่งข้อมูล', r.source_name)
        + '<div class="col-12 mb-2"><div class="ah-dlg-label">ยาที่แพ้ (ชื่อสามัญ)</div><div class="ah-dlg-val text-danger">' + esc(r.agent || '-') + '</div></div>'
        + '<div class="col-12 mb-2"><div class="ah-dlg-label">อาการที่แพ้</div><div class="ah-dlg-val">' + esc(r.symptom || '-') + '</div></div>'
        + '<div class="col-md-6 mb-2"><div class="ah-dlg-label">อาการรุนแรง (จัดกลุ่ม)</div><div>' + trueHtml + '</div></div>'
        + field('ความรุนแรง', r.seriousness_name)
        + field('ความสัมพันธ์', r.relation_name)
        + field('Naranjo', r.naranjo)
        + field('ประเภทการแพ้', r.allergy_type_name)
        + field('ผู้ประเมิน', r.evaluator_name || r.reporter_name)
        + '<div class="col-md-6 mb-2"><div class="ah-dlg-label">Preventable ADR</div><div>' + preventableBadge(r) + '</div></div>'
        + '<div class="col-md-6 mb-2"><div class="ah-dlg-label">การเตือนใน HOSxP</div><div>' + alertBadges(r) + '</div></div>'
        + '<div class="col-12 mb-2"><div class="ah-dlg-label">หมายเหตุ</div><div class="ah-dlg-val" style="white-space:pre-wrap;">' + esc(r.note || '-') + '</div></div>'
        + '<div class="col-12"><div class="ah-dlg-label">ที่อยู่</div><div class="ah-dlg-val">' + esc(r.fulladdress || '-') + '</div></div>'
        + '</div>'
    );
    const detail = [r.agent, r.symptom, r.true_symptom].filter(Boolean).join(' · ');
                $('#ahOpenFollow').attr('href', 'allergy_report.php?hn=' + encodeURIComponent(r.hn_display || r.hn || '') + '&detail=' + encodeURIComponent(detail));
    ahModal.show();
}

$(function() {
    ahModal = new bootstrap.Modal(document.getElementById('ahModal'));
    fetch('fetch_allergy_history_api.php?action=meta', { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') return;
            if (data.hosname) $('#ahHosname').text(data.hosname);
            const sel = document.getElementById('flt_true');
            Object.keys(data.true_types || {}).forEach(k => {
                sel.insertAdjacentHTML('beforeend', '<option value="' + esc(k) + '">' + esc(data.true_types[k]) + '</option>');
            });
        });
    $('#ahKpis .kpi-click').removeClass('active-kpi');
    $('#ahKpis .kpi-click[data-view="' + ahView + '"]').addClass('active-kpi');
    $('#btnLoad').on('click', loadData);
    $('#flt_q').on('keydown', e => { if (e.key === 'Enter') loadData(); });
    $('#ahTbody').on('click', 'tr.ah-row', function() { openRow(this.getAttribute('data-i')); });
    $('#ahThead').on('click', 'th.ah-sort', function() {
        const key = this.getAttribute('data-sort');
        if (ahSort.key === key) {
            ahSort.dir = ahSort.dir === 'asc' ? 'desc' : 'asc';
        } else {
            ahSort.key = key;
            ahSort.dir = (key === 'report_date') ? 'desc' : 'asc';
        }
        renderTable();
    });
    $('#ahKpis').on('click', '.kpi-click', function() {
        ahView = this.getAttribute('data-view') || 'all';
        $('#ahKpis .kpi-click').removeClass('active-kpi');
        $(this).addClass('active-kpi');
        renderTable();
    });
    $('#btnExport').on('click', function() {
        window.location = 'fetch_allergy_history_api.php?action=export&' + qs().toString();
    });
    renderHead();
    loadData();
});
</script>
</body>
</html>
