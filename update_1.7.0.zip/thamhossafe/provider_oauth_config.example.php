<?php
/**
 * ตัวอย่างการตั้งค่า Health ID / Provider ID / Drugs Center
 * คัดลอกเป็น provider_oauth_config.php แล้วใส่ค่าจริง
 * ไฟล์ provider_oauth_config.php ห้ามอัปขึ้น GitHub / ห้ามใส่ใน zip อัปเดต
 *
 * Redirect URI ที่ลงทะเบียนกับ Health ID ต้องตรงกับ PROVIDER_OAUTH_REDIRECT_URI
 * ตัวอย่าง: https://your-host/thamhossafe/oauth_callback.php
 */

/** uat | prd */
define('PROVIDER_OAUTH_ENV', 'uat');

/** Health ID (OAuth login) */
define('HEALTH_ID_CLIENT_ID', 'your-health-id-client-id');
define('HEALTH_ID_CLIENT_SECRET', 'your-health-id-client-secret');

/** Provider ID (แลก moph_access_token_idp) */
define('PROVIDER_ID_CLIENT_ID', 'your-provider-id-client-id');
define('PROVIDER_ID_SECRET_KEY', 'your-provider-id-secret-key');

/**
 * Redirect URI หลัง login สำเร็จ — ต้องตรงกับที่ลงทะเบียนไว้
 * เว้นว่างได้: ระบบจะสร้างจาก URL ปัจจุบันอัตโนมัติ
 */
define('PROVIDER_OAUTH_REDIRECT_URI', '');

/** Drugs Center API Key */
define('DRUG_CENTER_API_KEY', 'your-drug-center-api-key');
