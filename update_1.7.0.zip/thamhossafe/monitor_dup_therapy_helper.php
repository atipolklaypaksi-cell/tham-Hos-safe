<?php
/**
 * Monitor คู่ยาซ้ำซ้อน (Therapeutic Duplication)
 */

function mdt_ensure_table($con, $seed = true) {
    static $done_schema = false;
    static $done_seed = false;
    if (!$done_schema) {
        $q = mysqli_query($con, "SHOW TABLES LIKE 'monitor_dup_therapy_settings'");
        if (!$q || mysqli_num_rows($q) === 0) {
            $sql = @file_get_contents(__DIR__ . '/sql/monitor_dup_therapy.sql');
            if ($sql === false || trim($sql) === '') {
                return false;
            }
            foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
                if ($stmt !== '' && !mysqli_query($con, $stmt)) {
                    return false;
                }
            }
        }
        mdt_ensure_pick_columns($con);
        mdt_ensure_label_width($con);
        mdt_ensure_match_mode_column($con);
        mdt_ensure_filter_config($con);
        $done_schema = true;
    }
    if ($seed && !$done_seed) {
        mdt_seed_default_rules($con);
        mdt_seed_fill_hospital_picks($con);
        $done_seed = true;
    }
    return true;
}

function mdt_ensure_pick_columns($con) {
    $q = mysqli_query($con, "SHOW COLUMNS FROM monitor_dup_therapy_settings LIKE 'picks_a'");
    if ($q && mysqli_num_rows($q) > 0) {
        return true;
    }
    return (bool) mysqli_query($con, "ALTER TABLE monitor_dup_therapy_settings
        ADD COLUMN picks_a TEXT NULL AFTER exclude_b,
        ADD COLUMN picks_b TEXT NULL AFTER picks_a");
}

function mdt_ensure_match_mode_column($con) {
    $q = mysqli_query($con, "SHOW COLUMNS FROM monitor_dup_therapy_settings LIKE 'match_mode'");
    if ($q && mysqli_num_rows($q) > 0) {
        return true;
    }
    return (bool) mysqli_query($con, "ALTER TABLE monitor_dup_therapy_settings
        ADD COLUMN match_mode VARCHAR(10) NOT NULL DEFAULT 'pair' AFTER picks_b");
}

function mdt_ensure_filter_config($con) {
    static $done = false;
    if ($done) {
        return true;
    }
    @mysqli_query($con, "CREATE TABLE IF NOT EXISTS monitor_dup_therapy_config (
        id INT NOT NULL PRIMARY KEY,
        skip_ipd_off TINYINT(1) NOT NULL DEFAULT 1,
        skip_method_keywords TEXT NOT NULL,
        updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    @mysqli_query($con, "INSERT IGNORE INTO monitor_dup_therapy_config (id, skip_ipd_off, skip_method_keywords)
        VALUES (1, 1, 'hold, ทันที')");
    $q = @mysqli_query($con, 'SELECT skip_method_keywords FROM monitor_dup_therapy_config WHERE id=1 LIMIT 1');
    $row = $q ? mysqli_fetch_assoc($q) : null;
    $raw = trim((string)($row['skip_method_keywords'] ?? ''));
    if ($raw === 'hold') {
        @mysqli_query($con, "UPDATE monitor_dup_therapy_config SET skip_method_keywords='hold, ทันที' WHERE id=1");
    }
    $done = true;
    return true;
}

function mdt_parse_skip_keywords($raw) {
    $parts = preg_split('/[\r\n,;]+/', (string)$raw);
    $out = [];
    foreach ($parts as $p) {
        $p = trim((string)$p);
        if ($p !== '') {
            $out[$p] = true;
        }
    }
    return array_keys($out);
}

function mdt_default_filter_config() {
    return [
        'skip_ipd_off' => 1,
        'skip_method_keywords' => 'hold, ทันที',
        'keywords' => ['hold', 'ทันที'],
    ];
}

function mdt_get_filter_config($con) {
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    mdt_ensure_filter_config($con);
    $cfg = mdt_default_filter_config();
    $q = mysqli_query($con, 'SELECT skip_ipd_off, skip_method_keywords FROM monitor_dup_therapy_config WHERE id=1 LIMIT 1');
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if ($row) {
        $cfg['skip_ipd_off'] = !empty($row['skip_ipd_off']) ? 1 : 0;
        $raw = trim((string)($row['skip_method_keywords'] ?? 'hold, ทันที'));
        if ($raw === '') {
            $raw = 'hold, ทันที';
        }
        $cfg['skip_method_keywords'] = $raw;
        $cfg['keywords'] = mdt_parse_skip_keywords($raw);
        if (empty($cfg['keywords'])) {
            $cfg['keywords'] = ['hold', 'ทันที'];
        }
    }
    $cache = $cfg;
    return $cfg;
}

function mdt_save_filter_config($con, array $in) {
    mdt_ensure_filter_config($con);
    $skip_off = !empty($in['skip_ipd_off']) ? 1 : 0;
    $raw = trim((string)($in['skip_method_keywords'] ?? 'hold, ทันที'));
    if ($raw === '') {
        $raw = 'hold, ทันที';
    }
    $esc = mysqli_real_escape_string($con, $raw);
    return (bool) mysqli_query($con, "INSERT INTO monitor_dup_therapy_config (id, skip_ipd_off, skip_method_keywords)
        VALUES (1, $skip_off, '$esc')
        ON DUPLICATE KEY UPDATE skip_ipd_off=$skip_off, skip_method_keywords='$esc'");
}

function mdt_is_empty_offdate($offdate) {
    $d = trim((string)$offdate);
    return ($d === '' || $d === '0000-00-00' || $d === '0000-00-00 00:00:00');
}

function mdt_text_has_skip_keyword($text, array $keywords) {
    $hay = trim(preg_replace('/\s+/', ' ', (string)$text));
    if ($hay === '' || empty($keywords)) {
        return false;
    }
    foreach ($keywords as $kw) {
        $kw = trim((string)$kw);
        if ($kw === '') {
            continue;
        }
        if (preg_match('/^[A-Za-z0-9_\-]+$/', $kw)) {
            if (preg_match('/\b' . preg_quote($kw, '/') . '\b/i', $hay)) {
                return true;
            }
        } elseif (function_exists('mb_stripos')) {
            if (mb_stripos($hay, $kw, 0, 'UTF-8') !== false) {
                return true;
            }
        } elseif (stripos($hay, $kw) !== false) {
            return true;
        }
    }
    return false;
}

/**
 * @return array{off: array<string,bool>, usage: array<string,string>}
 */
function mdt_load_medplan_status_map($hos, array $an_list, array $icodes) {
    $out = ['off' => [], 'usage' => []];
    $ans = [];
    foreach ($an_list as $an) {
        $an = trim((string)$an);
        if ($an !== '') {
            $ans[] = "'" . mysqli_real_escape_string($hos, $an) . "'";
        }
    }
    $ics = [];
    foreach ($icodes as $ic) {
        $ic = trim((string)$ic);
        if ($ic !== '') {
            $ics[] = "'" . mysqli_real_escape_string($hos, $ic) . "'";
        }
    }
    $ans = array_values(array_unique($ans));
    $ics = array_values(array_unique($ics));
    if (empty($ans) || empty($ics) || !$hos) {
        return $out;
    }
    $sql = "SELECT an, icode, offdate,
            CAST(CONVERT(CONCAT(IFNULL(usage_line1,''),' ',IFNULL(usage_line2,''),' ',IFNULL(usage_line3,''),' ',IFNULL(shortlist,'')) USING utf8) AS CHAR) AS mp_usage
        FROM medplan_ipd
        WHERE an IN (" . implode(',', $ans) . ")
          AND icode IN (" . implode(',', $ics) . ")";
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        $sql = "SELECT an, icode, offdate, '' AS mp_usage
            FROM medplan_ipd
            WHERE an IN (" . implode(',', $ans) . ")
              AND icode IN (" . implode(',', $ics) . ")";
        $q = @mysqli_query($hos, $sql);
    }
    if (!$q) {
        return $out;
    }
    $has_row = [];
    $has_active = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $an = trim((string)($r['an'] ?? ''));
        $ic = trim((string)($r['icode'] ?? ''));
        if ($an === '' || $ic === '') {
            continue;
        }
        $key = $an . '|' . $ic;
        $has_row[$key] = true;
        if (mdt_is_empty_offdate($r['offdate'] ?? '')) {
            $has_active[$key] = true;
        }
        $u = trim(preg_replace('/\s+/', ' ', (string)($r['mp_usage'] ?? '')));
        if ($u !== '') {
            $out['usage'][$key] = trim(($out['usage'][$key] ?? '') . ' ' . $u);
        }
    }
    foreach ($has_row as $key => $_) {
        $out['off'][$key] = empty($has_active[$key]);
    }
    return $out;
}

/**
 * ตัดออเดอร์ที่ Medplan off (IPD) หรือวิธีใช้มีคำที่ตั้งไว้ เช่น hold
 * @return array{orders: array, skipped_off: int, skipped_keyword: int}
 */
function mdt_filter_orders($hos, array $orders, array $filter) {
    $stats = ['orders' => [], 'skipped_off' => 0, 'skipped_keyword' => 0];
    if (empty($orders)) {
        return $stats;
    }
    $keywords = $filter['keywords'] ?? [];
    $skip_off = !empty($filter['skip_ipd_off']);
    $an_list = [];
    $icodes = [];
    foreach ($orders as $o) {
        $an = trim((string)($o['an'] ?? ''));
        $ic = trim((string)($o['icode'] ?? ''));
        if ($an !== '') {
            $an_list[$an] = true;
        }
        if ($ic !== '') {
            $icodes[$ic] = true;
        }
    }
    $mp = ['off' => [], 'usage' => []];
    if ($skip_off || !empty($keywords)) {
        $mp = mdt_load_medplan_status_map($hos, array_keys($an_list), array_keys($icodes));
    }
    foreach ($orders as $o) {
        $an = trim((string)($o['an'] ?? ''));
        $ic = trim((string)($o['icode'] ?? ''));
        $key = ($an !== '' && $ic !== '') ? ($an . '|' . $ic) : '';
        $method = trim((string)($o['method'] ?? ''));
        $blob = $method;
        if ($key !== '' && !empty($mp['usage'][$key])) {
            $blob .= ' ' . $mp['usage'][$key];
        }
        if (!empty($keywords) && mdt_text_has_skip_keyword($blob, $keywords)) {
            $stats['skipped_keyword']++;
            continue;
        }
        if ($skip_off && $key !== '' && !empty($mp['off'][$key])) {
            $stats['skipped_off']++;
            continue;
        }
        $stats['orders'][] = $o;
    }
    return $stats;
}

function mdt_match_mode($row) {
    return (($row['match_mode'] ?? '') === 'class') ? 'class' : 'pair';
}

function mdt_ensure_label_width($con) {
    $q = mysqli_query($con, "SHOW COLUMNS FROM monitor_dup_therapy_settings LIKE 'label_a'");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    $type = strtolower((string)($row['Type'] ?? ''));
    if ($type === '' || strpos($type, 'varchar(500)') !== false) {
        return true;
    }
    return (bool) mysqli_query($con, "ALTER TABLE monitor_dup_therapy_settings
        MODIFY label_a VARCHAR(500) NOT NULL DEFAULT '',
        MODIFY label_b VARCHAR(500) NOT NULL DEFAULT ''");
}

function mdt_json_encode_list(array $items) {
    return json_encode(array_values($items), JSON_UNESCAPED_UNICODE);
}

function mdt_json_decode_list($raw) {
    if (is_array($raw)) {
        return $raw;
    }
    $raw = trim((string)$raw);
    if ($raw === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        return array_values(array_filter(array_map('trim', $decoded), function ($v) {
            return $v !== '';
        }));
    }
    $parts = preg_split('/[,;\n]+/', $raw);
    $out = [];
    foreach ($parts as $p) {
        $p = trim((string)$p);
        if ($p !== '') {
            $out[] = $p;
        }
    }
    return $out;
}

function mdt_alert_level($row) {
    return (($row['alert_level'] ?? '') === 'soft') ? 'soft' : 'hard';
}

function mdt_default_rules() {
    return [
        [
            'rule_key' => 'para_combo',
            'group_name' => 'กลุ่มยาแก้ปวดลดไข้',
            'label_a' => 'Paracetamol (เดี่ยว)',
            'label_b' => 'Norgesic / Ultracet / Tiffy / Decolgen',
            'keys_a' => ['paracetamol', 'acetaminophen', 'พาราเซตามอล', 'พาราเซตา'],
            'keys_b' => ['norgesic', 'ultracet', 'tiffy', 'decolgen', 'decogen', 'นอร์จีสิก', 'อัลตร้าเซ็ท'],
            'exclude_a' => ['norgesic', 'ultracet', 'tiffy', 'decolgen', 'decogen', 'orphenadrine', 'tramadol'],
            'exclude_b' => [],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Paracetamol เดี่ยว + สูตรผสม — เสี่ยงเกิน 4,000 mg/วัน',
            'detail_text' => "สาเหตุที่พบบ่อย: สั่งยาแก้หวัดสูตรผสมที่มี Paracetamol 325–500 mg แล้วไม่ได้หยุด Paracetamol 500 mg เดี่ยว\nความเสี่ยง: ได้ Paracetamol รวมเกิน 4,000 mg/วัน → พิษต่อตับ (Hepatotoxicity / ตับวายเฉียบพลัน)",
            'sort_order' => 10,
        ],
        [
            'rule_key' => 'nsaid_dup',
            'group_name' => 'กลุ่มยาแก้ปวดลดไข้',
            'label_a' => 'Diclofenac',
            'label_b' => 'Ibuprofen / Naproxen',
            'keys_a' => ['diclofenac', 'ไดโคลฟีแนค', 'ไดโคลฟีเนค', 'voltaren', 'โวลทาเรน'],
            'keys_b' => ['ibuprofen', 'naproxen', 'ไอบูโพรเฟน', 'นาโพรเซน', 'brufen', 'นูโรเฟน'],
            'exclude_a' => [],
            'exclude_b' => ['diclofenac'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน NSAID สองชนิด — ไม่เพิ่มฤทธิ์แก้ปวด แต่เพิ่มเลือดออก GI และ AKI',
            'detail_text' => "สาเหตุที่พบบ่อย: สลับยา (เช่น Diclofenac → Ibuprofen) โดยไม่หยุดตัวเดิม หรือได้ยาจากคนละคลินิก (กระดูก / ทันตกรรม)\nความเสี่ยง: GI bleeding และไตวายเฉียบพลัน (AKI) โดยไม่มีประโยชน์แก้ปวดเพิ่ม",
            'sort_order' => 20,
        ],
        [
            'rule_key' => 'metformin_combo',
            'group_name' => 'กลุ่มยารักษาโรคเบาหวาน',
            'label_a' => 'Metformin (เดี่ยว)',
            'label_b' => 'Janumet / Galvus Met / Glucovance',
            'keys_a' => ['metformin', 'เมตฟอร์มิน', 'glucophage', 'กลูโคฟาจ'],
            'keys_b' => ['janumet', 'galvus met', 'galvusmet', 'glucovance', 'จานูเมท', 'กัลวัส'],
            'exclude_a' => ['janumet', 'galvus', 'glucovance', 'sitagliptin', 'vildagliptin', 'glibenclamide', 'glyburide'],
            'exclude_b' => [],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Metformin เดี่ยว + สูตรผสม — เสี่ยงเกิน Max 2,550 mg/วัน',
            'detail_text' => "สาเหตุที่พบบ่อย: ผู้ป่วยกิน Metformin เดี่ยวอยู่แล้ว แพทย์เปลี่ยนเป็นยาสูตรผสมที่มี Metformin แต่ยังจ่ายตัวเดี่ยวต่อ\nความเสี่ยง: ได้ Metformin เกิน Max dose 2,550 mg/วัน → ผลข้างเคียง GI รุนแรง และ Lactic acidosis",
            'sort_order' => 30,
        ],
        [
            'rule_key' => 'su_dup',
            'group_name' => 'กลุ่มยารักษาโรคเบาหวาน',
            'label_a' => 'Glipizide',
            'label_b' => 'Glibenclamide / Gliclazide',
            'keys_a' => ['glipizide', 'กลิพิไซด์', 'minidiab', 'มินิไดแอบ'],
            'keys_b' => ['glibenclamide', 'gliclazide', 'glyburide', 'กลิเบนคลาไมด์', 'กลิคลาไซด์', 'daonil', 'diamicron'],
            'exclude_a' => ['glibenclamide', 'gliclazide'],
            'exclude_b' => ['glipizide'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Sulfonylurea สองชนิด — เสี่ยง Hypoglycemia รุนแรง',
            'detail_text' => "สาเหตุที่พบบ่อย: สั่งยาในกลุ่ม SU พร้อมกัน หรือปรับ/เปลี่ยนยาแล้วลืมยกเลิกตัวเดิมในระบบ\nความเสี่ยง: กระตุ้นตับอ่อนหลั่งอินซูลินมากเกินไป → น้ำตาลต่ำรุนแรง หมดสติได้",
            'sort_order' => 40,
        ],
        [
            'rule_key' => 'statin_dup',
            'group_name' => 'กลุ่มยาลดไขมันในเลือด',
            'label_a' => 'Simvastatin',
            'label_b' => 'Atorvastatin / Rosuvastatin',
            'keys_a' => ['simvastatin', 'ซิมวาสแตติน', 'ซิมวาสตาติน', 'zocor'],
            'keys_b' => ['atorvastatin', 'rosuvastatin', 'อะทอร์วาสแตติน', 'โรซูวาสแตติน', 'lipitor', 'crestor'],
            'exclude_a' => ['atorvastatin', 'rosuvastatin'],
            'exclude_b' => ['simvastatin'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Statin สองชนิด — เสี่ยง Rhabdomyolysis',
            'detail_text' => "สาเหตุที่พบบ่อย: Admit แล้วเปลี่ยนเป็น Atorvastatin แต่ตอนจำหน่ายดึงใบยา OPD เดิม (Simvastatin) กลับมาจ่ายพร้อมกัน\nความเสี่ยง: ระดับยาในเลือดสูง → กล้ามเนื้ออักเสบ/สลาย (Rhabdomyolysis) นำไปสู่ไตวาย",
            'sort_order' => 50,
        ],
        [
            'rule_key' => 'antihistamine_dup',
            'group_name' => 'กลุ่มยาระบบทางเดินหายใจและแก้แพ้',
            'label_a' => 'CPM (Chlorpheniramine)',
            'label_b' => 'Loratadine / Cetirizine',
            'keys_a' => ['chlorpheniramine', 'chlorphenamine', 'cpm', 'คลอร์เฟนิรามีน', 'คลอเฟนิรามีน'],
            'keys_b' => ['loratadine', 'cetirizine', 'cetirizin', 'zyrtec', 'clarityne', 'claritin', 'ลอราทาดีน', 'เซทิริซีน'],
            'exclude_a' => ['loratadine', 'cetirizine'],
            'exclude_b' => ['chlorpheniramine', 'chlorphenamine', 'desloratadine', 'levocetirizine'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน ยาแก้แพ้รุ่นเก่า (CPM) + รุ่นใหม่ — เสี่ยงง่วงซึมรุนแรง โดยเฉพาะผู้สูงอายุ',
            'detail_text' => "สาเหตุที่พบบ่อย: ผู้ป่วยกินยาแก้แพ้รุ่นใหม่วันละครั้งอยู่แล้ว เมื่อมีอาการหวัด แพทย์เติม CPM (วันละ 3 ครั้ง) โดยไม่มีข้อบ่งชี้ชัดเจน\nความเสี่ยง: ปากแห้ง คอแห้ง ปัสสาวะคั่ง และง่วงซึมมาก โดยเฉพาะในผู้สูงอายุ",
            'sort_order' => 60,
        ],
        [
            'rule_key' => 'saba_laba',
            'group_name' => 'กลุ่มยาระบบทางเดินหายใจและแก้แพ้',
            'label_a' => 'Salbutamol (MDI)',
            'label_b' => 'Seretide / Symbicort / Berodual',
            'keys_a' => ['salbutamol', 'albuterol', 'ventolin', 'ซัลบูทามอล', 'เวนโทลิน'],
            'keys_b' => ['seretide', 'symbicort', 'berodual', 'salmeterol', 'formoterol', 'fenoterol', 'เซเรไทด์', 'ซิมบิคอร์ท', 'บีโรดูอัล'],
            'exclude_a' => ['seretide', 'symbicort', 'berodual', 'salmeterol', 'formoterol'],
            'exclude_b' => ['salbutamol', 'albuterol', 'ventolin'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน SABA + สูตรผสม (LABA/SABA) — เสี่ยงใจสั่น หัวใจเต้นเร็ว',
            'detail_text' => "สาเหตุที่พบบ่อย: สั่ง Salbutamol (SABA) ซ้ำกับส่วนประกอบในยาสูดสูตรผสม เช่น Seretide / Symbicort / Berodual\nความเสี่ยง: กระตุ้นหัวใจมากเกินไป → ใจสั่นรุนแรง, tachycardia / arrhythmia และมือสั่น",
            'sort_order' => 70,
        ],
        [
            'rule_key' => 'ppi_dup',
            'group_name' => 'กลุ่มยาลดกรดในกระเพาะอาหาร',
            'label_a' => 'Omeprazole',
            'label_b' => 'Pantoprazole / Esomeprazole',
            'keys_a' => ['omeprazole', 'โอเมพราโซล', 'losek', 'โลเซค'],
            'keys_b' => ['pantoprazole', 'esomeprazole', 'แพนโทพราโซล', 'อีโซเมพราโซล', 'controloc', 'nexium'],
            'exclude_a' => ['pantoprazole', 'esomeprazole'],
            'exclude_b' => ['omeprazole'],
            'alert_level' => 'soft',
            'alert_message' => 'ซ้ำซ้อน PPI สองชนิด — ไม่เพิ่มประสิทธิภาพ เพิ่มภาระยาและค่าใช้จ่าย',
            'detail_text' => "สาเหตุที่พบบ่อย: ได้ PPI คนละชนิดจากคนละคลินิก (อายุรกรรม / ศัลยกรรม) เพราะระบบไม่ดักข้ามคลินิก\nความเสี่ยง: ไม่อันตรายเฉียบพลัน แต่เป็น polypharmacy ที่ไม่จำเป็น และสิ้นเปลืองงบโรงพยาบาล",
            'sort_order' => 80,
        ],
    ];
}

function mdt_extra_group_rules() {
    return [
        [
            'rule_key' => 'nsaid_class',
            'match_mode' => 'class',
            'group_name' => 'กลุ่มยา NSAIDs',
            'label_a' => 'NSAIDs',
            'label_b' => 'ชนิดอื่นในกลุ่มเดียวกัน',
            'keys_a' => [
                'diclofenac', 'ibuprofen', 'naproxen', 'mefenamic', 'piroxicam', 'meloxicam',
                'celecoxib', 'etoricoxib', 'aceclofenac', 'ketorolac', 'indomethacin', 'indometacin',
                'dexibuprofen', 'tenoxicam', 'etodolac', 'loxoprofen', 'sulindac', 'ketoprofen',
                'ไดโคลฟีแนค', 'ไดโคลฟีเนค', 'ไอบูโพรเฟน', 'นาโพรเซน', 'กรดเมฟีนา', 'เมเฟนามิก',
                'ไพร็อกซิแคม', 'เมโลซิแคม', 'เซเลคอกซิบ', 'อีทอริคอกซิบ', 'เอซคลอฟีแนค', 'คีโตโรแลค',
            ],
            'keys_b' => [],
            'exclude_a' => ['aspirin', 'acetylsalic', 'asa 81', 'แอสไพริน', 'norgesic', 'orphenadrine'],
            'exclude_b' => [],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน NSAID ≥ 2 ชนิด — ไม่เพิ่มฤทธิ์แก้ปวด แต่เพิ่มเลือดออก GI และ AKI',
            'detail_text' => "สาเหตุที่พบบ่อย: ได้ NSAID คนละชนิดจากคนละคลินิก หรือสลับยาโดยไม่หยุดตัวเดิม\nความเสี่ยง: GI bleeding และไตวายเฉียบพลัน (AKI) โดยไม่มีประโยชน์แก้ปวดเพิ่ม — ไม่นับ aspirin ขนาดป้องกันหัวใจ",
            'sort_order' => 90,
        ],
        [
            'rule_key' => 'norgesic_tolperisone',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยาคลายกล้ามเนื้อ',
            'label_a' => 'Norgesic',
            'label_b' => 'Tolperisone',
            'keys_a' => ['norgesic', 'orphenadrine', 'นอร์จีสิก', 'ออร์เฟนาดรีน'],
            'keys_b' => ['tolperisone', 'mydocalm', 'muscadol', 'ทอลเพอริโซน', 'โทลเพอริโซน', 'มายโดคาล์ม'],
            'exclude_a' => ['tolperisone', 'mydocalm'],
            'exclude_b' => ['norgesic', 'orphenadrine'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน ยาคลายกล้ามเนื้อ Norgesic + Tolperisone — เสี่ยงง่วงซึมและ anticholinergic',
            'detail_text' => "สาเหตุที่พบบ่อย: สั่ง Norgesic (orphenadrine) ร่วมกับ Tolperisone เพราะมองว่าคนละตัว\nความเสี่ยง: ง่วงซึมมาก ปากแห้ง ปัสสาวะคั่ง โดยเฉพาะผู้สูงอายุ ไม่เพิ่มประโยชน์คลายกล้ามเนื้อ",
            'sort_order' => 100,
        ],
        [
            'rule_key' => 'alpha_blocker_dup',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยา Alpha-blocker (ต่อมลูกหมาก / ความดัน)',
            'label_a' => 'Doxazosin',
            'label_b' => 'Tamsulosin / Alfuzosin',
            'keys_a' => ['doxazosin', 'cardura', 'ดอกซาโซซิน', 'คาร์ดูรา'],
            'keys_b' => ['tamsulosin', 'harnal', 'alfuzosin', 'xatral', 'แทมสุโลซิน', 'ฮาร์นอล', 'อัลฟูโซซิน', 'ซาทรัล'],
            'exclude_a' => ['tamsulosin', 'alfuzosin', 'harnal'],
            'exclude_b' => ['doxazosin', 'cardura'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Alpha-blocker สองชนิด — เสี่ยงความดันต่ำ Orthostatic hypotension',
            'detail_text' => "สาเหตุที่พบบ่อย: ได้ Doxazosin จากคลินิกความดัน และ Tamsulosin (Harnal) / Alfuzosin จากคลินิกทางเดินปัสสาวะ\nความเสี่ยง: ความดันตกเมื่อเปลี่ยนท่า วิงเวียน ล้ม โดยเฉพาะผู้สูงอายุ",
            'sort_order' => 110,
        ],
        [
            'rule_key' => 'dhp_ccb_dup',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยา Calcium channel blocker (DHP)',
            'label_a' => 'Amlodipine',
            'label_b' => 'Manidipine / Nifedipine / Lercanidipine',
            'keys_a' => ['amlodipine', 'norvasc', 'แอมโลดิพีน', 'นอร์วาสค์', 'นอร์วาสค'],
            'keys_b' => [
                'manidipine', 'nifedipine', 'lercanidipine', 'lerkanidipine', 'adalat',
                'มานิดิพีน', 'นิเฟดิพีน', 'เลอร์คานิดิพีน', 'เลอร์คานิดิปีน', 'อะดาแลท',
            ],
            'exclude_a' => ['manidipine', 'nifedipine', 'lercanidipine', 'lerkanidipine'],
            'exclude_b' => ['amlodipine', 'norvasc'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน CCB ชนิด DHP สองชนิด — ไม่เพิ่มควบคุมความดันตามสัดส่วน เสี่ยงบวมเท้า/หัวใจเต้นเร็ว',
            'detail_text' => "สาเหตุที่พบบ่อย: เปลี่ยนจาก Amlodipine เป็น Manidipine / Nifedipine / Lercanidipine แล้วไม่หยุดตัวเดิม\nความเสี่ยง: บวมเท้า หน้าแดง tachycardia โดยความดันไม่ได้ดีขึ้นตามสัดส่วน",
            'sort_order' => 120,
        ],
        [
            'rule_key' => 'beta_blocker_dup',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยา Beta-blocker',
            'label_a' => 'Bisoprolol',
            'label_b' => 'Propranolol',
            'keys_a' => ['bisoprolol', 'concor', 'ไบโซโปรลอล', 'คอนคอร์'],
            'keys_b' => ['propranolol', 'inderal', 'โพรพราโนลอล', 'อินเดอรัล'],
            'exclude_a' => ['propranolol'],
            'exclude_b' => ['bisoprolol'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Beta-blocker สองชนิด — เสี่ยงหัวใจเต้นช้าและความดันต่ำ',
            'detail_text' => "สาเหตุที่พบบ่อย: Bisoprolol สำหรับความดัน/หัวใจ ร่วมกับ Propranolol สำหรับไมเกรนหรืออาการสั่น โดยไม่ได้ทบทวนยาเดิม\nความเสี่ยง: bradycardia, hypotension, หมดสติ โดยเฉพาะในผู้สูงอายุ",
            'sort_order' => 130,
        ],
        [
            'rule_key' => 'warfarin_apixaban',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยาต้านการแข็งตัวของเลือด',
            'label_a' => 'Warfarin',
            'label_b' => 'Apixaban',
            'keys_a' => ['warfarin', 'orfanin', 'orfarin', 'marevan', 'วาร์ฟาริน', 'ออร์ฟาริน'],
            'keys_b' => ['apixaban', 'eliquis', 'อะพิกซาแบน', 'อีลิควิส'],
            'exclude_a' => ['apixaban', 'eliquis', 'หลีกเลี่ยง', 'note', 'คำแนะนำ'],
            'exclude_b' => ['warfarin'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Warfarin + Apixaban — เสี่ยงเลือดออกรุนแรง',
            'detail_text' => "สาเหตุที่พบบ่อย: เปลี่ยนจาก Warfarin เป็น DOAC (Apixaban) แล้วไม่หยุด Warfarin หรือได้ยาคนละคลินิก\nความเสี่ยง: เลือดออกรุนแรง (GI / intracranial) เป็น Hard Alert ที่ต้องจัดการทันที",
            'sort_order' => 140,
        ],
        [
            'rule_key' => 'arb_acei',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยา ARB + ACEI',
            'label_a' => 'ARB',
            'label_b' => 'ACEI',
            'keys_a' => [
                'losartan', 'valsartan', 'candesartan', 'irbesartan', 'telmisartan', 'olmesartan', 'azilsartan',
                'โคซาร์', 'ไดโอแวน', 'โลซาร์แทน', 'วาลซาร์แทน', 'แคนเดซาร์แทน', 'เออร์เบซาร์แทน', 'เทลมิซาร์แทน', 'โอลเมซาร์แทน',
            ],
            'keys_b' => [
                'enalapril', 'ramipril', 'perindopril', 'lisinopril', 'captopril', 'fosinopril',
                'imidapril', 'quinapril', 'benazepril', 'cilazapril',
                'เอ็นาลาพริล', 'รามิพริล', 'เพอรินโดพริล', 'ไลซิโนพริล', 'แคปโทพริล', 'คัฟเวอซิล', 'coversyl',
            ],
            'exclude_a' => ['enalapril', 'ramipril', 'perindopril', 'lisinopril', 'captopril'],
            'exclude_b' => ['losartan', 'valsartan', 'candesartan', 'irbesartan', 'telmisartan', 'olmesartan'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน ARB + ACEI — ไม่แนะนำใช้ร่วม เสี่ยงไตวายและโพแทสเซียมสูง',
            'detail_text' => "สาเหตุที่พบบ่อย: ได้ ACEI จากคลินิกหนึ่ง และ ARB จากอีกคลินิก โดยระบบไม่ดักข้ามคลินิก\nความเสี่ยง: hyperkalemia, ไตแย่ลง, ความดันต่ำ — dual blockade ไม่มีข้อบ่งชี้ในผู้ป่วยทั่วไป",
            'sort_order' => 150,
        ],
        [
            'rule_key' => 'amoxclav_metro',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยาปฏิชีวนะ (Overlapping spectrum)',
            'label_a' => 'Amoxicillin/Clavulanate',
            'label_b' => 'Metronidazole',
            'keys_a' => [
                'clavulan', 'augmentin', 'co-amoxiclav', 'coamoxiclav', 'amoxyclav',
                'อะม็อกซีซิลลิน+คลาวูลานิค', 'ออกเมนทิน', 'โคอะม็อกซิคลาฟ',
            ],
            'keys_b' => ['metronidazole', 'flagyl', 'เมโทรนิดาโซล', 'ฟลาจิล'],
            'exclude_a' => ['metronidazole', 'flagyl'],
            'exclude_b' => ['clavulan', 'augmentin', 'gel', 'cream', 'vaginal', 'ovule'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Amoxicillin/Clavulanate + Metronidazole — Augmentin ครอบคลุม anaerobe อยู่แล้ว เสี่ยง GI และ C. difficile',
            'detail_text' => "สาเหตุที่พบบ่อย: ต้องการครอบคลุม anaerobe (เช่น diabetic foot, intra-abdominal) แต่ลืมว่า Amoxicillin/Clavulanate ครอบคลุม anaerobe แล้ว\nความเสี่ยง: คลื่นไส้ อาเจียน ท้องเสีย และเพิ่มโอกาสติดเชื้อ C. difficile ในลำไส้",
            'sort_order' => 160,
        ],
        [
            'rule_key' => 'clinda_metro',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยาปฏิชีวนะ (Overlapping spectrum)',
            'label_a' => 'Clindamycin',
            'label_b' => 'Metronidazole',
            'keys_a' => ['clindamycin', 'dalacin', 'คลินดาไมซิน', 'ดาลาซิน'],
            'keys_b' => ['metronidazole', 'flagyl', 'เมโทรนิดาโซล', 'ฟลาจิล'],
            'exclude_a' => ['metronidazole', 'eye drop', 'ear drop', 'cream', 'gel', 'lotion', 'topical', 'ophthal'],
            'exclude_b' => ['clindamycin', 'dalacin', 'gel', 'cream', 'vaginal', 'ovule'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Clindamycin + Metronidazole — Double anaerobic coverage เสี่ยง colitis รุนแรง',
            'detail_text' => "สาเหตุที่พบบ่อย: สั่งคู่กันในติดเชื้อฟันหรือช่องท้อง เพราะทั้งคู่ฆ่า anaerobe ได้ดี\nความเสี่ยง: ไม่จำเป็น (double anaerobic coverage) และเพิ่มเสี่ยง Pseudomembranous colitis รุนแรง",
            'sort_order' => 170,
        ],
        [
            'rule_key' => 'diclox_amoxclav',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยาปฏิชีวนะ (Overlapping spectrum)',
            'label_a' => 'Dicloxacillin',
            'label_b' => 'Amoxicillin/Clavulanate',
            'keys_a' => ['dicloxacillin', 'dicloxacilin', 'ไดคล็อกซาซิลลิน', 'ไดคลอกซาซิลลิน'],
            'keys_b' => [
                'clavulan', 'augmentin', 'co-amoxiclav', 'coamoxiclav', 'amoxyclav',
                'อะม็อกซีซิลลิน+คลาวูลานิค', 'ออกเมนทิน', 'โคอะม็อกซิคลาฟ',
            ],
            'exclude_a' => ['clavulan', 'augmentin'],
            'exclude_b' => ['dicloxacillin'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Dicloxacillin + Amoxicillin/Clavulanate — Beta-lactam ซ้ำ ไม่เพิ่มประโยชน์ เสี่ยงผื่นและพิษตับ',
            'detail_text' => "สาเหตุที่พบบ่อย: สั่ง Dicloxacillin เพื่อครอบคลุม MSSA ใน cellulitis ทั้งที่ Amoxicillin/Clavulanate ครอบคลุม MSSA แล้ว\nความเสี่ยง: ไม่ได้ประโยชน์เพิ่ม แต่เพิ่มผื่น (skin eruption) และพิษต่อตับ (hepatotoxicity)",
            'sort_order' => 180,
        ],
        [
            'rule_key' => 'levo_cipro',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยาปฏิชีวนะ (Same class)',
            'label_a' => 'Levofloxacin',
            'label_b' => 'Ciprofloxacin',
            'keys_a' => ['levofloxacin', 'ลีโวฟลอกซาซิน', 'เลโวฟลอกซาซิน'],
            'keys_b' => ['ciprofloxacin', 'ซิโปรฟลอกซาซิน'],
            'exclude_a' => ['ciprofloxacin', 'eye drop', 'ear drop', 'ophthal', ' ed', 'ed-'],
            'exclude_b' => ['levofloxacin', 'eye drop', 'ear drop', 'ophthal'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Levofloxacin + Ciprofloxacin — Fluoroquinolone กลุ่มเดียวกัน เสี่ยงเส้นเอ็นฉีกและ QT prolongation',
            'detail_text' => "สาเหตุที่พบบ่อย: ได้ Ciprofloxacin จากคลินิกหนึ่ง (เช่น UTI) แล้วได้ Levofloxacin จากอีกคลินิก (เช่น ไอ) โดยไม่ทราบยาเดิม\nความเสี่ยง: ผลข้างเคียงกลุ่ม Fluoroquinolone รุนแรงขึ้น เช่น tendon rupture และ QT prolongation",
            'sort_order' => 190,
        ],
        [
            'rule_key' => 'azithro_roxithro',
            'match_mode' => 'pair',
            'group_name' => 'กลุ่มยาปฏิชีวนะ (Same class)',
            'label_a' => 'Azithromycin',
            'label_b' => 'Roxithromycin',
            'keys_a' => ['azithromycin', 'อะซิโทรมัยซิน', 'อาซิโทรมัยซิน'],
            'keys_b' => ['roxithromycin', 'ร็อกซิโทรมัยซิน', 'ร็อกซิโธรมัยซิน'],
            'exclude_a' => ['roxithromycin', 'eye drop', 'ear drop', 'ophthal'],
            'exclude_b' => ['azithromycin'],
            'alert_level' => 'hard',
            'alert_message' => 'ซ้ำซ้อน Azithromycin + Roxithromycin — Macrolide กลุ่มเดียวกัน เสี่ยง GI และหัวใจเต้นผิดจังหวะ',
            'detail_text' => "สาเหตุที่พบบ่อย: กิน Roxithromycin จากร้านยาก่อน แล้วโรงพยาบาลสั่ง Azithromycin เพราะอาการไม่ดีขึ้น\nความเสี่ยง: ปวดท้อง ท้องเสีย และเสี่ยงหัวใจเต้นผิดจังหวะ",
            'sort_order' => 200,
        ],
    ];
}

function mdt_deleted_seed_keys($con) {
    $q = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='mdt_deleted_rule_keys' LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    $raw = trim((string)($row['config_value'] ?? ''));
    if ($raw === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return [];
    }
    $out = [];
    foreach ($decoded as $k) {
        $k = trim((string)$k);
        if ($k !== '') {
            $out[$k] = true;
        }
    }
    return $out;
}

function mdt_remember_deleted_rule_key($con, $rule_key) {
    $rule_key = trim((string)$rule_key);
    if ($rule_key === '') {
        return;
    }
    $keys = mdt_deleted_seed_keys($con);
    $keys[$rule_key] = true;
    $json = mysqli_real_escape_string($con, json_encode(array_keys($keys), JSON_UNESCAPED_UNICODE));
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='mdt_deleted_rule_keys' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        mysqli_query($con, "UPDATE sys_config SET config_value='$json' WHERE config_name='mdt_deleted_rule_keys'");
    } else {
        mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('mdt_deleted_rule_keys', '$json')");
    }
}

function mdt_seed_default_rules($con) {
    $skip = mdt_deleted_seed_keys($con);
    foreach (array_merge(mdt_default_rules(), mdt_extra_group_rules()) as $rule) {
        $key = mysqli_real_escape_string($con, $rule['rule_key']);
        if (isset($skip[$rule['rule_key']])) {
            continue;
        }
        $chk = mysqli_query($con, "SELECT id FROM monitor_dup_therapy_settings WHERE rule_key='$key' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            continue;
        }
        $group = mysqli_real_escape_string($con, $rule['group_name']);
        $la = mysqli_real_escape_string($con, $rule['label_a']);
        $lb = mysqli_real_escape_string($con, $rule['label_b']);
        $ka = mysqli_real_escape_string($con, mdt_json_encode_list($rule['keys_a']));
        $kb = mysqli_real_escape_string($con, mdt_json_encode_list($rule['keys_b'] ?? []));
        $ea = mysqli_real_escape_string($con, mdt_json_encode_list($rule['exclude_a'] ?? []));
        $eb = mysqli_real_escape_string($con, mdt_json_encode_list($rule['exclude_b'] ?? []));
        $lvl = mysqli_real_escape_string($con, $rule['alert_level']);
        $msg = mysqli_real_escape_string($con, $rule['alert_message']);
        $det = mysqli_real_escape_string($con, $rule['detail_text']);
        $mode = mysqli_real_escape_string($con, mdt_match_mode($rule));
        $sort = (int)$rule['sort_order'];
        mysqli_query($con, "INSERT INTO monitor_dup_therapy_settings
            (rule_key, group_name, label_a, label_b, keys_a, keys_b, exclude_a, exclude_b, match_mode, alert_level, alert_message, detail_text, active, is_seed, sort_order)
            VALUES ('$key', '$group', '$la', '$lb', '$ka', '$kb', '$ea', '$eb', '$mode', '$lvl', '$msg', '$det', 1, 1, $sort)");
    }
}

function mdt_normalize_rule_row(array $row) {
    $row['keys_a'] = mdt_json_decode_list($row['keys_a'] ?? []);
    $row['keys_b'] = mdt_json_decode_list($row['keys_b'] ?? []);
    $row['exclude_a'] = mdt_json_decode_list($row['exclude_a'] ?? []);
    $row['exclude_b'] = mdt_json_decode_list($row['exclude_b'] ?? []);
    $row['picks_a'] = mdt_decode_drug_picks($row['picks_a'] ?? []);
    $row['picks_b'] = mdt_decode_drug_picks($row['picks_b'] ?? []);
    $row['alert_level'] = mdt_alert_level($row);
    $row['match_mode'] = mdt_match_mode($row);
    return $row;
}

function mdt_decode_drug_picks($raw) {
    if (is_array($raw)) {
        $items = $raw;
    } else {
        $raw = trim((string)$raw);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        $items = is_array($decoded) ? $decoded : [];
    }
    $out = [];
    foreach ($items as $it) {
        $icode = '';
        $name = '';
        if (is_string($it) || is_numeric($it)) {
            $it = trim((string)$it);
            if ($it === '') {
                continue;
            }
            if (strpos($it, '|') !== false && function_exists('hosxp_parse_drug_option')) {
                $p = hosxp_parse_drug_option($it);
                $icode = $p['icode'];
                $name = $p['name'];
            } else {
                $icode = $it;
            }
        } elseif (is_array($it)) {
            $icode = trim((string)($it['icode'] ?? ''));
            $name = trim((string)($it['name'] ?? $it['name_tmt'] ?? $it['name_local'] ?? ''));
        }
        if ($icode === '') {
            continue;
        }
        if ($name === '') {
            $name = $icode;
        }
        $out[$icode] = ['icode' => $icode, 'name' => $name];
    }
    return array_values($out);
}

function mdt_encode_drug_picks(array $picks) {
    return json_encode(mdt_decode_drug_picks($picks), JSON_UNESCAPED_UNICODE);
}

function mdt_parse_posted_drug_options($posted) {
    if (!is_array($posted)) {
        $posted = ($posted === '' || $posted === null) ? [] : [$posted];
    }
    return mdt_decode_drug_picks($posted);
}

function mdt_select2_items(array $picks) {
    $out = [];
    foreach (mdt_decode_drug_picks($picks) as $p) {
        $icode = $p['icode'];
        $name = $p['name'];
        $out[] = [
            'id' => $icode . '|' . $name,
            'text' => $name . ' (icode: ' . $icode . ')',
            'icode' => $icode,
            'name' => $name,
        ];
    }
    return $out;
}

function mdt_rule_form_drugs($hos, array $rule, $side) {
    $side = ($side === 'b') ? 'b' : 'a';
    $picks = $rule['picks_' . $side] ?? [];
    if (!empty($picks)) {
        return mdt_select2_items($picks);
    }
    if (!$hos) {
        return [];
    }
    $matched = mdt_fetch_matching_drugs($hos, $rule['keys_' . $side] ?? [], $rule['exclude_' . $side] ?? []);
    return mdt_select2_items($matched);
}

function mdt_fetch_drugs_by_icodes($hos, array $icodes) {
    $clean = [];
    foreach ($icodes as $ic) {
        $ic = trim((string)$ic);
        if ($ic !== '') {
            $clean[$ic] = true;
        }
    }
    $clean = array_keys($clean);
    if (empty($clean) || !$hos) {
        return [];
    }
    $in = [];
    foreach ($clean as $ic) {
        $in[] = "'" . mysqli_real_escape_string($hos, $ic) . "'";
    }
    $tmt = hosxp_sql_tmt_drug_name('d', 'tm');
    $sql = "SELECT d.icode,
                   CAST(CONVERT(d.name USING utf8) AS CHAR) AS name_local,
                   $tmt AS name_tmt
            FROM drugitems d
            " . hosxp_sql_tmt_join('d', 'tm') . "
            WHERE d.istatus = 'Y'
              AND d.icode IS NOT NULL AND TRIM(d.icode) <> ''
              AND d.icode IN (" . implode(',', $in) . ")";
    $q = mysqli_query($hos, $sql);
    $out = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $icode = trim((string)($r['icode'] ?? ''));
            if ($icode === '') {
                continue;
            }
            $name = trim((string)($r['name_tmt'] ?? ''));
            if ($name === '') {
                $name = trim((string)($r['name_local'] ?? $icode));
            }
            $out[$icode] = [
                'icode' => $icode,
                'name' => $name,
                'name_local' => trim((string)($r['name_local'] ?? '')),
            ];
        }
    }
    return array_values($out);
}

function mdt_seed_fill_hospital_picks($con) {
    if (!function_exists('hosxp_connect')) {
        return;
    }
    $q = mysqli_query($con, "SELECT id FROM monitor_dup_therapy_settings
        WHERE (picks_a IS NULL OR picks_a = '' OR picks_a = '[]')
          AND (picks_b IS NULL OR picks_b = '' OR picks_b = '[]')
        LIMIT 1");
    if (!$q || mysqli_num_rows($q) === 0) {
        return;
    }
    $hos = hosxp_connect($con);
    if (!$hos) {
        return;
    }
    $q2 = mysqli_query($con, "SELECT * FROM monitor_dup_therapy_settings
        WHERE (picks_a IS NULL OR picks_a = '' OR picks_a = '[]')
          AND (picks_b IS NULL OR picks_b = '' OR picks_b = '[]')");
    if (!$q2) {
        mysqli_close($hos);
        return;
    }
    while ($row = mysqli_fetch_assoc($q2)) {
        $rule = mdt_normalize_rule_row($row);
        $drugs_a = mdt_fetch_matching_drugs($hos, $rule['keys_a'] ?? [], $rule['exclude_a'] ?? []);
        $drugs_b = [];
        if (mdt_match_mode($rule) !== 'class') {
            $drugs_b = mdt_fetch_matching_drugs($hos, $rule['keys_b'] ?? [], $rule['exclude_b'] ?? []);
            $in_a = [];
            foreach ($drugs_a as $d) {
                $in_a[$d['icode']] = true;
            }
            $drugs_b = array_values(array_filter($drugs_b, function ($d) use ($in_a) {
                return empty($in_a[$d['icode']]);
            }));
        }
        if (empty($drugs_a) && empty($drugs_b)) {
            continue;
        }
        $la = mdt_side_label_from_picks($drugs_a);
        $lb = mdt_side_label_from_picks($drugs_b);
        if ($la === '') {
            $la = $rule['label_a'] ?? '';
        }
        if ($lb === '') {
            $lb = $rule['label_b'] ?? '';
        }
        $id = (int)$rule['id'];
        $pa = mysqli_real_escape_string($con, mdt_encode_drug_picks($drugs_a));
        $pb = mysqli_real_escape_string($con, mdt_encode_drug_picks($drugs_b));
        $la_esc = mysqli_real_escape_string($con, $la);
        $lb_esc = mysqli_real_escape_string($con, $lb);
        mysqli_query($con, "UPDATE monitor_dup_therapy_settings SET
            picks_a='$pa', picks_b='$pb', label_a='$la_esc', label_b='$lb_esc'
            WHERE id=$id");
    }
    mysqli_close($hos);
}

function mdt_class_drug_map($hos, array $rule) {
    $map = mdt_side_drug_map($hos, $rule, 'a');
    foreach (mdt_side_drug_map($hos, $rule, 'b') as $ic => $d) {
        $map[$ic] = $d;
    }
    return $map;
}

function mdt_side_drug_map($hos, array $rule, $side) {
    $side = ($side === 'b') ? 'b' : 'a';
    $picks = $rule['picks_' . $side] ?? [];
    $map = mdt_picks_to_map($picks);
    if (!empty($map)) {
        return $map;
    }
    foreach (mdt_fetch_matching_drugs($hos, $rule['keys_' . $side] ?? [], $rule['exclude_' . $side] ?? []) as $d) {
        $map[$d['icode']] = $d;
    }
    return $map;
}

function mdt_picks_to_map(array $picks) {
    $map = [];
    foreach ($picks as $p) {
        $ic = is_array($p) ? trim((string)($p['icode'] ?? '')) : trim((string)$p);
        if ($ic === '') {
            continue;
        }
        $name = is_array($p) ? trim((string)($p['name'] ?? $ic)) : $ic;
        $map[$ic] = [
            'icode' => $ic,
            'name' => ($name !== '' ? $name : $ic),
            'name_local' => '',
        ];
    }
    return $map;
}

function mdt_load_rules($con, $active_only = false, array $rule_ids = []) {
    mdt_ensure_table($con, false);
    $sql = "SELECT * FROM monitor_dup_therapy_settings";
    if ($active_only) {
        $sql .= " WHERE active = 1";
    }
    $sql .= " ORDER BY sort_order ASC, id ASC";
    $q = mysqli_query($con, $sql);
    $out = [];
    $filter = [];
    foreach ($rule_ids as $rid) {
        $rid = (int)$rid;
        if ($rid > 0) {
            $filter[$rid] = true;
        }
    }
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            if (!empty($filter) && !isset($filter[(int)$row['id']])) {
                continue;
            }
            $out[] = mdt_normalize_rule_row($row);
        }
    }
    return $out;
}

function mdt_load_active_rules($con, array $rule_ids = []) {
    return mdt_load_rules($con, true, $rule_ids);
}

function mdt_blob(array $drug) {
    $parts = [
        $drug['name_local'] ?? '',
        $drug['name_tmt'] ?? '',
        $drug['name'] ?? '',
        $drug['drug_name'] ?? '',
        $drug['ingredient'] ?? '',
    ];
    return strtolower(trim(implode(' ', $parts)));
}

function mdt_has_any($hay, array $needles) {
    $hay_l = strtolower($hay);
    foreach ($needles as $n) {
        $n = trim((string)$n);
        if ($n === '') {
            continue;
        }
        if (preg_match('/^[\x20-\x7e]+$/', $n)) {
            if (strpos($hay_l, strtolower($n)) !== false) {
                return true;
            }
        } elseif (strpos($hay, $n) !== false) {
            return true;
        }
    }
    return false;
}

function mdt_fetch_matching_drugs($hos, array $keys, array $exclude = []) {
    $keys = array_values(array_filter(array_map('trim', $keys)));
    if (empty($keys) || !$hos) {
        return [];
    }
    $likes = [];
    foreach ($keys as $k) {
        $esc = mysqli_real_escape_string($hos, $k);
        $likes[] = "(LOWER(d.name) LIKE '%$esc%' OR LOWER(IFNULL(tm.active_ingredient,'')) LIKE '%$esc%' OR CAST(CONVERT(d.name USING utf8) AS CHAR) LIKE '%$esc%')";
    }
    $tmt = hosxp_sql_tmt_drug_name('d', 'tm');
    $sql = "SELECT d.icode,
                   CAST(CONVERT(d.name USING utf8) AS CHAR) AS name_local,
                   $tmt AS name_tmt,
                   CAST(CONVERT(IFNULL(tm.active_ingredient,'') USING utf8) AS CHAR) AS ingredient
            FROM drugitems d
            " . hosxp_sql_tmt_join('d', 'tm') . "
            WHERE d.istatus = 'Y' AND d.icode IS NOT NULL AND TRIM(d.icode) <> ''
              AND (" . implode(' OR ', $likes) . ")
            LIMIT 800";
    $q = mysqli_query($hos, $sql);
    $out = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $blob = mdt_blob($r);
            if ($exclude && mdt_has_any($blob, $exclude)) {
                continue;
            }
            if (!mdt_has_any($blob, $keys)) {
                continue;
            }
            $icode = trim((string)($r['icode'] ?? ''));
            if ($icode === '') {
                continue;
            }
            $name = trim((string)($r['name_tmt'] ?? ''));
            if ($name === '') {
                $name = trim((string)($r['name_local'] ?? $icode));
            }
            $out[$icode] = [
                'icode' => $icode,
                'name' => $name,
                'name_local' => trim((string)($r['name_local'] ?? '')),
            ];
        }
    }
    return array_values($out);
}

function mdt_refresh_pick_names($hos, array $picks) {
    $icodes = [];
    foreach ($picks as $p) {
        $ic = trim((string)($p['icode'] ?? ''));
        if ($ic !== '') {
            $icodes[] = $ic;
        }
    }
    if (empty($icodes) || !$hos) {
        return $picks;
    }
    $map = [];
    foreach (mdt_fetch_drugs_by_icodes($hos, $icodes) as $d) {
        $map[$d['icode']] = $d;
    }
    $out = [];
    foreach ($picks as $p) {
        $ic = trim((string)($p['icode'] ?? ''));
        if ($ic === '') {
            continue;
        }
        if (isset($map[$ic])) {
            $out[] = ['icode' => $ic, 'name' => $map[$ic]['name']];
        } else {
            $name = trim((string)($p['name'] ?? $ic));
            $out[] = ['icode' => $ic, 'name' => $name !== '' ? $name : $ic];
        }
    }
    return $out;
}

function mdt_side_label_from_picks(array $picks, $max_names = 5) {
    $names = [];
    foreach (mdt_decode_drug_picks($picks) as $p) {
        $n = trim((string)($p['name'] ?? ''));
        $n = preg_replace('/\s*\(icode:\s*[^)]+\)\s*$/u', '', $n);
        $n = preg_replace('/\s*\[TMT\s+[^\]]+\]\s*$/u', '', $n);
        $n = trim((string)$n);
        if ($n === '' || $n === ($p['icode'] ?? '')) {
            continue;
        }
        $names[$n] = $n;
    }
    $list = array_values($names);
    if (empty($list)) {
        foreach (mdt_decode_drug_picks($picks) as $p) {
            $ic = trim((string)($p['icode'] ?? ''));
            if ($ic !== '') {
                $list[] = $ic;
            }
        }
    }
    $n = count($list);
    if ($n === 0) {
        return '';
    }
    $max_names = max(1, (int)$max_names);
    if ($n <= $max_names) {
        return implode(' / ', $list);
    }
    $keep = $max_names - 1;
    return implode(' / ', array_slice($list, 0, $keep)) . ' และอีก ' . ($n - $keep) . ' รายการ';
}

function mdt_pair_label(array $rule) {
    $a = mdt_side_label_from_picks($rule['picks_a'] ?? []);
    $b = mdt_side_label_from_picks($rule['picks_b'] ?? []);
    if ($a === '') {
        $a = trim((string)($rule['label_a'] ?? ''));
    }
    if ($b === '') {
        $b = trim((string)($rule['label_b'] ?? ''));
    }
    return trim($a . ($a !== '' && $b !== '' ? ' + ' : '') . $b);
}

function mdt_ward_display(array $row) {
    $type = ($row['type_patient'] ?? '') === 'IPD' ? 'IPD' : 'OPD';
    if ($type === 'OPD') {
        return 'ผู้ป่วยนอก';
    }
    $ward = trim((string)($row['ward_name'] ?? ''));
    $bed = trim((string)($row['bedno'] ?? ''));
    $s = trim($ward . ($ward && $bed ? ' / ' : '') . $bed);
    return $s !== '' ? $s : '-';
}

function mdt_hn_variants($hn) {
    if (function_exists('mhm_hn_variants')) {
        return mhm_hn_variants($hn);
    }
    $hn = trim((string)$hn);
    if ($hn === '') {
        return [];
    }
    $trim = ltrim($hn, '0');
    if ($trim === '') {
        $trim = '0';
    }
    return array_values(array_unique([$hn, $trim, str_pad($trim, 9, '0', STR_PAD_LEFT)]));
}

function mdt_hn_sql_in($hos, array $hn_filter) {
    $vals = [];
    foreach ($hn_filter as $hn) {
        foreach (mdt_hn_variants($hn) as $v) {
            $vals[$v] = true;
        }
    }
    $out = [];
    foreach (array_keys($vals) as $v) {
        $v = trim((string)$v);
        if ($v !== '') {
            $out[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
        }
    }
    return implode(',', $out);
}

function mdt_sql_in_list($hos, array $vals) {
    $out = [];
    foreach ($vals as $v) {
        $v = trim((string)$v);
        if ($v === '') {
            continue;
        }
        $out[$v] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return implode(',', $out);
}

function mdt_sql_utf8_expr($expr) {
    return "CAST(CONVERT($expr USING utf8) AS CHAR)";
}

function mdt_prepare_rule_pack($hos, array $rule) {
    $is_class = mdt_match_mode($rule) === 'class';
    $map_a = mdt_side_drug_map($hos, $rule, 'a');
    $map_b = mdt_side_drug_map($hos, $rule, 'b');
    if ($is_class) {
        foreach ($map_b as $ic => $d) {
            $map_a[$ic] = $d;
        }
        $map_b = $map_a;
        if (count($map_a) < 2) {
            return null;
        }
    } else {
        foreach (array_keys($map_b) as $ic) {
            if (isset($map_a[$ic])) {
                unset($map_b[$ic]);
            }
        }
        if (empty($map_a) || empty($map_b)) {
            return null;
        }
    }
    return [
        'rule' => $rule,
        'map_a' => $map_a,
        'map_b' => $map_b,
        'is_class' => $is_class,
        'pair_label' => mdt_pair_label($rule),
    ];
}

function mdt_fetch_raw_orders($hos, array $icodes, $start_date, $end_date, array $hn_filter = [], $limit = 60000) {
    $out = ['rows' => [], 'truncated' => false, 'error' => ''];
    $ics = [];
    foreach ($icodes as $ic) {
        $ic = trim((string)$ic);
        if ($ic !== '') {
            $ics[$ic] = true;
        }
    }
    $ics = array_keys($ics);
    if (empty($ics) || !$hos) {
        return $out;
    }
    $start_esc = mysqli_real_escape_string($hos, $start_date);
    $end_esc = mysqli_real_escape_string($hos, $end_date);
    $hn_in = mdt_hn_sql_in($hos, $hn_filter);
    $hn_clause = $hn_in !== '' ? " AND o.hn IN ($hn_in)" : '';
    $limit = max(1000, (int)$limit);
    foreach (array_chunk($ics, 100) as $chunk) {
        if (count($out['rows']) >= $limit) {
            $out['truncated'] = true;
            break;
        }
        $remain = $limit - count($out['rows']);
        $in = mdt_sql_in_list($hos, $chunk);
        if ($in === '') {
            continue;
        }
        $sql = "SELECT o.hn, o.vn, o.an, o.vstdate, o.rxdate, o.rxtime, o.icode, o.qty, o.item_no,
                       IFNULL(o.drugusage,'') AS drugusage, IFNULL(o.sp_use,'') AS sp_use, IFNULL(o.hos_guid,'') AS hos_guid
                FROM opitemrece o
                WHERE o.icode IN ($in)
                  AND o.rxdate BETWEEN '$start_esc' AND '$end_esc'
                  AND o.qty > 0
                  $hn_clause
                LIMIT $remain";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            $out['error'] = mysqli_error($hos);
            return $out;
        }
        while ($row = mysqli_fetch_assoc($q)) {
            $out['rows'][] = $row;
        }
    }
    if (count($out['rows']) >= $limit) {
        $out['truncated'] = true;
    }
    return $out;
}

function mdt_group_key(array $row) {
    return trim((string)($row['hn'] ?? '')) . '|' . trim((string)($row['rxdate'] ?? ''));
}

function mdt_group_matches_pack(array $icode_set, array $pack) {
    if (!empty($pack['is_class'])) {
        $n = 0;
        foreach ($pack['map_a'] as $ic => $_) {
            if (isset($icode_set[$ic])) {
                $n++;
                if ($n >= 2) {
                    return true;
                }
            }
        }
        return false;
    }
    $has_a = false;
    $has_b = false;
    foreach ($pack['map_a'] as $ic => $_) {
        if (isset($icode_set[$ic])) {
            $has_a = true;
            break;
        }
    }
    if (!$has_a) {
        return false;
    }
    foreach ($pack['map_b'] as $ic => $_) {
        if (isset($icode_set[$ic])) {
            $has_b = true;
            break;
        }
    }
    return $has_b;
}

function mdt_select_candidate_orders(array $orders, array $packs) {
    if (empty($orders) || empty($packs)) {
        return [];
    }
    $groups = [];
    foreach ($orders as $idx => $row) {
        $hn = trim((string)($row['hn'] ?? ''));
        $rxdate = trim((string)($row['rxdate'] ?? ''));
        $icode = trim((string)($row['icode'] ?? ''));
        if ($hn === '' || $rxdate === '' || $icode === '') {
            continue;
        }
        $gkey = $hn . '|' . $rxdate;
        if (!isset($groups[$gkey])) {
            $groups[$gkey] = ['icodes' => [], 'idx' => []];
        }
        $groups[$gkey]['icodes'][$icode] = true;
        $groups[$gkey]['idx'][] = $idx;
    }
    $keep = [];
    foreach ($groups as $g) {
        $hit = false;
        foreach ($packs as $pack) {
            if (mdt_group_matches_pack($g['icodes'], $pack)) {
                $hit = true;
                break;
            }
        }
        if (!$hit) {
            continue;
        }
        foreach ($g['idx'] as $idx) {
            $keep[$idx] = $orders[$idx];
        }
    }
    return array_values($keep);
}

function mdt_attach_methods($hos, array $orders) {
    if (empty($orders) || !$hos) {
        return $orders;
    }
    $dusage = [];
    $spuse = [];
    $guids = [];
    foreach ($orders as $r) {
        $du = trim((string)($r['drugusage'] ?? ''));
        $sp = trim((string)($r['sp_use'] ?? ''));
        if ($sp !== '') {
            $spuse[$sp] = true;
        } elseif ($du !== '') {
            $dusage[$du] = true;
            $g = trim((string)($r['hos_guid'] ?? ''));
            if ($g !== '') {
                $guids[$g] = true;
            }
        } else {
            $g = trim((string)($r['hos_guid'] ?? ''));
            if ($g !== '') {
                $guids[$g] = true;
            }
        }
    }
    $du_map = [];
    $in = mdt_sql_in_list($hos, array_keys($dusage));
    if ($in !== '') {
        $expr = mdt_sql_utf8_expr("CONCAT(IFNULL(name1,''),' ',IFNULL(name2,''),' ',IFNULL(name3,''))");
        $q = mysqli_query($hos, "SELECT drugusage, $expr AS method FROM drugusage WHERE drugusage IN ($in)");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $du_map[(string)$r['drugusage']] = trim(preg_replace('/\s+/', ' ', (string)($r['method'] ?? '')));
            }
        }
    }
    $sp_map = [];
    $in = mdt_sql_in_list($hos, array_keys($spuse));
    if ($in !== '') {
        $expr = mdt_sql_utf8_expr("CONCAT(IFNULL(name1,''),' ',IFNULL(name2,''),' ',IFNULL(name3,''))");
        $q = mysqli_query($hos, "SELECT sp_use, $expr AS method FROM sp_use WHERE sp_use IN ($in)");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $sp_map[(string)$r['sp_use']] = trim(preg_replace('/\s+/', ' ', (string)($r['method'] ?? '')));
            }
        }
    }
    $disp_map = [];
    foreach (array_chunk(array_keys($guids), 150) as $chunk) {
        $in = mdt_sql_in_list($hos, $chunk);
        if ($in === '') {
            continue;
        }
        $expr = mdt_sql_utf8_expr("CONCAT(IFNULL(usage_line1,''),' ',IFNULL(usage_line2,''),' ',IFNULL(usage_line3,''))");
        $q = mysqli_query($hos, "SELECT hos_guid, $expr AS method FROM opi_dispense WHERE hos_guid IN ($in)");
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $disp_map[(string)$r['hos_guid']] = trim(preg_replace('/\s+/', ' ', (string)($r['method'] ?? '')));
        }
    }
    foreach ($orders as &$r) {
        $sp = trim((string)($r['sp_use'] ?? ''));
        $du = trim((string)($r['drugusage'] ?? ''));
        $g = trim((string)($r['hos_guid'] ?? ''));
        $method = '';
        if ($sp !== '') {
            $method = $sp_map[$sp] ?? '';
        } else {
            $od = $disp_map[$g] ?? '';
            if (function_exists('mb_strlen') ? (mb_strlen($od, 'UTF-8') >= 8) : (strlen($od) >= 8)) {
                $method = $od;
            } else {
                $method = $du_map[$du] ?? $od;
            }
        }
        $r['method'] = $method;
    }
    unset($r);
    return $orders;
}

function mdt_attach_patient_ward($hos, array $orders) {
    if (empty($orders) || !$hos) {
        return $orders;
    }
    $hns = [];
    $ans = [];
    foreach ($orders as $r) {
        $hn = trim((string)($r['hn'] ?? ''));
        if ($hn !== '') {
            $hns[$hn] = true;
        }
        $an = trim((string)($r['an'] ?? ''));
        if ($an !== '') {
            $ans[$an] = true;
        }
    }
    $pt_map = [];
    $in = mdt_sql_in_list($hos, array_keys($hns));
    if ($in !== '') {
        $expr = mdt_sql_utf8_expr("CONCAT(IFNULL(pt.pname,''), IFNULL(pt.fname,''), ' ', IFNULL(pt.lname,''))");
        $q = mysqli_query($hos, "SELECT pt.hn, $expr AS ptname FROM patient pt WHERE pt.hn IN ($in)");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $pt_map[(string)$r['hn']] = trim((string)($r['ptname'] ?? ''));
            }
        }
    }
    $ward_map = [];
    $bed_map = [];
    $in = mdt_sql_in_list($hos, array_keys($ans));
    if ($in !== '') {
        $ward_expr = mdt_sql_utf8_expr("IFNULL(w1.name,'')");
        $q = mysqli_query($hos, "SELECT ia.an, IFNULL(ia.bedno,'') AS bedno, $ward_expr AS ward_name
            FROM iptadm ia
            LEFT JOIN ward_admit_snapshot wa ON wa.an = ia.an
            LEFT JOIN ward w1 ON w1.ward = wa.ward
            WHERE ia.an IN ($in)");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $an = (string)$r['an'];
                $ward_map[$an] = trim((string)($r['ward_name'] ?? ''));
                $bed_map[$an] = trim((string)($r['bedno'] ?? ''));
            }
        }
    }
    foreach ($orders as &$r) {
        $hn = trim((string)($r['hn'] ?? ''));
        $an = trim((string)($r['an'] ?? ''));
        $r['ptname'] = $pt_map[$hn] ?? ($r['ptname'] ?? '');
        $vn = trim((string)($r['vn'] ?? ''));
        $r['type_patient'] = ($vn === '') ? 'IPD' : 'OPD';
        $r['ward_name'] = $ward_map[$an] ?? '';
        $r['bedno'] = $bed_map[$an] ?? '';
    }
    unset($r);
    return $orders;
}

function mdt_build_alerts_for_pack(array $orders, array $pack) {
    $rule = $pack['rule'];
    $map_a = $pack['map_a'];
    $map_b = $pack['map_b'];
    $is_class = !empty($pack['is_class']);
    $groups = [];
    foreach ($orders as $row) {
        $icode = trim((string)($row['icode'] ?? ''));
        $hn = trim((string)($row['hn'] ?? ''));
        $rxdate = trim((string)($row['rxdate'] ?? ''));
        if ($hn === '' || $rxdate === '' || $icode === '') {
            continue;
        }
        if (!isset($map_a[$icode]) && !isset($map_b[$icode])) {
            continue;
        }
        $gkey = $hn . '|' . $rxdate;
        if (!isset($groups[$gkey])) {
            $groups[$gkey] = ['a' => [], 'b' => [], 'row' => $row];
        }
        $name = '';
        if (isset($map_a[$icode])) {
            $name = trim((string)($map_a[$icode]['name'] ?? ''));
        }
        if ($name === '' && isset($map_b[$icode])) {
            $name = trim((string)($map_b[$icode]['name'] ?? ''));
        }
        if ($name === '') {
            $name = trim((string)($row['drug_name'] ?? $icode));
        }
        $item = [
            'icode' => $icode,
            'drug_name' => $name,
            'method' => trim(preg_replace('/\s+/', ' ', (string)($row['method'] ?? ''))),
            'qty' => $row['qty'] ?? '',
        ];
        if (isset($map_a[$icode])) {
            $groups[$gkey]['a'][$icode] = $item;
            $groups[$gkey]['row'] = $row;
        }
        if (isset($map_b[$icode])) {
            $groups[$gkey]['b'][$icode] = $item;
        }
    }
    $hard = [];
    $soft = [];
    $level = mdt_alert_level($rule);
    $msg = trim((string)($rule['alert_message'] ?? '')) ?: ('พบคู่ยาซ้ำซ้อน: ' . $pack['pair_label']);
    $detail = trim((string)($rule['detail_text'] ?? ''));
    foreach ($groups as $g) {
        if ($is_class) {
            $hits = $g['a'];
            if (count($hits) < 2) {
                continue;
            }
            $vals = array_values($hits);
            $g['a'] = [$vals[0]['icode'] => $vals[0]];
            $g['b'] = [];
            for ($i = 1; $i < count($vals); $i++) {
                $g['b'][$vals[$i]['icode']] = $vals[$i];
            }
        } elseif (empty($g['a']) || empty($g['b'])) {
            continue;
        }
        $row = $g['row'];
        $drugs_a_txt = [];
        $methods_a = [];
        foreach ($g['a'] as $it) {
            $drugs_a_txt[] = $it['drug_name'] . ' [' . $it['icode'] . ']';
            if ($it['method'] !== '') {
                $methods_a[] = $it['method'];
            }
        }
        $drugs_b_txt = [];
        $methods_b = [];
        foreach ($g['b'] as $it) {
            $drugs_b_txt[] = $it['drug_name'] . ' [' . $it['icode'] . ']';
            if ($it['method'] !== '') {
                $methods_b[] = $it['method'];
            }
        }
        $rxdate = trim((string)($row['rxdate'] ?? ''));
        $alert = [
            'rule_id' => (int)($rule['id'] ?? 0),
            'rule_key' => $rule['rule_key'] ?? '',
            'group_name' => $rule['group_name'] ?? '',
            'pair_label' => $pack['pair_label'],
            'hn' => ltrim($row['hn'] ?? '', '0'),
            'hn_full' => $row['hn'] ?? '',
            'ptname' => trim((string)($row['ptname'] ?? '')),
            'type_patient' => (($row['type_patient'] ?? '') === 'IPD') ? 'IPD' : 'OPD',
            'vstdate' => $row['vstdate'] ?? '',
            'vn' => $row['vn'] ?? '',
            'an' => $row['an'] ?? '',
            'rxdate' => $rxdate,
            'order_date' => $rxdate !== '' ? date('d/m/Y', strtotime($rxdate)) : '-',
            'order_time' => function_exists('di_format_time') && function_exists('monitor_lab_normalize_hosxp_time')
                ? di_format_time(monitor_lab_normalize_hosxp_time($row['rxtime'] ?? ''))
                : trim((string)($row['rxtime'] ?? '')),
            'drugs_a' => implode(', ', $drugs_a_txt),
            'drugs_b' => implode(', ', $drugs_b_txt),
            'method_a' => implode(' / ', array_unique($methods_a)),
            'method_b' => implode(' / ', array_unique($methods_b)),
            'ward_display' => mdt_ward_display($row),
            'alert_level' => $level,
            'alert_message' => $msg,
            'detail_text' => $detail,
        ];
        if ($level === 'hard') {
            $hard[] = $alert;
        } else {
            $soft[] = $alert;
        }
    }
    return ['hard_alerts' => $hard, 'soft_alerts' => $soft];
}

function mdt_sort_alerts(array $alerts) {
    usort($alerts, static function ($a, $b) {
        $c = strcmp((string)($b['rxdate'] ?? ''), (string)($a['rxdate'] ?? ''));
        if ($c !== 0) {
            return $c;
        }
        $c = strcmp((string)($b['order_time'] ?? ''), (string)($a['order_time'] ?? ''));
        if ($c !== 0) {
            return $c;
        }
        return strcmp((string)($a['hn'] ?? ''), (string)($b['hn'] ?? ''));
    });
    return $alerts;
}

/**
 * คัดกรองหลายกฎในคำสั่งเดียว — ดึงใบยาจาก HOSxP ครั้งเดียว แล้วจับคู่ใน PHP
 */
function mdt_screen_rules($hos, array $rules, $start_date, $end_date, array $filter = null, array $hn_filter = [], array $opts = []) {
    $meta = [
        'rule_count' => count($rules),
        'rule_id' => 0,
        'rule_key' => '',
        'pair_label' => '',
        'matched_a' => 0,
        'matched_b' => 0,
        'orders_scanned' => 0,
        'truncated' => false,
        'match_mode' => '',
        'skipped_off' => 0,
        'skipped_keyword' => 0,
    ];
    $packs = [];
    $all_icodes = [];
    foreach ($rules as $rule) {
        $pack = mdt_prepare_rule_pack($hos, $rule);
        if ($pack === null) {
            continue;
        }
        $meta['matched_a'] += count($pack['map_a']);
        $meta['matched_b'] += $pack['is_class'] ? count($pack['map_a']) : count($pack['map_b']);
        if ($meta['pair_label'] === '') {
            $meta['pair_label'] = $pack['pair_label'];
            $meta['rule_id'] = (int)($rule['id'] ?? 0);
            $meta['rule_key'] = $rule['rule_key'] ?? '';
            $meta['match_mode'] = $pack['is_class'] ? 'class' : 'pair';
        }
        foreach (array_keys($pack['map_a']) as $ic) {
            $all_icodes[$ic] = true;
        }
        foreach (array_keys($pack['map_b']) as $ic) {
            $all_icodes[$ic] = true;
        }
        $packs[] = $pack;
    }
    if (empty($packs)) {
        return ['hard_alerts' => [], 'soft_alerts' => [], 'meta' => $meta, 'matched_hns' => []];
    }
    $hn_in = mdt_hn_sql_in($hos, $hn_filter);
    $limit = $hn_in !== '' ? 20000 : 60000;
    $fetched = mdt_fetch_raw_orders($hos, array_keys($all_icodes), $start_date, $end_date, $hn_filter, $limit);
    if ($fetched['error'] !== '') {
        $meta['sql_error'] = $fetched['error'];
        return ['hard_alerts' => [], 'soft_alerts' => [], 'meta' => $meta, 'error' => $fetched['error'], 'matched_hns' => []];
    }
    $matched_hns = [];
    foreach ($fetched['rows'] as $row) {
        $h = trim((string)($row['hn'] ?? ''));
        if ($h !== '') {
            $matched_hns[$h] = true;
        }
    }
    $meta['orders_scanned'] = count($fetched['rows']);
    $meta['truncated'] = !empty($fetched['truncated']);
    $candidates = mdt_select_candidate_orders($fetched['rows'], $packs);
    $candidates = mdt_attach_methods($hos, $candidates);
    if ($filter === null) {
        $filter = mdt_default_filter_config();
    }
    $filtered = mdt_filter_orders($hos, $candidates, $filter);
    $meta['skipped_off'] = (int)($filtered['skipped_off'] ?? 0);
    $meta['skipped_keyword'] = (int)($filtered['skipped_keyword'] ?? 0);
    $kept = $filtered['orders'];
    $alert_rows = [];
    $hard = [];
    $soft = [];
    foreach ($packs as $pack) {
        $built = mdt_build_alerts_for_pack($kept, $pack);
        foreach ($built['hard_alerts'] as $item) {
            $hard[] = $item;
            $alert_rows[] = $item;
        }
        foreach ($built['soft_alerts'] as $item) {
            $soft[] = $item;
            $alert_rows[] = $item;
        }
    }
    if (empty($opts['skip_patient_enrich']) && (!empty($hard) || !empty($soft))) {
        $lookup = [];
        foreach ($kept as $row) {
            $lookup[mdt_group_key($row)] = $row;
        }
        $need = [];
        foreach ($alert_rows as $item) {
            $k = trim((string)($item['hn_full'] ?? '')) . '|' . trim((string)($item['rxdate'] ?? ''));
            if (isset($lookup[$k])) {
                $need[$k] = $lookup[$k];
            }
        }
        $enriched = mdt_attach_patient_ward($hos, array_values($need));
        $by_key = [];
        foreach ($enriched as $row) {
            $by_key[mdt_group_key($row)] = $row;
        }
        $apply = static function (array $alerts) use ($by_key) {
            foreach ($alerts as &$item) {
                $k = trim((string)($item['hn_full'] ?? '')) . '|' . trim((string)($item['rxdate'] ?? ''));
                if (!isset($by_key[$k])) {
                    continue;
                }
                $row = $by_key[$k];
                $item['ptname'] = trim((string)($row['ptname'] ?? $item['ptname']));
                $item['type_patient'] = (($row['type_patient'] ?? '') === 'IPD') ? 'IPD' : 'OPD';
                $item['ward_display'] = mdt_ward_display($row);
            }
            unset($item);
            return $alerts;
        };
        $hard = $apply($hard);
        $soft = $apply($soft);
    }
    return [
        'hard_alerts' => mdt_sort_alerts($hard),
        'soft_alerts' => mdt_sort_alerts($soft),
        'meta' => $meta,
        'matched_hns' => array_keys($matched_hns),
    ];
}

/**
 * คัดกรอง 1 กฎ ในช่วงวันที่ — ผู้ป่วยที่มีทั้งยาฝั่ง A และ B ในวันเดียวกัน
 * $hn_filter: จำกัดเฉพาะ HN (เช่น เมื่อเปิดจาก Smart Pharma)
 */
function mdt_screen_rule($hos, array $rule, $start_date, $end_date, array $filter = null, array $hn_filter = []) {
    return mdt_screen_rules($hos, [$rule], $start_date, $end_date, $filter, $hn_filter);
}
