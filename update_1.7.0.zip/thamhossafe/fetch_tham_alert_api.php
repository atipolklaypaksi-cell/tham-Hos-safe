<?php
$tham_alert_action_early = $_GET['action'] ?? '';
$tham_alert_agent_fast = in_array($tham_alert_action_early, ['pending', 'heartbeat', 'ward_push'], true);
if (!$tham_alert_agent_fast || isset($_COOKIE[session_name()])) {
    session_start();
}
header('Content-Type: application/json; charset=utf-8');
if ($tham_alert_agent_fast) {
    if (!defined('THAM_LICENSE_NO_SESSION')) {
        define('THAM_LICENSE_NO_SESSION', true);
    }
    if (!defined('THAM_SKIP_UNIT_GATE')) {
        define('THAM_SKIP_UNIT_GATE', true);
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
}
if (!isset($_SESSION) || !is_array($_SESSION)) {
    $_SESSION = [];
}

include __DIR__ . '/connect.php';
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/tham_alert_helper.php';
tham_alert_ensure_tables($con);

$raw = file_get_contents('php://input');
$body = [];
if ($raw !== '' && $raw !== false) {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
    }
}
$req = array_merge($_GET, $_POST, $body);
$action = trim((string)($req['action'] ?? 'get'));
$key = trim((string)($req['key'] ?? ''));
$flags = JSON_UNESCAPED_UNICODE;

$logged_in = isset($_SESSION['user_id']);
if ($logged_in && empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
$can_admin = $logged_in && (
    tham_menu_can('admin.alert_pipelines')
    || tham_menu_can('admin.alert_agents')
    || tham_menu_can('admin.hosxp')
    || tham_menu_can('admin.hosxp_master')
    || (($_SESSION['role'] ?? '') === 'admin')
);
$key_ok = $key !== '' && tham_alert_cron_secret_ok($con, $key);

$agent_poll = in_array($action, ['pending', 'ward_push', 'heartbeat'], true);
$agent_latest = in_array($action, ['agent_latest', 'agent_file'], true);
$agent_admin = in_array($action, ['agents', 'delete_agent', 'save_agent_note', 'bind_agent', 'agent_logins', 'test_agent', 'set_agent_enabled', 'push_install', 'push_update', 'set_login_prompt', 'set_allergy_alert', 'set_allergy_config', 'set_agent_hidden', 'set_agent_name', 'set_j2_eval'], true);
$agent_self = in_array($action, ['my_install_push', 'ack_install_push'], true);

if ($agent_poll) {
    require_once __DIR__ . '/alert_agent_helper.php';
    $lan_ok = function_exists('tham_alert_is_lan_ip') && tham_alert_is_lan_ip();
    if (!$can_admin && !$key_ok && !$lan_ok) {
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], $flags);
        exit;
    }
} elseif ($agent_latest) {
    require_once __DIR__ . '/alert_agent_helper.php';
    $lan_ok = function_exists('tham_alert_is_lan_ip') && tham_alert_is_lan_ip();
    if (!$logged_in && !$key_ok && !$lan_ok) {
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], $flags);
        exit;
    }
} elseif ($agent_self) {
    if (!$logged_in) {
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], $flags);
        exit;
    }
} elseif ($agent_admin) {
    if (!$can_admin) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], $flags);
        exit;
    }
} elseif (!$can_admin) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], $flags);
    exit;
}

if ($logged_in) {
    session_write_close();
}

if ($action === 'agent_latest') {
    require_once __DIR__ . '/alert_agent_helper.php';
    $latest = tham_alert_agent_latest_exe();
    if (!$latest) {
        echo json_encode(['status' => 'error', 'message' => 'ยังไม่มีไฟล์ติดตั้งในโฟลเดอร์ downloads'], $flags);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'name' => $latest['name'],
        'version' => $latest['version'],
        'size' => $latest['size'],
        'sha256' => $latest['sha256'],
        'mtime' => $latest['mtime'],
    ], $flags);
    exit;
}

if ($action === 'agent_file') {
    require_once __DIR__ . '/alert_agent_helper.php';
    if (!tham_alert_agent_stream_latest($con)) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => 'ยังไม่มีไฟล์ติดตั้ง'], $flags);
    }
    exit;
}

if ($action === 'get') {
    echo json_encode([
        'status' => 'success',
        'config' => tham_alert_config($con),
        'pipelines' => tham_alert_pipelines(),
        'drugs' => tham_alert_trigger_rows($con),
        'recent' => tham_alert_recent($con, 25),
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'save' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $cfg = tham_alert_save_config($con, $req);
    echo json_encode(['status' => 'success', 'config' => $cfg], $flags);
    exit;
}

if ($action === 'add_drug' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $icode = trim((string)($req['icode'] ?? ''));
    $name = trim((string)($req['drug_name'] ?? ''));
    if (strpos($icode, '|') !== false) {
        $parts = explode('|', $icode, 2);
        $icode = trim($parts[0]);
        if ($name === '' && isset($parts[1])) {
            $name = trim($parts[1]);
        }
    }
    $res = tham_alert_add_drug($con, $icode, $name, [
        'use_doctor' => !empty($req['use_doctor']),
        'use_phar_opd' => !empty($req['use_phar_opd']),
        'use_phar_ipd' => !empty($req['use_phar_ipd']),
    ]);
    echo json_encode([
        'status' => $res['ok'] ? 'success' : 'error',
        'message' => $res['error'],
        'drugs' => tham_alert_trigger_rows($con),
    ], $flags);
    exit;
}

if ($action === 'delete_drug' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ok = tham_alert_delete_drug($con, (int)($req['id'] ?? 0));
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'drugs' => tham_alert_trigger_rows($con),
    ], $flags);
    exit;
}

if ($action === 'tick') {
    $result = tham_alert_tick($con);
    echo json_encode([
        'status' => 'success',
        'tick' => $result,
        'recent' => tham_alert_recent($con, 25),
    ], $flags);
    exit;
}

if ($action === 'pending') {
    $pipe = (string)($req['pipeline'] ?? $req['client_type'] ?? $req['ClientType'] ?? 'all');
    $station = (string)($req['station_id'] ?? $req['StationId'] ?? '');
    $group = (string)($req['group_name'] ?? $req['GroupName'] ?? '');
    $since = (int)($req['since_id'] ?? $req['since'] ?? 0);
    $hb = tham_alert_agent_heartbeat($con, $req);
    $enabled = !empty($hb['enabled']);
    $rows = $enabled ? tham_alert_pending($con, $pipe, $station, $since, $group) : [];
    if (!function_exists('tham_alert_agent_update_offer')) {
        require_once __DIR__ . '/alert_agent_helper.php';
    }
    $update = tham_alert_agent_update_offer((string)($req['agent_version'] ?? $req['Version'] ?? ''));
    $liveVers = tham_alert_agent_live_versions($con, (int)($hb['id'] ?? 0));
    if (count($liveVers) > 1) {
        $update = null;
    }
    echo json_encode([
        'status' => 'success',
        'events' => $rows,
        'enabled' => $enabled ? 1 : 0,
        'update' => $update,
    ], $flags);
    exit;
}

if ($action === 'heartbeat') {
    $hb = tham_alert_agent_heartbeat($con, $req);
    echo json_encode(['status' => 'success', 'agent' => $hb], $flags);
    exit;
}

if ($action === 'agents') {
    echo json_encode([
        'status' => 'success',
        'agents' => tham_alert_agent_list($con),
        'can_manage' => $can_admin,
        'login_prompt' => tham_alert_lan_auto_enabled($con) ? 1 : 0,
        'allergy_alert' => tham_alert_allergy_case_enabled($con) ? 1 : 0,
        'allergy_config' => tham_alert_allergy_case_config($con),
    ], $flags);
    exit;
}

if ($action === 'set_agent_hidden' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ok = tham_alert_agent_set_hidden($con, (int)($req['id'] ?? 0), !empty($req['hidden']) && (string)$req['hidden'] !== '0');
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'delete_agent' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ok = tham_alert_agent_delete($con, (int)($req['id'] ?? 0));
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'set_agent_name' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ok = tham_alert_agent_set_display_name($con, (int)($req['id'] ?? 0), (string)($req['name'] ?? ''));
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'save_agent_note' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ok = tham_alert_agent_set_note($con, (int)($req['id'] ?? 0), (string)($req['note'] ?? ''));
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'bind_agent' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ok = tham_alert_agent_bind(
        $con,
        (int)($req['id'] ?? 0),
        (string)($req['pipeline'] ?? ''),
        (string)($req['station_id'] ?? ''),
        (string)($req['group_name'] ?? ''),
        array_key_exists('note', $req) ? (string)$req['note'] : null
    );
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'set_agent_keep_login' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ok = tham_alert_agent_set_keep_login(
        $con,
        (int)($req['id'] ?? 0),
        !empty($req['enabled']) && (string)$req['enabled'] !== '0'
    );
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'set_agent_enabled' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ok = tham_alert_agent_set_enabled(
        $con,
        (int)($req['id'] ?? 0),
        !empty($req['enabled']) && (string)$req['enabled'] !== '0'
    );
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'set_login_prompt' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $on = !empty($req['enabled']) && (string)$req['enabled'] !== '0';
    $ok = tham_alert_set_login_prompt($con, $on);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'login_prompt' => tham_alert_lan_auto_enabled($con) ? 1 : 0,
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'set_j2_eval' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $on = !empty($req['enabled']) && (string)$req['enabled'] !== '0';
    $ok = tham_alert_set_j2_eval($con, $on);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'j2_eval' => tham_alert_j2_eval_enabled($con) ? 1 : 0,
    ], $flags);
    exit;
}

if ($action === 'set_allergy_alert' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $on = !empty($req['enabled']) && (string)$req['enabled'] !== '0';
    $ok = tham_alert_set_allergy_case($con, $on);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'allergy_alert' => tham_alert_allergy_case_enabled($con) ? 1 : 0,
        'allergy_config' => tham_alert_allergy_case_config($con),
    ], $flags);
    exit;
}

if ($action === 'set_allergy_config' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $res = tham_alert_set_allergy_case_config($con, [
        'target' => (string)($req['target'] ?? ''),
        'agent_ids' => (array)($req['agent_ids'] ?? []),
        'fields' => (array)($req['fields'] ?? []),
    ]);
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['error'] ?? '',
        'allergy_alert' => tham_alert_allergy_case_enabled($con) ? 1 : 0,
        'allergy_config' => $res['config'] ?? tham_alert_allergy_case_config($con),
    ], $flags);
    exit;
}

if ($action === 'push_update' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $res = tham_alert_agent_request_update($con, (int)($req['id'] ?? 0));
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['error'] ?? '',
        'queued' => (int)($res['queued'] ?? 0),
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'push_install' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $res = tham_alert_agent_push_install($con, (int)($req['id'] ?? 0), (int)($_SESSION['user_id'] ?? 0));
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['error'] ?? '',
        'agents' => tham_alert_agent_list($con),
    ], $flags);
    exit;
}

if ($action === 'my_install_push') {
    $info = tham_alert_my_install_push($con);
    echo json_encode(['status' => 'success'] + $info, $flags);
    exit;
}

if ($action === 'ack_install_push' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ok = tham_alert_ack_install_push($con);
    echo json_encode(['status' => $ok ? 'success' : 'error'], $flags);
    exit;
}

if ($action === 'agent_logins') {
    echo json_encode([
        'status' => 'success',
        'logins' => tham_alert_agent_logins($con, (int)($req['id'] ?? 0)),
    ], $flags);
    exit;
}

if ($action === 'test_agent' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $res = tham_alert_agent_test_send($con, (int)($req['id'] ?? 0), (string)($req['message'] ?? ''));
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'queued' => !empty($res['queued']),
        'online' => !empty($res['online']),
        'pipeline' => $res['pipeline'] ?? '',
        'message' => $res['error'] ?? '',
    ], $flags);
    exit;
}

if ($action === 'ward_push' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $res = tham_alert_ward_push($con, $req);
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'queued' => !empty($res['queued']),
        'message' => $res['error'] ?? '',
    ], $flags);
    exit;
}

if ($action === 'recent') {
    echo json_encode(['status' => 'success', 'recent' => tham_alert_recent($con, 25)], $flags);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'unknown action'], $flags);
