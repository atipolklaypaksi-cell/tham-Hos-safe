/**
 * Smart Pharma backup banner + login popup — polls local alert logs only (no HOSxP).
 */
(function () {
    if (window.__thamSpBackupBound) return;
    window.__thamSpBackupBound = true;

    var POLL_MS = 20000;
    var sess = String(window.SP_BK_SESS || '');
    var epoch = String(window.SP_BK_UI_EPOCH || sess || '0');
    var SS_SIG = 'spBkSig:' + epoch;
    var SS_SPEAK = 'spBkLastSpeak:' + epoch;
    var SS_HIDE = 'spBkHideSig:' + epoch;
    var SS_LOGIN = 'spBkLoginModal:' + epoch;
    var settings = { sound_enabled: 1, interval_min: 3, lookback_label: '1 ชั่วโมงล่าสุด' };
    var audioUnlocked = false;
    var audioCtx = null;
    var loginModalShown = false;

    function $(id) { return document.getElementById(id); }

    function ssGet(key) {
        try { return sessionStorage.getItem(key) || ''; } catch (e) { return ''; }
    }
    function ssSet(key, val) {
        try { sessionStorage.setItem(key, val); } catch (e) {}
    }

    function pageName() {
        var p = (location.pathname.split('/').pop() || '').toLowerCase();
        return p;
    }

    function isScreenPage() {
        var p = pageName();
        return p === 'smart_pharma_opd.php' || p === 'smart_pharma_ipd.php';
    }

    function ensureAudio() {
        var Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return null;
        if (!audioCtx) audioCtx = new Ctx();
        if (audioCtx.state === 'suspended') {
            try { audioCtx.resume(); } catch (e) {}
        }
        audioUnlocked = true;
        var btn = $('spBkUnlock');
        if (btn) btn.style.display = 'none';
        return audioCtx;
    }

    function playChime() {
        var ctx = ensureAudio();
        if (!ctx) return;
        var t0 = ctx.currentTime;
        var notes = [523.25, 659.25, 783.99];
        notes.forEach(function (freq, i) {
            var osc = ctx.createOscillator();
            var gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, t0 + i * 0.18);
            gain.gain.setValueAtTime(0.0001, t0 + i * 0.18);
            gain.gain.exponentialRampToValueAtTime(0.28, t0 + i * 0.18 + 0.03);
            gain.gain.exponentialRampToValueAtTime(0.0001, t0 + i * 0.18 + 0.55);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(t0 + i * 0.18);
            osc.stop(t0 + i * 0.18 + 0.58);
        });
        if (window.speechSynthesis) {
            try {
                window.speechSynthesis.cancel();
                var u = new SpeechSynthesisUtterance('Smart Pharma Alert');
                u.lang = 'en-US';
                u.rate = 1;
                window.speechSynthesis.speak(u);
            } catch (e) {}
        }
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function signatureOf(cases) {
        if (!cases || !cases.length) return '';
        return cases.map(function (c) { return String(c.id || '') + ':' + String(c.hn || ''); }).join('|');
    }

    function mountBanner() {
        var el = $('spBackupBanner');
        if (el && el.parentNode !== document.body) {
            document.body.appendChild(el);
        }
        return el;
    }

    function mountOverlay() {
        var el = $('spBkLoginOverlay');
        if (el && el.parentNode !== document.body) {
            document.body.appendChild(el);
        }
        return el;
    }

    function setSidebarStatus(text, warn) {
        var el = $('spBkSidebarStatus');
        if (!el) return;
        el.textContent = text || '';
        el.style.color = warn ? '#facc15' : '';
    }

    function caseMetaHtml(cases) {
        var first = (cases && cases[0]) ? cases[0] : null;
        var win = settings.lookback_label ? ('ช่วง ' + settings.lookback_label + ' · ') : '';
        if (!first) {
            return win + 'พบ Alert จากคัดกรอง Backup';
        }
        return win + 'ล่าสุด HN <b>' + esc(first.hn || '-') + '</b> '
            + esc(first.ptname || '')
            + (first.alert_summary ? ' · ' + esc(first.alert_summary) : '');
    }

    function setBanner(pending, cases) {
        var el = mountBanner();
        if (!el) return;
        var countEl = $('spBkCount');
        var meta = $('spBkMeta');
        var open = $('spBkOpen');
        var sig = signatureOf(cases);
        var hideThis = ssGet(SS_HIDE);
        var onHome = pageName() === 'home.php';
        var show = pending > 0 && (onHome || !(hideThis && sig && hideThis === sig));
        if (!show) {
            el.classList.remove('is-on');
            el.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('sp-backup-banner-on');
            return;
        }
        if (countEl) countEl.textContent = String(pending);
        if (meta) meta.innerHTML = caseMetaHtml(cases);
        var first = (cases && cases[0]) ? cases[0] : null;
        if (open && first && first.open_url) {
            open.setAttribute('href', first.open_url);
        }
        el.classList.add('is-on');
        el.setAttribute('aria-hidden', 'false');
        document.body.classList.add('sp-backup-banner-on');
        var unlock = $('spBkUnlock');
        if (unlock) unlock.style.display = audioUnlocked ? 'none' : '';
    }

    function hideLoginModal() {
        var ov = $('spBkLoginOverlay');
        if (ov) ov.classList.remove('is-on');
    }

    function showLoginModal(pending, cases) {
        var ov = mountOverlay();
        if (!ov) return;
        var countEl = $('spBkLoginCount');
        var meta = $('spBkLoginMeta');
        var open = $('spBkLoginOpen');
        if (countEl) countEl.textContent = String(pending);
        if (meta) meta.innerHTML = caseMetaHtml(cases);
        var first = (cases && cases[0]) ? cases[0] : null;
        if (open && first && first.open_url) {
            open.setAttribute('href', first.open_url);
        }
        ov.classList.add('is-on');
        loginModalShown = true;
        if (sess) ssSet(SS_LOGIN, '1');
    }

    function maybeLoginPopup(pending, cases) {
        if (pending <= 0 || loginModalShown || isScreenPage()) return;
        if (ssGet(SS_LOGIN)) return;
        showLoginModal(pending, cases);
        playChime();
    }

    function maybeSpeak(pending, cases) {
        if (!settings.sound_enabled || pending <= 0) return;
        var sig = signatureOf(cases);
        var prev = ssGet(SS_SIG);
        var lastSpeak = parseInt(ssGet(SS_SPEAK) || '0', 10) || 0;
        var intervalMs = Math.max(1, parseInt(settings.interval_min, 10) || 3) * 60 * 1000;
        var isNew = sig !== '' && sig !== prev;
        var due = (Date.now() - lastSpeak) >= intervalMs;
        if (isNew || due || lastSpeak === 0) {
            if (!loginModalShown) playChime();
            ssSet(SS_SPEAK, String(Date.now()));
        }
        ssSet(SS_SIG, sig);
    }

    function poll() {
        fetch('fetch_smart_pharma_backup_api.php?action=poll', { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (!data || data.status !== 'success' || !data.eligible) {
                    setBanner(0, []);
                    hideLoginModal();
                    setSidebarStatus('ยังไม่เริ่ม Backup — เลือกห้องจ่ายยา', true);
                    return;
                }
                if (data.settings) {
                    settings.sound_enabled = !!data.settings.sound_enabled;
                    settings.interval_min = parseInt(data.settings.interval_min, 10) || 3;
                    settings.lookback_label = data.settings.lookback_label || '1 ชั่วโมงล่าสุด';
                }
                var pending = parseInt(data.pending, 10) || 0;
                var cases = data.cases || [];
                setBanner(pending, cases);
                maybeLoginPopup(pending, cases);
                maybeSpeak(pending, cases);
                if (pending > 0) {
                    setSidebarStatus('พบ Alert ' + pending + ' รายการ · ' + (settings.lookback_label || ''));
                } else {
                    setSidebarStatus('กำลังเฝ้า · ' + (settings.lookback_label || '1 ชั่วโมงล่าสุด') + ' (ยังไม่พบ)');
                    hideLoginModal();
                }
            })
            .catch(function () {
                setSidebarStatus('เชื่อมต่อ Backup ไม่สำเร็จ', true);
            });
    }

    document.addEventListener('click', function () { ensureAudio(); }, { once: true });
    var unlock = $('spBkUnlock');
    if (unlock) {
        unlock.addEventListener('click', function () {
            ensureAudio();
            playChime();
        });
    }
    var hide = $('spBkHide');
    if (hide) {
        hide.addEventListener('click', function () {
            var el = $('spBackupBanner');
            var meta = $('spBkMeta');
            var sig = ssGet(SS_SIG);
            ssSet(SS_HIDE, sig);
            if (el) {
                el.classList.remove('is-on');
                document.body.classList.remove('sp-backup-banner-on');
            }
            if (meta) meta.textContent = '';
        });
    }
    var later = $('spBkLoginLater');
    if (later) {
        later.addEventListener('click', function () {
            hideLoginModal();
        });
    }
    var overlay = $('spBkLoginOverlay');
    if (overlay) {
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) hideLoginModal();
        });
    }

    function armPoll() {
        var wait = 1500 + Math.floor(Math.random() * 4000);
        setTimeout(function tick() {
            if (document.hidden) {
                setTimeout(tick, 8000);
                return;
            }
            poll();
            setTimeout(tick, POLL_MS);
        }, wait);
    }
    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) poll();
    });
    armPoll();
})();
