(function (global) {
    function monitorUrlParam(k) {
        try {
            return String(new URLSearchParams(location.search).get(k) || '').trim();
        } catch (e) {
            return '';
        }
    }
    function monitorFilterHn() {
        var el = document.getElementById('filter_hn');
        var typed = el ? String(el.value || '').trim() : '';
        if (typed) return typed;
        return monitorUrlParam('hn');
    }
    function monitorSetFilterDates(start, end) {
        function setOne(id, val) {
            var el = document.getElementById(id);
            if (!el || !val) return;
            if (el._flatpickr) el._flatpickr.setDate(val, true);
            else el.value = val;
        }
        setOne('filter_start', start);
        setOne('filter_end', end);
    }
    function monitorEsc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
    function monitorAppendHn(target) {
        var hn = monitorFilterHn();
        if (!hn) return target;
        if (typeof URLSearchParams !== 'undefined' && target instanceof URLSearchParams) {
            target.set('hn', hn);
            return target;
        }
        if (target && typeof target === 'object') {
            target.hn = hn;
            return target;
        }
        return target;
    }
    function monitorInitHnFilter(opts) {
        opts = opts || {};
        var hn = monitorUrlParam('hn');
        var date = monitorUrlParam('date');
        var input = document.getElementById(opts.inputId || 'filter_hn');
        if (hn && input && !String(input.value || '').trim()) {
            input.value = hn;
        }
        if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
            monitorSetFilterDates(date, date);
        }
        var banner = document.getElementById(opts.bannerId || 'hnFocusBanner');
        if (hn && banner) {
            var extra = '';
            if (date) extra += ' · วันที่ ' + monitorEsc(date);
            var vn = monitorUrlParam('vn');
            var an = monitorUrlParam('an');
            if (vn) extra += ' · VN ' + monitorEsc(vn);
            if (an) extra += ' · AN ' + monitorEsc(an);
            var clearHref = opts.clearHref || String(location.pathname.split('/').pop() || '');
            banner.classList.remove('d-none');
            banner.innerHTML = '<i class="fas fa-link me-1"></i> เปิดจาก Smart Pharma · HN <b>'
                + monitorEsc(hn) + '</b>' + extra
                + (clearHref ? ' <a href="' + clearHref + '" class="ms-2">ดูทุก HN</a>' : '');
        }
        if (input && typeof opts.fetchFn === 'function') {
            input.addEventListener('keydown', function (ev) {
                if (ev.key === 'Enter') {
                    ev.preventDefault();
                    opts.fetchFn();
                }
            });
        }
        if (hn && typeof opts.autofetch === 'function') {
            setTimeout(opts.autofetch, 80);
        }
        return hn;
    }
    global.monitorUrlParam = monitorUrlParam;
    global.monitorFilterHn = monitorFilterHn;
    global.monitorSetFilterDates = monitorSetFilterDates;
    global.monitorAppendHn = monitorAppendHn;
    global.monitorInitHnFilter = monitorInitHnFilter;
})(window);
