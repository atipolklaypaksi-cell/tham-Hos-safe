/**
 * บีบรูปก่อนอัปโหลดเคสแพ้ยา — กันไฟล์มือถือเกิน upload_max_filesize (2MB)
 */
(function (global) {
    var MAX_BYTES = 1400 * 1024;

    function loadImage(file) {
        return new Promise(function (resolve, reject) {
            var url = URL.createObjectURL(file);
            var img = new Image();
            img.onload = function () {
                URL.revokeObjectURL(url);
                resolve(img);
            };
            img.onerror = function () {
                URL.revokeObjectURL(url);
                reject(new Error('อ่านรูปไม่ได้'));
            };
            img.src = url;
        });
    }

    function canvasToJpeg(img, maxSide, quality) {
        return new Promise(function (resolve) {
            var w = img.naturalWidth || img.width || 0;
            var h = img.naturalHeight || img.height || 0;
            if (w > 0 && h > 0 && (w > maxSide || h > maxSide)) {
                if (w >= h) {
                    h = Math.round(h * maxSide / w);
                    w = maxSide;
                } else {
                    w = Math.round(w * maxSide / h);
                    h = maxSide;
                }
            }
            if (!w || !h) {
                resolve(null);
                return;
            }
            var canvas = document.createElement('canvas');
            canvas.width = w;
            canvas.height = h;
            var ctx = canvas.getContext('2d');
            ctx.fillStyle = '#fff';
            ctx.fillRect(0, 0, w, h);
            ctx.drawImage(img, 0, 0, w, h);
            canvas.toBlob(function (blob) { resolve(blob || null); }, 'image/jpeg', quality);
        });
    }

    function asJpegFile(blob, origName) {
        var name = String(origName || 'photo.jpg').replace(/\.[^.]+$/, '') + '.jpg';
        return new File([blob], name, { type: 'image/jpeg', lastModified: Date.now() });
    }

    function looksLikeImage(file) {
        if (!file) return false;
        var t = String(file.type || '').toLowerCase();
        if (t.indexOf('image/') === 0) return true;
        return /\.(jpe?g|png|gif|webp|heic|heif|bmp)$/i.test(file.name || '');
    }

    async function compressImage(file) {
        if (!looksLikeImage(file)) return null;
        var img;
        try {
            img = await loadImage(file);
        } catch (e) {
            if (file.size && file.size <= MAX_BYTES && (file.type === 'image/jpeg' || file.type === 'image/png')) {
                return file;
            }
            throw new Error('แปลงรูปไม่ได้ — ถ้าเป็น iPhone ให้ตั้งกล้องเป็น Most Compatible หรือถ่ายใหม่เป็น JPG');
        }
        var sides = [1600, 1280, 1024, 800];
        var quals = [0.72, 0.62, 0.52, 0.42];
        var best = null;
        for (var i = 0; i < sides.length; i++) {
            var blob = await canvasToJpeg(img, sides[i], quals[Math.min(i, quals.length - 1)]);
            if (!blob) continue;
            best = blob;
            if (blob.size <= MAX_BYTES) break;
        }
        if (!best) {
            if (file.size <= MAX_BYTES) return file;
            throw new Error('ไฟล์รูปใหญ่เกินไป กรุณาถ่ายใหม่หรือลดขนาด');
        }
        return asJpegFile(best, file.name);
    }

    async function compressFileList(list, limit) {
        limit = limit || 8;
        var incoming = Array.from(list || []);
        var out = [];
        for (var i = 0; i < incoming.length; i++) {
            if (out.length >= limit) break;
            var f = incoming[i];
            if (!looksLikeImage(f)) continue;
            out.push(await compressImage(f));
        }
        return out;
    }

    global.afCompressImage = compressImage;
    global.afCompressFileList = compressFileList;
    global.afLooksLikeImage = looksLikeImage;
})(window);
