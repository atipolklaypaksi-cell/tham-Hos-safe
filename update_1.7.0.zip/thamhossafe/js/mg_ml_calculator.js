(function () {
    function esc(s) {
        if (s == null) return '';
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function fmt(val, digits) {
        if (val == null || val === '' || isNaN(val)) return '—';
        const n = Number(val);
        if (!isFinite(n)) return '—';
        let s = n.toFixed(digits == null ? 4 : digits);
        s = s.replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '');
        return s;
    }

    function numAttr(el, name) {
        const v = parseFloat(el.getAttribute(name) || '');
        return isFinite(v) && v > 0 ? v : 0;
    }

    function selectedDrug() {
        const sel = document.getElementById('mmc_drug');
        if (!sel || !sel.value) return null;
        const opt = sel.options[sel.selectedIndex];
        if (!opt) return null;
        return {
            id: sel.value,
            icode: opt.getAttribute('data-icode') || '',
            name: opt.getAttribute('data-name') || opt.text,
            mgml: numAttr(opt, 'data-mgml'),
            amp: numAttr(opt, 'data-amp'),
            kgmin: numAttr(opt, 'data-kgmin'),
            kgmax: numAttr(opt, 'data-kgmax'),
            interval: numAttr(opt, 'data-interval'),
            strength: opt.getAttribute('data-strength') || ''
        };
    }

    function currentBw() {
        const el = document.getElementById('mmc_bw');
        const bw = parseFloat(el && el.value ? el.value : '');
        return bw > 0 ? bw : 0;
    }

    function currentIntervalHours(drug) {
        const sel = document.getElementById('mmc_interval');
        const ov = sel && sel.value ? parseFloat(sel.value) : 0;
        if (ov > 0) return ov;
        return drug && drug.interval > 0 ? drug.interval : 0;
    }

    function dosesPerDay(hours) {
        const h = parseFloat(hours);
        if (!(h > 0)) return null;
        return 24 / h;
    }

    function intervalLabel(hours) {
        const n = dosesPerDay(hours);
        if (n == null) return '';
        const nDisp = Math.abs(n - Math.round(n)) < 0.001 ? String(Math.round(n)) : fmt(n, 2);
        return 'ทุก ' + fmt(hours, 2) + ' ชม. (×' + nDisp + '/วัน)';
    }

    function kgRangeText(drug, bw) {
        if (!drug) return '';
        const lo = drug.kgmin > 0 ? drug.kgmin : 0;
        const hi = drug.kgmax > 0 ? drug.kgmax : 0;
        if (!(lo > 0) && !(hi > 0)) return '';
        let range;
        if (lo > 0 && hi > 0 && Math.abs(lo - hi) >= 0.0001) {
            range = fmt(lo) + '–' + fmt(hi) + ' mg/kg';
        } else {
            range = fmt(lo || hi) + ' mg/kg';
        }
        if (!(bw > 0)) return range;
        const mgLo = (lo > 0 ? lo : hi) * bw;
        const mgHi = (hi > 0 ? hi : lo) * bw;
        if (Math.abs(mgLo - mgHi) < 0.0001) {
            return range + ' = ' + fmt(mgLo, 2) + ' mg (BW ' + fmt(bw, 1) + ' kg)';
        }
        return range + ' = ' + fmt(mgLo, 2) + '–' + fmt(mgHi, 2) + ' mg (BW ' + fmt(bw, 1) + ' kg)';
    }

    function suggestedMgFromKg(drug, bw) {
        if (!drug || !(bw > 0)) return null;
        const lo = drug.kgmin > 0 ? drug.kgmin : 0;
        const hi = drug.kgmax > 0 ? drug.kgmax : 0;
        if (!(lo > 0) && !(hi > 0)) return null;
        return (lo > 0 ? lo : hi) * bw;
    }

    function clearOutputs() {
        const ids = ['mmcOutConc', 'mmcOutMl', 'mmcOutAmp', 'mmcOutAmpDay'];
        ids.forEach(function (id) {
            const el = document.getElementById(id);
            if (el) el.textContent = '—';
        });
    }

    function updateCalc(from) {
        const drug = selectedDrug();
        const meta = document.getElementById('mmcDrugMeta');
        const hint = document.getElementById('mmcKgHint');
        const outConc = document.getElementById('mmcOutConc');
        const outMl = document.getElementById('mmcOutMl');
        const outAmp = document.getElementById('mmcOutAmp');
        const outAmpDay = document.getElementById('mmcOutAmpDay');
        const suggest = document.getElementById('mmcSuggest');
        const mgEl = document.getElementById('mmc_mg');
        const mlEl = document.getElementById('mmc_ml');
        const bw = currentBw();
        if (!drug || !(drug.mgml > 0)) {
            if (meta) meta.textContent = 'เลือกยาเพื่อดูความเข้มข้น';
            if (hint) hint.textContent = '';
            clearOutputs();
            if (suggest) suggest.textContent = 'วิธีใช้ที่แนะนำจะแสดงที่นี่';
            return;
        }
        const hours = currentIntervalHours(drug);
        const perDay = dosesPerDay(hours);
        if (meta) {
            meta.textContent = drug.name + ' · ' + fmt(drug.mgml) + ' mg/mL'
                + (drug.strength ? ' · ' + drug.strength : '')
                + (drug.amp > 0 ? ' · ' + fmt(drug.amp) + ' mg/Amp' : '')
                + (hours > 0 ? ' · ' + intervalLabel(hours) : '');
        }
        if (hint) hint.textContent = kgRangeText(drug, bw);
        if (outConc) outConc.textContent = fmt(drug.mgml);

        if (from === 'drug' || from === 'bw') {
            const suggested = suggestedMgFromKg(drug, bw);
            if (suggested != null && mgEl) {
                mgEl.value = fmt(suggested, 4);
            }
        }

        let mg = parseFloat(mgEl && mgEl.value ? mgEl.value : '');
        let ml = parseFloat(mlEl && mlEl.value ? mlEl.value : '');
        if (from === 'ml' && ml > 0) {
            mg = ml * drug.mgml;
            if (mgEl && document.activeElement !== mgEl) mgEl.value = fmt(mg, 4);
        } else if (mg > 0) {
            ml = mg / drug.mgml;
            if (mlEl && document.activeElement !== mlEl) mlEl.value = fmt(ml, 4);
        } else {
            if (outMl) outMl.textContent = '—';
            if (outAmp) outAmp.textContent = '—';
            if (outAmpDay) outAmpDay.textContent = '—';
            if (suggest) {
                suggest.textContent = bw > 0 && (drug.kgmin > 0 || drug.kgmax > 0)
                    ? 'เลือกยาแล้วระบบจะใส่ขนาดจาก mg/kg × น้ำหนัก'
                    : 'ใส่น้ำหนัก หรือขนาดยา (mg) / ปริมาตร (mL)';
            }
            return;
        }
        const ampDose = drug.amp > 0 ? (mg / drug.amp) : null;
        const ampDay = ampDose != null && perDay != null ? ampDose * perDay : null;
        if (outMl) outMl.textContent = fmt(ml, 4) + ' mL';
        if (outAmp) outAmp.textContent = ampDose != null ? fmt(ampDose, 3) : '—';
        if (outAmpDay) outAmpDay.textContent = ampDay != null ? fmt(ampDay, 3) : '—';
        if (suggest) {
            let line = 'IV ' + fmt(mg, 2) + ' MG (' + fmt(ml, 4) + ' ml)';
            if (ampDose != null) line += '  ·  Amp/ครั้ง ' + fmt(ampDose, 3);
            if (ampDay != null) line += '  ·  Amp/วัน ' + fmt(ampDay, 3) + ' (' + intervalLabel(hours) + ')';
            suggest.textContent = line;
        }
    }

    function fmtDate(d) {
        if (!d) return '';
        const s = String(d).slice(0, 10);
        const m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
        if (!m) return String(d);
        return m[3] + '/' + m[2] + '/' + m[1];
    }

    function pickOrder(item) {
        const sel = document.getElementById('mmc_drug');
        if (sel && item.rule_id) {
            sel.value = String(item.rule_id);
        }
        const mgEl = document.getElementById('mmc_mg');
        const mlEl = document.getElementById('mmc_ml');
        if (mgEl) mgEl.value = item.dose_mg != null ? item.dose_mg : '';
        if (mlEl) mlEl.value = '';
        updateCalc('mg');
        document.querySelectorAll('tr.mmc-order-row').forEach(function (tr) {
            tr.classList.toggle('mmc-order-picked', tr.getAttribute('data-key') === item._key);
        });
    }

    function renderOrders(orders) {
        const tbody = document.getElementById('mmcOrderTbody');
        const count = document.getElementById('mmcOrderCount');
        if (count) count.textContent = orders.length;
        if (!tbody) return;
        if (!orders.length) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted py-4">ไม่พบใบยาที่ตรงกับรายการที่ตั้งค่าในช่วงนี้</td></tr>';
            return;
        }
        tbody.innerHTML = orders.map(function (item, idx) {
            item._key = String(idx);
            const when = esc(item.order_date || '-') + (item.order_time ? '<br><span class="text-muted">' + esc(item.order_time) + '</span>' : '');
            const badge = item.type_patient === 'IPD' ? 'bg-secondary' : 'bg-info text-dark';
            return '<tr class="mmc-order-row" data-key="' + idx + '">'
                + '<td class="text-center small">' + when + '</td>'
                + '<td class="text-center"><span class="badge ' + badge + '">' + esc(item.type_patient || '') + '</span>'
                + (item.ward_display ? '<div class="small text-muted">' + esc(item.ward_display) + '</div>' : '') + '</td>'
                + '<td class="text-start small"><b>' + esc(item.drug_name) + '</b><br><span class="text-muted">' + esc(item.mg_per_ml_display || '') + '</span></td>'
                + '<td class="text-start small">' + esc(item.method || '-') + '</td>'
                + '<td class="text-center small fw-bold">' + esc(item.dose_mg_display || '—') + '</td>'
                + '<td class="text-center small">' + esc(item.stated_ml_display || '—') + '</td>'
                + '<td class="text-center small fw-bold text-success">' + esc(item.expected_ml_display || '—') + '</td>'
                + '</tr>';
        }).join('');
        tbody.querySelectorAll('tr.mmc-order-row').forEach(function (tr, idx) {
            tr.addEventListener('click', function () {
                pickOrder(orders[idx]);
            });
        });
    }

    function setMsg(text, isErr) {
        const el = document.getElementById('mmcMsg');
        if (!el) return;
        if (!text) {
            el.style.display = 'none';
            el.textContent = '';
            return;
        }
        el.style.display = 'block';
        el.className = 'mt-2 small fw-bold ' + (isErr ? 'text-danger' : 'text-success');
        el.textContent = text;
    }

    function lookupHn() {
        const hnEl = document.getElementById('mmc_hn');
        const daysEl = document.getElementById('mmc_days');
        const info = document.getElementById('mmcPatientInfo');
        const btn = document.getElementById('mmcBtnLookup');
        const hn = (hnEl && hnEl.value ? hnEl.value : '').trim();
        if (!hn) {
            alert('กรุณากรอก HN');
            return;
        }
        if (btn) btn.disabled = true;
        setMsg('กำลังค้นหา...', false);
        const qs = new URLSearchParams({
            action: 'lookup',
            hn: hn,
            days: daysEl ? daysEl.value : '7'
        });
        fetch('fetch_mg_ml_calculator_api.php?' + qs.toString(), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (btn) btn.disabled = false;
                if (data.status !== 'success') {
                    setMsg(data.message || 'ค้นหาไม่สำเร็จ', true);
                    return;
                }
                const p = data.patient || {};
                const bits = [];
                bits.push('<b>' + esc(p.ptname || '') + '</b>');
                bits.push('HN ' + esc(p.hn || hn));
                if (p.age != null) bits.push('อายุ ' + p.age + ' ปี');
                if (info) info.innerHTML = bits.join(' · ');
                const bwEl = document.getElementById('mmc_bw');
                const bwHint = document.getElementById('mmcBwHint');
                if (bwEl) {
                    bwEl.value = p.bw ? fmt(p.bw, 2) : '';
                }
                if (bwHint) {
                    if (p.bw) {
                        const src = p.bw_source_label
                            || (p.bw_source === 'calculator' || p.bw_source === 'tham' ? 'THAM' : 'HOSxP');
                        const when = fmtDate(p.bw_date || p.vstdate);
                        bwHint.textContent = 'น้ำหนักล่าสุดจาก ' + src + (when ? ' · ' + when : '');
                    } else {
                        bwHint.textContent = 'ไม่พบน้ำหนัก — กรอกเองได้ (บันทึกเข้า THAM อัตโนมัติเมื่อเปลี่ยนค่า)';
                    }
                }
                window.__mmcLastHn = p.hn || hn;
                window.__mmcLastPtname = p.ptname || '';
                const n = (data.orders || []).length;
                const rules = (data.meta && data.meta.rule_count) || 0;
                setMsg('พบ ' + n + ' ใบยา จาก ' + rules + ' รายการที่ตั้งค่า — คลิกแถวเพื่อใส่เครื่องคำนวณ', false);
                renderOrders(data.orders || []);
                updateCalc('bw');
            })
            .catch(function (err) {
                if (btn) btn.disabled = false;
                setMsg(err.message || 'เชื่อมต่อไม่สำเร็จ', true);
            });
    }

    function initCalc() {
        const btn = document.getElementById('mmcBtnLookup');
        if (!btn) return;
        btn.addEventListener('click', lookupHn);
        const hnEl = document.getElementById('mmc_hn');
        if (hnEl) {
            hnEl.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    lookupHn();
                }
            });
        }
        const drug = document.getElementById('mmc_drug');
        const mgEl = document.getElementById('mmc_mg');
        const mlEl = document.getElementById('mmc_ml');
        const bwEl = document.getElementById('mmc_bw');
        const intEl = document.getElementById('mmc_interval');
        if (drug) drug.addEventListener('change', function () { updateCalc('drug'); });
        if (mgEl) mgEl.addEventListener('input', function () { updateCalc('mg'); });
        if (mlEl) mlEl.addEventListener('input', function () { updateCalc('ml'); });
        let bwSaveTimer = null;
        function persistBw() {
            const hn = (window.__mmcLastHn || (hnEl && hnEl.value) || '').trim();
            const bw = currentBw();
            if (!hn || !(bw > 0)) return;
            const hint = document.getElementById('mmcBwHint');
            fetch('fetch_mg_ml_calculator_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify({
                    action: 'save_bw',
                    hn: hn,
                    bw: bw,
                    ptname: window.__mmcLastPtname || '',
                    source_module: 'mg_ml_calculator'
                })
            }).then(function (r) { return r.json(); }).then(function (res) {
                if (!hint) return;
                if (res && res.status === 'success') {
                    hint.textContent = 'บันทึกน้ำหนักใน THAM แล้ว · ' + fmt(bw, 2) + ' kg';
                }
            }).catch(function () {});
        }
        if (bwEl) {
            bwEl.addEventListener('input', function () {
                updateCalc('bw');
                if (bwSaveTimer) clearTimeout(bwSaveTimer);
                bwSaveTimer = setTimeout(persistBw, 800);
            });
            bwEl.addEventListener('change', persistBw);
        }
        if (intEl) intEl.addEventListener('change', function () { updateCalc('interval'); });
        if (hnEl && hnEl.value.trim()) lookupHn();
    }

    const PARSE_RULES = [
        { regex: /(\d+(?:\.\d+)?)\s*mg\s*\/\s*(\d+(?:\.\d+)?)?\s*ml\b/i, unit: 'mg' },
        { regex: /(\d+(?:\.\d+)?)\s*(?:mcg|µg|μg|ug)\s*\/\s*(\d+(?:\.\d+)?)?\s*ml\b/i, unit: 'mcg' },
        { regex: /(\d+(?:\.\d+)?)\s*(?:g|gm|gram)\s*\/\s*(\d+(?:\.\d+)?)?\s*ml\b/i, unit: 'g' }
    ];

    function parseStrength() {
        const text = ($('#mmc_strength_text').val() || '').trim();
        if (!text) {
            alert('กรุณาใส่ strength เช่น 250 mg/mL หรือ 1000 mg/4 mL');
            return;
        }
        for (let i = 0; i < PARSE_RULES.length; i++) {
            const p = PARSE_RULES[i];
            const m = text.match(p.regex);
            if (!m) continue;
            let num = parseFloat(m[1]);
            let vol = m[2] !== undefined && m[2] !== '' ? parseFloat(m[2]) : 1;
            if (!(vol > 0)) continue;
            if (p.unit === 'mcg') num = num / 1000;
            if (p.unit === 'g') num = num * 1000;
            const mgPerMl = num / vol;
            if (mgPerMl > 0) {
                $('#mmc_mg_per_ml').val(mgPerMl);
                return;
            }
        }
        alert('ไม่สามารถแปลง strength นี้ได้ — ลองใส่ mg/mL โดยตรง');
    }

    function resetItemForm() {
        $('#mmcFormCard').removeClass('edit-mode');
        $('#mmcFormTitle').text('เพิ่มรายการยา');
        $('#mmc_action').val('add_item');
        $('#mmc_rule_id').val('');
        $('#mmc_item_drug').val(null).trigger('change');
        $('#mmc_strength_text').val('');
        $('#mmc_mg_per_ml').val('');
        $('#mmc_mg_per_amp').val('');
        $('#mmc_kg_min').val('');
        $('#mmc_kg_max').val('');
        $('#mmc_item_interval').val('');
        $('#mmc_detail_text').val('');
        $('#mmc_active').prop('checked', true);
        $('.mmc-rule-row').removeClass('mmc-editing-row');
    }

    function setEdit(rule) {
        $('.mmc-rule-row').removeClass('mmc-editing-row');
        $('tr.mmc-rule-row[data-rule-id="' + rule.id + '"]').addClass('mmc-editing-row');
        $('#mmcFormCard').addClass('edit-mode');
        $('#mmcFormTitle').text('แก้ไข: ' + (rule.drug_name || '') + ' (ID ' + rule.id + ')');
        $('#mmc_action').val('edit_item');
        $('#mmc_rule_id').val(rule.id);
        const drugVal = (rule.icode || '') + '|' + (rule.drug_name || '');
        const $sel = $('#mmc_item_drug');
        if (!$sel.find('option').filter(function () { return $(this).val() === drugVal; }).length) {
            $sel.append(new Option((rule.drug_name || '') + ' (icode: ' + rule.icode + ')', drugVal, true, true));
        }
        $sel.val(drugVal).trigger('change');
        $('#mmc_strength_text').val(rule.strength_text || '');
        $('#mmc_mg_per_ml').val(rule.mg_per_ml || '');
        $('#mmc_mg_per_amp').val(rule.mg_per_amp != null ? rule.mg_per_amp : '');
        $('#mmc_kg_min').val(rule.calc_mg_per_kg_min != null ? rule.calc_mg_per_kg_min : '');
        $('#mmc_kg_max').val(rule.calc_mg_per_kg_max != null ? rule.calc_mg_per_kg_max : '');
        const iv = rule.calc_interval_hours != null ? String(rule.calc_interval_hours).replace(/\.0+$/, '') : '';
        $('#mmc_item_interval').val(iv);
        $('#mmc_detail_text').val(rule.detail_text || '');
        $('#mmc_active').prop('checked', !!rule.active);
        const card = document.getElementById('mmcFormCard');
        if (card) card.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function initDrugSelect() {
        const $sel = $('#mmc_item_drug');
        if (!$sel.length || typeof $sel.select2 !== 'function') return;
        if ($sel.hasClass('select2-hidden-accessible')) {
            $sel.select2('destroy');
        }
        $sel.select2({
            theme: 'bootstrap-5',
            width: '100%',
            dropdownParent: $('#mmc-pane-settings'),
            placeholder: 'พิมพ์ชื่อยาหรือ icode เพื่อค้นหา...',
            allowClear: true,
            minimumInputLength: 1,
            ajax: {
                url: 'fetch_hosxp_drugs_select_api.php',
                dataType: 'json',
                delay: 250,
                data: function (params) { return { q: params.term }; },
                processResults: function (data) { return { results: data.results || [] }; }
            }
        });
    }

    function initSettings() {
        if (!$('#mmc_item_drug').length) return;
        const settingsBtn = document.getElementById('mmc-tab-settings');
        const calcBtn = document.getElementById('mmc-tab-calc');
        if (settingsBtn) {
            settingsBtn.addEventListener('shown.bs.tab', function () {
                initDrugSelect();
                if (history.replaceState) history.replaceState(null, '', 'mg_ml_calculator.php?tab=settings');
            });
        }
        if (calcBtn) {
            calcBtn.addEventListener('shown.bs.tab', function () {
                if (history.replaceState) history.replaceState(null, '', 'mg_ml_calculator.php');
            });
        }
        if ($('#mmc-pane-settings').hasClass('active')) {
            initDrugSelect();
        }
        $('#mmcBtnParse').on('click', parseStrength);
        $('#mmcBtnReset').on('click', resetItemForm);
        $(document).on('click', '.mmc-btn-edit', function () {
            let rule = $(this).data('rule');
            if (typeof rule === 'string') {
                try { rule = JSON.parse(rule); } catch (e) { return; }
            }
            if (!rule || !rule.id) return;
            const tabBtn = document.getElementById('mmc-tab-settings');
            if (tabBtn && typeof bootstrap !== 'undefined') {
                bootstrap.Tab.getOrCreateInstance(tabBtn).show();
            }
            setEdit(rule);
        });
        $('#mmcRuleSearch').on('input', function () {
            const q = (($(this).val() || '') + '').toLowerCase();
            $('.mmc-rule-row').each(function () {
                const t = (($(this).text() || '') + '').toLowerCase();
                $(this).toggle(!q || t.indexOf(q) !== -1);
            });
        });
    }

    $(function () {
        initCalc();
        initSettings();
    });
})();
