/**
 * เมื่อเปิดหน้า Monitor จาก Smart Pharma ด้วย ?hn=&date=
 * ตั้งช่วงวันที่, กดประมวลผล, แล้วกรองตารางให้เหลือ HN นั้น
 */
(function () {
    var page = (location.pathname.split('/').pop() || '').split('?')[0];
    if (!/^monitor_/.test(page)) {
        return;
    }
    var params = new URLSearchParams(location.search);
    if ((params.get('tab') || '') === 'settings') {
        return;
    }
    var hnRaw = String(params.get('hn') || '').trim();
    var date = String(params.get('date') || params.get('start') || '').trim();
    var end = String(params.get('end') || date).trim();
    if (!hnRaw && !date) {
        return;
    }

    function digits(s) {
        return String(s || '').replace(/\D+/g, '');
    }
    function normHn(s) {
        var d = digits(s).replace(/^0+/, '');
        return d === '' ? '0' : d;
    }
    var hnN = hnRaw ? normHn(hnRaw) : '';
    var focusOff = false;

    function setDates() {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
            return;
        }
        ['filter_start', 'filter_end'].forEach(function (id, i) {
            var val = i === 1 ? end : date;
            var el = document.getElementById(id);
            if (!el) {
                return;
            }
            if (el._flatpickr) {
                el._flatpickr.setDate(val, true);
            } else {
                el.value = val;
            }
        });
    }

    function tablesWithHn() {
        return Array.prototype.filter.call(document.querySelectorAll('#content table, .content table'), function (tbl) {
            if (tbl.closest('form') || tbl.closest('.modal')) {
                return false;
            }
            var head = (tbl.tHead && tbl.tHead.innerText) || '';
            if (!head && tbl.querySelector('thead')) {
                head = tbl.querySelector('thead').innerText || '';
            }
            return /\bHN\b/i.test(head);
        });
    }

    function rowHasHn(tr) {
        if (!hnN) {
            return true;
        }
        var dh = tr.getAttribute('data-hn') || '';
        if (dh && normHn(dh) === hnN) {
            return true;
        }
        var tds = tr.querySelectorAll('td');
        if (!tds.length) {
            return true;
        }
        if (tr.querySelector('[colspan]') && tds.length < 2) {
            return true;
        }
        for (var i = 0; i < Math.min(tds.length, 4); i++) {
            var txt = (tds[i].innerText || tds[i].textContent || '').trim();
            var d = digits(txt);
            if (d.length >= 3 && d.length <= 12 && normHn(d) === hnN) {
                return true;
            }
        }
        return false;
    }

    function applyFilter() {
        if (focusOff || !hnN) {
            return;
        }
        tablesWithHn().forEach(function (tbl) {
            var tb = tbl.tBodies[0];
            if (!tb) {
                return;
            }
            Array.prototype.forEach.call(tb.rows, function (tr) {
                if (!tr.querySelector('td')) {
                    return;
                }
                tr.style.display = rowHasHn(tr) ? '' : 'none';
            });
        });
        document.querySelectorAll('.mhm-patient').forEach(function (card) {
            var dh = card.getAttribute('data-hn') || '';
            var txt = card.querySelector('.mhm-pt-hn') ? card.querySelector('.mhm-pt-hn').innerText : '';
            var ok = (dh && normHn(dh) === hnN) || (txt && normHn(txt) === hnN);
            card.style.display = ok ? '' : 'none';
        });
    }

    function showAll() {
        focusOff = true;
        tablesWithHn().forEach(function (tbl) {
            var tb = tbl.tBodies[0];
            if (!tb) return;
            Array.prototype.forEach.call(tb.rows, function (tr) { tr.style.display = ''; });
        });
        document.querySelectorAll('.mhm-patient').forEach(function (card) {
            card.style.display = '';
        });
        try {
            var u = new URL(location.href);
            u.searchParams.delete('hn');
            history.replaceState({}, '', u);
        } catch (e) {}
        var btn = document.querySelector('button[id^="btnFetch"]');
        if (btn && !btn.disabled) {
            btn.click();
        }
    }

    function banner() {
        if (!hnRaw || document.getElementById('thamHnFocusBanner')) {
            return;
        }
        var b = document.createElement('div');
        b.id = 'thamHnFocusBanner';
        b.setAttribute('role', 'status');
        b.style.cssText = 'position:sticky;top:0;z-index:1020;background:#0f766e;color:#fff;'
            + 'padding:8px 16px;font-weight:700;display:flex;gap:12px;align-items:center;flex-wrap:wrap;';
        var label = document.createElement('span');
        label.innerHTML = '<i class="fas fa-user-injured me-1"></i>กำลังดูรายละเอียด HN '
            + String(hnRaw).replace(/[<>&]/g, '')
            + (date ? ' · วันที่ ' + date : '');
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-sm btn-light py-0 fw-bold';
        btn.textContent = 'แสดงทั้งหมด';
        btn.addEventListener('click', function () {
            showAll();
            b.remove();
        });
        b.appendChild(label);
        b.appendChild(btn);
        var content = document.getElementById('content') || document.querySelector('.content') || document.body;
        content.insertBefore(b, content.firstChild);
    }

    function fillSearchBoxes() {
        if (!hnRaw) {
            return;
        }
        ['madQ', 'mspQ', 'moqHnSearch'].forEach(function (id) {
            var el = document.getElementById(id);
            if (!el) {
                return;
            }
            el.value = hnRaw;
            el.dispatchEvent(new Event('input', { bubbles: true }));
        });
    }

    function clickFetch() {
        if (!date) {
            return;
        }
        setDates();
        var btn = document.querySelector('button[id^="btnFetch"]');
        if (btn && !btn.disabled) {
            btn.click();
        }
    }

    function boot() {
        setDates();
        fillSearchBoxes();
        banner();
        var obs = new MutationObserver(function () {
            applyFilter();
        });
        obs.observe(document.body, { childList: true, subtree: true });
        setTimeout(clickFetch, 350);
        setTimeout(applyFilter, 800);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 250); });
    } else {
        setTimeout(boot, 250);
    }
})();
