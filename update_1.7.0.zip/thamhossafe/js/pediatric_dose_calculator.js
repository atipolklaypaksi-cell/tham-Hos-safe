(function () {
    function esc(s) {
        if (s == null) return '';
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function fmt(val, digits) {
        if (val == null || val === '' || isNaN(val)) return '—';
        const n = Number(val);
        if (!isFinite(n)) return '—';
        let s = n.toFixed(digits == null ? 2 : digits);
        s = s.replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '');
        return s;
    }

    function fmtRange(a, b, digits, suffix) {
        const lo = fmt(a, digits);
        const hi = fmt(b, digits);
        const sfx = suffix || '';
        if (lo === '—' && hi === '—') return '—';
        if (lo === hi) return lo + sfx;
        return lo + '–' + hi + sfx;
    }

    function fmtDate(d) {
        if (!d) return '';
        const s = String(d).slice(0, 10);
        const m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
        if (!m) return String(d);
        return m[3] + '/' + m[2] + '/' + m[1];
    }

    function hoursFromTimes(times) {
        const n = parseFloat(times);
        if (!(n > 0)) return null;
        return 24 / n;
    }

    function intervalLabel(times) {
        const n = parseFloat(times);
        const h = hoursFromTimes(n);
        if (!(n > 0)) return '';
        const nDisp = Math.abs(n - Math.round(n)) < 0.001 ? String(Math.round(n)) : fmt(n, 2);
        if (h) return 'ทุก ' + fmt(h, 2) + ' ชม. (×' + nDisp + '/วัน)';
        return 'วันละ ' + nDisp + ' ครั้ง';
    }

    function currentBw() {
        const el = document.getElementById('pdc_bw');
        const bw = parseFloat(el && el.value ? el.value : '');
        return bw > 0 ? bw : 0;
    }

    function calcItem(item, bw, timesOverride) {
        const times = timesOverride != null && timesOverride !== ''
            ? parseFloat(timesOverride) : parseFloat(item.times_per_day);
        const t = times > 0 ? times : 1;
        let lo = parseFloat(item.mg_per_kg_min);
        let hi = parseFloat(item.mg_per_kg_max);
        if (!(hi > 0)) hi = lo;
        if (!(lo > 0)) lo = hi;
        if (!(bw > 0) || (!(lo > 0) && !(hi > 0))) return null;
        let dayMin, dayMax, doseMin, doseMax;
        if (item.dose_unit === 'mg_kg_day') {
            dayMin = bw * lo;
            dayMax = bw * hi;
            doseMin = dayMin / t;
            doseMax = dayMax / t;
        } else {
            doseMin = bw * lo;
            doseMax = bw * hi;
            dayMin = doseMin * t;
            dayMax = doseMax * t;
        }
        const cap = parseFloat(item.max_mg_day);
        let capped = false;
        if (cap > 0) {
            if (dayMin > cap) { dayMin = cap; capped = true; }
            if (dayMax > cap) { dayMax = cap; capped = true; }
            doseMin = dayMin / t;
            doseMax = dayMax / t;
        }
        const conc = parseFloat(item.mg_per_ml);
        const amp = parseFloat(item.mg_per_amp);
        return {
            times: t,
            capped: capped,
            mg_day_min: dayMin,
            mg_day_max: dayMax,
            mg_dose_min: doseMin,
            mg_dose_max: doseMax,
            ml_dose_min: conc > 0 ? doseMin / conc : null,
            ml_dose_max: conc > 0 ? doseMax / conc : null,
            amp_day_min: amp > 0 ? dayMin / amp : null,
            amp_day_max: amp > 0 ? dayMax / amp : null
        };
    }

    const catalog = Array.isArray(window.PDC_CATALOG) ? window.PDC_CATALOG : [];
    const timesOverride = {};
    let selectedId = catalog.length ? catalog[0].id : null;
    let catFilter = 'oral';

    function itemById(id) {
        for (let i = 0; i < catalog.length; i++) {
            if (String(catalog[i].id) === String(id)) return catalog[i];
        }
        return null;
    }

    function showDetail(item, r) {
        const nameEl = document.getElementById('pdcSelName');
        const meta = document.getElementById('pdcSelMeta');
        const suggest = document.getElementById('pdcSuggest');
        if (!item) {
            if (nameEl) nameEl.textContent = 'เลือกยาจากตาราง';
            if (meta) meta.textContent = 'คลิกแถวในตารางเพื่อดูรายละเอียด';
            ['pdcOutDay', 'pdcOutDose', 'pdcOutMl', 'pdcOutAmp'].forEach(function (id) {
                const el = document.getElementById(id);
                if (el) el.textContent = '—';
            });
            if (suggest) suggest.textContent = 'ใส่น้ำหนัก แล้วคลิกยาในตาราง';
            return;
        }
        if (nameEl) nameEl.textContent = item.drug_name;
        const kg = fmtRange(item.mg_per_kg_min, item.mg_per_kg_max, 2, ' mg/kg');
        const unit = item.dose_unit === 'mg_kg_day' ? 'mg/kg/day' : 'mg/kg/dose';
        if (meta) {
            meta.textContent = (item.strength_text ? item.strength_text + ' · ' : '')
                + kg + ' · ' + unit
                + (r ? ' · ' + intervalLabel(r.times) : '')
                + (item.note_text ? ' · ' + item.note_text : '');
        }
        if (!r) {
            ['pdcOutDay', 'pdcOutDose', 'pdcOutMl', 'pdcOutAmp'].forEach(function (id) {
                const el = document.getElementById(id);
                if (el) el.textContent = '—';
            });
            if (suggest) suggest.textContent = 'ใส่น้ำหนักเพื่อคำนวณ';
            return;
        }
        document.getElementById('pdcOutDay').textContent = fmtRange(r.mg_day_min, r.mg_day_max, 1, ' mg');
        document.getElementById('pdcOutDose').textContent = fmtRange(r.mg_dose_min, r.mg_dose_max, 1, ' mg');
        document.getElementById('pdcOutMl').textContent = fmtRange(r.ml_dose_min, r.ml_dose_max, 2, ' mL');
        document.getElementById('pdcOutAmp').textContent = fmtRange(r.amp_day_min, r.amp_day_max, 2);
        let line = intervalLabel(r.times);
        if (r.ml_dose_min != null) line += '  ·  ให้ ' + fmtRange(r.ml_dose_min, r.ml_dose_max, 2, ' mL') + ' /ครั้ง';
        line += '  ·  ' + fmtRange(r.mg_dose_min, r.mg_dose_max, 1, ' mg') + ' /ครั้ง';
        if (r.capped) line += '  ·  จำกัดที่ max mg/วัน';
        if (suggest) suggest.textContent = line;
    }

    function renderTable() {
        const tbody = document.getElementById('pdcTableBody');
        if (!tbody) return;
        const bw = currentBw();
        const q = ((document.getElementById('pdcSearch') && document.getElementById('pdcSearch').value) || '').toLowerCase();
        const rows = catalog.filter(function (item) {
            if (catFilter && item.category !== catFilter) return false;
            if (!q) return true;
            const blob = ((item.drug_name || '') + ' ' + (item.strength_text || '')).toLowerCase();
            return blob.indexOf(q) !== -1;
        });
        if (!rows.length) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted py-4">ไม่พบรายการยา</td></tr>';
            showDetail(null, null);
            return;
        }
        tbody.innerHTML = rows.map(function (item) {
            const times = timesOverride[item.id] != null ? timesOverride[item.id] : item.times_per_day;
            const r = bw > 0 ? calcItem(item, bw, times) : null;
            const kg = fmtRange(item.mg_per_kg_min, item.mg_per_kg_max, 2);
            const unit = item.dose_unit === 'mg_kg_day' ? 'mg/kg/day' : 'mg/kg/dose';
            const picked = String(item.id) === String(selectedId) ? ' pdc-row-picked' : '';
            const capped = r && r.capped ? ' pdc-capped' : '';
            return '<tr class="pdc-row' + picked + capped + '" data-id="' + item.id + '">'
                + '<td class="text-start small"><b>' + esc(item.drug_name) + '</b>'
                + (item.note_text ? '<br><span class="text-muted">' + esc(item.note_text) + '</span>' : '') + '</td>'
                + '<td class="text-center small">' + esc(item.strength_text || '—') + '</td>'
                + '<td class="text-center small fw-bold">' + kg + '</td>'
                + '<td class="text-center small">' + unit + '</td>'
                + '<td class="text-center"><input type="number" class="form-control form-control-sm pdc-times mx-auto" min="0.5" step="0.5" data-id="' + item.id + '" value="' + fmt(times, 2) + '"></td>'
                + '<td class="text-center small">' + (item.max_mg_day ? fmt(item.max_mg_day, 1) : '—') + '</td>'
                + '<td class="text-center small pdc-mgday">' + (r ? fmtRange(r.mg_day_min, r.mg_day_max, 1) : '—') + '</td>'
                + '<td class="text-center small fw-bold">' + (r ? fmtRange(r.mg_dose_min, r.mg_dose_max, 1) : '—') + '</td>'
                + '<td class="text-center small fw-bold pdc-ml">' + (r ? fmtRange(r.ml_dose_min, r.ml_dose_max, 2) : '—') + '</td>'
                + '</tr>';
        }).join('');

        tbody.querySelectorAll('tr.pdc-row').forEach(function (tr) {
            tr.addEventListener('click', function (e) {
                if (e.target && e.target.classList.contains('pdc-times')) return;
                selectedId = tr.getAttribute('data-id');
                renderTable();
            });
        });
        tbody.querySelectorAll('input.pdc-times').forEach(function (inp) {
            inp.addEventListener('click', function (e) { e.stopPropagation(); });
            inp.addEventListener('change', function () {
                const id = inp.getAttribute('data-id');
                const v = parseFloat(inp.value);
                timesOverride[id] = v > 0 ? v : 1;
                selectedId = id;
                renderTable();
            });
        });

        const sel = itemById(selectedId) || rows[0];
        if (sel) selectedId = sel.id;
        const times = sel ? (timesOverride[sel.id] != null ? timesOverride[sel.id] : sel.times_per_day) : null;
        showDetail(sel, sel && bw > 0 ? calcItem(sel, bw, times) : null);
    }

    function setMsg(text, isErr) {
        const el = document.getElementById('pdcMsg');
        if (!el) return;
        if (!text) {
            el.style.display = 'none';
            el.textContent = '';
            return;
        }
        el.style.display = 'block';
        el.className = 'mt-2 small fw-bold ' + (isErr ? 'text-danger' : 'text-success');
        el.textContent = text;
    }

    function lookupHn() {
        const hnEl = document.getElementById('pdc_hn');
        const info = document.getElementById('pdcPatientInfo');
        const btn = document.getElementById('pdcBtnLookup');
        const hn = (hnEl && hnEl.value ? hnEl.value : '').trim();
        if (!hn) {
            alert('กรุณากรอก HN');
            return;
        }
        if (btn) btn.disabled = true;
        setMsg('กำลังค้นหา...', false);
        fetch('fetch_pediatric_dose_api.php?hn=' + encodeURIComponent(hn), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (btn) btn.disabled = false;
                if (data.status !== 'success') {
                    setMsg(data.message || 'ค้นหาไม่สำเร็จ', true);
                    return;
                }
                const p = data.patient || {};
                const bits = [];
                bits.push('<b>' + esc(p.ptname || '') + '</b>');
                bits.push('HN ' + esc(p.hn || hn));
                if (p.age != null) bits.push('อายุ ' + p.age + ' ปี');
                if (info) info.innerHTML = bits.join(' · ');
                const bwEl = document.getElementById('pdc_bw');
                const bwHint = document.getElementById('pdcBwHint');
                if (bwEl) bwEl.value = p.bw ? fmt(p.bw, 2) : '';
                if (bwHint) {
                    if (p.bw) {
                        const src = p.bw_source_label
                            || (p.bw_source === 'calculator' || p.bw_source === 'tham' ? 'THAM' : 'HOSxP');
                        const when = fmtDate(p.bw_date || p.vstdate);
                        bwHint.textContent = 'น้ำหนักล่าสุดจาก ' + src + (when ? ' · ' + when : '');
                    } else {
                        bwHint.textContent = 'ไม่พบน้ำหนัก — กรอกเองได้ (บันทึกเข้า THAM อัตโนมัติเมื่อเปลี่ยนค่า)';
                    }
                }
                window.__pdcLastHn = p.hn || hn;
                window.__pdcLastPtname = p.ptname || '';
                setMsg(p.bw ? 'ดึงน้ำหนักแล้ว — ตารางคำนวณตามน้ำหนักนี้' : 'พบผู้ป่วย แต่ไม่มีน้ำหนัก กรอก kg เองได้', false);
                renderTable();
            })
            .catch(function (err) {
                if (btn) btn.disabled = false;
                setMsg(err.message || 'เชื่อมต่อไม่สำเร็จ', true);
            });
    }

    function initCalc() {
        const btn = document.getElementById('pdcBtnLookup');
        if (!btn) return;
        btn.addEventListener('click', lookupHn);
        const hnEl = document.getElementById('pdc_hn');
        if (hnEl) {
            hnEl.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    lookupHn();
                }
            });
        }
        const bwEl = document.getElementById('pdc_bw');
        let bwSaveTimer = null;
        function persistBw() {
            const hn = (window.__pdcLastHn || (document.getElementById('pdc_hn') && document.getElementById('pdc_hn').value) || '').trim();
            const bw = currentBw();
            if (!hn || !(bw > 0)) return;
            const hint = document.getElementById('pdcBwHint');
            fetch('fetch_pediatric_dose_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify({
                    action: 'save_bw',
                    hn: hn,
                    bw: bw,
                    ptname: window.__pdcLastPtname || '',
                    source_module: 'pediatric_dose'
                })
            }).then(function (r) { return r.json(); }).then(function (res) {
                if (!hint) return;
                if (res && res.status === 'success') {
                    hint.textContent = 'บันทึกน้ำหนักใน THAM แล้ว · ' + fmt(bw, 2) + ' kg';
                }
            }).catch(function () {});
        }
        if (bwEl) {
            bwEl.addEventListener('input', function () {
                renderTable();
                if (bwSaveTimer) clearTimeout(bwSaveTimer);
                bwSaveTimer = setTimeout(persistBw, 800);
            });
            bwEl.addEventListener('change', persistBw);
        }
        const search = document.getElementById('pdcSearch');
        if (search) search.addEventListener('input', renderTable);
        document.querySelectorAll('.pdc-cat').forEach(function (b) {
            b.addEventListener('click', function () {
                catFilter = b.getAttribute('data-cat') || '';
                document.querySelectorAll('.pdc-cat').forEach(function (x) {
                    x.classList.toggle('btn-dark', x === b);
                    x.classList.toggle('btn-outline-secondary', x !== b);
                });
                renderTable();
            });
        });
        if (hnEl && hnEl.value.trim()) lookupHn();
        else renderTable();
    }

    function resetItemForm() {
        $('#pdcFormCard').removeClass('edit-mode');
        $('#pdcFormTitle').text('เพิ่มรายการยา');
        $('#pdc_action').val('add_item');
        $('#pdc_rule_id').val('');
        $('#pdc_icode').val('');
        $('#pdc_item_drug').val(null).trigger('change');
        $('#pdc_drug_name').val('');
        $('#pdc_strength_text').val('');
        $('#pdc_category').val('oral');
        $('#pdc_dose_unit').val('mg_kg_dose');
        $('#pdc_kg_min').val('');
        $('#pdc_kg_max').val('');
        $('#pdc_item_interval').val('');
        $('#pdc_times').val('1');
        $('#pdc_max_day').val('');
        $('#pdc_tolerance_pct').val('');
        $('#pdc_monitor_exclude_keywords').val('');
        $('#pdc_mg_per_ml').val('');
        $('#pdc_mg_per_amp').val('');
        $('#pdc_note').val('');
        $('#pdc_sort').val('100');
        $('#pdc_active').prop('checked', true);
        $('.pdc-rule-row').removeClass('pdc-editing-row');
    }

    function setEdit(rule) {
        $('.pdc-rule-row').removeClass('pdc-editing-row');
        $('tr.pdc-rule-row[data-rule-id="' + rule.id + '"]').addClass('pdc-editing-row');
        $('#pdcFormCard').addClass('edit-mode');
        $('#pdcFormTitle').text('แก้ไข: ' + (rule.drug_name || '') + ' (ID ' + rule.id + ')');
        $('#pdc_action').val('edit_item');
        $('#pdc_rule_id').val(rule.id);
        $('#pdc_icode').val(rule.icode || '');
        if (rule.icode && rule.drug_name) {
            const drugVal = rule.icode + '|' + rule.drug_name;
            const $sel = $('#pdc_item_drug');
            if (!$sel.find('option').filter(function () { return $(this).val() === drugVal; }).length) {
                $sel.append(new Option((rule.drug_name || '') + ' (icode: ' + rule.icode + ')', drugVal, true, true));
            }
            $sel.val(drugVal).trigger('change');
        }
        $('#pdc_drug_name').val(rule.drug_name || '');
        $('#pdc_strength_text').val(rule.strength_text || '');
        $('#pdc_category').val(rule.category || 'inject');
        $('#pdc_dose_unit').val(rule.dose_unit || 'mg_kg_dose');
        $('#pdc_kg_min').val(rule.mg_per_kg_min != null ? rule.mg_per_kg_min : '');
        $('#pdc_kg_max').val(rule.mg_per_kg_max != null ? rule.mg_per_kg_max : '');
        const iv = rule.interval_hours != null ? String(rule.interval_hours).replace(/\.0+$/, '') : '';
        $('#pdc_item_interval').val(iv);
        $('#pdc_times').val(rule.times_per_day != null ? rule.times_per_day : 1);
        $('#pdc_max_day').val(rule.max_mg_day != null ? rule.max_mg_day : '');
        $('#pdc_tolerance_pct').val(rule.tolerance_pct != null ? rule.tolerance_pct : '');
        $('#pdc_monitor_exclude_keywords').val(rule.monitor_exclude_keywords || '');
        $('#pdc_mg_per_ml').val(rule.mg_per_ml != null ? rule.mg_per_ml : '');
        $('#pdc_mg_per_amp').val(rule.mg_per_amp != null ? rule.mg_per_amp : '');
        $('#pdc_note').val(rule.note_text || '');
        $('#pdc_sort').val(rule.sort_order != null ? rule.sort_order : 100);
        $('#pdc_active').prop('checked', !!rule.active);
        const card = document.getElementById('pdcFormCard');
        if (card) card.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function initDrugSelect() {
        const $sel = $('#pdc_item_drug');
        if (!$sel.length || typeof $sel.select2 !== 'function') return;
        if ($sel.hasClass('select2-hidden-accessible')) {
            $sel.select2('destroy');
        }
        $sel.select2({
            theme: 'bootstrap-5',
            width: '100%',
            dropdownParent: $('#pdc-pane-settings'),
            placeholder: 'พิมพ์ชื่อยาหรือ icode เพื่อค้นหา...',
            allowClear: true,
            minimumInputLength: 1,
            ajax: {
                url: 'fetch_hosxp_drugs_select_api.php',
                dataType: 'json',
                delay: 250,
                data: function (params) { return { q: params.term }; },
                processResults: function (data) { return { results: data.results || [] }; }
            }
        });
        $sel.off('select2:select.pdc').on('select2:select.pdc', function (e) {
            const d = e.params && e.params.data ? e.params.data : {};
            const val = (d.id || $sel.val() || '') + '';
            const parts = val.split('|');
            if (parts[0]) $('#pdc_icode').val(parts[0]);
            const name = d.text || parts[1] || '';
            if (name && !$('#pdc_drug_name').val()) {
                $('#pdc_drug_name').val(name.replace(/\s*\(icode:.*$/, '').trim());
            } else if (parts[1] && !$('#pdc_drug_name').val()) {
                $('#pdc_drug_name').val(parts[1]);
            }
        });
    }

    function initSettings() {
        if (!$('#pdc_item_drug').length) return;
        const settingsBtn = document.getElementById('pdc-tab-settings');
        const calcBtn = document.getElementById('pdc-tab-calc');
        if (settingsBtn) {
            settingsBtn.addEventListener('shown.bs.tab', function () {
                initDrugSelect();
                if (history.replaceState) history.replaceState(null, '', 'pediatric_dose_calculator.php?tab=settings');
            });
        }
        if (calcBtn) {
            calcBtn.addEventListener('shown.bs.tab', function () {
                if (history.replaceState) history.replaceState(null, '', 'pediatric_dose_calculator.php');
            });
        }
        if ($('#pdc-pane-settings').hasClass('active')) initDrugSelect();
        $('#pdcBtnReset').on('click', resetItemForm);
        $('#pdc_item_interval').on('change', function () {
            const h = parseFloat($(this).val());
            if (h > 0) $('#pdc_times').val(fmt(24 / h, 2));
        });
        $(document).on('click', '.pdc-btn-edit', function () {
            let rule = $(this).data('rule');
            if (typeof rule === 'string') {
                try { rule = JSON.parse(rule); } catch (e) { return; }
            }
            if (!rule || !rule.id) return;
            const tabBtn = document.getElementById('pdc-tab-settings');
            if (tabBtn && typeof bootstrap !== 'undefined') {
                bootstrap.Tab.getOrCreateInstance(tabBtn).show();
            }
            setEdit(rule);
        });
        $('#pdcRuleSearch').on('input', function () {
            const q = (($(this).val() || '') + '').toLowerCase();
            $('.pdc-rule-row').each(function () {
                const t = (($(this).text() || '') + '').toLowerCase();
                $(this).toggle(!q || t.indexOf(q) !== -1);
            });
        });
    }

    $(function () {
        initCalc();
        initSettings();
    });
})();
