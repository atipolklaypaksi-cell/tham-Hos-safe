(function (global) {
    const API = 'fetch_amr_amass_api.php';
    const SETS = [
        { dataset: 'drug', filename: 'drug_data.xlsx', label: 'ยา' },
        { dataset: 'admission', filename: 'hospital_admission_data.xlsx', label: 'admit' },
        { dataset: 'microbiology', filename: 'microbiology_data.xlsx', label: 'เพาะเชื้อ' }
    ];

    async function parseJson(res) {
        const text = await res.text();
        try {
            return JSON.parse(text);
        } catch (e) {
            const hint = String(text || '')
                .replace(/<[^>]+>/g, ' ')
                .replace(/\s+/g, ' ')
                .trim()
                .slice(0, 180);
            throw new Error(hint || ('เซิร์ฟเวอร์ตอบ ' + res.status + ' ไม่ใช่ JSON'));
        }
    }

    function iso(d) {
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return y + '-' + m + '-' + day;
    }

    function monthSpans(start, end) {
        const spans = [];
        let d = new Date(start + 'T00:00:00');
        const last = new Date(end + 'T00:00:00');
        if (isNaN(d.getTime()) || isNaN(last.getTime()) || d > last) {
            return spans;
        }
        while (d <= last) {
            const monthEnd = new Date(d.getFullYear(), d.getMonth() + 1, 0);
            const ce = monthEnd < last ? monthEnd : last;
            spans.push({ start: iso(d), end: iso(ce) });
            d = new Date(ce.getTime() + 86400000);
        }
        return spans;
    }

    async function mapPool(items, limit, fn) {
        const out = new Array(items.length);
        let i = 0;
        async function worker() {
            while (true) {
                const idx = i++;
                if (idx >= items.length) {
                    break;
                }
                out[idx] = await fn(items[idx], idx);
            }
        }
        const n = Math.min(Math.max(1, limit || 1), items.length || 1);
        await Promise.all(Array.from({ length: n }, worker));
        return out;
    }

    function triggerDownload(dataset, filename) {
        const a = document.createElement('a');
        a.href = API + '?action=download&dataset=' + encodeURIComponent(dataset);
        a.download = filename || (dataset + '.xlsx');
        document.body.appendChild(a);
        a.click();
        a.remove();
    }

    async function apiGet(qs) {
        return parseJson(await fetch(API + '?' + qs, { credentials: 'same-origin' }));
    }

    async function extractChunk(job, evalStart, evalEnd) {
        const qs = 'action=extract&mode=chunk'
            + '&dataset=' + encodeURIComponent(job.dataset)
            + '&start_date=' + encodeURIComponent(job.start)
            + '&end_date=' + encodeURIComponent(job.end)
            + '&eval_start=' + encodeURIComponent(evalStart)
            + '&eval_end=' + encodeURIComponent(evalEnd);
        const res = await apiGet(qs);
        if (res.status !== 'success') {
            throw new Error(res.message || ('ดึง ' + job.label + ' ' + job.start + ' ไม่สำเร็จ'));
        }
        return res;
    }

    async function extractChunkRetry(job, evalStart, evalEnd) {
        try {
            return await extractChunk(job, evalStart, evalEnd);
        } catch (e) {
            return extractChunk(job, evalStart, evalEnd);
        }
    }

    function buildJobs(datasets, start, end) {
        const months = monthSpans(start, end);
        const jobs = [];
        datasets.forEach(function (ds) {
            months.forEach(function (m) {
                jobs.push({
                    dataset: ds.dataset,
                    filename: ds.filename,
                    label: ds.label,
                    start: m.start,
                    end: m.end
                });
            });
        });
        return jobs;
    }

    async function exportDatasets(opts) {
        const start = opts.start;
        const end = opts.end;
        const datasets = opts.datasets || SETS;
        const download = opts.download !== false;
        const onStatus = opts.onStatus || function () {};
        const onProgress = opts.onProgress || function () {};
        const concurrency = Math.min(4, Math.max(1, parseInt(opts.concurrency, 10) || 3));
        if (!start || !end) {
            throw new Error('กรุณาเลือกช่วงวันที่');
        }
        const jobs = buildJobs(datasets, start, end);
        if (!jobs.length) {
            throw new Error('ช่วงวันที่ไม่ถูกต้อง');
        }
        const dsParam = datasets.length === 1 ? datasets[0].dataset : '';
        onStatus('เตรียมดึงรายเดือนคู่ขนาน ' + jobs.length + ' งาน (' + concurrency + ' พร้อมกัน)...');
        await apiGet('action=reset_chunks' + (dsParam ? '&dataset=' + encodeURIComponent(dsParam) : ''));
        let done = 0;
        const results = await mapPool(jobs, concurrency, async function (job) {
            const res = await extractChunkRetry(job, start, end);
            done++;
            const pct = Math.round((done / jobs.length) * 90);
            onProgress(pct);
            onStatus('ดึง ' + job.label + ' ' + job.start.slice(0, 7) + ' (' + done + '/' + jobs.length + ') · ' +
                numberFmt(res.row_count) + ' แถว');
            return res;
        });
        onStatus('รวมไฟล์รายเดือนทั้งช่วง ' + start + ' ถึง ' + end + '...');
        onProgress(92);
        const mergeQs = 'action=merge_chunks'
            + '&start_date=' + encodeURIComponent(start)
            + '&end_date=' + encodeURIComponent(end)
            + ((download || opts.write_xlsx) ? '&write_xlsx=1' : '')
            + (dsParam ? '&dataset=' + encodeURIComponent(dsParam) : '');
        const merged = await apiGet(mergeQs);
        if (merged.status !== 'success') {
            throw new Error(merged.message || 'รวมไฟล์ไม่สำเร็จ');
        }
        if (download) {
            datasets.forEach(function (ds) {
                triggerDownload(ds.dataset, ds.filename);
            });
        }
        onProgress(100);
        return {
            jobs: results,
            merged: merged,
            staged: merged.staged || null
        };
    }

    function numberFmt(n) {
        n = Number(n || 0);
        return n.toLocaleString('en-US');
    }

    async function exportOne(opts) {
        const ds = SETS.find(function (s) { return s.dataset === opts.dataset; });
        if (!ds) {
            throw new Error('ไม่รู้จักชุดข้อมูล');
        }
        const pack = await exportDatasets({
            start: opts.start,
            end: opts.end,
            datasets: [ds],
            download: opts.download !== false,
            concurrency: opts.concurrency,
            onStatus: opts.onStatus,
            onProgress: opts.onProgress
        });
        const one = (pack.merged && pack.merged.merged && pack.merged.merged[ds.dataset]) || {};
        if (opts.onStatus) {
            opts.onStatus((pack.merged && pack.merged.message) || ('ได้ ' + ds.filename));
        }
        return {
            filename: one.filename || ds.filename,
            row_count: one.row_count || 0,
            staged: pack.staged
        };
    }

    async function exportAll(opts) {
        const pack = await exportDatasets({
            start: opts.start,
            end: opts.end,
            datasets: SETS,
            download: opts.download !== false,
            concurrency: opts.concurrency,
            onStatus: opts.onStatus,
            onProgress: opts.onProgress
        });
        if (opts.onStatus) {
            opts.onStatus('ดึงครบแล้ว — กำลังวิเคราะห์ตาม AMASS/WHO GLASS ทั้งช่วง...');
        }
        if (opts.onProgress) {
            opts.onProgress(96);
        }
        const analyzed = await apiGet(
            'action=analyze'
            + '&start_date=' + encodeURIComponent(opts.start)
            + '&end_date=' + encodeURIComponent(opts.end)
        );
        if (analyzed.status !== 'success') {
            throw new Error(analyzed.message || 'วิเคราะห์ไม่สำเร็จ');
        }
        if (opts.onStatus) {
            opts.onStatus(analyzed.message || 'สร้าง Dashboard แล้ว');
        }
        if (opts.onProgress) {
            opts.onProgress(100);
        }
        return {
            files: pack.jobs,
            staged: pack.staged,
            analysis: analyzed,
            merged: pack.merged
        };
    }

    global.AmassExport = {
        exportOne: exportOne,
        exportAll: exportAll,
        monthSpans: monthSpans,
        analyze: function (opts) {
            opts = opts || {};
            let qs = 'action=analyze';
            if (opts.start && opts.end) {
                qs += '&start_date=' + encodeURIComponent(opts.start)
                    + '&end_date=' + encodeURIComponent(opts.end);
            }
            return fetch(API + '?' + qs, { credentials: 'same-origin' }).then(parseJson);
        },
        fetchStaged: function () {
            return fetch(API + '?action=staged', { credentials: 'same-origin' }).then(parseJson);
        },
        periods: function () {
            return fetch(API + '?action=periods', { credentials: 'same-origin' }).then(parseJson);
        },
        compare: function (a, b) {
            return fetch(
                API + '?action=compare&a=' + encodeURIComponent(a) + '&b=' + encodeURIComponent(b),
                { credentials: 'same-origin' }
            ).then(parseJson);
        },
        compareMulti: function (keys) {
            return fetch(
                API + '?action=compare&keys=' + encodeURIComponent((keys || []).join(',')),
                { credentials: 'same-origin' }
            ).then(parseJson);
        },
        exportPeriods: async function (opts) {
            const periods = opts.periods || [];
            const onStatus = opts.onStatus || function () {};
            const onProgress = opts.onProgress || function () {};
            if (periods.length < 1) {
                throw new Error('ไม่พบช่วงเวลาที่จะดึง');
            }
            const out = [];
            for (let i = 0; i < periods.length; i++) {
                const p = periods[i];
                const prefix = periods.length > 1
                    ? ('ช่วง ' + (i + 1) + '/' + periods.length + ' · ' + (p.label || p.start) + ' — ')
                    : '';
                const res = await exportAll({
                    start: p.start,
                    end: p.end,
                    download: false,
                    concurrency: opts.concurrency,
                    onStatus: function (msg) { onStatus(prefix + msg); },
                    onProgress: function (pct) {
                        const overall = ((i + (Number(pct) || 0) / 100) / periods.length) * 100;
                        onProgress(overall);
                    }
                });
                const key = (res.analysis && res.analysis.period && res.analysis.period.key)
                    || (p.start + '_' + p.end);
                out.push({
                    key: key,
                    start: p.start,
                    end: p.end,
                    label: p.label,
                    analysis: res.analysis,
                    staged: res.staged
                });
            }
            onProgress(100);
            if (periods.length < 2) {
                return { periods: out, comparison: null, staged: out[0] ? out[0].staged : null };
            }
            onStatus('กำลังเปรียบเทียบ ' + periods.length + ' ช่วง...');
            const comparison = await fetch(
                API + '?action=compare&keys=' + encodeURIComponent(out.map(function (x) { return x.key; }).join(',')),
                { credentials: 'same-origin' }
            ).then(parseJson);
            if (comparison.status !== 'success') {
                throw new Error(comparison.message || 'เปรียบเทียบไม่สำเร็จ');
            }
            return { periods: out, comparison: comparison, staged: out[out.length - 1].staged };
        },
        downloadUrl: function (dataset, start, end) {
            let href = API + '?action=download&dataset=' + encodeURIComponent(dataset);
            if (start) {
                href += '&start_date=' + encodeURIComponent(start);
            }
            if (end) {
                href += '&end_date=' + encodeURIComponent(end);
            }
            return href;
        },
        zipUrl: function (start, end) {
            let href = API + '?action=download_zip';
            if (start) {
                href += '&start_date=' + encodeURIComponent(start);
            }
            if (end) {
                href += '&end_date=' + encodeURIComponent(end);
            }
            return href;
        },
        triggerHref: function (href) {
            const a = document.createElement('a');
            a.href = href;
            a.rel = 'noopener';
            document.body.appendChild(a);
            a.click();
            a.remove();
        },
        downloadBlob: async function (href, filename) {
            const res = await fetch(href, { credentials: 'same-origin' });
            const ct = (res.headers.get('content-type') || '').toLowerCase();
            if (ct.indexOf('application/json') !== -1) {
                const j = await parseJson(res);
                throw new Error(j.message || 'ดาวน์โหลดไม่สำเร็จ');
            }
            if (!res.ok) {
                throw new Error('ดาวน์โหลดไม่สำเร็จ (' + res.status + ')');
            }
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename || 'download';
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
        },
        stagedMatchesRange: function (staged, start, end, datasets) {
            const keys = datasets || ['drug', 'admission', 'microbiology'];
            return keys.every(function (key) {
                const s = staged && staged[key];
                if (!s || !s.exists) {
                    return false;
                }
                if (!s.start_date || !s.end_date) {
                    return true;
                }
                return s.start_date === start && s.end_date === end;
            });
        },
        exportFiles: async function (opts) {
            const start = opts.start;
            const end = opts.end;
            const datasets = opts.datasets || SETS;
            const zip = opts.zip !== false && datasets.length > 1;
            const onStatus = opts.onStatus || function () {};
            let staged = opts.staged || null;
            if (!staged) {
                const st = await fetch(API + '?action=staged', { credentials: 'same-origin' }).then(parseJson);
                staged = st.staged || null;
            }
            const keys = datasets.map(function (d) { return d.dataset; });
            const ready = AmassExport.stagedMatchesRange(staged, start, end, keys);
            if (!ready) {
                onStatus('ดึงไฟล์ตามช่วง ' + start + ' ถึง ' + end + ' เพื่อส่งออก...');
                const pack = await exportDatasets({
                    start: start,
                    end: end,
                    datasets: datasets,
                    download: false,
                    write_xlsx: true,
                    concurrency: opts.concurrency,
                    onStatus: onStatus,
                    onProgress: opts.onProgress
                });
                staged = pack.staged || staged;
            } else {
                onStatus('ใช้ไฟล์ที่ดึงไว้แล้วตามช่วง ' + start + ' ถึง ' + end);
                if (opts.onProgress) {
                    opts.onProgress(90);
                }
            }
            onStatus('กำลังแปลงเป็น Excel และดาวน์โหลด...');
            if (opts.onProgress) {
                opts.onProgress(100);
            }
            const stamp = String(start).replace(/\D/g, '') + '_' + String(end).replace(/\D/g, '');
            if (zip) {
                await AmassExport.downloadBlob(
                    AmassExport.zipUrl(start, end),
                    'AMASS_HOSxP_' + stamp + '.zip'
                );
            } else {
                for (let i = 0; i < datasets.length; i++) {
                    const ds = datasets[i];
                    const base = String(ds.filename || ds.dataset).replace(/\.xlsx$/i, '');
                    await AmassExport.downloadBlob(
                        AmassExport.downloadUrl(ds.dataset, start, end),
                        base + '_' + stamp + '.xlsx'
                    );
                }
            }
            return { staged: staged };
        }
    };
})(window);
