(function () {
    'use strict';

    var root = document.getElementById('hiwRoot');
    if (!root) return;

    var REFRESH_MS = 90000;
    var MAX_BEDS_SHOW = 6;
    var MAX_BUSY_WARDS = 6; /* จำกัดอนิเมชันลุกเดิน กันหน่วง */
    var MAX_ADMIT_FX = 4;   /* รถพยาบาลสูงสุด */
    var MAX_DC_FX = 4;      /* ผู้ป่วย D/C วิ่งออกสูงสุด */
    var apiUrl = root.getAttribute('data-api') || 'fetch_home_ipd_ward_api.php';
    var tip = null;
    var timer = null;
    var busy = false;
    /** snapshot ครั้งก่อน: { wardname: { admit, discharge } } — ใช้จับรายการใหม่ตอน refresh */
    var prevWardSnap = null;
    var lastStage = null;
    var lastBoard = null;
    var pathResizeTimer = null;
    var TIMING_FILTER_KEY = 'hiw_timing_filter_v3';
    var TIMING_HISTORY_KEY = 'hiw_timing_history_v1';
    var SHIFT_OPTIONS = [
        { id: 'all', label: 'ทั้งวัน' },
        { id: '0-8', label: '00.00-08.00' },
        { id: '8-16', label: '08.00-16.00' },
        { id: '16-24', label: '16.00-24.00' }
    ];
    var timingFilter = loadTimingFilter();
    var timingMode = 'today'; // today | history
    var timingHistoryState = loadTimingHistoryState();
    var timingHistoryCache = null;
    var timingHistoryBusy = false;

    function loadTimingHistoryState() {
        var today = ymdLocal(new Date());
        var def = { from: addDaysYmd(today, -6), to: today };
        try {
            var raw = localStorage.getItem(TIMING_HISTORY_KEY);
            if (!raw) return def;
            var o = JSON.parse(raw);
            if (!o || typeof o !== 'object') return def;
            var from = String(o.from || '');
            var to = String(o.to || '');
            if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) return def;
            if (from > to) { var tmp = from; from = to; to = tmp; }
            return { from: from, to: to };
        } catch (e) {
            return def;
        }
    }

    function saveTimingHistoryState() {
        try { localStorage.setItem(TIMING_HISTORY_KEY, JSON.stringify(timingHistoryState)); } catch (e) {}
    }

    function normalizeShiftId(id) {
        id = String(id || '');
        if (id === '0-8' || id === '8-16' || id === '16-24' || id === 'all') return id;
        return 'all';
    }

    /** เวรปัจจุบันจากเวลาเครื่อง (00-08 / 08-16 / 16-24) */
    function currentShiftId(now) {
        var h = (now instanceof Date ? now : new Date()).getHours();
        if (h < 8) return '0-8';
        if (h < 16) return '8-16';
        return '16-24';
    }

    function shiftLabel(id) {
        id = normalizeShiftId(id);
        for (var i = 0; i < SHIFT_OPTIONS.length; i++) {
            if (SHIFT_OPTIONS[i].id === id) return SHIFT_OPTIONS[i].label;
        }
        return 'ทั้งวัน';
    }

    function effectiveTimingShift() {
        if (timingFilter.autoShift) return currentShiftId();
        return normalizeShiftId(timingFilter.shift);
    }

    function rowInScanShift(r, shiftId) {
        shiftId = normalizeShiftId(shiftId);
        if (shiftId === 'all') return true;
        var h = +r.sh;
        if (!isFinite(h) || h < 0 || h > 23) return false;
        if (shiftId === '0-8') return h < 8;
        if (shiftId === '8-16') return h >= 8 && h < 16;
        if (shiftId === '16-24') return h >= 16;
        return true;
    }

    function loadTimingFilter() {
        var def = {
            types: { 1: true, 2: true, 3: true },
            ward: '',
            excludeConsult: true,
            shift: 'all',
            autoShift: false
        };
        try {
            var raw = localStorage.getItem(TIMING_FILTER_KEY);
            if (!raw) {
                // migrate จาก v2 ถ้ามี
                var legacy = localStorage.getItem('hiw_timing_filter_v2');
                if (legacy) raw = legacy;
            }
            if (!raw) return def;
            var o = JSON.parse(raw);
            if (!o || typeof o !== 'object') return def;
            return {
                types: {
                    1: o.types && o.types[1] === false ? false : true,
                    2: o.types && o.types[2] === false ? false : true,
                    3: o.types && o.types[3] === false ? false : true
                },
                ward: o.ward != null ? String(o.ward) : '',
                excludeConsult: o.excludeConsult === false ? false : true,
                shift: normalizeShiftId(o.shift),
                autoShift: !!o.autoShift
            };
        } catch (e) {
            return def;
        }
    }

    function saveTimingFilter() {
        try { localStorage.setItem(TIMING_FILTER_KEY, JSON.stringify(timingFilter)); } catch (e) {}
    }

    function statsFromMins(arr) {
        if (!arr || !arr.length) return { n: 0, avg: null, min: null, max: null };
        var n = arr.length;
        var sum = 0;
        var mn = arr[0];
        var mx = arr[0];
        for (var i = 0; i < n; i++) {
            var v = +arr[i];
            sum += v;
            if (v < mn) mn = v;
            if (v > mx) mx = v;
        }
        return {
            n: n,
            avg: Math.round((sum / n) * 10) / 10,
            min: Math.round(mn * 10) / 10,
            max: Math.round(mx * 10) / 10
        };
    }

    function ymdLocal(d) {
        var x = d instanceof Date ? d : new Date(d);
        var y = x.getFullYear();
        var m = String(x.getMonth() + 1).padStart(2, '0');
        var day = String(x.getDate()).padStart(2, '0');
        return y + '-' + m + '-' + day;
    }

    function addDaysYmd(ymd, delta) {
        var p = String(ymd || '').split('-');
        if (p.length !== 3) return '';
        var dt = new Date(+p[0], +p[1] - 1, +p[2]);
        dt.setDate(dt.getDate() + delta);
        return ymdLocal(dt);
    }

    /** เทียบค่าเฉลี่ยวันนี้กับ baseline — ลบ = เร็วกว่า (ดี) */
    function timingDelta(todayAvg, baseAvg) {
        if (todayAvg == null || baseAvg == null || !isFinite(todayAvg) || !isFinite(baseAvg)) {
            return null;
        }
        return Math.round((todayAvg - baseAvg) * 10) / 10;
    }

    function avgOfDailyAvgs(byDay, dayList, field) {
        var avgs = [];
        for (var i = 0; i < dayList.length; i++) {
            var st = statsFromMins((byDay[dayList[i]] && byDay[dayList[i]][field]) || []);
            if (st.n > 0 && st.avg != null) avgs.push(st.avg);
        }
        if (!avgs.length) return null;
        var sum = 0;
        for (var j = 0; j < avgs.length; j++) sum += avgs[j];
        return Math.round((sum / avgs.length) * 10) / 10;
    }

    function buildStatsWithCompare(todayMins, byDay, yesterday, days7, field) {
        var st = statsFromMins(todayMins);
        var yMins = (byDay[yesterday] && byDay[yesterday][field]) || [];
        var ySt = statsFromMins(yMins);
        var avg7 = avgOfDailyAvgs(byDay, days7, field);
        return {
            n: st.n,
            avg: st.avg,
            min: st.min,
            max: st.max,
            vs_yesterday: timingDelta(st.avg, ySt.avg),
            vs_yesterday_n: ySt.n,
            vs_avg7: timingDelta(st.avg, avg7),
            vs_avg7_days: days7.filter(function (d) {
                return byDay[d] && byDay[d][field] && byDay[d][field].length;
            }).length,
            yesterday_avg: ySt.avg,
            avg7: avg7
        };
    }

    function aggregateTimingRows(rows, typeId, wardId, excludeConsult, shiftId, statsDate) {
        var today = statsDate || ymdLocal(new Date());
        var yesterday = addDaysYmd(today, -1);
        var days7 = [];
        for (var i = 1; i <= 7; i++) days7.push(addDaysYmd(today, -i));

        var k = [];
        var c = [];
        var t = [];
        var byDay = {};
        var skippedConsult = 0;

        (rows || []).forEach(function (r) {
            if (+r.t !== +typeId) return;
            if (wardId && String(r.w) !== String(wardId)) return;
            if (!rowInScanShift(r, shiftId)) return;
            if (excludeConsult && +r.xc === 1) {
                if (!r.dd || r.dd === today) skippedConsult++;
                return;
            }
            var day = String(r.dd || '');
            if (!day) return;
            if (!byDay[day]) byDay[day] = { k: [], c: [], t: [] };
            byDay[day].k.push(+r.k);
            byDay[day].c.push(+r.c);
            byDay[day].t.push(+r.tot);
            if (day === today) {
            k.push(+r.k);
            c.push(+r.c);
            t.push(+r.tot);
            }
        });

        return {
            key_minutes: buildStatsWithCompare(k, byDay, yesterday, days7, 'k'),
            check_minutes: buildStatsWithCompare(c, byDay, yesterday, days7, 'c'),
            total_minutes: buildStatsWithCompare(t, byDay, yesterday, days7, 't'),
            n: k.length,
            skippedConsult: skippedConsult
        };
    }

    function renderTimingCompare(st) {
        if (!st || !st.n) {
            return '<div class="hiw-timing-cmp is-empty">ยังไม่มีข้อมูลเทียบ</div>';
        }
        function chip(delta, label, baseAvg, baseN) {
            if (delta == null) {
                return '<div class="hiw-cmp-chip is-na" title="ยังไม่มีข้อมูล ' + esc(label) + '">' +
                    '<span class="hiw-cmp-k">' + esc(label) + '</span>' +
                    '<span class="hiw-cmp-v">—</span></div>';
            }
            var abs = Math.abs(delta);
            var same = abs < 0.05;
            var faster = delta < 0;
            var cls = same ? 'is-same' : (faster ? 'is-fast' : 'is-slow');
            var arrow = same ? 'fa-equals' : (faster ? 'fa-arrow-down' : 'fa-arrow-up');
            var word = same ? 'เท่าเดิม' : (faster ? 'เร็วกว่า' : 'ช้ากว่า');
            var tip = word + ' ' + label +
                (baseAvg != null ? (' (ฐาน ' + baseAvg + ' น.' + (baseN ? ' · n=' + baseN : '') + ')') : '');
            return '<div class="hiw-cmp-chip ' + cls + '" title="' + esc(tip) + '">' +
                '<span class="hiw-cmp-k">' + esc(label) + '</span>' +
                '<span class="hiw-cmp-v"><i class="fas ' + arrow + '"></i> ' +
                (same ? 'เท่าเดิม' : (word + ' ' + esc(abs) + ' น.')) +
                '</span></div>';
        }
        return '<div class="hiw-timing-cmp">' +
            chip(st.vs_yesterday, 'เมื่อวาน', st.yesterday_avg, st.vs_yesterday_n) +
            chip(st.vs_avg7, 'เฉลี่ย 7 วัน', st.avg7, st.vs_avg7_days) +
            '</div>';
    }

    function el(tag, cls, html) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (html != null) n.innerHTML = html;
        return n;
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function levelOf(w) {
        var blank = +w.blank || 0;
        var maxbed = +w.maxbed || 0;
        var occ = maxbed > 0 ? ((+w.stay || 0) / maxbed) : 0;
        if (blank < 0) return 'over';
        if (blank === 0 || occ >= 0.95) return 'full';
        if (blank <= 3 || occ >= 0.85) return 'mid';
        return 'ok';
    }

    var HIW_SPRITE = {
        doc: 'assets/doctor.svg',
        nurse: 'assets/nurse.svg',
        nurse_imp: 'assets/nurse_impatient.svg',
        pharm: 'assets/pharmacist.svg',
        patient: 'assets/dc_patient.svg',
        healthy: 'assets/dc_patient.svg',
        angry: 'assets/patient_angry.svg',
        amb: 'assets/ambulance.svg',
        room: 'assets/room_bg.svg',
        bedEmpty: 'assets/bed_green.svg',
        bedUsed: 'assets/bed_red.svg',
        tree: 'assets/tree.svg'
    };

    /* พิกัดเตียง isometric ใน room_bg (top%, left%) */
    var BED_SLOTS = [
        { top: 28, left: 36 },
        { top: 36, left: 48 },
        { top: 44, left: 60 },
        { top: 40, left: 20 },
        { top: 48, left: 32 },
        { top: 56, left: 44 }
    ];

    /* role ที่ต้องเล่น CSS animation ใน SVG — ใช้ <object> เพราะ <img> ไม่เล่น keyframes ภายใน */
    var ANIM_ROLES = { doc: 1, nurse: 1, nurse_imp: 1, pharm: 1, patient: 1, healthy: 1, amb: 1, angry: 1 };

    function spriteHtml(role, cls, opts) {
        opts = opts || {};
        var src = HIW_SPRITE[role] || HIW_SPRITE.patient;
        var label = role === 'doc' ? 'แพทย์'
            : role === 'nurse' ? 'พยาบาล'
            : role === 'nurse_imp' ? 'พยาบาลตามยาด่วน'
            : role === 'pharm' ? 'เภสัช'
            : role === 'amb' ? 'รถพยาบาล'
            : role === 'angry' ? 'คนไข้โวยวาย เตียงล้นวิกฤต'
            : role === 'tree' ? 'ต้นไม้'
            : 'ผู้ป่วย';
        var extra = cls ? (' ' + cls) : '';
        /* ไอคอนเล็กในแคปซูล/legend นิ่งใช้ img ได้ */
        if (opts.static || !ANIM_ROLES[role]) {
            return '<img class="hiw-sprite' + extra +
                '" src="' + src + '" alt="' + label + '" draggable="false">';
        }
        /* cache-bust เมื่อไฟล์ SVG เปลี่ยน */
        var ver = 'v=imp1';
        return '<object class="hiw-sprite hiw-sprite-obj' + extra +
            '" type="image/svg+xml" data="' + src + '?' + ver +
            '" aria-label="' + label + '" tabindex="-1"></object>';
    }

    function charHtml(role) {
        return spriteHtml(role, 'is-' + role);
    }

    function patrolDelayStyle() {
        var delay = (Math.random() * 2.4).toFixed(2);
        var dur = (2.4 + Math.random() * 1.6).toFixed(2);
        return 'animation-delay:' + delay + 's;animation-duration:' + dur + 's';
    }

    function bedsHtml(w) {
        var maxbed = Math.max(0, +w.maxbed || 0);
        var stay = Math.max(0, +w.stay || 0);
        if (maxbed <= 0) return '<div class="hiw-beds" aria-hidden="true"></div>';

        var show = Math.min(BED_SLOTS.length, Math.max(3, Math.min(maxbed, MAX_BEDS_SHOW)));
        var used = Math.round((stay / maxbed) * show);
        if (stay > 0 && used < 1) used = 1;
        if (stay >= maxbed) used = show;

        var html = '<div class="hiw-beds">';
        for (var i = 0; i < show; i++) {
            var slot = BED_SLOTS[i];
            var occupied = i < used;
            var src = occupied ? HIW_SPRITE.bedUsed : HIW_SPRITE.bedEmpty;
            html += '<img class="hiw-bed-img' + (occupied ? ' is-used' : ' is-empty') +
                '" src="' + src + '" alt="' + (occupied ? 'ครองเตียง' : 'เตียงว่าง') +
                '" title="' + (occupied ? 'ครองเตียง' : 'เตียงว่าง') +
                '" style="top:' + slot.top + '%;left:' + slot.left + '%;" draggable="false">';
        }
        html += '</div>';
        return html;
    }

    function hasUrgentWait(w) {
        return (+w.urgent_over30 || 0) > 0;
    }

    /** เภสัชกรเด่น: มี D/C (ยากลับบ้าน) หรือเตียงล้น/ครองเต็ม (เฝ้าระวังยา) */
    function needsPharmacist(w) {
        var dc = +w.discharge || 0;
        var blank = +w.blank || 0;
        var occ = +w.occ_pct || 0;
        return dc > 0 || blank < 0 || occ >= 100;
    }

    function staffRole(w) {
        /* ยาด่วนค้าง >30น. → พยาบาลไม่อดทน (สำคัญสุดสำหรับ Visual Alert) */
        if (hasUrgentWait(w)) return 'nurse_imp';
        if (needsPharmacist(w)) return 'pharm';
        if (w.critical) return 'doc';
        if ((+w.admit || 0) > 0) return 'doc';
        if ((+w.blank || 0) <= 0) return 'doc';
        return 'nurse';
    }

    function occBarHtml(w) {
        var pct = Math.max(0, +w.occ_pct || 0);
        var fill = Math.min(100, pct);
        var tone = pct >= 100 ? 'is-red' : (pct >= 80 ? 'is-orange' : 'is-green');
        return '<div class="hiw-occ-bar" title="ครองเตียง ' + esc(pct) + '%">' +
            '<span class="hiw-occ-fill ' + tone + '" style="width:' + fill + '%"></span>' +
            '</div>';
    }

    var wardFilterMode = 'all';

    function applyWardFilter(board, mode) {
        if (!board) return;
        wardFilterMode = mode || 'all';
        var cards = board.querySelectorAll('.hiw-ward');
        for (var i = 0; i < cards.length; i++) {
            var card = cards[i];
            var blank = +card.getAttribute('data-blank') || 0;
            var admit = +card.getAttribute('data-admit') || 0;
            var dc = +card.getAttribute('data-dc') || 0;
            var urg = +card.getAttribute('data-urgent30') || 0;
            var show = true;
            if (wardFilterMode === 'vacant') show = blank > 0;
            else if (wardFilterMode === 'full') show = blank <= 0;
            else if (wardFilterMode === 'flow') show = admit > 0 || dc > 0;
            else if (wardFilterMode === 'urgent30') show = urg > 0;
            card.classList.toggle('is-dimmed', !show);
        }
    }

    function bindWardFilters(bar, board) {
        if (!bar || !board) return;
        var pills = bar.querySelectorAll('[data-filter]');
        for (var i = 0; i < pills.length; i++) {
            pills[i].classList.toggle('is-active', pills[i].getAttribute('data-filter') === wardFilterMode);
            pills[i].addEventListener('click', function () {
                var mode = this.getAttribute('data-filter') || 'all';
                var all = bar.querySelectorAll('[data-filter]');
                for (var j = 0; j < all.length; j++) {
                    all[j].classList.toggle('is-active', all[j] === this);
                }
                applyWardFilter(board, mode);
            });
        }
        applyWardFilter(board, wardFilterMode);
    }

    function fmtTime(ts) {
        if (!ts) return '-';
        var d = new Date((+ts) * 1000);
        if (isNaN(d.getTime())) return '-';
        var p = function (n) { return (n < 10 ? '0' : '') + n; };
        return p(d.getHours()) + ':' + p(d.getMinutes());
    }

    function setPaused(paused) {
        root.classList.toggle('is-paused', !!paused);
    }

    function ensureTip() {
        if (tip) return tip;
        tip = el('div', 'hiw-tip');
        root.appendChild(tip);
        return tip;
    }

    function showTip(wardEl, w, evt) {
        var t = ensureTip();
        var blankTip = +w.blank || 0;
        var urg = +w.urgent_over30 || 0;
        var urgKey = +w.urgent_over30_key || 0;
        var urgPay = +w.urgent_over30_pay || 0;
        var crisisLine = blankTip <= -5
            ? '<br><span style="color:#fca5a5;font-weight:800">⚠️ วิกฤตเตียงล้นเกิน 5 เตียง!</span>'
            : '';
        var urgLine = urg > 0
            ? '<br><span style="color:#fdba74;font-weight:800">💊 ยาด่วนรอนาน >30 นาที · ' + esc(urg) + ' ราย' +
              ' (รอ Key ' + esc(urgKey) + ' · รอจ่าย ' + esc(urgPay) + ')</span>' +
              '<br><span style="color:#bbf7d0;font-size:0.9em">คลิกตึกเพื่อเปิดรายการยาด่วนของหอนี้</span>'
            : '';
        t.innerHTML =
            '<b>' + esc(w.wardname) + '</b><br>' +
            esc(w.ward_name) + '<br>' +
            'เตียงทั้งหมด ' + esc(w.maxbed) +
            ' · คงรักษา ' + esc(w.stay) +
            ' · ว่าง ' + esc(w.blank) + '<br>' +
            'Admit วันนี้ ' + esc(w.admit) +
            ' · D/C ' + esc(w.discharge) +
            ' · ครองเตียง ' + esc(w.occ_pct) + '%' +
            crisisLine + urgLine;
        t.style.display = 'block';
        var rect = root.getBoundingClientRect();
        var x = (evt.clientX - rect.left) + 12;
        var y = (evt.clientY - rect.top) + 12;
        if (x + 200 > rect.width) x = rect.width - 210;
        if (y + 90 > rect.height) y = rect.height - 100;
        t.style.left = x + 'px';
        t.style.top = y + 'px';
    }

    function hideTip() {
        if (tip) tip.style.display = 'none';
    }

    function pickBusyIndexes(wards) {
        var scored = [];
        for (var i = 0; i < wards.length; i++) {
            var w = wards[i];
            var stay = +w.stay || 0;
            if (stay <= 0) continue;
            scored.push({
                i: i,
                score: (+w.admit || 0) * 10 + stay + (w.critical ? 5 : 0)
            });
        }
        scored.sort(function (a, b) { return b.score - a.score; });
        var map = {};
        for (var j = 0; j < scored.length && j < MAX_BUSY_WARDS; j++) {
            map[scored[j].i] = true;
        }
        return map;
    }

    function applyPayload(j) {
        if (!j || j.status !== 'success' || !j.data) {
            renderError((j && j.msg) || 'โหลดภาพรวมไม่สำเร็จ');
            return false;
        }
        var hasWards = j.data.wards && j.data.wards.length;
        var hasOrders = j.data.orders && j.data.orders.ok;
        if (!j.data.ok && !hasWards && !hasOrders) {
            renderError(j.data.error || j.msg || 'โหลดภาพรวมไม่สำเร็จ');
            return false;
        }
        render(j.data);
        return true;
    }

    function readBoot() {
        var node = document.getElementById('hiwBoot');
        if (!node) return null;
        try {
            return JSON.parse(node.textContent || 'null');
        } catch (e) {
            return null;
        }
    }

    function timingCard(opts) {
        var st = opts.stats || {};
        var n = +st.n || 0;
        return '<article class="hiw-timing-card ' + esc(opts.tone || '') + '">' +
            '<div class="hiw-timing-icon"><i class="fas ' + esc(opts.icon) + '"></i></div>' +
            '<div class="hiw-timing-body">' +
            '<div class="hiw-timing-label">' + esc(opts.label) + '</div>' +
            '<div class="hiw-timing-flow">' + esc(opts.flow) + '</div>' +
            '<div class="hiw-timing-avg">' +
            '<span class="hiw-timing-avg-num">' + (n ? esc(st.avg) : '—') + '</span>' +
            '<span class="hiw-timing-avg-unit">นาที</span>' +
            '<span class="hiw-timing-avg-caption">เฉลี่ย</span>' +
            '</div>' +
            renderTimingCompare(st) +
            '<div class="hiw-timing-minmax">' +
            '<div><em>Min</em><b>' + (n ? esc(st.min) : '—') + '</b></div>' +
            '<div><em>Max</em><b>' + (n ? esc(st.max) : '—') + '</b></div>' +
            '<div><em>n</em><b>' + esc(n) + '</b></div>' +
            '</div>' +
            '</div>' +
            '</article>';
    }

    function openDrugViewerFromQueue(it) {
        if (!it || !it.id) return;
        var qs = new URLSearchParams();
        if (it.hn) qs.set('hn', it.hn);
        if (it.an) qs.set('an', it.an);
        qs.set('id', String(it.id));
        var url = 'drug_viewer_win.php?' + qs.toString();
        try {
            var w = window.open(url, 'pip_drug_viewer_home');
            if (w) try { w.focus(); } catch (e) {}
            else window.location.href = url;
        } catch (e2) {
            window.open(url, '_blank');
        }
    }

    function ensureQueueModal() {
        var m = document.getElementById('hiwQueueModal');
        if (m) return m;
        m = el('div', 'hiw-modal');
        m.id = 'hiwQueueModal';
        m.innerHTML =
            '<div class="hiw-modal-backdrop" data-hiw-close="1"></div>' +
            '<div class="hiw-modal-panel" role="dialog" aria-modal="true">' +
            '<div class="hiw-modal-head">' +
            '<div>' +
            '<h3 class="hiw-modal-title" id="hiwQueueTitle">รายการคิว</h3>' +
            '<div class="hiw-modal-sub" id="hiwQueueSub"></div>' +
            '</div>' +
            '<button type="button" class="hiw-modal-x" data-hiw-close="1" aria-label="ปิด">&times;</button>' +
            '</div>' +
            '<div class="hiw-modal-body" id="hiwQueueBody"><div class="hiw-modal-loading">กำลังโหลด…</div></div>' +
            '</div>';
        document.body.appendChild(m);
        m.addEventListener('click', function (e) {
            if (e.target && e.target.getAttribute('data-hiw-close') === '1') {
                m.classList.remove('is-open');
            }
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') m.classList.remove('is-open');
        });
        return m;
    }

    function wardNameMatch(itemWard, itemWardName, targetShort, targetFull) {
        var a = String(itemWardName || itemWard || '').toUpperCase().replace(/\s+/g, ' ').trim();
        var b = String(targetShort || '').toUpperCase().replace(/\s+/g, ' ').trim();
        var c = String(targetFull || '').toUpperCase().replace(/\s+/g, ' ').trim();
        if (!a) return false;
        if (b && (a === b || a.indexOf(b) >= 0 || b.indexOf(a) >= 0)) return true;
        if (c && (a === c || a.indexOf(c) >= 0 || c.indexOf(a) >= 0)) return true;
        return false;
    }

    function filterQueueItems(items, opts) {
        opts = opts || {};
        return (items || []).filter(function (it) {
            if (opts.urgentOver30) {
                if (Number(it.scr_type) !== 1) return false;
                if (!(Number(it.wait_minutes) > 30)) return false;
            }
            if (opts.wardName || opts.wardFull) {
                if (!wardNameMatch(it.ward, it.ward_name, opts.wardName, opts.wardFull)) return false;
            }
            return true;
        });
    }

    function renderQueueRows(kind, items) {
        if (!items || !items.length) {
            return '<div class="hiw-modal-empty">ไม่มีรายการ</div>';
        }
        var head =
            '<table class="hiw-queue-table"><thead><tr>' +
            '<th>#</th><th>ประเภท</th><th>AN</th><th>HN</th><th>ผู้ป่วย</th><th>Ward</th>' +
            (kind === 'waiting_pay'
                ? '<th>Scan</th><th>Key</th><th>IRx/HME</th><th>รอ (นาที)</th>'
                : '<th>Scan</th><th>รอ (นาที)</th>') +
            '<th></th></tr></thead><tbody>';
        var rows = items.map(function (it, idx) {
            var over = Number(it.scr_type) === 1 && Number(it.wait_minutes) > 30;
            var mapCell = '';
            if (kind === 'waiting_pay') {
                var mapType = it.mapped_order_type || '';
                var mapNo = it.mapped_order_no || '';
                var mapDrugs = Number(it.mapped_drug_count) || 0;
                mapCell = mapNo
                    ? ('<td class="mono">' + esc(mapType) + ' ' + esc(mapNo) +
                        (mapDrugs > 0 ? (' <span class="text-muted">(' + esc(mapDrugs) + ')</span>') : '') +
                        '</td>')
                    : '<td class="mono text-muted">—</td>';
            }
            return '<tr' + (over ? ' class="is-over30"' : '') + '>' +
                '<td>' + esc(idx + 1) + '</td>' +
                '<td><span class="hiw-q-type' + (it.scr_type === 1 ? ' is-urgent' : '') + '">' + esc(it.type_name || '-') + '</span></td>' +
                '<td class="mono">' + esc(it.an || '-') + '</td>' +
                '<td class="mono">' + esc(it.hn || '-') + '</td>' +
                '<td>' + esc(it.patient || '-') + '</td>' +
                '<td>' + esc(it.ward_name || it.ward || '-') + '</td>' +
                '<td class="mono">' + esc(it.datescan || '-') + '</td>' +
                (kind === 'waiting_pay' ? ('<td class="mono">' + esc(it.datesave || '-') + '</td>') : '') +
                mapCell +
                '<td class="num' + (over ? ' is-over30' : '') + '">' + (it.wait_minutes != null ? esc(it.wait_minutes) : '—') + '</td>' +
                '<td><button type="button" class="hiw-q-btn" data-scan-id="' + esc(it.id) + '">' +
                '<i class="fas fa-file-medical"></i> ดูใบสแกน</button></td>' +
                '</tr>';
        }).join('');
        return head + rows + '</tbody></table>';
    }

    function openQueueModal(kind, opts) {
        opts = opts || {};
        var m = ensureQueueModal();
        var title = kind === 'waiting_pay' ? 'รายการรอจ่าย' : 'รายการรอ Key';
        var sub = kind === 'waiting_pay'
            ? 'Key แล้วและจับคู่ IRx/HME ที่มีรายการยาได้ แต่ยังไม่บันทึกผู้จ่ายใน Tham HOS-Safe'
            : 'สแกนแล้ว ยังไม่ Key ใน Drug Viewer · วันนี้';
        if (opts.urgentOver30) {
            title = (kind === 'waiting_pay' ? 'ยาด่วนรอจ่าย >30 นาที' : 'ยาด่วนรอ Key >30 นาที');
            if (opts.wardName) title += ' · ' + opts.wardName;
            sub = 'กรองเฉพาะยาเร่งด่วนที่รอนานเกิน 30 นาที' +
                (opts.wardName ? (' · หอ ' + opts.wardName) : '');
        }
        document.getElementById('hiwQueueTitle').textContent = title;
        document.getElementById('hiwQueueSub').textContent = sub;
        var body = document.getElementById('hiwQueueBody');
        body.innerHTML = '<div class="hiw-modal-loading"><i class="fas fa-spinner fa-spin me-2"></i>กำลังโหลดรายชื่อ…</div>';
        m.classList.add('is-open');

        var url = apiUrl + '?action=queue&kind=' + encodeURIComponent(kind) + '&limit=300';
        fetch(url, { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
            .then(function (r) { return r.json(); })
            .then(function (j) {
                if (!j || j.status !== 'success' || !j.data) {
                    body.innerHTML = '<div class="hiw-modal-empty">' + esc((j && j.msg) || 'โหลดไม่สำเร็จ') + '</div>';
                    return;
                }
                var items = filterQueueItems(j.data.items || [], opts);
                document.getElementById('hiwQueueSub').textContent =
                    sub + ' · ' + items.length + ' รายการ';
                body.innerHTML = renderQueueRows(kind, items);
                body.querySelectorAll('.hiw-q-btn').forEach(function (btn) {
                    btn.addEventListener('click', function () {
                        var id = Number(btn.getAttribute('data-scan-id') || 0);
                        var it = items.find(function (x) { return Number(x.id) === id; });
                        if (it) openDrugViewerFromQueue(it);
                    });
                });
            })
            .catch(function () {
                body.innerHTML = '<div class="hiw-modal-empty">เครือข่ายขัดข้อง</div>';
            });
    }

    function openWardUrgentQueue(w) {
        var keyN = +w.urgent_over30_key || 0;
        var payN = +w.urgent_over30_pay || 0;
        if (keyN <= 0 && payN <= 0) return;
        var kind = keyN >= payN ? 'pending_key' : 'waiting_pay';
        openQueueModal(kind, {
            urgentOver30: true,
            wardName: w.wardname || '',
            wardFull: w.ward_name || ''
        });
    }

    function bindOrderClicks(wrap) {
        wrap.querySelectorAll('[data-hiw-queue]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var kind = btn.getAttribute('data-hiw-queue') || '';
                if (kind) openQueueModal(kind);
            });
        });
    }

    function renderOrderPanel(orders) {
        var wrap = el('div', 'hiw-order hiw-order-clean');
        if (!orders || !orders.ok) {
            wrap.innerHTML =
                '<div class="hiw-order-head">' +
                '<h3 class="hiw-order-title">ภาพรวมห้องจ่ายยาผู้ป่วยใน</h3>' +
                '<span class="hiw-order-err">' + esc((orders && orders.error) || 'ยังไม่มีข้อมูล Order') + '</span>' +
                '</div>';
            return wrap;
        }

        var pending = +orders.pending_total || 0;
        var waitingPay = +orders.waiting_pay || 0;
        var keyed = +orders.keyed_today || 0;
        var keyedWithDrugs = +orders.keyed_with_drugs || 0;
        var dispensedFromKeyed = +orders.dispensed_from_keyed;
        if (!isFinite(dispensedFromKeyed)) {
            dispensedFromKeyed = Math.max(0, keyedWithDrugs - waitingPay);
        }
        var dispensedTham = +orders.dispensed_today || 0;
        var matched = +orders.matched_pairs || 0;
        var statsDate = orders.stats_date || '';
        var pendU = +orders.pending_urgent || 0;
        var pendN = +orders.pending_normal || 0;
        var pendH = +orders.pending_home || 0;
        var pendOver = +orders.pending_urgent_over30 || 0;
        var waitU = +orders.waiting_pay_urgent || 0;
        var waitN = +orders.waiting_pay_normal || 0;
        var waitH = +orders.waiting_pay_home || 0;
        var waitOver = +orders.waiting_pay_urgent_over30 || 0;

        function typeMini(urgent, normal, home) {
            return '<div class="hiw-qcard-types">' +
                '<span class="hiw-mini is-urgent">เร่งด่วน <b>' + esc(urgent) + '</b></span>' +
                '<span class="hiw-mini">ปกติ <b>' + esc(normal) + '</b></span>' +
                '<span class="hiw-mini is-home">กลับบ้าน <b>' + esc(home) + '</b></span>' +
                '</div>';
        }

        function overAlert(n, label) {
            if (!n) return '';
            return '<div class="hiw-qcard-alert" title="มีรายการเร่งด่วนรอนานกว่า 30 นาที">' +
                '<i class="fas fa-exclamation-triangle"></i> เร่งด่วน >30 นาที · ' + esc(n) + ' ราย (' + esc(label) + ')' +
                '</div>';
        }

        wrap.innerHTML =
            '<div class="hiw-order-head">' +
            '<div>' +
            '<h3 class="hiw-order-title">ภาพรวมห้องจ่ายยาผู้ป่วยใน</h3>' +
            '<p class="hiw-order-sub">ข้อมูลวันที่ ' + esc(statsDate || 'วันนี้') +
            ' · Scan → Key → จับคู่ IRx/HME → บันทึกผู้จ่าย · คลิกเลขคิวเพื่อดูรายชื่อ</p>' +
            '</div>' +
            '</div>' +
            '<div class="hiw-order-split">' +
            '<section class="hiw-order-zone hiw-order-zone-left">' +
            '<div class="hiw-zone-label">คิวงานวันนี้</div>' +
            '<div class="hiw-queue-grid">' +
            '<button type="button" class="hiw-qcard is-click' +
            (pending > 0 ? ' is-warn' : '') +
            (pendOver > 0 ? ' is-blink' : '') +
            '" data-hiw-queue="pending_key" title="คลิกดูรายชื่อรอ Key">' +
            '<span class="hiw-qcard-k">รอ Key</span><b>' + esc(pending) + '</b>' +
            typeMini(pendU, pendN, pendH) +
            overAlert(pendOver, 'รอ Key') +
            '</button>' +
            '<button type="button" class="hiw-qcard is-click' +
            (waitingPay > 0 ? ' is-warn' : '') +
            (waitOver > 0 ? ' is-blink' : '') +
            '" data-hiw-queue="waiting_pay" title="คลิกดูรายชื่อรอจ่าย">' +
            '<span class="hiw-qcard-k">รอจ่าย</span><b>' + esc(waitingPay) + '</b>' +
            typeMini(waitU, waitN, waitH) +
            overAlert(waitOver, 'รอจ่าย') +
            '</button>' +
            '<div class="hiw-qcard" title="Key ใน Drug Viewer วันนี้ · มียา = จับคู่ IRx/HME ที่มีรายการยาได้ · สมการ: มียา = รอจ่าย + บันทึกจ่าย">' +
            '<span class="hiw-qcard-k">Key แล้ว</span><b>' + esc(keyed) + '</b>' +
            '<div class="hiw-qcard-drugs">มียา <strong>' + esc(keyedWithDrugs) + '</strong> ใบ</div>' +
            '<small>รอจ่าย ' + esc(waitingPay) + ' + จ่ายแล้ว ' + esc(dispensedFromKeyed) +
            ' · ' + esc(statsDate) + '</small></div>' +
            '<div class="hiw-qcard is-ok" title="ใบ Key วันนี้ที่มียา และจับคู่กับบันทึกผู้จ่ายแล้ว · มียา = รอจ่าย + บันทึกจ่าย' +
            (dispensedTham !== dispensedFromKeyed
                ? (' · บันทึกใน Tham วันนี้ทั้งหมด ' + dispensedTham + ' ราย (รวม Key วันอื่น / จับคู่ใบสแกนไม่ได้)')
                : '') +
            '">' +
            '<span class="hiw-qcard-k">บันทึกจ่าย</span><b>' + esc(dispensedFromKeyed) + '</b>' +
            '<small>จาก Key มียาวันนี้' +
            (dispensedTham !== dispensedFromKeyed
                ? (' · Tham รวม ' + esc(dispensedTham))
                : '') +
            '</small></div>' +
            '</div>' +
            '</section>' +
            '<section class="hiw-order-zone hiw-order-zone-right">' +
            '<div class="hiw-zone-head">' +
            '<div class="hiw-zone-label">ระยะเวลา Order · ห้องจ่ายยาผู้ป่วยใน</div>' +
            '<div class="hiw-timing-mode-tabs" role="tablist" aria-label="โหมดระยะเวลา">' +
            '<button type="button" class="hiw-mode-tab' + (timingMode === 'today' ? ' is-on' : '') +
            '" data-timing-mode="today" role="tab">วันนี้</button>' +
            '<button type="button" class="hiw-mode-tab' + (timingMode === 'history' ? ' is-on' : '') +
            '" data-timing-mode="history" role="tab">ดูประวัติเวลา</button>' +
            '</div></div>' +
            '<div class="hiw-timing-pane' + (timingMode === 'today' ? '' : ' is-hidden') + '" id="hiwTimingTodayPane">' +
            '<div class="hiw-timing-toolbar" id="hiwTimingToolbar"></div>' +
            '<div class="hiw-timing-body" id="hiwTimingBody"></div>' +
            '<div class="hiw-order-note" id="hiwTimingNote"></div>' +
            '</div>' +
            '<div class="hiw-timing-pane' + (timingMode === 'history' ? '' : ' is-hidden') + '" id="hiwTimingHistoryPane">' +
            '<div class="hiw-hist-toolbar" id="hiwHistToolbar"></div>' +
            '<div class="hiw-hist-body" id="hiwHistBody"></div>' +
            '<div class="hiw-order-note" id="hiwHistNote"></div>' +
            '</div>' +
            '</section>' +
            '</div>';
        bindOrderClicks(wrap);
        mountTimingPanel(wrap, orders);
        return wrap;
    }

    function fmtYmdTh(ymd) {
        var p = String(ymd || '').split('-');
        if (p.length !== 3) return ymd || '—';
        return p[2] + '/' + p[1] + '/' + p[0];
    }

    function listDaysInclusive(from, to) {
        var out = [];
        if (!from || !to || from > to) return out;
        var cur = from;
        var guard = 0;
        while (cur <= to && guard < 40) {
            out.push(cur);
            cur = addDaysYmd(cur, 1);
            guard++;
        }
        return out;
    }

    function aggregateHistoryByDay(rows, typeIds, wardId, excludeConsult, shiftId, from, to) {
        var typeSet = {};
        (typeIds || []).forEach(function (id) { typeSet[+id] = true; });
        var byDay = {};
        listDaysInclusive(from, to).forEach(function (d) {
            byDay[d] = { k: [], c: [], t: [] };
        });
        var skipped = 0;
        (rows || []).forEach(function (r) {
            if (!typeSet[+r.t]) return;
            if (wardId && String(r.w) !== String(wardId)) return;
            if (!rowInScanShift(r, shiftId)) return;
            if (excludeConsult && +r.xc === 1) {
                skipped++;
                return;
            }
            var day = String(r.dd || '');
            if (!day || day < from || day > to) return;
            if (!byDay[day]) byDay[day] = { k: [], c: [], t: [] };
            byDay[day].k.push(+r.k);
            byDay[day].c.push(+r.c);
            byDay[day].t.push(+r.tot);
        });
        var days = listDaysInclusive(from, to).map(function (d) {
            var k = statsFromMins(byDay[d].k);
            var c = statsFromMins(byDay[d].c);
            var t = statsFromMins(byDay[d].t);
            return { date: d, n: k.n, key: k, check: c, total: t };
        });
        var allK = [];
        var allC = [];
        var allT = [];
        days.forEach(function (d) {
            (byDay[d.date].k || []).forEach(function (v) { allK.push(v); });
            (byDay[d.date].c || []).forEach(function (v) { allC.push(v); });
            (byDay[d.date].t || []).forEach(function (v) { allT.push(v); });
        });
        return {
            days: days,
            skippedConsult: skipped,
            period: {
                key: statsFromMins(allK),
                check: statsFromMins(allC),
                total: statsFromMins(allT),
                n: allK.length
            }
        };
    }

    function mountTimingPanel(wrap, orders) {
        var toolbar = wrap.querySelector('#hiwTimingToolbar');
        var body = wrap.querySelector('#hiwTimingBody');
        var note = wrap.querySelector('#hiwTimingNote');
        var todayPane = wrap.querySelector('#hiwTimingTodayPane');
        var histPane = wrap.querySelector('#hiwTimingHistoryPane');
        var histToolbar = wrap.querySelector('#hiwHistToolbar');
        var histBody = wrap.querySelector('#hiwHistBody');
        var histNote = wrap.querySelector('#hiwHistNote');
        if (!toolbar || !body) return;

        var typeOpts = orders.timing_type_options || [
            { id: 1, key: 'urgent', name: 'ยาเร่งด่วน' },
            { id: 2, key: 'normal', name: 'ยาปกติ' },
            { id: 3, key: 'home', name: 'ยากลับบ้าน' }
        ];
        var wardOpts = orders.timing_ward_options || [];
        var rows = orders.timing_rows || [];

        function typeChipsHtml(opts) {
            return (opts || typeOpts).map(function (t) {
            var on = timingFilter.types[+t.id] !== false;
            return '<button type="button" class="hiw-type-tog' + (on ? ' is-on' : '') +
                '" data-type="' + esc(t.id) + '" title="' + (on ? 'คลิกเพื่อซ่อน' : 'คลิกเพื่อแสดง') + '">' +
                '<i class="fas ' + (on ? 'fa-eye' : 'fa-eye-slash') + '"></i> ' + esc(t.name) +
                '</button>';
        }).join('');
        }

        function wardHtml(opts, selId) {
            return '<label class="hiw-ward-filter">' +
            '<span>หอผู้ป่วย</span>' +
                '<select id="' + esc(selId) + '">' +
            '<option value="">ทุกหอ</option>' +
                (opts || []).map(function (w) {
                var sel = String(timingFilter.ward) === String(w.id) ? ' selected' : '';
                return '<option value="' + esc(w.id) + '"' + sel + '>' + esc(w.name) + '</option>';
            }).join('') +
            '</select></label>';
        }

        var consultN = +orders.timing_consult_excluded || 0;
        var consultHtml =
            '<label class="hiw-consult-filter" title="ยกเว้นรายการที่ผู้ Key ใน Drug Viewer มีคำว่า Consult เช่น Consult COM1-4">' +
            '<input type="checkbox" id="hiwExcludeConsult"' +
            (timingFilter.excludeConsult !== false ? ' checked' : '') + '>' +
            '<span>ยกเว้น Consult' +
            (consultN ? (' <em>(' + esc(consultN) + ')</em>') : '') +
            '</span></label>';

        var autoShiftHtml =
            '<label class="hiw-autoshift-filter" title="เปิดแล้วแท็บเวรจะเปลี่ยนตามเวลาปัจจุบันอัตโนมัติ (00-08 / 08-16 / 16-24)">' +
            '<input type="checkbox" id="hiwAutoShift"' +
            (timingFilter.autoShift ? ' checked' : '') + '>' +
            '<span>แสดงตามเวร</span></label>';

        function shiftTabsHtml(activeShift) {
            return '<div class="hiw-shift-tabs" role="tablist" aria-label="กรองเวลา Scan order">' +
                '<span class="hiw-shift-tabs-label">เวลา Scan</span>' +
                SHIFT_OPTIONS.map(function (s) {
                    var on = s.id === activeShift;
                    return '<button type="button" class="hiw-shift-tab' + (on ? ' is-on' : '') +
                        '" data-shift="' + esc(s.id) + '" role="tab" aria-selected="' + (on ? 'true' : 'false') + '"' +
                        ' title="กรองตามเวลา Scan order">' + esc(s.label) + '</button>';
                }).join('') +
                '</div>';
        }

        toolbar.innerHTML =
            '<div class="hiw-timing-filters hiw-timing-filters-shift">' +
            shiftTabsHtml(effectiveTimingShift()) +
            autoShiftHtml +
            '</div>' +
            '<div class="hiw-timing-filters">' +
            '<div class="hiw-type-togs" role="group" aria-label="แสดง/ซ่อนประเภทยา">' + typeChipsHtml(typeOpts) + '</div>' +
            '<div class="hiw-timing-filters-right">' + consultHtml + wardHtml(wardOpts, 'hiwTimingWard') + '</div>' +
            '</div>';

        function syncShiftTabs(rootEl) {
            var active = effectiveTimingShift();
            (rootEl || toolbar).querySelectorAll('.hiw-shift-tab').forEach(function (btn) {
                var on = btn.getAttribute('data-shift') === active;
                btn.classList.toggle('is-on', on);
                btn.setAttribute('aria-selected', on ? 'true' : 'false');
            });
            toolbar.classList.toggle('is-autoshift', !!timingFilter.autoShift);
            if (histToolbar) histToolbar.classList.toggle('is-autoshift', !!timingFilter.autoShift);
        }

        function setTimingMode(mode) {
            timingMode = mode === 'history' ? 'history' : 'today';
            wrap.querySelectorAll('.hiw-mode-tab').forEach(function (btn) {
                btn.classList.toggle('is-on', btn.getAttribute('data-timing-mode') === timingMode);
            });
            if (todayPane) todayPane.classList.toggle('is-hidden', timingMode !== 'today');
            if (histPane) histPane.classList.toggle('is-hidden', timingMode !== 'history');
            if (timingMode === 'history') {
                ensureHistoryLoaded(false);
            }
        }

        function paintToday() {
            if (timingFilter.autoShift) {
                timingFilter.shift = currentShiftId();
            }
            syncShiftTabs(toolbar);

            var shiftId = effectiveTimingShift();
            var statsDate = orders.stats_date || ymdLocal(new Date());
            var visible = typeOpts.filter(function (t) {
                return timingFilter.types[+t.id] !== false;
            });
            if (!visible.length) {
                body.innerHTML = '<div class="hiw-timing-empty">เลือกอย่างน้อย 1 ประเภทยาเพื่อแสดงสถิติ</div>';
                if (note) note.textContent = '';
                return;
            }

            var totalN = 0;
            var skipped = 0;
            var html = '';
            visible.forEach(function (t) {
                var agg = aggregateTimingRows(
                    rows,
                    t.id,
                    timingFilter.ward,
                    timingFilter.excludeConsult !== false,
                    shiftId,
                    statsDate
                );
                totalN += agg.n;
                skipped += agg.skippedConsult || 0;
                var tone = +t.id === 1 ? 'is-urgent' : (+t.id === 3 ? 'is-home' : 'is-normal');
                html += '<div class="hiw-timing-block ' + tone + '">' +
                    '<div class="hiw-timing-block-head">' +
                    '<strong>' + esc(t.name) + '</strong>' +
                    '<span>n=' + esc(agg.n) +
                    (shiftId !== 'all' ? (' · Scan ' + esc(shiftLabel(shiftId))) : '') +
                    (timingFilter.ward ? ' · กรองหอ' : '') +
                    (timingFilter.excludeConsult !== false && agg.skippedConsult
                        ? (' · ยกเว้น Consult ' + esc(agg.skippedConsult))
                        : '') +
                    '</span></div>' +
                    '<div class="hiw-timing-grid">' +
                    timingCard({
                        tone: 'tone-key',
                        icon: 'fa-keyboard',
                        label: '1. ระยะเวลา Key',
                        flow: 'Scan order → Key',
                        stats: agg.key_minutes
                    }) +
                    timingCard({
                        tone: 'tone-check',
                        icon: 'fa-user-check',
                        label: '2. ระยะเวลา Check',
                        flow: 'Key → บันทึกผู้จ่าย (Tham)',
                        stats: agg.check_minutes
                    }) +
                    timingCard({
                        tone: 'tone-total',
                        icon: 'fa-stopwatch',
                        label: '3. ระยะเวลาทั้งหมด',
                        flow: 'Scan → จ่าย (= Key + Check)',
                        stats: agg.total_minutes
                    }) +
                    '</div></div>';
            });
            body.innerHTML = html;
            if (note) {
                note.textContent = 'สถิติเวลาใช้ชุดออเดอร์ที่จับคู่ครบ Scan→Key→จ่ายวันนี้' +
                    ' · เทียบเมื่อวาน / ค่าเฉลี่ยรายวัน 7 วันล่าสุด (ตามตัวกรองเดียวกัน)' +
                    ' (n ที่แสดง=' + totalN +
                    ' / คู่วันนี้=' + (+orders.matched_pairs || 0) +
                    (shiftId !== 'all' ? (' · เวร Scan ' + shiftLabel(shiftId)) : ' · ทั้งวัน') +
                    (timingFilter.autoShift ? ' · ปรับตามเวรอัตโนมัติ' : '') +
                    (timingFilter.excludeConsult !== false
                        ? (' · ยกเว้น Consult ' + skipped + ' รายที่ผู้ Key มีคำว่า Consult')
                        : ' · รวม Consult') +
                    ') · เขียว = เร็วขึ้น · แดง = ช้าลง';
            }
        }

        function paintHistory() {
            if (!histToolbar || !histBody) return;
            if (timingFilter.autoShift) {
                timingFilter.shift = currentShiftId();
            }
            var shiftId = effectiveTimingShift();
            var from = timingHistoryState.from;
            var to = timingHistoryState.to;
            var hTypes = (timingHistoryCache && timingHistoryCache.timing_type_options) || typeOpts;
            var hWards = (timingHistoryCache && timingHistoryCache.timing_ward_options) || wardOpts;
            var hRows = (timingHistoryCache && timingHistoryCache.timing_rows) || [];

            histToolbar.innerHTML =
                '<div class="hiw-hist-range">' +
                '<label class="hiw-hist-date"><span>จาก</span>' +
                '<input type="date" id="hiwHistFrom" value="' + esc(from) + '"></label>' +
                '<label class="hiw-hist-date"><span>ถึง</span>' +
                '<input type="date" id="hiwHistTo" value="' + esc(to) + '"></label>' +
                '<div class="hiw-hist-presets">' +
                '<button type="button" class="hiw-hist-preset" data-days="7">7 วัน</button>' +
                '<button type="button" class="hiw-hist-preset" data-days="14">14 วัน</button>' +
                '<button type="button" class="hiw-hist-preset" data-days="30">30 วัน</button>' +
                '</div>' +
                '<button type="button" class="hiw-hist-apply" id="hiwHistApply">' +
                '<i class="fas fa-search"></i> ดู</button>' +
                '</div>' +
                '<div class="hiw-timing-filters hiw-timing-filters-shift">' +
                shiftTabsHtml(shiftId) +
                '<label class="hiw-autoshift-filter" title="เปิดแล้วแท็บเวรจะเปลี่ยนตามเวลาปัจจุบันอัตโนมัติ">' +
                '<input type="checkbox" id="hiwHistAutoShift"' +
                (timingFilter.autoShift ? ' checked' : '') + '>' +
                '<span>แสดงตามเวร</span></label>' +
                '</div>' +
                '<div class="hiw-timing-filters">' +
                '<div class="hiw-type-togs" role="group">' + typeChipsHtml(hTypes) + '</div>' +
                '<div class="hiw-timing-filters-right">' +
                '<label class="hiw-consult-filter">' +
                '<input type="checkbox" id="hiwHistExcludeConsult"' +
                (timingFilter.excludeConsult !== false ? ' checked' : '') + '>' +
                '<span>ยกเว้น Consult</span></label>' +
                wardHtml(hWards, 'hiwHistWard') +
                '</div></div>';

            syncShiftTabs(histToolbar);
            bindHistoryControls();

            if (timingHistoryBusy) {
                histBody.innerHTML = '<div class="hiw-timing-empty"><i class="fas fa-spinner fa-spin me-1"></i>กำลังโหลดประวัติ…</div>';
                if (histNote) histNote.textContent = '';
                return;
            }
            if (!timingHistoryCache || !timingHistoryCache.ok) {
                histBody.innerHTML = '<div class="hiw-timing-empty">' +
                    esc((timingHistoryCache && timingHistoryCache.error) || 'ยังไม่มีข้อมูลประวัติ') +
                    '</div>';
                if (histNote) histNote.textContent = '';
                return;
            }

            var typeIds = hTypes.filter(function (t) {
                return timingFilter.types[+t.id] !== false;
            }).map(function (t) { return +t.id; });
            if (!typeIds.length) {
                histBody.innerHTML = '<div class="hiw-timing-empty">เลือกอย่างน้อย 1 ประเภทยาเพื่อแสดงประวัติ</div>';
                return;
            }

            var agg = aggregateHistoryByDay(
                hRows,
                typeIds,
                timingFilter.ward,
                timingFilter.excludeConsult !== false,
                shiftId,
                from,
                to
            );
            var maxTot = 0;
            agg.days.forEach(function (d) {
                if (d.total.avg != null && d.total.avg > maxTot) maxTot = d.total.avg;
            });
            if (maxTot <= 0) maxTot = 1;

            var p = agg.period;
            var summary =
                '<div class="hiw-hist-summary">' +
                '<div class="hiw-hist-sum-card tone-key"><span>Key เฉลี่ยช่วงนี้</span><b>' +
                (p.key.n ? esc(p.key.avg) : '—') + '</b><em>นาที · n=' + esc(p.key.n) + '</em></div>' +
                '<div class="hiw-hist-sum-card tone-check"><span>Check เฉลี่ยช่วงนี้</span><b>' +
                (p.check.n ? esc(p.check.avg) : '—') + '</b><em>นาที · n=' + esc(p.check.n) + '</em></div>' +
                '<div class="hiw-hist-sum-card tone-total"><span>รวมเฉลี่ยช่วงนี้</span><b>' +
                (p.total.n ? esc(p.total.avg) : '—') + '</b><em>นาที · n=' + esc(p.total.n) + '</em></div>' +
                '</div>';

            var rowsHtml = agg.days.map(function (d) {
                var pct = d.total.avg != null ? Math.max(6, Math.round((d.total.avg / maxTot) * 100)) : 0;
                var barCls = d.n ? '' : ' is-empty';
                return '<tr>' +
                    '<td class="hiw-hist-date-cell hiw-hist-col-date">' + esc(fmtYmdTh(d.date)) + '</td>' +
                    '<td class="num hiw-hist-col-n">' + esc(d.n) + '</td>' +
                    '<td class="num hiw-hist-col-min">' + (d.key.n ? esc(d.key.avg) : '—') + '</td>' +
                    '<td class="num hiw-hist-col-min">' + (d.check.n ? esc(d.check.avg) : '—') + '</td>' +
                    '<td class="num hiw-hist-col-min">' + (d.total.n ? esc(d.total.avg) : '—') + '</td>' +
                    '<td class="hiw-hist-bar-cell hiw-hist-col-bar"><div class="hiw-hist-bar' + barCls +
                    '" style="width:' + pct + '%" title="รวมเฉลี่ย ' +
                    (d.total.avg != null ? esc(d.total.avg) + ' นาที' : 'ไม่มีข้อมูล') +
                    '"></div></td>' +
                    '</tr>';
            }).join('');

            histBody.innerHTML = summary +
                '<div class="hiw-hist-table-wrap"><table class="hiw-hist-table">' +
                '<thead><tr>' +
                '<th class="hiw-hist-col-date">วันที่</th>' +
                '<th class="num hiw-hist-col-n">n</th>' +
                '<th class="num hiw-hist-col-min">Key</th>' +
                '<th class="num hiw-hist-col-min">Check</th>' +
                '<th class="num hiw-hist-col-min">รวม</th>' +
                '<th class="hiw-hist-col-bar">แนวโน้ม (รวม)</th>' +
                '</tr></thead><tbody>' +
                (rowsHtml || '<tr><td colspan="6" class="text-center text-muted">ไม่มีข้อมูลในช่วงนี้</td></tr>') +
                '</tbody></table></div>';

            if (histNote) {
                histNote.textContent = 'ประวัติตามวันที่จ่าย · ' + fmtYmdTh(from) + ' – ' + fmtYmdTh(to) +
                    ' · คู่ที่จับคู่ได้ ' + (+timingHistoryCache.pair_count || 0) + ' ราย' +
                    (shiftId !== 'all' ? (' · เวร Scan ' + shiftLabel(shiftId)) : ' · ทั้งวัน') +
                    (timingFilter.excludeConsult !== false
                        ? (' · ยกเว้น Consult ' + (agg.skippedConsult || 0))
                        : ' · รวม Consult') +
                    ' · สูงสุด 31 วัน';
            }
        }

        function bindHistoryControls() {
            if (!histToolbar) return;
            histToolbar.querySelectorAll('.hiw-hist-preset').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    var days = Math.max(1, Math.min(31, +btn.getAttribute('data-days') || 7));
                    var today = ymdLocal(new Date());
                    timingHistoryState.to = today;
                    timingHistoryState.from = addDaysYmd(today, -(days - 1));
                    saveTimingHistoryState();
                    ensureHistoryLoaded(true);
                });
            });
            var applyBtn = histToolbar.querySelector('#hiwHistApply');
            if (applyBtn) {
                applyBtn.addEventListener('click', function () {
                    var f = histToolbar.querySelector('#hiwHistFrom');
                    var t = histToolbar.querySelector('#hiwHistTo');
                    var from = f ? f.value : timingHistoryState.from;
                    var to = t ? t.value : timingHistoryState.to;
                    if (!from || !to) return;
                    if (from > to) { var tmp = from; from = to; to = tmp; }
                    timingHistoryState.from = from;
                    timingHistoryState.to = to;
                    saveTimingHistoryState();
                    ensureHistoryLoaded(true);
                });
            }
            histToolbar.querySelectorAll('.hiw-shift-tab').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    timingFilter.shift = normalizeShiftId(btn.getAttribute('data-shift'));
                    if (timingFilter.autoShift) {
                        timingFilter.autoShift = false;
                    }
                    saveTimingFilter();
                    paintHistory();
                });
            });
            histToolbar.querySelectorAll('.hiw-type-tog').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    var tid = +btn.getAttribute('data-type');
                    timingFilter.types[tid] = !timingFilter.types[tid];
                    var any = timingFilter.types[1] || timingFilter.types[2] || timingFilter.types[3];
                    if (!any) timingFilter.types[tid] = true;
                    saveTimingFilter();
                    paintHistory();
                });
            });
            var wardSel = histToolbar.querySelector('#hiwHistWard');
            if (wardSel) {
                wardSel.addEventListener('change', function () {
                    timingFilter.ward = wardSel.value || '';
                    saveTimingFilter();
                    paintHistory();
                });
            }
            var consultChk = histToolbar.querySelector('#hiwHistExcludeConsult');
            if (consultChk) {
                consultChk.addEventListener('change', function () {
                    timingFilter.excludeConsult = !!consultChk.checked;
                    saveTimingFilter();
                    paintHistory();
                });
            }
            var autoChk = histToolbar.querySelector('#hiwHistAutoShift');
            if (autoChk) {
                autoChk.addEventListener('change', function () {
                    timingFilter.autoShift = !!autoChk.checked;
                    if (timingFilter.autoShift) timingFilter.shift = currentShiftId();
                    saveTimingFilter();
                    paintHistory();
                });
            }
        }

        function ensureHistoryLoaded(force) {
            var from = timingHistoryState.from;
            var to = timingHistoryState.to;
            if (!force && timingHistoryCache && timingHistoryCache.ok &&
                timingHistoryCache.date_from === from && timingHistoryCache.date_to === to) {
                paintHistory();
                return;
            }
            timingHistoryBusy = true;
            paintHistory();
            var qs = new URLSearchParams({
                action: 'timing_history',
                from: from,
                to: to
            });
            fetch(apiUrl + (apiUrl.indexOf('?') >= 0 ? '&' : '?') + qs.toString(), {
                credentials: 'same-origin',
                cache: 'no-store'
            })
                .then(function (r) { return r.json(); })
                .then(function (j) {
                    timingHistoryBusy = false;
                    if (j && j.status === 'success' && j.data) {
                        timingHistoryCache = j.data;
                        if (j.data.date_from) timingHistoryState.from = j.data.date_from;
                        if (j.data.date_to) timingHistoryState.to = j.data.date_to;
                        saveTimingHistoryState();
                    } else {
                        timingHistoryCache = {
                            ok: false,
                            error: (j && j.msg) || 'โหลดประวัติไม่สำเร็จ',
                            date_from: from,
                            date_to: to,
                            timing_rows: []
                        };
                    }
                    if (timingMode === 'history') paintHistory();
                })
                .catch(function () {
                    timingHistoryBusy = false;
                    timingHistoryCache = {
                        ok: false,
                        error: 'เชื่อมต่อไม่สำเร็จ',
                        date_from: from,
                        date_to: to,
                        timing_rows: []
                    };
                    if (timingMode === 'history') paintHistory();
                });
        }

        wrap.querySelectorAll('.hiw-mode-tab').forEach(function (btn) {
            btn.addEventListener('click', function () {
                setTimingMode(btn.getAttribute('data-timing-mode'));
            });
        });

        toolbar.querySelectorAll('.hiw-shift-tab').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var sid = normalizeShiftId(btn.getAttribute('data-shift'));
                timingFilter.shift = sid;
                if (timingFilter.autoShift) {
                    timingFilter.autoShift = false;
                    var autoChk = toolbar.querySelector('#hiwAutoShift');
                    if (autoChk) autoChk.checked = false;
                }
                saveTimingFilter();
                paintToday();
            });
        });
        toolbar.querySelectorAll('.hiw-type-tog').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var tid = +btn.getAttribute('data-type');
                timingFilter.types[tid] = !timingFilter.types[tid];
                var any = timingFilter.types[1] || timingFilter.types[2] || timingFilter.types[3];
                if (!any) timingFilter.types[tid] = true;
                saveTimingFilter();
                var on = !!timingFilter.types[tid];
                btn.classList.toggle('is-on', on);
                btn.title = on ? 'คลิกเพื่อซ่อน' : 'คลิกเพื่อแสดง';
                var icon = btn.querySelector('i');
                if (icon) icon.className = 'fas ' + (on ? 'fa-eye' : 'fa-eye-slash');
                paintToday();
            });
        });
        var wardSel = toolbar.querySelector('#hiwTimingWard');
        if (wardSel) {
            wardSel.addEventListener('change', function () {
                timingFilter.ward = wardSel.value || '';
                saveTimingFilter();
                paintToday();
            });
        }
        var consultChk = toolbar.querySelector('#hiwExcludeConsult');
        if (consultChk) {
            consultChk.addEventListener('change', function () {
                timingFilter.excludeConsult = !!consultChk.checked;
                saveTimingFilter();
                paintToday();
            });
        }
        var autoChk = toolbar.querySelector('#hiwAutoShift');
        if (autoChk) {
            autoChk.addEventListener('change', function () {
                timingFilter.autoShift = !!autoChk.checked;
                if (timingFilter.autoShift) {
                    timingFilter.shift = currentShiftId();
                }
                saveTimingFilter();
                paintToday();
            });
        }

        paintToday();
        if (timingMode === 'history') {
            ensureHistoryLoaded(false);
        }
    }

    function render(data) {
        var summary = data.summary || {};
        var wards = data.wards || [];
        var orders = data.orders || null;
        var busyMap = pickBusyIndexes(wards);

        var head = el('div', 'hiw-head');
        head.innerHTML =
            '<div>' +
            '<h2 class="hiw-title"><i class="fas fa-hospital me-2"></i>ภาพรวมห้องจ่ายยาผู้ป่วยใน</h2>' +
            '<p class="hiw-sub">ระยะเวลา Key / Check / รวม · หอผู้ป่วย (โหมดเบา)</p>' +
            '</div>' +
            '<div class="hiw-meta">' +
            'อัปเดต ' + esc(data.as_of || fmtTime(data.fetched_at)) +
            (data.cached ? ' · cache' : '') +
            '<br><span>รีเฟรชทุก ' + esc(data.ttl || 90) + ' วินาที</span>' +
            '</div>';

        var orderPanel = renderOrderPanel(orders);

        var kpis = el('div', 'hiw-kpis');
        [
            { label: 'เตียงทั้งหมด', val: summary.maxbed || 0 },
            { label: 'คงรักษา', val: summary.stay || 0 },
            { label: 'เตียงว่าง', val: summary.blank || 0, cls: (summary.blank || 0) < 0 ? 'is-bad' : 'is-ok' },
            { label: 'Admit วันนี้', val: summary.admit || 0 },
            { label: 'D/C วันนี้', val: summary.discharge || 0 }
        ].forEach(function (it) {
            kpis.appendChild(el('div', 'hiw-kpi' + (it.cls ? ' ' + it.cls : ''),
                '<b>' + esc(it.val) + '</b><span>' + esc(it.label) + '</span>'));
        });

        var admitTotal = 0;
        for (var ai = 0; ai < wards.length; ai++) {
            admitTotal += (+wards[ai].admit || 0);
        }
        var ambCount = Math.min(4, Math.max(0, admitTotal));
        var ambLane = '';
        for (var aj = 0; aj < ambCount; aj++) {
            ambLane += '<div class="hiw-road-amb">' + spriteHtml('amb', 'hiw-sprite-amb') + '</div>';
        }

        var stage = el('div', 'hiw-stage');
        stage.innerHTML =
            '<div class="hiw-env" aria-hidden="true">' +
            '<img class="hiw-tree-img t1" src="' + HIW_SPRITE.tree + '" alt="">' +
            '<img class="hiw-tree-img t2" src="' + HIW_SPRITE.tree + '" alt="">' +
            '<img class="hiw-tree-img t3" src="' + HIW_SPRITE.tree + '" alt="">' +
            '<img class="hiw-tree-img t4" src="' + HIW_SPRITE.tree + '" alt="">' +
            '<img class="hiw-tree-img t5" src="' + HIW_SPRITE.tree + '" alt="">' +
            '<img class="hiw-tree-img t6" src="' + HIW_SPRITE.tree + '" alt="">' +
            '<img class="hiw-tree-img t7" src="' + HIW_SPRITE.tree + '" alt="">' +
            '<img class="hiw-tree-img t8" src="' + HIW_SPRITE.tree + '" alt="">' +
            '<img class="hiw-tree-img t9" src="' + HIW_SPRITE.tree + '" alt="">' +
            '<img class="hiw-tree-img t10" src="' + HIW_SPRITE.tree + '" alt="">' +
            '</div>' +
            '<svg class="hiw-paths-svg" id="hiwPathsSvg" aria-hidden="true"></svg>' +
            '<div class="hiw-road-v" aria-hidden="true"></div>' +
            '<div class="hiw-road" aria-hidden="true">' +
            '<div class="hiw-zebra z1"></div><div class="hiw-zebra z2"></div>' +
            (ambLane ? '<div class="hiw-road-amb-lane">' + ambLane + '</div>' : '') +
            '</div>';

        var board = el('div', 'hiw-board');
        if (!wards.length) {
            board.appendChild(el('div', 'hiw-empty', 'ไม่พบข้อมูลหอผู้ป่วย'));
        } else {
            wards.forEach(function (w, idx) {
                var isBusy = !!busyMap[idx];
                var admitN = +w.admit || 0;
                var dcN = +w.discharge || 0;
                var blankN = +w.blank || 0;
                var urgN = +w.urgent_over30 || 0;
                var urgKey = +w.urgent_over30_key || 0;
                var urgPay = +w.urgent_over30_pay || 0;
                var role = staffRole(w);
                var pharmFocus = needsPharmacist(w) && !hasUrgentWait(w);
                var isCrisis = blankN <= -5; /* วิกฤตเตียงล้นหนัก */
                var isUrgentWait = urgN > 0;
                var card = el('div', 'hiw-ward ward-card' + (isBusy ? ' is-busy' : '') +
                    (blankN < 0 ? ' is-overcap' : '') +
                    (isCrisis ? ' is-crisis' : '') +
                    (isUrgentWait ? ' has-urgent-wait' : '') +
                    (pharmFocus ? ' has-pharm' : ''));
                card.setAttribute('data-level', levelOf(w));
                card.setAttribute('data-critical', w.critical ? '1' : '0');
                card.setAttribute('data-ward', w.wardname || '');
                card.setAttribute('data-admit', String(admitN));
                card.setAttribute('data-dc', String(dcN));
                card.setAttribute('data-blank', String(blankN));
                card.setAttribute('data-urgent30', String(urgN));

                var caps = '<div class="hiw-caps">';
                if (isCrisis) {
                    caps += '<span class="hiw-cap is-crisis" title="วิกฤตเตียงล้นเกิน 5 เตียง">' +
                        '<em>CRIT</em><b>' + esc(blankN) + '</b></span>';
                }
                if (isUrgentWait) {
                    var urgLabel = urgKey > 0 && urgPay <= 0 ? 'ด่วนรอคีย์'
                        : (urgPay > 0 && urgKey <= 0 ? 'ด่วนรอจ่าย' : 'ด่วนรอนาน');
                    caps += '<span class="hiw-cap is-urgent-wait" title="ยาด่วนรอ Key/รอจ่าย >30 นาที · คลิกดูรายการ">' +
                        '<em>💊 ' + urgLabel + ' &gt;30น.</em><b>' + esc(urgN) + '</b></span>';
                }
                if (admitN > 0) {
                    caps += '<span class="hiw-cap is-in" title="Admit วันนี้">' +
                        spriteHtml('amb', 'hiw-cap-ico', { static: true }) +
                        '<em>IN</em><b>+' + esc(admitN) + '</b></span>';
                }
                if (dcN > 0) {
                    caps += '<span class="hiw-cap is-out" title="D/C วันนี้">' +
                        spriteHtml('patient', 'hiw-cap-ico', { static: true }) +
                        '<em>OUT</em><b>-' + esc(dcN) + '</b></span>';
                }
                caps += '</div>';

                var staffTitle = role === 'nurse_imp'
                    ? ('พยาบาลตามยาด่วน · ' + urgN + ' ราย >30 นาที (Key ' + urgKey + ' / จ่าย ' + urgPay + ')')
                    : (role === 'pharm'
                        ? (dcN > 0 ? 'เภสัชกร · มี D/C รับยากลับบ้าน' : 'เภสัชกร · เฝ้าระวังยา/เตียงล้น')
                        : (role === 'doc' ? 'แพทย์' : 'พยาบาล'));
                if (isCrisis) staffTitle += ' · งานล้นมือ (เตียงล้นวิกฤต)';

                var angryHtml = '';
                if (isCrisis) {
                    angryHtml =
                        '<div class="hiw-room-angry" title="⚠️ วิกฤตเตียงล้นเกิน 5 เตียง!">' +
                        spriteHtml('angry', 'hiw-sprite-angry') +
                        '<span class="hiw-angry-bubble">⚠️ วิกฤตเตียงล้นเกิน 5 เตียง!</span>' +
                        '</div>';
                }

                card.innerHTML =
                    caps +
                    '<div class="hiw-ward-badge' + (blankN < 0 ? ' is-neg' : '') + '" title="เตียงว่าง">' +
                    '<b>' + esc(blankN) + '</b><span>ว่าง</span></div>' +
                    '<div class="hiw-room-wrap">' +
                    '<img class="hiw-room-bg" src="' + HIW_SPRITE.room + '" alt="" draggable="false">' +
                    bedsHtml(w) +
                    '<div class="hiw-room-staff is-patrol' +
                    (pharmFocus ? ' is-pharm-focus' : '') +
                    (isUrgentWait ? ' is-urgent-nurse' : '') +
                    (isCrisis ? ' is-high-workload' : '') +
                    '" style="' + patrolDelayStyle() + '" title="' + esc(staffTitle) + '">' +
                    charHtml(role) +
                    (isUrgentWait
                        ? '<span class="hiw-nurse-urgent-tag">💊 &gt;30น. ×' + esc(urgN) + '</span>'
                        : '') +
                    '</div>' +
                    angryHtml +
                    (dcN > 0 && !isCrisis
                        ? '<div class="hiw-room-dc is-patrol" style="' + patrolDelayStyle() + '">' +
                          spriteHtml('patient', 'hiw-sprite-dc') + '</div>'
                        : '') +
                    '</div>' +
                    '<div class="hiw-ward-foot">' +
                    '<div class="hiw-ward-label" title="' + esc(w.ward_name) + '">' + esc(w.wardname) + '</div>' +
                    occBarHtml(w) +
                    '</div>';

                card.style.cursor = isUrgentWait ? 'pointer' : '';
                card.addEventListener('mousemove', function (e) { showTip(card, w, e); });
                card.addEventListener('mouseleave', hideTip);
                if (isUrgentWait) {
                    card.addEventListener('click', function () {
                        openWardUrgentQueue(w);
                    });
                }
                board.appendChild(card);
            });
        }

        var actors = el('div', 'hiw-actors');
        actors.innerHTML =
            '<div class="hiw-actor">' + spriteHtml('doc') + '</div>' +
            '<div class="hiw-actor">' + spriteHtml('nurse') + '</div>' +
            '<div class="hiw-actor">' + spriteHtml('patient') + '</div>' +
            '<div class="hiw-actor">' + spriteHtml('pharm') + '</div>' +
            '<div class="hiw-actor">' + spriteHtml('nurse') + '</div>' +
            '<div class="hiw-actor is-amb">' + spriteHtml('amb', 'hiw-sprite-amb') + '</div>';

        var fxLayer = el('div', 'hiw-fx-layer');

        stage.appendChild(board);
        stage.appendChild(actors);
        stage.appendChild(fxLayer);

        var section = el('div', 'hiw-section-label');
        section.innerHTML = '<i class="fas fa-procedures me-1"></i>หอผู้ป่วย · เตียงว่าง/ครองเตียง';

        var filters = el('div', 'hiw-filters');
        filters.innerHTML =
            '<button type="button" class="hiw-filter-pill" data-filter="all">ทั้งหมด</button>' +
            '<button type="button" class="hiw-filter-pill" data-filter="vacant">🟢 มีเตียงว่าง</button>' +
            '<button type="button" class="hiw-filter-pill" data-filter="full">🔴 เตียงเต็ม/ล้น</button>' +
            '<button type="button" class="hiw-filter-pill" data-filter="flow">🚑 มี Admit/DC</button>' +
            '<button type="button" class="hiw-filter-pill is-urgent-filter" data-filter="urgent30">⏰ ยาด่วนรอนาน &gt;30น.</button>';

        var legend = el('div', 'hiw-legend');
        legend.innerHTML =
            '<div class="hiw-legend-group">' +
            '<span class="hiw-legend-item"><img class="hiw-legend-bed" src="' + HIW_SPRITE.bedEmpty + '" alt="">เตียงว่าง</span>' +
            '<span class="hiw-legend-item"><img class="hiw-legend-bed" src="' + HIW_SPRITE.bedUsed + '" alt="">ครองเตียง</span>' +
            '<span class="hiw-legend-item"><span class="hiw-cap is-in hiw-cap-demo"><em>IN</em><b>+n</b></span> Admit</span>' +
            '<span class="hiw-legend-item"><span class="hiw-cap is-out hiw-cap-demo"><em>OUT</em><b>-n</b></span> D/C</span>' +
            '</div>' +
            '<div class="hiw-legend-group">' +
            '<span class="hiw-legend-char">' + spriteHtml('doc', 'hiw-sprite-lg') + ' แพทย์</span>' +
            '<span class="hiw-legend-char">' + spriteHtml('nurse', 'hiw-sprite-lg') + ' พยาบาล</span>' +
            '<span class="hiw-legend-char">' + spriteHtml('nurse_imp', 'hiw-sprite-lg hiw-sprite-nurse-imp', { static: true }) + ' พยาบาลตามยาด่วน (&gt;30 นาที)</span>' +
            '<span class="hiw-legend-char">' + spriteHtml('pharm', 'hiw-sprite-lg') + ' เภสัชกร (D/C / เฝ้าระวังยา)</span>' +
            '<span class="hiw-legend-char">' + spriteHtml('patient', 'hiw-sprite-lg') + ' ผู้ป่วย D/C</span>' +
            '<span class="hiw-legend-char">' + spriteHtml('angry', 'hiw-sprite-lg hiw-sprite-angry', { static: true }) + ' เตียงล้นวิกฤต (ติดลบ ≥ 5)</span>' +
            '<span class="hiw-legend-char">' + spriteHtml('amb', 'hiw-sprite-lg hiw-sprite-amb') + ' รถพยาบาล</span>' +
            '<span class="hiw-legend-note">พยาบาลเคาะเท้า = ยาด่วนรอ Key/รอจ่าย &gt;30น. · คลิกตึกเปิดรายการ · คนไข้โวยวาย = ว่าง ≤ -5</span>' +
            '</div>';

        root.innerHTML = '';
        root.appendChild(head);
        root.appendChild(orderPanel);
        root.appendChild(section);
        root.appendChild(kpis);
        root.appendChild(filters);
        root.appendChild(stage);
        root.appendChild(legend);
        tip = null;

        lastStage = stage;
        lastBoard = board;
        bindWardFilters(filters, board);
        drawCampusPaths(stage, board);
        scheduleWardTrafficFx(stage, board, wards, fxLayer);
    }

    /** วาดทางเดินปูพื้นเชื่อมประตูหอ ↔ กันและกัน ↔ ถนนซ้าย (zigzag) */
    function drawCampusPaths(stage, board) {
        var svg = stage.querySelector('#hiwPathsSvg');
        if (!svg || !board) return;
        var cards = board.querySelectorAll('.hiw-ward');
        if (!cards.length) {
            svg.innerHTML = '';
            return;
        }
        var sr = stage.getBoundingClientRect();
        var w = Math.max(1, Math.round(sr.width));
        var h = Math.max(1, Math.round(sr.height));
        svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
        svg.setAttribute('width', String(w));
        svg.setAttribute('height', String(h));

        var roadY = h - 78;
        var leftRoadX = 42;
        var topY = Math.round(h * 0.12);
        var pts = [];
        for (var i = 0; i < cards.length; i++) {
            var cr = cards[i].getBoundingClientRect();
            /* จุดเชื่อมที่ฐานตึก (เหนือป้ายชื่อ) */
            pts.push({
                x: Math.round(cr.left - sr.left + cr.width * 0.42),
                y: Math.round(cr.top - sr.top + cr.height * 0.72),
                row: Math.round((cr.top - sr.top) / 48)
            });
        }
        pts.sort(function (a, b) { return a.row - b.row || a.x - b.x; });

        var segs = [];
        var r = 16; /* รัศมีมุมโค้ง */

        /* ถนนแนวตั้งซ้าย + แนวนอนล่าง (โค้งที่มุม) */
        segs.push(
            'M' + leftRoadX + ' ' + topY +
            ' L' + leftRoadX + ' ' + (roadY - r) +
            ' Q' + leftRoadX + ' ' + roadY + ' ' + (leftRoadX + r) + ' ' + roadY +
            ' L' + (w - 14) + ' ' + roadY
        );

        for (var j = 0; j < pts.length; j++) {
            var p = pts[j];
            var x = p.x;
            var y = Math.min(p.y, roadY - r - 4);
            /* ประตู → ลง → โค้งเข้าถนนหลัก */
            segs.push(
                'M' + x + ' ' + y +
                ' L' + x + ' ' + (roadY - r) +
                ' Q' + x + ' ' + roadY + ' ' + (x - r) + ' ' + roadY +
                ' L' + (leftRoadX + r) + ' ' + roadY
            );
            if (j > 0) {
                var prev = pts[j - 1];
                if (prev.row === p.row) {
                    var yLink = Math.min(prev.y, p.y) + 6;
                    var x1 = prev.x;
                    var x2 = p.x;
                    var mid = Math.round((x1 + x2) / 2);
                    segs.push(
                        'M' + x1 + ' ' + yLink +
                        ' Q' + mid + ' ' + (yLink + 10) + ' ' + x2 + ' ' + yLink
                    );
                }
            }
        }

        var d = segs.join(' ');
        svg.innerHTML =
            '<defs>' +
            '<pattern id="hiwWalkTile" width="16" height="16" patternUnits="userSpaceOnUse" patternTransform="rotate(22)">' +
            '<rect width="16" height="16" fill="#e4e9ef"/>' +
            '<path d="M0 16 H16 M16 0 V16" stroke="#c5ced8" stroke-width="0.8" opacity="0.65"/>' +
            '</pattern>' +
            '<filter id="hiwWalkShadow" x="-20%" y="-20%" width="140%" height="160%">' +
            '<feDropShadow dx="0" dy="1.5" stdDeviation="1.2" flood-color="#0f172a" flood-opacity="0.18"/>' +
            '</filter>' +
            '</defs>' +
            '<path class="hiw-path-base" d="' + d + '" filter="url(#hiwWalkShadow)" />' +
            '<path class="hiw-path-tile" d="' + d + '" />' +
            '<path class="hiw-path-edge" d="' + d + '" />' +
            '<path class="hiw-path-top" d="' + d + '" />';
    }

    function findWardCard(board, name) {
        var cards = board.querySelectorAll('.hiw-ward');
        for (var i = 0; i < cards.length; i++) {
            if ((cards[i].getAttribute('data-ward') || '') === name) return cards[i];
        }
        return null;
    }

    function ambulanceHtml() {
        return '<div class="hiw-amb">' + spriteHtml('amb', 'hiw-sprite-amb') + '</div>';
    }

    function healthyRunnerHtml() {
        return '<div class="hiw-runner">' + spriteHtml('patient', 'hiw-sprite-dc') + '</div>';
    }

    /** สร้าง snapshot + หาหอที่ admit/dc เพิ่มขึ้นจากรอบก่อน */
    function diffNewWardEvents(wards) {
        var snap = {};
        var admitNew = [];
        var dcNew = [];
        (wards || []).forEach(function (w) {
            var name = String(w.wardname || '');
            if (!name) return;
            var admit = +w.admit || 0;
            var dc = +w.discharge || 0;
            snap[name] = { admit: admit, discharge: dc };
            if (!prevWardSnap) return; /* รอบแรกไม่เล่น FX — รอ refresh ที่ตัวเลขเพิ่ม */
            var prev = prevWardSnap[name] || { admit: 0, discharge: 0 };
            if (admit > prev.admit) {
                admitNew.push({
                    wardname: name,
                    admit: admit,
                    delta: admit - prev.admit
                });
            }
            if (dc > prev.discharge) {
                dcNew.push({
                    wardname: name,
                    discharge: dc,
                    delta: dc - prev.discharge
                });
            }
        });
        prevWardSnap = snap;
        admitNew.sort(function (a, b) { return b.delta - a.delta; });
        dcNew.sort(function (a, b) { return b.delta - a.delta; });
        return {
            admitNew: admitNew.slice(0, MAX_ADMIT_FX),
            dcNew: dcNew.slice(0, MAX_DC_FX)
        };
    }

    function playOnceThenRemove(node, ms) {
        if (!node) return;
        var done = false;
        var finish = function () {
            if (done) return;
            done = true;
            if (node.parentNode) node.parentNode.removeChild(node);
        };
        node.addEventListener('animationend', finish);
        setTimeout(finish, ms || 14000);
    }

    /**
     * รถพยาบาล / คนออก D/C — เล่นครั้งเดียวเฉพาะเมื่อ refresh แล้วตัวเลขเพิ่ม
     * (ไม่ loop และไม่เล่นตอนโหลดครั้งแรก)
     */
    function scheduleWardTrafficFx(stage, board, wards, fxLayer) {
        if (!stage || !board || !fxLayer || !wards || !wards.length) return;
        var events = diffNewWardEvents(wards);
        if (!events.admitNew.length && !events.dcNew.length) return;
        if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

        var run = function () {
            if (!document.body.contains(stage)) return;
            var stageRect = stage.getBoundingClientRect();
            if (stageRect.width < 40) return;
            fxLayer.innerHTML = '';

            events.admitNew.forEach(function (w, i) {
                var card = findWardCard(board, w.wardname || '');
                if (!card) return;
                var cr = card.getBoundingClientRect();
                var x = Math.round(cr.left - stageRect.left + cr.width * 0.35);
                var amb = el('div', 'hiw-fx hiw-fx-amb is-once');
                amb.style.setProperty('--fx-x', x + 'px');
                amb.style.animationDelay = (i * 1.6) + 's';
                amb.innerHTML = ambulanceHtml() +
                    '<div class="hiw-fx-bubble is-admit">Admit ใหม่ +' + esc(w.delta) +
                    ' · ' + esc(w.wardname) + '</div>';
                fxLayer.appendChild(amb);
                playOnceThenRemove(amb, 12000 + i * 1600);
            });

            events.dcNew.forEach(function (w, i) {
                var card = findWardCard(board, w.wardname || '');
                if (!card) return;
                var cr = card.getBoundingClientRect();
                var x = Math.round(cr.left - stageRect.left + cr.width * 0.4);
                var yFrom = Math.max(70, Math.round(stageRect.bottom - cr.bottom + 8));
                var runner = el('div', 'hiw-fx hiw-fx-dc is-once');
                runner.style.setProperty('--fx-x', x + 'px');
                runner.style.setProperty('--fx-y', yFrom + 'px');
                runner.style.animationDelay = (0.8 + i * 1.5) + 's';
                runner.innerHTML = healthyRunnerHtml() +
                    '<div class="hiw-fx-bubble is-dc">D/C +' + esc(w.delta) +
                    ' · ' + esc(w.wardname) + '</div>';
                fxLayer.appendChild(runner);
                playOnceThenRemove(runner, 11000 + i * 1500);
            });
        };

        if (typeof requestAnimationFrame === 'function') {
            requestAnimationFrame(function () { requestAnimationFrame(run); });
        } else {
            setTimeout(run, 60);
        }
    }

    function renderError(msg) {
        root.innerHTML = '<div class="hiw-error"><i class="fas fa-exclamation-triangle me-1"></i>' +
            esc(msg || 'โหลดภาพรวมเตียงไม่สำเร็จ') + '</div>';
    }

    function load(force) {
        if (busy) return;
        if (document.visibilityState === 'hidden') return;
        busy = true;
        var url = apiUrl + (force ? '?force=1' : '');
        fetch(url, { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
            .then(function (r) {
                return r.text().then(function (text) {
                    var j = null;
                    try { j = JSON.parse(text); } catch (e) { j = null; }
                    if (!r.ok) throw new Error((j && j.msg) || ('HTTP ' + r.status));
                    if (!j) throw new Error('ตอบกลับไม่ใช่ JSON');
                    return j;
                });
            })
            .then(function (j) { applyPayload(j); })
            .catch(function (err) {
                if (!root.querySelector('.hiw-board')) {
                    renderError((err && err.message) ? err.message : 'โหลดภาพรวมเตียงไม่สำเร็จ');
                }
            })
            .finally(function () { busy = false; });
    }

    var boot = readBoot();
    if (boot) {
        applyPayload(boot);
    } else {
        root.innerHTML = '<div class="hiw-loading"><i class="fas fa-spinner fa-spin me-2"></i>กำลังโหลดภาพรวมเตียง...</div>';
        load(false);
    }
    timer = setInterval(function () { load(false); }, REFRESH_MS);

    document.addEventListener('visibilitychange', function () {
        setPaused(document.visibilityState === 'hidden');
        if (document.visibilityState === 'visible') load(false);
    });
    setPaused(document.visibilityState === 'hidden');

    window.addEventListener('resize', function () {
        if (pathResizeTimer) clearTimeout(pathResizeTimer);
        pathResizeTimer = setTimeout(function () {
            if (lastStage && lastBoard && document.body.contains(lastStage)) {
                drawCampusPaths(lastStage, lastBoard);
            }
        }, 120);
    });

    window.addEventListener('beforeunload', function () {
        if (timer) clearInterval(timer);
    });
})();
