/**
 * คำนวณยา Warfarin — lookup HN + INR + ปรับ % + แนะนำวิธีใช้
 */
(function () {
    'use strict';

    var inrState = { history: [], patientLabel: '', latest: null, message: '', maxAgeMonths: 6 };
    var inrChart = null;
    var lastItems = [];
    var guideState = {
        protocols: [],
        protocolId: 'inr_2_3',
        match: null,
        applying: false,
        hn: '',
        noteTimer: null
    };

    function showMsg(text, type) {
        var el = document.getElementById('wfMsg');
        if (!el) return;
        el.style.display = text ? '' : 'none';
        el.className = 'mt-2 small fw-bold text-' + (type || 'muted');
        el.textContent = text || '';
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    var wfPillSeq = 0;

    function wfPillTone(mg) {
        var n = Number(mg);
        if (Math.abs(n - 2) < 0.05) {
            return { fill: '#fb923c', stroke: '#c2410c', score: '#9a3412', label: '2 mg' };
        }
        if (Math.abs(n - 3) < 0.05) {
            return { fill: '#38bdf8', stroke: '#0369a1', score: '#0c4a6e', label: '3 mg' };
        }
        if (Math.abs(n - 5) < 0.05) {
            return { fill: '#f9a8d4', stroke: '#be185d', score: '#9d174d', label: '5 mg' };
        }
        return { fill: '#94a3b8', stroke: '#475569', score: '#334155', label: (n || '') + ' mg' };
    }

    function wfPillSvg(mg, half) {
        var t = wfPillTone(mg);
        var num = esc(t.label.replace(/\s*mg\s*/i, ''));
        var title = esc(t.label + (half ? ' ครึ่งเม็ด' : ' 1 เม็ด'));
        var txt = ' font-family="Sarabun, Tahoma, sans-serif" font-weight="800" fill="' + t.score + '" stroke="#fff" stroke-width="0.6" paint-order="stroke"';
        if (half) {
            wfPillSeq += 1;
            var id = 'wfClip' + wfPillSeq;
            return '<svg class="wf-pill" width="26" height="42" viewBox="0 0 24 40" role="img" aria-label="' + title + '">'
                + '<title>' + title + '</title>'
                + '<defs><clipPath id="' + id + '"><rect x="0" y="0" width="20" height="40"/></clipPath></defs>'
                + '<g clip-path="url(#' + id + ')">'
                + '<circle cx="20" cy="20" r="16.5" fill="' + t.fill + '" stroke="' + t.stroke + '" stroke-width="1.6"/>'
                + '</g>'
                + '<line x1="20" y1="4" x2="20" y2="36" stroke="' + t.score + '" stroke-width="1.5" stroke-linecap="round"/>'
                + '<text x="10.5" y="18" text-anchor="middle" font-size="8.5"' + txt + '>' + num + '</text>'
                + '<text x="10.5" y="27" text-anchor="middle" font-size="6"' + txt + '>mg</text>'
                + '</svg>';
        }
        return '<svg class="wf-pill" width="42" height="42" viewBox="0 0 40 40" role="img" aria-label="' + title + '">'
            + '<title>' + title + '</title>'
            + '<circle cx="20" cy="20" r="16.5" fill="' + t.fill + '" stroke="' + t.stroke + '" stroke-width="1.6"/>'
            + '<line x1="20" y1="4.5" x2="20" y2="35.5" stroke="' + t.score + '" stroke-width="1.5" stroke-linecap="round"/>'
            + '<text x="11.5" y="23.5" text-anchor="middle" font-size="9"' + txt + '>' + num + '</text>'
            + '<text x="28.5" y="23.5" text-anchor="middle" font-size="7"' + txt + '>mg</text>'
            + '</svg>';
    }

    function wfPillsHtml(pills) {
        if (!pills || !pills.length) {
            return '<span class="text-muted">ไม่ทาน</span>';
        }
        var html = '<span class="wf-pills">';
        var any = false;
        pills.forEach(function (p) {
            var tabs = Number(p.tabs) || 0;
            var str = Number(p.strength) || 0;
            if (tabs <= 0 || str <= 0) return;
            var full = Math.floor(tabs + 1e-6);
            var half = (tabs - full) >= 0.4;
            var i;
            for (i = 0; i < full; i++) {
                html += wfPillSvg(str, false);
                any = true;
            }
            if (half) {
                html += wfPillSvg(str, true);
                any = true;
            }
        });
        html += '</span>';
        return any ? html : '<span class="text-muted">ไม่ทาน</span>';
    }

    function inrTone(val) {
        if (val == null || isNaN(val)) return 'wf-inr-empty';
        if (val < 2) return 'wf-inr-warn';
        if (val > 3) return 'wf-inr-high';
        return 'wf-inr-ok';
    }

    function formatInr(val, raw) {
        if (val != null && !isNaN(val)) {
            return (Math.round(val * 100) / 100).toString();
        }
        return raw || '—';
    }

    function ensurePctOption(pct) {
        var sel = document.getElementById('wf_pct');
        if (!sel) return;
        var v = String(Math.round(pct));
        var found = false;
        Array.prototype.forEach.call(sel.options, function (o) {
            if (o.value === v) found = true;
        });
        if (!found) {
            var opt = document.createElement('option');
            opt.value = v;
            opt.textContent = v + '%';
            sel.appendChild(opt);
        }
        sel.value = v;
    }

    function fillProtocols(guidelines, preferredId) {
        var sel = document.getElementById('wf_protocol');
        if (!sel) return;
        var protocols = (guidelines && guidelines.protocols) ? guidelines.protocols : [];
        guideState.protocols = protocols;
        var cur = preferredId || sel.value || guideState.protocolId || 'inr_2_3';
        sel.innerHTML = '';
        protocols.forEach(function (p) {
            var opt = document.createElement('option');
            opt.value = p.id;
            opt.textContent = p.name + ' (Target ' + p.target_low + '-' + p.target_high + ')';
            sel.appendChild(opt);
        });
        if (!protocols.length) {
            var opt0 = document.createElement('option');
            opt0.value = 'inr_2_3';
            opt0.textContent = 'Target INR 2.0 - 3.0';
            sel.appendChild(opt0);
        }
        if (cur && Array.prototype.some.call(sel.options, function (o) { return o.value === cur; })) {
            sel.value = cur;
        }
        guideState.protocolId = sel.value;
        updateProtocolInd();
    }

    function updateProtocolInd() {
        var ind = document.getElementById('wf_protocol_ind');
        var sel = document.getElementById('wf_protocol');
        if (!ind || !sel) return;
        var p = null;
        (guideState.protocols || []).forEach(function (x) {
            if (x.id === sel.value) p = x;
        });
        ind.textContent = p && p.indication ? p.indication : '—';
    }

    function saveHnPref(fields, silent) {
        var hn = guideState.hn;
        if (!hn) return;
        var payload = { action: 'save_pref', hn: hn };
        Object.keys(fields || {}).forEach(function (k) { payload[k] = fields[k]; });
        fetch('fetch_warfarin_guideline_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.status === 'success' && res.data && res.data.protocol_id) {
                    guideState.protocolId = res.data.protocol_id;
                }
            })
            .catch(function () {});
    }

    function renderGuide(match) {
        var box = document.getElementById('wfGuideBox');
        var sum = document.getElementById('wfGuideSummary');
        var meta = document.getElementById('wfGuideMeta');
        if (!box || !sum) return;
        guideState.match = match || null;
        box.className = 'wf-guide-box';
        if (!match || !match.ok || !match.suggest) {
            sum.textContent = 'ยังไม่มีคำแนะนำ — ตรวจสอบ INR / แนวทาง';
            if (meta) meta.textContent = match && match.error ? match.error : '';
            return;
        }
        var s = match.suggest;
        sum.textContent = s.summary || s.note || '—';
        var bits = [];
        bits.push('INR ' + (match.inr != null ? match.inr : '—') + ' → ช่วง ' + ((match.row && match.row.inr_label) || '—'));
        if (s.pct_text) bits.push(s.pct_text);
        if (s.hold_text) bits.push(s.hold_text);
        if (s.extra_dose) bits.push('พิจารณา Extra dose 1 มื้อ');
        if (meta) meta.textContent = bits.join(' · ');
        if (s.in_target) box.classList.add('in-target');
        else if (match.inr != null && match.inr >= 4) box.classList.add('warn-high');
    }

    function applyGuideSuggest(match, autoCalc) {
        if (!match || !match.ok || !match.suggest) {
            renderGuide(match);
            return;
        }
        renderGuide(match);
        var s = match.suggest;
        guideState.applying = true;
        var dirEl = document.getElementById('wf_direction');
        var manual = document.getElementById('wf_target_manual');
        if (dirEl) {
            if (s.direction === 'hold') dirEl.value = 'hold';
            else if (s.direction === 'down') dirEl.value = 'down';
            else dirEl.value = 'up';
        }
        if (s.direction === 'hold') {
            ensurePctOption(0);
            if (manual) manual.value = '';
        } else {
            ensurePctOption(s.pct != null ? s.pct : 10);
            if (manual) manual.value = '';
        }
        guideState.applying = false;
        if (autoCalc && parseFloat(document.getElementById('wf_current').value) > 0) {
            recommend();
        }
    }

    function refreshGuideMatch(autoCalc) {
        var latest = inrState.latest;
        var protocolId = (document.getElementById('wf_protocol') || {}).value || guideState.protocolId || 'inr_2_3';
        guideState.protocolId = protocolId;
        updateProtocolInd();
        if (latest && latest.stale) {
            renderGuide({
                ok: false,
                error: 'ผล INR นานกว่า ' + (inrState.maxAgeMonths || 6) + ' เดือน — ประเมินไม่ได้'
            });
            return;
        }
        if (latest && latest.carried) {
            var carriedTh = latest.date_th ? ' (' + latest.date_th + ')' : '';
            renderGuide({
                ok: false,
                error: 'ใช้ผล Lab ก่อนหน้า' + carriedTh + ' ไม่ได้เจาะใหม่ — ประเมินไม่ได้'
            });
            return;
        }
        var inr = latest && latest.value != null ? latest.value : null;
        if (inr == null || isNaN(inr)) {
            renderGuide(null);
            return;
        }
        fetch('fetch_warfarin_guideline_api.php?action=match&inr=' + encodeURIComponent(inr) +
            '&protocol_id=' + encodeURIComponent(protocolId), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.status !== 'success') {
                    renderGuide({ ok: false, error: res.message || 'จับคู่ไม่สำเร็จ' });
                    return;
                }
                applyGuideSuggest(res.data, !!autoCalc);
            })
            .catch(function () {
                renderGuide({ ok: false, error: 'โหลด guideline ไม่สำเร็จ' });
            });
    }

    function onProtocolChange() {
        var sel = document.getElementById('wf_protocol');
        if (!sel) return;
        guideState.protocolId = sel.value || 'inr_2_3';
        if (guideState.hn) {
            saveHnPref({ protocol_id: guideState.protocolId }, true);
        }
        refreshGuideMatch(true);
        // ประเมินประวัติใหม่ตาม guideline ที่เลือก (ไม่เรียกซ้ำถ้ากำลัง lookup อยู่)
        if (guideState.hn && !guideState.lookingUp) {
            lookup();
        }
    }

    function formatPctChange(pct) {
        if (pct == null || isNaN(pct)) return '—';
        var n = Math.round(pct * 10) / 10;
        return (n > 0 ? '+' : '') + n + '%';
    }

    function renderHistory(hist) {
        var tbody = document.getElementById('wf_hist_tbody');
        var note = document.getElementById('wfHistNote');
        if (!tbody) return;
        hist = hist || {};
        var rows = hist.rows || [];
        if (note) {
            if (hist.message && !rows.length) {
                note.textContent = hist.message;
            } else if (rows.length) {
                var lim = hist.limit || 5;
                note.textContent = 'ย้อนหลัง ' + lim + ' ช่วง dose' +
                    (rows.length < lim ? ' (มีข้อมูล ' + rows.length + ' ช่วง)' : '') +
                    ' · ประเมินตาม guideline ที่เลือก' +
                    (hist.protocol_id ? ' (' + hist.protocol_id + ')' : '');
            } else {
                note.textContent = 'ค้นหา HN เพื่อดูประวัติ dose / INR / การปรับยา';
            }
        }
        if (!rows.length) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-muted text-center">' +
                esc(hist.message || 'ยังไม่มีข้อมูล') + '</td></tr>';
            return;
        }
        tbody.innerHTML = rows.map(function (r) {
            var inrCell = '—';
            if (r.inr != null && !isNaN(r.inr)) {
                inrCell = '<strong>' + esc(formatInr(r.inr, r.inr_raw)) + '</strong>';
                if (r.inr_date_th) {
                    inrCell += '<div class="small text-muted">' + esc(r.inr_date_th) + '</div>';
                }
                if (r.inr_stale) {
                    inrCell += '<div class="small text-danger">นานเกิน ' + esc(String(r.inr_max_age_months || 6)) + ' เดือน</div>';
                } else if (r.inr_carried) {
                    inrCell += '<div class="small text-warning">ผลก่อนหน้า (ไม่ได้เจาะใหม่)</div>';
                }
            } else if (r.inr_raw) {
                inrCell = esc(r.inr_raw);
            }
            var pctCell = formatPctChange(r.pct_change);
            if (r.prev_mg_week != null && r.mg_week != null) {
                pctCell += '<div class="small text-muted">' + esc(String(r.prev_mg_week)) +
                    ' → ' + esc(String(r.mg_week)) + '</div>';
            }
            var badge = r.assess_badge || 'secondary';
            var assess = '<span class="badge text-bg-' + esc(badge) + '">' + esc(r.assess_label || '—') + '</span>';
            var detail = esc(r.assess_detail || '');

            var qtyCell = '—';
            var methodCell = '—';
            var lines = r.lines || [];
            if (lines.length) {
                qtyCell = lines.map(function (ln) {
                    return esc(ln.qty_label || (ln.is_off ? '0 (OFF)' : '—'));
                }).join('<br>');
                methodCell = lines.map(function (ln) {
                    var m = esc(ln.method || '—');
                    if (ln.is_off) {
                        m += ' <span class="badge text-bg-secondary">OFF</span>';
                    }
                    return '<div class="mb-1">' + m + '</div>';
                }).join('');
            } else {
                if (r.qty_label) qtyCell = esc(r.qty_label);
                if (r.methods) methodCell = esc(r.methods);
            }

            return '<tr>' +
                '<td class="text-center">' + esc(r.date_th || r.date || '—') +
                (r.time_hm ? '<div class="small text-muted">' + esc(r.time_hm) + '</div>' : '') +
                (r.is_hme ? '<div class="small"><span class="badge text-bg-success">HME</span></div>' :
                    (r.source === 'ipd' ? '<div class="small text-danger">IPD</div>' : '')) + '</td>' +
                '<td class="text-center fw-bold">' + (r.is_off ? '—' : (r.mg_week != null ? esc(String(r.mg_week)) : '—')) +
                (r.is_off ? '<div class="small text-muted">OFF</div>' : '') + '</td>' +
                '<td class="text-center small">' + qtyCell + '</td>' +
                '<td class="text-start small">' + methodCell + '</td>' +
                '<td class="text-center">' + inrCell + '</td>' +
                '<td class="text-center fw-bold">' + pctCell + '</td>' +
                '<td class="text-center">' + assess + '</td>' +
                '<td class="small text-start">' + detail + '</td>' +
                '</tr>';
        }).join('');
    }

    function renderInr(inr, patient) {
        var btn = document.getElementById('wfInrBtn');
        var valEl = document.getElementById('wfInrVal');
        if (!btn || !valEl) return;

        inr = inr || {};
        inrState.history = inr.history || [];
        inrState.latest = inr.latest || null;
        inrState.message = inr.message || '';
        inrState.maxAgeMonths = inr.max_age_months || 6;
        inrState.patientLabel = (patient && (patient.hn || '')) +
            (patient && patient.ptname ? ' · ' + patient.ptname : '');

        btn.className = 'wf-inr-btn';
        btn.style.pointerEvents = '';
        btn.style.opacity = '';
        btn.removeAttribute('disabled');

        if (!inr.configured) {
            btn.classList.add('wf-inr-empty');
            valEl.textContent = 'ยังไม่ตั้งค่า';
            btn.title = inr.message || 'ตั้งค่ารหัส Lab INR ในตั้งค่าระบบก่อน';
            btn.onclick = function () {
                alert(inr.message || 'ยังไม่ได้ตั้งค่า Lab Code: INR');
            };
            return;
        }

        var latest = inr.latest;
        if (!latest) {
            btn.classList.add('wf-inr-empty');
            valEl.textContent = 'ไม่มีผล';
            btn.title = inr.message || 'ไม่พบผล INR';
            btn.onclick = openInrModal;
            return;
        }

        var num = latest.value;
        if (latest.stale) {
            btn.classList.add('wf-inr-warn');
            valEl.innerHTML = esc(formatInr(num, latest.raw)) +
                (latest.date_th ? '<span class="d-block" style="font-size:.7rem;font-weight:600;">' + esc(latest.date_th) + '</span>' : '');
            var staleTip = 'ผล INR นานกว่า ' + (inr.max_age_months || 6) + ' เดือน — ประเมินไม่ได้';
            if (latest.date_th) staleTip += ' (ลงวันที่ ' + latest.date_th + ')';
            btn.title = staleTip;
            btn.onclick = openInrModal;
            return;
        }
        if (latest.carried) {
            btn.classList.add('wf-inr-warn');
            valEl.innerHTML = esc(formatInr(num, latest.raw)) +
                (latest.date_th ? '<span class="d-block" style="font-size:.7rem;font-weight:600;">' + esc(latest.date_th) + '</span>' : '');
            var carriedTip = 'ใช้ผล Lab ก่อนหน้า ไม่ได้เจาะใหม่ — ประเมินไม่ได้';
            if (latest.date_th) carriedTip += ' (ลงวันที่ ' + latest.date_th + ')';
            btn.title = carriedTip;
            btn.onclick = openInrModal;
            return;
        }
        btn.classList.add(inrTone(num));
        valEl.innerHTML = esc(formatInr(num, latest.raw)) +
            (latest.date_th ? '<span class="d-block" style="font-size:.7rem;font-weight:600;">' + esc(latest.date_th) + '</span>' : '');
        var tip = 'INR ล่าสุด ' + formatInr(num, latest.raw);
        if (latest.date_th) tip += ' (' + latest.date_th + ')';
        tip += ' — คลิกดูกราฟย้อนหลัง';
        btn.title = tip;
        btn.onclick = openInrModal;
    }

    function openInrModal() {
        var sub = document.getElementById('wfInrModalSub');
        var tbody = document.getElementById('wfInrHistTbody');
        var hist = (inrState.history || []).slice();

        if (sub) {
            var latest = inrState.latest;
            var parts = [];
            if (inrState.patientLabel) parts.push(inrState.patientLabel);
            if (latest) {
                parts.push('ล่าสุด ' + formatInr(latest.value, latest.raw) +
                    (latest.date_th ? ' (' + latest.date_th + ')' : ''));
            } else if (inrState.message) {
                parts.push(inrState.message);
            }
            sub.textContent = parts.join(' · ') || '—';
        }

        if (tbody) {
            if (!hist.length) {
                tbody.innerHTML = '<tr><td colspan="3" class="text-muted">' +
                    esc(inrState.message || 'ไม่พบผล INR') + '</td></tr>';
            } else {
                tbody.innerHTML = hist.map(function (h) {
                    var tone = '';
                    if (h.value != null) {
                        if (h.value < 2) tone = 'text-warning fw-bold';
                        else if (h.value > 3) tone = 'text-danger fw-bold';
                        else tone = 'text-success fw-bold';
                    }
                    return '<tr><td>' + esc(h.date_th || h.order_date || '—') +
                        '</td><td class="' + tone + '">' + esc(formatInr(h.value, h.raw)) +
                        '</td><td class="small text-muted">' + esc(h.raw || '') + '</td></tr>';
                }).join('');
            }
        }

        var modalEl = document.getElementById('wfInrModal');
        if (modalEl && window.bootstrap && bootstrap.Modal) {
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        } else if (window.jQuery) {
            jQuery(modalEl).modal('show');
        }

        // Chart after modal visible (correct size)
        setTimeout(function () { drawInrChart(hist); }, 250);
    }

    function drawInrChart(hist) {
        var canvas = document.getElementById('wfInrChart');
        if (!canvas || typeof Chart === 'undefined') return;

        // oldest → newest for line chart
        var rows = (hist || []).slice().reverse().filter(function (h) {
            return h.value != null && !isNaN(h.value);
        });

        if (inrChart) {
            inrChart.destroy();
            inrChart = null;
        }

        if (!rows.length) {
            var ctx0 = canvas.getContext('2d');
            ctx0.clearRect(0, 0, canvas.width, canvas.height);
            return;
        }

        var labels = rows.map(function (h) { return h.date_th || h.order_date || ''; });
        var values = rows.map(function (h) { return h.value; });
        var pointColors = values.map(function (v) {
            if (v < 2) return '#d97706';
            if (v > 3) return '#dc2626';
            return '#16a34a';
        });

        inrChart = new Chart(canvas.getContext('2d'), {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'INR',
                    data: values,
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.12)',
                    pointBackgroundColor: pointColors,
                    pointBorderColor: pointColors,
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    borderWidth: 2,
                    fill: true,
                    tension: 0.25
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function (ctx) {
                                return 'INR: ' + ctx.parsed.y;
                            }
                        }
                    },
                    annotation: undefined
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        suggestedMax: Math.max(3.5, Math.ceil(Math.max.apply(null, values) * 10) / 10 + 0.5),
                        title: { display: true, text: 'INR' },
                        grid: {
                            color: function (ctx) {
                                var y = ctx.tick && ctx.tick.value;
                                if (y === 2 || y === 3) return 'rgba(22, 163, 74, 0.45)';
                                return 'rgba(0,0,0,0.06)';
                            }
                        }
                    },
                    x: {
                        ticks: { maxRotation: 45, minRotation: 0, autoSkip: true, maxTicksLimit: 12 }
                    }
                }
            }
        });
    }

    function setStrengthOptions(patientStrengths) {
        var box = document.getElementById('wf_strengths');
        if (!box) return;

        var defaults = [1, 2, 2.5, 3, 5];
        var fromVisit = [];
        (patientStrengths || []).forEach(function (s) {
            var v = parseFloat(s);
            if (v > 0 && fromVisit.indexOf(v) < 0) fromVisit.push(v);
        });
        fromVisit.sort(function (a, b) { return a - b; });

        var list = defaults.slice();
        fromVisit.forEach(function (s) {
            if (list.indexOf(s) < 0) list.push(s);
        });
        list.sort(function (a, b) { return a - b; });

        var selected = fromVisit.length ? fromVisit.slice() : [3];
        // ถ้าไม่มีจาก visit แต่เคยมี 5 เป็นค่ากลางของระบบเดิม — ใช้ 5
        if (!fromVisit.length) selected = [5];

        box.innerHTML = '';
        list.forEach(function (s) {
            var id = 'wf_str_' + String(s).replace('.', '_');
            var wrap = document.createElement('div');
            wrap.className = 'form-check form-check-inline';
            var inp = document.createElement('input');
            inp.className = 'form-check-input';
            inp.type = 'checkbox';
            inp.name = 'wf_strength_cb';
            inp.id = id;
            inp.value = String(s);
            inp.checked = selected.indexOf(s) >= 0;
            inp.addEventListener('change', function () {
                if (parseFloat(document.getElementById('wf_current').value) > 0) recommend();
            });
            var lab = document.createElement('label');
            lab.className = 'form-check-label';
            lab.htmlFor = id;
            lab.textContent = s + ' mg';
            wrap.appendChild(inp);
            wrap.appendChild(lab);
            box.appendChild(wrap);
        });
    }

    function getSelectedStrengths() {
        var box = document.getElementById('wf_strengths');
        if (!box) return [];
        var out = [];
        box.querySelectorAll('input[type="checkbox"]:checked').forEach(function (el) {
            var v = parseFloat(el.value);
            if (v > 0) out.push(v);
        });
        out.sort(function (a, b) { return a - b; });
        return out;
    }

    function renderItems(items) {
        var tbody = document.getElementById('wf_items_tbody');
        if (!tbody) return;
        if (!items || !items.length) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-danger">ไม่พบรายการ Warfarin ใน Visit ล่าสุด</td></tr>';
            return;
        }
        var html = '';
        items.forEach(function (it) {
            var name = it.drug_name_tmt || it.drug_name || '—';
            var orderDate = it.order_date_th || it.order_date || it.source_date || '—';
            html += '<tr>';
            html += '<td><strong>' + esc(name) + '</strong><div class="small text-muted">' + esc(it.icode || '');
            if (it.item_no) html += ' · #' + esc(it.item_no);
            html += '</div></td>';
            html += '<td>' + esc(it.strength || (it.strength_mg != null ? it.strength_mg + ' mg' : '—')) + '</td>';
            html += '<td class="small">' + esc(it.method || '—') + '</td>';
            html += '<td class="fw-bold">' + (it.mg_week != null ? it.mg_week : '—');
            if (it.mg_week_notes && it.mg_week_notes.length) {
                html += '<div class="small text-muted fw-normal">' + esc(it.mg_week_notes.join(' · ')) + '</div>';
            }
            html += '</td>';
            html += '<td class="fw-bold text-nowrap">' + esc(orderDate) + '</td>';
            html += '<td class="small">' + esc(it.source_label || '') + '</td>';
            html += '</tr>';
        });
        tbody.innerHTML = html;
    }

    function renderSchedule(data) {
        document.getElementById('wf_target').textContent = data.target_mg_week != null ? data.target_mg_week : '—';
        var planned = data.adjust_pct;
        var plannedEl = document.getElementById('wf_adj_pct');
        if (plannedEl) {
            if (planned == null) plannedEl.textContent = '—';
            else plannedEl.textContent = (planned > 0 ? '+' : '') + planned;
        }
        document.getElementById('wf_actual').textContent = data.actual_mg_week != null ? data.actual_mg_week : '—';
        document.getElementById('wf_diff').textContent = data.diff_mg != null ? data.diff_mg : '—';
        document.getElementById('wf_method').textContent = data.method_text || '—';

        var actualPctEl = document.getElementById('wf_actual_pct');
        var noteEl = document.getElementById('wf_pct_note');
        var actualPct = data.actual_adjust_pct;
        if (actualPctEl) {
            if (actualPct == null || isNaN(actualPct)) {
                actualPctEl.textContent = '—';
            } else {
                actualPctEl.textContent = (actualPct > 0 ? '+' : '') + actualPct;
            }
        }
        if (noteEl) {
            var cur = data.current_mg_week;
            var act = data.actual_mg_week;
            if (cur != null && act != null) {
                var dir = (actualPct > 0) ? 'เพิ่ม' : ((actualPct < 0) ? 'ลด' : 'เท่าเดิม');
                noteEl.textContent = dir + ' จาก ' + cur + ' → ' + act + ' mg/สัปดาห์';
            } else {
                noteEl.textContent = 'ค่าบวก = เพิ่ม / ค่าลบ = ลด';
            }
        }

        var chips = document.getElementById('wf_day_chips');
        var tbody = document.getElementById('wf_sched_tbody');
        var sched = data.schedule || [];
        if (!sched.length) {
            if (chips) chips.innerHTML = '';
            if (tbody) tbody.innerHTML = '<tr><td colspan="4" class="text-muted">—</td></tr>';
            return;
        }
        if (chips) {
            chips.innerHTML = sched.map(function (d) {
                var pills = d.pills || [];
                var icons = wfPillsHtml(pills);
                return '<span class="wf-day-chip"><strong>' + esc(d.day) + '</strong>'
                    + icons
                    + '<span class="wf-day-mg">' + esc(d.mg) + ' mg</span></span>';
            }).join('');
        }
        if (tbody) {
            tbody.innerHTML = sched.map(function (d) {
                var label = d.pills_label || d.tabs;
                return '<tr><td>' + esc(d.day) + '</td>'
                    + '<td class="small">' + esc(label) + '</td>'
                    + '<td class="wf-sched-pills">' + wfPillsHtml(d.pills || []) + '</td>'
                    + '<td>' + d.mg + '</td></tr>';
            }).join('');
        }
    }

    function lookup() {
        var hn = (document.getElementById('wf_hn').value || '').trim();
        if (!hn) {
            alert('กรุณากรอก HN');
            return;
        }
        showMsg('กำลังค้นหา...', 'muted');
        guideState.lookingUp = true;
        var protocolId = (document.getElementById('wf_protocol') || {}).value || guideState.protocolId || '';
        var url = 'fetch_warfarin_api.php?action=lookup&hn=' + encodeURIComponent(hn);
        if (protocolId) {
            url += '&protocol_id=' + encodeURIComponent(protocolId);
        }
        fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.status !== 'success') {
                    showMsg(res.message || 'ค้นหาไม่สำเร็จ', 'danger');
                    renderHistory({ rows: [], message: res.message || 'ค้นหาไม่สำเร็จ' });
                    return;
                }
                var d = res.data || {};
                var p = d.patient || {};
                var visitLabel = (p.visit_date_th || (d.visit && d.visit.vstdate_th) || '');
                var visitSrc = (d.visit && d.visit.label) ? d.visit.label : '';
                var typeBadge = (p.visit_type === 'ipd')
                    ? ' · <span class="badge text-bg-danger">IPD' + (p.an ? ' AN ' + esc(p.an) : '') + '</span>'
                    : '';
                document.getElementById('wfPatientInfo').innerHTML =
                    '<strong class="text-success">' + esc(p.hn || hn) + '</strong> · ' +
                    esc(p.ptname || '—') +
                    (d.has_warfarin ? ' · <span class="badge text-bg-success">พบ Warfarin</span>' :
                        ' · <span class="badge text-bg-warning text-dark">ไม่พบ Warfarin</span>') +
                    typeBadge +
                    (visitSrc ? ' · <span class="badge text-bg-primary">' + esc(visitSrc) + '</span>' :
                        (visitLabel ? ' · <span class="badge text-bg-primary">Visit ' + esc(visitLabel) + '</span>' : ''));

                renderInr(d.inr || {}, p);
                lastItems = d.items || [];
                renderItems(lastItems);
                setStrengthOptions(d.tablet_strengths || []);

                guideState.hn = p.hn || hn;
                var pref = d.hn_pref || {};
                guideState.protocolId = pref.protocol_id || protocolId || 'inr_2_3';

                fillProtocols(d.guidelines || {}, guideState.protocolId);
                if (d.mg_week_total != null) {
                    document.getElementById('wf_current').value = d.mg_week_total;
                }
                renderHistory(d.therapy_history || {});
                showMsg(d.has_warfarin
                    ? ((visitSrc || ('Visit ล่าสุด' + (visitLabel ? ' ' + visitLabel : ''))) +
                        ' · พบ ' + (d.items || []).length + ' รายการ · รวมประมาณ ' +
                        (d.mg_week_total != null ? d.mg_week_total : '—') + ' mg/สัปดาห์')
                    : 'ไม่พบ Warfarin — กรอก dose เดิมด้วยตนเองได้',
                    d.has_warfarin ? 'success' : 'warning');

                refreshGuideMatch(d.mg_week_total != null);
            })
            .catch(function (err) {
                showMsg(err.message || 'เชื่อมต่อไม่สำเร็จ', 'danger');
                renderHistory({ rows: [], message: 'โหลดประวัติไม่สำเร็จ' });
            })
            .then(function () {
                guideState.lookingUp = false;
            });
    }

    function recommend() {
        var current = parseFloat(document.getElementById('wf_current').value);
        var pct = parseFloat(document.getElementById('wf_pct').value);
        var direction = document.getElementById('wf_direction').value;
        var strengths = getSelectedStrengths();
        var manual = document.getElementById('wf_target_manual').value;
        if (!strengths.length) {
            alert('กรุณาเลือกความแรงเม็ดปรับอย่างน้อย 1 ค่า');
            return;
        }
        var payload = {
            action: 'recommend',
            current_mg_week: current,
            pct: pct,
            direction: direction,
            strengths: strengths,
            baseline_items: lastItems || []
        };
        if (manual !== '' && !isNaN(parseFloat(manual))) {
            payload.target_mg_week = parseFloat(manual);
        }
        if (!(current > 0) && !(payload.target_mg_week > 0)) {
            alert('กรุณาระบุ dose เดิม (mg/สัปดาห์)');
            return;
        }
        fetch('fetch_warfarin_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.status !== 'success') {
                    showMsg(res.message || 'คำนวณไม่สำเร็จ', 'danger');
                    return;
                }
                renderSchedule(res.data || {});
                showMsg('คำนวณแล้ว · แนะนำ ' + (res.data.actual_mg_week || '—') + ' mg/สัปดาห์', 'success');
            })
            .catch(function (err) {
                showMsg(err.message || 'เชื่อมต่อไม่สำเร็จ', 'danger');
            });
    }

    document.addEventListener('DOMContentLoaded', function () {
        var btnL = document.getElementById('wfBtnLookup');
        var btnC = document.getElementById('wfBtnCalc');
        var hn = document.getElementById('wf_hn');
        var proto = document.getElementById('wf_protocol');
        setStrengthOptions([]);
        fillProtocols({ protocols: [] }, 'inr_2_3');
        fetch('fetch_warfarin_guideline_api.php?action=get', { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.status === 'success') fillProtocols(res.data || {}, 'inr_2_3');
            })
            .catch(function () {});
        if (btnL) btnL.addEventListener('click', lookup);
        if (btnC) btnC.addEventListener('click', recommend);
        if (proto) {
            proto.addEventListener('change', onProtocolChange);
        }
        if (hn) {
            hn.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    lookup();
                }
            });
        }
        ['wf_direction', 'wf_pct', 'wf_current', 'wf_target_manual'].forEach(function (id) {
            var el = document.getElementById(id);
            if (!el) return;
            el.addEventListener('change', function () {
                if (guideState.applying) return;
                if (parseFloat(document.getElementById('wf_current').value) > 0) recommend();
            });
        });
        if ((hn.value || '').trim()) {
            lookup();
        }
    });
})();
