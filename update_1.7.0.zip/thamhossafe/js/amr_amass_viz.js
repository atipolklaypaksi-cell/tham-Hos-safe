(function (global) {
    const COLORS = ['#0d9488', '#f59e0b', '#6366f1', '#ef4444', '#14b8a6', '#8b5cf6'];
    if (typeof Chart !== 'undefined') {
        Chart.defaults.font.family = 'Helvetica, Arial, sans-serif';
        Chart.defaults.font.size = 11;
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function num(v) {
        if (v === '' || v == null || isNaN(Number(v))) {
            return null;
        }
        return Number(v);
    }

    function unique(values) {
        const seen = {};
        const out = [];
        (values || []).forEach(function (v) {
            if (!v || seen[v]) {
                return;
            }
            seen[v] = true;
            out.push(v);
        });
        return out;
    }

    function isTotalRow(r) {
        const keys = ['Organism', 'drug_name', 'Antibiotic', 'Month', 'AWaRe_classification',
            'Department', 'Route_of_administration', 'Antifungal', 'Indicators', 'Description', 'AMR_pathogen'];
        for (let i = 0; i < keys.length; i++) {
            const v = String(r[keys[i]] || '');
            if (v === 'Total:' || v === 'Total') {
                return true;
            }
        }
        return false;
    }

    function parsePct(v) {
        if (v == null || v === '') {
            return null;
        }
        if (typeof v === 'number') {
            return v;
        }
        const s = String(v).trim();
        if (s === 'NA') {
            return null;
        }
        const m = s.match(/-?[\d.]+/);
        return m ? Number(m[0]) : null;
    }

    function shortMonth(s) {
        return String(s || '')
            .replace('January', 'Jan').replace('February', 'Feb').replace('March', 'Mar')
            .replace('April', 'Apr').replace('May', 'May').replace('June', 'Jun')
            .replace('July', 'Jul').replace('August', 'Aug').replace('September', 'Sep')
            .replace('October', 'Oct').replace('November', 'Nov').replace('December', 'Dec');
    }

    const ANNEX_B_LABELS = {
        'blood_culture_contamination_rate': 'ปนเปื้อนเลือด',
        'proportion_of_notifiable_antibiotic-pathogen_combinations': 'AMR ที่ต้องรายงาน',
        'proportion_of_potential_errors_in_the_AST_results': 'AST ผิดปกติ',
        'blood_culture_contamination_rate_among_inpatients': 'ปนเปื้อน (ผู้ป่วยใน)'
    };

    function pickValueKey(kind, rows) {
        if (kind === 'pct' || kind === 'pct_origin') {
            return 'Non-susceptible(%)';
        }
        if (kind === 'mort_origin') {
            return 'Mortality(%)';
        }
        if (kind === 'amu') {
            return 'prescriptions';
        }
        if (kind === 'annex_b') {
            return 'Proportion';
        }
        if (kind === 'annex_b_month') {
            return 'blood_culture_contamination_rate';
        }
        if (kind === 'annex_c_ward') {
            return 'Hospital_origin_isolates';
        }
        if (kind === 'annex_d_dot' || kind === 'annex_d_aware' || kind === 'annex_d_dept') {
            return 'DOT';
        }
        if (kind === 'annex_d_month') {
            return 'Number_of_antibiotic_records';
        }
        if (kind === 'annex_d_route') {
            return 'Number_of_antibiotic_records';
        }
        const first = rows[0] || {};
        if (first.frequency_per_tested !== undefined && first.frequency_per_tested !== '') {
            return 'frequency_per_tested';
        }
        return 'Incidence_per_100000_patient_days';
    }

    function axisTitle(kind, valueKey) {
        if (kind === 'pct' || kind === 'pct_origin') {
            return '%R';
        }
        if (kind === 'mort_origin') {
            return 'Mortality %';
        }
        if (kind === 'amu') {
            return 'ใบสั่ง';
        }
        if (kind === 'annex_b' || kind === 'annex_b_month') {
            return '%';
        }
        if (kind === 'annex_c_ward' || kind === 'annex_b_cont') {
            return 'isolate';
        }
        if (kind === 'annex_d_dot' || kind === 'annex_d_aware' || kind === 'annex_d_dept') {
            return 'DOT';
        }
        if (kind === 'annex_d_month' || kind === 'annex_d_route') {
            return 'รายการ';
        }
        return valueKey === 'frequency_per_tested' ? 'ต่อ 100,000 tested' : 'ต่อ 100,000 pt-days';
    }

    function isPctKind(kind) {
        return kind === 'pct' || kind === 'pct_origin' || kind === 'mort_origin'
            || kind === 'annex_b' || kind === 'annex_b_month';
    }

    function findRow(rows, pred) {
        for (let i = 0; i < rows.length; i++) {
            if (pred(rows[i])) {
                return rows[i];
            }
        }
        return null;
    }

    function groupPlans(kind, rows, orgFilter) {
        const filtered = rows.filter(function (r) {
            if (isTotalRow(r)) {
                return false;
            }
            if (!orgFilter) {
                return true;
            }
            if (kind === 'amu' || kind === 'annex_d_dot' || kind === 'annex_b' || kind === 'annex_b_month' || kind === 'annex_b_cont'
                || kind === 'annex_d_aware' || kind === 'annex_d_dept' || kind === 'annex_d_month' || kind === 'annex_d_route') {
                return true;
            }
            if (kind === 'annex_c_ward') {
                return (r.AMR_pathogen || '') === orgFilter;
            }
            return (r.Organism || '') === orgFilter;
        });

        if (kind === 'pct') {
            return unique(filtered.map(function (r) { return r.Organism; })).map(function (org) {
                const orgRows = filtered.filter(function (r) { return r.Organism === org; });
                return {
                    title: org,
                    labels: orgRows.map(function (r) { return r.Antibiotic || ''; }),
                    rows: orgRows,
                    datasets: [{
                        label: '%R',
                        data: orgRows.map(function (r) { return num(r['Non-susceptible(%)']); })
                    }]
                };
            });
        }

        if (kind === 'pct_origin') {
            return unique(filtered.map(function (r) { return r.Organism; })).map(function (org) {
                const orgRows = filtered.filter(function (r) { return r.Organism === org; });
                const drugs = unique(orgRows.map(function (r) { return r.Antibiotic; }));
                const origins = ['Community-origin', 'Hospital-origin'];
                return {
                    title: org,
                    labels: drugs,
                    rows: orgRows,
                    datasets: origins.map(function (origin) {
                        return {
                            label: origin,
                            origin: origin,
                            data: drugs.map(function (drug) {
                                const row = findRow(orgRows, function (r) {
                                    return r.Antibiotic === drug && r.Infection_origin === origin;
                                });
                                return row ? num(row['Non-susceptible(%)']) : null;
                            })
                        };
                    })
                };
            });
        }

        if (kind === 'mort_origin') {
            const orgs = unique(filtered.map(function (r) { return r.Organism; }));
            const origins = ['Community-origin', 'Hospital-origin'];
            return [{
                title: '',
                labels: orgs,
                rows: filtered,
                datasets: origins.map(function (origin) {
                    return {
                        label: origin,
                        origin: origin,
                        data: orgs.map(function (org) {
                            const row = findRow(filtered, function (r) {
                                return r.Organism === org && r.Infection_origin === origin;
                            });
                            return row ? num(row['Mortality(%)']) : null;
                        })
                    };
                })
            }];
        }

        if (kind === 'amu') {
            return [{
                title: '',
                labels: filtered.map(function (r) { return r.drug_name || ''; }),
                rows: filtered,
                datasets: [{
                    label: 'ใบสั่ง',
                    data: filtered.map(function (r) { return num(r.prescriptions); })
                }]
            }];
        }

        if (kind === 'annex_b') {
            return [{
                title: '',
                labels: filtered.map(function (r) {
                    return ANNEX_B_LABELS[r.Indicators] || r.Description || r.Indicators || '';
                }),
                rows: filtered,
                datasets: [{
                    label: '%',
                    data: filtered.map(function (r) {
                        const p = parsePct(r.Proportion);
                        if (p != null) {
                            return p;
                        }
                        const n = num(r.Number);
                        const d = num(r.Denominator);
                        return (n != null && d) ? Math.round((n / d) * 1000) / 10 : null;
                    })
                }]
            }];
        }

        if (kind === 'annex_b_month') {
            return [{
                title: '',
                indexAxis: 'x',
                labels: filtered.map(function (r) { return shortMonth(r.Month); }),
                rows: filtered,
                datasets: [
                    { label: 'ปนเปื้อน', data: filtered.map(function (r) { return parsePct(r.blood_culture_contamination_rate); }) },
                    { label: 'AMR ที่ต้องรายงาน', data: filtered.map(function (r) { return parsePct(r.notifiable_antibiotic_pathogen); }) },
                    { label: 'AST ผิดปกติ', data: filtered.map(function (r) { return parsePct(r.potential_AST_errors); }) }
                ]
            }];
        }

        if (kind === 'annex_c_ward') {
            const sorted = filtered.slice().sort(function (a, b) {
                return (num(b.Hospital_origin_isolates) || 0) - (num(a.Hospital_origin_isolates) || 0);
            });
            return [{
                title: '',
                labels: sorted.map(function (r) {
                    return (r.AMR_pathogen || '') + ' · ' + (r.Ward || '');
                }),
                rows: sorted,
                datasets: [{
                    label: 'isolate',
                    data: sorted.map(function (r) { return num(r.Hospital_origin_isolates); })
                }]
            }];
        }

        if (kind === 'annex_d_dot') {
            return [{
                title: '',
                labels: filtered.map(function (r) { return r.Antibiotic || ''; }),
                rows: filtered,
                datasets: [{
                    label: 'DOT',
                    data: filtered.map(function (r) { return num(r.DOT); })
                }]
            }];
        }

        if (kind === 'annex_d_aware') {
            return [{
                title: '',
                indexAxis: 'x',
                labels: filtered.map(function (r) { return r.AWaRe_classification || ''; }),
                rows: filtered,
                datasets: [{
                    label: 'DOT',
                    data: filtered.map(function (r) { return num(r.DOT); })
                }]
            }];
        }

        if (kind === 'annex_d_dept') {
            return [{
                title: '',
                indexAxis: 'x',
                labels: filtered.map(function (r) { return r.Department || ''; }),
                rows: filtered,
                datasets: [{
                    label: 'DOT',
                    data: filtered.map(function (r) { return num(r.DOT); })
                }]
            }];
        }

        if (kind === 'annex_d_month') {
            return [{
                title: '',
                indexAxis: 'x',
                labels: filtered.map(function (r) { return shortMonth(r.Month); }),
                rows: filtered,
                datasets: [
                    { label: 'ยาปฏิชีวนะ', data: filtered.map(function (r) { return num(r.Number_of_antibiotic_records); }) },
                    { label: 'ยาต้านเชื้อรา', data: filtered.map(function (r) { return num(r.Number_of_antifungal_records); }) }
                ]
            }];
        }

        if (kind === 'annex_d_route') {
            const withData = filtered.filter(function (r) {
                return (num(r.Number_of_antibiotic_records) || 0) + (num(r.Number_of_antifungal_records) || 0) > 0;
            });
            return [{
                title: '',
                labels: withData.map(function (r) { return r.Route_of_administration || ''; }),
                rows: withData,
                datasets: [
                    { label: 'ยาปฏิชีวนะ', data: withData.map(function (r) { return num(r.Number_of_antibiotic_records); }) },
                    { label: 'ยาต้านเชื้อรา', data: withData.map(function (r) { return num(r.Number_of_antifungal_records); }) }
                ]
            }];
        }

        if (kind === 'annex_b_cont') {
            return [{
                title: '',
                labels: filtered.map(function (r) { return r.Organism || ''; }),
                rows: filtered,
                datasets: [{
                    label: 'isolate',
                    data: filtered.map(function (r) { return num(r.Number_of_possible_contaminants); })
                }]
            }];
        }

        const valueKey = pickValueKey(kind, filtered);
        return [{
            title: '',
            labels: filtered.map(function (r) { return r.Organism || ''; }),
            rows: filtered,
            valueKey: valueKey,
            datasets: [{
                label: axisTitle(kind, valueKey),
                data: filtered.map(function (r) { return num(r[valueKey]); })
            }]
        }];
    }

    function detailHtml(kind, row) {
        if (!row) {
            return '';
        }
        if (kind === 'pct' || kind === 'pct_origin') {
            return '<div class="pair mb-1">' + esc(row.Organism) + ' · ' + esc(row.Antibiotic)
                + (row.Infection_origin ? ' · ' + esc(row.Infection_origin) : '') + '</div>'
                + '<div class="num fw-bold">' + esc(row['Non-susceptible(%)']) + '%</div>'
                + '<div class="text-muted">R/n ' + esc(row['Non-susceptible(N)']) + '/' + esc(row['Total(N)'])
                + ' · 95% CI ' + esc(row['lower95CI(%)*']) + '–' + esc(row['upper95CI(%)*']) + '</div>';
        }
        if (kind === 'mort_origin') {
            return '<div class="pair mb-1">' + esc(row.Organism) + ' · ' + esc(row.Infection_origin || '') + '</div>'
                + '<div class="num fw-bold">' + esc(row['Mortality(%)']) + '%</div>'
                + '<div class="text-muted">เสียชีวิต ' + esc(row.Number_of_deaths) + ' / ผู้ป่วย ' + esc(row.Total_number_of_patients) + '</div>';
        }
        if (kind === 'amu') {
            return '<div class="pair mb-1">' + esc(row.drug_name) + '</div>'
                + '<div class="num fw-bold">' + esc(row.prescriptions) + ' ใบสั่ง</div>';
        }
        if (kind === 'annex_b') {
            return '<div class="pair mb-1">' + esc(ANNEX_B_LABELS[row.Indicators] || row.Description || '') + '</div>'
                + '<div class="num fw-bold">' + esc(row.Proportion) + '</div>'
                + '<div class="text-muted">' + esc(row.Number) + ' / ' + esc(row.Denominator) + '</div>';
        }
        if (kind === 'annex_b_month') {
            return '<div class="pair mb-1">' + esc(row.Month) + '</div>'
                + '<div class="text-muted">ปนเปื้อน ' + esc(row.blood_culture_contamination_rate)
                + ' · AMR ' + esc(row.notifiable_antibiotic_pathogen)
                + ' · AST ' + esc(row.potential_AST_errors) + '</div>'
                + '<div class="text-muted">เลือด ' + esc(row['Total_blood_positive_and_negative(N)'])
                + ' · มี AST ' + esc(row['Total_blood_positive_AST(N)']) + '</div>';
        }
        if (kind === 'annex_c_ward') {
            return '<div class="pair mb-1">' + esc(row.AMR_pathogen) + ' · ' + esc(row.Organism) + '</div>'
                + '<div class="num fw-bold">' + esc(row.Hospital_origin_isolates) + ' isolate</div>'
                + '<div class="text-muted">วอร์ด ' + esc(row.Ward) + '</div>';
        }
        if (kind === 'annex_d_dot') {
            return '<div class="pair mb-1">' + esc(row.Antibiotic) + ' · ' + esc(row.AWaRe_classification || '') + '</div>'
                + '<div class="num fw-bold">' + esc(row.DOT_percent_text || row.DOT) + '</div>'
                + '<div class="text-muted">DOT ' + esc(row.DOT) + ' · ต่อพัน pt-days ' + esc(row.DOT_per1000patient_days) + '</div>';
        }
        if (kind === 'annex_d_aware') {
            return '<div class="pair mb-1">' + esc(row.AWaRe_classification) + '</div>'
                + '<div class="num fw-bold">' + esc(row.DOT_percent_text || row.DOT) + '</div>'
                + '<div class="text-muted">DOT ' + esc(row.DOT) + ' · ต่อพัน pt-days ' + esc(row.DOT_per1000patient_days) + '</div>';
        }
        if (kind === 'annex_d_dept') {
            return '<div class="pair mb-1">' + esc(row.Department) + '</div>'
                + '<div class="num fw-bold">' + esc(row.DOT_percent_text || row.DOT) + '</div>'
                + '<div class="text-muted">DOT ' + esc(row.DOT) + ' · ต่อพัน pt-days ' + esc(row.DOT_per1000patient_days) + '</div>';
        }
        if (kind === 'annex_d_month') {
            return '<div class="pair mb-1">' + esc(row.Month) + '</div>'
                + '<div class="text-muted">ยาปฏิชีวนะ ' + esc(row.Number_of_antibiotic_records)
                + ' · ยาต้านเชื้อรา ' + esc(row.Number_of_antifungal_records)
                + ' · รวม ' + esc(row.Number_of_drug_records) + '</div>';
        }
        if (kind === 'annex_d_route') {
            return '<div class="pair mb-1">' + esc(row.Route_of_administration) + '</div>'
                + '<div class="text-muted">ยาปฏิชีวนะ ' + esc(row.Number_of_antibiotic_records)
                + ' · ยาต้านเชื้อรา ' + esc(row.Number_of_antifungal_records) + '</div>';
        }
        if (kind === 'annex_b_cont') {
            return '<div class="pair mb-1">' + esc(row.Organism) + '</div>'
                + '<div class="num fw-bold">' + esc(row.Number_of_possible_contaminants) + '</div>'
                + '<div class="text-muted">' + esc(row.Percent_of_contaminants) + '% ของเชื้อปนเปื้อน</div>';
        }
        const rate = row.frequency_per_tested != null && row.frequency_per_tested !== ''
            ? row.frequency_per_tested
            : row.Incidence_per_100000_patient_days;
        const ci = (row.frequency_per_tested_lci != null && row.frequency_per_tested_lci !== '')
            ? (' · 95% CI ' + esc(row.frequency_per_tested_lci) + '–' + esc(row.frequency_per_tested_uci))
            : '';
        return '<div class="pair mb-1">' + esc(row.Organism) + (row.Infection_origin ? ' · ' + esc(row.Infection_origin) : '') + '</div>'
            + '<div class="num fw-bold">' + esc(rate) + '</div>'
            + '<div class="text-muted">ผู้ป่วย ' + esc(row.Number_of_patients)
            + (row.Tested_patients != null && row.Tested_patients !== '' ? ' / tested ' + esc(row.Tested_patients) : '')
            + (row.Patient_days != null && row.Patient_days !== '' ? ' · pt-days ' + esc(row.Patient_days) : '')
            + ci + '</div>';
    }

    function rowAtClick(kind, plan, dsIndex, index) {
        if (plan.rows && plan.rows[index] && !(plan.datasets[dsIndex] || {}).origin) {
            return plan.rows[index];
        }
        const ds = plan.datasets[dsIndex] || {};
        if (kind === 'pct') {
            return plan.rows[index] || null;
        }
        if (kind === 'pct_origin') {
            const drug = plan.labels[index];
            const origin = ds.origin;
            return findRow(plan.rows, function (r) {
                return r.Antibiotic === drug && r.Infection_origin === origin;
            });
        }
        if (kind === 'mort_origin') {
            const org = plan.labels[index];
            const origin = ds.origin;
            return findRow(plan.rows, function (r) {
                return r.Organism === org && r.Infection_origin === origin;
            });
        }
        return plan.rows[index] || null;
    }

    let compareCtx = null;
    const vizInstances = [];
    const MONTH_RANK = {
        January: 1, February: 2, March: 3, April: 4, May: 5, June: 6,
        July: 7, August: 8, September: 9, October: 10, November: 11, December: 12,
        Jan: 1, Feb: 2, Mar: 3, Apr: 4, Jun: 6, Jul: 7, Aug: 8, Sep: 9, Oct: 10, Nov: 11, Dec: 12
    };

    function monthRank(s) {
        const t = String(s || '').trim();
        if (MONTH_RANK[t]) {
            return MONTH_RANK[t];
        }
        const short = t.slice(0, 3);
        return MONTH_RANK[short] || 99;
    }

    function periodNum(row, i, alias) {
        const v = row['p' + i + '_' + alias];
        const n = num(v);
        return n != null ? n : parsePct(v);
    }

    function periodDatasets(rows, periods, alias) {
        return (periods || []).map(function (p, i) {
            return {
                label: p.label || ('ช่วง ' + (i + 1)),
                data: rows.map(function (r) { return periodNum(r, i, alias); }),
                periodIndex: i
            };
        });
    }

    function sortByP0(rows, alias) {
        alias = alias || 'val';
        return rows.slice().sort(function (a, b) {
            return (periodNum(b, 0, alias) || 0) - (periodNum(a, 0, alias) || 0);
        });
    }

    function groupPlansCompare(kind, rows, periods, orgFilter) {
        const filtered = (rows || []).filter(function (r) {
            if (isTotalRow(r)) {
                return false;
            }
            if (!orgFilter) {
                return true;
            }
            if (kind === 'annex_c_ward') {
                return (r.AMR_pathogen || '') === orgFilter;
            }
            return (r.Organism || '') === orgFilter;
        });
        function pack(list, labels, alias, indexAxis) {
            return [{
                title: '',
                indexAxis: indexAxis || 'y',
                labels: labels,
                rows: list,
                datasets: periodDatasets(list, periods, alias)
            }];
        }
        if (kind === 'pct' || kind === 'pct_origin') {
            return unique(filtered.map(function (r) { return r.Organism; })).map(function (org) {
                const orgRows = filtered.filter(function (r) { return r.Organism === org; });
                const labels = orgRows.map(function (r) {
                    if (kind === 'pct_origin' && r.Infection_origin) {
                        return (r.Antibiotic || '') + ' · ' + String(r.Infection_origin).replace('-origin', '');
                    }
                    return r.Antibiotic || '';
                });
                return {
                    title: org,
                    labels: labels,
                    rows: orgRows,
                    datasets: periodDatasets(orgRows, periods, 'pct')
                };
            });
        }
        if (kind === 'mort_origin') {
            return pack(filtered, filtered.map(function (r) {
                return (r.Organism || '') + (r.Infection_origin ? ' · ' + String(r.Infection_origin).replace('-origin', '') : '');
            }), 'val');
        }
        if (kind === 'annex_d_dot') {
            const sorted = sortByP0(filtered, 'val');
            return pack(sorted, sorted.map(function (r) { return r.Antibiotic || ''; }), 'val');
        }
        if (kind === 'annex_d_aware') {
            return pack(filtered, filtered.map(function (r) { return r.AWaRe_classification || ''; }), 'val', 'x');
        }
        if (kind === 'annex_d_dept') {
            const sorted = sortByP0(filtered, 'val');
            return pack(sorted, sorted.map(function (r) { return r.Department || ''; }), 'val', 'x');
        }
        if (kind === 'annex_d_month' || kind === 'annex_b_month') {
            const sorted = filtered.slice().sort(function (a, b) {
                return monthRank(a.Month) - monthRank(b.Month);
            });
            return pack(sorted, sorted.map(function (r) { return shortMonth(r.Month); }), 'val', 'x');
        }
        if (kind === 'annex_d_route') {
            return pack(filtered, filtered.map(function (r) { return r.Route_of_administration || ''; }), 'val');
        }
        if (kind === 'annex_b') {
            return pack(filtered, filtered.map(function (r) {
                return ANNEX_B_LABELS[r.Indicators] || r.Description || r.Indicators || '';
            }), 'val');
        }
        if (kind === 'annex_b_cont') {
            const sorted = sortByP0(filtered, 'val');
            return pack(sorted, sorted.map(function (r) { return r.Organism || ''; }), 'val');
        }
        if (kind === 'annex_c_ward') {
            const sorted = sortByP0(filtered, 'val');
            return pack(sorted, sorted.map(function (r) {
                return (r.AMR_pathogen || '') + ' · ' + (r.Ward || '');
            }), 'val');
        }
        if (kind === 'amu') {
            const sorted = sortByP0(filtered, 'val').slice(0, 20);
            return pack(sorted, sorted.map(function (r) { return r.drug_name || ''; }), 'val');
        }
        const sorted = sortByP0(filtered, 'val');
        return pack(sorted, sorted.map(function (r) { return r.Organism || r.Antibiotic || ''; }), 'val');
    }

    function compareDetailHtml(kind, row, periods) {
        if (!row || !periods) {
            return '';
        }
        const title = row.Antibiotic || row.Organism || row.drug_name || row.Department
            || row.AWaRe_classification || row.Route_of_administration || row.Month
            || row.AMR_pathogen || row.Indicators || row.Parameter || '';
        let html = '<div class="pair mb-1">' + esc(title)
            + (row.Infection_origin ? ' · ' + esc(row.Infection_origin) : '')
            + (row.Ward ? ' · ' + esc(row.Ward) : '') + '</div><div class="row g-2">';
        periods.forEach(function (p, i) {
            const alias = (kind === 'pct' || kind === 'pct_origin') ? 'pct' : 'val';
            const v = row['p' + i + '_' + alias];
            const extra = row['p' + i + '_per1000'] != null && row['p' + i + '_per1000'] !== ''
                ? (' · ต่อพัน ' + esc(row['p' + i + '_per1000']))
                : (row['p' + i + '_n'] != null && row['p' + i + '_n'] !== ''
                    ? (' · n ' + esc(row['p' + i + '_r'] || '') + '/' + esc(row['p' + i + '_n']))
                    : '');
            const d = i > 0 ? row['p' + i + '_delta'] : '';
            let delta = '';
            if (d !== '' && d != null) {
                const n = Number(d);
                const cls = n > 0 ? 'delta-up' : (n < 0 ? 'delta-down' : 'delta-zero');
                delta = ' <span class="' + cls + '">ต่าง ' + (n > 0 ? '+' : '') + esc(d) + '</span>';
            }
            html += '<div class="col-md-4"><div class="border rounded p-2">'
                + '<div class="text-muted">' + esc(p.label) + '</div>'
                + '<div class="num fw-bold">' + esc(v) + '</div>'
                + '<div class="small text-muted">' + extra + delta + '</div></div></div>';
        });
        return html + '</div>';
    }

    function compareTableHtml(kind, rows, periods, orgFilter) {
        const filtered = (rows || []).filter(function (r) {
            if (isTotalRow(r)) {
                return false;
            }
            if (!orgFilter) {
                return true;
            }
            if (kind === 'annex_c_ward') {
                return (r.AMR_pathogen || '') === orgFilter;
            }
            return (r.Organism || '') === orgFilter;
        });
        const alias = (kind === 'pct' || kind === 'pct_origin') ? 'pct' : 'val';
        let html = '<div class="table-responsive"><table class="table table-sm table-bordered amass-table mb-0"><thead><tr><th>รายการ</th>';
        periods.forEach(function (p, i) {
            html += '<th>' + esc(p.label) + '</th>';
            if (i > 0) {
                html += '<th>ต่าง</th>';
            }
        });
        html += '</tr></thead><tbody>';
        filtered.forEach(function (r) {
            const name = r.Antibiotic || r.Organism || r.drug_name || r.Department
                || r.AWaRe_classification || r.Route_of_administration || r.Month
                || ((r.AMR_pathogen || '') + (r.Ward ? ' · ' + r.Ward : ''))
                || r.Indicators || r.Parameter || '';
            html += '<tr><td>' + esc(name)
                + (r.Infection_origin ? ' <span class="text-muted">(' + esc(r.Infection_origin) + ')</span>' : '')
                + '</td>';
            periods.forEach(function (_p, i) {
                html += '<td class="num">' + esc(r['p' + i + '_' + alias]) + '</td>';
                if (i > 0) {
                    const d = r['p' + i + '_delta'];
                    html += '<td class="num">' + esc(d === '' || d == null ? '–' : ((Number(d) > 0 ? '+' : '') + d)) + '</td>';
                }
            });
            html += '</tr>';
        });
        html += '</tbody></table></div>';
        html += '<p class="small text-muted mt-2 mb-0">ต่าง = ค่าเทียบช่วงแรก</p>';
        return html;
    }

    function bind(root) {
        const dataEl = root.querySelector('.amass-viz-data');
        if (!dataEl || typeof Chart === 'undefined') {
            return;
        }
        let spec;
        try {
            spec = JSON.parse(dataEl.textContent);
        } catch (e) {
            return;
        }
        const kind = spec.kind || 'pct';
        const compareKey = spec.compare_key || kind;
        const rows = spec.rows || [];
        const state = { view: 'chart', org: '' };
        const chartObjs = [];
        const chartBtn = root.querySelector('.amass-viz-chart');
        const tableBtn = root.querySelector('.amass-viz-table');
        const orgsEl = root.querySelector('.amass-viz-orgs');
        const detailEl = root.querySelector('.amass-viz-detail');
        const chartsEl = root.querySelector('.amass-viz-charts');
        const tableEl = root.querySelector('.amass-viz-table-wrap');
        const originalTable = tableEl ? tableEl.innerHTML : '';
        const valueKey = pickValueKey(kind, rows);
        const xMax = isPctKind(kind) ? 100 : undefined;

        function activeCompare() {
            if (!compareCtx || !compareCtx.periods || compareCtx.periods.length < 2) {
                return null;
            }
            const list = compareCtx[compareKey];
            if (!list || !list.length) {
                return null;
            }
            return { periods: compareCtx.periods, rows: list };
        }

        function sourceRows() {
            const cmp = activeCompare();
            return cmp ? cmp.rows : rows;
        }

        function ensureHint() {
            let hint = root.querySelector('.amass-viz-compare-hint');
            if (!hint && chartsEl) {
                hint = document.createElement('div');
                hint.className = 'amass-viz-compare-hint small fw-bold mb-2';
                hint.style.color = '#0f766e';
                root.insertBefore(hint, chartsEl);
            }
            return hint;
        }

        function destroy() {
            chartObjs.splice(0).forEach(function (ch) {
                try { ch.destroy(); } catch (e) {}
            });
        }

        function showDetail(row) {
            if (!detailEl) {
                return;
            }
            const cmp = activeCompare();
            detailEl.innerHTML = cmp ? compareDetailHtml(kind, row, cmp.periods) : detailHtml(kind, row);
            detailEl.classList.toggle('d-none', !row);
        }

        function renderPills() {
            if (!orgsEl) {
                return;
            }
            if (kind !== 'pct' && kind !== 'pct_origin' && kind !== 'annex_c_ward') {
                orgsEl.classList.add('d-none');
                orgsEl.innerHTML = '';
                return;
            }
            const src = sourceRows();
            const orgs = kind === 'annex_c_ward'
                ? unique(src.map(function (r) { return r.AMR_pathogen; }))
                : unique(src.map(function (r) { return r.Organism; }));
            orgsEl.classList.remove('d-none');
            orgsEl.innerHTML = ['<button type="button" class="btn btn-sm btn-outline-success compare-org-btn' + (state.org === '' ? ' active' : '') + '" data-org="">ทั้งหมด</button>']
                .concat(orgs.map(function (o) {
                    const on = state.org === o ? ' active' : '';
                    return '<button type="button" class="btn btn-sm btn-outline-success compare-org-btn' + on + '" data-org="' + esc(o) + '">' + esc(o) + '</button>';
                })).join('');
            orgsEl.querySelectorAll('.compare-org-btn').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    state.org = btn.getAttribute('data-org') || '';
                    apply();
                });
            });
        }

        function renderCharts() {
            if (!chartsEl) {
                return;
            }
            destroy();
            const cmp = activeCompare();
            const plans = cmp
                ? groupPlansCompare(kind, cmp.rows, cmp.periods, state.org)
                : groupPlans(kind, rows, state.org);
            if (!plans.length) {
                chartsEl.innerHTML = '<p class="small text-muted mb-0">ยังไม่มีข้อมูลกราฟ</p>';
                return;
            }
            chartsEl.innerHTML = plans.map(function (plan, idx) {
                const title = plan.title ? '<h6>' + esc(plan.title) + '</h6>' : '';
                return '<div class="amass-chart-box">' + title
                    + '<div class="amass-chart-canvas"><canvas id="' + esc(root.id) + '-c' + idx + '"></canvas></div></div>';
            }).join('');
            plans.forEach(function (plan, idx) {
                const canvas = document.getElementById(root.id + '-c' + idx);
                if (!canvas) {
                    return;
                }
                const indexAxis = plan.indexAxis || 'y';
                if (indexAxis === 'y') {
                    canvas.parentNode.style.height = Math.max(170, plan.labels.length * 28 + 52) + 'px';
                } else {
                    canvas.parentNode.style.height = plan.datasets.length > 1 ? '280px' : '250px';
                }
                const datasets = plan.datasets.map(function (ds, i) {
                    return {
                        label: ds.label,
                        data: ds.data,
                        backgroundColor: COLORS[i % COLORS.length],
                        borderRadius: 3,
                        maxBarThickness: 18
                    };
                });
                const valScale = {
                    beginAtZero: true,
                    max: xMax,
                    title: { display: true, text: axisTitle(kind, valueKey), font: { size: 11 } },
                    ticks: { font: { size: 10 } }
                };
                const catScale = {
                    ticks: {
                        maxRotation: indexAxis === 'x' ? 45 : 0,
                        minRotation: 0,
                        font: function (ctx) {
                            const label = ctx.tick && ctx.tick.label ? String(ctx.tick.label) : '';
                            const isTotal = label === 'Total:' || label === 'Total';
                            const italic = !isTotal && (kind === 'freq' || kind === 'mort_origin' || kind === 'annex_b_cont');
                            return {
                                size: 10,
                                family: 'Helvetica, Arial, sans-serif',
                                style: italic ? 'italic' : 'normal',
                                weight: isTotal ? 'bold' : 'normal'
                            };
                        }
                    }
                };
                const chart = new Chart(canvas.getContext('2d'), {
                    type: 'bar',
                    data: { labels: plan.labels, datasets: datasets },
                    options: {
                        indexAxis: indexAxis,
                        responsive: true,
                        maintainAspectRatio: false,
                        onClick: function (_evt, elements) {
                            if (!elements || !elements.length) {
                                return;
                            }
                            const el = elements[0];
                            showDetail(rowAtClick(kind, plan, el.datasetIndex, el.index));
                        },
                        onHover: function (evt, elements) {
                            if (evt && evt.native && evt.native.target) {
                                evt.native.target.style.cursor = (elements && elements.length) ? 'pointer' : 'default';
                            }
                        },
                        plugins: {
                            legend: { display: plan.datasets.length > 1, position: 'top', labels: { boxWidth: 12, font: { size: 11 } } },
                            tooltip: {
                                callbacks: {
                                    label: function (item) {
                                        const row = rowAtClick(kind, plan, item.datasetIndex, item.dataIndex);
                                        if (!row) {
                                            return item.formattedValue;
                                        }
                                        if (activeCompare()) {
                                            const i = item.datasetIndex;
                                            const alias = (kind === 'pct' || kind === 'pct_origin') ? 'pct' : 'val';
                                            let txt = item.dataset.label + ': ' + String(row['p' + i + '_' + alias] ?? item.formattedValue);
                                            if (row['p' + i + '_per1000'] != null && row['p' + i + '_per1000'] !== '') {
                                                txt += ' · ต่อพัน ' + row['p' + i + '_per1000'];
                                            }
                                            if (row['p' + i + '_n'] != null && row['p' + i + '_n'] !== '') {
                                                txt += ' (' + (row['p' + i + '_r'] || '') + '/' + row['p' + i + '_n'] + ')';
                                            }
                                            return txt;
                                        }
                                        if (kind === 'pct' || kind === 'pct_origin') {
                                            return item.dataset.label + ': ' + row['Non-susceptible(%)'] + '% (' + row['Non-susceptible(N)'] + '/' + row['Total(N)'] + ')';
                                        }
                                        if (kind === 'mort_origin') {
                                            return item.dataset.label + ': ' + row['Mortality(%)'] + '% (' + row.Number_of_deaths + '/' + row.Total_number_of_patients + ')';
                                        }
                                        if (kind === 'amu') {
                                            return row.drug_name + ': ' + row.prescriptions;
                                        }
                                        if (kind === 'annex_b') {
                                            return (item.dataset.label || '%') + ': ' + row.Proportion;
                                        }
                                        if (kind === 'annex_b_month') {
                                            const key = item.dataset.label === 'ปนเปื้อน' ? 'blood_culture_contamination_rate'
                                                : (item.dataset.label === 'AMR ที่ต้องรายงาน' ? 'notifiable_antibiotic_pathogen' : 'potential_AST_errors');
                                            return item.dataset.label + ': ' + row[key];
                                        }
                                        if (kind === 'annex_c_ward') {
                                            return row.AMR_pathogen + ' · ' + row.Ward + ': ' + row.Hospital_origin_isolates;
                                        }
                                        if (kind === 'annex_d_dot') {
                                            return row.Antibiotic + ': ' + (row.DOT_percent_text || row.DOT);
                                        }
                                        if (kind === 'annex_d_aware') {
                                            return row.AWaRe_classification + ': ' + (row.DOT_percent_text || row.DOT);
                                        }
                                        if (kind === 'annex_d_dept') {
                                            return row.Department + ': ' + (row.DOT_percent_text || row.DOT);
                                        }
                                        if (kind === 'annex_d_month') {
                                            return item.dataset.label + ': ' + item.formattedValue;
                                        }
                                        if (kind === 'annex_d_route') {
                                            return item.dataset.label + ': ' + item.formattedValue;
                                        }
                                        if (kind === 'annex_b_cont') {
                                            return row.Organism + ': ' + row.Number_of_possible_contaminants;
                                        }
                                        const rate = row[valueKey];
                                        return item.dataset.label + ': ' + rate + ' (n=' + row.Number_of_patients + ')';
                                    }
                                }
                            }
                        },
                        scales: indexAxis === 'y'
                            ? { x: valScale, y: catScale }
                            : { y: valScale, x: catScale }
                    }
                });
                chartObjs.push(chart);
            });
        }

        function setButtons() {
            const isChart = state.view === 'chart';
            if (chartBtn) {
                chartBtn.className = 'btn ' + (isChart ? 'btn-success' : 'btn-outline-success');
            }
            if (tableBtn) {
                tableBtn.className = 'btn ' + (isChart ? 'btn-outline-success' : 'btn-success');
            }
        }

        function apply() {
            setButtons();
            renderPills();
            const cmp = activeCompare();
            const hint = ensureHint();
            if (hint) {
                hint.textContent = cmp
                    ? ('เปรียบเทียบ: ' + cmp.periods.map(function (p) { return p.label; }).join(' · '))
                    : '';
                hint.classList.toggle('d-none', !cmp);
            }
            if (detailEl) {
                detailEl.classList.add('d-none');
            }
            if (state.view === 'chart') {
                if (chartsEl) {
                    chartsEl.classList.remove('d-none');
                }
                if (tableEl) {
                    tableEl.classList.add('d-none');
                }
                renderCharts();
            } else {
                destroy();
                if (chartsEl) {
                    chartsEl.classList.add('d-none');
                }
                if (tableEl) {
                    tableEl.classList.remove('d-none');
                    tableEl.innerHTML = cmp
                        ? compareTableHtml(kind, cmp.rows, cmp.periods, state.org)
                        : originalTable;
                }
            }
        }

        if (chartBtn) {
            chartBtn.addEventListener('click', function () {
                state.view = 'chart';
                apply();
            });
        }
        if (tableBtn) {
            tableBtn.addEventListener('click', function () {
                state.view = 'table';
                apply();
            });
        }
        apply();
        vizInstances.push({ apply: apply });
    }

    function mountAll(scope) {
        const root = scope || document;
        root.querySelectorAll('.amass-viz').forEach(bind);
    }

    function setCompare(data) {
        compareCtx = (data && data.periods && data.periods.length > 1) ? data : null;
        vizInstances.forEach(function (inst) {
            try { inst.apply(); } catch (e) {}
        });
    }

    global.AmassViz = { mountAll: mountAll, setCompare: setCompare };
})(window);
