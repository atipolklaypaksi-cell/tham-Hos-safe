รับ/**
 * Client cache สำหรับ Smart Drug (sessionStorage)
 * ใช้ร่วมกันระหว่าง Patient IPD / Smart Drug
 */
(function (global) {
    'use strict';

    var TTL_MS = 10 * 60 * 1000;
    var PREFIX = 'tham_emr_sd_v1:';

    function normHn(hn) {
        hn = String(hn || '').trim();
        if (/^\d+$/.test(hn) && hn.length < 9) {
            hn = ('000000000' + hn).slice(-9);
        }
        return hn;
    }

    function lookbackMonths() {
        try {
            var n = parseInt(localStorage.getItem('tham_lookback_months') || '12', 10);
            if ([3, 6, 12, 36, 60, 0].indexOf(n) >= 0) return n;
        } catch (e) {}
        return 12;
    }

    function flag(key, defaultOn) {
        try {
            var v = localStorage.getItem(key);
            if (v === null || v === undefined) return !!defaultOn;
            return v === '1' || v === 'true';
        } catch (e) {
            return !!defaultOn;
        }
    }

    function drugParams(overrides) {
        overrides = overrides || {};
        return {
            months: overrides.months != null ? overrides.months : lookbackMonths(),
            network: overrides.network != null ? !!overrides.network : flag('tham_network_hospitals', true),
            jhcis: overrides.jhcis != null ? !!overrides.jhcis : flag('tham_jhcis_pcc', false)
        };
    }

    function drugKey(hn, params) {
        params = params || drugParams();
        return PREFIX + [normHn(hn), params.months, params.network ? 1 : 0, params.jhcis ? 1 : 0].join('|');
    }

    function putDrug(hn, data, params) {
        if (!data || data.status !== 'success') return false;
        try {
            var wrap = { ts: Date.now(), hn: normHn(hn), params: params || drugParams(), data: data };
            sessionStorage.setItem(drugKey(hn, wrap.params), JSON.stringify(wrap));
            return true;
        } catch (e) {
            return false;
        }
    }

    function getDrug(hn, params) {
        params = params || drugParams();
        try {
            var raw = sessionStorage.getItem(drugKey(hn, params));
            if (!raw) return null;
            var wrap = JSON.parse(raw);
            if (!wrap || !wrap.data || wrap.data.status !== 'success') return null;
            if ((Date.now() - (wrap.ts || 0)) > TTL_MS) {
                sessionStorage.removeItem(drugKey(hn, params));
                return null;
            }
            if (normHn(wrap.hn) !== normHn(hn)) return null;
            return wrap.data;
        } catch (e) {
            return null;
        }
    }

    /** เตรียม Smart Drug + Smart Lab หลังค้น HN จาก Patient IPD */
    function prefetchFromIpd(hn, opts) {
        opts = opts || {};
        hn = normHn(hn);
        if (!hn) return;
        var params = drugParams(opts);
        var canDrug = opts.canDrug !== false;
        var canLab = opts.canLab !== false;
        var onStatus = typeof opts.onStatus === 'function' ? opts.onStatus : null;

        function status(msg) {
            if (onStatus) onStatus(msg);
        }

        if (canDrug) {
            var cached = getDrug(hn, params);
            if (cached) {
                status('Smart Drug พร้อม (cache)');
            } else {
                status('กำลังเตรียม Smart Drug...');
                fetch('fetch_hosxp_history_api.php', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        hn: hn,
                        months: params.months,
                        limit: params.months === 0 ? 5000 : 3000,
                        include_network: params.network ? 1 : 0,
                        include_jhcis: params.jhcis ? 1 : 0
                    })
                })
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        if (data && data.status === 'success') {
                            putDrug(hn, data, params);
                            // mirror ฝั่งเซิร์ฟเวอร์ (เผื่อ sessionStorage เต็ม)
                            fetch('fetch_emr_prefetch_api.php', {
                                method: 'POST',
                                credentials: 'same-origin',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                    action: 'put_drug_cache',
                                    hn: hn,
                                    months: params.months,
                                    include_network: params.network ? 1 : 0,
                                    include_jhcis: params.jhcis ? 1 : 0,
                                    data: data
                                })
                            }).catch(function () {});
                            status('Smart Drug พร้อมแล้ว');
                        } else {
                            status('เตรียม Smart Drug ไม่สำเร็จ');
                        }
                    })
                    .catch(function () { status('เตรียม Smart Drug ไม่สำเร็จ'); });
            }
        }

        if (canLab) {
            status(canDrug ? 'กำลังเตรียม Smart Lab...' : 'กำลังเตรียม Smart Lab...');
            fetch('fetch_emr_prefetch_api.php', {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'prefetch_lab',
                    hn: hn,
                    months: params.months,
                    include_network: params.network ? 1 : 0
                })
            })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data && data.status === 'success') {
                        status('Smart Lab พร้อมแล้ว' + (data.order_count != null ? ' (' + data.order_count + ' ใบ)' : ''));
                    }
                })
                .catch(function () {});
        }
    }

    global.EmrPrefetchCache = {
        TTL_MS: TTL_MS,
        normHn: normHn,
        drugParams: drugParams,
        putDrug: putDrug,
        getDrug: getDrug,
        prefetchFromIpd: prefetchFromIpd
    };
})(window);
