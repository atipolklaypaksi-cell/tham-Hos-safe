/**
 * ระบบช่วยคำนวณยา — ต้องเลือก HN, ดึง BW/ส่วนสูง/อายุ, confirm ถ้าแก้ >10% หรือแก้อายุ
 */
(function () {
    'use strict';

    var patient = null; // { hn, hn_key, ptname, bw_source, height_source, age_source, vstdate }
    var ageConfirmed = false;
    var agePendingValue = null; // ค่าอายุที่รอ confirm ใน modal
    var ageModalInstance = null;
    var ageConfirmCallback = null; // หลังยืนยันอายุสำเร็จ (เช่น save)
    var pediatricModalInstance = null;
    var pediatricWarnedKey = null; // กันแจ้งซ้ำ: hn_key|age

    function num(v, fallback) {
        var n = parseFloat(v);
        return isFinite(n) ? n : (fallback != null ? fallback : 0);
    }

    function fmt(v, d) {
        if (v == null || !isFinite(v)) return '—';
        var n = Number(v);
        var s = n.toFixed(d != null ? d : 3);
        s = s.replace(/\.?0+$/, '');
        return s === '' ? '0' : s;
    }

    function fmtIntComma(v) {
        return Math.round(v).toLocaleString('en-US');
    }

    function setText(id, text) {
        var el = document.getElementById(id);
        if (el) el.textContent = text;
    }

    function getBw() {
        return num(document.getElementById('dc_bw') && document.getElementById('dc_bw').value);
    }

    function getHeight() {
        var el = document.getElementById('dc_height');
        var v = el ? num(el.value) : 0;
        return v > 0 ? v : null;
    }

    function getAge() {
        var el = document.getElementById('dc_age');
        if (!el || el.value === '') return null;
        return Math.round(num(el.value));
    }

    function ageNeedsConfirm() {
        if (!patient || patient.age_source == null) return false;
        var cur = getAge();
        if (cur == null) return false;
        return cur !== patient.age_source;
    }

    function resetAgeConfirmState() {
        ageConfirmed = false;
        agePendingValue = null;
        ageConfirmCallback = null;
        var cf = document.getElementById('dc_age_confirm');
        if (cf) cf.value = '';
        var err = document.getElementById('dc_age_confirm_err');
        if (err) err.classList.add('d-none');
    }

    function getAgeModal() {
        var el = document.getElementById('dcAgeConfirmModal');
        if (!el || typeof bootstrap === 'undefined') return null;
        if (!ageModalInstance) ageModalInstance = bootstrap.Modal.getOrCreateInstance(el);
        return ageModalInstance;
    }

    function showAgeConfirmModal(opts) {
        opts = opts || {};
        var src = patient && patient.age_source != null ? patient.age_source : '—';
        var cur = agePendingValue != null ? agePendingValue : getAge();
        var msg = document.getElementById('dcAgeConfirmMsg');
        if (msg) {
            msg.innerHTML = 'แก้ไขอายุจากค่า HOSxP <strong>' + src + '</strong> ปี → <strong>' +
                (cur != null ? cur : '—') + '</strong> ปี<br>พิมพ์ <strong>confirm</strong> เพื่อยืนยัน';
        }
        var cf = document.getElementById('dc_age_confirm');
        if (cf) cf.value = '';
        var err = document.getElementById('dc_age_confirm_err');
        if (err) err.classList.add('d-none');
        ageConfirmCallback = opts.onSuccess || null;
        var modal = getAgeModal();
        if (modal) {
            modal.show();
            setTimeout(function () { if (cf) cf.focus(); }, 300);
        } else {
            // fallback
            var typed = window.prompt('แก้ไขอายุจาก HOSxP — พิมพ์ confirm เพื่อยืนยัน', '');
            if (typed && typed.trim().toLowerCase() === 'confirm') {
                ageConfirmed = true;
                if (ageConfirmCallback) ageConfirmCallback();
            } else {
                revertAgeToSource();
            }
        }
    }

    function revertAgeToSource() {
        var el = document.getElementById('dc_age');
        if (el && patient && patient.age_source != null) {
            el.value = patient.age_source;
        }
        resetAgeConfirmState();
        recalcAll();
    }

    function submitAgeConfirmModal() {
        var cf = document.getElementById('dc_age_confirm');
        var err = document.getElementById('dc_age_confirm_err');
        var typed = cf ? cf.value.trim().toLowerCase() : '';
        if (typed !== 'confirm') {
            if (err) err.classList.remove('d-none');
            if (cf) cf.focus();
            return;
        }
        ageConfirmed = true;
        agePendingValue = null;
        if (err) err.classList.add('d-none');
        var modal = getAgeModal();
        if (modal) modal.hide();
        recalcAll();
        var cb = ageConfirmCallback;
        ageConfirmCallback = null;
        if (cb) cb();
    }

    function cancelAgeConfirmModal() {
        revertAgeToSource();
        ageConfirmCallback = null;
        showMsg('ยกเลิกการแก้ไขอายุ — คืนค่าจาก HOSxP แล้ว', 'warning');
    }

    function checkAgeConfirmBeforeSave(auto) {
        if (!ageNeedsConfirm() || ageConfirmed) return true;
        if (auto) {
            showMsg('ยังไม่ได้บันทึก — รอยืนยันการแก้ไขอายุ (พิมพ์ confirm)', 'warning');
            showAgeConfirmModal({
                onSuccess: function () { saveCalc(false, { auto: true }); }
            });
            return false;
        }
        showAgeConfirmModal({
            onSuccess: function () { saveCalc(false, { auto: false }); }
        });
        return false;
    }

    function onAgeInput() {
        ageConfirmed = false;
        agePendingValue = getAge();
        recalcAll();
        if (ageNeedsConfirm()) {
            showAgeConfirmModal({
                onSuccess: function () {
                    maybeWarnTnkPediatric(true);
                }
            });
        } else {
            resetAgeConfirmState();
            maybeWarnTnkPediatric(true);
        }
    }

    function activeCalcType() {
        var btn = document.querySelector('#dcTabs .nav-link.active');
        return (btn && btn.getAttribute('data-dc-tab')) || 'methylpred';
    }

    function pctChange(from, to) {
        from = Number(from); to = Number(to);
        if (!(from > 0)) return to > 0 ? 100 : 0;
        return Math.abs(to - from) / from * 100;
    }

    function changeReasons() {
        if (!patient) return [];
        var reasons = [];
        var bw = getBw();
        var ht = getHeight();
        if (patient.bw_source > 0 && bw > 0) {
            var p = pctChange(patient.bw_source, bw);
            if (p > 10) reasons.push('น้ำหนักเปลี่ยน ' + p.toFixed(1) + '% (' + patient.bw_source + ' → ' + bw + ' kg)');
        }
        if (patient.height_source > 0 && ht > 0) {
            var p2 = pctChange(patient.height_source, ht);
            if (p2 > 10) reasons.push('ส่วนสูงเปลี่ยน ' + p2.toFixed(1) + '% (' + patient.height_source + ' → ' + ht + ' cm)');
        }
        return reasons;
    }

    /* ——— Methylpred ——— */
    /** ปัดจ่าย Amp: รวม = ceil(exact) · แบ่ง Bolus/Infusion เป็นจำนวนเต็มที่รวมเท่ากัน โดยเพิ่มให้ฝั่งเศษมากกว่า */
    function dispenseAmps(bolusExact, infExact) {
        var totalExact = bolusExact + infExact;
        var totalDisp = Math.ceil(totalExact - 1e-12);
        if (!(totalExact > 0)) {
            return { bolus: 0, inf: 0, total: 0, bolusExact: 0, infExact: 0, totalExact: 0 };
        }
        var bFloor = Math.floor(bolusExact + 1e-12);
        var iFloor = Math.floor(infExact + 1e-12);
        var bFrac = bolusExact - bFloor;
        var iFrac = infExact - iFloor;
        var need = totalDisp - bFloor - iFloor;
        var bolusDisp = bFloor;
        var infDisp = iFloor;
        var order = [
            { key: 'bolus', frac: bFrac },
            { key: 'inf', frac: iFrac }
        ];
        order.sort(function (a, b) {
            if (b.frac !== a.frac) return b.frac - a.frac;
            return a.key === 'bolus' ? -1 : 1; // เศษเท่ากัน → เพิ่มที่ Bolus ก่อน
        });
        for (var n = 0; n < need; n++) {
            if (order[n].key === 'bolus') bolusDisp++;
            else infDisp++;
        }
        return {
            bolus: bolusDisp,
            inf: infDisp,
            total: totalDisp,
            bolusExact: bolusExact,
            infExact: infExact,
            totalExact: totalExact
        };
    }

    function ampDispLabel(disp, exact) {
        return disp + ' Amp (' + fmt(exact, 3) + ' Amp)';
    }

    function calcMethylpred() {
        var bw = getBw();
        var hoursSel = num(document.getElementById('mp_hours').value, 24);
        var vol = num(document.getElementById('mp_vol').value, 500);
        var note47 = document.getElementById('mp_note_47');

        if (bw <= 0) {
            ['mp_amp_total', 'mp_amp_bolus', 'mp_amp_inf'].forEach(function (id) { setText(id, '—'); });
            ['mp_sticker_bolus', 'mp_sticker_inf', 'mp_sticker_fluid'].forEach(function (id) { setText(id, ''); });
            return null;
        }

        var is47 = hoursSel === 47;
        if (note47) note47.classList.toggle('d-none', !is47);

        var hoursDose = is47 ? 47 : hoursSel;
        var hoursSticker = is47 ? 23.5 : hoursSel;
        var conc = 1000 / 16;
        var bolusMg = 30 * bw;
        var bolusMl = bolusMg / conc;
        var bolusAmp = bolusMg / 1000;
        var mgHr = 5.4 * bw;
        var infMg = mgHr * hoursDose;
        var infMl = infMg / conc;
        var infAmp = infMg / 1000;
        var stickerInfMg = mgHr * hoursSticker;
        var stickerInfMl = stickerInfMg / conc;
        var nssMl = Math.max(0, vol - stickerInfMl);
        var rate = vol / hoursSticker;
        var amps = dispenseAmps(bolusAmp, infAmp);

        setText('mp_amp_total', ampDispLabel(amps.total, amps.totalExact));
        setText('mp_amp_bolus', ampDispLabel(amps.bolus, amps.bolusExact));
        setText('mp_amp_inf', ampDispLabel(amps.inf, amps.infExact));
        setText('mp_sticker_bolus',
            'IV bolus ' + fmt(bolusMg, 1) + ' mg (' + fmt(bolusMl, 1) + ' ml)\n' +
            'ผสม NSS 100 ml, IV drip in 15 นาที\n(bolus = 30 mg/kg)');
        setText('mp_sticker_inf',
            'IV ' + fmt(rate, 2) + ' ml/hr (' + fmt(mgHr, 1) + ' mg/hr)\n' +
            'drip in ' + fmt(hoursSticker, 1) + ' ชั่วโมง');
        setText('mp_sticker_fluid',
            'Methylpred ' + fmt(stickerInfMg, 0) + ' mg (' + fmt(stickerInfMl, 0) + ' ml)\n' +
            '+ NSS ' + fmt(nssMl, 0) + ' ml');

        return {
            hours: hoursDose, hours_sticker: hoursSticker, volume_ml: vol,
            bolus_mg: bolusMg, bolus_ml: bolusMl, bolus_amp: bolusAmp, bolus_amp_dispense: amps.bolus,
            infusion_mg: infMg, infusion_ml: infMl, infusion_amp: infAmp, infusion_amp_dispense: amps.inf,
            amp_total: amps.totalExact, amp_total_dispense: amps.total,
            rate_ml_hr: rate, mg_hr: mgHr
        };
    }

    function calcRtpaStemi() {
        var bw = getBw();
        if (bw <= 0) return null;
        // 15 mg bolus → 0.75 mg/kg (up to 50) → 0.5 mg/kg (up to 30) · MAX total 100 mg
        var bolusMg = 15;
        var drip1 = Math.min(0.75 * bw, 50);
        var drip2 = Math.min(0.5 * bw, 30);
        var total = bolusMg + drip1 + drip2;
        if (total > 100) {
            var remain = 100 - bolusMg;
            var sumInf = drip1 + drip2;
            if (sumInf > 0) {
                drip1 = remain * (drip1 / sumInf);
                drip2 = remain * (drip2 / sumInf);
            }
            total = 100;
        }
        var vial = 50;
        // กล่องสรุป
        setText('rs_bolus_mg', fmt(bolusMg, 2));
        setText('rs_bolus_ml', fmt(bolusMg, 2));
        setText('rs_bolus_vial', fmt(bolusMg / vial, 3));
        setText('rs_drip1_mg', fmt(drip1, 2));
        setText('rs_drip1_ml', fmt(drip1, 2));
        setText('rs_drip1_vial', fmt(drip1 / vial, 3));
        setText('rs_drip2_mg', fmt(drip2, 2));
        setText('rs_drip2_ml', fmt(drip2, 2));
        setText('rs_drip2_vial', fmt(drip2 / vial, 3));
        // แถว sticker / รายละเอียด
        setText('rs_bolus_mg2', fmt(bolusMg, 2));
        setText('rs_bolus_ml2', fmt(bolusMg, 2));
        setText('rs_drip1_mg2', fmt(drip1, 2));
        setText('rs_drip1_ml2', fmt(drip1, 2));
        setText('rs_drip2_mg2', fmt(drip2, 2));
        setText('rs_drip2_ml2', fmt(drip2, 2));
        setText('rs_total_mg', fmt(total, 2));
        setText('rs_total_ml', fmt(total, 2));
        setText('rs_total_vial', fmt(total / vial, 3));

        setText('rs_sticker_bolus',
            'IV bolus 15 mg in 1 min\n' +
            fmt(bolusMg, 2) + ' mg / ' + fmt(bolusMg, 2) + ' ml');
        setText('rs_sticker_inf1',
            'IV infusion drip ≥ 30 min\n' +
            '(0.75 mg/kg, up to 50 mg)\n' +
            fmt(drip1, 2) + ' mg / ' + fmt(drip1, 2) + ' ml');
        setText('rs_sticker_inf2',
            'IV infusion drip ≥ 60 min\n' +
            '(0.5 mg/kg, up to 30 mg)\n' +
            fmt(drip2, 2) + ' mg / ' + fmt(drip2, 2) + ' ml');
        setText('rs_sticker_total',
            'Total dose\n' +
            fmt(total, 2) + ' mg / ' + fmt(total, 2) + ' ml\n' +
            '(' + fmt(total / vial, 3) + ' ขวด)');

        return {
            bolus_mg: bolusMg, bolus_ml: bolusMg,
            drip1_mg: drip1, drip1_ml: drip1, drip1_vial: drip1 / vial,
            drip2_mg: drip2, drip2_ml: drip2, drip2_vial: drip2 / vial,
            total_mg: total, total_ml: total, vials: total / vial
        };
    }

    function calcRtpaStroke() {
        var bw = getBw();
        if (bw <= 0) return null;
        var total = Math.min(0.9 * bw, 90);
        var bolus = total * 0.1;
        var inf = total * 0.9;
        var vial = 50;
        setText('rk_total_mg', fmt(total, 2));
        setText('rk_total_ml', fmt(total, 2));
        setText('rk_total_vial', fmt(total / vial, 3));
        setText('rk_bolus_mg', fmt(bolus, 2));
        setText('rk_bolus_ml', fmt(bolus, 2));
        setText('rk_inf_mg', fmt(inf, 2));
        setText('rk_inf_ml', fmt(inf, 2));
        return { total_mg: total, bolus_mg: bolus, infusion_mg: inf, vials: total / vial };
    }

    function tnkStrokeTier(bw) {
        if (bw < 60) return { units: 3000, mg: 15, ml: 3 };
        if (bw < 70) return { units: 3500, mg: 17.5, ml: 3.5 };
        if (bw < 80) return { units: 4000, mg: 20, ml: 4 };
        if (bw < 90) return { units: 4500, mg: 22.5, ml: 4.5 };
        return { units: 5000, mg: 25, ml: 5 };
    }

    function calcTnkStroke() {
        var bw = getBw();
        if (bw <= 0) return null;
        var t = tnkStrokeTier(bw);
        setText('ts_units', fmtIntComma(t.units));
        setText('ts_mg', fmt(t.mg, 1));
        setText('ts_ml', fmt(t.ml, 1));
        return t;
    }

    function tnkStemiTier(bw) {
        if (bw < 60) return { mg: 30, ml: 6 };
        if (bw < 70) return { mg: 35, ml: 7 };
        if (bw < 80) return { mg: 40, ml: 8 };
        if (bw < 90) return { mg: 45, ml: 9 };
        return { mg: 50, ml: 10 };
    }

    function calcTnkStemi() {
        var bw = getBw();
        var age = getAge();
        var note = document.getElementById('tm_age_note');
        var pedNote = document.getElementById('tm_pediatric_note');
        if (bw <= 0) return null;
        var t = tnkStemiTier(bw);
        var mg = t.mg;
        var ml = t.ml;
        var half = age != null && age > 75;
        var pediatric = age != null && age < 18;
        if (note) note.classList.toggle('d-none', !half);
        if (pedNote) pedNote.classList.toggle('d-none', !pediatric);
        if (half) { mg = mg / 2; ml = ml / 2; }
        var vials = Math.max(1, Math.ceil(mg / 40));
        setText('tm_mg', fmt(mg, 1));
        setText('tm_ml', fmt(ml, 1));
        setText('tm_vial', String(vials));
        return { age: age, mg: mg, ml: ml, vials: vials, age_half: half, pediatric: pediatric };
    }

    function maybeWarnTnkPediatric(force) {
        if (activeCalcType() !== 'tnk_stemi') return;
        var age = getAge();
        if (age == null || !(age < 18)) {
            pediatricWarnedKey = null;
            return;
        }
        var key = ((patient && patient.hn_key) || '') + '|' + age;
        if (!force && pediatricWarnedKey === key) return;
        pediatricWarnedKey = key;

        var msg = document.getElementById('dcTnkPediatricMsg');
        if (msg) {
            msg.innerHTML = 'ผู้ป่วยอายุ <strong>' + age + '</strong> ปี — ไม่มีข้อมูลความปลอดภัย/ประสิทธิภาพในเด็กอายุ &lt; 18 ปี';
        }
        var el = document.getElementById('dcTnkPediatricModal');
        if (!el || typeof bootstrap === 'undefined') {
            window.alert('อายุ ' + age + ' ปี — ไม่มีข้อมูลความปลอดภัย/ประสิทธิภาพในเด็กอายุ < 18 ปี');
            return;
        }
        if (!pediatricModalInstance) {
            pediatricModalInstance = bootstrap.Modal.getOrCreateInstance(el);
        }
        pediatricModalInstance.show();
    }

    /* ——— Bolus ——— */
    function calcBolus() {
        var bw = getBw();
        if (bw <= 0) {
            ['bl_mz_min_mg', 'bl_mz_max_mg', 'bl_mz_drug_ml', 'bl_fn_min_mcg', 'bl_fn_drug_ml'].forEach(function (id) { setText(id, '—'); });
            return null;
        }
        var mzMin = 0.05 * bw;
        var mzMax = 0.15 * bw;
        var mzOrder = num(document.getElementById('bl_mz_order_mg') && document.getElementById('bl_mz_order_mg').value);
        var fnMin = 1 * bw;
        var fnOrder = num(document.getElementById('bl_fn_order_mcg') && document.getElementById('bl_fn_order_mcg').value);
        var mzMl = mzOrder > 0 ? mzOrder / 5 : null;
        var fnMl = fnOrder > 0 ? fnOrder / 50 : null;
        setText('bl_mz_min_mg', fmt(mzMin, 3));
        setText('bl_mz_max_mg', fmt(mzMax, 3));
        setText('bl_mz_drug_ml', mzMl != null ? fmt(mzMl, 2) : '—');
        setText('bl_fn_min_mcg', fmt(fnMin, 2));
        setText('bl_fn_drug_ml', fnMl != null ? fmt(fnMl, 2) : '—');
        return {
            midazolam: { min_mg: mzMin, max_mg: mzMax, order_mg: mzOrder, drug_ml: mzMl },
            fentanyl: { min_mcg: fnMin, order_mcg: fnOrder, drug_ml: fnMl }
        };
    }

    /* ——— Midazolam (mcg/kg/min) ——— */
    function calcMidazolam() {
        var bw = getBw();
        var dose = num(document.getElementById('mz_dose') && document.getElementById('mz_dose').value);
        var drugMg = num(document.getElementById('mz_drug_mg') && document.getElementById('mz_drug_mg').value);
        var totalMl = num(document.getElementById('mz_total_ml') && document.getElementById('mz_total_ml').value);
        if (bw <= 0 || dose <= 0 || drugMg <= 0 || totalMl <= 0) {
            ['mz_mg_hr', 'mz_conc', 'mz_rate'].forEach(function (id) { setText(id, '—'); });
            return null;
        }
        var mcgHr = dose * bw * 60;
        var drugMcg = drugMg * 1000;
        var conc = drugMcg / totalMl;
        var rate = mcgHr / conc;
        setText('mz_mg_hr', fmt(mcgHr, 2));
        setText('mz_conc', fmt(conc, 2));
        setText('mz_rate', fmt(rate, 4));
        return { dose_mcg_kg_min: dose, drug_mg: drugMg, total_ml: totalMl, mcg_hr: mcgHr, conc_mcg_ml: conc, rate_ml_hr: rate };
    }

    /* ——— Midazolam (mcg/kg/hr) ——— */
    function calcMidazolamHr() {
        var bw = getBw();
        var dose = num(document.getElementById('mzh_dose') && document.getElementById('mzh_dose').value);
        var drugMg = num(document.getElementById('mzh_drug_mg') && document.getElementById('mzh_drug_mg').value);
        var totalMl = num(document.getElementById('mzh_total_ml') && document.getElementById('mzh_total_ml').value);
        var alertEl = document.getElementById('mzh_dose_alert');
        if (bw <= 0 || dose <= 0 || drugMg <= 0 || totalMl <= 0) {
            ['mzh_mcg_hr', 'mzh_conc', 'mzh_rate', 'mzh_drug_ml'].forEach(function (id) { setText(id, '—'); });
            if (alertEl) {
                alertEl.classList.add('d-none');
                alertEl.textContent = '';
            }
            calcMidazolamHrReverse();
            return null;
        }
        var mcgHr = dose * bw;
        var drugMcg = drugMg * 1000;
        var conc = drugMcg / totalMl;
        var rate = mcgHr / conc;
        var drugMl = drugMg / 5;
        setText('mzh_mcg_hr', fmt(mcgHr, 2));
        setText('mzh_conc', fmt(conc, 2));
        setText('mzh_rate', fmt(rate, 3));
        setText('mzh_drug_ml', fmt(drugMl, 2));
        if (alertEl) {
            if (dose >= 20 && dose <= 100) {
                alertEl.className = 'alert alert-warning mb-3 fw-bold py-2';
                alertEl.textContent = 'อยู่ใน Recommended Drug Dose (20–100 mcg/kg/hr)';
                alertEl.classList.remove('d-none');
            } else if (dose > 100) {
                alertEl.className = 'alert alert-danger mb-3 fw-bold py-2';
                alertEl.textContent = 'เกิน Recommended Drug Dose (> 100 mcg/kg/hr)';
                alertEl.classList.remove('d-none');
            } else if (dose > 0 && dose < 20) {
                alertEl.className = 'alert alert-info mb-3 fw-bold py-2';
                alertEl.textContent = 'ต่ำกว่า Recommended Drug Dose (< 20 mcg/kg/hr)';
                alertEl.classList.remove('d-none');
            } else {
                alertEl.classList.add('d-none');
                alertEl.textContent = '';
            }
        }
        calcMidazolamHrReverse();
        return { dose_mcg_kg_hr: dose, drug_mg: drugMg, total_ml: totalMl, mcg_hr: mcgHr, conc_mcg_ml: conc, rate_ml_hr: rate, drug_ml: drugMl };
    }

    function calcMidazolamHrReverse() {
        var bw = getBw();
        var rate = num(document.getElementById('mzh_rev_rate') && document.getElementById('mzh_rev_rate').value);
        var conc = num(document.getElementById('mzh_rev_conc') && document.getElementById('mzh_rev_conc').value, 1);
        var box = document.getElementById('mzh_rev_result_box');
        var alertEl = document.getElementById('mzh_rev_alert');
        if (!(bw > 0) || !(rate > 0) || !(conc > 0)) {
            setText('mzh_rev_dose', '—');
            setText('mzh_eq_mg_hr', '—');
            ['mzh_eq_05', 'mzh_eq_1', 'mzh_eq_2', 'mzh_eq_3', 'mzh_eq_4', 'mzh_eq_5'].forEach(function (id) { setText(id, '—'); });
            if (alertEl) alertEl.classList.add('d-none');
            if (box) {
                box.style.background = '';
                box.style.borderColor = '';
            }
            return null;
        }
        // Dose (mcg/kg/hr) = (rate_ml_hr × conc_mg_ml × 1000) / BW
        var dose = (rate * conc * 1000) / bw;
        setText('mzh_rev_dose', fmt(dose, 2));

        var amountMgHr = rate * conc;
        setText('mzh_eq_mg_hr', fmt(amountMgHr, 2) + ' mg/hr');
        setText('mzh_eq_05', fmt(amountMgHr / 0.5, 2));
        setText('mzh_eq_1', fmt(amountMgHr / 1, 2));
        setText('mzh_eq_2', fmt(amountMgHr / 2, 2));
        setText('mzh_eq_3', fmt(amountMgHr / 3, 2));
        setText('mzh_eq_4', fmt(amountMgHr / 4, 2));
        setText('mzh_eq_5', fmt(amountMgHr / 5, 2));

        if (box) {
            if (dose > 100) {
                box.style.background = '#fecaca';
                box.style.borderColor = '#f87171';
            } else if (dose >= 20) {
                box.style.background = '#fef08a';
                box.style.borderColor = '#facc15';
            } else {
                box.style.background = '#e0f2fe';
                box.style.borderColor = '#7dd3fc';
            }
        }
        if (alertEl) {
            alertEl.className = 'dc-note mb-0';
            if (dose > 100) {
                alertEl.style.background = '#fecaca';
                alertEl.style.borderLeftColor = '#dc2626';
                alertEl.textContent = 'เกิน Recommended (> 100 mcg/kg/hr)';
            } else if (dose >= 20) {
                alertEl.style.background = '#fef08a';
                alertEl.style.borderLeftColor = '#ca8a04';
                alertEl.textContent = 'สีเหลือง — Recommended Drug Dose (20–100)';
            } else {
                alertEl.style.background = '#e0f2fe';
                alertEl.style.borderLeftColor = '#0284c7';
                alertEl.textContent = 'ต่ำกว่า Recommended (< 20 mcg/kg/hr)';
            }
            alertEl.classList.remove('d-none');
        }
        return { rate_ml_hr: rate, conc_mg_ml: conc, dose_mcg_kg_hr: dose, mg_hr: amountMgHr };
    }

    /* ——— Fentanyl (mcg/kg/hr) ——— */
    function calcFentanyl() {
        var bw = getBw();
        var dose = num(document.getElementById('fn_dose') && document.getElementById('fn_dose').value);
        var drugMg = num(document.getElementById('fn_drug_mg') && document.getElementById('fn_drug_mg').value);
        var totalMl = num(document.getElementById('fn_total_ml') && document.getElementById('fn_total_ml').value);
        if (bw <= 0 || dose <= 0 || drugMg <= 0 || totalMl <= 0) {
            ['fn_mcg_hr', 'fn_conc', 'fn_rate'].forEach(function (id) { setText(id, '—'); });
            return null;
        }
        var mcgHr = dose * bw;
        var drugMcg = drugMg * 1000;
        var conc = drugMcg / totalMl;
        var rate = mcgHr / conc;
        setText('fn_mcg_hr', fmt(mcgHr, 2));
        setText('fn_conc', fmt(conc, 2));
        setText('fn_rate', fmt(rate, 4));
        return { dose_mcg_kg_hr: dose, drug_mg: drugMg, total_ml: totalMl, mcg_hr: mcgHr, conc_mcg_ml: conc, rate_ml_hr: rate };
    }

    /* ——— mcg/kg/min infusion (Dobutamine / Dopamine / NE / Cisatracurium) ——— */
    function calcMcgKgMinInfusion(prefix, stockMgPerMl, drugMlDecimals) {
        var bw = getBw();
        var dose = num(document.getElementById(prefix + '_dose') && document.getElementById(prefix + '_dose').value);
        var drugMg = num(document.getElementById(prefix + '_drug_mg') && document.getElementById(prefix + '_drug_mg').value);
        var totalMl = num(document.getElementById(prefix + '_total_ml') && document.getElementById(prefix + '_total_ml').value);
        var ids = [prefix + '_mcg_hr', prefix + '_conc', prefix + '_rate', prefix + '_drug_ml'];
        if (bw <= 0 || dose <= 0 || drugMg <= 0 || totalMl <= 0) {
            ids.forEach(function (id) { setText(id, '—'); });
            return null;
        }
        var mcgHr = dose * bw * 60;
        var conc = (drugMg * 1000) / totalMl;
        var rate = mcgHr / conc;
        var drugMl = stockMgPerMl > 0 ? drugMg / stockMgPerMl : null;
        var mlDec = drugMlDecimals != null ? drugMlDecimals : 2;
        setText(prefix + '_mcg_hr', fmt(mcgHr, 2));
        setText(prefix + '_conc', fmt(conc, 2));
        setText(prefix + '_rate', fmt(rate, 3));
        setText(prefix + '_drug_ml', drugMl != null ? fmt(drugMl, mlDec) : '—');
        return {
            dose_mcg_kg_min: dose, drug_mg: drugMg, total_ml: totalMl,
            mcg_hr: mcgHr, conc_mcg_ml: conc, rate_ml_hr: rate, drug_ml: drugMl
        };
    }

    function calcDobutamine() {
        var result = calcMcgKgMinInfusion('db', 50);
        var dose = num(document.getElementById('db_dose') && document.getElementById('db_dose').value);
        var alertEl = document.getElementById('db_dose_alert');
        if (alertEl) {
            if (dose > 40) {
                alertEl.className = 'alert alert-danger mb-3 fw-bold py-2';
                alertEl.textContent = 'เกิน Max dose (> 40 mcg/kg/min)';
                alertEl.classList.remove('d-none');
            } else if (dose > 20) {
                alertEl.className = 'alert alert-warning mb-3 fw-bold py-2';
                alertEl.textContent = 'เกิน Recommended Drug Dose (> 20 mcg/kg/min) — Max = 40';
                alertEl.classList.remove('d-none');
            } else {
                alertEl.classList.add('d-none');
                alertEl.textContent = '';
            }
        }
        calcDobutamineReverse();
        return result;
    }

    function calcDobutamineReverse() {
        var bw = getBw();
        var rate = num(document.getElementById('db_rev_rate') && document.getElementById('db_rev_rate').value);
        var conc = num(document.getElementById('db_rev_conc') && document.getElementById('db_rev_conc').value, 1);
        var box = document.getElementById('db_rev_result_box');
        var alertEl = document.getElementById('db_rev_alert');
        if (!(bw > 0) || !(rate > 0) || !(conc > 0)) {
            setText('db_rev_dose', '—');
            ['db_eq_1', 'db_eq_2', 'db_eq_3', 'db_eq_4', 'db_eq_5'].forEach(function (id) { setText(id, '—'); });
            if (alertEl) alertEl.classList.add('d-none');
            if (box) {
                box.style.background = '';
                box.style.borderColor = '';
            }
            return null;
        }
        // Dose (mcg/kg/min) = (rate_ml_hr × conc_mg_ml × 1000) / (bw × 60)
        var dose = (rate * conc * 1000) / (bw * 60);
        setText('db_rev_dose', fmt(dose, 3));

        // Equivalent rates at other concentrations (same drug amount/hr)
        var amountMgHr = rate * conc;
        for (var c = 1; c <= 5; c++) {
            setText('db_eq_' + c, fmt(amountMgHr / c, 2));
        }

        if (box) {
            if (dose > 40) {
                box.style.background = '#fecaca';
                box.style.borderColor = '#f87171';
            } else if (dose > 20) {
                box.style.background = '#fef08a';
                box.style.borderColor = '#facc15';
            } else {
                box.style.background = '#dcfce7';
                box.style.borderColor = '#86efac';
            }
        }
        if (alertEl) {
            if (dose > 40) {
                alertEl.className = 'dc-note mb-0';
                alertEl.style.background = '#fecaca';
                alertEl.style.borderLeftColor = '#dc2626';
                alertEl.textContent = 'สีแดง — เกิน Max dose (> 40 mcg/kg/min)';
                alertEl.classList.remove('d-none');
            } else if (dose > 20) {
                alertEl.className = 'dc-note mb-0';
                alertEl.style.background = '#fef08a';
                alertEl.style.borderLeftColor = '#ca8a04';
                alertEl.textContent = 'สีเหลือง — เกิน Recommended Drug Dose (> 20 mcg/kg/min)';
                alertEl.classList.remove('d-none');
            } else {
                alertEl.classList.add('d-none');
                alertEl.textContent = '';
            }
        }
        return { rate_ml_hr: rate, conc_mg_ml: conc, dose_mcg_kg_min: dose };
    }

    function dopamineEffectLabel(dose) {
        if (!(dose > 0)) return '';
        if (dose > 50) return 'เกินช่วงยา (> 50 mcg/kg/min)';
        if (dose >= 20) return 'High dose (20–50) — ↑ BP, vasoconstriction · Alpha';
        if (dose > 15) return 'ระหว่าง Medium–High (15–20) · Alpha';
        if (dose >= 5) return 'Medium dose (5–15) — ↑ CO, HR, contractility · Beta1 / Alpha';
        if (dose >= 1) return 'Low dose (1–5) — ↑ urine output, renal blood flow · Dopaminergic / Beta1';
        return 'Dopaminergic (0.5–2 mcg/kg/min)';
    }

    function calcDopamine() {
        var result = calcMcgKgMinInfusion('dp', 25);
        var dose = num(document.getElementById('dp_dose') && document.getElementById('dp_dose').value);
        var alertEl = document.getElementById('dp_dose_alert');
        if (alertEl) {
            if (dose > 50) {
                alertEl.className = 'alert alert-danger mb-3 fw-bold py-2';
                alertEl.textContent = 'เกินช่วงยา (> 50 mcg/kg/min)';
                alertEl.classList.remove('d-none');
            } else if (dose >= 20) {
                alertEl.className = 'alert alert-warning mb-3 fw-bold py-2';
                alertEl.textContent = dopamineEffectLabel(dose);
                alertEl.classList.remove('d-none');
            } else if (dose > 0) {
                alertEl.className = 'alert alert-info mb-3 fw-bold py-2';
                alertEl.textContent = dopamineEffectLabel(dose);
                alertEl.classList.remove('d-none');
            } else {
                alertEl.classList.add('d-none');
                alertEl.textContent = '';
            }
        }
        calcDopamineReverse();
        return result;
    }

    function calcDopamineReverse() {
        var bw = getBw();
        var rate = num(document.getElementById('dp_rev_rate') && document.getElementById('dp_rev_rate').value);
        var conc = num(document.getElementById('dp_rev_conc') && document.getElementById('dp_rev_conc').value, 1);
        var box = document.getElementById('dp_rev_result_box');
        var alertEl = document.getElementById('dp_rev_alert');
        if (!(bw > 0) || !(rate > 0) || !(conc > 0)) {
            setText('dp_rev_dose', '—');
            ['dp_eq_1', 'dp_eq_2', 'dp_eq_3', 'dp_eq_32'].forEach(function (id) { setText(id, '—'); });
            if (alertEl) alertEl.classList.add('d-none');
            if (box) {
                box.style.background = '';
                box.style.borderColor = '';
            }
            return null;
        }
        // Dose (mcg/kg/min) = (rate_ml_hr × conc_mg_ml × 1000) / (bw × 60)
        var dose = (rate * conc * 1000) / (bw * 60);
        setText('dp_rev_dose', fmt(dose, 3));

        var amountMgHr = rate * conc;
        setText('dp_eq_1', fmt(amountMgHr / 1, 2));
        setText('dp_eq_2', fmt(amountMgHr / 2, 2));
        setText('dp_eq_3', fmt(amountMgHr / 3, 2));
        setText('dp_eq_32', fmt(amountMgHr / 3.2, 2));

        if (box) {
            if (dose > 50) {
                box.style.background = '#fecaca';
                box.style.borderColor = '#f87171';
            } else if (dose >= 20) {
                box.style.background = '#fef08a';
                box.style.borderColor = '#facc15';
            } else {
                box.style.background = '#dcfce7';
                box.style.borderColor = '#86efac';
            }
        }
        if (alertEl) {
            if (dose > 0) {
                alertEl.className = 'dc-note mb-0';
                if (dose > 50) {
                    alertEl.style.background = '#fecaca';
                    alertEl.style.borderLeftColor = '#dc2626';
                } else if (dose >= 20) {
                    alertEl.style.background = '#fef08a';
                    alertEl.style.borderLeftColor = '#ca8a04';
                } else {
                    alertEl.style.background = '#e0f2fe';
                    alertEl.style.borderLeftColor = '#0284c7';
                }
                alertEl.textContent = dopamineEffectLabel(dose);
                alertEl.classList.remove('d-none');
            } else {
                alertEl.classList.add('d-none');
                alertEl.textContent = '';
            }
        }
        return { rate_ml_hr: rate, conc_mg_ml: conc, dose_mcg_kg_min: dose };
    }
    function neDoseBand(dose) {
        if (!(dose > 0)) return { level: '', label: '' };
        if (dose >= 3) return { level: 'red', label: 'สีแดง — เกิน Max (≥ 3 mcg/kg/min)' };
        if (dose >= 2) return { level: 'orange', label: 'สีส้ม — High dose (2–2.99 mcg/kg/min)' };
        if (dose >= 1) return { level: 'yellow', label: 'สีเหลือง — 1–1.99 mcg/kg/min' };
        return { level: 'normal', label: 'ปกติ (< 1 mcg/kg/min) · ช่วงยา 0.01–3' };
    }

    function neApplyBandStyles(box, alertEl, dose) {
        var band = neDoseBand(dose);
        if (box) {
            if (band.level === 'red') {
                box.style.background = '#fecaca';
                box.style.borderColor = '#f87171';
            } else if (band.level === 'orange') {
                box.style.background = '#fed7aa';
                box.style.borderColor = '#fb923c';
            } else if (band.level === 'yellow') {
                box.style.background = '#fef08a';
                box.style.borderColor = '#facc15';
            } else if (band.level === 'normal') {
                box.style.background = '#dcfce7';
                box.style.borderColor = '#86efac';
            } else {
                box.style.background = '';
                box.style.borderColor = '';
            }
        }
        if (alertEl) {
            if (!band.label) {
                alertEl.classList.add('d-none');
                alertEl.textContent = '';
                return;
            }
            alertEl.className = 'dc-note mb-0';
            if (band.level === 'red') {
                alertEl.style.background = '#fecaca';
                alertEl.style.borderLeftColor = '#dc2626';
            } else if (band.level === 'orange') {
                alertEl.style.background = '#fed7aa';
                alertEl.style.borderLeftColor = '#ea580c';
            } else if (band.level === 'yellow') {
                alertEl.style.background = '#fef08a';
                alertEl.style.borderLeftColor = '#ca8a04';
            } else {
                alertEl.style.background = '#e0f2fe';
                alertEl.style.borderLeftColor = '#0284c7';
            }
            alertEl.textContent = band.label;
            alertEl.classList.remove('d-none');
        }
    }

    function calcNorepinephrine() {
        var result = calcMcgKgMinInfusion('ne', 1);
        var dose = num(document.getElementById('ne_dose') && document.getElementById('ne_dose').value);
        var drugMg = num(document.getElementById('ne_drug_mg') && document.getElementById('ne_drug_mg').value);
        var totalMl = num(document.getElementById('ne_total_ml') && document.getElementById('ne_total_ml').value);
        var alertEl = document.getElementById('ne_dose_alert');
        var lineNote = document.getElementById('ne_line_note');
        var band = neDoseBand(dose);
        if (alertEl) {
            if (band.level === 'red') {
                alertEl.className = 'alert alert-danger mb-3 fw-bold py-2';
                alertEl.textContent = band.label;
                alertEl.classList.remove('d-none');
            } else if (band.level === 'orange') {
                alertEl.className = 'alert mb-3 fw-bold py-2';
                alertEl.style.background = '#fed7aa';
                alertEl.style.borderColor = '#fb923c';
                alertEl.style.color = '#9a3412';
                alertEl.textContent = band.label;
                alertEl.classList.remove('d-none');
            } else if (band.level === 'yellow') {
                alertEl.className = 'alert alert-warning mb-3 fw-bold py-2';
                alertEl.style.background = '';
                alertEl.style.borderColor = '';
                alertEl.style.color = '';
                alertEl.textContent = band.label;
                alertEl.classList.remove('d-none');
            } else if (band.level === 'normal') {
                alertEl.className = 'alert alert-info mb-3 fw-bold py-2';
                alertEl.style.background = '';
                alertEl.style.borderColor = '';
                alertEl.style.color = '';
                alertEl.textContent = band.label;
                alertEl.classList.remove('d-none');
            } else {
                alertEl.classList.add('d-none');
                alertEl.textContent = '';
                alertEl.style.background = '';
                alertEl.style.borderColor = '';
                alertEl.style.color = '';
            }
        }
        if (lineNote) {
            if (drugMg > 0 && totalMl > 0) {
                var concMcgMl = (drugMg * 1000) / totalMl;
                if (concMcgMl > 64) {
                    lineNote.style.background = '#fecaca';
                    lineNote.style.borderLeftColor = '#dc2626';
                    lineNote.textContent = 'ความเข้มข้น ' + fmt(concMcgMl, 1) + ' mcg/ml — เกิน MAX 64 mcg/ml · ต้องใช้ Central line';
                    lineNote.classList.remove('d-none');
                } else if (concMcgMl > 32) {
                    lineNote.style.background = '#fed7aa';
                    lineNote.style.borderLeftColor = '#ea580c';
                    lineNote.textContent = 'ความเข้มข้น ' + fmt(concMcgMl, 1) + ' mcg/ml — ต้องใช้ Central line (> 32 mcg/ml)';
                    lineNote.classList.remove('d-none');
                } else {
                    lineNote.style.background = '#e0f2fe';
                    lineNote.style.borderLeftColor = '#0284c7';
                    lineNote.textContent = 'ความเข้มข้น ' + fmt(concMcgMl, 1) + ' mcg/ml — Peripheral line ได้ (≤ 32 mcg/ml)';
                    lineNote.classList.remove('d-none');
                }
            } else {
                lineNote.classList.add('d-none');
                lineNote.textContent = '';
            }
        }
        calcNorepinephrineReverse();
        return result;
    }

    function calcNorepinephrineReverse() {
        var bw = getBw();
        var rate = num(document.getElementById('ne_rev_rate') && document.getElementById('ne_rev_rate').value);
        var conc = num(document.getElementById('ne_rev_conc') && document.getElementById('ne_rev_conc').value, 16);
        var box = document.getElementById('ne_rev_result_box');
        var alertEl = document.getElementById('ne_rev_alert');
        if (!(bw > 0) || !(rate > 0) || !(conc > 0)) {
            setText('ne_rev_dose', '—');
            ['ne_eq_16', 'ne_eq_32', 'ne_eq_40', 'ne_eq_64', 'ne_eq_80'].forEach(function (id) { setText(id, '—'); });
            if (alertEl) alertEl.classList.add('d-none');
            if (box) {
                box.style.background = '';
                box.style.borderColor = '';
            }
            return null;
        }
        // Dose (mcg/kg/min) = (rate_ml_hr × conc_mcg_ml) / (bw × 60)
        var dose = (rate * conc) / (bw * 60);
        setText('ne_rev_dose', fmt(dose, 4));

        var amountMcgHr = rate * conc;
        [16, 32, 40, 64, 80].forEach(function (c) {
            setText('ne_eq_' + c, fmt(amountMcgHr / c, 2));
        });

        var lineMsg = conc > 32
            ? (conc > 64 ? ' · Central · เกิน MAX 64' : ' · ต้องใช้ Central line')
            : ' · Peripheral ได้';
        neApplyBandStyles(box, alertEl, dose);
        if (alertEl && !alertEl.classList.contains('d-none')) {
            alertEl.textContent = (alertEl.textContent || '') + lineMsg;
        }
        return { rate_ml_hr: rate, conc_mcg_ml: conc, dose_mcg_kg_min: dose };
    }

    function calcCisatracurium() { return calcMcgKgMinInfusion('cs', 2); }
    function calcAdrenaline() { return calcMcgKgMinInfusion('ad', 1); }
    function calcAlprostadil() { return calcMcgKgMinInfusion('ap', 0.5, 3); }

    /* ——— Indomethacin ฉีด ——— */
    function calcIndomethacin() {
        var bw = getBw();
        var rows = [
            { key: 'lt48', doses: [0.2, 0.1, 0.1] },
            { key: '2to7', doses: [0.2, 0.2, 0.2] },
            { key: 'gt7', doses: [0.2, 0.25, 0.25] }
        ];
        var result = { conc_mg_ml: 0.5, rows: {} };
        if (bw <= 0) {
            rows.forEach(function (row) {
                for (var i = 1; i <= 3; i++) {
                    setText('in_mg_' + row.key + '_' + i, '—');
                    setText('in_ml_' + row.key + '_' + i, '—');
                }
            });
            return null;
        }
        rows.forEach(function (row) {
            var mgList = [];
            var mlList = [];
            row.doses.forEach(function (dPerKg, idx) {
                var mg = dPerKg * bw;
                var ml = mg / 0.5;
                var n = idx + 1;
                setText('in_mg_' + row.key + '_' + n, fmt(mg, 2));
                setText('in_ml_' + row.key + '_' + n, ml.toFixed(3));
                mgList.push(mg);
                mlList.push(ml);
            });
            result.rows[row.key] = { mg_per_kg: row.doses, mg: mgList, ml: mlList };
        });
        return result;
    }

    /* ——— NAC Paracetamol overdose ——— */
    function nacAmpFromMl(ml) {
        return Math.ceil(ml / 3 - 1e-12);
    }

    function nacFluidPlan(bw) {
        if (bw >= 40) {
            return {
                category: 'Adult (BW ≥ 40 kg)',
                fluids: [
                    '+ D5W 200 ml drip in 1 hr',
                    '+ D5W 500 ml drip in 4 hr',
                    '+ D5W 1000 ml drip in 16 hr'
                ]
            };
        }
        if (bw >= 20) {
            return {
                category: 'Children (20–40 kg)',
                fluids: [
                    '+ D5W 100 ml drip in 30 min',
                    '+ D5W 250 ml drip in 4 hr',
                    '+ D5W 500 ml drip in 16 hr'
                ]
            };
        }
        return {
            category: 'Children (BW < 20 kg)',
            fluids: [
                '+ D5W ' + fmt(bw * 3, 1) + ' ml drip in 30 min',
                '+ D5W ' + fmt(bw * 7, 1) + ' ml drip in 4 hr',
                '+ D5W ' + fmt(bw * 14, 1) + ' ml drip in 16 hr'
            ]
        };
    }

    function calcNac() {
        var bw = getBw();
        var ids = [
            'nac_category', 'nac_d1_mg', 'nac_d1_ml', 'nac_d1_fluid', 'nac_d1_amp',
            'nac_d2_mg', 'nac_d2_ml', 'nac_d2_fluid', 'nac_d2_amp',
            'nac_d3_mg', 'nac_d3_ml', 'nac_d3_fluid', 'nac_d3_amp',
            'nac_total_amp', 'nac_liv_mg', 'nac_liv_ml', 'nac_liv_amp'
        ];
        if (bw <= 0) {
            ids.forEach(function (id) { setText(id, '—'); });
            return null;
        }
        // Adult: BW ≥ 110 kg ให้ใช้ 110 kg คิด
        var bwCalc = Math.min(bw, 110);
        var plan = nacFluidPlan(bw);
        var factors = [150, 50, 100];
        var doses = [];
        var totalAmp = 0;
        factors.forEach(function (f, i) {
            var mg = f * bwCalc;
            var ml = mg / 100;
            var amp = nacAmpFromMl(ml);
            var n = i + 1;
            setText('nac_d' + n + '_mg', fmtIntComma(mg));
            setText('nac_d' + n + '_ml', fmt(ml, 2));
            setText('nac_d' + n + '_fluid', plan.fluids[i]);
            setText('nac_d' + n + '_amp', amp + ' amp');
            totalAmp += amp;
            doses.push({ mg_per_kg: f, mg: mg, ml: ml, amp: amp, fluid: plan.fluids[i] });
        });
        var catMsg = 'ช่วงน้ำหนัก: ' + plan.category;
        if (bw >= 110) {
            catMsg += ' · ใช้น้ำหนักคำนวณ 110 kg (จริง ' + fmt(bw, 1) + ' kg)';
        }
        setText('nac_category', catMsg);
        setText('nac_total_amp', String(totalAmp));

        var livMg = 150 * bwCalc;
        var livMl = livMg / 100;
        var livAmp = nacAmpFromMl(livMl);
        setText('nac_liv_mg', fmtIntComma(livMg));
        setText('nac_liv_ml', fmt(livMl, 2));
        setText('nac_liv_amp', livAmp + ' amp');

        return {
            category: plan.category,
            bw_actual: bw,
            bw_calc: bwCalc,
            doses: doses,
            total_amp: totalAmp,
            liver: { mg: livMg, ml: livMl, amp: livAmp }
        };
    }

    /* ——— LBW / Atracurium / Propofol / Ketamine ——— */
    function calcJamesLbw(abw, heightCm, sex) {
        if (!(abw > 0) || !(heightCm > 0)) return null;
        var ratio = abw / heightCm;
        var sq = ratio * ratio;
        if (sex === 'F') return 1.07 * abw - 148 * sq;
        return 1.10 * abw - 128 * sq;
    }

    function clearLbwDrugOutputs() {
        [
            'at_start_mg', 'at_max_mg', 'at_11_s', 'at_11_m', 'at_12_s', 'at_12_m',
            'at_21_s', 'at_21_m', 'at_101_s', 'at_101_m',
            'pf_start_mg', 'pf_max_mg', 'pf_start_ml', 'pf_max_ml',
            'kt_min_mcg', 'kt_max_mcg', 'kt_min_mg', 'kt_max_mg', 'kt_min_ml', 'kt_max_ml',
            'ktm_start_mg', 'ktm_max_mg', 'ktm_21_s', 'ktm_21_m', 'ktm_11_s', 'ktm_11_m'
        ].forEach(function (id) { setText(id, '—'); });
    }

    function applyLbwDrugRates(lbwUsed, abw) {
        clearLbwDrugOutputs();
        if (!(lbwUsed > 0)) return null;

        var atStart = 0.3 * lbwUsed;
        var atMax = 0.7 * lbwUsed;
        setText('at_start_mg', fmt(atStart, 2));
        setText('at_max_mg', fmt(atMax, 2));
        var dil = { '11': 1, '12': 0.5, '21': 2, '101': 10 };
        Object.keys(dil).forEach(function (k) {
            setText('at_' + k + '_s', fmt(atStart / dil[k], 2));
            setText('at_' + k + '_m', fmt(atMax / dil[k], 2));
        });

        // Propofol ใช้น้ำหนักตัวจริง (ABW)
        var pfBw = abw > 0 ? abw : lbwUsed;
        var pfStart = 1.5 * pfBw;
        var pfMax = 6 * pfBw;
        setText('pf_start_mg', fmt(pfStart, 2));
        setText('pf_max_mg', fmt(pfMax, 2));
        setText('pf_start_ml', fmt(pfStart / 10, 2));
        setText('pf_max_ml', fmt(pfMax / 10, 2));

        // Ketamine first dose — 50 mg/ml
        var ktMinMcg = 200 * lbwUsed;
        var ktMaxMcg = 750 * lbwUsed;
        var ktMinMg = ktMinMcg / 1000;
        var ktMaxMg = ktMaxMcg / 1000;
        setText('kt_min_mcg', fmt(ktMinMcg, 1));
        setText('kt_max_mcg', fmt(ktMaxMcg, 1));
        setText('kt_min_mg', fmt(ktMinMg, 3));
        setText('kt_max_mg', fmt(ktMaxMg, 3));
        setText('kt_min_ml', fmt(ktMinMg / 50, 3));
        setText('kt_max_ml', fmt(ktMaxMg / 50, 3));

        // Ketamine maintenance
        var ktmStart = 0.3 * lbwUsed;
        var ktmMax = 1.2 * lbwUsed;
        setText('ktm_start_mg', fmt(ktmStart, 2));
        setText('ktm_max_mg', fmt(ktmMax, 2));
        setText('ktm_21_s', fmt(ktmStart / 2, 2));
        setText('ktm_21_m', fmt(ktmMax / 2, 2));
        setText('ktm_11_s', fmt(ktmStart / 1, 2));
        setText('ktm_11_m', fmt(ktmMax / 1, 2));

        return {
            atracurium: { start_mg_hr: atStart, max_mg_hr: atMax },
            propofol: { bw: pfBw, start_mg_hr: pfStart, max_mg_hr: pfMax, start_ml_hr: pfStart / 10, max_ml_hr: pfMax / 10 },
            ketamine_first: {
                min_mcg: ktMinMcg, max_mcg: ktMaxMcg,
                min_mg: ktMinMg, max_mg: ktMaxMg,
                min_ml: ktMinMg / 50, max_ml: ktMaxMg / 50
            },
            ketamine_maint: { start_mg_hr: ktmStart, max_mg_hr: ktmMax }
        };
    }

    function calcLbw(opts) {
        opts = opts || {};
        var syncOverride = opts.syncOverride !== false;
        var abw = getBw();
        var ht = getHeight();
        var sexEl = document.getElementById('lbw_sex');
        var sex = sexEl ? sexEl.value : 'M';
        var overrideEl = document.getElementById('lbw_override');

        if (!(abw > 0) || !(ht > 0)) {
            setText('lbw_men', '—');
            setText('lbw_women', '—');
            if (overrideEl && syncOverride) overrideEl.value = '';
            clearLbwDrugOutputs();
            return null;
        }

        var lbwMen = calcJamesLbw(abw, ht, 'M');
        var lbwWomen = calcJamesLbw(abw, ht, 'F');
        var lbwCalc = sex === 'F' ? lbwWomen : lbwMen;
        setText('lbw_men', fmt(lbwMen, 2));
        setText('lbw_women', fmt(lbwWomen, 2));

        if (overrideEl && syncOverride) {
            overrideEl.value = fmt(lbwCalc, 2);
        }
        var lbwUsed = overrideEl && num(overrideEl.value) > 0 ? num(overrideEl.value) : lbwCalc;
        var drugs = applyLbwDrugRates(lbwUsed, abw);

        return {
            sex: sex,
            abw: abw,
            height: ht,
            lbw_men: lbwMen,
            lbw_women: lbwWomen,
            lbw_calc: lbwCalc,
            lbw_used: lbwUsed,
            drugs: drugs
        };
    }

    /* ——— Calcium gluconate 100 mg/ml ——— */
    function calcCalciumGlu() {
        var bw = getBw();
        var ids = ['cg_init_min_mg', 'cg_init_max_mg', 'cg_init_min_ml', 'cg_init_max_ml',
                   'cg_maint_min_mg', 'cg_maint_max_mg', 'cg_maint_min_ml', 'cg_maint_max_ml'];
        if (bw <= 0) {
            ids.forEach(function (id) { setText(id, '—'); });
            return null;
        }
        var stock = 100; // mg/ml
        var initMinMg = 100 * bw;
        var initMaxMg = 200 * bw;
        var maintMinMg = 200 * bw;
        var maintMaxMg = 800 * bw;
        setText('cg_init_min_mg', fmt(initMinMg, 1));
        setText('cg_init_max_mg', fmt(initMaxMg, 1));
        setText('cg_init_min_ml', fmt(initMinMg / stock, 2));
        setText('cg_init_max_ml', fmt(initMaxMg / stock, 2));
        setText('cg_maint_min_mg', fmt(maintMinMg, 1));
        setText('cg_maint_max_mg', fmt(maintMaxMg, 1));
        setText('cg_maint_min_ml', fmt(maintMinMg / stock, 2));
        setText('cg_maint_max_ml', fmt(maintMaxMg / stock, 2));
        return {
            init_min_mg: initMinMg, init_max_mg: initMaxMg,
            init_min_ml: initMinMg / stock, init_max_ml: initMaxMg / stock,
            maint_min_mg: maintMinMg, maint_max_mg: maintMaxMg,
            maint_min_ml: maintMinMg / stock, maint_max_ml: maintMaxMg / stock
        };
    }

    /* ——— Iloprost (ng/kg/min) ——— */
    function calcIloprost() {
        var bw = getBw();
        var dose = num(document.getElementById('il_dose') && document.getElementById('il_dose').value);
        var drugMcg = num(document.getElementById('il_drug_mcg') && document.getElementById('il_drug_mcg').value);
        var totalMl = num(document.getElementById('il_total_ml') && document.getElementById('il_total_ml').value);
        if (bw <= 0 || dose <= 0 || drugMcg <= 0 || totalMl <= 0) {
            ['il_mcg_hr', 'il_conc', 'il_rate'].forEach(function (id) { setText(id, '—'); });
            return null;
        }
        var ngHr = dose * bw * 60;
        var mcgHr = ngHr / 1000;
        var drugNg = drugMcg * 1000;
        var conc_ng_ml = drugNg / totalMl;
        var conc_mcg_ml = conc_ng_ml / 1000;
        var rate = ngHr / conc_ng_ml;
        setText('il_mcg_hr', fmt(mcgHr, 4));
        setText('il_conc', fmt(conc_mcg_ml, 4));
        setText('il_rate', fmt(rate, 4));
        return { dose_ng_kg_min: dose, drug_mcg: drugMcg, total_ml: totalMl, mcg_hr: mcgHr, conc_mcg_ml: conc_mcg_ml, rate_ml_hr: rate };
    }

    /* ——— KCL (mEq/hr) ——— */
    function kclBand(meqHr) {
        if (!(meqHr > 0)) return { level: '', label: '' };
        if (meqHr > 20) return { level: 'red', label: 'เกิน 20 mEq/hr — อันตราย ต้อง closely monitor' };
        if (meqHr >= 10) return { level: 'yellow', label: 'Central line (10–20 mEq/hr) · Closely monitor' };
        return { level: 'normal', label: 'Peripheral ได้ (< 10 mEq/hr)' };
    }

    function kclStyleBox(box, meqHr) {
        if (!box) return;
        var band = kclBand(meqHr);
        if (band.level === 'red') {
            box.style.background = '#fecaca';
            box.style.borderColor = '#f87171';
        } else if (band.level === 'yellow') {
            box.style.background = '#fef08a';
            box.style.borderColor = '#facc15';
        } else if (band.level === 'normal') {
            box.style.background = '#dcfce7';
            box.style.borderColor = '#86efac';
        } else {
            box.style.background = '';
            box.style.borderColor = '';
        }
    }

    function buildKclRefTable() {
        var tbody = document.getElementById('kcl_ref_tbody');
        if (!tbody || tbody.getAttribute('data-built') === '1') return;
        var rates = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120];
        var concs = [20, 40, 60, 80, 100, 120];
        var html = '';
        rates.forEach(function (rate) {
            html += '<tr><td class="fw-bold">' + rate + ' ml/hr</td>';
            concs.forEach(function (conc) {
                var meq = (conc * rate) / 1000;
                var bg = '';
                if (meq > 20) bg = 'background:#fecaca;';
                else if (meq >= 10) bg = 'background:#fef08a;';
                html += '<td style="' + bg + '">' + (meq % 1 === 0 ? meq.toFixed(0) : meq.toFixed(1)) + '</td>';
            });
            html += '</tr>';
        });
        tbody.innerHTML = html;
        tbody.setAttribute('data-built', '1');
    }

    function calcKcl() {
        buildKclRefTable();
        var conc = num(document.getElementById('kcl_conc') && document.getElementById('kcl_conc').value, 20);
        var rate = num(document.getElementById('kcl_rate') && document.getElementById('kcl_rate').value);
        var renal = !!(document.getElementById('kcl_renal') && document.getElementById('kcl_renal').checked);
        var box = document.getElementById('kcl_result_box');
        var alertEl = document.getElementById('kcl_dose_alert');
        var lineNote = document.getElementById('kcl_line_note');
        var halfWrap = document.getElementById('kcl_meq_hr_half_wrap');

        var meqHr = (conc > 0 && rate > 0) ? (conc * rate) / 1000 : null;
        if (meqHr == null) {
            setText('kcl_meq_hr', '—');
            setText('kcl_meq_hr_half', '—');
            if (halfWrap) halfWrap.classList.add('d-none');
            if (alertEl) alertEl.classList.add('d-none');
            if (lineNote) lineNote.classList.add('d-none');
            kclStyleBox(box, 0);
        } else {
            setText('kcl_meq_hr', fmt(meqHr, 2));
            var effective = renal ? meqHr * 0.5 : meqHr;
            if (renal && halfWrap) {
                setText('kcl_meq_hr_half', fmt(effective, 2));
                halfWrap.classList.remove('d-none');
            } else if (halfWrap) {
                halfWrap.classList.add('d-none');
            }
            kclStyleBox(box, effective);
            var band = kclBand(effective);
            if (alertEl) {
                if (band.level === 'red') {
                    alertEl.className = 'alert alert-danger mb-3 fw-bold py-2';
                } else if (band.level === 'yellow') {
                    alertEl.className = 'alert alert-warning mb-3 fw-bold py-2';
                } else {
                    alertEl.className = 'alert alert-info mb-3 fw-bold py-2';
                }
                alertEl.textContent = band.label + (renal ? ' · (คำนวณหลังลด 50% สำหรับไตเสื่อม)' : '');
                alertEl.classList.remove('d-none');
            }
            if (lineNote) {
                if (conc >= 80) {
                    lineNote.style.background = '#fed7aa';
                    lineNote.style.borderLeftColor = '#ea580c';
                    lineNote.textContent = 'ความเข้มข้น ' + conc + ' mEq/L — ใช้ Central line';
                } else {
                    lineNote.style.background = '#e0f2fe';
                    lineNote.style.borderLeftColor = '#0284c7';
                    lineNote.textContent = 'ความเข้มข้น ' + conc + ' mEq/L — Peripheral ได้ถ้า rate < 10 mEq/hr';
                }
                lineNote.classList.remove('d-none');
            }
        }

        // Reverse: mEq/hr → rate
        var want = num(document.getElementById('kcl_rev_meq') && document.getElementById('kcl_rev_meq').value);
        var revConc = num(document.getElementById('kcl_rev_conc') && document.getElementById('kcl_rev_conc').value, 40);
        var revAlert = document.getElementById('kcl_rev_alert');
        var wantEff = renal && want > 0 ? want * 0.5 : want;
        if (wantEff > 0 && revConc > 0) {
            var revRate = (wantEff * 1000) / revConc;
            setText('kcl_rev_rate', fmt(revRate, 1));
            if (revAlert) {
                var rb = kclBand(wantEff);
                revAlert.className = 'dc-note mb-0';
                if (rb.level === 'red') {
                    revAlert.style.background = '#fecaca';
                    revAlert.style.borderLeftColor = '#dc2626';
                } else if (rb.level === 'yellow') {
                    revAlert.style.background = '#fef08a';
                    revAlert.style.borderLeftColor = '#ca8a04';
                } else {
                    revAlert.style.background = '#e0f2fe';
                    revAlert.style.borderLeftColor = '#0284c7';
                }
                revAlert.textContent = rb.label + (renal ? ' · ใช้ขนาด 50%' : '');
                revAlert.classList.remove('d-none');
            }
        } else {
            setText('kcl_rev_rate', '—');
            if (revAlert) revAlert.classList.add('d-none');
        }

        // Mix → concentration
        var mixMeq = num(document.getElementById('kcl_mix_meq') && document.getElementById('kcl_mix_meq').value);
        var mixVol = num(document.getElementById('kcl_mix_vol') && document.getElementById('kcl_mix_vol').value);
        if (mixMeq > 0 && mixVol > 0) {
            setText('kcl_mix_conc', fmt((mixMeq * 1000) / mixVol, 1));
        } else {
            setText('kcl_mix_conc', '—');
        }

        return {
            conc_meq_l: conc,
            rate_ml_hr: rate,
            meq_hr: meqHr,
            meq_hr_effective: meqHr != null && renal ? meqHr * 0.5 : meqHr,
            renal_half: renal,
            rev_meq_hr: want,
            rev_rate_ml_hr: (wantEff > 0 && revConc > 0) ? (wantEff * 1000) / revConc : null,
            mix_meq: mixMeq,
            mix_vol_ml: mixVol
        };
    }

    /* ——— NTG / Nitroglycerine (mcg/min) ——— */
    function calcNtg() {
        var dose = num(document.getElementById('ntg_dose') && document.getElementById('ntg_dose').value);
        var drugMg = num(document.getElementById('ntg_drug_mg') && document.getElementById('ntg_drug_mg').value);
        var totalMl = num(document.getElementById('ntg_total_ml') && document.getElementById('ntg_total_ml').value);
        var alertEl = document.getElementById('ntg_dose_alert');
        var concNote = document.getElementById('ntg_conc_note');
        var mcgHr = null;
        var conc = null;
        var rate = null;

        if (dose > 0 && drugMg > 0 && totalMl > 0) {
            mcgHr = dose * 60;
            conc = (drugMg * 1000) / totalMl;
            rate = mcgHr / conc;
            setText('ntg_mcg_hr', fmt(mcgHr, 2));
            setText('ntg_conc', fmt(conc, 1));
            setText('ntg_rate', fmt(rate, 3));
        } else {
            ['ntg_mcg_hr', 'ntg_conc', 'ntg_rate'].forEach(function (id) { setText(id, '—'); });
        }

        if (alertEl) {
            if (dose > 400) {
                alertEl.className = 'alert alert-danger mb-3 fw-bold py-2';
                alertEl.textContent = 'เกิน Max dose Angina/CAD (> 400 mcg/min)';
                alertEl.classList.remove('d-none');
            } else if (dose > 200) {
                alertEl.className = 'alert alert-warning mb-3 fw-bold py-2';
                alertEl.textContent = 'สูงกว่า Max ของ HF / Pulmonary edema (200) — Max Angina = 400 mcg/min';
                alertEl.classList.remove('d-none');
            } else if (dose > 0) {
                alertEl.className = 'alert alert-info mb-3 fw-bold py-2';
                alertEl.textContent = 'ขนาดยา ' + fmt(dose, 1) + ' mcg/min · เริ่มทั่วไป 5 mcg/min (HF 10–20)';
                alertEl.classList.remove('d-none');
            } else {
                alertEl.classList.add('d-none');
                alertEl.textContent = '';
            }
        }
        if (concNote) {
            if (conc != null) {
                if (conc > 400) {
                    concNote.style.background = '#fecaca';
                    concNote.style.borderLeftColor = '#dc2626';
                    concNote.textContent = 'เกิน MAX 400 mcg/ml (สูงสุดประมาณ 500)';
                } else if (conc > 200) {
                    concNote.style.background = '#fef08a';
                    concNote.style.borderLeftColor = '#ca8a04';
                    concNote.textContent = 'ความเข้มข้นสูง — ใช้ non-PVC / ขวดแก้ว';
                } else {
                    concNote.style.background = '#e0f2fe';
                    concNote.style.borderLeftColor = '#0284c7';
                    concNote.textContent = 'ใช้ขวดแก้วหรือ non-PVC set';
                }
                concNote.classList.remove('d-none');
            } else {
                concNote.classList.add('d-none');
            }
        }

        // Reverse
        var revRate = num(document.getElementById('ntg_rev_rate') && document.getElementById('ntg_rev_rate').value);
        var revConc = num(document.getElementById('ntg_rev_conc') && document.getElementById('ntg_rev_conc').value, 200);
        var box = document.getElementById('ntg_rev_result_box');
        var revAlert = document.getElementById('ntg_rev_alert');
        if (revRate > 0 && revConc > 0) {
            var revDose = (revRate * revConc) / 60;
            setText('ntg_rev_dose', fmt(revDose, 3));
            var amountMcgHr = revRate * revConc;
            [50, 100, 200, 400].forEach(function (c) {
                setText('ntg_eq_' + c, fmt(amountMcgHr / c, 2));
            });
            if (box) {
                if (revDose > 400) {
                    box.style.background = '#fecaca';
                    box.style.borderColor = '#f87171';
                } else if (revDose > 200) {
                    box.style.background = '#fef08a';
                    box.style.borderColor = '#facc15';
                } else {
                    box.style.background = '#dcfce7';
                    box.style.borderColor = '#86efac';
                }
            }
            if (revAlert) {
                revAlert.className = 'dc-note mb-0';
                if (revDose > 400) {
                    revAlert.style.background = '#fecaca';
                    revAlert.style.borderLeftColor = '#dc2626';
                    revAlert.textContent = 'เกิน Max 400 mcg/min';
                } else if (revDose > 200) {
                    revAlert.style.background = '#fef08a';
                    revAlert.style.borderLeftColor = '#ca8a04';
                    revAlert.textContent = '> Max HF/PE (200)';
                } else {
                    revAlert.style.background = '#e0f2fe';
                    revAlert.style.borderLeftColor = '#0284c7';
                    revAlert.textContent = 'อยู่ในช่วงทั่วไป';
                }
                revAlert.classList.remove('d-none');
            }
        } else {
            setText('ntg_rev_dose', '—');
            ['ntg_eq_50', 'ntg_eq_100', 'ntg_eq_200', 'ntg_eq_400'].forEach(function (id) { setText(id, '—'); });
            if (revAlert) revAlert.classList.add('d-none');
            if (box) {
                box.style.background = '';
                box.style.borderColor = '';
            }
        }

        return {
            dose_mcg_min: dose,
            drug_mg: drugMg,
            total_ml: totalMl,
            mcg_hr: mcgHr,
            conc_mcg_ml: conc,
            rate_ml_hr: rate,
            rev_rate: revRate,
            rev_conc: revConc
        };
    }

    /* ——— ARV เด็ก ——— */
    var ARV_PROPHYLAXIS_ROWS = [
        { group: 'Standard risk · GA ≥ 35 wk', drug: 'Zidovudine', conc: 10, mgkg: 4, freq: 'q 12 hr', perDay: 2, weeks: 4, tone: '#dcfce7' },
        { group: 'High risk · GA ≥ 35 wk', drug: 'Zidovudine', conc: 10, mgkg: 4, freq: 'q 12 hr', perDay: 2, weeks: 4, tone: '#fecaca' },
        { group: 'High risk · GA ≥ 35 wk', drug: 'Lamivudine', conc: 10, mgkg: 2, freq: 'q 12 hr', perDay: 2, weeks: 4, tone: '#fecaca' },
        { group: 'High risk · GA ≥ 35 wk', drug: 'Nevirapine', conc: 10, mgkg: 4, freq: 'q 24 hr', perDay: 1, weeks: 2, tone: '#fecaca' },
        { group: 'High risk · GA 30–35 wk', drug: 'Zidovudine', conc: 10, mgkg: 2, freq: 'q 12 hr', perDay: 2, weeks: 4, tone: '#e9d5ff' },
        { group: 'High risk · GA 30–35 wk', drug: 'Lamivudine', conc: 10, mgkg: 2, freq: 'q 12 hr', perDay: 2, weeks: 4, tone: '#e9d5ff' },
        { group: 'High risk · GA 30–35 wk', drug: 'Nevirapine', conc: 10, mgkg: 2, freq: 'q 24 hr', perDay: 1, weeks: 2, tone: '#e9d5ff' },
        { group: 'Prophylaxis อายุ < 4 สัปดาห์', drug: 'Zidovudine', conc: 10, mgkg: 2, freq: 'q 8 hr', perDay: 3, weeks: 4, tone: '#fecaca' },
        { group: 'Prophylaxis อายุ < 4 สัปดาห์', drug: 'Lamivudine', conc: 10, mgkg: 2, freq: 'q 12 hr', perDay: 2, weeks: 4, tone: '#fecaca' },
        { group: 'Prophylaxis อายุ < 4 สัปดาห์', drug: 'Nevirapine', conc: 10, mgkg: 4, freq: 'q 24 hr', perDay: 1, weeks: 4, tone: '#fecaca' }
    ];

    var ARV_WEIGHT_REF = [
        { min: 3, max: 4, label: '3–4', azt: 4, tc: 1.5, lpv: 0.5, nvp: 2 },
        { min: 4, max: 5, label: '4–5', azt: 5, tc: 2, lpv: 0.6, nvp: 2.5 },
        { min: 5, max: 6, label: '5–6', azt: 6, tc: 2.5, lpv: 0.8, nvp: 3 },
        { min: 6, max: 7, label: '6–7', azt: 7, tc: 3, lpv: 0.9, nvp: 3.5 },
        { min: 7, max: 9, label: '7–9', azt: 8, tc: 3.5, lpv: 1.2, nvp: 4 },
        { min: 9, max: 12, label: '9–12', azt: 10, tc: 4.5, lpv: 1.5, nvp: 5 },
        { min: 12, max: 15, label: '12–15', azt: 12, tc: 5.5, lpv: 1.8, nvp: 6 }
    ];

    function calcArvPed() {
        var bw = getBw();
        var height = getHeight();
        var bottle = num(document.getElementById('arv_bottle_ml') && document.getElementById('arv_bottle_ml').value, 60);
        if (!(bottle > 0)) bottle = 60;
        var bsa = (bw > 0 && height > 0) ? Math.sqrt((bw * height) / 3600) : null;

        setText('arv_bw', bw > 0 ? fmt(bw, 2) : '—');
        setText('arv_bsa', bsa != null ? fmt(bsa, 3) : '—');

        var tbody = document.getElementById('arv_calc_tbody');
        if (tbody) {
            var html = '';
            var lastGroup = '';
            ARV_PROPHYLAXIS_ROWS.forEach(function (row) {
                var mg = (bw > 0) ? bw * row.mgkg : null;
                var ml = (mg != null && row.conc > 0) ? mg / row.conc : null;
                var days = row.weeks * 7;
                var bottles = (ml != null && bottle > 0) ? (ml * row.perDay * days) / bottle : null;
                var showGroup = row.group !== lastGroup;
                lastGroup = row.group;
                html += '<tr style="background:' + row.tone + ';">';
                html += '<td>' + (showGroup ? '<strong>' + row.group + '</strong>' : '') + '</td>';
                html += '<td>' + row.drug + '</td>';
                html += '<td>' + row.conc + ' mg/ml</td>';
                html += '<td>' + row.mgkg + '</td>';
                html += '<td>' + row.freq + '</td>';
                html += '<td>' + (mg != null ? fmt(mg, 2) : '—') + '</td>';
                html += '<td>' + (ml != null ? fmt(ml, 3) : '—') + '</td>';
                html += '<td>' + (bottles != null ? fmt(bottles, 2) : '—') + '</td>';
                html += '</tr>';
            });
            tbody.innerHTML = html;
        }

        var refBody = document.getElementById('arv_ref_tbody');
        if (refBody) {
            var refHtml = '';
            ARV_WEIGHT_REF.forEach(function (r) {
                var match = bw >= r.min && bw < r.max;
                refHtml += '<tr' + (match ? ' style="background:#fef08a;font-weight:700;"' : '') + '>';
                refHtml += '<td>' + r.label + '</td>';
                refHtml += '<td>' + r.azt + ' ซีซี</td>';
                refHtml += '<td>' + r.tc + ' ซีซี</td>';
                refHtml += '<td>' + r.lpv + ' ซีซี</td>';
                refHtml += '<td>' + r.nvp + ' ซีซี</td>';
                refHtml += '</tr>';
            });
            refBody.innerHTML = refHtml;
        }

        var txBody = document.getElementById('arv_tx_tbody');
        if (txBody) {
            var txHtml = '';
            if (!(bw > 0)) {
                txHtml = '<tr><td colspan="5" class="text-muted">กรอกน้ำหนักด้านบน</td></tr>';
            } else {
                var aztMg = bsa != null ? Math.min(240 * bsa, 300) : null;
                var aztMl = aztMg != null ? aztMg / 10 : null;
                var tcMg = Math.min(4 * bw, 150);
                var tcMl = tcMg / 10;
                var nvpMg = bsa != null ? Math.min(200 * bsa, 200) : null;
                var nvpMl = nvpMg != null ? nvpMg / 10 : null;
                var lpvMg = bsa != null ? 230 * bsa : null; // LPV component approx
                var lpvMl = lpvMg != null ? lpvMg / 80 : null;

                function txRow(name, formula, freq, mg, ml) {
                    return '<tr><td><strong>' + name + '</strong></td><td>' + formula + '</td><td>' + freq + '</td><td>' +
                        (mg != null ? fmt(mg, 1) + ' mg' : '—') + '</td><td>' +
                        (ml != null ? fmt(ml, 2) + ' ml' : '—') + '</td></tr>';
                }
                txHtml += txRow('Zidovudine (AZT)', '180–240 mg/m²/dose (ใช้ 240) · Max 300', 'BID', aztMg, aztMl);
                txHtml += txRow('Lamivudine (3TC)', '4 mg/kg/dose · Max 150 mg', 'BID', tcMg, tcMl);
                txHtml += txRow('Nevirapine (NVP)', '160–200 mg/m²/dose (ใช้ 200) · Max 200 · lead-in 14 วันให้ QD', 'BID', nvpMg, nvpMl);
                txHtml += txRow('LPV/r', '~230 mg/m² LPV · syrup 80/20 mg/ml', 'BID', lpvMg, lpvMl);
            }
            txBody.innerHTML = txHtml;
        }

        return {
            bw: bw,
            height: height,
            bsa: bsa,
            bottle_ml: bottle
        };
    }

    /* ——— TB / anti-TBs ——— */
    var TB_DRUGS = [
        { name: 'Isoniazid', pill: 100, minKg: 4, maxKg: 6, maxDay: 300 },
        { name: 'Rifampin', pill: 300, minKg: 8, maxKg: 12, maxDay: 600 },
        { name: 'Rifampin', pill: 450, minKg: 8, maxKg: 12, maxDay: 600 },
        { name: 'Pyrazinamide', pill: 500, minKg: 20, maxKg: 30, maxDay: 2000 },
        { name: 'Ethambutol', pill: 400, minKg: 15, maxKg: 25, maxDay: 1600 },
        { name: 'Ethambutol', pill: 500, minKg: 15, maxKg: 25, maxDay: 1600 },
        { name: 'Streptomycin', pill: 1000, minKg: 12, maxKg: 18, maxDay: 1000 },
        { name: 'Kanamycin', pill: 1000, minKg: 15, maxKg: 20, maxDay: 1000 },
        { name: 'Levofloxacin', pill: 500, minKg: 7.5, maxKg: 15, maxDay: 1000 },
        { name: 'Ethionamide', pill: 250, minKg: 15, maxKg: 20, maxDay: 1000 },
        { name: 'Cycloserine', pill: 250, minKg: 10, maxKg: 20, maxDay: 1000 },
        { name: 'PAS', pill: 4000, minKg: 150, maxKg: 200, maxDay: 12000 }
    ];

    var TB_MDR_ROWS = [
        { name: 'Bedaquiline', vals: ['400→200×3/wk', '400→200×3/wk', '400→200×3/wk', '400→200×3/wk', '400→200×3/wk'] },
        { name: 'Levofloxacin', vals: ['750', '750', '1000', '1000', '1000'] },
        { name: 'Moxifloxacin', vals: ['400', '400', '400', '400', '400'] },
        { name: 'Prothionamide', vals: ['500', '750', '750', '1000', '1000'] },
        { name: 'Ethionamide', vals: ['500', '750', '750', '1000', '1000'] },
        { name: 'Clofazimine', vals: ['100', '100', '100', '100', '100'] },
        { name: 'Pyrazinamide', vals: ['1000', '1500', '1500', '1750', '2000'] },
        { name: 'Isoniazid', vals: ['400', '400', '500', '600', '600'] },
        { name: 'Ethambutol', vals: ['800', '800', '1000', '1200', '1200'] }
    ];

    var TB_COURSES = [
        { title: '[สูตร 6 เดือน] 2 HRZE + 4 HR', color: '#fce7f3', phases: [{ months: 2, drug: 'HRZE' }, { months: 4, drug: 'HR' }] },
        { title: '[สูตร 7 เดือน] 3 HRZE + 4 HR', color: '#ffedd5', phases: [{ months: 3, drug: 'HRZE' }, { months: 4, drug: 'HR' }] },
        { title: '[สูตร 9 เดือน] 3 HRZE + 6 HR', color: '#dcfce7', phases: [{ months: 3, drug: 'HRZE' }, { months: 6, drug: 'HR' }] }
    ];

    function tbPillsFor(mgNeeded, pillMg, maxDay) {
        if (!(pillMg > 0) || !(mgNeeded > 0)) return 0;
        var capped = Math.min(mgNeeded, maxDay);
        var n = Math.round(capped / pillMg);
        if (n < 1) n = 1;
        while (n * pillMg > maxDay && n > 1) n--;
        return n;
    }

    function tbAddMonths(dateStr, months) {
        if (!dateStr) return null;
        var parts = dateStr.split('-');
        if (parts.length < 3) return null;
        var d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
        if (isNaN(d.getTime())) return null;
        var day = d.getDate();
        d.setMonth(d.getMonth() + months);
        // clamp day if month overflow (e.g. Jan 31 + 1 mo)
        if (d.getDate() !== day) d.setDate(0);
        return d;
    }

    function tbFmtDate(d) {
        if (!d) return '—';
        var dd = String(d.getDate()).padStart(2, '0');
        var mm = String(d.getMonth() + 1).padStart(2, '0');
        return dd + '/' + mm + '/' + d.getFullYear();
    }

    function tbMdrBandIndex(bw) {
        if (!(bw > 0)) return -1;
        if (bw <= 35) return 0;
        if (bw <= 45) return 1;
        if (bw <= 55) return 2;
        if (bw <= 70) return 3;
        return 4;
    }

    function calcTb() {
        var bw = getBw();
        setText('tb_bw', bw > 0 ? fmt(bw, 1) : '—');

        var tbody = document.getElementById('tb_drug_tbody');
        if (tbody) {
            var html = '';
            if (!(bw > 0)) {
                html = '<tr><td colspan="7" class="text-muted">กรอกน้ำหนักด้านบน</td></tr>';
            } else {
                TB_DRUGS.forEach(function (d) {
                    var mgMin = bw * d.minKg;
                    var mgMax = bw * d.maxKg;
                    var pillsMin = tbPillsFor(mgMin, d.pill, d.maxDay);
                    var pillsMax = tbPillsFor(mgMax, d.pill, d.maxDay);
                    var mid = (mgMin + mgMax) / 2;
                    var pills = tbPillsFor(mid, d.pill, d.maxDay);
                    html += '<tr>';
                    html += '<td><strong>' + d.name + '</strong></td>';
                    html += '<td>' + d.pill + '</td>';
                    html += '<td class="fw-bold text-success">' + pills + '</td>';
                    html += '<td>' + pillsMin + ' / ' + pillsMax + '</td>';
                    html += '<td>' + d.minKg + '–' + d.maxKg + '</td>';
                    html += '<td>' + fmt(mgMin, 0) + '–' + fmt(mgMax, 0) + '</td>';
                    html += '<td>' + d.maxDay + '</td>';
                    html += '</tr>';
                });
            }
            tbody.innerHTML = html;
        }

        // Combination
        if (bw >= 71) {
            setText('tb_rifafour', '5');
            setText('tb_rifafour_note', '≥ 71 kg');
            setText('tb_rifinah', 'Rifinah 300 × 2');
            setText('tb_rifinah_note', 'H300 + R600');
        } else if (bw >= 55) {
            setText('tb_rifafour', '4');
            setText('tb_rifafour_note', '55–70 kg');
            setText('tb_rifinah', 'Rifinah 300 × 2');
            setText('tb_rifinah_note', 'H300 + R600');
        } else if (bw >= 38) {
            setText('tb_rifafour', '3');
            setText('tb_rifafour_note', '38–54 kg');
            setText('tb_rifinah', 'Rifinah 150 × 3');
            setText('tb_rifinah_note', '≈ H300 + R450');
        } else if (bw >= 30) {
            setText('tb_rifafour', '2');
            setText('tb_rifafour_note', '30–37 kg');
            setText('tb_rifinah', 'Rifinah 150 × 2');
            setText('tb_rifinah_note', '≈ H200 + R300');
        } else {
            setText('tb_rifafour', bw > 0 ? 'ปรึกษาแพทย์' : '—');
            setText('tb_rifafour_note', bw > 0 ? '< 30 kg' : '');
            setText('tb_rifinah', bw > 0 ? 'ปรึกษาแพทย์' : '—');
            setText('tb_rifinah_note', '');
        }

        // MDR table
        var mdrBody = document.getElementById('tb_mdr_tbody');
        var band = tbMdrBandIndex(bw);
        if (mdrBody) {
            var mhtml = '';
            TB_MDR_ROWS.forEach(function (row) {
                mhtml += '<tr><td class="text-start fw-bold">' + row.name + '</td>';
                row.vals.forEach(function (v, i) {
                    var hl = (i === band) ? ' style="background:#fef08a;font-weight:700;"' : '';
                    mhtml += '<td' + hl + '>' + v + '</td>';
                });
                mhtml += '</tr>';
            });
            mdrBody.innerHTML = mhtml;
        }

        // Course dates
        var startEl = document.getElementById('tb_start_date');
        var start = startEl && startEl.value ? startEl.value : '';
        if (startEl && !startEl.value) {
            var today = new Date();
            var yyyy = today.getFullYear();
            var mm = String(today.getMonth() + 1).padStart(2, '0');
            var dd = String(today.getDate()).padStart(2, '0');
            startEl.value = yyyy + '-' + mm + '-' + dd;
            start = startEl.value;
        }
        var boxes = document.getElementById('tb_course_boxes');
        if (boxes) {
            var bhtml = '';
            TB_COURSES.forEach(function (course) {
                bhtml += '<div class="mb-3 p-3 rounded" style="background:' + course.color + ';border:1px solid #ddd;">';
                bhtml += '<div class="fw-bold mb-2">' + course.title + '</div>';
                bhtml += '<div class="table-responsive"><table class="table table-sm table-bordered bg-white mb-0"><thead class="table-light"><tr><th>เดือน</th><th>ยา</th><th>START</th><th>ครบ Course</th></tr></thead><tbody>';
                var cursor = start;
                course.phases.forEach(function (ph) {
                    var sDate = cursor ? new Date(cursor + 'T00:00:00') : null;
                    var eDate = tbAddMonths(cursor, ph.months);
                    // end date is day before next phase start, or last day of phase: start + months - 1 day
                    var endShow = eDate ? new Date(eDate.getTime()) : null;
                    if (endShow) endShow.setDate(endShow.getDate() - 1);
                    bhtml += '<tr><td>' + ph.months + '</td><td><strong>' + ph.drug + '</strong></td><td>' +
                        tbFmtDate(sDate) + '</td><td>' + tbFmtDate(endShow) + '</td></tr>';
                    if (eDate) {
                        cursor = eDate.getFullYear() + '-' +
                            String(eDate.getMonth() + 1).padStart(2, '0') + '-' +
                            String(eDate.getDate()).padStart(2, '0');
                    }
                });
                bhtml += '</tbody></table></div></div>';
            });
            boxes.innerHTML = bhtml;
        }

        return { bw: bw, start_date: start };
    }

    function recalcAll() {
        var bolus = calcBolus();
        var mzMin = calcMidazolam();
        var mzHr = calcMidazolamHr();
        return {
            methylpred: calcMethylpred(),
            rtpa_stemi: calcRtpaStemi(),
            rtpa_stroke: calcRtpaStroke(),
            tnk_stroke: calcTnkStroke(),
            tnk_stemi: calcTnkStemi(),
            bolus: bolus,
            midazolam: { bolus: bolus, min: mzMin, hr: mzHr },
            midazolam_hr: mzHr,
            fentanyl: calcFentanyl(),
            dobutamine: calcDobutamine(),
            dopamine: calcDopamine(),
            norepinephrine: calcNorepinephrine(),
            cisatracurium: calcCisatracurium(),
            adrenaline: calcAdrenaline(),
            calcium_glu: calcCalciumGlu(),
            alprostadil: calcAlprostadil(),
            indomethacin: calcIndomethacin(),
            nac: calcNac(),
            lbw: calcLbw(),
            iloprost: calcIloprost(),
            kcl: calcKcl(),
            ntg: calcNtg(),
            arv_ped: calcArvPed(),
            tb: calcTb()
        };
    }

    function collectInputs(calcType) {
        var base = { bw: getBw(), height: getHeight(), age: getAge() };
        if (calcType === 'methylpred') {
            base.hours = num(document.getElementById('mp_hours').value, 24);
            base.volume_ml = num(document.getElementById('mp_vol').value, 500);
        } else if (calcType === 'bolus') {
            base.midazolam_order_mg = num(document.getElementById('bl_mz_order_mg').value);
            base.fentanyl_order_mcg = num(document.getElementById('bl_fn_order_mcg').value);
        } else if (calcType === 'midazolam') {
            base.bolus_order_mg = num(document.getElementById('bl_mz_order_mg') && document.getElementById('bl_mz_order_mg').value);
            base.min_dose = num(document.getElementById('mz_dose').value);
            base.min_drug_mg = num(document.getElementById('mz_drug_mg').value);
            base.min_total_ml = num(document.getElementById('mz_total_ml').value);
            base.hr_dose = num(document.getElementById('mzh_dose').value);
            base.hr_drug_mg = num(document.getElementById('mzh_drug_mg').value);
            base.hr_total_ml = num(document.getElementById('mzh_total_ml').value);
            base.rev_rate = num(document.getElementById('mzh_rev_rate') && document.getElementById('mzh_rev_rate').value);
            base.rev_conc = num(document.getElementById('mzh_rev_conc') && document.getElementById('mzh_rev_conc').value, 1);
        } else if (calcType === 'midazolam_hr') {
            base.dose = num(document.getElementById('mzh_dose').value);
            base.drug_mg = num(document.getElementById('mzh_drug_mg').value);
            base.total_ml = num(document.getElementById('mzh_total_ml').value);
        } else if (calcType === 'fentanyl') {
            base.bolus_order_mcg = num(document.getElementById('bl_fn_order_mcg') && document.getElementById('bl_fn_order_mcg').value);
            base.dose = num(document.getElementById('fn_dose').value);
            base.drug_mg = num(document.getElementById('fn_drug_mg').value);
            base.total_ml = num(document.getElementById('fn_total_ml').value);
        } else if (calcType === 'dobutamine') {
            base.dose = num(document.getElementById('db_dose').value);
            base.drug_mg = num(document.getElementById('db_drug_mg').value);
            base.total_ml = num(document.getElementById('db_total_ml').value);
            base.rev_rate = num(document.getElementById('db_rev_rate') && document.getElementById('db_rev_rate').value);
            base.rev_conc = num(document.getElementById('db_rev_conc') && document.getElementById('db_rev_conc').value, 1);
        } else if (calcType === 'dopamine') {
            base.dose = num(document.getElementById('dp_dose').value);
            base.drug_mg = num(document.getElementById('dp_drug_mg').value);
            base.total_ml = num(document.getElementById('dp_total_ml').value);
            base.rev_rate = num(document.getElementById('dp_rev_rate') && document.getElementById('dp_rev_rate').value);
            base.rev_conc = num(document.getElementById('dp_rev_conc') && document.getElementById('dp_rev_conc').value, 1);
        } else if (calcType === 'norepinephrine') {
            base.dose = num(document.getElementById('ne_dose').value);
            base.drug_mg = num(document.getElementById('ne_drug_mg').value);
            base.total_ml = num(document.getElementById('ne_total_ml').value);
            base.rev_rate = num(document.getElementById('ne_rev_rate') && document.getElementById('ne_rev_rate').value);
            base.rev_conc = num(document.getElementById('ne_rev_conc') && document.getElementById('ne_rev_conc').value, 16);
        } else if (calcType === 'cisatracurium') {
            base.dose = num(document.getElementById('cs_dose').value);
            base.drug_mg = num(document.getElementById('cs_drug_mg').value);
            base.total_ml = num(document.getElementById('cs_total_ml').value);
        } else if (calcType === 'adrenaline') {
            base.dose = num(document.getElementById('ad_dose').value);
            base.drug_mg = num(document.getElementById('ad_drug_mg').value);
            base.total_ml = num(document.getElementById('ad_total_ml').value);
        } else if (calcType === 'alprostadil') {
            base.dose = num(document.getElementById('ap_dose').value);
            base.drug_mg = num(document.getElementById('ap_drug_mg').value);
            base.total_ml = num(document.getElementById('ap_total_ml').value);
        } else if (calcType === 'lbw') {
            base.sex = (document.getElementById('lbw_sex') && document.getElementById('lbw_sex').value) || 'M';
            base.lbw = num(document.getElementById('lbw_override') && document.getElementById('lbw_override').value);
        } else if (calcType === 'iloprost') {
            base.dose = num(document.getElementById('il_dose').value);
            base.drug_mcg = num(document.getElementById('il_drug_mcg').value);
            base.total_ml = num(document.getElementById('il_total_ml').value);
        } else if (calcType === 'kcl') {
            base.conc_meq_l = num(document.getElementById('kcl_conc') && document.getElementById('kcl_conc').value, 20);
            base.rate_ml_hr = num(document.getElementById('kcl_rate') && document.getElementById('kcl_rate').value);
            base.renal_half = !!(document.getElementById('kcl_renal') && document.getElementById('kcl_renal').checked);
            base.rev_meq_hr = num(document.getElementById('kcl_rev_meq') && document.getElementById('kcl_rev_meq').value);
            base.rev_conc = num(document.getElementById('kcl_rev_conc') && document.getElementById('kcl_rev_conc').value, 40);
            base.mix_meq = num(document.getElementById('kcl_mix_meq') && document.getElementById('kcl_mix_meq').value);
            base.mix_vol_ml = num(document.getElementById('kcl_mix_vol') && document.getElementById('kcl_mix_vol').value);
        } else if (calcType === 'ntg') {
            base.dose = num(document.getElementById('ntg_dose') && document.getElementById('ntg_dose').value);
            base.drug_mg = num(document.getElementById('ntg_drug_mg') && document.getElementById('ntg_drug_mg').value);
            base.total_ml = num(document.getElementById('ntg_total_ml') && document.getElementById('ntg_total_ml').value);
            base.rev_rate = num(document.getElementById('ntg_rev_rate') && document.getElementById('ntg_rev_rate').value);
            base.rev_conc = num(document.getElementById('ntg_rev_conc') && document.getElementById('ntg_rev_conc').value, 200);
        } else if (calcType === 'arv_ped') {
            base.bottle_ml = num(document.getElementById('arv_bottle_ml') && document.getElementById('arv_bottle_ml').value, 60);
        } else if (calcType === 'tb') {
            base.start_date = (document.getElementById('tb_start_date') && document.getElementById('tb_start_date').value) || '';
        }
        return base;
    }

    function unlockCalc(on) {
        var area = document.getElementById('dcCalcArea');
        var row = document.getElementById('dcVitalsRow');
        if (area) area.classList.toggle('dc-locked', !on);
        if (row) row.style.display = on ? '' : 'none';
    }

    function showMsg(text, type) {
        var el = document.getElementById('dcSaveMsg');
        if (!el) return;
        el.style.display = text ? '' : 'none';
        el.className = 'mt-2 small fw-bold text-' + (type || 'muted');
        el.textContent = text || '';
    }

    function lookupHn() {
        var hn = (document.getElementById('dc_hn').value || '').trim();
        if (!hn) {
            alert('กรุณากรอก HN');
            return;
        }
        showMsg('กำลังค้นหา...', 'muted');
        fetch('fetch_dose_calculator_api.php?action=lookup&hn=' + encodeURIComponent(hn), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.status !== 'success') {
                    patient = null;
                    unlockCalc(false);
                    showMsg(data.message || 'ไม่พบข้อมูล', 'danger');
                    document.getElementById('dcPatientInfo').textContent = data.message || 'ไม่พบข้อมูล';
                    return;
                }
                var d = data.data;
                patient = {
                    hn: d.hn,
                    hn_key: d.hn_key,
                    ptname: d.ptname,
                    bw_source: d.bw,
                    height_source: d.height,
                    age_source: d.age != null ? d.age : null,
                    sex: d.sex || null,
                    vstdate: d.vstdate
                };
                var bwUse = d.bw_resolved != null ? d.bw_resolved : d.bw;
                var htUse = d.height;
                if (d.saved && d.saved.height) htUse = parseFloat(d.saved.height);
                document.getElementById('dc_bw').value = bwUse != null ? bwUse : '';
                document.getElementById('dc_height').value = htUse != null ? htUse : '';
                document.getElementById('dc_vstdate').value = d.vstdate || '—';
                var bwHintEl = document.getElementById('dc_bw_src_hint');
                if (bwHintEl) {
                    if (bwUse != null) {
                        var srcLbl = d.bw_source_label
                            || (d.bw_source === 'tham' ? 'THAM' : (d.bw_source === 'hosxp' ? 'HOSxP' : ''));
                        var hint = 'ใช้น้ำหนักล่าสุดจาก ' + (srcLbl || 'ระบบ') + ': ' + bwUse + ' kg';
                        if (d.bw != null && d.saved && d.saved.bw) {
                            hint += ' · HOSxP ' + d.bw + ' / THAM ' + d.saved.bw;
                        }
                        bwHintEl.textContent = hint;
                    } else {
                        bwHintEl.textContent = 'ไม่พบน้ำหนัก — กรอกเองได้ (บันทึกเข้า THAM เมื่อเปลี่ยนค่า/บันทึกคำนวณ)';
                    }
                }
                document.getElementById('dc_ht_src_hint').textContent = d.height != null
                    ? ('จาก HOSxP: ' + d.height + ' cm')
                    : 'ไม่พบส่วนสูงใน HOSxP';
                var ageEl = document.getElementById('dc_age');
                var ageHint = document.getElementById('dc_age_src_hint');
                if (ageEl) ageEl.value = d.age != null ? d.age : '';
                if (ageHint) {
                    if (d.age != null) {
                        var ageHintText = 'จาก HOSxP: ' + d.age + ' ปี';
                        if (d.birthday) ageHintText += ' (เกิด ' + d.birthday + ')';
                        ageHint.textContent = ageHintText;
                    } else {
                        ageHint.textContent = 'ไม่พบวันเกิดใน HOSxP — กรอกเองได้';
                    }
                }
                resetAgeConfirmState();
                pediatricWarnedKey = null;
                var sexEl = document.getElementById('lbw_sex');
                var sexHint = document.getElementById('lbw_sex_hint');
                if (sexEl && d.sex) {
                    sexEl.value = d.sex;
                    if (sexHint) sexHint.textContent = 'จาก HOSxP: ' + (d.sex === 'F' ? 'หญิง' : 'ชาย');
                } else if (sexHint) {
                    sexHint.textContent = 'เลือกเพศเพื่อคำนวณ LBW';
                }
                document.getElementById('dcPatientInfo').innerHTML =
                    '<strong class="text-success">HN ' + (d.hn_key || d.hn) + '</strong> — ' +
                    (d.ptname || '-') +
                    (d.vstdate ? ' <span class="text-muted">(vitals ' + d.vstdate + ')</span>' : '');
                unlockCalc(true);
                showMsg('กำลังคำนวณและบันทึกอัตโนมัติ...', 'muted');
                recalcAll();
                maybeWarnTnkPediatric(true);
                // ค้นหา HN สำเร็จ → คำนวณ + บันทึกอัตโนมัติ
                saveCalc(false, { auto: true });
            })
            .catch(function (err) {
                showMsg(err.message || 'เชื่อมต่อไม่สำเร็จ', 'danger');
            });
    }

    function saveCalc(confirmed, opts) {
        opts = opts || {};
        var auto = !!opts.auto;
        if (!patient) {
            if (!auto) alert('กรุณาค้นหา HN ก่อน');
            return;
        }
        var bw = getBw();
        if (!(bw > 0)) {
            if (!auto) alert('กรุณาระบุน้ำหนัก');
            else showMsg('ยังไม่มีน้ำหนัก — กรอกน้ำหนักแล้วกดบันทึก', 'warning');
            return;
        }
        var reasons = changeReasons();
        if (reasons.length && !confirmed) {
            var msg = 'น้ำหนัก/ส่วนสูงเปลี่ยนแปลงมากกว่า 10%\n\n' + reasons.join('\n') + '\n\nยืนยันใช้ค่าที่แก้ไขเพื่อคำนวณและบันทึกหรือไม่?';
            if (!window.confirm(msg)) {
                if (auto) showMsg('ยังไม่ได้บันทึก — รอยืนยันการเปลี่ยนน้ำหนัก/ส่วนสูง', 'warning');
                return;
            }
            confirmed = true;
        }
        if (!checkAgeConfirmBeforeSave(auto)) return;

        var calcType = opts.calcType || activeCalcType();
        var all = recalcAll();
        var result = all[calcType];
        if (!result) {
            if (!auto) alert('คำนวณไม่สำเร็จ — ตรวจสอบน้ำหนัก');
            return;
        }

        var payload = {
            action: 'save',
            hn: patient.hn,
            hn_key: patient.hn_key,
            ptname: patient.ptname,
            calc_type: calcType,
            bw_source: patient.bw_source,
            height_source: patient.height_source,
            bw_used: bw,
            height_used: getHeight(),
            vitals_vstdate: patient.vstdate,
            confirmed_change: confirmed ? 1 : 0,
            age_source: patient.age_source,
            age_confirmed: ageConfirmed ? 1 : 0,
            inputs: collectInputs(calcType),
            result: result
        };

        if (!auto) showMsg('กำลังบันทึก...', 'muted');
        fetch('fetch_dose_calculator_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.status === 'need_age_confirm') {
                    showMsg(data.message || 'กรุณายืนยันการแก้ไขอายุ (พิมพ์ confirm)', 'warning');
                    showAgeConfirmModal({
                        onSuccess: function () { saveCalc(false, opts); }
                    });
                    return;
                }
                if (data.status === 'need_confirm') {
                    var msg2 = (data.message || '') + '\n\n' + (data.reasons || []).join('\n') + '\n\nยืนยันหรือไม่?';
                    if (window.confirm(msg2)) {
                        saveCalc(true, opts);
                    } else {
                        showMsg('ยกเลิกการบันทึก', 'warning');
                    }
                    return;
                }
                if (data.status !== 'success') {
                    showMsg(data.message || 'บันทึกไม่สำเร็จ', 'danger');
                    return;
                }
                var label = {
                    methylpred: 'Methylpred',
                    rtpa_stemi: 'rT-PA STEMI',
                    rtpa_stroke: 'rT-PA STROKE',
                    tnk_stroke: 'TNK Stroke',
                    tnk_stemi: 'TNK STEMI',
                    bolus: 'Bolus',
                    midazolam: 'Midazolam',
                    midazolam_hr: 'Midazolam hr',
                    fentanyl: 'Fentanyl',
                    dobutamine: 'Dobutamine',
                    dopamine: 'Dopamine',
                    norepinephrine: 'NE',
                    cisatracurium: 'Cisatracurium',
                    adrenaline: 'Adrenaline',
                    calcium_glu: 'Calcium glu',
                    alprostadil: 'Alprostadil',
                    indomethacin: 'Indomethacin',
                    nac: 'NAC',
                    lbw: 'LBW / วิสัญญี',
                    iloprost: 'Iloprost',
                    kcl: 'KCL',
                    ntg: 'NTG',
                    arv_ped: 'ARV เด็ก',
                    tb: 'TB'
                }[calcType] || calcType;
                showMsg((data.message || 'บันทึกแล้ว') + ' · ' + label, 'success');
            })
            .catch(function (err) {
                showMsg(err.message || 'เชื่อมต่อไม่สำเร็จ', 'danger');
            });
    }

    function syncTabToUrl(tabKey) {
        if (!tabKey) return;
        try {
            var url = new URL(window.location.href);
            url.searchParams.set('tab', tabKey);
            window.history.replaceState({}, '', url.toString());
        } catch (e) { /* ignore */ }
    }

    function copyText(selector) {
        var el = document.querySelector(selector);
        if (!el) return;
        var text = el.textContent || '';
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(flashCopyOk).catch(function () { fallbackCopy(text); });
        } else {
            fallbackCopy(text);
        }
    }

    function fallbackCopy(text) {
        var ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); flashCopyOk(); } catch (e) {}
        document.body.removeChild(ta);
    }

    function flashCopyOk() {
        var tip = document.createElement('div');
        tip.className = 'position-fixed bottom-0 end-0 m-3 alert alert-success py-2 px-3 shadow';
        tip.style.zIndex = 9999;
        tip.textContent = 'คัดลอกแล้ว';
        document.body.appendChild(tip);
        setTimeout(function () { tip.remove(); }, 1200);
    }

    document.addEventListener('DOMContentLoaded', function () {
        unlockCalc(false);

        ['dc_bw', 'dc_height', 'mp_hours', 'mp_vol',
         'bl_mz_order_mg', 'bl_fn_order_mcg',
         'mz_dose', 'mz_drug_mg', 'mz_total_ml',
         'mzh_dose', 'mzh_drug_mg', 'mzh_total_ml', 'mzh_rev_rate', 'mzh_rev_conc',
         'fn_dose', 'fn_drug_mg', 'fn_total_ml',
         'db_dose', 'db_drug_mg', 'db_total_ml', 'db_rev_rate', 'db_rev_conc',
         'dp_dose', 'dp_drug_mg', 'dp_total_ml', 'dp_rev_rate', 'dp_rev_conc',
         'ne_dose', 'ne_drug_mg', 'ne_total_ml', 'ne_rev_rate', 'ne_rev_conc',
         'cs_dose', 'cs_drug_mg', 'cs_total_ml',
         'ad_dose', 'ad_drug_mg', 'ad_total_ml',
         'ap_dose', 'ap_drug_mg', 'ap_total_ml',
         'lbw_sex',
         'il_dose', 'il_drug_mcg', 'il_total_ml',
         'kcl_conc', 'kcl_rate', 'kcl_renal', 'kcl_rev_meq', 'kcl_rev_conc', 'kcl_mix_meq', 'kcl_mix_vol',
         'ntg_dose', 'ntg_drug_mg', 'ntg_total_ml', 'ntg_rev_rate', 'ntg_rev_conc',
         'arv_bottle_ml',
         'tb_start_date'].forEach(function (id) {
            var el = document.getElementById(id);
            if (!el) return;
            el.addEventListener('input', recalcAll);
            el.addEventListener('change', recalcAll);
        });

        var dcBwEl = document.getElementById('dc_bw');
        var dcBwSaveTimer = null;
        function persistDcBw() {
            if (!patient) return;
            var bw = getBw();
            if (!(bw > 0)) return;
            fetch('fetch_dose_calculator_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify({
                    action: 'save_bw',
                    hn: patient.hn || patient.hn_key,
                    hn_key: patient.hn_key,
                    bw: bw,
                    height: getHeight && getHeight() > 0 ? getHeight() : null,
                    ptname: patient.ptname || '',
                    source_module: 'dose_calculator'
                })
            }).then(function (r) { return r.json(); }).then(function (res) {
                var hint = document.getElementById('dc_bw_src_hint');
                if (hint && res && res.status === 'success') {
                    hint.textContent = 'บันทึกน้ำหนักใน THAM แล้ว · ' + bw + ' kg';
                }
            }).catch(function () {});
        }
        if (dcBwEl) {
            dcBwEl.addEventListener('input', function () {
                if (dcBwSaveTimer) clearTimeout(dcBwSaveTimer);
                dcBwSaveTimer = setTimeout(persistDcBw, 900);
            });
            dcBwEl.addEventListener('change', persistDcBw);
        }

        var lbwOverride = document.getElementById('lbw_override');
        if (lbwOverride) {
            lbwOverride.addEventListener('input', function () {
                calcLbw({ syncOverride: false });
            });
            lbwOverride.addEventListener('change', function () {
                calcLbw({ syncOverride: false });
            });
        }

        var ageEl = document.getElementById('dc_age');
        if (ageEl) {
            // ใช้ change (หลัง blur/enter) เพื่อเปิด popup — ไม่เปิดทุก keystroke
            ageEl.addEventListener('change', onAgeInput);
            ageEl.addEventListener('input', function () { recalcAll(); });
        }

        var ageCf = document.getElementById('dc_age_confirm');
        if (ageCf) {
            ageCf.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    submitAgeConfirmModal();
                }
            });
        }
        var ageOk = document.getElementById('dcAgeConfirmOk');
        if (ageOk) ageOk.addEventListener('click', submitAgeConfirmModal);
        var ageCancel = document.getElementById('dcAgeConfirmCancel');
        if (ageCancel) ageCancel.addEventListener('click', cancelAgeConfirmModal);

        var ageModalEl = document.getElementById('dcAgeConfirmModal');
        if (ageModalEl) {
            ageModalEl.addEventListener('hidden.bs.modal', function () {
                // ปิด modal โดยไม่ยืนยัน → คืนค่าอายุเดิม (ถ้ายังไม่ confirm)
                if (ageNeedsConfirm() && !ageConfirmed) {
                    revertAgeToSource();
                }
            });
        }

        document.getElementById('dcBtnLookup').addEventListener('click', lookupHn);
        document.getElementById('dc_hn').addEventListener('keypress', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); lookupHn(); }
        });
        document.getElementById('dcBtnCalc').addEventListener('click', function () { saveCalc(false, { auto: false }); });

        // เปิดจาก Patient IPD / URL ?hn= → กรอกและค้นหาอัตโนมัติ
        (function prefillHnFromQuery() {
            var hnEl = document.getElementById('dc_hn');
            if (!hnEl) return;
            var hn = (hnEl.value || '').trim();
            if (!hn) {
                try {
                    var q = new URLSearchParams(window.location.search || '');
                    hn = (q.get('hn') || '').trim();
                    if (hn) hnEl.value = hn;
                } catch (e) {}
            }
            if (hn) lookupHn();
        })();

        document.querySelectorAll('[data-copy]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                copyText(btn.getAttribute('data-copy'));
            });
        });

        document.querySelectorAll('#dcTabs [data-dc-tab]').forEach(function (btn) {
            btn.addEventListener('shown.bs.tab', function () {
                var tabKey = btn.getAttribute('data-dc-tab');
                syncTabToUrl(tabKey);
                recalcAll();
                if (tabKey === 'tnk_stemi') {
                    maybeWarnTnkPediatric(false);
                }
                // สลับยาอื่น → บันทึกน้ำหนัก/ส่วนสูง + ผลคำนวณของแท็บนั้นอัตโนมัติ
                if (patient && getBw() > 0) {
                    saveCalc(false, { auto: true, calcType: tabKey });
                }
            });
        });
    });
})();
