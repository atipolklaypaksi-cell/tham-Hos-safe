/**
 * Global allergy-case sound + banner for pharmacists / pharmacy technicians.
 * Repeats "New Drug Allergy Case" every N minutes until the case is acknowledged.
 */
(function () {
    if (window.__thamAllergyAlertBound) return;
    window.__thamAllergyAlertBound = true;

    var POLL_MS = 20000;
    var LS_SIG = 'afAlertSig';
    var LS_SPEAK = 'afAlertLastSpeak';
    var LS_HIDE = 'afAlertHideSig';
    var settings = {
        enabled: 1,
        sound_enabled: 1,
        banner_enabled: 1,
        interval_min: 5,
        speech_text: 'New Drug Allergy Case',
        intro_style: 'hospital'
    };
    var audioUnlocked = false;
    var audioCtx = null;
    var voices = [];
    var hideThisSig = '';

    function $(id) {
        return document.getElementById(id);
    }

    function initVoices() {
        if (!window.speechSynthesis) return;
        voices = Array.prototype.slice.call(window.speechSynthesis.getVoices() || []);
    }
    if (window.speechSynthesis) {
        initVoices();
        if (speechSynthesis.onvoiceschanged !== undefined) {
            speechSynthesis.onvoiceschanged = initVoices;
        }
    }

    function ensureAudio() {
        var Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return null;
        if (!audioCtx) audioCtx = new Ctx();
        if (audioCtx.state === 'suspended') {
            try { audioCtx.resume(); } catch (e) {}
        }
        audioUnlocked = true;
        var btn = $('afAlertUnlock');
        if (btn) btn.style.display = 'none';
        return audioCtx;
    }

    function tone(ctx, dest, type, freq, start, dur, peak) {
        var osc = ctx.createOscillator();
        var gain = ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, start);
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(peak, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
        osc.connect(gain);
        gain.connect(dest);
        osc.start(start);
        osc.stop(start + dur + 0.02);
        return osc;
    }

    function bell(ctx, dest, freq, start, dur, peak) {
        var osc = ctx.createOscillator();
        var harm = ctx.createOscillator();
        var gain = ctx.createGain();
        osc.type = 'sine';
        harm.type = 'triangle';
        osc.frequency.setValueAtTime(freq, start);
        harm.frequency.setValueAtTime(freq * 2, start);
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(peak, start + 0.018);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
        osc.connect(gain);
        harm.connect(gain);
        gain.connect(dest);
        osc.start(start);
        harm.start(start);
        osc.stop(start + dur + 0.02);
        harm.stop(start + dur + 0.02);
    }

    function playHospital(ctx, master, t0) {
        var notes = [523.25, 659.25, 783.99, 1046.5];
        var i;
        for (i = 0; i < notes.length; i++) {
            bell(ctx, master, notes[i], t0 + i * 0.28, 0.85, 0.34);
        }
        return 1550;
    }

    function playChime(ctx, master, t0) {
        bell(ctx, master, 880, t0, 0.7, 0.38);
        bell(ctx, master, 659.25, t0 + 0.38, 0.95, 0.36);
        bell(ctx, master, 1318.5, t0 + 0.95, 0.45, 0.22);
        return 1450;
    }

    function playPage(ctx, master, t0) {
        var i;
        for (i = 0; i < 3; i++) {
            tone(ctx, master, 'sine', 980, t0 + i * 0.28, 0.16, 0.32);
            tone(ctx, master, 'sine', 1960, t0 + i * 0.28, 0.1, 0.08);
        }
        return 1100;
    }

    function playFanfare(ctx, master, t0) {
        tone(ctx, master, 'triangle', 392, t0, 0.45, 0.22);
        tone(ctx, master, 'sine', 523.25, t0 + 0.12, 0.4, 0.26);
        tone(ctx, master, 'sine', 659.25, t0 + 0.24, 0.45, 0.28);
        tone(ctx, master, 'sine', 783.99, t0 + 0.36, 0.7, 0.3);
        tone(ctx, master, 'triangle', 1046.5, t0 + 0.7, 0.55, 0.26);
        return 1400;
    }

    function playSiren(ctx, master, t0) {
        var siren = ctx.createOscillator();
        var sirenGain = ctx.createGain();
        siren.type = 'sawtooth';
        siren.frequency.setValueAtTime(420, t0);
        siren.frequency.exponentialRampToValueAtTime(980, t0 + 0.38);
        siren.frequency.exponentialRampToValueAtTime(520, t0 + 0.72);
        siren.frequency.exponentialRampToValueAtTime(1100, t0 + 1.05);
        sirenGain.gain.setValueAtTime(0.0001, t0);
        sirenGain.gain.exponentialRampToValueAtTime(0.22, t0 + 0.05);
        sirenGain.gain.exponentialRampToValueAtTime(0.18, t0 + 0.7);
        sirenGain.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.12);
        siren.connect(sirenGain);
        sirenGain.connect(master);
        siren.start(t0);
        siren.stop(t0 + 1.14);
        var beeps = [784, 1046.5, 1318.5];
        var i;
        for (i = 0; i < beeps.length; i++) {
            tone(ctx, master, 'square', beeps[i], t0 + 1.12 + i * 0.16, 0.12, 0.28);
        }
        return 2050;
    }

    function playIntro(done, style) {
        var ctx = ensureAudio();
        if (!ctx) {
            if (done) done();
            return;
        }
        style = style || settings.intro_style || 'hospital';
        try {
            var t0 = ctx.currentTime;
            var master = ctx.createGain();
            master.gain.setValueAtTime(0.9, t0);
            master.connect(ctx.destination);
            var wait = 1500;
            if (style === 'chime') wait = playChime(ctx, master, t0);
            else if (style === 'page') wait = playPage(ctx, master, t0);
            else if (style === 'fanfare') wait = playFanfare(ctx, master, t0);
            else if (style === 'siren') wait = playSiren(ctx, master, t0);
            else wait = playHospital(ctx, master, t0);
            setTimeout(function () { if (done) done(); }, wait);
        } catch (e) {
            if (done) done();
        }
    }

    function speak(text) {
        if (!window.speechSynthesis) return;
        var phrase = (text || settings.speech_text || 'New Drug Allergy Case').trim();
        try { window.speechSynthesis.cancel(); } catch (e) {}
        var u = new SpeechSynthesisUtterance(phrase);
        u.lang = 'en-US';
        u.rate = 1.0;
        u.pitch = 1.05;
        if (voices.length) {
            var eng = voices.find(function (v) {
                return (v.lang || '').indexOf('en') === 0 || (v.name || '').indexOf('English') >= 0;
            });
            if (eng) u.voice = eng;
        }
        window.speechSynthesis.speak(u);
    }

    function announce(force) {
        if (!settings.sound_enabled) return;
        ensureAudio();
        playIntro(function () {
            speak(settings.speech_text);
        }, settings.intro_style);
        try { localStorage.setItem(LS_SPEAK, String(Date.now())); } catch (e) {}
        if (force) { /* keep signature handling in poll */ }
    }

    function signatureOf(cases) {
        return (cases || []).map(function (c) { return String(c.id); }).sort().join(',');
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function mountBanner() {
        var el = $('afAlertBanner') || $('afAlertToast');
        if (el && el.parentNode !== document.body) {
            document.body.appendChild(el);
        }
        return el;
    }

    function setBanner(pending, cases) {
        var el = mountBanner();
        if (!el) return;
        var countEl = $('afAlertCount');
        var meta = $('afAlertMeta');
        var open = el.querySelector('.af-alert-open');
        var show = !!(settings.enabled && settings.banner_enabled && pending > 0);
        var sig = signatureOf(cases);
        try { hideThisSig = localStorage.getItem(LS_HIDE) || ''; } catch (e) { hideThisSig = ''; }
        if (hideThisSig && hideThisSig === sig) show = false;
        if (!show) {
            el.classList.remove('is-on');
            el.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('af-alert-banner-on');
            return;
        }
        if (countEl) countEl.textContent = String(pending);
        var first = (cases && cases[0]) ? cases[0] : null;
        if (meta) {
            if (first) {
                meta.innerHTML = 'ล่าสุด HN <b>' + esc(first.hn || '-') + '</b> '
                    + esc(first.ptname || '')
                    + (first.ward ? ' · ' + esc(first.ward) : '');
            } else {
                meta.textContent = 'มีเคสที่ยังไม่ได้กดรับ';
            }
        }
        if (open && first && first.open_url) {
            open.setAttribute('href', first.open_url);
        }
        el.classList.add('is-on');
        el.setAttribute('aria-hidden', 'false');
        document.body.classList.add('af-alert-banner-on');
        var unlock = $('afAlertUnlock');
        if (unlock) unlock.style.display = audioUnlocked ? 'none' : '';
    }

    function updateSidebarBadge(pending) {
        var badge = document.getElementById('afPendingAckBadge');
        if (!badge) return;
        if (pending > 0) {
            badge.style.display = '';
            badge.textContent = String(pending);
        } else {
            badge.style.display = 'none';
        }
    }

    function maybeSpeak(pending, cases) {
        if (!settings.enabled || !settings.sound_enabled || pending <= 0) return;
        var sig = signatureOf(cases);
        var prev = '';
        var lastSpeak = 0;
        try {
            prev = localStorage.getItem(LS_SIG) || '';
            lastSpeak = parseInt(localStorage.getItem(LS_SPEAK) || '0', 10) || 0;
        } catch (e) {}
        var intervalMs = Math.max(1, parseInt(settings.interval_min, 10) || 5) * 60 * 1000;
        var isNew = sig !== '' && sig !== prev;
        var due = (Date.now() - lastSpeak) >= intervalMs;
        if (isNew || due || lastSpeak === 0) {
            announce();
        }
        try { localStorage.setItem(LS_SIG, sig); } catch (e) {}
    }

    function applyPoll(data) {
        if (!data || data.status !== 'success') return;
        if (data.settings) {
            settings = data.settings;
        }
        if (!data.eligible || !settings.enabled) {
            setBanner(0, []);
            updateSidebarBadge(0);
            return;
        }
        var pending = parseInt(data.pending, 10) || 0;
        var cases = data.cases || [];
        if (pending <= 0) {
            try {
                localStorage.removeItem(LS_SIG);
                localStorage.removeItem(LS_HIDE);
            } catch (e) {}
        }
        setBanner(pending, cases);
        updateSidebarBadge(pending);
        maybeSpeak(pending, cases);
    }

    function poll() {
        fetch('fetch_allergy_alert_api.php?action=poll', { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(applyPoll)
            .catch(function () { /* ignore */ });
    }

    function bindUnlock() {
        mountBanner();
        function unlock() {
            ensureAudio();
            if (window.speechSynthesis) {
                try { window.speechSynthesis.getVoices(); } catch (e) {}
            }
        }
        document.addEventListener('click', unlock, { once: true });
        document.addEventListener('keydown', unlock, { once: true });
        var btn = $('afAlertUnlock');
        if (btn) {
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                unlock();
                announce();
            });
        }
        var hide = $('afAlertHide');
        if (hide) {
            hide.addEventListener('click', function () {
                var el = $('afAlertBanner') || $('afAlertToast');
                if (el) {
                    el.classList.remove('is-on');
                    el.setAttribute('aria-hidden', 'true');
                    document.body.classList.remove('af-alert-banner-on');
                }
                try {
                    localStorage.setItem(LS_HIDE, localStorage.getItem(LS_SIG) || '');
                } catch (e) {}
            });
        }
    }

    window.ThamAllergyAlert = {
        test: function (text, style) {
            if (text) settings.speech_text = text;
            if (style) settings.intro_style = style;
            ensureAudio();
            announce();
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bindUnlock);
    } else {
        bindUnlock();
    }
    function armPoll() {
        var wait = 1500 + Math.floor(Math.random() * 4000);
        setTimeout(function tick() {
            if (document.hidden) {
                setTimeout(tick, 8000);
                return;
            }
            poll();
            setTimeout(tick, POLL_MS);
        }, wait);
    }
    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) poll();
    });
    armPoll();
})();
