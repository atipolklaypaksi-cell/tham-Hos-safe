/**
 * ตั้งค่า Guideline Warfarin (editable protocols/rows)
 */
(function () {
    'use strict';

    var state = JSON.parse(JSON.stringify(window.WG_INITIAL || { protocols: [] }));

    function showMsg(text, type) {
        var el = document.getElementById('wgMsg');
        if (!el) return;
        el.style.display = text ? '' : 'none';
        el.className = 'mb-3 small fw-bold text-' + (type || 'muted');
        el.textContent = text || '';
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function numOrEmpty(v) {
        if (v === null || v === undefined || v === '') return '';
        return v;
    }

    function collect() {
        var protocols = [];
        document.querySelectorAll('.wg-protocol').forEach(function (card) {
            var id = card.getAttribute('data-id') || '';
            var rows = [];
            card.querySelectorAll('tbody tr').forEach(function (tr) {
                rows.push({
                    inr_label: tr.querySelector('[data-f="inr_label"]').value.trim(),
                    inr_min: tr.querySelector('[data-f="inr_min"]').value,
                    inr_max: tr.querySelector('[data-f="inr_max"]').value,
                    inr_max_exclusive: tr.querySelector('[data-f="inr_max_exclusive"]').checked,
                    direction: tr.querySelector('[data-f="direction"]').value,
                    pct_min: parseFloat(tr.querySelector('[data-f="pct_min"]').value) || 0,
                    pct_max: parseFloat(tr.querySelector('[data-f="pct_max"]').value) || 0,
                    default_pct: parseFloat(tr.querySelector('[data-f="default_pct"]').value) || 0,
                    hold_doses_min: parseInt(tr.querySelector('[data-f="hold_doses_min"]').value, 10) || 0,
                    hold_doses_max: parseInt(tr.querySelector('[data-f="hold_doses_max"]').value, 10) || 0,
                    extra_dose: tr.querySelector('[data-f="extra_dose"]').checked,
                    vitamin_k: tr.querySelector('[data-f="vitamin_k"]').value.trim(),
                    note: tr.querySelector('[data-f="note"]').value.trim()
                });
            });
            protocols.push({
                id: id,
                name: card.querySelector('[data-f="name"]').value.trim(),
                indication: card.querySelector('[data-f="indication"]').value.trim(),
                target_low: parseFloat(card.querySelector('[data-f="target_low"]').value) || 0,
                target_high: parseFloat(card.querySelector('[data-f="target_high"]').value) || 0,
                rows: rows
            });
        });
        return { protocols: protocols };
    }

    function rowHtml(row) {
        row = row || {};
        return '<tr>' +
            '<td><input class="form-control form-control-sm" data-f="inr_label" value="' + esc(row.inr_label || '') + '"></td>' +
            '<td><input type="number" step="0.1" class="form-control form-control-sm" data-f="inr_min" value="' + esc(numOrEmpty(row.inr_min)) + '" placeholder="ว่าง=ไม่มี"></td>' +
            '<td><input type="number" step="0.1" class="form-control form-control-sm" data-f="inr_max" value="' + esc(numOrEmpty(row.inr_max)) + '" placeholder="ว่าง=ไม่มี"></td>' +
            '<td class="text-center"><input type="checkbox" class="form-check-input" data-f="inr_max_exclusive" ' + (row.inr_max_exclusive ? 'checked' : '') + ' title="< ค่าสูงสุด"></td>' +
            '<td><select class="form-select form-select-sm" data-f="direction">' +
            '<option value="up"' + (row.direction === 'up' ? ' selected' : '') + '>เพิ่ม</option>' +
            '<option value="down"' + (row.direction === 'down' ? ' selected' : '') + '>ลด</option>' +
            '<option value="hold"' + (row.direction === 'hold' ? ' selected' : '') + '>คงเดิม</option>' +
            '</select></td>' +
            '<td><input type="number" step="1" class="form-control form-control-sm" data-f="pct_min" value="' + esc(row.pct_min != null ? row.pct_min : 0) + '"></td>' +
            '<td><input type="number" step="1" class="form-control form-control-sm" data-f="pct_max" value="' + esc(row.pct_max != null ? row.pct_max : 0) + '"></td>' +
            '<td><input type="number" step="1" class="form-control form-control-sm" data-f="default_pct" value="' + esc(row.default_pct != null ? row.default_pct : 0) + '"></td>' +
            '<td><input type="number" step="1" class="form-control form-control-sm" data-f="hold_doses_min" value="' + esc(row.hold_doses_min != null ? row.hold_doses_min : 0) + '"></td>' +
            '<td><input type="number" step="1" class="form-control form-control-sm" data-f="hold_doses_max" value="' + esc(row.hold_doses_max != null ? row.hold_doses_max : 0) + '"></td>' +
            '<td class="text-center"><input type="checkbox" class="form-check-input" data-f="extra_dose" ' + (row.extra_dose ? 'checked' : '') + '></td>' +
            '<td><textarea class="form-control form-control-sm" rows="2" data-f="note">' + esc(row.note || '') + '</textarea></td>' +
            '<td><textarea class="form-control form-control-sm" rows="2" data-f="vitamin_k">' + esc(row.vitamin_k || '') + '</textarea></td>' +
            '<td><button type="button" class="btn btn-sm btn-outline-danger wg-del-row" title="ลบแถว"><i class="fas fa-trash"></i></button></td>' +
            '</tr>';
    }

    function protocolHtml(p, idx) {
        var rows = (p.rows || []).map(rowHtml).join('');
        return '<div class="card wg-card mb-4 wg-protocol" data-id="' + esc(p.id || ('protocol_' + (idx + 1))) + '">' +
            '<div class="card-header wg-proto-head py-3">' +
            '<div class="row g-2 align-items-end">' +
            '<div class="col-md-4"><label class="form-label small mb-1">ชื่อแนวทาง</label>' +
            '<input class="form-control fw-bold" data-f="name" value="' + esc(p.name || '') + '"></div>' +
            '<div class="col-md-2"><label class="form-label small mb-1">Target ต่ำ</label>' +
            '<input type="number" step="0.1" class="form-control" data-f="target_low" value="' + esc(p.target_low != null ? p.target_low : '') + '"></div>' +
            '<div class="col-md-2"><label class="form-label small mb-1">Target สูง</label>' +
            '<input type="number" step="0.1" class="form-control" data-f="target_high" value="' + esc(p.target_high != null ? p.target_high : '') + '"></div>' +
            '<div class="col-md-4"><label class="form-label small mb-1">ข้อบ่งใช้</label>' +
            '<input class="form-control" data-f="indication" value="' + esc(p.indication || '') + '"></div>' +
            '</div></div>' +
            '<div class="card-body p-2">' +
            '<div class="table-responsive">' +
            '<table class="table table-sm table-bordered align-middle mb-2 wg-table">' +
            '<thead class="table-light"><tr>' +
            '<th>ช่วง INR (ข้อความ)</th><th>INR min</th><th>INR max</th><th>&lt;max</th>' +
            '<th>ทิศทาง</th><th>% min</th><th>% max</th><th>% ใช้จริง</th>' +
            '<th>งดมื้อ min</th><th>งดมื้อ max</th><th>Extra</th><th>คำแนะนำ</th><th>Vitamin K / หมายเหตุ</th><th></th>' +
            '</tr></thead><tbody>' + rows + '</tbody></table></div>' +
            '<button type="button" class="btn btn-sm btn-outline-primary wg-add-row"><i class="fas fa-plus me-1"></i>เพิ่มแถว</button>' +
            '</div></div>';
    }

    function render() {
        var box = document.getElementById('wgProtocols');
        if (!box) return;
        box.innerHTML = (state.protocols || []).map(protocolHtml).join('');
        box.querySelectorAll('.wg-add-row').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var tbody = btn.closest('.wg-protocol').querySelector('tbody');
                tbody.insertAdjacentHTML('beforeend', rowHtml({
                    inr_label: '', direction: 'up', pct_min: 5, pct_max: 10, default_pct: 10,
                    hold_doses_min: 0, hold_doses_max: 0, note: ''
                }));
                bindRowDeletes();
            });
        });
        bindRowDeletes();
    }

    function bindRowDeletes() {
        document.querySelectorAll('.wg-del-row').forEach(function (btn) {
            btn.onclick = function () {
                var tr = btn.closest('tr');
                var tbody = tr.parentNode;
                if (tbody.querySelectorAll('tr').length <= 1) {
                    alert('ต้องมีอย่างน้อย 1 แถว');
                    return;
                }
                tr.remove();
            };
        });
    }

    function save() {
        var payload = collect();
        showMsg('กำลังบันทึก...', 'muted');
        fetch('fetch_warfarin_guideline_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'save', data: payload })
        })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.status !== 'success') {
                    showMsg(res.message || 'บันทึกไม่สำเร็จ', 'danger');
                    return;
                }
                state = res.data || payload;
                render();
                showMsg('บันทึก guideline แล้ว', 'success');
            })
            .catch(function (err) {
                showMsg(err.message || 'เชื่อมต่อไม่สำเร็จ', 'danger');
            });
    }

    document.addEventListener('DOMContentLoaded', function () {
        render();
        var btnS = document.getElementById('wgBtnSave');
        var btnR = document.getElementById('wgBtnReset');
        if (btnS) btnS.addEventListener('click', save);
        if (btnR) btnR.addEventListener('click', function () {
            if (!confirm('คืนค่าเริ่มต้นตามแนวทาง Target 2.0-3.0 และ 2.5-3.5?')) return;
            state = JSON.parse(JSON.stringify(window.WG_DEFAULTS || { protocols: [] }));
            render();
            showMsg('โหลดค่าเริ่มต้นแล้ว — กดบันทึกเพื่อยืนยัน', 'warning');
        });
    });
})();
