<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/dose_calculator_helper.php');
mysqli_set_charset($con, 'utf8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

header('Content-Type: application/json; charset=utf-8');

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? 'lookup'));
$raw = file_get_contents('php://input');
$body = [];
if ($raw !== false && $raw !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
        if ($action === '' || $action === 'lookup') {
            if (!empty($body['action'])) {
                $action = trim((string)$body['action']);
            }
        }
    }
}

if ($action === 'save_bw') {
    $payload = !empty($body) ? $body : $_POST;
    $payload['user_id'] = (int)($_SESSION['user_id'] ?? 0);
    $payload['user_name'] = (string)($_SESSION['full_name'] ?? '');
    $payload['source_module'] = trim((string)($payload['source_module'] ?? 'pediatric_dose'));
    $res = dc_save_vitals_bw($con, $payload);
    ob_clean();
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกน้ำหนักไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'message' => $res['message'] ?? 'บันทึกน้ำหนักแล้ว',
        'bw' => $res['bw'] ?? null,
        'source' => $res['source'] ?? 'tham',
        'source_label' => $res['source_label'] ?? 'THAM',
        'updated_at' => $res['updated_at'] ?? null,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$hn = trim((string)($_GET['hn'] ?? $_POST['hn'] ?? ($body['hn'] ?? '')));

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}

$pt = dc_lookup_patient($hos, $con, $hn);
mysqli_close($hos);
if (empty($pt['ok'])) {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => $pt['error'] ?? 'ไม่พบ HN'], JSON_UNESCAPED_UNICODE);
    exit;
}

$bw = isset($pt['bw_resolved']) ? $pt['bw_resolved'] : null;
if ($bw !== null && (float)$bw <= 0) {
    $bw = null;
}
$bw_source = (string)($pt['bw_source'] ?? '');
$bw_source_label = (string)($pt['bw_source_label'] ?? '');
$bw_date = $pt['bw_resolved_date'] ?? ($pt['vstdate'] ?? null);
// เข้ากับ UI เดิม: calculator = THAM
if ($bw_source === 'tham') {
    $bw_source = 'calculator';
}

ob_clean();
echo json_encode([
    'status' => 'success',
    'patient' => [
        'hn' => $pt['hn'],
        'ptname' => $pt['ptname'] ?? '',
        'bw' => $bw,
        'bw_source' => $bw_source,
        'bw_source_label' => $bw_source_label,
        'bw_date' => $bw_date,
        'vstdate' => $pt['vstdate'] ?? null,
        'age' => $pt['age'] ?? null,
    ],
], JSON_UNESCAPED_UNICODE);
