<?php
/**
 * เชื่อมต่อฐานข้อมูล Drug Viewer (gtwrx) แบบอ่านอย่างเดียว
 */

function drug_viewer_config_keys() {
    return ['dv_host', 'dv_port', 'dv_user', 'dv_pass', 'dv_db', 'dv_readonly'];
}

function drug_viewer_default_config() {
    return [
        'dv_host' => '192.168.2.3',
        'dv_port' => '3306',
        'dv_user' => 'read_scanorder',
        'dv_pass' => 'scph@27',
        'dv_db' => 'gtwrx',
        'dv_readonly' => '1',
    ];
}

function drug_viewer_upsert_config($con, $key, $value) {
    $k = mysqli_real_escape_string($con, $key);
    $v = mysqli_real_escape_string($con, (string)$value);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$k'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
}

function drug_viewer_ensure_config($con) {
    $defaults = drug_viewer_default_config();
    foreach ($defaults as $key => $value) {
        $k = mysqli_real_escape_string($con, $key);
        $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
        if (!$chk || mysqli_num_rows($chk) === 0) {
            drug_viewer_upsert_config($con, $key, $value);
            continue;
        }
        if ($key === 'dv_readonly') {
            drug_viewer_upsert_config($con, $key, '1');
        }
    }
}

function drug_viewer_load_config($con) {
    drug_viewer_ensure_config($con);
    $cfg = drug_viewer_default_config();
    $keys = "'" . implode("','", array_map(function ($k) use ($con) {
        return mysqli_real_escape_string($con, $k);
    }, drug_viewer_config_keys())) . "'";
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ($keys)");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cfg[$r['config_name']] = (string)$r['config_value'];
        }
    }
    $cfg['dv_readonly'] = '1';
    $port = (int)($cfg['dv_port'] ?? 3306);
    $cfg['dv_port'] = (string)($port > 0 ? $port : 3306);
    return $cfg;
}

function drug_viewer_save_config($con, array $input) {
    $next = drug_viewer_load_config($con);
    foreach (['dv_host', 'dv_port', 'dv_user', 'dv_db'] as $key) {
        if (array_key_exists($key, $input)) {
            $next[$key] = trim((string)$input[$key]);
        }
    }
    if (isset($input['dv_pass'])) {
        $pass = (string)$input['dv_pass'];
        if ($pass !== '' && $pass !== '********') {
            $next['dv_pass'] = $pass;
        }
    }
    $port = (int)$next['dv_port'];
    $next['dv_port'] = (string)($port > 0 ? $port : 3306);
    $next['dv_readonly'] = '1';
    foreach (drug_viewer_config_keys() as $key) {
        drug_viewer_upsert_config($con, $key, $next[$key] ?? '');
    }
    return drug_viewer_load_config($con);
}

function drug_viewer_public_config(array $cfg) {
    $out = $cfg;
    $out['dv_pass'] = ($cfg['dv_pass'] ?? '') !== '' ? '********' : '';
    $out['dv_readonly'] = '1';
    return $out;
}

function drug_viewer_is_readonly_sql($sql) {
    $sql = trim((string)$sql);
    if ($sql === '') {
        return false;
    }
    $sql = preg_replace('/^\s*\/\*.*?\*\//s', '', $sql);
    $sql = preg_replace('/^\s*--[^\n]*\n/', '', $sql);
    $sql = ltrim($sql);
    if (!preg_match('/^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN|WITH)\b/i', $sql)) {
        return false;
    }
    if (preg_match('/\b(INSERT|UPDATE|DELETE|ALTER|DROP|CREATE|TRUNCATE|GRANT|REVOKE|LOAD\s+DATA|INTO\s+OUTFILE|INTO\s+DUMPFILE|FOR\s+UPDATE)\b/i', $sql)) {
        return false;
    }
    if (preg_match('/\bREPLACE\s+INTO\b/i', $sql)) {
        return false;
    }
    return true;
}

function drug_viewer_ident($name) {
    $name = trim((string)$name);
    if ($name === '' || !preg_match('/^[A-Za-z0-9_]+$/', $name)) {
        return null;
    }
    return '`' . $name . '`';
}

function drug_viewer_apply_readonly($dv) {
    if (!$dv) {
        return;
    }
    @mysqli_query($dv, 'SET SESSION TRANSACTION READ ONLY');
}

function drug_viewer_connect($con, $read_timeout = 30, array $override = null) {
    if (is_file(__DIR__ . '/integrations_hub_helper.php')) {
        require_once __DIR__ . '/integrations_hub_helper.php';
        if (function_exists('ih_is_enabled') && !ih_is_enabled($con, 'drug_viewer')) {
            return null;
        }
    }
    $cfg = $override ? array_merge(drug_viewer_load_config($con), $override) : drug_viewer_load_config($con);
    $host = trim((string)($cfg['dv_host'] ?? ''));
    $user = trim((string)($cfg['dv_user'] ?? ''));
    $pass = (string)($cfg['dv_pass'] ?? '');
    $db = trim((string)($cfg['dv_db'] ?? ''));
    $port = (int)($cfg['dv_port'] ?? 3306);
    if ($host === '' || $user === '' || $db === '') {
        return null;
    }
    if ($port <= 0) {
        $port = 3306;
    }
    mysqli_report(MYSQLI_REPORT_OFF);
    $c = mysqli_init();
    if (!$c) {
        return null;
    }
    $read_timeout = max(8, min(120, (int)$read_timeout));
    mysqli_options($c, MYSQLI_OPT_CONNECT_TIMEOUT, 8);
    if (defined('MYSQLI_OPT_READ_TIMEOUT')) {
        mysqli_options($c, MYSQLI_OPT_READ_TIMEOUT, $read_timeout);
    }
    $ok = @mysqli_real_connect($c, $host, $user, $pass, $db, $port);
    if (!$ok) {
        return null;
    }
    @mysqli_set_charset($c, 'utf8mb4');
    drug_viewer_apply_readonly($c);
    return $c;
}

function drug_viewer_query($dv, $sql) {
    if (!$dv || !drug_viewer_is_readonly_sql($sql)) {
        return false;
    }
    return @mysqli_query($dv, $sql);
}

function drug_viewer_close($dv) {
    if (!$dv) {
        return;
    }
    try {
        @mysqli_close($dv);
    } catch (Throwable $e) {
        // ignore
    }
}

function drug_viewer_table_count($dv) {
    $q = drug_viewer_query($dv, "SELECT COUNT(*) AS c FROM information_schema.tables WHERE table_schema = DATABASE()");
    if (!$q) {
        return 0;
    }
    $r = mysqli_fetch_assoc($q);
    return (int)($r['c'] ?? 0);
}

function drug_viewer_ping($con, array $override = null) {
    $t0 = microtime(true);
    $cfg = $override ? array_merge(drug_viewer_load_config($con), $override) : drug_viewer_load_config($con);
    $out = [
        'ok' => false,
        'ms' => 0,
        'host' => trim((string)($cfg['dv_host'] ?? '')),
        'port' => (int)($cfg['dv_port'] ?? 3306),
        'db' => (string)($cfg['dv_db'] ?? ''),
        'user' => (string)($cfg['dv_user'] ?? ''),
        'readonly' => true,
        'version' => '',
        'table_count' => 0,
        'error' => '',
    ];
    $dv = drug_viewer_connect($con, 12, $override);
    $out['ms'] = round((microtime(true) - $t0) * 1000, 1);
    if (!$dv) {
        $err = mysqli_connect_error() ?: 'เชื่อมต่อ Drug Viewer ไม่ได้';
        $out['error'] = $err;
        return $out;
    }
    $info = drug_viewer_query($dv, 'SELECT @@session.transaction_read_only AS ro, DATABASE() AS db, VERSION() AS ver');
    if ($info) {
        $r = mysqli_fetch_assoc($info);
        $out['version'] = (string)($r['ver'] ?? '');
        $out['db'] = (string)($r['db'] ?? $out['db']);
        $out['readonly'] = ((string)($r['ro'] ?? '1')) === '1';
    }
    $out['table_count'] = drug_viewer_table_count($dv);
    $out['ok'] = true;
    drug_viewer_close($dv);
    return $out;
}

function drug_viewer_strtolower($s) {
    $s = (string)$s;
    if (function_exists('mb_strtolower')) {
        return mb_strtolower($s, 'UTF-8');
    }
    return strtolower($s);
}

function drug_viewer_strpos($haystack, $needle) {
    if (function_exists('mb_strpos')) {
        return mb_strpos((string)$haystack, (string)$needle, 0, 'UTF-8');
    }
    return strpos((string)$haystack, (string)$needle);
}

function drug_viewer_list_tables($dv, $q = '', $limit = 100) {
    $limit = max(1, min(300, (int)$limit));
    $res = drug_viewer_query($dv, 'SHOW TABLES');
    if (!$res) {
        return [];
    }
    $q = trim(drug_viewer_strtolower($q));
    $preferred = ['scanorder', 'orders', 'drug', 'drugs', 'prescription', 'patient', 'rx', 'scan'];
    $tables = [];
    $rest = [];
    while ($row = mysqli_fetch_row($res)) {
        $name = (string)($row[0] ?? '');
        if ($name === '') {
            continue;
        }
        if ($q !== '' && drug_viewer_strpos(drug_viewer_strtolower($name), $q) === false) {
            continue;
        }
        $low = strtolower($name);
        $hit = false;
        foreach ($preferred as $p) {
            if (strpos($low, $p) !== false) {
                $hit = true;
                break;
            }
        }
        if ($hit) {
            $tables[] = $name;
        } else {
            $rest[] = $name;
        }
    }
    return array_slice(array_merge($tables, $rest), 0, $limit);
}

function drug_viewer_describe_table($dv, $table) {
    $ident = drug_viewer_ident($table);
    if (!$ident) {
        return [];
    }
    $q = drug_viewer_query($dv, "SHOW COLUMNS FROM $ident");
    if (!$q) {
        return [];
    }
    $cols = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $cols[] = [
            'name' => (string)($r['Field'] ?? ''),
            'type' => (string)($r['Type'] ?? ''),
            'null' => (string)($r['Null'] ?? ''),
            'key' => (string)($r['Key'] ?? ''),
        ];
    }
    return $cols;
}

/** ตรวจชื่อตารางรูปสแกนที่อนุญาต */
function drug_viewer_valid_image_table($name) {
    $name = trim((string)$name);
    return (bool)preg_match('/^scan_image(?:_\d{6})?$/', $name);
}

function drug_viewer_normalize_hn($hn) {
    $hn = preg_replace('/\D+/', '', (string)$hn);
    return $hn !== null ? $hn : '';
}

function drug_viewer_normalize_an($an) {
    return preg_replace('/[^0-9A-Za-z]/', '', (string)$an);
}

function drug_viewer_type_map($dv) {
    static $map = null;
    if ($map !== null) {
        return $map;
    }
    $map = [];
    $q = drug_viewer_query($dv, 'SELECT id, name FROM scan_type');
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $map[(int)$r['id']] = (string)$r['name'];
        }
    }
    return $map;
}

function drug_viewer_ward_map($dv) {
    static $map = null;
    if ($map !== null) {
        return $map;
    }
    $map = [];
    $q = drug_viewer_query($dv, 'SELECT id, name, shortname FROM ward');
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $id = trim((string)$r['id']);
            $label = trim((string)($r['shortname'] ?? ''));
            if ($label === '') {
                $label = trim((string)($r['name'] ?? ''));
            }
            $map[$id] = $label !== '' ? $label : $id;
        }
    }
    return $map;
}

function drug_viewer_user_map($dv) {
    static $map = null;
    if ($map !== null) {
        return $map;
    }
    $map = [];
    $q = drug_viewer_query($dv, 'SELECT id, fullname FROM users');
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $map[(int)$r['id']] = (string)$r['fullname'];
        }
    }
    return $map;
}

function drug_viewer_pay_label($pay) {
    $p = (string)$pay;
    if ($p === '1') {
        return 'จ่ายแล้ว';
    }
    if ($p === '9') {
        return 'ยกเลิก';
    }
    return 'ยังไม่จ่าย';
}

/**
 * รายการสแกนใบยาตาม HN/AN (อ่านจากตาราง scan)
 * @return array{ok:bool,error?:string,items:array,count:int}
 */
function drug_viewer_list_scans($con, $hn = '', $an = '', $limit = 80) {
    $hn = drug_viewer_normalize_hn($hn);
    $an = drug_viewer_normalize_an($an);
    $limit = max(1, min(200, (int)$limit));
    $out = ['ok' => false, 'items' => [], 'count' => 0, 'error' => ''];
    if ($hn === '' && $an === '') {
        $out['error'] = 'ระบุ HN หรือ AN';
        return $out;
    }
    $dv = drug_viewer_connect($con, 30);
    if (!$dv) {
        $out['error'] = 'เชื่อมต่อ Drug Viewer ไม่ได้';
        return $out;
    }
    // IPD: ใช้ AN เป็นหลัก ถ้าไม่มีค่อยใช้ HN
    if ($an !== '') {
        $an_esc = mysqli_real_escape_string($dv, $an);
        $sqlWhere = "s.an='$an_esc'";
    } else {
        $hn_esc = mysqli_real_escape_string($dv, $hn);
        $hn_trim = ltrim($hn, '0');
        if ($hn_trim === '') {
            $hn_trim = '0';
        }
        $hn_trim_esc = mysqli_real_escape_string($dv, $hn_trim);
        $sqlWhere = "(s.hn='$hn_esc' OR TRIM(LEADING '0' FROM s.hn)='$hn_trim_esc')";
    }
    $sql = "SELECT s.id, s.an, s.hn, s.patient, s.ward, s.datescan, s.scr_type, s.user_id,
                   s.datesave, s.print, s.pay, s.tbl_image, s.note
            FROM scan s
            WHERE $sqlWhere
            ORDER BY s.datescan DESC, s.id DESC
            LIMIT $limit";
    $q = drug_viewer_query($dv, $sql);
    if (!$q) {
        $out['error'] = 'อ่านรายการสแกนไม่สำเร็จ';
        drug_viewer_close($dv);
        return $out;
    }
    $types = drug_viewer_type_map($dv);
    $wards = drug_viewer_ward_map($dv);
    $users = drug_viewer_user_map($dv);
    $items = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $tid = (int)($r['scr_type'] ?? 0);
        $wid = trim((string)($r['ward'] ?? ''));
        $uid = (int)($r['user_id'] ?? 0);
        $tbl = trim((string)($r['tbl_image'] ?? ''));
        $items[] = [
            'id' => (int)$r['id'],
            'an' => (string)($r['an'] ?? ''),
            'hn' => (string)($r['hn'] ?? ''),
            'patient' => (string)($r['patient'] ?? ''),
            'ward' => $wid,
            'ward_name' => $wards[$wid] ?? $wid,
            'datescan' => (string)($r['datescan'] ?? ''),
            'scr_type' => $tid,
            'type_name' => $types[$tid] ?? ('ประเภท ' . $tid),
            'user_id' => $uid,
            'user_name' => $users[$uid] ?? '',
            'print' => (string)($r['print'] ?? '0'),
            'pay' => (string)($r['pay'] ?? '0'),
            'pay_label' => drug_viewer_pay_label($r['pay'] ?? '0'),
            'tbl_image' => $tbl,
            'has_image' => drug_viewer_valid_image_table($tbl) ? 1 : 0,
            'note' => (string)($r['note'] ?? ''),
        ];
    }
    drug_viewer_close($dv);
    $out['ok'] = true;
    $out['items'] = $items;
    $out['count'] = count($items);
    return $out;
}

/**
 * ดึงไฟล์สแกน (มักเป็น PDF) ตาม scan.id
 * @return array{ok:bool,error?:string,blob?:string,mime?:string,filename?:string}
 */
function drug_viewer_get_scan_blob($con, $scan_id) {
    $scan_id = (int)$scan_id;
    $out = ['ok' => false, 'error' => ''];
    if ($scan_id <= 0) {
        $out['error'] = 'รหัสสแกนไม่ถูกต้อง';
        return $out;
    }
    $dv = drug_viewer_connect($con, 60);
    if (!$dv) {
        $out['error'] = 'เชื่อมต่อ Drug Viewer ไม่ได้';
        return $out;
    }
    $q = drug_viewer_query($dv, "SELECT id, tbl_image, hn, an, datescan FROM scan WHERE id=$scan_id LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        drug_viewer_close($dv);
        $out['error'] = 'ไม่พบรายการสแกน';
        return $out;
    }
    $tbl = trim((string)($row['tbl_image'] ?? ''));
    if (!drug_viewer_valid_image_table($tbl)) {
        drug_viewer_close($dv);
        $out['error'] = 'ตารางรูปไม่ถูกต้อง';
        return $out;
    }
    $tbl_ident = drug_viewer_ident($tbl);
    $iq = drug_viewer_query($dv, "SELECT image FROM $tbl_ident WHERE id=$scan_id LIMIT 1");
    $img = $iq ? mysqli_fetch_assoc($iq) : null;
    drug_viewer_close($dv);
    if (!$img || !isset($img['image']) || $img['image'] === '' || $img['image'] === null) {
        $out['error'] = 'ไม่พบไฟล์สแกน';
        return $out;
    }
    $blob = $img['image'];
    if (!is_string($blob)) {
        $blob = (string)$blob;
    }
    $mime = 'application/octet-stream';
    $head = substr($blob, 0, 8);
    if (strncmp($head, '%PDF', 4) === 0) {
        $mime = 'application/pdf';
    } elseif (strncmp($head, "\xFF\xD8\xFF", 3) === 0) {
        $mime = 'image/jpeg';
    } elseif (strncmp($head, "\x89PNG", 4) === 0) {
        $mime = 'image/png';
    } elseif (strncmp($head, 'GIF8', 4) === 0) {
        $mime = 'image/gif';
    }
    $ext = ($mime === 'application/pdf') ? 'pdf' : (($mime === 'image/png') ? 'png' : (($mime === 'image/gif') ? 'gif' : 'jpg'));
    $fn = 'scan_' . $scan_id . '_' . preg_replace('/\D+/', '', (string)($row['hn'] ?? '')) . '.' . $ext;
    return [
        'ok' => true,
        'blob' => $blob,
        'mime' => $mime,
        'filename' => $fn,
        'hn' => (string)($row['hn'] ?? ''),
        'an' => (string)($row['an'] ?? ''),
    ];
}

function drug_viewer_preview_table($dv, $table, $limit = 20) {
    $ident = drug_viewer_ident($table);
    if (!$ident) {
        return ['columns' => [], 'rows' => [], 'error' => 'ชื่อตารางไม่ถูกต้อง'];
    }
    $cols = drug_viewer_describe_table($dv, $table);
    if (empty($cols)) {
        return ['columns' => [], 'rows' => [], 'error' => 'ไม่พบตารางนี้ หรืออ่านโครงสร้างไม่ได้'];
    }
    $limit = max(1, min(50, (int)$limit));
    $headers = [];
    $select = [];
    foreach ($cols as $c) {
        $colIdent = drug_viewer_ident($c['name']);
        if (!$colIdent) {
            continue;
        }
        $select[] = $colIdent;
        $headers[] = $c['name'];
        if (count($select) >= 24) {
            break;
        }
    }
    if (empty($select)) {
        return ['columns' => [], 'rows' => [], 'error' => 'ไม่มีคอลัมน์ที่อ่านได้'];
    }
    $sql = 'SELECT ' . implode(', ', $select) . " FROM $ident LIMIT $limit";
    $q = drug_viewer_query($dv, $sql);
    if (!$q) {
        return ['columns' => $headers, 'rows' => [], 'error' => 'อ่านข้อมูลไม่สำเร็จ'];
    }
    $rows = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $rows[] = $r;
    }
    return ['columns' => $headers, 'rows' => $rows, 'error' => ''];
}
