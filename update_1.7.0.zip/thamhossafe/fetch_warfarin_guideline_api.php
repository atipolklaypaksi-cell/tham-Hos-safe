<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
session_write_close();
require_once __DIR__ . '/warfarin_guideline_helper.php';
mysqli_set_charset($con, 'utf8');

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$raw = file_get_contents('php://input');
$body = [];
if ($raw !== false && $raw !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
        if ($action === '' && !empty($body['action'])) {
            $action = $body['action'];
        }
    }
}

if ($action === 'get' || $action === 'list') {
    echo json_encode(['status' => 'success', 'data' => wf_guideline_load($con)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'defaults') {
    echo json_encode(['status' => 'success', 'data' => wf_guideline_defaults()], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'match') {
    $inr = $body['inr'] ?? $_GET['inr'] ?? null;
    $protocol = $body['protocol_id'] ?? $_GET['protocol_id'] ?? 'inr_2_3';
    $res = wf_guideline_match($con, $inr, $protocol);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'จับคู่ไม่สำเร็จ', 'data' => $res], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode(['status' => 'success', 'data' => $res], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'get_pref') {
    $hn = trim((string)($body['hn'] ?? $_GET['hn'] ?? ''));
    if ($hn === '') {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ HN'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode(['status' => 'success', 'data' => wf_hn_pref_get($con, $hn)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_pref') {
    $hn = trim((string)($body['hn'] ?? ''));
    if ($hn === '') {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ HN'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $fields = [];
    if (array_key_exists('protocol_id', $body)) {
        $fields['protocol_id'] = $body['protocol_id'];
    }
    if (array_key_exists('guide_note', $body)) {
        $fields['guide_note'] = $body['guide_note'];
    }
    if (array_key_exists('clear_guide_note', $body) && $body['clear_guide_note']) {
        $fields['guide_note'] = null;
    }
    if (empty($fields)) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีข้อมูลที่จะบันทึก'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $saved = wf_hn_pref_save($con, $hn, $fields);
    if (empty($saved['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $saved['error'] ?? 'บันทึกไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode(['status' => 'success', 'message' => 'บันทึกแล้ว', 'data' => $saved['data']], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save') {
    $data = $body['data'] ?? null;
    if (!is_array($data)) {
        echo json_encode(['status' => 'error', 'message' => 'ข้อมูลไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $saved = wf_guideline_save($con, $data);
    if (empty($saved['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $saved['error'] ?? 'บันทึกไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode(['status' => 'success', 'message' => 'บันทึกแล้ว', 'data' => $saved['data']], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
