<?php
/**
 * สุขภาพเซิร์ฟเวอร์ + สถานะ Cron Smart Pharma
 * ใช้ทั้งหน้า monitor และ cron (flock / บันทึกผลรันล่าสุด)
 */

if (!defined('SH_CRON_LOCK_PATH')) {
    // ห้ามใช้ /tmp — cron ของ www-data มักมี PrivateTmp คนละใบกับ user อื่น
    define('SH_CRON_LOCK_PATH', __DIR__ . '/logs/cron_smart_pharma.lock');
}
if (!defined('SH_CRON_STATUS_KEY')) {
    define('SH_CRON_STATUS_KEY', 'sp_cron_last_run');
}
/** ฆ่างานค้างเมื่อรันนานเกินนี้ (วินาที) — ต่ำกว่า set_time_limit ของ cron นิดหน่อย */
if (!defined('SH_CRON_MAX_RUNTIME_SEC')) {
    define('SH_CRON_MAX_RUNTIME_SEC', 300);
}

function sh_config_get($con, $name, $default = '') {
    if (!$con) {
        return $default;
    }
    $name_esc = mysqli_real_escape_string($con, $name);
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='$name_esc' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return (string)($r['config_value'] ?? $default);
    }
    return $default;
}

function sh_config_set($con, $name, $value) {
    if (!$con) {
        return false;
    }
    $name_esc = mysqli_real_escape_string($con, $name);
    $value_esc = mysqli_real_escape_string($con, (string)$value);
    $chk = @mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$name_esc' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)@mysqli_query($con, "UPDATE sys_config SET config_value='$value_esc' WHERE config_name='$name_esc'");
    }
    return (bool)@mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$name_esc', '$value_esc')");
}

function sh_interval_options($which = 'default') {
    $all = [
        5 => '5 นาที',
        10 => '10 นาที',
        15 => '15 นาที',
        30 => '30 นาที',
        60 => '1 ชั่วโมง',
        360 => '6 ชั่วโมง',
        1440 => '24 ชั่วโมง',
    ];
    if ($which === 'screen') {
        return [5 => $all[5], 10 => $all[10], 15 => $all[15], 30 => $all[30], 60 => $all[60]];
    }
    return $all;
}

function sh_norm_interval($raw, array $allowed, $fallback) {
    $n = (int)$raw;
    return isset($allowed[$n]) ? $n : (int)$fallback;
}

function sh_jobs_catalog() {
    return [
        'smart_pharma' => [
            'id' => 'smart_pharma',
            'label' => 'Smart Pharma (คัดกรอง OPD/IPD + แจ้งเตือน)',
            'script' => 'cron_smart_pharma_telegram.php',
            'log' => 'logs/cron_smart_pharma.log',
            'heavy' => true,
            'note' => 'งานหนัก เชื่อม HOSxP — ตอนนี้คัดเฉพาะ 30 นาทีล่าสุด (ไม่คัดทั้งวัน) · ถี่เกินไปหรือรันซ้อนยังทำให้ช้าได้',
            'enabled_key' => 'sh_cron_smart_pharma_enabled',
            'enabled_default' => '1',
            'interval_key' => 'sh_cron_smart_pharma_interval_min',
            'interval_default' => 10,
            'night_interval_key' => 'sh_cron_smart_pharma_night_interval_min',
            'night_interval_default' => 15,
            'intervals' => 'screen',
        ],
        'mlab' => [
            'id' => 'mlab',
            'label' => 'mLAB ซิงก์ผลเพาะเชื้อ',
            'script' => 'cron_amr_mlab_sync.php',
            'log' => 'logs/cron_amr_mlab.log',
            'heavy' => false,
            'note' => 'ดึงไฟล์ DBF จากเครื่องแล็บ — ค่านี้ใช้ร่วมกับหน้าเชื่อมต่อ AMR',
            'enabled_key' => 'amr_mlab_sync_enabled',
            'enabled_default' => '0',
            'interval_key' => 'amr_mlab_sync_interval_min',
            'interval_default' => 10,
            'night_interval_key' => '',
            'night_interval_default' => 0,
            'intervals' => 'default',
        ],
    ];
}

function sh_job_opts($spec) {
    return sh_interval_options($spec['intervals'] ?? 'default');
}

function sh_jobs_load($con) {
    $out = [];
    foreach (sh_jobs_catalog() as $id => $spec) {
        $opts = sh_job_opts($spec);
        $enabled = sh_config_get($con, $spec['enabled_key'], $spec['enabled_default']) === '1';
        $interval = sh_norm_interval(
            sh_config_get($con, $spec['interval_key'], $spec['interval_default']),
            $opts,
            $spec['interval_default']
        );
        $night = 0;
        if (($spec['night_interval_key'] ?? '') !== '') {
            $night = sh_norm_interval(
                sh_config_get($con, $spec['night_interval_key'], $spec['night_interval_default']),
                $opts,
                $spec['night_interval_default']
            );
        }
        $out[$id] = [
            'id' => $id,
            'label' => $spec['label'],
            'script' => $spec['script'],
            'heavy' => !empty($spec['heavy']),
            'note' => $spec['note'],
            'enabled' => $enabled,
            'interval_min' => $interval,
            'night_interval_min' => $night,
            'has_night' => ($spec['night_interval_key'] ?? '') !== '',
            'options' => $opts,
            'log' => $spec['log'],
        ];
    }
    return $out;
}

function sh_jobs_save($con, array $jobs) {
    $cat = sh_jobs_catalog();
    $saved = 0;
    foreach ($jobs as $row) {
        $id = (string)($row['id'] ?? '');
        if (!isset($cat[$id])) {
            continue;
        }
        $spec = $cat[$id];
        $opts = sh_job_opts($spec);
        $enabled = !empty($row['enabled']) ? '1' : '0';
        $interval = sh_norm_interval($row['interval_min'] ?? $spec['interval_default'], $opts, $spec['interval_default']);
        sh_config_set($con, $spec['enabled_key'], $enabled);
        sh_config_set($con, $spec['interval_key'], (string)$interval);
        if (($spec['night_interval_key'] ?? '') !== '') {
            $night = sh_norm_interval($row['night_interval_min'] ?? $spec['night_interval_default'], $opts, $spec['night_interval_default']);
            sh_config_set($con, $spec['night_interval_key'], (string)$night);
        }
        $saved++;
    }
    return $saved;
}

function sh_job_active_interval(array $job) {
    $hour = (int)(new DateTime('now', new DateTimeZone('Asia/Bangkok')))->format('G');
    $day = $hour >= 7 && $hour <= 21;
    if (!empty($job['has_night']) && !$day) {
        return max(5, (int)$job['night_interval_min']);
    }
    return max(5, (int)$job['interval_min']);
}

function sh_job_due($last_ok_at, $interval_min) {
    $interval_min = max(1, (int)$interval_min);
    if (!$last_ok_at) {
        return ['due' => true, 'wait_sec' => 0];
    }
    $ts = strtotime((string)$last_ok_at);
    if (!$ts) {
        return ['due' => true, 'wait_sec' => 0];
    }
    $need = ($interval_min * 60) - 30;
    $elapsed = time() - $ts;
    if ($elapsed >= $need) {
        return ['due' => true, 'wait_sec' => 0];
    }
    return ['due' => false, 'wait_sec' => max(0, $need - $elapsed)];
}

function sh_mlab_last_run($con) {
    $q = @mysqli_query($con, "SELECT * FROM amr_mlab_sync_log ORDER BY id DESC LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return $r;
    }
    return null;
}

function sh_smart_pharma_gate($con, $force = false) {
    $jobs = sh_jobs_load($con);
    $job = $jobs['smart_pharma'];
    $interval = sh_job_active_interval($job);
    if (!$force && empty($job['enabled'])) {
        return ['run' => false, 'reason' => 'ปิดจากหน้า Monitor เซิร์ฟเวอร์', 'interval' => $interval];
    }
    if ($force) {
        return ['run' => true, 'reason' => '', 'interval' => $interval];
    }
    $last = sh_cron_status_load($con);
    $ok_at = '';
    if (is_array($last)) {
        $ok_at = (string)($last['last_ok_at'] ?? '');
        if ($ok_at === '' && ($last['status'] ?? '') === 'ok') {
            $ok_at = (string)($last['ended_at'] ?? '');
        }
    }
    $due = sh_job_due($ok_at, $interval);
    if (empty($due['due'])) {
        $wait = (int)($due['wait_sec'] ?? 0);
        return [
            'run' => false,
            'reason' => 'ยังไม่ถึงรอบ (ทุก ' . $interval . ' นาที · อีก ' . max(1, (int)ceil($wait / 60)) . ' นาที)',
            'interval' => $interval,
        ];
    }
    return ['run' => true, 'reason' => '', 'interval' => $interval];
}

function sh_now_iso() {
    $tz = new DateTimeZone('Asia/Bangkok');
    return (new DateTime('now', $tz))->format('Y-m-d H:i:s');
}

function sh_cron_peer_pids() {
    $me = (int)getmypid();
    $pids = [];
    foreach (glob('/proc/[0-9]*/cmdline') as $file) {
        if (!preg_match('#/proc/(\d+)/cmdline#', $file, $m)) {
            continue;
        }
        $pid = (int)$m[1];
        if ($pid === $me) {
            continue;
        }
        $cmd = @file_get_contents($file);
        if ($cmd === false) {
            continue;
        }
        $cmd = str_replace("\0", ' ', $cmd);
        if (strpos($cmd, 'cron_smart_pharma_telegram.php') === false) {
            continue;
        }
        if (strpos($cmd, 'sh -c') !== false) {
            continue;
        }
        if (stripos($cmd, 'php') === false) {
            continue;
        }
        $pids[] = $pid;
    }
    return $pids;
}

/** อายุโปรเซสจาก /proc (วินาที) หรือ null ถ้าไม่มี */
function sh_proc_age_sec($pid) {
    $pid = (int)$pid;
    if ($pid <= 0 || !is_dir('/proc/' . $pid)) {
        return null;
    }
    $stat = @file_get_contents('/proc/' . $pid . '/stat');
    if ($stat === false) {
        return null;
    }
    $rp = @file_get_contents('/proc/uptime');
    if ($rp === false || !preg_match('/^([\d.]+)/', $rp, $um)) {
        return null;
    }
    $uptime = (float)$um[1];
    // field 22 = starttime (clock ticks)
    $parts = explode(')', $stat, 2);
    if (count($parts) < 2) {
        return null;
    }
    $rest = preg_split('/\s+/', trim($parts[1]));
    $start_ticks = (float)($rest[19] ?? 0);
    $hz = 100.0;
    if (is_readable('/proc/self/status')) {
        // CLK_TCK ส่วนใหญ่ 100 บน Linux
    }
    $age = $uptime - ($start_ticks / $hz);
    return $age >= 0 ? (int)floor($age) : null;
}

/**
 * ฆ่า cron ที่ค้างนานเกิน SH_CRON_MAX_RUNTIME_SEC แล้วคืน true หากเคลียร์แล้ว
 */
function sh_cron_kill_stale_peers($max_age_sec = null) {
    $max_age_sec = $max_age_sec === null ? (int)SH_CRON_MAX_RUNTIME_SEC : (int)$max_age_sec;
    $killed = [];
    foreach (sh_cron_peer_pids() as $pid) {
        $age = sh_proc_age_sec($pid);
        if ($age === null) {
            continue;
        }
        if ($age < $max_age_sec) {
            continue;
        }
        @posix_kill($pid, SIGTERM);
        usleep(300000);
        if (is_dir('/proc/' . $pid)) {
            @posix_kill($pid, SIGKILL);
        }
        $killed[] = ['pid' => $pid, 'age_sec' => $age];
    }
    return $killed;
}

function sh_cron_lock_acquire() {
    $dir = dirname(SH_CRON_LOCK_PATH);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    if (!file_exists(SH_CRON_LOCK_PATH)) {
        @touch(SH_CRON_LOCK_PATH);
        @chmod(SH_CRON_LOCK_PATH, 0666);
    }

    // เคลียร์งานค้างก่อนพยายาม lock
    $killed = sh_cron_kill_stale_peers();
    if ($killed) {
        usleep(200000);
    }

    $fp = @fopen(SH_CRON_LOCK_PATH, 'c+');
    if (!$fp) {
        return sh_cron_peer_pids() ? false : null;
    }
    @chmod(SH_CRON_LOCK_PATH, 0666);
    if (!@flock($fp, LOCK_EX | LOCK_NB)) {
        // ล็อกยังถูกถือ — ลองฆ่า stale อีกรอบแล้ว reclaim
        fclose($fp);
        $killed2 = sh_cron_kill_stale_peers();
        if (!$killed2) {
            return false;
        }
        usleep(250000);
        $fp = @fopen(SH_CRON_LOCK_PATH, 'c+');
        if (!$fp || !@flock($fp, LOCK_EX | LOCK_NB)) {
            if ($fp) {
                fclose($fp);
            }
            return false;
        }
    }
    ftruncate($fp, 0);
    $meta = json_encode([
        'pid' => getmypid(),
        'started_at' => sh_now_iso(),
        'max_runtime_sec' => (int)SH_CRON_MAX_RUNTIME_SEC,
        'reclaimed' => !empty($killed),
    ], JSON_UNESCAPED_UNICODE);
    fwrite($fp, $meta !== false ? $meta : ((string)getmypid() . ' ' . sh_now_iso()));
    fflush($fp);
    return $fp;
}

function sh_cron_lock_release($fp) {
    if (!$fp) {
        return;
    }
    try {
        @flock($fp, LOCK_UN);
        @fclose($fp);
    } catch (Throwable $e) {
        // ignore
    }
}

function sh_cron_status_save($con, array $payload) {
    $prev = sh_cron_status_load($con);
    if (($payload['status'] ?? '') === 'ok') {
        $payload['last_ok_at'] = $payload['ended_at'] ?? sh_now_iso();
    } elseif ($prev) {
        if (!empty($prev['last_ok_at'])) {
            $payload['last_ok_at'] = $prev['last_ok_at'];
        } elseif (($prev['status'] ?? '') === 'ok' && !empty($prev['ended_at'])) {
            $payload['last_ok_at'] = $prev['ended_at'];
        }
    }
    $payload['saved_at'] = sh_now_iso();
    return sh_config_set($con, SH_CRON_STATUS_KEY, json_encode($payload, JSON_UNESCAPED_UNICODE));
}

function sh_cron_status_load($con) {
    $raw = sh_config_get($con, SH_CRON_STATUS_KEY, '');
    if ($raw === '') {
        return null;
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : null;
}

function sh_nproc() {
    $n = 0;
    $cpu = @file_get_contents('/proc/cpuinfo');
    if ($cpu !== false) {
        $n = preg_match_all('/^processor\s*:/m', $cpu);
    }
    return max(1, (int)$n);
}

function sh_meminfo() {
    $info = [
        'total_kb' => 0,
        'available_kb' => 0,
        'free_kb' => 0,
        'cached_kb' => 0,
        'swap_total_kb' => 0,
        'swap_free_kb' => 0,
    ];
    $raw = @file_get_contents('/proc/meminfo');
    if ($raw === false) {
        return $info;
    }
    foreach (explode("\n", $raw) as $line) {
        if (!preg_match('/^(\w+):\s+(\d+)/', $line, $m)) {
            continue;
        }
        $k = $m[1];
        $v = (int)$m[2];
        if ($k === 'MemTotal') {
            $info['total_kb'] = $v;
        } elseif ($k === 'MemAvailable') {
            $info['available_kb'] = $v;
        } elseif ($k === 'MemFree') {
            $info['free_kb'] = $v;
        } elseif ($k === 'Cached') {
            $info['cached_kb'] = $v;
        } elseif ($k === 'SwapTotal') {
            $info['swap_total_kb'] = $v;
        } elseif ($k === 'SwapFree') {
            $info['swap_free_kb'] = $v;
        }
    }
    return $info;
}

function sh_disk_path($path) {
    $total = @disk_total_space($path);
    $free = @disk_free_space($path);
    if ($total === false || $free === false || $total <= 0) {
        return null;
    }
    return [
        'path' => $path,
        'total_bytes' => (int)$total,
        'free_bytes' => (int)$free,
        'used_pct' => round((($total - $free) / $total) * 100, 1),
    ];
}

function sh_read_cmdline($pid) {
    $raw = @file_get_contents('/proc/' . (int)$pid . '/cmdline');
    if ($raw === false || $raw === '') {
        return '';
    }
    return trim(str_replace("\0", ' ', $raw));
}

function sh_web_app_catalog() {
    return [
        'thamhossafe' => 'Hos-Safe',
        'thamerp' => 'THAM ERP',
        'thamcyto' => 'THAM Cyto',
        'Emr' => 'EMR',
        'MedicationError' => 'Medication Error',
        'manageuser' => 'Manage User',
        'ANC_Record' => 'ANC Record',
        'api_php' => 'API PHP',
        'crts' => 'CRTS',
        'donate' => 'Donate',
        'donat' => 'Donat',
        'ods' => 'ODS',
        'db_config+' => 'db_config',
    ];
}

function sh_classify_web_request($script, $uri) {
    $script = (string)$script;
    $uri = (string)$uri;
    $hay = $script . ' ' . $uri;
    if ($script === '' && ($uri === '' || $uri === '-')) {
        return ['id' => 'idle', 'label' => 'ว่าง'];
    }
    if (stripos($hay, 'fpm-status') !== false) {
        return ['id' => 'status', 'label' => 'FPM status'];
    }
    foreach (sh_web_app_catalog() as $dir => $label) {
        $needle = '/' . $dir;
        if (stripos($script, $needle . '/') !== false || stripos($script, $needle) !== false) {
            return ['id' => $dir, 'label' => $label];
        }
        if (preg_match('#(?:^|/)' . preg_quote($dir, '#') . '(?:/|\?|$)#i', $uri)) {
            return ['id' => $dir, 'label' => $label];
        }
    }
    if (stripos($script, '/public/index.php') !== false || preg_match('#^/(index\.php)?(\?|$)#', $uri)) {
        return ['id' => 'employee', 'label' => 'ระบบพนักงาน (Laravel)'];
    }
    if ($uri !== '' && $uri !== '-' && $uri[0] === '/') {
        return ['id' => 'employee', 'label' => 'ระบบพนักงาน (Laravel)'];
    }
    return ['id' => 'other', 'label' => 'อื่น'];
}

function sh_fcgi_nv($name, $value) {
    $n = strlen($name);
    $v = strlen($value);
    $out = ($n < 128) ? chr($n) : pack('N', $n | 0x80000000);
    $out .= ($v < 128) ? chr($v) : pack('N', $v | 0x80000000);
    return $out . $name . $value;
}

function sh_fcgi_record($type, $reqId, $content = '') {
    $len = strlen($content);
    $pad = (8 - ($len % 8)) % 8;
    return pack('CCnnCC', 1, $type, $reqId, $len, $pad, 0) . $content . ($pad ? str_repeat("\0", $pad) : '');
}

function sh_fcgi_read($fp, $n) {
    $data = '';
    while (strlen($data) < $n && !feof($fp)) {
        $chunk = fread($fp, $n - strlen($data));
        if ($chunk === false || $chunk === '') {
            break;
        }
        $data .= $chunk;
    }
    return $data;
}

function sh_fcgi_request($host, $port, array $params, $timeout = 1.2) {
    $fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
    if (!$fp) {
        return [null, $errstr ?: ('connect ' . $host . ':' . $port . ' failed')];
    }
    stream_set_timeout($fp, (int)max(1, ceil($timeout)));
    $reqId = 1;
    $begin = pack('nC6', 1, 0, 0, 0, 0, 0, 0);
    fwrite($fp, sh_fcgi_record(1, $reqId, $begin));
    $nv = '';
    foreach ($params as $k => $v) {
        $nv .= sh_fcgi_nv($k, (string)$v);
    }
    fwrite($fp, sh_fcgi_record(4, $reqId, $nv));
    fwrite($fp, sh_fcgi_record(4, $reqId, ''));
    fwrite($fp, sh_fcgi_record(5, $reqId, ''));
    $stdout = '';
    $stderr = '';
    while (!feof($fp)) {
        $hdr = sh_fcgi_read($fp, 8);
        if (strlen($hdr) < 8) {
            break;
        }
        $h = unpack('Cver/Ctype/nreq/nlen/Cpad/Cres', $hdr);
        $content = $h['len'] > 0 ? sh_fcgi_read($fp, (int)$h['len']) : '';
        if ($h['pad'] > 0) {
            sh_fcgi_read($fp, (int)$h['pad']);
        }
        if ((int)$h['type'] === 6) {
            $stdout .= $content;
        } elseif ((int)$h['type'] === 7) {
            $stderr .= $content;
        } elseif ((int)$h['type'] === 3) {
            break;
        }
    }
    fclose($fp);
    if (preg_match('/\r\n\r\n/', $stdout)) {
        $stdout = preg_replace('/^.*?\r\n\r\n/s', '', $stdout, 1);
    }
    return [$stdout, $stderr];
}

function sh_fpm_status_query() {
    $params = [
        'SCRIPT_FILENAME' => '/fpm-status',
        'SCRIPT_NAME' => '/fpm-status',
        'QUERY_STRING' => 'json&full',
        'REQUEST_METHOD' => 'GET',
        'REQUEST_URI' => '/fpm-status?json&full',
        'SERVER_SOFTWARE' => 'thamhossafe-monitor',
        'GATEWAY_INTERFACE' => 'CGI/1.1',
    ];
    // www status :9001 · hossafe status :9003 · fallback listen :9000
    $attempts = [
        ['127.0.0.1', 9001, 'www'],
        ['127.0.0.1', 9003, 'hossafe'],
        ['127.0.0.1', 9000, 'www'],
    ];
    $merged = null;
    $lastErr = '';
    $pools_ok = [];
    foreach ($attempts as $hp) {
        [$body, $err] = sh_fcgi_request($hp[0], $hp[1], $params, 1.2);
        if ($body === null || $body === '') {
            $lastErr = $err ?: 'empty';
            continue;
        }
        $json = json_decode($body, true);
        if (!is_array($json) || !isset($json['processes'])) {
            $lastErr = 'FPM status ไม่ใช่ JSON';
            continue;
        }
        $poolName = (string)($json['pool'] ?? $hp[2]);
        if (isset($pools_ok[$poolName])) {
            continue;
        }
        $pools_ok[$poolName] = true;
        foreach ($json['processes'] as &$proc) {
            $proc['_pool'] = $poolName;
        }
        unset($proc);
        if ($merged === null) {
            $merged = $json;
            $merged['pool'] = $poolName;
            $merged['_pools'] = [$poolName];
        } else {
            $merged['processes'] = array_merge(
                (array)$merged['processes'],
                (array)$json['processes']
            );
            $merged['_pools'][] = $poolName;
            $merged['pool'] = implode('+', $merged['_pools']);
            $merged['listen queue'] = (int)($merged['listen queue'] ?? 0) + (int)($json['listen queue'] ?? 0);
            $merged['accepted conn'] = (int)($merged['accepted conn'] ?? 0) + (int)($json['accepted conn'] ?? 0);
        }
    }
    if ($merged !== null) {
        return [$merged, ''];
    }
    return [null, $lastErr];
}

function sh_fpm_status_snapshot() {
    [$raw, $err] = sh_fpm_status_query();
    $out = [
        'ok' => false,
        'error' => $err,
        'pool' => 'www',
        'pools' => [],
        'max_children' => 20,
        'workers' => 0,
        'idle' => 0,
        'busy' => 0,
        'listen_queue' => 0,
        'accepted_conn' => 0,
        'by_app_busy' => [],
        'by_app_last' => [],
        'processes' => [],
    ];
    $cfg = [];
    @exec('grep -hE "^pm\\.max_children" /usr/local/etc/php-fpm.d/zz-*.conf 2>/dev/null', $cfg);
    $sum = 0;
    foreach ($cfg as $row) {
        if (preg_match('/=\s*(\d+)/', $row, $m)) {
            $sum += (int)$m[1];
        }
    }
    if ($sum > 0) {
        $out['max_children'] = $sum;
    }
    if (!is_array($raw)) {
        return $out;
    }
    $out['ok'] = true;
    $out['error'] = '';
    $out['pool'] = (string)($raw['pool'] ?? 'www');
    $out['pools'] = (array)($raw['_pools'] ?? [$out['pool']]);
    $out['listen_queue'] = (int)($raw['listen queue'] ?? 0);
    $out['accepted_conn'] = (int)($raw['accepted conn'] ?? 0);
    $busyBy = [];
    $lastBy = [];
    foreach ((array)($raw['processes'] ?? []) as $p) {
        $state = strtolower((string)($p['state'] ?? ''));
        $uri = (string)($p['request uri'] ?? '');
        $script = (string)($p['script'] ?? '');
        if ($uri === '-') {
            $uri = '';
        }
        if ($script === '-') {
            $script = '';
        }
        $app = sh_classify_web_request($script, $uri);
        $busy = ($state === 'running');
        $row = [
            'pid' => (int)($p['pid'] ?? 0),
            'state' => $state !== '' ? $state : 'unknown',
            'busy' => $busy,
            'requests' => (int)($p['requests'] ?? 0),
            'duration_ms' => (int)round(((int)($p['request duration'] ?? 0)) / 1000),
            'method' => (string)($p['request method'] ?? ''),
            'uri' => $uri,
            'script' => $script,
            'app_id' => $app['id'],
            'app_label' => $app['label'],
            'pool' => (string)($p['_pool'] ?? ''),
        ];
        $out['processes'][] = $row;
        $out['workers']++;
        if ($busy) {
            $out['busy']++;
            $busyBy[$app['id']] = ($busyBy[$app['id']] ?? 0) + 1;
        } else {
            $out['idle']++;
        }
        if ($app['id'] !== 'idle') {
            $lastBy[$app['id']] = ($lastBy[$app['id']] ?? 0) + 1;
        }
    }
    $out['by_app_busy'] = $busyBy;
    $out['by_app_last'] = $lastBy;
    $catalog = sh_web_app_catalog() + ['employee' => 'ระบบพนักงาน (Laravel)', 'other' => 'อื่น'];
    $lastParts = [];
    foreach ($lastBy as $id => $n) {
        if ($id === 'status' || $id === 'idle' || $n < 1) {
            continue;
        }
        $lastParts[] = ($catalog[$id] ?? $id) . ' ' . $n;
    }
    $out['last_summary'] = implode(' · ', $lastParts);
    usort($out['processes'], function ($a, $b) {
        if ($a['busy'] !== $b['busy']) {
            return $a['busy'] ? -1 : 1;
        }
        return strcmp($a['app_id'], $b['app_id']);
    });
    return $out;
}

function sh_php_processes() {
    $list = [];
    foreach (glob('/proc/[0-9]*/cmdline') as $file) {
        if (!preg_match('#/proc/(\d+)/cmdline#', $file, $m)) {
            continue;
        }
        $pid = (int)$m[1];
        $cmd = sh_read_cmdline($pid);
        if ($cmd === '' || stripos($cmd, 'php') === false) {
            continue;
        }
        $stat = @file_get_contents('/proc/' . $pid . '/stat');
        $etime = '';
        $rss_kb = 0;
        $status = @file_get_contents('/proc/' . $pid . '/status');
        if ($status && preg_match('/VmRSS:\s+(\d+)/', $status, $rm)) {
            $rss_kb = (int)$rm[1];
        }
        $start_clock = 0;
        if ($stat) {
            $parts = explode(' ', $stat);
            $start_clock = isset($parts[21]) ? (int)$parts[21] : 0;
        }
        $uptime_raw = @file_get_contents('/proc/uptime');
        $uptime_sec = $uptime_raw ? (float)strtok($uptime_raw, ' ') : 0;
        $hertz = 100;
        $running_sec = 0;
        if ($start_clock > 0 && $uptime_sec > 0) {
            $running_sec = max(0, (int)round($uptime_sec - ($start_clock / $hertz)));
        }
        $kind = 'php';
        if (stripos($cmd, 'php-fpm') !== false) {
            $kind = (stripos($cmd, 'master') !== false) ? 'php-fpm-master' : 'php-fpm';
        } elseif (stripos($cmd, 'cron_smart_pharma') !== false) {
            $kind = 'cron-smart-pharma';
        } elseif (stripos($cmd, 'cron_amr_mlab') !== false) {
            $kind = 'cron-mlab';
        } elseif (stripos($cmd, 'amr_mlab_clone') !== false) {
            $kind = 'mlab-clone';
        } elseif (stripos($cmd, 'cron_dashboard_cache') !== false) {
            $kind = 'cron-dashboard';
        } elseif (stripos($cmd, 'artisan') !== false) {
            $kind = 'artisan';
        } elseif (stripos($cmd, 'thamhossafe') !== false) {
            $kind = 'thamhossafe';
        }
        $list[] = [
            'pid' => $pid,
            'kind' => $kind,
            'rss_mb' => round($rss_kb / 1024, 1),
            'running_sec' => $running_sec,
            'cmd' => substr($cmd, 0, 180),
        ];
    }
    usort($list, function ($a, $b) {
        return $b['running_sec'] <=> $a['running_sec'];
    });
    return $list;
}

function sh_tail_file($path, $lines = 40, $max_bytes = 65536) {
    if (!is_readable($path)) {
        return '';
    }
    $fp = @fopen($path, 'rb');
    if (!$fp) {
        return '';
    }
    $size = filesize($path);
    $read = min((int)$size, $max_bytes);
    if ($read <= 0) {
        fclose($fp);
        return '';
    }
    fseek($fp, -$read, SEEK_END);
    $data = fread($fp, $read);
    fclose($fp);
    $arr = preg_split("/\r\n|\n|\r/", (string)$data);
    $arr = array_values(array_filter($arr, function ($l) {
        return $l !== '';
    }));
    return implode("\n", array_slice($arr, -$lines));
}

function sh_count_in_text($text, $needle) {
    if ($text === '' || $needle === '') {
        return 0;
    }
    return substr_count($text, $needle);
}

function sh_ping_local_db($con) {
    $t0 = microtime(true);
    $ok = false;
    $err = '';
    try {
        $q = @$con ? mysqli_query($con, 'SELECT 1') : false;
        $ok = (bool)$q;
        if (!$ok && $con) {
            $err = mysqli_error($con);
        }
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
    return [
        'ok' => $ok,
        'ms' => round((microtime(true) - $t0) * 1000, 1),
        'error' => $err,
    ];
}

function sh_ping_hosoffice($con) {
    $t0 = microtime(true);
    if (!function_exists('hosoffice_connect')) {
        require_once __DIR__ . '/hosoffice_helper.php';
    }
    $cfg = function_exists('hosoffice_load_config') ? hosoffice_load_config($con) : [];
    $host = (string)($cfg['ho_host'] ?? '');
    if (trim($host) === '') {
        return [
            'ok' => false,
            'configured' => false,
            'ms' => round((microtime(true) - $t0) * 1000, 1),
            'host' => '',
            'error' => 'ยังไม่ได้ตั้งค่า',
        ];
    }
    $ping = hosoffice_ping($con);
    $ping['configured'] = true;
    if (empty($ping['ms'])) {
        $ping['ms'] = round((microtime(true) - $t0) * 1000, 1);
    }
    return $ping;
}

function sh_ping_jhcis($con) {
    $t0 = microtime(true);
    if (!function_exists('jhcis_connect')) {
        require_once __DIR__ . '/jhcis_helper.php';
    }
    $cfg = function_exists('jhcis_load_config') ? jhcis_load_config($con) : [];
    $host = (string)($cfg['jhcis_host'] ?? '');
    if (trim($host) === '') {
        return [
            'ok' => false,
            'configured' => false,
            'ms' => round((microtime(true) - $t0) * 1000, 1),
            'host' => '',
            'error' => 'ยังไม่ได้ตั้งค่า',
        ];
    }
    $ping = jhcis_ping($con);
    $ping['configured'] = true;
    if (empty($ping['ms'])) {
        $ping['ms'] = round((microtime(true) - $t0) * 1000, 1);
    }
    return $ping;
}

function sh_ping_invc($con) {
    $t0 = microtime(true);
    if (!function_exists('invc_connect')) {
        require_once __DIR__ . '/invc_helper.php';
    }
    $cfg = function_exists('invc_load_config') ? invc_load_config($con) : [];
    $host = (string)($cfg['invc_host'] ?? '');
    if (trim($host) === '') {
        return [
            'ok' => false,
            'configured' => false,
            'ms' => round((microtime(true) - $t0) * 1000, 1),
            'host' => '',
            'error' => 'ยังไม่ได้ตั้งค่า',
        ];
    }
    $ping = invc_ping($con);
    $ping['configured'] = true;
    if (empty($ping['ms'])) {
        $ping['ms'] = round((microtime(true) - $t0) * 1000, 1);
    }
    return $ping;
}

function sh_ping_hosxp($con) {
    $t0 = microtime(true);
    $ok = false;
    $err = '';
    $host = '';
    if (!function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    }
    $cfg = function_exists('hosxp_load_config') ? hosxp_load_config($con) : [];
    $host = (string)($cfg['h_host'] ?? '');
    $hos = hosxp_connect($con, 12);
    if ($hos) {
        try {
            $q = @mysqli_query($hos, 'SELECT 1');
            $ok = (bool)$q;
            if (!$ok) {
                $err = mysqli_error($hos);
            }
        } catch (Throwable $e) {
            $err = $e->getMessage();
        }
        try {
            @mysqli_close($hos);
        } catch (Throwable $e) {
            // ignore
        }
    } else {
        $err = 'เชื่อมต่อ HOSxP ไม่ได้';
    }
    return [
        'ok' => $ok,
        'ms' => round((microtime(true) - $t0) * 1000, 1),
        'host' => $host,
        'error' => $err,
    ];
}

function sh_level($ok, $warn) {
    if (!$ok) {
        return 'crit';
    }
    return $warn ? 'warn' : 'ok';
}

function sh_collect_snapshot($con) {
    $load = function_exists('sys_getloadavg') ? sys_getloadavg() : [0, 0, 0];
    $nproc = sh_nproc();
    $mem = sh_meminfo();
    $mem_used_pct = 0;
    if ($mem['total_kb'] > 0) {
        $mem_used_pct = round((($mem['total_kb'] - $mem['available_kb']) / $mem['total_kb']) * 100, 1);
    }
    $disk_root = sh_disk_path('/');
    $disk_home = sh_disk_path('/home');
    $disk_proj = sh_disk_path(__DIR__);
    $php_list = sh_php_processes();
    $fpm_status = sh_fpm_status_snapshot();
    $fpm_by_pid = [];
    foreach ($fpm_status['processes'] as $fp) {
        $fpm_by_pid[(int)$fp['pid']] = $fp;
    }
    $cron_running = [];
    $mlab_running = [];
    $clone_running = [];
    $fpm_workers = 0;
    $fpm_masters = 0;
    $tham_php = 0;
    foreach ($php_list as &$p) {
        if ($p['kind'] === 'cron-smart-pharma') {
            $cron_running[] = $p;
        } elseif ($p['kind'] === 'cron-mlab') {
            $mlab_running[] = $p;
        } elseif ($p['kind'] === 'mlab-clone') {
            $clone_running[] = $p;
        } elseif ($p['kind'] === 'php-fpm') {
            $fpm_workers++;
            $extra = $fpm_by_pid[(int)$p['pid']] ?? null;
            if ($extra) {
                $p['fpm_state'] = $extra['state'];
                $p['app_id'] = $extra['app_id'];
                $p['app_label'] = $extra['app_label'];
                $p['request_uri'] = $extra['uri'];
                $p['script'] = $extra['script'];
                $p['busy'] = $extra['busy'];
                $p['kind'] = $extra['busy'] ? ('fpm-' . $extra['app_id']) : 'php-fpm-idle';
            }
        } elseif ($p['kind'] === 'php-fpm-master') {
            $fpm_masters++;
        }
        if (stripos($p['cmd'], 'thamhossafe') !== false || (($p['app_id'] ?? '') === 'thamhossafe' && !empty($p['busy']))) {
            $tham_php++;
        }
    }
    unset($p);

    $log_paths = [
        __DIR__ . '/logs/cron_smart_pharma.log',
        __DIR__ . '/logs/cron_amr_mlab.log',
        '/var/log/thamhossafe_cron.log',
    ];
    $logs = [];
    $fatal_recent = 0;
    foreach ($log_paths as $path) {
        if (!file_exists($path)) {
            continue;
        }
        $tail = sh_tail_file($path, 35);
        $fatal_recent += sh_count_in_text($tail, 'mysqli object is already closed');
        $fatal_recent += sh_count_in_text($tail, 'PHP Fatal error');
        $logs[] = [
            'path' => $path,
            'size_mb' => round(filesize($path) / 1048576, 2),
            'mtime' => date('Y-m-d H:i:s', filemtime($path)),
            'tail' => $tail,
        ];
    }

    $local = sh_ping_local_db($con);
    $hosxp = sh_ping_hosxp($con);
    $hosoffice = sh_ping_hosoffice($con);
    $jhcis = sh_ping_jhcis($con);
    $invc = sh_ping_invc($con);
    $cron_last = sh_cron_status_load($con);

    $load1 = (float)($load[0] ?? 0);
    $load_warn = $load1 >= $nproc * 0.8;
    $load_crit = $load1 >= $nproc;
    $mem_warn = $mem_used_pct >= 85 || ($mem['available_kb'] > 0 && $mem['available_kb'] < 300 * 1024);
    $disk_warn = ($disk_root && $disk_root['used_pct'] >= 85) || ($disk_home && $disk_home['used_pct'] >= 85);
    $cron_overlap = count($cron_running) >= 2;
    $cron_long = false;
    foreach ($cron_running as $c) {
        if ((int)$c['running_sec'] >= 300) {
            $cron_long = true;
        }
    }
    $hosxp_slow = $hosxp['ok'] && $hosxp['ms'] >= 1500;
    $hosoffice_slow = !empty($hosoffice['ok']) && $hosoffice['ms'] >= 1500;
    $jhcis_slow = !empty($jhcis['ok']) && $jhcis['ms'] >= 1500;
    $invc_slow = !empty($invc['ok']) && $invc['ms'] >= 1500;
    $cron_fail = is_array($cron_last) && (($cron_last['status'] ?? '') === 'error');
    $www_log = null;
    $sp_log = null;
    foreach ($logs as $lg) {
        if (strpos($lg['path'], 'thamhossafe_cron.log') !== false) {
            $www_log = $lg;
        }
        if (strpos($lg['path'], 'cron_smart_pharma.log') !== false) {
            $sp_log = $lg;
        }
    }
    $two_crontabs = $www_log && $sp_log
        && abs(strtotime($sp_log['mtime']) - strtotime($www_log['mtime'])) <= 120;

    $jobs = sh_jobs_load($con);
    $jobs['smart_pharma']['last'] = $cron_last;
    $jobs['smart_pharma']['running'] = $cron_running;
    $jobs['smart_pharma']['active_interval_min'] = sh_job_active_interval($jobs['smart_pharma']);
    $jobs['mlab']['last'] = sh_mlab_last_run($con);
    $jobs['mlab']['running'] = $mlab_running;
    $jobs['mlab']['active_interval_min'] = sh_job_active_interval($jobs['mlab']);

    $findings = [];
    $overall = 'ok';
    $bump = function ($level) use (&$overall) {
        $rank = ['ok' => 0, 'warn' => 1, 'crit' => 2];
        if ($rank[$level] > $rank[$overall]) {
            $overall = $level;
        }
    };

    if (!$local['ok']) {
        $findings[] = ['level' => 'crit', 'title' => 'ฐานข้อมูล Hos-Safe ตอบไม่ได้', 'detail' => $local['error'] ?: 'SELECT 1 ล้มเหลว'];
        $bump('crit');
    }
    if (!$hosxp['ok']) {
        $findings[] = ['level' => 'crit', 'title' => 'เชื่อมต่อ HOSxP ไม่ได้', 'detail' => ($hosxp['host'] ? $hosxp['host'] . ' — ' : '') . ($hosxp['error'] ?: 'timeout')];
        $bump('crit');
    } elseif ($hosxp_slow) {
        $findings[] = ['level' => 'warn', 'title' => 'HOSxP ตอบช้า', 'detail' => 'ใช้เวลา ' . $hosxp['ms'] . ' ms — หน้า Monitor ที่ดึงยา/แลบจะรู้สึกค้าง'];
        $bump('warn');
    }
    if (!empty($hosoffice['configured']) && empty($hosoffice['ok'])) {
        $findings[] = ['level' => 'warn', 'title' => 'เชื่อมต่อ HOSoffice ไม่ได้', 'detail' => ($hosoffice['host'] ? $hosoffice['host'] . ' — ' : '') . ($hosoffice['error'] ?: 'timeout')];
        $bump('warn');
    } elseif ($hosoffice_slow) {
        $findings[] = ['level' => 'warn', 'title' => 'HOSoffice ตอบช้า', 'detail' => 'ใช้เวลา ' . $hosoffice['ms'] . ' ms'];
        $bump('warn');
    }
    if (!empty($jhcis['configured']) && empty($jhcis['ok'])) {
        $findings[] = ['level' => 'warn', 'title' => 'เชื่อมต่อ JHCIS PCC ไม่ได้', 'detail' => ($jhcis['host'] ? $jhcis['host'] . ' — ' : '') . ($jhcis['error'] ?: 'timeout')];
        $bump('warn');
    } elseif ($jhcis_slow) {
        $findings[] = ['level' => 'warn', 'title' => 'JHCIS PCC ตอบช้า', 'detail' => 'ใช้เวลา ' . $jhcis['ms'] . ' ms'];
        $bump('warn');
    }
    if (!empty($invc['configured']) && empty($invc['ok'])) {
        $findings[] = ['level' => 'warn', 'title' => 'เชื่อมต่อ INVC ไม่ได้', 'detail' => ($invc['host'] ? $invc['host'] . ' — ' : '') . ($invc['error'] ?: 'timeout')];
        $bump('warn');
    } elseif ($invc_slow) {
        $findings[] = ['level' => 'warn', 'title' => 'INVC ตอบช้า', 'detail' => 'ใช้เวลา ' . $invc['ms'] . ' ms'];
        $bump('warn');
    }
    if ($cron_overlap) {
        $findings[] = ['level' => 'crit', 'title' => 'Cron Smart Pharma ซ้อนกันอยู่', 'detail' => 'เจอ ' . count($cron_running) . ' โปรเซสพร้อมกัน — แย่ง connection HOSxP ทำให้เว็บค้าง'];
        $bump('crit');
    } elseif ($cron_long) {
        $findings[] = ['level' => 'warn', 'title' => 'Cron Smart Pharma รันนานเกิน 5 นาที', 'detail' => 'รอบถัดไปจะถูกข้าม (flock) จนกว่างานนี้จะจบ — ถ้าเว็บช้าช่วงนี้ ให้รอหรือลดความถี่ด้านล่าง'];
        $bump('warn');
    }
    if ($clone_running) {
        $findings[] = ['level' => 'warn', 'title' => 'กำลังดึงทั้งฐาน mLAB', 'detail' => 'งานนี้กิน CPU/ดิสก์ — หน้าเว็บอาจช้าจนกว่าจะดึงครบ'];
        $bump('warn');
    }
    foreach ($mlab_running as $c) {
        if ((int)$c['running_sec'] >= 180) {
            $findings[] = ['level' => 'warn', 'title' => 'Cron mLAB รันนาน', 'detail' => 'PID ' . $c['pid'] . ' รันมาแล้ว ' . $c['running_sec'] . ' วินาที'];
            $bump('warn');
            break;
        }
    }
    if ($two_crontabs) {
        $findings[] = [
            'level' => 'warn',
            'title' => 'มี Cron 2 เส้นทางเขียน log คนละไฟล์',
            'detail' => 'user co-scph → logs/cron_smart_pharma.log และ www-data → /var/log/thamhossafe_cron.log — ควรเหลือ crontab เดียว',
        ];
        $bump('warn');
    }
    if ($cron_fail) {
        $findings[] = ['level' => 'warn', 'title' => 'Cron รอบล่าสุด error', 'detail' => (string)($cron_last['message'] ?? 'ดู log ด้านล่าง')];
        $bump('warn');
    }
    if ($fatal_recent > 0) {
        $findings[] = ['level' => 'warn', 'title' => 'Log Cron มี Fatal ล่าสุด', 'detail' => 'พบบรรทัด Fatal ประมาณ ' . $fatal_recent . ' บรรทัดในช่วงท้าย log — มักเกิดจาก HOSxP ตัด connection กลางคัน'];
        $bump('warn');
    }
    if ($load_crit) {
        $findings[] = ['level' => 'crit', 'title' => 'CPU โหลดสูง', 'detail' => 'load 1 นาที = ' . round($load1, 2) . ' / ' . $nproc . ' คอร์'];
        $bump('crit');
    } elseif ($load_warn) {
        $findings[] = ['level' => 'warn', 'title' => 'CPU เริ่มสูง', 'detail' => 'load 1 นาที = ' . round($load1, 2) . ' / ' . $nproc . ' คอร์'];
        $bump('warn');
    }
    if ($mem_warn) {
        $findings[] = ['level' => 'warn', 'title' => 'RAM เหลือน้อย', 'detail' => 'ใช้ไป ' . $mem_used_pct . '% — ว่าง ' . round($mem['available_kb'] / 1024) . ' MB'];
        $bump('warn');
    }
    if ($disk_warn) {
        $findings[] = ['level' => 'warn', 'title' => 'ดิสก์เกือบเต็ม', 'detail' => 'ตรวจพื้นที่ / หรือ /home'];
        $bump('warn');
    }
    if (empty($findings)) {
        $findings[] = [
            'level' => 'ok',
            'title' => 'ตอนนี้เครื่องนี้ไม่ได้ช้า',
            'detail' => 'ถ้าเว็บเพิ่งค้างแล้วหาย ดูกล่องช่วงที่เว็บค้างด้านล่าง — หน้า Monitor จับตอนค้างไม่ได้เพราะใช้ PHP ชุดเดียวกับเว็บ',
        ];
    }

    $hang_watch = sh_hang_watch_summary();
    if (!empty($hang_watch['recent_hangs'])) {
        $n = count($hang_watch['recent_hangs']);
        $last_at = $hang_watch['recent_hangs'][0]['at'] ?? '';
        $findings = array_merge([[
            'level' => 'warn',
            'title' => 'จับได้ว่าเว็บเคยค้าง (นอกหน้า Monitor)',
            'detail' => 'มี ' . $n . ' ช่วงใน 6 ชั่วโมงล่าสุด · ล่าสุด ' . $last_at . ' — ดูกล่องด้านล่างว่าตอนนั้น PHP/Apache/CPU เป็นอย่างไร',
        ]], $findings);
        $bump('warn');
    }

    return [
        'checked_at' => sh_now_iso(),
        'overall' => $overall,
        'findings' => $findings,
        'cpu' => [
            'nproc' => $nproc,
            'load' => [round((float)$load[0], 2), round((float)$load[1], 2), round((float)$load[2], 2)],
            'level' => $load_crit ? 'crit' : ($load_warn ? 'warn' : 'ok'),
        ],
        'memory' => [
            'total_mb' => round($mem['total_kb'] / 1024),
            'available_mb' => round($mem['available_kb'] / 1024),
            'used_pct' => $mem_used_pct,
            'swap_used_mb' => round(($mem['swap_total_kb'] - $mem['swap_free_kb']) / 1024),
            'level' => $mem_warn ? 'warn' : 'ok',
        ],
        'disk' => [
            'root' => $disk_root,
            'home' => $disk_home,
            'project' => $disk_proj,
            'level' => $disk_warn ? 'warn' : 'ok',
        ],
        'php' => [
            'fpm_masters' => $fpm_masters,
            'fpm_workers' => $fpm_status['ok'] ? (int)$fpm_status['workers'] : $fpm_workers,
            'thamhossafe' => $tham_php,
            'fpm' => $fpm_status,
            'processes' => array_slice($php_list, 0, 25),
        ],
        'db' => [
            'local' => $local,
            'hosxp' => $hosxp,
            'hosoffice' => $hosoffice,
            'jhcis' => $jhcis,
            'invc' => $invc,
        ],
        'cron' => [
            'running' => $cron_running,
            'overlap' => $cron_overlap,
            'last' => $cron_last,
            'schedule' => 'เซิร์ฟเวอร์ตรวจทุก 5 นาที — ความถี่จริงตั้งด้านล่าง',
            'lock_path' => SH_CRON_LOCK_PATH,
            'logs' => $logs,
            'jobs' => array_values($jobs),
            'mlab_running' => $mlab_running,
            'clone_running' => $clone_running,
        ],
        'hang_watch' => $hang_watch,
    ];
}

function sh_hang_dir() {
    return __DIR__ . '/logs/hang_watch';
}

function sh_count_cmd_matches(array $needles) {
    $n = 0;
    foreach (glob('/proc/[0-9]*/cmdline') as $file) {
        $cmd = @file_get_contents($file);
        if ($cmd === false) {
            continue;
        }
        $cmd = str_replace("\0", ' ', $cmd);
        foreach ($needles as $needle) {
            if (stripos($cmd, $needle) !== false) {
                $n++;
                break;
            }
        }
    }
    return $n;
}

function sh_http_probe($url, $timeout = 3) {
    $t0 = microtime(true);
    $ctx = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => max(1, (int)$timeout),
            'ignore_errors' => true,
            'header' => "Connection: close\r\n",
        ],
    ]);
    $body = @file_get_contents($url, false, $ctx);
    $ms = round((microtime(true) - $t0) * 1000, 1);
    $code = 0;
    if (!empty($http_response_header[0]) && preg_match('/\s(\d{3})\b/', $http_response_header[0], $m)) {
        $code = (int)$m[1];
    }
    $ok = ($body !== false && $code > 0 && $code < 500);
    return [
        'url' => $url,
        'ok' => $ok,
        'ms' => $ms,
        'code' => $code,
        'body' => $body === false ? '' : substr(trim((string)$body), 0, 80),
        'error' => $body === false ? 'timeout หรือเชื่อมไม่ได้ใน ' . $timeout . ' วินาที' : '',
    ];
}

function sh_tcp_probe($host, $port, $timeout = 2) {
    $t0 = microtime(true);
    $errno = 0;
    $errstr = '';
    $fp = @fsockopen((string)$host, (int)$port, $errno, $errstr, (float)$timeout);
    $ms = round((microtime(true) - $t0) * 1000, 1);
    if (is_resource($fp)) {
        fclose($fp);
        return ['host' => (string)$host, 'port' => (int)$port, 'ok' => true, 'ms' => $ms, 'error' => ''];
    }
    $err = trim((string)$errstr);
    if ($err === '') {
        $err = 'errno ' . (int)$errno;
    }
    return ['host' => (string)$host, 'port' => (int)$port, 'ok' => false, 'ms' => $ms, 'error' => $err];
}

function sh_db_connect_fail_recent($limit = 20, $within_sec = 900) {
    $path = __DIR__ . '/logs/db_connect_fail.log';
    $limit = max(1, (int)$limit);
    $cut = time() - max(60, (int)$within_sec);
    if (!is_readable($path)) {
        return [];
    }
    $raw = @file_get_contents($path);
    if (!is_string($raw) || $raw === '') {
        return [];
    }
    $lines = preg_split("/\r\n|\n|\r/", trim($raw));
    $out = [];
    for ($i = count($lines) - 1; $i >= 0 && count($out) < $limit; $i--) {
        $line = trim((string)$lines[$i]);
        if ($line === '') {
            continue;
        }
        $parts = explode("\t", $line, 4);
        $at = $parts[0] ?? '';
        $ts = strtotime($at);
        if ($ts && $ts < $cut) {
            break;
        }
        $out[] = [
            'at' => $at,
            'sapi' => $parts[1] ?? '',
            'uri' => $parts[2] ?? '',
            'message' => $parts[3] ?? $line,
        ];
    }
    return $out;
}

function sh_hang_watch_collect() {
    $load = function_exists('sys_getloadavg') ? sys_getloadavg() : [0, 0, 0];
    $nproc = sh_nproc();
    $mem = sh_meminfo();
    $php_list = sh_php_processes();
    $long = [];
    foreach ($php_list as $p) {
        $kind = (string)($p['kind'] ?? '');
        $cmd = (string)($p['cmd'] ?? '');
        if ($kind === 'php-fpm' || $kind === 'php-fpm-master') {
            continue;
        }
        if (stripos($cmd, 'cron_hang_watch') !== false || stripos($cmd, 'queue:work') !== false) {
            continue;
        }
        if (stripos($cmd, 'intelliphp') !== false || stripos($cmd, 'cursor-server') !== false) {
            continue;
        }
        // ข้าม shell ห่อ cron (/bin/sh -c php ...) — นับเฉพาะโปรเซส php จริง กัน false positive
        if (preg_match('#(^|/bin/)(ba)?sh(\s|$)#', $cmd) && stripos($cmd, ' -c ') !== false) {
            continue;
        }
        if ((int)($p['running_sec'] ?? 0) < 90) {
            continue;
        }
        if (stripos($cmd, 'thamhossafe') === false && strpos($kind, 'cron') !== 0 && $kind !== 'mlab-clone') {
            continue;
        }
        $long[] = [
            'pid' => $p['pid'],
            'kind' => $kind,
            'running_sec' => $p['running_sec'],
            'rss_mb' => $p['rss_mb'],
            'cmd' => $cmd,
        ];
    }
    $long = array_slice($long, 0, 15);
    $docker = sh_docker_php_snapshot();
    $probe = sh_http_probe('http://127.0.0.1:8889/thamhossafe/app_ping.php', 3);
    if (!$probe['ok'] && (int)($probe['code'] ?? 0) === 0) {
        $alt = sh_http_probe('http://61.7.167.197/thamhossafe/app_ping.php', 3);
        if ($alt['ok'] || (int)($alt['code'] ?? 0) > 0) {
            $probe = $alt;
        }
    }
    $db = sh_tcp_probe('192.168.4.4', 3306, 2);
    $db_fails = sh_db_connect_fail_recent(20, 900);
    $db_fail_recent = false;
    $db_fail_cut = time() - 180;
    foreach ($db_fails as $fail) {
        $ts = strtotime((string)($fail['at'] ?? ''));
        if ($ts && $ts >= $db_fail_cut) {
            $db_fail_recent = true;
            break;
        }
    }
    $fpm = sh_fpm_status_snapshot();
    $slow_req = [];
    foreach ((array)($fpm['processes'] ?? []) as $proc) {
        if (empty($proc['busy'])) {
            continue;
        }
        if ((int)($proc['duration_ms'] ?? 0) < 8000) {
            continue;
        }
        $slow_req[] = [
            'pid' => $proc['pid'] ?? 0,
            'pool' => $proc['pool'] ?? '',
            'duration_ms' => $proc['duration_ms'] ?? 0,
            'uri' => $proc['uri'] ?? '',
            'script' => $proc['script'] ?? '',
        ];
    }
    $slow_req = array_slice($slow_req, 0, 12);
    $web_down = empty($probe['ok']);
    $web_slow = !empty($probe['ok']) && (float)$probe['ms'] >= 2000;
    $load1 = (float)($load[0] ?? 0);
    $load_high = $load1 >= max(1, $nproc);
    $fpm_full = ((int)($docker['workers'] ?? 0) >= (int)($docker['max_children'] ?? 5))
        && ((int)($docker['busy'] ?? 0) >= max(2, (int)($docker['workers'] ?? 0) - 1));
    // cron รันนาน = สัญญาณเสี่ยง (แย่ง HOSxP) แต่ไม่นับเป็น "เว็บค้าง" ถ้า ping ยังเร็ว
    $cron_heavy = count($long) >= 1 && (int)($long[0]['running_sec'] ?? 0) >= 180;
    $php_jam = count($long) >= 2;
    $db_down = empty($db['ok']);
    $req_stuck = count($slow_req) > 0;
    $hang = $web_down || $web_slow || $fpm_full || $db_down || $db_fail_recent || $req_stuck
        || ($php_jam && ($web_slow || $web_down || $fpm_full || $load_high));
    $reasons = [];
    if ($db_down) {
        $reasons[] = 'ฐาน THAM 192.168.4.4:3306 ไม่ตอบ (' . ($db['error'] ?: 'timeout') . ', ' . $db['ms'] . ' ms)';
    }
    if ($db_fail_recent) {
        $reasons[] = 'มีหน้าเว็บต่อฐานข้อมูลไม่สำเร็จใน 3 นาทีล่าสุด';
    }
    if ($req_stuck) {
        $uris = [];
        foreach ($slow_req as $proc) {
            $uris[] = trim((string)($proc['uri'] ?: $proc['script'])) . ' ' . round(((int)$proc['duration_ms']) / 1000) . 's';
        }
        $reasons[] = 'มี request ค้างตั้งแต่ 8 วินาที: ' . implode(' | ', array_slice($uris, 0, 4));
    }
    if ($web_down) {
        $reasons[] = 'เว็บ (employee-web:8889) ไม่ตอบ app_ping ใน 3 วินาที';
    } elseif ($web_slow) {
        $reasons[] = 'app_ping ช้า ' . $probe['ms'] . ' ms';
    }
    if ($fpm_full) {
        $reasons[] = 'PHP-FPM ใน Docker เต็ม (' . (int)$docker['busy'] . '/' . (int)$docker['workers'] . ' worker ไม่ว่าง · max ' . (int)$docker['max_children'] . ')';
    }
    if ($php_jam) {
        $reasons[] = 'มี cron/CLI ของ Hos-Safe รันนาน ' . count($long) . ' โปรเซส';
    } elseif ($cron_heavy) {
        $reasons[] = 'Cron Smart Pharma รันนาน ' . (int)$long[0]['running_sec'] . ' วินาที (แย่ง HOSxP ได้ — เว็บยังตอบได้)';
    }
    if ($load_high) {
        $reasons[] = 'CPU load ' . round($load1, 2) . ' / ' . $nproc . ' คอร์';
    }
    $mem_used_pct = 0;
    if ($mem['total_kb'] > 0) {
        $mem_used_pct = round((($mem['total_kb'] - $mem['available_kb']) / $mem['total_kb']) * 100, 1);
    }
    return [
        'at' => sh_now_iso(),
        'hang' => $hang,
        'reasons' => $reasons,
        'web' => $probe,
        'db' => $db,
        'db_fails' => $db_fails,
        'slow_requests' => $slow_req,
        'cpu' => [
            'nproc' => $nproc,
            'load' => [round((float)$load[0], 2), round((float)$load[1], 2), round((float)$load[2], 2)],
        ],
        'memory' => [
            'used_pct' => $mem_used_pct,
            'available_mb' => round($mem['available_kb'] / 1024),
        ],
        'docker_php' => $docker,
        'php_n' => count($php_list),
        'php_long' => $long,
    ];
}

function sh_docker_php_snapshot() {
    $out = [
        'workers' => 0,
        'busy' => 0,
        'max_children' => 5,
        'by_pool' => [],
        'lines' => [],
    ];
    $lines = [];
    @exec('docker top employee-php -eo pid,etime,stat,cmd 2>/dev/null', $lines);
    foreach ($lines as $line) {
        $pool = '';
        if (preg_match('/pool\s+(\w+)/i', $line, $pm)) {
            $pool = strtolower($pm[1]);
        }
        if ($pool === '' || !in_array($pool, ['www', 'hossafe'], true)) {
            continue;
        }
        if (!isset($out['by_pool'][$pool])) {
            $out['by_pool'][$pool] = ['workers' => 0, 'busy' => 0];
        }
        $out['workers']++;
        $out['by_pool'][$pool]['workers']++;
        $stat = '';
        if (preg_match('/\s([RSDZT])(?:[+<s])?\s+php-fpm/i', $line, $m)) {
            $stat = strtoupper($m[1]);
        } elseif (preg_match('/\b([RSDZT])\b/', $line, $m)) {
            $stat = strtoupper($m[1]);
        }
        if (in_array($stat, ['R', 'D'], true)) {
            $out['busy']++;
            $out['by_pool'][$pool]['busy']++;
            $out['lines'][] = trim($line);
        }
    }
    $cfg = [];
    // อ้างอิงผ่าน sh -c เพื่อไม่ให้ shell โฮสต์ขยาย *.conf ก่อนเข้าคอนเทนเนอร์
    @exec('docker exec employee-php sh -c \'grep -hE "^pm\\.max_children" /usr/local/etc/php-fpm.d/zz-*.conf\' 2>/dev/null', $cfg);
    $sum = 0;
    foreach ($cfg as $row) {
        if (preg_match('/=\s*(\d+)/', $row, $m)) {
            $sum += (int)$m[1];
        }
    }
    if ($sum > 0) {
        $out['max_children'] = $sum;
    }
    return $out;
}

function sh_hang_watch_save(array $snap) {
    $dir = sh_hang_dir();
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $json = json_encode($snap, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    @file_put_contents($dir . '/latest.json', $json);
    if (!empty($snap['hang'])) {
        $name = $dir . '/hang-' . (new DateTime('now', new DateTimeZone('Asia/Bangkok')))->format('Ymd-His') . '.json';
        @file_put_contents($name, $json);
        $files = glob($dir . '/hang-*.json') ?: [];
        rsort($files);
        foreach (array_slice($files, 40) as $old) {
            @unlink($old);
        }
    }
    return $dir . '/latest.json';
}

function sh_hang_watch_summary() {
    $dir = sh_hang_dir();
    $latest = null;
    $latest_path = $dir . '/latest.json';
    if (is_readable($latest_path)) {
        $latest = json_decode((string)file_get_contents($latest_path), true);
        if (!is_array($latest)) {
            $latest = null;
        }
    }
    $recent = [];
    $cut = time() - 6 * 3600;
    $files = glob($dir . '/hang-*.json') ?: [];
    rsort($files);
    foreach (array_slice($files, 0, 20) as $path) {
        $row = json_decode((string)@file_get_contents($path), true);
        if (!is_array($row)) {
            continue;
        }
        $ts = strtotime((string)($row['at'] ?? ''));
        if ($ts && $ts < $cut) {
            continue;
        }
        $recent[] = [
            'at' => $row['at'] ?? '',
            'reasons' => $row['reasons'] ?? [],
            'web_ms' => $row['web']['ms'] ?? null,
            'web_ok' => $row['web']['ok'] ?? null,
            'load' => $row['cpu']['load'][0] ?? null,
            'php_long_n' => is_array($row['php_long'] ?? null) ? count($row['php_long']) : 0,
            'php_long' => array_slice($row['php_long'] ?? [], 0, 8),
            'db_ok' => $row['db']['ok'] ?? null,
            'db_error' => $row['db']['error'] ?? '',
            'db_fails' => array_slice($row['db_fails'] ?? [], 0, 8),
            'slow_requests' => array_slice($row['slow_requests'] ?? [], 0, 8),
        ];
    }
    return [
        'latest' => $latest,
        'recent_hangs' => $recent,
        'cron_line' => '* * * * * /usr/bin/php ' . __DIR__ . '/cron_hang_watch.php >> ' . $dir . '/cron.log 2>&1',
        'has_watcher' => is_array($latest) && !empty($latest['at']) && (time() - strtotime((string)$latest['at'])) < 180,
    ];
}
