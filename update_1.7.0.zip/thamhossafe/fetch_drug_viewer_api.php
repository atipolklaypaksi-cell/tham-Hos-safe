<?php
/**
 * API เชื่อมต่อ Drug Viewer (Read Only)
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();
include(__DIR__ . '/connect.php');
require_once __DIR__ . '/drug_viewer_helper.php';
mysqli_set_charset($con, 'utf8');

function drug_viewer_api_json(array $payload, $code = 200) {
    ob_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    drug_viewer_api_json(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], 401);
}

require_once __DIR__ . '/menu_permissions_helper.php';
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.drug_viewer') && !tham_menu_can('admin.hosxp')) {
    drug_viewer_api_json(['status' => 'error', 'message' => 'ไม่มีสิทธิ์ตั้งค่า Drug Viewer'], 403);
}
session_write_close();

drug_viewer_ensure_config($con);
$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'get'));

if ($action === 'get') {
    drug_viewer_api_json([
        'status' => 'success',
        'config' => drug_viewer_public_config(drug_viewer_load_config($con)),
    ]);
}

if ($action === 'save') {
    $cfg = drug_viewer_save_config($con, $input);
    drug_viewer_api_json([
        'status' => 'success',
        'message' => 'บันทึกการเชื่อมต่อ Drug Viewer แล้ว (Read Only)',
        'config' => drug_viewer_public_config($cfg),
    ]);
}

if ($action === 'test') {
    $override = [];
    foreach (['dv_host', 'dv_port', 'dv_user', 'dv_db'] as $k) {
        if (isset($input[$k])) {
            $override[$k] = trim((string)$input[$k]);
        }
    }
    if (isset($input['dv_pass']) && (string)$input['dv_pass'] !== '' && (string)$input['dv_pass'] !== '********') {
        $override['dv_pass'] = (string)$input['dv_pass'];
    }
    $ping = drug_viewer_ping($con, $override ?: null);
    drug_viewer_api_json([
        'status' => $ping['ok'] ? 'success' : 'error',
        'message' => $ping['ok']
            ? 'เชื่อมต่อ Drug Viewer สำเร็จ (Read Only)'
            : ('เชื่อมต่อล้มเหลว: ' . ($ping['error'] ?: 'ไม่ทราบสาเหตุ')),
        'ping' => $ping,
    ]);
}

if ($action === 'tables') {
    $dv = drug_viewer_connect($con, 20);
    if (!$dv) {
        drug_viewer_api_json(['status' => 'error', 'message' => 'เชื่อมต่อ Drug Viewer ไม่ได้']);
    }
    $q = trim((string)($input['q'] ?? $_GET['q'] ?? ''));
    $tables = drug_viewer_list_tables($dv, $q, 120);
    drug_viewer_close($dv);
    drug_viewer_api_json([
        'status' => 'success',
        'tables' => $tables,
    ]);
}

if ($action === 'preview') {
    $table = trim((string)($input['table'] ?? $_GET['table'] ?? ''));
    $dv = drug_viewer_connect($con, 20);
    if (!$dv) {
        drug_viewer_api_json(['status' => 'error', 'message' => 'เชื่อมต่อ Drug Viewer ไม่ได้']);
    }
    $preview = drug_viewer_preview_table($dv, $table, 20);
    $cols = drug_viewer_describe_table($dv, $table);
    drug_viewer_close($dv);
    drug_viewer_api_json([
        'status' => empty($preview['error']) ? 'success' : 'error',
        'message' => $preview['error'] ?: '',
        'table' => $table,
        'columns' => $cols,
        'preview' => $preview,
    ]);
}

drug_viewer_api_json(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], 400);
