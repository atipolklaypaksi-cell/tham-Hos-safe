<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}
include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.hosxp_master') && !tham_menu_can('admin.hosxp')) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์ตั้งค่า HOSxP master']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'วิธีเรียกไม่ถูกต้อง']);
    exit;
}

$cur = hosxp_load_master_config($con);
$cur_write = hosxp_load_write_config($con);
$host = trim((string)($_POST['h_master_host'] ?? ''));
$port = trim((string)($_POST['h_master_port'] ?? '3306'));
$db = trim((string)($_POST['h_master_db'] ?? 'hos'));
$user = trim((string)($_POST['h_master_user'] ?? ''));
$pass = (string)($_POST['h_master_pass'] ?? '');
$write_user = trim((string)($_POST['h_write_user'] ?? ''));
$write_pass = (string)($_POST['h_write_pass'] ?? '');

if ($port === '' || (int)$port <= 0) {
    $port = '3306';
}
if ($db === '') {
    $db = 'hos';
}
if ($pass === '' || $pass === '********') {
    $pass = (string)($cur['h_master_pass'] ?? '');
}
if ($write_pass === '' || $write_pass === '********') {
    $write_pass = (string)($cur_write['h_write_pass'] ?? '');
}

$values = [
    'h_master_host' => $host,
    'h_master_port' => $port,
    'h_master_db' => $db,
    'h_master_user' => $user,
    'h_master_pass' => $pass,
    'h_write_user' => $write_user,
    'h_write_pass' => $write_pass,
];

foreach ($values as $key => $val) {
    $k = mysqli_real_escape_string($con, $key);
    $v = mysqli_real_escape_string($con, $val);
    $check = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name = '$k'");
    if ($check && mysqli_num_rows($check) > 0) {
        mysqli_query($con, "UPDATE sys_config SET config_value = '$v' WHERE config_name = '$k'");
    } else {
        mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
    }
}

echo json_encode(['status' => 'success', 'message' => 'บันทึกการเชื่อมต่อ HOSxP master แล้ว']);
