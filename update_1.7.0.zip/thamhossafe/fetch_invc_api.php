<?php
/**
 * API เชื่อมต่อ INVC (SQL Server, Read Only)
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();
include(__DIR__ . '/connect.php');
require_once __DIR__ . '/invc_helper.php';
require_once __DIR__ . '/invc_gsheet_helper.php';
mysqli_set_charset($con, 'utf8');

function invc_api_json(array $payload, $code = 200) {
    ob_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    invc_api_json(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], 401);
}

require_once __DIR__ . '/menu_permissions_helper.php';
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.invc') && !tham_menu_can('admin.hosxp')) {
    invc_api_json(['status' => 'error', 'message' => 'ไม่มีสิทธิ์ตั้งค่า INVC'], 403);
}
session_write_close();

invc_ensure_config($con);
$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'get'));

if ($action === 'get') {
    invc_api_json([
        'status' => 'success',
        'config' => invc_public_config(invc_load_config($con)),
        'driver' => invc_driver_status(),
    ]);
}

if ($action === 'save') {
    $cfg = invc_save_config($con, $input);
    invc_api_json([
        'status' => 'success',
        'message' => 'บันทึกการเชื่อมต่อ INVC แล้ว (Read Only)',
        'config' => invc_public_config($cfg),
        'driver' => invc_driver_status(),
    ]);
}

if ($action === 'save_gsheet') {
    if (array_key_exists('invc_gsheet_sa_json', $input)) {
        $saSave = invc_gsheet_save_sa_json($input['invc_gsheet_sa_json']);
        if (empty($saSave['ok'])) {
            invc_api_json([
                'status' => 'error',
                'message' => $saSave['error'] ?? 'บันทึก Service Account ไม่สำเร็จ',
            ]);
        }
    }
    $cfg = invc_save_config($con, $input);
    $sa = invc_gsheet_sa_status();
    $msg = 'บันทึกการเชื่อมต่อ Google Sheet แล้ว';
    if (!empty($sa['configured'])) {
        $msg .= ' · SA: ' . $sa['email'];
    }
    invc_api_json([
        'status' => 'success',
        'message' => $msg,
        'config' => invc_public_config($cfg),
        'sa' => $sa,
    ]);
}

if ($action === 'test_gsheet') {
    $override = [];
    foreach (invc_gsheet_config_keys() as $k) {
        if (isset($input[$k])) {
            $override[$k] = trim((string)$input[$k]);
        }
    }
    if (isset($input['invc_gsheet_sa_json'])) {
        $override['invc_gsheet_sa_json'] = (string)$input['invc_gsheet_sa_json'];
    }
    $ping = invc_gsheet_test($con, $override ?: null);
    $modeLabel = ($ping['mode'] ?? '') === 'service_account' ? 'Service Account' : 'CSV สาธารณะ';
    invc_api_json([
        'status' => $ping['ok'] ? 'success' : 'error',
        'message' => $ping['ok']
            ? ('ดึงสำเร็จ (' . $modeLabel . ') · มีวันที่รับ ' . (int)$ping['row_count'] . ' แถว'
                . (!empty($ping['sheet_title']) ? ' · ชีต “' . $ping['sheet_title'] . '”' : ''))
            : ('ดึง Google Sheet ล้มเหลว: ' . ($ping['error'] ?: 'ไม่ทราบสาเหตุ')),
        'ping' => $ping,
        'sa' => invc_gsheet_sa_status(),
    ]);
}

if ($action === 'test') {
    $override = [];
    foreach (['invc_host', 'invc_port', 'invc_user', 'invc_db'] as $k) {
        if (isset($input[$k])) {
            $override[$k] = trim((string)$input[$k]);
        }
    }
    if (isset($input['invc_pass']) && (string)$input['invc_pass'] !== '' && (string)$input['invc_pass'] !== '********') {
        $override['invc_pass'] = (string)$input['invc_pass'];
    }
    $ping = invc_ping($con, $override ?: null);
    invc_api_json([
        'status' => $ping['ok'] ? 'success' : 'error',
        'message' => $ping['ok']
            ? 'เชื่อมต่อ INVC สำเร็จ (SQL Server · Read Only)'
            : ('เชื่อมต่อล้มเหลว: ' . ($ping['error'] ?: 'ไม่ทราบสาเหตุ')),
        'ping' => $ping,
        'driver' => invc_driver_status(),
    ]);
}

if ($action === 'tables') {
    $pdo = invc_connect($con, 12);
    if (!$pdo) {
        invc_api_json(['status' => 'error', 'message' => invc_last_error() ?: 'เชื่อมต่อ INVC ไม่ได้']);
    }
    $q = trim((string)($input['q'] ?? $_GET['q'] ?? ''));
    $tables = invc_list_tables($pdo, $q, 100);
    invc_close($pdo);
    invc_api_json([
        'status' => 'success',
        'tables' => $tables,
    ]);
}

if ($action === 'preview') {
    $table = trim((string)($input['table'] ?? $_GET['table'] ?? ''));
    $pdo = invc_connect($con, 12);
    if (!$pdo) {
        invc_api_json(['status' => 'error', 'message' => invc_last_error() ?: 'เชื่อมต่อ INVC ไม่ได้']);
    }
    $preview = invc_preview_table($pdo, $table, 20);
    $cols = invc_describe_table($pdo, $table);
    invc_close($pdo);
    invc_api_json([
        'status' => empty($preview['error']) ? 'success' : 'error',
        'message' => $preview['error'] ?: '',
        'table' => $table,
        'columns' => $cols,
        'preview' => $preview,
    ]);
}

invc_api_json(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], 400);
