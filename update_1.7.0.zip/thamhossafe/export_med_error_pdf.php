<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/med_error_helper.php';
mysqli_set_charset($con, 'utf8');
med_error_ensure_tables($con);

function pdf_text($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function pdf_nl($value) {
    $s = trim((string)$value);
    return $s === '' ? '—' : nl2br(pdf_text($s));
}

$start_date = isset($_GET['start_date']) ? trim((string)$_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? trim((string)$_GET['end_date']) : '';
if ($start_date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = '';
}
if ($end_date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = '';
}
if ($start_date !== '' && $end_date !== '' && $start_date > $end_date) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$report_filters = med_error_report_filters_from_request($_GET);
$parts = [];
if ($start_date !== '' && $end_date !== '') {
    $start_esc = mysqli_real_escape_string($con, $start_date);
    $end_esc = mysqli_real_escape_string($con, $end_date);
    $parts[] = "DATE(m.incident_date) BETWEEN '{$start_esc}' AND '{$end_esc}'";
}
$parts = array_merge($parts, med_error_report_filter_sql($con, $report_filters));
$where = $parts ? (' WHERE ' . implode(' AND ', $parts)) : '';

$sql = "SELECT m.id, m.hn, m.patient_name, m.patient_type, m.an, m.vn, m.order_doctor_code, m.order_doctor_name, m.order_doctor_group, m.reporting_dept, m.error_dept, m.error_drugs, m.correct_drugs, m.is_had, m.is_robot, m.rx_type, m.record_kind, m.incident_date, m.created_at, m.error_level, m.description, m.solution,
               m.intervention_module, t.category, t.name AS type_name, u.full_name AS reporter_name
        FROM med_error_records m
        LEFT JOIN med_error_types t ON m.error_type_id = t.id
        LEFT JOIN users u ON m.reporter_id = u.id
        {$where}
        ORDER BY m.incident_date DESC";
$q = mysqli_query($con, $sql);
$rows = [];
if ($q) {
    while ($r = mysqli_fetch_assoc($q)) {
        $rows[] = $r;
    }
}

$range_title = ($start_date !== '' && $end_date !== '')
    ? (date('d/m/Y', strtotime($start_date)) . ' – ' . date('d/m/Y', strtotime($end_date)))
    : 'ทั้งหมด';
$filter_reporter_name = '';
if (!empty($report_filters['reporter_id'])) {
    $rid = (int)$report_filters['reporter_id'];
    $qr = mysqli_query($con, "SELECT full_name FROM users WHERE id = {$rid} LIMIT 1");
    if ($qr && ($rrn = mysqli_fetch_assoc($qr))) {
        $filter_reporter_name = (string)($rrn['full_name'] ?? '');
    }
}
$filter_bits = med_error_report_filter_label($report_filters, $filter_reporter_name);

$total_errors = 0;
$count_near_miss = 0;
$count_reached = 0;
$count_harm = 0;
$cat_counts = [];
foreach ($rows as $r) {
    $total_errors++;
    $kind = med_error_sanitize_record_kind($r['record_kind'] ?? 'error');
    $lvl = strtoupper(trim((string)($r['error_level'] ?? '')));
    if (in_array($lvl, ['A', 'B'], true)) {
        $count_near_miss++;
    } elseif (in_array($lvl, ['C', 'D'], true)) {
        $count_reached++;
    } elseif (in_array($lvl, ['E', 'F', 'G', 'H', 'I'], true)) {
        $count_harm++;
    }
    $cat = trim((string)($r['category'] ?? ''));
    if ($kind === 'consult') {
        $cat = 'Consult';
    } elseif ($cat === '') {
        $cat = 'ไม่ระบุ';
    }
    if (!isset($cat_counts[$cat])) {
        $cat_counts[$cat] = 0;
    }
    $cat_counts[$cat]++;
}
arsort($cat_counts);

$hospital = 'โรงพยาบาล';
if (is_file(__DIR__ . '/amr_amass_helper.php')) {
    require_once __DIR__ . '/amr_amass_helper.php';
    if (function_exists('amr_amass_cover_info')) {
        $cover = amr_amass_cover_info($con);
        if (!empty($cover['hospital_name_th'])) {
            $hospital = $cover['hospital_name_th'];
        } elseif (!empty($cover['hospital_name'])) {
            $hospital = $cover['hospital_name'];
        }
    }
}

$printed_at = date('d/m/Y H:i');
$printed_by = trim((string)($_SESSION['full_name'] ?? ''));
$range_suffix = ($start_date !== '' && $end_date !== '') ? ('_' . $start_date . '_to_' . $end_date) : '';
$doc_title = 'Med_Error_Report' . $range_suffix;
$back_qs = htmlspecialchars(med_error_report_query_string($start_date, $end_date, $report_filters), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title><?php echo pdf_text($doc_title); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        @page { size: A4 landscape; margin: 8mm; }
        * { box-sizing: border-box; }
        body {
            font-family: 'Sarabun', 'TH Sarabun New', Tahoma, sans-serif;
            font-size: 10.5px;
            color: #111;
            background: #fff;
            margin: 0;
            line-height: 1.35;
        }
        .sheet { width: 100%; }
        .no-print { margin-bottom: 10px; }
        .no-print button, .no-print a {
            display: inline-block;
            padding: 7px 14px;
            font-weight: 700;
            font-size: 13px;
            border-radius: 6px;
            text-decoration: none;
            border: 1px solid #cbd5e1;
            background: #fff;
            color: #0f172a;
            cursor: pointer;
            margin-right: 6px;
        }
        .no-print .btn-pdf { background: #dc3545; color: #fff; border-color: #dc3545; }
        .hint { color: #64748b; font-size: 12px; margin-left: 6px; }
        .head {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            border-bottom: 2px solid #b91c1c;
            padding-bottom: 8px;
            margin-bottom: 10px;
        }
        .head h1 { margin: 0; font-size: 18px; font-weight: 800; color: #991b1b; }
        .head .sub { margin-top: 2px; font-size: 12px; font-weight: 700; }
        .head .meta { text-align: right; font-size: 11px; color: #334155; }
        .kpis {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 8px;
        }
        .kpi {
            border: 1px solid #d1d5db;
            border-radius: 6px;
            padding: 6px 8px;
            background: #f8fafc;
        }
        .kpi .l { font-size: 10px; font-weight: 700; color: #64748b; }
        .kpi .n { font-size: 20px; font-weight: 800; line-height: 1.1; }
        .kpi.total .n { color: #b91c1c; }
        .kpi.near .n { color: #15803d; }
        .kpi.reach .n { color: #1d4ed8; }
        .kpi.harm .n { color: #b45309; }
        .cats { margin: 0 0 8px; font-size: 11px; }
        .cats b { margin-right: 4px; }
        table.rep {
            width: 100%;
            border-collapse: collapse;
            font-size: 10px;
        }
        table.rep th, table.rep td {
            border: 1px solid #94a3b8;
            padding: 4px 5px;
            vertical-align: top;
            overflow-wrap: anywhere;
        }
        table.rep th {
            background: #fee2e2;
            text-align: center;
            font-weight: 800;
            white-space: nowrap;
        }
        table.rep td.ctr { text-align: center; white-space: nowrap; }
        table.rep td.num { text-align: center; font-weight: 800; width: 28px; }
        .muted { color: #64748b; }
        .foot { margin-top: 8px; font-size: 10px; color: #64748b; }
        .empty { text-align: center; padding: 24px; color: #64748b; }
        @media print {
            .no-print { display: none !important; }
            body { margin: 0; }
            .kpi, table.rep th { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            a { color: inherit; text-decoration: none; }
        }
        @media screen {
            body { background: #e2e8f0; padding: 16px; }
            .sheet {
                background: #fff;
                box-shadow: 0 1px 8px rgba(0,0,0,.12);
                padding: 12px 14px;
                min-height: 180mm;
            }
        }
    </style>
</head>
<body>
<div class="sheet">
    <div class="no-print">
        <button type="button" class="btn-pdf" onclick="window.print()">พิมพ์ / บันทึก PDF</button>
        <a href="med_error.php?<?php echo $back_qs; ?>">กลับรายงาน</a>
        <span class="hint">เลือกเครื่องพิมพ์เป็น “Save as PDF” หรือ “Microsoft Print to PDF” · กระดาษ A4 แนวนอน</span>
    </div>

    <div class="head">
        <div>
            <h1>รายงานความคลาดเคลื่อนทางยา (Medication Error)</h1>
            <div class="sub"><?php echo pdf_text($hospital); ?> · THAM Hos-Safe</div>
        </div>
        <div class="meta">
            <div><b>ช่วงรายงาน:</b> <?php echo pdf_text($range_title); ?></div>
            <?php if ($filter_bits): ?>
            <div><b>ตัวกรอง:</b> <?php echo pdf_text(implode(' · ', $filter_bits)); ?></div>
            <?php endif; ?>
            <div><b>พิมพ์เมื่อ:</b> <?php echo pdf_text($printed_at); ?><?php echo $printed_by !== '' ? ' · ' . pdf_text($printed_by) : ''; ?></div>
            <div><b>จำนวนรายการ:</b> <?php echo (int)$total_errors; ?></div>
        </div>
    </div>

    <div class="kpis">
        <div class="kpi total"><div class="l">เหตุการณ์ทั้งหมด</div><div class="n"><?php echo (int)$total_errors; ?></div></div>
        <div class="kpi near"><div class="l">Near miss (A–B)</div><div class="n"><?php echo (int)$count_near_miss; ?></div></div>
        <div class="kpi reach"><div class="l">ถึงผู้ป่วย (C–D)</div><div class="n"><?php echo (int)$count_reached; ?></div></div>
        <div class="kpi harm"><div class="l">เกิดอันตราย (E–I)</div><div class="n"><?php echo (int)$count_harm; ?></div></div>
    </div>
    <?php if ($cat_counts): ?>
    <div class="cats">
        <b>ตามหมวดหมู่:</b>
        <?php
        $cat_bits = [];
        foreach ($cat_counts as $cn => $cc) {
            $cat_bits[] = pdf_text($cn) . ' ' . (int)$cc;
        }
        echo implode(' · ', $cat_bits);
        ?>
    </div>
    <?php endif; ?>

    <table class="rep">
        <thead>
            <tr>
                <th>#</th>
                <th>วัน-เวลาเกิดเหตุ</th>
                <th>HN / ผู้ป่วย</th>
                <th>ประเภท</th>
                <th>ระดับ</th>
                <th>ยา / HAD / Robot</th>
                <th>บรรยายเหตุการณ์</th>
                <th>การแก้ไขปัญหา</th>
                <th>ผู้บันทึก</th>
            </tr>
        </thead>
        <tbody>
        <?php if (!$rows): ?>
            <tr><td colspan="9" class="empty">ไม่มีข้อมูลตามตัวกรองที่เลือก</td></tr>
        <?php else: ?>
            <?php $no = 1; foreach ($rows as $r): ?>
            <?php
                $inc_ts = !empty($r['incident_date']) ? strtotime($r['incident_date']) : 0;
                $kind = med_error_sanitize_record_kind($r['record_kind'] ?? 'error');
                $ptype = strtoupper(trim((string)($r['patient_type'] ?? '')));
                $ptype_label = ($ptype === 'IPD') ? 'ผู้ป่วยใน' : (($ptype === 'OPD') ? 'ผู้ป่วยนอก' : '');
                $hn_line = trim((string)($r['hn'] ?? ''));
                $visit_bits = [];
                if (trim((string)($r['an'] ?? '')) !== '') {
                    $visit_bits[] = 'AN ' . $r['an'];
                }
                if (trim((string)($r['vn'] ?? '')) !== '') {
                    $visit_bits[] = 'VN ' . $r['vn'];
                }
                $type_line = trim((string)($r['type_name'] ?? ''));
                $cat_line = $kind === 'consult' ? 'Consult' : trim((string)($r['category'] ?? ''));
                $rx_label = med_error_rx_type_label($r['rx_type'] ?? '');
                $err_drugs = med_error_drugs_list_text(med_error_parse_drugs($r['error_drugs'] ?? '[]'));
                $ok_drugs = med_error_drugs_list_text(med_error_parse_drugs($r['correct_drugs'] ?? '[]'));
                $had = med_error_sanitize_yes_no($r['is_had'] ?? 'NO', 'NO');
                $robot = med_error_sanitize_yes_no($r['is_robot'] ?? 'NO', 'NO');
            ?>
            <tr>
                <td class="num"><?php echo $no++; ?></td>
                <td class="ctr">
                    <?php echo pdf_text($inc_ts ? date('d/m/Y', $inc_ts) : ''); ?><br>
                    <?php echo pdf_text($inc_ts ? date('H:i', $inc_ts) : ''); ?>
                </td>
                <td>
                    <b><?php echo pdf_text($hn_line !== '' ? $hn_line : '—'); ?></b>
                    <?php if ($visit_bits): ?><div class="muted"><?php echo pdf_text(implode(' · ', $visit_bits)); ?></div><?php endif; ?>
                    <div><?php echo pdf_text($r['patient_name'] ?? ''); ?></div>
                    <?php if ($ptype_label !== ''): ?><div class="muted"><?php echo pdf_text($ptype_label); ?></div><?php endif; ?>
                    <?php
                    $doc_line = trim((string)($r['order_doctor_name'] ?? ''));
                    $doc_g = med_error_doctor_group_label($r['order_doctor_group'] ?? '');
                    if ($doc_line !== '' || $doc_g !== ''):
                    ?>
                    <div class="muted">แพทย์ <?php echo pdf_text($doc_line !== '' ? $doc_line : '—'); ?><?php echo $doc_g !== '' ? ' · ' . pdf_text($doc_g) : ''; ?></div>
                    <?php endif; ?>
                    <?php
                    $clinic = trim((string)($r['reporting_dept'] ?? ''));
                    if ($kind === 'consult' && $clinic !== ''):
                    ?>
                    <div class="muted">จุดตรวจ <?php echo pdf_text($clinic); ?></div>
                    <?php endif; ?>
                </td>
                <td>
                    <b><?php echo pdf_text($kind === 'consult' ? 'Consult' : 'ความคลาดเคลื่อนจริง'); ?></b>
                    <?php if ($cat_line !== ''): ?><div><?php echo pdf_text($cat_line); ?></div><?php endif; ?>
                    <?php if ($type_line !== ''): ?><div class="muted"><?php echo pdf_text($type_line); ?></div><?php endif; ?>
                    <?php if ($rx_label !== ''): ?><div class="muted"><?php echo pdf_text($rx_label); ?></div><?php endif; ?>
                </td>
                <td class="ctr"><b><?php echo $kind === 'consult' ? '—' : pdf_text($r['error_level'] ?? ''); ?></b></td>
                <td>
                    <?php if ($kind !== 'consult'): ?>
                    <div><b>Error:</b> <?php echo pdf_text($err_drugs !== '' ? $err_drugs : '—'); ?></div>
                    <div><b>ถูกต้อง:</b> <?php echo pdf_text($ok_drugs !== '' ? $ok_drugs : '—'); ?></div>
                    <div class="muted">HAD <?php echo pdf_text($had); ?> · Robot <?php echo pdf_text($robot); ?></div>
                    <?php else: ?>
                    —
                    <?php endif; ?>
                </td>
                <td><?php echo pdf_nl($r['description'] ?? ''); ?></td>
                <td><?php echo pdf_nl($r['solution'] ?? ''); ?></td>
                <td class="ctr"><?php echo pdf_text($r['reporter_name'] ?? ''); ?></td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    <div class="foot">รายงานนี้ดึงจากระบบ THAM Hos-Safe ตามตัวกรองที่เลือก · ใช้สำหรับบันทึกและทบทวนภายในหน่วยงาน</div>
</div>
<script>
window.addEventListener('load', function () {
    setTimeout(function () { window.print(); }, 350);
});
</script>
</body>
</html>
