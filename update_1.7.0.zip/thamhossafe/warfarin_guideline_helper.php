<?php
/**
 * Warfarin INR dose-adjustment guidelines (editable via settings)
 */

function wf_guideline_config_key() {
    return 'warfarin_guidelines';
}

function wf_hn_key($hn) {
    $hn = trim((string)$hn);
    $key = ltrim($hn, '0');
    return $key === '' ? '0' : $key;
}

/** สร้างตารางจำค่า Target INR / คำแนะนำ ตาม HN */
function wf_hn_pref_ensure_table($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $sql = "CREATE TABLE IF NOT EXISTS warfarin_hn_pref (
        hn_key VARCHAR(20) NOT NULL COMMENT 'HN ตัด 0 นำหน้า',
        hn VARCHAR(20) NOT NULL,
        protocol_id VARCHAR(64) NOT NULL DEFAULT 'inr_2_3',
        guide_note TEXT NULL COMMENT 'คำแนะนำที่ user ปรับเอง (ว่าง=ใช้จาก guideline)',
        updated_by INT NULL,
        updated_by_name VARCHAR(255) NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (hn_key),
        KEY idx_hn (hn),
        KEY idx_updated (updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8";
    $ok = @mysqli_query($con, $sql);
    $ready = (bool)$ok;
    return $ready;
}

function wf_hn_pref_get($con, $hn) {
    wf_hn_pref_ensure_table($con);
    $key = mysqli_real_escape_string($con, wf_hn_key($hn));
    $q = mysqli_query($con, "SELECT hn, hn_key, protocol_id, guide_note, updated_at, updated_by_name
        FROM warfarin_hn_pref WHERE hn_key = '$key' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $pid = trim((string)($r['protocol_id'] ?? ''));
        if ($pid === '') {
            $pid = 'inr_2_3';
        }
        return [
            'hn' => $r['hn'],
            'hn_key' => $r['hn_key'],
            'protocol_id' => $pid,
            'guide_note' => $r['guide_note'],
            'updated_at' => $r['updated_at'] ?? null,
            'updated_by_name' => $r['updated_by_name'] ?? null,
            'exists' => true,
        ];
    }
    return [
        'hn' => trim((string)$hn),
        'hn_key' => wf_hn_key($hn),
        'protocol_id' => 'inr_2_3',
        'guide_note' => null,
        'updated_at' => null,
        'updated_by_name' => null,
        'exists' => false,
    ];
}

function wf_hn_pref_save($con, $hn, array $fields) {
    wf_hn_pref_ensure_table($con);
    $hn = trim((string)$hn);
    if ($hn === '') {
        return ['ok' => false, 'error' => 'ไม่มี HN'];
    }
    $hn_key = wf_hn_key($hn);
    $existing = wf_hn_pref_get($con, $hn);

    $protocol_id = array_key_exists('protocol_id', $fields)
        ? trim((string)$fields['protocol_id'])
        : ($existing['protocol_id'] ?? 'inr_2_3');
    if ($protocol_id === '') {
        $protocol_id = 'inr_2_3';
    }

    if (array_key_exists('guide_note', $fields)) {
        $note = $fields['guide_note'];
        if ($note === null) {
            $guide_note_sql = 'NULL';
        } else {
            $guide_note_sql = "'" . mysqli_real_escape_string($con, (string)$note) . "'";
        }
    } else {
        if ($existing['guide_note'] === null) {
            $guide_note_sql = 'NULL';
        } else {
            $guide_note_sql = "'" . mysqli_real_escape_string($con, (string)$existing['guide_note']) . "'";
        }
    }

    $uid = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 'NULL';
    $uname = isset($_SESSION['full_name'])
        ? ("'" . mysqli_real_escape_string($con, (string)$_SESSION['full_name']) . "'")
        : 'NULL';
    $hn_esc = mysqli_real_escape_string($con, $hn);
    $key_esc = mysqli_real_escape_string($con, $hn_key);
    $pid_esc = mysqli_real_escape_string($con, $protocol_id);

    $sql = "INSERT INTO warfarin_hn_pref (hn_key, hn, protocol_id, guide_note, updated_by, updated_by_name)
        VALUES ('$key_esc', '$hn_esc', '$pid_esc', $guide_note_sql, $uid, $uname)
        ON DUPLICATE KEY UPDATE
            hn = VALUES(hn),
            protocol_id = VALUES(protocol_id),
            guide_note = VALUES(guide_note),
            updated_by = VALUES(updated_by),
            updated_by_name = VALUES(updated_by_name)";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con) ?: 'บันทึกไม่สำเร็จ'];
    }
    return ['ok' => true, 'data' => wf_hn_pref_get($con, $hn)];
}

/** ค่าเริ่มต้นตามแนวทาง Target INR 2.0–3.0 และ 2.5–3.5 */
function wf_guideline_defaults() {
    return [
        'protocols' => [
            [
                'id' => 'inr_2_3',
                'name' => 'Target INR 2.0 - 3.0',
                'indication' => 'ข้อบ่งใช้ทั่วไป: Atrial Fibrillation, DVT, PE, Bioprosthetic heart valve',
                'target_low' => 2.0,
                'target_high' => 3.0,
                'rows' => [
                    [
                        'inr_label' => '< 1.5',
                        'inr_min' => null,
                        'inr_max' => 1.5,
                        'inr_max_exclusive' => true,
                        'direction' => 'up',
                        'pct_min' => 10,
                        'pct_max' => 20,
                        'default_pct' => 15,
                        'hold_doses_min' => 0,
                        'hold_doses_max' => 0,
                        'extra_dose' => true,
                        'vitamin_k' => '',
                        'note' => 'เพิ่ม TWD 10-20% (อาจพิจารณาให้ Extra dose 1 มื้อ ร่วมด้วย)',
                    ],
                    [
                        'inr_label' => '1.5 - 1.9',
                        'inr_min' => 1.5,
                        'inr_max' => 1.9,
                        'inr_max_exclusive' => false,
                        'direction' => 'up',
                        'pct_min' => 5,
                        'pct_max' => 10,
                        'default_pct' => 10,
                        'hold_doses_min' => 0,
                        'hold_doses_max' => 0,
                        'extra_dose' => false,
                        'vitamin_k' => '',
                        'note' => 'เพิ่ม TWD 5-10%',
                    ],
                    [
                        'inr_label' => '2.0 - 3.0',
                        'inr_min' => 2.0,
                        'inr_max' => 3.0,
                        'inr_max_exclusive' => false,
                        'direction' => 'hold',
                        'pct_min' => 0,
                        'pct_max' => 0,
                        'default_pct' => 0,
                        'hold_doses_min' => 0,
                        'hold_doses_max' => 0,
                        'extra_dose' => false,
                        'vitamin_k' => '',
                        'note' => 'เป้าหมาย: คงขนาดยาเดิม (นัดติดตามใน 1-4 สัปดาห์)',
                    ],
                    [
                        'inr_label' => '3.1 - 3.9',
                        'inr_min' => 3.1,
                        'inr_max' => 3.9,
                        'inr_max_exclusive' => false,
                        'direction' => 'down',
                        'pct_min' => 5,
                        'pct_max' => 10,
                        'default_pct' => 10,
                        'hold_doses_min' => 0,
                        'hold_doses_max' => 0,
                        'extra_dose' => false,
                        'vitamin_k' => '',
                        'note' => 'ลด TWD 5-10%',
                    ],
                    [
                        'inr_label' => '4.0 - 4.9',
                        'inr_min' => 4.0,
                        'inr_max' => 4.9,
                        'inr_max_exclusive' => false,
                        'direction' => 'down',
                        'pct_min' => 10,
                        'pct_max' => 10,
                        'default_pct' => 10,
                        'hold_doses_min' => 0,
                        'hold_doses_max' => 1,
                        'extra_dose' => false,
                        'vitamin_k' => '',
                        'note' => 'งดทานยา 0-1 มื้อ และ ลด TWD 10%',
                    ],
                    [
                        'inr_label' => '5.0 - 8.9',
                        'inr_min' => 5.0,
                        'inr_max' => 8.9,
                        'inr_max_exclusive' => false,
                        'direction' => 'down',
                        'pct_min' => 10,
                        'pct_max' => 20,
                        'default_pct' => 15,
                        'hold_doses_min' => 1,
                        'hold_doses_max' => 2,
                        'extra_dose' => false,
                        'vitamin_k' => 'หากมีความเสี่ยงเลือดออกสูง อาจพิจารณา Vitamin K 1-2.5 mg รับประทาน',
                        'note' => 'งดทานยา 1-2 มื้อ และ ลด TWD 10-20%',
                    ],
                    [
                        'inr_label' => '≥ 9.0',
                        'inr_min' => 9.0,
                        'inr_max' => null,
                        'inr_max_exclusive' => false,
                        'direction' => 'down',
                        'pct_min' => 0,
                        'pct_max' => 0,
                        'default_pct' => 0,
                        'hold_doses_min' => 1,
                        'hold_doses_max' => 99,
                        'extra_dose' => false,
                        'vitamin_k' => 'Vitamin K 2.5-5 mg รับประทาน นัดเจาะเลือดติดตามใกล้ชิด',
                        'note' => 'งดทานยา และให้ Vitamin K 2.5-5 mg รับประทาน นัดเจาะเลือดติดตามใกล้ชิด',
                    ],
                ],
            ],
            [
                'id' => 'inr_2_5_3_5',
                'name' => 'Target INR 2.5 - 3.5',
                'indication' => 'ข้อบ่งใช้: Mechanical heart valve ที่ตำแหน่ง Mitral valve หรือมีประวัติ Thromboembolism ขณะที่ INR อยู่ในเกณฑ์ 2.0-3.0',
                'target_low' => 2.5,
                'target_high' => 3.5,
                'rows' => [
                    [
                        'inr_label' => '< 1.5',
                        'inr_min' => null,
                        'inr_max' => 1.5,
                        'inr_max_exclusive' => true,
                        'direction' => 'up',
                        'pct_min' => 10,
                        'pct_max' => 20,
                        'default_pct' => 15,
                        'hold_doses_min' => 0,
                        'hold_doses_max' => 0,
                        'extra_dose' => false,
                        'vitamin_k' => '',
                        'note' => 'เพิ่ม TWD 10-20% (และพิจารณา Bridging therapy ด้วย LMWH/UFH)',
                    ],
                    [
                        'inr_label' => '1.5 - 2.4',
                        'inr_min' => 1.5,
                        'inr_max' => 2.4,
                        'inr_max_exclusive' => false,
                        'direction' => 'up',
                        'pct_min' => 5,
                        'pct_max' => 10,
                        'default_pct' => 10,
                        'hold_doses_min' => 0,
                        'hold_doses_max' => 0,
                        'extra_dose' => false,
                        'vitamin_k' => '',
                        'note' => 'เพิ่ม TWD 5-10%',
                    ],
                    [
                        'inr_label' => '2.5 - 3.5',
                        'inr_min' => 2.5,
                        'inr_max' => 3.5,
                        'inr_max_exclusive' => false,
                        'direction' => 'hold',
                        'pct_min' => 0,
                        'pct_max' => 0,
                        'default_pct' => 0,
                        'hold_doses_min' => 0,
                        'hold_doses_max' => 0,
                        'extra_dose' => false,
                        'vitamin_k' => '',
                        'note' => 'เป้าหมาย: คงขนาดยาเดิม (นัดติดตามใน 1-4 สัปดาห์)',
                    ],
                    [
                        'inr_label' => '3.6 - 4.4',
                        'inr_min' => 3.6,
                        'inr_max' => 4.4,
                        'inr_max_exclusive' => false,
                        'direction' => 'down',
                        'pct_min' => 5,
                        'pct_max' => 10,
                        'default_pct' => 10,
                        'hold_doses_min' => 0,
                        'hold_doses_max' => 0,
                        'extra_dose' => false,
                        'vitamin_k' => '',
                        'note' => 'ลด TWD 5-10%',
                    ],
                    [
                        'inr_label' => '4.5 - 5.9',
                        'inr_min' => 4.5,
                        'inr_max' => 5.9,
                        'inr_max_exclusive' => false,
                        'direction' => 'down',
                        'pct_min' => 10,
                        'pct_max' => 10,
                        'default_pct' => 10,
                        'hold_doses_min' => 0,
                        'hold_doses_max' => 1,
                        'extra_dose' => false,
                        'vitamin_k' => '',
                        'note' => 'งดทานยา 0-1 มื้อ และ ลด TWD 10%',
                    ],
                    [
                        'inr_label' => '6.0 - 8.9',
                        'inr_min' => 6.0,
                        'inr_max' => 8.9,
                        'inr_max_exclusive' => false,
                        'direction' => 'down',
                        'pct_min' => 10,
                        'pct_max' => 20,
                        'default_pct' => 15,
                        'hold_doses_min' => 1,
                        'hold_doses_max' => 2,
                        'extra_dose' => false,
                        'vitamin_k' => 'หากมีความเสี่ยงเลือดออกสูง อาจพิจารณา Vitamin K 1-2.5 mg รับประทาน',
                        'note' => 'งดทานยา 1-2 มื้อ และ ลด TWD 10-20%',
                    ],
                    [
                        'inr_label' => '≥ 9.0',
                        'inr_min' => 9.0,
                        'inr_max' => null,
                        'inr_max_exclusive' => false,
                        'direction' => 'down',
                        'pct_min' => 0,
                        'pct_max' => 0,
                        'default_pct' => 0,
                        'hold_doses_min' => 1,
                        'hold_doses_max' => 99,
                        'extra_dose' => false,
                        'vitamin_k' => 'Vitamin K 2.5-5 mg รับประทาน นัดเจาะเลือดติดตามใกล้ชิด',
                        'note' => 'งดทานยา และให้ Vitamin K 2.5-5 mg รับประทาน นัดเจาะเลือดติดตามใกล้ชิด',
                    ],
                ],
            ],
        ],
    ];
}

function wf_guideline_normalize_row(array $row) {
    $dir = strtolower(trim((string)($row['direction'] ?? 'hold')));
    if (!in_array($dir, ['up', 'down', 'hold'], true)) {
        $dir = 'hold';
    }
    $pct_min = (float)($row['pct_min'] ?? 0);
    $pct_max = (float)($row['pct_max'] ?? $pct_min);
    if ($pct_max < $pct_min) {
        $tmp = $pct_min;
        $pct_min = $pct_max;
        $pct_max = $tmp;
    }
    $default = isset($row['default_pct']) ? (float)$row['default_pct'] : (($pct_min + $pct_max) / 2);
    if ($dir === 'hold') {
        $pct_min = 0;
        $pct_max = 0;
        $default = 0;
    }
    $inr_min = array_key_exists('inr_min', $row) && $row['inr_min'] !== '' && $row['inr_min'] !== null
        ? (float)$row['inr_min'] : null;
    $inr_max = array_key_exists('inr_max', $row) && $row['inr_max'] !== '' && $row['inr_max'] !== null
        ? (float)$row['inr_max'] : null;

    return [
        'inr_label' => trim((string)($row['inr_label'] ?? '')),
        'inr_min' => $inr_min,
        'inr_max' => $inr_max,
        'inr_max_exclusive' => !empty($row['inr_max_exclusive']),
        'direction' => $dir,
        'pct_min' => $pct_min,
        'pct_max' => $pct_max,
        'default_pct' => $default,
        'hold_doses_min' => (int)($row['hold_doses_min'] ?? 0),
        'hold_doses_max' => (int)($row['hold_doses_max'] ?? 0),
        'extra_dose' => !empty($row['extra_dose']),
        'vitamin_k' => trim((string)($row['vitamin_k'] ?? '')),
        'note' => trim((string)($row['note'] ?? '')),
    ];
}

function wf_guideline_normalize(array $data) {
    $defaults = wf_guideline_defaults();
    $protocols = [];
    $src = $data['protocols'] ?? $defaults['protocols'];
    if (!is_array($src)) {
        $src = $defaults['protocols'];
    }
    foreach ($src as $i => $p) {
        if (!is_array($p)) {
            continue;
        }
        $id = trim((string)($p['id'] ?? ('protocol_' . ($i + 1))));
        if ($id === '') {
            $id = 'protocol_' . ($i + 1);
        }
        $rows = [];
        foreach (($p['rows'] ?? []) as $row) {
            if (is_array($row)) {
                $rows[] = wf_guideline_normalize_row($row);
            }
        }
        $protocols[] = [
            'id' => $id,
            'name' => trim((string)($p['name'] ?? $id)),
            'indication' => trim((string)($p['indication'] ?? '')),
            'target_low' => (float)($p['target_low'] ?? 0),
            'target_high' => (float)($p['target_high'] ?? 0),
            'rows' => $rows,
        ];
    }
    if (empty($protocols)) {
        return $defaults;
    }
    return ['protocols' => $protocols];
}

function wf_guideline_load($con) {
    $key = mysqli_real_escape_string($con, wf_guideline_config_key());
    $q = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = '$key' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $raw = trim((string)($r['config_value'] ?? ''));
        if ($raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                return wf_guideline_normalize($decoded);
            }
        }
    }
    return wf_guideline_defaults();
}

function wf_guideline_save($con, array $data) {
    $normalized = wf_guideline_normalize($data);
    $json = json_encode($normalized, JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return ['ok' => false, 'error' => 'แปลง JSON ไม่สำเร็จ'];
    }
    $key = mysqli_real_escape_string($con, wf_guideline_config_key());
    $val = mysqli_real_escape_string($con, $json);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name = '$key' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        $ok = mysqli_query($con, "UPDATE sys_config SET config_value = '$val' WHERE config_name = '$key'");
    } else {
        $ok = mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$key', '$val')");
    }
    if (!$ok) {
        return ['ok' => false, 'error' => mysqli_error($con) ?: 'บันทึกไม่สำเร็จ'];
    }
    return ['ok' => true, 'data' => $normalized];
}

function wf_guideline_row_matches(array $row, $inr) {
    $inr = (float)$inr;
    $min = $row['inr_min'];
    $max = $row['inr_max'];
    $maxEx = !empty($row['inr_max_exclusive']);

    if ($min !== null && $inr < (float)$min - 1e-9) {
        return false;
    }
    if ($max !== null) {
        if ($maxEx) {
            if ($inr >= (float)$max - 1e-9) {
                return false;
            }
        } else {
            if ($inr > (float)$max + 1e-9) {
                return false;
            }
        }
    }
    if ($min === null && $max === null) {
        return false;
    }
    return true;
}

/**
 * ปัด INR ตามหลักคณิตศาสตร์เป็น 1 ทศนิยม ก่อนจับคู่ guideline
 * เช่น 1.98 → 2.0, 1.94 → 1.9
 */
function wf_guideline_round_inr($inr) {
    if ($inr === null || $inr === '' || !is_numeric($inr)) {
        return null;
    }
    return round((float)$inr, 1);
}

function wf_guideline_find_protocol(array $guidelines, $protocolId) {
    foreach ($guidelines['protocols'] as $p) {
        if (($p['id'] ?? '') === $protocolId) {
            return $p;
        }
    }
    return $guidelines['protocols'][0] ?? null;
}

/**
 * จับคู่ INR กับแถว guideline
 * @return array{ok:bool,protocol?:array,row?:array,suggest?:array,error?:string,inr_raw?:float,inr?:float}
 */
function wf_guideline_match($con, $inr, $protocolId = 'inr_2_3') {
    if ($inr === null || $inr === '' || !is_numeric($inr)) {
        return ['ok' => false, 'error' => 'ไม่มีค่า INR'];
    }
    $inrRaw = (float)$inr;
    $inr = wf_guideline_round_inr($inrRaw);
    $guidelines = wf_guideline_load($con);
    $protocol = wf_guideline_find_protocol($guidelines, $protocolId);
    if (!$protocol) {
        return ['ok' => false, 'error' => 'ไม่พบแนวทางที่เลือก'];
    }
    $matched = null;
    foreach ($protocol['rows'] as $row) {
        if (wf_guideline_row_matches($row, $inr)) {
            $matched = $row;
            break;
        }
    }
    if (!$matched) {
        return [
            'ok' => false,
            'protocol' => $protocol,
            'inr_raw' => $inrRaw,
            'inr' => $inr,
            'error' => 'ไม่พบแถว guideline ที่ตรงกับ INR ' . $inrRaw .
                ($inr !== $inrRaw ? ' (ปัดเป็น ' . $inr . ')' : ''),
        ];
    }

    $dir = $matched['direction'];
    $pct = (float)$matched['default_pct'];
    if ($dir === 'hold') {
        $pct = 0;
    }

    $holdText = '';
    $hMin = (int)$matched['hold_doses_min'];
    $hMax = (int)$matched['hold_doses_max'];
    if ($hMax > 0) {
        if ($hMin === $hMax) {
            $holdText = 'งดทานยา ' . $hMin . ' มื้อ';
        } elseif ($hMax >= 99) {
            $holdText = 'งดทานยา';
        } else {
            $holdText = 'งดทานยา ' . $hMin . '-' . $hMax . ' มื้อ';
        }
    }

    $pctText = '';
    if ($dir === 'hold') {
        $pctText = 'คงขนาดยาเดิม';
    } elseif ($dir === 'up') {
        $pctText = 'เพิ่ม TWD ' . $matched['pct_min'] . ($matched['pct_max'] != $matched['pct_min'] ? '-' . $matched['pct_max'] : '') . '%';
    } else {
        $pctText = 'ลด TWD ' . $matched['pct_min'] . ($matched['pct_max'] != $matched['pct_min'] ? '-' . $matched['pct_max'] : '') . '%';
    }

    return [
        'ok' => true,
        'protocol' => [
            'id' => $protocol['id'],
            'name' => $protocol['name'],
            'indication' => $protocol['indication'],
            'target_low' => $protocol['target_low'],
            'target_high' => $protocol['target_high'],
        ],
        'row' => $matched,
        'inr_raw' => $inrRaw,
        'inr' => $inr,
        'suggest' => [
            'direction' => $dir === 'hold' ? 'hold' : $dir,
            'pct' => $pct,
            'pct_min' => (float)$matched['pct_min'],
            'pct_max' => (float)$matched['pct_max'],
            'hold_text' => $holdText,
            'pct_text' => $pctText,
            'extra_dose' => !empty($matched['extra_dose']),
            'vitamin_k' => $matched['vitamin_k'],
            'note' => $matched['note'],
            'summary' => trim($matched['note'] . ($matched['vitamin_k'] !== '' ? ' — ' . $matched['vitamin_k'] : '')),
            'in_target' => ($dir === 'hold'),
        ],
    ];
}
