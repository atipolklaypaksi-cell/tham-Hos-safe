<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/monitor_drug_interaction_consult_helper.php';
mysqli_set_charset($con, 'utf8');
mdi_ensure_tables($con);

function di_consult_esc($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function di_consult_req($key) {
    $src = $_POST + $_GET;
    return trim((string)($src[$key] ?? ''));
}

$ids = [];
if (!empty($_GET['ids'])) {
    foreach (preg_split('/[,\s]+/', (string)$_GET['ids']) as $p) {
        $n = (int)$p;
        if ($n > 0) {
            $ids[$n] = true;
        }
    }
}
$id_one = (int)($_GET['id'] ?? 0);
if ($id_one > 0) {
    $ids[$id_one] = true;
}
$ids = array_keys($ids);

$rows = [];
foreach ($ids as $id) {
    $row = mdi_get_consult($con, $id);
    if ($row) {
        mdi_mark_printed($con, $id);
        $rows[] = mdi_format_consult_row($row);
    }
}

if (empty($rows) && di_consult_req('hn') !== '' && di_consult_req('ptname') !== '') {
    $rows[] = [
        'hn' => di_consult_req('hn'),
        'ptname' => di_consult_req('ptname'),
        'vn' => di_consult_req('vn'),
        'vstdate' => di_consult_req('vstdate'),
        'alert_level' => strtolower(di_consult_req('alert_level')) === 'hard' ? 'hard' : 'soft',
        'detail_text' => di_consult_req('detail_text'),
        'check_mode_label' => di_consult_req('check_mode_label'),
        'interaction_type' => di_consult_req('interaction_type'),
        'consult_note' => '',
        'pharmacist_name' => trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? '')),
        'drug1_name' => di_consult_req('drug1_name'),
        'drug2_name' => di_consult_req('drug2_name'),
        'drug1_method' => di_consult_req('drug1_method'),
        'drug2_method' => di_consult_req('drug2_method'),
        'dose1_qty' => di_consult_req('dose1_qty'),
        'dose2_qty' => di_consult_req('dose2_qty'),
        'drug1_date' => di_consult_req('drug1_date'),
        'drug2_date' => di_consult_req('drug2_date'),
        'drug1_time' => di_consult_req('drug1_time'),
        'drug2_time' => di_consult_req('drug2_time'),
        'drug1_daily_mg' => di_consult_req('drug1_daily_mg'),
        'drug2_daily_mg' => di_consult_req('drug2_daily_mg'),
        'drug1_coverage_days' => di_consult_req('drug1_coverage_days'),
        'drug2_coverage_days' => di_consult_req('drug2_coverage_days'),
        'drug1_coverage_end' => di_consult_req('drug1_coverage_end'),
        'drug2_coverage_end' => di_consult_req('drug2_coverage_end'),
        'status' => 'waiting',
        'reply_wait_days' => 0,
        'reply_due_at' => '',
    ];
}

if (empty($rows)) {
    die('ไม่พบใบปรึกษา — กรุณาเริ่ม Consult จากหน้า Monitor Interaction ก่อน');
}

$primary = $rows[0];
$hn = (string)($primary['hn'] ?? '');
$ptname = (string)($primary['ptname'] ?? '');
$vn = (string)($primary['vn'] ?? '');
$vstdate = (string)($primary['vstdate'] ?? '');
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $vstdate)) {
    $vstdate = date('d/m/Y', strtotime($vstdate));
}
$alert_level = strtolower((string)($primary['alert_level'] ?? 'soft')) === 'hard' ? 'hard' : 'soft';
$detail = (string)($primary['detail_text'] ?? '');
$check_lbl = (string)($primary['check_mode_label'] ?? '');
$itype = (string)($primary['interaction_type'] ?? '');
$type_label = [
    'drug_drug' => 'Drug–Drug Interaction',
    'drug_food' => 'Drug–Food Interaction',
    'drug_disease' => 'Drug–Disease Interaction',
    'other' => 'ปฏิกิริยาระหว่างยา',
];
$topic = $type_label[$itype] ?? 'ปฏิกิริยาระหว่างยา (Drug Interaction)';

$drugs = [];
foreach ($rows as $r) {
    $drugs[] = [
        'name' => (string)($r['drug1_name'] ?? ''),
        'date' => (string)($r['drug1_date'] ?? ''),
        'time' => (string)($r['drug1_time'] ?? ''),
        'qty' => (string)($r['dose1_qty'] ?? ''),
        'method' => (string)($r['drug1_method'] ?? ''),
        'daily_mg' => (string)($r['drug1_daily_mg'] ?? ''),
        'coverage' => (string)($r['drug1_coverage_days'] ?? ''),
        'coverage_end' => (string)($r['drug1_coverage_end'] ?? ''),
    ];
    $drugs[] = [
        'name' => (string)($r['drug2_name'] ?? ''),
        'date' => (string)($r['drug2_date'] ?? ''),
        'time' => (string)($r['drug2_time'] ?? ''),
        'qty' => (string)($r['dose2_qty'] ?? ''),
        'method' => (string)($r['drug2_method'] ?? ''),
        'daily_mg' => (string)($r['drug2_daily_mg'] ?? ''),
        'coverage' => (string)($r['drug2_coverage_days'] ?? ''),
        'coverage_end' => (string)($r['drug2_coverage_end'] ?? ''),
    ];
}

$hospital = 'โรงพยาบาล';
if (is_file(__DIR__ . '/amr_amass_helper.php')) {
    require_once __DIR__ . '/amr_amass_helper.php';
    if (function_exists('amr_amass_cover_info')) {
        $cover = amr_amass_cover_info($con);
        if (!empty($cover['hospital_name_th'])) {
            $hospital = $cover['hospital_name_th'];
        } elseif (!empty($cover['hospital_name'])) {
            $hospital = $cover['hospital_name'];
        }
    }
}

$pharm_name = '';
foreach ($rows as $r) {
    if (trim((string)($r['pharmacist_name'] ?? '')) !== '') {
        $pharm_name = $r['pharmacist_name'];
        break;
    }
}
if ($pharm_name === '') {
    $pharm_name = trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? ''));
}
$print_date = date('d/m/Y H:i');
$autoprint = di_consult_req('autoprint') === '1';
$note = '';
foreach ($rows as $r) {
    if (trim((string)($r['consult_note'] ?? '')) !== '') {
        $note = $r['consult_note'];
        break;
    }
}
$outcome = mdi_parse_consult_outcome($note);
$note_display = $outcome['key'] === 'other' ? '' : $outcome['extra'];
if ($outcome['key'] === '' && $outcome['extra'] === '' && $note !== '') {
    $note_display = $note;
}
$reply_wait = (int)($primary['reply_wait_days'] ?? 0);
$reply_due = '';
foreach ($rows as $r) {
    if (($r['status'] ?? '') === 'in_progress' && !empty($r['reply_due_at'])) {
        $reply_due = $r['reply_due_at'];
        $reply_wait = (int)$r['reply_wait_days'];
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ใบปรึกษาแพทย์ — Drug Interaction</title>
    <style>
        @page { size: A4 portrait; margin: 10mm 12mm; }
        * { box-sizing: border-box; }
        body {
            font-family: 'Sarabun', Tahoma, sans-serif;
            font-size: 11.5px;
            color: #111;
            background: #fff;
            margin: 0;
            line-height: 1.35;
        }
        .sheet { width: 100%; max-width: 190mm; margin: 0 auto; padding: 8px 4px; }
        .print-header {
            border-bottom: 2px solid #b91c1c;
            margin-bottom: 8px;
            padding-bottom: 6px;
            text-align: center;
        }
        .print-header .brand { font-size: 11px; color: #64748b; }
        .print-header h1 {
            margin: 2px 0;
            font-size: 18px;
            font-weight: 800;
            color: #991b1b;
        }
        .print-header .sub { font-size: 12px; font-weight: 700; }
        .print-header .meta { font-size: 10.5px; margin-top: 2px; }
        .badge-st {
            display: inline-block;
            border-radius: 3px;
            padding: 1px 6px;
            font-size: 10px;
            font-weight: 800;
            color: #fff;
            background: <?php echo $alert_level === 'hard' ? '#dc2626' : '#d97706'; ?>;
        }
        .info-grid { width: 100%; border-collapse: collapse; margin-bottom: 6px; }
        .info-grid td { padding: 2px 4px; vertical-align: top; }
        .info-grid .lbl { font-weight: 700; width: 88px; color: #334155; white-space: nowrap; }
        .drug-table { width: 100%; border-collapse: collapse; margin: 6px 0 8px; font-size: 11px; }
        .drug-table th, .drug-table td {
            border: 1px solid #334155;
            padding: 4px 5px;
            vertical-align: top;
        }
        .drug-table th { background: #fef2f2; text-align: center; font-weight: 700; }
        .drug-table td.num { text-align: center; white-space: nowrap; }
        .box {
            border: 1px solid #334155;
            border-radius: 4px;
            padding: 6px 8px;
            margin-top: 6px;
        }
        .box-title { font-weight: 700; margin-bottom: 3px; color: #991b1b; font-size: 11.5px; }
        .doctor-box { min-height: 72px; }
        .doctor-lines { margin-top: 8px; }
        .doctor-lines div {
            border-bottom: 1px dotted #64748b;
            height: 18px;
            margin-top: 2px;
        }
        .sign-row {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            margin-top: 14px;
        }
        .sign-box { flex: 1; text-align: center; font-size: 11px; }
        .sign-line { margin-top: 28px; border-top: 1px solid #333; padding-top: 4px; }
        .hint { font-size: 10px; color: #475569; }
        .toolbar { margin-bottom: 10px; }
        .toolbar a, .toolbar button {
            font-family: inherit;
            font-size: 12px;
            padding: 4px 10px;
            margin-right: 6px;
            border: 1px solid #64748b;
            background: #fff;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            color: #111;
        }
        @media print {
            .no-print { display: none !important; }
            body { margin: 0; }
            .sheet { padding: 0; max-width: none; }
            a { color: inherit; text-decoration: none; }
        }
        @media screen {
            body { background: #e2e8f0; padding: 16px; }
            .sheet {
                background: #fff;
                padding: 16px 18px 22px;
                box-shadow: 0 8px 24px rgba(15, 23, 42, .12);
            }
        }
    </style>
</head>
<body>
<div class="sheet">
    <div class="toolbar no-print">
        <button type="button" onclick="window.print()">พิมพ์</button>
        <a href="monitor_drug_interaction.php">กลับ Monitor Interaction</a>
        <span class="hint" style="margin-left:12px;">แนะนำ: กระดาษ A4 · แนวตั้ง · ขนาด 100%</span>
    </div>

    <div class="print-header">
        <div class="brand"><?php echo di_consult_esc($hospital); ?> · THAM Hos-Safe · Monitor Drug Interaction</div>
        <h1>ใบปรึกษาแพทย์</h1>
        <div class="sub">เรื่อง <?php echo di_consult_esc($topic); ?></div>
        <div class="meta">
            ระดับ: <span class="badge-st"><?php echo $alert_level === 'hard' ? 'Hard Alert' : 'Soft Alert'; ?></span>
            · วันที่พิมพ์ <?php echo di_consult_esc($print_date); ?>
            <?php if ($reply_wait > 0): ?>
            · รอตอบกลับ <?php echo (int)$reply_wait; ?> วัน<?php echo $reply_due !== '' ? ' (' . di_consult_esc($reply_due) . ')' : ''; ?>
            <?php endif; ?>
        </div>
    </div>

    <table class="info-grid">
        <tr>
            <td class="lbl">HN</td>
            <td><strong><?php echo di_consult_esc($hn); ?></strong></td>
            <td class="lbl">VN / AN</td>
            <td><?php echo di_consult_esc($vn !== '' ? $vn : '-'); ?></td>
        </tr>
        <tr>
            <td class="lbl">ชื่อผู้ป่วย</td>
            <td colspan="3"><?php echo di_consult_esc($ptname); ?></td>
        </tr>
        <tr>
            <td class="lbl">วันที่พบคู่ยา</td>
            <td><?php echo di_consult_esc($vstdate !== '' ? $vstdate : '-'); ?></td>
            <td class="lbl">เภสัชกร</td>
            <td><strong><?php echo di_consult_esc($pharm_name !== '' ? $pharm_name : '-'); ?></strong></td>
        </tr>
    </table>

    <table class="drug-table">
        <thead>
            <tr>
                <th style="width:28px;">#</th>
                <th>ยา</th>
                <th>วิธีใช้</th>
                <th style="width:48px;">qty</th>
                <th style="width:92px;">วันที่สั่ง</th>
                <th style="width:88px;">ครอบคลุม</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($drugs as $i => $d): ?>
            <tr>
                <td class="num"><?php echo $i + 1; ?></td>
                <td>
                    <strong><?php echo di_consult_esc($d['name'] !== '' ? $d['name'] : '—'); ?></strong>
                    <?php if ($d['daily_mg'] !== ''): ?>
                    <div class="hint"><?php echo di_consult_esc($d['daily_mg']); ?></div>
                    <?php endif; ?>
                </td>
                <td><?php echo di_consult_esc($d['method'] !== '' ? $d['method'] : '—'); ?></td>
                <td class="num"><?php echo di_consult_esc($d['qty'] !== '' ? $d['qty'] : '—'); ?></td>
                <td class="num">
                    <?php echo di_consult_esc($d['date'] !== '' ? $d['date'] : '—'); ?>
                    <?php if ($d['time'] !== ''): ?>
                    <div class="hint"><?php echo di_consult_esc($d['time']); ?> น.</div>
                    <?php endif; ?>
                </td>
                <td class="num">
                    <?php echo $d['coverage'] !== '' ? di_consult_esc($d['coverage']) . ' วัน' : '—'; ?>
                    <?php if ($d['coverage_end'] !== ''): ?>
                    <div class="hint">ถึง <?php echo di_consult_esc($d['coverage_end']); ?></div>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="box">
        <div class="box-title">รายละเอียดปฏิกิริยา / ความเสี่ยง</div>
        <div><?php echo $detail !== '' ? nl2br(di_consult_esc($detail)) : '—'; ?></div>
        <?php if ($check_lbl !== ''): ?>
        <div class="hint" style="margin-top:4px;">วิธีตรวจ: <?php echo di_consult_esc($check_lbl); ?></div>
        <?php endif; ?>
    </div>

    <?php if (trim((string)$note_display) !== ''): ?>
    <div class="box">
        <div class="box-title">หมายเหตุจากเภสัชกร</div>
        <div><?php echo nl2br(di_consult_esc($note_display)); ?></div>
    </div>
    <?php endif; ?>

    <div class="box doctor-box">
        <div class="box-title">ผลการปรึกษา / คำสั่งแพทย์</div>
        <div class="hint">
            <?php echo mdi_consult_outcome_checked_html($note); ?>
        </div>
        <div class="doctor-lines">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <div class="sign-row">
        <div class="sign-box">
            <div class="sign-line">
                เภสัชกรผู้ Consult<br>
                (<?php echo di_consult_esc($pharm_name !== '' ? $pharm_name : '................................'); ?>)<br>
                วันที่ ....../....../..........
            </div>
        </div>
        <div class="sign-box">
            <div class="sign-line">
                แพทย์ผู้รับปรึกษา<br>
                (................................................)<br>
                วันที่ ....../....../..........
            </div>
        </div>
    </div>
</div>
<script>
window.addEventListener('load', function() {
    if (<?php echo $autoprint ? 'true' : 'false'; ?>) {
        setTimeout(function() { window.print(); }, 250);
    }
});
</script>
</body>
</html>
