<?php
/**
 * AMASS v4.0 Annex B / C / D analysis for THAM Hos-Safe.
 * Annex C is a simplified Poisson ward-week scan (not SaTScan).
 */

function amr_amass_is_possible_contaminant($organism) {
    $s = strtolower(trim((string)$organism));
    $s = preg_replace('/\\s+/', ' ', $s);
    if ($s === '' || amr_amass_is_nogrowth($s)) {
        return false;
    }
    if (preg_match('/aureus|diphtheriae|anthracis|jeikeium|cereus/', $s)) {
        return false;
    }
    if (preg_match('/coagulase\\s*-?\\s*negative|\\bcns\\b|\\bcons\\b|คอกกูเลส/', $s)) {
        return true;
    }
    if (preg_match('/staphylococcus\\s+(epidermidis|haemolyticus|hominis|capitis|warneri|saprophyticus|lugdunensis)/', $s)) {
        return true;
    }
    if (preg_match('/\\b(micrococcus|cutibacterium|propionibacterium|aerococcus|rothia|kocuria)\\b/', $s)) {
        return true;
    }
    if (preg_match('/\\bcorynebacterium\\b/', $s)) {
        return true;
    }
    if (preg_match('/\\bbacillus\\b/', $s)) {
        return true;
    }
    if (preg_match('/viridans/', $s)) {
        return true;
    }
    return false;
}

function amr_amass_pct_frac($n, $d, $dp = 1) {
    $n = (int)$n;
    $d = (int)$d;
    if ($d <= 0) {
        return 'NA';
    }
    $p = round(100.0 * $n / $d, $dp);
    $p = (fmod($p, 1.0) == 0.0) ? (string)(int)$p : (string)$p;
    return $p . '% (' . $n . '/' . $d . ')';
}

function amr_amass_poisson_sf($k, $lambda) {
    $k = (int)$k;
    $lambda = (float)$lambda;
    if ($k <= 0) {
        return 1.0;
    }
    if ($lambda <= 0) {
        return 0.0;
    }
    if ($lambda >= 50) {
        $z = ($k - 0.5 - $lambda) / sqrt($lambda);
        if ($z > 8) {
            return 0.0;
        }
        if ($z < -8) {
            return 1.0;
        }
        $a = 1 / (1 + 0.2316419 * abs($z));
        $d = 0.39894228040143 * exp(-$z * $z / 2);
        $p = $d * $a * (0.31938153 + $a * (-0.356563782 + $a * (1.781477937 + $a * (-1.821255978 + $a * 1.330274429))));
        return $z >= 0 ? $p : (1 - $p);
    }
    $term = exp(-$lambda);
    $sum = $term;
    for ($i = 1; $i < $k; $i++) {
        $term *= $lambda / $i;
        $sum += $term;
        if ($sum >= 1) {
            return 0.0;
        }
    }
    $p = 1.0 - $sum;
    if ($p < 0) {
        return 0.0;
    }
    if ($p > 1) {
        return 1.0;
    }
    return $p;
}

function amr_amass_iso_week($date) {
    if ($date === '') {
        return '';
    }
    $t = strtotime($date);
    return $t ? date('o-\\WW', $t) : '';
}

function amr_amass_annex_b_notifiable($iso) {
    $org = $iso['org_key'] ?? '';
    $atb = $iso['atb'] ?? [];
    if ($org === 'organism_staphylococcus_aureus' && amr_amass_isolate_ris($atb, $org, 'METHICILLIN') === 'R') {
        return 'MRSA';
    }
    if ($org === 'organism_enterococcus_faecium' && ($atb['Vancomycin'] ?? '') === 'R') {
        return 'VREfm';
    }
    if ($org === 'organism_enterococcus_faecalis' && ($atb['Vancomycin'] ?? '') === 'R') {
        return 'VREfs';
    }
    if ($org === 'organism_escherichia_coli' && amr_amass_isolate_ris($atb, $org, 'CARBAPENEMS') === 'R') {
        return 'CREC';
    }
    if ($org === 'organism_klebsiella_pneumoniae' && amr_amass_isolate_ris($atb, $org, 'CARBAPENEMS') === 'R') {
        return 'CRKP';
    }
    if ($org === 'organism_pseudomonas_aeruginosa' && amr_amass_isolate_ris($atb, $org, 'CARBAPENEMS') === 'R') {
        return 'CRPA';
    }
    if ($org === 'organism_acinetobacter_baumannii' && amr_amass_isolate_ris($atb, $org, 'CARBAPENEMS') === 'R') {
        return 'CRAB';
    }
    if (in_array($org, ['organism_escherichia_coli', 'organism_klebsiella_pneumoniae'], true)
        && amr_amass_isolate_ris($atb, $org, '3GC') === 'R') {
        return $org === 'organism_escherichia_coli' ? '3GC-R E. coli' : '3GC-R K. pneumoniae';
    }
    if ($org === 'organism_salmonella_spp' && amr_amass_isolate_ris($atb, $org, 'FLUOROQUINOLONES') === 'R') {
        return 'FQ-R Salmonella';
    }
    return '';
}

function amr_amass_annex_b_ast_errors($iso) {
    $org = $iso['org_key'] ?? '';
    $atb = $iso['atb'] ?? [];
    $reasons = [];
    if ($org === 'organism_klebsiella_pneumoniae' && ($atb['Ampicillin'] ?? '') === 'S') {
        $reasons[] = 'K. pneumoniae susceptible to ampicillin (intrinsic resistance)';
    }
    $enterob = in_array($org, ['organism_escherichia_coli', 'organism_klebsiella_pneumoniae', 'organism_salmonella_spp'], true);
    if ($enterob) {
        $carb = amr_amass_isolate_ris($atb, $org, 'CARBAPENEMS');
        $gc3 = amr_amass_isolate_ris($atb, $org, '3GC');
        if ($carb === 'R' && $gc3 === 'S') {
            $reasons[] = 'Carbapenem-resistant but 3GC-susceptible (discordant AST)';
        }
        $ipm = $atb['Imipenem'] ?? '';
        $mem = $atb['Meropenem'] ?? '';
        if (($ipm === 'S' && $mem === 'R') || ($ipm === 'R' && $mem === 'S')) {
            $reasons[] = 'Discordant carbapenem results (imipenem vs meropenem)';
        }
    }
    if ($org === 'organism_staphylococcus_aureus') {
        if (($atb['Vancomycin'] ?? '') === 'R') {
            $reasons[] = 'S. aureus vancomycin-resistant (rare; review AST)';
        }
        $fox = $atb['Cefoxitin'] ?? '';
        $oxa = $atb['Oxacillin'] ?? '';
        if (($fox === 'S' && $oxa === 'R') || ($fox === 'R' && $oxa === 'S')) {
            $reasons[] = 'Discordant cefoxitin vs oxacillin';
        }
    }
    if ($org === 'organism_pseudomonas_aeruginosa') {
        foreach (['Ampicillin', 'Ceftriaxone', 'Cefotaxime'] as $a) {
            if (($atb[$a] ?? '') === 'S') {
                $reasons[] = 'P. aeruginosa susceptible to ' . strtolower($a) . ' (intrinsic resistance)';
            }
        }
    }
    if ($org === 'organism_acinetobacter_baumannii' && ($atb['Ampicillin'] ?? '') === 'S') {
        $reasons[] = 'A. baumannii susceptible to ampicillin (intrinsic resistance)';
    }
    if (in_array($org, ['organism_enterococcus_faecium', 'organism_enterococcus_faecalis'], true)) {
        foreach (['Ceftriaxone', 'Cefotaxime', 'Ceftazidime'] as $a) {
            if (($atb[$a] ?? '') === 'S') {
                $reasons[] = 'Enterococcus susceptible to cephalosporin (intrinsic resistance)';
            }
        }
    }
    return $reasons;
}

function amr_amass_annex_b_compute(array $blood_cultures, array $blood_dedup, array $adm_by_hn) {
    $n_posneg = count($blood_cultures);
    $n_cont = 0;
    $cont_by_org = [];
    $by_month = [];
    foreach ($blood_cultures as $row) {
        $ym = substr((string)($row['date'] ?? ''), 0, 7);
        if ($ym === '' || $ym === '0000-00') {
            $ym = 'unknown';
        }
        if (!isset($by_month[$ym])) {
            $by_month[$ym] = ['posneg' => 0, 'cont' => 0, 'ast' => 0, 'notif' => 0, 'err' => 0];
        }
        $by_month[$ym]['posneg']++;
        if (!empty($row['contaminant'])) {
            $n_cont++;
            $by_month[$ym]['cont']++;
            $org = trim((string)($row['org_raw'] ?? ''));
            if ($org === '') {
                $org = 'Unspecified contaminant';
            }
            if (!isset($cont_by_org[$org])) {
                $cont_by_org[$org] = 0;
            }
            $cont_by_org[$org]++;
        }
    }

    $n_ast = 0;
    $n_notif = 0;
    $n_err = 0;
    $notif_rows = [];
    $err_rows = [];
    $orgs = amr_amass_priority_orgs();
    foreach ($blood_dedup as $iso) {
        if (empty($iso['atb'])) {
            continue;
        }
        $n_ast++;
        $ym = substr((string)($iso['date'] ?? ''), 0, 7);
        if ($ym === '' || $ym === '0000-00') {
            $ym = 'unknown';
        }
        if (!isset($by_month[$ym])) {
            $by_month[$ym] = ['posneg' => 0, 'cont' => 0, 'ast' => 0, 'notif' => 0, 'err' => 0];
        }
        $by_month[$ym]['ast']++;
        $label = amr_amass_annex_b_notifiable($iso);
        if ($label !== '') {
            $n_notif++;
            $by_month[$ym]['notif']++;
            $notif_rows[] = [
                'Organism' => $orgs[$iso['org_key']][0] ?? $iso['org_key'],
                'Combination' => $label,
                'Infection_origin' => ($iso['origin'] ?? '') !== '' ? $iso['origin'] . '-origin' : 'Unknown',
            ];
        }
        $reasons = amr_amass_annex_b_ast_errors($iso);
        if ($reasons) {
            $n_err++;
            $by_month[$ym]['err']++;
            $err_rows[] = [
                'Organism' => $orgs[$iso['org_key']][0] ?? $iso['org_key'],
                'Potential_error' => implode('; ', $reasons),
                'Infection_origin' => ($iso['origin'] ?? '') !== '' ? $iso['origin'] . '-origin' : 'Unknown',
            ];
        }
    }

    $n_inp = 0;
    $n_inp_cont = 0;
    foreach ($blood_cultures as $row) {
        if (($row['hn'] ?? '') === '' || ($row['date'] ?? '') === '') {
            continue;
        }
        $adm = amr_amass_match_admission($row, $adm_by_hn);
        if (!$adm) {
            continue;
        }
        $n_inp++;
        if (!empty($row['contaminant'])) {
            $n_inp_cont++;
        }
    }

    $indicators = [
        [
            'Indicators' => 'blood_culture_contamination_rate',
            'Description' => 'Possible contaminants among blood cultures (positive + negative)',
            'Number' => $n_cont,
            'Denominator' => $n_posneg,
            'Proportion' => amr_amass_pct_frac($n_cont, $n_posneg),
        ],
        [
            'Indicators' => 'proportion_of_notifiable_antibiotic-pathogen_combinations',
            'Description' => 'Notifiable AMR combinations among blood isolates with AST (deduplicated)',
            'Number' => $n_notif,
            'Denominator' => $n_ast,
            'Proportion' => amr_amass_pct_frac($n_notif, $n_ast),
        ],
        [
            'Indicators' => 'proportion_of_potential_errors_in_the_AST_results',
            'Description' => 'Potential errors / discordant AST among blood isolates with AST (deduplicated)',
            'Number' => $n_err,
            'Denominator' => $n_ast,
            'Proportion' => amr_amass_pct_frac($n_err, $n_ast),
        ],
        [
            'Indicators' => 'blood_culture_contamination_rate_among_inpatients',
            'Description' => 'Possible contaminants among blood cultures matched to an admission',
            'Number' => $n_inp_cont,
            'Denominator' => $n_inp,
            'Proportion' => amr_amass_pct_frac($n_inp_cont, $n_inp),
        ],
    ];

    ksort($by_month);
    $month_rows = [];
    foreach ($by_month as $ym => $m) {
        $label = $ym === 'unknown' ? 'Unknown' : date('F Y', strtotime($ym . '-01'));
        $month_rows[] = [
            'Month' => $label,
            'blood_culture_contamination_rate' => amr_amass_pct_frac($m['cont'], $m['posneg']),
            'notifiable_antibiotic_pathogen' => amr_amass_pct_frac($m['notif'], $m['ast']),
            'potential_AST_errors' => amr_amass_pct_frac($m['err'], $m['ast']),
            'Total_blood_positive_and_negative(N)' => $m['posneg'],
            'Total_blood_positive_AST(N)' => $m['ast'],
        ];
    }
    if ($month_rows) {
        $month_rows[] = [
            'Month' => 'Total:',
            'blood_culture_contamination_rate' => amr_amass_pct_frac($n_cont, $n_posneg),
            'notifiable_antibiotic_pathogen' => amr_amass_pct_frac($n_notif, $n_ast),
            'potential_AST_errors' => amr_amass_pct_frac($n_err, $n_ast),
            'Total_blood_positive_and_negative(N)' => $n_posneg,
            'Total_blood_positive_AST(N)' => $n_ast,
        ];
    }

    arsort($cont_by_org);
    $cont_rows = [];
    foreach ($cont_by_org as $org => $n) {
        $cont_rows[] = [
            'Organism' => $org,
            'Number_of_possible_contaminants' => $n,
            'Percent_of_contaminants' => $n_cont > 0 ? round(100.0 * $n / $n_cont, 1) : '',
        ];
    }
    if ($cont_rows) {
        $cont_rows[] = [
            'Organism' => 'Total:',
            'Number_of_possible_contaminants' => $n_cont,
            'Percent_of_contaminants' => 100,
        ];
    }

    $inpatient_rows = [[
        'Description' => 'blood_culture_contamination_rate_among_inpatients',
        'Number' => $n_inp_cont,
        'Denominator' => $n_inp,
        'Proportion' => amr_amass_pct_frac($n_inp_cont, $n_inp),
    ]];

    return [
        'indicators' => $indicators,
        'by_month' => $month_rows,
        'contaminants' => $cont_rows,
        'inpatient' => $inpatient_rows,
        'notifiable' => $notif_rows,
        'errors' => $err_rows,
        'n_posneg' => $n_posneg,
        'n_cont' => $n_cont,
        'n_ast' => $n_ast,
        'n_notif' => $n_notif,
        'n_err' => $n_err,
        'n_inp' => $n_inp,
        'n_inp_cont' => $n_inp_cont,
    ];
}

function amr_amass_annex_c_profiles() {
    return [
        'mrsa' => ['organism_staphylococcus_aureus', 'METHICILLIN', 'MRSA', 'Methicillin-resistant S. aureus'],
        'vrefs' => ['organism_enterococcus_faecalis', 'Vancomycin', 'VREfs', 'Vancomycin-resistant E. faecalis'],
        'vrefm' => ['organism_enterococcus_faecium', 'Vancomycin', 'VREfm', 'Vancomycin-resistant E. faecium'],
        'crec' => ['organism_escherichia_coli', 'CARBAPENEMS', 'CREC', 'Carbapenem-resistant E. coli'],
        'crkp' => ['organism_klebsiella_pneumoniae', 'CARBAPENEMS', 'CRKP', 'Carbapenem-resistant K. pneumoniae'],
        'crpa' => ['organism_pseudomonas_aeruginosa', 'CARBAPENEMS', 'CRPA', 'Carbapenem-resistant P. aeruginosa'],
        'crab' => ['organism_acinetobacter_baumannii', 'CARBAPENEMS', 'CRAB', 'Carbapenem-resistant A. baumannii'],
    ];
}

function amr_amass_annex_c_is_resistant($iso, $marker) {
    $org = $iso['org_key'] ?? '';
    $atb = $iso['atb'] ?? [];
    if (in_array($marker, ['METHICILLIN', 'CARBAPENEMS', '3GC', 'FLUOROQUINOLONES', 'AMINOGLYCOSIDES'], true)) {
        return amr_amass_isolate_ris($atb, $org, $marker) === 'R';
    }
    return ($atb[$marker] ?? '') === 'R';
}

function amr_amass_annex_c_compute(array $blood_dedup) {
    $ho = array_values(array_filter($blood_dedup, function ($i) {
        return ($i['origin'] ?? '') === 'Hospital';
    }));
    $n_ho_blood = count($ho);
    $ward_tot = [];
    foreach ($ho as $iso) {
        $w = trim((string)($iso['ward'] ?? ''));
        if ($w === '') {
            $w = 'Unknown';
        }
        if (!isset($ward_tot[$w])) {
            $ward_tot[$w] = 0;
        }
        $ward_tot[$w]++;
    }

    $weeks_all = [];
    foreach ($ho as $iso) {
        $wk = amr_amass_iso_week($iso['date'] ?? '');
        if ($wk !== '') {
            $weeks_all[$wk] = true;
        }
    }
    $n_weeks = max(1, count($weeks_all));
    $orgs = amr_amass_priority_orgs();
    $clusters = [];
    $ward_counts = [];
    $profiles = [];

    foreach (amr_amass_annex_c_profiles() as $code => $meta) {
        $org_key = $meta[0];
        $marker = $meta[1];
        $short = $meta[2];
        $label = $meta[3];
        $cases = [];
        foreach ($ho as $iso) {
            if (($iso['org_key'] ?? '') !== $org_key) {
                continue;
            }
            if (!amr_amass_annex_c_is_resistant($iso, $marker)) {
                continue;
            }
            $w = trim((string)($iso['ward'] ?? ''));
            if ($w === '') {
                $w = 'Unknown';
            }
            $wk = amr_amass_iso_week($iso['date'] ?? '');
            $cases[] = ['ward' => $w, 'week' => $wk, 'date' => $iso['date'] ?? ''];
        }
        $n_cases = count($cases);
        $by_ward = [];
        foreach ($cases as $c) {
            if (!isset($by_ward[$c['ward']])) {
                $by_ward[$c['ward']] = 0;
            }
            $by_ward[$c['ward']]++;
        }
        arsort($by_ward);
        foreach ($by_ward as $w => $n) {
            $ward_counts[] = [
                'AMR_pathogen' => $short,
                'Organism' => $orgs[$org_key][0] ?? $org_key,
                'Ward' => $w,
                'Hospital_origin_isolates' => $n,
            ];
        }
        if ($n_cases === 0) {
            continue;
        }
        $by_ww = [];
        foreach ($cases as $c) {
            if ($c['week'] === '') {
                continue;
            }
            $k = $c['ward'] . '|' . $c['week'];
            if (!isset($by_ww[$k])) {
                $by_ww[$k] = ['ward' => $c['ward'], 'week' => $c['week'], 'n' => 0, 'dates' => []];
            }
            $by_ww[$k]['n']++;
            $by_ww[$k]['dates'][] = $c['date'];
        }
        foreach ($by_ww as $cell) {
            $share = $n_ho_blood > 0 ? (($ward_tot[$cell['ward']] ?? 0) / $n_ho_blood) : (1 / max(1, count($ward_tot)));
            $expected = $n_cases * $share / $n_weeks;
            if ($expected < 0.01) {
                $expected = 0.01;
            }
            $obs = $cell['n'];
            if ($obs < 2) {
                continue;
            }
            $p = amr_amass_poisson_sf($obs, $expected);
            $rr = $expected > 0 ? round($obs / $expected, 2) : '';
            if ($p > 0.05 && $rr !== '' && $rr < 2) {
                continue;
            }
            sort($cell['dates']);
            $clusters[] = [
                'AMR_pathogen' => $short,
                'Description' => $label,
                'Ward' => $cell['ward'],
                'Week' => $cell['week'],
                'start_signal_date' => $cell['dates'][0],
                'end_signal_date' => $cell['dates'][count($cell['dates']) - 1],
                'observed_cases' => $obs,
                'expected_cases' => round($expected, 2),
                'observed_expected_ratio' => $rr,
                'p_value' => $p < 0.0001 ? '<0.0001' : round($p, 4),
                'method' => 'Poisson ward-week (not SaTScan)',
            ];
        }

        $atb_list = amr_amass_org_atb_list($org_key);
        $by_prof = [];
        foreach ($ho as $iso) {
            if (($iso['org_key'] ?? '') !== $org_key) {
                continue;
            }
            if (!amr_amass_annex_c_is_resistant($iso, $marker)) {
                continue;
            }
            $bits = [];
            foreach ($atb_list as $atb) {
                if (in_array($atb, ['FLUOROQUINOLONES', 'AMINOGLYCOSIDES', '3GC', 'CARBAPENEMS', 'METHICILLIN'], true)
                    || in_array($atb, ['Meropenem', 'Imipenem', 'Ceftriaxone', 'Oxacillin', 'Vancomycin', 'Ceftazidime'], true)) {
                    $ris = amr_amass_isolate_ris($iso['atb'] ?? [], $org_key, $atb);
                    if ($ris !== '') {
                        $bits[] = $atb . '-' . $ris;
                    }
                }
            }
            $pkey = $bits ? implode(' | ', $bits) : 'AST incomplete';
            $w = trim((string)($iso['ward'] ?? ''));
            if ($w === '') {
                $w = 'Unknown';
            }
            $pk = $short . '|' . $w . '|' . $pkey;
            if (!isset($by_prof[$pk])) {
                $by_prof[$pk] = [
                    'AMR_pathogen' => $short,
                    'Ward' => $w,
                    'AST_profile' => $pkey,
                    'Isolates' => 0,
                ];
            }
            $by_prof[$pk]['Isolates']++;
        }
        foreach ($by_prof as $row) {
            $profiles[] = $row;
        }
    }

    usort($clusters, function ($a, $b) {
        $pa = $a['p_value'] === '<0.0001' ? 0 : (float)$a['p_value'];
        $pb = $b['p_value'] === '<0.0001' ? 0 : (float)$b['p_value'];
        if ($pa == $pb) {
            return ($b['observed_cases'] <=> $a['observed_cases']);
        }
        return $pa <=> $pb;
    });

    return [
        'clusters' => $clusters,
        'ward_counts' => $ward_counts,
        'profiles' => $profiles,
        'n_hospital_origin' => $n_ho_blood,
        'method' => 'simplified Poisson ward-week scan (not SaTScan)',
    ];
}

function amr_amass_drug_generic($name) {
    $s = strtolower(trim((string)$name));
    $s = preg_replace('/\\s+/', ' ', $s);
    $s = preg_replace('/\\s*\\([^)]*\\)/', '', $s);
    $s = preg_replace('/\\s+[0-9].*$/', '', $s);
    $s = preg_replace('/\\s+(mg|g|mcg|iu|unit|ml|tab|inj|vial|cap).*$/i', '', $s);
    $s = str_replace(['+', ' and ', ' with ', ' / ', '/'], '/', $s);
    return trim($s, " \t/-");
}

function amr_amass_aware_map() {
    return [
        'amikacin' => ['Antibiotic', 'Access'],
        'amoxicillin' => ['Antibiotic', 'Access'],
        'amoxicillin/clavulanic acid' => ['Antibiotic', 'Access'],
        'amoxicillin/clavulanate' => ['Antibiotic', 'Access'],
        'amoxycillin' => ['Antibiotic', 'Access'],
        'ampicillin' => ['Antibiotic', 'Access'],
        'benzylpenicillin' => ['Antibiotic', 'Access'],
        'benzathine penicillin' => ['Antibiotic', 'Access'],
        'benzathinepen' => ['Antibiotic', 'Access'],
        'streptomycin' => ['Antibiotic', 'Low watch'],
        'penicillin g' => ['Antibiotic', 'Access'],
        'penicillin' => ['Antibiotic', 'Access'],
        'cefalexin' => ['Antibiotic', 'Access'],
        'cephalexin' => ['Antibiotic', 'Access'],
        'cefazolin' => ['Antibiotic', 'Access'],
        'chloramphenicol' => ['Antibiotic', 'Access'],
        'clindamycin' => ['Antibiotic', 'Access'],
        'cloxacillin' => ['Antibiotic', 'Access'],
        'dicloxacillin' => ['Antibiotic', 'Access'],
        'doxycycline' => ['Antibiotic', 'Access'],
        'gentamicin' => ['Antibiotic', 'Access'],
        'metronidazole' => ['Antibiotic', 'Access'],
        'nitrofurantoin' => ['Antibiotic', 'Access'],
        'co-trimoxazole' => ['Antibiotic', 'Access'],
        'sulfamethoxazole/trimethoprim' => ['Antibiotic', 'Access'],
        'trimethoprim/sulfamethoxazole' => ['Antibiotic', 'Access'],
        'tetracycline' => ['Antibiotic', 'Access'],
        'azithromycin' => ['Antibiotic', 'Low watch'],
        'clarithromycin' => ['Antibiotic', 'Low watch'],
        'erythromycin' => ['Antibiotic', 'Low watch'],
        'roxithromycin' => ['Antibiotic', 'Low watch'],
        'cefuroxime' => ['Antibiotic', 'Low watch'],
        'cefaclor' => ['Antibiotic', 'Low watch'],
        'cefixime' => ['Antibiotic', 'Medium watch'],
        'cefpodoxime' => ['Antibiotic', 'Medium watch'],
        'cefdinir' => ['Antibiotic', 'Medium watch'],
        'cefditoren' => ['Antibiotic', 'Medium watch'],
        'ceftriaxone' => ['Antibiotic', 'Medium watch'],
        'cefotaxime' => ['Antibiotic', 'Medium watch'],
        'ceftazidime' => ['Antibiotic', 'Medium watch'],
        'cefepime' => ['Antibiotic', 'Medium watch'],
        'cefoxitin' => ['Antibiotic', 'Medium watch'],
        'ciprofloxacin' => ['Antibiotic', 'Medium watch'],
        'levofloxacin' => ['Antibiotic', 'Medium watch'],
        'ofloxacin' => ['Antibiotic', 'Medium watch'],
        'moxifloxacin' => ['Antibiotic', 'Medium watch'],
        'norfloxacin' => ['Antibiotic', 'Medium watch'],
        'piperacillin/tazobactam' => ['Antibiotic', 'Medium watch'],
        'piperacillin' => ['Antibiotic', 'Medium watch'],
        'cefoperazone/sulbactam' => ['Antibiotic', 'Medium watch'],
        'cefoperazone' => ['Antibiotic', 'Medium watch'],
        'ampicillin/sulbactam' => ['Antibiotic', 'Medium watch'],
        'vancomycin' => ['Antibiotic', 'Medium watch'],
        'teicoplanin' => ['Antibiotic', 'Medium watch'],
        'meropenem' => ['Antibiotic', 'High watch'],
        'imipenem' => ['Antibiotic', 'High watch'],
        'imipenem/cilastatin' => ['Antibiotic', 'High watch'],
        'ertapenem' => ['Antibiotic', 'High watch'],
        'doripenem' => ['Antibiotic', 'High watch'],
        'aztreonam' => ['Antibiotic', 'High watch'],
        'colistin' => ['Antibiotic', 'Reserve'],
        'colistimethate' => ['Antibiotic', 'Reserve'],
        'polymyxin b' => ['Antibiotic', 'Reserve'],
        'tigecycline' => ['Antibiotic', 'Reserve'],
        'linezolid' => ['Antibiotic', 'Reserve'],
        'daptomycin' => ['Antibiotic', 'Reserve'],
        'fosfomycin' => ['Antibiotic', 'Reserve'],
        'ceftazidime/avibactam' => ['Antibiotic', 'Reserve'],
        'fluconazole' => ['Antifungal', 'Unclassified'],
        'amphotericin' => ['Antifungal', 'Unclassified'],
        'amphotericin b' => ['Antifungal', 'Unclassified'],
        'voriconazole' => ['Antifungal', 'Unclassified'],
        'itraconazole' => ['Antifungal', 'Unclassified'],
        'ketoconazole' => ['Antifungal', 'Unclassified'],
        'nystatin' => ['Antifungal', 'Unclassified'],
        'caspofungin' => ['Antifungal', 'Unclassified'],
        'micafungin' => ['Antifungal', 'Unclassified'],
        'anidulafungin' => ['Antifungal', 'Unclassified'],
        'posaconazole' => ['Antifungal', 'Unclassified'],
        'isavuconazole' => ['Antifungal', 'Unclassified'],
    ];
}

function amr_amass_classify_drug($name) {
    $g = amr_amass_drug_generic($name);
    $map = amr_amass_aware_map();
    if (isset($map[$g])) {
        return ['generic' => $g, 'type' => $map[$g][0], 'aware' => $map[$g][1]];
    }
    foreach ($map as $key => $meta) {
        if ($g === '' || strlen($g) < 5 || strlen($key) < 5) {
            continue;
        }
        if (strpos($g, $key) !== false || strpos($key, $g) !== false) {
            return ['generic' => $key, 'type' => $meta[0], 'aware' => $meta[1]];
        }
    }
    if (preg_match('/azole|fungin|amphotericin|nystatin/', $g)) {
        return ['generic' => $g, 'type' => 'Antifungal', 'aware' => 'Unclassified'];
    }
    return ['generic' => $g !== '' ? $g : trim((string)$name), 'type' => 'Antibiotic', 'aware' => 'Unclassified'];
}

function amr_amass_classify_route($route) {
    $s = strtolower(trim((string)$route));
    if ($s === '') {
        return ['code' => 'Unknown', 'label' => 'Unknown****', 'parenteral' => false];
    }
    if (preg_match('/intrathecal|ith|น้ำไขสันหลัง/', $s)) {
        return ['code' => 'ITH', 'label' => 'Intrathecal (ITH)*', 'parenteral' => true];
    }
    if (preg_match('/intraperitoneal|ip\\b|ช่องท้อง|\\bpd\\b|peritoneal/', $s)) {
        return ['code' => 'IP', 'label' => 'Intraperitoneal (IP)*', 'parenteral' => true];
    }
    if (preg_match('/intramuscular|\\bim\\b|กล้ามเนื้อ/', $s)) {
        return ['code' => 'IM', 'label' => 'Intramuscular (IM)*', 'parenteral' => true];
    }
    if (preg_match('/intravenous|\\biv\\b|หลอดเลือด|เข้าเส้น|drip|หยด|infusion/', $s)) {
        return ['code' => 'IV', 'label' => 'Intravenous (IV)*', 'parenteral' => true];
    }
    if (preg_match('/inject|ฉีด/', $s)) {
        return ['code' => 'Other injection', 'label' => 'Other injection routes**', 'parenteral' => true];
    }
    if (preg_match('/oral|po\\b|รับประทาน|ทาน|ปาก|เม็ด|syrup|แขวนตะกอน/', $s)) {
        return ['code' => 'Oral', 'label' => 'Oral (O)', 'parenteral' => false];
    }
    if (preg_match('/rectal|pr\\b|สวน|ทวาร/', $s)) {
        return ['code' => 'Rectal', 'label' => 'Rectal (R)', 'parenteral' => false];
    }
    if (preg_match('/inhal|พ่น|neb/', $s)) {
        return ['code' => 'Inhalation', 'label' => 'Inhalation (I)', 'parenteral' => false];
    }
    return ['code' => 'Others', 'label' => 'Others***', 'parenteral' => false];
}

function amr_amass_dept_group($name) {
    $s = strtolower(trim((string)$name));
    if ($s === '') {
        return 'Others';
    }
    if (preg_match('/icu|ไอซียู|วิกฤต|critical|ccu|nicu|picu/', $s)) {
        return 'ICU';
    }
    if (preg_match('/กุมาร|pediatr|เด็ก/', $s)) {
        return 'Pediatrics';
    }
    if (preg_match('/ออร์โธ|ortho|กระดูก/', $s)) {
        return 'Orthopedics';
    }
    if (preg_match('/ศัลย|surg|ผ่าตัด|neuro.?surg/', $s)) {
        return 'Surgery';
    }
    if (preg_match('/อายุร|internal|medici|cardio|chest|gi\\b|nephro|hemato|infect|endo|neuro(?!s)/', $s)) {
        return 'Medicine';
    }
    if (preg_match('/สูติ|นรี|ob.?gyn|gyne|labour|คลอด/', $s)) {
        return 'Obstetrics and Gynaecology';
    }
    return 'Others';
}

function amr_amass_is_day_admission(array $adm) {
    $admit = $adm['admit'] ?? '';
    $dc = $adm['discharge'] ?? '';
    if ($admit === '' || $dc === '' || $admit !== $dc) {
        return false;
    }
    if (!empty($adm['died']) || !empty($adm['dama'])) {
        return false;
    }
    return true;
}

function amr_amass_each_day($start, $end, $max = 60) {
    if ($start === '') {
        return [];
    }
    if ($end === '' || $end < $start) {
        $end = $start;
    }
    $t1 = strtotime($start);
    $t2 = strtotime($end);
    if (!$t1 || !$t2) {
        return [];
    }
    $span = (int)round(($t2 - $t1) / 86400);
    if ($span > $max) {
        $t2 = $t1 + $max * 86400;
    }
    $out = [];
    for ($t = $t1; $t <= $t2; $t += 86400) {
        $out[] = date('Y-m-d', $t);
    }
    return $out;
}

function amr_amass_annex_d_compute(array $drug_rows, array $adm_by_hn) {
    $inpatient = [];
    $patient_days = 0;
    $patient_days_ex = 0;
    $n_day_adm = 0;
    foreach ($adm_by_hn as $hn => $list) {
        foreach ($list as $adm) {
            $admit = $adm['admit'] ?? '';
            $dc = $adm['discharge'] ?? '';
            if ($admit === '') {
                continue;
            }
            $end = $dc !== '' ? $dc : $admit;
            if ($end < $admit) {
                $end = $admit;
            }
            $days = amr_amass_each_day($admit, $end, 120);
            $n = count($days);
            $patient_days += $n;
            if (amr_amass_is_day_admission($adm)) {
                $n_day_adm++;
                continue;
            }
            $patient_days_ex += $n;
            $ward = trim((string)($adm['ward'] ?? ''));
            foreach ($days as $d) {
                $inpatient[$hn][$d] = [
                    'ward' => $ward,
                    'dept' => amr_amass_dept_group($ward),
                ];
            }
        }
    }

    $route_order = [
        'IV' => 'Intravenous (IV)*',
        'IM' => 'Intramuscular (IM)*',
        'IP' => 'Intraperitoneal (IP)*',
        'ITH' => 'Intrathecal (ITH)*',
        'Other injection' => 'Other injection routes**',
        'Oral' => 'Oral (O)',
        'Rectal' => 'Rectal (R)',
        'Inhalation' => 'Inhalation (I)',
        'Others' => 'Others***',
        'Unknown' => 'Unknown****',
    ];
    $route_atb = array_fill_keys(array_keys($route_order), 0);
    $route_atf = array_fill_keys(array_keys($route_order), 0);
    $month_atb = [];
    $month_atf = [];
    $month_all = [];
    $top = [];
    $n_drug = 0;
    $n_atb = 0;
    $n_atf = 0;
    $dot_atb = [];
    $dot_aware = [];
    $dot_dept = [];
    $dot_atf = [];
    $lot_keys = [];
    $dates = [];

    foreach ($drug_rows as $row) {
        $name = trim((string)($row['drug_name'] ?? ''));
        if ($name === '') {
            continue;
        }
        $n_drug++;
        if (!isset($top[$name])) {
            $top[$name] = 0;
        }
        $top[$name]++;
        $hn = amr_amass_clean_hn($row['HN'] ?? $row['hospital_number'] ?? '');
        $start = amr_amass_parse_date($row['drug_start_date_td'] ?? $row['drug_start_date'] ?? '');
        $stop = amr_amass_parse_date($row['drug_stop_date_td'] ?? $row['drug_stop_date'] ?? '');
        if ($start !== '') {
            $dates[] = $start;
        }
        $cls = amr_amass_classify_drug($name);
        $rt = amr_amass_classify_route($row['route_administration'] ?? $row['route_of_administration'] ?? '');
        $ym = $start !== '' ? substr($start, 0, 7) : 'unknown';
        if (!isset($month_all[$ym])) {
            $month_all[$ym] = 0;
            $month_atb[$ym] = 0;
            $month_atf[$ym] = 0;
        }
        $month_all[$ym]++;
        if ($cls['type'] === 'Antifungal') {
            $n_atf++;
            $month_atf[$ym]++;
            $route_atf[$rt['code']] = ($route_atf[$rt['code']] ?? 0) + 1;
        } else {
            $n_atb++;
            $month_atb[$ym]++;
            $route_atb[$rt['code']] = ($route_atb[$rt['code']] ?? 0) + 1;
        }

        $drug_dept = amr_amass_dept_group($row['department'] ?? '');
        if ($drug_dept === 'Others') {
            $drug_dept = amr_amass_dept_group($row['ward_name'] ?? '');
        }
        $days = amr_amass_each_day($start, $stop, 60);
        $seen_day = [];
        foreach ($days as $d) {
            if (!isset($inpatient[$hn][$d])) {
                continue;
            }
            $key = $hn . '|' . $d . '|' . $cls['generic'];
            if (isset($seen_day[$key])) {
                continue;
            }
            $seen_day[$key] = true;
            $dept = $drug_dept !== 'Others' ? $drug_dept : ($inpatient[$hn][$d]['dept'] ?? 'Others');
            if ($cls['type'] === 'Antifungal' && $rt['parenteral']) {
                if (!isset($dot_atf[$cls['generic']])) {
                    $dot_atf[$cls['generic']] = 0;
                }
                $dot_atf[$cls['generic']]++;
            }
            if ($cls['type'] !== 'Antibiotic' || !$rt['parenteral']) {
                continue;
            }
            $lot_keys[$hn . '|' . $d] = true;
            $g = $cls['generic'];
            if (!isset($dot_atb[$g])) {
                $dot_atb[$g] = ['DOT' => 0, 'aware' => $cls['aware']];
            }
            $dot_atb[$g]['DOT']++;
            $aw = $cls['aware'];
            if (!isset($dot_aware[$aw])) {
                $dot_aware[$aw] = 0;
            }
            $dot_aware[$aw]++;
            if (!isset($dot_dept[$dept])) {
                $dot_dept[$dept] = 0;
            }
            $dot_dept[$dept]++;
        }
    }

    $total_dot = 0;
    foreach ($dot_atb as $row) {
        $total_dot += $row['DOT'];
    }
    $total_lot = count($lot_keys);
    $prev = $patient_days_ex > 0 ? round(100.0 * $total_lot / $patient_days_ex, 1) : '';
    $prev_text = $patient_days_ex > 0 ? amr_amass_pct_frac($total_lot, $patient_days_ex) : 'NA';

    $aware_order = ['Access', 'Low watch', 'Medium watch', 'High watch', 'Reserve', 'Unclassified'];
    uasort($dot_atb, function ($a, $b) {
        return $b['DOT'] <=> $a['DOT'];
    });
    $dot_atb_rows = [];
    $rank = 1;
    foreach ($dot_atb as $name => $row) {
        $pct = $total_dot > 0 ? round(100.0 * $row['DOT'] / $total_dot, 1) : '';
        $dot_atb_rows[] = [
            'RANK' => $rank++,
            'Antibiotic' => $name,
            'AWaRe_classification' => $row['aware'],
            'DOT' => $row['DOT'],
            'DOT_percent' => $pct,
            'DOT_percent_text' => $total_dot > 0 ? ($pct . '% (' . $row['DOT'] . ')') : 'NA',
            'DOT_per1000patient_days' => $patient_days_ex > 0 ? round(1000.0 * $row['DOT'] / $patient_days_ex, 1) : '',
        ];
    }
    if ($dot_atb_rows) {
        $dot_atb_rows[] = [
            'RANK' => '',
            'Antibiotic' => 'Total:',
            'AWaRe_classification' => '',
            'DOT' => $total_dot,
            'DOT_percent' => 100,
            'DOT_percent_text' => '100% (' . $total_dot . ')',
            'DOT_per1000patient_days' => $patient_days_ex > 0 ? round(1000.0 * $total_dot / $patient_days_ex, 1) : '',
        ];
    }

    $aware_rows = [];
    foreach ($aware_order as $aw) {
        $n = (int)($dot_aware[$aw] ?? 0);
        $pct = $total_dot > 0 ? round(100.0 * $n / $total_dot, 1) : '';
        $aware_rows[] = [
            'AWaRe_classification' => $aw,
            'DOT' => $n,
            'DOT_percent' => $pct,
            'DOT_percent_text' => $total_dot > 0 ? ($pct . '% (' . $n . ')') : 'NA',
            'DOT_per1000patient_days' => $patient_days_ex > 0 ? round(1000.0 * $n / $patient_days_ex, 1) : '',
        ];
    }
    $aware_rows[] = [
        'AWaRe_classification' => 'Total:',
        'DOT' => $total_dot,
        'DOT_percent' => 100,
        'DOT_percent_text' => '100% (' . $total_dot . ')',
        'DOT_per1000patient_days' => $patient_days_ex > 0 ? round(1000.0 * $total_dot / $patient_days_ex, 1) : '',
    ];

    $dept_order = ['Medicine', 'Pediatrics', 'Surgery', 'Orthopedics', 'Obstetrics and Gynaecology', 'ICU', 'Others'];
    $dept_rows = [];
    foreach ($dept_order as $d) {
        $n = (int)($dot_dept[$d] ?? 0);
        $pct = $total_dot > 0 ? round(100.0 * $n / $total_dot, 1) : '';
        $dept_rows[] = [
            'Department' => $d,
            'DOT' => $n,
            'DOT_percent' => $pct,
            'DOT_percent_text' => $total_dot > 0 ? ($pct . '% (' . $n . ')') : 'NA',
            'DOT_per1000patient_days' => $patient_days_ex > 0 ? round(1000.0 * $n / $patient_days_ex, 1) : '',
        ];
    }
    $dept_rows[] = [
        'Department' => 'Total:',
        'DOT' => $total_dot,
        'DOT_percent' => 100,
        'DOT_percent_text' => '100% (' . $total_dot . ')',
        'DOT_per1000patient_days' => $patient_days_ex > 0 ? round(1000.0 * $total_dot / $patient_days_ex, 1) : '',
    ];

    $route_rows = [];
    $sum_r_atb = 0;
    $sum_r_atf = 0;
    foreach ($route_order as $code => $label) {
        $a = (int)($route_atb[$code] ?? 0);
        $f = (int)($route_atf[$code] ?? 0);
        $sum_r_atb += $a;
        $sum_r_atf += $f;
        $route_rows[] = [
            'Route_of_administration' => $label,
            'Number_of_antibiotic_records' => $a,
            'Number_of_antifungal_records' => $f,
        ];
    }
    $route_rows[] = [
        'Route_of_administration' => 'Total:',
        'Number_of_antibiotic_records' => $sum_r_atb,
        'Number_of_antifungal_records' => $sum_r_atf,
    ];

    $month_keys = array_keys($month_all);
    sort($month_keys);
    $month_rows = [];
    $sum_m_all = 0;
    $sum_m_atb = 0;
    $sum_m_atf = 0;
    foreach ($month_keys as $ym) {
        $label = $ym === 'unknown' ? 'Unknown' : date('F Y', strtotime($ym . '-01'));
        $a = (int)($month_atb[$ym] ?? 0);
        $f = (int)($month_atf[$ym] ?? 0);
        $all = (int)($month_all[$ym] ?? 0);
        $sum_m_all += $all;
        $sum_m_atb += $a;
        $sum_m_atf += $f;
        $month_rows[] = [
            'Month' => $label,
            'Number_of_drug_records' => $all,
            'Number_of_antibiotic_records' => $a,
            'Number_of_antifungal_records' => $f,
        ];
    }
    if ($month_rows) {
        $month_rows[] = [
            'Month' => 'Total:',
            'Number_of_drug_records' => $sum_m_all,
            'Number_of_antibiotic_records' => $sum_m_atb,
            'Number_of_antifungal_records' => $sum_m_atf,
        ];
    }

    arsort($top);
    $amu = [];
    $i = 0;
    foreach ($top as $name => $n) {
        $amu[] = ['drug_name' => $name, 'prescriptions' => $n];
        if (++$i >= 30) {
            break;
        }
    }

    arsort($dot_atf);
    $atf_rows = [];
    $atf_total = 0;
    foreach ($dot_atf as $name => $n) {
        $atf_total += $n;
        $atf_rows[] = [
            'Antifungal' => $name,
            'DOT' => $n,
            'DOT_per1000patient_days' => $patient_days_ex > 0 ? round(1000.0 * $n / $patient_days_ex, 1) : '',
        ];
    }
    if ($atf_rows) {
        $atf_rows[] = [
            'Antifungal' => 'Total:',
            'DOT' => $atf_total,
            'DOT_per1000patient_days' => $patient_days_ex > 0 ? round(1000.0 * $atf_total / $patient_days_ex, 1) : '',
        ];
    }

    $summary = [
        ['Parameter' => 'Number_of_drug_records', 'Value' => $n_drug],
        ['Parameter' => 'Number_of_antibiotic_records', 'Value' => $n_atb],
        ['Parameter' => 'Number_of_antifungal_records', 'Value' => $n_atf],
        ['Parameter' => 'Minimum_Drug_Start_date', 'Value' => $dates ? min($dates) : ''],
        ['Parameter' => 'Maximum_Drug_Start_date', 'Value' => $dates ? max($dates) : ''],
        ['Parameter' => 'patient_days', 'Value' => $patient_days],
        ['Parameter' => 'patient_days_exclude_dayadmission', 'Value' => $patient_days_ex],
        ['Parameter' => 'Number_of_day_admissions_excluded', 'Value' => $n_day_adm],
        ['Parameter' => 'total_dot_parenteral_antibiotic', 'Value' => $total_dot],
        ['Parameter' => 'total_lot_parenteral_antibiotic', 'Value' => $total_lot],
        ['Parameter' => 'AMU_prevalence_parenteral_antibiotic', 'Value' => $prev],
        ['Parameter' => 'AMU_prevalence_parenteral_antibiotic_text', 'Value' => $prev_text],
    ];

    return [
        'summary' => $summary,
        'by_month' => $month_rows,
        'by_route' => $route_rows,
        'dot_atb' => $dot_atb_rows,
        'dot_aware' => $aware_rows,
        'dot_dept' => $dept_rows,
        'dot_atf' => $atf_rows,
        'amu' => $amu,
        'kpis' => [
            'n_drug' => $n_drug,
            'n_atb' => $n_atb,
            'n_atf' => $n_atf,
            'patient_days' => $patient_days,
            'patient_days_ex' => $patient_days_ex,
            'dot' => $total_dot,
            'lot' => $total_lot,
            'prevalence' => $prev,
            'prevalence_text' => $prev_text,
            'date_min' => $dates ? min($dates) : '',
            'date_max' => $dates ? max($dates) : '',
        ],
    ];
}
