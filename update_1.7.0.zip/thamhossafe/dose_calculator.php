<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('dose_calculator_helper.php');
mysqli_set_charset($con, 'utf8');
dc_ensure_tables($con);

$allowed_tabs = ['methylpred', 'rtpa_stemi', 'rtpa_stroke', 'tnk_stroke', 'tnk_stemi', 'midazolam', 'fentanyl', 'dobutamine', 'dopamine', 'norepinephrine', 'cisatracurium', 'adrenaline', 'calcium_glu', 'alprostadil', 'indomethacin', 'nac', 'lbw', 'iloprost', 'kcl', 'ntg', 'arv_ped', 'tb'];
$tab = isset($_GET['tab']) ? strtolower(trim((string)$_GET['tab'])) : 'methylpred';
// แท็บเก่า → รวมใน Midazolam
if ($tab === 'bolus' || $tab === 'midazolam_hr' || $tab === 'midazolam_min') {
    $tab = 'midazolam';
}
if (!in_array($tab, $allowed_tabs, true)) {
    $tab = 'methylpred';
}
$prefill_hn = isset($_GET['hn']) ? htmlspecialchars(trim((string)$_GET['hn']), ENT_QUOTES, 'UTF-8') : '';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ระบบช่วยคำนวณยา - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .dc-hint {
            background: #0d6efd;
            color: #fff;
            border-radius: 8px;
            padding: 0.65rem 1rem;
            font-weight: 600;
            font-size: 0.95rem;
        }
        .dc-input-yellow {
            background: #fff3cd !important;
            border-color: #ffc107 !important;
            font-weight: 700;
        }
        .dc-result {
            background: #fce7f3;
            border: 1px solid #f9a8d4;
            border-radius: 8px;
            padding: 0.85rem 1rem;
        }
        .dc-result .val { font-size: 1.35rem; font-weight: 800; color: #9d174d; }
        .dc-sticker {
            background: #ffedd5;
            border: 1px solid #fdba74;
            border-radius: 8px;
            padding: 0.75rem 1rem;
            white-space: pre-wrap;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
            font-size: 0.9rem;
            min-height: 4.5rem;
        }
        .dc-note {
            background: #fef08a;
            border-left: 4px solid #ca8a04;
            border-radius: 6px;
            padding: 0.75rem 1rem;
        }
        .dc-ref-table th, .dc-ref-table td { vertical-align: middle; }
        .nav-tabs .nav-link { font-weight: 600; font-size: 0.9rem; }
        .nav-tabs .nav-link.active { color: #0d6efd; }
        .dc-card-title { font-weight: 800; color: #1e3a5f; }
        .dc-patient-box { background: #ecfdf5; border: 1px solid #6ee7b7; border-radius: 10px; }
        .dc-locked { opacity: 0.45; pointer-events: none; user-select: none; }
        .dc-source-hint { font-size: 0.8rem; color: #64748b; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-1 text-dark d-flex flex-wrap align-items-center gap-2">
                <span><i class="fas fa-calculator me-2 text-primary"></i>ระบบช่วยคำนวณยา</span>
                <a href="monitor_dose_calculator.php?tab=settings" class="btn btn-sm btn-outline-danger fw-bold">
                    <i class="fas fa-desktop me-1"></i> Monitor / ตั้งค่า
                </a>
            </h4>
            <p class="text-muted small mb-3">ค้นหา HN แล้วระบบจะคำนวณและบันทึกอัตโนมัติ — สลับแท็บยาก็บันทึกน้ำหนัก/ส่วนสูงให้ด้วย · ผูกยาเพื่อเฝ้าระวังใบสั่งได้ที่ Monitor</p>

            <div class="card border-0 shadow-sm mb-3 dc-patient-box">
                <div class="card-body py-3">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">HN <span class="text-danger">*</span></label>
                            <input type="text" id="dc_hn" class="form-control form-control-lg fw-bold border-success" placeholder="กรอก HN แล้วกดค้นหา" value="<?php echo $prefill_hn; ?>">
                        </div>
                        <div class="col-md-2">
                            <button type="button" id="dcBtnLookup" class="btn btn-success btn-lg w-100 fw-bold">
                                <i class="fas fa-search me-1"></i> ค้นหา
                            </button>
                        </div>
                        <div class="col-md-7">
                            <div id="dcPatientInfo" class="small text-muted">ยังไม่ได้เลือกผู้ป่วย — ต้องค้นหา HN ก่อนใช้งานเครื่องคำนวณ</div>
                        </div>
                    </div>
                    <div class="row g-2 mt-2" id="dcVitalsRow" style="display:none;">
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">น้ำหนัก (kg) <span class="text-danger">*</span></label>
                            <input type="number" id="dc_bw" class="form-control dc-input-yellow" min="1" step="0.1">
                            <div class="dc-source-hint" id="dc_bw_src_hint"></div>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">ส่วนสูง (cm)</label>
                            <input type="number" id="dc_height" class="form-control dc-input-yellow" min="1" step="0.1">
                            <div class="dc-source-hint" id="dc_ht_src_hint"></div>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">วันชั่งน้ำหนัก (HOSxP)</label>
                            <input type="text" id="dc_vstdate" class="form-control" readonly>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="button" id="dcBtnCalc" class="btn btn-outline-primary btn-lg w-100 fw-bold">
                                <i class="fas fa-save me-1"></i> บันทึกอีกครั้ง
                            </button>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">อายุ (ปี)</label>
                            <input type="number" id="dc_age" class="form-control dc-input-yellow" min="0" step="1" placeholder="—">
                            <div class="dc-source-hint" id="dc_age_src_hint">ค้นหา HN แล้วระบบจะดึงอายุจาก HOSxP</div>
                        </div>
                    </div>
                    <div id="dcSaveMsg" class="mt-2 small" style="display:none;"></div>
                </div>
            </div>

            <div id="dcCalcArea" class="dc-locked">
            <ul class="nav nav-tabs flex-wrap mb-3" id="dcTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'methylpred' ? 'active' : '' ?>" id="tab-methylpred" data-bs-toggle="tab" data-bs-target="#pane-methylpred" type="button" role="tab" data-dc-tab="methylpred">Methylpred 23/24 hr</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'rtpa_stemi' ? 'active' : '' ?>" id="tab-rtpa-stemi" data-bs-toggle="tab" data-bs-target="#pane-rtpa-stemi" type="button" role="tab" data-dc-tab="rtpa_stemi">rT-PA STEMI</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'rtpa_stroke' ? 'active' : '' ?>" id="tab-rtpa-stroke" data-bs-toggle="tab" data-bs-target="#pane-rtpa-stroke" type="button" role="tab" data-dc-tab="rtpa_stroke">rT-PA STROKE</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'tnk_stroke' ? 'active' : '' ?>" id="tab-tnk-stroke" data-bs-toggle="tab" data-bs-target="#pane-tnk-stroke" type="button" role="tab" data-dc-tab="tnk_stroke">TNK Stroke</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'tnk_stemi' ? 'active' : '' ?>" id="tab-tnk-stemi" data-bs-toggle="tab" data-bs-target="#pane-tnk-stemi" type="button" role="tab" data-dc-tab="tnk_stemi">TNK STEMI</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'midazolam' ? 'active' : '' ?>" id="tab-midazolam" data-bs-toggle="tab" data-bs-target="#pane-midazolam" type="button" role="tab" data-dc-tab="midazolam">Midazolam</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'fentanyl' ? 'active' : '' ?>" id="tab-fentanyl" data-bs-toggle="tab" data-bs-target="#pane-fentanyl" type="button" role="tab" data-dc-tab="fentanyl">Fentanyl</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'dobutamine' ? 'active' : '' ?>" id="tab-dobutamine" data-bs-toggle="tab" data-bs-target="#pane-dobutamine" type="button" role="tab" data-dc-tab="dobutamine">Dobutamine</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'dopamine' ? 'active' : '' ?>" id="tab-dopamine" data-bs-toggle="tab" data-bs-target="#pane-dopamine" type="button" role="tab" data-dc-tab="dopamine">Dopamine</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'norepinephrine' ? 'active' : '' ?>" id="tab-norepinephrine" data-bs-toggle="tab" data-bs-target="#pane-norepinephrine" type="button" role="tab" data-dc-tab="norepinephrine">NE</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'cisatracurium' ? 'active' : '' ?>" id="tab-cisatracurium" data-bs-toggle="tab" data-bs-target="#pane-cisatracurium" type="button" role="tab" data-dc-tab="cisatracurium">Cisatracurium</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'adrenaline' ? 'active' : '' ?>" id="tab-adrenaline" data-bs-toggle="tab" data-bs-target="#pane-adrenaline" type="button" role="tab" data-dc-tab="adrenaline">Adrenaline</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'calcium_glu' ? 'active' : '' ?>" id="tab-calcium-glu" data-bs-toggle="tab" data-bs-target="#pane-calcium-glu" type="button" role="tab" data-dc-tab="calcium_glu">Calcium glu</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'alprostadil' ? 'active' : '' ?>" id="tab-alprostadil" data-bs-toggle="tab" data-bs-target="#pane-alprostadil" type="button" role="tab" data-dc-tab="alprostadil">Alprostadil</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'indomethacin' ? 'active' : '' ?>" id="tab-indomethacin" data-bs-toggle="tab" data-bs-target="#pane-indomethacin" type="button" role="tab" data-dc-tab="indomethacin">Indomethacin</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'nac' ? 'active' : '' ?>" id="tab-nac" data-bs-toggle="tab" data-bs-target="#pane-nac" type="button" role="tab" data-dc-tab="nac">NAC</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'lbw' ? 'active' : '' ?>" id="tab-lbw" data-bs-toggle="tab" data-bs-target="#pane-lbw" type="button" role="tab" data-dc-tab="lbw">LBW / วิสัญญี</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'iloprost' ? 'active' : '' ?>" id="tab-iloprost" data-bs-toggle="tab" data-bs-target="#pane-iloprost" type="button" role="tab" data-dc-tab="iloprost">Iloprost</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'kcl' ? 'active' : '' ?>" id="tab-kcl" data-bs-toggle="tab" data-bs-target="#pane-kcl" type="button" role="tab" data-dc-tab="kcl">KCL</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'ntg' ? 'active' : '' ?>" id="tab-ntg" data-bs-toggle="tab" data-bs-target="#pane-ntg" type="button" role="tab" data-dc-tab="ntg">NTG</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'arv_ped' ? 'active' : '' ?>" id="tab-arv-ped" data-bs-toggle="tab" data-bs-target="#pane-arv-ped" type="button" role="tab" data-dc-tab="arv_ped">ARV เด็ก</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?= $tab === 'tb' ? 'active' : '' ?>" id="tab-tb" data-bs-toggle="tab" data-bs-target="#pane-tb" type="button" role="tab" data-dc-tab="tb">TB</button>
                </li>
            </ul>

            <div class="tab-content" id="dcTabContent">

                <!-- Methylpred -->
                <div class="tab-pane fade <?= $tab === 'methylpred' ? 'show active' : '' ?>" id="pane-methylpred" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Methylprednisolone (1,000 mg / 16 ml = 62.5 mg/mL)</h5>
                            <div class="dc-hint mb-3">*** เลือกชั่วโมงและปริมาตร — น้ำหนักใช้จากช่องด้านบน (ดึงจาก HOSxP / แก้ได้) — Bolus 30 mg/kg · Infusion 5.4 mg/kg/hr ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">ชั่วโมงที่ให้ยา</label>
                                    <select id="mp_hours" class="form-select form-select-lg dc-input-yellow">
                                        <option value="23">23 hr</option>
                                        <option value="24" selected>24 hr</option>
                                        <option value="47">47 hr (สติกเกอร์แสดง 23.5 × 2 ชุด)</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">ปริมาตรสารน้ำ (mL)</label>
                                    <select id="mp_vol" class="form-select form-select-lg dc-input-yellow">
                                        <option value="500" selected>500 ml</option>
                                        <option value="1000">1000 ml</option>
                                    </select>
                                </div>
                            </div>
                            <div id="mp_note_47" class="dc-note mb-3 d-none">
                                กรณี 47 ชม.: จ่ายยาครบ 47 ชม. แต่พิมพ์สติกเกอร์เป็นชุดละ 23.5 ชม. (2 ชุด)
                            </div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">จำนวนยาที่จ่ายรวม Bolus + Infusion</div>
                                        <div class="val"><span id="mp_amp_total">—</span></div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">จำนวนยาที่จ่าย Bolus</div>
                                        <div class="val"><span id="mp_amp_bolus">—</span></div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">จำนวนยาที่จ่าย Infusion</div>
                                        <div class="val"><span id="mp_amp_inf">—</span></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-lg-4">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <strong>Sticker ยา Bolus</strong>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" data-copy="#mp_sticker_bolus"><i class="fas fa-copy"></i></button>
                                    </div>
                                    <div class="dc-sticker" id="mp_sticker_bolus"></div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <strong>Sticker ยา Infusion</strong>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" data-copy="#mp_sticker_inf"><i class="fas fa-copy"></i></button>
                                    </div>
                                    <div class="dc-sticker" id="mp_sticker_inf"></div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <strong>Sticker สารน้ำ Infusion</strong>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" data-copy="#mp_sticker_fluid"><i class="fas fa-copy"></i></button>
                                    </div>
                                    <div class="dc-sticker" id="mp_sticker_fluid"></div>
                                </div>
                            </div>
                            <div class="table-responsive mt-3">
                                <table class="table table-sm table-bordered dc-ref-table mb-0 bg-white">
                                    <thead class="table-light"><tr><th colspan="2">Rate อ้างอิง (ml/hr)</th></tr></thead>
                                    <tbody>
                                        <tr><td>23 hr × 500 ml</td><td>21.75</td></tr>
                                        <tr><td>23 hr × 1000 ml</td><td>43.5</td></tr>
                                        <tr><td>24 hr × 500 ml</td><td>20.83</td></tr>
                                        <tr><td>24 hr × 1000 ml</td><td>41.67</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- rT-PA STEMI -->
                <div class="tab-pane fade <?= $tab === 'rtpa_stemi' ? 'show active' : '' ?>" id="pane-rtpa-stemi" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">สำหรับคำนวณยา Alteplase (rtPA) (ยา 50 mg/50 ml) Acute STEMI</h5>
                            <div class="dc-hint mb-3">*** น้ำหนักใช้จากช่องด้านบน — 15 mg bolus then 0.75 mg/kg (up to 50 mg) drip ≥ 30 min then 0.5 mg/kg (up to 30 mg) drip ≥ 60 min · MAX total = 100 mg ***</div>
                            <div class="small text-muted mb-3">ยาผง 50 mg/vial · สารละลาย 50 ml/vial · ความเข้มข้น 1 mg/mL</div>

                            <div class="row g-3 mb-3">
                                <div class="col-md-4">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">ยาที่ให้ Bolus</div>
                                        <div class="val" style="color:#166534;"><span id="rs_bolus_mg">15</span> mg</div>
                                        <div class="small"><span id="rs_bolus_ml">15</span> ml · <span id="rs_bolus_vial">—</span> ขวด</div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">ยาที่ใช้ 0.75 mg/kg (up to 50 mg)</div>
                                        <div class="val" style="color:#166534;"><span id="rs_drip1_mg">—</span> mg</div>
                                        <div class="small"><span id="rs_drip1_ml">—</span> ml · <span id="rs_drip1_vial">—</span> ขวด</div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">ยาที่ใช้ 0.5 mg/kg (up to 30 mg)</div>
                                        <div class="val" style="color:#166534;"><span id="rs_drip2_mg">—</span> mg</div>
                                        <div class="small"><span id="rs_drip2_ml">—</span> ml · <span id="rs_drip2_vial">—</span> ขวด</div>
                                    </div>
                                </div>
                            </div>

                            <div class="row g-3 mb-2">
                                <div class="col-lg-6">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <strong>IV bolus 15 mg <span class="text-muted fw-normal">in 1 min</span></strong>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" data-copy="#rs_sticker_bolus"><i class="fas fa-copy"></i></button>
                                    </div>
                                    <div class="dc-sticker" id="rs_sticker_bolus"></div>
                                    <div class="small mt-1">→ <span id="rs_bolus_mg2">15</span> mg / <span id="rs_bolus_ml2">15</span> ml</div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <strong>IV infusion <span class="text-muted fw-normal">drip ≥ 30 min</span></strong>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" data-copy="#rs_sticker_inf1"><i class="fas fa-copy"></i></button>
                                    </div>
                                    <div class="dc-sticker" id="rs_sticker_inf1"></div>
                                    <div class="small mt-1">→ <span id="rs_drip1_mg2">—</span> mg / <span id="rs_drip1_ml2">—</span> ml</div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <strong>IV infusion <span class="text-muted fw-normal">drip ≥ 60 min</span></strong>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" data-copy="#rs_sticker_inf2"><i class="fas fa-copy"></i></button>
                                    </div>
                                    <div class="dc-sticker" id="rs_sticker_inf2"></div>
                                    <div class="small mt-1">→ <span id="rs_drip2_mg2">—</span> mg / <span id="rs_drip2_ml2">—</span> ml</div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <strong class="text-primary">Total dose</strong>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" data-copy="#rs_sticker_total"><i class="fas fa-copy"></i></button>
                                    </div>
                                    <div class="dc-result">
                                        <div class="val"><span id="rs_total_mg">—</span> mg / <span id="rs_total_ml">—</span> ml</div>
                                        <div class="small">รวม <span id="rs_total_vial">—</span> ขวด (max 100 mg)</div>
                                    </div>
                                    <div class="dc-sticker mt-2 d-none" id="rs_sticker_total"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- rT-PA STROKE -->
                <div class="tab-pane fade <?= $tab === 'rtpa_stroke' ? 'show active' : '' ?>" id="pane-rtpa-stroke" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Alteplase (rtPA) STROKE — 0.9 mg/kg (MAX total = 90 mg)</h5>
                            <div class="dc-hint mb-3">*** น้ำหนักใช้จากช่องด้านบน — Bolus 10% in 1 min · Infusion 90% drip in 60 min ***</div>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">ยาที่ใช้ทั้งหมด</div>
                                        <div class="val"><span id="rk_total_mg">—</span> mg</div>
                                        <div class="small"><span id="rk_total_ml">—</span> ml · <span id="rk_total_vial">—</span> ขวด</div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">IV Bolus 10% in 1 min</div>
                                        <div class="val"><span id="rk_bolus_mg">—</span> mg</div>
                                        <div class="small"><span id="rk_bolus_ml">—</span> ml</div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">IV Infusion 90% drip in 60 min</div>
                                        <div class="val"><span id="rk_inf_mg">—</span> mg</div>
                                        <div class="small"><span id="rk_inf_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TNK Stroke -->
                <div class="tab-pane fade <?= $tab === 'tnk_stroke' ? 'show active' : '' ?>" id="pane-tnk-stroke" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Tenecteplase (TNK / Metalyse) Stroke — 25 mg / 5 ml SWI (5 mg/mL)</h5>
                            <div class="dc-hint mb-3">*** น้ำหนักใช้จากช่องด้านบน — ขนาดตามตารางน้ำหนัก · ยาไม่มีสารน้ำให้ ใช้ SWI ได้เลย ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">Tenecteplase (Units)</div>
                                        <div class="val"><span id="ts_units">—</span></div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยา (mg)</div>
                                        <div class="val"><span id="ts_mg">—</span> mg</div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">ปริมาตรที่ให้ (mL)</div>
                                        <div class="val"><span id="ts_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                            <div class="dc-note mb-3">
                                <strong class="text-danger">สำคัญ:</strong> ยานี้สำหรับผู้ป่วยสิทธิเบิก — หากสิทธิอื่นให้ชำระก่อน
                                หากชำระไม่ทันแจ้งแพทย์พิจารณาใช้ <strong>rtPA</strong> แทน
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr><th>น้ำหนัก (kg)</th><th>Units</th><th>mg</th><th>mL</th></tr>
                                    </thead>
                                    <tbody>
                                        <tr><td>&lt; 60</td><td>3,000</td><td>15.0</td><td>3.0</td></tr>
                                        <tr><td>≥ 60 – &lt; 70</td><td>3,500</td><td>17.5</td><td>3.5</td></tr>
                                        <tr><td>≥ 70 – &lt; 80</td><td>4,000</td><td>20.0</td><td>4.0</td></tr>
                                        <tr><td>≥ 80 – &lt; 90</td><td>4,500</td><td>22.5</td><td>4.5</td></tr>
                                        <tr><td>≥ 90</td><td>5,000</td><td>25.0</td><td>5.0</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TNK STEMI -->
                <div class="tab-pane fade <?= $tab === 'tnk_stemi' ? 'show active' : '' ?>" id="pane-tnk-stemi" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Tenecteplase (TNK) STEMI — 5 mg/mL (ผง 40 mg/vial + WFI 8 ml)</h5>
                            <div class="dc-hint mb-3">*** น้ำหนัก/อายุใช้จากช่องด้านบน — อายุ &gt; 75 ปี ลดขนาดครึ่งหนึ่ง ***</div>
                            <div id="tm_age_note" class="dc-note mb-3 d-none">อายุ &gt; 75 ปี — ลดขนาดยาครึ่งหนึ่งตาม protocol</div>
                            <div id="tm_pediatric_note" class="alert alert-warning fw-bold mb-3 d-none" role="alert">
                                <i class="fas fa-exclamation-triangle me-1"></i>
                                ไม่มีข้อมูลความปลอดภัย/ประสิทธิภาพในเด็กอายุ &lt; 18 ปี
                            </div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาในเคสนี้</div>
                                        <div class="val"><span id="tm_mg">—</span> mg</div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">คิดเป็นปริมาตร</div>
                                        <div class="val"><span id="tm_ml">—</span> ml</div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result">
                                        <div class="small text-muted">จำนวนยาที่ต้องจ่าย</div>
                                        <div class="val"><span id="tm_vial">—</span> vial</div>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr><th>น้ำหนัก (kg)</th><th>TNK (mg)</th><th>ปริมาตร (ml)</th></tr>
                                    </thead>
                                    <tbody>
                                        <tr><td>&lt; 60</td><td>30</td><td>6</td></tr>
                                        <tr><td>≥ 60 – &lt; 70</td><td>35</td><td>7</td></tr>
                                        <tr><td>≥ 70 – &lt; 80</td><td>40</td><td>8</td></tr>
                                        <tr><td>≥ 80 – &lt; 90</td><td>45</td><td>9</td></tr>
                                        <tr><td>≥ 90</td><td>50</td><td>10</td></tr>
                                    </tbody>
                                </table>
                            </div>
                            <p class="small text-muted mt-2 mb-0">ไม่มีข้อมูลความปลอดภัย/ประสิทธิภาพในเด็กอายุ &lt; 18 ปี</p>
                        </div>
                    </div>
                </div>

                <!-- Midazolam: Bolus + min + hr -->
                <div class="tab-pane fade <?= $tab === 'midazolam' ? 'show active' : '' ?>" id="pane-midazolam" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Bolus Midazolam 5 mg/ml (0.05–0.15 mg/kg)</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน ***</div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">min (mg)</div>
                                        <div class="val"><span id="bl_mz_min_mg">—</span></div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">MAX (mg)</div>
                                        <div class="val"><span id="bl_mz_max_mg">—</span></div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">แพทย์สั่ง (mg)</label>
                                    <input type="number" id="bl_mz_order_mg" class="form-control dc-input-yellow" min="0" step="0.01" value="0.2">
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">ยา (ml)</div>
                                        <div class="val" style="color:#166534;"><span id="bl_mz_drug_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Infusion — mcg/kg/min</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (mcg/kg/min)</label>
                                    <input type="number" id="mz_dose" class="form-control dc-input-yellow" min="0" step="0.1" value="2">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mg)</label>
                                    <input type="number" id="mz_drug_mg" class="form-control dc-input-yellow" min="0" step="1" value="15">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="mz_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="41">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" id="mz_fluid" class="form-control" value="D5, D10, NS" readonly>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเฉลี่ย</div>
                                        <div class="val"><span id="mz_mg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="mz_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="mz_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Infusion — mcg/kg/hr (Recommended 20–100)</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน · MAX concentration = 5 mg/ml ***</div>
                            <div id="mzh_dose_alert" class="alert d-none mb-3 fw-bold py-2" role="alert"></div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (mcg/kg/hr)</label>
                                    <input type="number" id="mzh_dose" class="form-control dc-input-yellow" min="0" step="0.1" value="20">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mg)</label>
                                    <input type="number" id="mzh_drug_mg" class="form-control dc-input-yellow" min="0" step="0.1" value="2.5">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="mzh_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="20">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" class="form-control" value="D5, NS" readonly>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเคสนี้</div>
                                        <div class="val"><span id="mzh_mcg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="mzh_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="mzh_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ยา (ml) · 5 mg/ml</div>
                                        <div class="val"><span id="mzh_drug_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">คำนวณย้อนกลับ — จาก Rate → mcg/kg/hr</h5>
                            <div class="dc-hint mb-3">*** กรอก Rate (ml/hr) และความเข้มข้น · สูตร = (rate × conc_mg/ml × 1000) ÷ BW · Recommended 20–100 mcg/kg/hr ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Rate (ml/hr)</label>
                                    <input type="number" id="mzh_rev_rate" class="form-control dc-input-yellow" min="0" step="1" value="2">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ความเข้มข้น (mg/ml)</label>
                                    <select id="mzh_rev_conc" class="form-select dc-input-yellow">
                                        <option value="0.5">0.5 mg/ml (1 mg : 2 ml)</option>
                                        <option value="1" selected>1 mg : 1 ml</option>
                                        <option value="2">2 mg : 1 ml</option>
                                        <option value="3">3 mg : 1 ml</option>
                                        <option value="4">4 mg : 1 ml</option>
                                        <option value="5">5 mg : 1 ml (MAX)</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" id="mzh_rev_result_box">
                                        <div class="small text-muted">ได้ขนาดยา</div>
                                        <div class="val"><span id="mzh_rev_dose">—</span> mcg/kg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div id="mzh_rev_alert" class="dc-note mb-0 d-none"></div>
                                </div>
                            </div>
                            <h6 class="fw-bold mb-2">เทียบเท่า Rate ที่ความเข้มข้นอื่น (ปริมาณยาเท่ากัน)</h6>
                            <div class="table-responsive mb-3">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ความเข้มข้น</th>
                                            <th>0.5</th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                            <th>4</th>
                                            <th>5 (MAX)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Rate (ml/hr)</td>
                                            <td><span id="mzh_eq_05">—</span></td>
                                            <td><span id="mzh_eq_1">—</span></td>
                                            <td><span id="mzh_eq_2">—</span></td>
                                            <td><span id="mzh_eq_3">—</span></td>
                                            <td><span id="mzh_eq_4">—</span></td>
                                            <td><span id="mzh_eq_5">—</span></td>
                                        </tr>
                                        <tr>
                                            <td>mg/hr</td>
                                            <td colspan="6"><span id="mzh_eq_mg_hr">—</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="small text-muted">
                                <span class="badge text-bg-warning text-dark">เหลือง</span> Recommended Drug Dose (20–100 mcg/kg/hr) ·
                                MAX concentration = 5 mg/ml
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Fentanyl (bolus + mcg/kg/hr) -->
                <div class="tab-pane fade <?= $tab === 'fentanyl' ? 'show active' : '' ?>" id="pane-fentanyl" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Bolus Fentanyl 100 mcg/2 ml (1 mcg/kg)</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน ***</div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">min (mcg)</div>
                                        <div class="val"><span id="bl_fn_min_mcg">—</span></div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">แพทย์สั่ง (mcg)</label>
                                    <input type="number" id="bl_fn_order_mcg" class="form-control dc-input-yellow" min="0" step="0.1" value="25">
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">ยา (ml)</div>
                                        <div class="val" style="color:#166534;"><span id="bl_fn_drug_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Infusion — mcg/kg/hr</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (mcg/kg/hr)</label>
                                    <input type="number" id="fn_dose" class="form-control dc-input-yellow" min="0" step="0.1" value="1">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mg)</label>
                                    <input type="number" id="fn_drug_mg" class="form-control dc-input-yellow" min="0" step="0.01" value="0.1">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="fn_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="33">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" id="fn_fluid" class="form-control" value="D5, NS" readonly>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเฉลี่ย</div>
                                        <div class="val"><span id="fn_mcg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="fn_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="fn_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Dobutamine (mcg/kg/min) -->
                <div class="tab-pane fade <?= $tab === 'dobutamine' ? 'show active' : '' ?>" id="pane-dobutamine" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Dobutamine (2–20 mcg/kg/min) Max 40 mcg/kg/min</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน · MAX concentration = 5 mg/ml ***</div>
                            <div id="db_dose_alert" class="alert d-none mb-3 fw-bold py-2" role="alert"></div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (mcg/kg/min)</label>
                                    <input type="number" id="db_dose" class="form-control dc-input-yellow" min="0" step="0.1" value="5">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mg)</label>
                                    <input type="number" id="db_drug_mg" class="form-control dc-input-yellow" min="0" step="1" value="100">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="db_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="130">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" class="form-control" value="D5, D10, NS" readonly>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเคสนี้</div>
                                        <div class="val"><span id="db_mcg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="db_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="db_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ยา (ml) · 50 mg/ml</div>
                                        <div class="val"><span id="db_drug_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">คำนวณย้อนกลับ — จาก Rate → mcg/kg/min</h5>
                            <div class="dc-hint mb-3">*** กรอก Rate (ml/hr) และความเข้มข้น · สูตร = (rate × conc_mg/ml × 1000) ÷ (BW × 60) ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Rate (ml/hr)</label>
                                    <input type="number" id="db_rev_rate" class="form-control dc-input-yellow" min="0" step="1" value="5">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ความเข้มข้น (mg/ml)</label>
                                    <select id="db_rev_conc" class="form-select dc-input-yellow">
                                        <option value="1" selected>1 mg : 1 ml</option>
                                        <option value="2">2 mg : 1 ml</option>
                                        <option value="3">3 mg : 1 ml</option>
                                        <option value="4">4 mg : 1 ml</option>
                                        <option value="5">5 mg : 1 ml (MAX)</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" id="db_rev_result_box">
                                        <div class="small text-muted">ได้ขนาดยา</div>
                                        <div class="val"><span id="db_rev_dose">—</span> mcg/kg/min</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div id="db_rev_alert" class="dc-note mb-0 d-none"></div>
                                </div>
                            </div>
                            <h6 class="fw-bold mb-2">เทียบเท่า Rate ที่ความเข้มข้นอื่น (ปริมาณยาเท่ากัน)</h6>
                            <div class="table-responsive mb-2">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ความเข้มข้น</th>
                                            <th>1 mg/ml</th>
                                            <th>2 mg/ml</th>
                                            <th>3 mg/ml</th>
                                            <th>4 mg/ml</th>
                                            <th>5 mg/ml</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Rate (ml/hr)</td>
                                            <td><span id="db_eq_1">—</span></td>
                                            <td><span id="db_eq_2">—</span></td>
                                            <td><span id="db_eq_3">—</span></td>
                                            <td><span id="db_eq_4">—</span></td>
                                            <td><span id="db_eq_5">—</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="small text-muted">
                                <span class="badge text-bg-warning text-dark">เหลือง</span> เกิน Recommended (&gt; 20 mcg/kg/min) ·
                                <span class="badge text-bg-danger">แดง</span> เกิน Max dose (&gt; 40 mcg/kg/min) ·
                                MAX concentration = 5 mg/ml
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Dopamine (mcg/kg/min) -->
                <div class="tab-pane fade <?= $tab === 'dopamine' ? 'show active' : '' ?>" id="pane-dopamine" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Dopamine (1–50 mcg/kg/min)</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน · MAX concentration = 3.2 mg/ml ***</div>
                            <div id="dp_dose_alert" class="alert d-none mb-3 fw-bold py-2" role="alert"></div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (mcg/kg/min)</label>
                                    <input type="number" id="dp_dose" class="form-control dc-input-yellow" min="0" step="0.1" value="5">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mg)</label>
                                    <input type="number" id="dp_drug_mg" class="form-control dc-input-yellow" min="0" step="1" value="50">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="dp_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="32">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" class="form-control" value="D5, D10, NS" readonly>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเคสนี้</div>
                                        <div class="val"><span id="dp_mcg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="dp_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="dp_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ยา (ml) · 25 mg/ml</div>
                                        <div class="val"><span id="dp_drug_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">คำนวณย้อนกลับ — จาก Rate → mcg/kg/min</h5>
                            <div class="dc-hint mb-3">*** กรอก Rate (ml/hr) และความเข้มข้น · สูตร = (rate × conc_mg/ml × 1000) ÷ (BW × 60) ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Rate (ml/hr)</label>
                                    <input type="number" id="dp_rev_rate" class="form-control dc-input-yellow" min="0" step="1" value="5">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ความเข้มข้น (mg/ml)</label>
                                    <select id="dp_rev_conc" class="form-select dc-input-yellow">
                                        <option value="1" selected>1 mg : 1 ml</option>
                                        <option value="2">2 mg : 1 ml</option>
                                        <option value="3">3 mg : 1 ml</option>
                                        <option value="3.2">3.2 mg : 1 ml (MAX)</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" id="dp_rev_result_box">
                                        <div class="small text-muted">ได้ขนาดยา</div>
                                        <div class="val"><span id="dp_rev_dose">—</span> mcg/kg/min</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div id="dp_rev_alert" class="dc-note mb-0 d-none"></div>
                                </div>
                            </div>
                            <h6 class="fw-bold mb-2">เทียบเท่า Rate ที่ความเข้มข้นอื่น (ปริมาณยาเท่ากัน)</h6>
                            <div class="table-responsive mb-2">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ความเข้มข้น</th>
                                            <th>1 mg/ml</th>
                                            <th>2 mg/ml</th>
                                            <th>3 mg/ml</th>
                                            <th>3.2 mg/ml (MAX)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Rate (ml/hr)</td>
                                            <td><span id="dp_eq_1">—</span></td>
                                            <td><span id="dp_eq_2">—</span></td>
                                            <td><span id="dp_eq_3">—</span></td>
                                            <td><span id="dp_eq_32">—</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="small text-muted">MAX concentration = 3.2 mg/ml · ช่วงยา 1–50 mcg/kg/min</div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Recommended Drug Dose &amp; Effect</h5>
                            <div class="table-responsive mb-3">
                                <table class="table table-sm table-bordered bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Dosage (mcg/kg/min)</th>
                                            <th>Effect</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><strong>Low dose (1–5)</strong></td>
                                            <td>↑ urine output, renal blood flow</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Medium dose (5–15)</strong></td>
                                            <td>↑ renal blood flow, cardiac output, HR, cardiac contractility</td>
                                        </tr>
                                        <tr>
                                            <td><strong>High dose (20–50)</strong></td>
                                            <td>↑ BP, stimulate vasoconstriction</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row g-2 small">
                                <div class="col-md-4"><strong>Dopaminergic:</strong> 0.5–2 mcg/kg/min</div>
                                <div class="col-md-4"><strong>Beta1:</strong> 2–10 mcg/kg/min</div>
                                <div class="col-md-4"><strong>Alpha:</strong> &gt; 10 mcg/kg/min</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Norepinephrine / NE (mcg/kg/min) -->
                <div class="tab-pane fade <?= $tab === 'norepinephrine' ? 'show active' : '' ?>" id="pane-norepinephrine" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Norepinephrine (NE) (0.01–3 mcg/kg/min)</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน · Peripheral ≤ 32 mcg/ml · Central &gt; 32 · MAX 64 mcg/ml (ชีตรวม 80) ***</div>
                            <div id="ne_dose_alert" class="alert d-none mb-3 fw-bold py-2" role="alert"></div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (mcg/kg/min)</label>
                                    <input type="number" id="ne_dose" class="form-control dc-input-yellow" min="0" step="0.01" value="0.1">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mg)</label>
                                    <input type="number" id="ne_drug_mg" class="form-control dc-input-yellow" min="0" step="0.1" value="4">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="ne_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="250">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" class="form-control" value="D5, D10, NS" readonly>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเคสนี้</div>
                                        <div class="val"><span id="ne_mcg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="ne_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="ne_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ยา (ml) · 1 mg/ml</div>
                                        <div class="val"><span id="ne_drug_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                            <div id="ne_line_note" class="dc-note mt-3 mb-0 d-none"></div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">คำนวณย้อนกลับ — จาก Rate → mcg/kg/min</h5>
                            <div class="dc-hint mb-3">*** สูตร = (rate × conc_mcg/ml) ÷ (BW × 60) ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Rate (ml/hr)</label>
                                    <input type="number" id="ne_rev_rate" class="form-control dc-input-yellow" min="0" step="1" value="5">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mb-1">ความเข้มข้น (mcg/ml)</label>
                                    <select id="ne_rev_conc" class="form-select dc-input-yellow">
                                        <option value="16" selected>16 mcg/ml — 4 mg in 250 ml (Peripheral)</option>
                                        <option value="32">32 mcg/ml — 8 mg in 250 ml (Peripheral)</option>
                                        <option value="40">40 mcg/ml — 4 mg in 100 ml (Central)</option>
                                        <option value="64">64 mcg/ml — 16 mg in 250 ml (Central · MAX)</option>
                                        <option value="80">80 mcg/ml — 8 mg in 100 ml (Central)</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" id="ne_rev_result_box">
                                        <div class="small text-muted">ได้ขนาดยา</div>
                                        <div class="val"><span id="ne_rev_dose">—</span> mcg/kg/min</div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div id="ne_rev_alert" class="dc-note mb-0 d-none"></div>
                                </div>
                            </div>
                            <h6 class="fw-bold mb-2">เทียบเท่า Rate ที่ความเข้มข้นอื่น (ปริมาณยาเท่ากัน)</h6>
                            <div class="table-responsive mb-2">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ความเข้มข้น</th>
                                            <th>16</th>
                                            <th>32</th>
                                            <th>40</th>
                                            <th>64</th>
                                            <th>80</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Rate (ml/hr)</td>
                                            <td><span id="ne_eq_16">—</span></td>
                                            <td><span id="ne_eq_32">—</span></td>
                                            <td><span id="ne_eq_40">—</span></td>
                                            <td><span id="ne_eq_64">—</span></td>
                                            <td><span id="ne_eq_80">—</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="small text-muted">
                                <span class="badge bg-light text-dark border">ขาว</span> &lt; 1 ·
                                <span class="badge text-bg-warning text-dark">เหลือง</span> 1–1.99 ·
                                <span class="badge" style="background:#fd7e14;color:#fff;">ส้ม</span> 2–2.99 ·
                                <span class="badge text-bg-danger">แดง</span> ≥ 3 mcg/kg/min
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">ความเข้มข้นมาตรฐาน &amp; สายน้ำเกลือ</h5>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Conc</th>
                                            <th>การเตรียม</th>
                                            <th>สาย</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><strong>16 mcg/ml</strong></td>
                                            <td>4 mg in 250 ml</td>
                                            <td>Peripheral (≤ 32)</td>
                                        </tr>
                                        <tr>
                                            <td><strong>32 mcg/ml</strong></td>
                                            <td>8 mg in 250 ml</td>
                                            <td>Peripheral (≤ 32)</td>
                                        </tr>
                                        <tr>
                                            <td><strong>40 mcg/ml</strong></td>
                                            <td>4 mg in 100 ml</td>
                                            <td>Central (&gt; 32)</td>
                                        </tr>
                                        <tr>
                                            <td><strong>64 mcg/ml</strong></td>
                                            <td>16 mg in 250 ml</td>
                                            <td>Central · MAX</td>
                                        </tr>
                                        <tr>
                                            <td><strong>80 mcg/ml</strong></td>
                                            <td>8 mg in 100 ml</td>
                                            <td>Central (ชีตรวม)</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Cisatracurium (mcg/kg/min) -->
                <div class="tab-pane fade <?= $tab === 'cisatracurium' ? 'show active' : '' ?>" id="pane-cisatracurium" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Cisatracurium — mcg/kg/min</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (mcg/kg/min)</label>
                                    <input type="number" id="cs_dose" class="form-control dc-input-yellow" min="0" step="0.1" value="1">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mg)</label>
                                    <input type="number" id="cs_drug_mg" class="form-control dc-input-yellow" min="0" step="1" value="30">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="cs_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="30">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" class="form-control" value="D5, NS" readonly>
                                </div>
                            </div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเคสนี้</div>
                                        <div class="val"><span id="cs_mcg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="cs_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="cs_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ยา (ml) · 2 mg/ml</div>
                                        <div class="val"><span id="cs_drug_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Adrenaline (mcg/kg/min) -->
                <div class="tab-pane fade <?= $tab === 'adrenaline' ? 'show active' : '' ?>" id="pane-adrenaline" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Adrenaline — mcg/kg/min</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (mcg/kg/min)</label>
                                    <input type="number" id="ad_dose" class="form-control dc-input-yellow" min="0" step="0.1" value="1">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mg)</label>
                                    <input type="number" id="ad_drug_mg" class="form-control dc-input-yellow" min="0" step="0.1" value="4">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="ad_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="28">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" class="form-control" value="D5, D10, NS" readonly>
                                </div>
                            </div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเคสนี้</div>
                                        <div class="val"><span id="ad_mcg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="ad_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="ad_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ยา (ml) · 1 mg/ml</div>
                                        <div class="val"><span id="ad_drug_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Calcium gluconate -->
                <div class="tab-pane fade <?= $tab === 'calcium_glu' ? 'show active' : '' ?>" id="pane-calcium-glu" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Calcium glu — 100 mg/ml</h5>
                            <div class="dc-hint mb-3">*** น้ำหนักใช้จากด้านบน · Initial 100–200 mg/kg/dose · Maintenance 200–800 mg/kg/day ***</div>
                            <div class="dc-note mb-3">drip 10–60 นาที · ติดตาม HR · สารน้ำ: D5W, D10W, NS</div>
                            <div class="row g-3">
                                <div class="col-lg-6">
                                    <h6 class="fw-bold">Initial (100–200 mg/kg/dose)</h6>
                                    <div class="row g-2">
                                        <div class="col-6">
                                            <div class="dc-result">
                                                <div class="small text-muted">100 mg/kg → mg</div>
                                                <div class="val"><span id="cg_init_min_mg">—</span></div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="dc-result">
                                                <div class="small text-muted">200 mg/kg → mg</div>
                                                <div class="val"><span id="cg_init_max_mg">—</span></div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                                <div class="small fw-bold text-success">min (ml)</div>
                                                <div class="val" style="color:#166534;"><span id="cg_init_min_ml">—</span></div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                                <div class="small fw-bold text-success">MAX (ml)</div>
                                                <div class="val" style="color:#166534;"><span id="cg_init_max_ml">—</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <h6 class="fw-bold">Maintenance (200–800 mg/kg/day)</h6>
                                    <div class="row g-2">
                                        <div class="col-6">
                                            <div class="dc-result">
                                                <div class="small text-muted">200 mg/kg → mg</div>
                                                <div class="val"><span id="cg_maint_min_mg">—</span></div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="dc-result">
                                                <div class="small text-muted">800 mg/kg → mg</div>
                                                <div class="val"><span id="cg_maint_max_mg">—</span></div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                                <div class="small fw-bold text-success">min (ml)</div>
                                                <div class="val" style="color:#166534;"><span id="cg_maint_min_ml">—</span></div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                                <div class="small fw-bold text-success">MAX (ml)</div>
                                                <div class="val" style="color:#166534;"><span id="cg_maint_max_ml">—</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Alprostadil (mcg/kg/min) -->
                <div class="tab-pane fade <?= $tab === 'alprostadil' ? 'show active' : '' ?>" id="pane-alprostadil" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Alprostadil — 0.05–0.1 mcg/kg/min (prep 2–20 mcg/ml)</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (mcg/kg/min)</label>
                                    <input type="number" id="ap_dose" class="form-control dc-input-yellow" min="0" step="0.01" value="0.01">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mg)</label>
                                    <input type="number" id="ap_drug_mg" class="form-control dc-input-yellow" min="0" step="0.001" value="0.032">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="ap_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="15">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" class="form-control" value="D5W, NS" readonly>
                                </div>
                            </div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเคสนี้</div>
                                        <div class="val"><span id="ap_mcg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="ap_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="ap_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ยา (ml) · 0.5 mg/ml</div>
                                        <div class="val"><span id="ap_drug_ml">—</span> ml</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Indomethacin -->
                <div class="tab-pane fade <?= $tab === 'indomethacin' ? 'show active' : '' ?>" id="pane-indomethacin" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Indomethacin ฉีด — 3 doses/course (MAX 2 course)</h5>
                            <div class="dc-hint mb-3">*** น้ำหนักใช้จากด้านบน · ความเข้มข้น 0.5 mg/ml ***</div>
                            <div class="dc-note mb-3">
                                Infuse [0.5–1 mg/ml] over 20–30 นาที · แนะนำ SWI<br>
                                ใช้ได้ หากไม่แยกตะกอน (2.5DW, D5W, NS)
                            </div>

                            <h6 class="fw-bold mb-2">ยา (mg/kg) — ตาม Age at 1st dose</h6>
                            <div class="table-responsive mb-3">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Age at 1st dose</th>
                                            <th>1st dose</th>
                                            <th>2nd dose</th>
                                            <th>3rd dose</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr><td>&lt; 48 hr</td><td>0.2</td><td>0.1</td><td>0.1</td></tr>
                                        <tr><td>2–7 days</td><td>0.2</td><td>0.2</td><td>0.2</td></tr>
                                        <tr><td>&gt; 7 days</td><td>0.2</td><td>0.25</td><td>0.25</td></tr>
                                    </tbody>
                                </table>
                            </div>

                            <h6 class="fw-bold mb-2">ยา (mg) = mg/kg × น้ำหนัก</h6>
                            <div class="table-responsive mb-3">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Age at 1st dose</th>
                                            <th>1st dose</th>
                                            <th>2nd dose</th>
                                            <th>3rd dose</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>&lt; 48 hr</td>
                                            <td><span id="in_mg_lt48_1">—</span></td>
                                            <td><span id="in_mg_lt48_2">—</span></td>
                                            <td><span id="in_mg_lt48_3">—</span></td>
                                        </tr>
                                        <tr>
                                            <td>2–7 days</td>
                                            <td><span id="in_mg_2to7_1">—</span></td>
                                            <td><span id="in_mg_2to7_2">—</span></td>
                                            <td><span id="in_mg_2to7_3">—</span></td>
                                        </tr>
                                        <tr>
                                            <td>&gt; 7 days</td>
                                            <td><span id="in_mg_gt7_1">—</span></td>
                                            <td><span id="in_mg_gt7_2">—</span></td>
                                            <td><span id="in_mg_gt7_3">—</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <h6 class="fw-bold mb-2">ยา (ml) = mg ÷ 0.5 <span class="text-muted fw-normal">(ทศนิยม 3 ตำแหน่ง)</span></h6>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Age at 1st dose</th>
                                            <th>1st dose</th>
                                            <th>2nd dose</th>
                                            <th>3rd dose</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>&lt; 48 hr</td>
                                            <td><span id="in_ml_lt48_1">—</span></td>
                                            <td><span id="in_ml_lt48_2">—</span></td>
                                            <td><span id="in_ml_lt48_3">—</span></td>
                                        </tr>
                                        <tr>
                                            <td>2–7 days</td>
                                            <td><span id="in_ml_2to7_1">—</span></td>
                                            <td><span id="in_ml_2to7_2">—</span></td>
                                            <td><span id="in_ml_2to7_3">—</span></td>
                                        </tr>
                                        <tr>
                                            <td>&gt; 7 days</td>
                                            <td><span id="in_ml_gt7_1">—</span></td>
                                            <td><span id="in_ml_gt7_2">—</span></td>
                                            <td><span id="in_ml_gt7_3">—</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- NAC Paraoverdose -->
                <div class="tab-pane fade <?= $tab === 'nac' ? 'show active' : '' ?>" id="pane-nac" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">N-acetylcysteine (NAC) — 300 mg/3 ml (100 mg/ml)</h5>
                            <div class="dc-hint mb-3">*** น้ำหนักใช้จากด้านบน · ระบบเลือกช่วงน้ำหนักให้อัตโนมัติ · BW ≥ 110 kg ให้ใช้ 110 kg คิด ***</div>
                            <div class="dc-note mb-3">
                                <strong>Indication:</strong> Paracetamol intake &gt; 7.5 gm และวัดระดับไม่ได้ หรือ blood level &gt; 140 mcg/ml
                            </div>
                            <div class="alert alert-info fw-bold mb-3 py-2" id="nac_category">—</div>

                            <div class="table-responsive mb-3">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Dose</th>
                                            <th>ขนาด (mg/kg)</th>
                                            <th>mg</th>
                                            <th>ml</th>
                                            <th>สารน้ำ / เวลา</th>
                                            <th>จ่าย (amp)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1st dose</td>
                                            <td>150</td>
                                            <td><span id="nac_d1_mg">—</span></td>
                                            <td><span id="nac_d1_ml">—</span></td>
                                            <td><span id="nac_d1_fluid">—</span></td>
                                            <td><span id="nac_d1_amp">—</span></td>
                                        </tr>
                                        <tr>
                                            <td>2nd dose</td>
                                            <td>50</td>
                                            <td><span id="nac_d2_mg">—</span></td>
                                            <td><span id="nac_d2_ml">—</span></td>
                                            <td><span id="nac_d2_fluid">—</span></td>
                                            <td><span id="nac_d2_amp">—</span></td>
                                        </tr>
                                        <tr>
                                            <td>3rd dose</td>
                                            <td>100</td>
                                            <td><span id="nac_d3_mg">—</span></td>
                                            <td><span id="nac_d3_ml">—</span></td>
                                            <td><span id="nac_d3_fluid">—</span></td>
                                            <td><span id="nac_d3_amp">—</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="row g-3 mb-4">
                                <div class="col-md-4">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">จำนวนยาที่ต้องจ่ายรวม</div>
                                        <div class="val" style="color:#166534;"><span id="nac_total_amp">—</span> amp</div>
                                    </div>
                                </div>
                            </div>

                            <h6 class="fw-bold mb-2 text-danger">กรณีเอนไซม์ตับเพิ่มขึ้น &gt; 1000 IU/L</h6>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ขนาด</th>
                                            <th>mg</th>
                                            <th>ml</th>
                                            <th>สารน้ำ / เวลา</th>
                                            <th>จ่าย (amp)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>150 mg/kg</td>
                                            <td><span id="nac_liv_mg">—</span></td>
                                            <td><span id="nac_liv_ml">—</span></td>
                                            <td>+ D5W 1000 ml drip in 24 hr</td>
                                            <td><span id="nac_liv_amp">—</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <p class="small text-muted mt-2 mb-0">อ้างอิง: Ramathibodi Poison Center</p>
                        </div>
                    </div>
                </div>

                <!-- LBW / Anesthesia -->
                <div class="tab-pane fade <?= $tab === 'lbw' ? 'show active' : '' ?>" id="pane-lbw" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Lean Body Weight (LBW) — วิสัญญี</h5>
                            <div class="dc-hint mb-3">*** น้ำหนัก/ส่วนสูงใช้จากด้านบน · เลือกเพศเพื่อคำนวณ rate ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">เพศ</label>
                                    <select id="lbw_sex" class="form-select dc-input-yellow">
                                        <option value="M">ชาย (Men)</option>
                                        <option value="F">หญิง (Women)</option>
                                    </select>
                                    <div class="dc-source-hint" id="lbw_sex_hint"></div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">LBW Men</div>
                                        <div class="val"><span id="lbw_men">—</span> kg</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">LBW Women</div>
                                        <div class="val"><span id="lbw_women">—</span> kg</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">LBW ที่ใช้คำนวณ (kg)</label>
                                    <input type="number" id="lbw_override" class="form-control dc-input-yellow" min="0" step="0.01" placeholder="—">
                                    <div class="dc-source-hint">แก้ได้ · ค่าเริ่มจากสูตรตามเพศ</div>
                                </div>
                            </div>
                            <div class="dc-note mb-0 small">
                                สูตร James: Men = 1.10×ABW − 128×(ABW/H)² · Women = 1.07×ABW − 148×(ABW/H)²<br>
                                IBW คร่าวๆ: Men = ส่วนสูง−100 · Women = ส่วนสูง−105 · หาก IBW ต่างจาก BW มาก ให้พิจารณาใช้ IBW
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Atracurium — 0.3–0.7 mg/kg/hr (50 mg/5 ml = 10 mg/ml)</h5>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">เริ่ม 0.3 mg/kg/hr</div>
                                        <div class="val"><span id="at_start_mg">—</span> mg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">Max 0.7 mg/kg/hr</div>
                                        <div class="val"><span id="at_max_mg">—</span> mg/hr</div>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ความเข้มข้น</th>
                                            <th>เริ่ม (ml/hr)</th>
                                            <th>Max (ml/hr)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr><td>[1:1] = 1 mg/ml</td><td><span id="at_11_s">—</span></td><td><span id="at_11_m">—</span></td></tr>
                                        <tr><td>[1:2] = 0.5 mg/ml</td><td><span id="at_12_s">—</span></td><td><span id="at_12_m">—</span></td></tr>
                                        <tr><td>[2:1] = 2 mg/ml</td><td><span id="at_21_s">—</span></td><td><span id="at_21_m">—</span></td></tr>
                                        <tr><td>[10:1] undiluted = 10 mg/ml</td><td><span id="at_101_s">—</span></td><td><span id="at_101_m">—</span></td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Propofol — 25–100 mcg/kg/min (= 1.5–6 mg/kg/hr)</h5>
                            <div class="dc-hint mb-3">*** ใช้น้ำหนักตัวจริง (ABW) จากด้านบน · [10:1] undiluted = 10 mg/ml ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">เริ่ม 1.5 mg/kg/hr</div>
                                        <div class="val"><span id="pf_start_mg">—</span> mg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">Max 6 mg/kg/hr</div>
                                        <div class="val"><span id="pf_max_mg">—</span> mg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">เริ่ม (10 mg/ml)</div>
                                        <div class="val" style="color:#166534;"><span id="pf_start_ml">—</span> ml/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Max (10 mg/ml)</div>
                                        <div class="val" style="color:#166534;"><span id="pf_max_ml">—</span> ml/hr</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">First dosage — Ketamine (200–750 mcg/kg over 3 minutes)</h5>
                            <div class="dc-hint mb-3">*** ใช้ LBW · ความเข้มข้น 50 mg/ml ***</div>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th></th>
                                            <th>min dosage (200 mcg/kg)</th>
                                            <th>MAX dosage (750 mcg/kg)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>mcg</td>
                                            <td><span id="kt_min_mcg">—</span></td>
                                            <td><span id="kt_max_mcg">—</span></td>
                                        </tr>
                                        <tr>
                                            <td>mg</td>
                                            <td><span id="kt_min_mg">—</span></td>
                                            <td><span id="kt_max_mg">—</span></td>
                                        </tr>
                                        <tr>
                                            <td>ml</td>
                                            <td><span id="kt_min_ml">—</span></td>
                                            <td><span id="kt_max_ml">—</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Maintenance — Ketamine (5–20 mcg/kg/min = 0.3–1.2 mg/kg/hr)</h5>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">เริ่ม 0.3 mg/kg/hr</div>
                                        <div class="val"><span id="ktm_start_mg">—</span> mg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">Max 1.2 mg/kg/hr</div>
                                        <div class="val"><span id="ktm_max_mg">—</span> mg/hr</div>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ความเข้มข้น</th>
                                            <th>เริ่ม (ml/hr)</th>
                                            <th>Max (ml/hr)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr><td>[2:1] = 2 mg/ml</td><td><span id="ktm_21_s">—</span></td><td><span id="ktm_21_m">—</span></td></tr>
                                        <tr><td>[1:1] = 1 mg/ml</td><td><span id="ktm_11_s">—</span></td><td><span id="ktm_11_m">—</span></td></tr>
                                    </tbody>
                                </table>
                            </div>
                            <p class="small text-muted mt-2 mb-0">อ้างอิง Cisatracurium: 1–2 mcg/kg/min (ใช้แท็บ Cisatracurium สำหรับคำนวณ rate)</p>
                        </div>
                    </div>
                </div>

                <!-- Iloprost (ng/kg/min) -->
                <div class="tab-pane fade <?= $tab === 'iloprost' ? 'show active' : '' ?>" id="pane-iloprost" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Iloprost — ng/kg/min</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · น้ำหนักใช้จากด้านบน ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (ng/kg/min)</label>
                                    <input type="number" id="il_dose" class="form-control dc-input-yellow" min="0" step="0.1" value="2">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mcg)</label>
                                    <input type="number" id="il_drug_mcg" class="form-control dc-input-yellow" min="0" step="1" value="20">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="il_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="50">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" id="il_fluid" class="form-control" value="D5, NS" readonly>
                                </div>
                            </div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเฉลี่ย</div>
                                        <div class="val"><span id="il_mcg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="il_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="il_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- KCL (mEq/hr) -->
                <div class="tab-pane fade <?= $tab === 'kcl' ? 'show active' : '' ?>" id="pane-kcl" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">KCL — mEq/hr</h5>
                            <div class="dc-hint mb-3">*** สูตร = (conc_mEq/L × rate_ml/hr) ÷ 1000 · Peripheral &lt; 10 mEq/hr · Central 10–20 mEq/hr ***</div>
                            <div id="kcl_dose_alert" class="alert d-none mb-3 fw-bold py-2" role="alert"></div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" id="kcl_renal" value="1">
                                <label class="form-check-label fw-bold" for="kcl_renal">ผู้ป่วยไตเสื่อม — ลดขนาดเหลือ 50%</label>
                            </div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ความเข้มข้น (mEq/L)</label>
                                    <select id="kcl_conc" class="form-select dc-input-yellow">
                                        <option value="20" selected>20 mEq/L (Peripheral · Mild–Mod)</option>
                                        <option value="40">40 mEq/L (Peripheral · Severe)</option>
                                        <option value="60">60 mEq/L (Peripheral · Severe)</option>
                                        <option value="80">80 mEq/L (Central)</option>
                                        <option value="100">100 mEq/L (Central)</option>
                                        <option value="120">120 mEq/L (Central)</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Rate (ml/hr)</label>
                                    <input type="number" id="kcl_rate" class="form-control dc-input-yellow" min="0" step="1" value="50">
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" id="kcl_result_box">
                                        <div class="small text-muted">ได้ขนาดยา</div>
                                        <div class="val"><span id="kcl_meq_hr">—</span> mEq/hr</div>
                                        <div class="small text-muted d-none" id="kcl_meq_hr_half_wrap">หลังลด 50%: <strong id="kcl_meq_hr_half">—</strong> mEq/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div id="kcl_line_note" class="dc-note mb-0 d-none"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">คำนวณย้อนกลับ — จาก mEq/hr → Rate</h5>
                            <div class="dc-hint mb-3">*** Rate (ml/hr) = (mEq/hr × 1000) ÷ conc_mEq/L ***</div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ต้องการ (mEq/hr)</label>
                                    <input type="number" id="kcl_rev_meq" class="form-control dc-input-yellow" min="0" step="0.1" value="10">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ความเข้มข้น (mEq/L)</label>
                                    <select id="kcl_rev_conc" class="form-select dc-input-yellow">
                                        <option value="20">20</option>
                                        <option value="40" selected>40</option>
                                        <option value="60">60</option>
                                        <option value="80">80</option>
                                        <option value="100">100</option>
                                        <option value="120">120</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="kcl_rev_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div id="kcl_rev_alert" class="dc-note mb-0 d-none"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">คำนวณความเข้มข้นจากการผสม</h5>
                            <div class="dc-hint mb-3">*** conc (mEq/L) = (KCL mEq × 1000) ÷ volume_ml ***</div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">KCL (mEq)</label>
                                    <input type="number" id="kcl_mix_meq" class="form-control dc-input-yellow" min="0" step="1" value="20">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาตรสารน้ำ (ml)</label>
                                    <input type="number" id="kcl_mix_vol" class="form-control dc-input-yellow" min="0" step="1" value="1000">
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="kcl_mix_conc">—</span> mEq/L</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">แนวทางความเข้มข้น &amp; สายน้ำเกลือ</h5>
                            <div class="table-responsive mb-3">
                                <table class="table table-sm table-bordered bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>สาย</th>
                                            <th>Conc (mEq/L)</th>
                                            <th>Rate</th>
                                            <th>ข้อบ่งชี้</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td rowspan="2"><strong>Peripheral</strong><br><span class="small text-muted">&lt; 10 mEq/hr</span></td>
                                            <td>20</td>
                                            <td>&lt; 10 mEq/hr</td>
                                            <td>Mild–Moderate Hypo K+ (serum K+ 2.5–3.4)</td>
                                        </tr>
                                        <tr>
                                            <td>40 / 60</td>
                                            <td>&lt; 10 mEq/hr</td>
                                            <td>Severe Hypo K+ (serum K+ &lt; 2.5)</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Central</strong></td>
                                            <td>80 / 100 / 120</td>
                                            <td>10–20 mEq/hr</td>
                                            <td>Closely monitor · Rate &gt; 10 ต้อง Central line</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="small">
                                <div class="dc-note mb-2">Note 1: อาจผสม 1% Lidocaine 1 ml ใน KCL 10–20 mEq/100 ml เพื่อลดโอกาส Phlebitis</div>
                                <div class="dc-note mb-2">Note 2: ผู้ป่วยไตเสื่อม — ลดขนาด K+ เหลือ 50% ของขนาดปกติ</div>
                                <div class="dc-note mb-0">Note 3: ห้ามผสมในสารน้ำที่มี Dextrose (กระตุ้น insulin → อาจแย่ลง Hypokalemia)</div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">ตารางอ้างอิง mEq/hr</h5>
                            <div class="table-responsive mb-2">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0 text-center">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Rate \ Conc</th>
                                            <th>20</th>
                                            <th>40</th>
                                            <th>60</th>
                                            <th>80</th>
                                            <th>100</th>
                                            <th>120</th>
                                        </tr>
                                    </thead>
                                    <tbody id="kcl_ref_tbody"></tbody>
                                </table>
                            </div>
                            <div class="small text-muted">
                                <span class="badge bg-light text-dark border">ขาว</span> Peripheral &lt; 10 ·
                                <span class="badge text-bg-warning text-dark">เหลือง</span> Central 10–20 ·
                                <span class="badge text-bg-danger">แดง</span> &gt; 20 mEq/hr
                            </div>
                        </div>
                    </div>
                </div>

                <!-- NTG / Nitroglycerine (mcg/min) -->
                <div class="tab-pane fade <?= $tab === 'ntg' ? 'show active' : '' ?>" id="pane-ntg" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Nitroglycerine (NTG) — mcg/min</h5>
                            <div class="dc-hint mb-3">*** เติมข้อมูลในช่องสีเหลือง · MAX concentration = 400 mcg/ml · ใช้ขวดแก้ว / non-PVC set ***</div>
                            <div id="ntg_dose_alert" class="alert d-none mb-3 fw-bold py-2" role="alert"></div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ขนาดยา (mcg/min)</label>
                                    <input type="number" id="ntg_dose" class="form-control dc-input-yellow" min="0" step="1" value="5">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาณยา (mg)</label>
                                    <input type="number" id="ntg_drug_mg" class="form-control dc-input-yellow" min="0" step="0.1" value="50">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Total สารน้ำ (ml)</label>
                                    <input type="number" id="ntg_total_ml" class="form-control dc-input-yellow" min="0" step="1" value="250">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">สารน้ำ</label>
                                    <input type="text" class="form-control" value="D5W, NSS" readonly>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ขนาดยาเคสนี้</div>
                                        <div class="val"><span id="ntg_mcg_hr">—</span> mcg/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">ความเข้มข้น</div>
                                        <div class="val"><span id="ntg_conc">—</span> mcg/ml</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rate เครื่อง</div>
                                        <div class="val" style="color:#166534;"><span id="ntg_rate">—</span> ml/hr</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div id="ntg_conc_note" class="dc-note mb-0 d-none"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">คำนวณย้อนกลับ — จาก Rate → mcg/min</h5>
                            <div class="dc-hint mb-3">*** สูตร = (rate × conc_mcg/ml) ÷ 60 ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">Rate (ml/hr)</label>
                                    <input type="number" id="ntg_rev_rate" class="form-control dc-input-yellow" min="0" step="0.5" value="1">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mb-1">ความเข้มข้น (mcg/ml)</label>
                                    <select id="ntg_rev_conc" class="form-select dc-input-yellow">
                                        <option value="50">50 mcg/ml — 1 mg : 20 ml</option>
                                        <option value="100">100 mcg/ml — 1 mg : 10 ml</option>
                                        <option value="200" selected>200 mcg/ml — 1 mg : 5 ml</option>
                                        <option value="400">400 mcg/ml — MAX</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result" id="ntg_rev_result_box">
                                        <div class="small text-muted">ได้ขนาดยา</div>
                                        <div class="val"><span id="ntg_rev_dose">—</span> mcg/min</div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div id="ntg_rev_alert" class="dc-note mb-0 d-none"></div>
                                </div>
                            </div>
                            <h6 class="fw-bold mb-2">เทียบเท่า Rate ที่ความเข้มข้นอื่น (ปริมาณยาเท่ากัน)</h6>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered dc-ref-table bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ความเข้มข้น</th>
                                            <th>50</th>
                                            <th>100</th>
                                            <th>200</th>
                                            <th>400 (MAX)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Rate (ml/hr)</td>
                                            <td><span id="ntg_eq_50">—</span></td>
                                            <td><span id="ntg_eq_100">—</span></td>
                                            <td><span id="ntg_eq_200">—</span></td>
                                            <td><span id="ntg_eq_400">—</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">Adult dosing &amp; titration</h5>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Indication</th>
                                            <th>เริ่ม (mcg/min)</th>
                                            <th>Titration</th>
                                            <th>Max</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Angina / CAD</td>
                                            <td>5</td>
                                            <td>↑ 5 ทุก 3–5 นาที จน 20 แล้ว ↑ 10–20 ทุก 3–5 นาที</td>
                                            <td>400</td>
                                        </tr>
                                        <tr>
                                            <td>Acute decompensated HF</td>
                                            <td>10–20</td>
                                            <td>↑ 10–20 ทุก 5–15 นาที</td>
                                            <td>200</td>
                                        </tr>
                                        <tr>
                                            <td>HTN, Perioperative</td>
                                            <td>5</td>
                                            <td>↑ 5 ทุก 3–5 นาที จน 20 แล้ว ↑ 10–20</td>
                                            <td>—</td>
                                        </tr>
                                        <tr>
                                            <td>Hypotension induction &amp; maintenance, Intraop</td>
                                            <td>5</td>
                                            <td>↑ 5 ทุก 3–5 นาที จน 20 แล้ว ↑ 10–20</td>
                                            <td>—</td>
                                        </tr>
                                        <tr>
                                            <td>Pulmonary edema</td>
                                            <td>5–10</td>
                                            <td>↑ 5 ทุก 3–5 นาที</td>
                                            <td>200</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">การเตรียม &amp; ความคงตัว</h5>
                            <div class="dc-note mb-2">ต้องใช้ <strong>ขวดแก้ว</strong> หรือ <strong>non-PVC IV set</strong> (เช่น Polyolefin) — NTG ถูกดูดซึมโดยสาย PVC ปกติ</div>
                            <div class="dc-note mb-2">เจือจางกับ D5W / NSS · ความเข้มข้นแนะนำไม่เกิน <strong>400 mcg/ml</strong> (absolute สูงสุดประมาณ 500 mcg/ml = 1:2)</div>
                            <div class="dc-note mb-0">
                                Stability: แก้ว 48 ชม. อุณหภูมิห้อง / 7 วันแช่เย็น · พลาสติก 24 ชม. อุณหภูมิห้อง
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ARV เด็ก -->
                <div class="tab-pane fade <?= $tab === 'arv_ped' ? 'show active' : '' ?>" id="pane-arv-ped" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">ARV เด็ก — Prophylaxis ทารกจากมารดาเสี่ยง</h5>
                            <div class="dc-hint mb-3">*** น้ำหนักใช้จากด้านบน · คำนวณ mg = BW × mg/kg · ml = mg ÷ ความเข้มข้น · จ่ายขวดคิด 4 สัปดาห์ ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-3">
                                    <label class="form-label fw-bold mb-1">ปริมาตรขวดน้ำเชื่อม (ml)</label>
                                    <input type="number" id="arv_bottle_ml" class="form-control dc-input-yellow" min="1" step="1" value="60">
                                    <div class="dc-source-hint">ใช้คำนวณจำนวนขวด 4 สัปดาห์</div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">น้ำหนักที่ใช้</div>
                                        <div class="val"><span id="arv_bw">—</span> kg</div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="dc-result">
                                        <div class="small text-muted">BSA</div>
                                        <div class="val"><span id="arv_bsa">—</span> m²</div>
                                    </div>
                                </div>
                            </div>
                            <div class="row g-2 mb-3 small">
                                <div class="col-md-6">
                                    <div class="dc-note mb-0">
                                        <strong>Standard risk:</strong> มารดา VL &lt; 50 copies/ml ใกล้คลอด / ได้ ART ต่อเนื่องดี
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="dc-note mb-0" style="background:#fecaca;border-left-color:#dc2626;">
                                        <strong>High risk:</strong> VL ≥ 50 / ไม่ได้ ART / ART ไม่ต่อเนื่อง / acute infection
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ข้อบ่งใช้</th>
                                            <th>ยา</th>
                                            <th>Conc</th>
                                            <th>mg/kg/dose</th>
                                            <th>ความถี่</th>
                                            <th>mg</th>
                                            <th>ml</th>
                                            <th>ขวด (4 wk)</th>
                                        </tr>
                                    </thead>
                                    <tbody id="arv_calc_tbody"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">ภาคผนวก — ขนาดยาน้ำตามช่วงน้ำหนัก (เช้า–เย็น)</h5>
                            <div class="dc-hint mb-3">*** อ้างอิงตารางน้ำหนัก · ไฮไลต์แถวที่ตรงกับ BW ปัจจุบัน ***</div>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered bg-white mb-0 text-center" id="arv_ref_table">
                                    <thead class="table-light">
                                        <tr>
                                            <th>น้ำหนัก (กก.)</th>
                                            <th>AZT 10 มก./มล.</th>
                                            <th>3TC 10 มก./มล.</th>
                                            <th>LPV/r 80/20 มก./มล.</th>
                                            <th>NVP 10 มก./มล.</th>
                                        </tr>
                                    </thead>
                                    <tbody id="arv_ref_tbody"></tbody>
                                </table>
                            </div>
                            <p class="small text-muted mt-2 mb-0">หน่วยเป็น ซีซี เช้า–เย็น (BID) · ตรวจสอบกับแนวทางของหน่วยงานก่อนจ่าย</p>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">เด็กติดเชื้อ HIV (อายุ &gt; 1 ปี) — คำนวณจาก BSA / น้ำหนัก</h5>
                            <div class="dc-hint mb-3">*** BSA = √(BW × Height ÷ 3600) · ใช้น้ำหนัก/ส่วนสูงจากด้านบน ***</div>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ยา</th>
                                            <th>สูตร</th>
                                            <th>ความถี่</th>
                                            <th>ขนาด/ครั้ง</th>
                                            <th>ml (ถ้าเป็นน้ำเชื่อม)</th>
                                        </tr>
                                    </thead>
                                    <tbody id="arv_tx_tbody"></tbody>
                                </table>
                            </div>
                            <p class="small text-muted mt-2 mb-0">AZT / NVP คิดจาก BSA · 3TC คิดจาก mg/kg · Max ตามแนวทางมาตรฐาน</p>
                        </div>
                    </div>
                </div>

                <!-- TB / anti-TBs -->
                <div class="tab-pane fade <?= $tab === 'tb' ? 'show active' : '' ?>" id="pane-tb" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">สำหรับคำนวณยา anti-TBs</h5>
                            <div class="dc-hint mb-3">*** น้ำหนักใช้จากด้านบน · จำนวนเม็ดปัดและไม่เกิน Max dose/day ***</div>
                            <div class="mb-2"><strong>น้ำหนักที่ใช้:</strong> <span id="tb_bw">—</span> kg</div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ยา</th>
                                            <th>เม็ด (mg)</th>
                                            <th>จำนวนเม็ด</th>
                                            <th>min–MAX เม็ด</th>
                                            <th>mg/kg/day</th>
                                            <th>mg ที่คำนวณ</th>
                                            <th>Max/day</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tb_drug_tbody"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">ยาสูตรผสม</h5>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rifafour (RHZE)</div>
                                        <div class="val" style="color:#166534;"><span id="tb_rifafour">—</span> เม็ด/วัน</div>
                                        <div class="small text-muted" id="tb_rifafour_note"></div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-result" style="background:#dcfce7;border-color:#86efac;">
                                        <div class="small fw-bold text-success">Rifinah</div>
                                        <div class="val" style="color:#166534;"><span id="tb_rifinah">—</span></div>
                                        <div class="small text-muted" id="tb_rifinah_note"></div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="dc-note mb-0 small">
                                        Rifafour 1 เม็ด = H75 + R150 + Z400 + E275<br>
                                        Rifinah 150 ≈ R150/H100 · Rifinah 300 = R300/H150
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive mt-3 mb-0">
                                <table class="table table-sm table-bordered bg-white mb-0 text-center">
                                    <thead class="table-light">
                                        <tr><th>น้ำหนัก</th><th>Rifafour</th><th>Rifinah</th></tr>
                                    </thead>
                                    <tbody>
                                        <tr><td>30–37 kg</td><td>2 เม็ด</td><td>Rifinah 150 × 2</td></tr>
                                        <tr><td>38–54 kg</td><td>3 เม็ด</td><td>Rifinah 150 × 3</td></tr>
                                        <tr><td>55–70 kg</td><td>4 เม็ด</td><td>Rifinah 300 × 2</td></tr>
                                        <tr><td>≥ 71 kg</td><td>5 เม็ด</td><td>Rifinah 300 × 2</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">MDR/RR-TB สูตรระยะสั้นมี Bdq — ขนาดต่อวันตามน้ำหนัก</h5>
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-bordered bg-white mb-0 text-center" id="tb_mdr_table">
                                    <thead class="table-light">
                                        <tr>
                                            <th>ยา</th>
                                            <th>30–35</th>
                                            <th>36–45</th>
                                            <th>46–55</th>
                                            <th>56–70</th>
                                            <th>&gt;70</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tb_mdr_tbody"></tbody>
                                </table>
                            </div>
                            <p class="small text-muted mt-2 mb-0">แถวที่ไฮไลต์ = ช่วงน้ำหนักของผู้ป่วย · Bdq: 400 mg/วัน × 2 สัปดาห์ แล้ว 200 mg 3 ครั้ง/สัปดาห์</p>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="dc-card-title mb-2">นับ Course ยา Anti-TBs</h5>
                            <div class="dc-hint mb-3">*** กรอกวันแรกที่เริ่มทานในช่องสีเหลือง ***</div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mb-1">วันเริ่มทาน</label>
                                    <input type="date" id="tb_start_date" class="form-control dc-input-yellow">
                                </div>
                            </div>
                            <div id="tb_course_boxes"></div>
                        </div>
                    </div>
                </div>

            </div>
            </div><!-- /#dcCalcArea -->
        </div>
    </div>
</div>

<!-- Modal ยืนยันแก้ไขอายุ -->
<div class="modal fade" id="dcAgeConfirmModal" tabindex="-1" aria-labelledby="dcAgeConfirmModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="dcAgeConfirmModalLabel">ยืนยันการแก้ไขอายุ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="mb-2" id="dcAgeConfirmMsg">แก้ไขอายุจากค่า HOSxP — พิมพ์ <strong>confirm</strong> เพื่อยืนยัน</p>
                <input type="text" id="dc_age_confirm" class="form-control form-control-lg" placeholder="พิมพ์ confirm" autocomplete="off" spellcheck="false">
                <div id="dc_age_confirm_err" class="small text-danger mt-2 d-none">กรุณาพิมพ์คำว่า confirm ให้ถูกต้อง</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal" id="dcAgeConfirmCancel">ยกเลิก</button>
                <button type="button" class="btn btn-primary" id="dcAgeConfirmOk">ยืนยัน</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal แจ้งเตือน TNK STEMI อายุ < 18 -->
<div class="modal fade" id="dcTnkPediatricModal" tabindex="-1" aria-labelledby="dcTnkPediatricModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-warning">
            <div class="modal-header bg-warning">
                <h5 class="modal-title fw-bold" id="dcTnkPediatricModalLabel">
                    <i class="fas fa-exclamation-triangle me-1"></i> แจ้งเตือน TNK STEMI
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="mb-2 fw-bold" id="dcTnkPediatricMsg">ไม่มีข้อมูลความปลอดภัย/ประสิทธิภาพในเด็กอายุ &lt; 18 ปี</p>
                <p class="mb-0 text-muted small">โปรดตรวจสอบความเหมาะสมก่อนใช้ยา Tenecteplase (TNK) ในผู้ป่วยรายนี้</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-warning fw-bold" data-bs-dismiss="modal">รับทราบ</button>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/dose_calculator.js?v=20261009a"></script>
</body>
</html>
