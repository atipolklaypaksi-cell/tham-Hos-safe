<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/drug_center_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
tham_menu_ensure_page_access('dc_check_drug_all.php');

$prefill_hn = htmlspecialchars($_GET['hn'] ?? '', ENT_QUOTES, 'UTF-8');
$default_hcode = htmlspecialchars(provider_oauth_session_hcode(), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Check Drug All (Drugs Center) - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .patient-bar { background: #eef7f3; border: 1px solid #c5d4a0; border-radius: 8px; }
        .chip { display: inline-flex; align-items: center; gap: 6px; background: #e7f1ff; border: 1px solid #b6d4fe; border-radius: 16px; padding: 2px 10px; margin: 2px; font-size: 0.85rem; }
        .chip button { border: 0; background: transparent; color: #dc3545; font-weight: 700; line-height: 1; }
        .sev-contraindicated, .sev-major { color: #dc3545; font-weight: 700; }
        .sev-moderate { color: #fd7e14; font-weight: 700; }
        .instr { white-space: pre-wrap; font-size: 0.85rem; color: #495057; }
        .detail-th { white-space: pre-wrap; font-size: 0.9rem; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-2 text-dark">
                <i class="fas fa-shield-alt me-2 text-danger"></i>
                Check Drug All (Drugs Center)
            </h4>
            <p class="text-muted small mb-3">
                ตรวจ Interaction + Allergy + Med Reconcile จาก PHR ในครั้งเดียว ตาม
                <a href="https://docs.google.com/document/d/1oJZ700FIOCNr8QcdvhCGPWfuLAre2q2s797VOE1Vp68/edit?usp=sharing" target="_blank" rel="noopener">API Drug Center §6</a>
            </p>

            <?php echo drug_center_status_banner_html(); ?>

            <div class="filter-box p-3 mb-3">
                <div class="row g-2 align-items-end">
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">HN</label>
                        <input type="text" id="hn" class="form-control form-control-sm" value="<?php echo $prefill_hn; ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold mb-1">CID</label>
                        <input type="text" id="cid" class="form-control form-control-sm" maxlength="13" placeholder="13 หลัก">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">hcode <span class="text-danger">*</span></label>
                        <input type="text" id="hcode" class="form-control form-control-sm" value="<?php echo $default_hcode; ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">history_mode</label>
                        <select id="history_mode" class="form-select form-select-sm">
                            <option value="">ภายในวันปัจจุบัน</option>
                            <option value="7D">7 วัน</option>
                            <option value="1M" selected>1 เดือน</option>
                            <option value="6M">6 เดือน</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold mb-1">med_reconcile_history</label>
                        <select id="med_reconcile_history" class="form-select form-select-sm">
                            <option value="1M">1 เดือน</option>
                            <option value="3M">3 เดือน</option>
                            <option value="6M" selected>6 เดือน</option>
                            <option value="1Y">1 ปี</option>
                        </select>
                    </div>
                </div>
                <div class="row g-2 align-items-end mt-2">
                    <div class="col-md-5">
                        <label class="form-label small fw-bold mb-1">เพิ่มรหัสยา TPU</label>
                        <div class="input-group input-group-sm">
                            <input type="text" id="tpuInput" class="form-control" placeholder="เช่น 104721 หรือค้นหาชื่อยา">
                            <button type="button" class="btn btn-outline-secondary" id="btnSearchTpu"><i class="fas fa-search"></i></button>
                            <button type="button" class="btn btn-outline-primary" id="btnAddTpu"><i class="fas fa-plus"></i> เพิ่ม</button>
                        </div>
                        <div id="searchSuggest" class="small mt-1"></div>
                    </div>
                    <div class="col-md-7 text-md-end">
                        <button type="button" class="btn btn-outline-success btn-sm fw-bold" id="btnLoadHn"><i class="fas fa-hospital-user me-1"></i>โหลดยาจาก HN (7 วัน)</button>
                        <button type="button" class="btn btn-danger btn-sm fw-bold" id="btnRun"><i class="fas fa-stethoscope me-1"></i>Check Drug All</button>
                    </div>
                </div>
                <div class="mt-2">
                    <span class="small fw-bold text-muted">รหัสยาที่จะตรวจ:</span>
                    <div id="codeChips" class="mt-1"></div>
                </div>
            </div>

            <div id="patientBar" class="patient-bar p-3 mb-3 d-none">
                <strong id="ptLabel"></strong>
                <span class="text-muted small ms-2" id="ptMeta"></span>
            </div>
            <div id="msg" class="alert d-none"></div>

            <ul class="nav nav-tabs fw-bold" role="tablist">
                <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tabContrast" type="button">Interaction <span class="badge bg-danger" id="cntContrast">0</span></button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabAllergy" type="button">Allergy <span class="badge bg-warning text-dark" id="cntAllergy">0</span></button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabMed" type="button">Med Reconcile <span class="badge bg-success" id="cntMed">0</span></button></li>
            </ul>
            <div class="tab-content bg-white border border-top-0 p-3 rounded-bottom shadow-sm">
                <div class="tab-pane fade show active" id="tabContrast">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover align-middle mb-0">
                            <thead class="table-light"><tr><th>ยา A</th><th>ยา B</th><th>ความรุนแรง</th><th>รายละเอียด</th></tr></thead>
                            <tbody id="tbContrast"><tr><td colspan="4" class="text-muted text-center py-3">ยังไม่มีผล</td></tr></tbody>
                        </table>
                    </div>
                </div>
                <div class="tab-pane fade" id="tabAllergy">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover align-middle mb-0">
                            <thead class="table-light"><tr><th>ยา</th><th>สารที่แพ้</th><th>อาการ</th><th>ความรุนแรง</th><th>วันที่</th></tr></thead>
                            <tbody id="tbAllergy"><tr><td colspan="5" class="text-muted text-center py-3">ยังไม่มีผล</td></tr></tbody>
                        </table>
                    </div>
                </div>
                <div class="tab-pane fade" id="tabMed">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover align-middle mb-0">
                            <thead class="table-light"><tr><th>วันที่</th><th>ยา</th><th>Qty</th><th>ประเภท</th><th>สถานพยาบาล</th><th>แหล่ง</th><th>วิธีใช้</th></tr></thead>
                            <tbody id="tbMed"><tr><td colspan="7" class="text-muted text-center py-3">ยังไม่มีผล</td></tr></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/bootstrap.bundle.min.js"></script>
<?php echo drug_center_status_banner_script(); ?>
<script>
(function () {
    var codes = [];

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
    function showMsg(type, text) {
        var el = document.getElementById('msg');
        el.className = 'alert alert-' + type;
        el.textContent = text;
        el.classList.remove('d-none');
    }
    function hideMsg() { document.getElementById('msg').classList.add('d-none'); }

    function renderChips() {
        var box = document.getElementById('codeChips');
        if (!codes.length) {
            box.innerHTML = '<span class="text-muted small">ยังไม่มีรหัสยา</span>';
            return;
        }
        box.innerHTML = codes.map(function (c, i) {
            return '<span class="chip">' + esc(c) + ' <button type="button" data-i="' + i + '" title="ลบ">&times;</button></span>';
        }).join('');
        box.querySelectorAll('button').forEach(function (btn) {
            btn.addEventListener('click', function () {
                codes.splice(parseInt(btn.getAttribute('data-i'), 10), 1);
                renderChips();
            });
        });
    }
    function addCode(code) {
        code = String(code || '').trim();
        if (!code) return;
        if (codes.indexOf(code) === -1) codes.push(code);
        renderChips();
    }
    renderChips();

    document.getElementById('btnAddTpu').addEventListener('click', function () {
        addCode(document.getElementById('tpuInput').value);
        document.getElementById('tpuInput').value = '';
    });

    document.getElementById('btnSearchTpu').addEventListener('click', function () {
        var kw = document.getElementById('tpuInput').value.trim();
        if (!kw) return;
        var box = document.getElementById('searchSuggest');
        box.innerHTML = '<span class="text-muted">กำลังค้นหา...</span>';
        fetch('fetch_drug_center_api.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'search', keyword: kw, page: 1, row: 8})
        }).then(function (r) { return r.json(); }).then(function (j) {
            var rows = (j && j.data && j.data.data) ? j.data.data : [];
            if (!rows.length) {
                box.innerHTML = '<span class="text-muted">ไม่พบผลค้นหา</span>';
                return;
            }
            box.innerHTML = rows.map(function (row) {
                var code = row.tpu_code || '';
                var name = row.tpu_name || row.gpu_name || '';
                return '<button type="button" class="btn btn-link btn-sm p-0 me-2 dc-pick" data-code="' + esc(code) + '">'
                    + esc(code) + ' — ' + esc(name) + '</button><br>';
            }).join('');
            box.querySelectorAll('.dc-pick').forEach(function (b) {
                b.addEventListener('click', function () {
                    addCode(b.getAttribute('data-code'));
                });
            });
        }).catch(function (e) { box.innerHTML = '<span class="text-danger">' + esc(e) + '</span>'; });
    });

    document.getElementById('btnLoadHn').addEventListener('click', function () {
        var hn = document.getElementById('hn').value.trim();
        if (!hn) { showMsg('warning', 'กรุณาระบุ HN'); return; }
        hideMsg();
        fetch('fetch_drug_center_api.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'lookup_hn', hn: hn, recent_days: 7})
        }).then(function (r) { return r.json(); }).then(function (j) {
            if (!j || j.status !== 'ok') {
                showMsg('danger', (j && j.message) || 'โหลด HN ไม่สำเร็จ');
                return;
            }
            document.getElementById('cid').value = j.cid || '';
            document.getElementById('patientBar').classList.remove('d-none');
            document.getElementById('ptLabel').textContent = (j.ptname || '-') + ' (HN ' + j.hn + ')';
            document.getElementById('ptMeta').textContent = 'CID: ' + (j.cid || '-') + ' · ยาที่มี TPU: ' + (j.codes || []).length;
            (j.codes || []).forEach(addCode);
            if (!(j.codes || []).length) showMsg('warning', 'ไม่พบยาที่มี TPU ใน 7 วันล่าสุด — เพิ่มรหัสยาเองได้');
        }).catch(function (e) { showMsg('danger', String(e)); });
    });

    function sevClass(sev) {
        sev = String(sev || '').toLowerCase();
        if (sev.indexOf('contra') >= 0 || sev.indexOf('major') >= 0) return 'sev-major';
        if (sev.indexOf('moderate') >= 0) return 'sev-moderate';
        return '';
    }

    document.getElementById('btnRun').addEventListener('click', function () {
        hideMsg();
        if (!codes.length) { showMsg('warning', 'กรุณาเพิ่มรหัสยาอย่างน้อย 1 รายการ'); return; }
        if (!document.getElementById('hcode').value.trim()) { showMsg('warning', 'กรุณาระบุ hcode'); return; }
        var btn = document.getElementById('btnRun');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>กำลังตรวจ...';
        fetch('fetch_drug_center_api.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                action: 'check_all',
                hn: document.getElementById('hn').value.trim(),
                cid: document.getElementById('cid').value.trim(),
                hcode: document.getElementById('hcode').value.trim(),
                history_mode: document.getElementById('history_mode').value,
                med_reconcile_history: document.getElementById('med_reconcile_history').value,
                code: codes
            })
        }).then(function (r) { return r.json(); }).then(function (j) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-stethoscope me-1"></i>Check Drug All';
            if (!j || j.status !== 'ok') {
                showMsg('danger', (j && j.message) || 'เรียก API ไม่สำเร็จ');
                return;
            }
            if (j.cid) document.getElementById('cid').value = j.cid;
            var data = j.data || {};
            var contrast = data.contrast || [];
            var allergy = data.allergy || [];
            var med = data.med_reconcile || [];
            document.getElementById('cntContrast').textContent = contrast.length;
            document.getElementById('cntAllergy').textContent = allergy.length;
            document.getElementById('cntMed').textContent = med.length;

            document.getElementById('tbContrast').innerHTML = contrast.length ? contrast.map(function (row) {
                var a = row.input_tpu_name || row.input_ttmt_name || row.input_tpu_code || row.input_ttmt_code || '';
                var b = row.contrast_tpu_name || row.contrast_tpu_code || '';
                return '<tr><td>' + esc(a) + '</td><td>' + esc(b) + '</td>'
                    + '<td class="' + sevClass(row.severity) + '">' + esc(row.severity) + '</td>'
                    + '<td class="detail-th">' + esc(row.interaction_detail_th || row.interaction_detail_en) + '</td></tr>';
            }).join('') : '<tr><td colspan="4" class="text-center text-success py-3">ไม่พบ interaction</td></tr>';

            document.getElementById('tbAllergy').innerHTML = allergy.length ? allergy.map(function (row) {
                var subs = (row.allergy_substances || [])[0] || {};
                return '<tr><td>' + esc(row.input_tpu_name || row.input_tpu_code) + '</td>'
                    + '<td>' + esc(subs.name) + '</td>'
                    + '<td>' + esc(subs.reaction) + '</td>'
                    + '<td>' + esc(subs.seriousness) + '</td>'
                    + '<td>' + esc(subs.record_date) + '</td></tr>';
            }).join('') : '<tr><td colspan="5" class="text-center text-success py-3">ไม่พบการแพ้ยา</td></tr>';

            document.getElementById('tbMed').innerHTML = med.length ? med.map(function (row) {
                var orgName = row.organization_name || '';
                var orgCode = row.organization_code || '';
                var orgCell = orgName
                    ? (esc(orgName) + (orgCode ? '<div class="small text-muted">' + esc(orgCode) + '</div>' : ''))
                    : esc(orgCode || '-');
                var src = (row.source === 'hosxp')
                    ? '<span class="badge bg-success">HOSxP</span>'
                    : '<span class="badge bg-secondary">PHR</span>';
                return '<tr><td>' + esc(row.date) + '</td><td class="fw-bold">' + esc(row.code_text) + '</td>'
                    + '<td>' + esc(row.qty) + '</td><td>' + esc(row.patien_category) + '</td>'
                    + '<td>' + orgCell + '</td><td>' + src + '</td>'
                    + '<td class="instr">' + esc(row.patient_instruction || row.instruction) + '</td></tr>';
            }).join('') : '<tr><td colspan="7" class="text-center text-muted py-3">ไม่มีรายการ med reconcile</td></tr>';

            showMsg('success', j.message || 'ตรวจสำเร็จ');
        }).catch(function (e) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-stethoscope me-1"></i>Check Drug All';
            showMsg('danger', String(e));
        });
    });
})();
</script>
</body>
</html>
