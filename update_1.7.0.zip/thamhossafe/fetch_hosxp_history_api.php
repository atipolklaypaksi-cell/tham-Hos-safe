<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

set_time_limit(180);
include('connect.php');
require_once __DIR__ . '/hospital_ds_helper.php';
require_once __DIR__ . '/jhcis_helper.php';
require_once __DIR__ . '/smart_drug_chronic_helper.php';
require_once __DIR__ . '/display_mask_helper.php';
session_write_close();
dm_ensure_tables($con);

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = [];
}

$hn = isset($input['hn']) ? trim($input['hn']) : '';
if ($hn === '') {
    echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ HN']);
    exit;
}

$months = hds_lookback_months($input['months'] ?? 12, 12);
$limit = isset($input['limit']) ? (int)$input['limit'] : ($months === 0 ? 5000 : 3000);
if ($limit < 1) {
    $limit = 3000;
}
if ($limit > 5000) {
    $limit = 5000;
}

$include_network = !isset($input['include_network']) || $input['include_network'] === true
    || $input['include_network'] === 1 || $input['include_network'] === '1';
$include_jhcis = isset($input['include_jhcis']) && ($input['include_jhcis'] === true
    || $input['include_jhcis'] === 1 || $input['include_jhcis'] === '1');

$hn_variants = [];
if (is_numeric($hn)) {
    $hn_variants[] = str_pad($hn, 9, '0', STR_PAD_LEFT);
    $hn_variants[] = ltrim($hn, '0');
    if ($hn_variants[1] === '') {
        $hn_variants[1] = '0';
    }
} else {
    $hn_variants[] = $hn;
}
$hn_variants = array_values(array_unique($hn_variants));

$q_config = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ('h_host', 'h_user', 'h_pass', 'h_db')");
$hos_cfg = [];
if ($q_config) {
    while ($r = mysqli_fetch_assoc($q_config)) {
        $hos_cfg[$r['config_name']] = $r['config_value'];
    }
}

mysqli_report(MYSQLI_REPORT_OFF);
$con_hosxp = mysqli_init();
mysqli_options($con_hosxp, MYSQLI_OPT_CONNECT_TIMEOUT, 8);
if (defined('MYSQLI_OPT_READ_TIMEOUT')) {
    mysqli_options($con_hosxp, MYSQLI_OPT_READ_TIMEOUT, 60);
}
@mysqli_real_connect(
    $con_hosxp,
    $hos_cfg['h_host'] ?? '',
    $hos_cfg['h_user'] ?? '',
    $hos_cfg['h_pass'] ?? '',
    $hos_cfg['h_db'] ?? ''
);

if (!$con_hosxp) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อฐานข้อมูล HOSxP ได้ ตรวจสอบการตั้งค่าใน sys_config']);
    exit;
}
mysqli_set_charset($con_hosxp, 'utf8');

$hn_in = [];
foreach ($hn_variants as $v) {
    $hn_in[] = "'" . mysqli_real_escape_string($con_hosxp, $v) . "'";
}
$hn_sql = implode(',', $hn_in);

$t_start = microtime(true);
$local_ms = 0;
$network_ms = 0;
$jhcis_ms = 0;

$date_filter = '';
if ($months > 0) {
    $date_filter = " AND o.vstdate >= DATE_SUB(CURDATE(), INTERVAL $months MONTH) ";
}

$patient_info = null;
$sql_patient = "
    SELECT
        p.hn,
        CAST(CONVERT(p.pname USING utf8) AS CHAR) AS pname,
        CAST(CONVERT(p.fname USING utf8) AS CHAR) AS fname,
        CAST(CONVERT(p.lname USING utf8) AS CHAR) AS lname,
        p.cid,
        p.sex,
        p.birthday,
        TIMESTAMPDIFF(YEAR, p.birthday, CURDATE()) AS age_y
    FROM patient p
    WHERE p.hn IN ($hn_sql)
    LIMIT 1
";
$patient_cid = '';
$q_patient = mysqli_query($con_hosxp, $sql_patient);
if ($q_patient && ($p = mysqli_fetch_assoc($q_patient))) {
    $patient_cid = preg_replace('/\D+/', '', (string)($p['cid'] ?? ''));
    $sex_raw = trim((string)($p['sex'] ?? ''));
    $sex = ($sex_raw === '1' || $sex_raw === 'M' || $sex_raw === 'm') ? 'M'
        : (($sex_raw === '2' || $sex_raw === 'F' || $sex_raw === 'f') ? 'F' : '');
    $birthday = trim((string)($p['birthday'] ?? ''));
    if ($birthday === '0000-00-00') {
        $birthday = '';
    }
    $patient_info = [
        'hn' => $p['hn'],
        'pname' => trim($p['pname'] ?? ''),
        'fname' => trim($p['fname'] ?? ''),
        'lname' => trim($p['lname'] ?? ''),
        'full_name' => trim(($p['pname'] ?? '') . ($p['fname'] ?? '') . ' ' . ($p['lname'] ?? '')),
        'sex' => $sex,
        'birthday' => $birthday,
        'age_y' => isset($p['age_y']) ? (int)$p['age_y'] : null,
    ];
}

// เฉพาะรายการยา + ชื่อ/strength จาก TMT (tmt_tpu_code) ถ้ามี tpu_code_list
$sql_hosxp = "
    SELECT
        o.vn,
        o.an,
        o.vstdate,
        o.vsttime,
        o.rxdate,
        o.rxtime,
        o.order_no,
        o.item_type,
        ion.order_type,
        o.item_no,
        o.icode,
        o.qty,
        CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name_local,
        CAST(CONVERT(IFNULL(d.strength, '') USING utf8) AS CHAR) AS strength_local,
        CAST(CONVERT(
            COALESCE(
                NULLIF(TRIM(CONCAT(IFNULL(tm.active_ingredient, ''), ' ', IFNULL(tm.strength, ''))), ''),
                d.name
            ) USING utf8
        ) AS CHAR) AS drug_name,
        CAST(CONVERT(
            COALESCE(NULLIF(TRIM(tm.strength), ''), d.strength)
            USING utf8
        ) AS CHAR) AS strength,
        CAST(CONVERT(d.units USING utf8) AS CHAR) AS units,
        TRIM(IFNULL(d.tpu_code_list, '')) AS tpu_code,
        IFNULL(d.continuous, '') AS continuous,
        IF(o.sp_use <> '' AND o.sp_use IS NOT NULL,
           CONCAT(IFNULL(sp.name1,''), ' ', IFNULL(sp.name2,''), ' ', IFNULL(sp.name3,'')),
           CONCAT(IFNULL(du.name1,''), ' ', IFNULL(du.name2,''), ' ', IFNULL(du.name3,''))
        ) AS method
    FROM opitemrece o
    INNER JOIN drugitems d ON d.icode = o.icode
    LEFT JOIN tmt_tpu_code tm ON d.tpu_code_list = tm.tpu_code
    LEFT JOIN drugusage du ON du.drugusage = o.drugusage
    LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
    LEFT JOIN ipt_order_no ion ON ion.order_no = o.order_no
    WHERE o.hn IN ($hn_sql)
      $date_filter
    ORDER BY o.vstdate DESC, o.vsttime DESC, o.item_no ASC
    LIMIT $limit
";

$local_hospital_code = 'local';
$local_hospital_name = 'รพ.นี้ (HOSxP)';
foreach (hds_catalog() as $cat) {
    if (($cat['code'] ?? '') === 'scph') {
        $local_hospital_name = (string)$cat['name'];
        break;
    }
}

$q_hosxp = null;
$local_sql_ms = 0;
$run_local_sql = function () use ($con_hosxp, $sql_hosxp, &$q_hosxp, &$local_sql_ms) {
    $t0 = microtime(true);
    $q_hosxp = mysqli_query($con_hosxp, $sql_hosxp);
    $local_sql_ms = (int)round((microtime(true) - $t0) * 1000);
};

$network_sources = [];
$net = ['history' => [], 'visits' => [], 'sources' => []];
if ($include_network) {
    $t_net0 = microtime(true);
    $net = hds_fetch_smart_drug_network($con, $hn_variants, $patient_cid, $months, 400, $run_local_sql);
    $network_ms = (int)round((microtime(true) - $t_net0) * 1000);
    $network_sources = $net['sources'] ?? [];
} else {
    $run_local_sql();
}

$jhcis_src = null;
if ($include_jhcis) {
    $jhcis_src = jhcis_fetch_smart_drug($con, $patient_cid, $months, 800);
    $jhcis_ms = (int)($jhcis_src['ms'] ?? 0);
}

if (!$q_hosxp) {
    echo json_encode(['status' => 'error', 'message' => 'SQL Error: ' . mysqli_error($con_hosxp)]);
    mysqli_close($con_hosxp);
    exit;
}

$t_local_proc = microtime(true);
$history = [];
$visits_map = [];
$row_count = 0;
$widened = false;

for ($pass = 0; $pass < 2; $pass++) {
    if ($pass === 1) {
        if ($months <= 0 || count($history) > 0 || $date_filter === '') {
            break;
        }
        $q_retry = mysqli_query($con_hosxp, str_replace($date_filter, ' ', $sql_hosxp));
        if (!$q_retry) {
            break;
        }
        $q_hosxp = $q_retry;
        $widened = true;
    }

while ($row = mysqli_fetch_assoc($q_hosxp)) {
    $row_count++;
    $method = trim($row['method'] ?? '');
    $ts = strtotime($row['vstdate']);
    $be_year = (int)date('Y', $ts) + 543;

    $row['vstdate_iso'] = date('Y-m-d', $ts);
    $row['vstdate_display'] = date('d/m/', $ts) . $be_year;
    $row['vsttime_display'] = $row['vsttime'] ? substr($row['vsttime'], 0, 8) : '';
    $row['qty'] = floatval($row['qty']);
    $row['numeric_mg_value'] = null;

    $rxdate_raw = trim($row['rxdate'] ?? '');
    $rxtime_raw = trim($row['rxtime'] ?? '');
    $order_date_raw = ($rxdate_raw !== '' && $rxdate_raw !== '0000-00-00') ? $rxdate_raw : $row['vstdate'];
    $order_time_raw = ($rxtime_raw !== '') ? $rxtime_raw : ($row['vsttime'] ?? '');
    $order_ts = strtotime($order_date_raw . ' ' . substr($order_time_raw, 0, 8));
    if (!$order_ts) {
        $order_ts = strtotime($order_date_raw);
    }
    $order_be_year = $order_ts ? ((int)date('Y', $order_ts) + 543) : $be_year;
    $row['order_date_iso'] = $order_ts ? date('Y-m-d', $order_ts) : $row['vstdate_iso'];
    $row['order_date_display'] = $order_ts ? (date('d/m/', $order_ts) . $order_be_year) : $row['vstdate_display'];
    $row['order_time_display'] = $order_time_raw ? substr($order_time_raw, 0, 8) : '';
    $row['order_sort_key'] = $row['order_date_iso'] . ' ' . str_pad(substr($row['order_time_display'], 0, 8), 8, '0');

    $order_type = trim($row['order_type'] ?? '');
    $item_type = trim($row['item_type'] ?? '');
    $row['is_hme'] = (strcasecmp($order_type, 'Hme') === 0) || ($item_type === 'H');
    $row['tpu_code'] = trim((string)($row['tpu_code'] ?? ''));
    $row['continuous'] = strtoupper(trim((string)($row['continuous'] ?? '')));

    if ($method !== '' && preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|μg|ug|ไมโครกรัม)/iu', $method, $mc)) {
        $row['numeric_mg_value'] = (float)$mc[1] / 1000;
    } elseif ($method !== '' && preg_match('/(\d+(?:\.\d+)?)\s*mg(?!cg)/i', $method, $m)) {
        $row['numeric_mg_value'] = (float)$m[1];
    } elseif ($method !== '' && preg_match('/(\d+(?:\.\d+)?)\s*(?:g|gm|gram|กร\.?|กรัม)(?![a-zA-Z])/iu', $method, $g)) {
        $row['numeric_mg_value'] = (float)$g[1] * 1000;
    }

    $vn = trim($row['vn'] ?? '');
    $an = trim($row['an'] ?? '');
    if ($an !== '') {
        $visit_key = $local_hospital_code . ':ipd:' . $an;
        $visit_type = 'ipd';
    } elseif ($vn !== '') {
        $visit_key = $local_hospital_code . ':opd:' . $vn;
        $visit_type = 'opd';
    } else {
        continue;
    }

    $row['an'] = $an;
    $row['visit_key'] = $visit_key;
    $row['visit_type'] = $visit_type;
    $row['hospital_code'] = $local_hospital_code;
    $row['hospital_name'] = $local_hospital_name;

    if (!isset($visits_map[$visit_key])) {
        $visits_map[$visit_key] = [
            'visit_key' => $visit_key,
            'visit_type' => $visit_type,
            'vn' => $vn,
            'an' => $an,
            'vstdate_iso' => $row['vstdate_iso'],
            'vstdate_display' => $row['vstdate_display'],
            'vsttime_display' => $row['vsttime_display'],
            'drug_count' => 0,
            'ward_name' => '',
            'admit_date' => '',
            'hospital_code' => $local_hospital_code,
            'hospital_name' => $local_hospital_name,
        ];
    }
    $visits_map[$visit_key]['drug_count']++;
    if ($row['vstdate_iso'] > $visits_map[$visit_key]['vstdate_iso']) {
        $visits_map[$visit_key]['vstdate_iso'] = $row['vstdate_iso'];
        $visits_map[$visit_key]['vstdate_display'] = $row['vstdate_display'];
        $visits_map[$visit_key]['vsttime_display'] = $row['vsttime_display'];
    }

    $history[] = $row;
}
    if (count($history) > 0) {
        break;
    }
}
if (count($history) === 0) {
    $widened = false;
}

$ipd_ans = [];
foreach ($visits_map as $vk => $v) {
    if (($v['visit_type'] ?? '') === 'ipd' && !empty($v['an'])) {
        $ipd_ans[$v['an']] = $vk;
    }
}
if (!empty($ipd_ans)) {
    $an_in = [];
    foreach (array_keys($ipd_ans) as $a) {
        $an_in[] = "'" . mysqli_real_escape_string($con_hosxp, $a) . "'";
    }
    $an_sql = implode(',', $an_in);
    $sql_ipt = "
        SELECT i.an, i.vn, i.regdate, i.ward AS ipt_ward,
               CAST(CONVERT(IFNULL(w_ipt.name, '') USING utf8) AS CHAR) AS ward_ipt_name,
               CAST(CONVERT(IFNULL(w_first.name, '') USING utf8) AS CHAR) AS ward_first_name
        FROM ipt i
        LEFT JOIN ward w_ipt ON w_ipt.ward = i.ward
        LEFT JOIN ward w_first ON w_first.ward = i.first_ward
        WHERE i.an IN ($an_sql)
    ";
    $qi = mysqli_query($con_hosxp, $sql_ipt);
    if (!$qi) {
        $qi = mysqli_query($con_hosxp, "
            SELECT i.an, i.vn, i.regdate, i.ward AS ipt_ward,
                   '' AS ward_ipt_name, '' AS ward_first_name
            FROM ipt i
            WHERE i.an IN ($an_sql)
        ");
    }
    if ($qi) {
        while ($ir = mysqli_fetch_assoc($qi)) {
            $a = trim($ir['an'] ?? '');
            if ($a === '' || !isset($ipd_ans[$a])) {
                continue;
            }
            $vk = $ipd_ans[$a];
            $ward = trim($ir['ward_ipt_name'] ?? '');
            if ($ward === '') $ward = trim($ir['ward_first_name'] ?? '');
            if ($ward === '') $ward = trim($ir['ipt_ward'] ?? '');
            $visits_map[$vk]['ward_name'] = $ward;
            $ivn = trim((string)($ir['vn'] ?? ''));
            if ($ivn !== '' && trim((string)($visits_map[$vk]['vn'] ?? '')) === '') {
                $visits_map[$vk]['vn'] = $ivn;
            }
            $reg = $ir['regdate'] ?? '';
            if ($reg && $reg !== '0000-00-00') {
                $visits_map[$vk]['admit_date'] = substr((string)$reg, 0, 10);
                $ts = strtotime($reg);
                if ($ts) {
                    $visits_map[$vk]['vstdate_iso'] = date('Y-m-d', $ts);
                    $visits_map[$vk]['vstdate_display'] = date('d/m/', $ts) . ((int)date('Y', $ts) + 543);
                }
            }
            $admit_iso = substr((string)($visits_map[$vk]['admit_date'] ?? ''), 0, 10);
            $visit_vn = trim((string)($visits_map[$vk]['vn'] ?? ''));
            foreach ($history as &$hrow) {
                if (($hrow['visit_key'] ?? '') !== $vk) {
                    continue;
                }
                if ($admit_iso !== '') {
                    $hrow['admit_date'] = $admit_iso;
                }
                if ($visit_vn !== '' && trim((string)($hrow['vn'] ?? '')) === '') {
                    $hrow['vn'] = $visit_vn;
                }
            }
            unset($hrow);
        }
    }
}

$visits = array_values($visits_map);
$local_ms = $local_sql_ms + (int)round((microtime(true) - $t_local_proc) * 1000);
foreach ($net['history'] ?? [] as $h) {
    $history[] = $h;
    $row_count++;
}
foreach ($net['visits'] ?? [] as $v) {
    $visits[] = $v;
}
if ($jhcis_src) {
    foreach ($jhcis_src['history'] ?? [] as $h) {
        $history[] = $h;
        $row_count++;
    }
    foreach ($jhcis_src['visit_list'] ?? [] as $v) {
        $visits[] = $v;
    }
}
sd_chronic_mark_history($con, $history);
$total_ms = (int)round((microtime(true) - $t_start) * 1000);
usort($visits, function ($a, $b) {
    $da = $a['vstdate_iso'] ?? '';
    $db = $b['vstdate_iso'] ?? '';
    if ($da !== $db) {
        return strcmp($db, $da);
    }
    $ta = $a['vsttime_display'] ?? '';
    $tb = $b['vsttime_display'] ?? '';
    $tc = strcmp($tb, $ta);
    if ($tc !== 0) {
        return $tc;
    }
    return strcmp((string)($a['hospital_code'] ?? ''), (string)($b['hospital_code'] ?? ''));
});

$network_ok = 0;
$network_hit = 0;
foreach ($network_sources as $s) {
    if (!empty($s['ok'])) {
        $network_ok++;
    }
    if (!empty($s['rows'])) {
        $network_hit++;
    }
}

$sd_allergy_with_symptom = function ($agent, $symptom) {
    $agent = trim((string)$agent);
    $symptom = trim(preg_replace('/\s+/u', ' ', (string)$symptom));
    if ($agent === '') {
        return '';
    }
    if ($symptom === '') {
        return $agent;
    }
    $fold_a = function_exists('mb_strtolower') ? mb_strtolower($agent, 'UTF-8') : strtolower($agent);
    $fold_s = function_exists('mb_strtolower') ? mb_strtolower($symptom, 'UTF-8') : strtolower($symptom);
    if ($fold_s === $fold_a) {
        return $agent;
    }
    return $agent . ' (อาการ: ' . $symptom . ')';
};
$allergy_agents = [];
if ($hn_sql !== '') {
    $qa = @mysqli_query($con_hosxp, "
        SELECT CAST(CONVERT(IFNULL(agent,'') USING utf8) AS CHAR) AS agent,
               CAST(CONVERT(IFNULL(symptom,'') USING utf8) AS CHAR) AS symptom
        FROM opd_allergy
        WHERE hn IN ($hn_sql)
        ORDER BY report_date DESC
        LIMIT 30
    ");
    if (!$qa) {
        $qa = @mysqli_query($con_hosxp, "
            SELECT agent, symptom
            FROM opd_allergy
            WHERE hn IN ($hn_sql)
            ORDER BY report_date DESC
            LIMIT 30
        ");
    }
    if ($qa) {
        while ($ar = mysqli_fetch_assoc($qa)) {
            $agent = trim((string)($ar['agent'] ?? ''));
            if ($agent === '' || preg_match('/^(ปฏิเสธ|ปฎิเสธ|ไม่มีประวัติ|ไม่มี|ไม่แพ้|ไม่เคยแพ้|nka|nkda|none|no\s*known)/iu', $agent)) {
                continue;
            }
            $label = $sd_allergy_with_symptom($agent, $ar['symptom'] ?? '');
            if (!in_array($label, $allergy_agents, true)) {
                $allergy_agents[] = $label;
            }
        }
    }
}
$allergy_extra = [];
if ($include_network && function_exists('hds_fetch_allergy_network')) {
    try {
        $net_al = hds_fetch_allergy_network($con, $hn_variants, $patient_cid);
        foreach ($net_al['rows'] ?? [] as $row) {
            if (is_array($row)) {
                $allergy_extra[] = $row;
            }
        }
    } catch (Throwable $e) {
    }
}
if ($include_jhcis && function_exists('jhcis_fetch_allergy') && strlen($patient_cid) === 13) {
    try {
        $jhcis_al = jhcis_fetch_allergy($con, $patient_cid);
        foreach ($jhcis_al['rows'] ?? [] as $row) {
            if (is_array($row)) {
                $allergy_extra[] = $row;
            }
        }
    } catch (Throwable $e) {
    }
}
$seen_agents = [];
foreach ($allergy_agents as $agent) {
    $base = preg_replace('/\s*\(อาการ:.*$/u', '', (string)$agent);
    $seen_agents[function_exists('mb_strtolower') ? mb_strtolower($base, 'UTF-8') : strtolower($base)] = true;
}
$grouped = [];
foreach ($allergy_extra as $row) {
    $agent = trim((string)($row['agent'] ?? ''));
    $key = strtolower($agent);
    if ($agent === '' || isset($seen_agents[$key]) || preg_match('/^(ปฏิเสธ|ปฎิเสธ|ไม่มีประวัติ|ไม่มี|ไม่แพ้|ไม่เคยแพ้|nka|nkda|none|no\s*known)/iu', $agent)) {
        continue;
    }
    $seen_agents[$key] = true;
    $place = trim((string)($row['hospital_name'] ?? ''));
    if ($place === '') {
        $place = 'รพ.เครือข่าย';
    }
    if (!isset($grouped[$place])) {
        $grouped[$place] = [];
    }
    $grouped[$place][] = $sd_allergy_with_symptom($agent, $row['symptom'] ?? '');
}
$allergy_chunks = $allergy_agents;
foreach ($grouped as $place => $names) {
    $allergy_chunks[] = implode(', ', $names) . ' (' . $place . ')';
}
$allergy_text = implode(', ', $allergy_chunks);
$has_allergy = $allergy_text !== '';

$visit_appointments = [];
if ($hn_sql !== '') {
    $qa = @mysqli_query($con_hosxp, "
        SELECT o.vn, IFNULL(o.an,'') AS an, o.vstdate, o.nextdate,
               SUBSTR(IFNULL(o.nexttime,''),1,8) AS nexttime,
               CAST(CONVERT(IFNULL(c.name,'') USING utf8) AS CHAR) AS clinic_name,
               CAST(CONVERT(IFNULL(doc.name,'') USING utf8) AS CHAR) AS doctor_name
        FROM oapp o
        LEFT JOIN clinic c ON c.clinic = o.clinic
        LEFT JOIN doctor doc ON doc.code = o.doctor
        WHERE o.hn IN ($hn_sql)
          AND o.vstdate IS NOT NULL AND o.vstdate <> '0000-00-00'
          AND o.nextdate IS NOT NULL AND o.nextdate <> '0000-00-00'
        ORDER BY o.vstdate DESC, o.nextdate ASC
        LIMIT 400
    ");
    if (!$qa) {
        $qa = @mysqli_query($con_hosxp, "
            SELECT o.vn, IFNULL(o.an,'') AS an, o.vstdate, o.nextdate,
                   SUBSTR(IFNULL(o.nexttime,''),1,8) AS nexttime,
                   '' AS clinic_name, '' AS doctor_name
            FROM oapp o
            WHERE o.hn IN ($hn_sql)
              AND o.vstdate IS NOT NULL AND o.vstdate <> '0000-00-00'
              AND o.nextdate IS NOT NULL AND o.nextdate <> '0000-00-00'
            ORDER BY o.vstdate DESC, o.nextdate ASC
            LIMIT 400
        ");
    }
    if ($qa) {
        while ($r = mysqli_fetch_assoc($qa)) {
            $vd = substr(trim((string)($r['vstdate'] ?? '')), 0, 10);
            $nd = substr(trim((string)($r['nextdate'] ?? '')), 0, 10);
            if ($vd === '' || $vd === '0000-00-00' || $nd === '' || $nd === '0000-00-00') {
                continue;
            }
            $visit_appointments[] = [
                'vn' => trim((string)($r['vn'] ?? '')),
                'an' => trim((string)($r['an'] ?? '')),
                'vstdate' => $vd,
                'nextdate' => $nd,
                'nexttime' => substr(trim((string)($r['nexttime'] ?? '')), 0, 8),
                'clinic_name' => trim((string)($r['clinic_name'] ?? '')),
                'doctor_name' => trim((string)($r['doctor_name'] ?? '')),
                'hospital_code' => 'local',
                'hospital_name' => $local_hospital_name,
            ];
        }
    }
}
foreach ($net['appointments'] ?? [] as $row) {
    if (is_array($row)) {
        $visit_appointments[] = $row;
    }
}

$history = dm_apply_drug_history($con, $history);

echo json_encode([
    'status' => 'success',
    'patient' => $patient_info,
    'allergy' => [
        'has_allergy' => $has_allergy,
        'text' => $has_allergy ? $allergy_text : 'ไม่แพ้ยา',
    ],
    'visits' => $visits,
    'history' => $history,
    'visit_appointments' => $visit_appointments,
    'meta' => [
        'count' => $row_count,
        'visit_count' => count($visits),
        'months' => $months,
        'widened' => $widened,
        'limit' => $limit,
        'truncated' => ($row_count >= $limit),
        'drugs_only' => true,
        'local_hospital' => [
            'code' => $local_hospital_code,
            'name' => $local_hospital_name,
        ],
        'network' => $network_sources,
        'network_ok' => $network_ok,
        'network_hit' => $network_hit,
        'jhcis' => $jhcis_src ? [
            'ok' => !empty($jhcis_src['ok']),
            'code' => 'jhcis',
            'name' => (string)($jhcis_src['name'] ?? 'JHCIS PCC'),
            'rows' => (int)($jhcis_src['rows'] ?? 0),
            'visits' => (int)($jhcis_src['visits'] ?? 0),
            'ms' => (int)($jhcis_src['ms'] ?? 0),
            'error' => (string)($jhcis_src['error'] ?? ''),
        ] : null,
        'lookback_label' => hds_lookback_label($months),
        'timing' => [
            'total_ms' => $total_ms,
            'local_ms' => $local_ms,
            'network_ms' => $network_ms,
            'jhcis_ms' => $jhcis_ms,
            'parallel' => $include_network,
        ],
    ],
], JSON_UNESCAPED_UNICODE);

mysqli_close($con_hosxp);
