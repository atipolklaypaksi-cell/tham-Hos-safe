<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/hapysure_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
tham_menu_ensure_page_access('hapysure_sso.php');

$hn = trim((string)($_GET['hn'] ?? ''));
$vn = trim((string)($_GET['vn'] ?? ''));
$date = trim((string)($_GET['vstdate'] ?? ''));
if ($date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    $date = '';
}

$status = hapysure_connect_status($con);
$payload = hapysure_payload($con, $hn, $vn, $date);
$creds = hapysure_session_credentials();
$cfg = hapysure_load_config($con);
$login_url = hapysure_login_url($cfg['hapysure_base_url'], $cfg['hapysure_login_path'] ?? '/login');
$launch_url = $payload['launch_url'] ?? '';
$can_sso = !empty($status['connected']) && !empty($creds['ok']) && $login_url !== '';

header('Cache-Control: no-store, no-cache, must-revalidate');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>เข้า HAPYsure</title>
    <style>
        body { font-family: Sarabun, Tahoma, sans-serif; background: #eef6f8; color: #243038; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
        .box { background: #fff; border-radius: 12px; padding: 22px 24px; width: min(420px, calc(100% - 32px)); text-align: center; box-shadow: 0 10px 30px rgba(15,40,48,.12); }
        .t { font-weight: 800; color: #0b7285; margin-bottom: 8px; }
        .m { color: #842029; font-weight: 700; }
        a { color: #0aa2c0; font-weight: 700; }
    </style>
</head>
<body>
<?php if (empty($status['connected'])): ?>
    <div class="box">
        <div class="t">HAPYsure</div>
        <div class="m"><?php echo htmlspecialchars(hapysure_offline_message(), ENT_QUOTES, 'UTF-8'); ?></div>
        <p><a href="patient_opd.php">กลับ Patient OPD</a></p>
    </div>
<?php elseif (!$can_sso): ?>
    <div class="box">
        <div class="t">HAPYsure</div>
        <p>ยังไม่มี user/password สำหรับเข้า HAPYsure</p>
        <?php if ($launch_url !== ''): ?>
            <p><a href="<?php echo htmlspecialchars($launch_url, ENT_QUOTES, 'UTF-8'); ?>">เปิดหน้าผู้ป่วย</a></p>
        <?php endif; ?>
        <p><a href="patient_opd.php">กลับ Patient OPD</a></p>
    </div>
<?php else: ?>
    <div class="box">
        <div class="t">กำลังเข้าสู่ระบบ HAPYsure</div>
        <p>ใช้บัญชีเดียวกับ THAM</p>
    </div>
    <form id="hapyForm" method="post" action="<?php echo htmlspecialchars($login_url, ENT_QUOTES, 'UTF-8'); ?>" accept-charset="UTF-8">
        <input type="hidden" name="username" value="<?php echo htmlspecialchars($creds['user'], ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="password" value="<?php echo htmlspecialchars($creds['pass'], ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="redirect" value="<?php echo htmlspecialchars($launch_url, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="returnUrl" value="<?php echo htmlspecialchars($launch_url, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="next" value="<?php echo htmlspecialchars($launch_url, ENT_QUOTES, 'UTF-8'); ?>">
    </form>
    <script>
        document.getElementById('hapyForm').submit();
        setTimeout(function () {
            var next = <?php echo json_encode($launch_url, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
            if (next) window.location.replace(next);
        }, 1200);
    </script>
<?php endif; ?>
</body>
</html>
