<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/allergy_followup_helper.php';
require_once __DIR__ . '/integrations_hub_helper.php';
mysqli_set_charset($con, 'utf8');
if (isset($_SESSION['user_id'])) {
    tham_menu_sync_allergy_followup_permission($con);
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
af_ensure_tables($con);

$can_assess = af_can_assess();
$can_import_gsheet = $can_assess && ih_is_enabled($con, 'google_sheet_allergy');
$user = af_current_user();
$unit_ward = trim((string)($_SESSION['unit_ward'] ?? ''));
$scope_ward = af_user_ward_scope();
$ward_locked = ($scope_ward !== '');
$open_id = (int)($_GET['open'] ?? 0);
$prefill_hn = trim((string)($_GET['hn'] ?? ''));
$prefill_detail = trim((string)($_GET['detail'] ?? ''));
if ($prefill_hn !== '' && $open_id <= 0) {
    $qs = [];
    $qs['hn'] = $prefill_hn;
    if ($prefill_detail !== '') {
        $qs['detail'] = $prefill_detail;
    }
    header('Location: allergy_report.php?' . http_build_query($qs));
    exit;
}
$fy_start = ((int)date('n') >= 10) ? date('Y-10-01') : date('Y-10-01', strtotime('-1 year'));
$default_tab = 'dash';
if ($open_id > 0) {
    $default_tab = 'dash';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ติดตามการแพ้ยา - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        :root { --af-rose: #be123c; --af-dark: #9f1239; --af-soft: #fff1f2; }
        .af-hero {
            background: linear-gradient(135deg, #9f1239 0%, #e11d48 55%, #fb7185 100%);
            color: #fff; border-radius: 12px; padding: 1.15rem 1.4rem;
            box-shadow: 0 8px 24px rgba(190, 18, 60, 0.25);
        }
        .nav-pills .nav-link { font-weight: 700; color: #9f1239; }
        .nav-pills .nav-link.active { background: var(--af-rose); }
        .af-sheet { min-width: 1280px; }
        .af-sheet thead th { font-size: 0.78rem; white-space: nowrap; vertical-align: middle; }
        .af-h-date { background: #111827; color: #fff; }
        .af-h-blue { background: #1d4ed8; color: #fff; }
        .af-h-orange { background: #c2410c; color: #fff; }
        .af-h-red { background: #be123c; color: #fff; }
        .af-h-photo { background: #0f766e; color: #fff; }
        .af-cell-pre { white-space: pre-wrap; font-size: 0.82rem; max-width: 280px; }
        .af-clip {
            max-width: 240px; max-height: 4.2em; overflow: hidden;
            display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical;
            white-space: pre-wrap; font-size: 0.8rem; line-height: 1.35;
        }
        .af-dash { font-size: 0.875rem; }
        .af-dash thead th {
            font-size: 0.78rem; font-weight: 700; line-height: 1.3;
            white-space: normal; vertical-align: bottom;
            background: #f8fafc; color: #334155;
            padding: 0.5rem 0.4rem; border-bottom: 2px solid #e2e8f0;
        }
        .af-dash tbody td { vertical-align: top; padding: 0.5rem 0.45rem; }
        .af-person {
            font-weight: 600; color: #0f172a; font-size: 0.875rem;
            line-height: 1.35; min-width: 132px; max-width: 176px;
        }
        .af-hn { font-weight: 700; color: #be123c; font-variant-numeric: tabular-nums; }
        .af-sheet .af-person { max-width: 160px; }
        .af-thumb { width: 52px; height: 52px; object-fit: cover; border-radius: 6px; cursor: pointer; border: 1px solid #fecdd3; }
        .af-photo-box {
            border: 1px solid #fecdd3; background: #fff1f2; border-radius: 10px;
            padding: 10px 12px;
        }
        .af-photo-box img.af-thumb { width: 92px; height: 92px; }
        .af-photo-box-progress {
            border-color: #86efac; background: #f0fdf4;
        }
        .af-photo-box-progress img.af-thumb { border-color: #86efac; }
        .af-drop {
            border: 2px dashed #fda4af; border-radius: 12px; background: var(--af-soft);
            padding: 1.25rem; text-align: center; cursor: pointer;
        }
        .af-drop.drag { background: #ffe4e6; border-color: #e11d48; }
        .af-preview { width: 88px; height: 88px; object-fit: cover; border-radius: 8px; }
        .badge-pending { background: #fef3c7; color: #92400e; }
        .badge-allergy { background: #fee2e2; color: #991b1b; }
        .badge-monitor { background: #dbeafe; color: #1e40af; }
        .badge-ok { background: #dcfce7; color: #166534; }
        .badge-adr { background: #ffedd5; color: #9a3412; }
        .badge-hist { background: #f3e8ff; color: #6b21a8; }
        .btn-af { background: var(--af-rose); color: #fff; border: 0; }
        .btn-af:hover { background: var(--af-dark); color: #fff; }
        #afLightbox img { max-height: 85vh; max-width: 100%; }
        .kpi-card { border-radius: 12px; border: none; box-shadow: 0 4px 15px rgba(0,0,0,0.05); cursor: pointer; transition: transform 0.15s; }
        .kpi-card:hover { transform: translateY(-3px); }
        .kpi-card.active-kpi { outline: 2px solid var(--af-rose); }
        @keyframes afKpiBlink {
            0%, 100% { background: #fff5f5; box-shadow: 0 0 0 0 rgba(220,53,69,0.55); }
            50% { background: #ffd6d6; box-shadow: 0 0 0 6px rgba(220,53,69,0.12); }
        }
        .kpi-card.kpi-blink { animation: afKpiBlink 1s ease-in-out infinite; border-color: #dc3545 !important; }
        .kpi-icon { width: 52px; height: 52px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 22px; }
        .time-badge { font-family: ui-monospace, monospace; font-size: 12px; background: #e9ecef; padding: 3px 7px; border-radius: 4px; color: #333; white-space: nowrap; }
        .af-stepper { display: flex; gap: 0; flex-wrap: wrap; }
        .af-step { flex: 1; min-width: 120px; text-align: center; padding: 0.55rem 0.4rem; font-size: 0.78rem; font-weight: 700; background: #f3f4f6; color: #6b7280; border: 1px solid #e5e7eb; }
        .af-step:first-child { border-radius: 8px 0 0 8px; }
        .af-step:last-child { border-radius: 0 8px 8px 0; }
        .af-step.done { background: #dcfce7; color: #166534; }
        .af-step.current { background: #be123c; color: #fff; }
        .af-quick-tabs {
            display: flex; flex-wrap: wrap; gap: 0.4rem;
        }
        .af-quick-tab {
            border: 1px solid #fda4af; background: #fff; color: #9f1239;
            font-size: 0.78rem; font-weight: 700; border-radius: 999px;
            padding: 0.28rem 0.75rem; cursor: pointer;
            transition: background .15s, color .15s, border-color .15s;
        }
        .af-quick-tab:hover {
            background: #be123c; color: #fff; border-color: #be123c;
        }
        .af-tl { border-left: 3px solid #fda4af; margin-left: 8px; padding-left: 14px; }
        .af-tl-item { position: relative; margin-bottom: 0.75rem; }
        .af-tl-item::before { content: ''; position: absolute; left: -19px; top: 6px; width: 9px; height: 9px; border-radius: 50%; background: #be123c; }
        .af-recv { border: 1px dashed #cbd5e1; border-radius: 8px; background: #f8fafc; padding: 0.5rem 0.7rem; }
        .af-recv-item { padding: 0.15rem 0; }
        .af-recv-item + .af-recv-item { border-top: 1px solid #e2e8f0; }
        .af-case-tabbar {
            background: #fff1f2;
            padding: 0 1rem;
            border-bottom: 1px solid #fecdd3;
        }
        .af-case-tabs { border-bottom: 0; }
        .af-case-tabs .nav-link {
            font-weight: 700; font-size: 0.9rem; color: #9f1239;
            border: 1px solid transparent; border-bottom: 0;
            border-radius: 8px 8px 0 0; padding: 0.55rem 1.1rem;
        }
        .af-case-tabs .nav-link:hover { color: #be123c; background: #ffe4e6; }
        .af-case-tabs .nav-link.active {
            color: #be123c; background: #fff;
            border-color: #fecdd3 #fecdd3 #fff;
        }
        .af-xfer-box {
            border: 1px solid #bfdbfe; border-radius: 10px; background: #f8fbff;
            padding: 0.9rem 1rem;
        }
        .af-chrono-box {
            border: 1px solid #fecdd3; border-radius: 10px; background: #fff;
            box-shadow: 0 2px 10px rgba(190, 18, 60, 0.06);
        }
        .af-chrono-box .af-chrono-head {
            background: linear-gradient(90deg, #fff1f2, #fff); border-bottom: 1px solid #fecdd3;
            padding: 0.55rem 0.75rem; border-radius: 10px 10px 0 0;
        }
        .af-chrono-table { width: 100%; margin: 0; font-size: 0.82rem; }
        .af-chrono-table thead th {
            background: #f8fafc; color: #334155; font-weight: 700; font-size: 0.75rem;
            border-bottom: 2px solid #e2e8f0; padding: 0.45rem 0.5rem; white-space: nowrap;
        }
        .af-chrono-table td {
            border-bottom: 1px solid #f1f5f9; padding: 0.5rem; vertical-align: top;
        }
        .af-chrono-table tbody tr:last-child td { border-bottom: 0; }
        .af-chrono-date { font-weight: 700; color: #0f172a; white-space: nowrap; }
        .af-chrono-drug-stop { color: #be123c; font-style: italic; font-weight: 600; }
        .af-chrono-event-onset { font-weight: 700; color: #9f1239; }
        .af-chrono-st { white-space: nowrap; font-size: 0.78rem; }
        .af-chrono-st.start { color: #166534; }
        .af-chrono-st.onset { color: #be123c; }
        .af-chrono-st.stop { color: #b45309; }
        .af-chrono-empty { color: #94a3b8; font-size: 0.8rem; padding: 0.75rem; text-align: center; }
        .af-drug-box {
            border: 1px solid #bbf7d0; border-radius: 10px; background: #f0fdf4;
            padding: 0.65rem 0.75rem;
        }
        .af-drug-row { position: relative; }
        .af-drug-suggest {
            position: absolute; left: 0; right: 2.5rem; top: 100%; z-index: 20;
            background: #fff; border: 1px solid #cbd5e1; border-radius: 8px;
            max-height: 200px; overflow-y: auto; box-shadow: 0 8px 20px rgba(15,23,42,.12);
            display: none;
        }
        .af-drug-suggest button {
            display: block; width: 100%; text-align: left; border: 0; background: #fff;
            padding: 0.4rem 0.65rem; font-size: 0.8rem; border-bottom: 1px solid #f1f5f9;
        }
        .af-drug-suggest button:hover { background: #ecfdf5; }
        .af-drug-suggest button:last-child { border-bottom: 0; }
        .af-drug-meta { font-size: 0.72rem; color: #64748b; }
        .af-cg-wrap { overflow-x: auto; border: 1px solid #e2e8f0; border-radius: 8px; background: #fff; }
        .af-cg-legend { font-size: 0.78rem; color: #475569; display: flex; flex-wrap: wrap; gap: 0.65rem 1rem; }
        .af-cg-legend span { white-space: nowrap; }
        .af-cg-meta { font-size: 0.82rem; }
        .af-cg-meta .row-label { color: #64748b; font-size: 0.72rem; }
        .af-cg-adr { font-size: 0.82rem; white-space: pre-wrap; }
        .af-cg-svg text { font-family: "Sarabun", "Kanit", sans-serif; }
        @media print {
            body * { visibility: hidden !important; }
            #afChronoGraphPrint, #afChronoGraphPrint * { visibility: visible !important; }
            #afChronoGraphPrint { position: absolute; left: 0; top: 0; width: 100%; }
        }
        .af-naranjo-box {
            border: 1px solid #bfdbfe; border-radius: 10px; background: #fff;
            box-shadow: 0 2px 10px rgba(37, 99, 235, 0.06); margin-top: 0.65rem;
        }
        .af-naranjo-box .af-naranjo-head {
            background: linear-gradient(90deg, #eff6ff, #fff); border-bottom: 1px solid #bfdbfe;
            padding: 0.55rem 0.75rem; border-radius: 10px 10px 0 0;
        }
        .af-naranjo-score {
            font-size: 1.35rem; font-weight: 800; color: #c2410c;
            font-variant-numeric: tabular-nums;
        }
        .af-naranjo-table { width: 100%; font-size: 0.8rem; margin: 0; }
        .af-naranjo-table th {
            background: #f8fafc; font-weight: 700; font-size: 0.75rem;
            border-bottom: 2px solid #e2e8f0; padding: 0.4rem 0.35rem; text-align: center;
        }
        .af-naranjo-table th.q { text-align: left; }
        .af-naranjo-table td { border-bottom: 1px solid #f1f5f9; padding: 0.45rem 0.35rem; vertical-align: middle; }
        .af-naranjo-table td.q { text-align: left; }
        .af-naranjo-table td.opt { text-align: center; white-space: nowrap; }
        .af-naranjo-table .pts { display: block; font-size: 0.68rem; color: #64748b; margin-top: 2px; }
        .af-naranjo-legend { font-size: 0.75rem; color: #475569; }
        .af-naranjo-legend b { color: #0f172a; }
        .badge-naranjo-definite { background: #166534; color: #fff; }
        .badge-naranjo-probable { background: #c2410c; color: #fff; }
        .badge-naranjo-possible { background: #ca8a04; color: #fff; }
        .badge-naranjo-doubtful { background: #64748b; color: #fff; }
        .af-regiscar-box {
            border: 1px solid #a7f3d0; border-radius: 10px; background: #fff;
            box-shadow: 0 2px 10px rgba(5, 150, 105, 0.06); margin-top: 0.65rem;
        }
        .af-regiscar-box .af-regiscar-head {
            background: linear-gradient(90deg, #ecfdf5, #fff); border-bottom: 1px solid #a7f3d0;
            padding: 0.55rem 0.75rem; border-radius: 10px 10px 0 0;
        }
        .af-regi-item {
            border-bottom: 1px solid #f1f5f9; padding: 0.75rem 1rem;
        }
        .af-regi-item:last-child { border-bottom: 0; }
        .af-regi-q { font-weight: 700; font-size: 0.85rem; color: #0f172a; margin-bottom: 0.45rem; }
        .af-regi-opts { display: flex; flex-wrap: wrap; gap: 0.4rem; }
        .af-regi-opts label {
            display: inline-flex; align-items: center; justify-content: space-between; gap: 0.65rem;
            border: 1px solid #d1d5db; border-radius: 8px; padding: 0.4rem 0.65rem;
            font-size: 0.78rem; cursor: pointer; background: #fff; min-width: 140px;
            margin: 0; transition: background .12s, border-color .12s;
        }
        .af-regi-opts label:has(input:checked) {
            background: #d1fae5; border-color: #059669; font-weight: 700;
        }
        .af-regi-opts input { margin: 0; }
        .af-regi-pts { color: #64748b; font-variant-numeric: tabular-nums; white-space: nowrap; }
        .af-regi-opts label:has(input:checked) .af-regi-pts { color: #047857; }
        .badge-regiscar-definite { background: #166534; color: #fff; }
        .badge-regiscar-probable { background: #c2410c; color: #fff; }
        .badge-regiscar-possible { background: #ca8a04; color: #fff; }
        .badge-regiscar-no { background: #64748b; color: #fff; }
        .af-dress-alert {
            display: inline-flex; align-items: center; gap: 0.25rem;
            background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca;
            border-radius: 999px; padding: 0.15rem 0.55rem; font-size: 0.72rem; font-weight: 700;
            animation: afDressPulse 1.4s ease-in-out infinite;
        }
        @keyframes afDressPulse {
            0%, 100% { box-shadow: 0 0 0 0 rgba(185, 28, 28, 0.35); }
            50% { box-shadow: 0 0 0 6px rgba(185, 28, 28, 0); }
        }
        .af-dress-lab-val { font-weight: 800; font-variant-numeric: tabular-nums; }
        .af-dress-lab-val.hi { color: #b91c1c; }
        .af-dress-lab-val.ok { color: #047857; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="af-hero mb-4 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <div class="small opacity-75 mb-1"><i class="fas fa-allergies me-1"></i>Drug Allergy Follow-up</div>
                    <h4 class="fw-bold mb-1"><i class="fas fa-book-medical me-2"></i>ติดตามการแพ้ยา</h4>
                    <small>แดชบอร์ดขั้นตอนเคส — แจ้งแพ้ยา → เภสัชรับเคส → ติดตาม → ปิดเคส สรุปแพ้ยาหรือไม่</small>
                    <?php if ($ward_locked): ?>
                    <div class="small mt-2 text-white-50"><i class="fas fa-filter me-1"></i>แสดงเคสที่ผู้ป่วย<b class="text-white">นอนอยู่ที่หอนี้ตอนนี้</b> หรือ<b class="text-white">เคยอยู่หอนี้ใน AN ปัจจุบัน</b> และเคสที่<b class="text-white">ผู้แจ้งสังกัดหอนี้</b></div>
                    <?php endif; ?>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-light text-dark fs-6" id="afUnreadBadge" style="display:none;"></span>
                    <a href="allergy_report.php" class="btn btn-light btn-sm fw-bold text-danger">
                        <i class="fas fa-camera me-1"></i> แจ้งเคสแพ้ยา
                    </a>
                </div>
            </div>

            <ul class="nav nav-pills mb-3 gap-2" role="tablist">
                <li class="nav-item">
                    <button class="nav-link <?= $default_tab === 'dash' ? 'active' : '' ?>" data-bs-toggle="pill" data-bs-target="#tabDash" type="button" id="btnTabDash">
                        <i class="fas fa-chart-line me-1"></i> Dashboard ขั้นตอน
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link <?= $default_tab === 'book' ? 'active' : '' ?>" data-bs-toggle="pill" data-bs-target="#tabBook" type="button" id="btnTabBook">
                        <i class="fas fa-table me-1"></i> สมุดติดตามเคส
                    </button>
                </li>
            </ul>

            <div class="tab-content">
                <div class="tab-pane fade <?= $default_tab === 'dash' ? 'show active' : '' ?>" id="tabDash">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body py-2">
                            <div class="row g-2 align-items-end">
                                <div class="col-6 col-md-2">
                                    <label class="form-label small mb-0">จากวันที่</label>
                                    <input type="date" class="form-control form-control-sm" id="dash_start" value="<?= htmlspecialchars($fy_start, ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-6 col-md-2">
                                    <label class="form-label small mb-0">ถึงวันที่</label>
                                    <input type="date" class="form-control form-control-sm" id="dash_end" value="<?= date('Y-m-d') ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small mb-0">ค้นหา HN / ชื่อ</label>
                                    <input type="text" class="form-control form-control-sm" id="dash_q" placeholder="HN, ชื่อผู้ป่วย...">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label small mb-0">หน่วยงาน</label>
                                    <select class="form-select form-select-sm" id="dash_ward" <?= $ward_locked ? 'disabled' : '' ?>>
                                        <?php if ($ward_locked): ?>
                                        <option value="<?= htmlspecialchars($scope_ward, ENT_QUOTES, 'UTF-8') ?>" selected><?= htmlspecialchars($scope_ward, ENT_QUOTES, 'UTF-8') ?></option>
                                        <?php else: ?>
                                        <option value="">ทั้งหมด</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-af btn-sm fw-bold" id="btnDashReload"><i class="fas fa-search me-1"></i>ค้นหา</button>
                                </div>
                                <?php if ($can_import_gsheet): ?>
                                <div class="col-md-3">
                                    <button type="button" class="btn btn-outline-danger btn-sm fw-bold" id="btnImportSheet"><i class="fas fa-file-import me-1"></i>นำเข้าสมุด Google Sheet</button>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row g-3 mb-3" id="afKpiRow">
                        <div class="col-6 col-lg">
                            <div class="card kpi-card bg-white p-3 h-100" data-stage="all">
                                <div class="d-flex align-items-center">
                                    <div class="kpi-icon bg-light text-dark me-2"><i class="fas fa-list"></i></div>
                                    <div>
                                        <div class="small text-muted fw-bold">ทั้งหมด</div>
                                        <div class="fs-3 fw-bold mb-0" id="kpi_total">0</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-lg">
                            <div class="card kpi-card bg-white p-3 h-100 border-start border-4 border-secondary" data-stage="reported">
                                <div class="d-flex align-items-center">
                                    <div class="kpi-icon bg-secondary bg-opacity-25 text-secondary me-2"><i class="fas fa-bell"></i></div>
                                    <div>
                                        <div class="small text-muted fw-bold">แจ้งแพ้ยา</div>
                                        <div class="fs-3 fw-bold text-secondary mb-0" id="kpi_reported">0</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-lg">
                            <div class="card kpi-card bg-white p-3 h-100 border-start border-4 border-info" data-stage="acknowledged">
                                <div class="d-flex align-items-center">
                                    <div class="kpi-icon bg-info bg-opacity-25 text-info me-2"><i class="fas fa-user-check"></i></div>
                                    <div>
                                        <div class="small text-muted fw-bold">เภสัชรับเคส</div>
                                        <div class="fs-3 fw-bold text-info mb-0" id="kpi_acknowledged">0</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-lg">
                            <div class="card kpi-card bg-white p-3 h-100 border-start border-4 border-warning" data-stage="following">
                                <div class="d-flex align-items-center">
                                    <div class="kpi-icon bg-warning bg-opacity-25 text-warning me-2"><i class="fas fa-stethoscope"></i></div>
                                    <div>
                                        <div class="small text-muted fw-bold">กำลังติดตาม</div>
                                        <div class="fs-3 fw-bold text-warning mb-0" id="kpi_following">0</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-lg">
                            <div class="card kpi-card bg-white p-3 h-100 border-start border-4 border-danger" data-stage="shift_handover" id="kpiCardShift">
                                <div class="d-flex align-items-center">
                                    <div class="kpi-icon bg-danger bg-opacity-25 text-danger me-2"><i class="fas fa-exchange-alt"></i></div>
                                    <div>
                                        <div class="small text-muted fw-bold">ส่งต่อเวร(ไม่ระบุชื่อ)</div>
                                        <div class="fs-3 fw-bold text-danger mb-0" id="kpi_shift_handover">0</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-lg">
                            <div class="card kpi-card bg-white p-3 h-100 border-start border-4 border-success" data-stage="closed">
                                <div class="d-flex align-items-center">
                                    <div class="kpi-icon bg-success bg-opacity-25 text-success me-2"><i class="fas fa-flag-checkered"></i></div>
                                    <div>
                                        <div class="small text-muted fw-bold">ปิดเคส</div>
                                        <div class="fs-3 fw-bold text-success mb-0" id="kpi_closed">0</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row g-2 mb-3" id="afClosedSummary">
                        <div class="col-auto"><span class="badge badge-allergy p-2">แพ้ยา <b id="sum_allergy">0</b></span></div>
                        <div class="col-auto"><span class="badge badge-ok p-2">ไม่แพ้ยา <b id="sum_not_allergy">0</b></span></div>
                        <div class="col-auto"><span class="badge badge-monitor p-2">เฝ้าระวัง <b id="sum_monitor">0</b></span></div>
                        <div class="col-auto"><span class="badge badge-adr p-2">ADRs type A <b id="sum_adr_type_a">0</b></span></div>
                        <div class="col-auto"><span class="badge badge-hist p-2">บัตรเดิม/รพ.อื่น <b id="sum_existing_history">0</b></span></div>
                        <div class="col-auto"><span class="badge badge-pending p-2">ปิดเคสไม่ได้ <b id="sum_unclosed">0</b></span></div>
                    </div>
                    <div class="card border-0 shadow-sm">
                        <div class="table-responsive">
                            <table class="table table-hover table-sm align-middle mb-0 af-dash">
                                <thead>
                                    <tr>
                                        <th style="width:7%">วันที่</th>
                                        <th style="width:6%">HN</th>
                                        <th style="width:12%">ชื่อ-สกุล</th>
                                        <th style="width:8%">WARD</th>
                                        <th style="width:8%">แจ้งแพ้ยา</th>
                                        <th style="width:8%">ผู้แจ้ง</th>
                                        <th style="width:12%">ผู้รับเคส</th>
                                        <th style="width:7%">ติดตาม</th>
                                        <th style="width:8%">ปิดเคส</th>
                                        <th style="width:7%">สรุปผล</th>
                                        <th style="width:8%">HOSxP</th>
                                        <th style="width:12%">รายการยาที่แพ้หรือเกิด ADR</th>
                                        <th style="width:7%">ขั้นตอน</th>
                                    </tr>
                                </thead>
                                <tbody id="afDashTbody">
                                    <tr><td colspan="13" class="text-center text-muted py-4">กำลังโหลด...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade <?= $default_tab === 'book' ? 'show active' : '' ?>" id="tabBook">
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body py-2">
                            <div class="row g-2 align-items-end">
                                <div class="col-6 col-md-2">
                                    <label class="form-label small mb-0">จากวันที่</label>
                                    <input type="date" class="form-control form-control-sm" id="flt_start" value="<?= htmlspecialchars($fy_start, ENT_QUOTES, 'UTF-8') ?>">
                                </div>
                                <div class="col-6 col-md-2">
                                    <label class="form-label small mb-0">ถึงวันที่</label>
                                    <input type="date" class="form-control form-control-sm" id="flt_end" value="<?= date('Y-m-d') ?>">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label small mb-0">สรุปผล</label>
                                    <select class="form-select form-select-sm" id="flt_summary">
                                        <option value="all">ทั้งหมด</option>
                                        <option value="pending">รอประเมิน</option>
                                        <option value="allergy">แพ้ยา</option>
                                        <option value="monitor">เฝ้าระวัง</option>
                                        <option value="not_allergy">ไม่แพ้ยา</option>
                                        <option value="adr_type_a">ADRs type A</option>
                                        <option value="existing_history">บัตรเดิม/รพ.อื่น</option>
                                        <option value="unclosed">ปิดเคสไม่ได้</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small mb-0">ค้นหา HN / ชื่อ / รายละเอียด</label>
                                    <input type="text" class="form-control form-control-sm" id="flt_q" placeholder="HN, ชื่อ, ยาที่สงสัย...">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label small mb-0">หน่วยงาน</label>
                                    <select class="form-select form-select-sm" id="flt_ward" <?= $ward_locked ? 'disabled' : '' ?>>
                                        <?php if ($ward_locked): ?>
                                        <option value="<?= htmlspecialchars($scope_ward, ENT_QUOTES, 'UTF-8') ?>" selected><?= htmlspecialchars($scope_ward, ENT_QUOTES, 'UTF-8') ?></option>
                                        <?php else: ?>
                                        <option value="">ทั้งหมด</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check mb-1">
                                        <input class="form-check-input" type="checkbox" id="flt_no_hosxp">
                                        <label class="form-check-label small" for="flt_no_hosxp">ยังไม่ลง HOSxP</label>
                                    </div>
                                    <button type="button" class="btn btn-af btn-sm fw-bold" id="btnReload"><i class="fas fa-sync me-1"></i>โหลด</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 shadow-sm">
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm align-middle mb-0 af-sheet">
                                <thead class="text-center">
                                    <tr>
                                        <th class="af-h-date">วันที่</th>
                                        <th class="af-h-date">เวลารับแจ้ง</th>
                                        <th class="af-h-date">ชื่อ-สกุล</th>
                                        <th class="af-h-date">HN</th>
                                        <th class="af-h-date">WARD</th>
                                        <th class="af-h-date">รายละเอียดข้อมูลจากหอผู้ป่วย</th>
                                        <th class="af-h-photo">รูป</th>
                                        <th class="af-h-date">ผู้แจ้ง</th>
                                        <th class="af-h-date">ผู้รับเคส</th>
                                        <th class="af-h-orange">ขั้นตอน</th>
                                        <th class="af-h-blue">สรุปผล</th>
                                        <th class="af-h-photo">HOSxP</th>
                                        <th class="af-h-orange">ส่งต่อแพทย์/ติดต่อ พยาบาล</th>
                                        <th class="af-h-red">ข้อมูลรายละเอียดและผลการประเมิน</th>
                                    </tr>
                                </thead>
                                <tbody id="afTbody">
                                    <tr><td colspan="14" class="text-center text-muted py-4">กำลังโหลด...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<datalist id="afWardList"></datalist>

<div class="modal fade" id="afCaseModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header py-2" style="background:#fff1f2;">
                <h5 class="modal-title fw-bold text-danger"><i class="fas fa-user-injured me-2"></i>ประเมินเคสแพ้ยา</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="af-case-tabbar">
                <ul class="nav nav-tabs af-case-tabs" id="afCaseTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="tabBtnAssess" data-bs-toggle="tab" data-bs-target="#afTabAssess" type="button" role="tab">
                            <i class="fas fa-notes-medical me-1"></i>ประเมิน
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="tabBtnTransfer" data-bs-toggle="tab" data-bs-target="#afTabTransfer" type="button" role="tab">
                            <i class="fas fa-share me-1"></i>ส่งต่อเคส
                        </button>
                    </li>
                </ul>
            </div>
            <div class="modal-body">
                <input type="hidden" id="md_id">
                <div id="mdStepper" class="af-stepper mb-2"></div>
                <div class="tab-content">
                <div class="tab-pane fade show active" id="afTabAssess" role="tabpanel">
                <div class="af-quick-tabs mb-3">
                    <button type="button" class="af-quick-tab" id="btnOpenSmartDrug" title="เปิด Smart Drug ด้วย HN นี้">
                        <i class="fas fa-pills me-1"></i>Smart Drug
                    </button>
                    <button type="button" class="af-quick-tab" id="btnOpenSmartLab" title="เปิด Smart Lab ด้วย HN นี้">
                        <i class="fas fa-flask me-1"></i>Smart Lab
                    </button>
                </div>
                <div class="row g-3">
                    <div class="col-md-3"><label class="form-label small fw-bold">วันที่</label><input type="date" class="form-control form-control-sm" id="md_date"></div>
                    <div class="col-md-3"><label class="form-label small fw-bold">เวลารับแจ้ง</label><input type="time" class="form-control form-control-sm" id="md_time"></div>
                    <div class="col-md-3"><label class="form-label small fw-bold">HN</label><input type="text" class="form-control form-control-sm" id="md_hn"></div>
                    <div class="col-md-3"><label class="form-label small fw-bold">WARD</label><input type="text" class="form-control form-control-sm" id="md_ward" list="afWardList"></div>
                    <div class="col-md-6"><label class="form-label small fw-bold">ชื่อ-สกุล</label><input type="text" class="form-control form-control-sm" id="md_ptname"></div>
                    <div class="col-md-3"><label class="form-label small fw-bold">ผู้รับแจ้ง</label><select class="form-select form-select-sm" id="md_channel"></select></div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold">ผู้รับเคส</label>
                        <input type="hidden" id="md_owner_id">
                        <input type="hidden" id="md_owner_name">
                        <input type="text" class="form-control form-control-sm" id="md_owner_display" readonly placeholder="ยังไม่มีผู้รับเคส">
                    </div>
                    <div class="col-12"><label class="form-label small fw-bold">รายละเอียดจากหอผู้ป่วย</label><textarea class="form-control form-control-sm" id="md_detail" rows="2"></textarea></div>
                    <div class="col-12" id="mdPhotos"></div>
                    <div class="col-12" id="mdHosAllergy"></div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold">สรุปผล</label>
                        <select class="form-select form-select-sm" id="md_summary"></select>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label small fw-bold">ส่งต่อแพทย์ / ติดต่อพยาบาล</label>
                        <input type="text" class="form-control form-control-sm" id="md_referral">
                    </div>
                    <div class="col-12" id="mdAssessDrugsWrap" style="display:none;">
                        <div class="af-drug-box">
                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
                                <div class="small fw-bold text-success mb-0">
                                    <i class="fas fa-pills me-1"></i>รายการยาที่แพ้หรือเกิด ADR
                                </div>
                                <button type="button" class="btn btn-outline-success btn-sm py-0 px-2" id="btnAssessDrugAdd">
                                    <i class="fas fa-plus me-1"></i>เพิ่มยา
                                </button>
                            </div>
                            <div id="mdAssessDrugRows"></div>
                            <div class="form-text mb-0">พิมพ์ชื่อยาเพื่อค้นจาก TMT หรือพิมพ์ชื่อเองได้ · มียาหลายตัวกดเพิ่มยา</div>
                        </div>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">ข้อมูลรายละเอียดและผลการประเมิน</label>
                        <textarea class="form-control form-control-sm" id="md_assess" rows="5" placeholder="ยาที่สงสัย, เวลาเกิดอาการ, Naranjo/เกณฑ์วินิจฉัย, การจัดการ, บันทึกติดตาม"></textarea>
                        <div class="form-text mb-2">ใช้ข้อความนี้เป็นรายละเอียดในไทม์ไลน์เมื่อกดรับเคส / ติดตาม / ปิดเคส</div>
                        <div class="af-chrono-box">
                            <div class="af-chrono-head d-flex justify-content-between align-items-center flex-wrap gap-2">
                                <div class="small fw-bold text-danger mb-0">
                                    <i class="fas fa-stream me-1"></i>เมนูพิเศษ: Timeline บันทึกการแพ้ยา
                                </div>
                                <div class="d-flex flex-wrap gap-1">
                                    <button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2" id="btnChronoGraph">
                                        <i class="fas fa-chart-bar me-1"></i>ดูกราฟ Timeline
                                    </button>
                                    <button type="button" class="btn btn-outline-danger btn-sm py-0 px-2" id="btnChronoToggle">
                                        <i class="fas fa-plus me-1"></i>เปิดสร้าง Timeline
                                    </button>
                                </div>
                            </div>
                            <div id="afChronoPanel" style="display:none;">
                                <div class="p-2 border-bottom">
                                    <div class="row g-2 align-items-end">
                                        <div class="col-6 col-md-2">
                                            <label class="form-label small mb-0 fw-bold">วันที่</label>
                                            <input type="date" class="form-control form-control-sm" id="chrono_date">
                                        </div>
                                        <div class="col-6 col-md-2">
                                            <label class="form-label small mb-0 fw-bold">เวลา</label>
                                            <input type="time" class="form-control form-control-sm" id="chrono_time">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label small mb-0 fw-bold">รายการยา / ขนาด</label>
                                            <input type="text" class="form-control form-control-sm" id="chrono_drug" placeholder="เช่น Amoxicillin 500 mg 1x3 pc" list="afChronoDrugList">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label small mb-0 fw-bold">เหตุการณ์ / อาการ</label>
                                            <input type="text" class="form-control form-control-sm" id="chrono_event" placeholder="เช่น ผื่นแดงราบขึ้นที่คอและอก" list="afChronoEventList">
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label small mb-0 fw-bold">สถานะ</label>
                                            <select class="form-select form-select-sm" id="chrono_status">
                                                <option value="">— ไม่ระบุ —</option>
                                                <option value="start">🟢 เริ่มยาครั้งแรก</option>
                                                <option value="dose">ทานยา</option>
                                                <option value="onset">🔴 จุดเกิดอาการ</option>
                                                <option value="stop">⚠️ หยุดยาที่สงสัย</option>
                                                <option value="note">หมายเหตุ</option>
                                            </select>
                                        </div>
                                        <div class="col-12 d-flex flex-wrap gap-2">
                                            <button type="button" class="btn btn-af btn-sm fw-bold" id="btnChronoAdd"><i class="fas fa-plus me-1"></i>เพิ่มเหตุการณ์</button>
                                            <button type="button" class="btn btn-outline-primary btn-sm fw-bold" id="btnChronoSave"><i class="fas fa-save me-1"></i>บันทึก Timeline</button>
                                            <button type="button" class="btn btn-outline-secondary btn-sm" id="btnChronoToAssess"><i class="fas fa-file-alt me-1"></i>ใส่สรุปลงผลการประเมิน</button>
                                            <button type="button" class="btn btn-outline-danger btn-sm" id="btnChronoClear"><i class="fas fa-eraser me-1"></i>ล้างทั้งหมด</button>
                                            <input type="hidden" id="chrono_edit_idx" value="-1">
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="af-chrono-table">
                                        <thead>
                                            <tr>
                                                <th>วันที่ / ช่วงเวลา</th>
                                                <th>รายการยา / ขนาด</th>
                                                <th>เหตุการณ์ / อาการ (ADR)</th>
                                                <th>หมายเหตุ / สถานะ</th>
                                                <th style="width:72px;"></th>
                                            </tr>
                                        </thead>
                                        <tbody id="afChronoTbody"></tbody>
                                    </table>
                                    <div class="af-chrono-empty" id="afChronoEmpty">ยังไม่มีรายการ — เลือกวันที่และเหตุการณ์แล้วกดเพิ่ม</div>
                                </div>
                            </div>
                            <div id="afChronoPreviewOnly" class="table-responsive" style="display:none;">
                                <table class="af-chrono-table">
                                    <thead>
                                        <tr>
                                            <th>วันที่ / ช่วงเวลา</th>
                                            <th>รายการยา / ขนาด</th>
                                            <th>เหตุการณ์ / อาการ (ADR)</th>
                                            <th>หมายเหตุ / สถานะ</th>
                                        </tr>
                                    </thead>
                                    <tbody id="afChronoPreviewBody"></tbody>
                                </table>
                            </div>
                        </div>
                        <datalist id="afChronoDrugList"></datalist>
                        <datalist id="afChronoEventList">
                            <option value="เริ่มทานยา"></option>
                            <option value="ทานต่อเนื่องปกติ ไม่มีผื่น"></option>
                            <option value="ทานเช้า"></option>
                            <option value="ทานกลางวัน"></option>
                            <option value="ทานเย็น"></option>
                            <option value="ผื่นแดงราบ (Maculopapular rash)"></option>
                            <option value="อาการทรงตัว"></option>
                            <option value="อาการดีขึ้น"></option>
                        </datalist>
                        <div class="af-naranjo-box">
                            <div class="af-naranjo-head d-flex justify-content-between align-items-center flex-wrap gap-2">
                                <div class="small fw-bold text-primary mb-0">
                                    <i class="fas fa-clipboard-check me-1"></i>แบบประเมิน Naranjo
                                    <span id="afNaranjoSummary" class="ms-1"></span>
                                </div>
                                <button type="button" class="btn btn-outline-primary btn-sm py-0 px-2" id="btnNaranjoOpen">
                                    <i class="fas fa-external-link-alt me-1"></i>เปิดเพื่อบันทึก
                                </button>
                            </div>
                        </div>
                        <div class="af-regiscar-box">
                            <div class="af-regiscar-head d-flex justify-content-between align-items-center flex-wrap gap-2">
                                <div class="small fw-bold text-success mb-0">
                                    <i class="fas fa-notes-medical me-1"></i>แบบประเมิน RegiSCAR (DRESS)
                                    <span id="afRegiscarSummary" class="ms-1"></span>
                                    <span id="afDressAlertBadge" class="ms-1" style="display:none;"></span>
                                </div>
                                <button type="button" class="btn btn-outline-success btn-sm py-0 px-2" id="btnRegiscarOpen">
                                    <i class="fas fa-external-link-alt me-1"></i>เปิดเพื่อบันทึก
                                </button>
                            </div>
                            <div id="afDressLabPanel" class="px-3 py-2 small border-top" style="display:none; background:#f8fffb;"></div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="af-photo-box af-photo-box-progress">
                            <div class="small fw-bold mb-1 text-success">
                                <i class="fas fa-notes-medical me-1"></i>รูปติดตาม progress ของเภสัช
                                <span id="mdProgressCount"></span>
                            </div>
                            <div id="mdProgressThumbs"></div>
                            <div id="mdProgressUpload" class="mt-2">
                                <div class="d-flex flex-wrap gap-2">
                                    <button type="button" class="btn btn-outline-success btn-sm fw-bold" id="btnMdPickGallery">
                                        <i class="fas fa-images me-1"></i>เลือกจากคลังรูป
                                    </button>
                                    <button type="button" class="btn btn-outline-secondary btn-sm" id="btnMdPickCamera">
                                        <i class="fas fa-camera me-1"></i>ถ่ายรูป
                                    </button>
                                </div>
                                <input type="file" id="md_photos" accept="image/*" multiple hidden>
                                <input type="file" id="md_photos_camera" accept="image/*" capture="environment" hidden>
                                <div class="form-text">โซนนี้สำหรับเภสัชติดตามอาการ — ไม่ปนกับรูปจากหอผู้ป่วย · JPG/PNG ระบบย่อให้อัตโนมัติ</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="small fw-bold mb-2">ไทม์ไลน์เคส</div>
                        <div id="mdTimeline" class="af-tl small"></div>
                    </div>
                </div>
                </div>
                <div class="tab-pane fade" id="afTabTransfer" role="tabpanel">
                    <div class="af-xfer-box mb-3">
                        <div class="small fw-bold text-primary mb-2"><i class="fas fa-share me-1"></i>ส่งต่อผู้รับเคส</div>
                        <div class="small mb-2">ผู้รับเคสปัจจุบัน (คนล่าสุดที่รับเคส): <b id="xfer_from_name">-</b></div>
                        <input type="hidden" id="xfer_case_id">
                        <label class="form-label small fw-bold mb-1">ส่งต่อไปยังเภสัชกร</label>
                        <select class="form-select form-select-sm" id="xfer_pick_user"></select>
                        <label class="form-label small fw-bold mb-1 mt-2">เหตุผลการส่งต่อ (ถ้ามี)</label>
                        <textarea class="form-control form-control-sm" id="xfer_note" rows="2" placeholder="เช่น เวรต่อ, เจ้าของวอร์ด, ขอความเห็นเพิ่ม"></textarea>
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mt-2">
                            <div class="form-text mb-0">ระบบจะเก็บประวัติผู้รับเคสเดิมและผู้รับใหม่ทุกครั้งที่ส่งต่อ</div>
                            <button type="button" class="btn btn-primary btn-sm fw-bold" id="btnTransferConfirm">
                                <i class="fas fa-check me-1"></i>ยืนยันส่งต่อ
                            </button>
                        </div>
                    </div>
                    <div class="small fw-bold mb-2">ประวัติผู้รับเคส / ส่งต่อ</div>
                    <div id="mdReceiverHistory" class="small mb-2"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer flex-wrap">
                <button type="button" class="btn btn-outline-danger btn-sm" id="btnDeleteCase"><i class="fas fa-trash-alt me-1"></i>ลบเคส</button>
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิด</button>
                <button type="button" class="btn btn-outline-info btn-sm fw-bold" id="btnAck"><i class="fas fa-user-check me-1"></i> รับเคส</button>
                <button type="button" class="btn btn-outline-warning btn-sm fw-bold" id="btnFollow"><i class="fas fa-stethoscope me-1"></i> บันทึกติดตาม</button>
                <button type="button" class="btn btn-success btn-sm fw-bold" id="btnCloseCase"><i class="fas fa-flag-checkered me-1"></i> ปิดเคส + สรุปผล</button>
                <button type="button" class="btn btn-af btn-sm fw-bold" id="btnSaveCase"><i class="fas fa-save me-1"></i> บันทึกแก้ไข</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="afChronoGraphModal" tabindex="-1">
    <div class="modal-dialog modal-fullscreen-lg-down modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header py-2" style="background:#fff1f2;">
                <h6 class="modal-title fw-bold mb-0 text-danger">
                    <i class="fas fa-chart-bar me-1"></i>กราฟ Timeline บันทึกการแพ้ยา
                </h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="afChronoGraphPrint">
                <div class="af-cg-meta mb-2">
                    <div class="row g-2">
                        <div class="col-md-4"><div class="row-label">ชื่อผู้ป่วย</div><div class="fw-bold" id="cg_ptname">—</div></div>
                        <div class="col-md-2"><div class="row-label">HN</div><div class="fw-bold" id="cg_hn">—</div></div>
                        <div class="col-md-3"><div class="row-label">Ward</div><div class="fw-bold" id="cg_ward">—</div></div>
                        <div class="col-md-3"><div class="row-label">ผู้จัดทำ</div><div class="fw-bold" id="cg_owner">—</div></div>
                    </div>
                </div>
                <div class="af-cg-legend mb-2">
                    <span>○ เริ่มยา</span>
                    <span>△ วันเริ่มไม่ทราบ</span>
                    <span>● หยุดยา</span>
                    <span>→ ยังใช้อยู่</span>
                    <span style="color:#be123c;">▼ จุดเกิดอาการ (ADR)</span>
                </div>
                <div class="af-cg-wrap mb-3" id="afChronoGraphSvgWrap"></div>
                <div class="mb-2">
                    <div class="small fw-bold text-danger mb-1">สรุปเหตุการณ์ ADR</div>
                    <div class="af-cg-adr border rounded p-2 bg-light" id="afChronoGraphAdr">—</div>
                </div>
                <div>
                    <div class="small fw-bold mb-1">บันทึกเภสัชกร</div>
                    <div class="af-cg-adr border rounded p-2" id="afChronoGraphNote">—</div>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิด</button>
                <button type="button" class="btn btn-success btn-sm fw-bold" id="btnChronoGraphPrint">
                    <i class="fas fa-print me-1"></i>พิมพ์ / PDF
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="afRegiscarModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header py-2" style="background:#ecfdf5;">
                <h6 class="modal-title fw-bold mb-0 text-success">
                    <i class="fas fa-notes-medical me-1"></i>RegiSCAR Score — ประเมิน DRESS
                </h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0">
                <div id="afRegiscarLabBanner" class="px-3 py-2 small border-bottom" style="background:#f0fdf4; display:none;"></div>
                <div id="afRegiscarBody"></div>
                <div class="p-3 border-top d-flex flex-wrap justify-content-between align-items-end gap-3">
                    <div class="af-naranjo-legend">
                        <div><b>&lt; 2</b> ไม่เข้าเกณฑ์ · <b>2–3</b> อาจเป็น (Possible)</div>
                        <div><b>4–5</b> น่าจะเป็น (Probable) · <b>≥ 6</b> ใช่แน่ (Definite)</div>
                    </div>
                    <div class="text-end">
                        <div class="small text-muted mb-0">คะแนนรวม</div>
                        <div class="af-naranjo-score" id="afRegiscarScoreLive" style="color:#047857;">—</div>
                        <div class="fw-bold" id="afRegiscarCatLive" style="color:#047857;"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-outline-secondary btn-sm" id="btnRegiscarClear">ล้างคำตอบ</button>
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="button" class="btn btn-success btn-sm fw-bold" id="btnRegiscarSave">
                    <i class="fas fa-save me-1"></i>บันทึก RegiSCAR
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="afNaranjoModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header py-2" style="background:#eff6ff;">
                <h6 class="modal-title fw-bold mb-0 text-primary">
                    <i class="fas fa-clipboard-check me-1"></i>Naranjo Algorithm — ความน่าจะเป็นของ ADR
                </h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0">
                <div class="table-responsive">
                    <table class="af-naranjo-table" id="afNaranjoTable">
                        <thead>
                            <tr>
                                <th class="q" style="min-width:280px;">คำถามพิจารณา</th>
                                <th style="width:88px;">ใช่</th>
                                <th style="width:88px;">ไม่ใช่</th>
                                <th style="width:88px;">ไม่ทราบ</th>
                            </tr>
                        </thead>
                        <tbody id="afNaranjoTbody"></tbody>
                    </table>
                </div>
                <div class="p-3 border-top d-flex flex-wrap justify-content-between align-items-end gap-3">
                    <div class="af-naranjo-legend">
                        <div><b>≥ 9</b> ใช่แน่ (Definite) · <b>5–8</b> น่าจะใช่ (Probable)</div>
                        <div><b>1–4</b> อาจจะใช่ (Possible) · <b>≤ 0</b> น่าสงสัย (Doubtful)</div>
                    </div>
                    <div class="text-end">
                        <div class="small text-muted mb-0">คะแนนรวม</div>
                        <div class="af-naranjo-score" id="afNaranjoScoreLive">—</div>
                        <div class="fw-bold" id="afNaranjoCatLive" style="color:#c2410c;"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-outline-secondary btn-sm" id="btnNaranjoClear">ล้างคำตอบ</button>
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="button" class="btn btn-primary btn-sm fw-bold" id="btnNaranjoSave">
                    <i class="fas fa-save me-1"></i>บันทึก Naranjo
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="afAckModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h6 class="modal-title fw-bold mb-0"><i class="fas fa-user-check me-1 text-info"></i>รับเคส</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="ack_case_id">
                <label class="form-label small fw-bold mb-1">ผู้รับเคส (เภสัชกร)</label>
                <select class="form-select form-select-sm" id="ack_pick_user"></select>
                <div class="form-text">ค่าเริ่มต้น = ผู้ที่ login อยู่ สามารถเลือกเภสัชกรคนอื่นได้</div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="button" class="btn btn-info btn-sm fw-bold text-white" id="btnAckConfirm">
                    <i class="fas fa-check me-1"></i>ยืนยันรับเคส
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="afTlEditModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h6 class="modal-title fw-bold mb-0">แก้ไขข้อความไทม์ไลน์</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="tl_edit_id">
                <div class="small text-muted mb-1" id="tl_edit_label"></div>
                <textarea class="form-control form-control-sm" id="tl_edit_note" rows="6" placeholder="ข้อความในไทม์ไลน์"></textarea>
                <div class="form-text">แก้ไขได้แม้เคสปิดแล้ว</div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="button" class="btn btn-af btn-sm fw-bold" id="btnTlEditSave"><i class="fas fa-save me-1"></i>บันทึก</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="afLightbox" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content bg-dark">
            <div class="modal-body text-center p-2">
                <img id="afLightboxImg" src="" alt="photo">
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/af_photo_compress.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const AF_CAN_ASSESS = <?= $can_assess ? 'true' : 'false' ?>;
const AF_OPEN = <?= (int)$open_id ?>;
const AF_USER_ID = <?= (int)$user['id'] ?>;
const AF_USER_NAME = <?= json_encode($user['name'], JSON_UNESCAPED_UNICODE) ?>;
const AF_UNIT_WARD = <?= json_encode($unit_ward, JSON_UNESCAPED_UNICODE) ?>;
const AF_WARD_LOCKED = <?= $ward_locked ? 'true' : 'false' ?>;
const AF_SCOPE_WARD = <?= json_encode($scope_ward, JSON_UNESCAPED_UNICODE) ?>;
let afMeta = { channels: {}, summaries: {}, wards: [], pharmacists: [] };
let afModal, afLight, afTlEditModal = null, afAckModal = null;
let afTimelineById = {};
let afChronology = [];
let afAssessDrugs = [];
let afDrugSuggestTimer = null;
let afLastAllergies = [];
const AF_DRUG_SUMMARY_KEYS = { allergy: 1, monitor: 1, adr_type_a: 1, existing_history: 1 };
let afNaranjo = null;
let afNaranjoModal = null;
let afRegiscar = null;
let afRegiscarModal = null;
let afDressLabs = null;
let afOwnerBaseline = '';
let afLastFilledId = 0;
let dashStage = 'all';
const NARANJO_QUESTIONS = <?= json_encode(af_naranjo_questions(), JSON_UNESCAPED_UNICODE) ?>;
const REGISCAR_QUESTIONS = <?= json_encode(af_regiscar_questions(), JSON_UNESCAPED_UNICODE) ?>;
const CHRONO_STATUS = {
    start: { label: 'เริ่มยาครั้งแรก', icon: '🟢', cls: 'start' },
    dose: { label: 'ทานยา', icon: '', cls: '' },
    onset: { label: 'จุดเกิดอาการ', icon: '🔴', cls: 'onset' },
    stop: { label: 'หยุดยาที่สงสัย', icon: '⚠️', cls: 'stop' },
    note: { label: 'หมายเหตุ', icon: '', cls: '' }
};
const THAI_MONTHS_SHORT = ['', 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
const SUM_CLASS = {
    '': 'badge-pending', allergy: 'badge-allergy', monitor: 'badge-monitor',
    not_allergy: 'badge-ok', adr_type_a: 'badge-adr', existing_history: 'badge-hist',
    unclosed: 'badge-pending'
};
const STAGE_CLASS = {
    reported: 'bg-secondary',
    acknowledged: 'bg-info text-dark',
    following: 'bg-warning text-dark',
    closed: 'bg-success'
};

function formatThaiChronoDate(dateStr, timeStr) {
    const m = String(dateStr || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) return esc(dateStr || '-');
    const y = parseInt(m[1], 10);
    const mo = parseInt(m[2], 10);
    const d = parseInt(m[3], 10);
    const be = String((y + 543) % 100).padStart(2, '0');
    let s = d + ' ' + (THAI_MONTHS_SHORT[mo] || '') + ' ' + be;
    if (timeStr) s += ' (' + esc(timeStr) + ' น.)';
    return s;
}

function sortChronology(list) {
    return (list || []).slice().sort((a, b) => {
        const ka = (a.date || '') + ' ' + (a.time || '99:99');
        const kb = (b.date || '') + ' ' + (b.time || '99:99');
        return ka < kb ? -1 : (ka > kb ? 1 : 0);
    });
}

function chronologyText(list) {
    const items = sortChronology(list);
    if (!items.length) return '';
    const lines = ['Timeline บันทึกการแพ้ยา:'];
    items.forEach(row => {
        const m = String(row.date || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
        let dateLabel = row.date || '';
        if (m) {
            const be = String((parseInt(m[1], 10) + 543) % 100).padStart(2, '0');
            dateLabel = parseInt(m[3], 10) + ' ' + (THAI_MONTHS_SHORT[parseInt(m[2], 10)] || '') + ' ' + be;
            if (row.time) dateLabel += ' (' + row.time + ' น.)';
        }
        const parts = [dateLabel];
        if (row.drug) parts.push(row.drug);
        if (row.event) parts.push(row.event);
        const st = CHRONO_STATUS[row.status];
        if (st) parts.push('[' + st.label + ']');
        lines.push('- ' + parts.join(' | '));
    });
    return lines.join('\n');
}

function upsertChronologyBlock(text, block) {
    const re = /Timeline บันทึกการแพ้ยา:(?:\n-[^\n]*)*/;
    text = String(text || '').trim();
    block = String(block || '').trim();
    if (re.test(text)) {
        return (block ? text.replace(re, block) : text.replace(re, '')).trim();
    }
    return block ? (text ? (text + '\n' + block) : block) : text;
}

function syncChronologyIntoAssess() {
    const $a = $('#md_assess');
    if (!$a.length) return;
    $a.val(upsertChronologyBlock($a.val(), chronologyText(afChronology)));
}

function renderChronologyRows(list, editable) {
    const items = sortChronology(list);
    if (!items.length) return '';
    return items.map((row, idx) => {
        const st = CHRONO_STATUS[row.status] || null;
        const drugCls = row.status === 'stop' ? 'af-chrono-drug-stop' : '';
        const eventCls = row.status === 'onset' ? 'af-chrono-event-onset' : '';
        const statusHtml = st
            ? ('<span class="af-chrono-st ' + esc(st.cls) + '">' + (st.icon ? st.icon + ' ' : '') + esc(st.label) + '</span>')
            : '—';
        const actions = editable
            ? ('<button type="button" class="btn btn-link btn-sm p-0 text-secondary btn-chrono-edit" data-idx="' + idx + '" title="แก้ไข"><i class="fas fa-pen"></i></button> '
                + '<button type="button" class="btn btn-link btn-sm p-0 text-danger btn-chrono-del" data-idx="' + idx + '" title="ลบ"><i class="fas fa-trash-alt"></i></button>')
            : '';
        return '<tr data-idx="' + idx + '">'
            + '<td class="af-chrono-date">' + formatThaiChronoDate(row.date, row.time) + '</td>'
            + '<td class="' + drugCls + '">' + (row.drug ? esc(row.drug) : '—') + '</td>'
            + '<td class="' + eventCls + '">' + (row.event ? esc(row.event) : '—') + '</td>'
            + '<td>' + statusHtml + '</td>'
            + (editable ? ('<td class="text-nowrap">' + actions + '</td>') : '')
            + '</tr>';
    }).join('');
}

function refreshChronologyUI() {
    afChronology = sortChronology(afChronology);
    const html = renderChronologyRows(afChronology, true);
    const preview = renderChronologyRows(afChronology, false);
    $('#afChronoTbody').html(html);
    $('#afChronoPreviewBody').html(preview);
    $('#afChronoEmpty').toggle(!afChronology.length);
    const panelOpen = $('#afChronoPanel').is(':visible');
    if (!panelOpen && afChronology.length) {
        $('#afChronoPreviewOnly').show();
    } else {
        $('#afChronoPreviewOnly').hide();
    }
    // sync drug datalist from existing rows
    const drugs = [];
    afChronology.forEach(r => { if (r.drug && drugs.indexOf(r.drug) < 0) drugs.push(r.drug); });
    const dl = document.getElementById('afChronoDrugList');
    if (dl) dl.innerHTML = drugs.map(d => '<option value="' + esc(d) + '">').join('');
}

function resetChronoForm() {
    $('#chrono_edit_idx').val('-1');
    $('#chrono_date').val('');
    $('#chrono_time').val('');
    $('#chrono_drug').val('');
    $('#chrono_event').val('');
    $('#chrono_status').val('');
    $('#btnChronoAdd').html('<i class="fas fa-plus me-1"></i>เพิ่มเหตุการณ์');
}

function setChronology(list) {
    afChronology = sortChronology(Array.isArray(list) ? list : []);
    refreshChronologyUI();
    if (afChronology.length) {
        // แสดง preview แม้ยังไม่เปิดแผงแก้ไข
        $('#afChronoPreviewOnly').show();
    }
}

function formatHosAllergyItem(a) {
    a = a || {};
    let s = esc(a.agent || '');
    if (a.symptom) s += ' (' + esc(a.symptom) + ')';
    const d = a.report_date_fmt || '';
    if (d) s += ' <span class="text-muted">· วันที่ประเมิน ' + esc(d) + '</span>';
    return s;
}

function summaryNeedsDrugs(sum) {
    return !!AF_DRUG_SUMMARY_KEYS[String(sum || '')];
}

function setAssessedDrugs(list) {
    afAssessDrugs = Array.isArray(list) ? list.map(function (d) {
        return {
            name: String((d && (d.name || d.text || d.drug)) || '').trim(),
            icode: String((d && d.icode) || '').trim(),
            tmt_name: String((d && (d.tmt_name || d.name_tmt)) || '').trim(),
            source: String((d && d.source) || '') || 'free'
        };
    }).filter(function (d) { return d.name !== ''; }) : [];
    if (!afAssessDrugs.length) afAssessDrugs = [{ name: '', icode: '', tmt_name: '', source: 'free' }];
    renderAssessDrugRows();
    toggleAssessDrugsPanel();
}

function collectAssessedDrugs() {
    const out = [];
    $('#mdAssessDrugRows .af-drug-row').each(function () {
        const $row = $(this);
        const name = String($row.find('.af-drug-name').val() || '').trim();
        if (!name) return;
        out.push({
            name: name,
            icode: String($row.find('.af-drug-icode').val() || '').trim(),
            tmt_name: String($row.find('.af-drug-tmt').val() || '').trim(),
            source: String($row.find('.af-drug-source').val() || '') || 'free'
        });
    });
    afAssessDrugs = out;
    return out;
}

function toggleAssessDrugsPanel() {
    const show = summaryNeedsDrugs($('#md_summary').val());
    $('#mdAssessDrugsWrap').toggle(show);
    if (show && !$('#mdAssessDrugRows .af-drug-row').length) {
        setAssessedDrugs(afAssessDrugs);
    }
}

function renderAssessDrugRows() {
    const rows = afAssessDrugs.length ? afAssessDrugs : [{ name: '', icode: '', tmt_name: '', source: 'free' }];
    let html = '';
    rows.forEach(function (d, idx) {
        const meta = d.icode
            ? ('icode ' + d.icode + (d.tmt_name ? ' · TMT' : ''))
            : (d.name ? 'พิมพ์ชื่อเองได้' : 'ค้น TMT หรือพิมพ์ชื่อเอง');
        html += '<div class="af-drug-row mb-2" data-idx="' + idx + '">'
            + '<div class="input-group input-group-sm">'
            + '<input type="text" class="form-control af-drug-name" placeholder="พิมพ์ชื่อยา (ค้นจาก TMT)..." value="' + esc(d.name || '') + '" autocomplete="off">'
            + '<button type="button" class="btn btn-outline-danger af-drug-remove" title="ลบรายการ"><i class="fas fa-times"></i></button>'
            + '</div>'
            + '<div class="af-drug-suggest"></div>'
            + '<div class="af-drug-meta mt-1">' + esc(meta) + '</div>'
            + '<input type="hidden" class="af-drug-icode" value="' + esc(d.icode || '') + '">'
            + '<input type="hidden" class="af-drug-tmt" value="' + esc(d.tmt_name || '') + '">'
            + '<input type="hidden" class="af-drug-source" value="' + esc(d.source || 'free') + '">'
            + '</div>';
    });
    $('#mdAssessDrugRows').html(html);
}

function parseDrugSelectId(id) {
    const s = String(id || '');
    const p = s.indexOf('|');
    if (p < 0) return { icode: s, tmt_name: '' };
    return { icode: s.slice(0, p), tmt_name: s.slice(p + 1) };
}

function searchAssessDrugTmt($row, term) {
    const $box = $row.find('.af-drug-suggest');
    term = String(term || '').trim();
    if (term.length < 1) {
        $box.hide().empty();
        return;
    }
    fetch('fetch_hosxp_drugs_select_api.php?q=' + encodeURIComponent(term), { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            const results = (data && data.results) || [];
            if (!results.length) {
                $box.html('<div class="px-2 py-1 small text-muted">ไม่พบใน TMT — พิมพ์ชื่อเองได้</div>').show();
                return;
            }
            $box.html(results.slice(0, 20).map(function (it) {
                return '<button type="button" class="af-drug-pick" data-id="' + esc(it.id || '') + '" data-text="' + esc(it.text || '') + '">'
                    + esc(it.text || '') + '</button>';
            }).join('')).show();
        })
        .catch(function () { $box.hide().empty(); });
}

function ymdAddDays(ymd, days) {
    const d = new Date(ymd + 'T00:00:00');
    d.setDate(d.getDate() + days);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + day;
}

function formatThaiDateShort(ymd) {
    const m = String(ymd || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) return ymd || '';
    const be = String((parseInt(m[1], 10) + 543) % 100).padStart(2, '0');
    return parseInt(m[3], 10) + '/' + parseInt(m[2], 10) + '/' + be;
}

function drugKeyFromChrono(drug) {
    const s = String(drug || '').trim();
    if (!s) return '';
    // จัดกลุ่มด้วยชื่อยาก่อนขนาดยา
    const m = s.match(/^([A-Za-zก-๙0-9.\-\/+]+)/);
    return (m ? m[1] : s).toLowerCase();
}

function buildChronoGraphModel(list) {
    const items = sortChronology(list || []);
    if (!items.length) return null;
    const dateSet = {};
    items.forEach(r => { if (r.date) dateSet[r.date] = true; });
    const sorted = Object.keys(dateSet).sort();
    if (!sorted.length) return null;
    let cur = sorted[0];
    const end = sorted[sorted.length - 1];
    const dates = [];
    while (cur <= end) {
        dates.push(cur);
        cur = ymdAddDays(cur, 1);
        if (dates.length > 120) break; // safety
    }

    const reactions = [];
    items.forEach(r => {
        if (r.status !== 'onset') return;
        reactions.push({
            id: 'R' + (reactions.length + 1),
            date: r.date,
            event: r.event || 'จุดเกิดอาการ',
            drug: r.drug || ''
        });
    });

    const groups = {};
    items.forEach(r => {
        const raw = String(r.drug || '').trim();
        if (!raw) return;
        const key = drugKeyFromChrono(raw);
        if (!groups[key]) {
            groups[key] = { key: key, label: raw, doseHints: [], events: [] };
        }
        groups[key].events.push(r);
        if (raw && groups[key].doseHints.indexOf(raw) < 0) groups[key].doseHints.push(raw);
        // keep longest label as display name
        if (raw.length > groups[key].label.length) groups[key].label = raw;
    });

    const drugs = Object.keys(groups).map(k => {
        const g = groups[k];
        const ev = sortChronology(g.events);
        let start = ev[0].date;
        let endD = ev[ev.length - 1].date;
        let ended = false;
        let startUnknown = false;
        ev.forEach(e => {
            if (e.status === 'start') start = e.date;
            if (e.status === 'stop') { endD = e.date; ended = true; }
        });
        // ถ้ามี onset ของยานี้หลัง stop ไม่ขยาย
        const dose = g.doseHints[0] || g.label;
        return {
            label: g.label,
            dose: dose,
            start: start,
            end: endD,
            ended: ended,
            startUnknown: startUnknown
        };
    });

    return { dates: dates, drugs: drugs, reactions: reactions, items: items };
}

function renderChronoGraphSvg(model) {
    if (!model || !model.dates.length) {
        return '<div class="text-muted text-center p-4">ยังไม่มีข้อมูล Timeline</div>';
    }
    const left = 168;
    const top = 42;
    const colW = Math.max(48, Math.min(72, Math.floor(720 / Math.max(1, model.dates.length))));
    const rowH = 48;
    const width = left + model.dates.length * colW + 24;
    const height = top + Math.max(1, model.drugs.length) * rowH + 36;
    const dateIndex = {};
    model.dates.forEach((d, i) => { dateIndex[d] = i; });

    let svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '" viewBox="0 0 ' + width + ' ' + height + '">';
    svg += '<rect width="100%" height="100%" fill="#fff"/>';

    // date headers + vertical guides
    model.dates.forEach((d, i) => {
        const x = left + i * colW + colW / 2;
        svg += '<text x="' + x + '" y="18" text-anchor="middle" font-size="11" font-weight="700" fill="#334155">'
            + esc(formatThaiDateShort(d)) + '</text>';
        svg += '<line x1="' + x + '" y1="' + (top - 8) + '" x2="' + x + '" y2="' + (height - 20) + '" stroke="#cbd5e1" stroke-width="1" stroke-dasharray="3,3"/>';
    });

    // drug rows
    model.drugs.forEach((drug, ri) => {
        const y = top + ri * rowH + rowH / 2;
        const yLine = y;
        svg += '<text x="8" y="' + (y - 4) + '" font-size="12" font-weight="700" fill="#0f172a">'
            + esc(drug.label.length > 22 ? drug.label.slice(0, 20) + '…' : drug.label) + '</text>';
        const si = dateIndex[drug.start];
        const ei = dateIndex[drug.end];
        if (si == null || ei == null) return;
        const x1 = left + si * colW + colW / 2;
        const x2 = left + ei * colW + colW / 2;
        svg += '<line x1="' + x1 + '" y1="' + yLine + '" x2="' + x2 + '" y2="' + yLine + '" stroke="#2563eb" stroke-width="3" stroke-linecap="round"/>';
        // dose label above bar
        if (drug.dose) {
            const mx = (x1 + x2) / 2;
            svg += '<text x="' + mx + '" y="' + (yLine - 10) + '" text-anchor="middle" font-size="10" fill="#1d4ed8">'
                + esc(drug.dose.length > 28 ? drug.dose.slice(0, 26) + '…' : drug.dose) + '</text>';
        }
        // start marker
        if (drug.startUnknown) {
            svg += '<polygon points="' + x1 + ',' + (yLine - 7) + ' ' + (x1 - 7) + ',' + (yLine + 5) + ' ' + (x1 + 7) + ',' + (yLine + 5) + '" fill="none" stroke="#2563eb" stroke-width="2"/>';
        } else {
            svg += '<circle cx="' + x1 + '" cy="' + yLine + '" r="5" fill="#fff" stroke="#2563eb" stroke-width="2.5"/>';
        }
        // end marker
        if (drug.ended) {
            svg += '<circle cx="' + x2 + '" cy="' + yLine + '" r="5" fill="#2563eb" stroke="#1e40af" stroke-width="1"/>';
        } else {
            svg += '<polygon points="' + (x2 + 2) + ',' + yLine + ' ' + (x2 - 6) + ',' + (yLine - 6) + ' ' + (x2 - 6) + ',' + (yLine + 6) + '" fill="#2563eb"/>';
        }
    });

    // ADR vertical markers
    model.reactions.forEach(rx => {
        const i = dateIndex[rx.date];
        if (i == null) return;
        const x = left + i * colW + colW / 2;
        svg += '<line x1="' + x + '" y1="' + (top - 4) + '" x2="' + x + '" y2="' + (height - 22) + '" stroke="#e11d48" stroke-width="2.5"/>';
        svg += '<polygon points="' + x + ',' + (height - 8) + ' ' + (x - 7) + ',' + (height - 20) + ' ' + (x + 7) + ',' + (height - 20) + '" fill="#e11d48"/>';
        svg += '<text x="' + x + '" y="' + (height - 2) + '" text-anchor="middle" font-size="11" font-weight="800" fill="#be123c">'
            + esc(rx.id) + '</text>';
    });

    if (!model.drugs.length) {
        svg += '<text x="' + (left + 20) + '" y="' + (top + 28) + '" font-size="13" fill="#94a3b8">ยังไม่มีรายการยาใน Timeline — มีเฉพาะเหตุการณ์</text>';
    }

    svg += '</svg>';
    return svg;
}

function openChronoGraphModal() {
    if (!afChronology.length) {
        alert('ยังไม่มีข้อมูล Timeline — กรุณาสร้าง Timeline ก่อน');
        return;
    }
    const model = buildChronoGraphModel(afChronology);
    $('#cg_ptname').text($('#md_ptname').val() || '—');
    $('#cg_hn').text($('#md_hn').val() || '—');
    $('#cg_ward').text($('#md_ward').val() || '—');
    $('#cg_owner').text(selectedOwnerPayload().owner_name || '—');
    $('#afChronoGraphSvgWrap').html(renderChronoGraphSvg(model));
    if (model && model.reactions.length) {
        $('#afChronoGraphAdr').html(model.reactions.map(r =>
            '<div><b>' + esc(r.id) + ':</b> ' + esc(r.event)
            + (r.drug ? ' (' + esc(r.drug) + ')' : '')
            + ' — ' + esc(formatThaiDateShort(r.date)) + '</div>'
        ).join(''));
    } else {
        $('#afChronoGraphAdr').html('<span class="text-muted">ยังไม่มีจุดเกิดอาการ (onset) ใน Timeline</span>');
    }
    const note = ($('#md_assess').val() || '').trim();
    $('#afChronoGraphNote').text(note || '—');
    const el = document.getElementById('afChronoGraphModal');
    if (el) {
        const m = bootstrap.Modal.getOrCreateInstance(el);
        m.show();
    }
}

function addOrUpdateChronologyRow() {
    const date = ($('#chrono_date').val() || '').trim();
    const time = ($('#chrono_time').val() || '').trim();
    const drug = ($('#chrono_drug').val() || '').trim();
    const event = ($('#chrono_event').val() || '').trim();
    const status = ($('#chrono_status').val() || '').trim();
    if (!date) { alert('กรุณาเลือกวันที่'); return; }
    if (!drug && !event && !status) { alert('กรุณากรอกยา / เหตุการณ์ หรือเลือกสถานะ'); return; }
    const row = { date: date, time: time, drug: drug, event: event, status: status };
    const editIdx = parseInt($('#chrono_edit_idx').val() || -1, 10);
    if (editIdx >= 0 && editIdx < afChronology.length) {
        afChronology[editIdx] = row;
    } else {
        afChronology.push(row);
    }
    setChronology(afChronology);
    resetChronoForm();
    syncChronologyIntoAssess();
    // เปิดแผงไว้
    $('#afChronoPanel').show();
    $('#afChronoPreviewOnly').hide();
    $('#btnChronoToggle').html('<i class="fas fa-chevron-up me-1"></i>ย่อ Timeline');
}

function loadChronologyRowToForm(idx) {
    const row = afChronology[idx];
    if (!row) return;
    $('#chrono_edit_idx').val(String(idx));
    $('#chrono_date').val(row.date || '');
    $('#chrono_time').val(row.time || '');
    $('#chrono_drug').val(row.drug || '');
    $('#chrono_event').val(row.event || '');
    $('#chrono_status').val(row.status || '');
    $('#btnChronoAdd').html('<i class="fas fa-save me-1"></i>บันทึกแก้ไข');
    $('#afChronoPanel').show();
    $('#afChronoPreviewOnly').hide();
}

function naranjoCategory(score) {
    score = parseInt(score, 10);
    if (isNaN(score)) return { code: '', label: '' };
    if (score >= 9) return { code: 'definite', label: 'ใช่แน่ (Definite)' };
    if (score >= 5) return { code: 'probable', label: 'น่าจะใช่ (Probable)' };
    if (score >= 1) return { code: 'possible', label: 'อาจจะใช่ (Possible)' };
    return { code: 'doubtful', label: 'น่าสงสัย (Doubtful)' };
}

function formatPts(n) {
    n = parseInt(n, 10) || 0;
    if (n > 0) return '(+)' + n;
    if (n < 0) return '(' + n + ')';
    return '(0)';
}

function buildNaranjoTable() {
    const $tb = $('#afNaranjoTbody');
    if (!$tb.length || $tb.children().length) return;
    let html = '';
    Object.keys(NARANJO_QUESTIONS).forEach(k => {
        const q = NARANJO_QUESTIONS[k];
        const name = 'naranjo_q_' + k;
        html += '<tr data-q="' + k + '">'
            + '<td class="q"><b>' + k + '.</b> ' + esc(q.q) + '</td>'
            + '<td class="opt"><label class="mb-0">'
            + '<input type="radio" name="' + name + '" value="yes" class="naranjo-ans">'
            + '<span class="pts">' + formatPts(q.yes) + '</span></label></td>'
            + '<td class="opt"><label class="mb-0">'
            + '<input type="radio" name="' + name + '" value="no" class="naranjo-ans">'
            + '<span class="pts">' + formatPts(q.no) + '</span></label></td>'
            + '<td class="opt"><label class="mb-0">'
            + '<input type="radio" name="' + name + '" value="dk" class="naranjo-ans">'
            + '<span class="pts">' + formatPts(q.dk) + '</span></label></td>'
            + '</tr>';
    });
    $tb.html(html);
}

function readNaranjoAnswersFromForm() {
    const answers = {};
    let score = 0;
    let answered = 0;
    Object.keys(NARANJO_QUESTIONS).forEach(k => {
        const n = parseInt(k, 10);
        const v = ($('input[name="naranjo_q_' + k + '"]:checked').val() || '');
        answers[n] = v;
        if (v === 'yes' || v === 'no' || v === 'dk') {
            score += parseInt(NARANJO_QUESTIONS[k][v], 10) || 0;
            answered++;
        }
    });
    if (!answered) return null;
    const cat = naranjoCategory(score);
    return {
        answers: answers,
        score: score,
        category: cat.code,
        category_label: cat.label,
        answered: answered
    };
}

function applyNaranjoToForm(data) {
    buildNaranjoTable();
    Object.keys(NARANJO_QUESTIONS).forEach(k => {
        $('input[name="naranjo_q_' + k + '"]').prop('checked', false);
    });
    const ans = (data && data.answers) ? data.answers : {};
    Object.keys(NARANJO_QUESTIONS).forEach(k => {
        const v = ans[k] || ans[parseInt(k, 10)] || '';
        if (v) $('input[name="naranjo_q_' + k + '"][value="' + v + '"]').prop('checked', true);
    });
    refreshNaranjoLiveScore();
}

function refreshNaranjoLiveScore() {
    const cur = readNaranjoAnswersFromForm();
    if (!cur) {
        $('#afNaranjoScoreLive').text('—');
        $('#afNaranjoCatLive').text('');
        return;
    }
    $('#afNaranjoScoreLive').text(String(cur.score));
    $('#afNaranjoCatLive').text(cur.category_label);
}

function refreshNaranjoSummary() {
    const $s = $('#afNaranjoSummary');
    if (!$s.length) return;
    if (!afNaranjo || afNaranjo.score == null) {
        $s.html('<span class="text-muted fw-normal">ยังไม่บันทึก</span>');
        return;
    }
    const cls = 'badge-naranjo-' + (afNaranjo.category || 'doubtful');
    $s.html('<span class="badge ' + cls + '">คะแนน ' + esc(afNaranjo.score)
        + ' · ' + esc(afNaranjo.category_label || '') + '</span>');
}

function setNaranjo(data) {
    afNaranjo = data && data.answered ? data : null;
    refreshNaranjoSummary();
}

function naranjoText(data) {
    if (!data || data.score == null) return '';
    return 'Naranjo: คะแนน ' + data.score + ' — ' + (data.category_label || '')
        + ' (ตอบครบ ' + (data.answered || 0) + '/10 ข้อ)';
}

function openNaranjoModal() {
    buildNaranjoTable();
    applyNaranjoToForm(afNaranjo);
    if (!afNaranjoModal && document.getElementById('afNaranjoModal')) {
        afNaranjoModal = new bootstrap.Modal(document.getElementById('afNaranjoModal'));
    }
    if (afNaranjoModal) afNaranjoModal.show();
}

function regiscarCategory(score) {
    score = parseInt(score, 10);
    if (isNaN(score)) return { code: '', label: '' };
    if (score >= 6) return { code: 'definite', label: 'ใช่แน่ DRESS (Definite)' };
    if (score >= 4) return { code: 'probable', label: 'น่าจะเป็น DRESS (Probable)' };
    if (score >= 2) return { code: 'possible', label: 'อาจเป็น DRESS (Possible)' };
    return { code: 'no', label: 'ไม่เข้าเกณฑ์ DRESS (No case)' };
}

function formatRegiPts(n) {
    n = parseInt(n, 10) || 0;
    if (n > 0) return '+' + n;
    return String(n);
}

function buildRegiscarForm() {
    const $b = $('#afRegiscarBody');
    if (!$b.length || $b.children().length) return;
    let html = '';
    Object.keys(REGISCAR_QUESTIONS).forEach(key => {
        const q = REGISCAR_QUESTIONS[key];
        html += '<div class="af-regi-item" data-key="' + esc(key) + '">'
            + '<div class="af-regi-q">' + esc(q.q) + '</div>'
            + '<div class="af-regi-opts">';
        Object.keys(q.options || {}).forEach(optKey => {
            const opt = q.options[optKey];
            const id = 'regi_' + key + '_' + optKey;
            html += '<label for="' + id + '">'
                + '<span><input type="radio" class="regiscar-ans" name="regiscar_' + esc(key) + '" id="' + id + '" value="' + esc(optKey) + '"> '
                + esc(opt.label) + '</span>'
                + '<span class="af-regi-pts">' + formatRegiPts(opt.score) + '</span>'
                + '</label>';
        });
        html += '</div></div>';
    });
    $b.html(html);
}

function readRegiscarAnswersFromForm() {
    const answers = {};
    let score = 0;
    let answered = 0;
    Object.keys(REGISCAR_QUESTIONS).forEach(key => {
        const v = ($('input[name="regiscar_' + key + '"]:checked').val() || '');
        answers[key] = v;
        if (v && REGISCAR_QUESTIONS[key].options[v]) {
            score += parseInt(REGISCAR_QUESTIONS[key].options[v].score, 10) || 0;
            answered++;
        }
    });
    if (!answered) return null;
    const cat = regiscarCategory(score);
    return {
        answers: answers,
        score: score,
        category: cat.code,
        category_label: cat.label,
        answered: answered
    };
}

function applyRegiscarToForm(data) {
    buildRegiscarForm();
    Object.keys(REGISCAR_QUESTIONS).forEach(key => {
        $('input[name="regiscar_' + key + '"]').prop('checked', false);
    });
    const ans = (data && data.answers) ? data.answers : {};
    Object.keys(REGISCAR_QUESTIONS).forEach(key => {
        const v = ans[key] || '';
        if (v) $('input[name="regiscar_' + key + '"][value="' + v + '"]').prop('checked', true);
    });
    refreshRegiscarLiveScore();
}

function refreshRegiscarLiveScore() {
    const cur = readRegiscarAnswersFromForm();
    if (!cur) {
        $('#afRegiscarScoreLive').text('—');
        $('#afRegiscarCatLive').text('');
        return;
    }
    $('#afRegiscarScoreLive').text(String(cur.score));
    $('#afRegiscarCatLive').text(cur.category_label);
}

function refreshRegiscarSummary() {
    const $s = $('#afRegiscarSummary');
    if (!$s.length) return;
    if (!afRegiscar || afRegiscar.score == null) {
        $s.html('<span class="text-muted fw-normal">ยังไม่บันทึก</span>');
        return;
    }
    const cls = 'badge-regiscar-' + (afRegiscar.category || 'no');
    $s.html('<span class="badge ' + cls + '">คะแนน ' + esc(afRegiscar.score)
        + ' · ' + esc(afRegiscar.category_label || '') + '</span>');
}

function setRegiscar(data) {
    afRegiscar = data && data.answered ? data : null;
    refreshRegiscarSummary();
}

function regiscarText(data) {
    if (!data || data.score == null) return '';
    return 'RegiSCAR (DRESS): คะแนน ' + data.score + ' — ' + (data.category_label || '')
        + ' (ตอบ ' + (data.answered || 0) + '/10 ข้อ)';
}

function formatDressLabCell(lab, label, hiThreshold) {
    if (!lab) {
        return '<span class="text-muted">' + esc(label) + ': ไม่พบผล</span>';
    }
    const v = lab.value;
    const hi = (v != null && hiThreshold != null && v > hiThreshold);
    const valHtml = (v != null)
        ? ('<span class="af-dress-lab-val ' + (hi ? 'hi' : 'ok') + '">' + esc(lab.raw || v) + '</span>')
        : ('<span class="af-dress-lab-val">' + esc(lab.raw || '-') + '</span>');
    const when = lab.order_date
        ? (' <span class="text-muted">(' + esc(lab.order_date) + (lab.order_time ? ' ' + esc(lab.order_time) : '') + ')</span>')
        : '';
    const warn = hi ? ' <i class="fas fa-exclamation-triangle text-danger" title="สูงกว่าเกณฑ์"></i>' : '';
    return '<span>' + esc(label) + ' ' + valHtml + warn + when + '</span>';
}

function renderDressLabPanels(data) {
    afDressLabs = data || null;
    const $panel = $('#afDressLabPanel');
    const $banner = $('#afRegiscarLabBanner');
    const $badge = $('#afDressAlertBadge');
    if (!data || (!data.atypical && !data.eosinophil && !data.ok)) {
        $panel.hide().html('');
        $banner.hide().html('');
        $badge.hide().html('');
        if (data && data.message) {
            $panel.html('<span class="text-muted">' + esc(data.message) + '</span>').show();
        }
        return;
    }
    const parts = [
        formatDressLabCell(data.atypical, 'Atypical lymphocytes', 5),
        formatDressLabCell(data.eosinophil, 'Eosinophil', 10)
    ];
    const codes = 'รหัส ' + esc(data.atypical_code || '1107') + ' / ' + esc(data.eosinophil_code || '1109');
    let html = '<div class="d-flex flex-wrap gap-3 align-items-center">'
        + parts.map(p => '<div>' + p + '</div>').join('')
        + '<div class="text-muted">' + codes + '</div></div>';
    if (data.dress_alert) {
        html += '<div class="mt-1 af-dress-alert"><i class="fas fa-radiation"></i> Lab ผิดปกติ — อาจเป็น DRESS (Atypical &gt; 5 และ Eosinophil &gt; 10)</div>';
        $badge.html('<span class="af-dress-alert"><i class="fas fa-exclamation-triangle"></i> อาจเป็น DRESS</span>').show();
    } else {
        $badge.hide().html('');
    }
    $panel.html(html).show();
    $banner.html(html).show();
}

function applyDressLabSuggestToRegiscarForm(force) {
    if (!afDressLabs || !afDressLabs.suggest) return;
    const sug = afDressLabs.suggest;
    ['atypical_lymphocytes', 'eosinophilia'].forEach(key => {
        const want = sug[key] || '';
        if (!want) return;
        const $checked = $('input[name="regiscar_' + key + '"]:checked');
        if (!force && $checked.length) return;
        const $opt = $('input[name="regiscar_' + key + '"][value="' + want + '"]');
        if ($opt.length) $opt.prop('checked', true);
    });
    refreshRegiscarLiveScore();
}

function openRegiscarModal() {
    buildRegiscarForm();
    applyRegiscarToForm(afRegiscar);
    // ถ้ายังไม่เคยบันทึก RegiSCAR ให้เติมจาก Lab อัตโนมัติ
    if (!afRegiscar || !afRegiscar.answered) {
        applyDressLabSuggestToRegiscarForm(true);
    } else {
        applyDressLabSuggestToRegiscarForm(false);
    }
    renderDressLabPanels(afDressLabs);
    if (!afRegiscarModal && document.getElementById('afRegiscarModal')) {
        afRegiscarModal = new bootstrap.Modal(document.getElementById('afRegiscarModal'));
    }
    if (afRegiscarModal) afRegiscarModal.show();
}

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function hosxpBadge(c) {
    if (c.hosxp_logged) {
        const drugs = (c.hosxp_agents || []).slice(0, 2).join(', ');
        const extra = c.hosxp_match === 'drug' && drugs ? '<div class="small">' + esc(drugs) + '</div>' : '';
        return '<span class="badge bg-success">ลงข้อมูลใน HOSxP แล้ว</span>' + extra;
    }
    if (c.hosxp_label === 'ยังไม่พบใน HOSxP') {
        return '<span class="badge bg-warning text-dark">ยังไม่พบใน HOSxP</span>';
    }
    return '<span class="text-muted">-</span>';
}
function summaryBadge(code, label) {
    const cls = SUM_CLASS[code] || 'badge-pending';
    return '<span class="badge ' + cls + '">' + esc(label || 'รอประเมิน') + '</span>';
}
function stageBadge(c) {
    if (c.is_shift_handover) {
        return '<span class="badge bg-danger">ส่งต่อเวร(ไม่ระบุชื่อ)</span>';
    }
    const st = c.workflow_stage || 'reported';
    const cls = STAGE_CLASS[st] || 'bg-secondary';
    return '<span class="badge ' + cls + '">' + esc(c.workflow_label || 'แจ้งแพ้ยา') + '</span>';
}
function fmtDate(iso) {
    if (!iso) return '-';
    const p = String(iso).split('-');
    if (p.length !== 3) return iso;
    return p[2] + '/' + p[1] + '/' + p[0];
}
function fillWardSelect(sel, wards) {
    const $s = $(sel);
    if (!$s.length) return;
    if (AF_WARD_LOCKED && AF_SCOPE_WARD) {
        $s.prop('disabled', true);
        $s.html('<option value="' + esc(AF_SCOPE_WARD) + '">' + esc(AF_SCOPE_WARD) + '</option>');
        $s.val(AF_SCOPE_WARD);
        return;
    }
    const cur = $s.val() || AF_UNIT_WARD || '';
    let html = '<option value="">ทั้งหมด</option>';
    (wards || []).forEach(w => {
        html += '<option value="' + esc(w) + '">' + esc(w) + '</option>';
    });
    if (cur && !(wards || []).some(w => w === cur)) {
        html += '<option value="' + esc(cur) + '">' + esc(cur) + '</option>';
    }
    $s.html(html);
    if (cur) $s.val(cur);
}
function timeCell(txt) {
    return txt ? '<span class="time-badge">' + esc(txt) + '</span>' : '<span class="text-muted">-</span>';
}

function fillKeyedSelect(el, map) {
    if (!el) return;
    const cur = el.value;
    el.innerHTML = Object.keys(map || {}).map(k =>
        '<option value="' + esc(k) + '">' + esc(map[k]) + '</option>').join('');
    if (cur != null && [...el.options].some(o => o.value === cur)) {
        el.value = cur;
    }
}

function ensureSelectValue(sel, value, label) {
    const el = typeof sel === 'string' ? document.querySelector(sel) : sel;
    if (!el) return;
    const v = value == null ? '' : String(value);
    const text = (label || '').trim();
    let opt = [...el.options].find(o => o.value === v);
    if (!opt) {
        el.add(new Option(text || v || '—', v, true, true));
        opt = el.options[el.options.length - 1];
    }
    el.value = opt.value;
}

function setChannelField(c) {
    const el = document.getElementById('md_channel');
    if (!el) return;
    [...el.options].filter(o => o.dataset.case === '1').forEach(o => o.remove());
    const reporter = (c.reporter_name || '').trim();
    const ch = String(c.channel || '');
    const label = reporter || c.channel_label || '';
    const same = [...el.options].find(o => o.value === ch && (!label || o.textContent === label));
    if (same) {
        el.value = same.value;
        return;
    }
    if (label) {
        const opt = new Option(label, ch || 'other', true, true);
        opt.dataset.case = '1';
        el.insertBefore(opt, el.firstChild);
        el.selectedIndex = 0;
        return;
    }
    if (ch && [...el.options].some(o => o.value === ch)) {
        el.value = ch;
    }
}

function loadMeta() {
    return fetch('fetch_allergy_followup_api.php?action=meta', { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') return;
            afMeta = data;
            const wdl = document.getElementById('afWardList');
            if (wdl) wdl.innerHTML = (data.wards || []).map(w => '<option value="' + esc(w) + '">').join('');
            fillWardSelect('#dash_ward', data.wards || []);
            fillWardSelect('#flt_ward', data.wards || []);
            fillKeyedSelect(document.getElementById('md_channel'), data.channels || {});
            fillKeyedSelect(document.getElementById('md_summary'), data.summaries || {});
            fillAckUserSelect('#xfer_pick_user', 0, '');
            setUnread(data.unread || 0);
        });
}

function setUnread(n) {
    const el = document.getElementById('afUnreadBadge');
    if (!el) return;
    if (n > 0) {
        el.style.display = '';
        el.textContent = 'รออ่าน ' + n + ' รายการ';
    } else {
        el.style.display = 'none';
    }
}

function loadCases() {
    const qs = new URLSearchParams({
        action: 'list',
        start_date: $('#flt_start').val(),
        end_date: $('#flt_end').val(),
        summary_result: $('#flt_summary').val(),
        q: $('#flt_q').val(),
        ward: $('#flt_ward').val() || ''
    });
    fetch('fetch_allergy_followup_api.php?' + qs.toString(), { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') {
                $('#afTbody').html('<tr><td colspan="14" class="text-center text-danger py-3">โหลดไม่สำเร็จ</td></tr>');
                return;
            }
            setUnread(data.unread || 0);
            let rows = data.cases || [];
            if ($('#flt_no_hosxp').is(':checked')) {
                rows = rows.filter(c => c.hosxp_label === 'ยังไม่พบใน HOSxP');
            }
            if (!rows.length) {
                $('#afTbody').html('<tr><td colspan="14" class="text-center text-muted py-4">ยังไม่มีเคสในช่วงที่เลือก</td></tr>');
                return;
            }
            $('#afTbody').html(rows.map(renderRow).join(''));
        });
}

function loadDashboard() {
    const qs = new URLSearchParams({
        action: 'dashboard',
        start_date: $('#dash_start').val(),
        end_date: $('#dash_end').val(),
        q: $('#dash_q').val(),
        ward: $('#dash_ward').val() || '',
        workflow_stage: dashStage
    });
    fetch('fetch_allergy_followup_api.php?' + qs.toString(), { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') {
                $('#afDashTbody').html('<tr><td colspan="13" class="text-center text-danger py-3">โหลดไม่สำเร็จ</td></tr>');
                return;
            }
            setUnread(data.unread || 0);
            const c = data.counts || {};
            $('#kpi_total').text(c.total || 0);
            $('#kpi_reported').text(c.reported || 0);
            $('#kpi_acknowledged').text(c.acknowledged || 0);
            $('#kpi_following').text(c.following || 0);
            $('#kpi_closed').text(c.closed || 0);
            const shiftN = parseInt(c.shift_handover || 0, 10) || 0;
            $('#kpi_shift_handover').text(shiftN);
            const $shiftCard = $('#kpiCardShift');
            $shiftCard.toggleClass('kpi-blink', shiftN > 0);
            const s = c.closed_summary || {};
            $('#sum_allergy').text(s.allergy || 0);
            $('#sum_not_allergy').text(s.not_allergy || 0);
            $('#sum_monitor').text(s.monitor || 0);
            $('#sum_adr_type_a').text(s.adr_type_a || 0);
            $('#sum_existing_history').text(s.existing_history || 0);
            $('#sum_unclosed').text(s.unclosed || 0);
            document.querySelectorAll('#afKpiRow .kpi-card').forEach(el => {
                el.classList.toggle('active-kpi', el.getAttribute('data-stage') === dashStage);
            });
            const rows = data.cases || [];
            if (!rows.length) {
                $('#afDashTbody').html('<tr><td colspan="13" class="text-center text-muted py-4">ยังไม่มีเคสในช่วงที่เลือก</td></tr>');
                return;
            }
            $('#afDashTbody').html(rows.map(renderDashRow).join(''));
        });
}

function renderRow(c) {
    const photos = (c.nurse_photos || c.photos || []).slice(0, 3).map(p =>
        '<img class="af-thumb me-1" src="' + esc(p.url) + '" onclick="event.stopPropagation(); openLight(\'' + esc(p.url) + '\')">').join('')
        + (c.photo_count > 3 ? '<span class="small text-muted">+' + (c.photo_count - 3) + '</span>' : '');
    return '<tr class="af-row" data-id="' + c.id + '" style="cursor:pointer">'
        + '<td class="text-nowrap">' + esc(fmtDate(c.case_date)) + '</td>'
        + '<td class="text-center">' + esc(c.notify_time || '-') + '</td>'
        + '<td class="af-person">' + esc(c.ptname) + '</td>'
        + '<td class="text-nowrap af-hn">' + esc(c.hn_display) + '</td>'
        + '<td>' + esc(c.ward) + '</td>'
        + '<td class="af-cell-pre">' + esc(c.ward_detail) + '</td>'
        + '<td>' + (photos || '<span class="text-muted">-</span>') + '</td>'
        + '<td>' + esc(c.reporter_name || c.channel_label || '-') + '</td>'
        + '<td class="af-person">' + esc(c.receiver_name || c.ack_by_name || c.owner_name || '-') + '</td>'
        + '<td class="text-center">' + stageBadge(c) + '</td>'
        + '<td class="text-center">' + summaryBadge(c.summary_result, c.summary_label) + '</td>'
        + '<td class="text-center">' + hosxpBadge(c) + '</td>'
        + '<td class="af-cell-pre">' + esc(c.referral_note) + '</td>'
        + '<td class="af-cell-pre">' + esc(c.assessment_detail) + '</td>'
        + '</tr>';
}

function renderDashRow(c) {
    const fu = (c.followup_count || 0) > 0
        ? timeCell(c.last_followup_at_fmt) + '<div class="small text-muted">ครั้งที่ ' + c.followup_count + '</div>'
        : '<span class="text-muted">-</span>';
    const drugs = String(c.assessed_drugs_text || '').trim();
    const assess = (c.assessment_detail || '').trim();
    const drugCell = drugs || assess;
    const recvName = c.receiver_name || c.ack_by_name || c.owner_name || '-';
    const recvExtra = c.is_shift_handover
        ? '<div class="small text-danger fw-bold">ส่งต่อเวร(ไม่ระบุชื่อ)</div>'
        : (c.ack_at_fmt ? '<div class="small fw-normal text-muted">รับเคส ' + esc(c.ack_at_fmt) + '</div>' : '');
    return '<tr class="af-row" data-id="' + c.id + '" style="cursor:pointer">'
        + '<td class="text-nowrap">' + esc(fmtDate(c.case_date)) + '<div class="small text-muted">' + esc(c.notify_time || '') + '</div></td>'
        + '<td class="text-nowrap af-hn">' + esc(c.hn_display) + '</td>'
        + '<td class="af-person">' + esc(c.ptname) + '</td>'
        + '<td>' + esc(c.ward) + '</td>'
        + '<td>' + timeCell(c.reported_at_fmt) + '</td>'
        + '<td>' + esc(c.reporter_name || c.channel_label || '-') + '</td>'
        + '<td class="af-person">' + esc(recvName) + recvExtra + '</td>'
        + '<td>' + fu + '</td>'
        + '<td>' + timeCell(c.closed_at_fmt)
            + (c.closed_by_name ? '<div class="small text-muted">' + esc(c.closed_by_name) + '</div>' : '') + '</td>'
        + '<td>' + (c.summary_result ? summaryBadge(c.summary_result, c.summary_label) : '<span class="text-muted">รอสรุป</span>') + '</td>'
        + '<td>' + hosxpBadge(c) + '</td>'
        + '<td class="af-clip" title="' + esc(drugCell) + '">' + (drugCell ? esc(drugCell) : '<span class="text-muted">-</span>') + '</td>'
        + '<td>' + stageBadge(c) + '</td>'
        + '</tr>';
}

function renderStepper(c) {
    const st = c.workflow_stage || 'reported';
    const order = ['reported', 'acknowledged', 'following', 'closed'];
    const labels = {
        reported: 'แจ้งแพ้ยา',
        acknowledged: 'เภสัชรับเคส',
        following: (c.followup_count > 0 ? 'ติดตามครั้งที่ ' + c.followup_count : 'ติดตาม'),
        closed: 'ปิดเคส'
    };
    const idx = Math.max(0, order.indexOf(st));
    return order.map((k, i) => {
        let cls = 'af-step';
        if (i < idx) cls += ' done';
        else if (i === idx) cls += ' current';
        return '<div class="' + cls + '">' + esc(labels[k]) + '</div>';
    }).join('');
}

function latestReceiver(c) {
    if (!c) return { id: 0, name: '' };
    const id = parseInt(c.receiver_user_id || c.ack_by || c.owner_user_id || 0, 10);
    const name = String(c.receiver_name || c.ack_by_name || c.owner_name || '').trim();
    return { id: id, name: name };
}

function showCaseTab(name) {
    const target = name === 'Transfer' ? '#afTabTransfer' : '#afTabAssess';
    const btn = document.querySelector('#afCaseTabs [data-bs-target="' + target + '"]');
    if (btn && window.bootstrap && bootstrap.Tab) {
        bootstrap.Tab.getOrCreateInstance(btn).show();
    }
}

function renderReceiverHistory(c) {
    const events = (c && c.events) ? c.events : [];
    const rows = events.filter(ev => ev.event_type === 'acknowledged' || ev.event_type === 'transferred');
    if (!rows.length) {
        const cur = latestReceiver(c).name;
        if (!cur) return '<div class="text-muted">ยังไม่มีผู้รับเคส</div>';
        return '<div class="af-recv"><div class="af-recv-item">ผู้รับเคสปัจจุบัน: <b>' + esc(cur) + '</b>'
            + (c.ack_at_fmt ? ' <span class="text-muted">· ' + esc(c.ack_at_fmt) + '</span>' : '') + '</div></div>';
    }
    return '<div class="af-recv">' + rows.map(ev => {
        const note = (ev.note_display || ev.note || '').trim();
        return '<div class="af-recv-item"><b>' + esc(ev.label || '') + '</b>'
            + ' <span class="text-muted">' + esc(ev.created_at_fmt || '') + '</span>'
            + (ev.actor_name ? ' · ' + esc(ev.actor_name) : '')
            + (note ? '<div class="text-muted">' + esc(note).replace(/\n/g, '<br>') + '</div>' : '')
            + '</div>';
    }).join('') + '</div>';
}

function renderTimeline(events) {
    if (!events || !events.length) {
        return '<div class="text-muted">ยังไม่มีบันทึกขั้นตอน</div>';
    }
    afTimelineById = {};
    return events.map(ev => {
        const eid = parseInt(ev.id || 0, 10);
        if (eid > 0) afTimelineById[eid] = ev;
        const showNote = ev.note_display || ev.note || '';
        const noteHtml = showNote ? esc(showNote).replace(/\n/g, '<br>') : '';
        const editBtn = (AF_CAN_ASSESS && eid > 0)
            ? ' <button type="button" class="btn btn-outline-secondary btn-sm py-0 px-1 btn-edit-tl" data-id="' + eid + '" title="แก้ไขข้อความไทม์ไลน์"><i class="fas fa-pen"></i></button>'
            : '';
        return '<div class="af-tl-item" data-event-id="' + eid + '">'
            + '<div class="fw-bold d-flex justify-content-between align-items-start gap-2">'
            + '<span>' + esc(ev.label) + ' <span class="text-muted fw-normal">' + esc(ev.created_at_fmt || ev.created_at || '') + '</span></span>'
            + editBtn
        + '</div>'
            + '<div>' + esc(ev.actor_name || '') + (noteHtml ? ' — <span class="af-tl-note">' + noteHtml + '</span>' : '') + '</div>'
            + '</div>';
    }).join('');
}

function openTimelineEditor(eventId) {
    eventId = parseInt(eventId, 10);
    if (!eventId || !AF_CAN_ASSESS) return;
    const ev = afTimelineById[eventId];
    if (!ev) { alert('ไม่พบรายการไทม์ไลน์'); return; }
    $('#tl_edit_id').val(eventId);
    $('#tl_edit_label').text((ev.label || '') + (ev.created_at_fmt ? ' · ' + ev.created_at_fmt : ''));
    $('#tl_edit_note').val(ev.note || '');
    if (!afTlEditModal && document.getElementById('afTlEditModal')) {
        afTlEditModal = new bootstrap.Modal(document.getElementById('afTlEditModal'));
    }
    if (afTlEditModal) afTlEditModal.show();
}

function saveTimelineEditor() {
    const eventId = parseInt($('#tl_edit_id').val() || 0, 10);
    if (!eventId) return;
    fetch('fetch_allergy_followup_api.php?action=update_event', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event_id: eventId, note: $('#tl_edit_note').val() })
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'success') { alert(data.message || 'บันทึกไทม์ไลน์ไม่สำเร็จ'); return; }
        if (afTlEditModal) afTlEditModal.hide();
        if (data.case) fillModal(data.case, []);
        reloadViews();
    })
    .catch(() => alert('บันทึกไทม์ไลน์ไม่สำเร็จ'));
}

function openLight(url) {
    document.getElementById('afLightboxImg').src = url;
    afLight.show();
}

function photoThumbsHtml(photos) {
    return (photos || []).map(function (p) {
        const who = p.uploaded_by_name
            ? '<div class="small text-muted">' + esc(p.uploaded_by_name) + '</div>'
            : '';
        const del = AF_CAN_ASSESS
            ? ' <button type="button" class="btn btn-outline-danger btn-sm py-0 mb-1" onclick="delPhoto(' + p.id + ')">ลบ</button>'
            : '';
        return '<span class="d-inline-block align-top me-1 mb-1">'
            + '<img class="af-thumb" src="' + esc(p.url) + '" onclick="openLight(\'' + esc(p.url) + '\')" alt="' + esc(p.orig_name || 'photo') + '">'
            + del
            + who
            + '</span>';
    }).join('');
}

function fillModal(c, allergies, dressLabs) {
    const sameCase = parseInt(c.id, 10) === parseInt(afLastFilledId, 10);
    $('#md_id').val(c.id);
    $('#md_date').val(c.case_date);
    $('#md_time').val((c.notify_time || '').slice(0, 5));
    $('#md_hn').val(c.hn_display || c.hn);
    $('#md_ward').val(c.ward);
    $('#md_ptname').val(c.ptname);
    setChannelField(c);
    fillReceiverDisplay(c);
    $('#md_detail').val(c.ward_detail);
    ensureSelectValue('#md_summary', c.summary_result || '', c.summary_label || '');
    $('#md_referral').val(c.referral_note);
    $('#md_assess').val(c.assessment_detail);
    setChronology(c.allergy_chronology || []);
    setAssessedDrugs(c.assessed_drugs || []);
    setNaranjo(c.naranjo_assessment || null);
    setRegiscar(c.regiscar_assessment || null);
    if (typeof dressLabs !== 'undefined') {
        renderDressLabPanels(dressLabs || null);
    } else {
        renderDressLabPanels(afDressLabs);
    }
    resetChronoForm();
    $('#afChronoPanel').hide();
    $('#btnChronoToggle').html('<i class="fas fa-plus me-1"></i>เปิดสร้าง Timeline');
    refreshChronologyUI();
    $('#md_photos').val('');
    $('#md_photos_camera').val('');
    $('#mdStepper').html(renderStepper(c));
    $('#mdTimeline').html(renderTimeline(c.events || []));
    $('#mdReceiverHistory').html(renderReceiverHistory(c));
    const nursePhotos = c.nurse_photos || (c.photos || []).filter(p => (p.kind || 'nurse') !== 'progress');
    const progressPhotos = c.progress_photos || (c.photos || []).filter(p => p.kind === 'progress');
    $('#mdPhotos').html(
        '<div class="af-photo-box">'
        + '<div class="small fw-bold mb-1"><i class="fas fa-camera me-1"></i>รูปจากหอผู้ป่วย'
        + (nursePhotos.length ? ' (' + nursePhotos.length + ')' : '') + '</div>'
        + (nursePhotos.length ? photoThumbsHtml(nursePhotos) : '<div class="small text-muted">ยังไม่มีรูปจากหอผู้ป่วย — พยาบาลแนบจากหน้าแจ้งเคส</div>')
        + '</div>'
    );
    $('#mdProgressCount').text(progressPhotos.length ? ' (' + progressPhotos.length + ')' : '');
    $('#mdProgressThumbs').html(
        progressPhotos.length
            ? photoThumbsHtml(progressPhotos)
            : '<div class="small text-muted">ยังไม่มีรูปติดตาม — เภสัชอัปโหลดในโซนนี้เพื่อดู progress</div>'
    );
    if (allergies && allergies.length) {
        afLastAllergies = allergies;
    } else if (!(c && c.id) || parseInt(c.id, 10) !== afLastFilledId) {
        afLastAllergies = [];
    }
    const allergyList = (allergies && allergies.length) ? allergies : afLastAllergies;
    let hosHtml = '';
    if (c.hosxp_logged) {
        const items = allergyList.length
            ? allergyList.map(formatHosAllergyItem).join(' · ')
            : (c.hosxp_agents || []).map(esc).join(' · ');
        hosHtml = '<div class="alert alert-success py-2 small mb-0"><b>ลงข้อมูลใน HOSxP แล้ว</b>'
            + (items ? ': ' + items : '') + '</div>';
    } else if (allergyList.length) {
        hosHtml = '<div class="alert alert-danger py-2 small mb-0"><b>ประวัติแพ้ HOSxP:</b> '
            + allergyList.map(formatHosAllergyItem).join(' · ') + '</div>';
    } else if (c.hosxp_label === 'ยังไม่พบใน HOSxP') {
        hosHtml = '<div class="alert alert-warning py-2 small mb-0">ยังไม่พบประวัติแพ้ยานี้ใน HOSxP</div>';
    }
    $('#mdHosAllergy').html(hosHtml);
    toggleAssessDrugsPanel();
    const lock = !AF_CAN_ASSESS;
    const closed = (c.workflow_stage || '') === 'closed';
    // เภสัชแก้ข้อมูลประเมิน/ไทม์ไลน์ได้แม้เคสปิดแล้ว
    $('#afCaseModal input, #afCaseModal textarea, #afCaseModal select').not('#xfer_pick_user, #xfer_note, #md_owner_display, #md_owner_id, #md_owner_name, #xfer_case_id').prop('disabled', lock);
    $('#md_photos, #md_photos_camera, #btnMdPickGallery, #btnMdPickCamera').prop('disabled', lock);
    $('#mdProgressUpload').toggle(!lock);
    $('#btnSaveCase').toggle(!lock && closed); // แสดงเฉพาะเคสปิดแล้ว เพื่อแก้สรุปผล/รายละเอียด
    $('#btnAck').toggle(!lock && !closed && (c.workflow_stage === 'reported')).prop('disabled', false);
    $('#md_owner_display').prop('disabled', false);
    $('#xfer_pick_user, #xfer_note, #btnTransferConfirm').prop('disabled', lock || closed);
    afLastFilledId = parseInt(c.id, 10) || 0;
    if (!sameCase) showCaseTab('Assess');
    const nextFu = Math.max(1, (c.followup_count || 0) + 1);
    $('#btnFollow').toggle(!lock && !closed).text('บันทึกติดตามครั้งที่ ' + nextFu);
    $('#btnCloseCase').toggle(!lock && !closed);
    const canDel = AF_CAN_ASSESS || (AF_USER_ID > 0 && AF_USER_ID === parseInt(c.reporter_user_id || 0, 10));
    $('#btnDeleteCase').toggle(canDel);
    $('#btnChronoToggle, #btnChronoAdd, #btnChronoSave, #btnChronoToAssess, #btnChronoClear, #btnNaranjoOpen, #btnRegiscarOpen, #btnChronoGraph, #btnAssessDrugAdd').toggle(!lock);
    $('#mdAssessDrugRows .af-drug-remove').prop('disabled', lock);
    if (lock) {
        $('#afChronoPanel').hide();
        refreshChronologyUI();
    }
}

function deleteCase(id) {
    id = parseInt(id, 10);
    if (!id) return;
    const confirmText = prompt("คำเตือน: คุณกำลังจะลบเคสแพ้ยาออกจากระบบ\n\nพิมพ์คำว่า 'delete' เพื่อยืนยัน:");
    if (confirmText === null) return;
    if (confirmText !== 'delete') {
        if (confirmText !== '') alert("พิมพ์คำว่า 'delete' ไม่ถูกต้อง ข้อมูลจะไม่ถูกลบ");
        return;
    }
    fetch('fetch_allergy_followup_api.php?action=delete_case', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id, confirm: 'delete' })
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'success') { alert(data.message || 'ลบเคสไม่สำเร็จ'); return; }
        afModal.hide();
        reloadViews();
        alert('ลบเคสแล้ว');
    })
    .catch(() => alert('ลบเคสไม่สำเร็จ'));
}

function openCase(id) {
    fetch('fetch_allergy_followup_api.php?action=get&id=' + id, { credentials: 'same-origin' })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') { alert(data.message || 'ไม่พบเคส'); return; }
            fillModal(data.case, data.allergies || [], data.dress_labs || null);
            afModal.show();
            fetch('fetch_allergy_followup_api.php?action=mark_read', {
                method: 'POST', credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ case_id: id })
            }).then(r => r.json()).then(function(d) {
                if (d && d.status === 'success' && d.unread != null) setUnread(d.unread);
            });
        });
}

function delPhoto(id) {
    if (!confirm('ลบรูปนี้?')) return;
    const fd = new FormData();
    fd.append('action', 'delete_photo');
    fd.append('photo_id', id);
    fetch('fetch_allergy_followup_api.php?action=delete_photo', { method: 'POST', credentials: 'same-origin', body: fd })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'success') { alert(data.message || 'ลบไม่สำเร็จ'); return; }
            openCase($('#md_id').val());
            reloadViews();
        });
}

function reloadViews() {
    loadCases();
    loadDashboard();
}

function uploadPendingPhotos(caseId, fromInput) {
    caseId = caseId || $('#md_id').val();
    const input = fromInput || document.getElementById('md_photos');
    const files = input ? input.files : null;
    if (!caseId || !files || !files.length) {
        return Promise.resolve(null);
    }
    const compress = (typeof afCompressFileList === 'function')
        ? afCompressFileList(files, 8)
        : Promise.resolve(Array.from(files));
    return compress.then(function (ready) {
        if (!ready || !ready.length) {
            alert('แปลงรูปไม่สำเร็จ กรุณาใช้ไฟล์ JPG/PNG');
            return null;
        }
        const fd = new FormData();
        fd.append('case_id', caseId);
        fd.append('photo_kind', 'progress');
        ready.forEach(f => fd.append('photos[]', f));
        return fetch('fetch_allergy_followup_api.php?action=upload_photos', {
            method: 'POST', credentials: 'same-origin', body: fd
        });
    })
    .then(function (r) {
        if (!r) return null;
        return r.json();
    })
    .then(data => {
        if (!data) return null;
        if (data.status !== 'success') {
            alert(data.message || 'อัปโหลดรูปไม่สำเร็จ');
            return null;
        }
        if (input) input.value = '';
        return data;
    })
    .catch(() => {
        alert('อัปโหลดรูปไม่สำเร็จ');
        return null;
    });
}

function saveCaseAssessment(opts) {
    opts = opts || {};
    const id = $('#md_id').val();
    if (!id) return Promise.resolve(null);
    syncChronologyIntoAssess();
    const owner = selectedOwnerPayload();
    const payload = {
        id: id,
        case_date: $('#md_date').val(),
        notify_time: $('#md_time').val(),
        hn: $('#md_hn').val(),
        ptname: $('#md_ptname').val(),
        ward: $('#md_ward').val(),
        ward_detail: $('#md_detail').val(),
        channel: $('#md_channel').val(),
        owner_user_id: owner.owner_user_id,
        owner_name: owner.owner_name,
        summary_result: $('#md_summary').val(),
        referral_note: $('#md_referral').val(),
        assessment_detail: $('#md_assess').val(),
        allergy_chronology: afChronology,
        assessed_drugs: collectAssessedDrugs(),
        naranjo_assessment: afNaranjo,
        regiscar_assessment: afRegiscar
    };
    return fetch('fetch_allergy_followup_api.php?action=assess', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'success') {
            if (!opts.silent) alert(data.message || 'บันทึกไม่สำเร็จ');
            return null;
        }
        return uploadPendingPhotos(id).then(photoData => photoData || data);
    })
    .then(data => {
        if (!data || data.status !== 'success') {
            if (!opts.silent && data && data.message) alert(data.message);
            return null;
        }
        if (data.case) fillModal(data.case, []);
        reloadViews();
        if (opts.okMessage && !opts.silent) alert(opts.okMessage);
        return data;
    });
}

function postFlow(action, extra) {
    const id = $('#md_id').val();
    if (!id) return;
    syncChronologyIntoAssess();
    const assess = $('#md_assess').val();
    const owner = selectedOwnerPayload();
    const payload = Object.assign({
        id: id,
        note: assess, // ใช้ช่องผลการประเมินเป็นข้อความไทม์ไลน์
        summary_result: $('#md_summary').val(),
        assessment_detail: assess,
        referral_note: $('#md_referral').val(),
        owner_user_id: owner.owner_user_id,
        owner_name: owner.owner_name,
        allergy_chronology: afChronology,
        assessed_drugs: collectAssessedDrugs(),
        naranjo_assessment: afNaranjo,
        regiscar_assessment: afRegiscar
    }, extra || {});
    return fetch('fetch_allergy_followup_api.php?action=' + action, {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'success') { alert(data.message || 'บันทึกไม่สำเร็จ'); return null; }
        return uploadPendingPhotos(id).then(photoData => {
            const c = (photoData && photoData.case) ? photoData.case : data.case;
            if (c) fillModal(c, []);
        reloadViews();
        return data;
        });
    });
}

function fillReceiverDisplay(c) {
    const recv = latestReceiver(c);
    $('#md_owner_id').val(recv.id || '');
    $('#md_owner_name').val(recv.name || '');
    $('#md_owner_display').val(recv.name || '');
    $('#xfer_from_name').text(recv.name || 'ยังไม่มีผู้รับเคส');
    if (c && c.id) $('#xfer_case_id').val(c.id);
    afOwnerBaseline = ownerSignature();
}

function ownerSignature() {
    const o = selectedOwnerPayload();
    return String(o.owner_user_id || 0) + '|' + String(o.owner_name || '');
}

function selectedOwnerPayload() {
    return {
        owner_user_id: parseInt($('#md_owner_id').val() || 0, 10),
        owner_name: String($('#md_owner_name').val() || '').trim()
    };
}

function pharmacistOptionValue(p) {
    const pid = parseInt(p && p.id, 10) || 0;
    const pname = String((p && p.name) || '').trim();
    return pid > 0 ? ('u:' + pid) : ('n:' + pname);
}

function isAckPlaceholderName(name) {
    const n = String(name || '').trim();
    return n === '' || n.indexOf('เลือกผู้รับเคส') >= 0;
}

function appendAckOption(sel, p) {
    const pid = parseInt(p && p.id, 10) || 0;
    const pname = String((p && p.name) || '').trim();
    if (!pname && pid <= 0) return null;
    const opt = document.createElement('option');
    opt.value = pharmacistOptionValue({ id: pid, name: pname });
    opt.text = pname;
    opt.setAttribute('data-id', String(pid));
    opt.setAttribute('data-name', pname);
    sel.appendChild(opt);
    return opt;
}

function fillAckUserSelect(sel, selectedId, selectedName) {
    const $s = $(sel);
    const el = $s.get(0);
    if (!el) return;
    const list = ((afMeta && afMeta.pharmacists) || []).slice();
    const sid = parseInt(selectedId || 0, 10);
    const sname = String(selectedName || '').trim();
    const isXfer = el.id === 'xfer_pick_user';
    $s.data('filling', true);
    if (AF_USER_ID > 0 && !list.some(p => parseInt(p.id, 10) === AF_USER_ID)) {
        list.unshift({ id: AF_USER_ID, name: AF_USER_NAME || ('User #' + AF_USER_ID) });
    }
    if (sid > 0 && !list.some(p => parseInt(p.id, 10) === sid)) {
        list.unshift({ id: sid, name: sname || ('User #' + sid) });
    }
    if (sname && !list.some(p => String(p.name).trim() === sname)) {
        list.unshift({ id: sid || 0, name: sname });
    }
    el.innerHTML = '';
    if (isXfer) {
        const ph = document.createElement('option');
        ph.value = '__none__';
        ph.text = '— เลือกผู้รับเคส —';
        el.appendChild(ph);
        const shift = document.createElement('option');
        shift.value = '__shift__';
        shift.setAttribute('data-id', '0');
        shift.setAttribute('data-name', 'ส่งต่อเวร (ไม่ระบุชื่อ)');
        shift.text = 'ส่งต่อให้เวรถัดไป (ไม่ระบุชื่อ)';
        el.appendChild(shift);
    }
    list.forEach(p => appendAckOption(el, p));
    if (!isXfer && !el.options.length) {
        appendAckOption(el, { id: AF_USER_ID, name: AF_USER_NAME || 'ผู้ใช้ปัจจุบัน' });
    }
    let picked = -1;
    if (sid > 0) {
        for (let i = 0; i < el.options.length; i++) {
            if (parseInt(el.options[i].getAttribute('data-id') || '0', 10) === sid) { picked = i; break; }
        }
    }
    if (picked < 0 && sname && !isXfer) {
        for (let i = 0; i < el.options.length; i++) {
            if (String(el.options[i].getAttribute('data-name') || el.options[i].text || '').trim() === sname) {
                picked = i; break;
            }
        }
    }
    if (picked < 0 && !isXfer && AF_USER_ID > 0) {
        for (let i = 0; i < el.options.length; i++) {
            if (parseInt(el.options[i].getAttribute('data-id') || '0', 10) === AF_USER_ID) { picked = i; break; }
        }
    }
    el.selectedIndex = picked >= 0 ? picked : 0;
    $s.data('filling', false);
    if (isXfer && picked < 0) $s.removeData('last-pick');
}

function optionAckPayload(opt) {
    if (!opt) return { ack_user_id: 0, ack_by_name: '' };
    const raw = String(opt.value || '').trim();
    let name = String(opt.getAttribute('data-name') || opt.text || '').replace(/\s+/g, ' ').trim();
    if (raw.indexOf('n:') === 0 && !name) name = raw.slice(2).trim();
    if (raw === '__none__' || isAckPlaceholderName(name)) {
        return { ack_user_id: 0, ack_by_name: '' };
    }
    if (raw === '__shift__') {
        return { ack_user_id: 0, ack_by_name: 'ส่งต่อเวร (ไม่ระบุชื่อ)', to_shift: true };
    }
    let id = parseInt(opt.getAttribute('data-id') || '0', 10) || 0;
    if (raw.indexOf('u:') === 0) {
        id = parseInt(raw.slice(2), 10) || id;
    } else if (raw.indexOf('n:') === 0) {
        id = 0;
    } else if (raw !== '') {
        id = parseInt(raw, 10) || id;
    }
    return { ack_user_id: id, ack_by_name: name };
}

function selectedAckPayload(sel) {
    const $s = (sel && sel.jquery) ? sel : $(sel);
    const el = $s.get(0) || (typeof sel === 'string' ? document.querySelector(sel) : sel);
    if (!el || !el.options) return { ack_user_id: 0, ack_by_name: '' };
    const wasDisabled = !!el.disabled;
    if (wasDisabled) el.disabled = false;
    const opt = (el.selectedOptions && el.selectedOptions[0])
        || (el.selectedIndex >= 0 ? el.options[el.selectedIndex] : null)
        || $s.find('option:selected').get(0);
    let payload = optionAckPayload(opt);
    if (!payload.ack_by_name) {
        const cached = $s.data('last-pick');
        if (cached && cached.ack_by_name) payload = cached;
    }
    if (wasDisabled) el.disabled = true;
    return payload;
}

function openAckPicker(id) {
    id = parseInt(id, 10);
    if (!id || !AF_CAN_ASSESS) return;
    $('#ack_case_id').val(id);
    fillAckUserSelect('#ack_pick_user', AF_USER_ID, AF_USER_NAME);
    if (!afAckModal && document.getElementById('afAckModal')) {
        afAckModal = new bootstrap.Modal(document.getElementById('afAckModal'));
    }
    if (afAckModal) afAckModal.show();
}

function confirmAckCase() {
    const id = parseInt($('#ack_case_id').val() || 0, 10);
    if (!id) return;
    const ack = selectedAckPayload('#ack_pick_user');
    const ackUserId = ack.ack_user_id || AF_USER_ID;
    const who = ack.ack_by_name || AF_USER_NAME || 'ผู้ใช้ปัจจุบัน';
    postFlow('ack', { ack_user_id: ackUserId, ack_by_name: who }).then(data => {
        if (data && data.status === 'success' && afAckModal) afAckModal.hide();
    });
}

function currentCaseReceiverName() {
    const o = selectedOwnerPayload();
    return o.owner_name || 'ยังไม่มีผู้รับเคส';
}

function openTransferPicker(preselectId, preselectName) {
    const id = parseInt($('#md_id').val() || 0, 10);
    if (!id) return;
    $('#xfer_case_id').val(id);
    $('#xfer_from_name').text(currentCaseReceiverName());
    $('#xfer_note').val('');
    fillAckUserSelect('#xfer_pick_user', preselectId || 0, preselectName || '');
    showCaseTab('Transfer');
}

function confirmTransferCase() {
    const id = parseInt($('#xfer_case_id').val() || $('#md_id').val() || 0, 10);
    if (!id) return;
    const $pick = $('#xfer_pick_user');
    $pick.prop('disabled', false);
    let ack = selectedAckPayload($pick);
    if (!ack.ack_by_name && $pick.data('last-pick') && $pick.data('last-pick').ack_by_name) {
        ack = $pick.data('last-pick');
    }
    if (!ack.ack_by_name) { alert('กรุณาเลือกผู้รับเคส'); return; }
    const toShift = !!ack.to_shift || ack.ack_by_name === 'ส่งต่อเวร (ไม่ระบุชื่อ)';
    fetch('fetch_allergy_followup_api.php?action=transfer', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            id: id,
            ack_user_id: toShift ? '__shift__' : (ack.ack_user_id || 0),
            ack_by_name: ack.ack_by_name,
            to_user_id: toShift ? '__shift__' : (ack.ack_user_id || 0),
            to_name: ack.ack_by_name,
            note: $('#xfer_note').val()
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'success') { alert(data.message || 'ส่งต่อเคสไม่สำเร็จ'); return; }
        if (data.case) fillModal(data.case, []);
        showCaseTab('Transfer');
        fillAckUserSelect('#xfer_pick_user', 0, '');
        $('#xfer_note').val('');
        reloadViews();
    })
    .catch(() => alert('ส่งต่อเคสไม่สำเร็จ'));
}

$(function() {
    afModal = new bootstrap.Modal(document.getElementById('afCaseModal'));
    afLight = new bootstrap.Modal(document.getElementById('afLightbox'));
    loadMeta().then(function() {
        loadCases();
        loadDashboard();
        if (AF_OPEN > 0) openCase(AF_OPEN);
    });

    $('#md_summary').on('change', function () {
        toggleAssessDrugsPanel();
    });
    $('#btnAssessDrugAdd').on('click', function () {
        collectAssessedDrugs();
        afAssessDrugs.push({ name: '', icode: '', tmt_name: '', source: 'free' });
        renderAssessDrugRows();
        $('#mdAssessDrugRows .af-drug-row:last .af-drug-name').focus();
    });
    $(document).on('click', '.af-drug-remove', function () {
        const $row = $(this).closest('.af-drug-row');
        $row.remove();
        if (!$('#mdAssessDrugRows .af-drug-row').length) {
            afAssessDrugs = [{ name: '', icode: '', tmt_name: '', source: 'free' }];
            renderAssessDrugRows();
        } else {
            collectAssessedDrugs();
        }
    });
    $(document).on('input', '.af-drug-name', function () {
        const $row = $(this).closest('.af-drug-row');
        $row.find('.af-drug-icode, .af-drug-tmt').val('');
        $row.find('.af-drug-source').val('free');
        $row.find('.af-drug-meta').text('พิมพ์ชื่อเองได้ · หรือเลือกจากรายการ TMT');
        const term = $(this).val();
        clearTimeout(afDrugSuggestTimer);
        afDrugSuggestTimer = setTimeout(function () {
            searchAssessDrugTmt($row, term);
        }, 280);
    });
    $(document).on('focus', '.af-drug-name', function () {
        const $row = $(this).closest('.af-drug-row');
        const term = $(this).val();
        if (String(term || '').trim().length >= 1) searchAssessDrugTmt($row, term);
    });
    $(document).on('click', '.af-drug-pick', function () {
        const $row = $(this).closest('.af-drug-row');
        const text = String($(this).data('text') || '');
        const parsed = parseDrugSelectId($(this).data('id'));
        let name = text;
        // ตัดส่วน (icode: ...) / [TMT ...] ออกจากชื่อแสดงถ้ามี — เก็บชื่ออ่านง่าย
        name = name.replace(/\s*\(icode:[^)]+\)\s*$/i, '').trim();
        $row.find('.af-drug-name').val(name);
        $row.find('.af-drug-icode').val(parsed.icode || '');
        $row.find('.af-drug-tmt').val(parsed.tmt_name || '');
        $row.find('.af-drug-source').val('tmt');
        $row.find('.af-drug-meta').text(
            (parsed.icode ? ('icode ' + parsed.icode) : 'TMT')
            + (parsed.tmt_name ? (' · ' + parsed.tmt_name) : '')
        );
        $row.find('.af-drug-suggest').hide().empty();
    });
    $(document).on('click', function (e) {
        if (!$(e.target).closest('.af-drug-row').length) {
            $('.af-drug-suggest').hide();
        }
    });

    $('#btnReload').on('click', loadCases);
    $('#btnDashReload').on('click', loadDashboard);
    $('#dash_ward').on('change', loadDashboard);
    $('#flt_ward').on('change', loadCases);
    $('#flt_no_hosxp').on('change', loadCases);
    $('#btnImportSheet').on('click', function() {
        if (!confirm('นำเข้าสมุดจาก Google Sheet ปีงบ 2569?\nเคสที่มีอยู่แล้วจะถูกอัปเดต ไม่สร้างแถวซ้ำ')) return;
        const btn = $(this).prop('disabled', true);
        fetch('fetch_allergy_followup_api.php?action=import_gsheet', { method: 'POST', credentials: 'same-origin' })
            .then(r => r.json())
            .then(data => {
                btn.prop('disabled', false);
                if (data.status !== 'success') { alert(data.message || 'นำเข้าไม่สำเร็จ'); return; }
                alert(data.message);
                reloadViews();
            })
            .catch(() => { btn.prop('disabled', false); alert('นำเข้าไม่สำเร็จ'); });
    });
    $('#flt_q').on('keydown', function(e) { if (e.key === 'Enter') loadCases(); });
    $('#dash_q').on('keydown', function(e) { if (e.key === 'Enter') loadDashboard(); });
    $('#afTbody, #afDashTbody').on('click', 'tr.af-row', function() { openCase(this.getAttribute('data-id')); });
    $('#afKpiRow').on('click', '.kpi-card', function() {
        dashStage = this.getAttribute('data-stage') || 'all';
        loadDashboard();
    });

    $('#md_photos, #md_photos_camera').on('change', function() {
        const id = $('#md_id').val();
        if (!id) { alert('ไม่พบเคส'); this.value = ''; return; }
        if (!this.files || !this.files.length) return;
        uploadPendingPhotos(id, this).then(data => {
            if (!data) return;
            if (data.case) fillModal(data.case, []);
            reloadViews();
        });
    });
    $('#btnMdPickGallery').on('click', function(e) {
        e.preventDefault();
        document.getElementById('md_photos').click();
    });
    $('#btnMdPickCamera').on('click', function(e) {
        e.preventDefault();
        document.getElementById('md_photos_camera').click();
    });

    $('#btnAck').on('click', function() { openAckPicker($('#md_id').val()); });
    $('#btnAckConfirm').on('click', confirmAckCase);
    $('#btnTransferConfirm').on('click', confirmTransferCase);
    $(document).on('change', '#xfer_pick_user, #ack_pick_user', function() {
        const $el = $(this);
        if ($el.data('filling')) return;
        const p = selectedAckPayload($el);
        if (p.ack_by_name) $el.data('last-pick', p);
    });
    $('#tabBtnTransfer').on('shown.bs.tab', function() {
        const id = $('#md_id').val();
        if (id) {
            $('#xfer_case_id').val(id);
            $('#xfer_from_name').text(currentCaseReceiverName());
        }
    });
    $('#afAckModal').on('hidden.bs.modal', function() {
        if ($('#afCaseModal').hasClass('show')) {
            document.body.classList.add('modal-open');
        }
    });
    $('#btnDeleteCase').on('click', function() { deleteCase($('#md_id').val()); });
    $('#mdTimeline').on('click', '.btn-edit-tl', function(e) {
        e.preventDefault();
        e.stopPropagation();
        openTimelineEditor(this.getAttribute('data-id'));
    });
    $('#btnTlEditSave').on('click', saveTimelineEditor);
    $('#btnFollow').on('click', function() {
        const note = $('#md_assess').val().trim();
        if (!note && !afChronology.length) {
            alert('กรุณากรอกข้อมูลรายละเอียดและผลการประเมิน หรือสร้าง Timeline บันทึกการแพ้ยาก่อนติดตาม');
            return;
        }
        postFlow('followup');
    });
    $('#btnCloseCase').on('click', function() {
        const sum = $('#md_summary').val();
        if (!sum) { alert('กรุณาเลือกสรุปผลก่อนปิดเคส (แพ้ยา / ไม่แพ้ยา / อื่นๆ)'); return; }
        if (summaryNeedsDrugs(sum) && !collectAssessedDrugs().length) {
            if (!confirm('ยังไม่ได้ระบุรายการยาที่แพ้หรือเกิด ADR — ปิดเคสต่อเลยหรือไม่?')) return;
        } else if (!confirm('ปิดเคสนี้และสรุปผลตามที่เลือก?')) {
            return;
        }
        postFlow('close');
    });

    $('#btnChronoToggle').on('click', function() {
        const $p = $('#afChronoPanel');
        if ($p.is(':visible')) {
            $p.hide();
            $(this).html('<i class="fas fa-plus me-1"></i>เปิดสร้าง Timeline');
            refreshChronologyUI();
        } else {
            $p.show();
            $('#afChronoPreviewOnly').hide();
            $(this).html('<i class="fas fa-chevron-up me-1"></i>ย่อ Timeline');
        }
    });
    $('#btnChronoGraph').on('click', openChronoGraphModal);
    $('#btnChronoGraphPrint').on('click', function() { window.print(); });
    $('#btnChronoAdd').on('click', addOrUpdateChronologyRow);
    $('#btnOpenSmartDrug').on('click', function() {
        const hn = ($('#md_hn').val() || '').trim();
        if (!hn) { alert('ไม่พบ HN ของเคสนี้'); return; }
        window.open('smart_drug.php?hn=' + encodeURIComponent(hn), '_blank');
    });
    $('#btnOpenSmartLab').on('click', function() {
        const hn = ($('#md_hn').val() || '').trim();
        if (!hn) { alert('ไม่พบ HN ของเคสนี้'); return; }
        window.open('smart_lab.php?hn=' + encodeURIComponent(hn), '_blank');
    });
    $('#btnChronoSave').on('click', function() {
        saveCaseAssessment({ okMessage: 'บันทึก Timeline แล้ว' });
    });
    $('#btnChronoClear').on('click', function() {
        if (!afChronology.length) return;
        if (!confirm('ล้าง Timeline บันทึกการแพ้ยาทั้งหมด?')) return;
        setChronology([]);
        resetChronoForm();
    });
    $('#btnChronoToAssess').on('click', function() {
        const txt = chronologyText(afChronology);
        if (!txt) { alert('ยังไม่มีรายการใน Timeline'); return; }
        syncChronologyIntoAssess();
    });
    $('#afChronoTbody').on('click', '.btn-chrono-edit', function() {
        loadChronologyRowToForm(parseInt(this.getAttribute('data-idx'), 10));
    });
    $('#afChronoTbody').on('click', '.btn-chrono-del', function() {
        const idx = parseInt(this.getAttribute('data-idx'), 10);
        if (idx < 0 || idx >= afChronology.length) return;
        afChronology.splice(idx, 1);
        setChronology(afChronology);
        resetChronoForm();
        syncChronologyIntoAssess();
    });

    $('#btnNaranjoOpen').on('click', openNaranjoModal);
    $('#afNaranjoTbody').on('change', '.naranjo-ans', refreshNaranjoLiveScore);
    $('#btnNaranjoClear').on('click', function() {
        Object.keys(NARANJO_QUESTIONS).forEach(k => {
            $('input[name="naranjo_q_' + k + '"]').prop('checked', false);
        });
        refreshNaranjoLiveScore();
    });
    $('#btnNaranjoSave').on('click', function() {
        const cur = readNaranjoAnswersFromForm();
        if (!cur) {
            if (!confirm('ยังไม่ได้เลือกคำตอบ — ต้องการล้างผล Naranjo ที่บันทึกไว้หรือไม่?')) return;
            afNaranjo = null;
        } else {
            afNaranjo = cur;
        }
        refreshNaranjoSummary();
        // แปะสรุปลงผลการประเมินถ้ายังไม่มี
        const txt = naranjoText(afNaranjo);
        if (txt) {
            const assess = ($('#md_assess').val() || '').trim();
            if (assess.indexOf('Naranjo:') < 0) {
                $('#md_assess').val(assess ? (assess + '\n' + txt) : txt);
            } else {
                $('#md_assess').val(assess.replace(/Naranjo:[^\n]*/, txt));
            }
        }
        saveCaseAssessment({ okMessage: 'บันทึก Naranjo แล้ว' }).then(data => {
            if (data && afNaranjoModal) afNaranjoModal.hide();
        });
    });

    $('#btnRegiscarOpen').on('click', openRegiscarModal);
    $('#afRegiscarBody').on('change', '.regiscar-ans', refreshRegiscarLiveScore);
    $('#btnRegiscarClear').on('click', function() {
        Object.keys(REGISCAR_QUESTIONS).forEach(key => {
            $('input[name="regiscar_' + key + '"]').prop('checked', false);
        });
        refreshRegiscarLiveScore();
    });
    $('#btnRegiscarSave').on('click', function() {
        const cur = readRegiscarAnswersFromForm();
        if (!cur) {
            if (!confirm('ยังไม่ได้เลือกคำตอบ — ต้องการล้างผล RegiSCAR ที่บันทึกไว้หรือไม่?')) return;
            afRegiscar = null;
        } else {
            afRegiscar = cur;
        }
        refreshRegiscarSummary();
        const txt = regiscarText(afRegiscar);
        if (txt) {
            const assess = ($('#md_assess').val() || '').trim();
            if (assess.indexOf('RegiSCAR') < 0) {
                $('#md_assess').val(assess ? (assess + '\n' + txt) : txt);
            } else {
                $('#md_assess').val(assess.replace(/RegiSCAR[^\n]*/, txt));
            }
        }
        saveCaseAssessment({ okMessage: 'บันทึก RegiSCAR แล้ว' }).then(data => {
            if (data && afRegiscarModal) afRegiscarModal.hide();
        });
    });

    $('#btnSaveCase').on('click', function() {
        saveCaseAssessment();
    });
});
</script>
</body>
</html>
