<?php
/**
 * การตั้งค่า Health ID / Provider ID / Drugs Center
 * ไฟล์นี้ห้ามอัปขึ้น GitHub / ห้ามใส่ใน zip อัปเดต
 *
 * แก้เฉพาะข้อความในเครื่องหมายคำพูด '...' ให้เป็นค่าจริงที่ได้มา
 */

/** uat = ทดสอบ | prd = ใช้งานจริง */
define('PROVIDER_OAUTH_ENV', 'prd');

/** 1) Health ID (หน้า Login OAuth) */
define('HEALTH_ID_CLIENT_ID', '01946455-cdb7-746e-925a-17ba3f0ba14d');
define('HEALTH_ID_CLIENT_SECRET', 'b65c18d0acda91ace4b691b241a9d110765dd8c3');

/** 2) Provider ID (แลก moph token) */
define('PROVIDER_ID_CLIENT_ID', 'cd61bd83-894a-48f8-b7bf-5f20d5fb91af');
define('PROVIDER_ID_SECRET_KEY', 'NT4h52Bgxw8V4fSvHqkEAM8rgeOt6NIU');

/**
 * 3) Redirect URI — ต้องลงทะเบียนกับ Health ID ให้ตรงทุกตัวอักษร
 * URL ของเซิร์ฟเวอร์นี้:
 */
define('PROVIDER_OAUTH_REDIRECT_URI', 'http://61.7.167.197/thamhossafe/oauth_callback.php');

/** 4) Drugs Center API Key */
define('DRUG_CENTER_API_KEY', '94e36bebf57325c1a4a2c3221038529be81f67ca');
