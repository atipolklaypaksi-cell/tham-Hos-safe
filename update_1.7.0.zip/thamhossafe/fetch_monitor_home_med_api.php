<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_home_med_helper.php');
mysqli_set_charset($con, 'utf8');
set_time_limit(90);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

$start_date = isset($_GET['start_date']) ? trim($_GET['start_date']) : date('Y-m-d', strtotime('-3 days'));
$end_date = isset($_GET['end_date']) ? trim($_GET['end_date']) : date('Y-m-d');
$hn_raw = function_exists('monitor_req_hn') ? monitor_req_hn() : trim((string)($_GET['hn'] ?? $_POST['hn'] ?? ''));

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-3 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if (strtotime($start_date) > strtotime($end_date)) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}
mysqli_set_charset($hos, 'utf8');

$result = mhm_scan($con, $hos, $start_date, $end_date, [], $hn_raw !== '' ? [$hn_raw] : []);
mysqli_close($hos);

if (!empty($result['meta']['error']) && empty($result['hard_alerts']) && empty($result['soft_alerts'])
    && empty($result['patients'])
    && strpos((string)$result['meta']['error'], 'SQL') !== false) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'error',
        'message' => $result['meta']['error'],
        'meta' => $result['meta'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'status' => 'success',
    'patients' => sp_alert_mute_filter_rows($con, $result['patients'] ?? []),
    'hard_alerts' => sp_alert_mute_filter_rows($con, $result['hard_alerts'] ?? []),
    'soft_alerts' => sp_alert_mute_filter_rows($con, $result['soft_alerts'] ?? []),
    'meta' => $result['meta'],
], JSON_UNESCAPED_UNICODE);
exit;
