<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/med_error_helper.php';
mysqli_set_charset($con, 'utf8');
med_error_ensure_tables($con);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: med_error.php');
    exit;
}

$record_id = isset($_POST['record_id']) ? (int)$_POST['record_id'] : 0;
$record_kind = med_error_sanitize_record_kind($_POST['record_kind'] ?? 'error');
$is_consult = ($record_kind === 'consult');
$hn = mysqli_real_escape_string($con, trim((string)($_POST['hn'] ?? '')));
$incident_day = trim((string)($_POST['incident_date'] ?? ''));
$incident_time = trim((string)($_POST['incident_time'] ?? ''));
$error_type_id = $is_consult ? 0 : (int)($_POST['error_type_id'] ?? 0);
$error_level = $is_consult ? '' : mysqli_real_escape_string($con, trim((string)($_POST['error_level'] ?? '')));
$description = mysqli_real_escape_string($con, trim((string)($_POST['description'] ?? '')));
$solution = mysqli_real_escape_string($con, trim((string)($_POST['solution'] ?? '')));
$patient_name = trim((string)($_POST['patient_name'] ?? ''));
$patient_type = med_error_sanitize_patient_type($_POST['patient_type'] ?? '');
$an = mysqli_real_escape_string($con, trim((string)($_POST['an'] ?? '')));
$vn = mysqli_real_escape_string($con, trim((string)($_POST['vn'] ?? '')));
$reporting_dept = med_error_post_dept('reporting_dept');
$error_dept = $is_consult ? '' : med_error_post_dept('error_dept');
$error_drugs = $is_consult ? [] : med_error_parse_drugs($_POST['error_drugs'] ?? '[]');
$correct_drugs = $is_consult ? [] : med_error_parse_drugs($_POST['correct_drugs'] ?? '[]');
$is_had = $is_consult ? 'NO' : med_error_sanitize_yes_no($_POST['is_had'] ?? 'NO', 'NO');
$is_robot = $is_consult ? 'NO' : med_error_sanitize_yes_no($_POST['is_robot'] ?? 'NO', 'NO');
$rx_type = $is_consult ? '' : med_error_sanitize_rx_type($_POST['rx_type'] ?? '', $patient_type);
$order_doctor_code = trim((string)($_POST['order_doctor_code'] ?? ''));
$order_doctor_name = trim((string)($_POST['order_doctor_name'] ?? ''));
$order_doctor_group = med_error_sanitize_doctor_group($_POST['order_doctor_group'] ?? '');
if ($order_doctor_group === '' && ($order_doctor_code !== '' || $order_doctor_name !== '')) {
    $order_doctor_group = med_error_lookup_doctor_group($con, $order_doctor_code, $order_doctor_name);
}
$reporter_id = isset($_POST['reporter_id']) ? (int)$_POST['reporter_id'] : (int)$_SESSION['user_id'];
$type_info = $is_consult ? ['category' => '', 'name' => ''] : med_error_lookup_error_type($con, $error_type_id);
$intervention_module = $is_consult ? '' : med_error_auto_map_intervention_module([
    'category' => $type_info['category'],
    'type_name' => $type_info['name'],
    'description' => (string)($_POST['description'] ?? ''),
    'solution' => (string)($_POST['solution'] ?? ''),
    'drugs' => array_merge($error_drugs, $correct_drugs),
    'is_had' => $is_had,
    'patient_type' => $patient_type,
    'rx_type' => $rx_type,
]);
$intervention_sql = $intervention_module !== ''
    ? ("'" . mysqli_real_escape_string($con, $intervention_module) . "'")
    : 'NULL';

if (strpos($incident_day, 'T') !== false) {
    $incident_date = str_replace('T', ' ', $incident_day);
    if (strlen($incident_date) === 16) {
        $incident_date .= ':00';
    }
} else {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $incident_day)) {
        $incident_day = '';
    }
    if ($incident_time === '') {
        $incident_time = '00:00';
    }
    if (preg_match('/^\d{2}:\d{2}$/', $incident_time)) {
        $incident_time .= ':00';
    } elseif (!preg_match('/^\d{2}:\d{2}:\d{2}$/', $incident_time)) {
        $incident_time = '';
    }
    $incident_date = ($incident_day !== '' && $incident_time !== '')
        ? ($incident_day . ' ' . $incident_time)
        : '';
}

if ($is_consult) {
    if ($hn === '' || $incident_date === '' || $description === '' || $reporter_id <= 0 || $patient_type === '') {
        echo "<script>alert('กรุณากรอก HN ประเภทผู้ป่วย วันเวลา ผู้บันทึก และบรรยายเหตุการณ์'); history.back();</script>";
        exit;
    }
} else {
    if ($hn === '' || $incident_date === '' || $error_type_id <= 0 || $error_level === '' || $patient_type === '' || $reporting_dept === '' || $error_dept === '') {
        echo "<script>alert('กรุณากรอกข้อมูลให้ครบถ้วน'); history.back();</script>";
        exit;
    }
    if ($patient_type === 'IPD' && $rx_type === '') {
        echo "<script>alert('กรุณาเลือกประเภทใบสั่งยา'); history.back();</script>";
        exit;
    }
}

$incident_date = mysqli_real_escape_string($con, $incident_date);

if ($patient_name === '' && $hn !== '') {
    $patient_name = med_error_lookup_patient_name($con, $hn);
}
$patient_sql = $patient_name !== ''
    ? ("'" . mysqli_real_escape_string($con, $patient_name) . "'")
    : 'NULL';
$hn_sql = $hn !== '' ? "'$hn'" : 'NULL';
$patient_type_sql = $patient_type !== '' ? "'$patient_type'" : 'NULL';
$error_type_sql = $error_type_id > 0 ? (string)$error_type_id : 'NULL';
$error_level_sql = $error_level !== '' ? "'$error_level'" : 'NULL';
$record_kind_sql = "'" . mysqli_real_escape_string($con, $record_kind) . "'";
$an_sql = $an !== '' ? "'$an'" : 'NULL';
$vn_sql = $vn !== '' ? "'$vn'" : 'NULL';
$reporting_sql = $reporting_dept !== ''
    ? ("'" . mysqli_real_escape_string($con, $reporting_dept) . "'")
    : 'NULL';
$error_dept_sql = $error_dept !== ''
    ? ("'" . mysqli_real_escape_string($con, $error_dept) . "'")
    : 'NULL';
$error_drugs_sql = "'" . mysqli_real_escape_string($con, med_error_drugs_json($error_drugs)) . "'";
$correct_drugs_sql = "'" . mysqli_real_escape_string($con, med_error_drugs_json($correct_drugs)) . "'";
$is_had_sql = "'" . mysqli_real_escape_string($con, $is_had) . "'";
$is_robot_sql = "'" . mysqli_real_escape_string($con, $is_robot) . "'";
$rx_type_sql = $rx_type !== ''
    ? ("'" . mysqli_real_escape_string($con, $rx_type) . "'")
    : 'NULL';
$order_doctor_code_sql = $order_doctor_code !== ''
    ? ("'" . mysqli_real_escape_string($con, $order_doctor_code) . "'")
    : 'NULL';
$order_doctor_name_sql = $order_doctor_name !== ''
    ? ("'" . mysqli_real_escape_string($con, $order_doctor_name) . "'")
    : 'NULL';
$order_doctor_group_sql = $order_doctor_group !== ''
    ? ("'" . mysqli_real_escape_string($con, $order_doctor_group) . "'")
    : 'NULL';

if ($record_id > 0) {
    $sql = "UPDATE med_error_records SET
                hn = $hn_sql,
                patient_name = $patient_sql,
                patient_type = $patient_type_sql,
                an = $an_sql,
                vn = $vn_sql,
                order_doctor_code = $order_doctor_code_sql,
                order_doctor_name = $order_doctor_name_sql,
                order_doctor_group = $order_doctor_group_sql,
                reporting_dept = $reporting_sql,
                error_dept = $error_dept_sql,
                error_drugs = $error_drugs_sql,
                correct_drugs = $correct_drugs_sql,
                is_had = $is_had_sql,
                is_robot = $is_robot_sql,
                rx_type = $rx_type_sql,
                record_kind = $record_kind_sql,
                incident_date = '$incident_date',
                error_type_id = $error_type_sql,
                error_level = $error_level_sql,
                description = '$description',
                solution = '$solution',
                reporter_id = $reporter_id,
                intervention_module = $intervention_sql
            WHERE id = $record_id";
    $ok_msg = 'อัปเดตข้อมูลสำเร็จ';
} else {
    $sql = "INSERT INTO med_error_records
            (hn, patient_name, patient_type, an, vn, order_doctor_code, order_doctor_name, order_doctor_group, reporting_dept, error_dept, error_drugs, correct_drugs, is_had, is_robot, rx_type, record_kind, incident_date, error_type_id, error_level, description, solution, reporter_id, intervention_module)
            VALUES
            ($hn_sql, $patient_sql, $patient_type_sql, $an_sql, $vn_sql, $order_doctor_code_sql, $order_doctor_name_sql, $order_doctor_group_sql, $reporting_sql, $error_dept_sql, $error_drugs_sql, $correct_drugs_sql, $is_had_sql, $is_robot_sql, $rx_type_sql, $record_kind_sql, '$incident_date', $error_type_sql, $error_level_sql, '$description', '$solution', $reporter_id, $intervention_sql)";
    $ok_msg = $is_consult ? 'บันทึกการ Consult สำเร็จ' : 'บันทึกความคลาดเคลื่อนทางยาสำเร็จ';
}

if (mysqli_query($con, $sql)) {
    if (!$is_consult) {
        med_error_memory_learn(
            $con,
            trim((string)($_POST['description'] ?? '')),
            trim((string)($_POST['solution'] ?? '')),
            $error_drugs,
            $correct_drugs
        );
    }
    echo "<script>alert(" . json_encode($ok_msg, JSON_UNESCAPED_UNICODE) . "); window.location.href='med_error.php';</script>";
} else {
    echo "<script>alert(" . json_encode('เกิดข้อผิดพลาด: ' . mysqli_error($con), JSON_UNESCAPED_UNICODE) . "); history.back();</script>";
}
mysqli_close($con);
