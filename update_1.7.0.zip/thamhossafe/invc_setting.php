<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/invc_helper.php';
require_once __DIR__ . '/invc_gsheet_helper.php';
mysqli_set_charset($con, 'utf8');
invc_ensure_config($con);
$cfg = invc_load_config($con);
$drv = invc_driver_status();
$gsheet_on = (($cfg['invc_gsheet_enabled'] ?? '1') === '1');
$sa_status = invc_gsheet_sa_status();
$sa_email = (string)($sa_status['email'] ?? '');
$auth_mode = (string)($cfg['invc_gsheet_auth'] ?? 'auto');
$cache_ttl = (string)($cfg['invc_gsheet_cache_ttl'] ?? '60');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เชื่อมต่อ INVC - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .invc-hero {
            background: linear-gradient(135deg, #1e1b4b 0%, #3730a3 55%, #4f46e5 100%);
            color: #fff; border-radius: 16px; padding: 1.2rem 1.4rem; margin-bottom: 1.1rem;
        }
        .invc-badge { background: rgba(255,255,255,.18); border: 1px solid rgba(255,255,255,.28); }
        .invc-stat { border: 0; border-radius: 12px; }
        .invc-stat .n { font-size: 1.45rem; font-weight: 800; }
        .invc-table-list { max-height: 280px; overflow: auto; }
        .invc-table-list button { text-align: left; }
        .invc-preview { font-size: .8rem; }
        .invc-preview th { white-space: nowrap; }
        code.cmd { font-size: .8rem; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="invc-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="small text-uppercase" style="letter-spacing:.08em;opacity:.75;">ตั้งค่าระบบ · INVC</div>
                    <h4 class="fw-bold mb-1">เชื่อมต่อ INVC (คลังยา)</h4>
                    <p class="mb-0 small" style="opacity:.92;">อ่านฐาน <code>INV_STOCK</code> บน SQL Server เท่านั้น ไม่มีการเขียนหรือแก้ข้อมูลต้นทาง</p>
                </div>
                <div class="d-flex flex-column align-items-end gap-2">
                    <a href="invc_stock.php" class="btn btn-light btn-sm fw-bold">
                        <i class="fas fa-boxes me-1"></i> เปิดระบบ INVC
                    </a>
                    <span class="badge invc-badge px-3 py-2 fs-6"><i class="fas fa-lock me-1"></i> Read Only</span>
                    <span class="badge invc-badge">SQL Server · พอร์ต 1433</span>
                </div>
            </div>

            <?php if (empty($drv['ok'])): ?>
            <div class="alert alert-warning">
                <div class="fw-bold mb-1"><i class="fas fa-exclamation-triangle me-1"></i>PHP ใน Docker ยังไม่มี driver สำหรับ SQL Server</div>
                <div class="small mb-2">พอร์ต INVC เปิดอยู่แล้ว แต่คอนเทนเนอร์ <code>employee-php</code> ติดตั้งแค่ MySQL ต้องใส่ FreeTDS ใน image แล้ว rebuild จึงจะเชื่อมต่อได้</div>
                <code class="cmd"><?php echo htmlspecialchars($drv['install_hint']); ?></code>
            </div>
            <?php endif; ?>

            <div class="row g-3 mb-3">
                <div class="col-6 col-lg-3">
                    <div class="card invc-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">สถานะ</div>
                        <div class="n" id="statStatus">กำลังตรวจ…</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card invc-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">ตาราง</div>
                        <div class="n" id="statTables">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card invc-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">Driver</div>
                        <div class="n" id="statDriver"><?php echo htmlspecialchars($drv['driver'] ?: 'ไม่มี'); ?></div>
                    </div></div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card invc-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">เวลาตอบ</div>
                        <div class="n" id="statMs">—</div>
                    </div></div>
                </div>
            </div>

            <div class="card shadow-sm border-0 mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
                        <div>
                            <h6 class="fw-bold mb-1"><i class="fab fa-google-drive me-2 text-success"></i>Google Sheet จัดซื้อ (รอตรวจรับ)</h6>
                            <div class="small text-muted">เมื่อคลัง = 0 จะเทียบรหัสยา (คอลัมน์ E) กับวันที่รับ (N) หลังวันที่จ่ายล่าสุด แล้วแสดงจำนวนสั่งจาก Pack (H) และ ORDER (I)</div>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="invc_gsheet_enabled" <?php echo $gsheet_on ? 'checked' : ''; ?>>
                            <label class="form-check-label small fw-bold" for="invc_gsheet_enabled">เปิดใช้</label>
                        </div>
                    </div>
                    <form id="gsheetForm">
                        <div class="alert alert-light border small mb-3">
                            <div class="fw-bold mb-1"><i class="fas fa-key me-1 text-warning"></i>Service Account (แนะนำเมื่อ Sheet เปิดเฉพาะ Gmail)</div>
                            <ol class="mb-2 ps-3">
                                <li>สร้างโปรเจกต์ใน <a href="https://console.cloud.google.com/" target="_blank" rel="noopener">Google Cloud Console</a></li>
                                <li>เปิด API → <b>Google Sheets API</b> → Enable</li>
                                <li>IAM &amp; Admin → Service Accounts → Create → สร้าง JSON key</li>
                                <li>วาง JSON ด้านล่าง แล้วบันทึก จะได้ อีเมล SA</li>
                                <li>เปิด Sheet → แชร์อีเมล SA เป็น <b>Viewer</b> (ไม่ต้องเปิด Anyone with the link)</li>
                            </ol>
                            <div class="mb-1">อีเมล Service Account ปัจจุบัน:
                                <?php if ($sa_email !== ''): ?>
                                    <code id="saEmailShow" class="user-select-all"><?php echo htmlspecialchars($sa_email); ?></code>
                                    <button type="button" class="btn btn-link btn-sm p-0 ms-1" id="btnCopySa" title="คัดลอก">คัดลอก</button>
                                <?php else: ?>
                                    <span class="text-danger" id="saEmailShow">ยังไม่มี — อัปโหลด JSON ก่อน</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label small fw-bold">Service Account JSON key</label>
                                <textarea class="form-control font-monospace" id="invc_gsheet_sa_json" rows="4" placeholder='{"type":"service_account","project_id":"...","private_key":"-----BEGIN PRIVATE KEY-----\n...","client_email":"...@....iam.gserviceaccount.com",...}'><?php echo $sa_email !== '' ? '********' : ''; ?></textarea>
                                <div class="form-text">เว้น <code>********</code> ไว้ถ้าไม่เปลี่ยน · พิมพ์ <code>CLEAR</code> เพื่อลบ key</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">โหมดดึงข้อมูล</label>
                                <select class="form-select" id="invc_gsheet_auth">
                                    <option value="auto" <?php echo $auth_mode === 'auto' ? 'selected' : ''; ?>>auto (มี SA ใช้ API, ไม่มีใช้ CSV)</option>
                                    <option value="service_account" <?php echo $auth_mode === 'service_account' ? 'selected' : ''; ?>>Service Account เท่านั้น</option>
                                    <option value="csv" <?php echo $auth_mode === 'csv' ? 'selected' : ''; ?>>CSV สาธารณะเท่านั้น</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Cache (วินาที)</label>
                                <input type="number" class="form-control" id="invc_gsheet_cache_ttl" min="30" max="3600" value="<?php echo htmlspecialchars($cache_ttl); ?>">
                                <div class="form-text">ยิ่งน้อยยิ่งใกล้ realtime (แนะนำ 30–60)</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">GID ชีต</label>
                                <input type="text" class="form-control" id="invc_gsheet_gid" value="<?php echo htmlspecialchars($cfg['invc_gsheet_gid'] ?? '0'); ?>">
                                <div class="form-text">0 = ชีตแรก · หรืออ่านจากลิงก์</div>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">ลิงก์ Google Sheet</label>
                                <input type="text" class="form-control" id="invc_gsheet_url" value="<?php echo htmlspecialchars($cfg['invc_gsheet_url'] ?? ''); ?>" placeholder="https://docs.google.com/spreadsheets/d/...">
                                <div class="form-text">ใช้ SA: แชร์ให้ SA เป็น Viewer พอ · โหมด CSV: ต้อง Anyone with the link</div>
                            </div>
                            <div class="col-6 col-md-3">
                                <label class="form-label small fw-bold">คอลัมน์รหัสยา</label>
                                <input type="text" class="form-control text-uppercase" id="invc_gsheet_col_code" maxlength="2" value="<?php echo htmlspecialchars($cfg['invc_gsheet_col_code'] ?? 'E'); ?>">
                            </div>
                            <div class="col-6 col-md-3">
                                <label class="form-label small fw-bold">คอลัมน์ Pack</label>
                                <input type="text" class="form-control text-uppercase" id="invc_gsheet_col_pack" maxlength="2" value="<?php echo htmlspecialchars($cfg['invc_gsheet_col_pack'] ?? 'H'); ?>">
                            </div>
                            <div class="col-6 col-md-3">
                                <label class="form-label small fw-bold">คอลัมน์ ORDER</label>
                                <input type="text" class="form-control text-uppercase" id="invc_gsheet_col_order" maxlength="2" value="<?php echo htmlspecialchars($cfg['invc_gsheet_col_order'] ?? 'I'); ?>">
                            </div>
                            <div class="col-6 col-md-3">
                                <label class="form-label small fw-bold">คอลัมน์วันที่รับ</label>
                                <input type="text" class="form-control text-uppercase" id="invc_gsheet_col_recv" maxlength="2" value="<?php echo htmlspecialchars($cfg['invc_gsheet_col_recv'] ?? 'N'); ?>">
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mt-3">
                            <div class="small text-muted" id="gsheetStatus"><?php echo $sa_email !== '' ? ('พร้อม SA · ' . htmlspecialchars($sa_email)) : 'ยังไม่ได้ตั้ง Service Account'; ?></div>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-outline-success fw-bold" id="btnTestGsheet">
                                    <i class="fas fa-cloud-download-alt me-1"></i> ทดสอบดึง Sheet
                                </button>
                                <button type="submit" class="btn btn-success fw-bold">
                                    <i class="fas fa-save me-1"></i> บันทึก Sheet
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-lg-5">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3"><i class="fas fa-server me-2 text-primary"></i>ข้อมูลการเชื่อมต่อ SQL Server</h6>
                            <form id="invcForm">
                                <div class="row g-3">
                                    <div class="col-8">
                                        <label class="form-label small fw-bold">Host / IP</label>
                                        <input type="text" class="form-control" id="invc_host" value="<?php echo htmlspecialchars($cfg['invc_host']); ?>">
                                    </div>
                                    <div class="col-4">
                                        <label class="form-label small fw-bold">Port</label>
                                        <input type="number" class="form-control" id="invc_port" value="<?php echo htmlspecialchars($cfg['invc_port']); ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label small fw-bold">Database Name</label>
                                        <input type="text" class="form-control" id="invc_db" value="<?php echo htmlspecialchars($cfg['invc_db']); ?>">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Username</label>
                                        <input type="text" class="form-control" id="invc_user" value="<?php echo htmlspecialchars($cfg['invc_user']); ?>">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Password</label>
                                        <input type="password" class="form-control" id="invc_pass" value="<?php echo ($cfg['invc_pass'] ?? '') !== '' ? '********' : ''; ?>" autocomplete="new-password">
                                        <div class="form-text">เว้น ******** ไว้ถ้าไม่ต้องการเปลี่ยนรหัส</div>
                                    </div>
                                </div>
                                <div class="alert alert-info small mt-3 mb-0">
                                    <i class="fas fa-shield-alt me-1"></i>
                                    บังคับ Read Only: อนุญาตเฉพาะ SELECT และตั้ง <code>READ UNCOMMITTED</code> หลังเชื่อมต่อ
                                </div>
                                <div class="d-flex justify-content-end gap-2 mt-3">
                                    <button type="button" class="btn btn-outline-primary fw-bold" id="btnTest">
                                        <i class="fas fa-plug me-1"></i> ทดสอบการเชื่อมต่อ
                                    </button>
                                    <button type="submit" class="btn btn-primary fw-bold">
                                        <i class="fas fa-save me-1"></i> บันทึก
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body">
                            <h6 class="fw-bold mb-2"><i class="fas fa-boxes me-2 text-success"></i>ดูตาราง (อ่านอย่างเดียว)</h6>
                            <div class="input-group input-group-sm mb-2">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" class="form-control" id="tableQ" placeholder="ค้นหาชื่อตาราง เช่น stock, drug">
                            </div>
                            <div class="invc-table-list list-group mb-3" id="tableList">
                                <div class="text-muted small p-2">กำลังโหลดรายการตาราง…</div>
                            </div>
                            <div id="previewBox" class="d-none">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div class="fw-bold" id="previewTitle"></div>
                                    <span class="badge bg-secondary">ซ่อนคอลัมน์อ่อนไหว</span>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered bg-white invc-preview mb-0">
                                        <thead class="table-light" id="previewHead"></thead>
                                        <tbody id="previewBody"></tbody>
                                    </table>
                                </div>
                            </div>
                            <div id="previewEmpty" class="small text-muted">เลือกตารางด้านบนเพื่อดูตัวอย่าง 20 แถวแรก</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
function formBody(extra) {
    return Object.assign({
        invc_host: document.getElementById('invc_host').value.trim(),
        invc_port: document.getElementById('invc_port').value.trim(),
        invc_db: document.getElementById('invc_db').value.trim(),
        invc_user: document.getElementById('invc_user').value.trim(),
        invc_pass: document.getElementById('invc_pass').value
    }, extra || {});
}
function gsheetBody(extra) {
    return Object.assign({
        invc_gsheet_enabled: document.getElementById('invc_gsheet_enabled').checked ? '1' : '0',
        invc_gsheet_url: document.getElementById('invc_gsheet_url').value.trim(),
        invc_gsheet_gid: document.getElementById('invc_gsheet_gid').value.trim(),
        invc_gsheet_auth: document.getElementById('invc_gsheet_auth').value,
        invc_gsheet_cache_ttl: document.getElementById('invc_gsheet_cache_ttl').value.trim(),
        invc_gsheet_sa_json: document.getElementById('invc_gsheet_sa_json').value,
        invc_gsheet_col_code: document.getElementById('invc_gsheet_col_code').value.trim(),
        invc_gsheet_col_pack: document.getElementById('invc_gsheet_col_pack').value.trim(),
        invc_gsheet_col_order: document.getElementById('invc_gsheet_col_order').value.trim(),
        invc_gsheet_col_recv: document.getElementById('invc_gsheet_col_recv').value.trim()
    }, extra || {});
}
function applySaInfo(sa, ping) {
    const el = document.getElementById('saEmailShow');
    const email = (sa && sa.email) || (ping && ping.sa_email) || '';
    if (el) {
        if (email) {
            el.textContent = email;
            el.className = 'user-select-all';
            if (el.tagName === 'SPAN') {
                const code = document.createElement('code');
                code.id = 'saEmailShow';
                code.className = 'user-select-all';
                code.textContent = email;
                el.replaceWith(code);
            }
        }
    }
    if (document.getElementById('invc_gsheet_sa_json').value.trim() !== '' &&
        document.getElementById('invc_gsheet_sa_json').value.trim() !== '********' &&
        document.getElementById('invc_gsheet_sa_json').value.trim().toUpperCase() !== 'CLEAR' &&
        email) {
        document.getElementById('invc_gsheet_sa_json').value = '********';
    }
}
function api(action, extra) {
    return fetch('fetch_invc_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign(formBody({ action: action }), extra || {}))
    }).then(async function (res) {
        const text = await res.text();
        try { return JSON.parse(text); }
        catch (e) { throw new Error('ไฟล์ API ตอบกลับไม่ใช่ JSON'); }
    });
}
function applyPing(ping) {
    const ok = ping && ping.ok;
    document.getElementById('statStatus').textContent = ok ? 'เชื่อมต่อได้' : 'เชื่อมต่อไม่ได้';
    document.getElementById('statStatus').className = 'n ' + (ok ? 'text-success' : 'text-danger');
    document.getElementById('statTables').textContent = ok ? (ping.table_count || 0).toLocaleString() : '—';
    document.getElementById('statMs').textContent = ping && ping.ms != null ? (ping.ms + ' ms') : '—';
    if (ping && ping.driver) document.getElementById('statDriver').textContent = ping.driver;
}
function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function loadTables(q) {
    const box = document.getElementById('tableList');
    box.innerHTML = '<div class="text-muted small p-2">กำลังค้นหา…</div>';
    api('tables', { q: q || '' }).then(function (data) {
        const tables = data.tables || [];
        if (!tables.length) {
            box.innerHTML = '<div class="text-muted small p-2">ไม่พบตาราง</div>';
            return;
        }
        box.innerHTML = tables.map(function (t) {
            return '<button type="button" class="list-group-item list-group-item-action py-1 px-2 font-monospace" data-table="' + esc(t) + '">' + esc(t) + '</button>';
        }).join('');
    }).catch(function () {
        box.innerHTML = '<div class="text-danger small p-2">โหลดรายการตารางไม่สำเร็จ</div>';
    });
}
function previewTable(table) {
    document.getElementById('previewEmpty').classList.add('d-none');
    document.getElementById('previewBox').classList.remove('d-none');
    document.getElementById('previewTitle').textContent = table;
    document.getElementById('previewHead').innerHTML = '';
    document.getElementById('previewBody').innerHTML = '<tr><td class="text-muted">กำลังอ่าน…</td></tr>';
    api('preview', { table: table }).then(function (data) {
        const preview = data.preview || {};
        const cols = preview.columns || [];
        const rows = preview.rows || [];
        if (preview.error) {
            document.getElementById('previewBody').innerHTML = '<tr><td class="text-danger">' + esc(preview.error) + '</td></tr>';
            return;
        }
        document.getElementById('previewHead').innerHTML = '<tr>' + cols.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') + '</tr>';
        if (!rows.length) {
            document.getElementById('previewBody').innerHTML = '<tr><td colspan="' + cols.length + '" class="text-muted">ไม่มีข้อมูล</td></tr>';
            return;
        }
        document.getElementById('previewBody').innerHTML = rows.map(function (r) {
            return '<tr>' + cols.map(function (c) { return '<td>' + esc(r[c]) + '</td>'; }).join('') + '</tr>';
        }).join('');
    }).catch(function () {
        document.getElementById('previewBody').innerHTML = '<tr><td class="text-danger">อ่านตัวอย่างไม่สำเร็จ</td></tr>';
    });
}

document.getElementById('btnTest').addEventListener('click', function () {
    const btn = this;
    const html = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังทดสอบ...';
    api('test').then(function (data) {
        applyPing(data.ping || {});
        alert((data.status === 'success' ? '✅ ' : '❌ ') + data.message);
        if (data.status === 'success') loadTables(document.getElementById('tableQ').value.trim());
    }).catch(function (err) {
        alert('❌ ' + (err.message || 'ทดสอบไม่สำเร็จ'));
    }).finally(function () {
        btn.innerHTML = html;
        btn.disabled = false;
    });
});
document.getElementById('invcForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    const html = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังบันทึก...';
    api('save').then(function (data) {
        alert((data.status === 'success' ? '✅ ' : '❌ ') + (data.message || ''));
        if (data.status === 'success') api('test').then(function (t) { applyPing(t.ping || {}); });
    }).catch(function () {
        alert('❌ บันทึกไม่สำเร็จ');
    }).finally(function () {
        btn.innerHTML = html;
        btn.disabled = false;
    });
});
let tmr = null;
document.getElementById('tableQ').addEventListener('input', function () {
    clearTimeout(tmr);
    const q = this.value.trim();
    tmr = setTimeout(function () { loadTables(q); }, 250);
});
document.getElementById('tableList').addEventListener('click', function (e) {
    const btn = e.target.closest('[data-table]');
    if (!btn) return;
    previewTable(btn.getAttribute('data-table'));
});
const btnCopySa = document.getElementById('btnCopySa');
if (btnCopySa) {
    btnCopySa.addEventListener('click', function () {
        const t = (document.getElementById('saEmailShow') || {}).textContent || '';
        if (!t) return;
        navigator.clipboard.writeText(t).then(function () {
            btnCopySa.textContent = 'คัดลอกแล้ว';
            setTimeout(function () { btnCopySa.textContent = 'คัดลอก'; }, 1200);
        });
    });
}
document.getElementById('btnTestGsheet').addEventListener('click', function () {
    const btn = this;
    const html = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังดึง...';
    api('test_gsheet', gsheetBody()).then(function (data) {
        const ping = data.ping || {};
        const mode = ping.mode === 'service_account' ? 'SA' : 'CSV';
        document.getElementById('gsheetStatus').textContent = data.status === 'success'
            ? ('OK (' + mode + ') · ' + (ping.row_count || 0) + ' แถว · ' + (ping.ms || 0) + ' ms')
            : (data.message || 'ทดสอบไม่สำเร็จ');
        document.getElementById('gsheetStatus').className = 'small ' + (data.status === 'success' ? 'text-success' : 'text-danger');
        applySaInfo(data.sa, ping);
        alert((data.status === 'success' ? '✅ ' : '❌ ') + data.message);
    }).catch(function (err) {
        alert('❌ ' + (err.message || 'ทดสอบไม่สำเร็จ'));
    }).finally(function () {
        btn.innerHTML = html;
        btn.disabled = false;
    });
});
document.getElementById('gsheetForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    const html = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังบันทึก...';
    api('save_gsheet', gsheetBody()).then(function (data) {
        applySaInfo(data.sa || (data.config ? {
            email: data.config.invc_gsheet_sa_email,
            configured: !!data.config.invc_gsheet_sa_configured
        } : null));
        alert((data.status === 'success' ? '✅ ' : '❌ ') + (data.message || ''));
    }).catch(function () {
        alert('❌ บันทึกไม่สำเร็จ');
    }).finally(function () {
        btn.innerHTML = html;
        btn.disabled = false;
    });
});
api('test').then(function (data) {
    applyPing(data.ping || {});
    if (data.status === 'success') loadTables('');
    else document.getElementById('tableList').innerHTML = '<div class="text-danger small p-2">' + esc(data.message || 'เชื่อมต่อไม่ได้') + '</div>';
}).catch(function () {
    document.getElementById('statStatus').textContent = 'ตรวจไม่ได้';
});
</script>
</body>
</html>
