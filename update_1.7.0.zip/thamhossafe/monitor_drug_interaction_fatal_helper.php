<?php
/**
 * คู่ยา Fatal DI 23 คู่ ตามเอกสารจังหวัดสระแก้ว (SP-DSC-67-002)
 * นำเข้าเป็นกฎ Monitor Interaction โดยจับคู่ icode จาก HOSxP ตามชื่อสามัญ
 */

function di_fatal_reference() {
    return "Micromedex drug interactions\n"
        . "รายการยาที่ห้ามใช้ร่วมกัน โรงพยาบาลหัวหิน\n"
        . "http://pharmacy.huahinhospital.go.th/UserFiles/File/Drug%20interaction-HH.pdf\n"
        . "https://songpeenong.moph.go.th/file/รายการยาที่ห้ามใช้ร่วมกัน.pdf";
}

function di_fatal_di_pairs() {
    $ref = di_fatal_reference();
    return [
        [
            'n' => 1, 'a' => 'Amiodarone', 'b' => 'Ritonavir',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Good',
            'effect' => 'increased risk of amiodarone toxicity (hypotension, bradycardia, sinus arrest).',
            'reference' => $ref,
            'a_keys' => ['amiodarone', 'อะมิโอดาโรน', 'อะมิโอดารอน', 'cordarone', 'คอร์ดาโรน'],
            'b_keys' => ['ritonavir', 'ริโทนาเวียร์', 'ริโทนาเวีย', 'norvir', 'นอร์เวียร์', 'kaletra', 'คาเลตรา'],
        ],
        [
            'n' => 2, 'a' => 'Amiodarone', 'b' => 'Lopinavir',
            'onset' => 'Delayed', 'severity' => 'Major', 'documentation' => 'Good',
            'effect' => 'increased risk of amiodarone toxicity (hypotension, bradycardia, sinus arrest).',
            'reference' => $ref,
            'a_keys' => ['amiodarone', 'อะมิโอดาโรน', 'อะมิโอดารอน', 'cordarone', 'คอร์ดาโรน'],
            'b_keys' => ['lopinavir', 'โลพินาเวียร์', 'โลพินาเวีย', 'kaletra', 'คาเลตรา'],
        ],
        [
            'n' => 3, 'a' => 'Carbamazepine', 'b' => 'Efavirenz',
            'onset' => 'Not specified', 'severity' => 'Contraindicated', 'documentation' => 'Excellent',
            'effect' => 'decreased carbamazepine and/or efavirenz exposure and loss of efficacy.',
            'reference' => $ref,
            'a_keys' => ['carbamazepine', 'คาร์บามาเซพีน', 'คาร์บามาเซปิน', 'tegretol', 'เทเกรทอล'],
            'b_keys' => ['efavirenz', 'อีฟาไวเรนซ์', 'อีฟาวิเรนซ์', 'efaviren', 'stocrin', 'สโตคริน'],
        ],
        [
            'n' => 4, 'a' => 'Carbamazepine', 'b' => 'Ritonavir',
            'onset' => 'Not specified', 'severity' => 'Contraindicated', 'documentation' => 'Excellent',
            'effect' => 'increased carbamazepine exposure and decreased ritonavir exposure.',
            'reference' => $ref,
            'a_keys' => ['carbamazepine', 'คาร์บามาเซพีน', 'คาร์บามาเซปิน', 'tegretol', 'เทเกรทอล'],
            'b_keys' => ['ritonavir', 'ริโทนาเวียร์', 'ริโทนาเวีย', 'norvir', 'นอร์เวียร์', 'kaletra', 'คาเลตรา'],
        ],
        [
            'n' => 5, 'a' => 'Clozapine', 'b' => 'Ritonavir',
            'onset' => 'Delayed', 'severity' => 'Major', 'documentation' => 'Fair',
            'effect' => 'increased clozapine exposure and risk of QT prolongation.',
            'reference' => $ref,
            'a_keys' => ['clozapine', 'โคลซาพีน', 'โคลซาปิน', 'clozaril', 'leponex'],
            'b_keys' => ['ritonavir', 'ริโทนาเวียร์', 'ริโทนาเวีย', 'norvir', 'นอร์เวียร์', 'kaletra', 'คาเลตรา'],
        ],
        [
            'n' => 6, 'a' => 'Dopamine', 'b' => 'Phenytoin',
            'onset' => 'Rapid', 'severity' => 'Major', 'documentation' => 'Fair',
            'effect' => 'May result in hypotension and/or cardiac arrest.',
            'reference' => $ref,
            'a_keys' => ['dopamine', 'โดพามีน', 'โดปามีน'],
            'b_keys' => ['phenytoin', 'ฟีนิโทอิน', 'ฟีนิโตอิน'],
            'a_exclude' => ['levodopa', 'carbidopa', 'methyldopa', 'โดปามีน อะโกนิสต์'],
        ],
        [
            'n' => 7, 'a' => 'Ergotamine', 'b' => 'Clarithromycin',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Good',
            'effect' => 'increased risk of acute ergotism (nausea, vomiting, vasospastic ischemia).',
            'reference' => $ref,
            'a_keys' => ['ergotamine', 'cafergot', 'เออร์โกทามีน', 'เออร์โกตามีน', 'คาเฟอร์กอต'],
            'b_keys' => ['clarithromycin', 'คลาลิโทรมัยซิน', 'คลาริโทรมัยซิน', 'คลาริโธรมัยซิน', 'คลาริโทรมัยซิน', 'klacid', 'klaricid'],
        ],
        [
            'n' => 8, 'a' => 'Ergotamine', 'b' => 'Lopinavir',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Fair',
            'effect' => 'increased risk of acute ergotism (nausea, vomiting, vasospastic ischemia).',
            'reference' => $ref,
            'a_keys' => ['ergotamine', 'cafergot', 'เออร์โกทามีน', 'เออร์โกตามีน', 'คาเฟอร์กอต'],
            'b_keys' => ['lopinavir', 'โลพินาเวียร์', 'โลพินาเวีย', 'kaletra', 'คาเลตรา'],
        ],
        [
            'n' => 9, 'a' => 'Ergotamine', 'b' => 'Ritonavir',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Fair',
            'effect' => 'increased risk of acute ergotism (nausea, vomiting, vasospastic ischemia).',
            'reference' => $ref,
            'a_keys' => ['ergotamine', 'cafergot', 'เออร์โกทามีน', 'เออร์โกตามีน', 'คาเฟอร์กอต'],
            'b_keys' => ['ritonavir', 'ริโทนาเวียร์', 'ริโทนาเวีย', 'norvir', 'นอร์เวียร์', 'kaletra', 'คาเลตรา'],
        ],
        [
            'n' => 10, 'a' => 'Ergotamine', 'b' => 'Lopinavir+Ritonavir',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Fair',
            'effect' => 'increased risk of acute ergotism (nausea, vomiting, vasospastic ischemia).',
            'reference' => $ref,
            'a_keys' => ['ergotamine', 'cafergot', 'เออร์โกทามีน', 'เออร์โกตามีน', 'คาเฟอร์กอต'],
            'b_keys' => ['kaletra', 'คาเลตรา'],
            'b_require_all' => [['lopinavir', 'โลพินาเวียร์'], ['ritonavir', 'ริโทนาเวียร์']],
        ],
        [
            'n' => 11, 'a' => 'Ergotamine', 'b' => 'Saquinavir',
            'onset' => 'Rapid', 'severity' => 'Contraindicated', 'documentation' => 'Good',
            'effect' => 'increased risk of acute ergotism (nausea, vomiting, vasospastic ischemia).',
            'reference' => $ref,
            'a_keys' => ['ergotamine', 'cafergot', 'เออร์โกทามีน', 'เออร์โกตามีน', 'คาเฟอร์กอต'],
            'b_keys' => ['saquinavir', 'ซาควินาเวียร์', 'ซาควินาเวีย'],
        ],
        [
            'n' => 12, 'a' => 'Ergotamine', 'b' => 'Indinavir',
            'onset' => 'Rapid', 'severity' => 'Contraindicated', 'documentation' => 'Good',
            'effect' => 'increased risk of acute ergotism (nausea, vomiting, vasospastic ischemia).',
            'reference' => $ref,
            'a_keys' => ['ergotamine', 'cafergot', 'เออร์โกทามีน', 'เออร์โกตามีน', 'คาเฟอร์กอต'],
            'b_keys' => ['indinavir', 'อินดินาเวียร์', 'อินดินาเวีย'],
        ],
        [
            'n' => 13, 'a' => 'Ergotamine', 'b' => 'Itraconazole',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Good',
            'effect' => 'increased risk of acute ergotism (nausea, vomiting, vasospastic ischemia).',
            'reference' => $ref,
            'a_keys' => ['ergotamine', 'cafergot', 'เออร์โกทามีน', 'เออร์โกตามีน', 'คาเฟอร์กอต'],
            'b_keys' => ['itraconazole', 'อิทราโคนาโซล', 'ไอทราโคนาโซล', 'sporanox'],
        ],
        [
            'n' => 14, 'a' => 'Ketoconazole', 'b' => 'Ritonavir',
            'onset' => 'Delayed', 'severity' => 'Major', 'documentation' => 'Excellent',
            'effect' => 'increased ketoconazole and/or ritonavir serum concentrations and increased risk for QT-interval prolongation.',
            'reference' => $ref,
            'a_keys' => ['ketoconazole', 'คีโตโคนาโซล', 'คีโตโคนาซอล', 'nizoral'],
            'a_exclude' => ['itraconazole', 'อิทราโคนาโซล'],
            'b_keys' => ['ritonavir', 'ริโทนาเวียร์', 'ริโทนาเวีย', 'norvir', 'นอร์เวียร์', 'kaletra', 'คาเลตรา'],
        ],
        [
            'n' => 15, 'a' => 'Sildenafil', 'b' => 'Isosorbide Mononitrate',
            'onset' => 'Rapid', 'severity' => 'Contraindicated', 'documentation' => 'Excellent',
            'effect' => 'Increase hypotensive effects.',
            'reference' => $ref,
            'a_keys' => ['sildenafil', 'ซิลเดนาฟิล', 'viagra', 'ไวอากร้า'],
            'b_keys' => ['imdur', 'ismo', 'elantan'],
            'b_require_all' => [['isosorbide', 'ไอโซซอร์ไบด์', 'ไอโซซอร์บाइड'], ['mononitrate', 'ismn', 'โมโนไนเตรต']],
        ],
        [
            'n' => 16, 'a' => 'Sildenafil', 'b' => 'Isosorbide Sublingual',
            'onset' => 'Rapid', 'severity' => 'Contraindicated', 'documentation' => 'Excellent',
            'effect' => 'Increase hypotensive effects.',
            'reference' => $ref,
            'a_keys' => ['sildenafil', 'ซิลเดนาฟิล', 'viagra', 'ไวอากร้า'],
            'b_keys' => ['isdn', 'isordil'],
            'b_require_all' => [['isosorbide', 'ไอโซซอร์ไบด์', 'ไอโซซอร์บाइड'], ['dinitrate', 'ไดไนเตรท', 'ใต้ลิ้น', 'sublingual']],
            'b_exclude' => ['mononitrate', 'ismn', 'โมโนไนเตรต', 'imdur'],
        ],
        [
            'n' => 17, 'a' => 'Simvastatin', 'b' => 'Clarithromycin',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Good',
            'effect' => 'increased risk of myopathy or rhabdomyolysis.',
            'reference' => $ref,
            'a_keys' => ['simvastatin', 'ซิมวาสแตติน', 'ซิมวาสตาติน', 'zocor', 'โซคอร์'],
            'b_keys' => ['clarithromycin', 'คลาลิโทรมัยซิน', 'คลาริโทรมัยซิน', 'คลาริโธรมัยซิน', 'klacid', 'klaricid'],
        ],
        [
            'n' => 18, 'a' => 'Simvastatin', 'b' => 'Lopinavir+Ritonavir',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Fair',
            'effect' => 'increased risk of myopathy or rhabdomyolysis.',
            'reference' => $ref,
            'a_keys' => ['simvastatin', 'ซิมวาสแตติน', 'ซิมวาสตาติน', 'zocor', 'โซคอร์'],
            'b_keys' => ['kaletra', 'คาเลตรา'],
            'b_require_all' => [['lopinavir', 'โลพินาเวียร์'], ['ritonavir', 'ริโทนาเวียร์']],
        ],
        [
            'n' => 19, 'a' => 'Simvastatin', 'b' => 'Ritonavir',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Good',
            'effect' => 'increased risk of myopathy or rhabdomyolysis.',
            'reference' => $ref,
            'a_keys' => ['simvastatin', 'ซิมวาสแตติน', 'ซิมวาสตาติน', 'zocor', 'โซคอร์'],
            'b_keys' => ['ritonavir', 'ริโทนาเวียร์', 'ริโทนาเวีย', 'norvir', 'นอร์เวียร์', 'kaletra', 'คาเลตรา'],
        ],
        [
            'n' => 20, 'a' => 'Simvastatin', 'b' => 'Indinavir',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Fair',
            'effect' => 'increased risk of myopathy or rhabdomyolysis.',
            'reference' => $ref,
            'a_keys' => ['simvastatin', 'ซิมวาสแตติน', 'ซิมวาสตาติน', 'zocor', 'โซคอร์'],
            'b_keys' => ['indinavir', 'อินดินาเวียร์', 'อินดินาเวีย'],
        ],
        [
            'n' => 21, 'a' => 'Simvastatin', 'b' => 'Nelfinavir',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Excellent',
            'effect' => 'increased risk of myopathy or rhabdomyolysis.',
            'reference' => $ref,
            'a_keys' => ['simvastatin', 'ซิมวาสแตติน', 'ซิมวาสตาติน', 'zocor', 'โซคอร์'],
            'b_keys' => ['nelfinavir', 'เนลฟินาเวียร์', 'เนลฟินาเวีย'],
        ],
        [
            'n' => 22, 'a' => 'Simvastatin', 'b' => 'Saquinavir',
            'onset' => 'Delayed', 'severity' => 'Contraindicated', 'documentation' => 'Fair',
            'effect' => 'increased risk of myopathy or rhabdomyolysis.',
            'reference' => $ref,
            'a_keys' => ['simvastatin', 'ซิมวาสแตติน', 'ซิมวาสตาติน', 'zocor', 'โซคอร์'],
            'b_keys' => ['saquinavir', 'ซาควินาเวียร์', 'ซาควินาเวีย'],
        ],
        [
            'n' => 23, 'a' => 'Simvastatin', 'b' => 'Itraconazole',
            'onset' => 'Rapid', 'severity' => 'Contraindicated', 'documentation' => 'Excellent',
            'effect' => 'increased risk of myopathy or rhabdomyolysis.',
            'reference' => $ref,
            'a_keys' => ['simvastatin', 'ซิมวาสแตติน', 'ซิมวาสตาติน', 'zocor', 'โซคอร์'],
            'b_keys' => ['itraconazole', 'อิทราโคนาโซล', 'ไอทราโคนาโซล', 'sporanox'],
        ],
    ];
}

function di_fatal_lower($s) {
    $s = (string)$s;
    return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
}

function di_fatal_blob(array $drug) {
    return di_fatal_lower(trim(($drug['name_tmt'] ?? '') . ' ' . ($drug['name_local'] ?? '')));
}

function di_fatal_has_any($blob, array $keys) {
    foreach ($keys as $k) {
        $k = di_fatal_lower(trim((string)$k));
        if ($k === '') {
            continue;
        }
        if (function_exists('mb_strpos')) {
            if (mb_strpos($blob, $k) !== false) {
                return true;
            }
        } elseif (strpos($blob, $k) !== false) {
            return true;
        }
    }
    return false;
}

function di_fatal_match_side(array $drugs, array $pair, $side) {
    $keys = $pair[$side . '_keys'] ?? [];
    $require = $pair[$side . '_require_all'] ?? [];
    $exclude = $pair[$side . '_exclude'] ?? [];
    $out = [];
    foreach ($drugs as $d) {
        $blob = di_fatal_blob($d);
        if ($blob === '') {
            continue;
        }
        if ($exclude && di_fatal_has_any($blob, $exclude)) {
            continue;
        }
        $ok = false;
        if ($keys && di_fatal_has_any($blob, $keys)) {
            $ok = true;
        }
        if (!$ok && !empty($require)) {
            $ok = true;
            foreach ($require as $group) {
                $group = is_array($group) ? $group : [$group];
                if (!di_fatal_has_any($blob, $group)) {
                    $ok = false;
                    break;
                }
            }
        }
        if ($ok) {
            $out[] = $d;
        }
    }
    return $out;
}

function di_fatal_find_existing($con, $icode_a, $icode_b) {
    $a = mysqli_real_escape_string($con, $icode_a);
    $b = mysqli_real_escape_string($con, $icode_b);
    $q = mysqli_query(
        $con,
        "SELECT id, IFNULL(pdf_onset,'') AS pdf_onset, IFNULL(detail_text,'') AS detail_text
         FROM monitor_drug_interaction_settings
         WHERE (drug_icode='$a' AND hosxp_icode='$b')
            OR (drug_icode='$b' AND hosxp_icode='$a')
         LIMIT 1"
    );
    return ($q && ($row = mysqli_fetch_assoc($q))) ? $row : null;
}

function di_fatal_pair_exists($con, $icode_a, $icode_b) {
    return di_fatal_find_existing($con, $icode_a, $icode_b) !== null;
}

function di_fatal_import($con, array $hosxp_drugs) {
    ensure_di_dose_columns($con);
    $has_pdf = ensure_di_pdf_columns($con);
    $pairs = di_fatal_di_pairs();
    $inserted = 0;
    $skipped_exist = 0;
    $skipped_missing = [];
    $pair_ok = 0;
    $errors = [];

    foreach ($pairs as $pair) {
        $list_a = di_fatal_match_side($hosxp_drugs, $pair, 'a');
        $list_b = di_fatal_match_side($hosxp_drugs, $pair, 'b');
        if (empty($list_a) || empty($list_b)) {
            $missing = [];
            if (empty($list_a)) {
                $missing[] = 'ไม่พบยา ' . $pair['a'] . ' ใน HOSxP';
            }
            if (empty($list_b)) {
                $missing[] = 'ไม่พบยา ' . $pair['b'] . ' ใน HOSxP';
            }
            $skipped_missing[] = 'คู่ที่ ' . $pair['n'] . ' ' . $pair['a'] . ' ↔ ' . $pair['b'] . ' — ' . implode(', ', $missing);
            continue;
        }
        $pair_ok++;
        $alert = 'hard';
        $onset = mysqli_real_escape_string($con, $pair['onset']);
        $severity = mysqli_real_escape_string($con, $pair['severity']);
        $doc = mysqli_real_escape_string($con, $pair['documentation']);
        $effect = mysqli_real_escape_string($con, $pair['effect']);
        $ref = mysqli_real_escape_string($con, $pair['reference']);
        $pdf_cols = $has_pdf ? ', pdf_onset, pdf_severity, pdf_documentation, pdf_reference' : '';
        $pdf_vals = $has_pdf ? ", '$onset', '$severity', '$doc', '$ref'" : '';

        foreach ($list_a as $da) {
            foreach ($list_b as $db) {
                if ($da['icode'] === $db['icode']) {
                    continue;
                }
                $exist = di_fatal_find_existing($con, $da['icode'], $db['icode']);
                if ($exist) {
                    $skipped_exist++;
                    if ($has_pdf && trim((string)$exist['pdf_onset']) === '') {
                        $eid = (int)$exist['id'];
                        $fill_detail = trim((string)$exist['detail_text']) === ''
                            ? ", detail_text='$effect'"
                            : '';
                        mysqli_query(
                            $con,
                            "UPDATE monitor_drug_interaction_settings
                             SET pdf_onset='$onset', pdf_severity='$severity',
                                 pdf_documentation='$doc', pdf_reference='$ref'
                                 $fill_detail
                             WHERE id=$eid"
                        );
                    }
                    continue;
                }
                $name_a = mysqli_real_escape_string($con, $da['name_tmt'] !== '' ? $da['name_tmt'] : $da['name_local']);
                $name_b = mysqli_real_escape_string($con, $db['name_tmt'] !== '' ? $db['name_tmt'] : $db['name_local']);
                $ic_a = mysqli_real_escape_string($con, $da['icode']);
                $ic_b = mysqli_real_escape_string($con, $db['icode']);
                $sql = "INSERT INTO monitor_drug_interaction_settings
                    (drug_id, drug_name, drug_icode, hosxp_icode, hosxp_drug_name, interaction_type, alert_level, detail_text
                     {$pdf_cols}, check_mode, lookback_days, active_status)
                    VALUES (0, '$name_a', '$ic_a', '$ic_b', '$name_b', 'drug_drug', '$alert', '$effect'
                            {$pdf_vals}, 'lookback', 30, 1)";
                if (mysqli_query($con, $sql)) {
                    $inserted++;
                } else {
                    $errors[] = mysqli_error($con);
                }
            }
        }
    }

    return [
        'inserted' => $inserted,
        'skipped_exist' => $skipped_exist,
        'pair_ok' => $pair_ok,
        'pair_total' => count($pairs),
        'missing' => $skipped_missing,
        'errors' => array_slice(array_unique($errors), 0, 5),
    ];
}
