<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
tham_menu_ensure_page_access('patient_opd.php');
$prefill_hn = htmlspecialchars(trim((string)($_GET['hn'] ?? '')), ENT_QUOTES, 'UTF-8');
$prefill_vn = htmlspecialchars(trim((string)($_GET['vn'] ?? '')), ENT_QUOTES, 'UTF-8');
$prefill_date = htmlspecialchars(trim((string)($_GET['vstdate'] ?? '')), ENT_QUOTES, 'UTF-8');
$prefill_cmp_vn = htmlspecialchars(trim((string)($_GET['compare_vn'] ?? '')), ENT_QUOTES, 'UTF-8');
$prefill_cmp_an = htmlspecialchars(trim((string)($_GET['compare_an'] ?? '')), ENT_QUOTES, 'UTF-8');
$user_name = htmlspecialchars((string)($_SESSION['full_name'] ?? ''), ENT_QUOTES, 'UTF-8');
$can_smart_drug = tham_menu_can('pharm_care.smart_drug') || (($_SESSION['role'] ?? '') === 'admin');
$can_smart_lab = tham_menu_can('pharm_care.smart_lab') || (($_SESSION['role'] ?? '') === 'admin');
$can_patient_ipd = tham_menu_can('pharm_care.patient_ipd') || (($_SESSION['role'] ?? '') === 'admin');
$emr_hn_qs = $prefill_hn !== '' ? ('?hn=' . rawurlencode(html_entity_decode($prefill_hn, ENT_QUOTES, 'UTF-8'))) : '';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Patient OPD - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        html, body { height: 100%; margin: 0; overflow: hidden; }
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: #e8eef1; color: #243038; font-size: 13px; }
        .pop-shell { height: 100vh; display: flex; flex-direction: column; min-height: 0; overflow: hidden; }
        .pop-chrome {
            flex: 0 0 auto; min-height: 50px; display: flex; align-items: center; gap: 12px;
            padding: 0 14px; background: #fff; border-bottom: 1px solid #d5e4ea;
            box-shadow: 0 1px 0 rgba(10, 162, 192, .08); flex-wrap: nowrap; overflow: hidden;
        }
        .pop-back {
            color: #5a7380; text-decoration: none; width: 32px; height: 32px;
            display: inline-flex; align-items: center; justify-content: center;
            border-radius: 8px;
        }
        .pop-back:hover { background: #eef6f8; color: #0aa2c0; }
        .pop-brand { font-weight: 800; font-size: 1.2rem; color: #0aa2c0; letter-spacing: .02em; white-space: nowrap; }
        .pop-brand span { color: #1488a3; }
        .pop-search-bar { display: flex; align-items: center; gap: 6px; flex: 0 0 auto; }
        .pop-search-bar input {
            height: 32px; width: 200px; font-weight: 700; font-size: 13px; border: 1px solid #c5dbe3;
            border-radius: 6px; padding: 0 10px;
        }
        .pop-search-bar button {
            height: 32px; border: 0; border-radius: 6px; background: #0aa2c0; color: #fff;
            font-weight: 700; padding: 0 12px; white-space: nowrap;
        }
        .pop-emr-links { display: flex; align-items: center; gap: 6px; flex: 0 0 auto; }
        .pop-emr-link {
            display: inline-flex; align-items: center; gap: 5px; height: 32px; padding: 0 10px;
            border-radius: 6px; text-decoration: none; font-weight: 800; font-size: 12px;
            border: 1px solid #c5e4ec; background: #e8f7fb; color: #0b7285; white-space: nowrap;
        }
        .pop-emr-link:hover { background: #d4eef5; color: #085d6c; }
        .pop-emr-link i { font-size: 12px; }
        .pop-status { color: #5a7380; font-size: 12px; flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .pop-chrome-right { margin-left: auto; display: flex; align-items: center; gap: 10px; color: #355; font-weight: 700; white-space: nowrap; }
        .pop-mode {
            background: #e8f7fb; color: #0b7285; border: 1px solid #c5e4ec;
            border-radius: 6px; padding: 4px 10px; font-size: 12px;
        }
        .pop-stage { flex: 1; min-height: 0; display: flex; background: #fff; }
        .pop-empty {
            flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;
            color: #8a9aa3; gap: 8px;
        }
        .pop-left {
            width: 310px; flex: 0 0 310px; border-right: 1px solid #d7e6ec;
            background: #fbfdfe; padding: 10px 12px 10px; min-height: 0;
            display: grid; grid-template-rows: auto minmax(0, 1fr); overflow: auto;
        }
        .pop-left-top { min-width: 0; }
        .pop-notes {
            min-height: 0; display: flex; flex-direction: column; overflow: hidden;
            margin-top: 4px;
        }
        .pop-right { flex: 1; min-width: 0; display: flex; flex-direction: column; min-height: 0; }
        .pop-pt-head { display: flex; gap: 10px; }
        .pop-photo {
            width: 78px; height: 92px; object-fit: cover; border-radius: 4px;
            border: 1px solid #c5d5dc; background: #e9eef1; flex-shrink: 0;
        }
        .pop-photo-ph {
            width: 78px; height: 92px; border-radius: 4px; border: 1px solid #c5d5dc;
            background: #d9e4ea; color: #7a8f98; display: flex; align-items: center; justify-content: center;
            font-size: 2rem; flex-shrink: 0;
        }
        .pop-hn { font-size: 12px; color: #4a6570; }
        .pop-hn b { color: #0b7285; }
        .pop-name { font-size: 1.05rem; font-weight: 800; color: #0aa2c0; line-height: 1.25; }
        .pop-meta { font-size: 12px; color: #334; line-height: 1.45; }
        .pop-chip {
            display: inline-block; font-size: 11px; font-weight: 700; padding: 1px 7px;
            border-radius: 4px; margin: 1px 2px 1px 0;
        }
        .chip-dep { background: #fff3cd; color: #856404; }
        .chip-right { background: #e7f5ff; color: #0b4f8a; }
        .chip-al { background: #f8d7da; color: #842029; }
        .chip-ok { background: #d1e7dd; color: #0f5132; }
        .chip-note { background: #e7f1fb; color: #0b4f8a; cursor: pointer; border: 1px solid #b6d4fe; }
        .chip-note:hover { background: #d4e8fb; }
        .pop-appt-mini { margin-top: 8px; border: 1px solid #dce8ed; border-radius: 6px; overflow: hidden; }
        .pop-appt-mini table { width: 100%; margin: 0; font-size: 11px; }
        .pop-appt-mini th { background: #f1f6f8; font-weight: 700; padding: 3px 5px; }
        .pop-appt-mini td { padding: 3px 5px; }
        .pop-vital-row { display: grid; grid-template-columns: 1fr 108px; gap: 8px; margin-top: 8px; align-items: start; }
        .pop-vitals table { width: 100%; font-size: 12px; }
        .pop-vitals th { font-weight: 700; color: #4a6570; width: 52px; }
        .pop-vitals td { padding: 1px 4px; }
        .pop-bag {
            border: 1px solid #dce8ed; border-radius: 8px; background: #fff;
            min-height: 92px; text-align: center; color: #adb5bd; padding: 8px 4px 6px;
            font-size: 11px;
        }
        .pop-bag .bag-title { font-weight: 800; color: #4a6570; margin-bottom: 6px; text-align: left; padding-left: 6px; }
        .pop-note {
            border-radius: 8px; padding: 6px 8px; min-height: 0; height: 100%;
            overflow: auto; margin-top: 0;
            font-size: 12px; white-space: pre-wrap; word-break: break-word;
        }
        .note-cc { background: #e8f8ef; border: 1px solid #b7e4c7; }
        .note-pf { background: #e8f8ef; border: 1px solid #b7e4c7; }
        .note-hpi { background: #e7f1fb; border: 1px solid #b6d4fe; }
        .note-pmh { background: #fdeeee; border: 1px solid #f5c2c7; }
        .note-title { font-weight: 800; font-size: 11px; color: #355; margin-bottom: 2px; }
        .note-pair {
            display: grid; grid-template-columns: 1fr 1fr; gap: 6px;
            flex: 1 1 0; min-height: 68px;
        }
        .note-pair-hp { flex: 1.55 1 0; min-height: 88px; }
        .note-cap { font-size: 11px; font-weight: 700; color: #5a7380; margin: 4px 0 4px; flex: 0 0 auto; }
        .pop-sec-title {
            background: #dff4f8; color: #0b7285; font-weight: 800; font-size: 13px;
            padding: 7px 12px; border-bottom: 1px solid #c5e4ec; flex: 0 0 auto;
        }
        .pop-drug-meta { padding: 4px 12px; font-size: 12px; color: #355; background: #f7fbfc; border-bottom: 1px solid #e4eef2; flex: 0 0 auto; }
        .pop-drugs { flex: 1; min-height: 0; display: flex; flex-direction: column; }
        .pop-table-wrap { overflow: auto; flex: 1; min-height: 0; }
        .pop-table { width: 100%; font-size: 12px; margin: 0; }
        .pop-table th {
            position: sticky; top: 0; z-index: 1; background: #eef6f8; font-weight: 700;
            white-space: nowrap; padding: 5px 6px; border-bottom: 1px solid #d0e2e8; color: #355;
        }
        .pop-table td { padding: 4px 6px; border-bottom: 1px solid #eef2f4; vertical-align: top; }
        .pop-table tr:hover td { background: #f4fbfd; }
        .pop-drug-table { min-width: 1680px; }
        .td-new { color: #0d6efd; font-weight: 800; text-align: center; }
        .td-num { text-align: right; white-space: nowrap; }
        .td-ellipsis { max-width: 110px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .td-drug { min-width: 160px; max-width: 240px; }
        .td-use { min-width: 140px; max-width: 220px; }
        .cmp-same { color: #0d6efd; font-weight: 700; white-space: nowrap; }
        .cmp-new { color: #0d6efd; font-weight: 700; white-space: nowrap; }
        .cmp-chg { color: #d35400; font-weight: 700; white-space: nowrap; }
        .cmp-stop { color: #868e96; font-weight: 700; white-space: nowrap; }
        .pay-chk { accent-color: #e74c3c; width: 15px; height: 15px; }
        .pop-bottom {
            display: grid; grid-template-columns: 1.05fr 1.2fr 1.05fr;
            border-top: 1px solid #d7e6ec; height: 250px; flex: 0 0 250px;
        }
        .pop-pane { border-right: 1px solid #d7e6ec; min-width: 0; display: flex; flex-direction: column; min-height: 0; }
        .pop-pane:last-child { border-right: 0; }
        .pop-pane-h { background: #f4f8fa; font-weight: 800; font-size: 12px; padding: 5px 8px; border-bottom: 1px solid #e0eaee; flex: 0 0 auto; }
        .pop-pane-b { overflow: auto; flex: 1; min-height: 0; }
        .visit-table { width: 100%; font-size: 12px; margin: 0; border-collapse: collapse; }
        .visit-table th {
            position: sticky; top: 0; z-index: 1; background: #eef6f8; font-weight: 700;
            white-space: nowrap; padding: 5px 6px; border-bottom: 1px solid #d0e2e8; color: #355; text-align: left;
        }
        .visit-table td { padding: 5px 6px; border-bottom: 1px solid #eef2f4; vertical-align: middle; }
        .visit-table tr { cursor: pointer; }
        .visit-table tr:hover td { background: #e8f4fd; }
        .visit-table tr.current td { background: #f3fafc; }
        .visit-table tr.compare td { background: #d4eef5; }
        .visit-table tr.no-drug td { color: #8a9aa3; }
        .visit-date { font-weight: 700; white-space: nowrap; }
        .visit-type { font-weight: 800; color: #0b7285; text-align: center; }
        .visit-room { min-width: 0; }
        .visit-doc { color: #4a6570; max-width: 110px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .visit-drug { text-align: right; font-weight: 800; white-space: nowrap; }
        .visit-drug .n { display: inline-block; min-width: 22px; padding: 0 6px; border-radius: 8px; background: #dff4f8; color: #0b7285; }
        .visit-drug .n.zero { background: #eef2f4; color: #8a9aa3; font-weight: 600; }
        .cost-split { display: grid; grid-template-columns: 1fr 1fr; min-height: 0; flex: 1; }
        .cost-box { padding: 8px 10px; }
        .cost-row { display: flex; justify-content: space-between; align-items: center; padding: 3px 0; }
        .cost-val { font-weight: 800; min-width: 88px; text-align: right; padding: 2px 8px; border-radius: 4px; }
        .cost-total { background: #cfe2ff; color: #084298; }
        .cost-ed { background: #f8d7da; color: #842029; }
        .cost-neg { background: #cfe2ff; color: #084298; }
        .cost-disc { background: #fff3cd; color: #664d03; }
        .cost-claim { background: #e9ecef; color: #495057; }
        .appt-empty { color: #adb5bd; text-align: center; padding: 18px 8px; }
        .pop-foot {
            display: flex; justify-content: stretch; gap: 8px; padding: 8px 10px;
            background: #f7fbfc; border-top: 1px solid #d7e6ec; flex: 0 0 auto;
        }
        .btn-screen { flex: 1; background: #7dcea0; border: 0; color: #143; font-weight: 800; padding: 8px 10px; border-radius: 6px; cursor: pointer; }
        .btn-qty-save { flex: 1; background: #5dade2; border: 0; color: #08324d; font-weight: 800; padding: 8px 10px; border-radius: 6px; cursor: pointer; }
        .btn-appt { flex: 1; background: #f7dc6f; border: 0; color: #5c4800; font-weight: 800; padding: 8px 10px; border-radius: 6px; }
        .btn-screen:not([disabled]):hover, .btn-qty-save:not([disabled]):hover { filter: brightness(0.96); }
        .btn-screen[disabled], .btn-appt[disabled], .btn-qty-save[disabled] { opacity: .65; cursor: not-allowed; }
        .btn-qty-save.dirty { box-shadow: 0 0 0 2px #f4d03f inset; }
        .pop-qty-inp {
            width: 58px; height: 26px; text-align: right; font-weight: 800; font-size: 12px;
            border: 1px solid #9ad0e0; border-radius: 4px; padding: 0 4px; color: #0b4f8a; background: #fff;
        }
        .pop-qty-inp:focus { outline: 2px solid #5dade2; border-color: #5dade2; }
        .pop-qty-inp.dirty { background: #fff8db; border-color: #f0c36d; }
        .pop-qty-locked { color: #8a9aa3; }
        .muted { color: #8a9aa3; }
        .pop-alert {
            position: fixed; inset: 0; background: rgba(20, 40, 48, .35);
            display: none; align-items: center; justify-content: center; z-index: 50;
        }
        .pop-alert-box {
            width: min(420px, calc(100% - 32px)); background: #fff; border-radius: 12px;
            box-shadow: 0 12px 40px rgba(15, 40, 48, .22); padding: 18px 18px 14px; text-align: center;
        }
        .pop-alert-title { font-weight: 800; color: #0b7285; margin-bottom: 8px; }
        .pop-alert-msg { color: #842029; font-weight: 700; line-height: 1.45; }
        .pop-alert-box button {
            margin-top: 14px; border: 0; border-radius: 8px; background: #0aa2c0; color: #fff;
            font-weight: 800; padding: 7px 22px; cursor: pointer;
        }
        .pop-alert-box input {
            width: 100%; box-sizing: border-box; margin-top: 8px; height: 34px;
            border: 1px solid #c5dbe3; border-radius: 6px; padding: 0 10px; font-size: 13px;
        }
        .pop-alert-box .hint { color: #5a7380; font-weight: 600; font-size: 12px; margin-top: 8px; }
        .pop-alert-box .btn-row { display: flex; gap: 8px; justify-content: center; }
        .pop-alert-box .btn-ghost { background: #e9eef1; color: #355; }
        .pop-note-modal {
            position: fixed; inset: 0; background: rgba(20, 40, 48, .45);
            display: none; align-items: center; justify-content: center; z-index: 60;
        }
        .pop-note-box {
            width: min(820px, calc(100% - 40px)); max-height: min(78vh, 640px);
            background: #fff; border-radius: 12px; box-shadow: 0 16px 48px rgba(15, 40, 48, .28);
            display: flex; flex-direction: column; min-height: 0; overflow: hidden;
        }
        .pop-note-head {
            display: flex; align-items: center; justify-content: space-between;
            padding: 12px 16px 8px; flex: 0 0 auto;
        }
        .pop-note-head h6 { margin: 0; font-weight: 800; font-size: 1.05rem; color: #243038; }
        .pop-note-x {
            border: 0; background: transparent; color: #6c757d; font-size: 1.3rem;
            line-height: 1; cursor: pointer; padding: 0 4px;
        }
        .pop-note-body { overflow: auto; padding: 0 12px 14px; min-height: 0; }
        .pop-note-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .pop-note-table th {
            background: #e7f1fb; color: #1b4f72; font-weight: 800; text-align: center;
            padding: 8px 10px; border-bottom: 1px solid #d0e4f5; white-space: nowrap;
        }
        .pop-note-table td { padding: 10px 10px; border-bottom: 1px solid #eef2f4; vertical-align: top; }
        .pop-note-table tr:last-child td { border-bottom: 0; }
        .pop-note-text { white-space: pre-wrap; word-break: break-word; color: #243038; }
        .pop-note-staff, .pop-note-date, .pop-note-exp { text-align: center; white-space: nowrap; color: #355; }
        .pop-note-empty { text-align: center; color: #8a9aa3; padding: 28px 12px; }
        @media (max-width: 960px) {
            .pop-chrome-right { display: none; }
            .pop-status { display: none; }
            .pop-left { width: 260px; flex-basis: 260px; }
            .pop-bottom { grid-template-columns: 1fr; height: auto; flex: 0 0 auto; max-height: 50%; }
            .pop-pane { border-right: 0; border-bottom: 1px solid #d7e6ec; min-height: 160px; }
        }
        @media (max-width: 1100px) {
            .pop-left { width: 260px; flex-basis: 260px; }
        }
    </style>
</head>
<body>
<div class="pop-shell">
    <div class="pop-chrome">
        <a class="pop-back" href="home.php" title="กลับหน้าหลัก"><i class="fas fa-arrow-left"></i></a>
        <div class="pop-brand">Patient OPD</div>
        <form id="popForm" class="pop-search-bar">
            <input type="text" id="popHn" value="<?php echo $prefill_hn; ?>" placeholder="ค้นหา HN..." autocomplete="off">
            <button type="submit"><i class="fas fa-search me-1"></i>ค้นหา</button>
        </form>
        <?php if ($can_smart_drug || $can_smart_lab || $can_patient_ipd) { ?>
        <nav class="pop-emr-links" aria-label="Patient EMR">
            <?php if ($can_patient_ipd) { ?>
            <a class="pop-emr-link" id="linkPatientIpd" href="patient_ipd.php<?php echo $emr_hn_qs; ?>" title="เปิด Patient IPD ของ HN นี้"><i class="fas fa-procedures"></i> Patient IPD</a>
            <?php } ?>
            <?php if ($can_smart_drug) { ?>
            <a class="pop-emr-link" id="linkSmartDrug" href="smart_drug.php<?php echo $emr_hn_qs; ?>" title="เปิด Smart Drug ของ HN นี้"><i class="fas fa-pills"></i> Smart Drug</a>
            <?php } ?>
            <?php if ($can_smart_lab) { ?>
            <a class="pop-emr-link" id="linkSmartLab" href="smart_lab.php<?php echo $emr_hn_qs; ?>" title="เปิด Smart Lab ของ HN นี้"><i class="fas fa-vials"></i> Smart Lab</a>
            <?php } ?>
        </nav>
        <?php } ?>
        <div class="pop-status" id="popStatus"></div>
        <div class="pop-chrome-right">
            <span class="pop-mode">ดูประวัติ</span>
            <span><i class="fas fa-user-circle me-1"></i><?php echo $user_name; ?></span>
        </div>
    </div>
    <div class="pop-stage" id="popPlaceholder">
        <div class="pop-empty">
            <i class="fas fa-user-injured fa-3x"></i>
            <div id="popEmptyMsg">กรอก HN แล้วกดค้นหา เพื่อดูประวัติผู้ป่วยจาก HOSxP</div>
        </div>
    </div>
    <div class="pop-stage" id="popMain" style="display:none;">
        <div class="pop-left" id="popLeft"></div>
        <div class="pop-right">
            <div class="pop-drugs">
                <div class="pop-sec-title">เปรียบเทียบรายการยา</div>
                <div class="pop-drug-meta" id="popDrugMeta"></div>
                <div class="pop-table-wrap">
                    <table class="pop-table pop-drug-table">
                        <thead>
                            <tr>
                                <th></th>
                                <th>เพิ่ม</th>
                                <th>ลำดับ</th>
                                <th>บัญชียา</th>
                                <th>ยาปัจจุบัน</th>
                                <th>จำนวน</th>
                                <th>ค้างจ่าย</th>
                                <th>ยาที่นำมาเทียบ</th>
                                <th>จำนวน</th>
                                <th>วิธีใช้ปัจจุบัน</th>
                                <th>วิธีใช้ที่นำมาเทียบ</th>
                                <th>การเทียบ</th>
                                <th>การจ่าย</th>
                                <th>แพทย์</th>
                                <th>ราคา</th>
                                <th>รหัสยาปัจจุบัน</th>
                                <th>ผู้คัดยา</th>
                                <th>ผู้จ่ายยา</th>
                            </tr>
                        </thead>
                        <tbody id="popDrugBody"></tbody>
                    </table>
                </div>
            </div>
            <div class="pop-bottom">
                <div class="pop-pane">
                    <div class="pop-pane-h">ประวัติการมารับบริการ</div>
                    <div class="pop-pane-b" id="popVisits"></div>
                </div>
                <div class="pop-pane">
                    <div class="pop-pane-h">ผลตรวจ LAB</div>
                    <div class="pop-pane-b">
                        <table class="pop-table">
                            <thead>
                                <tr>
                                    <th>LAB</th>
                                    <th>ค่าปัจจุบัน</th>
                                    <th>Visit(เทียบ)</th>
                                    <th>วันที่ตรวจ</th>
                                </tr>
                            </thead>
                            <tbody id="popLabBody"></tbody>
                        </table>
                    </div>
                </div>
                <div class="pop-pane">
                    <div class="pop-pane-h">รวมค่าใช้จ่าย / รายการนัดหมาย</div>
                    <div class="pop-pane-b" id="popCostAppt"></div>
                    <div class="pop-foot">
                        <button type="button" class="btn-qty-save" id="btnQtySave" disabled title="ค้นหาผู้ป่วยก่อน">บันทึกจำนวนยา</button>
                        <button type="button" class="btn-screen" id="btnScreen" disabled title="ค้นหาผู้ป่วยก่อน">ยืนยันการคัดกรอง</button>
                        <button type="button" class="btn-appt" disabled title="หน้านี้สำหรับดูประวัติเท่านั้น">สร้างใบนัดรับ</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="pop-alert" id="popAlert">
    <div class="pop-alert-box">
        <div class="pop-alert-title"><i class="fas fa-unlink me-1"></i> HAPYsure</div>
        <div class="pop-alert-msg" id="popAlertMsg">ไม่เชื่อมต่อ HAPYsure ยังไม่สามารถใช้งานได้</div>
        <button type="button" id="popAlertOk">ตกลง</button>
    </div>
</div>
<div class="pop-alert" id="popHapyLogin">
    <div class="pop-alert-box" style="text-align:left;">
        <div class="pop-alert-title" style="text-align:center;"><i class="fas fa-sign-in-alt me-1"></i> เข้า HAPYsure</div>
        <div class="hint">ใช้ user/password เดียวกับที่ login THAM ถ้าตรงกับ HAPYsure จะเข้าหน้าผู้ป่วยต่อได้เลย</div>
        <input type="text" id="hapyUser" placeholder="Username" autocomplete="username">
        <input type="password" id="hapyPass" placeholder="Password" autocomplete="current-password">
        <div class="btn-row">
            <button type="button" class="btn-ghost" id="hapyLoginCancel">ยกเลิก</button>
            <button type="button" id="hapyLoginOk">เข้า HAPYsure</button>
        </div>
    </div>
</div>
<div class="pop-note-modal" id="popHosxpNotes">
    <div class="pop-note-box">
        <div class="pop-note-head">
            <h6>บันทึกจากระบบ Hosxp</h6>
            <button type="button" class="pop-note-x" id="popHosxpNotesX" aria-label="ปิด">&times;</button>
        </div>
        <div class="pop-note-body" id="popHosxpNotesBody"></div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script>
const PREFILL = {
    hn: <?php echo json_encode($prefill_hn, JSON_UNESCAPED_UNICODE); ?>,
    vn: <?php echo json_encode($prefill_vn, JSON_UNESCAPED_UNICODE); ?>,
    vstdate: <?php echo json_encode($prefill_date, JSON_UNESCAPED_UNICODE); ?>,
    compare_vn: <?php echo json_encode($prefill_cmp_vn, JSON_UNESCAPED_UNICODE); ?>,
    compare_an: <?php echo json_encode($prefill_cmp_an, JSON_UNESCAPED_UNICODE); ?>
};
let STATE = null;
let lastNoteHn = '';

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function dash(s) { return (s === '' || s == null) ? '-' : esc(s); }
function money(n) {
    const x = Number(n);
    return (isFinite(x) ? x : 0).toFixed(2);
}
function qtyText(q) {
    if (q === '' || q == null) return '';
    const s = String(q);
    return /^\d+$/.test(s) ? (s + '#') : s;
}

function syncEmrLinks(hn) {
    const q = hn ? ('?hn=' + encodeURIComponent(hn)) : '';
    const ipd = document.getElementById('linkPatientIpd');
    const drug = document.getElementById('linkSmartDrug');
    const lab = document.getElementById('linkSmartLab');
    if (ipd) ipd.setAttribute('href', 'patient_ipd.php' + q);
    if (drug) drug.setAttribute('href', 'smart_drug.php' + q);
    if (lab) lab.setAttribute('href', 'smart_lab.php' + q);
}

function loadPatient(opts) {
    opts = opts || {};
    const hn = (opts.hn != null ? opts.hn : $('#popHn').val() || '').trim();
    if (!hn) {
        $('#popStatus').text('กรุณากรอก HN');
        $('#popEmptyMsg').html('<span class="text-danger">กรุณากรอก HN</span>');
        return;
    }
    $('#popHn').val(hn);
    const qs = new URLSearchParams();
    qs.set('action', 'lookup');
    qs.set('hn', hn);
    if (opts.vn) qs.set('vn', opts.vn);
    if (opts.an) qs.set('an', opts.an);
    if (opts.vstdate) qs.set('vstdate', opts.vstdate);
    if (opts.compare_vn) qs.set('compare_vn', opts.compare_vn);
    if (opts.compare_an) qs.set('compare_an', opts.compare_an);
    $('#popStatus').html('<i class="fas fa-spinner fa-spin me-1"></i>กำลังดึงประวัติจาก HOSxP...');
    fetch('fetch_patient_opd_api.php?' + qs.toString())
        .then(r => r.json())
        .then(data => {
            if (!data || !data.ok) {
                const err = (data && data.error) ? data.error : 'ไม่พบข้อมูล';
                $('#popStatus').html('<span class="text-danger">' + esc(err) + '</span>');
                $('#popEmptyMsg').html('<span class="text-danger">' + esc(err) + '</span>');
                $('#popMain').hide();
                $('#popPlaceholder').css('display', 'flex');
                return;
            }
            STATE = data;
            renderAll(data);
            $('#popPlaceholder').hide();
            $('#popMain').css('display', 'flex');
            const cur = data.current || {};
            const cmp = data.compare || {};
            $('#popStatus').text('HN ' + (data.patient.hn_display || data.patient.hn) + (cur.vn ? ' · VN ' + cur.vn : ''));
            syncEmrLinks(data.patient.hn_display || data.patient.hn || hn);
            const url = new URL(window.location.href);
            url.searchParams.set('hn', data.patient.hn);
            if (cur.vn) url.searchParams.set('vn', cur.vn); else url.searchParams.delete('vn');
            if (cur.vstdate) url.searchParams.set('vstdate', cur.vstdate); else url.searchParams.delete('vstdate');
            if (cmp.vn) url.searchParams.set('compare_vn', cmp.vn); else url.searchParams.delete('compare_vn');
            if (cmp.an) url.searchParams.set('compare_an', cmp.an); else url.searchParams.delete('compare_an');
            history.replaceState({}, '', url);
        })
        .catch(() => {
            $('#popStatus').html('<span class="text-danger">เชื่อมต่อไม่สำเร็จ</span>');
            $('#popEmptyMsg').html('<span class="text-danger">เชื่อมต่อไม่สำเร็จ</span>');
        });
}

function noteBox(cls, title, text) {
    const body = text ? esc(text) : '<span class="muted">ไม่มีข้อมูล</span>';
    return '<div class="pop-note ' + cls + '"><div class="note-title">' + title + '</div>' + body + '</div>';
}

function renderLeft(d) {
    const p = d.patient || {};
    const cur = d.current || {};
    const cmp = d.screen_compare || {};
    const sc = d.screen || {};
    const al = d.allergy || {};
    const next = d.next_appointment;
    const hnPhoto = encodeURIComponent(p.hn_display || p.hn || '');
    const photo = '<img class="pop-photo" alt="" src="fetch_patient_opd_api.php?action=photo&hn=' + hnPhoto + '" onerror="this.onerror=null;this.outerHTML=\'<div class=&quot;pop-photo-ph&quot;><i class=&quot;fas fa-user&quot;></i></div>\'">';
    let chips = '';
    if (cur.room_name) chips += '<span class="pop-chip chip-dep">' + esc(cur.room_name) + '</span>';
    if (cur.pttype_name) chips += '<span class="pop-chip chip-right">' + esc(cur.pttype_name) + '</span>';
    if (al.has_allergy) chips += '<span class="pop-chip chip-al">แพ้ยา: ' + esc(al.text) + '</span>';
    else chips += '<span class="pop-chip chip-ok">ไม่แพ้ยา</span>';
    const notes = d.hosxp_notes || [];
    if (notes.length) {
        chips += '<button type="button" class="pop-chip chip-note" id="btnHosxpNotes"><i class="fas fa-sticky-note me-1"></i>บันทึก HOSxP (' + notes.length + ')</button>';
    }
    let appt = '';
    if (next) {
        appt = '<div class="pop-appt-mini"><table><thead><tr><th>วันที่เปิด</th><th>อีก(วัน)</th><th>คลินิก</th><th>แพทย์</th></tr></thead><tbody><tr>'
            + '<td>' + esc(next.nextdate_be || '') + '</td>'
            + '<td>' + esc(next.days == null ? '' : next.days) + '</td>'
            + '<td>' + esc(next.clinic_name || '') + '</td>'
            + '<td>' + esc(next.doctor_name || '') + '</td>'
            + '</tr></tbody></table></div>';
    }
    $('#popLeft').html(
        '<div class="pop-left-top">'
        + '<div class="pop-pt-head">'
        + '<div style="flex:1;min-width:0;">'
        + '<div class="pop-hn">HN <b>' + esc(p.hn_display || p.hn) + '</b> &nbsp; VN <b>' + esc(cur.vn || '-') + '</b></div>'
        + '<div class="pop-hn">วันที่เข้ารับการ ' + esc(cur.vstdate_th || cur.vstdate_be || '-') + '</div>'
        + '<div class="pop-name">' + esc(p.full_name || '') + '</div>'
        + '</div>' + photo + '</div>'
        + '<div class="pop-meta mt-1">อายุ ' + esc(p.age_text || '-') + (p.phone ? ' &nbsp; โทรศัพท์ ' + esc(p.phone) : '') + '</div>'
        + '<div class="pop-meta">ที่อยู่ ' + esc(p.address || '-') + '</div>'
        + '<div class="pop-meta">ห้องตรวจ ' + esc(cur.room_name || '-') + '</div>'
        + '<div class="pop-meta">แพทย์ผู้ส่ง ' + esc(cur.doctor_name || '-') + '</div>'
        + '<div class="pop-meta">สิทธิการรักษา ' + esc(cur.pttype_name || '-') + '</div>'
        + '<div class="mt-1">' + chips + '</div>'
        + appt
        + '<div class="pop-vital-row">'
        + '<div class="pop-vitals"><table>'
        + '<thead><tr><th>ค่า</th><th>ปัจจุบัน</th><th>vst</th></tr></thead><tbody>'
        + '<tr><th>BW</th><td>' + dash(sc.bw) + '</td><td>' + dash(cmp.bw) + '</td></tr>'
        + '<tr><th>ส่วนสูง</th><td>' + dash(sc.height) + '</td><td>' + dash(cmp.height) + '</td></tr>'
        + '<tr><th>BMI</th><td>' + dash(sc.bmi) + '</td><td>' + dash(cmp.bmi) + '</td></tr>'
        + '<tr><th>BPS</th><td>' + dash(sc.bps) + '</td><td>' + dash(cmp.bps) + '</td></tr>'
        + '<tr><th>ชีพจร</th><td>' + dash(sc.pulse) + '</td><td>' + dash(cmp.pulse) + '</td></tr>'
        + '</tbody></table></div>'
        + '<div class="pop-bag"><div class="bag-title">รายการเทียบยา</div><i class="fas fa-shopping-bag fa-lg d-block mb-1"></i>ไม่มีข้อมูล</div>'
        + '</div>'
        + '</div>'
        + '<div class="pop-notes">'
        + '<div class="note-cap">เทียบอาการกับประวัติปัจจุบันกับก่อนหน้า</div>'
        + '<div class="note-pair">' + noteBox('note-cc', 'CC:', sc.cc) + noteBox('note-cc', 'CC:', cmp.cc) + '</div>'
        + '<div class="note-pair">' + noteBox('note-pf', 'PF:', sc.pe) + noteBox('note-pf', 'PF:', cmp.pe) + '</div>'
        + '<div class="note-pair note-pair-hp">' + noteBox('note-hpi', 'HPI:', sc.hpi) + noteBox('note-pmh', 'PMH:', sc.pmh) + '</div>'
        + '</div>'
    );
}

function compareCell(r) {
    const key = r.compare_key || (r.is_new ? 'new' : 'same');
    const label = r.compare_label || (r.is_new ? 'ยาใหม่' : 'เท่ากัน');
    if (key === 'same') {
        return '<span class="cmp-same"><i class="fas fa-check-circle"></i> ' + esc(label) + '</span>';
    }
    if (key === 'new') {
        return '<span class="cmp-new">' + esc(label) + '</span>';
    }
    if (key === 'stop') {
        return '<span class="cmp-stop">' + esc(label) + '</span>';
    }
    return '<span class="cmp-chg">' + esc(label) + '</span>';
}

function renderDrugs(d) {
    const cur = d.current || {};
    const cmp = d.compare || {};
    $('#popDrugMeta').html(
        'ข้อมูลรายการเทียบยา &nbsp; VN <b>' + esc(cur.vn || '-') + '</b>'
        + ' &nbsp; สิทธิการรักษา <b>' + esc(cur.pttype_name || '-') + '</b>'
        + (cmp.vn ? ' &nbsp; เทียบกับ <b>' + esc(cmp.vstdate_be || cmp.vn) + '</b>' : '')
        + ' &nbsp; <span class="muted">แก้จำนวนยาปัจจุบันได้ แล้วกดบันทึกจำนวนยา</span>'
    );
    const rows = d.drugs || [];
    if (!rows.length) {
        $('#popDrugBody').html('<tr><td colspan="18" class="muted" style="text-align:center;padding:18px;">ไม่มีรายการยาใน visit นี้</td></tr>');
        return;
    }
    let html = '';
    rows.forEach(r => {
        const hasCur = !!(r.cur_name || '');
        let qtyHtml = '';
        if (!hasCur) {
            qtyHtml = '';
        } else if (r.qty_locked || !r.hos_guid) {
            qtyHtml = '<span class="pop-qty-locked" title="' + esc(r.qty_lock_reason || 'แก้ไม่ได้') + '">' + esc(qtyText(r.cur_qty)) + '</span>';
        } else {
            qtyHtml = '<input class="pop-qty-inp" type="number" min="0" max="9999" step="1" value="'
                + esc(r.cur_qty) + '" data-orig="' + esc(r.cur_qty) + '" data-guid="' + esc(r.hos_guid)
                + '" data-icode="' + esc(r.icode) + '" data-unit="' + esc(r.unitprice || 0) + '">';
        }
        html += '<tr>'
            + '<td><input type="checkbox" class="pay-chk" ' + (hasCur ? 'checked' : '') + ' disabled></td>'
            + '<td class="td-new">' + (r.is_new ? '+' : '') + '</td>'
            + '<td>' + esc(r.seq) + '</td>'
            + '<td>' + esc(r.ed || '') + '</td>'
            + '<td class="td-drug">' + esc(r.cur_name || '') + '</td>'
            + '<td class="td-num">' + qtyHtml + '</td>'
            + '<td class="td-num pop-remain">' + esc(r.cur_remain || '') + '</td>'
            + '<td class="td-drug">' + esc(r.cmp_name || '') + '</td>'
            + '<td class="td-num">' + esc(qtyText(r.cmp_qty)) + '</td>'
            + '<td class="td-use">' + esc(r.cur_usage || '') + '</td>'
            + '<td class="td-use">' + esc(r.cmp_usage || '') + '</td>'
            + '<td>' + compareCell(r) + '</td>'
            + '<td style="text-align:center;"><input type="checkbox" class="pay-chk" ' + (hasCur ? 'checked' : '') + ' disabled></td>'
            + '<td class="td-ellipsis" title="' + esc(r.doctor_name || '') + '">' + esc(r.doctor_name || '-') + '</td>'
            + '<td class="td-num pop-price">' + (hasCur ? money(r.price) : '') + '</td>'
            + '<td>' + esc(r.icode || '') + '</td>'
            + '<td>' + esc(r.picker_name || '-') + '</td>'
            + '<td class="td-ellipsis" title="' + esc(r.staff_name || '') + '">' + esc(r.staff_name || '-') + '</td>'
            + '</tr>';
    });
    $('#popDrugBody').html(html);
}

function renderVisits(d) {
    const curKey = (d.current && d.current.key) || '';
    const cmpKey = (d.compare && d.compare.key) || '';
    const visits = d.visits || [];
    if (!visits.length) {
        $('#popVisits').html('<div class="muted" style="padding:18px;text-align:center;">ไม่มีประวัติ visit</div>');
        return;
    }
    let html = '<table class="visit-table"><thead><tr>'
        + '<th></th><th>วันที่</th><th>ประเภท</th><th>ห้องตรวจ</th><th>แพทย์</th><th>ยา</th>'
        + '</tr></thead><tbody>';
    visits.forEach(v => {
        const n = Number(v.drug_count || 0);
        const cls = (v.key === curKey ? ' current' : '') + (v.key === cmpKey ? ' compare' : '') + (n ? '' : ' no-drug');
        html += '<tr class="visit-row' + cls + '" data-vn="' + esc(v.vn) + '" data-an="' + esc(v.an) + '" data-type="' + esc(v.type) + '" data-date="' + esc(v.vstdate) + '" title="คลิกเพื่อเทียบ visit นี้ · ดับเบิลคลิกเพื่อเปิดเป็น visit ปัจจุบัน">'
            + '<td><input type="radio" name="popVisit" ' + (v.key === cmpKey ? 'checked' : '') + '></td>'
            + '<td class="visit-date">' + esc(v.vstdate_be || '') + '</td>'
            + '<td class="visit-type">' + esc(v.type || '') + '</td>'
            + '<td class="visit-room">' + esc(v.room_name || '') + '</td>'
            + '<td class="visit-doc" title="' + esc(v.doctor_name || '') + '">' + esc(v.doctor_name || '-') + '</td>'
            + '<td class="visit-drug"><span class="n' + (n ? '' : ' zero') + '">' + n + '</span></td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    $('#popVisits').html(html);
}

function renderLabs(d) {
    const rows = d.labs || [];
    if (!rows.length) {
        $('#popLabBody').html('<tr><td colspan="4" class="muted" style="text-align:center;padding:18px;">ไม่มีผล LAB ใน visit นี้</td></tr>');
        return;
    }
    let html = '';
    rows.forEach(r => {
        const diff = r.cur_result && r.cmp_result && r.cur_result !== r.cmp_result;
        html += '<tr>'
            + '<td>' + esc(r.name || r.code) + '</td>'
            + '<td' + (diff ? ' style="font-weight:800;color:#0b7285;"' : '') + '>' + esc(r.cur_result || '') + '</td>'
            + '<td>' + esc(r.cmp_result || '') + '</td>'
            + '<td>' + esc(r.report_date_be || '') + '</td>'
            + '</tr>';
    });
    $('#popLabBody').html(html);
}

function renderCost(d) {
    const c = d.cost || {};
    const appts = d.appointments || [];
    let html = '<div class="cost-split"><div class="cost-box">'
        + '<div class="cost-row"><span>รวม :</span><span class="cost-val cost-total">' + money(c.total) + '</span></div>'
        + '<div class="cost-row"><span>ED :</span><span class="cost-val cost-ed">' + money(c.ed) + '</span></div>'
        + '<div class="cost-row"><span>NEG :</span><span class="cost-val cost-neg">' + money(c.neg) + '</span></div>'
        + '<div class="cost-row"><span>ส่วนลด :</span><span class="cost-val cost-disc">' + money(c.discount) + '</span></div>'
        + '<div class="cost-row"><span>เบิกได้ :</span><span class="cost-val cost-claim">' + money(c.claim) + '</span></div>'
        + '</div><div class="px-2 pb-2 pt-1"><div class="fw-bold mb-1" style="font-size:12px;">รายการนัดหมาย</div>'
        + '<table class="pop-table"><thead><tr><th>วันที่นัดรับยา</th><th>สถานะ</th></tr></thead><tbody>';
    if (!appts.length) {
        html += '<tr><td colspan="2"><div class="appt-empty"><i class="fas fa-shopping-bag fa-lg d-block mb-1"></i>ไม่มีข้อมูล</div></td></tr>';
    } else {
        appts.forEach(a => {
            html += '<tr><td>' + esc(a.nextdate_be || '') + (a.nexttime ? ' ' + esc(a.nexttime) : '') + '</td>'
                + '<td>' + esc(a.clinic_name || 'นัดแล้ว') + '</td></tr>';
        });
    }
    html += '</tbody></table></div></div>';
    $('#popCostAppt').html(html);
}

function showPopAlert(msg) {
    $('#popAlertMsg').text(msg || 'ไม่เชื่อมต่อ HAPYsure ยังไม่สามารถใช้งานได้');
    $('#popAlert').css('display', 'flex');
}

function syncScreenBtn(d) {
    const hasVisit = !!(d && d.patient && (d.current || d.patient.hn));
    $('#btnScreen')
        .prop('disabled', !hasVisit)
        .attr('title', hasVisit ? 'ยืนยันการคัดกรอง (HAPYsure)' : 'ค้นหาผู้ป่วยก่อน');
    $('#btnQtySave')
        .prop('disabled', !hasVisit)
        .attr('title', hasVisit ? 'บันทึกจำนวนยาลง HOSxP' : 'ค้นหาผู้ป่วยก่อน')
        .text('บันทึกจำนวนยา')
        .toggleClass('dirty', false);
}

function renderHosxpNotes(notes) {
    const body = document.getElementById('popHosxpNotesBody');
    if (!body) return;
    if (!notes || !notes.length) {
        body.innerHTML = '<div class="pop-note-empty">ไม่มีบันทึกจากระบบ HOSxP</div>';
        return;
    }
    let html = '<table class="pop-note-table"><thead><tr>'
        + '<th>ข้อความ</th><th>ผู้บันทึกรายการ</th><th>วันที่บันทึก<br>รายการ</th><th>มีรายการหมดอายุ</th>'
        + '</tr></thead><tbody>';
    notes.forEach(function (n) {
        const staff = esc(n.staff || '') + (n.staff_name ? '<br><small>' + esc(n.staff_name) + '</small>' : '');
        html += '<tr>'
            + '<td class="pop-note-text">' + esc(n.text || '') + '</td>'
            + '<td class="pop-note-staff">' + staff + '</td>'
            + '<td class="pop-note-date">' + esc(n.note_date_be || '') + '</td>'
            + '<td class="pop-note-exp">' + esc(n.expire_date_be || (n.has_expired ? 'หมดอายุ' : '')) + '</td>'
            + '</tr>';
    });
    html += '</tbody></table>';
    body.innerHTML = html;
}

function openHosxpNotes() {
    if (!STATE) return;
    renderHosxpNotes(STATE.hosxp_notes || []);
    $('#popHosxpNotes').css('display', 'flex');
}

function renderAll(d) {
    renderLeft(d);
    renderDrugs(d);
    renderVisits(d);
    renderLabs(d);
    renderCost(d);
    syncScreenBtn(d);
    const notes = d.hosxp_notes || [];
    const hnKey = (d.patient && (d.patient.hn_display || d.patient.hn)) || '';
    if (notes.length && hnKey && hnKey !== lastNoteHn) {
        lastNoteHn = hnKey;
        openHosxpNotes();
    }
}

$('#popForm').on('submit', function (e) {
    e.preventDefault();
    loadPatient({ hn: $('#popHn').val() });
});
$('#popAlertOk').on('click', function () {
    $('#popAlert').hide();
});
$('#popAlert').on('click', function (e) {
    if (e.target === this) $('#popAlert').hide();
});
$(document).on('click', '#btnHosxpNotes', function (e) {
    e.preventDefault();
    openHosxpNotes();
});
$('#popHosxpNotesX').on('click', function () {
    $('#popHosxpNotes').hide();
});
$('#popHosxpNotes').on('click', function (e) {
    if (e.target === this) $('#popHosxpNotes').hide();
});
function openHapyWindow(url) {
    if (!url) return;
    const w = window.open(url, 'hapysure_cpoe');
    if (!w) {
        window.location.href = url;
    }
}

function launchHapyFrom(data) {
    if (data.has_credentials && data.sso_url) {
        openHapyWindow(data.sso_url);
        return;
    }
    $('#hapyUser').val(data.suggest_user || '');
    $('#hapyPass').val('');
    $('#popHapyLogin').data('launch', data).css('display', 'flex');
    setTimeout(function () { $('#hapyPass').trigger('focus'); }, 50);
}

$('#hapyLoginCancel').on('click', function () {
    $('#popHapyLogin').hide();
});
$('#hapyLoginOk').on('click', function () {
    const data = $('#popHapyLogin').data('launch') || {};
    const user = ($('#hapyUser').val() || '').trim();
    const pass = $('#hapyPass').val() || '';
    if (!user || !pass) {
        showPopAlert('กรุณากรอก user และ password ของ HAPYsure');
        return;
    }
    const body = new URLSearchParams();
    body.set('action', 'hapysure_bind');
    body.set('username', user);
    body.set('password', pass);
    fetch('fetch_patient_opd_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: body.toString()
    })
        .then(r => r.json())
        .then(res => {
            if (!res || !res.ok) {
                showPopAlert((res && res.error) ? res.error : 'บันทึกบัญชีไม่สำเร็จ');
                return;
            }
            $('#popHapyLogin').hide();
            openHapyWindow(data.sso_url || data.launch_url);
        })
        .catch(() => {
            showPopAlert('บันทึกบัญชีไม่สำเร็จ');
        });
});
$('#hapyPass').on('keydown', function (e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        $('#hapyLoginOk').trigger('click');
    }
});
$('#popDrugBody').on('input change', '.pop-qty-inp', function () {
    const $i = $(this);
    const now = String($i.val()).trim();
    const orig = String($i.data('orig'));
    $i.toggleClass('dirty', now !== orig);
    const q = Number(now);
    const unit = Number($i.data('unit') || 0);
    const $tr = $i.closest('tr');
    if (isFinite(q) && q >= 0) {
        $tr.find('.pop-remain').text(String(q));
        $tr.find('.pop-price').text((q * (isFinite(unit) ? unit : 0)).toFixed(2));
    }
    $('#btnQtySave').toggleClass('dirty', $('#popDrugBody .pop-qty-inp.dirty').length > 0);
});
$('#popDrugBody').on('keydown', '.pop-qty-inp', function (e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        $('#btnQtySave').trigger('click');
    }
});
function collectQtyEdits() {
    const items = [];
    $('#popDrugBody .pop-qty-inp').each(function () {
        const $i = $(this);
        const now = String($i.val()).trim();
        const orig = String($i.data('orig'));
        if (now === orig) return;
        items.push({
            hos_guid: String($i.attr('data-guid') || ''),
            icode: String($i.attr('data-icode') || ''),
            qty: now
        });
    });
    return items;
}
$('#btnQtySave').on('click', function () {
    const $b = $(this);
    if ($b.prop('disabled')) return;
    if (!STATE || !STATE.patient || !STATE.current) {
        showPopAlert('กรุณาค้นหาผู้ป่วยก่อน');
        return;
    }
    const items = collectQtyEdits();
    if (!items.length) {
        showPopAlert('ยังไม่ได้เปลี่ยนจำนวนยา');
        return;
    }
    $b.prop('disabled', true).text('กำลังบันทึก...');
    fetch('fetch_patient_opd_api.php?action=save_qty', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify({
            hn: STATE.patient.hn_display || STATE.patient.hn || '',
            vn: STATE.current.vn || '',
            items: items
        })
    })
        .then(r => r.json())
        .then(res => {
            if (!res || !res.ok) {
                showPopAlert((res && res.error) ? res.error : 'บันทึกจำนวนยาไม่สำเร็จ');
                $b.prop('disabled', false).text('บันทึกจำนวนยา');
                return;
            }
            const cur = STATE.current || {};
            const cmp = STATE.compare || {};
            loadPatient({
                hn: STATE.patient.hn,
                vn: cur.vn,
                an: cur.an,
                vstdate: cur.vstdate,
                compare_vn: cmp.vn || '',
                compare_an: cmp.an || ''
            });
        })
        .catch(() => {
            showPopAlert('บันทึกจำนวนยาไม่สำเร็จ');
            $b.prop('disabled', false).text('บันทึกจำนวนยา');
        });
});
$('#btnScreen').on('click', function () {
    const $b = $(this);
    if ($b.prop('disabled')) return;
    if (collectQtyEdits().length && !confirm('มีการแก้จำนวนยาที่ยังไม่บันทึก ต้องการไป HAPYsure โดยไม่บันทึกหรือไม่?')) {
        return;
    }
    const p = (STATE && STATE.patient) || {};
    const cur = (STATE && STATE.current) || {};
    const qs = new URLSearchParams();
    qs.set('action', 'hapysure_launch');
    qs.set('hn', p.hn_display || p.hn || $('#popHn').val() || '');
    if (cur.vn) qs.set('vn', cur.vn);
    if (cur.vstdate) qs.set('vstdate', cur.vstdate);
    $b.prop('disabled', true);
    fetch('fetch_patient_opd_api.php?' + qs.toString())
        .then(r => r.json())
        .then(data => {
            $b.prop('disabled', false);
            if (!data || !data.ok || !data.connected || !data.launch_url) {
                showPopAlert((data && data.error) ? data.error : 'ไม่เชื่อมต่อ HAPYsure ยังไม่สามารถใช้งานได้');
                return;
            }
            launchHapyFrom(data);
        })
        .catch(() => {
            $b.prop('disabled', false);
            showPopAlert('ไม่เชื่อมต่อ HAPYsure ยังไม่สามารถใช้งานได้');
        });
});
let visitClickTimer = null;
$(document).on('click', '.visit-row', function () {
    const vn = $(this).data('vn') || '';
    const an = $(this).data('an') || '';
    const type = $(this).data('type') || '';
    const cur = (STATE && STATE.current) ? STATE.current : {};
    clearTimeout(visitClickTimer);
    visitClickTimer = setTimeout(function () {
        loadPatient({
            hn: $('#popHn').val(),
            vn: cur.vn || '',
            an: cur.an || '',
            vstdate: cur.vstdate || '',
            compare_vn: vn,
            compare_an: type === 'I' ? an : ''
        });
    }, 280);
});
$(document).on('dblclick', '.visit-row', function () {
    clearTimeout(visitClickTimer);
    const vn = $(this).data('vn') || '';
    const an = $(this).data('an') || '';
    const type = $(this).data('type') || '';
    const date = $(this).data('date') || '';
    loadPatient({
        hn: $('#popHn').val(),
        vn: vn,
        an: type === 'I' ? an : '',
        vstdate: date
    });
});
$(function () {
    if (PREFILL.hn) {
        loadPatient({
            hn: PREFILL.hn,
            vn: PREFILL.vn,
            vstdate: PREFILL.vstdate,
            compare_vn: PREFILL.compare_vn,
            compare_an: PREFILL.compare_an
        });
    }
});
</script>
</body>
</html>
