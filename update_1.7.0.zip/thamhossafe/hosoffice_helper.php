<?php
/**
 * เชื่อมต่อฐานข้อมูล HOSoffice แบบอ่านอย่างเดียว (Read Only)
 */

function hosoffice_config_keys() {
    return ['ho_host', 'ho_port', 'ho_user', 'ho_pass', 'ho_db', 'ho_readonly'];
}

function hosoffice_default_config() {
    return [
        'ho_host' => '192.168.2.222',
        'ho_port' => '3306',
        'ho_user' => 'web',
        'ho_pass' => 'scph27',
        'ho_db' => 'hosoffice',
        'ho_readonly' => '1',
    ];
}

function hosoffice_upsert_config($con, $key, $value) {
    $k = mysqli_real_escape_string($con, $key);
    $v = mysqli_real_escape_string($con, (string)$value);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$k'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
}

function hosoffice_ensure_config($con) {
    $defaults = hosoffice_default_config();
    foreach ($defaults as $key => $value) {
        $k = mysqli_real_escape_string($con, $key);
        $chk = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name='$k' LIMIT 1");
        if (!$chk || mysqli_num_rows($chk) === 0) {
            hosoffice_upsert_config($con, $key, $value);
            continue;
        }
        if ($key === 'ho_readonly') {
            hosoffice_upsert_config($con, $key, '1');
        }
    }
}

function hosoffice_load_config($con) {
    hosoffice_ensure_config($con);
    $cfg = hosoffice_default_config();
    $keys = "'" . implode("','", array_map(function ($k) use ($con) {
        return mysqli_real_escape_string($con, $k);
    }, hosoffice_config_keys())) . "'";
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ($keys)");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cfg[$r['config_name']] = (string)$r['config_value'];
        }
    }
    $cfg['ho_readonly'] = '1';
    $port = (int)($cfg['ho_port'] ?? 3306);
    $cfg['ho_port'] = (string)($port > 0 ? $port : 3306);
    return $cfg;
}

function hosoffice_save_config($con, array $input) {
    $cur = hosoffice_load_config($con);
    $next = $cur;
    foreach (['ho_host', 'ho_port', 'ho_user', 'ho_db'] as $key) {
        if (array_key_exists($key, $input)) {
            $next[$key] = trim((string)$input[$key]);
        }
    }
    if (isset($input['ho_pass'])) {
        $pass = (string)$input['ho_pass'];
        if ($pass !== '' && $pass !== '********') {
            $next['ho_pass'] = $pass;
        }
    }
    $port = (int)$next['ho_port'];
    $next['ho_port'] = (string)($port > 0 ? $port : 3306);
    $next['ho_readonly'] = '1';
    foreach (hosoffice_config_keys() as $key) {
        hosoffice_upsert_config($con, $key, $next[$key] ?? '');
    }
    return hosoffice_load_config($con);
}

function hosoffice_public_config(array $cfg) {
    $out = $cfg;
    $out['ho_pass'] = ($cfg['ho_pass'] ?? '') !== '' ? '********' : '';
    $out['ho_readonly'] = '1';
    return $out;
}

function hosoffice_is_readonly_sql($sql) {
    $sql = trim((string)$sql);
    if ($sql === '') {
        return false;
    }
    $sql = preg_replace('/^\s*\/\*.*?\*\//s', '', $sql);
    $sql = preg_replace('/^\s*--[^\n]*\n/', '', $sql);
    $sql = ltrim($sql);
    if (!preg_match('/^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN|WITH)\b/i', $sql)) {
        return false;
    }
    if (preg_match('/\b(INSERT|UPDATE|DELETE|REPLACE|ALTER|DROP|CREATE|TRUNCATE|GRANT|REVOKE|LOAD\s+DATA|INTO\s+OUTFILE|INTO\s+DUMPFILE|FOR\s+UPDATE)\b/i', $sql)) {
        return false;
    }
    return true;
}

function hosoffice_ident($name) {
    $name = trim((string)$name);
    if ($name === '' || !preg_match('/^[A-Za-z0-9_]+$/', $name)) {
        return null;
    }
    return '`' . $name . '`';
}

function hosoffice_apply_readonly($ho) {
    if (!$ho) {
        return;
    }
    @mysqli_query($ho, 'SET SESSION TRANSACTION READ ONLY');
}

function hosoffice_connect($con, $read_timeout = 30, array $override = null) {
    if (is_file(__DIR__ . '/integrations_hub_helper.php')) {
        require_once __DIR__ . '/integrations_hub_helper.php';
        if (function_exists('ih_is_enabled') && !ih_is_enabled($con, 'hosoffice')) {
            return null;
        }
    }
    $cfg = $override ? array_merge(hosoffice_load_config($con), $override) : hosoffice_load_config($con);
    $host = trim((string)($cfg['ho_host'] ?? ''));
    $user = trim((string)($cfg['ho_user'] ?? ''));
    $pass = (string)($cfg['ho_pass'] ?? '');
    $db = trim((string)($cfg['ho_db'] ?? ''));
    $port = (int)($cfg['ho_port'] ?? 3306);
    if ($host === '' || $user === '' || $db === '') {
        return null;
    }
    if ($port <= 0) {
        $port = 3306;
    }
    mysqli_report(MYSQLI_REPORT_OFF);
    $c = mysqli_init();
    if (!$c) {
        return null;
    }
    $read_timeout = max(8, min(120, (int)$read_timeout));
    mysqli_options($c, MYSQLI_OPT_CONNECT_TIMEOUT, 8);
    if (defined('MYSQLI_OPT_READ_TIMEOUT')) {
        mysqli_options($c, MYSQLI_OPT_READ_TIMEOUT, $read_timeout);
    }
    $ok = @mysqli_real_connect($c, $host, $user, $pass, $db, $port);
    if (!$ok) {
        return null;
    }
    mysqli_set_charset($c, 'utf8mb4');
    hosoffice_apply_readonly($c);
    return $c;
}

function hosoffice_query($ho, $sql) {
    if (!$ho || !hosoffice_is_readonly_sql($sql)) {
        return false;
    }
    return @mysqli_query($ho, $sql);
}

function hosoffice_close($ho) {
    if (!$ho) {
        return;
    }
    try {
        @mysqli_close($ho);
    } catch (Throwable $e) {
        // ignore
    }
}

function hosoffice_is_sensitive_column($name, $type = '') {
    $n = strtolower((string)$name);
    $t = strtolower((string)$type);
    if (strpos($t, 'blob') !== false || strpos($t, 'binary') !== false) {
        return true;
    }
    $needles = [
        'password', 'passwd', 'pass_hash', 'hash', 'token', 'secret', 'otp',
        'cid', 'salary', 'fingle', 'finger', 'licen', 'webhook',
        'bank_number', 'book_bank_number', 'hr_password',
    ];
    foreach ($needles as $w) {
        if (strpos($n, $w) !== false) {
            return true;
        }
    }
    return false;
}

function hosoffice_table_count($ho) {
    $q = hosoffice_query($ho, 'SHOW TABLES');
    if (!$q) {
        return 0;
    }
    return (int)mysqli_num_rows($q);
}

function hosoffice_safe_count($ho, $table) {
    $ident = hosoffice_ident($table);
    if (!$ident) {
        return null;
    }
    $q = hosoffice_query($ho, "SELECT COUNT(*) AS c FROM $ident");
    if (!$q) {
        return null;
    }
    $r = mysqli_fetch_assoc($q);
    return isset($r['c']) ? (int)$r['c'] : null;
}

function hosoffice_ping($con, array $override = null) {
    $t0 = microtime(true);
    $cfg = $override ? array_merge(hosoffice_load_config($con), $override) : hosoffice_load_config($con);
    $host = trim((string)($cfg['ho_host'] ?? ''));
    $out = [
        'ok' => false,
        'ms' => 0,
        'host' => $host,
        'port' => (int)($cfg['ho_port'] ?? 3306),
        'db' => (string)($cfg['ho_db'] ?? ''),
        'user' => (string)($cfg['ho_user'] ?? ''),
        'readonly' => true,
        'version' => '',
        'table_count' => 0,
        'stats' => [],
        'error' => '',
        'write_blocked' => true,
    ];
    $ho = hosoffice_connect($con, 12, $override);
    $out['ms'] = round((microtime(true) - $t0) * 1000, 1);
    if (!$ho) {
        $out['error'] = mysqli_connect_error() ?: 'เชื่อมต่อ HOSoffice ไม่ได้';
        return $out;
    }
    $info = hosoffice_query($ho, 'SELECT @@session.transaction_read_only AS ro, DATABASE() AS db, VERSION() AS ver');
    if ($info) {
        $r = mysqli_fetch_assoc($info);
        $out['version'] = (string)($r['ver'] ?? '');
        $out['db'] = (string)($r['db'] ?? $out['db']);
        $out['readonly'] = ((string)($r['ro'] ?? '1')) === '1';
    }
    $out['table_count'] = hosoffice_table_count($ho);
    $stats = [];
    foreach (['hr_person' => 'บุคลากร', 'hr_department' => 'หน่วยงาน', 'hr_position' => 'ตำแหน่ง'] as $table => $label) {
        $n = hosoffice_safe_count($ho, $table);
        if ($n !== null) {
            $stats[] = ['table' => $table, 'label' => $label, 'count' => $n];
        }
    }
    $out['stats'] = $stats;
    $probe = @mysqli_query($ho, 'UPDATE hr_person SET ID=ID WHERE 1=0');
    $out['write_blocked'] = !$probe;
    $out['ok'] = true;
    hosoffice_close($ho);
    return $out;
}

function hosoffice_list_tables($ho, $q = '', $limit = 80) {
    $limit = max(1, min(200, (int)$limit));
    $res = hosoffice_query($ho, 'SHOW TABLES');
    if (!$res) {
        return [];
    }
    $q = trim(mb_strtolower($q, 'UTF-8'));
    $preferred = ['hr_person', 'hr_department', 'hr_position', 'hr_depart', 'hr_status'];
    $tables = [];
    $rest = [];
    while ($row = mysqli_fetch_row($res)) {
        $name = (string)($row[0] ?? '');
        if ($name === '') {
            continue;
        }
        if ($q !== '' && mb_strpos(mb_strtolower($name, 'UTF-8'), $q) === false) {
            continue;
        }
        if (in_array($name, $preferred, true)) {
            $tables[] = $name;
        } else {
            $rest[] = $name;
        }
    }
    $tables = array_merge($tables, $rest);
    return array_slice($tables, 0, $limit);
}

function hosoffice_describe_table($ho, $table) {
    $ident = hosoffice_ident($table);
    if (!$ident) {
        return [];
    }
    $q = hosoffice_query($ho, "SHOW COLUMNS FROM $ident");
    if (!$q) {
        return [];
    }
    $cols = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $name = (string)($r['Field'] ?? '');
        $type = (string)($r['Type'] ?? '');
        $cols[] = [
            'name' => $name,
            'type' => $type,
            'null' => (string)($r['Null'] ?? ''),
            'key' => (string)($r['Key'] ?? ''),
            'sensitive' => hosoffice_is_sensitive_column($name, $type),
        ];
    }
    return $cols;
}

function hosoffice_preview_table($ho, $table, $limit = 20) {
    $ident = hosoffice_ident($table);
    if (!$ident) {
        return ['columns' => [], 'rows' => [], 'error' => 'ชื่อตารางไม่ถูกต้อง'];
    }
    $cols = hosoffice_describe_table($ho, $table);
    if (empty($cols)) {
        return ['columns' => [], 'rows' => [], 'error' => 'ไม่พบตารางนี้ หรืออ่านโครงสร้างไม่ได้'];
    }
    $select = [];
    $headers = [];
    foreach ($cols as $c) {
        if (!empty($c['sensitive'])) {
            continue;
        }
        $colIdent = hosoffice_ident($c['name']);
        if (!$colIdent) {
            continue;
        }
        $select[] = $colIdent;
        $headers[] = $c['name'];
        if (count($select) >= 12) {
            break;
        }
    }
    if (empty($select)) {
        return ['columns' => [], 'rows' => [], 'error' => 'คอลัมน์ที่แสดงได้ถูกซ่อนเพราะเป็นข้อมูลอ่อนไหว'];
    }
    $limit = max(1, min(50, (int)$limit));
    $sql = 'SELECT ' . implode(', ', $select) . " FROM $ident LIMIT $limit";
    $q = hosoffice_query($ho, $sql);
    if (!$q) {
        return ['columns' => $headers, 'rows' => [], 'error' => 'อ่านข้อมูลไม่ได้'];
    }
    $rows = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $row = [];
        foreach ($headers as $h) {
            $v = $r[$h] ?? '';
            if (is_string($v) && strlen($v) > 180) {
                $v = substr($v, 0, 180) . '…';
            }
            $row[$h] = $v;
        }
        $rows[] = $row;
    }
    return ['columns' => $headers, 'rows' => $rows, 'error' => ''];
}
