<?php
/**
 * ตั้งค่าปกปิดการแสดงผล Lab / ยา (Smart Lab, Smart Drug)
 * scope: all | network | pcc
 */

function dm_mask_message() {
    return 'กรุณาติดต่อ รพ.ต้นสังกัด';
}

function dm_scopes() {
    return [
        'all' => 'ปกปิดทั้งหมด',
        'network' => 'ฐานข้อมูลรพ.เครือข่าย',
        'pcc' => 'PCC (JHCIS)',
    ];
}

function dm_ensure_tables($con) {
    static $done = false;
    if ($done || !$con) {
        return (bool)$done;
    }
    $ok = mysqli_query($con, "CREATE TABLE IF NOT EXISTS display_mask_rules (
        id INT NOT NULL AUTO_INCREMENT,
        item_type ENUM('lab','drug') NOT NULL,
        match_value VARCHAR(255) NOT NULL DEFAULT '',
        match_label VARCHAR(255) NOT NULL DEFAULT '',
        scope ENUM('all','network','pcc') NOT NULL DEFAULT 'all',
        enabled TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_type_value_scope (item_type, match_value, scope),
        KEY idx_type_enabled (item_type, enabled)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!$ok) {
        return false;
    }
    $done = true;

    // ค่าเริ่มต้น: ปกปิด Lab ที่มีคำว่า HIV ทุกแหล่งข้อมูล
    $chk = mysqli_query($con, "SELECT id FROM display_mask_rules
        WHERE item_type='lab' AND match_value='HIV' AND scope='all' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) === 0) {
        mysqli_query($con, "INSERT INTO display_mask_rules (item_type, match_value, match_label, scope, enabled)
            VALUES ('lab', 'HIV', 'Anti HIV / HIV related lab', 'all', 1)");
    }
    return true;
}

function dm_normalize_match($value, $type = 'lab') {
    $v = trim((string)$value);
    if ($type === 'drug') {
        $v = preg_replace('/\s+/', '', $v);
        return $v;
    }
    $v = preg_replace('/\s+/u', ' ', $v);
    return $v;
}

function dm_source_bucket($hospital_code) {
    $code = strtolower(trim((string)$hospital_code));
    if ($code === '' || $code === 'local') {
        return 'local';
    }
    if ($code === 'jhcis' || $code === 'pcc' || strpos($code, 'jhcis') === 0) {
        return 'pcc';
    }
    return 'network';
}

function dm_scope_applies($scope, $bucket) {
    $scope = strtolower(trim((string)$scope));
    if ($scope === 'all') {
        return true;
    }
    if ($scope === 'network') {
        return $bucket === 'network';
    }
    if ($scope === 'pcc') {
        return $bucket === 'pcc';
    }
    return false;
}

function dm_get_rules($con, $item_type = null, $enabled_only = false) {
    dm_ensure_tables($con);
    $sql = "SELECT id, item_type, match_value, match_label, scope, enabled,
                   created_at, updated_at
            FROM display_mask_rules WHERE 1=1";
    if ($item_type === 'lab' || $item_type === 'drug') {
        $t = mysqli_real_escape_string($con, $item_type);
        $sql .= " AND item_type='$t'";
    }
    if ($enabled_only) {
        $sql .= " AND enabled=1";
    }
    $sql .= " ORDER BY item_type ASC, match_value ASC, scope ASC, id ASC";
    $rows = [];
    $q = mysqli_query($con, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'id' => (int)$r['id'],
                'item_type' => (string)$r['item_type'],
                'match_value' => (string)$r['match_value'],
                'match_label' => (string)$r['match_label'],
                'scope' => (string)$r['scope'],
                'enabled' => (int)$r['enabled'] === 1,
                'created_at' => (string)($r['created_at'] ?? ''),
                'updated_at' => (string)($r['updated_at'] ?? ''),
            ];
        }
    }
    return $rows;
}

function dm_rules_cache($con, $item_type) {
    static $cache = [];
    $key = (string)$item_type;
    if (!isset($cache[$key])) {
        $cache[$key] = dm_get_rules($con, $item_type, true);
    }
    return $cache[$key];
}

function dm_should_mask_lab($con, $lab_name, $hospital_code = 'local') {
    $name = function_exists('mb_strtolower')
        ? mb_strtolower(trim((string)$lab_name), 'UTF-8')
        : strtolower(trim((string)$lab_name));
    if ($name === '') {
        return false;
    }
    $bucket = dm_source_bucket($hospital_code);
    foreach (dm_rules_cache($con, 'lab') as $rule) {
        if (!dm_scope_applies($rule['scope'], $bucket)) {
            continue;
        }
        $kw = function_exists('mb_strtolower')
            ? mb_strtolower(trim((string)$rule['match_value']), 'UTF-8')
            : strtolower(trim((string)$rule['match_value']));
        if ($kw === '') {
            continue;
        }
        if (function_exists('mb_strpos')) {
            if (mb_strpos($name, $kw) !== false) {
                return true;
            }
        } elseif (strpos($name, $kw) !== false) {
            return true;
        }
    }
    return false;
}

function dm_should_mask_drug($con, $tpu_code, $hospital_code = 'local') {
    $code = dm_normalize_match($tpu_code, 'drug');
    if ($code === '') {
        return false;
    }
    $bucket = dm_source_bucket($hospital_code);
    foreach (dm_rules_cache($con, 'drug') as $rule) {
        if (!dm_scope_applies($rule['scope'], $bucket)) {
            continue;
        }
        $want = dm_normalize_match($rule['match_value'], 'drug');
        if ($want !== '' && strcasecmp($want, $code) === 0) {
            return true;
        }
    }
    return false;
}

function dm_apply_lab_result($con, $lab_name, $result, $hospital_code = 'local') {
    if (dm_should_mask_lab($con, $lab_name, $hospital_code)) {
        return dm_mask_message();
    }
    return $result;
}

function dm_mask_drug_row(array &$row, $con = null) {
    $msg = dm_mask_message();
    $row['is_masked'] = true;
    $row['drug_name'] = $msg;
    $row['drug_name_local'] = $msg;
    $row['method'] = '';
    $row['usage_display'] = $msg;
    $row['strength'] = '';
    $row['strength_local'] = '';
    $row['units'] = '';
    $row['tpu_code'] = '';
    $row['icode'] = '****';
    $row['qty'] = null;
    $row['pill_qty'] = null;
    $row['mg_dose'] = null;
    $row['mg_dose_max'] = null;
    $row['numeric_mg_value'] = null;
    if ($con) {
        // no-op; kept for call-site consistency
    }
    return $row;
}

function dm_apply_drug_history($con, array $history) {
    if (!$history) {
        return $history;
    }
    $rules = dm_rules_cache($con, 'drug');
    if (!$rules) {
        return $history;
    }
    foreach ($history as &$row) {
        if (!is_array($row)) {
            continue;
        }
        $tpu = trim((string)($row['tpu_code'] ?? ''));
        $hosp = (string)($row['hospital_code'] ?? 'local');
        if ($tpu !== '' && dm_should_mask_drug($con, $tpu, $hosp)) {
            dm_mask_drug_row($row);
        }
    }
    unset($row);
    return $history;
}

function dm_add_rule($con, array $in) {
    dm_ensure_tables($con);
    $type = strtolower(trim((string)($in['item_type'] ?? '')));
    if ($type !== 'lab' && $type !== 'drug') {
        return ['ok' => false, 'message' => 'ประเภทไม่ถูกต้อง'];
    }
    $value = dm_normalize_match($in['match_value'] ?? '', $type);
    if ($value === '') {
        return ['ok' => false, 'message' => $type === 'drug' ? 'กรุณาระบุรหัส TMT (tpu_code)' : 'กรุณาระบุคำค้น Lab'];
    }
    if ($type === 'lab' && function_exists('mb_strlen') && mb_strlen($value) < 2) {
        return ['ok' => false, 'message' => 'คำค้น Lab ต้องมีอย่างน้อย 2 ตัวอักษร'];
    }
    if ($type === 'lab' && !function_exists('mb_strlen') && strlen($value) < 2) {
        return ['ok' => false, 'message' => 'คำค้น Lab ต้องมีอย่างน้อย 2 ตัวอักษร'];
    }
    $label = trim((string)($in['match_label'] ?? ''));
    $scope = strtolower(trim((string)($in['scope'] ?? 'all')));
    if (!isset(dm_scopes()[$scope])) {
        $scope = 'all';
    }
    $enabled = !isset($in['enabled']) || $in['enabled'] === true || $in['enabled'] === 1 || $in['enabled'] === '1' ? 1 : 0;

    $esc = function ($v) use ($con) {
        return mysqli_real_escape_string($con, (string)$v);
    };
    $sql = "INSERT INTO display_mask_rules (item_type, match_value, match_label, scope, enabled)
            VALUES ('{$esc($type)}', '{$esc($value)}', '{$esc($label)}', '{$esc($scope)}', $enabled)
            ON DUPLICATE KEY UPDATE
                match_label=IF(VALUES(match_label)<>'', VALUES(match_label), match_label),
                enabled=VALUES(enabled),
                updated_at=NOW()";
    $ok = mysqli_query($con, $sql);
    return ['ok' => (bool)$ok, 'message' => $ok ? '' : ('บันทึกไม่สำเร็จ: ' . mysqli_error($con))];
}

function dm_update_rule($con, $id, array $in) {
    dm_ensure_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return ['ok' => false, 'message' => 'ไม่พบรายการ'];
    }
    $sets = [];
    if (array_key_exists('enabled', $in)) {
        $en = ($in['enabled'] === true || $in['enabled'] === 1 || $in['enabled'] === '1') ? 1 : 0;
        $sets[] = "enabled=$en";
    }
    if (isset($in['scope'])) {
        $scope = strtolower(trim((string)$in['scope']));
        if (isset(dm_scopes()[$scope])) {
            $sets[] = "scope='" . mysqli_real_escape_string($con, $scope) . "'";
        }
    }
    if (isset($in['match_label'])) {
        $sets[] = "match_label='" . mysqli_real_escape_string($con, trim((string)$in['match_label'])) . "'";
    }
    if (isset($in['match_value'])) {
        $q = mysqli_query($con, "SELECT item_type FROM display_mask_rules WHERE id=$id LIMIT 1");
        $type = ($q && ($r = mysqli_fetch_assoc($q))) ? $r['item_type'] : 'lab';
        $val = dm_normalize_match($in['match_value'], $type);
        if ($val === '') {
            return ['ok' => false, 'message' => 'ค่าที่ตั้งไม่ถูกต้อง'];
        }
        $sets[] = "match_value='" . mysqli_real_escape_string($con, $val) . "'";
    }
    if (!$sets) {
        return ['ok' => false, 'message' => 'ไม่มีข้อมูลที่จะอัปเดต'];
    }
    $sets[] = 'updated_at=NOW()';
    $ok = mysqli_query($con, 'UPDATE display_mask_rules SET ' . implode(', ', $sets) . " WHERE id=$id LIMIT 1");
    return ['ok' => (bool)$ok, 'message' => $ok ? '' : ('อัปเดตไม่สำเร็จ: ' . mysqli_error($con))];
}

function dm_delete_rule($con, $id) {
    dm_ensure_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "DELETE FROM display_mask_rules WHERE id=$id LIMIT 1");
}
