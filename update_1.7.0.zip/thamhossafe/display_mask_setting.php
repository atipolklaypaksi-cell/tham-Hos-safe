<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/display_mask_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.display_mask') && !tham_menu_can('admin.hosxp') && ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: home.php');
    exit;
}

dm_ensure_tables($con);
$scopes = dm_scopes();
$mask_msg = dm_mask_message();
$lab_items = dm_get_rules($con, 'lab');
$drug_items = dm_get_rules($con, 'drug');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตั้งค่าแสดงยา และ Lab - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .dm-hero {
            background: linear-gradient(135deg, #1f4d3b 0%, #0f766e 55%, #0e7490 100%);
            color: #fff; border-radius: 14px; padding: 1.15rem 1.4rem; margin-bottom: 1.1rem;
        }
        .dm-card { border: 0; border-radius: 12px; }
        .dm-scope-all { background: #fee2e2; color: #991b1b; }
        .dm-scope-network { background: #dbeafe; color: #1e40af; }
        .dm-scope-pcc { background: #d1fae5; color: #065f46; }
        .dm-hits { max-height: 220px; overflow: auto; }
        .dm-hits .list-group-item { cursor: pointer; }
        .dm-hits .list-group-item:hover { background: #f0fdfa; }
        .form-check-input:checked { background-color: #0f766e; border-color: #0f766e; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="dm-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="small text-uppercase" style="letter-spacing:.08em;opacity:.75;">ตั้งค่าระบบ · Privacy</div>
                    <h4 class="fw-bold mb-1"><i class="fas fa-eye-slash me-2"></i>ตั้งค่าแสดงยา และ Lab</h4>
                    <p class="mb-0 small" style="opacity:.92;">
                        กำหนดรายการ Lab (ตามคำในชื่อ) และยา (ตามรหัส TMT) ที่จะปกปิดผล/ชื่อ
                        — ข้อความที่แสดง: <b><?php echo htmlspecialchars($mask_msg, ENT_QUOTES, 'UTF-8'); ?></b>
                    </p>
                </div>
                <span class="badge bg-light text-dark px-3 py-2">Admin</span>
            </div>

            <div id="dmAlert" class="alert d-none" role="alert"></div>

            <div class="row g-3">
                <div class="col-lg-6">
                    <div class="card dm-card shadow-sm mb-3">
                        <div class="card-body p-4">
                            <h6 class="fw-bold mb-1"><i class="fas fa-vials me-2 text-info"></i>ปกปิด Lab</h6>
                            <p class="small text-muted mb-3">ถ้าชื่อรายการ Lab มีคำที่ตั้งไว้ จะแสดงข้อความปกปิดแทนผลลัพธ์ (ใช้ใน Smart Lab)</p>
                            <form id="labAddForm" class="row g-2 align-items-end">
                                <div class="col-md-5">
                                    <label class="form-label small fw-bold">คำในชื่อ Lab</label>
                                    <input type="text" class="form-control" id="labKeyword" placeholder="เช่น HIV" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label small fw-bold">ขอบเขต</label>
                                    <select class="form-select" id="labScope">
                                        <?php foreach ($scopes as $sk => $sl): ?>
                                        <option value="<?php echo htmlspecialchars($sk, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($sl, ENT_QUOTES, 'UTF-8'); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-success w-100 fw-bold"><i class="fas fa-plus me-1"></i>เพิ่ม</button>
                                </div>
                                <div class="col-12">
                                    <input type="text" class="form-control form-control-sm" id="labLabel" placeholder="คำอธิบาย (ไม่บังคับ)">
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card dm-card shadow-sm">
                        <div class="card-body p-0">
                            <div class="px-3 py-2 border-bottom fw-bold small text-secondary">รายการ Lab ที่ปกปิด</div>
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>คำค้น</th>
                                            <th>ขอบเขต</th>
                                            <th class="text-center">เปิด</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody id="labTableBody">
                                        <?php if (!$lab_items): ?>
                                        <tr class="dm-empty"><td colspan="4" class="text-center text-muted py-4">ยังไม่มีรายการ</td></tr>
                                        <?php endif; ?>
                                        <?php foreach ($lab_items as $it): ?>
                                        <tr data-id="<?php echo (int)$it['id']; ?>">
                                            <td>
                                                <span class="fw-bold"><?php echo htmlspecialchars($it['match_value'], ENT_QUOTES, 'UTF-8'); ?></span>
                                                <?php if ($it['match_label'] !== ''): ?>
                                                <div class="small text-muted"><?php echo htmlspecialchars($it['match_label'], ENT_QUOTES, 'UTF-8'); ?></div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <select class="form-select form-select-sm dm-scope" data-id="<?php echo (int)$it['id']; ?>">
                                                    <?php foreach ($scopes as $sk => $sl): ?>
                                                    <option value="<?php echo htmlspecialchars($sk, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $it['scope'] === $sk ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($sl, ENT_QUOTES, 'UTF-8'); ?>
                                                    </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td class="text-center">
                                                <div class="form-check form-switch d-inline-block">
                                                    <input class="form-check-input dm-enabled" type="checkbox" data-id="<?php echo (int)$it['id']; ?>" <?php echo $it['enabled'] ? 'checked' : ''; ?>>
                                                </div>
                                            </td>
                                            <td class="text-end">
                                                <button type="button" class="btn btn-sm btn-outline-danger dm-del" data-id="<?php echo (int)$it['id']; ?>" title="ลบ">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="card dm-card shadow-sm mb-3">
                        <div class="card-body p-4">
                            <h6 class="fw-bold mb-1"><i class="fas fa-pills me-2 text-primary"></i>ปกปิดยา (ตาม TMT)</h6>
                            <p class="small text-muted mb-3">ค้นหายาแล้วเพิ่มตามรหัส TMT (tpu_code) — ใช้ปกปิดใน Smart Drug</p>
                            <div class="input-group mb-2">
                                <input type="text" class="form-control" id="drugSearchQ" placeholder="ค้นชื่อยา / icode / TMT" autocomplete="off">
                                <button type="button" class="btn btn-outline-primary fw-bold" id="btnDrugSearch"><i class="fas fa-search me-1"></i>ค้นหา</button>
                            </div>
                            <div class="mb-2">
                                <label class="form-label small fw-bold mb-1">ขอบเขตเมื่อเพิ่ม</label>
                                <select class="form-select form-select-sm" id="drugScope" style="max-width:260px;">
                                    <?php foreach ($scopes as $sk => $sl): ?>
                                    <option value="<?php echo htmlspecialchars($sk, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($sl, ENT_QUOTES, 'UTF-8'); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div id="drugHits" class="list-group dm-hits border rounded mb-0">
                                <div class="list-group-item text-muted small">ค้นหายาแล้วกดเพิ่ม</div>
                            </div>
                        </div>
                    </div>
                    <div class="card dm-card shadow-sm">
                        <div class="card-body p-0">
                            <div class="px-3 py-2 border-bottom fw-bold small text-secondary">รายการยาที่ปกปิด</div>
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>TMT / ชื่อ</th>
                                            <th>ขอบเขต</th>
                                            <th class="text-center">เปิด</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody id="drugTableBody">
                                        <?php if (!$drug_items): ?>
                                        <tr class="dm-empty"><td colspan="4" class="text-center text-muted py-4">ยังไม่มีรายการ</td></tr>
                                        <?php endif; ?>
                                        <?php foreach ($drug_items as $it): ?>
                                        <tr data-id="<?php echo (int)$it['id']; ?>">
                                            <td>
                                                <span class="fw-bold font-monospace"><?php echo htmlspecialchars($it['match_value'], ENT_QUOTES, 'UTF-8'); ?></span>
                                                <?php if ($it['match_label'] !== ''): ?>
                                                <div class="small text-muted"><?php echo htmlspecialchars($it['match_label'], ENT_QUOTES, 'UTF-8'); ?></div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <select class="form-select form-select-sm dm-scope" data-id="<?php echo (int)$it['id']; ?>">
                                                    <?php foreach ($scopes as $sk => $sl): ?>
                                                    <option value="<?php echo htmlspecialchars($sk, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $it['scope'] === $sk ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($sl, ENT_QUOTES, 'UTF-8'); ?>
                                                    </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td class="text-center">
                                                <div class="form-check form-switch d-inline-block">
                                                    <input class="form-check-input dm-enabled" type="checkbox" data-id="<?php echo (int)$it['id']; ?>" <?php echo $it['enabled'] ? 'checked' : ''; ?>>
                                                </div>
                                            </td>
                                            <td class="text-end">
                                                <button type="button" class="btn btn-sm btn-outline-danger dm-del" data-id="<?php echo (int)$it['id']; ?>" title="ลบ">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card dm-card shadow-sm mt-3">
                <div class="card-body small text-muted">
                    <div class="fw-bold text-dark mb-1"><i class="fas fa-info-circle me-1"></i>ขอบเขตการปกปิด</div>
                    <ul class="mb-0 ps-3">
                        <li><b>ปกปิดทั้งหมด</b> — รพ.นี้ + รพ.เครือข่าย + PCC</li>
                        <li><b>ฐานข้อมูลรพ.เครือข่าย</b> — เฉพาะข้อมูลที่ดึงจากรพ.ในเครือข่าย</li>
                        <li><b>PCC</b> — เฉพาะข้อมูลจาก JHCIS PCC (Smart Drug)</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const DM_SCOPES = <?php echo json_encode($scopes, JSON_UNESCAPED_UNICODE); ?>;
let drugHitsCache = [];

function dmAlert(msg, ok) {
    const $a = $('#dmAlert');
    $a.removeClass('d-none alert-success alert-danger')
      .addClass(ok ? 'alert-success' : 'alert-danger')
      .text(msg || (ok ? 'บันทึกแล้ว' : 'เกิดข้อผิดพลาด'));
    if (ok) setTimeout(() => $a.addClass('d-none'), 2200);
}

function dmApi(body) {
    return fetch('fetch_display_mask_api.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(body)
    }).then(r => r.json());
}

function scopeOptions(selected) {
    return Object.keys(DM_SCOPES).map(k =>
        `<option value="${k}" ${k === selected ? 'selected' : ''}>${DM_SCOPES[k]}</option>`
    ).join('');
}

function renderRows(items, type) {
    const $tb = type === 'lab' ? $('#labTableBody') : $('#drugTableBody');
    if (!items || !items.length) {
        $tb.html('<tr class="dm-empty"><td colspan="4" class="text-center text-muted py-4">ยังไม่มีรายการ</td></tr>');
        return;
    }
    let html = '';
    items.forEach(it => {
        const valueHtml = type === 'drug'
            ? `<span class="fw-bold font-monospace">${esc(it.match_value)}</span>`
            : `<span class="fw-bold">${esc(it.match_value)}</span>`;
        const label = it.match_label ? `<div class="small text-muted">${esc(it.match_label)}</div>` : '';
        html += `<tr data-id="${it.id}">
            <td>${valueHtml}${label}</td>
            <td>
                <select class="form-select form-select-sm dm-scope" data-id="${it.id}">${scopeOptions(it.scope)}</select>
            </td>
            <td class="text-center">
                <div class="form-check form-switch d-inline-block">
                    <input class="form-check-input dm-enabled" type="checkbox" data-id="${it.id}" ${it.enabled ? 'checked' : ''}>
                </div>
            </td>
            <td class="text-end">
                <button type="button" class="btn btn-sm btn-outline-danger dm-del" data-id="${it.id}" title="ลบ">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>`;
    });
    $tb.html(html);
}

function applyList(data) {
    renderRows(data.lab_items || [], 'lab');
    renderRows(data.drug_items || [], 'drug');
}

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

$('#labAddForm').on('submit', function (e) {
    e.preventDefault();
    const keyword = $('#labKeyword').val().trim();
    if (!keyword) return;
    dmApi({
        action: 'add',
        item_type: 'lab',
        match_value: keyword,
        match_label: $('#labLabel').val().trim(),
        scope: $('#labScope').val(),
        enabled: 1
    }).then(data => {
        if (data.status !== 'success') {
            dmAlert(data.message || 'เพิ่มไม่สำเร็จ', false);
            return;
        }
        applyList(data);
        $('#labKeyword').val('');
        $('#labLabel').val('');
        dmAlert('เพิ่มรายการ Lab แล้ว', true);
    }).catch(() => dmAlert('เชื่อมต่อไม่สำเร็จ', false));
});

function searchDrug() {
    const q = $('#drugSearchQ').val().trim();
    if (!q) return;
    $('#drugHits').html('<div class="list-group-item text-muted small">กำลังค้นหา…</div>');
    dmApi({action: 'search_drug', q: q}).then(data => {
        if (data.status !== 'success') {
            $('#drugHits').html('<div class="list-group-item text-danger small">' + esc(data.message || 'ค้นหาไม่สำเร็จ') + '</div>');
            return;
        }
        drugHitsCache = data.items || [];
        if (!drugHitsCache.length) {
            $('#drugHits').html('<div class="list-group-item text-muted small">ไม่พบยา</div>');
            return;
        }
        let html = '';
        drugHitsCache.forEach((it, idx) => {
            const tmt = it.name_tmt || it.name_local || '-';
            const local = (it.name_local && it.name_local !== it.name_tmt) ? it.name_local : '';
            const tpu = it.tpu_code || '';
            html += `<button type="button" class="list-group-item list-group-item-action" data-idx="${idx}">
                <div class="fw-bold">${esc(tmt)}</div>
                <div class="small text-muted">TMT ${esc(tpu || '-')} · icode ${esc(it.icode || '-')}${local ? ' · ' + esc(local) : ''}</div>
            </button>`;
        });
        $('#drugHits').html(html);
    }).catch(() => {
        $('#drugHits').html('<div class="list-group-item text-danger small">เชื่อมต่อไม่สำเร็จ</div>');
    });
}

$('#btnDrugSearch').on('click', searchDrug);
$('#drugSearchQ').on('keydown', function (e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        searchDrug();
    }
});

$('#drugHits').on('click', '[data-idx]', function () {
    const it = drugHitsCache[Number($(this).attr('data-idx'))];
    if (!it || !it.tpu_code) {
        dmAlert('รายการนี้ไม่มีรหัส TMT (tpu_code)', false);
        return;
    }
    dmApi({
        action: 'add',
        item_type: 'drug',
        match_value: it.tpu_code,
        match_label: it.name_tmt || it.name_local || '',
        scope: $('#drugScope').val(),
        enabled: 1
    }).then(data => {
        if (data.status !== 'success') {
            dmAlert(data.message || 'เพิ่มไม่สำเร็จ', false);
            return;
        }
        applyList(data);
        dmAlert('เพิ่มรายการยาแล้ว', true);
    }).catch(() => dmAlert('เชื่อมต่อไม่สำเร็จ', false));
});

$(document).on('change', '.dm-enabled', function () {
    const id = Number($(this).attr('data-id'));
    const enabled = $(this).is(':checked') ? 1 : 0;
    dmApi({action: 'update', id: id, enabled: enabled}).then(data => {
        if (data.status !== 'success') {
            dmAlert(data.message || 'อัปเดตไม่สำเร็จ', false);
            $(this).prop('checked', !enabled);
            return;
        }
        dmAlert('อัปเดตแล้ว', true);
    }).catch(() => {
        dmAlert('เชื่อมต่อไม่สำเร็จ', false);
        $(this).prop('checked', !enabled);
    });
});

$(document).on('change', '.dm-scope', function () {
    const id = Number($(this).attr('data-id'));
    const scope = $(this).val();
    dmApi({action: 'update', id: id, scope: scope}).then(data => {
        if (data.status !== 'success') {
            dmAlert(data.message || 'อัปเดตไม่สำเร็จ', false);
            return;
        }
        dmAlert('เปลี่ยนขอบเขตแล้ว', true);
    }).catch(() => dmAlert('เชื่อมต่อไม่สำเร็จ', false));
});

$(document).on('click', '.dm-del', function () {
    const id = Number($(this).attr('data-id'));
    if (!id || !confirm('ลบรายการนี้?')) return;
    dmApi({action: 'delete', id: id}).then(data => {
        if (data.status !== 'success') {
            dmAlert(data.message || 'ลบไม่สำเร็จ', false);
            return;
        }
        applyList(data);
        dmAlert('ลบแล้ว', true);
    }).catch(() => dmAlert('เชื่อมต่อไม่สำเร็จ', false));
});
</script>
</body>
</html>
