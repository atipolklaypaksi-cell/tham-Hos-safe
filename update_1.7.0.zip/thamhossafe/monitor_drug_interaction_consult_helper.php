<?php
/**
 * Monitor Drug Interaction — Consult / ใบปรึกษาแพทย์ + ประวัติ (แบบ Monitor Lab)
 */

function mdi_consult_statuses() {
    return [
        'waiting' => 'รอ Consult',
        'in_progress' => 'รอตอบกลับ',
        'closed' => 'ปิด Consult',
    ];
}

function mdi_consult_normalize_status($status) {
    $s = trim((string)$status);
    if ($s === 'in_progress' || $s === 'progress' || $s === 'consulting') {
        return 'in_progress';
    }
    if ($s === 'closed' || $s === 'done' || $s === 'resolved') {
        return 'closed';
    }
    return 'waiting';
}

function mdi_consult_status_label($status) {
    $map = mdi_consult_statuses();
    $status = mdi_consult_normalize_status($status);
    return $map[$status] ?? $status;
}

function mdi_ensure_tables($con) {
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_drug_interaction_consults.sql');
    if ($sql !== false && trim($sql) !== '') {
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
            if ($stmt === '') {
                continue;
            }
            @mysqli_query($con, $stmt);
        }
    }
    $chk = @mysqli_query($con, "SHOW TABLES LIKE 'monitor_drug_interaction_consults'");
    return $chk && mysqli_num_rows($chk) > 0;
}

function mdi_normalize_reply_wait_days($days) {
    return max(0, min(30, (int)$days));
}

function mdi_get_reply_wait_days($con) {
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='mdi_reply_wait_days' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return mdi_normalize_reply_wait_days($r['config_value']);
    }
    @mysqli_query($con, "INSERT IGNORE INTO sys_config (config_name, config_value) VALUES ('mdi_reply_wait_days', '0')");
    return 0;
}

function mdi_consult_outcome_options() {
    require_once __DIR__ . '/monitor_lab_consult_helper.php';
    return mlc_consult_outcome_options();
}

function mdi_parse_consult_outcome($text) {
    require_once __DIR__ . '/monitor_lab_consult_helper.php';
    return mlc_parse_consult_outcome($text);
}

function mdi_consult_outcome_checked_html($text) {
    require_once __DIR__ . '/monitor_lab_consult_helper.php';
    return mlc_consult_outcome_checked_html($text);
}

function mdi_list_pharmacists($con, $prefer_user_id = 0) {
    require_once __DIR__ . '/opduser_auth_helper.php';
    return tham_list_consult_pharmacists($con, $prefer_user_id);
}

function mdi_resolve_pharmacist($con, $user_id, $fallback_name = '') {
    $user_id = (int)$user_id;
    if ($user_id > 0) {
        $q = mysqli_query($con, "SELECT id, full_name, username FROM users WHERE id = $user_id LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            $name = trim((string)($r['full_name'] ?? ''));
            if ($name === '') {
                $name = trim((string)($r['username'] ?? ''));
            }
            return ['id' => (int)$r['id'], 'name' => $name];
        }
    }
    return ['id' => 0, 'name' => trim((string)$fallback_name)];
}

function mdi_ymd($date) {
    $date = trim((string)$date);
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $date, $m)) {
        return sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[2], (int)$m[1]);
    }
    return substr($date, 0, 10);
}

function mdi_case_key($hn, $rule_id, $vstdate, $vn, $drug1, $drug2) {
    $hn = ltrim(trim((string)$hn), '0');
    $pair = substr(md5(trim((string)$drug1) . '|' . trim((string)$drug2)), 0, 10);
    return 'di|' . $hn . '|' . (int)$rule_id . '|' . mdi_ymd($vstdate) . '|' . trim((string)$vn) . '|' . $pair;
}

function mdi_case_key_from_visit(array $v) {
    $key = trim((string)($v['case_key'] ?? ''));
    if ($key !== '') {
        return $key;
    }
    return mdi_case_key(
        $v['hn'] ?? '',
        $v['rule_id'] ?? 0,
        $v['vstdate'] ?? ($v['drug1_date'] ?? ''),
        $v['vn'] ?? '',
        $v['drug1_name'] ?? '',
        $v['drug2_name'] ?? ''
    );
}

function mdi_get_consult($con, $id) {
    mdi_ensure_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM monitor_drug_interaction_consults WHERE id = $id LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function mdi_find_by_key($con, $case_key) {
    mdi_ensure_tables($con);
    $k = mysqli_real_escape_string($con, trim((string)$case_key));
    if ($k === '') {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM monitor_drug_interaction_consults WHERE case_key = '$k' LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function mdi_pair_label(array $r) {
    $d1 = trim((string)($r['drug1_name'] ?? ''));
    $d2 = trim((string)($r['drug2_name'] ?? ''));
    if ($d1 !== '' && $d2 !== '') {
        return $d1 . ' + ' . $d2;
    }
    return $d1 !== '' ? $d1 : ($d2 !== '' ? $d2 : 'คู่ยา');
}

function mdi_format_consult_row(array $r) {
    $status = mdi_consult_normalize_status($r['status'] ?? 'waiting');
    return [
        'id' => (int)($r['id'] ?? 0),
        'case_key' => (string)($r['case_key'] ?? ''),
        'hn' => (string)($r['hn'] ?? ''),
        'vn' => (string)($r['vn'] ?? ''),
        'ptname' => (string)($r['ptname'] ?? ''),
        'vstdate' => (string)($r['vstdate'] ?? ''),
        'rule_id' => (int)($r['rule_id'] ?? 0),
        'drug1_name' => (string)($r['drug1_name'] ?? ''),
        'drug2_name' => (string)($r['drug2_name'] ?? ''),
        'drug1_method' => (string)($r['drug1_method'] ?? ''),
        'drug2_method' => (string)($r['drug2_method'] ?? ''),
        'dose1_qty' => (string)($r['dose1_qty'] ?? ''),
        'dose2_qty' => (string)($r['dose2_qty'] ?? ''),
        'drug1_date' => (string)($r['drug1_date'] ?? ''),
        'drug2_date' => (string)($r['drug2_date'] ?? ''),
        'drug1_time' => (string)($r['drug1_time'] ?? ''),
        'drug2_time' => (string)($r['drug2_time'] ?? ''),
        'drug1_daily_mg' => (string)($r['drug1_daily_mg'] ?? ''),
        'drug2_daily_mg' => (string)($r['drug2_daily_mg'] ?? ''),
        'drug1_coverage_days' => (string)($r['drug1_coverage_days'] ?? ''),
        'drug2_coverage_days' => (string)($r['drug2_coverage_days'] ?? ''),
        'drug1_coverage_end' => (string)($r['drug1_coverage_end'] ?? ''),
        'drug2_coverage_end' => (string)($r['drug2_coverage_end'] ?? ''),
        'alert_level' => (string)($r['alert_level'] ?? 'soft'),
        'interaction_type' => (string)($r['interaction_type'] ?? ''),
        'detail_text' => (string)($r['detail_text'] ?? ''),
        'check_mode_label' => (string)($r['check_mode_label'] ?? ''),
        'pair_label' => mdi_pair_label($r),
        'status' => $status,
        'status_label' => mdi_consult_status_label($status),
        'pharmacist_user_id' => (int)($r['pharmacist_user_id'] ?? 0),
        'pharmacist_name' => (string)($r['pharmacist_name'] ?? ''),
        'consult_note' => (string)($r['consult_note'] ?? ''),
        'doctor_reply' => (string)($r['doctor_reply'] ?? ''),
        'reply_wait_days' => (int)($r['reply_wait_days'] ?? 0),
        'reply_due_at' => (string)($r['reply_due_at'] ?? ''),
        'started_at' => (string)($r['started_at'] ?? ''),
        'closed_at' => (string)($r['closed_at'] ?? ''),
        'printed_at' => (string)($r['printed_at'] ?? ''),
    ];
}

function mdi_default_consult_virtual(array $v) {
    return [
        'id' => 0,
        'case_key' => mdi_case_key_from_visit($v),
        'hn' => (string)($v['hn'] ?? ''),
        'status' => 'waiting',
        'status_label' => mdi_consult_status_label('waiting'),
        'consult_note' => '',
        'doctor_reply' => '',
        'pharmacist_name' => '',
        'reply_wait_days' => 0,
        'reply_due_at' => '',
        'printed_at' => '',
    ];
}

function mdi_process_timeouts($con) {
    mdi_ensure_tables($con);
    $q = mysqli_query($con, "SELECT * FROM monitor_drug_interaction_consults
        WHERE status = 'in_progress' AND reply_due_at IS NOT NULL AND reply_due_at <= NOW()");
    if (!$q) {
        return 0;
    }
    $n = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $id = (int)$row['id'];
        if (mysqli_query($con, "UPDATE monitor_drug_interaction_consults SET
            status='waiting', reply_due_at=NULL, updated_at=NOW() WHERE id=$id")) {
            $n++;
            $after = mdi_get_consult($con, $id);
            mdi_log_history($con, [
                'consult_id' => $id,
                'row' => $after ?: $row,
                'action_key' => 'timeout_reply',
                'action_label' => 'หมดเวลารอตอบ — กลับเป็นรอ Consult',
                'status_before' => 'in_progress',
                'status_after' => 'waiting',
                'actor_name' => 'ระบบ',
            ]);
        }
    }
    return $n;
}

function mdi_index_by_keys($con, array $keys) {
    mdi_ensure_tables($con);
    mdi_process_timeouts($con);
    $map = [];
    $keys = array_values(array_unique(array_filter(array_map('trim', $keys))));
    if (empty($keys)) {
        return $map;
    }
    $in = [];
    foreach ($keys as $k) {
        $in[] = "'" . mysqli_real_escape_string($con, $k) . "'";
    }
    foreach (array_chunk($in, 200) as $chunk) {
        $q = mysqli_query($con, 'SELECT * FROM monitor_drug_interaction_consults WHERE case_key IN (' . implode(',', $chunk) . ')');
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $map[$r['case_key']] = mdi_format_consult_row($r);
        }
    }
    return $map;
}

function mdi_attach_to_groups($con, array $groups) {
    $keys = [];
    foreach ($groups as $g) {
        foreach (($g['visits'] ?? []) as $v) {
            $v['hn'] = $v['hn'] ?? ($g['hn'] ?? '');
            $keys[] = mdi_case_key_from_visit($v);
        }
    }
    $map = mdi_index_by_keys($con, $keys);
    foreach ($groups as &$g) {
        foreach ($g['visits'] as &$v) {
            if (empty($v['hn'])) {
                $v['hn'] = $g['hn'] ?? '';
            }
            if (empty($v['ptname'])) {
                $v['ptname'] = $g['ptname'] ?? '';
            }
            $k = mdi_case_key_from_visit($v);
            $v['case_key'] = $k;
            $v['consult'] = $map[$k] ?? mdi_default_consult_virtual($v);
        }
        unset($v);
    }
    unset($g);
    return $groups;
}

function mdi_esc_date_sql($con, $date) {
    $ymd = mdi_ymd($date);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $ymd)) {
        return 'NULL';
    }
    return "'" . mysqli_real_escape_string($con, $ymd) . "'";
}

function mdi_upsert_from_case($con, array $case, array $extra = []) {
    mdi_ensure_tables($con);
    $key = trim((string)($case['case_key'] ?? ''));
    if ($key === '') {
        $key = mdi_case_key_from_visit($case);
    }
    if ($key === '' || trim((string)($case['hn'] ?? '')) === '') {
        return ['ok' => false, 'error' => 'ข้อมูลเคสไม่ครบ'];
    }
    $existing = mdi_find_by_key($con, $key);
    $hn = mysqli_real_escape_string($con, ltrim(trim((string)($case['hn'] ?? '')), '0'));
    $vn = mysqli_real_escape_string($con, trim((string)($case['vn'] ?? '')));
    $ptname = mysqli_real_escape_string($con, trim((string)($case['ptname'] ?? '')));
    $vst = mdi_esc_date_sql($con, $case['vstdate'] ?? ($case['drug1_date'] ?? ''));
    $rule_id = (int)($case['rule_id'] ?? 0);
    $d1 = mysqli_real_escape_string($con, trim((string)($case['drug1_name'] ?? '')));
    $d2 = mysqli_real_escape_string($con, trim((string)($case['drug2_name'] ?? '')));
    $m1 = mysqli_real_escape_string($con, trim((string)($case['drug1_method'] ?? '')));
    $m2 = mysqli_real_escape_string($con, trim((string)($case['drug2_method'] ?? '')));
    $q1 = mysqli_real_escape_string($con, (string)($case['dose1_qty'] ?? ''));
    $q2 = mysqli_real_escape_string($con, (string)($case['dose2_qty'] ?? ''));
    $dt1 = mysqli_real_escape_string($con, trim((string)($case['drug1_date'] ?? '')));
    $dt2 = mysqli_real_escape_string($con, trim((string)($case['drug2_date'] ?? '')));
    $tm1 = mysqli_real_escape_string($con, trim((string)($case['drug1_time'] ?? '')));
    $tm2 = mysqli_real_escape_string($con, trim((string)($case['drug2_time'] ?? '')));
    $mg1 = mysqli_real_escape_string($con, trim((string)($case['drug1_daily_mg'] ?? '')));
    $mg2 = mysqli_real_escape_string($con, trim((string)($case['drug2_daily_mg'] ?? '')));
    $c1 = mysqli_real_escape_string($con, (string)($case['drug1_coverage_days'] ?? ''));
    $c2 = mysqli_real_escape_string($con, (string)($case['drug2_coverage_days'] ?? ''));
    $e1 = mysqli_real_escape_string($con, trim((string)($case['drug1_coverage_end'] ?? '')));
    $e2 = mysqli_real_escape_string($con, trim((string)($case['drug2_coverage_end'] ?? '')));
    $lvl = (($case['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
    $itype = mysqli_real_escape_string($con, trim((string)($case['interaction_type'] ?? '')));
    $detail = mysqli_real_escape_string($con, trim((string)($case['detail_text'] ?? '')));
    $check = mysqli_real_escape_string($con, trim((string)($case['check_mode_label'] ?? '')));
    $key_esc = mysqli_real_escape_string($con, $key);
    $updated_by = (int)($extra['updated_by'] ?? $extra['created_by'] ?? 0);
    $created_by = (int)($extra['created_by'] ?? $updated_by);

    $set = "hn='$hn', vn='$vn', ptname='$ptname', vstdate=$vst, rule_id=$rule_id,
        drug1_name='$d1', drug2_name='$d2', drug1_method='$m1', drug2_method='$m2',
        dose1_qty='$q1', dose2_qty='$q2', drug1_date='$dt1', drug2_date='$dt2',
        drug1_time='$tm1', drug2_time='$tm2', drug1_daily_mg='$mg1', drug2_daily_mg='$mg2',
        drug1_coverage_days='$c1', drug2_coverage_days='$c2',
        drug1_coverage_end='$e1', drug2_coverage_end='$e2',
        alert_level='$lvl', interaction_type='$itype', detail_text='$detail', check_mode_label='$check',
        updated_by=" . ($updated_by > 0 ? $updated_by : 'NULL');

    if ($existing) {
        $id = (int)$existing['id'];
        if (!mysqli_query($con, "UPDATE monitor_drug_interaction_consults SET $set WHERE id=$id")) {
            return ['ok' => false, 'error' => mysqli_error($con)];
        }
        return ['ok' => true, 'id' => $id, 'row' => mdi_get_consult($con, $id)];
    }
    $sql = "INSERT INTO monitor_drug_interaction_consults
        (case_key, hn, vn, ptname, vstdate, rule_id, drug1_name, drug2_name, drug1_method, drug2_method,
         dose1_qty, dose2_qty, drug1_date, drug2_date, drug1_time, drug2_time, drug1_daily_mg, drug2_daily_mg,
         drug1_coverage_days, drug2_coverage_days, drug1_coverage_end, drug2_coverage_end,
         alert_level, interaction_type, detail_text, check_mode_label, status, created_by, updated_by)
        VALUES ('$key_esc', '$hn', '$vn', '$ptname', $vst, $rule_id, '$d1', '$d2', '$m1', '$m2',
            '$q1', '$q2', '$dt1', '$dt2', '$tm1', '$tm2', '$mg1', '$mg2',
            '$c1', '$c2', '$e1', '$e2',
            '$lvl', '$itype', '$detail', '$check', 'waiting',
            " . ($created_by > 0 ? $created_by : 'NULL') . ", " . ($updated_by > 0 ? $updated_by : 'NULL') . ")";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $id = (int)mysqli_insert_id($con);
    return ['ok' => true, 'id' => $id, 'row' => mdi_get_consult($con, $id)];
}

function mdi_start_consult($con, array $case, $pharmacist_user_id, $pharmacist_name, $note, $actor_user_id, $reply_wait_days = null, $actor_name = '') {
    $up = mdi_upsert_from_case($con, $case, [
        'created_by' => $actor_user_id,
        'updated_by' => $actor_user_id,
    ]);
    if (empty($up['ok'])) {
        return $up;
    }
    $id = (int)$up['id'];
    $before = mdi_get_consult($con, $id);
    $pharm = mdi_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name);
    $wait = mdi_normalize_reply_wait_days($reply_wait_days ?? mdi_get_reply_wait_days($con));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $due_sql = $wait <= 0 ? 'NULL' : "DATE_ADD(NOW(), INTERVAL $wait DAY)";
    $sql = "UPDATE monitor_drug_interaction_consults SET
        status='in_progress',
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'NULL') . ",
        pharmacist_name='$name_esc',
        consult_note='$note_esc',
        reply_wait_days=$wait,
        reply_due_at=$due_sql,
        closed_at=NULL,
        started_at=IFNULL(started_at, NOW()),
        printed_at=NOW(),
        updated_by=$actor
        WHERE id=$id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $row = mdi_get_consult($con, $id);
    mdi_log_history($con, [
        'consult_id' => $id,
        'row' => $row,
        'action_key' => 'start',
        'action_label' => 'เริ่ม Consult + พิมพ์ใบปรึกษา',
        'status_before' => $before['status'] ?? 'waiting',
        'status_after' => 'in_progress',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'reply_due_at' => $row['reply_due_at'] ?? null,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
        'meta' => ['reply_wait_days' => $wait],
    ]);
    return [
        'ok' => true,
        'id' => $id,
        'consult' => mdi_format_consult_row($row),
        'print_url' => 'monitor_drug_interaction_consult_print.php?id=' . $id,
        'message' => 'เริ่ม Consult แล้ว — รอตอบกลับ' . ($wait <= 0 ? 'ทันที' : ('ภายใน ' . $wait . ' วัน')),
    ];
}

function mdi_close_consult($con, $consult_id, $note, $doctor_reply, $actor_user_id, $actor_name = '', $pharmacist_user_id = 0, $pharmacist_name = '') {
    $consult_id = (int)$consult_id;
    $row = mdi_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $pharm = mdi_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name !== '' ? $pharmacist_name : ($row['pharmacist_name'] ?? ''));
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $reply_esc = mysqli_real_escape_string($con, trim((string)$doctor_reply));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $sql = "UPDATE monitor_drug_interaction_consults SET
        status='closed',
        closed_at=NOW(),
        reply_due_at=NULL,
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'pharmacist_user_id') . ",
        pharmacist_name=IF('$name_esc'='', pharmacist_name, '$name_esc'),
        consult_note=IF('$note_esc'='', consult_note, '$note_esc'),
        doctor_reply=IF('$reply_esc'='', doctor_reply, '$reply_esc'),
        updated_by=$actor
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = mdi_get_consult($con, $consult_id);
    mdi_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'close',
        'action_label' => 'ปิดการ Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => 'closed',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'doctor_reply' => $doctor_reply,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => mdi_format_consult_row($after), 'message' => 'ปิด Consult แล้ว'];
}

function mdi_save_result($con, $consult_id, $note, $doctor_reply, $actor_user_id, $actor_name = '', $pharmacist_user_id = 0, $pharmacist_name = '') {
    $consult_id = (int)$consult_id;
    $row = mdi_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $pharm = mdi_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $reply_esc = mysqli_real_escape_string($con, trim((string)$doctor_reply));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $sql = "UPDATE monitor_drug_interaction_consults SET
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'pharmacist_user_id') . ",
        pharmacist_name=IF('$name_esc'='', pharmacist_name, '$name_esc'),
        consult_note=IF('$note_esc'='', consult_note, '$note_esc'),
        doctor_reply=IF('$reply_esc'='', doctor_reply, '$reply_esc'),
        updated_by=$actor
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = mdi_get_consult($con, $consult_id);
    mdi_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'save_result',
        'action_label' => 'บันทึกผล Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => $after['status'] ?? '',
        'pharmacist_name' => $pharm['name'] !== '' ? $pharm['name'] : ($row['pharmacist_name'] ?? ''),
        'note_text' => $note,
        'doctor_reply' => $doctor_reply,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => mdi_format_consult_row($after), 'message' => 'บันทึกผล Consult เรียบร้อย'];
}

function mdi_reset_waiting($con, $consult_id, $actor_user_id, $note = '', $actor_name = '') {
    $consult_id = (int)$consult_id;
    $row = mdi_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $note_sql = $note_esc !== '' ? ", consult_note='$note_esc'" : '';
    $actor = (int)$actor_user_id;
    $sql = "UPDATE monitor_drug_interaction_consults SET
        status='waiting', reply_due_at=NULL, closed_at=NULL, updated_by=$actor
        $note_sql
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = mdi_get_consult($con, $consult_id);
    mdi_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'reset',
        'action_label' => 'ตั้งเป็นรอ Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => 'waiting',
        'note_text' => $note,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => mdi_format_consult_row($after)];
}

function mdi_mark_printed($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "UPDATE monitor_drug_interaction_consults SET printed_at=NOW() WHERE id=$id");
}

function mdi_log_history($con, array $data) {
    mdi_ensure_tables($con);
    $row = $data['row'] ?? [];
    $consult_id = (int)($data['consult_id'] ?? ($row['id'] ?? 0));
    $hn = mysqli_real_escape_string($con, (string)($row['hn'] ?? ''));
    $vn = mysqli_real_escape_string($con, (string)($row['vn'] ?? ''));
    $drug = mysqli_real_escape_string($con, mdi_pair_label($row));
    $action_key = mysqli_real_escape_string($con, (string)($data['action_key'] ?? ''));
    $action_label = mysqli_real_escape_string($con, (string)($data['action_label'] ?? $action_key));
    $sb = mysqli_real_escape_string($con, (string)($data['status_before'] ?? ''));
    $sa = mysqli_real_escape_string($con, (string)($data['status_after'] ?? ''));
    $pharm = mysqli_real_escape_string($con, (string)($data['pharmacist_name'] ?? ($row['pharmacist_name'] ?? '')));
    $note = mysqli_real_escape_string($con, (string)($data['note_text'] ?? ''));
    $reply = mysqli_real_escape_string($con, (string)($data['doctor_reply'] ?? ''));
    $reply_due = !empty($data['reply_due_at'])
        ? "'" . mysqli_real_escape_string($con, (string)$data['reply_due_at']) . "'"
        : 'NULL';
    $meta = '';
    if (!empty($data['meta']) && is_array($data['meta'])) {
        $meta = mysqli_real_escape_string($con, json_encode($data['meta'], JSON_UNESCAPED_UNICODE));
    }
    $actor_id = (int)($data['actor_user_id'] ?? 0);
    $actor_name = mysqli_real_escape_string($con, (string)($data['actor_name'] ?? ''));
    $sql = "INSERT INTO monitor_drug_interaction_consult_history
        (consult_id, hn, vn, drug_name, action_key, action_label,
         status_before, status_after, pharmacist_name, note_text, doctor_reply, reply_due_at, meta_json,
         actor_user_id, actor_name)
        VALUES
        ($consult_id, '$hn', '$vn', '$drug', '$action_key', '$action_label',
         '$sb', '$sa', '$pharm', '$note', '$reply', $reply_due, " . ($meta !== '' ? "'$meta'" : 'NULL') . ",
         " . ($actor_id > 0 ? $actor_id : 'NULL') . ", '$actor_name')";
    return (bool)@mysqli_query($con, $sql);
}

function mdi_list_history($con, array $opts = []) {
    mdi_ensure_tables($con);
    $where = ['1=1'];
    if (!empty($opts['consult_id'])) {
        $where[] = 'consult_id=' . (int)$opts['consult_id'];
    }
    if (!empty($opts['hn'])) {
        $where[] = "hn='" . mysqli_real_escape_string($con, ltrim(trim((string)$opts['hn']), '0')) . "'";
    }
    $limit = max(1, min(500, (int)($opts['limit'] ?? 100)));
    $sql = 'SELECT * FROM monitor_drug_interaction_consult_history WHERE ' . implode(' AND ', $where)
        . ' ORDER BY created_at DESC, id DESC LIMIT ' . $limit;
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'id' => (int)$r['id'],
                'consult_id' => (int)$r['consult_id'],
                'created_at' => $r['created_at'],
                'drug_name' => $r['drug_name'],
                'action_key' => $r['action_key'],
                'action_label' => $r['action_label'],
                'status_before' => $r['status_before'],
                'status_after' => $r['status_after'],
                'status_before_label' => mdi_consult_status_label($r['status_before']),
                'status_after_label' => mdi_consult_status_label($r['status_after']),
                'pharmacist_name' => $r['pharmacist_name'],
                'note_text' => $r['note_text'],
                'doctor_reply' => $r['doctor_reply'],
                'reply_due_at' => $r['reply_due_at'],
                'actor_name' => $r['actor_name'],
            ];
        }
    }
    return $rows;
}
