<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/allergy_alert_helper.php';

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('allergy_alert_settings') && !af_alert_can_manage_settings($con)) {
    echo "<script>alert('คุณไม่มีสิทธิ์เข้าหน้าตั้งค่าแจ้งเตือนแพ้ยา'); window.location='home.php';</script>";
    exit;
}

$eligible = af_alert_user_eligible($con);
$can_access = af_alert_can_manage_access();
$role_access = af_alert_get_role_access($con);
$role_labels = tham_menu_role_labels();
$settings = af_alert_get_settings($con, (int)$_SESSION['user_id']);
$intro_styles = af_alert_intro_styles();
$current_intro = $settings['intro_style'] ?? 'hospital';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตั้งค่าแจ้งเตือนแพ้ยา - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        .af-alert-hero {
            background: linear-gradient(135deg, #9f1239 0%, #e11d48 55%, #fb7185 100%);
            color: #fff; border-radius: 12px; padding: 1.15rem 1.4rem;
            box-shadow: 0 8px 24px rgba(190, 18, 60, 0.25);
        }
        .btn-af { background: #be123c; color: #fff; border: 0; }
        .btn-af:hover { background: #9f1239; color: #fff; }
        .af-alert-card { border: 0; border-radius: 12px; }
        .form-check-input:checked { background-color: #be123c; border-color: #be123c; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="af-alert-hero mb-4">
                <div class="small opacity-75 mb-1"><i class="fas fa-allergies me-1"></i>ระบบแพ้ยา</div>
                <h4 class="fw-bold mb-1"><i class="fas fa-bell me-2"></i>ตั้งค่าแจ้งเตือนแพ้ยา</h4>
                <small>เลือกบทบาทและห้องจ่ายยาที่จะได้เสียงกับแบนเนอร์จนกว่าจะรับเคส — ห้องจ่ายยาผู้ป่วยในเปิด/ปิดได้ด้านล่าง</small>
            </div>

            <?php if ($can_access): ?>
            <div class="card af-alert-card shadow-sm mb-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-1"><i class="fas fa-user-shield me-2 text-danger"></i>สิทธิ์รับการแจ้งเตือน</h6>
                    <p class="small text-muted mb-3">เลือกบทบาทที่ให้ได้ยินเสียงและเห็นแบนเนอร์เมื่อมีเคสแพ้ยารอรับ ค่าเริ่มต้นเปิดไว้ที่เภสัชกรและเจ้าพนักงานเภสัชกรรม</p>
                    <form id="afRoleAccessForm">
                        <div class="row g-2">
                            <?php foreach ($role_labels as $rk => $rl): ?>
                            <div class="col-md-4">
                                <div class="form-check form-switch border rounded px-3 py-2">
                                    <input class="form-check-input af-role-access" type="checkbox" id="af_role_<?= htmlspecialchars($rk, ENT_QUOTES, 'UTF-8') ?>"
                                           data-role="<?= htmlspecialchars($rk, ENT_QUOTES, 'UTF-8') ?>"
                                           <?= !empty($role_access[$rk]) ? 'checked' : '' ?>>
                                    <label class="form-check-label fw-bold" for="af_role_<?= htmlspecialchars($rk, ENT_QUOTES, 'UTF-8') ?>">
                                        <?= htmlspecialchars($rl, ENT_QUOTES, 'UTF-8') ?>
                                        <span class="small text-muted fw-normal">(<?= htmlspecialchars($rk, ENT_QUOTES, 'UTF-8') ?>)</span>
                                    </label>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="submit" class="btn btn-af fw-bold mt-3" id="btnSaveRoles">
                            <i class="fas fa-save me-1"></i> บันทึกสิทธิ์
                        </button>
                    </form>
                </div>
            </div>
            <?php elseif (!$eligible): ?>
            <div class="alert alert-warning">บัญชีนี้ยังไม่ได้รับสิทธิ์รับการแจ้งเตือน — ให้ผู้ดูแลระบบเปิดสิทธิ์บทบาทของคุณที่หน้านี้</div>
            <?php endif; ?>

            <div class="card af-alert-card shadow-sm mb-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-1"><i class="fas fa-hospital me-2 text-danger"></i>สถานที่ทำงานที่ให้เตือน</h6>
                    <p class="small text-muted mb-3">
                        เลือกห้องจ่ายยาที่จะได้รับการแจ้งเตือนแพ้ยา เมื่อ Login แล้วเลือกห้องนั้น
                        (ใช้ห้องเดียวกับโหมด Backup Smart Pharma)
                    </p>
                    <form id="afRoomForm">
                        <?php
                        $af_rooms = af_alert_get_room_config($con);
                        $af_room_opts = af_alert_dispense_rooms();
                        $af_room_keys = ['opd' => 'room_opd', 'ipd' => 'room_ipd'];
                        ?>
                        <div class="row g-2">
                            <?php foreach ($af_room_opts as $rk => $rl):
                                $cfg_key = $af_room_keys[$rk];
                            ?>
                            <div class="col-md-6">
                                <div class="form-check form-switch border rounded px-3 py-3">
                                    <input class="form-check-input af-room-access" type="checkbox" id="af_<?= htmlspecialchars($cfg_key, ENT_QUOTES, 'UTF-8') ?>"
                                           data-room="<?= htmlspecialchars($cfg_key, ENT_QUOTES, 'UTF-8') ?>"
                                           <?= !empty($af_rooms[$cfg_key]) ? 'checked' : '' ?>>
                                    <label class="form-check-label fw-bold" for="af_<?= htmlspecialchars($cfg_key, ENT_QUOTES, 'UTF-8') ?>">
                                        <?= htmlspecialchars($rl, ENT_QUOTES, 'UTF-8') ?>
                                        <?php if ($rk === 'ipd'): ?>
                                        <div class="small text-muted fw-normal mt-1">เปิดเมื่อต้องการให้ห้องจ่ายยาผู้ป่วยในได้ยินเสียงและเห็นแบนเนอร์</div>
                                        <?php else: ?>
                                        <div class="small text-muted fw-normal mt-1">เตือนเมื่อเลือกทำงานที่ห้องจ่ายยาผู้ป่วยนอก</div>
                                        <?php endif; ?>
                                    </label>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="submit" class="btn btn-af fw-bold mt-3" id="btnSaveRooms">
                            <i class="fas fa-save me-1"></i> บันทึกสถานที่ที่เตือน
                        </button>
                    </form>
                </div>
            </div>

            <div class="card af-alert-card shadow-sm mb-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3"><i class="fas fa-sliders-h me-2 text-danger"></i>การแจ้งเตือนของฉัน</h6>
                    <form id="afAlertForm">
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" id="af_enabled" <?= $settings['enabled'] ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="af_enabled">เปิดการแจ้งเตือนเคสรอรับ</label>
                            <div class="form-text">ปิดแล้วจะไม่แสดงแบนเนอร์และไม่เล่นเสียงในทุกหน้า</div>
                        </div>
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" id="af_banner" <?= $settings['banner_enabled'] ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="af_banner">แสดงแบนเนอร์บนทุกหน้า</label>
                        </div>
                        <div class="form-check form-switch mb-4">
                            <input class="form-check-input" type="checkbox" id="af_sound" <?= $settings['sound_enabled'] ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="af_sound">เล่นเสียงประกาศ</label>
                            <div class="form-text">มีเสียงนำแล้วตามด้วยข้อความ ซ้ำตามช่วงเวลาจนกว่าจะรับเคส</div>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-bold">เสียงนำ</label>
                            <div class="row g-2">
                                <?php foreach ($intro_styles as $sk => $sl): ?>
                                <div class="col-md-6">
                                    <label class="border rounded px-3 py-2 d-flex align-items-start gap-2 w-100" style="cursor:pointer;">
                                        <input class="form-check-input mt-1" type="radio" name="af_intro" value="<?= htmlspecialchars($sk, ENT_QUOTES, 'UTF-8') ?>"
                                               <?= $current_intro === $sk ? 'checked' : '' ?>>
                                        <span>
                                            <span class="fw-bold"><?= htmlspecialchars($sl, ENT_QUOTES, 'UTF-8') ?></span>
                                            <?php if ($sk === 'hospital'): ?>
                                            <div class="small text-muted">ชัด ฟังง่าย ไม่รบกวนเมื่อเตือนซ้ำ</div>
                                            <?php elseif ($sk === 'chime'): ?>
                                            <div class="small text-muted">กระดิ่ง ding-dong สั้นๆ</div>
                                            <?php elseif ($sk === 'page'): ?>
                                            <div class="small text-muted">จังหวะเพจเจอร์ทางการแพทย์</div>
                                            <?php elseif ($sk === 'fanfare'): ?>
                                            <div class="small text-muted">อะคอร์ดขึ้น สดใสกว่าไซเรน</div>
                                            <?php else: ?>
                                            <div class="small text-muted">ดังเร่งด่วน อาจล้าถ้าย้ำบ่อย</div>
                                            <?php endif; ?>
                                        </span>
                                    </label>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label fw-bold">ช่วงเวลาเตือนซ้ำ (นาที)</label>
                                <input type="number" class="form-control" id="af_interval" min="1" max="30" value="<?= (int)$settings['interval_min'] ?>">
                                <div class="form-text">ค่าเริ่มต้น 5 นาที — เคสใหม่จะเตือนทันที</div>
                            </div>
                            <div class="col-md-8">
                                <label class="form-label fw-bold">ข้อความเสียง</label>
                                <input type="text" class="form-control" id="af_speech" maxlength="120"
                                       value="<?= htmlspecialchars($settings['speech_text'], ENT_QUOTES, 'UTF-8') ?>">
                                <div class="form-text">ค่าเริ่มต้น: New Drug Allergy Case</div>
                            </div>
                        </div>
                        <div class="d-flex flex-wrap gap-2 mt-4">
                            <button type="submit" class="btn btn-af fw-bold" id="btnSaveAlert">
                                <i class="fas fa-save me-1"></i> บันทึกการตั้งค่า
                            </button>
                            <button type="button" class="btn btn-outline-danger" id="btnTestAlert">
                                <i class="fas fa-volume-up me-1"></i> ทดสอบเสียง
                            </button>
                            <a href="allergy_followup.php" class="btn btn-outline-secondary">ไปสมุดติดตามเคส</a>
                        </div>
                        <div class="small text-muted mt-3">
                            เบราว์เซอร์อาจปิดเสียงอัตโนมัติจนกว่าจะคลิกที่หน้าเว็บครั้งแรก — คลิก “ทดสอบเสียง” เพื่อเปิดสิทธิ์เสียง
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    function payload() {
        return {
            enabled: document.getElementById('af_enabled').checked ? 1 : 0,
            banner_enabled: document.getElementById('af_banner').checked ? 1 : 0,
            sound_enabled: document.getElementById('af_sound').checked ? 1 : 0,
            interval_min: parseInt(document.getElementById('af_interval').value, 10) || 5,
            speech_text: document.getElementById('af_speech').value || 'New Drug Allergy Case',
            intro_style: (document.querySelector('input[name="af_intro"]:checked') || {}).value || 'hospital'
        };
    }
    const roleForm = document.getElementById('afRoleAccessForm');
    if (roleForm) {
        roleForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const roles = {};
            document.querySelectorAll('.af-role-access').forEach(function (el) {
                roles[el.getAttribute('data-role')] = el.checked ? 1 : 0;
            });
            const btn = document.getElementById('btnSaveRoles');
            btn.disabled = true;
            fetch('fetch_allergy_alert_api.php?action=save_role_access', {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ roles: roles })
            }).then(function (r) { return r.json(); }).then(function (data) {
                btn.disabled = false;
                if (data.status === 'success') {
                    alert('บันทึกสิทธิ์แล้ว');
                    window.location.reload();
                    return;
                }
                alert(data.message || 'บันทึกไม่สำเร็จ');
            }).catch(function () {
                btn.disabled = false;
                alert('เชื่อมต่อไม่สำเร็จ');
            });
        });
    }
    const roomForm = document.getElementById('afRoomForm');
    if (roomForm) {
        roomForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const rooms = {};
            document.querySelectorAll('.af-room-access').forEach(function (el) {
                rooms[el.getAttribute('data-room')] = el.checked ? 1 : 0;
            });
            const btn = document.getElementById('btnSaveRooms');
            btn.disabled = true;
            fetch('fetch_allergy_alert_api.php?action=save_room_config', {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(rooms)
            }).then(function (r) { return r.json(); }).then(function (data) {
                btn.disabled = false;
                if (data.status === 'success') {
                    alert('บันทึกสถานที่ที่เตือนแล้ว');
                    return;
                }
                alert(data.message || 'บันทึกไม่สำเร็จ');
            }).catch(function () {
                btn.disabled = false;
                alert('เชื่อมต่อไม่สำเร็จ');
            });
        });
    }
    document.getElementById('afAlertForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const btn = document.getElementById('btnSaveAlert');
        btn.disabled = true;
        fetch('fetch_allergy_alert_api.php?action=save_settings', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload())
        }).then(function (r) { return r.json(); }).then(function (data) {
            btn.disabled = false;
            alert(data.status === 'success' ? 'บันทึกแล้ว' : (data.message || 'บันทึกไม่สำเร็จ'));
        }).catch(function () {
            btn.disabled = false;
            alert('เชื่อมต่อไม่สำเร็จ');
        });
    });
    document.getElementById('btnTestAlert').addEventListener('click', function () {
        if (window.ThamAllergyAlert && typeof window.ThamAllergyAlert.test === 'function') {
            const style = (document.querySelector('input[name="af_intro"]:checked') || {}).value || 'hospital';
            window.ThamAllergyAlert.test(document.getElementById('af_speech').value, style);
            return;
        }
        if (!window.speechSynthesis) {
            alert('เบราว์เซอร์นี้ไม่รองรับเสียงพูด');
            return;
        }
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(document.getElementById('af_speech').value || 'New Drug Allergy Case');
        u.lang = 'en-US';
        window.speechSynthesis.speak(u);
    });
})();
</script>
</body>
</html>
