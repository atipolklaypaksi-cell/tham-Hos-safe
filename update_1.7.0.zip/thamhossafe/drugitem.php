<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
// เมนู ข้อมูลยา (Master) ถูกถอดออกจากระบบ
header('Location: home.php');
exit;
