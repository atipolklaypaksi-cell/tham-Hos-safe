<?php
/**
 * API เชื่อมต่อ JHCIS PCC (Read Only)
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();
include(__DIR__ . '/connect.php');
require_once __DIR__ . '/jhcis_helper.php';
mysqli_set_charset($con, 'utf8');

function jhcis_api_json(array $payload, $code = 200) {
    ob_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    jhcis_api_json(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], 401);
}

require_once __DIR__ . '/menu_permissions_helper.php';
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.jhcis') && !tham_menu_can('admin.hosxp')) {
    jhcis_api_json(['status' => 'error', 'message' => 'ไม่มีสิทธิ์ตั้งค่า JHCIS PCC'], 403);
}
session_write_close();

jhcis_ensure_config($con);
$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'get'));

if ($action === 'get') {
    jhcis_api_json([
        'status' => 'success',
        'config' => jhcis_public_config(jhcis_load_config($con)),
    ]);
}

if ($action === 'save') {
    $cfg = jhcis_save_config($con, $input);
    jhcis_api_json([
        'status' => 'success',
        'message' => 'บันทึกการเชื่อมต่อ JHCIS PCC แล้ว (Read Only)',
        'config' => jhcis_public_config($cfg),
    ]);
}

if ($action === 'test') {
    $override = [];
    foreach (['jhcis_host', 'jhcis_port', 'jhcis_user', 'jhcis_db'] as $k) {
        if (isset($input[$k])) {
            $override[$k] = trim((string)$input[$k]);
        }
    }
    if (isset($input['jhcis_pass']) && (string)$input['jhcis_pass'] !== '' && (string)$input['jhcis_pass'] !== '********') {
        $override['jhcis_pass'] = (string)$input['jhcis_pass'];
    }
    $ping = jhcis_ping($con, $override ?: null);
    jhcis_api_json([
        'status' => $ping['ok'] ? 'success' : 'error',
        'message' => $ping['ok']
            ? 'เชื่อมต่อ JHCIS PCC สำเร็จ (Read Only)'
            : ('เชื่อมต่อล้มเหลว: ' . ($ping['error'] ?: 'ไม่ทราบสาเหตุ')),
        'ping' => $ping,
    ]);
}

if ($action === 'tables') {
    $jhcis = jhcis_connect($con, 20);
    if (!$jhcis) {
        jhcis_api_json(['status' => 'error', 'message' => 'เชื่อมต่อ JHCIS PCC ไม่ได้']);
    }
    $q = trim((string)($input['q'] ?? $_GET['q'] ?? ''));
    $tables = jhcis_list_tables($jhcis, $q, 100);
    jhcis_close($jhcis);
    jhcis_api_json([
        'status' => 'success',
        'tables' => $tables,
    ]);
}

if ($action === 'preview') {
    $table = trim((string)($input['table'] ?? $_GET['table'] ?? ''));
    $jhcis = jhcis_connect($con, 20);
    if (!$jhcis) {
        jhcis_api_json(['status' => 'error', 'message' => 'เชื่อมต่อ JHCIS PCC ไม่ได้']);
    }
    $preview = jhcis_preview_table($jhcis, $table, 20);
    $cols = jhcis_describe_table($jhcis, $table);
    jhcis_close($jhcis);
    jhcis_api_json([
        'status' => empty($preview['error']) ? 'success' : 'error',
        'message' => $preview['error'] ?: '',
        'table' => $table,
        'columns' => $cols,
        'preview' => $preview,
    ]);
}

jhcis_api_json(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], 400);
