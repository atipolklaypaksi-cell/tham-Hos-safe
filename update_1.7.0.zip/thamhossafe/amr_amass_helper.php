<?php
/**
 * เตรียมไฟล์ข้อมูลสำหรับรัน AMASS
 * drug_data / hospital_admission_data ตาม query ของโรงพยาบาล
 * microbiology_data จาก lab_head.result_rtf (HOSxP) หรือตาราง amr_mlab_lab / amr_mlab_ast
 * ตามการตั้งค่าแหล่งข้อมูลในหน้าเชื่อมต่อ AMR — ยาและ admit ยังดึงจาก HOSxP
 */

function amr_amass_datasets() {
    return [
        'drug' => [
            'ready' => true,
            'filename' => 'drug_data.xlsx',
            'label' => 'Drug data',
            'columns' => ['HN', 'drug_name', 'route_administration', 'drug_start_date_td', 'drug_stop_date_td', 'ward_name', 'department'],
        ],
        'admission' => [
            'ready' => true,
            'filename' => 'hospital_admission_data.xlsx',
            'label' => 'Hospital admission data',
            'columns' => ['HN', 'เพศ', 'อายุ', 'Admit', 'Discharge', 'ward_ad', 'ward_dc', 'discharge_type', 'dcstatus'],
        ],
        'microbiology' => [
            'ready' => true,
            'filename' => 'microbiology_data.xlsx',
            'label' => 'Microbiology data',
            'columns' => ['HN9_HIS', 'DATE_DATA', 'CDATE', 'SPECIMEN', 'CSOURCE', 'CRESULT'],
        ],
    ];
}

function amr_amass_ward_alias_pairs() {
    return [
        ['ICU 1 (X-Ray ชั้น 3)', 'ICU1'],
        ['ICU 2 (ER ชั้น 2)', 'ICU2'],
        ['ICU 3 (ชั้น 1)', 'ICU3'],
        ['ICU 4 (ER ชั้น 3)', 'ICU4'],
        ['NICU', 'NICU'],
        ['Psychiatric Home Ward', 'จิตเวช'],
        ['กุมารเวชกรรม ชั้น 2', 'กุมารเวชกรรมชั้น2'],
        ['กุมารเวชกรรม ชั้น 3', 'กุมารเวชกรรมชั้น3'],
        ['จักษุ', 'หูคอจมูก'],
        ['จิตเวช', 'จิตเวช'],
        ['ผู้ป่วย STROKE UNIT (ER ชั้น 4)', 'อายุรกรรมERชั้น4'],
        ['ผู้ป่วยโรคไต (MED ชั้น 3)', 'อายุรกรรมรวม'],
        ['พิเศษชั้น 4', 'พิเศษ4'],
        ['พิเศษชั้น 5', 'พิเศษ5'],
        ['พิเศษศัลยกรรม ER ชั้น 3-4', 'พิเศษศัลยกรรม ER'],
        ['พิเศษศัลยกรรมกระดูก ชั้น 5', 'พิเศษศัลยกรรมกระดูกชั้น5'],
        ['ศัลยกรรมกระดูก ชั้น 3', 'ศัลยกรรมกระดูก'],
        ['ศัลยกรรมชาย ชั้น 4', 'ศัลยกรรมชาย'],
        ['ศัลยกรรมหญิง ชั้น 2', 'ศัลยกรรมหญิง'],
        ['ศัลยกรรมอุบัติเหตุ (ER ชั้น 3)', 'ศัลยกรรมอุบัติเหตุ'],
        ['สงฆ์ ชั้น 1 (ยกเลิกห้ามใช้ 19 ส.ค. 67)', 'สงฆ์อาพาธ1'],
        ['สงฆ์ ชั้น 2', 'สงฆ์อาพาธ2'],
        ['สงฆ์ ชั้น 3', 'สงฆ์อาพาธ3'],
        ['สงฆ์ ชั้น 4', 'สงฆ์อาพาธ4'],
        ['สูติ-นรีเวชกรรม', 'สูตินรีเวชกรรม'],
        ['หูคอจมูก', 'หูคอจมูก'],
        ['ห้องคลอด', 'ห้องคลอด'],
        ['อายุรกรรม ER ชั้น 4', 'อายุรกรรมERชั้น4'],
        ['อายุรกรรมชาย ชั้น 1', 'อายุรกรรมชาย'],
        ['อายุรกรรมประสาท (ER ชั้น 4)', 'อายุรกรรมERชั้น4'],
        ['อายุรกรรมรวม ชั้น 3', 'อายุรกรรมรวม'],
        ['อายุรกรรมหญิง ชั้น 2', 'อายุรกรรมหญิง'],
    ];
}

function amr_amass_seed_ward_aliases($con) {
    if (!$con) {
        return false;
    }
    $q = mysqli_query($con, "SELECT COUNT(*) AS c FROM amr_dict_rows WHERE category = 'ward_alias'");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if ($row && (int)$row['c'] > 0) {
        return true;
    }
    $stmt = mysqli_prepare($con, "INSERT INTO amr_dict_rows
        (dict_file, category, section, amass_key, local_value, display_label, match_mode, sort_order, active, source)
        VALUES ('builtin', 'ward_alias', '', ?, ?, ?, 'exact', ?, 1, 'builtin')");
    if (!$stmt) {
        return false;
    }
    $i = 0;
    foreach (amr_amass_ward_alias_pairs() as $pair) {
        $i += 10;
        $amass = $pair[1];
        $local = $pair[0];
        $label = $pair[1];
        $order = $i;
        mysqli_stmt_bind_param($stmt, 'sssi', $amass, $local, $label, $order);
        mysqli_stmt_execute($stmt);
    }
    mysqli_stmt_close($stmt);
    return true;
}

function amr_amass_sql_utf8_bin($col) {
    return "CAST(CONVERT($col USING utf8) AS binary)";
}

function amr_amass_set_ward_pairs(array $pairs) {
    amr_amass_active_ward_pairs(null, $pairs);
}

function amr_amass_load_ward_pairs($con) {
    $pairs = [];
    if ($con) {
        $q = mysqli_query($con, "SELECT local_value, display_label, amass_key
            FROM amr_dict_rows
            WHERE category = 'ward_alias' AND active = 1
            ORDER BY sort_order ASC, id ASC");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $local = trim((string)($r['local_value'] ?? ''));
                $label = trim((string)($r['display_label'] ?? ''));
                if ($label === '') {
                    $label = trim((string)($r['amass_key'] ?? ''));
                }
                if ($local !== '' && $label !== '') {
                    $pairs[] = [$local, $label];
                }
            }
        }
    }
    if (empty($pairs)) {
        $pairs = amr_amass_ward_alias_pairs();
    }
    amr_amass_set_ward_pairs($pairs);
    return $pairs;
}

function amr_amass_active_ward_pairs($ignored = null, $set = null) {
    static $pairs = null;
    if ($set !== null) {
        $pairs = $set;
    }
    if ($pairs === null) {
        $pairs = amr_amass_ward_alias_pairs();
    }
    return $pairs;
}

function amr_amass_ward_case($hos, $name_col) {
    $expr = amr_amass_sql_utf8_bin($name_col);
    return amr_amass_ward_case_from_pairs($hos, $expr, amr_amass_active_ward_pairs());
}

function amr_amass_ward_case_from_pairs($mysqli, $expr, array $pairs) {
    $sql = "CASE $expr\n";
    foreach ($pairs as $pair) {
        $local = $pair[0];
        $label = $pair[1];
        if ($mysqli) {
            $local = mysqli_real_escape_string($mysqli, $local);
            $label = mysqli_real_escape_string($mysqli, $label);
        } else {
            $local = addslashes($local);
            $label = addslashes($label);
        }
        $sql .= "            WHEN '$local' THEN '$label'\n";
    }
    $sql .= "            ELSE $expr\n        END";
    return $sql;
}

function amr_amass_sql_drug($hos, $start, $end) {
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $ward_case = amr_amass_ward_case($hos, 'ward.name');
    $route_du = amr_amass_sql_utf8_bin('du.name1');
    $route_sp = amr_amass_sql_utf8_bin('sp.name1');
    $drug_name = "CONCAT(" . amr_amass_sql_utf8_bin('drugitems.generic_name') . ", ' ', drugitems.strength)";
    $dept = amr_amass_sql_utf8_bin('spclty.name');
    return "
SELECT
    CONCAT(\"'\", LPAD(ipt.hn, 9, '0')) AS HN,
    $drug_name AS drug_name,
    IF(medplan_ipd.sp_use = '', $route_du, $route_sp) AS route_administration,
    DATE_FORMAT(medplan_ipd.orderdate, '%d/%m/%Y') AS drug_start_date_td,
    DATE_FORMAT(medplan_ipd.offdate, '%d/%m/%Y') AS drug_stop_date_td,
    (SELECT $ward_case
     FROM ipt_order_no
     LEFT JOIN ward ON ward.ward = ipt_order_no.ward
     WHERE ipt_order_no.an = medplan_ipd.an
       AND ipt_order_no.rxdate = DATE(medplan_ipd.orderdate)
     ORDER BY order_no DESC
     LIMIT 1) AS ward_name,
    (SELECT $dept
     FROM ipt_order_no
     LEFT JOIN ward ON ward.ward = ipt_order_no.ward
     LEFT JOIN spclty ON spclty.spclty = ward.spclty
     WHERE ipt_order_no.an = medplan_ipd.an
       AND ipt_order_no.rxdate = DATE(medplan_ipd.orderdate)
     ORDER BY order_no DESC
     LIMIT 1) AS department
FROM medplan_ipd
INNER JOIN drugitems ON drugitems.icode = medplan_ipd.icode AND drugitems.antibiotic = 'Y'
LEFT JOIN ipt ON medplan_ipd.an = ipt.an
LEFT JOIN drugusage du ON du.drugusage = medplan_ipd.drugusage
LEFT JOIN sp_use sp ON sp.sp_use = medplan_ipd.sp_use
WHERE medplan_ipd.orderdate BETWEEN '$start_esc' AND '$end_esc'
ORDER BY medplan_ipd.an DESC
";
}

function amr_amass_sql_admission($hos, $start, $end, $eval_start = '', $eval_end = '') {
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    $eval_s = mysqli_real_escape_string($hos, $eval_start !== '' ? $eval_start : $start);
    $eval_e = mysqli_real_escape_string($hos, $eval_end !== '' ? $eval_end : $end);
    $ward_ad = amr_amass_ward_case($hos, 'w2.name');
    $ward_dc = amr_amass_ward_case($hos, 'w.name');
    $sex = amr_amass_sql_utf8_bin('s.name');
    return "
SELECT
    CONCAT(\"'\", LPAD(i.hn, 9, '0')) AS HN,
    $sex AS `เพศ`,
    a.age_y AS `อายุ`,
    DATE_FORMAT(i.regdate, '%d/%m/%Y') AS Admit,
    DATE_FORMAT(i.dchdate, '%d/%m/%Y') AS Discharge,
    (SELECT $ward_ad
     FROM ipt_ward_stat iw
     LEFT JOIN ward w2 ON w2.ward = iw.ward
     WHERE iw.an = i.an
     ORDER BY iw.ipt_ward_stat_id ASC
     LIMIT 1) AS ward_ad,
    $ward_dc AS ward_dc,
    ds.name AS discharge_type,
    dt.name AS dcstatus
FROM ipt i
INNER JOIN an_stat a ON a.an = i.an
LEFT JOIN dchstts ds ON ds.dchstts = i.dchstts
LEFT JOIN dchtype dt ON dt.dchtype = i.dchtype
LEFT JOIN ward w ON w.ward = i.ward
INNER JOIN patient pt ON pt.hn = i.hn
LEFT JOIN sex s ON s.code = pt.sex
WHERE i.dchdate BETWEEN '$start_esc' AND '$end_esc'
  AND i.regdate BETWEEN '$eval_s' AND '$eval_e'
  AND i.dchdate BETWEEN '$eval_s' AND '$eval_e'
ORDER BY i.an DESC
";
}

function amr_amass_dataset_source($con, $dataset) {
    if ($dataset === 'microbiology' && $con && function_exists('amr_mlab_using_direct') && amr_mlab_using_direct($con)) {
        return 'mlab';
    }
    return 'hosxp';
}

function amr_amass_fetch_rows($hos, $dataset, $start, $end, $con = null, $eval_start = '', $eval_end = '') {
    if ($dataset === 'microbiology') {
        return amr_amass_fetch_microbiology($hos, $con, $start, $end);
    }
    if (!$hos) {
        return ['error' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้', 'rows' => [], 'columns' => []];
    }
    if ($dataset === 'drug') {
        $sql = amr_amass_sql_drug($hos, $start, $end);
    } elseif ($dataset === 'admission') {
        $sql = amr_amass_sql_admission($hos, $start, $end, $eval_start, $eval_end);
    } else {
        return ['error' => 'ไม่รู้จักชุดข้อมูล', 'rows' => [], 'columns' => []];
    }
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['error' => mysqli_error($hos), 'rows' => [], 'columns' => []];
    }
    $rows = [];
    $columns = [];
    while ($r = mysqli_fetch_assoc($q)) {
        if (!$columns) {
            $columns = array_keys($r);
        }
        $out = [];
        foreach ($r as $k => $v) {
            if (is_string($v)) {
                $v = trim($v);
            }
            $out[$k] = $v;
        }
        $rows[] = $out;
    }
    return ['error' => '', 'rows' => $rows, 'columns' => $columns];
}

function amr_amass_micro_abx_columns($con) {
    $cols = [];
    if ($con) {
        $q = mysqli_query($con, "SELECT local_value, amass_key, section FROM amr_dict_rows
            WHERE category = 'antibiotic' AND active = 1 AND local_value <> ''
              AND (section LIKE '%02%' OR section LIKE '%10%')
            ORDER BY sort_order ASC, id ASC");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $code = trim((string)$r['local_value']);
                $name = trim((string)$r['amass_key']);
                if (!preg_match('/^[A-Za-z][A-Za-z0-9_]{0,12}$/', $code)) {
                    continue;
                }
                if (preg_match('/^(route_|drug_|return_|file_)/i', $name)) {
                    continue;
                }
                if (isset($cols[$code])) {
                    continue;
                }
                $cols[$code] = $name !== '' ? $name : $code;
            }
        }
    }
    if (empty($cols)) {
        foreach (['AK', 'AMX', 'AUG', 'AP', 'SAM', 'ATM', 'CZ', 'FEP', 'SCF', 'CTX', 'FOX', 'CAZ', 'CRO', 'CXM', 'C', 'CIP', 'CFX', 'DA', 'CL', 'ETP', 'E', 'GM', 'IPM', 'LVX', 'LNZ', 'MEM', 'OX', 'PG', 'TZP', 'SXT', 'T', 'VA', 'TGC', 'DOR'] as $c) {
            $cols[$c] = $c;
        }
    }
    return $cols;
}

function amr_amass_rtf_abx_aliases() {
    return [
        'AMIKACIN' => ['AK', 'Amikacin'],
        'AMPICILLIN' => ['AP', 'AM', 'Ampicillin'],
        'AMOXICIL/CLAV' => ['AUG', 'AMC', 'Amoxicillin_and_clavulanic_acid'],
        'AMOXICILL/CLAV' => ['AUG', 'AMC'],
        'AMPICILL/SULB' => ['SAM', 'Ampicillin_and_sulbactam'],
        'AZTREONAM' => ['ATM', 'Aztreonam'],
        'CEFAZOLIN' => ['CZ', 'Cefazolin'],
        'CEFEPIME' => ['FEP', 'Cefepime'],
        'CEFOPERA/SULB' => ['SCF', 'Cefoperazone_and_sulbactam'],
        'CEFOTAXIME' => ['CTX', 'Cefotaxime'],
        'CEFOTETAN' => ['CTT', 'Cefotetan'],
        'CEFOXITIN' => ['FOX', 'Cefoxitin'],
        'CEFPODOXIME' => ['CPD', 'Cefpodoxime'],
        'CEFTAROLINE' => ['CPT', 'Ceftaroline'],
        'CEFTAZIDIME' => ['CAZ', 'Ceftazidime'],
        'CEFTRIAXONE' => ['CRO', 'Ceftriaxone'],
        'CEFUROXIME' => ['CXM', 'Cefuroxime'],
        'CHLORAMPHENIC' => ['C', 'Chloramphenicol'],
        'CIPROFLOXACIN' => ['CIP', 'CFX', 'Ciprofloxacin'],
        'CLINDAMYCIN' => ['DA', 'CLI', 'Clindamycin'],
        'COLISTIN' => ['CL', 'CS', 'Colistin'],
        'DAPTOMYCIN' => ['DAP', 'Daptomycin'],
        'DORIPENEM' => ['DOR', 'Doripenem'],
        'DOXYCYCLINE' => ['DOX', 'Doxycycline'],
        'ERTAPENEM' => ['ETP', 'Ertapenem'],
        'ERYTHROMYCIN' => ['E', 'ERY', 'Erythromycin'],
        'FOSFOMYCIN' => ['FOS', 'Fosfomycin'],
        'FUSIDIC ACID' => ['FUS', 'Fusidic_acid'],
        'GENTAMICIN' => ['GM', 'GEN', 'Gentamicin'],
        'IMIPENEM' => ['IPM', 'Imipenem'],
        'LEVOFLOXACIN' => ['LVX', 'Levofloxacin'],
        'LINEZOLID' => ['LNZ', 'Linezolid'],
        'MEROPENEM' => ['MEM', 'Meropenem'],
        'MINOCYCLINE' => ['MI', 'Minocycline'],
        'MOXIFLOXACIN' => ['MXX', 'MXF', 'Moxifloxacin'],
        'NETILMICIN' => ['NET', 'Netilmicin'],
        'NITROFURANTOI' => ['NIT', 'Nitrofurantoin'],
        'OXACILLIN' => ['OX', 'Oxacillin'],
        'PENICILLIN' => ['PG', 'P', 'Penicillin_G'],
        'PIPERACI/TAZO' => ['TZP', 'Piperacillin_and_tazobactam'],
        'POLYMYXIN B' => ['PB', 'Polymyxin_B'],
        'RIFAMPIN' => ['RIF', 'RAMP', 'Rifampin'],
        'STREPTOMYCIN' => ['STR', 'Streptomycin'],
        'TRIMETHO/SULF' => ['SXT', 'Sulfamethoxazole_and_trimethoprim'],
        'TEICOPLANIN' => ['TCO', 'TEC', 'Teicoplanin'],
        'TETRACYCLINE' => ['T', 'TCY', 'Tetracycline'],
        'TIGECYCLINE' => ['TGC', 'Tigecycline'],
        'TOBRAMYCIN' => ['NN', 'TOB', 'Tobramycin'],
        'VANCOMYCIN' => ['VA', 'VAN', 'Vancomycin'],
        'NORFLOXACIN' => ['NOR', 'Norfloxacin'],
        'OFLOXACIN' => ['OFX', 'Ofloxacin'],
        'PEFLOXACIN' => ['PEF', 'Pefloxacin'],
    ];
}

function amr_amass_strip_rtf($raw) {
    $s = (string)$raw;
    $s = preg_replace('/\\\\par[d]?/i', "\n", $s);
    $s = preg_replace('/\\\\tab/i', ' ', $s);
    $s = preg_replace("/\\\\'[0-9a-fA-F]{2}/", '', $s);
    $s = preg_replace('/\\\\[a-z]+-?\\d* ?/i', '', $s);
    $s = str_replace(['{', '}'], '', $s);
    $s = html_entity_decode($s, ENT_QUOTES, 'UTF-8');
    $s = preg_replace("/\\r\\n|\\r/", "\n", $s);
    $s = preg_replace('/[ \\t]+/', ' ', $s);
    $s = preg_replace('/\\n[ \\t]*/', "\n", $s);
    return trim($s);
}

function amr_amass_parse_micro_ast($text, array $abx_cols) {
    $names_for = [];
    foreach ($abx_cols as $code => $name) {
        $list = [];
        if (strlen($code) >= 3) {
            $list[] = $code;
        }
        if ($name !== '' && strlen($name) >= 3) {
            $list[] = str_replace('_', ' ', $name);
            $list[] = $name;
        }
        $names_for[$code] = $list;
    }
    foreach (amr_amass_rtf_abx_aliases() as $rtf => $codes) {
        foreach ($abx_cols as $code => $name) {
            if (in_array($code, $codes, true) || in_array($name, $codes, true)) {
                $names_for[$code][] = $rtf;
            }
        }
    }
    $ast = [];
    foreach ($abx_cols as $code => $_n) {
        $ast[$code] = '';
        $tried = [];
        $cands = $names_for[$code] ?? [];
        usort($cands, function ($a, $b) {
            return strlen($b) - strlen($a);
        });
        foreach ($cands as $n) {
            $n = trim((string)$n);
            if ($n === '' || isset($tried[$n]) || strlen($n) < 3) {
                continue;
            }
            $tried[$n] = true;
            $pat = '/' . preg_quote($n, '/') . '[\. ]*(?:[<>]=?\s*)?[\d.\/]*\s*(S|I|R|NS|-)\b/i';
            if (preg_match($pat, $text, $m)) {
                $v = strtoupper($m[1]);
                if ($v !== '-') {
                    $ast[$code] = $v;
                }
                break;
            }
        }
    }
    return $ast;
}

function amr_amass_parse_micro_text($text, array $abx_cols) {
    $specimen = '';
    $organism = '';
    if (preg_match('/SPECIMEN\\s*:\\s*([^\\n]+)/i', $text, $m)) {
        $specimen = trim($m[1]);
        $specimen = preg_replace('/\\s*-{3,}.*$/', '', $specimen);
        $specimen = trim($specimen);
    } elseif (preg_match('/Blood-Hemoculture/i', $text)) {
        $specimen = 'Blood-Hemoculture';
    } elseif (preg_match('/Urine\\s*\\(MSU/i', $text)) {
        $specimen = 'Urine (MSU,Void)';
    } elseif (preg_match('/SPECIMEN:\\s*Sputum|\\bSputum\\b/i', $text)) {
        $specimen = 'Sputum';
    }
    if (preg_match('/CULTURE:\\s*(?:\\d+\\.\\s*)?([^\\n]+)/i', $text, $m)) {
        $organism = trim($m[1]);
        $organism = preg_replace('/\\s+NOTE:.*$/i', '', $organism);
    } elseif (preg_match('/No\\s+Growth[^\\n]*/i', $text, $m)) {
        $organism = trim($m[0]);
        $organism = preg_replace('/\\s*\\(.*$/', '', $organism);
        $organism = trim($organism);
    } else {
        foreach (preg_split('/\\n+/', $text) as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if (preg_match('/\\.(MDR|MRSA|MRSE|VRE|ESBL|CRE|CRAB|CRPA)/i', $line)
                || preg_match('/\\b(pneumoniae|coli|aureus|baumannii|aeruginosa|faecium|faecalis|cloacae)\\b/i', $line)
            ) {
                $organism = $line;
                break;
            }
        }
    }
    return [
        'SPECIMEN' => $specimen,
        'CSOURCE' => $specimen,
        'CRESULT' => $organism,
        'ast' => amr_amass_parse_micro_ast($text, $abx_cols),
    ];
}

function amr_amass_norm_drug_key($s) {
    return strtolower(preg_replace('/[^a-z0-9]+/i', '', (string)$s));
}

function amr_amass_mlab_drug_code_map() {
    static $map = null;
    if ($map !== null) {
        return $map;
    }
    $map = [
        'amikacin' => 'AK',
        'ampicillin' => 'AP',
        'amoxicillinclavu' => 'AUG',
        'amoxicillinclavulanicacid' => 'AUG',
        'ampicillinsulbac' => 'SAM',
        'ampicillinsulbactam' => 'SAM',
        'aztreonam' => 'ATM',
        'cefazolin' => 'CZ',
        'cefepime' => 'FEP',
        'cefoperazonesulbac' => 'SCF',
        'cefoperazonesulbactam' => 'SCF',
        'cefotaxime' => 'CTX',
        'cefoxitin' => 'FOX',
        'ceftazidime' => 'CAZ',
        'ceftriaxone' => 'CRO',
        'cefuroxime' => 'CXM',
        'chloramphenicol' => 'C',
        'ciprofloxacin' => 'CIP',
        'clindamycin' => 'DA',
        'colistin' => 'CL',
        'doripenem' => 'DOR',
        'ertapenem' => 'ETP',
        'erythromycin' => 'E',
        'fosfomycin' => 'FOS',
        'gentamicin' => 'GM',
        'imipenem' => 'IPM',
        'levofloxacin' => 'LVX',
        'linezolid' => 'LNZ',
        'meropenem' => 'MEM',
        'minocycline' => 'MI',
        'moxifloxacin' => 'MXX',
        'nitrofurantoin' => 'NIT',
        'norfloxacin' => 'NOR',
        'oxacillin' => 'OX',
        'penicillin' => 'PG',
        'penicilllng' => 'PG',
        'piperacillintazobac' => 'TZP',
        'piperacillintazobactam' => 'TZP',
        'rifampicin' => 'RIF',
        'rifampin' => 'RIF',
        'teicoplanin' => 'TCO',
        'tetracycline' => 'T',
        'tigecycline' => 'TGC',
        'tobramycin' => 'NN',
        'trimethosulfa' => 'SXT',
        'trimethoprimsulfa' => 'SXT',
        'cotrimoxazole' => 'SXT',
        'vancomycin' => 'VA',
    ];
    foreach (amr_amass_rtf_abx_aliases() as $rtf => $codes) {
        $nk = amr_amass_norm_drug_key($rtf);
        if ($nk !== '' && !isset($map[$nk]) && !empty($codes[0])) {
            $map[$nk] = $codes[0];
        }
    }
    return $map;
}

function amr_amass_mlab_map_ast_code($drug, array $abx_cols) {
    $key = amr_amass_norm_drug_key($drug);
    if ($key === '') {
        return '';
    }
    $up = strtoupper(trim((string)$drug));
    if (isset($abx_cols[$up])) {
        return $up;
    }
    $alias = amr_amass_mlab_drug_code_map();
    $want = $alias[$key] ?? '';
    if ($want === '') {
        foreach ($alias as $ak => $code) {
            if (strlen($key) < 6 || strlen($ak) < 6) {
                continue;
            }
            if (strpos($key, $ak) === 0 || strpos($ak, $key) === 0) {
                $want = $code;
                break;
            }
        }
    }
    $cands = [];
    if ($want !== '') {
        $cands[] = $want;
        foreach (amr_amass_rtf_abx_aliases() as $rtf => $codes) {
            if (!in_array($want, $codes, true)) {
                continue;
            }
            $rtf_key = amr_amass_norm_drug_key($rtf);
            foreach ($codes as $c) {
                if (!is_string($c) || !isset($abx_cols[$c])) {
                    continue;
                }
                $name_key = amr_amass_norm_drug_key($abx_cols[$c]);
                if ($name_key === $key || $name_key === $rtf_key
                    || (strlen($name_key) >= 6 && (strpos($key, $name_key) === 0 || strpos($name_key, $key) === 0))
                    || (strlen($rtf_key) >= 6 && (strpos($key, $rtf_key) === 0 || strpos($rtf_key, $key) === 0))
                ) {
                    $cands[] = $c;
                }
            }
        }
    }
    foreach ($cands as $c) {
        if (isset($abx_cols[$c])) {
            return $c;
        }
    }
    foreach ($abx_cols as $code => $name) {
        $nk = amr_amass_norm_drug_key($name);
        $ck = amr_amass_norm_drug_key($code);
        if ($nk !== '' && $key === $nk) {
            return $code;
        }
        if ($ck !== '' && $key === $ck) {
            return $code;
        }
        if ($want !== '' && $nk !== '' && amr_amass_norm_drug_key($want) === $nk) {
            return $code;
        }
    }
    return '';
}

function amr_amass_mlab_hn_cell($hn) {
    $d = preg_replace('/\D+/', '', (string)$hn);
    if ($d === '' || preg_match('/^0+$/', $d)) {
        return '';
    }
    return "'" . str_pad(substr($d, -9), 9, '0', STR_PAD_LEFT);
}

function amr_amass_fetch_microbiology_mlab($con, $start, $end) {
    if (!function_exists('amr_mlab_load_labs')) {
        require_once __DIR__ . '/amr_mlab_helper.php';
    }
    if (function_exists('amr_mlab_ensure_tables')) {
        amr_mlab_ensure_tables($con);
    }
    $abx = amr_amass_micro_abx_columns($con);
    $columns = array_merge(['HN9_HIS', 'DATE_DATA', 'CDATE', 'SPECIMEN', 'CSOURCE', 'CRESULT'], array_keys($abx));
    $loaded = amr_mlab_load_labs($con, $start, $end);
    if ($loaded['error'] !== '') {
        return ['error' => $loaded['error'], 'rows' => [], 'columns' => $columns];
    }
    $rows = [];
    foreach ($loaded['labs'] as $lab) {
        $specimen = trim((string)($lab['specimen'] ?? ''));
        $organism = trim((string)($lab['organism'] ?? ''));
        if ($organism === '') {
            foreach ($lab['ast'] ?? [] as $a) {
                $o = trim((string)($a['organism'] ?? ''));
                if ($o !== '') {
                    $organism = $o;
                    break;
                }
            }
        }
        if ($specimen === '' && $organism === '') {
            continue;
        }
        $od = substr((string)($lab['order_date'] ?? ''), 0, 10);
        if ($od === '' || $od === '0000-00-00') {
            $od = substr((string)($lab['report_date'] ?? ''), 0, 10);
        }
        $date = ($od !== '' && $od !== '0000-00-00') ? date('d/m/Y', strtotime($od)) : '';
        $cresult = $organism !== '' ? $organism : 'No growth';
        $row = [
            'HN9_HIS' => amr_amass_mlab_hn_cell($lab['hn'] ?? ''),
            'DATE_DATA' => $date,
            'CDATE' => $date,
            'SPECIMEN' => $specimen,
            'CSOURCE' => $specimen,
            'CRESULT' => $cresult,
        ];
        foreach ($abx as $code => $_n) {
            $row[$code] = '';
        }
        foreach ($lab['ast'] ?? [] as $a) {
            $sir = strtoupper(substr(trim((string)($a['sir'] ?? '')), 0, 1));
            if (!in_array($sir, ['S', 'I', 'R'], true)) {
                continue;
            }
            $code = amr_amass_mlab_map_ast_code($a['drug'] ?? '', $abx);
            if ($code === '' || !array_key_exists($code, $row)) {
                continue;
            }
            $prev = strtoupper((string)($row[$code] ?? ''));
            if ($prev === '' || ($sir === 'R') || ($sir === 'I' && $prev === 'S')) {
                $row[$code] = $sir;
            }
        }
        $rows[] = $row;
    }
    return ['error' => '', 'rows' => $rows, 'columns' => $columns];
}

function amr_amass_sql_microbiology($hos, $start, $end) {
    $start_esc = mysqli_real_escape_string($hos, $start);
    $end_esc = mysqli_real_escape_string($hos, $end);
    return "
SELECT
    CONCAT(\"'\", LPAD(COALESCE(NULLIF(lh.hn, ''), i.hn), 9, '0')) AS HN9_HIS,
    DATE_FORMAT(lh.order_date, '%d/%m/%Y') AS DATE_DATA,
    lh.result_rtf AS result_rtf
FROM lab_head lh
LEFT JOIN ipt i ON i.an = lh.vn
WHERE lh.order_date BETWEEN '$start_esc' AND '$end_esc'
  AND lh.result_rtf IS NOT NULL
  AND lh.result_rtf <> ''
  AND (
        lh.result_rtf LIKE '%SPECIMEN%'
     OR lh.result_rtf LIKE '%Hemoculture%'
     OR lh.result_rtf LIKE '%No growth%'
     OR lh.result_rtf LIKE '%No Growth%'
     OR lh.result_rtf LIKE '%CULTURE:%'
     OR lh.result_rtf LIKE '%CRESULT%'
  )
ORDER BY lh.order_date, lh.lab_order_number
";
}

function amr_amass_fetch_microbiology($hos, $con, $start, $end) {
    if (amr_amass_dataset_source($con, 'microbiology') === 'mlab') {
        return amr_amass_fetch_microbiology_mlab($con, $start, $end);
    }
    if (!$hos) {
        return ['error' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้', 'rows' => [], 'columns' => []];
    }
    $abx = amr_amass_micro_abx_columns($con);
    $sql = amr_amass_sql_microbiology($hos, $start, $end);
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['error' => mysqli_error($hos), 'rows' => [], 'columns' => []];
    }
    $columns = array_merge(['HN9_HIS', 'DATE_DATA', 'CDATE', 'SPECIMEN', 'CSOURCE', 'CRESULT'], array_keys($abx));
    $rows = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $parsed = amr_amass_parse_micro_text(amr_amass_strip_rtf($r['result_rtf'] ?? ''), $abx);
        if ($parsed['CRESULT'] === '' && $parsed['SPECIMEN'] === '') {
            continue;
        }
        $date = $r['DATE_DATA'] ?? '';
        $row = [
            'HN9_HIS' => $r['HN9_HIS'] ?? '',
            'DATE_DATA' => $date,
            'CDATE' => $date,
            'SPECIMEN' => $parsed['SPECIMEN'],
            'CSOURCE' => $parsed['CSOURCE'] !== '' ? $parsed['CSOURCE'] : $parsed['SPECIMEN'],
            'CRESULT' => $parsed['CRESULT'],
        ];
        foreach ($abx as $code => $_n) {
            $row[$code] = $parsed['ast'][$code] ?? '';
        }
        $rows[] = $row;
    }
    return ['error' => '', 'rows' => $rows, 'columns' => $columns];
}

function amr_amass_upload_dir() {
    $dir = __DIR__ . '/uploads/amass';
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }
    @chmod($dir, 0777);
    $rd = $dir . '/ResultData';
    if (!is_dir($rd)) {
        @mkdir($rd, 0777, true);
    }
    @chmod($rd, 0777);
    $idx = $dir . '/index.php';
    if (!is_file($idx)) {
        @file_put_contents($idx, "<?php header('HTTP/1.0 403 Forbidden');\n");
    }
    return $dir;
}

function amr_amass_cover_defaults() {
    return [
        'country' => 'Thailand',
        'hospital_name' => '10699 Sakaeo Crown Prince Hospital',
        'hospital_name_th' => 'รพ.สมเด็จพระยุพราชสระแก้ว',
        'contact_person' => 'Atipol Klaipaksi',
        'contact_address' => '283 Suwannasom Road Sakaeo Province',
        'contact_email' => 'atipolklaipaksi@gmail.com',
        'notes_on_the_cover' => 'HIS:HOSXP & LIS:M-LAB',
        'notes_on_fungal_identification' => '',
    ];
}

function amr_amass_default_hospital_name() {
    return amr_amass_cover_defaults()['hospital_name'];
}

function amr_amass_settings_path() {
    return amr_amass_upload_dir() . '/settings.json';
}

function amr_amass_load_settings() {
    $path = amr_amass_settings_path();
    if (!is_file($path)) {
        return [];
    }
    $raw = json_decode((string)file_get_contents($path), true);
    return is_array($raw) ? $raw : [];
}

function amr_amass_cover_info($con = null) {
    $defaults = amr_amass_cover_defaults();
    $data = amr_amass_load_settings();
    $out = $defaults;
    foreach ($defaults as $k => $v) {
        $cur = trim((string)($data[$k] ?? ''));
        if ($cur !== '') {
            $out[$k] = $cur;
        }
    }
    $stored_name = trim((string)($data['hospital_name'] ?? ''));
    if ($stored_name !== '' && preg_match('/[\x{0E00}-\x{0E7F}]/u', $stored_name)) {
        if (trim((string)($data['hospital_name_th'] ?? '')) === '') {
            $out['hospital_name_th'] = $stored_name;
        }
        $out['hospital_name'] = $defaults['hospital_name'];
    }
    if ($out['hospital_name'] === '' || $out['hospital_name'] === 'โรงพยาบาลท่าม่วง') {
        $out['hospital_name'] = $defaults['hospital_name'];
    }
    if ($con && trim((string)($data['hospital_name'] ?? '')) === '') {
        $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = 'amass_hospital_name' LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            $dbn = trim((string)$r['config_value']);
            if ($dbn !== '' && $dbn !== 'โรงพยาบาลท่าม่วง' && !preg_match('/[\x{0E00}-\x{0E7F}]/u', $dbn)) {
                $out['hospital_name'] = $dbn;
            } elseif ($dbn !== '' && preg_match('/[\x{0E00}-\x{0E7F}]/u', $dbn) && trim((string)($data['hospital_name_th'] ?? '')) === '') {
                $out['hospital_name_th'] = $dbn;
            }
        }
    }
    return $out;
}

function amr_amass_hospital_name($con = null) {
    return amr_amass_cover_info($con)['hospital_name'];
}

function amr_amass_patch_report1_cover(array $cover) {
    $path = amr_amass_results_dir() . '/ver3_Report1_page3_results.csv';
    if (!is_file($path)) {
        $path = amr_amass_results_dir() . '/Report1_page3_results.csv';
    }
    if (!is_file($path)) {
        return;
    }
    $rows = amr_amass_read_csv_assoc($path);
    $map = [
        'Hospital_name' => $cover['hospital_name'] ?? '',
        'Country' => $cover['country'] ?? '',
        'Contact_person' => $cover['contact_person'] ?? '',
        'Contact_address' => $cover['contact_address'] ?? '',
        'Contact_email' => $cover['contact_email'] ?? '',
        'notes_on_the_cover' => $cover['notes_on_the_cover'] ?? '',
        'notes_on_fungal_identification' => $cover['notes_on_fungal_identification'] ?? '',
    ];
    $found = [];
    foreach ($rows as $i => $row) {
        $p = $row['Parameters'] ?? '';
        if (($row['Type_of_data_file'] ?? '') === 'microbiology_data' && isset($map[$p])) {
            $rows[$i]['Values'] = $map[$p];
            $found[$p] = true;
        }
    }
    foreach ($map as $param => $val) {
        if (empty($found[$param])) {
            $rows[] = [
                'Type_of_data_file' => 'microbiology_data',
                'Parameters' => $param,
                'Values' => $val,
            ];
        }
    }
    $fh = @fopen($path, 'wb');
    if (!$fh) {
        return;
    }
    fwrite($fh, "\xEF\xBB\xBF");
    fputcsv($fh, ['Type_of_data_file', 'Parameters', 'Values']);
    foreach ($rows as $row) {
        fputcsv($fh, [$row['Type_of_data_file'] ?? '', $row['Parameters'] ?? '', $row['Values'] ?? '']);
    }
    fclose($fh);
    @chmod($path, 0666);
}

function amr_amass_save_cover($con, array $input) {
    $defaults = amr_amass_cover_defaults();
    $data = amr_amass_load_settings();
    foreach ($defaults as $k => $_v) {
        if (array_key_exists($k, $input)) {
            $data[$k] = trim((string)$input[$k]);
        }
    }
    if (trim((string)($data['hospital_name'] ?? '')) === '') {
        $data['hospital_name'] = $defaults['hospital_name'];
    }
    if (trim((string)($data['country'] ?? '')) === '') {
        $data['country'] = $defaults['country'];
    }
    $path = amr_amass_settings_path();
    @file_put_contents($path, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    @chmod($path, 0666);
    if ($con) {
        $esc = mysqli_real_escape_string($con, $data['hospital_name']);
        @mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('amass_hospital_name', '$esc')
            ON DUPLICATE KEY UPDATE config_value = '$esc'");
    }
    amr_amass_patch_report1_cover($data);
    return amr_amass_cover_info($con);
}

function amr_amass_save_hospital_name($con, $name) {
    return amr_amass_save_cover($con, ['hospital_name' => $name])['hospital_name'];
}

function amr_amass_canonical_filename($dataset) {
    $sets = amr_amass_datasets();
    return $sets[$dataset]['filename'] ?? '';
}

function amr_amass_guess_dataset($filename) {
    $n = strtolower((string)$filename);
    if (strpos($n, 'dictionary') !== false) {
        return '';
    }
    if (strpos($n, 'microbiology_data') !== false) {
        return 'microbiology';
    }
    if (strpos($n, 'hospital_admission_data') !== false || strpos($n, 'admission_data') !== false) {
        return 'admission';
    }
    if (strpos($n, 'drug_data') !== false) {
        return 'drug';
    }
    return '';
}

function amr_amass_save_upload($dataset, $tmp, $orig_name) {
    $dataset = trim((string)$dataset);
    if ($dataset === '') {
        $dataset = amr_amass_guess_dataset($orig_name);
    }
    $canon = amr_amass_canonical_filename($dataset);
    if ($canon === '') {
        return ['ok' => false, 'error' => 'ระบุประเภทไฟล์ไม่ได้ — ใช้ชื่อ drug_data / hospital_admission_data / microbiology_data'];
    }
    $dir = amr_amass_upload_dir();
    $dest = $dir . '/' . $canon;
    if (!is_uploaded_file($tmp) && !is_file($tmp)) {
        return ['ok' => false, 'error' => 'ไม่พบไฟล์อัปโหลด'];
    }
    $ok = is_uploaded_file($tmp) ? @move_uploaded_file($tmp, $dest) : @copy($tmp, $dest);
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกไฟล์ไม่สำเร็จ'];
    }
    @unlink($dir . '/' . preg_replace('/\.xlsx$/i', '.csv', $canon));
    amr_amass_touch_source($dataset, 'upload', $orig_name);
    return [
        'ok' => true,
        'dataset' => $dataset,
        'filename' => $canon,
        'bytes' => (int)@filesize($dest),
    ];
}

function amr_amass_source_path() {
    return amr_amass_upload_dir() . '/source.json';
}

function amr_amass_touch_source($dataset, $source, $note = '', $start = '', $end = '') {
    $path = amr_amass_source_path();
    $data = [];
    if (is_file($path)) {
        $raw = json_decode((string)file_get_contents($path), true);
        if (is_array($raw)) {
            $data = $raw;
        }
    }
    $fn = amr_amass_canonical_filename($dataset);
    $dir = amr_amass_upload_dir();
    $xlsx = $dir . '/' . $fn;
    $csv = $dir . '/' . amr_amass_csv_filename($dataset);
    $data[$dataset] = [
        'source' => $source,
        'note' => $note,
        'start_date' => $start,
        'end_date' => $end,
        'updated_at' => date('Y-m-d H:i:s'),
        'filename' => $fn,
        'exists' => is_file($xlsx) || is_file($csv),
    ];
    @file_put_contents($path, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    @chmod($path, 0666);
}

function amr_amass_staged_status() {
    $dir = amr_amass_upload_dir();
    $src = [];
    if (is_file(amr_amass_source_path())) {
        $raw = json_decode((string)file_get_contents(amr_amass_source_path()), true);
        if (is_array($raw)) {
            $src = $raw;
        }
    }
    $out = [];
    foreach (amr_amass_datasets() as $key => $meta) {
        $fn = $meta['filename'];
        $xlsx = $dir . '/' . $fn;
        $csv = $dir . '/' . preg_replace('/\.xlsx$/i', '.csv', $fn);
        $path = is_file($csv) ? $csv : $xlsx;
        $exists = is_file($path);
        $out[$key] = [
            'filename' => $fn,
            'label' => $meta['label'],
            'ready' => !empty($meta['ready']),
            'exists' => $exists,
            'bytes' => $exists ? (int)filesize($path) : 0,
            'updated_at' => $exists ? date('Y-m-d H:i:s', filemtime($path)) : '',
            'source' => $src[$key]['source'] ?? ($exists ? 'upload' : ''),
            'format' => $exists ? strtolower(pathinfo($path, PATHINFO_EXTENSION)) : '',
            'start_date' => $src[$key]['start_date'] ?? '',
            'end_date' => $src[$key]['end_date'] ?? '',
        ];
    }
    return $out;
}

function amr_amass_month_spans($start, $end) {
    $spans = [];
    $from = strtotime($start . ' 00:00:00');
    $to = strtotime($end . ' 00:00:00');
    if ($from === false || $to === false || $from > $to) {
        return $spans;
    }
    while ($from <= $to) {
        $cs = date('Y-m-d', $from);
        $last = strtotime(date('Y-m-t', $from));
        if ($last > $to) {
            $last = $to;
        }
        $spans[] = [$cs, date('Y-m-d', $last)];
        $from = strtotime('+1 day', $last);
    }
    return $spans;
}

function amr_amass_xlsx_escape($value) {
    $s = (string)$value;
    $s = preg_replace('/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/', '', $s);
    return str_replace(
        ['&', '<', '>', '"', "'"],
        ['&amp;', '&lt;', '&gt;', '&quot;', '&apos;'],
        $s
    );
}

function amr_amass_xlsx_row(array $values, $rownum) {
    $xml = '<row r="' . (int)$rownum . '">';
    $i = 0;
    foreach ($values as $v) {
        $col = '';
        $n = $i;
        do {
            $col = chr(65 + ($n % 26)) . $col;
            $n = intdiv($n, 26) - 1;
        } while ($n >= 0);
        $xml .= '<c r="' . $col . $rownum . '" t="inlineStr"><is><t xml:space="preserve">'
            . amr_amass_xlsx_escape($v) . '</t></is></c>';
        $i++;
    }
    return $xml . '</row>';
}

function amr_amass_zip_crc($path_or_data, $is_file) {
    $hex = $is_file ? hash_file('crc32b', $path_or_data) : hash('crc32b', $path_or_data);
    return hexdec($hex);
}

function amr_amass_zip_write($path, array $entries) {
    $tmp_zip = $path . '.tmpzip';
    @unlink($tmp_zip);
    $fh = @fopen($tmp_zip, 'wb');
    if (!$fh) {
        return false;
    }
    $cdir = '';
    $offset = 0;
    $count = 0;
    foreach ($entries as $name => $src) {
        $name = str_replace('\\', '/', (string)$name);
        $is_file = is_array($src) && !empty($src['file']);
        $file = $is_file ? $src['file'] : '';
        $data = $is_file ? '' : (is_array($src) ? (string)($src['data'] ?? '') : (string)$src);
        $len = $is_file ? (int)filesize($file) : strlen($data);
        $crc = $is_file ? amr_amass_zip_crc($file, true) : amr_amass_zip_crc($data, false);
        $nlen = strlen($name);
        $local = pack('VvvvvvVVVvv', 0x04034b50, 20, 0, 0, 0, 0, $crc, $len, $len, $nlen, 0) . $name;
        fwrite($fh, $local);
        if ($is_file) {
            $in = fopen($file, 'rb');
            if ($in) {
                stream_copy_to_stream($in, $fh);
                fclose($in);
            }
        } else {
            fwrite($fh, $data);
        }
        $cdir .= pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0, 0, 0, 0, $crc, $len, $len, $nlen, 0, 0, 0, 0, 0, $offset) . $name;
        $offset += strlen($local) + $len;
        $count++;
    }
    $eocd = pack('VvvvvVVv', 0x06054b50, 0, 0, $count, $count, strlen($cdir), $offset, 0);
    fwrite($fh, $cdir . $eocd);
    fclose($fh);
    if (is_file($path)) {
        @unlink($path);
    }
    if (!@rename($tmp_zip, $path)) {
        @unlink($tmp_zip);
        return false;
    }
    @chmod($path, 0666);
    return is_file($path) && filesize($path) > 0;
}

function amr_amass_xlsx_parts() {
    $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
        . ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>';
    $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        . '</Relationships>';
    $wbrels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        . '</Relationships>';
    $types = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        . '</Types>';
    return [$types, $rels, $workbook, $wbrels];
}

function amr_amass_write_xlsx($path, array $columns, array $rows) {
    $tmp = $path . '.sheet.xml';
    $sh = @fopen($tmp, 'wb');
    if (!$sh) {
        return false;
    }
    fwrite($sh, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>');
    $ri = 1;
    fwrite($sh, amr_amass_xlsx_row($columns, $ri++));
    foreach ($rows as $row) {
        $vals = [];
        foreach ($columns as $col) {
            $vals[] = is_array($row) ? ($row[$col] ?? '') : '';
        }
        fwrite($sh, amr_amass_xlsx_row($vals, $ri++));
    }
    fwrite($sh, '</sheetData></worksheet>');
    fclose($sh);
    list($types, $rels, $workbook, $wbrels) = amr_amass_xlsx_parts();
    $ok = amr_amass_zip_write($path, [
        '[Content_Types].xml' => $types,
        '_rels/.rels' => $rels,
        'xl/workbook.xml' => $workbook,
        'xl/_rels/workbook.xml.rels' => $wbrels,
        'xl/worksheets/sheet1.xml' => ['file' => $tmp],
    ]);
    @unlink($tmp);
    return $ok;
}

function amr_amass_export_stamp($start, $end) {
    $s = preg_replace('/\D+/', '', (string)$start);
    $e = preg_replace('/\D+/', '', (string)$end);
    if (strlen($s) >= 8 && strlen($e) >= 8) {
        return substr($s, 0, 8) . '_' . substr($e, 0, 8);
    }
    return date('Ymd');
}

function amr_amass_csv_to_xlsx($csv_path, $xlsx_path) {
    $in = @fopen($csv_path, 'rb');
    if (!$in) {
        return false;
    }
    $bom = fread($in, 3);
    if ($bom !== "\xEF\xBB\xBF") {
        rewind($in);
    }
    $header = fgetcsv($in);
    if (!is_array($header) || $header === []) {
        fclose($in);
        return false;
    }
    $header = array_map(function ($h) {
        $h = preg_replace('/^\xEF\xBB\xBF/', '', (string)$h);
        return trim($h);
    }, $header);
    $tmp = $xlsx_path . '.sheet.xml';
    $sh = @fopen($tmp, 'wb');
    if (!$sh) {
        fclose($in);
        return false;
    }
    fwrite($sh, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>');
    $ri = 1;
    fwrite($sh, amr_amass_xlsx_row($header, $ri++));
    $n = count($header);
    while (($row = fgetcsv($in)) !== false) {
        $vals = [];
        for ($i = 0; $i < $n; $i++) {
            $vals[] = isset($row[$i]) ? $row[$i] : '';
        }
        fwrite($sh, amr_amass_xlsx_row($vals, $ri++));
    }
    fclose($in);
    fwrite($sh, '</sheetData></worksheet>');
    fclose($sh);
    list($types, $rels, $workbook, $wbrels) = amr_amass_xlsx_parts();
    $ok = amr_amass_zip_write($xlsx_path, [
        '[Content_Types].xml' => $types,
        '_rels/.rels' => $rels,
        'xl/workbook.xml' => $workbook,
        'xl/_rels/workbook.xml.rels' => $wbrels,
        'xl/worksheets/sheet1.xml' => ['file' => $tmp],
    ]);
    @unlink($tmp);
    if ($ok) {
        @chmod($xlsx_path, 0666);
    }
    return $ok;
}

function amr_amass_ensure_xlsx($dataset) {
    $fn = amr_amass_canonical_filename($dataset);
    if ($fn === '') {
        return '';
    }
    $dir = amr_amass_upload_dir();
    $xlsx = $dir . '/' . $fn;
    $csv = $dir . '/' . amr_amass_csv_filename($dataset);
    if (is_file($xlsx) && (!is_file($csv) || filemtime($xlsx) >= filemtime($csv) - 1)) {
        return $xlsx;
    }
    if (is_file($csv) && amr_amass_csv_to_xlsx($csv, $xlsx)) {
        return $xlsx;
    }
    return is_file($xlsx) ? $xlsx : '';
}

function amr_amass_send_file($path, $download_name, $ctype, $delete_after = false) {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: ' . $ctype);
    header('Content-Disposition: attachment; filename="' . str_replace(['"', "\r", "\n"], '', $download_name) . '"');
    header('Content-Length: ' . filesize($path));
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    readfile($path);
    if ($delete_after) {
        @unlink($path);
    }
    exit;
}

function amr_amass_extract_to_stage($hos, $con, $dataset, $start, $end) {
    $sets = amr_amass_datasets();
    if (!isset($sets[$dataset]) || empty($sets[$dataset]['ready'])) {
        return ['ok' => false, 'error' => 'ชุดข้อมูลนี้ยังไม่พร้อม'];
    }
    $dir = amr_amass_upload_dir();
    if (!is_dir($dir) || !is_writable($dir)) {
        return ['ok' => false, 'error' => 'โฟลเดอร์ uploads/amass ไม่มีสิทธิ์เขียน'];
    }
    $fn = $sets[$dataset]['filename'];
    $dest = $dir . '/' . $fn;
    $tmp = $dir . '/.' . $dataset . '_' . getmypid() . '_sheet.xml';
    $sh = @fopen($tmp, 'wb');
    if (!$sh) {
        return ['ok' => false, 'error' => 'เปิดไฟล์ชั่วคราวไม่ได้ใน uploads/amass'];
    }
    fwrite($sh, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>');
    $columns = $sets[$dataset]['columns'];
    $header_done = false;
    $count = 0;
    $ri = 1;
    if ($dataset === 'microbiology') {
        $abx = amr_amass_micro_abx_columns($con);
        $columns = array_merge(['HN9_HIS', 'DATE_DATA', 'CDATE', 'SPECIMEN', 'CSOURCE', 'CRESULT'], array_keys($abx));
        fwrite($sh, amr_amass_xlsx_row($columns, $ri++));
        $header_done = true;
    }
    foreach (amr_amass_month_spans($start, $end) as $span) {
        $part = amr_amass_fetch_rows($hos, $dataset, $span[0], $span[1], $con, $start, $end);
        if (!empty($part['error'])) {
            fclose($sh);
            @unlink($tmp);
            return ['ok' => false, 'error' => $part['error'], 'start' => $span[0], 'end' => $span[1]];
        }
        if (!empty($part['columns'])) {
            $columns = $part['columns'];
        }
        if (!$header_done) {
            fwrite($sh, amr_amass_xlsx_row($columns, $ri++));
            $header_done = true;
        }
        foreach ($part['rows'] as $row) {
            $vals = [];
            foreach ($columns as $col) {
                $vals[] = $row[$col] ?? '';
            }
            fwrite($sh, amr_amass_xlsx_row($vals, $ri++));
            $count++;
        }
        unset($part);
    }
    if (!$header_done) {
        fwrite($sh, amr_amass_xlsx_row($columns, $ri++));
    }
    fwrite($sh, '</sheetData></worksheet>');
    fclose($sh);
    list($types, $rels, $workbook, $wbrels) = amr_amass_xlsx_parts();
    $ok = amr_amass_zip_write($dest, [
        '[Content_Types].xml' => $types,
        '_rels/.rels' => $rels,
        'xl/workbook.xml' => $workbook,
        'xl/_rels/workbook.xml.rels' => $wbrels,
        'xl/worksheets/sheet1.xml' => ['file' => $tmp],
    ]);
    @unlink($tmp);
    if (!$ok) {
        return ['ok' => false, 'error' => 'เขียนไฟล์ Excel ไม่สำเร็จ'];
    }
    $src = amr_amass_dataset_source($con, $dataset);
    $src_note = $src === 'mlab'
        ? ('mLAB ' . $start . ' – ' . $end)
        : ('HOSxP ' . $start . ' – ' . $end);
    amr_amass_touch_source($dataset, $src, $src_note, $start, $end);
    return [
        'ok' => true,
        'dataset' => $dataset,
        'filename' => $fn,
        'row_count' => $count,
        'bytes' => (int)@filesize($dest),
        'start_date' => $start,
        'end_date' => $end,
    ];
}

function amr_amass_csv_filename($dataset) {
    $fn = amr_amass_canonical_filename($dataset);
    return $fn !== '' ? preg_replace('/\.xlsx$/i', '.csv', $fn) : '';
}

function amr_amass_put_csv($path, array $columns, array $rows) {
    $fh = @fopen($path, 'wb');
    if (!$fh) {
        return false;
    }
    fwrite($fh, "\xEF\xBB\xBF");
    fputcsv($fh, $columns);
    foreach ($rows as $row) {
        $line = [];
        foreach ($columns as $col) {
            $line[] = is_array($row) ? ($row[$col] ?? '') : '';
        }
        fputcsv($fh, $line);
    }
    fclose($fh);
    @chmod($path, 0666);
    return is_file($path);
}

function amr_amass_chunk_dir() {
    $dir = amr_amass_deny_dir(amr_amass_upload_dir() . '/chunks');
    @chmod($dir, 0777);
    return $dir;
}

function amr_amass_chunk_path($dataset, $start) {
    $ym = date('Y-m', strtotime($start));
    return amr_amass_chunk_dir() . '/' . $dataset . '_' . $ym . '.csv';
}

function amr_amass_reset_chunks($dataset = '') {
    $dir = amr_amass_chunk_dir();
    $pat = $dataset !== ''
        ? $dir . '/' . preg_replace('/[^a-z_]/', '', $dataset) . '_*.csv'
        : $dir . '/*.csv';
    $n = 0;
    foreach (glob($pat) ?: [] as $f) {
        if (@unlink($f)) {
            $n++;
        }
    }
    return $n;
}

function amr_amass_extract_chunk($hos, $con, $dataset, $start, $end, $eval_start = '', $eval_end = '') {
    $sets = amr_amass_datasets();
    if (!isset($sets[$dataset]) || empty($sets[$dataset]['ready'])) {
        return ['ok' => false, 'error' => 'ชุดข้อมูลนี้ยังไม่พร้อม'];
    }
    $dir = amr_amass_chunk_dir();
    if (!is_dir($dir) || !is_writable($dir)) {
        return ['ok' => false, 'error' => 'โฟลเดอร์ chunks ไม่มีสิทธิ์เขียน'];
    }
    $eval_start = $eval_start !== '' ? $eval_start : $start;
    $eval_end = $eval_end !== '' ? $eval_end : $end;
    $part = amr_amass_fetch_rows($hos, $dataset, $start, $end, $con, $eval_start, $eval_end);
    if (!empty($part['error'])) {
        return ['ok' => false, 'error' => $part['error'], 'start_date' => $start, 'end_date' => $end];
    }
    $columns = !empty($part['columns']) ? $part['columns'] : $sets[$dataset]['columns'];
    $path = amr_amass_chunk_path($dataset, $start);
    if (!amr_amass_put_csv($path, $columns, $part['rows'])) {
        return ['ok' => false, 'error' => 'เขียนไฟล์รายเดือนไม่สำเร็จ'];
    }
    return [
        'ok' => true,
        'dataset' => $dataset,
        'chunk' => date('Y-m', strtotime($start)),
        'filename' => basename($path),
        'row_count' => count($part['rows']),
        'bytes' => (int)@filesize($path),
        'start_date' => $start,
        'end_date' => $end,
    ];
}

function amr_amass_merge_chunks($dataset, $start, $end, $write_xlsx = false, $con = null) {
    $sets = amr_amass_datasets();
    if (!isset($sets[$dataset]) || empty($sets[$dataset]['ready'])) {
        return ['ok' => false, 'error' => 'ชุดข้อมูลนี้ยังไม่พร้อม'];
    }
    $months = [];
    foreach (amr_amass_month_spans($start, $end) as $span) {
        $months[date('Y-m', strtotime($span[0]))] = true;
    }
    $files = [];
    foreach (glob(amr_amass_chunk_dir() . '/' . $dataset . '_*.csv') ?: [] as $f) {
        if (preg_match('/_(\d{4}-\d{2})\.csv$/', $f, $m) && isset($months[$m[1]])) {
            $files[] = $f;
        }
    }
    sort($files);
    $columns = $sets[$dataset]['columns'];
    foreach ($files as $f) {
        $fh = @fopen($f, 'r');
        if (!$fh) {
            continue;
        }
        $header = fgetcsv($fh);
        fclose($fh);
        if (!is_array($header)) {
            continue;
        }
        foreach ($header as $col) {
            $col = preg_replace('/^\xEF\xBB\xBF/', '', (string)$col);
            $col = trim($col);
            if ($col !== '' && !in_array($col, $columns, true)) {
                $columns[] = $col;
            }
        }
    }
    $csv_name = amr_amass_csv_filename($dataset);
    $dest_csv = amr_amass_upload_dir() . '/' . $csv_name;
    $out = @fopen($dest_csv, 'wb');
    if (!$out) {
        return ['ok' => false, 'error' => 'เปิดไฟล์รวม CSV ไม่ได้'];
    }
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, $columns);
    $count = 0;
    $xlsx_rows = $write_xlsx ? [] : null;
    foreach ($files as $f) {
        $fh = @fopen($f, 'r');
        if (!$fh) {
            continue;
        }
        $header = fgetcsv($fh);
        if (!is_array($header)) {
            fclose($fh);
            continue;
        }
        $header = array_map(function ($h) {
            $h = preg_replace('/^\xEF\xBB\xBF/', '', (string)$h);
            return trim($h);
        }, $header);
        while (($row = fgetcsv($fh)) !== false) {
            $assoc = [];
            foreach ($header as $i => $col) {
                if ($col === '') {
                    continue;
                }
                $assoc[$col] = isset($row[$i]) ? $row[$i] : '';
            }
            $line = [];
            foreach ($columns as $col) {
                $line[] = $assoc[$col] ?? '';
            }
            fputcsv($out, $line);
            if (is_array($xlsx_rows)) {
                $xlsx_rows[] = $assoc;
            }
            $count++;
        }
        fclose($fh);
    }
    fclose($out);
    @chmod($dest_csv, 0666);
    $xlsx_name = $sets[$dataset]['filename'];
    $dest_xlsx = amr_amass_upload_dir() . '/' . $xlsx_name;
    $xlsx_ok = false;
    if ($write_xlsx) {
        $xlsx_ok = amr_amass_write_xlsx($dest_xlsx, $columns, $xlsx_rows ?: []);
    } elseif (is_file($dest_xlsx)) {
        @unlink($dest_xlsx);
    }
    $src = amr_amass_dataset_source($con, $dataset);
    $src_note = ($src === 'mlab' ? 'mLAB ' : 'HOSxP ') . $start . ' – ' . $end . ' (monthly merge)';
    amr_amass_touch_source($dataset, $src, $src_note, $start, $end);
    return [
        'ok' => true,
        'dataset' => $dataset,
        'filename' => $xlsx_ok ? $xlsx_name : $csv_name,
        'row_count' => $count,
        'bytes' => (int)@filesize($xlsx_ok ? $dest_xlsx : $dest_csv),
        'chunks' => count($files),
        'format' => $xlsx_ok ? 'xlsx' : 'csv',
        'start_date' => $start,
        'end_date' => $end,
    ];
}

function amr_amass_period_key($start, $end) {
    return preg_replace('/[^0-9\-]/', '', $start) . '_' . preg_replace('/[^0-9\-]/', '', $end);
}

function amr_amass_periods_root() {
    $dir = amr_amass_deny_dir(amr_amass_upload_dir() . '/periods');
    @chmod($dir, 0777);
    return $dir;
}

function amr_amass_save_period($start, $end, array $meta = []) {
    $key = amr_amass_period_key($start, $end);
    if ($key === '_' || $start === '' || $end === '') {
        return ['ok' => false, 'error' => 'ช่วงวันที่ไม่ครบ'];
    }
    $dir = amr_amass_deny_dir(amr_amass_periods_root() . '/' . $key);
    $src = amr_amass_results_dir();
    foreach (glob($src . '/*.csv') ?: [] as $f) {
        @copy($f, $dir . '/' . basename($f));
    }
    if (is_file($src . '/analysis_meta.json')) {
        @copy($src . '/analysis_meta.json', $dir . '/analysis_meta.json');
    }
    $info = [
        'key' => $key,
        'start' => $start,
        'end' => $end,
        'saved_at' => date('Y-m-d H:i:s'),
        'meta' => $meta,
    ];
    @file_put_contents($dir . '/period.json', json_encode($info, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    @chmod($dir . '/period.json', 0666);
    return $info + ['ok' => true];
}

function amr_amass_period_info($key) {
    $key = preg_replace('/[^0-9_\-]/', '', (string)$key);
    $path = amr_amass_periods_root() . '/' . $key . '/period.json';
    if (!is_file($path)) {
        return null;
    }
    $raw = json_decode((string)file_get_contents($path), true);
    return is_array($raw) ? $raw : null;
}

function amr_amass_list_periods() {
    $out = [];
    foreach (glob(amr_amass_periods_root() . '/*/period.json') ?: [] as $f) {
        $raw = json_decode((string)file_get_contents($f), true);
        if (!is_array($raw)) {
            continue;
        }
        $out[] = [
            'key' => $raw['key'] ?? basename(dirname($f)),
            'start' => $raw['start'] ?? '',
            'end' => $raw['end'] ?? '',
            'label' => ($raw['start'] ?? '') . ' ถึง ' . ($raw['end'] ?? ''),
            'saved_at' => $raw['saved_at'] ?? '',
            'micro_rows' => (int)($raw['meta']['micro_rows'] ?? 0),
            'admission_rows' => (int)($raw['meta']['admission_rows'] ?? 0),
            'blood_priority_dedup' => (int)($raw['meta']['blood_priority_dedup'] ?? 0),
        ];
    }
    usort($out, function ($a, $b) {
        $c = strcmp($a['start'], $b['start']);
        return $c !== 0 ? $c : strcmp($a['end'], $b['end']);
    });
    return $out;
}

function amr_amass_period_csv($key, $filename) {
    $key = preg_replace('/[^0-9_\-]/', '', (string)$key);
    $path = amr_amass_periods_root() . '/' . $key . '/' . basename($filename);
    return function_exists('amr_amass_read_csv_assoc') ? amr_amass_read_csv_assoc($path) : [];
}

function amr_amass_compare_periods($key_a, $key_b) {
    $info_a = amr_amass_period_info($key_a);
    $info_b = amr_amass_period_info($key_b);
    if (!$info_a || !$info_b) {
        return ['ok' => false, 'error' => 'ไม่พบช่วงที่บันทึกไว้ — วิเคราะห์แต่ละช่วงก่อน'];
    }
    $map = function ($rows) {
        $m = [];
        foreach ($rows as $r) {
            $k = ($r['Organism'] ?? '') . '|' . ($r['Antibiotic'] ?? '');
            $m[$k] = $r;
        }
        return $m;
    };
    $ma = $map(amr_amass_period_csv($key_a, 'ver3_Report2_AMR_proportion_table.csv'));
    $mb = $map(amr_amass_period_csv($key_b, 'ver3_Report2_AMR_proportion_table.csv'));
    $keys = array_unique(array_merge(array_keys($ma), array_keys($mb)));
    sort($keys);
    $rows = [];
    foreach ($keys as $k) {
        if ($k === '|') {
            continue;
        }
        $ra = $ma[$k] ?? [];
        $rb = $mb[$k] ?? [];
        $pa = $ra['Non-susceptible(%)'] ?? '';
        $pb = $rb['Non-susceptible(%)'] ?? '';
        $da = is_numeric($pa) ? (float)$pa : null;
        $db = is_numeric($pb) ? (float)$pb : null;
        $parts = explode('|', $k, 2);
        $rows[] = [
            'Organism' => $parts[0],
            'Antibiotic' => $parts[1] ?? '',
            'a_r' => $ra['Non-susceptible(N)'] ?? '',
            'a_n' => $ra['Total(N)'] ?? '',
            'a_pct' => $pa,
            'b_r' => $rb['Non-susceptible(N)'] ?? '',
            'b_n' => $rb['Total(N)'] ?? '',
            'b_pct' => $pb,
            'delta' => ($da !== null && $db !== null) ? round($db - $da, 1) : '',
        ];
    }
    return [
        'ok' => true,
        'a' => [
            'key' => $info_a['key'],
            'start' => $info_a['start'],
            'end' => $info_a['end'],
            'label' => $info_a['start'] . ' ถึง ' . $info_a['end'],
            'meta' => $info_a['meta'] ?? [],
        ],
        'b' => [
            'key' => $info_b['key'],
            'start' => $info_b['start'],
            'end' => $info_b['end'],
            'label' => $info_b['start'] . ' ถึง ' . $info_b['end'],
            'meta' => $info_b['meta'] ?? [],
        ],
        'section2' => $rows,
    ];
}

function amr_amass_period_display_label($start, $end) {
    if (preg_match('/^(\d{4})-01-01$/', $start, $m)) {
        $y = $m[1];
        if (strpos($end, $y . '-') === 0 && (substr($end, 5) === '12-31' || $end === date('Y-m-d'))) {
            return 'ปี ' . $y;
        }
    }
    if (preg_match('/^(\d{4}-\d{2})-01$/', $start, $m) && date('Y-m-t', strtotime($start)) === $end) {
        return $m[1];
    }
    return $start . ' ถึง ' . $end;
}

function amr_amass_compare_is_total_row(array $r) {
    foreach ($r as $v) {
        $s = trim((string)$v);
        if ($s === 'Total:' || $s === 'Total') {
            return true;
        }
    }
    return false;
}

/**
 * รวม CSV หลายช่วงเป็นแถวเดียวต่อ key พร้อม p{i}_{alias}
 * $id_fields = คอลัมน์ประกอบ key, $metrics = [csv_col => alias]
 */
function amr_amass_compare_join_csv(array $period_keys, $filename, array $id_fields, array $metrics) {
    $maps = [];
    foreach ($period_keys as $pkey) {
        $m = [];
        foreach (amr_amass_period_csv($pkey, $filename) as $r) {
            if (amr_amass_compare_is_total_row($r)) {
                continue;
            }
            $parts = [];
            foreach ($id_fields as $f) {
                $parts[] = trim((string)($r[$f] ?? ''));
            }
            $k = implode('|', $parts);
            if ($k === '' || $k === str_repeat('|', max(0, count($id_fields) - 1))) {
                continue;
            }
            $m[$k] = $r;
        }
        $maps[] = $m;
    }
    $all = [];
    foreach ($maps as $m) {
        foreach (array_keys($m) as $k) {
            $all[$k] = true;
        }
    }
    ksort($all);
    $rows = [];
    foreach (array_keys($all) as $k) {
        $parts = explode('|', $k);
        $row = [];
        foreach ($id_fields as $i => $f) {
            $row[$f] = $parts[$i] ?? '';
        }
        $base = null;
        foreach ($maps as $i => $m) {
            $r = $m[$k] ?? [];
            foreach ($r as $ck => $cv) {
                if (!isset($row[$ck]) || $row[$ck] === '') {
                    $row[$ck] = $cv;
                }
            }
            foreach ($metrics as $src => $alias) {
                $v = $r[$src] ?? '';
                $row['p' . $i . '_' . $alias] = $v;
            }
            $primary = reset($metrics);
            $raw = $row['p' . $i . '_' . $primary] ?? '';
            $num = is_numeric($raw) ? (float)$raw : null;
            if ($num === null && is_string($raw) && preg_match('/-?[\d.]+/', $raw, $mm)) {
                $num = (float)$mm[0];
            }
            if ($i === 0) {
                $base = $num;
                $row['p' . $i . '_delta'] = '';
            } else {
                $row['p' . $i . '_delta'] = ($base !== null && $num !== null) ? round($num - $base, 1) : '';
            }
        }
        $rows[] = $row;
    }
    return $rows;
}

function amr_amass_compare_multi(array $keys) {
    $keys = array_values(array_unique(array_filter(array_map('trim', $keys))));
    if (count($keys) < 2) {
        return ['ok' => false, 'error' => 'เลือกอย่างน้อย 2 ช่วงเพื่อเปรียบเทียบ'];
    }
    $periods = [];
    $maps = [];
    foreach ($keys as $key) {
        $info = amr_amass_period_info($key);
        if (!$info) {
            return ['ok' => false, 'error' => 'ไม่พบช่วง ' . $key . ' — ดึงข้อมูลช่วงนี้ก่อน'];
        }
        $start = $info['start'] ?? '';
        $end = $info['end'] ?? '';
        $periods[] = [
            'key' => $info['key'],
            'start' => $start,
            'end' => $end,
            'label' => amr_amass_period_display_label($start, $end),
            'meta' => $info['meta'] ?? [],
        ];
        $map = [];
        foreach (amr_amass_period_csv($key, 'ver3_Report2_AMR_proportion_table.csv') as $r) {
            $k = ($r['Organism'] ?? '') . '|' . ($r['Antibiotic'] ?? '');
            $map[$k] = $r;
        }
        $maps[] = $map;
    }
    $pair_keys = [];
    foreach ($maps as $m) {
        foreach (array_keys($m) as $k) {
            $pair_keys[$k] = true;
        }
    }
    ksort($pair_keys);
    $rows = [];
    foreach (array_keys($pair_keys) as $k) {
        if ($k === '|') {
            continue;
        }
        $parts = explode('|', $k, 2);
        $row = [
            'Organism' => $parts[0],
            'Antibiotic' => $parts[1] ?? '',
        ];
        $base = null;
        foreach ($maps as $i => $m) {
            $r = $m[$k] ?? [];
            $pct = $r['Non-susceptible(%)'] ?? '';
            $num = is_numeric($pct) ? (float)$pct : null;
            $row['p' . $i . '_r'] = $r['Non-susceptible(N)'] ?? '';
            $row['p' . $i . '_n'] = $r['Total(N)'] ?? '';
            $row['p' . $i . '_pct'] = $pct;
            if ($i === 0) {
                $base = $num;
                $row['p' . $i . '_delta'] = '';
            } else {
                $row['p' . $i . '_delta'] = ($base !== null && $num !== null) ? round($num - $base, 1) : '';
            }
        }
        $rows[] = $row;
    }
    $pkey_list = array_map(function ($p) {
        return $p['key'];
    }, $periods);
    return [
        'ok' => true,
        'periods' => $periods,
        'section2' => $rows,
        'section3' => amr_amass_compare_join_csv($pkey_list, 'ver3_Report3_table.csv', ['Organism', 'Antibiotic', 'Infection_origin'], [
            'Non-susceptible(%)' => 'pct',
            'Non-susceptible(N)' => 'r',
            'Total(N)' => 'n',
        ]),
        'section4freq' => amr_amass_compare_join_csv($pkey_list, 'ver3_Report4_frequency_blood_pathogen.csv', ['Organism'], [
            'frequency_per_tested' => 'val',
            'Number_of_patients' => 'n',
        ]),
        'section5c' => amr_amass_compare_join_csv($pkey_list, 'ver3_Report5_incidence_blood_samples_community_origin.csv', ['Organism'], [
            'Incidence_per_100000_patient_days' => 'val',
            'Number_of_patients' => 'n',
        ]),
        'section5h' => amr_amass_compare_join_csv($pkey_list, 'ver3_Report5_incidence_blood_samples_hospital_origin.csv', ['Organism'], [
            'Incidence_per_100000_patient_days' => 'val',
            'Number_of_patients' => 'n',
        ]),
        'section5c_freq' => amr_amass_compare_join_csv($pkey_list, 'ver3_Report5_frequency_community_origin.csv', ['Organism'], [
            'frequency_per_tested' => 'val',
            'Number_of_patients' => 'n',
        ]),
        'section5h_freq' => amr_amass_compare_join_csv($pkey_list, 'ver3_Report5_frequency_hospital_origin.csv', ['Organism'], [
            'frequency_per_tested' => 'val',
            'Number_of_patients' => 'n',
        ]),
        'section6' => amr_amass_compare_join_csv($pkey_list, 'ver3_Report6_mortality_table.csv', ['Organism', 'Infection_origin'], [
            'Mortality(%)' => 'val',
            'Number_of_deaths' => 'deaths',
            'Total_number_of_patients' => 'n',
        ]),
        'annex_b' => amr_amass_compare_join_csv($pkey_list, 'ver3_AnnexB_proportion_table_blood.csv', ['Indicators'], [
            'Proportion' => 'val',
            'Number' => 'n',
            'Denominator' => 'd',
        ]),
        'annex_b_month' => amr_amass_compare_join_csv($pkey_list, 'ver3_AnnexB_proportion_table_blood_bymonth.csv', ['Month'], [
            'blood_culture_contamination_rate' => 'val',
            'notifiable_antibiotic_pathogen' => 'amr',
            'potential_AST_errors' => 'ast',
        ]),
        'annex_b_cont' => amr_amass_compare_join_csv($pkey_list, 'AnnexB1b_blood_culture_contamination.csv', ['Organism'], [
            'Number_of_possible_contaminants' => 'val',
            'Percent_of_contaminants' => 'pct',
        ]),
        'annex_c_ward' => amr_amass_compare_join_csv($pkey_list, 'ver3_AnnexC_ward_counts.csv', ['AMR_pathogen', 'Ward'], [
            'Hospital_origin_isolates' => 'val',
        ]),
        'annex_d_summary' => amr_amass_compare_join_csv($pkey_list, 'AnnexD1_summary.csv', ['Parameter'], [
            'Value' => 'val',
        ]),
        'annex_d_dot' => amr_amass_compare_join_csv($pkey_list, 'AnnexD1_AMU_DOT_by_parentaral_atb.csv', ['Antibiotic'], [
            'DOT' => 'val',
            'DOT_percent' => 'pct',
            'DOT_per1000patient_days' => 'per1000',
        ]),
        'annex_d_aware' => amr_amass_compare_join_csv($pkey_list, 'AnnexD1_AMU_DOT_by_Aware_class.csv', ['AWaRe_classification'], [
            'DOT' => 'val',
            'DOT_percent' => 'pct',
            'DOT_per1000patient_days' => 'per1000',
        ]),
        'annex_d_dept' => amr_amass_compare_join_csv($pkey_list, 'AnnexD1_AMU_DOT_by_dept.csv', ['Department'], [
            'DOT' => 'val',
            'DOT_percent' => 'pct',
            'DOT_per1000patient_days' => 'per1000',
        ]),
        'annex_d_month' => amr_amass_compare_join_csv($pkey_list, 'AnnexD1_AMU_by_month.csv', ['Month'], [
            'Number_of_antibiotic_records' => 'val',
            'Number_of_antifungal_records' => 'atf',
            'Number_of_drug_records' => 'all',
        ]),
        'annex_d_route' => amr_amass_compare_join_csv($pkey_list, 'AnnexD1_AMU_by_route.csv', ['Route_of_administration'], [
            'Number_of_antibiotic_records' => 'val',
            'Number_of_antifungal_records' => 'atf',
        ]),
        'amu' => amr_amass_compare_join_csv($pkey_list, 'ver3_AnnexD_amu_top_drugs.csv', ['drug_name'], [
            'prescriptions' => 'val',
        ]),
        'overview_periods' => amr_amass_compare_overview_periods($periods),
        'a' => $periods[0] ?? null,
        'b' => $periods[1] ?? null,
    ];
}

function amr_amass_compare_overview_periods(array $periods) {
    $out = [];
    foreach ($periods as $p) {
        $key = (string)($p['key'] ?? '');
        $meta = is_array($p['meta'] ?? null) ? $p['meta'] : [];
        $r1 = [];
        foreach (amr_amass_period_csv($key, 'ver3_Report1_page3_results.csv') as $row) {
            $type = $row['Type_of_data_file'] ?? '';
            $param = $row['Parameters'] ?? '';
            if ($type !== '' && $param !== '') {
                $r1[$type . '|' . $param] = $row['Values'] ?? '';
            }
        }
        $deaths = 0;
        foreach (amr_amass_period_csv($key, 'ver3_Report6_mortality_table.csv') as $row) {
            $org = trim((string)($row['Organism'] ?? ''));
            if ($org === 'Total:' || $org === 'Total') {
                continue;
            }
            $deaths += (int)($row['Number_of_deaths'] ?? 0);
        }
        $sec2 = amr_amass_period_csv($key, 'ver3_Report2_AMR_proportion_table.csv');
        $sec3 = amr_amass_period_csv($key, 'ver3_Report3_table.csv');
        $out[] = [
            'key' => $key,
            'label' => $p['label'] ?? $key,
            'micro' => (float)($r1['microbiology_data|Number_of_records'] ?? $meta['micro_rows'] ?? 0),
            'admit' => (float)($r1['hospital_admission_data|Number_of_records'] ?? $meta['admission_rows'] ?? 0),
            'dedup' => (float)($r1['merged_data|Number_of_patients_with_blood_culture_positive_for_organism_under_this_survey'] ?? $meta['blood_priority_dedup'] ?? 0),
            'pairs' => count($sec2),
            'origin_rows' => count($sec3),
            'patient_days' => (float)($r1['hospital_admission_data|Patient_days'] ?? $meta['patient_days'] ?? 0),
            'tested' => (float)($r1['merged_data|Number_of_patients_sampled_for_blood_culture'] ?? $meta['n_blood_patients'] ?? 0),
            'deaths' => $deaths,
            'com_bsi' => (float)($r1['merged_data|Number_of_patients_with_community_origin_BSI'] ?? 0),
            'hos_bsi' => (float)($r1['merged_data|Number_of_patients_with_hospital_origin_BSI'] ?? 0),
            'date_min' => $r1['overall_data|Minimum_date'] ?? ($meta['date_min'] ?? ($p['start'] ?? '')),
            'date_max' => $r1['overall_data|Maximum_date'] ?? ($meta['date_max'] ?? ($p['end'] ?? '')),
        ];
    }
    return $out;
}

function amr_amass_package_root() {
    $candidates = [
        '/home/co-scph/employee/amass/AMASS V4/AMASS4.0',
        dirname(__DIR__, 2) . '/amass/AMASS V4/AMASS4.0',
        __DIR__ . '/AMASS V4/AMASS4.0',
    ];
    foreach ($candidates as $path) {
        if (is_file($path . '/AMASS.bat')) {
            return $path;
        }
    }
    return $candidates[0];
}

function amr_amass_deny_dir($dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $idx = rtrim($dir, '/') . '/index.php';
    if (!is_file($idx)) {
        @file_put_contents($idx, "<?php header('HTTP/1.0 403 Forbidden');\n");
    }
    return $dir;
}

function amr_amass_results_dir() {
    return amr_amass_deny_dir(amr_amass_upload_dir() . '/ResultData');
}

function amr_amass_package_status() {
    $root = amr_amass_package_root();
    $items = [
        'bat' => ['label' => 'AMASS.bat', 'path' => $root . '/AMASS.bat'],
        'python' => ['label' => 'Python portable 3.8.9 (Windows 64-bit)', 'path' => $root . '/Programs/Python-Portable/Portable_Python-3.8.9-64bit/python.exe'],
        'analysis' => ['label' => 'AMASS4.0_amr_analysis.py', 'path' => $root . '/Programs/AMASS_amr/AMASS4.0_amr_analysis.py'],
        'config' => ['label' => 'Configuration.xlsx', 'path' => $root . '/Configuration/Configuration.xlsx'],
        'dict_micro' => ['label' => 'dictionary_for_microbiology_data.xlsx', 'path' => $root . '/dictionary_for_microbiology_data.xlsx'],
        'dict_adm' => ['label' => 'dictionary_for_hospital_admission_data.xlsx', 'path' => $root . '/dictionary_for_hospital_admission_data.xlsx'],
        'dict_drug' => ['label' => 'dictionary_for_drug_data.xlsx', 'path' => $root . '/dictionary_for_drug_data.xlsx'],
        'dict_ward' => ['label' => 'dictionary_for_wards.xlsx', 'path' => $root . '/dictionary_for_wards.xlsx'],
        'satscan' => ['label' => 'SaTScan (Annex C)', 'path' => $root . '/Programs/AMASS_amr/SaTScanBatch64.exe'],
        'example5' => ['label' => 'Example_dataset_5_AMU (ครบ 3 ไฟล์ข้อมูล)', 'path' => $root . '/Example_dataset_5_AMU/microbiology_data.xlsx'],
        'example_pdf' => ['label' => 'ตัวอย่าง AMR_surveillance_report.pdf', 'path' => $root . '/Example_dataset_5_AMU/Example_results_generated_by_AMASS/AMR_surveillance_report.pdf'],
    ];
    $ok = 0;
    $out = [];
    foreach ($items as $key => $meta) {
        $exists = is_file($meta['path']);
        if ($exists) {
            $ok++;
        }
        $out[$key] = [
            'label' => $meta['label'],
            'exists' => $exists,
            'bytes' => $exists ? (int)filesize($meta['path']) : 0,
        ];
    }
    $total = count($items);
    return [
        'installed' => is_dir($root),
        'root' => $root,
        'version' => '4.0',
        'build' => '4028',
        'released' => '14 Jan 2026',
        'os' => 'THAM Hos-Safe (Linux) + AMASS dictionaries',
        'items' => $out,
        'ok_count' => $ok,
        'total' => $total,
        'complete' => $ok === $total,
        'run_on_server' => true,
        'run_note' => 'ดึง 3 ไฟล์จาก HOSxP แล้ววิเคราะห์ WHO GLASS/AMASS ใน THAM Hos-Safe — ไม่ต้องรัน AMASS.bat บน Windows. Annex B และ D คำนวณใน PHP. Annex C เป็นสแกน Poisson รายวอร์ด-สัปดาห์ (ไม่ใช่ SaTScan)',
    ];
}

function amr_amass_example_pdf_map() {
    $root = amr_amass_package_root();
    $d5 = $root . '/Example_dataset_5_AMU/Example_results_generated_by_AMASS';
    $d2 = $root . '/Example_dataset_2/Example_results_generated_by_AMASS';
    return [
        'example_main' => ['path' => $d5 . '/AMR_surveillance_report.pdf', 'label' => 'AMR surveillance report (ตัวอย่างชุด AMU)', 'mime' => 'application/pdf'],
        'example_log' => ['path' => $d5 . '/Data_verification_logfile_report.pdf', 'label' => 'Data verification log', 'mime' => 'application/pdf'],
        'example_log_d' => ['path' => $d5 . '/Data_verification_logfile_report_annexD.pdf', 'label' => 'Data verification log Annex D', 'mime' => 'application/pdf'],
        'example_annex_b' => ['path' => $d5 . '/Supplementary_data_Annex_B.pdf', 'label' => 'Supplementary Annex B', 'mime' => 'application/pdf'],
        'example_annex_c' => ['path' => $d5 . '/Supplementary_data_Annex_C.pdf', 'label' => 'Supplementary Annex C', 'mime' => 'application/pdf'],
        'example_annex_d' => ['path' => $d5 . '/Supplementary_data_annex_D.pdf', 'label' => 'Supplementary Annex D', 'mime' => 'application/pdf'],
        'example2_main' => ['path' => $d2 . '/AMR_surveillance_report.pdf', 'label' => 'AMR surveillance report (ตัวอย่างชุด admit+micro)', 'mime' => 'application/pdf'],
    ];
}

function amr_amass_safe_result_basename($name) {
    $base = basename(str_replace('\\', '/', (string)$name));
    if (!preg_match('/^[A-Za-z0-9._-]+\.(csv|pdf|xlsx|png)$/i', $base)) {
        return '';
    }
    return $base;
}

function amr_amass_result_files() {
    $dir = amr_amass_results_dir();
    $out = [];
    $list = @scandir($dir);
    if (!is_array($list)) {
        return $out;
    }
    foreach ($list as $fn) {
        $safe = amr_amass_safe_result_basename($fn);
        if ($safe === '' || $safe === 'index.php') {
            continue;
        }
        $path = $dir . '/' . $safe;
        if (!is_file($path)) {
            continue;
        }
        $ext = strtolower(pathinfo($safe, PATHINFO_EXTENSION));
        $mime = 'application/octet-stream';
        if ($ext === 'pdf') {
            $mime = 'application/pdf';
        } elseif ($ext === 'csv') {
            $mime = 'text/csv';
        } elseif ($ext === 'xlsx') {
            $mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        } elseif ($ext === 'png') {
            $mime = 'image/png';
        }
        $out['result_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $safe)] = [
            'path' => $path,
            'label' => $safe,
            'mime' => $mime,
            'bytes' => (int)filesize($path),
            'updated_at' => date('Y-m-d H:i:s', filemtime($path)),
        ];
    }
    return $out;
}

function amr_amass_file_catalog() {
    $map = [];
    foreach (amr_amass_example_pdf_map() as $key => $meta) {
        if (!empty($meta['path']) && is_file($meta['path'])) {
            $map[$key] = $meta;
        }
    }
    return $map + amr_amass_result_files();
}

function amr_amass_read_csv_assoc($path) {
    if (!is_file($path)) {
        return [];
    }
    $fh = fopen($path, 'r');
    if (!$fh) {
        return [];
    }
    $header = fgetcsv($fh);
    if (!is_array($header) || !$header) {
        fclose($fh);
        return [];
    }
    $header = array_map(function ($h) {
        $h = (string)$h;
        $h = preg_replace('/^\xEF\xBB\xBF/', '', $h);
        $h = preg_replace('/^\x{FEFF}/u', '', $h);
        return trim($h);
    }, $header);
    $rows = [];
    while (($row = fgetcsv($fh)) !== false) {
        $assoc = [];
        foreach ($header as $i => $col) {
            $assoc[$col] = isset($row[$i]) ? trim((string)$row[$i]) : '';
        }
        $rows[] = $assoc;
    }
    fclose($fh);
    return $rows;
}

function amr_amass_report1_map() {
    $path = amr_amass_results_dir() . '/ver3_Report1_page3_results.csv';
    if (!is_file($path)) {
        $path = amr_amass_results_dir() . '/Report1_page3_results.csv';
    }
    $map = [];
    foreach (amr_amass_read_csv_assoc($path) as $row) {
        $type = $row['Type_of_data_file'] ?? '';
        $param = $row['Parameters'] ?? '';
        if ($type === '' || $param === '') {
            continue;
        }
        $map[$type . '|' . $param] = $row['Values'] ?? '';
    }
    return $map;
}

function amr_amass_result_kpis() {
    $r1 = amr_amass_report1_map();
    $dir = amr_amass_results_dir();
    $has_pdf = is_file($dir . '/AMR_surveillance_report.pdf');
    $csv_n = 0;
    foreach (amr_amass_result_files() as $meta) {
        if (strtolower(pathinfo($meta['label'], PATHINFO_EXTENSION)) === 'csv') {
            $csv_n++;
        }
    }
    return [
        'has_results' => $has_pdf || $csv_n > 0 || !empty($r1),
        'has_pdf' => $has_pdf,
        'csv_count' => $csv_n,
        'hospital_name' => amr_amass_hospital_name(),
        'country' => $r1['microbiology_data|Country'] ?? '',
        'date_min' => $r1['overall_data|Minimum_date'] ?? '',
        'date_max' => $r1['overall_data|Maximum_date'] ?? '',
        'micro_n' => $r1['microbiology_data|Number_of_records'] ?? '',
        'micro_min' => $r1['microbiology_data|Minimum_date'] ?? '',
        'micro_max' => $r1['microbiology_data|Maximum_date'] ?? '',
        'adm_n' => $r1['hospital_admission_data|Number_of_records'] ?? '',
        'patient_days' => $r1['hospital_admission_data|Patient_days'] ?? '',
        'patient_days_his' => $r1['hospital_admission_data|Patient_days_his'] ?? '',
        'blood_collected' => $r1['microbiology_data|Number_of_blood_specimens_collected'] ?? '',
    ];
}

function amr_amass_save_result_upload($tmp, $orig_name) {
    $dir = amr_amass_results_dir();
    $orig = (string)$orig_name;
    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    if (!is_uploaded_file($tmp) && !is_file($tmp)) {
        return ['ok' => false, 'error' => 'ไม่พบไฟล์อัปโหลด'];
    }
    $copied = [];
    if ($ext === 'zip') {
        if (!class_exists('ZipArchive')) {
            return ['ok' => false, 'error' => 'เซิร์ฟเวอร์ไม่รองรับไฟล์ zip'];
        }
        $zip = new ZipArchive();
        if ($zip->open($tmp) !== true) {
            return ['ok' => false, 'error' => 'เปิดไฟล์ zip ไม่ได้'];
        }
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $name = $stat['name'] ?? '';
            if (substr($name, -1) === '/') {
                continue;
            }
            $safe = amr_amass_safe_result_basename($name);
            if ($safe === '') {
                continue;
            }
            $data = $zip->getFromIndex($i);
            if ($data === false) {
                continue;
            }
            @file_put_contents($dir . '/' . $safe, $data);
            $copied[] = $safe;
        }
        $zip->close();
        if (!$copied) {
            return ['ok' => false, 'error' => 'ใน zip ไม่มีไฟล์ csv/pdf ของ ResultData'];
        }
        return ['ok' => true, 'files' => $copied];
    }
    $safe = amr_amass_safe_result_basename($orig);
    if ($safe === '') {
        return ['ok' => false, 'error' => 'รองรับเฉพาะ .pdf .csv .xlsx .zip ของ ResultData'];
    }
    if (stripos($safe, 'AMR_surveillance_report') !== false) {
        $safe = 'AMR_surveillance_report.pdf';
    }
    $dest = $dir . '/' . $safe;
    $ok = is_uploaded_file($tmp) ? @move_uploaded_file($tmp, $dest) : @copy($tmp, $dest);
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกไฟล์ไม่สำเร็จ'];
    }
    return ['ok' => true, 'files' => [$safe]];
}
