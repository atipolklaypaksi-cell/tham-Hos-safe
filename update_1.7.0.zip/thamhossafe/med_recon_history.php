<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
tham_menu_ensure_page_access('med_recon_history.php');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ประวัติการทำ Med Reconcile - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: #f4f7f6; }
        .sum-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 12px 14px; }
        .sum-card .n { font-size: 1.35rem; font-weight: 800; line-height: 1.1; }
        .an-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; margin-bottom: 14px; overflow: hidden; }
        .an-head { background: #fff7ed; border-bottom: 1px solid #fed7aa; padding: 10px 14px; }
        .kind-band { padding: 6px 14px; font-weight: 800; font-size: .86rem; }
        .kind-band.an { background: #fff1e6; color: #9a3412; border-top: 1px solid #fed7aa; }
        .kind-band.vn { background: #ecfdf3; color: #166534; border-top: 1px solid #bbf7d0; }
        .visit-sub { padding: 6px 14px; background: #fafafa; border-top: 1px solid #f1f3f5; font-size: .86rem; }
        .pill-an { background: #ffedd5; color: #9a3412; }
        .pill-vn { background: #dcfce7; color: #166534; }
        .sess { border-top: 1px solid #f1f3f5; padding: 10px 14px; }
        .sess:first-of-type { border-top: 0; }
        .pill { display: inline-block; border-radius: 999px; padding: 1px 8px; font-size: .78rem; font-weight: 700; }
        .pill-visit { background: #e7f5ee; color: #146c43; }
        .pill-add { background: #fff3cd; color: #8a5a00; }
        .drug-mini { font-size: .86rem; }
        .drug-mini th { background: #f8f9fa; }
        .place { color: #6c757d; font-size: .78rem; }
        .dash-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 12px 14px; height: 100%; }
        .dash-card.fit { height: auto; }
        .preset-btn.active { background: #b45309; color: #fff; border-color: #b45309; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
                <div>
                    <h4 class="fw-bold mb-1 text-dark">
                        <i class="fas fa-history me-2" style="color:#b45309;"></i>ประวัติการทำ Med Reconcile
                    </h4>
                    <p class="text-muted small mb-0">เรียงรายคน จากครั้งล่าสุด · ในแต่ละคนแยกส่วน AN และ VN · ในเลขเดียวกันดูแยกแต่ละครั้งและผู้ทำ</p>
                </div>
                <a href="med_reconcile_discharge.php" class="btn btn-outline-success btn-sm fw-bold">
                    <i class="fas fa-house-user me-1"></i> Med Reconcile ยากลับบ้าน
                </a>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-4">
                            <label class="form-label small fw-bold mb-1">ช่วงรายงาน</label>
                            <div class="d-flex gap-1 mb-1 flex-wrap">
                                <button type="button" class="btn btn-sm btn-outline-secondary preset-btn" data-preset="7">7 วัน</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary preset-btn active" data-preset="30">1 เดือน</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary preset-btn" data-preset="90">3 เดือน</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary preset-btn" data-preset="365">1 ปี</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary preset-btn" data-preset="0">ทั้งหมด</button>
                            </div>
                            <div class="d-flex gap-1 align-items-center">
                                <input type="date" id="fFrom" class="form-control form-control-sm">
                                <span class="small text-muted">ถึง</span>
                                <input type="date" id="fTo" class="form-control form-control-sm">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small fw-bold mb-1">HN / ชื่อ</label>
                            <input type="text" id="fQ" class="form-control form-control-sm" placeholder="HN หรือชื่อผู้ป่วย">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small fw-bold mb-1">AN / VN</label>
                            <input type="text" id="fAn" class="form-control form-control-sm" placeholder="AN หรือ VN">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold mb-1">ผู้ทำ</label>
                            <select id="fStaff" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small fw-bold mb-1">ตำแหน่ง</label>
                            <select id="fPosition" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold mb-1">ลักษณะรายการ</label>
                            <select id="fKind" class="form-select form-select-sm">
                                <option value="all">ทั้งหมด</option>
                                <option value="added">มีการเพิ่มรายการนอก Visit</option>
                                <option value="visit">ดึงจาก Visit อย่างเดียว</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold mb-1">จัดกลุ่ม</label>
                            <select id="fGroup" class="form-select form-select-sm">
                                <option value="an">ตามคน (แยก AN / VN)</option>
                                <option value="staff">ตามผู้ทำ</option>
                                <option value="position">ตามตำแหน่ง</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-success btn-sm fw-bold w-100" id="btnSearch">
                                <i class="fas fa-search me-1"></i> ค้นหา
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-2 mb-3" id="sumRow">
                <div class="col-6 col-md-2"><div class="sum-card"><div class="text-muted small">จำนวนครั้ง</div><div class="n" id="sumRecords">-</div></div></div>
                <div class="col-6 col-md-2"><div class="sum-card"><div class="text-muted small">ผู้ป่วย</div><div class="n" id="sumPatients">-</div><div class="text-muted" style="font-size:.72rem;" id="sumPatientsHint">รวม AN และ VN</div></div></div>
                <div class="col-6 col-md-2"><div class="sum-card"><div class="text-muted small">AN / VN</div><div class="n" id="sumAns">-</div></div></div>
                <div class="col-6 col-md-2"><div class="sum-card"><div class="text-muted small">ผู้ทำ</div><div class="n" id="sumStaff">-</div></div></div>
                <div class="col-6 col-md-2"><div class="sum-card"><div class="text-muted small">ครั้งที่มีรายการเพิ่ม</div><div class="n" id="sumWithAdded">-</div></div></div>
                <div class="col-6 col-md-2"><div class="sum-card"><div class="text-muted small">ยาที่เพิ่มนอก Visit</div><div class="n" style="color:#8a5a00;" id="sumAdded">-</div></div></div>
            </div>

            <div class="row g-2 mb-3">
                <div class="col-lg-5">
                    <div class="dash-card">
                        <div class="fw-bold mb-2">จำนวนครั้งตามผู้ทำ</div>
                        <div style="height:260px;"><canvas id="chartStaff"></canvas></div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="dash-card">
                        <div class="fw-bold mb-2">จำนวนครั้งรายวัน</div>
                        <div style="height:260px;"><canvas id="chartDay"></canvas></div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="dash-card">
                        <div class="fw-bold mb-2">แหล่งรายการยา</div>
                        <div style="height:180px;"><canvas id="chartKind"></canvas></div>
                        <div class="small text-muted mt-2" id="kindHint"></div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="dash-card">
                        <div class="fw-bold mb-2">จำนวนครั้งตามตำแหน่ง</div>
                        <div style="height:220px;"><canvas id="chartPosition"></canvas></div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="dash-card">
                        <div class="fw-bold mb-2">ตารางสรุปตามตำแหน่ง</div>
                        <div class="table-responsive">
                            <table class="table table-sm mb-0">
                                <thead class="table-light"><tr><th>ตำแหน่ง</th><th class="text-end">ครั้ง</th><th class="text-end">ผู้ป่วย</th><th class="text-end">ผู้ทำ</th><th class="text-end">มีรายการเพิ่ม</th></tr></thead>
                                <tbody id="positionTable"><tr><td colspan="5" class="text-muted">กำลังโหลด...</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="dash-card fit">
                        <div class="fw-bold mb-2">ตารางสรุปตามผู้ทำ</div>
                        <div class="table-responsive">
                            <table class="table table-sm mb-0">
                                <thead class="table-light"><tr><th>ผู้ทำ</th><th>ตำแหน่ง</th><th class="text-end">ครั้ง</th><th class="text-end">ผู้ป่วย</th><th class="text-end">มีรายการเพิ่ม</th><th class="text-end">ยาจาก Visit</th><th class="text-end">ยาที่เพิ่ม</th></tr></thead>
                                <tbody id="staffTable"><tr><td colspan="7" class="text-muted">กำลังโหลด...</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="dash-card fit">
                        <div class="fw-bold mb-2">หอผู้ป่วยที่ทำมากสุด <span class="fw-normal text-muted small">กรณี AN</span></div>
                        <div class="table-responsive">
                            <table class="table table-sm mb-0">
                                <thead class="table-light"><tr><th>หอผู้ป่วย</th><th class="text-end">ครั้ง</th></tr></thead>
                                <tbody id="wardTable"><tr><td colspan="2" class="text-muted">กำลังโหลด...</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="dash-card fit">
                        <div class="fw-bold mb-2">แผนกที่ทำมากสุด <span class="fw-normal text-muted small">กรณี VN</span></div>
                        <div class="table-responsive">
                            <table class="table table-sm mb-0">
                                <thead class="table-light"><tr><th>แผนก</th><th class="text-end">ครั้ง</th></tr></thead>
                                <tbody id="deptTable"><tr><td colspan="2" class="text-muted">กำลังโหลด...</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div id="histList">
                <div class="text-center text-muted py-5">กำลังโหลดประวัติ...</div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h5 class="modal-title fw-bold">แก้ไขประวัติ Med Reconcile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-2 mb-2">
                    <div class="col-md-4"><label class="form-label small fw-bold mb-0">ชื่อผู้ป่วย</label><input id="edName" class="form-control form-control-sm"></div>
                    <div class="col-md-2"><label class="form-label small fw-bold mb-0">HN</label><input id="edHn" class="form-control form-control-sm"></div>
                    <div class="col-md-2"><label class="form-label small fw-bold mb-0">AN</label><input id="edAn" class="form-control form-control-sm"></div>
                    <div class="col-md-4"><label class="form-label small fw-bold mb-0">ผู้ทำ</label><input id="edStaff" class="form-control form-control-sm"></div>
                    <div class="col-md-4"><label class="form-label small fw-bold mb-0">หอผู้ป่วย</label><input id="edWard" class="form-control form-control-sm"></div>
                    <div class="col-md-3"><label class="form-label small fw-bold mb-0">วันที่รับบริการ</label><input id="edService" class="form-control form-control-sm"></div>
                    <div class="col-md-5"><label class="form-label small fw-bold mb-0">Note</label><input id="edNote" class="form-control form-control-sm"></div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <div class="fw-bold small">รายการยา</div>
                    <button type="button" class="btn btn-sm btn-outline-success" onclick="editAddRow()">เพิ่มรายการ</button>
                </div>
                <div class="table-responsive">
                    <table class="table table-sm table-bordered align-middle mb-0">
                        <thead class="table-light"><tr>
                            <th>ชื่อยา</th><th>วิธีใช้</th><th width="8%">จำนวน</th><th width="8%">หน่วย</th><th width="12%">วันที่</th><th width="16%">สถานที่</th><th width="10%">นอก Visit</th><th width="6%"></th>
                        </tr></thead>
                        <tbody id="edRows"></tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                <button type="button" class="btn btn-primary fw-bold" id="btnSaveEdit">บันทึกการแก้ไข</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="delModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h5 class="modal-title fw-bold text-danger">ลบประวัติ Med Reconcile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="mb-2" id="delHint">ยืนยันลบรายการนี้</p>
                <label class="form-label small fw-bold">พิมพ์คำว่า delete เพื่อยืนยัน</label>
                <input type="text" id="delConfirm" class="form-control" autocomplete="off" placeholder="delete">
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="button" class="btn btn-danger fw-bold" id="btnDoDelete" disabled>ลบ</button>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/chart.min.js"></script>
<script>
function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function drugTable(rows, emptyText) {
    if (!rows || !rows.length) {
        return '<div class="text-muted small py-2">' + esc(emptyText) + '</div>';
    }
    let body = '';
    rows.forEach(function (r, i) {
        const qty = [r.qty, r.units].filter(Boolean).join(' ');
        const place = r.hospital_name || '';
        body += '<tr>'
            + '<td class="text-center">' + (i + 1) + '</td>'
            + '<td><div class="fw-bold">' + esc(r.drug_name) + '</div>'
            + (r.method ? '<div class="place">' + esc(r.method) + '</div>' : '')
            + '</td>'
            + '<td class="text-center">' + esc(qty) + '</td>'
            + '<td>' + esc(r.order_date || '') + (place ? '<div class="place">' + esc(place) + '</div>' : '') + '</td>'
            + '</tr>';
    });
    return '<div class="table-responsive"><table class="table table-sm table-bordered drug-mini mb-0">'
        + '<thead><tr><th width="8%">#</th><th>รายการยา</th><th width="16%">จำนวน</th><th width="28%">วันที่ / สถานที่</th></tr></thead>'
        + '<tbody>' + body + '</tbody></table></div>';
}

let lastGroup = 'an';

function histHnKey(it) {
    const raw = String((it && it.hn) || '').trim();
    const norm = raw.replace(/^0+/, '');
    return norm || raw || ('id' + (it && it.id));
}

function sessionHtml(it) {
    const detailId = 'd' + it.id;
    let kind = '';
    if (it.an) kind += '<span class="pill pill-an">AN ' + esc(it.an) + '</span> ';
    if (it.vn) kind += '<span class="pill pill-vn">VN ' + esc(it.vn) + '</span>';
    if (!kind) kind = '<span class="pill pill-visit">ไม่ระบุ AN/VN</span>';
    return '<div class="sess">'
        + '<div class="d-flex justify-content-between flex-wrap gap-2">'
        + '<div>'
        + '<div class="fw-bold">' + esc(it.saved_at_th || '-') + '</div>'
        + '<div class="small">ผู้ทำ <b>' + esc(it.saved_name || 'ไม่ระบุ') + '</b>'
        + ' <span class="pill pill-visit">' + esc(it.position_label || 'ไม่ระบุตำแหน่ง') + '</span> '
        + kind
        + (it.service_date ? ' · รับบริการ ' + esc(it.service_date) : '')
        + '</div>'
        + '<div class="small text-muted">' + esc(it.patient_name || '') + (it.hn ? ' · HN ' + esc(it.hn) : '')
        + (it.an && it.ward ? ' · หอ ' + esc(it.ward) : '')
        + (!it.an && it.department ? ' · แผนก ' + esc(it.department) : '')
        + '</div>'
        + '</div>'
        + '<div class="text-end">'
        + '<span class="pill pill-visit">จาก Visit ' + it.visit_count + ' ราย</span> '
        + '<span class="pill pill-add">เพิ่มนอก Visit ' + it.added_count + ' ราย</span>'
        + '<div class="mt-1">'
        + '<button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="collapse" data-bs-target="#' + detailId + '">ดูรายการ</button> '
        + '<button type="button" class="btn btn-sm btn-outline-primary" onclick="openEdit(' + it.id + ')">แก้ไข</button> '
        + '<button type="button" class="btn btn-sm btn-outline-danger" onclick="openDelete(' + it.id + ')">ลบ</button> '
        + '<a class="btn btn-sm btn-outline-success" href="smart_drug.php?hn=' + encodeURIComponent(it.hn || '') + '">Smart Drug</a>'
        + '</div></div></div>'
        + '<div class="collapse mt-2" id="' + detailId + '"><div class="row g-2">'
        + '<div class="col-lg-6"><div class="fw-bold small text-success mb-1">ดึงจาก Visit ที่มี ' + it.visit_count + ' ราย</div>'
        + drugTable(it.visit_rows, 'ไม่มีรายการจาก Visit') + '</div>'
        + '<div class="col-lg-6"><div class="fw-bold small mb-1" style="color:#8a5a00;">เพิ่มรายการนอกสถานพยาบาล ' + it.added_count + ' ราย</div>'
        + drugTable(it.added_rows, 'ไม่ได้เพิ่มรายการนอก Visit') + '</div>'
        + '</div></div></div>';
}

function visitBlocksHtml(map, kind) {
    const rows = Object.keys(map).map(function (k) { return map[k]; });
    rows.sort(function (a, b) { return String(b.latest).localeCompare(String(a.latest)); });
    if (!rows.length) return '';
    let n = 0;
    rows.forEach(function (v) { n += (v.items || []).length; });
    let html = '<div class="kind-band ' + kind + '">' + (kind === 'an' ? 'AN' : 'VN')
        + ' · ' + rows.length + ' เลข · ' + n + ' ครั้ง</div>';
    rows.forEach(function (v) {
        const items = (v.items || []).slice().sort(function (a, b) {
            return String(b.saved_at).localeCompare(String(a.saved_at));
        });
        html += '<div class="visit-sub fw-bold">' + esc(v.label)
            + (v.place ? ' <span class="fw-normal text-muted">· ' + esc(kind === 'an' ? 'หอ ' : 'แผนก ') + esc(v.place) + '</span>' : '')
            + ' <span class="fw-normal text-muted">· ' + items.length + ' ครั้ง</span></div>';
        items.forEach(function (it) { html += sessionHtml(it); });
    });
    return html;
}

function renderPeople(groups) {
    const people = {};
    groups.forEach(function (g) {
        (g.items || []).forEach(function (it) {
            const key = histHnKey(it);
            if (!people[key]) {
                people[key] = {
                    hn: it.hn || '',
                    name: it.patient_name || 'ไม่ระบุชื่อ',
                    latest: it.saved_at || '',
                    latest_th: it.saved_at_th || '',
                    ans: {},
                    vns: {}
                };
            }
            const p = people[key];
            if ((it.saved_at || '') > p.latest) {
                p.latest = it.saved_at || '';
                p.latest_th = it.saved_at_th || '';
                if (it.patient_name) p.name = it.patient_name;
                if (it.hn) p.hn = it.hn;
            }
            const isAn = !!it.an;
            const bucket = isAn ? p.ans : p.vns;
            const vk = isAn ? ('an:' + it.an) : (it.vn ? ('vn:' + it.vn) : ('id:' + it.id));
            if (!bucket[vk]) {
                bucket[vk] = {
                    label: isAn ? ('AN ' + it.an) : (it.vn ? ('VN ' + it.vn) : 'ไม่ระบุ AN / VN'),
                    place: isAn ? (it.ward || '') : (it.department || ''),
                    latest: it.saved_at || '',
                    items: []
                };
            }
            bucket[vk].items.push(it);
            if ((it.saved_at || '') > bucket[vk].latest) {
                bucket[vk].latest = it.saved_at || '';
                const place = isAn ? (it.ward || '') : (it.department || '');
                if (place) bucket[vk].place = place;
            }
        });
    });
    const list = Object.keys(people).map(function (k) { return people[k]; });
    list.sort(function (a, b) { return String(b.latest).localeCompare(String(a.latest)); });
    if (!list.length) {
        $('#histList').html('<div class="text-center text-muted py-5">ไม่พบประวัติตามตัวกรอง</div>');
        return;
    }
    let html = '';
    list.forEach(function (p) {
        const anN = Object.keys(p.ans).length;
        const vnN = Object.keys(p.vns).length;
        html += '<div class="an-card">'
            + '<div class="an-head d-flex justify-content-between flex-wrap gap-2">'
            + '<div><div class="fw-bold">' + esc(p.name) + '</div>'
            + '<div class="small text-muted">HN ' + esc(p.hn || '-') + '</div></div>'
            + '<div class="text-end small">'
            + '<div>' + (anN ? '<span class="pill pill-an me-1">AN ' + anN + ' เลข</span>' : '')
            + (vnN ? '<span class="pill pill-vn">VN ' + vnN + ' เลข</span>' : '') + '</div>'
            + '<div class="text-muted mt-1">ล่าสุด ' + esc(p.latest_th || '') + '</div>'
            + '</div></div>'
            + visitBlocksHtml(p.ans, 'an')
            + visitBlocksHtml(p.vns, 'vn')
            + '</div>';
    });
    $('#histList').html(html);
}

function renderGroups(groups) {
    if (!groups || !groups.length) {
        $('#histList').html('<div class="text-center text-muted py-5">ไม่พบประวัติตามตัวกรอง</div>');
        return;
    }
    if (lastGroup === 'an') {
        renderPeople(groups);
        return;
    }
    let html = '';
    groups.forEach(function (g) {
        const n = (g.items || []).length;
        const who = {};
        (g.items || []).forEach(function (it) {
            if (it.saved_name) who[it.saved_name] = true;
        });
        const whoN = Object.keys(who).length;
        html += '<div class="an-card">'
            + '<div class="an-head d-flex justify-content-between flex-wrap gap-2">'
            + '<div><div class="fw-bold">' + esc(g.label) + '</div>'
            + '<div class="small text-muted">แยกแต่ละครั้งที่บันทึก ในแต่ละครั้งดู AN หรือ VN และรายการยาได้</div></div>'
            + '<div class="text-end small">'
            + '<div class="fw-bold">' + n + ' ครั้ง' + (whoN ? ' · ผู้ทำ ' + whoN + ' คน' : '') + '</div>'
            + '<div class="text-muted">ล่าสุด ' + esc(g.latest_th || '') + '</div>'
            + '</div></div>';
        (g.items || []).forEach(function (it) { html += sessionHtml(it); });
        html += '</div>';
    });
    $('#histList').html(html);
}

let chartStaff = null;
let chartDay = null;
let chartKind = null;
let chartPosition = null;
let editId = 0;
let editRows = [];
let deleteId = 0;

function ymd(d) {
    const z = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
}

function setPreset(preset) {
    $('.preset-btn').removeClass('active');
    $('.preset-btn[data-preset="' + preset + '"]').addClass('active');
    const end = new Date();
    if (String(preset) === '0') {
        $('#fFrom').val('');
        $('#fTo').val('');
        return;
    }
    const start = new Date();
    const n = parseInt(preset, 10);
    if (n === 30) start.setMonth(start.getMonth() - 1);
    else if (n === 90) start.setMonth(start.getMonth() - 3);
    else if (n === 365) start.setFullYear(start.getFullYear() - 1);
    else start.setDate(start.getDate() - (n - 1));
    $('#fFrom').val(ymd(start));
    $('#fTo').val(ymd(end));
}

function dropChart(ch) {
    if (ch) {
        try { ch.destroy(); } catch (e) {}
    }
    return null;
}

function renderDashboard(data) {
    const s = data.summary || {};
    const dash = data.dashboard || {};
    $('#sumRecords').text(s.records || 0);
    $('#sumPatients').text(s.patients || 0);
    $('#sumPatientsHint').text('AN ' + (s.patients_an || 0) + ' + VN ' + (s.patients_vn || 0));
    $('#sumAns').text((s.ans || 0) + ' / ' + (s.vns || 0));
    $('#sumStaff').text(s.staff || 0);
    $('#sumWithAdded').text(s.with_added || 0);
    $('#sumAdded').text(s.added_rows || 0);
    const staff = dash.by_staff || [];
    let st = '';
    staff.forEach(function (r) {
        st += '<tr><td>' + esc(r.name) + '</td><td>' + esc(r.position || '') + '</td><td class="text-end fw-bold">' + r.cases + '</td><td class="text-end">' + (r.patients || 0) + '</td><td class="text-end">' + r.added_cases + '</td><td class="text-end">' + r.visit_rows + '</td><td class="text-end">' + r.added_rows + '</td></tr>';
    });
    $('#staffTable').html(st || '<tr><td colspan="7" class="text-muted">ไม่มีข้อมูล</td></tr>');
    const positions = dash.by_position || [];
    let pt = '';
    positions.forEach(function (r) {
        pt += '<tr><td class="fw-bold">' + esc(r.name) + '</td><td class="text-end fw-bold">' + r.cases + '</td><td class="text-end">' + (r.patients || 0) + '</td><td class="text-end">' + (r.staff || 0) + '</td><td class="text-end">' + r.added_cases + '</td></tr>';
    });
    $('#positionTable').html(pt || '<tr><td colspan="5" class="text-muted">ไม่มีข้อมูล</td></tr>');
    const wards = dash.by_ward || [];
    let wt = '';
    wards.forEach(function (r) {
        wt += '<tr><td>' + esc(r.name) + '</td><td class="text-end fw-bold">' + r.cases + '</td></tr>';
    });
    $('#wardTable').html(wt || '<tr><td colspan="2" class="text-muted">ไม่มีข้อมูล</td></tr>');
    const depts = dash.by_department || [];
    let dt = '';
    depts.forEach(function (r) {
        dt += '<tr><td>' + esc(r.name) + '</td><td class="text-end fw-bold">' + r.cases + '</td></tr>';
    });
    $('#deptTable').html(dt || '<tr><td colspan="2" class="text-muted">ไม่มีข้อมูล</td></tr>');

    chartStaff = dropChart(chartStaff);
    chartDay = dropChart(chartDay);
    chartKind = dropChart(chartKind);
    chartPosition = dropChart(chartPosition);
    const posColors = ['#1f4d3b', '#0d6efd', '#b45309', '#6f42c1', '#20c997', '#dc3545', '#6c757d'];
    if (positions.length) chartPosition = new Chart(document.getElementById('chartPosition'), {
        type: 'doughnut',
        data: {
            labels: positions.map(function (r) { return r.name; }),
            datasets: [{
                data: positions.map(function (r) { return r.cases; }),
                backgroundColor: positions.map(function (r, i) { return posColors[i % posColors.length]; })
            }]
        },
        options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
    });
    const top = staff.slice(0, 12);
    chartStaff = new Chart(document.getElementById('chartStaff'), {
        type: 'bar',
        data: {
            labels: top.map(function (r) { return r.name; }),
            datasets: [{ label: 'ครั้ง', data: top.map(function (r) { return r.cases; }), backgroundColor: '#b45309' }]
        },
        options: {
            indexAxis: 'y',
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { x: { beginAtZero: true, ticks: { precision: 0 } } }
        }
    });
    const days = dash.by_day || [];
    chartDay = new Chart(document.getElementById('chartDay'), {
        type: 'bar',
        data: {
            labels: days.map(function (r) { return r.date.slice(8) + '/' + r.date.slice(5, 7); }),
            datasets: [{ label: 'ครั้ง', data: days.map(function (r) { return r.cases; }), backgroundColor: '#1f4d3b' }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
        }
    });
    chartKind = new Chart(document.getElementById('chartKind'), {
        type: 'doughnut',
        data: {
            labels: ['จาก Visit อย่างเดียว', 'มีรายการเพิ่มนอก Visit'],
            datasets: [{ data: [s.visit_only || 0, s.with_added || 0], backgroundColor: ['#198754', '#d97706'] }]
        },
        options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
    });
    $('#kindHint').text('ยาจาก Visit ' + (s.visit_rows || 0) + ' ราย · ยาที่เพิ่ม ' + (s.added_rows || 0) + ' ราย');
}

function editRowHtml(row, idx) {
    const manual = row.is_manual ? ' checked' : '';
    return '<tr data-idx="' + idx + '">'
        + '<td><input class="form-control form-control-sm ed-name" value="' + esc(row.drug_name || '') + '"></td>'
        + '<td><input class="form-control form-control-sm ed-method" value="' + esc(row.method || '') + '"></td>'
        + '<td><input class="form-control form-control-sm ed-qty" value="' + esc(row.qty || '') + '"></td>'
        + '<td><input class="form-control form-control-sm ed-unit" value="' + esc(row.units || '') + '"></td>'
        + '<td><input class="form-control form-control-sm ed-date" value="' + esc(row.order_date || '') + '"></td>'
        + '<td><input class="form-control form-control-sm ed-place" value="' + esc(row.hospital_name || '') + '"></td>'
        + '<td class="text-center"><input type="checkbox" class="form-check-input ed-manual"' + manual + '></td>'
        + '<td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger" onclick="editRemoveRow(' + idx + ')">ลบ</button></td>'
        + '</tr>';
}

function paintEditRows() {
    let html = '';
    editRows.forEach(function (row, idx) { html += editRowHtml(row, idx); });
    $('#edRows').html(html || '<tr><td colspan="8" class="text-muted text-center">ไม่มีรายการ</td></tr>');
}

function syncEditRows() {
    $('#edRows tr').each(function () {
        const idx = Number($(this).data('idx'));
        if (!editRows[idx]) return;
        editRows[idx].drug_name = $(this).find('.ed-name').val();
        editRows[idx].method = $(this).find('.ed-method').val();
        editRows[idx].qty = $(this).find('.ed-qty').val();
        editRows[idx].units = $(this).find('.ed-unit').val();
        editRows[idx].order_date = $(this).find('.ed-date').val();
        editRows[idx].hospital_name = $(this).find('.ed-place').val();
        editRows[idx].is_manual = $(this).find('.ed-manual').is(':checked');
    });
}

function editAddRow() {
    syncEditRows();
    editRows.push({ src_index: -1, drug_name: '', method: '', qty: '', units: '', order_date: '', hospital_name: '', is_manual: true });
    paintEditRows();
}

function editRemoveRow(idx) {
    syncEditRows();
    editRows.splice(idx, 1);
    paintEditRows();
}

async function openEdit(id) {
    editId = id;
    $('#edRows').html('<tr><td colspan="8" class="text-center text-muted">กำลังโหลด...</td></tr>');
    bootstrap.Modal.getOrCreateInstance(document.getElementById('editModal')).show();
    try {
        const res = await fetch('fetch_smart_drug_medrecon_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'history_get', id: 'local:' + id })
        });
        const data = await res.json();
        if (data.status !== 'success') {
            alert(data.message || 'เปิดประวัติไม่ได้');
            return;
        }
        const p = data.payload || {};
        const vnRaw = String(p.vn || '');
        const anRaw = String(p.an || '').trim() || (/^\d{8,10}$/.test(vnRaw) ? vnRaw : '');
        $('#edName').val(p.patient_name || '');
        $('#edHn').val(p.hn || '');
        $('#edAn').val(anRaw);
        $('#edStaff').val(data.saved_name || '');
        $('#edWard').val(p.ward || '');
        $('#edService').val(p.service_date || '');
        $('#edNote').val(p.note_mr || '');
        editRows = (p.rows || []).map(function (r, i) {
            return {
                src_index: i,
                drug_name: r.drug_name || '',
                method: r.method || '',
                qty: r.qty || '',
                units: r.units || '',
                order_date: r.order_date || '',
                hospital_name: r.hospital_name || '',
                is_manual: !!r.is_manual
            };
        });
        paintEditRows();
    } catch (e) {
        alert('เปิดประวัติไม่ได้');
    }
}

async function saveEdit() {
    syncEditRows();
    const res = await fetch('fetch_smart_drug_medrecon_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'history_update',
            id: editId,
            fields: {
                patient_name: $('#edName').val().trim(),
                hn: $('#edHn').val().trim(),
                an: $('#edAn').val().trim(),
                saved_name: $('#edStaff').val().trim(),
                ward: $('#edWard').val().trim(),
                service_date: $('#edService').val().trim(),
                note_mr: $('#edNote').val().trim(),
                rows: editRows
            }
        })
    });
    const data = await res.json();
    if (data.status !== 'success') {
        alert(data.message || 'บันทึกไม่สำเร็จ');
        return;
    }
    bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
    loadHistory();
}

function openDelete(id) {
    deleteId = id;
    $('#delConfirm').val('');
    $('#btnDoDelete').prop('disabled', true);
    $('#delHint').text('ยืนยันลบประวัตินี้ การลบย้อนกลับไม่ได้');
    bootstrap.Modal.getOrCreateInstance(document.getElementById('delModal')).show();
    setTimeout(function () { $('#delConfirm').trigger('focus'); }, 200);
}

async function loadHistory() {
    $('#histList').html('<div class="text-center text-muted py-5"><i class="fas fa-spinner fa-spin me-1"></i> กำลังโหลด...</div>');
    const from = $('#fFrom').val();
    const to = $('#fTo').val();
    const body = {
        action: 'history_report',
        date_from: from,
        date_to: to,
        days: (from || to) ? 30 : 0,
        q: $('#fQ').val().trim(),
        an: $('#fAn').val().trim(),
        staff: $('#fStaff').val() || '',
        position: $('#fPosition').val() || '',
        kind: $('#fKind').val() || 'all',
        group: $('#fGroup').val() || 'an'
    };
    try {
        const res = await fetch('fetch_smart_drug_medrecon_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const data = await res.json();
        if (data.status !== 'success') {
            $('#histList').html('<div class="text-center text-danger py-5">' + esc(data.message || 'โหลดไม่สำเร็จ') + '</div>');
            return;
        }
        const keep = $('#fStaff').val() || '';
        let opts = '<option value="">ทั้งหมด</option>';
        (data.staff || []).forEach(function (name) {
            opts += '<option value="' + esc(name) + '"' + (name === keep ? ' selected' : '') + '>' + esc(name) + '</option>';
        });
        $('#fStaff').html(opts);
        const keepPos = $('#fPosition').val() || '';
        let popts = '<option value="">ทั้งหมด</option>';
        (data.positions || []).forEach(function (p) {
            popts += '<option value="' + esc(p.key) + '"' + (p.key === keepPos ? ' selected' : '') + '>' + esc(p.label) + '</option>';
        });
        $('#fPosition').html(popts);
        lastGroup = data.group || 'an';
        renderDashboard(data);
        renderGroups(data.groups || []);
    } catch (e) {
        $('#histList').html('<div class="text-center text-danger py-5">โหลดประวัติไม่สำเร็จ</div>');
    }
}

$('#btnSearch').on('click', loadHistory);
$('#fStaff, #fPosition, #fKind, #fGroup').on('change', loadHistory);
$('#fFrom, #fTo').on('change', function () {
    $('.preset-btn').removeClass('active');
    loadHistory();
});
$('.preset-btn').on('click', function () {
    setPreset($(this).data('preset'));
    loadHistory();
});
$('#fQ, #fAn').on('keydown', function (e) {
    if (e.key === 'Enter') loadHistory();
});
$('#delConfirm').on('input', function () {
    $('#btnDoDelete').prop('disabled', String($(this).val()).trim() !== 'delete');
});
$('#btnDoDelete').on('click', async function () {
    if (String($('#delConfirm').val()).trim() !== 'delete' || !deleteId) return;
    const res = await fetch('fetch_smart_drug_medrecon_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'history_delete', id: 'local:' + deleteId, confirm: 'delete' })
    });
    const data = await res.json();
    if (data.status !== 'success') {
        alert(data.message || 'ลบไม่สำเร็จ');
        return;
    }
    bootstrap.Modal.getInstance(document.getElementById('delModal')).hide();
    loadHistory();
});
$('#btnSaveEdit').on('click', function () { saveEdit(); });
setPreset('30');
loadHistory();
</script>
</body>
</html>
