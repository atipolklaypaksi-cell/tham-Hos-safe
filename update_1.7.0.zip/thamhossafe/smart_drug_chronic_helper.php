<?php
/**
 * รายการยาเรื้อรังของ Smart Drug — ใช้รหัส TMT (tpu_code) ร่วมกันทุกโรงพยาบาล
 * ค่าเริ่มต้นนำเข้าจากกลุ่ม ICD10 ของรพร.สระแก้ว: เบาหวาน ไขมัน ความดัน
 */

function sd_chronic_default_groups() {
    return ['โรคเบาหวาน', 'โรคไขมันในเลือดสูง', 'โรคความดันโลหิตสูง'];
}

function sd_chronic_ensure($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $ok = mysqli_query($con, "CREATE TABLE IF NOT EXISTS smart_drug_chronic_drug (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tpu_code VARCHAR(32) NOT NULL,
        drug_name VARCHAR(255) NOT NULL DEFAULT '',
        source_label VARCHAR(255) NOT NULL DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_sd_chronic_tpu (tpu_code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    $ready = (bool)$ok;
    return $ready;
}

function sd_chronic_cfg($con, $name, $default = '') {
    $esc = mysqli_real_escape_string($con, $name);
    $q = mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = '$esc' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return (string)$r['config_value'];
    }
    return $default;
}

function sd_chronic_cfg_set($con, $name, $value) {
    $n = mysqli_real_escape_string($con, $name);
    $v = mysqli_real_escape_string($con, (string)$value);
    $q = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name = '$n' LIMIT 1");
    if ($q && mysqli_num_rows($q) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value = '$v' WHERE config_name = '$n'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$n', '$v')");
}

function sd_chronic_cut($text, $max = 255) {
    $text = (string)$text;
    if (strlen($text) <= $max) {
        return $text;
    }
    $text = substr($text, 0, $max);
    return (string)preg_replace('/[\x80-\xBF\xC0-\xFF]+$/', '', $text);
}

function sd_chronic_display_name($tmt_name, $local_name) {
    $tmt = trim((string)$tmt_name);
    $local = trim((string)$local_name);
    if ($tmt !== '') {
        return $tmt;
    }
    return $local;
}

function sd_chronic_import_group($con, $hos, $property_name) {
    sd_chronic_ensure($con);
    $property_name = trim((string)$property_name);
    if ($property_name === '' || !$hos) {
        return 0;
    }
    $esc = mysqli_real_escape_string($hos, $property_name);
    $q = mysqli_query($hos, "
        SELECT DISTINCT TRIM(d.tpu_code_list) AS tpu_code,
               CAST(CONVERT(TRIM(CONCAT(IFNULL(tm.active_ingredient,''), ' ', IFNULL(tm.strength,''))) USING utf8) AS CHAR) AS tmt_name,
               CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS local_name
        FROM drugitems d
        INNER JOIN drugitems_property_list dl ON dl.icode = d.icode
        INNER JOIN drugitems_property dp ON dp.drugitems_property_id = dl.drugitems_property_id
        LEFT JOIN tmt_tpu_code tm ON tm.tpu_code = d.tpu_code_list
        WHERE dp.group_code = 'ICD10'
          AND dp.drugitems_property_name = '$esc'
          AND TRIM(IFNULL(d.tpu_code_list,'')) <> ''
    ");
    if (!$q) {
        return -1;
    }
    $n = 0;
    $label = mysqli_real_escape_string($con, $property_name);
    while ($r = mysqli_fetch_assoc($q)) {
        $tpu = trim((string)($r['tpu_code'] ?? ''));
        if ($tpu === '' || strlen($tpu) > 32) {
            continue;
        }
        $name = sd_chronic_display_name($r['tmt_name'] ?? '', $r['local_name'] ?? '');
        $name_esc = mysqli_real_escape_string($con, sd_chronic_cut($name, 255));
        $tpu_esc = mysqli_real_escape_string($con, $tpu);
        $ok = mysqli_query($con, "
            INSERT INTO smart_drug_chronic_drug (tpu_code, drug_name, source_label)
            VALUES ('$tpu_esc', '$name_esc', '$label')
            ON DUPLICATE KEY UPDATE
                drug_name = IF(drug_name = '', VALUES(drug_name), drug_name)
        ");
        if ($ok && mysqli_affected_rows($con) > 0) {
            $n++;
        }
    }
    return $n;
}

function sd_chronic_seed_defaults($con) {
    sd_chronic_ensure($con);
    if (sd_chronic_cfg($con, 'smart_drug_chronic_seeded', '') === '1') {
        return 0;
    }
    if (!function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    }
    $hos = hosxp_connect($con, 20);
    if (!$hos) {
        return 0;
    }
    $n = 0;
    $failed = false;
    foreach (sd_chronic_default_groups() as $group) {
        $added = sd_chronic_import_group($con, $hos, $group);
        if ($added < 0) {
            $failed = true;
            continue;
        }
        $n += $added;
    }
    mysqli_close($hos);
    if (!$failed) {
        sd_chronic_cfg_set($con, 'smart_drug_chronic_seeded', '1');
    }
    return $n;
}

function sd_chronic_tpu_set($con) {
    static $set = null;
    if ($set !== null) {
        return $set;
    }
    sd_chronic_seed_defaults($con);
    $set = [];
    $q = mysqli_query($con, "SELECT tpu_code FROM smart_drug_chronic_drug");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $tpu = trim((string)($r['tpu_code'] ?? ''));
            if ($tpu !== '') {
                $set[$tpu] = true;
            }
        }
    }
    return $set;
}

function sd_chronic_name_blocked($row) {
    $name = trim((string)($row['drug_name'] ?? '') . ' ' . (string)($row['drug_name_local'] ?? ''));
    return $name !== '' && preg_match('/ผู้ป่วยไตเรื้อรัง\s*ระยะที่/u', $name) === 1;
}

function sd_chronic_mark_history($con, array &$history) {
    $set = sd_chronic_tpu_set($con);
    foreach ($history as &$row) {
        if (!is_array($row)) {
            continue;
        }
        $tpu = trim((string)($row['tpu_code'] ?? ''));
        $continuous = strtoupper(trim((string)($row['continuous'] ?? ''))) === 'Y';
        $in_list = ($tpu !== '' && isset($set[$tpu]));
        $row['is_chronic'] = ($tpu !== '' && !sd_chronic_name_blocked($row) && ($continuous || $in_list));
        unset($row['tpu_code'], $row['continuous']);
    }
    unset($row);
}

function sd_chronic_list($con) {
    sd_chronic_seed_defaults($con);
    $rows = [];
    $q = mysqli_query($con, "SELECT id, tpu_code, drug_name, source_label FROM smart_drug_chronic_drug ORDER BY source_label ASC, drug_name ASC, tpu_code ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'id' => (int)$r['id'],
                'tpu_code' => (string)$r['tpu_code'],
                'drug_name' => (string)$r['drug_name'],
                'source_label' => (string)$r['source_label'],
            ];
        }
    }
    return $rows;
}

function sd_chronic_add($con, $tpu, $drug_name, $source_label = 'เพิ่มเอง') {
    sd_chronic_ensure($con);
    $tpu = trim((string)$tpu);
    $drug_name = trim((string)$drug_name);
    $source_label = trim((string)$source_label);
    if ($source_label === '') {
        $source_label = 'เพิ่มเอง';
    }
    if (!preg_match('/^[0-9A-Za-z][0-9A-Za-z._-]{2,31}$/', $tpu)) {
        return ['ok' => false, 'message' => 'รหัส TMT ไม่ถูกต้อง'];
    }
    if ($drug_name === '') {
        return ['ok' => false, 'message' => 'ไม่มีชื่อยา'];
    }
    $tpu_esc = mysqli_real_escape_string($con, $tpu);
    $name_esc = mysqli_real_escape_string($con, sd_chronic_cut($drug_name, 255));
    $label_esc = mysqli_real_escape_string($con, sd_chronic_cut($source_label, 255));
    $ok = mysqli_query($con, "
        INSERT INTO smart_drug_chronic_drug (tpu_code, drug_name, source_label)
        VALUES ('$tpu_esc', '$name_esc', '$label_esc')
        ON DUPLICATE KEY UPDATE drug_name = VALUES(drug_name), source_label = VALUES(source_label)
    ");
    if (!$ok) {
        return ['ok' => false, 'message' => 'บันทึกไม่สำเร็จ'];
    }
    return ['ok' => true];
}

function sd_chronic_set_group($con, $id, $source_label) {
    sd_chronic_ensure($con);
    $id = (int)$id;
    $source_label = trim((string)$source_label);
    if ($id <= 0) {
        return ['ok' => false, 'message' => 'ไม่พบรายการ'];
    }
    if ($source_label === '') {
        return ['ok' => false, 'message' => 'กรุณาระบุกลุ่มโรค'];
    }
    $label_esc = mysqli_real_escape_string($con, sd_chronic_cut($source_label, 255));
    $ok = mysqli_query($con, "UPDATE smart_drug_chronic_drug SET source_label = '$label_esc' WHERE id = $id LIMIT 1");
    if (!$ok || mysqli_affected_rows($con) < 0) {
        return ['ok' => false, 'message' => 'บันทึกกลุ่มโรคไม่สำเร็จ'];
    }
    $q = mysqli_query($con, "SELECT id FROM smart_drug_chronic_drug WHERE id = $id LIMIT 1");
    if (!$q || !mysqli_fetch_assoc($q)) {
        return ['ok' => false, 'message' => 'ไม่พบรายการ'];
    }
    return ['ok' => true];
}

function sd_chronic_delete($con, $id) {
    sd_chronic_ensure($con);
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "DELETE FROM smart_drug_chronic_drug WHERE id = $id LIMIT 1");
}

function sd_chronic_search($con, $q, $limit = 40) {
    $q = trim((string)$q);
    if (strlen($q) < 2) {
        return [];
    }
    if (!function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    }
    $hos = hosxp_connect($con, 20);
    if (!$hos) {
        return [];
    }
    $like = mysqli_real_escape_string($hos, str_replace(['%', '_'], ['\\%', '\\_'], $q));
    $exact = mysqli_real_escape_string($hos, $q);
    $limit = max(1, min(60, (int)$limit));
    $sql = "
        SELECT DISTINCT TRIM(d.tpu_code_list) AS tpu_code,
               CAST(CONVERT(TRIM(CONCAT(IFNULL(tm.active_ingredient,''), ' ', IFNULL(tm.strength,''))) USING utf8) AS CHAR) AS tmt_name,
               CAST(CONVERT(IFNULL(d.name,'') USING utf8) AS CHAR) AS local_name
        FROM drugitems d
        LEFT JOIN tmt_tpu_code tm ON tm.tpu_code = d.tpu_code_list
        WHERE TRIM(IFNULL(d.tpu_code_list,'')) <> ''
          AND (
                d.tpu_code_list = '$exact'
                OR d.name LIKE '%$like%'
                OR IFNULL(tm.active_ingredient,'') LIKE '%$like%'
          )
        ORDER BY tmt_name ASC, local_name ASC
        LIMIT $limit
    ";
    $res = mysqli_query($hos, $sql);
    $rows = [];
    if ($res) {
        while ($r = mysqli_fetch_assoc($res)) {
            $tpu = trim((string)($r['tpu_code'] ?? ''));
            if ($tpu === '') {
                continue;
            }
            $rows[] = [
                'tpu_code' => $tpu,
                'drug_name' => sd_chronic_display_name($r['tmt_name'] ?? '', $r['local_name'] ?? ''),
                'local_name' => trim((string)($r['local_name'] ?? '')),
            ];
        }
    }
    mysqli_close($hos);
    return $rows;
}

function sd_chronic_groups($con) {
    sd_chronic_ensure($con);
    if (!function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    }
    $hos = hosxp_connect($con, 20);
    if (!$hos) {
        return [];
    }
    $saved = sd_chronic_tpu_set($con);
    $q = mysqli_query($hos, "
        SELECT CAST(CONVERT(dp.drugitems_property_name USING utf8) AS CHAR) AS property_name,
               TRIM(d.tpu_code_list) AS tpu_code
        FROM drugitems d
        INNER JOIN drugitems_property_list dl ON dl.icode = d.icode
        INNER JOIN drugitems_property dp ON dp.drugitems_property_id = dl.drugitems_property_id
        WHERE dp.group_code = 'ICD10'
          AND TRIM(IFNULL(d.tpu_code_list,'')) <> ''
    ");
    $groups = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $name = trim((string)($r['property_name'] ?? ''));
            $tpu = trim((string)($r['tpu_code'] ?? ''));
            if ($name === '' || $tpu === '') {
                continue;
            }
            if (!isset($groups[$name])) {
                $groups[$name] = ['name' => $name, 'tpu' => [], 'saved' => 0];
            }
            if (!isset($groups[$name]['tpu'][$tpu])) {
                $groups[$name]['tpu'][$tpu] = true;
                if (isset($saved[$tpu])) {
                    $groups[$name]['saved']++;
                }
            }
        }
    }
    mysqli_close($hos);
    $out = [];
    foreach ($groups as $g) {
        $total = count($g['tpu']);
        $out[] = [
            'name' => $g['name'],
            'tpu_count' => $total,
            'saved_count' => (int)$g['saved'],
        ];
    }
    usort($out, function ($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
    return $out;
}
