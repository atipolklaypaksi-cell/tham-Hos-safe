<?php
/**
 * Smart Pharma Backup — คัดกรองจริงทำที่ cron เครื่องเดียว
 * เครื่องที่เปิดหลายเครื่อง poll เฉพาะ alert จากฐาน THAM ไม่ยิง HOSxP ซ้ำ
 */

function sp_backup_dispense_rooms() {
    return [
        'opd' => 'ห้องจ่ายยาผู้ป่วยนอก',
        'ipd' => 'ห้องจ่ายยาผู้ป่วยใน',
    ];
}

function sp_backup_roles() {
    return ['pharmacist', 'pharmacy_technician'];
}

function sp_backup_default_config() {
    return [
        'backup_opd' => 0,
        'backup_ipd' => 0,
        'alert_hard' => 1,
        'alert_soft' => 0,
        'sound_enabled' => 1,
        'interval_min' => 3,
        'lookback_minutes' => 60,
        'suppress_page_autorefresh' => 1,
    ];
}

function sp_backup_ensure_schema($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $cq2 = @mysqli_query($con, "SHOW COLUMNS FROM users LIKE 'dispense_room'");
    if (!$cq2 || mysqli_num_rows($cq2) === 0) {
        @mysqli_query($con, "ALTER TABLE users ADD COLUMN dispense_room VARCHAR(10) NULL DEFAULT NULL AFTER unit_ward");
    }
    @mysqli_query($con, "CREATE TABLE IF NOT EXISTS smart_pharma_backup_role_access (
        role VARCHAR(40) NOT NULL PRIMARY KEY,
        allowed TINYINT(1) NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    $q = @mysqli_query($con, "SELECT COUNT(*) AS c FROM smart_pharma_backup_role_access");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if ((int)($row['c'] ?? 0) === 0) {
        foreach (sp_backup_roles() as $role) {
            $esc = mysqli_real_escape_string($con, $role);
            @mysqli_query($con, "INSERT INTO smart_pharma_backup_role_access (role, allowed) VALUES ('$esc', 1)");
        }
    }
    $defaults = sp_backup_default_config();
    foreach ($defaults as $name => $val) {
        $key = 'sp_backup_' . $name;
        $esc = mysqli_real_escape_string($con, $key);
        $q = @mysqli_query($con, "SELECT 1 FROM sys_config WHERE config_name='$esc' LIMIT 1");
        if (!$q || mysqli_num_rows($q) === 0) {
            $v = mysqli_real_escape_string($con, (string)(int)$val);
            @mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$esc', '$v')");
        }
    }
    $ready = true;
    return true;
}

function sp_backup_get_config($con) {
    sp_backup_ensure_schema($con);
    $cfg = sp_backup_default_config();
    $keys = [];
    foreach (array_keys($cfg) as $name) {
        $keys[] = "'" . mysqli_real_escape_string($con, 'sp_backup_' . $name) . "'";
    }
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN (" . implode(',', $keys) . ")");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $name = preg_replace('/^sp_backup_/', '', (string)($r['config_name'] ?? ''));
            if ($name !== '' && array_key_exists($name, $cfg)) {
                $cfg[$name] = (int)$r['config_value'];
            }
        }
    }
    $cfg['backup_opd'] = !empty($cfg['backup_opd']) ? 1 : 0;
    $cfg['backup_ipd'] = !empty($cfg['backup_ipd']) ? 1 : 0;
    $cfg['alert_hard'] = !empty($cfg['alert_hard']) ? 1 : 0;
    $cfg['alert_soft'] = !empty($cfg['alert_soft']) ? 1 : 0;
    if ($cfg['alert_hard'] === 0 && $cfg['alert_soft'] === 0) {
        $cfg['alert_hard'] = 1;
    }
    $cfg['sound_enabled'] = !empty($cfg['sound_enabled']) ? 1 : 0;
    $cfg['suppress_page_autorefresh'] = !empty($cfg['suppress_page_autorefresh']) ? 1 : 0;
    $iv = (int)$cfg['interval_min'];
    if ($iv < 1) {
        $iv = 1;
    }
    if ($iv > 30) {
        $iv = 30;
    }
    $cfg['interval_min'] = $iv;
    $cfg['lookback_minutes'] = sp_backup_normalize_lookback($cfg['lookback_minutes'] ?? 60);
    return $cfg;
}

function sp_backup_normalize_lookback($minutes) {
    $allowed = [30, 60, 120, 180, 360, 0];
    $minutes = (int)$minutes;
    if (in_array($minutes, $allowed, true)) {
        return $minutes;
    }
    if ($minutes < 0) {
        return 60;
    }
    if ($minutes === 0) {
        return 0;
    }
    if ($minutes < 45) {
        return 30;
    }
    if ($minutes < 90) {
        return 60;
    }
    if ($minutes < 150) {
        return 120;
    }
    if ($minutes < 240) {
        return 180;
    }
    if ($minutes < 720) {
        return 360;
    }
    return 0;
}

function sp_backup_lookback_label($minutes) {
    $minutes = sp_backup_normalize_lookback($minutes);
    $map = [
        30 => '30 นาทีล่าสุด',
        60 => '1 ชั่วโมงล่าสุด',
        120 => '2 ชั่วโมงล่าสุด',
        180 => '3 ชั่วโมงล่าสุด',
        360 => '6 ชั่วโมงล่าสุด',
        0 => 'ทั้งวัน',
    ];
    return $map[$minutes] ?? '1 ชั่วโมงล่าสุด';
}

function sp_backup_screen_window($minutes) {
    $minutes = sp_backup_normalize_lookback($minutes);
    $map = [
        0 => 'full',
        30 => '30m',
        60 => '1h',
        120 => '2h',
        180 => '3h',
        360 => '6h',
    ];
    return $map[$minutes] ?? '1h';
}

function sp_backup_save_config($con, array $src) {
    sp_backup_ensure_schema($con);
    $cfg = sp_backup_get_config($con);
    foreach (array_keys(sp_backup_default_config()) as $name) {
        if (isset($src[$name])) {
            $cfg[$name] = (int)$src[$name];
        }
    }
    $cfg['backup_opd'] = !empty($cfg['backup_opd']) ? 1 : 0;
    $cfg['backup_ipd'] = !empty($cfg['backup_ipd']) ? 1 : 0;
    $cfg['alert_hard'] = !empty($cfg['alert_hard']) ? 1 : 0;
    $cfg['alert_soft'] = !empty($cfg['alert_soft']) ? 1 : 0;
    if ($cfg['alert_hard'] === 0 && $cfg['alert_soft'] === 0) {
        $cfg['alert_hard'] = 1;
    }
    $cfg['sound_enabled'] = !empty($cfg['sound_enabled']) ? 1 : 0;
    $cfg['suppress_page_autorefresh'] = !empty($cfg['suppress_page_autorefresh']) ? 1 : 0;
    $iv = (int)$cfg['interval_min'];
    if ($iv < 1) {
        $iv = 1;
    }
    if ($iv > 30) {
        $iv = 30;
    }
    $cfg['interval_min'] = $iv;
    $cfg['lookback_minutes'] = sp_backup_normalize_lookback($cfg['lookback_minutes'] ?? 60);
    foreach ($cfg as $name => $val) {
        $key = mysqli_real_escape_string($con, 'sp_backup_' . $name);
        $v = mysqli_real_escape_string($con, (string)(int)$val);
        $ok = mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$key', '$v')
            ON DUPLICATE KEY UPDATE config_value='$v'");
        if (!$ok) {
            return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ'];
        }
    }
    if (isset($src['roles']) && is_array($src['roles'])) {
        $rr = sp_backup_save_role_access($con, $src['roles']);
        if (empty($rr['ok'])) {
            return ['ok' => false, 'error' => $rr['error'] ?? 'บันทึกสิทธิ์ไม่สำเร็จ'];
        }
    }
    return ['ok' => true, 'config' => $cfg, 'roles' => sp_backup_get_role_access($con)];
}

function sp_backup_get_role_access($con) {
    if (!function_exists('tham_menu_role_labels')) {
        require_once __DIR__ . '/menu_permissions_helper.php';
    }
    sp_backup_ensure_schema($con);
    $labels = tham_menu_role_labels();
    $defaults = array_fill_keys(sp_backup_roles(), 1);
    $map = [];
    foreach (array_keys($labels) as $role) {
        $map[$role] = !empty($defaults[$role]) ? 1 : 0;
    }
    $q = mysqli_query($con, "SELECT role, allowed FROM smart_pharma_backup_role_access");
    $has_row = false;
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $has_row = true;
            $role = strtolower(trim((string)($r['role'] ?? '')));
            if ($role !== '' && array_key_exists($role, $map)) {
                $map[$role] = !empty($r['allowed']) ? 1 : 0;
            }
        }
    }
    if (!$has_row) {
        foreach ($defaults as $role => $on) {
            $map[$role] = $on;
        }
    }
    return $map;
}

function sp_backup_save_role_access($con, array $allowed_map) {
    sp_backup_ensure_schema($con);
    if (!function_exists('tham_menu_role_labels')) {
        require_once __DIR__ . '/menu_permissions_helper.php';
    }
    $valid = array_keys(tham_menu_role_labels());
    foreach ($valid as $role) {
        $on = !empty($allowed_map[$role]) ? 1 : 0;
        $esc = mysqli_real_escape_string($con, $role);
        $sql = "INSERT INTO smart_pharma_backup_role_access (role, allowed) VALUES ('$esc', $on)
                ON DUPLICATE KEY UPDATE allowed=$on";
        if (!mysqli_query($con, $sql)) {
            return ['ok' => false, 'error' => 'บันทึกสิทธิ์ไม่สำเร็จ'];
        }
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION['sp_backup_role_access'] = sp_backup_get_role_access($con);
    }
    return ['ok' => true, 'roles' => sp_backup_get_role_access($con)];
}

function sp_backup_feature_on(array $cfg = null, $con = null) {
    if ($cfg === null) {
        $cfg = $con ? sp_backup_get_config($con) : sp_backup_default_config();
    }
    return !empty($cfg['backup_opd']) || !empty($cfg['backup_ipd']);
}

function sp_backup_room_key($value = null) {
    $v = strtolower(trim((string)($value !== null ? $value : ($_SESSION['dispense_room'] ?? ''))));
    return isset(sp_backup_dispense_rooms()[$v]) ? $v : '';
}

function sp_backup_room_label($value = null) {
    $key = sp_backup_room_key($value);
    $map = sp_backup_dispense_rooms();
    return $key !== '' ? $map[$key] : '';
}

function sp_backup_room_patient_type($value = null) {
    $key = sp_backup_room_key($value);
    if ($key === 'ipd') {
        return 'IPD';
    }
    if ($key === 'opd') {
        return 'OPD';
    }
    return '';
}

function sp_backup_role_ok($role = null, $con = null) {
    $role = strtolower(trim((string)($role !== null ? $role : ($_SESSION['role'] ?? ''))));
    if ($role === '') {
        return false;
    }
    if ($con === null && isset($GLOBALS['con']) && $GLOBALS['con']) {
        $con = $GLOBALS['con'];
    }
    if ($con) {
        $map = sp_backup_get_role_access($con);
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION['sp_backup_role_access'] = $map;
        }
        return !empty($map[$role]);
    }
    $map = (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['sp_backup_role_access']) && is_array($_SESSION['sp_backup_role_access']))
        ? $_SESSION['sp_backup_role_access']
        : array_fill_keys(sp_backup_roles(), 1);
    return !empty($map[$role]);
}

function sp_backup_set_room($con, $user_id, $room) {
    sp_backup_ensure_schema($con);
    $user_id = (int)$user_id;
    $room = sp_backup_room_key($room);
    if ($user_id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบผู้ใช้'];
    }
    if ($room === '') {
        return ['ok' => false, 'error' => 'กรุณาเลือกห้องจ่ายยา'];
    }
    $esc = mysqli_real_escape_string($con, $room);
    $ok = mysqli_query($con, "UPDATE users SET dispense_room='$esc' WHERE id=$user_id");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ'];
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION['dispense_room'] = $room;
        $_SESSION['dispense_room_confirmed'] = 1;
        $_SESSION['sp_bk_ui_epoch'] = time();
    }
    return ['ok' => true, 'dispense_room' => $room, 'label' => sp_backup_room_label($room)];
}

function sp_backup_must_confirm($con) {
    if (session_status() !== PHP_SESSION_ACTIVE || empty($_SESSION['user_id'])) {
        return false;
    }
    if (!sp_backup_can_pick_room($con)) {
        return false;
    }
    if (!sp_backup_feature_on(null, $con)) {
        return false;
    }
    return empty($_SESSION['dispense_room_confirmed']);
}

function sp_backup_gate($con) {
    if (php_sapi_name() === 'cli') {
        return;
    }
    if (session_status() !== PHP_SESSION_ACTIVE || empty($_SESSION['user_id'])) {
        return;
    }
    if (headers_sent()) {
        return;
    }
    $page = basename((string)($_SERVER['PHP_SELF'] ?? ''));
    if (function_exists('tham_user_unit_skip_page') && tham_user_unit_skip_page($page)) {
        return;
    }
    if (sp_backup_apply_visit_room($con, $page)) {
        return;
    }
    if ($page === 'select_dispense.php') {
        return;
    }
    if (sp_backup_must_confirm($con)) {
        header('Location: select_dispense.php');
        exit;
    }
}

function sp_backup_apply_visit_room($con, $page)
{
    $page = strtolower((string)$page);
    if ($page !== 'drug_eval_j2.php' && $page !== 'select_dispense.php') {
        return false;
    }
    $from_alert = !empty($_GET['hosxp']) || !empty($_GET['an']) || !empty($_GET['vn']) || !empty($_SESSION['hosxp_j2_auto']);
    if (!$from_alert && (($_SESSION['login_via'] ?? '') === 'hosxp') && sp_backup_must_confirm($con)) {
        $from_alert = true;
    }
    if (!$from_alert) {
        return false;
    }
    $an = trim((string)($_GET['an'] ?? ($_SESSION['hosxp_j2_an'] ?? '')));
    $vn = trim((string)($_GET['vn'] ?? ($_SESSION['hosxp_j2_vn'] ?? '')));
    $hn = trim((string)($_GET['hn'] ?? ($_SESSION['hosxp_j2_hn'] ?? '')));
    $icode = trim((string)($_GET['icode'] ?? ($_SESSION['hosxp_j2_icode'] ?? '')));
    if ($an === '' && $vn === '' && $hn !== '' && $icode !== '') {
        if (!function_exists('tham_alert_j2_lookup_visit')) {
            require_once __DIR__ . '/tham_alert_helper.php';
        }
        $visit = tham_alert_j2_lookup_visit($con, $hn, $icode);
        $an = trim((string)($visit['an'] ?? ''));
        $vn = trim((string)($visit['vn'] ?? ''));
        $_SESSION['hosxp_j2_an'] = $an;
        $_SESSION['hosxp_j2_vn'] = $vn;
    }
    $room = $an !== '' ? 'ipd' : ($vn !== '' ? 'opd' : '');
    if ($room === '') {
        return false;
    }
    sp_backup_set_room($con, (int)($_SESSION['user_id'] ?? 0), $room);
    if ($page === 'select_dispense.php') {
        $form = trim((string)($_GET['form'] ?? ($_SESSION['hosxp_j2_form'] ?? '')));
        $dest = 'drug_eval_j2.php?hn=' . rawurlencode($hn)
            . '&icode=' . rawurlencode($icode)
            . '&phase=first';
        if ($form !== '') {
            $dest .= '&form=' . rawurlencode($form);
        }
        if ($an !== '') {
            $dest .= '&an=' . rawurlencode($an);
        }
        if ($vn !== '') {
            $dest .= '&vn=' . rawurlencode($vn);
        }
        header('Location: ' . $dest);
        exit;
    }
    return true;
}

function sp_backup_is_active_for($con, $patient_type) {
    if (!sp_backup_can_pick_room($con)) {
        return false;
    }
    $cfg = sp_backup_get_config($con);
    $pt = strtoupper(trim((string)$patient_type));
    if ($pt === 'OPD' && empty($cfg['backup_opd'])) {
        return false;
    }
    if ($pt === 'IPD' && empty($cfg['backup_ipd'])) {
        return false;
    }
    $room_pt = sp_backup_room_patient_type();
    return $room_pt !== '' && $room_pt === $pt && !empty($_SESSION['dispense_room_confirmed']);
}

function sp_backup_can_pick_room($con = null, $role = null) {
    if (sp_backup_role_ok($role, $con)) {
        return true;
    }
    $role = strtolower(trim((string)($role !== null ? $role : ($_SESSION['role'] ?? ''))));
    return $role === 'admin';
}

function sp_backup_user_eligible($con, $role = null) {
    if (!sp_backup_can_pick_room($con, $role)) {
        return false;
    }
    $cfg = sp_backup_get_config($con);
    if (!sp_backup_feature_on($cfg)) {
        return false;
    }
    $pt = sp_backup_room_patient_type();
    if ($pt === '') {
        return false;
    }
    if ($pt === 'OPD' && empty($cfg['backup_opd'])) {
        return false;
    }
    if ($pt === 'IPD' && empty($cfg['backup_ipd'])) {
        return false;
    }
    return true;
}

function sp_backup_parse_rx_ts($rxdate, $rxtime) {
    $d = trim((string)$rxdate);
    $t = trim((string)$rxtime);
    if ($d === '' || $d === '0000-00-00' || $t === '') {
        return null;
    }
    if (preg_match('/^\d{4}$/', $t)) {
        $t = substr($t, 0, 2) . ':' . substr($t, 2, 2) . ':00';
    } elseif (preg_match('/^\d{6}$/', $t)) {
        $t = substr($t, 0, 2) . ':' . substr($t, 2, 2) . ':' . substr($t, 4, 2);
    } elseif (strlen($t) === 5) {
        $t .= ':00';
    }
    $tz = new DateTimeZone('Asia/Bangkok');
    $dt = DateTime::createFromFormat('Y-m-d H:i:s', $d . ' ' . $t, $tz);
    if (!$dt) {
        try {
            $dt = new DateTime($d . ' ' . $t, $tz);
        } catch (Exception $e) {
            return null;
        }
    }
    return $dt->getTimestamp();
}

function sp_backup_row_in_lookback(array $row, $minutes) {
    $minutes = (int)$minutes;
    if ($minutes <= 0) {
        return true;
    }
    $cutoff = time() - ($minutes * 60);
    $ts = sp_backup_parse_rx_ts($row['rxdate'] ?? '', $row['rxtime'] ?? '');
    if ($ts === null) {
        $fd = trim((string)($row['first_detected_at'] ?? ''));
        if ($fd === '') {
            return false;
        }
        $ts = strtotime($fd);
        if ($ts === false) {
            return false;
        }
    }
    return $ts >= $cutoff;
}

function sp_poll_cache_get($key, $ttl) {
    $dir = sys_get_temp_dir() . '/tham_poll_cache';
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $path = $dir . '/' . preg_replace('/[^a-z0-9_\-]/i', '', (string)$key) . '.json';
    $fp = @fopen($path, 'c+');
    if (!$fp) {
        return [null, null];
    }
    if (!flock($fp, LOCK_EX)) {
        fclose($fp);
        return [null, null];
    }
    $raw = stream_get_contents($fp);
    $cached = json_decode((string)$raw, true);
    if (is_array($cached) && isset($cached['data']) && (time() - (int)($cached['t'] ?? 0)) < (int)$ttl) {
        flock($fp, LOCK_UN);
        fclose($fp);
        return [$cached['data'], null];
    }
    return [null, $fp];
}

function sp_poll_cache_put($fp, $data) {
    if (!is_resource($fp)) {
        return;
    }
    $payload = json_encode(['t' => time(), 'data' => $data], JSON_UNESCAPED_UNICODE);
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, $payload === false ? '{}' : $payload);
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
}

function sp_backup_pending($con) {
    $pt_key = sp_backup_room_patient_type();
    list($cached, $cache_fp) = sp_poll_cache_get('spbk_' . ($pt_key === '' ? 'none' : strtolower($pt_key)), 8);
    if ($cached !== null) {
        return $cached;
    }
    if (!function_exists('sp_alert_log_ensure_tables')) {
        require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
    }
    sp_alert_log_ensure_tables($con);
    $cfg = sp_backup_get_config($con);
    $pt = sp_backup_room_patient_type();
    if ($pt === '') {
        $empty = ['count' => 0, 'cases' => [], 'patient_type' => '', 'config' => $cfg];
        if (isset($cache_fp) && is_resource($cache_fp)) {
            sp_poll_cache_put($cache_fp, $empty);
        }
        return $empty;
    }
    $levels = [];
    if (!empty($cfg['alert_hard'])) {
        $levels[] = "'hard'";
    }
    if (!empty($cfg['alert_soft'])) {
        $levels[] = "'soft'";
    }
    if (!$levels) {
        $levels[] = "'hard'";
    }
    $date = date('Y-m-d');
    $pt_esc = mysqli_real_escape_string($con, $pt);
    $where = "status='pending' AND screen_date='$date' AND patient_type='$pt_esc' AND alert_level IN (" . implode(',', $levels) . ")";
    $lookback = sp_backup_normalize_lookback($cfg['lookback_minutes'] ?? 60);
    $rows = [];
    $q = mysqli_query($con, "SELECT id, hn, ptname, vn, an, patient_type, module_key, alert_level, alert_summary,
            rxdate, rxtime, first_detected_at
        FROM smart_pharma_alert_logs
        WHERE $where
        ORDER BY id DESC
        LIMIT 400");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            if (sp_backup_row_in_lookback($r, $lookback)) {
                $rows[] = $r;
            }
        }
    }
    usort($rows, static function ($a, $b) {
        $ta = sp_backup_parse_rx_ts($a['rxdate'] ?? '', $a['rxtime'] ?? '')
            ?: (strtotime((string)($a['first_detected_at'] ?? '')) ?: 0);
        $tb = sp_backup_parse_rx_ts($b['rxdate'] ?? '', $b['rxtime'] ?? '')
            ?: (strtotime((string)($b['first_detected_at'] ?? '')) ?: 0);
        return $tb <=> $ta;
    });
    $count = count($rows);
    $cases = [];
    $page = ($pt === 'IPD') ? 'smart_pharma_ipd.php' : 'smart_pharma_opd.php';
    $win = sp_backup_screen_window($lookback);
    foreach (array_slice($rows, 0, 12) as $r) {
        $hn = trim((string)($r['hn'] ?? ''));
        $qid = (int)$r['id'];
        $qs = 'alert_log_id=' . $qid
            . '&open=1&backup=1'
            . '&time_window=' . rawurlencode($win)
            . '&hn=' . rawurlencode($hn);
        if (!empty($r['vn'])) {
            $qs .= '&vn=' . rawurlencode((string)$r['vn']);
        }
        $mod = trim((string)($r['module_key'] ?? ''));
        if ($mod !== '') {
            $qs .= '&module=' . rawurlencode($mod);
        }
        $cases[] = [
            'id' => $qid,
            'hn' => $hn,
            'ptname' => trim((string)($r['ptname'] ?? '')),
            'vn' => trim((string)($r['vn'] ?? '')),
            'module_key' => (string)($r['module_key'] ?? ''),
            'alert_level' => (string)($r['alert_level'] ?? ''),
            'alert_summary' => trim((string)($r['alert_summary'] ?? '')),
            'patient_type' => $pt,
            'open_url' => $page . '?' . $qs,
        ];
    }
    $pending_out = [
        'count' => $count,
        'cases' => $cases,
        'patient_type' => $pt,
        'config' => $cfg,
        'room_label' => sp_backup_room_label(),
    ];
    if (isset($cache_fp) && is_resource($cache_fp)) {
        sp_poll_cache_put($cache_fp, $pending_out);
    }
    return $pending_out;
}

function sp_backup_decode_details($raw)
{
    if (is_array($raw)) {
        return $raw;
    }
    $s = trim((string)$raw);
    if ($s === '') {
        return [];
    }
    $j = json_decode($s, true);
    return is_array($j) ? $j : [];
}

/**
 * ตาราง Alert โหมด Backup — อ่านจาก smart_pharma_alert_logs ไม่ยิง HOSxP
 */
function sp_backup_screen_from_logs($con, $patient_type, $screen_date, $time_window = '1h', $time_from = '', $time_to = '')
{
    if (!function_exists('sp_get_modules')) {
        require_once __DIR__ . '/smart_pharma_helper.php';
    }
    if (!function_exists('sp_alert_log_ensure_tables')) {
        require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
    }
    sp_alert_log_ensure_tables($con);
    $patient_type = strtoupper(trim((string)$patient_type)) === 'IPD' ? 'IPD' : 'OPD';
    $screen_date = trim((string)$screen_date);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $screen_date)) {
        $screen_date = date('Y-m-d');
    }
    $cfg = sp_backup_get_config($con);
    $modules = sp_get_modules($con, $patient_type);
    $levels = [];
    if (!empty($cfg['alert_hard'])) {
        $levels[] = "'hard'";
    }
    if (!empty($cfg['alert_soft'])) {
        $levels[] = "'soft'";
    }
    if (!$levels) {
        $levels[] = "'hard'";
    }
    $pt_esc = mysqli_real_escape_string($con, $patient_type);
    $date_esc = mysqli_real_escape_string($con, $screen_date);
    $time_window = trim((string)$time_window);
    if ($time_window === '') {
        $time_window = sp_backup_screen_window($cfg['lookback_minutes'] ?? 60);
    }
    $window = function_exists('sp_normalize_time_window')
        ? sp_normalize_time_window($time_window, $screen_date)
        : $time_window;
    $rows = [];
    $q = mysqli_query($con, "SELECT id, hn, ptname, vn, an, patient_type, module_key, alert_level, alert_summary,
            alert_details, rxdate, rxtime, vstdate, ward_display, first_detected_at
        FROM smart_pharma_alert_logs
        WHERE status='pending' AND screen_date='$date_esc' AND patient_type='$pt_esc'
          AND alert_level IN (" . implode(',', $levels) . ")
        ORDER BY id DESC
        LIMIT 500");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }
    $pat_like = [];
    foreach ($rows as $r) {
        $rxdate = trim((string)($r['rxdate'] ?? ''));
        $rxtime = trim((string)($r['rxtime'] ?? ''));
        if ($rxdate === '' || $rxtime === '') {
            $fd = trim((string)($r['first_detected_at'] ?? ''));
            $ts = ($fd !== '') ? strtotime($fd) : false;
            if ($ts) {
                if ($rxdate === '') {
                    $r['rxdate'] = date('Y-m-d', $ts);
                    $rxdate = $r['rxdate'];
                }
                if ($rxtime === '') {
                    $r['rxtime'] = date('H:i:s', $ts);
                    $rxtime = $r['rxtime'];
                }
            }
        }
        $pat_like[] = [
            'rxdate' => $rxdate,
            'rxtime' => $rxtime,
            'vstdate' => $r['vstdate'] ?? $screen_date,
            'vsttime' => $rxtime,
            '_row' => $r,
        ];
    }
    if (function_exists('sp_patients_for_time_window')) {
        $kept = sp_patients_for_time_window($pat_like, $screen_date, $window, $time_from, $time_to);
        $rows = [];
        foreach ($kept as $p) {
            if (!empty($p['_row'])) {
                $rows[] = $p['_row'];
            }
        }
    } else {
        $lookback = sp_backup_normalize_lookback($cfg['lookback_minutes'] ?? 60);
        $rows = array_values(array_filter($rows, static function ($r) use ($lookback) {
            return sp_backup_row_in_lookback($r, $lookback);
        }));
    }

    $grouped = [];
    foreach ($rows as $r) {
        $hn = trim((string)($r['hn'] ?? ''));
        $vn = trim((string)($r['vn'] ?? ''));
        $rxdate = trim((string)($r['rxdate'] ?? ''));
        $rxtime = trim((string)($r['rxtime'] ?? ''));
        $key = $hn . '|' . $vn . '|' . $rxdate . '|' . $rxtime;
        if (!isset($grouped[$key])) {
            $ward = trim((string)($r['ward_display'] ?? ''));
            if ($ward === '') {
                $ward = ($patient_type === 'OPD') ? 'ผู้ป่วยนอก' : '-';
            }
            $grouped[$key] = [
                'hn' => ltrim($hn, '0') ?: $hn,
                'hn_full' => $hn,
                'vn' => $vn,
                'an' => trim((string)($r['an'] ?? '')),
                'ptname' => trim((string)($r['ptname'] ?? '')),
                'vstdate' => trim((string)($r['vstdate'] ?? $screen_date)),
                'vsttime' => $rxtime,
                'rxdate' => $rxdate,
                'rxtime' => $rxtime,
                'patient_type' => $patient_type,
                'ward_display' => $ward,
                'overall' => 'alert',
                'overall_level' => '',
                'alert_log_id' => (int)($r['id'] ?? 0),
                'modules' => [],
            ];
        }
        $mk = trim((string)($r['module_key'] ?? ''));
        if ($mk === '') {
            continue;
        }
        $level = ((string)($r['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
        if ($level === 'hard' || ($grouped[$key]['overall_level'] ?? '') === '') {
            $grouped[$key]['overall_level'] = $level;
        }
        $details = sp_backup_decode_details($r['alert_details'] ?? '');
        $grouped[$key]['modules'][$mk] = [
            'status' => 'alert',
            'level' => $level,
            'summary' => trim((string)($r['alert_summary'] ?? '')),
            'details' => $details,
            'items' => $details,
            'alert_log_id' => (int)($r['id'] ?? 0),
        ];
        if ((int)($r['id'] ?? 0) > (int)($grouped[$key]['alert_log_id'] ?? 0)) {
            $grouped[$key]['alert_log_id'] = (int)$r['id'];
        }
    }

    $na = ['status' => 'na', 'level' => '', 'summary' => 'ยังไม่พบใน Backup log', 'details' => [], 'items' => []];
    foreach ($grouped as &$row) {
        foreach ($modules as $mod) {
            $k = $mod['module_key'] ?? '';
            if ($k !== '' && empty($row['modules'][$k])) {
                $row['modules'][$k] = $na;
            }
        }
    }
    unset($row);

    $patients = array_values($grouped);
    usort($patients, static function ($a, $b) {
        $ta = sp_backup_parse_rx_ts($a['rxdate'] ?? '', $a['rxtime'] ?? '') ?: 0;
        $tb = sp_backup_parse_rx_ts($b['rxdate'] ?? '', $b['rxtime'] ?? '') ?: 0;
        if ($ta !== $tb) {
            return $tb <=> $ta;
        }
        return strcmp($a['hn'] ?? '', $b['hn'] ?? '');
    });

    $module_cols = array_map(static function ($m) {
        return [
            'key' => $m['module_key'],
            'label' => $m['label_th'],
            'icon' => $m['icon'],
            'color' => $m['color'],
        ];
    }, $modules);

    return [
        'patients' => $patients,
        'modules' => $module_cols,
        'meta' => [
            'patient_type' => $patient_type,
            'screen_date' => $screen_date,
            'count' => count($patients),
            'total_patients' => count($patients),
            'time_window' => $window,
            'time_window_label' => function_exists('sp_time_window_label')
                ? sp_time_window_label($window, $time_from, $time_to)
                : $window,
            'time_from' => $time_from,
            'time_to' => $time_to,
            'is_today' => function_exists('sp_is_screen_date_today') ? sp_is_screen_date_today($screen_date) : true,
            'alert_count' => count($patients),
            'phase' => 'backup_logs',
            'from_backup_logs' => 1,
        ],
    ];
}
