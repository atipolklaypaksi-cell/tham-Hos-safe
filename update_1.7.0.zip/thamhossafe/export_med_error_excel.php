<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/med_error_helper.php';
mysqli_set_charset($con, 'utf8');
med_error_ensure_tables($con);

function excel_text($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$start_date = isset($_GET['start_date']) ? trim((string)$_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? trim((string)$_GET['end_date']) : '';
if ($start_date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = '';
}
if ($end_date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = '';
}
if ($start_date !== '' && $end_date !== '' && $start_date > $end_date) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$report_filters = med_error_report_filters_from_request($_GET);
$parts = [];
if ($start_date !== '' && $end_date !== '') {
    $start_esc = mysqli_real_escape_string($con, $start_date);
    $end_esc = mysqli_real_escape_string($con, $end_date);
    $parts[] = "DATE(m.incident_date) BETWEEN '{$start_esc}' AND '{$end_esc}'";
}
$parts = array_merge($parts, med_error_report_filter_sql($con, $report_filters));
$where = $parts ? (' WHERE ' . implode(' AND ', $parts)) : '';

$sql = "SELECT m.id, m.hn, m.patient_name, m.patient_type, m.an, m.vn, m.order_doctor_code, m.order_doctor_name, m.order_doctor_group, m.reporting_dept, m.error_dept, m.error_drugs, m.correct_drugs, m.is_had, m.is_robot, m.rx_type, m.record_kind, m.incident_date, m.created_at, m.error_level, m.description, m.solution,
               m.intervention_module, t.category, t.name AS type_name, u.full_name AS reporter_name
        FROM med_error_records m
        LEFT JOIN med_error_types t ON m.error_type_id = t.id
        LEFT JOIN users u ON m.reporter_id = u.id
        {$where}
        ORDER BY m.incident_date DESC";
$q = mysqli_query($con, $sql);
$rows = [];
if ($q) {
    while ($r = mysqli_fetch_assoc($q)) {
        $rows[] = $r;
    }
}

$range_suffix = ($start_date !== '' && $end_date !== '') ? ('_' . $start_date . '_to_' . $end_date) : '';
$filename = 'Med_Error_History' . $range_suffix . '_' . date('Y-m-d_His') . '.xls';
$range_title = ($start_date !== '' && $end_date !== '')
    ? ('ช่วงรายงาน: ' . date('d/m/Y', strtotime($start_date)) . ' – ' . date('d/m/Y', strtotime($end_date)))
    : 'ช่วงรายงาน: ทั้งหมด';
$filter_reporter_name = '';
if (!empty($report_filters['reporter_id'])) {
    $rid = (int)$report_filters['reporter_id'];
    $qr = mysqli_query($con, "SELECT full_name FROM users WHERE id = {$rid} LIMIT 1");
    if ($qr && ($rrn = mysqli_fetch_assoc($qr))) {
        $filter_reporter_name = (string)($rrn['full_name'] ?? '');
    }
}
$filter_bits = med_error_report_filter_label($report_filters, $filter_reporter_name);
if ($filter_bits) {
    $range_title .= ' | กรอง: ' . implode(' · ', $filter_bits);
}

header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');
echo "\xEF\xBB\xBF";
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
<head>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; font-family: Tahoma, 'Sarabun', sans-serif; font-size: 11pt; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; vertical-align: top; }
        th { background: #f8e8e8; text-align: center; }
        td { mso-number-format: "\@"; }
        .title { font-size: 14pt; font-weight: bold; }
    </style>
</head>
<body>
<table>
    <tr><th colspan="26" class="title">รายงานความคลาดเคลื่อนทางยา (Medication Error)</th></tr>
    <tr><th colspan="26" style="text-align:left;"><?= excel_text($range_title) ?> | ส่งออกเมื่อ <?= excel_text(date('d/m/Y H:i')) ?></th></tr>
    <tr>
        <th>ลำดับ</th>
        <th>วันเกิดเหตุ</th>
        <th>เวลาเกิดเหตุ</th>
        <th>วันเวลาที่บันทึก</th>
        <th>ประเภทความคลาดเคลื่อน</th>
        <th>ประเภทผู้ป่วย</th>
        <th>HN</th>
        <th>AN</th>
        <th>VN</th>
        <th>ชื่อผู้ป่วย</th>
        <th>แพทย์ผู้สั่งใช้ยา</th>
        <th>กลุ่มแพทย์</th>
        <th>หมวดหมู่</th>
        <th>ลักษณะความคลาดเคลื่อน</th>
        <th>หน่วยงานที่รายงาน</th>
        <th>หน่วยงานที่เกิด Error</th>
        <th>ยาที่ Error</th>
        <th>ยาที่ถูกต้อง</th>
        <th>HAD</th>
        <th>Robot</th>
        <th>ประเภทใบสั่งยา</th>
        <th>Intervention log</th>
        <th>ระดับความรุนแรง</th>
        <th>บรรยายเหตุการณ์</th>
        <th>การแก้ไขปัญหา</th>
        <th>ผู้บันทึก</th>
    </tr>
    <?php if (!$rows): ?>
    <tr><td colspan="26" style="text-align:center;">ไม่มีข้อมูล</td></tr>
    <?php else: ?>
    <?php $no = 1; foreach ($rows as $r): ?>
    <?php
        $inc_ts = !empty($r['incident_date']) ? strtotime($r['incident_date']) : 0;
        $created_ts = !empty($r['created_at']) ? strtotime($r['created_at']) : 0;
        $ptype = strtoupper(trim((string)($r['patient_type'] ?? '')));
        $ptype_label = ($ptype === 'IPD') ? 'ผู้ป่วยใน' : (($ptype === 'OPD') ? 'ผู้ป่วยนอก' : '');
    ?>
    <tr>
        <td style="text-align:center;"><?= $no++ ?></td>
        <td style="text-align:center;"><?= excel_text($inc_ts ? date('d/m/Y', $inc_ts) : '') ?></td>
        <td style="text-align:center;"><?= excel_text($inc_ts ? date('H:i', $inc_ts) : '') ?></td>
        <td style="text-align:center;"><?= excel_text($created_ts ? date('d/m/Y H:i', $created_ts) : '') ?></td>
        <td><?= excel_text(med_error_record_kind_label($r['record_kind'] ?? 'error')) ?></td>
        <td style="text-align:center;"><?= excel_text($ptype_label) ?></td>
        <td style="text-align:center;"><?= excel_text($r['hn']) ?></td>
        <td style="text-align:center;"><?= excel_text($r['an'] ?? '') ?></td>
        <td style="text-align:center;"><?= excel_text($r['vn'] ?? '') ?></td>
        <td><?= excel_text($r['patient_name'] ?? '') ?></td>
        <td><?= excel_text($r['order_doctor_name'] ?? '') ?></td>
        <td style="text-align:center;"><?= excel_text(med_error_doctor_group_label($r['order_doctor_group'] ?? '')) ?></td>
        <td style="text-align:center;"><?= excel_text($r['category'] ?? '') ?></td>
        <td><?= excel_text($r['type_name'] ?? '') ?></td>
        <td><?= excel_text($r['reporting_dept'] ?? '') ?></td>
        <td><?= excel_text($r['error_dept'] ?? '') ?></td>
        <td><?= excel_text(med_error_drugs_list_text(med_error_parse_drugs($r['error_drugs'] ?? '[]'))) ?></td>
        <td><?= excel_text(med_error_drugs_list_text(med_error_parse_drugs($r['correct_drugs'] ?? '[]'))) ?></td>
        <td style="text-align:center;"><?= excel_text(med_error_sanitize_yes_no($r['is_had'] ?? 'NO', 'NO')) ?></td>
        <td style="text-align:center;"><?= excel_text(med_error_sanitize_yes_no($r['is_robot'] ?? 'NO', 'NO')) ?></td>
        <td style="text-align:center;"><?= excel_text(med_error_rx_type_label($r['rx_type'] ?? '')) ?></td>
        <td style="text-align:center;"><?= excel_text($r['intervention_module'] ?? '') ?></td>
        <td style="text-align:center;"><?= excel_text($r['error_level']) ?></td>
        <td><?= excel_text($r['description']) ?></td>
        <td><?= excel_text($r['solution'] ?? '') ?></td>
        <td style="text-align:center;"><?= excel_text($r['reporter_name'] ?? '') ?></td>
    </tr>
    <?php endforeach; ?>
    <?php endif; ?>
</table>
</body>
</html>
