<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('hosxp_tmt_drug_helper.php');
include('monitor_dose_calculator_helper.php');
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
mysqli_set_charset($con, 'utf8');

mdc_ensure_table($con);

$default_start = date('Y-m-d', strtotime('-3 days'));
$default_end = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save_tolerance') {
        $saved = mdc_save_monitor_tolerance_pct($con, $_POST['tolerance_pct'] ?? mdc_default_tolerance_pct());
        $_SESSION['mdc_msg'] = 'บันทึกคลาดเคลื่อนที่ยอมรับได้ ±' . mdc_fmt($saved, 1) . '% เรียบร้อย';
        header('Location: monitor_dose_calculator.php');
        exit;
    }

    if ($action === 'add_mdc' || $action === 'edit_mdc') {
        $drug = hosxp_parse_drug_option($_POST['drug'] ?? '');
        $icode = mdc_escape($con, $drug['icode']);
        $drug_name = mdc_escape($con, $drug['name']);
        $calc_type = trim((string)($_POST['calc_type'] ?? ''));
        $meta = mdc_catalog_item($calc_type);
        $alert_level = ($_POST['alert_level'] ?? '') === 'soft' ? 'soft' : 'hard';
        $alert_message = mdc_escape($con, $_POST['alert_message'] ?? '');
        $active = isset($_POST['active']) ? 1 : 0;
        $tol_raw = trim((string)($_POST['tolerance_pct'] ?? ''));
        $tol_sql = $tol_raw === '' ? 'NULL' : mdc_sql_num(mdc_clamp_tolerance_pct($tol_raw));
        $hours_sql = mdc_sql_num($_POST['default_hours'] ?? '');
        $stock_sql = mdc_sql_num($_POST['stock_mg_ml'] ?? '');
        $min_sql = mdc_sql_num($_POST['mg_per_kg_min'] ?? '');
        $max_sql = mdc_sql_num($_POST['mg_per_kg_max'] ?? '');
        $lvl_esc = mdc_escape($con, $alert_level);
        $type_esc = mdc_escape($con, $calc_type);

        if ($icode === '' || !$meta || empty($meta['mappable'])) {
            $_SESSION['mdc_error'] = 'กรุณาเลือกสูตรจากเครื่องคำนวณ และยาจาก HOSxP';
            header('Location: monitor_dose_calculator.php?tab=settings');
            exit;
        }

        if ($action === 'add_mdc') {
            $chk = mysqli_query($con, "SELECT id FROM monitor_dose_calculator_settings WHERE calc_type='$type_esc' AND icode='$icode' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) > 0) {
                $_SESSION['mdc_error'] = 'ผูกยา icode นี้กับสูตรนี้แล้ว — ใช้แก้ไขแทน';
            } else {
                $sql = "INSERT INTO monitor_dose_calculator_settings
                    (calc_type, icode, drug_name, alert_level, alert_message, tolerance_pct, default_hours, stock_mg_ml, mg_per_kg_min, mg_per_kg_max, active)
                    VALUES ('$type_esc', '$icode', '$drug_name', '$lvl_esc', '$alert_message', $tol_sql, $hours_sql, $stock_sql, $min_sql, $max_sql, $active)";
                if (mysqli_query($con, $sql)) {
                    $_SESSION['mdc_msg'] = 'ผูกยาเข้าสูตร ' . ($meta['label'] ?? $calc_type) . ' เรียบร้อย';
                    if (function_exists('sp_monitor_settings_changed')) {
                        sp_monitor_settings_changed($con, 'dose_calculator');
                    }
                } else {
                    $_SESSION['mdc_error'] = 'บันทึกไม่สำเร็จ: ' . mysqli_error($con);
                }
            }
        } else {
            $id = (int)($_POST['rule_id'] ?? 0);
            if ($id <= 0) {
                $_SESSION['mdc_error'] = 'ไม่พบรายการที่จะแก้ไข';
            } else {
                $sql = "UPDATE monitor_dose_calculator_settings SET
                    calc_type='$type_esc', icode='$icode', drug_name='$drug_name', alert_level='$lvl_esc',
                    alert_message='$alert_message', tolerance_pct=$tol_sql, default_hours=$hours_sql,
                    stock_mg_ml=$stock_sql, mg_per_kg_min=$min_sql, mg_per_kg_max=$max_sql, active=$active
                    WHERE id=$id";
                if (mysqli_query($con, $sql)) {
                    $_SESSION['mdc_msg'] = 'บันทึกการแก้ไขเรียบร้อย';
                    if (function_exists('sp_monitor_settings_changed')) {
                        sp_monitor_settings_changed($con, 'dose_calculator');
                    }
                } else {
                    $_SESSION['mdc_error'] = 'บันทึกไม่สำเร็จ: ' . mysqli_error($con);
                }
            }
        }
        header('Location: monitor_dose_calculator.php?tab=settings');
        exit;
    }

    if ($action === 'delete_mdc') {
        $id = (int)($_POST['del_id'] ?? 0);
        if ($id > 0) {
            mysqli_query($con, "DELETE FROM monitor_dose_calculator_settings WHERE id=$id");
            if (function_exists('sp_monitor_settings_changed')) {
                sp_monitor_settings_changed($con, 'dose_calculator');
            }
            $_SESSION['mdc_msg'] = 'ลบการผูกยาเรียบร้อย';
        }
        header('Location: monitor_dose_calculator.php?tab=settings');
        exit;
    }

    if ($action === 'import_hosxp') {
        $hos = hosxp_connect($con);
        $res = mdc_import_hosxp_bindings($con, $hos);
        if ($hos) {
            mysqli_close($hos);
        }
        if (!empty($res['error'])) {
            $_SESSION['mdc_error'] = $res['error'];
        } else {
            $msg = 'ผูกยาจาก HOSxP แล้ว — เพิ่มใหม่ ' . (int)($res['inserted'] ?? 0)
                . ' รายการ · มีอยู่แล้ว ' . (int)($res['skipped'] ?? 0) . ' รายการ (ไม่ทับของเดิม)';
            if (!empty($res['unmatched'])) {
                $msg .= ' · ไม่พบยา: ' . implode(', ', $res['unmatched']);
            }
            $_SESSION['mdc_msg'] = $msg;
            if ((int)($res['inserted'] ?? 0) > 0 && function_exists('sp_monitor_settings_changed')) {
                sp_monitor_settings_changed($con, 'dose_calculator');
            }
        }
        header('Location: monitor_dose_calculator.php?tab=settings');
        exit;
    }
}

$con_hosxp = hosxp_connect($con);
$hosxp_drugs = $con_hosxp ? hosxp_fetch_active_drugs_tmt($con_hosxp) : [];
if ($con_hosxp) {
    mysqli_close($con_hosxp);
}
$opt_drugs = hosxp_build_drug_options_html($hosxp_drugs, '- เลือกยาจาก HOSxP (TMT) -');

$all_rules = mdc_load_rules($con, [], false);
$monitor_rules = [];
foreach ($all_rules as $r) {
    if (!empty($r['active'])) {
        $monitor_rules[] = $r;
    }
}
$mdc_rule_groups = [];
foreach ($monitor_rules as $mr) {
    $meta = $mr['_meta'] ?? [];
    $g = trim((string)($meta['group_label'] ?? $meta['label'] ?? 'อื่น'));
    if ($g === '') {
        $g = 'อื่น';
    }
    $mdc_rule_groups[$g][] = $mr;
}

$catalog = mdc_mappable_types();
$tol_pct = mdc_get_monitor_tolerance_pct($con);
$tab = (isset($_GET['tab']) && $_GET['tab'] === 'settings') ? 'settings' : 'monitor';
$flash_msg = $_SESSION['mdc_msg'] ?? '';
$flash_err = $_SESSION['mdc_error'] ?? '';
unset($_SESSION['mdc_msg'], $_SESSION['mdc_error']);
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor เครื่องคำนวณยา - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/select2.min.css" rel="stylesheet">
    <link href="css/select2-bootstrap-5-theme.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .section-hard .table thead { background-color: #dc3545 !important; color: #fff !important; }
        .section-soft .table thead { background-color: #fd7e14 !important; color: #fff !important; }
        .section-pass .table thead { background-color: #198754 !important; color: #fff !important; }
        .section-unverifiable .table thead { background-color: #6c757d !important; color: #fff !important; }
        .mdc-range-btn.active { background-color: #db2777 !important; border-color: #db2777 !important; color: #fff !important; }
        .mdc-mismatch { background: #fee2e2; border-left: 3px solid #dc3545; padding: 4px 8px; border-radius: 4px; font-weight: 600; }
        .mdc-ok { background: #dcfce7; border-left: 3px solid #198754; padding: 4px 8px; border-radius: 4px; font-weight: 600; }
        .mdc-dir-high { background: #dc3545; color: #fff; font-size: 0.72rem; }
        .mdc-dir-low { background: #0d6efd; color: #fff; font-size: 0.72rem; }
        #mdcFormCard.edit-mode .card-header { background-color: #9d174d !important; }
        tr.mdc-editing-row { background-color: #fce7f3 !important; }
        .mdc-rule-group { border: 1px solid #f9a8d4; border-radius: 8px; padding: 8px 10px; background: #fdf2f8; }
        .mdc-rule-group h6 { font-size: 0.8rem; color: #9d174d; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-2 text-dark">
                <i class="fas fa-calculator me-2" style="color:#db2777;"></i>
                Monitor เครื่องคำนวณยา
            </h4>
            <p class="text-muted small mb-3">
                ตรวจใบยา OPD/IPD เทียบสูตรใน
                <a href="dose_calculator.php" class="fw-bold">ระบบช่วยคำนวณยา</a>
                — ผูกยา HOSxP กับแต่ละสูตรที่แท็บตั้งค่า
                <span class="ms-2">
                    <span class="badge mdc-dir-high"><i class="fas fa-arrow-up"></i> High</span> สูงเกิน
                    <span class="badge mdc-dir-low ms-1"><i class="fas fa-arrow-down"></i> Low</span> ต่ำเกิน
                </span>
            </p>

            <?php if ($flash_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo htmlspecialchars($flash_msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            <?php if ($flash_err): ?>
            <div class="alert alert-danger alert-dismissible fade show"><?php echo htmlspecialchars($flash_err); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <ul class="nav nav-tabs fw-bold" role="tablist">
                <li class="nav-item">
                    <button class="nav-link <?php echo $tab === 'monitor' ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#monitor" type="button">
                        <i class="fas fa-desktop me-1"></i> รายการเฝ้าระวัง
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link <?php echo $tab === 'settings' ? 'active' : ''; ?>" data-bs-toggle="tab" data-bs-target="#settings" type="button">
                        <i class="fas fa-cogs me-1"></i> ตั้งค่า (ดึงจากเครื่องคำนวณ)
                    </button>
                </li>
            </ul>

            <div class="tab-content bg-white border border-top-0 p-4 rounded-bottom shadow-sm">
                <div class="tab-pane fade <?php echo $tab === 'monitor' ? 'show active' : ''; ?>" id="monitor">
                    <div class="filter-box p-3 mb-3">
                        <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-filter me-2"></i>ตัวกรองรายงาน</h6>
                        <div class="row g-2 align-items-end">
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">วันที่สั่งยา ตั้งแต่</label>
                                <input type="text" id="filter_start" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_start); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ถึงวันที่</label>
                                <input type="text" id="filter_end" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_end); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">HN (ไม่บังคับ)</label>
                                <input type="text" id="filter_hn" class="form-control form-control-sm bg-white" placeholder="ทุก HN" autocomplete="off">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-sm fw-bold text-white w-100 shadow-sm" style="background:#db2777;" id="btnFetchMdc" onclick="fetchMdcData()">
                                    <i class="fas fa-sync-alt me-1"></i> ประมวลผล
                                </button>
                            </div>
                            <div class="col-md-3">
                                <form method="post" class="d-flex align-items-end gap-1">
                                    <input type="hidden" name="action" value="save_tolerance">
                                    <div class="flex-grow-1">
                                        <label class="form-label small fw-bold mb-1" for="tolerance_pct">ยอมคลาดเคลื่อน ± (ทั้งระบบ)</label>
                                        <div class="input-group input-group-sm">
                                            <input type="number" name="tolerance_pct" id="tolerance_pct" class="form-control bg-white" min="0" max="100" step="1" value="<?php echo htmlspecialchars(mdc_fmt($tol_pct, 1)); ?>">
                                            <span class="input-group-text">%</span>
                                            <button type="submit" class="btn btn-outline-secondary fw-bold">บันทึก</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row g-2 mt-2 align-items-center">
                            <div class="col-auto"><label class="form-label small fw-bold mb-0 text-secondary">ช่วงเร็ว:</label></div>
                            <div class="col">
                                <div class="btn-group btn-group-sm flex-wrap">
                                    <button type="button" class="btn btn-outline-secondary fw-bold mdc-range-btn" data-days="1" onclick="setMdcDateRange(1)">วันนี้</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mdc-range-btn active" data-days="3" onclick="setMdcDateRange(3)">3 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mdc-range-btn" data-days="7" onclick="setMdcDateRange(7)">7 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mdc-range-btn" data-days="30" onclick="setMdcDateRange(30)">30 วัน</button>
                                </div>
                            </div>
                        </div>
                        <div class="small text-muted mt-2">
                            <i class="fas fa-bolt me-1"></i>
                            ประมวลผล<b>คู่ขนานพร้อมกันได้ถึง 5 งาน</b> — ช่วงหลายวันจะแบ่งทีละวัน / วันเดียวจะตรวจทีละยา
                            จากรายการที่เลือกด้านล่าง (ค่าเริ่มต้นเลือกทั้งหมดจากหน้าตั้งค่า)
                        </div>
                        <div id="hnFocusBanner" class="alert alert-warning py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                        <div id="reportMeta" class="alert alert-info py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                    </div>

                    <div class="border rounded p-3 mb-3" id="mdcRuleFilterBox">
                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                            <label class="form-label fw-bold small mb-0">
                                <i class="fas fa-filter me-1 text-danger"></i> เลือกยาที่ต้องการรายงาน
                                <span class="text-muted fw-normal">(ดึงจากหน้าตั้งค่าที่เปิดใช้งาน)</span>
                                <span id="mdcRuleCount" class="badge bg-secondary ms-1">0/0</span>
                            </label>
                            <div class="d-flex flex-wrap gap-2">
                                <a href="monitor_dose_calculator.php?tab=settings" class="btn btn-sm btn-outline-danger fw-bold">
                                    <i class="fas fa-cogs me-1"></i> ตั้งค่ารายการยา
                                </a>
                                <div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-outline-primary fw-bold" onclick="mdcSelectAllRules(true)">เลือกทั้งหมด</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold" onclick="mdcSelectAllRules(false)">ยกเลิกทั้งหมด</button>
                                </div>
                            </div>
                        </div>
                        <input type="text" id="mdcRuleSearch" class="form-control form-control-sm mb-2" placeholder="ค้นหาสูตรหรือยา...">
                        <?php if (empty($monitor_rules)): ?>
                        <div class="small text-muted">ยังไม่มีรายการยาที่เปิดใช้งาน — ไปที่แท็บ
                            <a href="monitor_dose_calculator.php?tab=settings" class="fw-bold">ตั้งค่า</a>
                            เพื่อผูกยา HOSxP กับสูตรในเครื่องคำนวณ
                        </div>
                        <?php else: ?>
                        <div class="d-flex flex-column gap-2">
                            <?php foreach ($mdc_rule_groups as $gname => $gitems):
                                $gid = substr(md5($gname), 0, 8);
                            ?>
                            <div class="mdc-rule-group">
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                                    <h6 class="fw-bold mb-0">
                                        <i class="fas fa-calculator me-1"></i><?php echo htmlspecialchars($gname); ?>
                                        <span class="text-muted fw-normal">(<?php echo count($gitems); ?>)</span>
                                    </h6>
                                    <div class="btn-group btn-group-sm">
                                        <button type="button" class="btn btn-outline-secondary py-0" onclick="mdcSelectGroup('<?php echo htmlspecialchars($gid); ?>', true)">เลือกกลุ่มนี้</button>
                                        <button type="button" class="btn btn-outline-secondary py-0" onclick="mdcSelectGroup('<?php echo htmlspecialchars($gid); ?>', false)">ยกเลิกกลุ่มนี้</button>
                                    </div>
                                </div>
                                <div class="row g-2">
                                    <?php foreach ($gitems as $mr):
                                        $meta = $mr['_meta'] ?? mdc_catalog_item($mr['calc_type'] ?? '') ?: [];
                                        $lvl = mdc_alert_level($mr);
                                        $badge = $lvl === 'hard'
                                            ? '<span class="badge bg-danger ms-1">Hard</span>'
                                            : '<span class="badge bg-warning text-dark ms-1">Soft</span>';
                                    ?>
                                    <div class="col-md-6 col-xl-4 mdc-rule-item">
                                        <div class="form-check border rounded px-2 py-1 bg-white h-100">
                                            <input class="form-check-input mdc-rule-cb" type="checkbox"
                                                   value="<?php echo (int)$mr['id']; ?>"
                                                   data-group="<?php echo htmlspecialchars($gid); ?>"
                                                   data-name="<?php echo htmlspecialchars($mr['drug_name']); ?>"
                                                   id="mdc_rule_cb_<?php echo (int)$mr['id']; ?>" checked>
                                            <label class="form-check-label small" for="mdc_rule_cb_<?php echo (int)$mr['id']; ?>">
                                                <span class="fw-bold text-dark"><?php echo htmlspecialchars($mr['drug_name']); ?></span>
                                                <small class="text-muted">(<?php echo htmlspecialchars($mr['icode']); ?>)</small>
                                                <?php echo $badge; ?>
                                                <br><small class="text-primary"><?php echo htmlspecialchars($meta['label'] ?? $mr['calc_type']); ?></small>
                                            </label>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php
                    $thead = '<th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th>'
                        . '<th>อายุ</th><th>วันที่สั่ง</th><th class="text-start">ยา / สูตร</th>'
                        . '<th class="text-start">วิธีใช้</th><th>BW</th>'
                        . '<th>ที่พบ</th><th title="Low / High">↑↓</th><th>ที่ควรได้</th>'
                        . '<th>หอผู้ป่วย</th><th class="text-start">ข้อความ</th>';
                    $colspan = 13;
                    ?>
                    <div class="section-hard mb-4">
                        <h6 class="fw-bold text-danger mb-2"><i class="fas fa-exclamation-circle me-2"></i>Hard Alert <span id="hardCount" class="badge bg-danger">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small"><tr><?php echo $thead; ?></tr></thead>
                                <tbody id="hardTbody"><tr><td colspan="<?php echo $colspan; ?>" class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="section-soft mb-2">
                        <h6 class="fw-bold text-warning mb-2"><i class="fas fa-exclamation-triangle me-2"></i>Soft Alert <span id="softCount" class="badge bg-warning text-dark">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small"><tr><?php echo $thead; ?></tr></thead>
                                <tbody id="softTbody"><tr><td colspan="<?php echo $colspan; ?>" class="text-center py-4 text-muted">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="section-unverifiable mb-4">
                        <h6 class="fw-bold text-secondary mb-2"><i class="fas fa-question-circle me-2"></i>ตรวจสอบไม่ได้ <span id="unverifiableCount" class="badge bg-secondary">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small"><tr><?php echo $thead; ?></tr></thead>
                                <tbody id="unverifiableTbody"><tr><td colspan="<?php echo $colspan; ?>" class="text-center py-4 text-muted">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="section-pass mt-4">
                        <h6 class="fw-bold text-success mb-2"><i class="fas fa-check-circle me-2"></i>รายการผ่าน <span id="passCount" class="badge bg-success">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small"><tr><?php echo $thead; ?></tr></thead>
                                <tbody id="passTbody"><tr><td colspan="<?php echo $colspan; ?>" class="text-center py-4 text-muted">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade <?php echo $tab === 'settings' ? 'show active' : ''; ?>" id="settings">
                    <div class="alert alert-info py-2 small">
                        รายการสูตรดึงจากแท็บใน <a href="dose_calculator.php" class="fw-bold">ระบบช่วยคำนวณยา</a>
                        — เลือกสูตรแล้วผูกยา HOSxP ที่ต้องการให้ Monitor ตรวจ
                        <form method="post" class="mt-2 mb-0" onsubmit="return confirm('ค้นยาจาก HOSxP แล้วผูกเข้าสูตรเครื่องคำนวณ?\nรายการที่มีอยู่แล้วจะไม่ถูกทับ สามารถแก้ / เพิ่ม / ลบต่อได้');">
                            <input type="hidden" name="action" value="import_hosxp">
                            <button type="submit" class="btn btn-sm btn-outline-danger fw-bold">
                                <i class="fas fa-link me-1"></i> ผูกยาจาก HOSxP ตามสูตรเครื่องคำนวณ
                            </button>
                            <span class="text-muted ms-2">จับคู่ชื่อยา เช่น Methylpred, Alteplase, Dobutamine — ไม่ลบหรือแก้ไขรายการเดิม</span>
                        </form>
                    </div>
                    <div class="row g-4">
                        <div class="col-lg-5">
                            <div class="card shadow-sm border-0" id="mdcFormCard">
                                <div class="card-header text-white fw-bold" style="background:#db2777;">
                                    <i class="fas fa-plus-circle me-1"></i> <span id="mdcFormTitle">ผูกยาเข้าสูตรเครื่องคำนวณ</span>
                                </div>
                                <div class="card-body">
                                    <form method="post" id="mdcForm">
                                        <input type="hidden" name="action" id="mdc_action" value="add_mdc">
                                        <input type="hidden" name="rule_id" id="mdc_rule_id" value="">
                                        <div class="mb-2">
                                            <label class="form-label small fw-bold">สูตรจากเครื่องคำนวณ</label>
                                            <select name="calc_type" id="mdc_calc_type" class="form-select form-select-sm" required>
                                                <option value="">- เลือกสูตร -</option>
                                                <?php
                                                $last_g = '';
                                                foreach ($catalog as $ck => $ci):
                                                    $g = $ci['group_label'] ?? $ci['group'] ?? '';
                                                    if ($g !== $last_g) {
                                                        if ($last_g !== '') echo '</optgroup>';
                                                        echo '<optgroup label="' . htmlspecialchars($g) . '">';
                                                        $last_g = $g;
                                                    }
                                                ?>
                                                <option value="<?php echo htmlspecialchars($ck); ?>"><?php echo htmlspecialchars($ci['label']); ?></option>
                                                <?php endforeach; if ($last_g !== '') echo '</optgroup>'; ?>
                                            </select>
                                            <div class="form-text" id="mdcHint">เลือกสูตรแล้วระบบจะแสดงวิธีตรวจ</div>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small fw-bold">ยา (HOSxP)</label>
                                            <select name="drug" id="mdc_drug" class="form-select form-select-sm" required><?php echo $opt_drugs; ?></select>
                                        </div>
                                        <div class="row g-2">
                                            <div class="col-6">
                                                <label class="form-label small fw-bold">ระดับแจ้งเตือน</label>
                                                <select name="alert_level" id="mdc_alert_level" class="form-select form-select-sm">
                                                    <option value="hard">Hard Alert</option>
                                                    <option value="soft">Soft Alert</option>
                                                </select>
                                            </div>
                                            <div class="col-6">
                                                <label class="form-label small fw-bold">ยอมคลาดเคลื่อน ±%</label>
                                                <input type="number" name="tolerance_pct" id="mdc_tolerance" class="form-control form-control-sm" min="0" max="100" step="1" placeholder="ว่าง = ทั้งระบบ">
                                            </div>
                                            <div class="col-6">
                                                <label class="form-label small fw-bold">ชั่วโมง default</label>
                                                <input type="number" name="default_hours" id="mdc_hours" class="form-control form-control-sm" min="0" step="0.5" placeholder="เช่น 24">
                                            </div>
                                            <div class="col-6">
                                                <label class="form-label small fw-bold">ความเข้มข้นสำรอง (mg/mL)</label>
                                                <input type="number" name="stock_mg_ml" id="mdc_stock" class="form-control form-control-sm" min="0" step="0.01" placeholder="ถ้าอ่านจากวิธีใช้ไม่ได้">
                                            </div>
                                            <div class="col-6">
                                                <label class="form-label small fw-bold">mg/kg ต่ำสุด</label>
                                                <input type="number" name="mg_per_kg_min" id="mdc_min_kg" class="form-control form-control-sm" min="0" step="0.01">
                                            </div>
                                            <div class="col-6">
                                                <label class="form-label small fw-bold">mg/kg สูงสุด</label>
                                                <input type="number" name="mg_per_kg_max" id="mdc_max_kg" class="form-control form-control-sm" min="0" step="0.01">
                                            </div>
                                        </div>
                                        <div class="mb-2 mt-2">
                                            <label class="form-label small fw-bold">ข้อความแจ้งเตือน (ไม่บังคับ)</label>
                                            <input type="text" name="alert_message" id="mdc_alert_message" class="form-control form-control-sm">
                                        </div>
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="checkbox" name="active" id="mdc_active" checked>
                                            <label class="form-check-label small" for="mdc_active">เปิดใช้งาน</label>
                                        </div>
                                        <div class="d-flex gap-2">
                                            <button type="submit" class="btn btn-sm fw-bold text-white" style="background:#db2777;" id="mdcSubmitBtn">
                                                <i class="fas fa-save me-1"></i> บันทึก
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-secondary fw-bold" onclick="resetMdcForm()">ยกเลิก</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="table-responsive">
                                <table class="table table-sm table-hover align-middle border">
                                    <thead class="table-light small text-center">
                                        <tr>
                                            <th>สูตร</th>
                                            <th class="text-start">ยา</th>
                                            <th>icode</th>
                                            <th>ระดับ</th>
                                            <th>สถานะ</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if (empty($all_rules)): ?>
                                        <tr><td colspan="6" class="text-center text-muted py-4">ยังไม่มีรายการ — ผูกยาจากฟอร์มด้านซ้าย</td></tr>
                                    <?php else: foreach ($all_rules as $r):
                                        $meta = $r['_meta'] ?? [];
                                        $row_js = [
                                            'id' => (int)$r['id'],
                                            'calc_type' => $r['calc_type'],
                                            'icode' => $r['icode'],
                                            'drug_name' => $r['drug_name'],
                                            'alert_level' => $r['alert_level'],
                                            'alert_message' => $r['alert_message'] ?? '',
                                            'tolerance_pct' => $r['tolerance_pct'],
                                            'default_hours' => $r['default_hours'],
                                            'stock_mg_ml' => $r['stock_mg_ml'],
                                            'mg_per_kg_min' => $r['mg_per_kg_min'],
                                            'mg_per_kg_max' => $r['mg_per_kg_max'],
                                            'active' => (int)$r['active'],
                                        ];
                                    ?>
                                        <tr class="mdc-rule-row" data-rule-id="<?php echo (int)$r['id']; ?>">
                                            <td class="small fw-bold"><?php echo htmlspecialchars($meta['label'] ?? $r['calc_type']); ?></td>
                                            <td class="small"><?php echo htmlspecialchars($r['drug_name']); ?></td>
                                            <td class="text-center small"><?php echo htmlspecialchars($r['icode']); ?></td>
                                            <td class="text-center"><?php echo ($r['alert_level'] === 'soft')
                                                ? '<span class="badge bg-warning text-dark">Soft</span>'
                                                : '<span class="badge bg-danger">Hard</span>'; ?></td>
                                            <td class="text-center"><?php echo !empty($r['active'])
                                                ? '<span class="badge bg-success">เปิด</span>'
                                                : '<span class="badge bg-secondary">ปิด</span>'; ?></td>
                                            <td class="text-nowrap text-end">
                                                <button type="button" class="btn btn-sm btn-outline-primary py-0" onclick='setMdcEditMode(<?php echo json_encode($row_js, JSON_UNESCAPED_UNICODE); ?>)'>แก้</button>
                                                <form method="post" class="d-inline" onsubmit="return confirm('ลบรายการนี้?');">
                                                    <input type="hidden" name="action" value="delete_mdc">
                                                    <input type="hidden" name="del_id" value="<?php echo (int)$r['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger py-0">ลบ</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <h6 class="fw-bold small mt-3">สูตรทั้งหมดในเครื่องคำนวณ</h6>
                            <div class="row g-2">
                                <?php foreach (mdc_catalog() as $ck => $ci):
                                    $n = 0;
                                    foreach ($all_rules as $r) {
                                        if (($r['calc_type'] ?? '') === $ck && !empty($r['active'])) $n++;
                                    }
                                ?>
                                <div class="col-md-6">
                                    <div class="border rounded px-2 py-1 small bg-light h-100">
                                        <span class="fw-bold"><?php echo htmlspecialchars($ci['label']); ?></span>
                                        <?php if (empty($ci['mappable'])): ?>
                                        <span class="badge bg-secondary">ไม่ผูกยา</span>
                                        <?php else: ?>
                                        <span class="badge <?php echo $n ? 'bg-success' : 'bg-light text-dark border'; ?>"><?php echo $n; ?> ยา</span>
                                        <?php endif; ?>
                                        <div class="text-muted"><?php echo htmlspecialchars($ci['hint']); ?></div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/monitor_hn_filter.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/flatpickr.min.js"></script>
<script>
const MDC_COLSPAN = 13;
const MDC_HINTS = <?php
    $hints = [];
    foreach ($catalog as $ck => $ci) {
        $hints[$ck] = $ci['hint'] ?? '';
    }
    echo json_encode($hints, JSON_UNESCAPED_UNICODE);
?>;

function mdcEsc(s) {
    if (s == null) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function mdcDirBadge(item) {
    if (item.dose_direction === 'high') return '<span class="badge mdc-dir-high"><i class="fas fa-arrow-up me-1"></i>High</span>';
    if (item.dose_direction === 'low') return '<span class="badge mdc-dir-low"><i class="fas fa-arrow-down me-1"></i>Low</span>';
    return '<span class="text-muted">—</span>';
}
function mdcSelectAllRules(on) {
    $('.mdc-rule-cb').prop('checked', !!on);
    mdcUpdateRuleCount();
}
function mdcSelectGroup(gid, on) {
    $('.mdc-rule-cb[data-group="' + gid + '"]').prop('checked', !!on);
    mdcUpdateRuleCount();
}
function mdcUpdateRuleCount() {
    const total = $('.mdc-rule-cb').length;
    const n = $('.mdc-rule-cb:checked').length;
    $('#mdcRuleCount').text(n + '/' + total);
}

let fpStart, fpEnd;
$(function() {
    if (typeof flatpickr !== 'undefined') {
        fpStart = flatpickr('#filter_start', { dateFormat: 'Y-m-d' });
        fpEnd = flatpickr('#filter_end', { dateFormat: 'Y-m-d' });
    }
    if ($.fn.select2) {
        $('#mdc_drug').select2({ theme: 'bootstrap-5', width: '100%', placeholder: 'ค้นหายา HOSxP' });
    }
    $('#mdc_calc_type').on('change', function() {
        const h = MDC_HINTS[this.value] || 'เลือกสูตรแล้วระบบจะแสดงวิธีตรวจ';
        $('#mdcHint').text(h);
    });
    $(document).on('input', '#mdcRuleSearch', function() {
        const q = (($(this).val() || '') + '').toLowerCase();
        $('.mdc-rule-item').each(function() {
            const t = (($(this).text() || '') + '').toLowerCase();
            $(this).toggle(!q || t.indexOf(q) !== -1);
        });
        $('.mdc-rule-group').each(function() {
            $(this).toggle($(this).find('.mdc-rule-item:visible').length > 0);
        });
    });
    $(document).on('change', '.mdc-rule-cb', mdcUpdateRuleCount);
    mdcUpdateRuleCount();
    monitorInitHnFilter({
        clearHref: 'monitor_dose_calculator.php',
        fetchFn: fetchMdcData,
        autofetch: fetchMdcData
    });
});

function setMdcDateRange(days) {
    const end = new Date();
    const start = new Date();
    if (days <= 1) start.setHours(0,0,0,0);
    else start.setDate(end.getDate() - (days - 1));
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    if (fpStart) fpStart.setDate(fmt(start), true); else $('#filter_start').val(fmt(start));
    if (fpEnd) fpEnd.setDate(fmt(end), true); else $('#filter_end').val(fmt(end));
    $('.mdc-range-btn').removeClass('active');
    $('.mdc-range-btn[data-days="' + days + '"]').addClass('active');
}

function renderMdcRow(item, kind) {
    const when = item.order_time
        ? item.order_date + ' <span class="text-dark">' + mdcEsc(item.order_time) + '</span>'
        : mdcEsc(item.order_date);
    let extra = '';
    if (item.calc_label) extra += '<div class="text-primary small">' + mdcEsc(item.calc_label) + '</div>';
    if (item.weight_source === 'calculator') extra += '<div class="text-success small">(น้ำหนักจากเครื่องคำนวณ)</div>';
    else if (item.weight_vstdate) extra += '<div class="text-muted small">ชั่ง ' + mdcEsc(item.weight_vstdate) + '</div>';
    const msgClass = kind === 'pass' ? 'text-success' : (kind === 'unverifiable' ? 'text-secondary' : 'text-danger');
    const suggest = (kind !== 'pass' && item.suggest_value_text)
        ? '<div class="small fw-bold text-success mt-1">ควรให้ ' + mdcEsc(item.suggest_value_text) + '</div>' : '';
    const rangeHtml = kind === 'pass'
        ? '<div class="mdc-ok small">' + mdcEsc(item.expected_display || '—') + '</div>'
        : (kind === 'unverifiable'
            ? mdcEsc(item.expected_display || '—')
            : '<div class="mdc-mismatch small">' + mdcEsc(item.expected_display || '—') + '</div>' + suggest);
    const bw = item.weight_kg ? mdcEsc(String(item.weight_kg)) + ' kg' : '—';
    const age = (item.age !== null && item.age !== undefined && item.age !== '') ? mdcEsc(String(item.age)) : '—';
    return '<tr>'
        + '<td class="text-center fw-bold">' + mdcEsc(item.hn) + '</td>'
        + '<td class="text-center"><span class="badge ' + (item.type_patient === 'IPD' ? 'bg-secondary' : 'bg-info text-dark') + '">' + mdcEsc(item.type_patient) + '</span></td>'
        + '<td>' + mdcEsc(item.ptname) + '</td>'
        + '<td class="text-center small">' + age + '</td>'
        + '<td class="text-center small">' + when + '</td>'
        + '<td class="text-start"><b>' + mdcEsc(item.drug_name) + '</b><br><small class="text-muted">icode: ' + mdcEsc(item.icode) + '</small>' + extra + '</td>'
        + '<td class="text-start small">' + mdcEsc(item.method || '-') + '</td>'
        + '<td class="text-center small fw-bold">' + bw + '</td>'
        + '<td class="text-center small fw-bold">' + mdcEsc(item.found_display || '—') + '</td>'
        + '<td class="text-center">' + mdcDirBadge(item) + '</td>'
        + '<td class="text-center small">' + rangeHtml + '</td>'
        + '<td class="text-center small">' + mdcEsc(item.ward_display || '-') + '</td>'
        + '<td class="text-start small ' + msgClass + ' fw-bold">' + mdcEsc(item.alert_message || item.pass_message || '') + '</td>'
        + '</tr>';
}

function emptyRow(msg) {
    return '<tr><td colspan="' + MDC_COLSPAN + '" class="text-center py-4 text-muted">' + mdcEsc(msg) + '</td></tr>';
}

function mdcFriendlyError(text, status) {
    const raw = String(text || '');
    if (status === 504 || /504|Gateway Time-out/i.test(raw)) {
        return 'ประมวลผลนานเกินกำหนด (504) — ระบบแบ่งงานทีละวันแล้วรันคู่ขนาน กรุณากดอีกครั้ง หรือย่อช่วงวันที่';
    }
    if (status === 502 || /Bad Gateway/i.test(raw)) {
        return 'เซิร์ฟเวอร์ไม่ตอบ (502) — ลองใหม่ในอีกสักครู่';
    }
    const stripped = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    return (stripped || ('HTTP ' + status)).substring(0, 240);
}

function mdcDatesInRange(start, end) {
    const out = [];
    const a = new Date(start + 'T00:00:00');
    const b = new Date(end + 'T00:00:00');
    if (isNaN(a.getTime()) || isNaN(b.getTime()) || a > b) return out;
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    const cur = new Date(a);
    while (cur <= b) {
        out.push(fmt(cur));
        cur.setDate(cur.getDate() + 1);
    }
    return out;
}

function mdcItemKey(item) {
    return [item.hn, item.icode, item.rxdate || item.order_date, item.order_time, item.method, item.calc_type].join('|');
}

function mdcItemSortKey(item) {
    return String(item.rxdate || '') + ' ' + String(item.order_time || '') + ' ' + String(item.hn || '');
}

function mdcSortItems(list) {
    return list.slice().sort(function(a, b) {
        return mdcItemSortKey(b).localeCompare(mdcItemSortKey(a));
    });
}

function mdcPaintTables(agg, isFinal) {
    const hard = mdcSortItems(agg.hard);
    const soft = mdcSortItems(agg.soft);
    const unv = mdcSortItems(agg.unverifiable);
    const pass = mdcSortItems(agg.passed);
    $('#hardCount').text(hard.length);
    $('#softCount').text(soft.length);
    $('#unverifiableCount').text(unv.length);
    $('#passCount').text(pass.length);
    $('#hardTbody').html(hard.length ? hard.map(i => renderMdcRow(i, 'hard')).join('') : emptyRow(isFinal ? 'ไม่มี Hard Alert' : 'กำลังตรวจ...'));
    $('#softTbody').html(soft.length ? soft.map(i => renderMdcRow(i, 'soft')).join('') : emptyRow(isFinal ? 'ไม่มี Soft Alert' : 'กำลังตรวจ...'));
    $('#unverifiableTbody').html(unv.length ? unv.map(i => renderMdcRow(i, 'unverifiable')).join('') : emptyRow(isFinal ? '—' : 'กำลังตรวจ...'));
    $('#passTbody').html(pass.length ? pass.map(i => renderMdcRow(i, 'pass')).join('') : emptyRow(isFinal ? '—' : 'กำลังตรวจ...'));
}

let mdcFetchGen = 0;
let mdcAbortCtl = null;
const MDC_PARALLEL = 5;

function mdcBuildJobs(ids, days) {
    const jobs = [];
    if (days.length >= 2) {
        days.forEach(function(day) {
            jobs.push({ day: day, ids: ids.slice(), label: day });
        });
        return jobs;
    }
    if (ids.length > 1) {
        ids.forEach(function(id) {
            const name = ($('.mdc-rule-cb[value="' + id + '"]').attr('data-name') || id);
            jobs.push({ day: days[0], ids: [id], label: name });
        });
        return jobs;
    }
    jobs.push({ day: days[0], ids: ids.slice(), label: days[0] });
    return jobs;
}

async function mdcPostJob(job, signal) {
    const r = await fetch('fetch_monitor_dose_calculator_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        signal: signal,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams(monitorAppendHn({
            start_date: job.day,
            end_date: job.day,
            tolerance_pct: $('#tolerance_pct').val() || '',
            rule_ids: job.ids.join(',')
        }))
    });
    const text = await r.text();
    let data;
    try {
        data = JSON.parse(text);
    } catch (e) {
        throw new Error(mdcFriendlyError(text, r.status));
    }
    if (!r.ok || data.status === 'error') {
        throw new Error(data.message || mdcFriendlyError(text, r.status));
    }
    return data;
}

async function mdcPostJobRetry(job, signal) {
    try {
        return await mdcPostJob(job, signal);
    } catch (err) {
        if (err && err.name === 'AbortError') throw err;
        const msg = String(err && err.message ? err.message : '');
        if (/504|นานเกินกำหนด|502/.test(msg)) {
            return await mdcPostJob(job, signal);
        }
        throw err;
    }
}

async function fetchMdcData() {
    const ids = [];
    $('.mdc-rule-cb:checked').each(function() { ids.push(this.value); });
    if (!ids.length) {
        alert('เลือกอย่างน้อย 1 รายการยา');
        return;
    }
    const start = $('#filter_start').val();
    const end = $('#filter_end').val();
    const days = mdcDatesInRange(start, end);
    if (!days.length) {
        alert('กรุณาเลือกช่วงวันที่ให้ถูกต้อง');
        return;
    }

    const gen = ++mdcFetchGen;
    if (mdcAbortCtl) {
        try { mdcAbortCtl.abort(); } catch (e) {}
    }
    const ac = new AbortController();
    mdcAbortCtl = ac;

    const jobs = mdcBuildJobs(ids, days);
    const workers = Math.min(MDC_PARALLEL, jobs.length);
    const t0 = Date.now();
    const agg = { hard: [], soft: [], passed: [], unverifiable: [], seen: {}, orders_scanned: 0, orders_checked: 0, truncated: false };
    const failed = [];
    let done = 0;

    function pushItems(into, add) {
        (add || []).forEach(function(it) {
            const k = mdcItemKey(it);
            if (agg.seen[k]) return;
            agg.seen[k] = true;
            into.push(it);
        });
    }

    $('#btnFetchMdc').prop('disabled', true);
    $('#hardTbody').html(emptyRow('กำลังประมวลผลคู่ขนาน (พร้อมกัน ' + workers + ' งาน)...'));
    $('#softTbody').html(emptyRow('—'));
    $('#unverifiableTbody').html(emptyRow('—'));
    $('#passTbody').html(emptyRow('—'));
    $('#hardCount').text(0);
    $('#softCount').text(0);
    $('#unverifiableCount').text(0);
    $('#passCount').text(0);
    $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info')
        .html('<i class="fas fa-spinner fa-spin me-1"></i> เริ่มตรวจ 0/' + jobs.length + ' งาน (พร้อมกัน ' + workers + ') · ยา ' + ids.length + ' รายการ');

    function updateMeta(label, isFinal) {
        if (gen !== mdcFetchGen) return;
        const sec = ((Date.now() - t0) / 1000).toFixed(1);
        let html = '<i class="fas fa-info-circle me-1"></i> ตรวจแล้ว ' + done + '/' + jobs.length + ' งาน'
            + ' | พร้อมกัน ' + workers
            + ' | ยา ' + ids.length + ' รายการ'
            + ' | Hard: ' + agg.hard.length
            + ' | Soft: ' + agg.soft.length
            + ' | ตรวจสอบไม่ได้: ' + agg.unverifiable.length
            + ' | ผ่าน: ' + agg.passed.length
            + ' | สแกน: ' + agg.orders_scanned
            + ' | ' + sec + ' วินาที';
        if (!isFinal && label) html += ' | ล่าสุด: ' + mdcEsc(label);
        if (agg.truncated) html += ' | <span class="text-danger">บางงานมีใบยาถึงขีดจำกัด — ย่อช่วงวันที่</span>';
        if (failed.length) html += ' | <span class="text-danger">ไม่สำเร็จ ' + failed.length + ' งาน</span>';
        if (isFinal && failed.length) {
            html += '<div class="small fw-normal mt-1">' + failed.map(mdcEsc).join('<br>') + '</div>';
        }
        $('#reportMeta').toggleClass('alert-danger', failed.length > 0 && isFinal)
            .toggleClass('alert-info', !(failed.length > 0 && isFinal))
            .html(html);
    }

    let next = 0;
    async function worker() {
        while (next < jobs.length) {
            if (gen !== mdcFetchGen) return;
            const job = jobs[next++];
            try {
                const data = await mdcPostJobRetry(job, ac.signal);
                const m = data.meta || {};
                pushItems(agg.hard, data.hard_alerts);
                pushItems(agg.soft, data.soft_alerts);
                pushItems(agg.passed, data.passed_items);
                pushItems(agg.unverifiable, data.unverifiable_items);
                agg.orders_scanned += m.orders_scanned || 0;
                agg.orders_checked += m.orders_checked || 0;
                if (m.truncated) agg.truncated = true;
            } catch (err) {
                if (err && err.name === 'AbortError') throw err;
                failed.push((job.label || job.day) + ' — ' + (err && err.message ? err.message : 'เชื่อมต่อไม่สำเร็จ'));
            }
            done++;
            updateMeta(job.label, false);
            mdcPaintTables(agg, false);
        }
    }

    try {
        await Promise.all(Array.from({ length: workers }, worker));
    } catch (err) {
        if (err && err.name === 'AbortError') return;
        if (gen !== mdcFetchGen) return;
        $('#btnFetchMdc').prop('disabled', false);
        $('#hardTbody').html(emptyRow(err && err.message ? err.message : 'เชื่อมต่อ API ไม่สำเร็จ'));
        $('#reportMeta').removeClass('alert-info').addClass('alert-danger').removeClass('d-none')
            .html('<i class="fas fa-times-circle me-1"></i> ' + mdcEsc(err.message || 'ไม่สำเร็จ'));
        return;
    }

    if (gen !== mdcFetchGen) return;
    $('#btnFetchMdc').prop('disabled', false);
    mdcPaintTables(agg, true);
    updateMeta('', true);
}

function ensureMdcSelectOption($sel, val, label) {
    if (!$sel.length || !val) return;
    if ($sel.find('option[value="' + val.replace(/"/g, '\\"') + '"]').length === 0) {
        $sel.append($('<option>', { value: val, text: label }));
    }
}
function resetMdcForm() {
    $('#mdcFormCard').removeClass('edit-mode');
    $('#mdcFormTitle').text('ผูกยาเข้าสูตรเครื่องคำนวณ');
    $('#mdc_action').val('add_mdc');
    $('#mdc_rule_id').val('');
    $('#mdc_calc_type').val('');
    $('#mdc_drug').val('').trigger('change');
    $('#mdc_alert_level').val('hard');
    $('#mdc_alert_message').val('');
    $('#mdc_tolerance').val('');
    $('#mdc_hours').val('');
    $('#mdc_stock').val('');
    $('#mdc_min_kg').val('');
    $('#mdc_max_kg').val('');
    $('#mdc_active').prop('checked', true);
    $('#mdcHint').text('เลือกสูตรแล้วระบบจะแสดงวิธีตรวจ');
    $('.mdc-rule-row').removeClass('mdc-editing-row');
}
function setMdcEditMode(rule) {
    $('.mdc-rule-row').removeClass('mdc-editing-row');
    $('tr.mdc-rule-row[data-rule-id="' + rule.id + '"]').addClass('mdc-editing-row');
    $('#mdcFormCard').addClass('edit-mode');
    $('#mdcFormTitle').text('แก้ไข: ' + (rule.drug_name || '') + ' (ID: ' + rule.id + ')');
    $('#mdc_action').val('edit_mdc');
    $('#mdc_rule_id').val(rule.id);
    $('#mdc_calc_type').val(rule.calc_type).trigger('change');
    const drugVal = (rule.icode || '') + '|' + (rule.drug_name || '');
    ensureMdcSelectOption($('#mdc_drug'), drugVal, (rule.drug_name || '') + ' (icode: ' + rule.icode + ')');
    $('#mdc_drug').val(drugVal).trigger('change');
    $('#mdc_alert_level').val(rule.alert_level === 'soft' ? 'soft' : 'hard');
    $('#mdc_alert_message').val(rule.alert_message || '');
    $('#mdc_tolerance').val(rule.tolerance_pct != null && rule.tolerance_pct !== '' ? rule.tolerance_pct : '');
    $('#mdc_hours').val(rule.default_hours || '');
    $('#mdc_stock').val(rule.stock_mg_ml || '');
    $('#mdc_min_kg').val(rule.mg_per_kg_min || '');
    $('#mdc_max_kg').val(rule.mg_per_kg_max || '');
    $('#mdc_active').prop('checked', !!parseInt(rule.active, 10));
    document.getElementById('mdcFormCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
</script>
</body>
</html>
