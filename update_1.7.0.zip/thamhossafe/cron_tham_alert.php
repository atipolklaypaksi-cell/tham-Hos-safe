<?php
/**
 * Cron ตรวจ 4 pipeline (Doctor / Phar OPD / Phar IPD / Ward queue cleanup)
 * CLI:  php cron_tham_alert.php
 * HTTP: cron_tham_alert.php?key=SECRET
 *
 * รันทุกนาที — วนในรอบ ~55 วินาที ตามช่วง poll ที่ตั้งใน alert_settings.php
 * Master = hosxp_master_setting.php · Slave = hosxp_setting.php
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
set_time_limit(70);
ini_set('memory_limit', '128M');

$lock_path = sys_get_temp_dir() . '/tham_alert_cron.lock';
$lock_fp = @fopen($lock_path, 'c');
if (!$lock_fp || !@flock($lock_fp, LOCK_EX | LOCK_NB)) {
    echo json_encode(['status' => 'skipped', 'message' => 'already running'], JSON_UNESCAPED_UNICODE) . PHP_EOL;
    exit(0);
}

include __DIR__ . '/connect.php';
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/tham_alert_helper.php';
tham_alert_ensure_tables($con);

if (php_sapi_name() !== 'cli') {
    $key = trim((string)($_GET['key'] ?? ''));
    if (!tham_alert_cron_secret_ok($con, $key)) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Forbidden';
        @flock($lock_fp, LOCK_UN);
        @fclose($lock_fp);
        exit;
    }
}

$cfg = tham_alert_config($con);
$poll = (int)$cfg['poll_sec'];
$deadline = time() + 55;
$ticks = [];
do {
    $ticks[] = tham_alert_tick($con);
    if (time() + $poll >= $deadline) {
        break;
    }
    sleep($poll);
} while (time() < $deadline);

@flock($lock_fp, LOCK_UN);
@fclose($lock_fp);

$last = $ticks ? $ticks[count($ticks) - 1] : null;
echo json_encode([
    'status' => 'ok',
    'loops' => count($ticks),
    'poll_sec' => $poll,
    'last' => $last,
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
