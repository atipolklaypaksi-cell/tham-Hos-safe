<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/menu_permissions_helper.php';
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.server_health')) {
    echo "<script>alert('คุณไม่มีสิทธิ์เข้าหน้า Monitor เซิร์ฟเวอร์'); window.location='home.php';</script>";
    exit;
}
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitor เซิร์ฟเวอร์ - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        .sh-hero { border-radius: 14px; padding: 1.25rem 1.5rem; color: #fff; }
        .sh-ok { background: linear-gradient(135deg, #14532d 0%, #166534 55%, #15803d 100%); }
        .sh-warn { background: linear-gradient(135deg, #92400e 0%, #b45309 55%, #d97706 100%); }
        .sh-crit { background: linear-gradient(135deg, #7f1d1d 0%, #b91c1c 55%, #dc2626 100%); }
        .sh-card { border: 0; border-radius: 12px; }
        .sh-metric { font-size: 1.55rem; font-weight: 800; line-height: 1.2; }
        .sh-label { font-size: 0.78rem; color: #64748b; font-weight: 700; letter-spacing: .02em; }
        .sh-pill { font-size: .72rem; font-weight: 700; padding: .15rem .5rem; border-radius: 999px; }
        .sh-pre {
            font-size: .72rem; max-height: 280px; overflow: auto; background: #0f172a; color: #e2e8f0;
            border-radius: 8px; padding: .75rem 1rem; white-space: pre-wrap; word-break: break-word;
        }
        .sh-finding-ok { border-left: 4px solid #16a34a; }
        .sh-finding-warn { border-left: 4px solid #d97706; }
        .sh-finding-crit { border-left: 4px solid #dc2626; }
        .sh-proc td { font-size: .8rem; vertical-align: middle; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div id="hero" class="sh-hero sh-warn mb-4">
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                    <div>
                        <div class="small opacity-75 mb-1"><i class="fas fa-heartbeat me-1"></i>ตั้งค่าระบบ</div>
                        <h4 class="fw-bold mb-1" id="heroTitle"><i class="fas fa-server me-2"></i>Monitor เซิร์ฟเวอร์</h4>
                        <div id="heroSub" class="small opacity-90">กำลังตรวจสุขภาพเครื่อง, Cron และ HOSxP…</div>
                    </div>
                    <div class="text-end">
                        <div class="form-check form-switch text-white">
                            <input class="form-check-input" type="checkbox" id="autoRefresh" checked>
                            <label class="form-check-label small" for="autoRefresh">รีเฟรชทุก 10 วินาที</label>
                        </div>
                        <button class="btn btn-light btn-sm fw-bold mt-2" type="button" id="btnRefresh">
                            <i class="fas fa-sync-alt me-1"></i>ตรวจตอนนี้
                        </button>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-3" id="metrics"></div>
            <div class="row g-3 mb-3">
                <div class="col-lg-7">
                    <div class="card sh-card shadow-sm">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3"><i class="fas fa-stethoscope me-2 text-success"></i>สรุปสาเหตุที่เว็บอาจค้าง</h6>
                            <div id="findings"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="card sh-card shadow-sm h-100">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3"><i class="fas fa-clock me-2 text-warning"></i>สถานะรอบล่าสุด</h6>
                            <div id="cronBox" class="small"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card sh-card shadow-sm mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
                        <div>
                            <h6 class="fw-bold mb-1"><i class="fas fa-cogs me-2 text-secondary"></i>ตั้งค่า Cron job</h6>
                            <p class="small text-muted mb-0">เซิร์ฟเวอร์ตรวจทุก 5 นาที แต่จะรันจริงตามความถี่ที่เลือก · ปิดงานได้จากหน้านี้โดยไม่ต้องแก้ crontab · งาน Smart Pharma ถี่เกินไปมักทำให้เว็บช้าเพราะแย่ง HOSxP</p>
                        </div>
                        <button type="button" class="btn btn-success btn-sm fw-bold" id="btnSaveCron">
                            <i class="fas fa-save me-1"></i>บันทึก Cron
                        </button>
                    </div>
                    <div id="cronJobs"></div>
                    <div id="cronJobsMsg" class="small mt-2"></div>
                </div>
            </div>

            <div class="card sh-card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-1"><i class="fas fa-camera me-2 text-danger"></i>ช่วงที่เว็บค้าง (จับนอกหน้า Monitor)</h6>
                    <p class="small text-muted mb-2">ตอนค้างหน้า Monitor เปิดไม่ได้ เพราะใช้ Apache/PHP ชุดเดียวกับเว็บ — สคริปต์นี้รันจาก crontab ทุก 1 นาที จึงเก็บหลักฐานไว้ดูหลังหายค้าง</p>
                    <div id="hangWatchBox" class="small">กำลังโหลด…</div>
                </div>
            </div>

            <div class="card sh-card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-1"><i class="fas fa-users-cog me-2 text-info"></i>PHP-FPM workers — กำลังเข้าแอปไหน</h6>
                    <p class="small text-muted mb-2">แยก pool แล้ว: <code>hossafe</code> สำหรับ <code>/thamhossafe/</code> และ <code>www</code> สำหรับ Laravel / EMR / ERP / อื่นๆ — ไม่แย่ง worker กันโดยตรง</p>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover sh-proc mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>PID</th>
                                    <th>สถานะ</th>
                                    <th>แอป</th>
                                    <th>เวลาคำขอ</th>
                                    <th>คำขอล่าสุด / กำลังทำ</th>
                                </tr>
                            </thead>
                            <tbody id="fpmBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="card sh-card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-3"><i class="fas fa-microchip me-2 text-primary"></i>โปรเซส PHP ที่กำลังรัน</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover sh-proc mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>PID</th>
                                    <th>ชนิด</th>
                                    <th>เวลา</th>
                                    <th>RAM</th>
                                    <th>คำสั่ง</th>
                                </tr>
                            </thead>
                            <tbody id="procBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="card sh-card shadow-sm mb-4">
                <div class="card-body">
                    <h6 class="fw-bold mb-3"><i class="fas fa-file-alt me-2 text-secondary"></i>ท้ายไฟล์ Log Cron</h6>
                    <div id="logBox"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    const hero = document.getElementById('hero');
    const heroSub = document.getElementById('heroSub');
    let timer = null;
    let jobsFormBuilt = false;

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
    function pill(level, text) {
        const map = { ok: 'bg-success', warn: 'bg-warning text-dark', crit: 'bg-danger' };
        return '<span class="sh-pill ' + (map[level] || 'bg-secondary') + '">' + esc(text) + '</span>';
    }
    function fmtSec(s) {
        s = parseInt(s, 10) || 0;
        if (s < 60) return s + ' วินาที';
        const m = Math.floor(s / 60);
        const r = s % 60;
        return m + ' นาที ' + r + ' วินาที';
    }
    function fmtBytesMb(b) {
        if (!b) return '—';
        return (b / 1073741824 >= 1)
            ? (b / 1073741824).toFixed(1) + ' GB'
            : Math.round(b / 1048576) + ' MB';
    }
    function overallText(level) {
        if (level === 'ok') return { title: 'เครื่องนี้ปกติ', sub: 'CPU/RAM ไม่ได้เป็นคอขวด — ถ้าหน้าเว็บค้าง ให้ดู HOSxP และ Cron' };
        if (level === 'warn') return { title: 'พบจุดที่ทำให้เว็บช้าได้', sub: 'ยังใช้ได้ แต่มีสัญญาณที่ควรดูด้านล่าง' };
        return { title: 'พบปัญหาที่ทำให้ระบบค้าง', sub: 'ดูรายการสรุปด้านล่าง แล้วแก้ตามนั้น' };
    }
    function fpmSub(php) {
        const fpm = (php && php.fpm) || {};
        if (fpm.ok) {
            const busyHos = (fpm.by_app_busy && fpm.by_app_busy.thamhossafe) || 0;
            const busyOther = Math.max(0, (fpm.busy || 0) - busyHos);
            let sub = 'ว่าง ' + (fpm.idle || 0) + ' · Hos-Safe ' + busyHos + ' · อื่น ' + busyOther + ' · max ' + (fpm.max_children || '-');
            if (busyHos === 0 && busyOther === 0 && fpm.last_summary) {
                sub += ' · ล่าสุด ' + fpm.last_summary;
            }
            return sub;
        }
        return 'master ' + ((php && php.fpm_masters) || 0) + ' · ยังแยกแอปไม่ได้';
    }
    function fpmLevel(php) {
        const fpm = (php && php.fpm) || {};
        if (!fpm.ok) return 'ok';
        const maxc = fpm.max_children || 20;
        if ((fpm.busy || 0) >= Math.max(2, maxc - 1) || (fpm.listen_queue || 0) > 0) return 'warn';
        return 'ok';
    }
    function renderFpmWorkers(fpm) {
        const body = document.getElementById('fpmBody');
        if (!body) return;
        if (!fpm || !fpm.ok) {
            body.innerHTML = '<tr><td colspan="5" class="text-muted">ยังอ่านสถานะราย worker ไม่ได้'
                + (fpm && fpm.error ? ' — ' + esc(fpm.error) : '') + '</td></tr>';
            return;
        }
        const rows = fpm.processes || [];
        if (!rows.length) {
            body.innerHTML = '<tr><td colspan="5" class="text-muted">ไม่มี worker</td></tr>';
            return;
        }
        body.innerHTML = rows.map(function (p) {
            const busy = !!p.busy;
            const st = busy ? 'กำลังทำ' : 'ว่าง';
            const pool = p.pool ? (' [' + p.pool + ']') : '';
            const app = busy
                ? ((p.app_label || 'อื่น') + pool)
                : ('ว่าง' + pool + (p.uri && p.app_id && p.app_id !== 'idle' ? ' · ล่าสุด ' + p.app_label : ''));
            const uri = p.uri || p.script || '—';
            const dur = busy && p.duration_ms ? (p.duration_ms + ' ms') : '—';
            return '<tr><td>' + esc(p.pid) + '</td><td>' + pill(busy ? 'warn' : 'ok', st)
                + '</td><td>' + esc(app)
                + '</td><td>' + esc(dur)
                + '</td><td class="font-monospace small">' + esc(uri) + '</td></tr>';
        }).join('');
    }

    function render(data) {
        const ov = overallText(data.overall);
        hero.className = 'sh-hero sh-' + data.overall + ' mb-4';
        document.getElementById('heroTitle').innerHTML = '<i class="fas fa-server me-2"></i>' + esc(ov.title);
        heroSub.innerHTML = ov.sub + ' · ตรวจเมื่อ ' + esc(data.checked_at);

        const cpu = data.cpu || {};
        const mem = data.memory || {};
        const disk = data.disk || {};
        const db = data.db || {};
        const php = data.php || {};
        const cron = data.cron || {};
        const root = disk.root || {};
        const home = disk.home || {};

        document.getElementById('metrics').innerHTML = [
            metricCard('CPU Load', (cpu.load || []).join(' / '), 'คอร์ ' + (cpu.nproc || '-') + ' · 1 / 5 / 15 นาที', cpu.level),
            metricCard('RAM', (mem.used_pct || 0) + '%', 'ว่าง ' + (mem.available_mb || 0) + ' MB จาก ' + (mem.total_mb || 0) + ' MB', mem.level),
            metricCard('ดิสก์', (root.used_pct || 0) + '% ที่ /', 'ว่าง ' + fmtBytesMb(root.free_bytes) + (home.used_pct != null ? ' · /home ' + home.used_pct + '%' : ''), disk.level),
            metricCard('HOSxP', db.hosxp && db.hosxp.ok ? db.hosxp.ms + ' ms' : 'ไม่ได้', (db.hosxp && db.hosxp.host ? db.hosxp.host : '') + (db.hosxp && db.hosxp.ok ? '' : ' — ' + ((db.hosxp && db.hosxp.error) || '')), db.hosxp && db.hosxp.ok ? (db.hosxp.ms >= 1500 ? 'warn' : 'ok') : 'crit'),
            metricCard('HOSoffice', db.hosoffice && db.hosoffice.ok ? db.hosoffice.ms + ' ms' : 'ไม่ได้', (db.hosoffice && db.hosoffice.host ? db.hosoffice.host : '') + (db.hosoffice && db.hosoffice.ok ? ' · Read Only' : ' — ' + ((db.hosoffice && db.hosoffice.error) || '')), db.hosoffice && db.hosoffice.ok ? (db.hosoffice.ms >= 1500 ? 'warn' : 'ok') : (db.hosoffice && db.hosoffice.configured ? 'warn' : 'ok')),
            metricCard('JHCIS PCC', db.jhcis && db.jhcis.ok ? db.jhcis.ms + ' ms' : 'ไม่ได้', (db.jhcis && db.jhcis.host ? db.jhcis.host : '') + (db.jhcis && db.jhcis.ok ? ' · Read Only' : ' — ' + ((db.jhcis && db.jhcis.error) || '')), db.jhcis && db.jhcis.ok ? (db.jhcis.ms >= 1500 ? 'warn' : 'ok') : (db.jhcis && db.jhcis.configured ? 'warn' : 'ok')),
            metricCard('INVC', db.invc && db.invc.ok ? db.invc.ms + ' ms' : 'ไม่ได้', (db.invc && db.invc.host ? db.invc.host : '') + (db.invc && db.invc.ok ? ' · SQL Server RO' : ' — ' + ((db.invc && db.invc.error) || '')), db.invc && db.invc.ok ? (db.invc.ms >= 1500 ? 'warn' : 'ok') : (db.invc && db.invc.configured ? 'warn' : 'ok')),
            metricCard('ฐาน Hos-Safe', db.local && db.local.ok ? db.local.ms + ' ms' : 'ไม่ได้', 'SELECT 1', db.local && db.local.ok ? 'ok' : 'crit'),
            metricCard('PHP-FPM', (php.fpm_workers || 0) + ' worker', fpmSub(php), fpmLevel(php))
        ].join('');
        renderFpmWorkers(php.fpm || {});

        const findings = data.findings || [];
        document.getElementById('findings').innerHTML = findings.map(function (f) {
            return '<div class="bg-white rounded-3 p-3 mb-2 sh-finding-' + esc(f.level) + '">'
                + '<div class="d-flex justify-content-between gap-2">'
                + '<strong>' + esc(f.title) + '</strong>' + pill(f.level, f.level === 'ok' ? 'ปกติ' : (f.level === 'warn' ? 'เฝ้าระวัง' : 'ต้องแก้'))
                + '</div><div class="small text-muted mt-1">' + esc(f.detail) + '</div></div>';
        }).join('');

        const last = cron.last || null;
        const running = cron.running || [];
        let cronHtml = '';
        cronHtml += '<div class="mb-2">ตารางโฮสต์: ' + esc(cron.schedule || '') + '</div>';
        if (running.length) {
            cronHtml += '<div class="mb-2">' + pill('warn', 'กำลังรัน ' + running.length + ' ตัว');
            running.forEach(function (p) {
                cronHtml += '<div class="mt-1">PID ' + esc(p.pid) + ' · ' + fmtSec(p.running_sec) + ' · RAM ' + esc(p.rss_mb) + ' MB</div>';
            });
            cronHtml += '</div>';
        } else {
            cronHtml += '<div class="mb-2">' + pill('ok', 'ตอนนี้ไม่ได้รัน') + '</div>';
        }
        if (last) {
            const st = last.status || '';
            const lv = st === 'ok' ? 'ok' : (st === 'running' ? 'warn' : (st === 'skipped' ? 'warn' : 'crit'));
            cronHtml += '<div class="mb-1">รอบล่าสุด: ' + pill(lv, st || '-') + '</div>';
            cronHtml += '<div>เริ่ม: ' + esc(last.started_at || '-') + '</div>';
            cronHtml += '<div>จบ: ' + esc(last.ended_at || '-') + (last.duration_sec ? ' (' + last.duration_sec + ' วินาที)' : '') + '</div>';
            cronHtml += '<div class="mt-1">' + esc(last.message || '') + '</div>';
        } else {
            cronHtml += '<div class="text-muted">ยังไม่มีสถิติรอบล่าสุด — รอ Cron รันรอบถัดไป</div>';
        }
        document.getElementById('cronBox').innerHTML = cronHtml;
        renderJobs(cron.jobs || []);
        renderHangWatch(data.hang_watch || {});

        const procs = (php.processes || []);
        document.getElementById('procBody').innerHTML = procs.length ? procs.map(function (p) {
            const hot = p.kind.indexOf('cron') === 0 || p.kind === 'mlab-clone' || (p.kind && p.kind.indexOf('fpm-') === 0);
            let cmd = p.cmd || '';
            if (p.request_uri) {
                cmd = (p.app_label ? p.app_label + ' · ' : '') + (p.busy ? 'กำลังทำ ' : 'ล่าสุด ') + p.request_uri;
            }
            return '<tr><td>' + esc(p.pid) + '</td><td>' + pill(hot ? 'warn' : 'ok', p.kind)
                + '</td><td>' + fmtSec(p.running_sec) + '</td><td>' + esc(p.rss_mb) + ' MB</td><td class="font-monospace small">' + esc(cmd) + '</td></tr>';
        }).join('') : '<tr><td colspan="5" class="text-muted">ไม่พบโปรเซส PHP</td></tr>';

        const logs = cron.logs || [];
        document.getElementById('logBox').innerHTML = logs.length ? logs.map(function (lg) {
            return '<div class="mb-3"><div class="small text-muted mb-1">' + esc(lg.path)
                + ' · ' + esc(lg.size_mb) + ' MB · อัปเดต ' + esc(lg.mtime) + '</div>'
                + '<pre class="sh-pre mb-0">' + esc(lg.tail || '(ว่าง)') + '</pre></div>';
        }).join('') : '<div class="text-muted">ไม่พบไฟล์ log</div>';
    }

    function renderHangWatch(hw) {
        const box = document.getElementById('hangWatchBox');
        if (!box) return;
        const latest = hw.latest || null;
        const events = hw.recent_hangs || [];
        let html = '';
        if (hw.has_watcher) {
            html += '<div class="mb-2">' + pill('ok', 'ตัวจับทำงาน') + ' ตรวจล่าสุด ' + esc((latest && latest.at) || '-') + '</div>';
        } else {
            html += '<div class="mb-2">' + pill('warn', 'ยังไม่มีรอบจับล่าสุด') + ' ตั้ง crontab:<pre class="sh-pre mt-2 mb-2">' + esc(hw.cron_line || '') + '</pre></div>';
        }
        if (latest && latest.web) {
            const db = latest.db || {};
            html += '<div class="mb-2">app_ping: ' + (latest.web.ok ? pill('ok', (latest.web.ms || 0) + ' ms') : pill('crit', 'ไม่ตอบ'))
                + ' · ฐาน THAM: ' + (db.ok ? pill('ok', (db.ms || 0) + ' ms') : pill('crit', 'ไม่ตอบ'))
                + ' · load ' + esc(((latest.cpu && latest.cpu.load) || []).join(' / '))
                + (latest.docker_php ? (' · FPM ' + esc(latest.docker_php.busy || 0) + '/' + esc(latest.docker_php.workers || 0) + ' busy (max ' + esc(latest.docker_php.max_children || '-') + ')') : '')
                + ' · cron รันนาน ' + esc((latest.php_long && latest.php_long.length) || 0) + ' โปรเซส</div>';
            const fails = latest.db_fails || [];
            if (fails.length) {
                html += '<div class="mb-2">ต่อฐานไม่สำเร็จล่าสุด<pre class="sh-pre mt-1 mb-0">' + esc(fails.map(function (f) {
                    return (f.at || '') + '  ' + (f.uri || '') + '  ' + (f.message || '');
                }).join('\n')) + '</pre></div>';
            }
        }
        if (!events.length) {
            html += '<div class="text-muted">ยังไม่จับช่วงค้างใน 6 ชั่วโมงล่าสุด — ถ้าเว็บค้างอีกครั้ง รอ 1–2 นาทีแล้วเปิดหน้านี้ใหม่</div>';
            box.innerHTML = html;
            return;
        }
        html += events.map(function (e) {
            const rs = (e.reasons || []).join(' · ') || 'ค้าง';
            const procs = (e.php_long || []).map(function (p) {
                return 'PID ' + p.pid + ' ' + (p.kind || '') + ' ' + fmtSec(p.running_sec) + ' — ' + (p.cmd || '');
            }).join('\n');
            const stuck = (e.slow_requests || []).map(function (p) {
                return (p.uri || p.script || '') + ' ' + Math.round((p.duration_ms || 0) / 1000) + 's';
            }).join('\n');
            const fails = (e.db_fails || []).map(function (f) {
                return (f.at || '') + '  ' + (f.uri || '') + '  ' + (f.message || '');
            }).join('\n');
            const extra = [procs, stuck, fails].filter(Boolean).join('\n');
            return '<div class="border rounded-3 p-2 mb-2 bg-white sh-finding-warn">'
                + '<div class="fw-bold">' + esc(e.at) + '</div>'
                + '<div class="text-muted">' + esc(rs) + ' · ping ' + (e.web_ok ? (e.web_ms + ' ms') : 'ไม่ตอบ')
                + ' · ฐาน ' + (e.db_ok === false ? 'ไม่ตอบ' : (e.db_ok ? 'ตอบ' : '-'))
                + ' · load ' + esc(e.load) + '</div>'
                + (extra ? ('<pre class="sh-pre mt-2 mb-0">' + esc(extra) + '</pre>') : '')
                + '</div>';
        }).join('');
        box.innerHTML = html;
    }

    function optionList(opts, selected) {
        let html = '';
        Object.keys(opts || {}).forEach(function (k) {
            html += '<option value="' + esc(k) + '"' + (String(selected) === String(k) ? ' selected' : '') + '>' + esc(opts[k]) + '</option>';
        });
        return html;
    }
    function jobLastText(job) {
        const last = job.last;
        if (!last) {
            return 'ยังไม่มีรอบล่าสุด';
        }
        const st = last.status || '';
        const when = last.ended_at || last.started_at || '-';
        const dur = last.duration_sec ? ' · ' + last.duration_sec + ' วินาที' : '';
        const extra = last.message ? ' · ' + last.message : '';
        return st + ' · ' + when + dur + extra;
    }
    function jobRunText(job) {
        const running = job.running || [];
        if (!running.length) {
            return 'ไม่ได้รัน';
        }
        return 'กำลังรัน ' + running.length + ' ตัว · PID ' + running.map(function (p) { return p.pid; }).join(', ');
    }
    function renderJobs(jobs) {
        const box = document.getElementById('cronJobs');
        if (!box) {
            return;
        }
        if (jobsFormBuilt) {
            jobs.forEach(function (job) {
                const st = box.querySelector('[data-job-status="' + job.id + '"]');
                if (st) {
                    st.textContent = jobLastText(job);
                }
                const rn = box.querySelector('[data-job-run="' + job.id + '"]');
                if (rn) {
                    rn.innerHTML = (job.running && job.running.length) ? pill('warn', jobRunText(job)) : pill('ok', 'ไม่ได้รัน');
                }
            });
            return;
        }
        if (!jobs.length) {
            box.innerHTML = '<div class="text-muted">ยังไม่มีงาน Cron ที่จัดการได้</div>';
            return;
        }
        box.innerHTML = jobs.map(function (job) {
            const night = job.has_night
                ? ('<div class="col-md-3"><label class="form-label small fw-bold">นอกเวลา (22:00–06:59)</label>'
                    + '<select class="form-select form-select-sm" data-night="' + esc(job.id) + '">' + optionList(job.options || {}, job.night_interval_min) + '</select></div>')
                : '<div class="col-md-3"></div>';
            return '<div class="border rounded-3 p-3 mb-2 bg-white" data-job="' + esc(job.id) + '">'
                + '<div class="d-flex justify-content-between flex-wrap gap-2 mb-2">'
                + '<div><div class="fw-bold">' + esc(job.label) + (job.heavy ? ' <span class="sh-pill bg-warning text-dark">งานหนัก</span>' : '') + '</div>'
                + '<div class="small text-muted">' + esc(job.note || '') + '</div></div>'
                + '<div class="form-check form-switch"><input class="form-check-input" type="checkbox" data-on="' + esc(job.id) + '"' + (job.enabled ? ' checked' : '') + '>'
                + '<label class="form-check-label small fw-bold">เปิดใช้งาน</label></div></div>'
                + '<div class="row g-2 align-items-end">'
                + '<div class="col-md-3"><label class="form-label small fw-bold">' + (job.has_night ? 'ช่วงทำงาน (07:00–21:00)' : 'ความถี่') + '</label>'
                + '<select class="form-select form-select-sm" data-interval="' + esc(job.id) + '">' + optionList(job.options || {}, job.interval_min) + '</select></div>'
                + night
                + '<div class="col-md-6 small">'
                + '<div data-job-run="' + esc(job.id) + '">' + ((job.running && job.running.length) ? pill('warn', jobRunText(job)) : pill('ok', 'ไม่ได้รัน')) + '</div>'
                + '<div class="text-muted mt-1" data-job-status="' + esc(job.id) + '">' + esc(jobLastText(job)) + '</div>'
                + '</div></div></div>';
        }).join('');
        jobsFormBuilt = true;
    }
    function collectJobs() {
        const rows = [];
        document.querySelectorAll('#cronJobs [data-job]').forEach(function (el) {
            const id = el.getAttribute('data-job');
            const on = el.querySelector('[data-on]');
            const iv = el.querySelector('[data-interval]');
            const nt = el.querySelector('[data-night]');
            rows.push({
                id: id,
                enabled: on && on.checked ? 1 : 0,
                interval_min: iv ? parseInt(iv.value, 10) : 10,
                night_interval_min: nt ? parseInt(nt.value, 10) : 0
            });
        });
        return rows;
    }

    function metricCard(title, value, sub, level) {
        return '<div class="col-6 col-lg-4 col-xl-2"><div class="card sh-card shadow-sm h-100"><div class="card-body">'
            + '<div class="d-flex justify-content-between"><div class="sh-label">' + esc(title) + '</div>' + pill(level, level === 'ok' ? 'ปกติ' : (level === 'warn' ? 'ช้า' : 'ผิดปกติ')) + '</div>'
            + '<div class="sh-metric mt-1">' + esc(value) + '</div>'
            + '<div class="small text-muted mt-1">' + esc(sub) + '</div>'
            + '</div></div></div>';
    }

    function load() {
        fetch('fetch_server_health_api.php', { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
                if (!j || j.status !== 'success') {
                    heroSub.textContent = (j && j.msg) ? j.msg : 'โหลดข้อมูลไม่ได้';
                    return;
                }
                render(j.data);
            })
            .catch(function () {
                heroSub.textContent = 'โหลดข้อมูลไม่ได้';
            });
    }

    function armTimer() {
        if (timer) clearInterval(timer);
        timer = null;
        if (document.getElementById('autoRefresh').checked) {
            timer = setInterval(load, 10000);
        }
    }

    document.getElementById('btnRefresh').addEventListener('click', load);
    document.getElementById('autoRefresh').addEventListener('change', armTimer);
    document.getElementById('btnSaveCron').addEventListener('click', function () {
        const btn = this;
        btn.disabled = true;
        fetch('fetch_server_health_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json; charset=UTF-8' },
            body: JSON.stringify({ action: 'save_cron', jobs: collectJobs() })
        }).then(function (r) { return r.json(); }).then(function (j) {
            const msg = document.getElementById('cronJobsMsg');
            msg.className = 'small mt-2 fw-bold ' + (j.status === 'success' ? 'text-success' : 'text-danger');
            msg.textContent = j.msg || '';
            if (j.status === 'success' && j.data) {
                jobsFormBuilt = false;
                render(j.data);
            }
        }).catch(function () {
            document.getElementById('cronJobsMsg').className = 'small mt-2 fw-bold text-danger';
            document.getElementById('cronJobsMsg').textContent = 'บันทึกไม่สำเร็จ';
        }).finally(function () { btn.disabled = false; });
    });
    load();
    armTimer();
})();
</script>
</body>
</html>
