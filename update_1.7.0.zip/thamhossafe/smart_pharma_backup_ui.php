<?php
/**
 * แบนเนอร์ + เสียงแจ้งเตือน Smart Pharma Backup
 */
if (!isset($_SESSION['user_id'])) {
    return;
}
if (!isset($con) || !$con) {
    return;
}
require_once __DIR__ . '/smart_pharma_backup_helper.php';
if (!sp_backup_user_eligible($con)) {
    return;
}
$sp_bk_pt = sp_backup_room_patient_type();
$sp_bk_label = sp_backup_room_label();
$sp_bk_page = ($sp_bk_pt === 'IPD') ? 'smart_pharma_ipd.php' : 'smart_pharma_opd.php';
$sp_bk_cfg = sp_backup_get_config($con);
$sp_bk_win = sp_backup_screen_window($sp_bk_cfg['lookback_minutes'] ?? 60);
$sp_bk_open = $sp_bk_page . '?backup=1&time_window=' . rawurlencode($sp_bk_win);
if (session_status() === PHP_SESSION_ACTIVE && empty($_SESSION['sp_bk_ui_epoch'])) {
    $_SESSION['sp_bk_ui_epoch'] = time();
}
$sp_bk_epoch = (int)($_SESSION['sp_bk_ui_epoch'] ?? time());
?>
<style>
#spBackupBanner {
    display: none;
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    width: 100% !important;
    z-index: 2147482800 !important;
    box-sizing: border-box;
}
#spBackupBanner.is-on { display: block !important; }
body.af-alert-banner-on #spBackupBanner.is-on { top: 72px !important; }
#spBackupBanner .sp-bk-inner {
    display: flex;
    align-items: center;
    gap: 12px;
    width: 100%;
    min-height: 56px;
    padding: 10px 18px;
    color: #fff;
    background: #0f766e;
    border: 4px solid #99f6e4;
    box-shadow: 0 6px 0 #115e59;
    animation: spBkFlash 0.9s linear infinite;
}
#spBackupBanner .sp-bk-icon {
    width: 40px; height: 40px; border-radius: 50%;
    background: rgba(255,255,255,.22);
    display: flex; align-items: center; justify-content: center;
    font-size: 1.25rem; flex-shrink: 0;
}
#spBackupBanner .sp-bk-body { flex: 1; min-width: 0; }
#spBackupBanner .sp-bk-title { font-weight: 800; font-size: 1.15rem; line-height: 1.25; }
#spBackupBanner .sp-bk-meta { font-size: .9rem; opacity: .95; }
#spBackupBanner .sp-bk-open {
    background: #fff !important; color: #0f766e !important;
    font-weight: 800; border: 0;
}
#spBackupBanner .sp-bk-close {
    background: transparent; border: 0; color: #fff;
    font-size: 1.7rem; line-height: 1; padding: 0 6px;
}
body.sp-backup-banner-on { padding-top: 72px !important; }
body.af-alert-banner-on.sp-backup-banner-on { padding-top: 140px !important; }
@keyframes spBkFlash {
    0%, 49% { background: #0f766e; border-color: #99f6e4; }
    50%, 100% { background: #115e59; border-color: #5eead4; }
}
#spBkLoginOverlay {
    display: none;
    position: fixed !important;
    inset: 0 !important;
    z-index: 2147483600 !important;
    background: rgba(15, 36, 25, .5);
    align-items: center;
    justify-content: center;
    padding: 16px;
}
#spBkLoginOverlay.is-on { display: flex !important; }
#spBkLoginCard {
    width: 100%;
    max-width: 460px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 18px 50px rgba(15, 36, 25, .28);
    overflow: hidden;
    font-family: 'Sarabun', Tahoma, sans-serif;
}
#spBkLoginCard .sp-bk-login-head {
    background: linear-gradient(135deg, #0f766e 0%, #115e59 100%);
    color: #fff;
    padding: 18px 20px 16px;
}
#spBkLoginCard .sp-bk-login-head h5 { margin: 0; font-weight: 800; }
#spBkLoginCard .sp-bk-login-body { padding: 18px 20px 8px; color: #334155; font-size: .95rem; line-height: 1.55; }
#spBkLoginCard .sp-bk-login-foot { padding: 8px 20px 18px; }
#spBkLoginOpen {
    background: #0f766e; border: 0; color: #fff; font-weight: 800;
    border-radius: 10px; padding: 10px 16px; width: 100%;
}
#spBkLoginOpen:hover { background: #115e59; color: #fff; }
</style>
<div id="spBackupBanner" aria-live="assertive" aria-hidden="true">
    <div class="sp-bk-inner">
        <div class="sp-bk-icon"><i class="fas fa-user-shield"></i></div>
        <div class="sp-bk-body">
            <div class="sp-bk-title">
                Smart Pharma Alert <span id="spBkCount">0</span> รายการ
                <span class="fw-normal">· <?= htmlspecialchars($sp_bk_label, ENT_QUOTES, 'UTF-8') ?></span>
            </div>
            <div class="sp-bk-meta" id="spBkMeta"></div>
        </div>
        <div class="d-flex gap-2 flex-shrink-0 flex-wrap">
            <a href="<?= htmlspecialchars($sp_bk_open, ENT_QUOTES, 'UTF-8') ?>" class="btn btn-sm fw-bold sp-bk-open" id="spBkOpen">เปิดดู Alert</a>
            <button type="button" class="btn btn-sm btn-outline-light" id="spBkUnlock">เปิดเสียง</button>
        </div>
        <button type="button" class="sp-bk-close" id="spBkHide" title="ซ่อนแบนเนอร์รอบนี้">&times;</button>
    </div>
</div>
<div id="spBkLoginOverlay" aria-modal="true" role="dialog" aria-labelledby="spBkLoginTitle">
    <div id="spBkLoginCard">
        <div class="sp-bk-login-head">
            <div class="small opacity-75 mb-1"><?= htmlspecialchars($sp_bk_label, ENT_QUOTES, 'UTF-8') ?></div>
            <h5 id="spBkLoginTitle"><i class="fas fa-bell me-2"></i>Smart Pharma Alert</h5>
        </div>
        <div class="sp-bk-login-body">
            <div class="fw-bold mb-2">พบ Alert <span id="spBkLoginCount">0</span> รายการ ที่รอตรวจสอบ</div>
            <div id="spBkLoginMeta" class="small text-muted"></div>
        </div>
        <div class="sp-bk-login-foot">
            <a href="<?= htmlspecialchars($sp_bk_open, ENT_QUOTES, 'UTF-8') ?>" class="btn sp-bk-login-open" id="spBkLoginOpen">เปิดดู Alert</a>
            <div class="text-center mt-2">
                <button type="button" class="btn btn-link btn-sm text-secondary text-decoration-none" id="spBkLoginLater">รับทราบ ดูภายหลัง</button>
            </div>
        </div>
    </div>
</div>
<script>
window.SP_BK_SESS = <?= json_encode(session_id(), JSON_UNESCAPED_UNICODE) ?>;
window.SP_BK_UI_EPOCH = <?= (int)$sp_bk_epoch ?>;
</script>
<script src="js/smart_pharma_backup_notifier.js?v=6"></script>
