<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
session_write_close();
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_antibiotic_helper.php');
mysqli_set_charset($con, 'utf8');
set_time_limit(300);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

$override = [];
if (isset($_GET['min_duration_days'])) {
    $override['min_duration_days'] = (int)$_GET['min_duration_days'];
}
if (isset($_GET['order_lookback_days'])) {
    $override['order_lookback_days'] = (int)$_GET['order_lookback_days'];
}
if (isset($_GET['recent_rx_days'])) {
    $override['recent_rx_days'] = (int)$_GET['recent_rx_days'];
}
$hn_raw = function_exists('monitor_req_hn') ? monitor_req_hn() : trim((string)($_GET['hn'] ?? $_POST['hn'] ?? ''));
if ($hn_raw !== '') {
    $override['hn'] = $hn_raw;
}

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}
mysqli_set_charset($hos, 'utf8');

$result = mab_scan($con, $hos, $override);
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
$result['items'] = sp_alert_mute_filter_rows($con, $result['items'] ?? []);
mysqli_close($hos);

if (!empty($result['meta']['error'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'error',
        'message' => $result['meta']['error'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'status' => 'success',
    'items' => $result['items'],
    'summary' => $result['summary'],
    'config' => $result['config'],
    'meta' => $result['meta'],
], JSON_UNESCAPED_UNICODE);
exit;
