<?php
/**
 * Monitor Antibiotic — ระบบ Consult / ใบปรึกษาแพทย์ + สถานะรอตอบกลับ
 */

function mab_consult_statuses() {
    return [
        'waiting' => 'รอ Consult',
        'in_progress' => 'ระหว่าง Consult',
        'closed' => 'ปิดการ Consult',
    ];
}

function mab_consult_status_label($status) {
    $map = mab_consult_statuses();
    $status = mab_consult_normalize_status($status);
    return $map[$status] ?? $status;
}

function mab_consult_normalize_status($status) {
    $s = strtolower(trim((string)$status));
    if ($s === 'in_progress' || $s === 'progress' || $s === 'consulting') {
        return 'in_progress';
    }
    if ($s === 'closed' || $s === 'done' || $s === 'close') {
        return 'closed';
    }
    return 'waiting';
}

function mab_ensure_consult_tables($con) {
    mab_ensure_tables($con);
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_antibiotic_consults.sql');
    if ($sql !== false && trim($sql) !== '') {
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
            if ($stmt === '') {
                continue;
            }
            @mysqli_query($con, $stmt);
        }
    }
    // อัปเกรดคอลัมน์ consults เก่า
    foreach ([
        'close_mode' => "ADD COLUMN close_mode VARCHAR(20) NOT NULL DEFAULT 'more_days' AFTER continue_days",
        'planned_total_days' => 'ADD COLUMN planned_total_days INT NULL AFTER close_mode',
        'plan_off_date' => 'ADD COLUMN plan_off_date DATE NULL AFTER planned_total_days',
    ] as $col => $ddl) {
        $q = mysqli_query($con, "SHOW COLUMNS FROM monitor_antibiotic_consults LIKE '" . mysqli_real_escape_string($con, $col) . "'");
        if (!$q || mysqli_num_rows($q) === 0) {
            @mysqli_query($con, "ALTER TABLE monitor_antibiotic_consults $ddl");
        }
    }
    $q2 = mysqli_query($con, "SHOW COLUMNS FROM monitor_antibiotic_config LIKE 'reply_wait_days'");
    if (!$q2 || mysqli_num_rows($q2) === 0) {
        @mysqli_query($con, "ALTER TABLE monitor_antibiotic_config
            ADD COLUMN reply_wait_days INT NOT NULL DEFAULT 3
            AFTER exclude_method_regex");
    }
}

function mab_get_reply_wait_days($con) {
    mab_ensure_consult_tables($con);
    $cfg = mab_get_config($con);
    $days = (int)($cfg['reply_wait_days'] ?? 3);
    return max(1, $days);
}

function mab_list_pharmacists($con, $prefer_user_id = 0) {
    require_once __DIR__ . '/opduser_auth_helper.php';
    return tham_list_consult_pharmacists($con, $prefer_user_id);
}

function mab_consult_outcome_options() {
    require_once __DIR__ . '/monitor_lab_consult_helper.php';
    return mlc_consult_outcome_options();
}

function mab_parse_consult_outcome($text) {
    require_once __DIR__ . '/monitor_lab_consult_helper.php';
    return mlc_parse_consult_outcome($text);
}

function mab_consult_outcome_checked_html($text) {
    require_once __DIR__ . '/monitor_lab_consult_helper.php';
    return mlc_consult_outcome_checked_html($text);
}

function mab_resolve_pharmacist($con, $user_id, $fallback_name = '') {
    $user_id = (int)$user_id;
    if ($user_id > 0) {
        $q = mysqli_query($con, "SELECT id, full_name, username FROM users WHERE id = $user_id LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            $name = trim((string)($r['full_name'] ?? ''));
            if ($name === '') {
                $name = trim((string)($r['username'] ?? ''));
            }
            return ['id' => (int)$r['id'], 'name' => $name];
        }
    }
    return ['id' => 0, 'name' => trim((string)$fallback_name)];
}

function mab_consult_case_key($an, $med_plan_number) {
    return trim((string)$an) . '|' . trim((string)$med_plan_number);
}

function mab_process_consult_timeouts($con) {
    mab_ensure_consult_tables($con);
    $reopened = 0;

    $q1 = mysqli_query($con, "SELECT * FROM monitor_antibiotic_consults
        WHERE status = 'in_progress' AND reply_due_at IS NOT NULL AND reply_due_at <= NOW()");
    if ($q1) {
        while ($row = mysqli_fetch_assoc($q1)) {
            $id = (int)$row['id'];
            if (mysqli_query($con, "UPDATE monitor_antibiotic_consults SET
                status = 'waiting', reply_due_at = NULL, updated_at = NOW() WHERE id = $id")) {
                $reopened++;
                $after = mab_get_consult($con, $id);
                mab_log_consult_history($con, [
                    'consult_id' => $id,
                    'row' => $after ?: $row,
                    'action_key' => 'timeout_reply',
                    'action_label' => 'หมดเวลารอตอบ — กลับเป็นรอ Consult',
                    'status_before' => 'in_progress',
                    'status_after' => 'waiting',
                    'actor_name' => 'ระบบ',
                ]);
            }
        }
    }

    $q2 = mysqli_query($con, "SELECT * FROM monitor_antibiotic_consults
        WHERE status = 'closed' AND reopen_at IS NOT NULL AND reopen_at <= NOW()");
    if ($q2) {
        while ($row = mysqli_fetch_assoc($q2)) {
            $id = (int)$row['id'];
            if (mysqli_query($con, "UPDATE monitor_antibiotic_consults SET
                status = 'waiting',
                reopen_at = NULL,
                continue_days = NULL,
                close_mode = 'more_days',
                planned_total_days = NULL,
                plan_off_date = NULL,
                closed_at = NULL,
                reply_due_at = NULL,
                updated_at = NOW()
                WHERE id = $id")) {
                $reopened++;
                $after = mab_get_consult($con, $id);
                mab_log_consult_history($con, [
                    'consult_id' => $id,
                    'row' => $after ?: $row,
                    'action_key' => 'timeout_reopen',
                    'action_label' => 'ครบกำหนด plan off — กลับเป็นรอ Consult',
                    'status_before' => 'closed',
                    'status_after' => 'waiting',
                    'actor_name' => 'ระบบ',
                    'continue_days' => $row['continue_days'] ?? null,
                    'planned_total_days' => $row['planned_total_days'] ?? null,
                    'plan_off_date' => $row['plan_off_date'] ?? null,
                ]);
            }
        }
    }
    return $reopened;
}

function mab_get_consult($con, $id) {
    mab_ensure_consult_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM monitor_antibiotic_consults WHERE id = $id LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function mab_find_consult_by_case($con, $an, $med_plan_number) {
    mab_ensure_consult_tables($con);
    $an_esc = mysqli_real_escape_string($con, trim((string)$an));
    $mp_esc = mysqli_real_escape_string($con, trim((string)$med_plan_number));
    $q = mysqli_query($con, "SELECT * FROM monitor_antibiotic_consults
        WHERE an = '$an_esc' AND med_plan_number = '$mp_esc' LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function mab_index_consults($con) {
    mab_ensure_consult_tables($con);
    mab_process_consult_timeouts($con);
    $map = [];
    $q = mysqli_query($con, 'SELECT * FROM monitor_antibiotic_consults');
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $map[mab_consult_case_key($r['an'], $r['med_plan_number'])] = mab_format_consult_row($r);
        }
    }
    return $map;
}

function mab_format_consult_row(array $r) {
    $status = mab_consult_normalize_status($r['status'] ?? 'waiting');
    return [
        'id' => (int)($r['id'] ?? 0),
        'hn' => (string)($r['hn'] ?? ''),
        'an' => (string)($r['an'] ?? ''),
        'med_plan_number' => (string)($r['med_plan_number'] ?? ''),
        'icode' => (string)($r['icode'] ?? ''),
        'drug_name' => (string)($r['drug_name'] ?? ''),
        'method_text' => (string)($r['method_text'] ?? ''),
        'qty' => $r['qty'] ?? null,
        'ward_name' => (string)($r['ward_name'] ?? ''),
        'ptname' => (string)($r['ptname'] ?? ''),
        'firstday' => (string)($r['firstday'] ?? ''),
        'rxdatetime' => (string)($r['rxdatetime'] ?? ''),
        'duration_at_action' => isset($r['duration_at_action']) ? (int)$r['duration_at_action'] : null,
        'status' => $status,
        'status_label' => mab_consult_status_label($status),
        'pharmacist_user_id' => (int)($r['pharmacist_user_id'] ?? 0),
        'pharmacist_name' => (string)($r['pharmacist_name'] ?? ''),
        'consult_note' => (string)($r['consult_note'] ?? ''),
        'doctor_reply' => (string)($r['doctor_reply'] ?? ''),
        'reply_wait_days' => (int)($r['reply_wait_days'] ?? 3),
        'reply_due_at' => (string)($r['reply_due_at'] ?? ''),
        'continue_days' => isset($r['continue_days']) && $r['continue_days'] !== null ? (int)$r['continue_days'] : null,
        'close_mode' => (string)($r['close_mode'] ?? 'more_days'),
        'planned_total_days' => isset($r['planned_total_days']) && $r['planned_total_days'] !== null ? (int)$r['planned_total_days'] : null,
        'plan_off_date' => (string)($r['plan_off_date'] ?? ''),
        'reopen_at' => (string)($r['reopen_at'] ?? ''),
        'started_at' => (string)($r['started_at'] ?? ''),
        'closed_at' => (string)($r['closed_at'] ?? ''),
        'printed_at' => (string)($r['printed_at'] ?? ''),
        'updated_at' => (string)($r['updated_at'] ?? ''),
    ];
}

function mab_default_consult_virtual(array $item) {
    return [
        'id' => 0,
        'hn' => (string)($item['hn'] ?? ''),
        'an' => (string)($item['an'] ?? ''),
        'med_plan_number' => (string)($item['med_plan_number'] ?? ''),
        'icode' => (string)($item['icode'] ?? ''),
        'drug_name' => (string)($item['drug'] ?? ''),
        'method_text' => (string)($item['method'] ?? ''),
        'qty' => $item['qty'] ?? null,
        'ward_name' => (string)($item['wname'] ?? ''),
        'ptname' => (string)($item['ptname'] ?? ''),
        'firstday' => (string)($item['firstday'] ?? ''),
        'rxdatetime' => (string)($item['rxdatetime'] ?? ''),
        'duration_at_action' => isset($item['duration']) ? (int)$item['duration'] : null,
        'status' => 'waiting',
        'status_label' => mab_consult_status_label('waiting'),
        'pharmacist_user_id' => 0,
        'pharmacist_name' => '',
        'consult_note' => '',
        'doctor_reply' => '',
        'reply_wait_days' => 3,
        'reply_due_at' => '',
        'continue_days' => null,
        'close_mode' => 'more_days',
        'planned_total_days' => null,
        'plan_off_date' => '',
        'reopen_at' => '',
        'started_at' => '',
        'closed_at' => '',
        'printed_at' => '',
        'updated_at' => '',
    ];
}

function mab_attach_consults_to_items($con, array $items, $reply_wait_days = 3) {
    $map = mab_index_consults($con);
    $status_counts = ['waiting' => 0, 'in_progress' => 0, 'closed' => 0];
    foreach ($items as &$it) {
        $key = mab_consult_case_key($it['an'] ?? '', $it['med_plan_number'] ?? '');
        if (isset($map[$key])) {
            $consult = $map[$key];
        } else {
            $consult = mab_default_consult_virtual($it);
            $consult['reply_wait_days'] = (int)$reply_wait_days;
        }
        $it['consult'] = $consult;
        $st = $consult['status'] ?? 'waiting';
        if (!isset($status_counts[$st])) {
            $status_counts[$st] = 0;
        }
        $status_counts[$st]++;
    }
    unset($it);
    return [$items, $status_counts];
}

function mab_upsert_consult_from_case($con, array $case, array $extra = []) {
    mab_ensure_consult_tables($con);
    $an = trim((string)($case['an'] ?? ''));
    $mp = trim((string)($case['med_plan_number'] ?? ''));
    if ($an === '' || $mp === '') {
        return ['ok' => false, 'error' => 'ข้อมูล AN / med_plan_number ไม่ครบ'];
    }

    $existing = mab_find_consult_by_case($con, $an, $mp);
    $hn = mysqli_real_escape_string($con, trim((string)($case['hn'] ?? '')));
    $an_esc = mysqli_real_escape_string($con, $an);
    $mp_esc = mysqli_real_escape_string($con, $mp);
    $icode = mysqli_real_escape_string($con, trim((string)($case['icode'] ?? '')));
    $drug = mysqli_real_escape_string($con, trim((string)($case['drug'] ?? $case['drug_name'] ?? '')));
    $method = mysqli_real_escape_string($con, trim((string)($case['method'] ?? $case['method_text'] ?? '')));
    $ward = mysqli_real_escape_string($con, trim((string)($case['wname'] ?? $case['ward_name'] ?? '')));
    $ptname = mysqli_real_escape_string($con, trim((string)($case['ptname'] ?? '')));
    $rxdt = mysqli_real_escape_string($con, trim((string)($case['rxdatetime'] ?? '')));
    $firstday = trim((string)($case['firstday'] ?? ''));
    $firstday_sql = preg_match('/^\d{4}-\d{2}-\d{2}/', $firstday)
        ? "'" . mysqli_real_escape_string($con, substr($firstday, 0, 10)) . "'"
        : 'NULL';
    $qty = isset($case['qty']) && $case['qty'] !== '' ? (float)$case['qty'] : 'NULL';
    $duration = isset($case['duration']) ? (int)$case['duration'] : 'NULL';
    $updated_by = (int)($extra['updated_by'] ?? 0);

    if ($existing) {
        $id = (int)$existing['id'];
        $sql = "UPDATE monitor_antibiotic_consults SET
            hn = '$hn',
            icode = '$icode',
            drug_name = '$drug',
            method_text = '$method',
            qty = $qty,
            ward_name = '$ward',
            ptname = '$ptname',
            firstday = $firstday_sql,
            rxdatetime = '$rxdt',
            duration_at_action = $duration,
            updated_by = $updated_by
            WHERE id = $id";
        if (!mysqli_query($con, $sql)) {
            return ['ok' => false, 'error' => mysqli_error($con)];
        }
        return ['ok' => true, 'id' => $id, 'row' => mab_get_consult($con, $id)];
    }

    $created_by = (int)($extra['created_by'] ?? $updated_by);
    $reply_wait = max(1, (int)($extra['reply_wait_days'] ?? mab_get_reply_wait_days($con)));
    $sql = "INSERT INTO monitor_antibiotic_consults
        (hn, an, med_plan_number, icode, drug_name, method_text, qty, ward_name, ptname,
         firstday, rxdatetime, duration_at_action, status, reply_wait_days, created_by, updated_by)
        VALUES
        ('$hn', '$an_esc', '$mp_esc', '$icode', '$drug', '$method', $qty, '$ward', '$ptname',
         $firstday_sql, '$rxdt', $duration, 'waiting', $reply_wait, $created_by, $updated_by)";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $id = (int)mysqli_insert_id($con);
    return ['ok' => true, 'id' => $id, 'row' => mab_get_consult($con, $id)];
}

function mab_start_consult($con, array $case, $pharmacist_user_id, $pharmacist_name, $note, $actor_user_id, $reply_wait_days = null, $actor_name = '') {
    $up = mab_upsert_consult_from_case($con, $case, [
        'created_by' => $actor_user_id,
        'updated_by' => $actor_user_id,
        'reply_wait_days' => $reply_wait_days,
    ]);
    if (empty($up['ok'])) {
        return $up;
    }
    $id = (int)$up['id'];
    $before = mab_get_consult($con, $id);
    $pharm = mab_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name);
    $wait = max(1, (int)($reply_wait_days ?? mab_get_reply_wait_days($con)));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;

    $sql = "UPDATE monitor_antibiotic_consults SET
        status = 'in_progress',
        pharmacist_user_id = " . ($pid > 0 ? $pid : 'NULL') . ",
        pharmacist_name = '$name_esc',
        consult_note = '$note_esc',
        reply_wait_days = $wait,
        reply_due_at = DATE_ADD(NOW(), INTERVAL $wait DAY),
        reopen_at = NULL,
        continue_days = NULL,
        close_mode = 'more_days',
        planned_total_days = NULL,
        plan_off_date = NULL,
        closed_at = NULL,
        started_at = IFNULL(started_at, NOW()),
        printed_at = NOW(),
        updated_by = $actor
        WHERE id = $id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $row = mab_get_consult($con, $id);
    mab_log_consult_history($con, [
        'consult_id' => $id,
        'row' => $row,
        'action_key' => 'start',
        'action_label' => 'บันทึก Intervention',
        'status_before' => $before['status'] ?? 'waiting',
        'status_after' => 'in_progress',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'reply_due_at' => $row['reply_due_at'] ?? null,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
        'meta' => ['reply_wait_days' => $wait],
    ]);
    return [
        'ok' => true,
        'id' => $id,
        'consult' => mab_format_consult_row($row),
        'print_url' => 'monitor_antibiotic_consult_print.php?id=' . $id,
        'message' => 'เริ่ม Consult แล้ว — รอตอบกลับภายใน ' . $wait . ' วัน',
    ];
}

/**
 * คำนวณวันปิด Consult
 * - more_days: จำนวนวันที่ plan off จากวันนี้ (ใช้ต่ออีกกี่วัน)
 * - total_days: จำนวนวันใช้ยาทั้งหมดนับจาก firstday
 */
function mab_calc_close_schedule(array $row, $close_mode, $days_value) {
    $close_mode = ($close_mode === 'total_days') ? 'total_days' : 'more_days';
    $days_value = max(1, (int)$days_value);
    $firstday = substr(trim((string)($row['firstday'] ?? '')), 0, 10);
    $duration = (int)($row['duration_at_action'] ?? 0);
    if ($duration <= 0 && $firstday !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $firstday)) {
        $ts = strtotime($firstday);
        if ($ts !== false) {
            $duration = max(0, (int)floor((time() - $ts) / 86400));
        }
    }

    if ($close_mode === 'total_days') {
        $planned_total = $days_value;
        if ($firstday !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $firstday)) {
            $plan_off = date('Y-m-d', strtotime($firstday . ' +' . max(0, $planned_total - 1) . ' days'));
            // ถ้า plan_off อยู่ในอดีตหรือวันนี้แล้ว ให้เปิดใหม่พรุ่งนี้ขั้นต่ำ 1 วัน
            $reopen_ts = strtotime($plan_off . ' 23:59:59');
            if ($reopen_ts === false || $reopen_ts <= time()) {
                $continue_days = 1;
                $plan_off = date('Y-m-d', strtotime('+1 day'));
                $reopen_at = date('Y-m-d H:i:s', strtotime('+1 day'));
            } else {
                $continue_days = max(1, (int)ceil(($reopen_ts - time()) / 86400));
                $reopen_at = date('Y-m-d H:i:s', $reopen_ts);
            }
        } else {
            $remain = max(1, $planned_total - $duration);
            $continue_days = $remain;
            $plan_off = date('Y-m-d', strtotime('+' . $remain . ' days'));
            $reopen_at = date('Y-m-d H:i:s', strtotime('+' . $remain . ' days'));
        }
        return [
            'close_mode' => 'total_days',
            'continue_days' => $continue_days,
            'planned_total_days' => $planned_total,
            'plan_off_date' => $plan_off,
            'reopen_at' => $reopen_at,
            'message' => 'ปิด Consult แล้ว — plan ใช้รวม ' . $planned_total . ' วัน (off ประมาณ ' . $plan_off . ') จะกลับมาแจ้งเตือนหลังครบกำหนด',
        ];
    }

    // more_days = จำนวนวันที่ต้องใช้ต่อจากวันนี้ / วันจนถึง plan off
    $continue_days = $days_value;
    $plan_off = date('Y-m-d', strtotime('+' . $continue_days . ' days'));
    $reopen_at = date('Y-m-d H:i:s', strtotime('+' . $continue_days . ' days'));
    $planned_total = $duration > 0 ? ($duration + $continue_days) : null;
    return [
        'close_mode' => 'more_days',
        'continue_days' => $continue_days,
        'planned_total_days' => $planned_total,
        'plan_off_date' => $plan_off,
        'reopen_at' => $reopen_at,
        'message' => 'ปิด Consult แล้ว — plan off ในอีก ' . $continue_days . ' วัน (ประมาณ ' . $plan_off . ')',
    ];
}

function mab_close_consult($con, $consult_id, $days_value, $note, $actor_user_id, $pharmacist_user_id = 0, $pharmacist_name = '', $close_mode = 'more_days', $actor_name = '', $doctor_reply = '') {
    $consult_id = (int)$consult_id;
    $row = mab_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบรายการ Consult'];
    }
    $sched = mab_calc_close_schedule($row, $close_mode, $days_value);
    $pharm = mab_resolve_pharmacist($con, $pharmacist_user_id ?: (int)$row['pharmacist_user_id'], $pharmacist_name ?: $row['pharmacist_name']);
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $reply_esc = mysqli_real_escape_string($con, trim((string)$doctor_reply));
    $mode_esc = mysqli_real_escape_string($con, $sched['close_mode']);
    $plan_off_esc = mysqli_real_escape_string($con, $sched['plan_off_date']);
    $reopen_esc = mysqli_real_escape_string($con, $sched['reopen_at']);
    $continue_days = (int)$sched['continue_days'];
    $planned_total = $sched['planned_total_days'] !== null ? (int)$sched['planned_total_days'] : 'NULL';
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $before_status = $row['status'] ?? '';

    $sql = "UPDATE monitor_antibiotic_consults SET
        status = 'closed',
        continue_days = $continue_days,
        close_mode = '$mode_esc',
        planned_total_days = $planned_total,
        plan_off_date = '$plan_off_esc',
        reopen_at = '$reopen_esc',
        reply_due_at = NULL,
        closed_at = NOW(),
        pharmacist_user_id = " . ($pid > 0 ? $pid : 'NULL') . ",
        pharmacist_name = '$name_esc',
        consult_note = IF('$note_esc' = '', consult_note, '$note_esc'),
        doctor_reply = IF('$reply_esc' = '', doctor_reply, '$reply_esc'),
        updated_by = $actor
        WHERE id = $consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $row = mab_get_consult($con, $consult_id);
    mab_log_consult_history($con, [
        'consult_id' => $consult_id,
        'row' => $row,
        'action_key' => 'close',
        'action_label' => 'ปิดการ Consult',
        'status_before' => $before_status,
        'status_after' => 'closed',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'doctor_reply' => $doctor_reply,
        'close_mode' => $sched['close_mode'],
        'continue_days' => $continue_days,
        'planned_total_days' => $sched['planned_total_days'],
        'plan_off_date' => $sched['plan_off_date'],
        'reopen_at' => $sched['reopen_at'],
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return [
        'ok' => true,
        'id' => $consult_id,
        'consult' => mab_format_consult_row($row),
        'schedule' => $sched,
        'message' => $sched['message'],
    ];
}

function mab_reset_consult_waiting($con, $consult_id, $actor_user_id, $note = '', $actor_name = '', $action_key = 'reset', $action_label = 'ตั้งเป็นรอ Consult') {
    $consult_id = (int)$consult_id;
    $row = mab_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบรายการ Consult'];
    }
    $before = $row['status'] ?? '';
    $actor = (int)$actor_user_id;
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $note_sql = $note_esc !== '' ? ", consult_note = '$note_esc'" : '';
    $sql = "UPDATE monitor_antibiotic_consults SET
        status = 'waiting',
        reply_due_at = NULL,
        reopen_at = NULL,
        continue_days = NULL,
        close_mode = 'more_days',
        planned_total_days = NULL,
        plan_off_date = NULL,
        closed_at = NULL,
        updated_by = $actor
        $note_sql
        WHERE id = $consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $row = mab_get_consult($con, $consult_id);
    mab_log_consult_history($con, [
        'consult_id' => $consult_id,
        'row' => $row,
        'action_key' => $action_key,
        'action_label' => $action_label,
        'status_before' => $before,
        'status_after' => 'waiting',
        'note_text' => $note,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return [
        'ok' => true,
        'id' => $consult_id,
        'consult' => mab_format_consult_row($row),
        'message' => 'ตั้งสถานะเป็น รอ Consult แล้ว',
    ];
}

function mab_save_consult_result($con, $consult_id, $note, $doctor_reply, $actor_user_id, $actor_name = '', $pharmacist_user_id = 0, $pharmacist_name = '') {
    $consult_id = (int)$consult_id;
    $row = mab_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบรายการ Consult'];
    }
    $pharm = mab_resolve_pharmacist($con, $pharmacist_user_id ?: (int)$row['pharmacist_user_id'], $pharmacist_name ?: $row['pharmacist_name']);
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $reply_esc = mysqli_real_escape_string($con, trim((string)$doctor_reply));
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $sql = "UPDATE monitor_antibiotic_consults SET
        pharmacist_user_id = " . ($pid > 0 ? $pid : 'NULL') . ",
        pharmacist_name = '$name_esc',
        consult_note = IF('$note_esc' = '', consult_note, '$note_esc'),
        doctor_reply = IF('$reply_esc' = '', doctor_reply, '$reply_esc'),
        updated_by = $actor
        WHERE id = $consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $row = mab_get_consult($con, $consult_id);
    mab_log_consult_history($con, [
        'consult_id' => $consult_id,
        'row' => $row,
        'action_key' => 'save_result',
        'action_label' => 'บันทึกผล Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => $row['status'] ?? '',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'doctor_reply' => $doctor_reply,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return [
        'ok' => true,
        'id' => $consult_id,
        'consult' => mab_format_consult_row($row),
        'message' => 'บันทึกผล Consult เรียบร้อย',
    ];
}

function mab_log_consult_history($con, array $data) {
    mab_ensure_consult_tables($con);
    $row = $data['row'] ?? [];
    $consult_id = (int)($data['consult_id'] ?? ($row['id'] ?? 0));
    $hn = mysqli_real_escape_string($con, (string)($row['hn'] ?? ''));
    $an = mysqli_real_escape_string($con, (string)($row['an'] ?? ''));
    $mp = mysqli_real_escape_string($con, (string)($row['med_plan_number'] ?? ''));
    $icode = mysqli_real_escape_string($con, (string)($row['icode'] ?? ''));
    $drug = mysqli_real_escape_string($con, (string)($row['drug_name'] ?? ''));
    $action_key = mysqli_real_escape_string($con, (string)($data['action_key'] ?? ''));
    $action_label = mysqli_real_escape_string($con, (string)($data['action_label'] ?? $action_key));
    $sb = mysqli_real_escape_string($con, (string)($data['status_before'] ?? ''));
    $sa = mysqli_real_escape_string($con, (string)($data['status_after'] ?? ''));
    $pharm = mysqli_real_escape_string($con, (string)($data['pharmacist_name'] ?? ($row['pharmacist_name'] ?? '')));
    $note = mysqli_real_escape_string($con, (string)($data['note_text'] ?? ''));
    $reply = mysqli_real_escape_string($con, (string)($data['doctor_reply'] ?? ''));
    $mode = mysqli_real_escape_string($con, (string)($data['close_mode'] ?? ''));
    $continue = isset($data['continue_days']) && $data['continue_days'] !== null && $data['continue_days'] !== ''
        ? (int)$data['continue_days'] : 'NULL';
    $planned = isset($data['planned_total_days']) && $data['planned_total_days'] !== null && $data['planned_total_days'] !== ''
        ? (int)$data['planned_total_days'] : 'NULL';
    $plan_off = !empty($data['plan_off_date'])
        ? "'" . mysqli_real_escape_string($con, substr((string)$data['plan_off_date'], 0, 10)) . "'"
        : 'NULL';
    $reopen = !empty($data['reopen_at'])
        ? "'" . mysqli_real_escape_string($con, (string)$data['reopen_at']) . "'"
        : 'NULL';
    $reply_due = !empty($data['reply_due_at'])
        ? "'" . mysqli_real_escape_string($con, (string)$data['reply_due_at']) . "'"
        : 'NULL';
    $meta = '';
    if (!empty($data['meta']) && is_array($data['meta'])) {
        $meta = mysqli_real_escape_string($con, json_encode($data['meta'], JSON_UNESCAPED_UNICODE));
    }
    $actor_id = (int)($data['actor_user_id'] ?? 0);
    $actor_name = mysqli_real_escape_string($con, (string)($data['actor_name'] ?? ''));

    $sql = "INSERT INTO monitor_antibiotic_consult_history
        (consult_id, hn, an, med_plan_number, icode, drug_name, action_key, action_label,
         status_before, status_after, pharmacist_name, note_text, doctor_reply, close_mode,
         continue_days, planned_total_days, plan_off_date, reopen_at, reply_due_at, meta_json,
         actor_user_id, actor_name)
        VALUES
        ($consult_id, '$hn', '$an', '$mp', '$icode', '$drug', '$action_key', '$action_label',
         '$sb', '$sa', '$pharm', '$note', '$reply', '$mode',
         $continue, $planned, $plan_off, $reopen, $reply_due, " . ($meta !== '' ? "'$meta'" : 'NULL') . ",
         " . ($actor_id > 0 ? $actor_id : 'NULL') . ", '$actor_name')";
    return (bool)@mysqli_query($con, $sql);
}

function mab_list_consult_history($con, array $opts = []) {
    mab_ensure_consult_tables($con);
    $where = ['1=1'];
    if (!empty($opts['consult_id'])) {
        $where[] = 'consult_id = ' . (int)$opts['consult_id'];
    }
    if (!empty($opts['hn'])) {
        $where[] = "hn = '" . mysqli_real_escape_string($con, trim((string)$opts['hn'])) . "'";
    }
    if (!empty($opts['an'])) {
        $where[] = "an = '" . mysqli_real_escape_string($con, trim((string)$opts['an'])) . "'";
    }
    if (!empty($opts['med_plan_number'])) {
        $where[] = "med_plan_number = '" . mysqli_real_escape_string($con, trim((string)$opts['med_plan_number'])) . "'";
    }
    $limit = max(1, min(500, (int)($opts['limit'] ?? 100)));
    $sql = 'SELECT * FROM monitor_antibiotic_consult_history WHERE ' . implode(' AND ', $where)
        . ' ORDER BY created_at DESC, id DESC LIMIT ' . $limit;
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'id' => (int)$r['id'],
                'consult_id' => (int)$r['consult_id'],
                'hn' => $r['hn'],
                'an' => $r['an'],
                'med_plan_number' => $r['med_plan_number'],
                'icode' => $r['icode'],
                'drug_name' => $r['drug_name'],
                'action_key' => $r['action_key'],
                'action_label' => $r['action_label'],
                'status_before' => $r['status_before'],
                'status_after' => $r['status_after'],
                'status_before_label' => mab_consult_status_label($r['status_before']),
                'status_after_label' => mab_consult_status_label($r['status_after']),
                'pharmacist_name' => $r['pharmacist_name'],
                'note_text' => $r['note_text'],
                'doctor_reply' => $r['doctor_reply'],
                'close_mode' => $r['close_mode'],
                'continue_days' => $r['continue_days'] !== null ? (int)$r['continue_days'] : null,
                'planned_total_days' => $r['planned_total_days'] !== null ? (int)$r['planned_total_days'] : null,
                'plan_off_date' => $r['plan_off_date'],
                'reopen_at' => $r['reopen_at'],
                'reply_due_at' => $r['reply_due_at'],
                'actor_name' => $r['actor_name'],
                'created_at' => $r['created_at'],
            ];
        }
    }
    return $rows;
}

function mab_get_consult_history_row($con, $id) {
    mab_ensure_consult_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM monitor_antibiotic_consult_history WHERE id = $id LIMIT 1");
    if (!$q || !($r = mysqli_fetch_assoc($q))) {
        return null;
    }
    return $r;
}

function mab_update_consult_history($con, $id, array $fields) {
    mab_ensure_consult_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบประวัติ'];
    }
    $row = mab_get_consult_history_row($con, $id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบประวัติ'];
    }

    $sets = [];
    $textCols = ['action_label', 'drug_name', 'note_text', 'doctor_reply', 'actor_name', 'pharmacist_name'];
    foreach ($textCols as $col) {
        if (!array_key_exists($col, $fields)) {
            continue;
        }
        $sets[] = $col . " = '" . mysqli_real_escape_string($con, trim((string)$fields[$col])) . "'";
    }
    if (array_key_exists('continue_days', $fields)) {
        $v = trim((string)$fields['continue_days']);
        $sets[] = $v === '' ? 'continue_days = NULL' : ('continue_days = ' . (int)$v);
    }
    if (array_key_exists('planned_total_days', $fields)) {
        $v = trim((string)$fields['planned_total_days']);
        $sets[] = $v === '' ? 'planned_total_days = NULL' : ('planned_total_days = ' . (int)$v);
    }
    if (array_key_exists('plan_off_date', $fields)) {
        $v = substr(trim((string)$fields['plan_off_date']), 0, 10);
        $sets[] = $v === ''
            ? 'plan_off_date = NULL'
            : ("plan_off_date = '" . mysqli_real_escape_string($con, $v) . "'");
    }
    if (array_key_exists('reply_due_at', $fields)) {
        $v = trim((string)$fields['reply_due_at']);
        $sets[] = $v === ''
            ? 'reply_due_at = NULL'
            : ("reply_due_at = '" . mysqli_real_escape_string($con, $v) . "'");
    }
    if (empty($sets)) {
        return ['ok' => false, 'error' => 'ไม่มีข้อมูลที่แก้ไข'];
    }

    $sql = 'UPDATE monitor_antibiotic_consult_history SET ' . implode(', ', $sets) . ' WHERE id = ' . $id;
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ'];
    }
    return ['ok' => true, 'id' => $id];
}

function mab_delete_consult_history($con, $id, $confirm = '') {
    mab_ensure_consult_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบประวัติ'];
    }
    if (trim((string)$confirm) !== 'delete') {
        return ['ok' => false, 'error' => "พิมพ์คำว่า 'delete' เพื่อยืนยันการลบ"];
    }
    $row = mab_get_consult_history_row($con, $id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบประวัติ'];
    }
    if (!mysqli_query($con, "DELETE FROM monitor_antibiotic_consult_history WHERE id = $id LIMIT 1")) {
        return ['ok' => false, 'error' => 'ลบไม่สำเร็จ'];
    }
    return ['ok' => true, 'id' => $id];
}

function mab_mark_consult_printed($con, $consult_id) {
    $consult_id = (int)$consult_id;
    if ($consult_id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "UPDATE monitor_antibiotic_consults SET printed_at = NOW() WHERE id = $consult_id");
}
