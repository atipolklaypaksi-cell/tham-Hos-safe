<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('hosxp_tmt_drug_helper.php');
include('monitor_mg_ml_helper.php');
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
mysqli_set_charset($con, 'utf8');

mmgml_ensure_table($con);

$tab = (isset($_GET['tab']) && $_GET['tab'] === 'settings') ? 'settings' : 'calc';
$prefill_hn = isset($_GET['hn']) ? htmlspecialchars((string)$_GET['hn'], ENT_QUOTES, 'UTF-8') : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_item' || $action === 'edit_item') {
        $drug = hosxp_parse_drug_option($_POST['drug'] ?? '');
        $id = ($action === 'edit_item') ? (int)($_POST['rule_id'] ?? 0) : 0;
        $res = mmgml_save_catalog_item($con, [
            'icode' => $drug['icode'],
            'drug_name' => $drug['name'],
            'strength_text' => $_POST['strength_text'] ?? '',
            'mg_per_ml' => $_POST['mg_per_ml'] ?? 0,
            'mg_per_amp' => $_POST['mg_per_amp'] ?? '',
            'calc_mg_per_kg_min' => $_POST['calc_mg_per_kg_min'] ?? '',
            'calc_mg_per_kg_max' => $_POST['calc_mg_per_kg_max'] ?? '',
            'calc_interval_hours' => $_POST['calc_interval_hours'] ?? '',
            'detail_text' => $_POST['detail_text'] ?? '',
            'active' => isset($_POST['active']) ? 1 : 0,
        ], $id);
        if (!empty($res['ok'])) {
            $_SESSION['mmc_msg'] = $res['message'] ?? 'บันทึกเรียบร้อย';
            if (function_exists('sp_monitor_settings_changed')) {
                sp_monitor_settings_changed($con, 'mg_ml');
            }
        } else {
            $_SESSION['mmc_error'] = $res['error'] ?? 'บันทึกไม่สำเร็จ';
        }
        header('Location: mg_ml_calculator.php?tab=settings');
        exit;
    }

    if ($action === 'delete_item') {
        $id = (int)($_POST['rule_id'] ?? 0);
        if ($id > 0) {
            mysqli_query($con, "DELETE FROM monitor_mg_ml_settings WHERE id=$id");
            if (function_exists('sp_monitor_settings_changed')) {
                sp_monitor_settings_changed($con, 'mg_ml');
            }
            $_SESSION['mmc_msg'] = 'ลบรายการยาเรียบร้อย';
        }
        header('Location: mg_ml_calculator.php?tab=settings');
        exit;
    }

    if ($action === 'scan_tmt') {
        $hos = hosxp_connect($con);
        $result = mmgml_scan_from_tmt($hos, $con);
        if ($hos) {
            mysqli_close($hos);
        }
        if (($result['message'] ?? '') === 'ok') {
            $_SESSION['mmc_msg'] = 'สแกน TMT สำเร็จ — เพิ่ม ' . (int)$result['inserted']
                . ' รายการ, อัปเดต ' . (int)$result['updated']
                . ' (ข้าม ' . (int)$result['skipped'] . ' จาก ' . (int)$result['scanned'] . ')';
            if (function_exists('sp_monitor_settings_changed')) {
                sp_monitor_settings_changed($con, 'mg_ml');
            }
        } else {
            $_SESSION['mmc_error'] = 'สแกนไม่สำเร็จ: ' . ($result['message'] ?? 'unknown');
        }
        header('Location: mg_ml_calculator.php?tab=settings');
        exit;
    }

    if ($action === 'import_inject_catalog') {
        $hos = hosxp_connect($con);
        $result = mmgml_import_injection_catalog($hos, $con);
        if ($hos) {
            mysqli_close($hos);
        }
        if (($result['message'] ?? '') === 'ok' || empty($result['message'])) {
            $msg = 'นำเข้าคลังยาฉีด — เพิ่ม ' . (int)($result['inserted'] ?? 0)
                . ' · อัปเดต ' . (int)($result['updated'] ?? 0)
                . ' · ข้าม ' . (int)($result['skipped'] ?? 0);
            if (!empty($result['unmatched'])) {
                $msg .= ' · ไม่พบใน HOSxP ' . (int)$result['unmatched'];
            }
            $_SESSION['mmc_msg'] = $msg;
            if (!empty($result['inserted']) || !empty($result['updated'])) {
                if (function_exists('sp_monitor_settings_changed')) {
                    sp_monitor_settings_changed($con, 'mg_ml');
                }
            }
        } else {
            $_SESSION['mmc_error'] = 'นำเข้าไม่สำเร็จ: ' . ($result['message'] ?? 'unknown');
        }
        header('Location: mg_ml_calculator.php?tab=settings');
        exit;
    }
}

$all_rules = [];
$q_rules = mysqli_query($con, "SELECT * FROM monitor_mg_ml_settings ORDER BY drug_name ASC, id ASC");
if ($q_rules) {
    while ($r = mysqli_fetch_assoc($q_rules)) {
        $all_rules[] = $r;
    }
}
$active_catalog = [];
foreach ($all_rules as $r) {
    if (!empty($r['active']) && (float)($r['mg_per_ml'] ?? 0) > 0) {
        $active_catalog[] = mmgml_rule_for_calculator($r);
    }
}

$flash_msg = $_SESSION['mmc_msg'] ?? '';
$flash_err = $_SESSION['mmc_error'] ?? '';
unset($_SESSION['mmc_msg'], $_SESSION['mmc_error']);
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>คำนวณ mg → mL - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/select2.min.css" rel="stylesheet">
    <link href="css/select2-bootstrap-5-theme.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .mmc-patient-box { background: #ecfdf5; border: 1px solid #6ee7b7; border-radius: 10px; }
        .mmc-result { background: #fce7f3; border: 1px solid #f9a8d4; border-radius: 8px; padding: 0.85rem 1rem; }
        .mmc-result .val { font-size: 1.2rem; font-weight: 800; color: #9d174d; }
        .mmc-result-green { background: #dcfce7; border-color: #86efac; }
        .mmc-result-green .val { color: #166534; }
        .mmc-result-blue { background: #dbeafe; border-color: #93c5fd; }
        .mmc-result-blue .val { color: #1d4ed8; }
        .mmc-input-yellow { background: #fff3cd !important; border-color: #ffc107 !important; font-weight: 700; }
        .mmc-hint { background: #0d6efd; color: #fff; border-radius: 8px; padding: 0.65rem 1rem; font-weight: 600; font-size: 0.95rem; }
        .mmc-method { background: #ffedd5; border: 1px solid #fdba74; border-radius: 8px; padding: 0.75rem 1rem; font-weight: 600; white-space: pre-wrap; }
        tr.mmc-order-row { cursor: pointer; }
        tr.mmc-order-row:hover { background: #e0f2fe; }
        tr.mmc-order-picked { background: #dbeafe !important; }
        #mmcFormCard.edit-mode .card-header { background-color: #0a58ca !important; }
        tr.mmc-editing-row { background-color: #e7f1ff !important; }
        .mmc-tabs .nav-link {
            font-weight: 700;
            color: #475569;
            border: 1px solid transparent;
            border-radius: 8px 8px 0 0;
            padding: 0.65rem 1.15rem;
        }
        .mmc-tabs .nav-link:hover { color: #0d6efd; background: #eff6ff; }
        .mmc-tabs .nav-link.active {
            color: #0d6efd;
            background: #fff;
            border-color: #dee2e6 #dee2e6 #fff;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-1 text-dark">
                <i class="fas fa-syringe me-2" style="color:#0d6efd;"></i>คำนวณ mg → mL
            </h4>
            <p class="text-muted small mb-3">ค้นหา HN เพื่อดึงใบยาฉีดตามรายการที่ตั้งค่า แล้วแปลงขนาด mg เป็น mL ตามความเข้มข้น — รายการยานี้ใช้ร่วมกับ Monitor mg → mL</p>

            <ul class="nav nav-tabs mmc-tabs mb-0" id="mmcTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo $tab === 'calc' ? 'active' : ''; ?>" id="mmc-tab-calc" data-bs-toggle="tab" data-bs-target="#mmc-pane-calc" type="button" role="tab">
                        <i class="fas fa-calculator me-1"></i> คำนวณ
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo $tab === 'settings' ? 'active' : ''; ?>" id="mmc-tab-settings" data-bs-toggle="tab" data-bs-target="#mmc-pane-settings" type="button" role="tab">
                        <i class="fas fa-cogs me-1"></i> ตั้งค่ารายการยา
                    </button>
                </li>
            </ul>
            <div class="tab-content bg-white border border-top-0 p-3 rounded-bottom shadow-sm mb-3">

            <?php if ($flash_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo htmlspecialchars($flash_msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            <?php if ($flash_err): ?>
            <div class="alert alert-danger alert-dismissible fade show"><?php echo htmlspecialchars($flash_err); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <div class="tab-pane fade <?php echo $tab === 'calc' ? 'show active' : ''; ?>" id="mmc-pane-calc" role="tabpanel">
            <div class="card border-0 shadow-sm mb-3 mmc-patient-box">
                <div class="card-body py-3">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">HN <span class="text-danger">*</span></label>
                            <input type="text" id="mmc_hn" class="form-control form-control-lg fw-bold border-success" placeholder="กรอก HN" value="<?php echo $prefill_hn; ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-bold mb-1">ย้อนหลัง</label>
                            <select id="mmc_days" class="form-select">
                                <option value="3">3 วัน</option>
                                <option value="7" selected>7 วัน</option>
                                <option value="14">14 วัน</option>
                                <option value="30">30 วัน</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="button" id="mmcBtnLookup" class="btn btn-success btn-lg w-100 fw-bold">
                                <i class="fas fa-search me-1"></i> ค้นหา
                            </button>
                        </div>
                        <div class="col-md-5">
                            <div id="mmcPatientInfo" class="small text-muted">ยังไม่ได้เลือกผู้ป่วย — กรอก HN แล้วกดค้นหา</div>
                        </div>
                    </div>
                    <div class="row g-2 mt-2" id="mmcVitalsRow">
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">น้ำหนักล่าสุด (kg)</label>
                            <input type="number" id="mmc_bw" class="form-control mmc-input-yellow" min="0.1" step="0.1" placeholder="kg">
                            <div class="small text-muted" id="mmcBwHint">ค้นหา HN เพื่อดึงน้ำหนักจาก HOSxP</div>
                        </div>
                    </div>
                    <div id="mmcMsg" class="mt-2 small" style="display:none;"></div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-lg-5">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white fw-bold">
                            <i class="fas fa-exchange-alt me-1 text-primary"></i> แปลง mg ↔ mL
                        </div>
                        <div class="card-body">
                            <div class="mb-2">
                                <label class="form-label small fw-bold">ยา (จากรายการที่ตั้งค่า)</label>
                                <select id="mmc_drug" class="form-select">
                                    <option value="">— เลือกยา —</option>
                                    <?php foreach ($active_catalog as $c): ?>
                                    <option value="<?php echo (int)$c['id']; ?>"
                                        data-icode="<?php echo htmlspecialchars($c['icode']); ?>"
                                        data-mgml="<?php echo htmlspecialchars((string)$c['mg_per_ml']); ?>"
                                        data-amp="<?php echo htmlspecialchars((string)($c['mg_per_amp'] ?? '')); ?>"
                                        data-kgmin="<?php echo htmlspecialchars((string)($c['calc_mg_per_kg_min'] ?? '')); ?>"
                                        data-kgmax="<?php echo htmlspecialchars((string)($c['calc_mg_per_kg_max'] ?? '')); ?>"
                                        data-interval="<?php echo htmlspecialchars((string)($c['calc_interval_hours'] ?? '')); ?>"
                                        data-strength="<?php echo htmlspecialchars($c['strength_text']); ?>"
                                        data-name="<?php echo htmlspecialchars($c['drug_name']); ?>">
                                        <?php echo htmlspecialchars($c['drug_name']); ?>
                                        (<?php echo htmlspecialchars(mmgml_format_mg($c['mg_per_ml'])); ?> mg/mL)
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if (empty($active_catalog)): ?>
                                <div class="form-text text-danger">ยังไม่มีรายการยา — เปิดแท็บ <b>ตั้งค่ารายการยา</b></div>
                                <?php endif; ?>
                            </div>
                            <div class="small text-muted mb-2" id="mmcDrugMeta">เลือกยาเพื่อดูความเข้มข้น</div>
                            <div class="row g-2">
                                <div class="col-sm-4">
                                    <label class="form-label small fw-bold">ขนาดยา (mg) / ครั้ง</label>
                                    <input type="number" id="mmc_mg" class="form-control mmc-input-yellow" min="0" step="0.01" placeholder="เช่น 70">
                                </div>
                                <div class="col-sm-4">
                                    <label class="form-label small fw-bold">ปริมาตร (mL) / ครั้ง</label>
                                    <input type="number" id="mmc_ml" class="form-control mmc-input-yellow" min="0" step="0.001" placeholder="เช่น 0.28">
                                </div>
                                <div class="col-sm-4">
                                    <label class="form-label small fw-bold">ช่วงการให้ยา</label>
                                    <select id="mmc_interval" class="form-select">
                                        <option value="">ตามการตั้งค่ายา</option>
                                        <option value="4">ทุก 4 ชั่วโมง (×6 /วัน)</option>
                                        <option value="6">ทุก 6 ชั่วโมง (×4 /วัน)</option>
                                        <option value="8">ทุก 8 ชั่วโมง (×3 /วัน)</option>
                                        <option value="12">ทุก 12 ชั่วโมง (×2 /วัน)</option>
                                        <option value="24">ทุก 24 ชั่วโมง (×1 /วัน)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="small text-muted mt-1" id="mmcKgHint"></div>
                            <div class="row g-2 mt-3">
                                <div class="col-6 col-xl-3">
                                    <div class="mmc-result">
                                        <div class="small text-muted">mg/mL</div>
                                        <div class="val" id="mmcOutConc">—</div>
                                    </div>
                                </div>
                                <div class="col-6 col-xl-3">
                                    <div class="mmc-result mmc-result-green">
                                        <div class="small text-muted">mL / ครั้ง</div>
                                        <div class="val" id="mmcOutMl">—</div>
                                    </div>
                                </div>
                                <div class="col-6 col-xl-3">
                                    <div class="mmc-result mmc-result-blue">
                                        <div class="small text-muted">Amp/vial / ครั้ง</div>
                                        <div class="val" id="mmcOutAmp">—</div>
                                    </div>
                                </div>
                                <div class="col-6 col-xl-3">
                                    <div class="mmc-result mmc-result-blue">
                                        <div class="small text-muted">Amp/vial / วัน</div>
                                        <div class="val" id="mmcOutAmpDay">—</div>
                                    </div>
                                </div>
                            </div>
                            <div class="mmc-method mt-3" id="mmcSuggest">วิธีใช้ที่แนะนำจะแสดงที่นี่</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-list me-1 text-primary"></i> ใบยาตาม HN</span>
                            <span class="badge bg-secondary" id="mmcOrderCount">0</span>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-sm table-hover align-middle mb-0">
                                    <thead class="table-light text-center small">
                                        <tr>
                                            <th>วันที่</th>
                                            <th>OPD/IPD</th>
                                            <th class="text-start">ยา</th>
                                            <th class="text-start">วิธีใช้</th>
                                            <th>mg</th>
                                            <th>mL ระบุ</th>
                                            <th>mL คำนวณ</th>
                                        </tr>
                                    </thead>
                                    <tbody id="mmcOrderTbody">
                                        <tr><td colspan="7" class="text-center text-muted py-4">ค้นหา HN เพื่อดึงใบยา</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="tab-pane fade <?php echo $tab === 'settings' ? 'show active' : ''; ?>" id="mmc-pane-settings" role="tabpanel">
            <div class="alert alert-info py-2 small mb-3">
                รายการยานี้เป็นคลังหลัก — <b>Monitor mg → mL</b> จะดึงรายการที่เปิดใช้งานมาเฝ้าระวัง
            </div>
            <div class="d-flex flex-wrap gap-2 mb-3">
                <form method="post" class="d-inline" onsubmit="return confirm('นำเข้ายาฉีดจากตารางคำนวณเข้าคลังนี้?');">
                    <input type="hidden" name="action" value="import_inject_catalog">
                    <button type="submit" class="btn btn-sm btn-outline-primary fw-bold">
                        <i class="fas fa-file-import me-1"></i> นำเข้ายาฉีดจากตารางคำนวณ
                    </button>
                </form>
                <form method="post" class="d-inline" onsubmit="return confirm('สแกนยาจาก HOSxP/TMT ที่มี strength แบบ mg/mL หรือ mcg/mL?');">
                    <input type="hidden" name="action" value="scan_tmt">
                    <button type="submit" class="btn btn-sm btn-outline-secondary fw-bold">
                        <i class="fas fa-search me-1"></i> สแกนจาก TMT
                    </button>
                </form>
                <a href="monitor_mg_ml.php" class="btn btn-sm btn-outline-success">
                    เปิด Monitor mg → mL
                </a>
            </div>
            <div class="row g-4">
                <div class="col-lg-5">
                    <div class="card shadow-sm border-0" id="mmcFormCard">
                        <div class="card-header text-white fw-bold" style="background:#0d6efd;">
                            <i class="fas fa-plus-circle me-1"></i> <span id="mmcFormTitle">เพิ่มรายการยา</span>
                        </div>
                        <div class="card-body">
                            <form method="post" id="mmcItemForm">
                                <input type="hidden" name="action" id="mmc_action" value="add_item">
                                <input type="hidden" name="rule_id" id="mmc_rule_id" value="">
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">ยา (HOSxP)</label>
                                    <select name="drug" id="mmc_item_drug" class="form-select form-select-sm" required>
                                        <option value="">ค้นหายา...</option>
                                    </select>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">Strength (อ้างอิง)</label>
                                    <input type="text" name="strength_text" id="mmc_strength_text" class="form-control form-control-sm"
                                        placeholder="เช่น 250 mg/mL หรือ 1000 mg/4 mL">
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">ความเข้มข้น mg/mL <span class="text-danger">*</span></label>
                                    <div class="input-group input-group-sm">
                                        <input type="number" name="mg_per_ml" id="mmc_mg_per_ml" class="form-control" min="0" step="0.000001" required placeholder="เช่น 250">
                                        <button type="button" class="btn btn-outline-secondary" id="mmcBtnParse">Parse</button>
                                    </div>
                                    <div class="form-text">Cloxacillin 1 GM ละลาย 4 mL → ใส่ 250</div>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">mg ต่อ Amp / vial (ไม่บังคับ)</label>
                                    <input type="number" name="mg_per_amp" id="mmc_mg_per_amp" class="form-control form-control-sm" min="0" step="0.01" placeholder="เช่น 250">
                                </div>
                                <div class="row g-2 mb-2">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">mg/kg ต่ำสุด</label>
                                        <input type="number" name="calc_mg_per_kg_min" id="mmc_kg_min" class="form-control form-control-sm" min="0" step="0.01" placeholder="เช่น 5">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">mg/kg สูงสุด</label>
                                        <input type="number" name="calc_mg_per_kg_max" id="mmc_kg_max" class="form-control form-control-sm" min="0" step="0.01" placeholder="เช่น 10">
                                    </div>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">ช่วงการให้ยา</label>
                                    <select name="calc_interval_hours" id="mmc_item_interval" class="form-select form-select-sm">
                                        <option value="">— ไม่ระบุ —</option>
                                        <option value="4">ทุก 4 ชั่วโมง (×6 /วัน)</option>
                                        <option value="6">ทุก 6 ชั่วโมง (×4 /วัน)</option>
                                        <option value="8">ทุก 8 ชั่วโมง (×3 /วัน)</option>
                                        <option value="12">ทุก 12 ชั่วโมง (×2 /วัน)</option>
                                        <option value="24">ทุก 24 ชั่วโมง (×1 /วัน)</option>
                                    </select>
                                    <div class="form-text">ใช้คูณจำนวนครั้ง/วัน เพื่อคิด Amp/vial ต่อวัน เช่น ทุก 6 ชม. = ×4</div>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small fw-bold">หมายเหตุ</label>
                                    <textarea name="detail_text" id="mmc_detail_text" class="form-control form-control-sm" rows="2"
                                        placeholder="เช่น ละลาย 4 mL NS → 250 mg/mL"></textarea>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" name="active" id="mmc_active" checked>
                                    <label class="form-check-label small" for="mmc_active">เปิดใช้งาน</label>
                                </div>
                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-sm text-white fw-bold" style="background:#0d6efd;">
                                        <i class="fas fa-save me-1"></i> บันทึก
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" id="mmcBtnReset">ล้างฟอร์ม</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-list me-1"></i>รายการยา (<?php echo count($all_rules); ?>)</h6>
                    <div class="mb-2">
                        <input type="text" id="mmcRuleSearch" class="form-control form-control-sm" placeholder="ค้นหายา / icode...">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover border align-middle">
                            <thead class="table-light text-center small">
                                <tr>
                                    <th>ยา</th><th>icode</th><th>mg/mL</th><th>mg/kg</th><th>ช่วงให้</th><th>Amp</th><th>เปิด</th><th>จัดการ</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (empty($all_rules)): ?>
                                <tr><td colspan="8" class="text-center text-muted py-3">ยังไม่มีรายการ — เพิ่มยาหรือนำเข้าจากตารางคำนวณ</td></tr>
                            <?php else: foreach ($all_rules as $r):
                                $rule_json = htmlspecialchars(json_encode([
                                    'id' => (int)$r['id'],
                                    'icode' => $r['icode'],
                                    'drug_name' => $r['drug_name'],
                                    'strength_text' => $r['strength_text'] ?? '',
                                    'mg_per_ml' => (float)($r['mg_per_ml'] ?? 0),
                                    'mg_per_amp' => isset($r['mg_per_amp']) && $r['mg_per_amp'] !== '' && $r['mg_per_amp'] !== null ? (float)$r['mg_per_amp'] : null,
                                    'calc_mg_per_kg_min' => isset($r['calc_mg_per_kg_min']) && $r['calc_mg_per_kg_min'] !== '' && $r['calc_mg_per_kg_min'] !== null ? (float)$r['calc_mg_per_kg_min'] : null,
                                    'calc_mg_per_kg_max' => isset($r['calc_mg_per_kg_max']) && $r['calc_mg_per_kg_max'] !== '' && $r['calc_mg_per_kg_max'] !== null ? (float)$r['calc_mg_per_kg_max'] : null,
                                    'calc_interval_hours' => isset($r['calc_interval_hours']) && $r['calc_interval_hours'] !== '' && $r['calc_interval_hours'] !== null ? (float)$r['calc_interval_hours'] : null,
                                    'detail_text' => $r['detail_text'] ?? '',
                                    'active' => (int)!empty($r['active']),
                                ], JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
                            ?>
                                <tr class="mmc-rule-row" data-rule-id="<?php echo (int)$r['id']; ?>">
                                    <td class="small"><b><?php echo htmlspecialchars($r['drug_name']); ?></b>
                                        <?php if (!empty($r['strength_text'])): ?>
                                        <br><span class="text-muted"><?php echo htmlspecialchars($r['strength_text']); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center small"><?php echo htmlspecialchars($r['icode']); ?></td>
                                    <td class="text-center fw-bold"><?php echo htmlspecialchars(mmgml_format_mg($r['mg_per_ml'])); ?></td>
                                    <td class="text-center small"><?php echo htmlspecialchars(mmgml_format_kg_range($r['calc_mg_per_kg_min'] ?? null, $r['calc_mg_per_kg_max'] ?? null)); ?></td>
                                    <td class="text-center small"><?php echo htmlspecialchars(mmgml_format_interval_label($r['calc_interval_hours'] ?? 0)); ?></td>
                                    <td class="text-center small"><?php echo !empty($r['mg_per_amp']) ? htmlspecialchars(mmgml_format_mg($r['mg_per_amp'])) : '—'; ?></td>
                                    <td class="text-center"><?php echo !empty($r['active']) ? '<span class="badge bg-success">เปิด</span>' : '<span class="badge bg-secondary">ปิด</span>'; ?></td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-sm btn-outline-primary mmc-btn-edit" data-rule="<?php echo $rule_json; ?>">แก้ไข</button>
                                        <form method="post" class="d-inline" onsubmit="return confirm('ลบรายการนี้?');">
                                            <input type="hidden" name="action" value="delete_item">
                                            <input type="hidden" name="rule_id" value="<?php echo (int)$r['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">ลบ</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/mg_ml_calculator.js?v=20260814c"></script>
</body>
</html>
