<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    if (($_GET['action'] ?? '') === 'photo') {
        exit;
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/patient_ipd_helper.php';
if (empty($_SESSION['menu_permissions_loaded']) && isset($con)) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
$pip_blob_actions = ['photo', 'drug_viewer_image'];
if (!tham_menu_can('pharm_care.patient_ipd') && ($_SESSION['role'] ?? '') !== 'admin') {
    if (in_array(($_GET['action'] ?? ''), $pip_blob_actions, true)) {
        http_response_code(403);
        exit;
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
    exit;
}

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? ''));
$hn = trim((string)($_GET['hn'] ?? $_POST['hn'] ?? ''));
$an = trim((string)($_GET['an'] ?? $_POST['an'] ?? ''));
$prefer = strtolower(trim((string)($_GET['prefer'] ?? $_POST['prefer'] ?? '')));
$order_no = trim((string)($_GET['order_no'] ?? $_POST['order_no'] ?? ''));

// application/json ไม่เข้า $_POST — อ่านจาก body ก่อน
$json_body = null;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $raw = file_get_contents('php://input');
    $decoded = json_decode((string)$raw, true);
    if (is_array($decoded)) {
        $json_body = $decoded;
        if ($action === '') {
            $action = trim((string)($decoded['action'] ?? ''));
        }
        if ($an === '') {
            $an = trim((string)($decoded['an'] ?? ''));
        }
        if ($hn === '') {
            $hn = trim((string)($decoded['hn'] ?? ''));
        }
        if ($order_no === '') {
            $order_no = trim((string)($decoded['order_no'] ?? ''));
        }
    }
}
if ($action === '') {
    $action = 'lookup';
}

if ($action === 'dispense_save' || $action === 'dispense_cancel') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($action === 'dispense_save') {
        echo json_encode(pip_save_dispense($con, $an, $order_no, $hn), JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(pip_cancel_dispense($con, $an, $order_no), JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'rx_note_save') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $payload = is_array($json_body) ? $json_body : $_POST;
    if ($an === '') {
        $an = trim((string)($payload['an'] ?? ''));
    }
    if ($order_no === '') {
        $order_no = trim((string)($payload['order_no'] ?? ''));
    }
    if ($hn === '') {
        $hn = trim((string)($payload['hn'] ?? ''));
    }
    $note = (string)($payload['rx_note'] ?? $payload['note'] ?? '');
    $mode = (string)($payload['rx_note_mode'] ?? $payload['alert_mode'] ?? 'note');
    echo json_encode(pip_save_rx_note($con, $an, $order_no, $note, $mode, $hn), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'settings_get') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok' => true,
        'settings' => pip_load_day_ahead_settings($con),
        'lab_settings' => pip_load_lab_settings($con),
        'alert_pharma' => pip_load_alert_pharma_settings($con),
        'alert_pharma_modules' => pip_alert_pharma_available_modules($con),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'settings_save') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $payload = is_array($json_body) ? $json_body : $_POST;
    $settings = isset($payload['settings']) && is_array($payload['settings'])
        ? $payload['settings']
        : $payload;
    $user = (string)($_SESSION['username'] ?? $_SESSION['full_name'] ?? '');
    $dayRes = pip_save_day_ahead_settings($con, $settings, $user);
    if (empty($dayRes['ok'])) {
        echo json_encode($dayRes, JSON_UNESCAPED_UNICODE);
        exit;
    }
    $labPayload = isset($payload['lab_settings']) && is_array($payload['lab_settings'])
        ? $payload['lab_settings']
        : null;
    $labSettings = pip_load_lab_settings($con);
    if ($labPayload !== null) {
        $labRes = pip_save_lab_settings($con, $labPayload, $user);
        if (empty($labRes['ok'])) {
            echo json_encode($labRes, JSON_UNESCAPED_UNICODE);
            exit;
        }
        $labSettings = $labRes['lab_settings'];
    }
    $apPayload = isset($payload['alert_pharma']) && is_array($payload['alert_pharma'])
        ? $payload['alert_pharma']
        : null;
    $apSettings = pip_load_alert_pharma_settings($con);
    $apModules = pip_alert_pharma_available_modules($con);
    if ($apPayload !== null) {
        $apRes = pip_save_alert_pharma_settings($con, $apPayload, $user);
        if (empty($apRes['ok'])) {
            echo json_encode($apRes, JSON_UNESCAPED_UNICODE);
            exit;
        }
        $apSettings = $apRes['settings'];
        $apModules = $apRes['available_modules'] ?? $apModules;
    }
    echo json_encode([
        'ok' => true,
        'settings' => $dayRes['settings'],
        'lab_settings' => $labSettings,
        'alert_pharma' => $apSettings,
        'alert_pharma_modules' => $apModules,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'alert_pharma_screen') {
    header('Content-Type: application/json; charset=utf-8');
    if ($hn === '') {
        echo json_encode(['ok' => false, 'error' => 'กรุณาระบุ HN', 'has_alert' => false, 'alerts' => []], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $result = pip_run_alert_pharma_screen($con, $hn, $an);
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'order_cols_get') {
    header('Content-Type: application/json; charset=utf-8');
    $uid = (int)($_SESSION['user_id'] ?? 0);
    echo json_encode([
        'ok' => true,
        'widths' => pip_load_order_col_widths($con, $uid),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'order_cols_save') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $payload = is_array($json_body) ? $json_body : $_POST;
    $widths = isset($payload['widths']) && is_array($payload['widths']) ? $payload['widths'] : [];
    $uid = (int)($_SESSION['user_id'] ?? 0);
    $by = (string)($_SESSION['username'] ?? $_SESSION['full_name'] ?? '');
    echo json_encode(pip_save_order_col_widths($con, $uid, $widths, $by), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'med_cols_get') {
    header('Content-Type: application/json; charset=utf-8');
    $uid = (int)($_SESSION['user_id'] ?? 0);
    echo json_encode([
        'ok' => true,
        'widths' => pip_load_med_col_widths($con, $uid),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'med_cols_save') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $payload = is_array($json_body) ? $json_body : $_POST;
    $widths = isset($payload['widths']) && is_array($payload['widths']) ? $payload['widths'] : [];
    $uid = (int)($_SESSION['user_id'] ?? 0);
    $by = (string)($_SESSION['username'] ?? $_SESSION['full_name'] ?? '');
    echo json_encode(pip_save_med_col_widths($con, $uid, $widths, $by), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'layout_save') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $payload = is_array($json_body) ? $json_body : $_POST;
    $layout = isset($payload['layout']) && is_array($payload['layout']) ? $payload['layout'] : $payload;
    $uid = (int)($_SESSION['user_id'] ?? 0);
    $by = (string)($_SESSION['username'] ?? $_SESSION['full_name'] ?? '');
    echo json_encode(pip_save_layout($con, $uid, $layout, $by), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'drug_viewer_ui_get') {
    header('Content-Type: application/json; charset=utf-8');
    $uid = (int)($_SESSION['user_id'] ?? 0);
    echo json_encode([
        'ok' => true,
        'ui' => pip_load_drug_viewer_ui($con, $uid),
        'user_id' => $uid,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'drug_viewer_ui_save') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $payload = is_array($json_body) ? $json_body : $_POST;
    $ui = isset($payload['ui']) && is_array($payload['ui']) ? $payload['ui'] : $payload;
    $uid = (int)($_SESSION['user_id'] ?? 0);
    $by = (string)($_SESSION['username'] ?? $_SESSION['full_name'] ?? '');
    echo json_encode(pip_save_drug_viewer_ui($con, $uid, $ui, $by), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'robot_drugs_list') {
    header('Content-Type: application/json; charset=utf-8');
    $q = trim((string)($_GET['q'] ?? $_POST['q'] ?? ''));
    if (is_array($json_body) && isset($json_body['q'])) {
        $q = trim((string)$json_body['q']);
    }
    $items = pip_list_robot_drugs($con, $q);
    echo json_encode([
        'ok' => true,
        'count' => pip_robot_drugs_count($con),
        'items' => $items,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'robot_drugs_seed') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $payload = is_array($json_body) ? $json_body : $_POST;
    $replace = !empty($payload['replace']);
    $by = (string)($_SESSION['username'] ?? $_SESSION['full_name'] ?? '');
    $hos = pop_connect($con);
    if (!$hos) {
        echo json_encode(['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $res = pip_seed_robot_drugs($con, $hos, $by, $replace);
    mysqli_close($hos);
    echo json_encode($res, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'robot_drugs_add') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $payload = is_array($json_body) ? $json_body : $_POST;
    $icode = trim((string)($payload['icode'] ?? ''));
    $by = (string)($_SESSION['username'] ?? $_SESSION['full_name'] ?? '');
    $hos = pop_connect($con);
    $res = pip_add_robot_drug($con, $hos, $icode, $by);
    if ($hos) {
        mysqli_close($hos);
    }
    echo json_encode($res, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'robot_drugs_remove') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $payload = is_array($json_body) ? $json_body : $_POST;
    $icode = trim((string)($payload['icode'] ?? ''));
    $by = (string)($_SESSION['username'] ?? $_SESSION['full_name'] ?? '');
    echo json_encode(pip_remove_robot_drug($con, $icode, $by), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'robot_drugs_search') {
    header('Content-Type: application/json; charset=utf-8');
    $q = trim((string)($_GET['q'] ?? $_POST['q'] ?? ''));
    if (is_array($json_body) && isset($json_body['q'])) {
        $q = trim((string)$json_body['q']);
    }
    $hos = pop_connect($con);
    if (!$hos) {
        echo json_encode(['ok' => false, 'error' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้', 'items' => []], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $items = pip_search_hosxp_drugs_for_robot($hos, $q, 40);
    mysqli_close($hos);
    echo json_encode(['ok' => true, 'items' => $items], JSON_UNESCAPED_UNICODE);
    exit;
}

session_write_close();

if ($action === 'photo') {
    if ($hn === '') {
        http_response_code(404);
        exit;
    }
    $blob = pop_fetch_photo_any($con, $hn);
    if ($blob === null || $blob === '') {
        http_response_code(404);
        exit;
    }
    $mime = pop_photo_mime($blob);
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . strlen($blob));
    header('Cache-Control: private, max-age=300');
    header('X-Content-Type-Options: nosniff');
    echo $blob;
    exit;
}

if ($action === 'drug_viewer_scans') {
    require_once __DIR__ . '/drug_viewer_helper.php';
    header('Content-Type: application/json; charset=utf-8');
    $limit = (int)($_GET['limit'] ?? $_POST['limit'] ?? ($json_body['limit'] ?? 80));
    $res = drug_viewer_list_scans($con, $hn, $an, $limit);
    echo json_encode([
        'ok' => !empty($res['ok']),
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['error'] ?? '',
        'count' => (int)($res['count'] ?? 0),
        'items' => $res['items'] ?? [],
        'hn' => $hn,
        'an' => $an,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'drug_viewer_image') {
    require_once __DIR__ . '/drug_viewer_helper.php';
    $scan_id = (int)($_GET['id'] ?? $_POST['id'] ?? ($json_body['id'] ?? 0));
    $res = drug_viewer_get_scan_blob($con, $scan_id);
    if (empty($res['ok'])) {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        echo $res['error'] ?? 'ไม่พบไฟล์';
        exit;
    }
    header('Content-Type: ' . $res['mime']);
    header('Content-Length: ' . strlen($res['blob']));
    header('Content-Disposition: inline; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $res['filename']) . '"');
    header('Cache-Control: private, max-age=120');
    header('X-Content-Type-Options: nosniff');
    echo $res['blob'];
    exit;
}

header('Content-Type: application/json; charset=utf-8');

if ($action === 'order_items') {
    echo json_encode(pip_order_detail($con, $an, $order_no), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_bw' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_once __DIR__ . '/dose_calculator_helper.php';
    $payload = is_array($json_body) ? $json_body : $_POST;
    $payload['hn'] = trim((string)($payload['hn'] ?? $hn));
    $payload['user_id'] = (int)($_SESSION['user_id'] ?? 0);
    $payload['user_name'] = (string)($_SESSION['full_name'] ?? '');
    $payload['source_module'] = trim((string)($payload['source_module'] ?? 'patient_ipd_crcl'));
    $res = dc_save_vitals_bw($con, $payload);
    if (empty($res['ok'])) {
        echo json_encode(['ok' => false, 'error' => $res['error'] ?? 'บันทึกน้ำหนักไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'ok' => true,
        'message' => $res['message'] ?? 'บันทึกแล้ว',
        'bw' => $res['bw'] ?? null,
        'source' => $res['source'] ?? 'tham',
        'source_label' => $res['source_label'] ?? 'THAM',
        'updated_at' => $res['updated_at'] ?? date('Y-m-d H:i:s'),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(pip_lookup($con, $hn, $an, $prefer), JSON_UNESCAPED_UNICODE);
