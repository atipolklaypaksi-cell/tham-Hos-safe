<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor Sepsis by culture — ผลเพาะเลือด</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: #e8f1ec; }
        #content.msc-content {
            background:
                radial-gradient(1000px 380px at 100% -8%, rgba(185,28,28,.10), transparent 55%),
                #e8f1ec;
            min-height: 100vh;
        }
        .msc-hero { display: flex; justify-content: space-between; align-items: flex-end; gap: 16px; flex-wrap: wrap; margin-bottom: 16px; }
        .msc-kicker {
            display: inline-flex; align-items: center; gap: 8px;
            font-size: .75rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase;
            color: #991b1b; background: rgba(220,38,38,.12); border: 1px solid rgba(153,27,27,.15);
            border-radius: 999px; padding: 4px 10px; margin-bottom: 8px;
        }
        .msc-title { font-size: 1.45rem; font-weight: 800; color: #12261c; margin: 0; }
        .msc-sub { color: #5f7468; font-size: .9rem; margin: .2rem 0 0; }
        .msc-panel {
            background: #fff; border: 1px solid #d7e4dc; border-radius: 14px;
            padding: 1rem 1.1rem; box-shadow: 0 8px 24px rgba(18,38,28,.04);
        }
        .msc-kpi { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 10px; margin-bottom: 14px; }
        .msc-kpi-card { background: #fff; border: 1px solid #d7e4dc; border-radius: 12px; padding: .85rem 1rem; }
        .msc-kpi-card .lbl { font-size: .75rem; color: #5f7468; font-weight: 700; }
        .msc-kpi-card .num { font-size: 1.7rem; font-weight: 800; line-height: 1.1; color: #12261c; }
        .msc-kpi-card .hint { font-size: .72rem; color: #7a8c84; margin-top: 4px; }
        .msc-kpi-card.is-alert { border-color: #fecaca; background: #fff7f7; }
        .msc-kpi-card.is-alert .num { color: #dc2626; }
        .msc-kpi-card.is-ok { border-color: #bbf7d0; background: #f0fdf4; }
        .msc-kpi-card.is-ok .num { color: #166534; }
        .msc-kpi-card.is-warn { border-color: #fde68a; background: #fffbeb; }
        .msc-kpi-card.is-warn .num { color: #b45309; }
        .msc-table { font-size: .82rem; margin: 0; }
        .msc-table thead th {
            background: #f6faf8; color: #146c4a; font-weight: 700; white-space: nowrap;
            border-bottom: 1px solid #d7e4dc; position: sticky; top: 0; z-index: 1;
        }
        .msc-table tbody tr.st-none td { background: #fef2f2; }
        .msc-table tbody tr.st-off td { background: #fffbeb; }
        .msc-table tbody tr.st-uncover td { background: #fef2f2; }
        .table-scroll { max-height: 62vh; overflow: auto; }
        .msc-toolbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
        .msc-status { font-size: .82rem; color: #5f7468; }
        .msc-status.is-error { color: #b91c1c; }
        .badge-none { background: #dc2626; color: #fff; font-weight: 800; }
        .badge-off { background: #d97706; color: #fff; font-weight: 800; }
        .badge-now { background: #16a34a; color: #fff; font-weight: 800; }
        .badge-res { background: #fee2e2; color: #991b1b; font-weight: 800; }
        .badge-sens { background: #e8f0ec; color: #4b6358; font-weight: 800; }
        .badge-r { background: #dc2626; color: #fff; font-weight: 800; }
        .badge-s { background: #16a34a; color: #fff; font-weight: 800; }
        .badge-i { background: #eab308; color: #1c1917; font-weight: 800; }
        .badge-cover { background: #16a34a; color: #fff; font-weight: 800; }
        .badge-gap { background: #dc2626; color: #fff; font-weight: 800; }
        .badge-gram { font-size: .65rem; display: block; font-weight: 700; opacity: .85; margin-top: 2px; }
        .msc-suggest { font-size: .72rem; color: #9a3412; font-weight: 700; margin-top: 4px; line-height: 1.35; max-width: 220px; }
        .msc-suggest .lbl { font-weight: 800; color: #7c2d12; }
        .msc-cfg-table { font-size: .78rem; }
        .msc-cfg-table th { white-space: nowrap; }
        .msc-cfg-table th.msc-cfg-alias { white-space: normal; min-width: 220px; }
        .msc-cfg-table input.form-control { font-size: .78rem; min-width: 110px; }
        .msc-cfg-table input[data-k="aliases"] { min-width: 200px; }
        .msc-cfg-note { background: #f4f8f6; border: 1px solid #d7e4dc; border-radius: 8px; padding: .55rem .75rem; }
        .msc-tabs .nav-link { font-size: .82rem; font-weight: 700; color: #5f7468; }
        .msc-tabs .nav-link.active { color: #991b1b; }
        .msc-empty { color: #7a8c84; text-align: center; padding: 1.6rem .5rem; }
        .msc-drugs { font-size: .78rem; line-height: 1.35; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content msc-content">
        <div class="container-fluid py-3">
            <div class="msc-hero">
                <div>
                    <div class="msc-kicker"><i class="fas fa-tint"></i> AMR · Sepsis by culture</div>
                    <h1 class="msc-title">Monitor Sepsis by culture</h1>
                    <p class="msc-sub">ผลเพาะ<strong>เลือด</strong>ที่พบเชื้อ (ดื้อยาและไม่ดื้อยา) — ตรวจว่าผู้ป่วยได้ยาปฏิชีวนะแล้วหรือยัง</p>
                </div>
                <div class="msc-toolbar">
                    <select id="mscLookback" class="form-select form-select-sm" style="width:auto;">
                        <option value="1d">1 วัน</option>
                        <option value="3d">3 วัน</option>
                        <option value="7d" selected>7 วัน</option>
                        <option value="14d">14 วัน</option>
                    </select>
                    <label class="small mb-0 d-flex align-items-center gap-1">
                        <input type="checkbox" id="mscIpdOnly" checked>
                        เฉพาะ IPD ที่ยัง admit
                    </label>
                    <input type="search" id="mscQ" class="form-control form-control-sm" placeholder="ค้นหา HN / ชื่อ / หอ / เชื้อ" style="min-width:200px;">
                    <button type="button" class="btn btn-outline-danger btn-sm" id="mscCfgBtn">
                        <i class="fas fa-sliders-h me-1"></i>ตั้งค่าความครอบคลุม
                    </button>
                    <button type="button" class="btn btn-danger btn-sm" id="mscReload">
                        <i class="fas fa-sync-alt me-1"></i>โหลดใหม่
                    </button>
                </div>
            </div>

            <div class="msc-kpi">
                <div class="msc-kpi-card">
                    <div class="lbl">เพาะเลือดพบเชื้อ</div>
                    <div class="num" id="kpiBlood">—</div>
                    <div class="hint" id="kpiBloodHint">ในช่วงที่เลือก</div>
                </div>
                <div class="msc-kpi-card is-alert">
                    <div class="lbl">ยังไม่ได้ยา</div>
                    <div class="num" id="kpiNone">—</div>
                    <div class="hint">ไม่มี ATB ทั้งช่วง admit / วันนี้</div>
                </div>
                <div class="msc-kpi-card is-warn">
                    <div class="lbl">วันนี้ไม่มียา</div>
                    <div class="num" id="kpiOff">—</div>
                    <div class="hint">ไม่มีใบจ่าย ATB วันนี้ และไม่มี medplan ที่ยังใช้</div>
                </div>
                <div class="msc-kpi-card is-ok">
                    <div class="lbl">กำลังได้ยา</div>
                    <div class="num" id="kpiNow">—</div>
                    <div class="hint">จ่ายวันนี้ หรือ medplan ที่ยังไม่ถึงวันหยุดยา</div>
                </div>
                <div class="msc-kpi-card">
                    <div class="lbl">เชื้อดื้อยา</div>
                    <div class="num" id="kpiRes">—</div>
                    <div class="hint">มี phenotype เช่น ESBL / CRE</div>
                </div>
            </div>

            <div class="msc-panel mb-3" id="mscCfgBox" style="display:none;">
                <h2 class="h6 fw-bold mb-1">ตารางความครอบคลุม ATB ตาม Gram / สกุลเชื้อ</h2>
                <p class="small text-muted mb-2">
                    ใช้เมื่อยังไม่มีผล AST — ทั้งผล Gram stain และชื่อสกุลตามมาตรฐาน
                    (เช่น Enterococcus species, Staphylococcus species, Bacillus)
                    ค่าเริ่มต้นอิง Sanford / IDSA สำหรับ bacteremia:
                    cephalosporin <b>ไม่ครอบคลุม Enterococcus</b> เพราะดื้อโดยกำเนิด
                </p>
                <div class="msc-cfg-note small mb-2">
                    <b>นามแฝงเทียบกับชื่อยาจาก TMT เป็นหลัก</b>
                    ระบบดึง <code>tmt_tpu_code.active_ingredient</code> (เช่น Vancomycin, Ceftriaxone)
                    จากรหัส TPU ที่ผูกในรายการยา HOSxP แล้วจับคู่กับชื่อยาและนามแฝงในตารางนี้
                    — ใช้ชื่อสามัญตาม TMT จะขยายไป รพ.อื่นได้โดยไม่ต้องตามชื่อการค้าในแต่ละที่
                    ถ้ายังไม่ผูก TMT จะเทียบชื่อใน HOSxP (<code>drugitems.name</code>) เป็นสำรอง จึงยังใส่ชื่อยี่ห้อได้
                </div>
                <div class="table-responsive">
                    <table class="table table-sm table-bordered msc-cfg-table mb-2">
                        <thead>
                            <tr>
                                <th>ยาปฏิชีวนะ</th>
                                <th class="msc-cfg-alias">นามแฝง / ชื่อในระบบ
                                    <div class="small fw-normal text-muted">เทียบชื่อ TMT (สำรองชื่อ HOSxP)</div>
                                </th>
                                <th class="text-center">GPC cluster</th>
                                <th class="text-center">GPC คู่/สาย</th>
                                <th class="text-center">Enterococcus</th>
                                <th class="text-center">GPB</th>
                                <th class="text-center">GNB</th>
                                <th class="text-center">GNC</th>
                                <th class="text-center">Yeast</th>
                                <th class="text-center">ใช้</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="mscCfgBody"></tbody>
                    </table>
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="mscCfgAdd">
                        <i class="fas fa-plus me-1"></i>เพิ่มยา
                    </button>
                    <button type="button" class="btn btn-success btn-sm" id="mscCfgSave">
                        <i class="fas fa-save me-1"></i>บันทึก
                    </button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="mscCfgReset">คืนค่ามาตรฐาน</button>
                    <span class="small text-muted align-self-center" id="mscCfgHint"></span>
                </div>
            </div>

            <div class="msc-panel">
                <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
                    <ul class="nav nav-pills msc-tabs" id="mscTabs">
                        <li class="nav-item">
                            <button type="button" class="nav-link" data-tab="gap">ต้องติดตาม <span class="badge badge-none" id="tabGap">0</span></button>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="nav-link" data-tab="none">ยังไม่ได้ยา <span class="badge badge-none" id="tabNone">0</span></button>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="nav-link" data-tab="off">วันนี้ไม่มียา <span class="badge badge-off" id="tabOff">0</span></button>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="nav-link" data-tab="now">กำลังได้ยา <span class="badge badge-now" id="tabNow">0</span></button>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="nav-link" data-tab="uncover">ยาไม่ครอบคลุม <span class="badge badge-none" id="tabUncover">0</span></button>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="nav-link active" data-tab="all">ทั้งหมด <span class="badge bg-secondary" id="tabAll">0</span></button>
                        </li>
                    </ul>
                    <span class="msc-status" id="mscStatus">กำลังโหลด...</span>
                </div>
                <div class="table-scroll">
                    <table class="table table-sm msc-table">
                        <thead>
                            <tr>
                                <th>วันที่รายงาน</th>
                                <th>หอผู้ป่วย</th>
                                <th>HN</th>
                                <th>AN</th>
                                <th>ชื่อ-สกุล</th>
                                <th>ชนิด</th>
                                <th>เชื้อ</th>
                                <th>ผลดื้อยา</th>
                                <th>สถานะยา</th>
                                <th>ยาปฏิชีวนะวันนี้</th>
                                <th title="ผล AST เมื่อ identify แล้ว หรือ screen ตาม Gram เมื่อยังไม่มีชื่อเชื้อ">เทียบยา</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="mscBody">
                            <tr><td colspan="12" class="msc-empty">กำลังโหลด</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const MSC_API = 'fetch_monitor_sepsis_culture_api.php';
let lastRows = [];
let lastMeta = {};
let activeTab = 'all';

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function setStatus(msg, isError) {
    const el = document.getElementById('mscStatus');
    el.textContent = msg;
    el.classList.toggle('is-error', !!isError);
}

function ipdOnly() {
    return document.getElementById('mscIpdOnly').checked;
}

function filteredBase() {
    const q = (document.getElementById('mscQ').value || '').trim().toLowerCase();
    return lastRows.filter(function (r) {
        if (ipdOnly() && !r.inpatient) return false;
        if (!q) return true;
        return [r.hn, r.an, r.ptname, r.ward, r.microtype, r.result, (r.atb_now || []).join(' '), (r.atb_suggest || []).join(' ')]
            .join(' ').toLowerCase().indexOf(q) !== -1;
    });
}

function isUncovered(r) {
    if (r.cover_mode === 'ast' && r.atb_cover === 'R') return true;
    if (r.cover_mode === 'gram' && r.atb_screen === 'gap') return true;
    return false;
}

function rowsForTab(tab) {
    const rows = filteredBase();
    if (tab === 'none') return rows.filter(r => r.atb_status === 'none');
    if (tab === 'off') return rows.filter(r => r.atb_status === 'off');
    if (tab === 'now') return rows.filter(r => r.atb_status === 'now');
    if (tab === 'gap') return rows.filter(r => r.atb_status !== 'now');
    if (tab === 'uncover') return rows.filter(isUncovered);
    return rows;
}

function statusBadge(st) {
    if (st === 'now') return '<span class="badge badge-now">กำลังได้ยา</span>';
    if (st === 'off') return '<span class="badge badge-off">วันนี้ไม่มียา</span>';
    return '<span class="badge badge-none">ยังไม่ได้ยา</span>';
}

const GRAM_GROUP_LABEL = {
    gpc_cluster: 'GPC cluster / Staph',
    gpc_chain: 'GPC คู่/สาย / Strep',
    enterococcus: 'Enterococcus',
    gpb: 'GPB',
    gnb: 'GNB',
    gnc: 'GNC',
    yeast: 'Yeast'
};

function suggestHtml(r) {
    const list = r.atb_suggest || [];
    if (!list.length) return '';
    const src = r.cover_mode === 'ast' ? 'ตาม AST' : 'empiric';
    return '<div class="msc-suggest"><span class="lbl">แนะนำ ' + esc(src) + ':</span> ' + esc(list.join(', ')) + '</div>';
}

function coverBadge(r) {
    if (r.cover_mode === 'ast') {
        const c = r.atb_cover;
        if (c === 'R') {
            return '<span class="badge badge-r">R</span>' + suggestHtml(r);
        }
        if (c === 'I') return '<span class="badge badge-i">I</span>';
        if (c === 'S') return '<span class="badge badge-s">S</span>';
    }
    if (r.cover_mode === 'gram') {
        const g = GRAM_GROUP_LABEL[r.gram_group] || r.gram_group || 'Gram';
        const hit = (r.gram_matched || []).join(', ');
        if (r.atb_screen === 'cover') {
            return '<span class="badge badge-cover" title="' + esc(hit || 'ครอบคลุม ' + g) + '">ครอบคลุม</span>'
                + '<span class="badge-gram text-muted">screen ' + esc(g) + '</span>';
        }
        if (r.atb_screen === 'gap') {
            return '<span class="badge badge-gap" title="ยาวันนี้ไม่ครอบคลุม ' + esc(g) + '">ไม่ครอบคลุม</span>'
                + '<span class="badge-gram text-muted">screen ' + esc(g) + '</span>'
                + suggestHtml(r);
        }
    }
    return '<span class="text-muted">—</span>';
}

function fmtDt(d, t, combined) {
    let x = String(d || '').slice(0, 10);
    let tm = String(t || '');
    const c = String(combined || '');
    const m = c.match(/(\d{4}-\d{2}-\d{2})(?:[ T]+(\S+))?/);
    if (m) {
        if (!x) x = m[1];
        if (!tm) tm = m[2] || '';
    }
    if (!x) return '—';
    const digits = String(tm).replace(/\D/g, '');
    const hh = digits.length >= 4 ? (digits.slice(0, 2) + ':' + digits.slice(2, 4)) : '';
    return esc(x) + (hh ? '<div class="small text-muted">' + esc(hh) + '</div>' : '');
}

function render() {
    const base = filteredBase();
    const none = base.filter(r => r.atb_status === 'none').length;
    const off = base.filter(r => r.atb_status === 'off').length;
    const now = base.filter(r => r.atb_status === 'now').length;
    const res = base.filter(r => r.result).length;
    document.getElementById('kpiBlood').textContent = String(base.length);
    document.getElementById('kpiNone').textContent = String(none);
    document.getElementById('kpiOff').textContent = String(off);
    document.getElementById('kpiNow').textContent = String(now);
    document.getElementById('kpiRes').textContent = String(res);
    document.getElementById('tabGap').textContent = String(none + off);
    document.getElementById('tabNone').textContent = String(none);
    document.getElementById('tabOff').textContent = String(off);
    document.getElementById('tabNow').textContent = String(now);
    document.getElementById('tabUncover').textContent = String(base.filter(isUncovered).length);
    document.getElementById('tabAll').textContent = String(base.length);
    const rows = rowsForTab(activeTab);
    const body = document.getElementById('mscBody');
    if (!rows.length) {
        body.innerHTML = '<tr><td colspan="12" class="msc-empty">ไม่พบรายการตามตัวกรอง</td></tr>';
        return;
    }
    body.innerHTML = rows.map(function (r) {
        const href = 'amr_sensitivity.php?order=' + encodeURIComponent(r.lab_order_number || '')
            + (r.hn ? ('&hn=' + encodeURIComponent(r.hn)) : '');
        const res = r.result
            ? '<span class="badge badge-res">' + esc(r.result) + '</span>'
            : '<span class="badge badge-sens">ไม่ดื้อยา</span>';
        const drugs = (r.atb_now || []).length
            ? '<div class="msc-drugs">' + r.atb_now.map(esc).join('<br>') + '</div>'
            : (r.atb_last_rx ? '<span class="small text-muted">ล่าสุด ' + esc(r.atb_last_rx) + '</span>' : '—');
        const ni = r.Typeinfect === 'NI'
            ? '<span class="badge" style="background:#ffe4ea;color:#be123c;">NI</span>'
            : '<span class="badge" style="background:#d7f6ef;color:#0f766e;">CI</span>';
        const cls = isUncovered(r) ? 'st-uncover' : ('st-' + esc(r.atb_status));
        return '<tr class="' + cls + '">'
            + '<td class="text-nowrap">' + fmtDt(r.report_date, r.report_time, r.reportdatetime) + '</td>'
            + '<td>' + esc(r.ward) + '</td>'
            + '<td class="fw-bold"><a href="' + href + '">' + esc(r.hn) + '</a></td>'
            + '<td>' + esc(r.an) + '</td>'
            + '<td>' + esc(r.ptname) + '</td>'
            + '<td>' + ni + '</td>'
            + '<td class="fw-semibold">' + esc(r.microtype) + '</td>'
            + '<td>' + res + '</td>'
            + '<td>' + statusBadge(r.atb_status) + '</td>'
            + '<td>' + drugs + '</td>'
            + '<td>' + coverBadge(r) + '</td>'
            + '<td><a class="btn btn-sm btn-outline-success py-0 px-2" href="' + href + '">CDSS</a></td>'
            + '</tr>';
    }).join('');
}

async function loadList() {
    setStatus('กำลังโหลดผลเพาะเลือด...');
    try {
        const lb = document.getElementById('mscLookback').value || '7d';
        const res = await fetch(MSC_API + '?action=list&lookback=' + encodeURIComponent(lb), { credentials: 'same-origin' });
        const text = await res.text();
        let data;
        try { data = JSON.parse(text); } catch (e) {
            throw new Error('ตอบกลับไม่ใช่ JSON');
        }
        if (data.status !== 'success') throw new Error(data.message || 'โหลดไม่สำเร็จ');
        lastRows = data.rows || [];
        lastMeta = data.meta || {};
        const src = lastMeta.data_source_label || '';
        const ms = lastMeta.elapsed_ms ? (' · ' + lastMeta.elapsed_ms + ' ms') : '';
        document.getElementById('kpiBloodHint').textContent = (lastMeta.start_date || '') + ' ถึง ' + (lastMeta.end_date || '');
        setStatus('อัปเดตแล้ว · ' + src + ' · ' + lastRows.length + ' lab' + ms);
        render();
    } catch (e) {
        setStatus(e.message || String(e), true);
    }
}

document.querySelectorAll('#mscTabs [data-tab]').forEach(function (btn) {
    btn.addEventListener('click', function () {
        activeTab = btn.getAttribute('data-tab');
        document.querySelectorAll('#mscTabs .nav-link').forEach(el => el.classList.toggle('active', el === btn));
        render();
    });
});
document.getElementById('mscQ').addEventListener('input', render);
document.getElementById('mscIpdOnly').addEventListener('change', render);
document.getElementById('mscLookback').addEventListener('change', loadList);
document.getElementById('mscReload').addEventListener('click', loadList);

let cfgRows = [];
const CFG_KEYS = ['gpc_cluster', 'gpc_chain', 'enterococcus', 'gpb', 'gnb', 'gnc', 'yeast'];

function cfgChk(row, key) {
    return Number(row['cover_' + key] || 0) ? ' checked' : '';
}

function renderCfg() {
    const body = document.getElementById('mscCfgBody');
    if (!cfgRows.length) {
        body.innerHTML = '<tr><td colspan="11" class="text-muted text-center py-3">ยังไม่มีรายการ — กดคืนค่ามาตรฐาน</td></tr>';
        return;
    }
    body.innerHTML = cfgRows.map(function (row, i) {
        const chks = CFG_KEYS.map(function (k) {
            return '<td class="text-center"><input type="checkbox" data-i="' + i + '" data-k="cover_' + k + '"' + cfgChk(row, k) + '></td>';
        }).join('');
        return '<tr>'
            + '<td><input class="form-control form-control-sm" data-i="' + i + '" data-k="drug_name" value="' + esc(row.drug_name || '') + '"></td>'
            + '<td><input class="form-control form-control-sm" data-i="' + i + '" data-k="aliases" placeholder="เช่น Vancomycin, CEFTRIAXONE" title="เทียบกับชื่อ TMT (active_ingredient) เป็นหลัก ถ้าไม่มี TMT จึงเทียบชื่อใน HOSxP" value="' + esc(row.aliases || '') + '"></td>'
            + chks
            + '<td class="text-center"><input type="checkbox" data-i="' + i + '" data-k="is_active"' + (Number(row.is_active) !== 0 ? ' checked' : '') + '></td>'
            + '<td><button type="button" class="btn btn-sm btn-outline-danger py-0 px-1" data-del="' + i + '">ลบ</button></td>'
            + '</tr>';
    }).join('');
}

function readCfgFromDom() {
    document.querySelectorAll('#mscCfgBody [data-i][data-k]').forEach(function (el) {
        const i = Number(el.getAttribute('data-i'));
        const k = el.getAttribute('data-k');
        if (!cfgRows[i]) return;
        if (el.type === 'checkbox') cfgRows[i][k] = el.checked ? 1 : 0;
        else cfgRows[i][k] = el.value;
    });
}

async function loadCfg() {
    const hint = document.getElementById('mscCfgHint');
    hint.textContent = 'กำลังโหลดตาราง...';
    try {
        const res = await fetch(MSC_API + '?action=gram_cover_get', { credentials: 'same-origin' });
        const data = await res.json();
        if (data.status !== 'success') throw new Error(data.message || 'โหลดไม่สำเร็จ');
        cfgRows = data.rows || [];
        renderCfg();
        hint.textContent = cfgRows.length + ' รายการ';
    } catch (e) {
        hint.textContent = e.message || String(e);
    }
}

document.getElementById('mscCfgBtn').addEventListener('click', function () {
    const box = document.getElementById('mscCfgBox');
    const show = box.style.display === 'none';
    box.style.display = show ? '' : 'none';
    if (show) loadCfg();
});
document.getElementById('mscCfgAdd').addEventListener('click', function () {
    readCfgFromDom();
    cfgRows.push({
        drug_name: '', aliases: '',
        cover_gpc_cluster: 0, cover_gpc_chain: 0, cover_enterococcus: 0, cover_gpb: 0,
        cover_gnb: 0, cover_gnc: 0, cover_yeast: 0,
        is_active: 1, sort_order: (cfgRows.length + 1) * 10
    });
    renderCfg();
});
document.getElementById('mscCfgBody').addEventListener('click', function (e) {
    const btn = e.target.closest('[data-del]');
    if (!btn) return;
    readCfgFromDom();
    cfgRows.splice(Number(btn.getAttribute('data-del')), 1);
    renderCfg();
});
document.getElementById('mscCfgSave').addEventListener('click', async function () {
    readCfgFromDom();
    const hint = document.getElementById('mscCfgHint');
    hint.textContent = 'กำลังบันทึก...';
    try {
        const res = await fetch(MSC_API, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'gram_cover_save', rows: cfgRows })
        });
        const data = await res.json();
        if (data.status !== 'success') throw new Error(data.message || 'บันทึกไม่สำเร็จ');
        cfgRows = data.rows || cfgRows;
        renderCfg();
        hint.textContent = data.message || 'บันทึกแล้ว';
        loadList();
    } catch (e) {
        hint.textContent = e.message || String(e);
    }
});
document.getElementById('mscCfgReset').addEventListener('click', async function () {
    if (!confirm('คืนค่าตารางความครอบคลุมเป็นชุดมาตรฐาน? ค่าที่แก้ไว้จะถูกแทนที่')) return;
    const hint = document.getElementById('mscCfgHint');
    hint.textContent = 'กำลังคืนค่า...';
    try {
        const res = await fetch(MSC_API, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'gram_cover_reset' })
        });
        const data = await res.json();
        if (data.status !== 'success') throw new Error(data.message || 'คืนค่าไม่สำเร็จ');
        cfgRows = data.rows || [];
        renderCfg();
        hint.textContent = data.message || 'คืนค่าแล้ว';
        loadList();
    } catch (e) {
        hint.textContent = e.message || String(e);
    }
});

loadList();
</script>
</body>
</html>
