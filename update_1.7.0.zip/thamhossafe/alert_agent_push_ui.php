<?php
/**
 * หลัง Login: ชวนดาวน์โหลด THAM Notify (เครื่อง Windows ที่ยังไม่มีโปรแกรม)
 * ไม่ยิงไฟล์ .exe ให้อัตโนมัติ — ให้ไปหน้าดาวน์โหลดแล้วเปิดเองแบบ SCPH Notify
 */
if (!isset($_SESSION['user_id'])) {
    return;
}
if (!isset($con) || !$con) {
    return;
}
$page = basename((string)($_SERVER['PHP_SELF'] ?? ''));
if (in_array($page, ['login.php', 'logout.php', 'alert_agent_file.php'], true)) {
    return;
}
require_once __DIR__ . '/alert_agent_helper.php';
require_once __DIR__ . '/tham_alert_helper.php';

$latest = tham_alert_agent_latest_file();
$dl = 'alert_agent_file.php?latest=1';
$fname = (string)($latest['name'] ?? 'THAM-Alert-Agent.exe');
$prompt_on = tham_alert_lan_auto_enabled($con);
if (!$prompt_on) {
    return;
}
$ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
$is_windows = stripos($ua, 'Windows') !== false;
$st = tham_alert_this_machine_status($con);
$need_install = $latest && $is_windows && empty($st['installed']);
$show_login_modal = false;
if ($need_install && empty($_SESSION['tham_agent_update_ui'])) {
    $_SESSION['tham_agent_update_ui'] = 1;
    $show_login_modal = true;
}
?>
<style>
#thamAgentUpdateRoot {
    font-family: 'Sarabun', Tahoma, sans-serif;
}
#thamAgentUpdateOverlay {
    position: fixed !important;
    inset: 0 !important;
    z-index: 2147483000 !important;
    background: rgba(15, 36, 25, .45);
    display: none;
    align-items: center;
    justify-content: center;
    padding: 16px;
}
#thamAgentUpdateCard {
    width: 100%;
    max-width: 460px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 18px 50px rgba(15, 36, 25, .28);
    overflow: hidden;
}
#thamAgentUpdateCard .ta-head {
    background: linear-gradient(135deg, #0f766e 0%, #166534 100%);
    color: #fff;
    padding: 18px 20px 16px;
}
#thamAgentUpdateCard .ta-body { padding: 18px 20px 8px; color: #334155; font-size: .95rem; line-height: 1.55; }
#thamAgentUpdateCard .ta-foot { padding: 8px 20px 18px; }
#thamAgentUpdateCard .btn-update {
    background: #0f766e; border: 0; color: #fff; font-weight: 700;
    border-radius: 10px; padding: 10px 16px; width: 100%;
}
#thamAgentUpdateCard .btn-update:hover { background: #115e59; color: #fff; }
#thamAgentUpdateCard .btn-later { color: #64748b; text-decoration: none; font-size: .88rem; }
#thamAgentSilentToast {
    position: fixed !important;
    right: 16px !important;
    bottom: 16px !important;
    z-index: 2147483001 !important;
    max-width: 340px;
    background: #134e4a;
    color: #ecfdf5;
    border-radius: 10px;
    padding: 10px 12px;
    font-size: .82rem;
    box-shadow: 0 8px 20px rgba(15,36,25,.28);
    display: none;
}
#thamAgentSilentToast a { color: #fff; font-weight: 700; }
</style>
<div id="thamAgentUpdateRoot">
    <div id="thamAgentUpdateOverlay" role="dialog" aria-modal="true" aria-labelledby="thamAgentUpdateTitle">
        <div id="thamAgentUpdateCard">
            <div class="ta-head">
                <div style="font-size:.78rem;opacity:.9;letter-spacing:.02em;">THAM Hos-Safe</div>
                <div id="thamAgentUpdateTitle" style="font-size:1.2rem;font-weight:800;margin-top:4px;">ดาวน์โหลด THAM Notify</div>
            </div>
            <div class="ta-body" id="thamAgentUpdateBody">
                โปรแกรมแจ้งเตือนยาบนเครื่องนี้ ใช้แบบเดียวกับ SCPH Notify — เปิดเอง มีหน้าต่าง ไม่ติดตั้งเงียบ
                <div class="small text-muted mt-2 mb-0">ไปหน้าดาวน์โหลด แล้วเปิดไฟล์ THAM Notify จากแถบดาวน์โหลด</div>
            </div>
            <div class="ta-foot">
                <button type="button" class="btn btn-update" id="thamAgentUpdateBtn">ไปหน้าดาวน์โหลด</button>
                <div class="text-center mt-2">
                    <a href="#" class="btn-later" id="thamAgentLaterBtn">ไว้ก่อน</a>
                </div>
            </div>
        </div>
    </div>
    <div id="thamAgentSilentToast"></div>
</div>
<script>
(function () {
    var dl = <?= json_encode($dl) ?>;
    var fname = <?= json_encode($fname) ?>;
    var root = document.getElementById('thamAgentUpdateRoot');
    if (root && root.parentNode !== document.body) document.body.appendChild(root);
    var overlay = document.getElementById('thamAgentUpdateOverlay');
    var toast = document.getElementById('thamAgentSilentToast');
    var titleEl = document.getElementById('thamAgentUpdateTitle');
    var bodyEl = document.getElementById('thamAgentUpdateBody');
    var btn = document.getElementById('thamAgentUpdateBtn');
    var later = document.getElementById('thamAgentLaterBtn');
    var lastPushAt = '';
    var skippedPushAt = '';
    try { skippedPushAt = sessionStorage.getItem('tham_agent_skip_push') || ''; } catch (e) {}
    var busyUntil = 0;

    function showToast(msg) {
        if (!toast) return;
        toast.innerHTML = msg;
        toast.style.display = 'block';
        setTimeout(function () { toast.style.display = 'none'; }, 16000);
    }
    function showModal(isCenter) {
        if (!overlay) return;
        if (isCenter && titleEl) titleEl.textContent = 'ศูนย์แจ้งให้ดาวน์โหลด THAM Notify';
        overlay.style.display = 'flex';
    }
    function hideModal() {
        if (overlay) overlay.style.display = 'none';
    }
    function startDownload(fromCenter) {
        if (Date.now() < busyUntil) return;
        busyUntil = Date.now() + 8000;
        fetch('fetch_tham_alert_api.php', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'ack_install_push' })
        }).catch(function () {});
        window.location.href = 'alert_agent.php';
        if (fromCenter) showModal(true);
    }
    if (btn) btn.addEventListener('click', function (e) {
        e.preventDefault();
        startDownload(false);
    });
    if (later) later.addEventListener('click', function (e) {
        e.preventDefault();
        hideModal();
        try {
            sessionStorage.setItem('tham_agent_skip_push', lastPushAt || '1');
        } catch (err) {}
        fetch('fetch_tham_alert_api.php', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'ack_install_push' })
        }).catch(function () {});
    });
    <?php if (!empty($show_login_modal)): ?>
    showModal(false);
    <?php endif; ?>
    function pollCenter() {
        if (Date.now() < busyUntil) return;
        fetch('fetch_tham_alert_api.php?action=my_install_push', { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (!data || !data.push) return;
                if (data.name) fname = data.name;
                if (data.url) dl = data.url;
                lastPushAt = data.push_at || lastPushAt || '1';
                if (skippedPushAt && lastPushAt === skippedPushAt) return;
                if (overlay && overlay.style.display === 'flex') return;
                showModal(true);
            })
            .catch(function () {});
    }
    pollCenter();
    setInterval(pollCenter, 8000);
})();
</script>
