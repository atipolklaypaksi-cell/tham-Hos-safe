<?php
/**
 * รายงานผู้ป่วยนอกเวลา / SMC ตามจุดรับบริการ
 * โหมดเวร 4 ชม. แยกกลุ่ม:
 * - คลินิกทั่วไป: ไม่จำกัดเวลา visit
 * - ตึกอุบัติเหตุ / ห้องตรวจ เวชศาสตร์ฟื้นฟู: กรองตามเวลาลงยา/visit (เริ่มต้น 16:30–20:30)
 * - SI = ฉุกเฉิน/อุบัติเหตุ/ER/เวชศาสตร์ฟื้นฟู (+ dep 414)
 * - SO = SMC / OPD นอกเวลา
 * - SI: ตึกฉุกเฉิน / ตึกอุบัติเหตุ / ตึก ER / เวชศาสตร์ฟื้นฟู
 * - SO: อื่นๆ ในเวร (เช่น SMC, OPD นอกเวลา)
 */
require_once __DIR__ . '/rational_lab_use_helper.php';

function smc_normalize_granularity($g) {
    $g = strtolower(trim((string)$g));
    if (in_array($g, ['day', 'month', 'year'], true)) {
        return $g;
    }
    return 'day';
}

function smc_normalize_doctor_codes($doctor_codes) {
    if (is_string($doctor_codes)) {
        $doctor_codes = preg_split('/\s*,\s*/', $doctor_codes);
    }
    if (!is_array($doctor_codes)) {
        return [];
    }
    $out = [];
    foreach ($doctor_codes as $code) {
        $code = trim((string)$code);
        if ($code === '' || $code === 'all' || $code === '*') {
            continue;
        }
        $out[$code] = $code;
    }
    return array_values($out);
}

function smc_normalize_dep_codes($dep_codes) {
    if (is_string($dep_codes)) {
        $dep_codes = preg_split('/\s*,\s*/', $dep_codes);
    }
    if (!is_array($dep_codes)) {
        return [];
    }
    $out = [];
    foreach ($dep_codes as $code) {
        $code = trim((string)$code);
        if ($code === '') {
            continue;
        }
        $out[$code] = $code;
    }
    return array_values($out);
}

/** จุดบริการ preset เวร 4 ชม.: si | so */
function smc_normalize_service_groups($groups) {
    $allowed = ['si', 'so'];
    if (is_string($groups)) {
        $groups = preg_split('/\s*,\s*/', $groups);
    }
    if (!is_array($groups) || empty($groups)) {
        return $allowed;
    }
    $out = [];
    foreach ($groups as $g) {
        $g = strtolower(trim((string)$g));
        // รองรับค่าเก่า
        if (in_array($g, ['er', 'smc', 'opd_after'], true)) {
            $g = ($g === 'er') ? 'si' : 'so';
        }
        if (in_array($g, $allowed, true)) {
            $out[$g] = $g;
        }
    }
    return !empty($out) ? array_values($out) : $allowed;
}

function smc_normalize_time($time, $fallback) {
    $time = trim((string)$time);
    if (preg_match('/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/', $time, $m)) {
        $h = max(0, min(23, (int)$m[1]));
        $i = max(0, min(59, (int)$m[2]));
        $s = isset($m[3]) ? max(0, min(59, (int)$m[3])) : 0;
        return sprintf('%02d:%02d:%02d', $h, $i, $s);
    }
    return $fallback;
}

function smc_normalize_mode($mode) {
    $mode = strtolower(trim((string)$mode));
    if ($mode === 'custom' || $mode === 'all') {
        return 'custom';
    }
    return 'shift4h';
}

function smc_sql_in_list($hos, array $values) {
    $escaped = [];
    foreach ($values as $v) {
        $escaped[] = "'" . mysqli_real_escape_string($hos, (string)$v) . "'";
    }
    return empty($escaped) ? "''" : implode(',', $escaped);
}

function smc_sql_patient_name_expr($patient_alias = 'p') {
    return "CAST(CONVERT(CONCAT(
        IFNULL({$patient_alias}.pname, ''),
        IFNULL({$patient_alias}.fname, ''),
        ' ',
        IFNULL({$patient_alias}.lname, '')
    ) USING utf8) AS CHAR)";
}

function smc_sql_doctor_code_expr() {
    return "COALESCE(NULLIF(NULLIF(TRIM(o.doctor), ''), '00000'), '')";
}

function smc_sql_doctor_name_expr() {
    return "CAST(CONVERT(COALESCE(NULLIF(TRIM(doc.name), ''), 'ไม่ระบุ') USING utf8) AS CHAR)";
}

function smc_sql_dept_name_expr() {
    return "CAST(CONVERT(COALESCE(NULLIF(TRIM(kdep.department), ''), 'ไม่ระบุ') USING utf8) AS CHAR)";
}

/** depcode ที่บังคับเป็น SI (แม้ชื่อมี SMC) */
function smc_si_dep_codes() {
    return ['414']; // จุดซักประวัติ คลินิกพิเศษเฉพาะทางนอกเวลา (SMC)
}

function smc_sql_si_dep_codes_in($alias = 'kdep') {
    $codes = smc_si_dep_codes();
    if (empty($codes)) {
        return '0';
    }
    $quoted = array_map(function ($c) {
        return "'" . addslashes($c) . "'";
    }, $codes);
    return "{$alias}.depcode IN (" . implode(',', $quoted) . ")";
}

/** SI: ฉุกเฉิน / อุบัติเหตุ / ER / เวชศาสตร์ฟื้นฟู + depcode พิเศษ */
function smc_sql_si_dept_condition($alias = 'kdep') {
    $d = "{$alias}.department";
    $codes_in = smc_sql_si_dep_codes_in($alias);
    return "(
        {$codes_in}
        OR {$d} LIKE '%ตึกฉุกเฉิน%'
        OR {$d} LIKE '%ตึกอุบัติเหตุ%'
        OR {$d} LIKE '%ตึก ER%'
        OR {$d} LIKE '%ตึกER%'
        OR {$d} LIKE '%เวชศาสตร์ฟื้นฟู%'
    )";
}

/** SO ในเวร 4 ชม.: SMC / OPD นอกเวลา */
function smc_sql_so_dept_condition($alias = 'kdep') {
    $d = "{$alias}.department";
    return "(
        {$d} LIKE '%SMC%'
        OR {$d} LIKE '%OPD นอกเวลา%'
    )";
}

/** จัดกลุ่ม SI / SO สำหรับสรุปรายงาน */
function smc_sql_service_group_expr() {
    $si = smc_sql_si_dept_condition('kdep');
    return "CASE
        WHEN {$si} THEN 'SI'
        ELSE 'SO'
    END";
}

function smc_shift4h_group_sql($alias = 'k') {
    return '(' . smc_sql_si_dept_condition($alias) . ' OR ' . smc_sql_so_dept_condition($alias) . ')';
}

/**
 * ดึงจุดรับบริการทั้งหมด + ทำเครื่องหมายกลุ่มเวร 4 ชม. (SI/SO)
 */
function smc_fetch_departments($hos) {
    $t0 = microtime(true);
    $si = smc_sql_si_dept_condition('k');
    $so = smc_sql_so_dept_condition('k');
    $sql = "
        SELECT
            k.depcode,
            CAST(CONVERT(IFNULL(k.department, '') USING utf8) AS CHAR) AS department,
            CASE
                WHEN {$si} THEN 'si'
                WHEN {$so} THEN 'so'
                ELSE ''
            END AS shift_group
        FROM kskdepartment k
        WHERE k.depcode IS NOT NULL
          AND TRIM(k.depcode) <> ''
          AND IFNULL(k.department, '') <> ''
        ORDER BY
            CASE
                WHEN {$si} THEN 1
                WHEN {$so} THEN 2
                ELSE 9
            END,
            k.department ASC
    ";
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['rows' => [], 'shift4h_codes' => [], 'si_codes' => [], 'so_codes' => [], 'error' => mysqli_error($hos), 'elapsed_ms' => 0];
    }
    $rows = [];
    $shift_codes = [];
    $si_codes = [];
    $so_codes = [];
    while ($row = mysqli_fetch_assoc($q)) {
        $code = trim((string)($row['depcode'] ?? ''));
        $name = trim((string)($row['department'] ?? ''));
        $group = trim((string)($row['shift_group'] ?? ''));
        if ($code === '') {
            continue;
        }
        $is_shift = ($group === 'si' || $group === 'so');
        if ($is_shift) {
            $shift_codes[] = $code;
        }
        if ($group === 'si') {
            $si_codes[] = $code;
        }
        if ($group === 'so') {
            $so_codes[] = $code;
        }
        $rows[] = [
            'dep_code' => $code,
            'dep_name' => $name,
            'shift_group' => $group,
            'is_shift4h' => $is_shift,
            'is_si' => $group === 'si',
            'is_so' => $group === 'so',
        ];
    }
    return [
        'rows' => $rows,
        'shift4h_codes' => $shift_codes,
        'si_codes' => $si_codes,
        'so_codes' => $so_codes,
        'error' => '',
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
    ];
}

/**
 * แปลงโหมด/กลุ่ม เป็นรายการ depcode (ใช้ IN ซึ่งเร็วกว่า LIKE บนทุกแถว visit)
 */
function smc_resolve_dep_codes($hos, array $options) {
    $explicit = smc_normalize_dep_codes($options['dep_codes'] ?? []);
    if (!empty($explicit)) {
        return $explicit;
    }

    $mode = smc_normalize_mode($options['mode'] ?? 'shift4h');
    if ($mode === 'custom') {
        return [];
    }

    $groups = smc_normalize_service_groups($options['service_groups'] ?? []);
    $parts = [];
    if (in_array('si', $groups, true)) {
        $parts[] = smc_sql_si_dept_condition('k');
    }
    if (in_array('so', $groups, true)) {
        $parts[] = smc_sql_so_dept_condition('k');
    }
    if (empty($parts)) {
        $parts[] = smc_shift4h_group_sql('k');
    }
    $sql = "
        SELECT k.depcode
        FROM kskdepartment k
        WHERE (" . implode(' OR ', $parts) . ")
    ";
    $q = mysqli_query($hos, $sql);
    $codes = [];
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $code = trim((string)($row['depcode'] ?? ''));
            if ($code !== '') {
                $codes[$code] = $code;
            }
        }
    }
    return array_values($codes);
}

/**
 * Subquery ยา — จำกัดช่วงวันที่เสมอ (กัน full scan opitemrece)
 * รวมชื่อเภสัชกรผู้จ่าย (opitemrece.staff → opduser)
 */
function smc_sql_drug_visit_subquery($hos, $start_date, $end_date) {
    $start_esc = mysqli_real_escape_string($hos, $start_date);
    $end_esc = mysqli_real_escape_string($hos, $end_date);
    return "
        (
            SELECT
                i.vn,
                COUNT(*) AS drug_item_count,
                SUM(i.sum_price) AS drug_total_price,
                CAST(CONVERT(GROUP_CONCAT(DISTINCT NULLIF(TRIM(u.name), '') ORDER BY u.name SEPARATOR ', ') USING utf8) AS CHAR) AS pharmacist_names,
                CAST(CONVERT(GROUP_CONCAT(DISTINCT NULLIF(TRIM(i.staff), '') ORDER BY i.staff SEPARATOR ',') USING utf8) AS CHAR) AS pharmacist_codes
            FROM opitemrece i
            INNER JOIN drugitems d ON d.icode = i.icode
            LEFT JOIN opduser u ON u.loginname = i.staff
            WHERE i.vstdate >= '{$start_esc}'
              AND i.vstdate <= '{$end_esc}'
              AND i.vn IS NOT NULL
              AND i.vn <> ''
              AND i.qty > 0
              AND i.sum_price > 0
            GROUP BY i.vn
        ) drug
    ";
}

/**
 * จุดบริการจริงของ visit จากรายการค่ารักษา (opitemrece.dep_code)
 * — visit นอกเวลา main_dep มักเป็น "จุดซักประวัติ" ไม่ใช่ห้องตรวจ SMC จริง
 * เลือกเฉพาะ dep ที่อยู่ในชุดที่กรอง และให้ "ห้องตรวจ" มาก่อนจุดซักประวัติ
 */
function smc_sql_visit_dep_subquery($hos, $start_date, $end_date, array $options = []) {
    $start_esc = mysqli_real_escape_string($hos, $start_date);
    $end_esc = mysqli_real_escape_string($hos, $end_date);
    $dep_codes = smc_normalize_dep_codes($options['resolved_dep_codes'] ?? ($options['dep_codes'] ?? []));
    if (!empty($dep_codes)) {
        $dep_filter = "i.dep_code IN (" . smc_sql_in_list($hos, $dep_codes) . ")";
    } else {
        $dep_filter = smc_shift4h_group_sql('kk');
    }
    return "
        (
            SELECT
                i.vn,
                SUBSTRING_INDEX(
                    GROUP_CONCAT(i.dep_code
                        ORDER BY (CASE WHEN kk.department LIKE '%ห้องตรวจ%' THEN 0 ELSE 1 END), i.dep_code
                        SEPARATOR ','),
                    ',', 1) AS dep_code
            FROM opitemrece i
            INNER JOIN kskdepartment kk ON kk.depcode = i.dep_code
            WHERE i.vstdate >= '{$start_esc}'
              AND i.vstdate <= '{$end_esc}'
              AND i.vn IS NOT NULL
              AND i.vn <> ''
              AND {$dep_filter}
            GROUP BY i.vn
        ) vdep
    ";
}

/** จุดบริการที่ใช้จัดกลุ่ม: ห้องตรวจจริงจากรายการค่ารักษา ถ้าไม่มีใช้ main_dep */
function smc_sql_effective_dep_expr() {
    return "COALESCE(vdep.dep_code, o.main_dep)";
}

function smc_sql_base_from($hos, $start_date, $end_date, $with_patient = false, array $options = []) {
    $joins = "
        FROM ovst o
        LEFT JOIN " . smc_sql_visit_dep_subquery($hos, $start_date, $end_date, $options) . " ON vdep.vn = o.vn
        INNER JOIN kskdepartment kdep ON kdep.depcode = " . smc_sql_effective_dep_expr() . "
        LEFT JOIN doctor doc ON doc.code = o.doctor
        LEFT JOIN pttype pt ON pt.pttype = o.pttype
        LEFT JOIN vn_stat vs ON vs.vn = o.vn
        LEFT JOIN " . smc_sql_drug_visit_subquery($hos, $start_date, $end_date) . " ON drug.vn = o.vn
    ";
    if ($with_patient) {
        $joins .= "
        LEFT JOIN patient p ON p.hn = o.hn
        ";
    }
    return $joins;
}

/** case ชำระเงิน = ช่องชำระแล้ว (vn_stat.paid_money) > 0 */
function smc_sql_must_pay_condition() {
    return "IFNULL(vs.paid_money, 0) > 0";
}

function smc_sql_paid_money_expr() {
    return "IFNULL(vs.paid_money, 0)";
}

/** จุดที่กรองเวลาเหมือนตึกอุบัติเหตุ (ตามเวลาลงยา / visit) */
function smc_sql_timed_dept_condition($alias = 'kdep') {
    $d = "{$alias}.department";
    return "(
        {$alias}.depcode = '001'
        OR {$d} = 'ตึกอุบัติเหตุ'
        OR {$d} LIKE 'ห้องตรวจ เวชศาสตร์ฟื้นฟู%'
    )";
}

/**
 * WHERE หลัก:
 * - คลินิกทั่วไป: ไม่จำกัดเวลา visit (ทั้งวัน)
 * - ตึกอุบัติเหตุ / ห้องตรวจ เวชศาสตร์ฟื้นฟู: ช่วงเวลาลงข้อมูลยา (opitemrece.rxtime ของยา) หรือเวลา visit
 *   เริ่มต้น 16:30–20:30
 */
function smc_sql_base_where($hos, $start_date, $end_date, array $options = []) {
    $start_esc = mysqli_real_escape_string($hos, $start_date);
    $end_esc = mysqli_real_escape_string($hos, $end_date);
    $time_start = smc_normalize_time($options['time_start'] ?? '16:30:00', '16:30:00');
    $time_end = smc_normalize_time($options['time_end'] ?? '20:30:00', '20:30:00');
    $doctor_codes = smc_normalize_doctor_codes($options['doctor_codes'] ?? []);
    $dep_codes = smc_normalize_dep_codes($options['resolved_dep_codes'] ?? ($options['dep_codes'] ?? []));
    $timed = smc_sql_timed_dept_condition('kdep');
    $drug_rx_in_window = "
        EXISTS (
            SELECT 1
            FROM opitemrece ix
            INNER JOIN drugitems dx ON dx.icode = ix.icode
            WHERE ix.vn = o.vn
              AND ix.vstdate = o.vstdate
              AND ix.qty > 0
              AND ix.sum_price > 0
              AND ix.rxtime >= '{$time_start}'
              AND ix.rxtime <= '{$time_end}'
        )
    ";

    $where = "
        WHERE o.vstdate >= '{$start_esc}'
          AND o.vstdate <= '{$end_esc}'
          AND (
                NOT ({$timed})
                OR {$drug_rx_in_window}
                OR (o.vsttime >= '{$time_start}' AND o.vsttime <= '{$time_end}')
          )
    ";

    if (!empty($dep_codes)) {
        $where .= " AND " . smc_sql_effective_dep_expr() . " IN (" . smc_sql_in_list($hos, $dep_codes) . ") ";
    } else {
        $where .= " AND " . smc_shift4h_group_sql('kdep') . " ";
    }

    if (!empty($doctor_codes)) {
        $where .= " AND o.doctor IN (" . smc_sql_in_list($hos, $doctor_codes) . ") ";
    }

    return $where;
}

function smc_format_metric_row(array $row) {
    $visit = (int)($row['visit_count'] ?? 0);
    $patient = (int)($row['patient_count'] ?? 0);
    $drug_visit = (int)($row['drug_visit_count'] ?? 0);
    $drug_patient = (int)($row['drug_patient_count'] ?? 0);
    $no_drug = max(0, $visit - $drug_visit);
    $items = (int)($row['drug_item_count'] ?? 0);
    $price = (float)($row['drug_total_price'] ?? 0);
    $pct = $visit > 0 ? ($drug_visit * 100.0 / $visit) : 0;
    $must_pay = (int)($row['must_pay_count'] ?? 0);
    $no_pay = (int)($row['no_pay_count'] ?? 0);
    if ($must_pay === 0 && $no_pay === 0 && $visit > 0 && !array_key_exists('must_pay_count', $row)) {
        // ไม่มีข้อมูลชำระเงินในแถวนี้
        $no_pay = 0;
    } elseif ($must_pay + $no_pay === 0 && $visit > 0) {
        $no_pay = $visit;
    }
    $must_pct = $visit > 0 ? ($must_pay * 100.0 / $visit) : 0;

    return array_merge($row, [
        'visit_count' => $visit,
        'patient_count' => $patient,
        'drug_visit_count' => $drug_visit,
        'drug_patient_count' => $drug_patient,
        'no_drug_visit_count' => $no_drug,
        'drug_item_count' => $items,
        'drug_total_price' => $price,
        'drug_visit_pct' => $pct,
        'must_pay_count' => $must_pay,
        'no_pay_count' => $no_pay,
        'must_pay_pct' => $must_pct,
        'visit_count_display' => rlu_format_number($visit),
        'patient_count_display' => rlu_format_number($patient),
        'drug_visit_count_display' => rlu_format_number($drug_visit),
        'drug_patient_count_display' => rlu_format_number($drug_patient),
        'no_drug_visit_count_display' => rlu_format_number($no_drug),
        'drug_item_count_display' => rlu_format_number($items),
        'drug_total_price_display' => rlu_format_money($price),
        'drug_visit_pct_display' => rlu_format_number($pct, 1) . '%',
        'must_pay_count_display' => rlu_format_number($must_pay),
        'no_pay_count_display' => rlu_format_number($no_pay),
        'must_pay_pct_display' => rlu_format_number($must_pct, 1) . '%',
    ]);
}

function smc_empty_summary() {
    return smc_format_metric_row([
        'visit_count' => 0,
        'patient_count' => 0,
        'drug_visit_count' => 0,
        'drug_patient_count' => 0,
        'drug_item_count' => 0,
        'drug_total_price' => 0,
        'must_pay_count' => 0,
        'no_pay_count' => 0,
        'period_count' => 0,
    ]);
}

function smc_select_metric_exprs() {
    $must = smc_sql_must_pay_condition();
    return "
        COUNT(DISTINCT o.vn) AS visit_count,
        COUNT(DISTINCT o.hn) AS patient_count,
        COUNT(DISTINCT CASE WHEN drug.vn IS NOT NULL THEN o.vn END) AS drug_visit_count,
        COUNT(DISTINCT CASE WHEN drug.vn IS NOT NULL THEN o.hn END) AS drug_patient_count,
        COALESCE(SUM(drug.drug_item_count), 0) AS drug_item_count,
        COALESCE(SUM(drug.drug_total_price), 0) AS drug_total_price,
        COUNT(DISTINCT CASE WHEN {$must} THEN o.vn END) AS must_pay_count,
        COUNT(DISTINCT CASE WHEN NOT ({$must}) THEN o.vn END) AS no_pay_count
    ";
}

function smc_prepare_options($hos, $start_date, $end_date, array $options) {
    $options['mode'] = smc_normalize_mode($options['mode'] ?? 'shift4h');
    $options['doctor_codes'] = smc_normalize_doctor_codes($options['doctor_codes'] ?? ($options['doctor_code'] ?? []));
    $options['service_groups'] = smc_normalize_service_groups($options['service_groups'] ?? []);
    $options['time_start'] = smc_normalize_time($options['time_start'] ?? '16:30:00', '16:30:00');
    $options['time_end'] = smc_normalize_time($options['time_end'] ?? '20:30:00', '20:30:00');
    $options['dep_codes'] = smc_normalize_dep_codes($options['dep_codes'] ?? []);
    $options['resolved_dep_codes'] = smc_resolve_dep_codes($hos, $options);
    return $options;
}

function smc_fetch_period_summary($hos, $start_date, $end_date, $granularity = 'day', array $options = []) {
    $granularity = smc_normalize_granularity($granularity);
    if ($granularity === 'year') {
        $bucket_expr = "DATE_FORMAT(o.vstdate, '%Y')";
        $label_expr = $bucket_expr;
    } elseif ($granularity === 'month') {
        $bucket_expr = "DATE_FORMAT(o.vstdate, '%Y-%m')";
        $label_expr = $bucket_expr;
    } else {
        $bucket_expr = "o.vstdate";
        $label_expr = "DATE_FORMAT(o.vstdate, '%Y-%m-%d')";
    }

    $from = smc_sql_base_from($hos, $start_date, $end_date, false, $options);
    $where = smc_sql_base_where($hos, $start_date, $end_date, $options);
    $metrics = smc_select_metric_exprs();

    $sql = "
        SELECT
            {$bucket_expr} AS bucket_key,
            {$label_expr} AS period_label,
            {$metrics}
        {$from}
        {$where}
        GROUP BY bucket_key, period_label
        ORDER BY bucket_key ASC
    ";
    $t0 = microtime(true);
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['rows' => [], 'error' => mysqli_error($hos), 'elapsed_ms' => 0];
    }
    $rows = [];
    while ($row = mysqli_fetch_assoc($q)) {
        $rows[] = smc_format_metric_row([
            'period_key' => trim((string)($row['bucket_key'] ?? '')),
            'period_label' => trim((string)($row['period_label'] ?? '')),
            'visit_count' => $row['visit_count'] ?? 0,
            'patient_count' => $row['patient_count'] ?? 0,
            'drug_visit_count' => $row['drug_visit_count'] ?? 0,
            'drug_patient_count' => $row['drug_patient_count'] ?? 0,
            'drug_item_count' => $row['drug_item_count'] ?? 0,
            'drug_total_price' => $row['drug_total_price'] ?? 0,
            'must_pay_count' => $row['must_pay_count'] ?? 0,
            'no_pay_count' => $row['no_pay_count'] ?? 0,
        ]);
    }

    // สรุปรวมจากแถว period — ไม่ยิง query ซ้ำ (ลดเวลา ~30%)
    $summary = smc_summary_from_metric_rows($rows);
    $summary['period_count'] = count($rows);

    return [
        'rows' => $rows,
        'summary' => $summary,
        'granularity' => $granularity,
        'error' => '',
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
    ];
}

/** รวมตัวเลขจากหลายแถว (ใช้ทั้งฝั่ง PHP และแนว chunk) */
function smc_summary_from_metric_rows(array $rows) {
    $visit = 0;
    $patient = 0;
    $drug_visit = 0;
    $drug_patient = 0;
    $items = 0;
    $price = 0.0;
    $must_pay = 0;
    $no_pay = 0;
    foreach ($rows as $r) {
        $visit += (int)($r['visit_count'] ?? 0);
        $patient += (int)($r['patient_count'] ?? 0);
        $drug_visit += (int)($r['drug_visit_count'] ?? 0);
        $drug_patient += (int)($r['drug_patient_count'] ?? 0);
        $items += (int)($r['drug_item_count'] ?? 0);
        $price += (float)($r['drug_total_price'] ?? 0);
        $must_pay += (int)($r['must_pay_count'] ?? 0);
        $no_pay += (int)($r['no_pay_count'] ?? 0);
    }
    return smc_format_metric_row([
        'visit_count' => $visit,
        'patient_count' => $patient,
        'drug_visit_count' => $drug_visit,
        'drug_patient_count' => $drug_patient,
        'drug_item_count' => $items,
        'drug_total_price' => $price,
        'must_pay_count' => $must_pay,
        'no_pay_count' => $no_pay,
        'period_count' => count($rows),
    ]);
}

function smc_fetch_service_point_summary($hos, $start_date, $end_date, array $options = []) {
    $group_expr = smc_sql_service_group_expr();
    $dept_expr = smc_sql_dept_name_expr();
    $metrics = smc_select_metric_exprs();
    $sql = "
        SELECT
            {$group_expr} AS service_group,
            IFNULL(" . smc_sql_effective_dep_expr() . ", '') AS dept_code,
            {$dept_expr} AS dept_name,
            {$metrics}
        " . smc_sql_base_from($hos, $start_date, $end_date, false, $options) . "
        " . smc_sql_base_where($hos, $start_date, $end_date, $options) . "
        GROUP BY service_group, dept_code, dept_name
        ORDER BY visit_count DESC, dept_name ASC
    ";
    $t0 = microtime(true);
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['rows' => [], 'error' => mysqli_error($hos), 'elapsed_ms' => 0];
    }
    $rows = [];
    $total_visits = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $formatted = smc_format_metric_row([
            'service_group' => trim((string)($row['service_group'] ?? '')) ?: 'SO',
            'dept_code' => trim((string)($row['dept_code'] ?? '')),
            'dept_name' => trim((string)($row['dept_name'] ?? '')) ?: 'ไม่ระบุ',
            'visit_count' => $row['visit_count'] ?? 0,
            'patient_count' => $row['patient_count'] ?? 0,
            'drug_visit_count' => $row['drug_visit_count'] ?? 0,
            'drug_patient_count' => $row['drug_patient_count'] ?? 0,
            'drug_item_count' => $row['drug_item_count'] ?? 0,
            'drug_total_price' => $row['drug_total_price'] ?? 0,
            'must_pay_count' => $row['must_pay_count'] ?? 0,
            'no_pay_count' => $row['no_pay_count'] ?? 0,
        ]);
        $total_visits += $formatted['visit_count'];
        $rows[] = $formatted;
    }
    foreach ($rows as &$r) {
        $pct = $total_visits > 0 ? ($r['visit_count'] * 100.0 / $total_visits) : 0;
        $r['pct_share'] = $pct;
        $r['pct_share_display'] = rlu_format_number($pct, 1) . '%';
    }
    unset($r);

    return [
        'rows' => $rows,
        'error' => '',
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
    ];
}

function smc_fetch_doctor_summary($hos, $start_date, $end_date, array $options = []) {
    $doctor_code_expr = smc_sql_doctor_code_expr();
    $doctor_name_expr = smc_sql_doctor_name_expr();
    $metrics = smc_select_metric_exprs();
    $sql = "
        SELECT
            {$doctor_code_expr} AS doctor_code,
            {$doctor_name_expr} AS doctor_name,
            {$metrics}
        " . smc_sql_base_from($hos, $start_date, $end_date, false, $options) . "
        " . smc_sql_base_where($hos, $start_date, $end_date, $options) . "
        GROUP BY doctor_code, doctor_name
        ORDER BY visit_count DESC, doctor_name ASC
        LIMIT 200
    ";
    $t0 = microtime(true);
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['rows' => [], 'error' => mysqli_error($hos), 'elapsed_ms' => 0];
    }
    $rows = [];
    $total_visits = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $formatted = smc_format_metric_row([
            'doctor_code' => trim((string)($row['doctor_code'] ?? '')),
            'doctor_name' => trim((string)($row['doctor_name'] ?? '')) ?: 'ไม่ระบุ',
            'visit_count' => $row['visit_count'] ?? 0,
            'patient_count' => $row['patient_count'] ?? 0,
            'drug_visit_count' => $row['drug_visit_count'] ?? 0,
            'drug_patient_count' => $row['drug_patient_count'] ?? 0,
            'drug_item_count' => $row['drug_item_count'] ?? 0,
            'drug_total_price' => $row['drug_total_price'] ?? 0,
            'must_pay_count' => $row['must_pay_count'] ?? 0,
            'no_pay_count' => $row['no_pay_count'] ?? 0,
        ]);
        $total_visits += $formatted['visit_count'];
        $rows[] = $formatted;
    }
    foreach ($rows as &$r) {
        $pct = $total_visits > 0 ? ($r['visit_count'] * 100.0 / $total_visits) : 0;
        $r['pct_share'] = $pct;
        $r['pct_share_display'] = rlu_format_number($pct, 1) . '%';
    }
    unset($r);

    return [
        'rows' => $rows,
        'error' => '',
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
    ];
}

/**
 * สรุปแยกตามเภสัชกรผู้จ่ายยา (opitemrece.staff → opduser)
 * นับเฉพาะ visit ที่มีรายการยาจริง
 */
function smc_fetch_pharmacist_summary($hos, $start_date, $end_date, array $options = []) {
    $start_esc = mysqli_real_escape_string($hos, $start_date);
    $end_esc = mysqli_real_escape_string($hos, $end_date);
    $sql = "
        SELECT
            COALESCE(NULLIF(TRIM(i.staff), ''), '') AS pharmacist_code,
            CAST(CONVERT(COALESCE(
                NULLIF(TRIM(u.name), ''),
                NULLIF(TRIM(i.staff), ''),
                'ไม่ระบุ'
            ) USING utf8) AS CHAR) AS pharmacist_name,
            COUNT(DISTINCT o.vn) AS visit_count,
            COUNT(DISTINCT o.hn) AS patient_count,
            COUNT(DISTINCT o.vn) AS drug_visit_count,
            COUNT(DISTINCT o.hn) AS drug_patient_count,
            COUNT(*) AS drug_item_count,
            COALESCE(SUM(i.sum_price), 0) AS drug_total_price
        FROM ovst o
        LEFT JOIN " . smc_sql_visit_dep_subquery($hos, $start_date, $end_date, $options) . " ON vdep.vn = o.vn
        INNER JOIN kskdepartment kdep ON kdep.depcode = " . smc_sql_effective_dep_expr() . "
        INNER JOIN opitemrece i
            ON i.vn = o.vn
           AND i.vstdate >= '{$start_esc}'
           AND i.vstdate <= '{$end_esc}'
           AND i.qty > 0
           AND i.sum_price > 0
        INNER JOIN drugitems d ON d.icode = i.icode
        LEFT JOIN opduser u ON u.loginname = i.staff
        " . smc_sql_base_where($hos, $start_date, $end_date, $options) . "
        GROUP BY pharmacist_code, pharmacist_name
        ORDER BY drug_item_count DESC, pharmacist_name ASC
        LIMIT 200
    ";
    $t0 = microtime(true);
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['rows' => [], 'error' => mysqli_error($hos), 'elapsed_ms' => 0];
    }
    $rows = [];
    $total_items = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $formatted = smc_format_metric_row([
            'pharmacist_code' => trim((string)($row['pharmacist_code'] ?? '')),
            'pharmacist_name' => trim((string)($row['pharmacist_name'] ?? '')) ?: 'ไม่ระบุ',
            'visit_count' => $row['visit_count'] ?? 0,
            'patient_count' => $row['patient_count'] ?? 0,
            'drug_visit_count' => $row['drug_visit_count'] ?? 0,
            'drug_patient_count' => $row['drug_patient_count'] ?? 0,
            'drug_item_count' => $row['drug_item_count'] ?? 0,
            'drug_total_price' => $row['drug_total_price'] ?? 0,
            'must_pay_count' => $row['must_pay_count'] ?? 0,
            'no_pay_count' => $row['no_pay_count'] ?? 0,
        ]);
        $total_items += $formatted['drug_item_count'];
        $rows[] = $formatted;
    }
    foreach ($rows as &$r) {
        $pct = $total_items > 0 ? ($r['drug_item_count'] * 100.0 / $total_items) : 0;
        $r['pct_share'] = $pct;
        $r['pct_share_display'] = rlu_format_number($pct, 1) . '%';
    }
    unset($r);

    return [
        'rows' => $rows,
        'error' => '',
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
    ];
}

function smc_fetch_detail_rows($hos, $start_date, $end_date, array $options = [], $limit = 3000) {
    $limit = max(1, min(5000, (int)$limit));
    $name_expr = smc_sql_patient_name_expr('p');
    $doctor_code_expr = smc_sql_doctor_code_expr();
    $doctor_name_expr = smc_sql_doctor_name_expr();
    $dept_expr = smc_sql_dept_name_expr();
    $group_expr = smc_sql_service_group_expr();
    $sql = "
        SELECT
            o.vstdate AS visit_date,
            DATE_FORMAT(o.vstdate, '%Y-%m-%d') AS visit_date_display,
            TIME_FORMAT(o.vsttime, '%H:%i') AS visit_time,
            o.hn,
            o.vn,
            {$name_expr} AS patient_name,
            CAST(CONVERT(COALESCE(NULLIF(TRIM(pt.name), ''), o.pttype, 'ไม่ระบุ') USING utf8) AS CHAR) AS pttype_name,
            {$doctor_code_expr} AS doctor_code,
            {$doctor_name_expr} AS doctor_name,
            IFNULL(" . smc_sql_effective_dep_expr() . ", '') AS dept_code,
            {$dept_expr} AS dept_name,
            {$group_expr} AS service_group,
            CASE WHEN drug.vn IS NOT NULL THEN 1 ELSE 0 END AS has_drug,
            COALESCE(drug.drug_item_count, 0) AS drug_item_count,
            COALESCE(drug.drug_total_price, 0) AS drug_total_price,
            CAST(CONVERT(COALESCE(NULLIF(TRIM(drug.pharmacist_names), ''), '') USING utf8) AS CHAR) AS pharmacist_names,
            IFNULL(TRIM(pt.paidst), '') AS paidst,
            " . smc_sql_paid_money_expr() . " AS paid_money,
            CASE WHEN " . smc_sql_must_pay_condition() . " THEN 1 ELSE 0 END AS must_pay
        " . smc_sql_base_from($hos, $start_date, $end_date, true, $options) . "
        " . smc_sql_base_where($hos, $start_date, $end_date, $options) . "
        ORDER BY o.vstdate ASC, o.vsttime ASC, o.vn ASC
        LIMIT {$limit}
    ";
    $t0 = microtime(true);
    $q = mysqli_query($hos, $sql);
    if (!$q) {
        return ['rows' => [], 'error' => mysqli_error($hos), 'elapsed_ms' => 0, 'truncated' => false];
    }
    $rows = [];
    $n = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $n++;
        $has_drug = (int)($row['has_drug'] ?? 0) === 1;
        $items = (int)($row['drug_item_count'] ?? 0);
        $price = (float)($row['drug_total_price'] ?? 0);
        $pharm = trim((string)($row['pharmacist_names'] ?? ''));
        $must_pay = (int)($row['must_pay'] ?? 0) === 1;
        $paid_money = (float)($row['paid_money'] ?? 0);
        $rows[] = [
            'row_no' => $n,
            'visit_date' => trim((string)($row['visit_date'] ?? '')),
            'visit_date_display' => trim((string)($row['visit_date_display'] ?? '')),
            'visit_time' => trim((string)($row['visit_time'] ?? '')),
            'hn' => trim((string)($row['hn'] ?? '')),
            'vn' => trim((string)($row['vn'] ?? '')),
            'patient_name' => trim((string)($row['patient_name'] ?? '')),
            'pttype_name' => trim((string)($row['pttype_name'] ?? '')),
            'doctor_code' => trim((string)($row['doctor_code'] ?? '')),
            'doctor_name' => trim((string)($row['doctor_name'] ?? '')) ?: 'ไม่ระบุ',
            'dept_code' => trim((string)($row['dept_code'] ?? '')),
            'dept_name' => trim((string)($row['dept_name'] ?? '')) ?: 'ไม่ระบุ',
            'service_group' => trim((string)($row['service_group'] ?? '')) ?: 'SO',
            'has_drug' => $has_drug,
            'has_drug_label' => $has_drug ? 'มียา' : 'ไม่มียา',
            'must_pay' => $must_pay,
            'pay_status' => $must_pay ? 'ชำระแล้ว' : 'ไม่ได้ชำระ',
            'paidst' => trim((string)($row['paidst'] ?? '')),
            'paid_money' => $paid_money,
            'paid_money_display' => rlu_format_money($paid_money),
            'pharmacist_names' => $pharm,
            'drug_item_count' => $items,
            'drug_item_count_display' => rlu_format_number($items),
            'drug_total_price' => $price,
            'drug_total_price_display' => rlu_format_money($price),
        ];
    }
    return [
        'rows' => $rows,
        'error' => '',
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
        'truncated' => count($rows) >= $limit,
        'limit' => $limit,
    ];
}

function smc_build_report($hos, $start_date, $end_date, $granularity = 'day', $include_detail = true, array $options = []) {
    $period = rlu_parse_period($start_date, $end_date);
    $start_date = $period['start_date'];
    $end_date = $period['end_date'];
    $granularity = smc_normalize_granularity($granularity);
    $options = smc_prepare_options($hos, $start_date, $end_date, $options);

    if (empty($options['resolved_dep_codes'])) {
        return [
            'status' => 'error',
            'message' => 'ไม่พบจุดรับบริการที่เลือก — กรุณาเลือกจุดบริการอย่างน้อย 1 จุด',
            'period' => $period,
        ];
    }

    $sum = smc_fetch_period_summary($hos, $start_date, $end_date, $granularity, $options);
    if (($sum['error'] ?? '') !== '') {
        return ['status' => 'error', 'message' => $sum['error'], 'period' => $period];
    }

    $points = smc_fetch_service_point_summary($hos, $start_date, $end_date, $options);
    if (($points['error'] ?? '') !== '') {
        return ['status' => 'error', 'message' => $points['error'], 'period' => $period];
    }

    $doctors = smc_fetch_doctor_summary($hos, $start_date, $end_date, $options);
    if (($doctors['error'] ?? '') !== '') {
        return ['status' => 'error', 'message' => $doctors['error'], 'period' => $period];
    }

    $pharmacists = smc_fetch_pharmacist_summary($hos, $start_date, $end_date, $options);
    if (($pharmacists['error'] ?? '') !== '') {
        return ['status' => 'error', 'message' => $pharmacists['error'], 'period' => $period];
    }

    $detail = ['rows' => [], 'elapsed_ms' => 0, 'truncated' => false, 'limit' => 0];
    if ($include_detail) {
        $detail = smc_fetch_detail_rows($hos, $start_date, $end_date, $options);
        if (($detail['error'] ?? '') !== '') {
            return ['status' => 'error', 'message' => $detail['error'], 'period' => $period];
        }
    }

    $elapsed = (int)($sum['elapsed_ms'] ?? 0)
        + (int)($points['elapsed_ms'] ?? 0)
        + (int)($doctors['elapsed_ms'] ?? 0)
        + (int)($pharmacists['elapsed_ms'] ?? 0)
        + (int)($detail['elapsed_ms'] ?? 0);

    $time_label = substr($options['time_start'], 0, 5) . '–' . substr($options['time_end'], 0, 5);

    return [
        'status' => 'success',
        'period' => $period,
        'granularity' => $granularity,
        'filters' => [
            'mode' => $options['mode'],
            'doctor_codes' => $options['doctor_codes'],
            'service_groups' => $options['service_groups'],
            'dep_codes' => $options['resolved_dep_codes'],
            'dep_count' => count($options['resolved_dep_codes']),
            'time_start' => $options['time_start'],
            'time_end' => $options['time_end'],
            'time_label' => $time_label,
        ],
        'summary' => $sum['summary'] ?? smc_empty_summary(),
        'periods' => $sum['rows'] ?? [],
        'service_points' => $points['rows'] ?? [],
        'doctors' => $doctors['rows'] ?? [],
        'pharmacists' => $pharmacists['rows'] ?? [],
        'details' => $detail['rows'] ?? [],
        'meta' => [
            'source' => 'hosxp_ovst_service_point',
            'source_label' => 'Visit ตามจุดรับบริการ — คลินิกทั่วไปทั้งวัน, ตึกอุบัติเหตุ/เวชศาสตร์ฟื้นฟูตามเวลาลงยา',
            'drug_definition' => 'รับยาจริง = มีรายการใน drugitems ของ visit นั้น (qty>0 และ sum_price>0)',
            'pay_definition' => 'case ชำระเงิน = vn_stat.paid_money (ช่องชำระแล้วใน HOSxP) > 0, ไม่ได้ชำระ = paid_money = 0',
            'time_definition' => 'ตึกอุบัติเหตุ + ห้องตรวจ เวชศาสตร์ฟื้นฟู = opitemrece.rxtime ของยา หรือ ovst.vsttime ในช่วงที่เลือก; จุดอื่น = ไม่จำกัดเวลา',
            'pharmacist_definition' => 'เภสัชกรผู้จ่ายยา = opitemrece.staff → opduser.name',
            'time_label' => $time_label,
            'mode' => $options['mode'],
            'dep_count' => count($options['resolved_dep_codes']),
            'doctor_filter_count' => count($options['doctor_codes']),
            'doctor_count' => count($doctors['rows'] ?? []),
            'pharmacist_count' => count($pharmacists['rows'] ?? []),
            'service_point_count' => count($points['rows'] ?? []),
            'detail_truncated' => !empty($detail['truncated']),
            'detail_limit' => (int)($detail['limit'] ?? 0),
            'include_detail' => (bool)$include_detail,
            'elapsed_ms' => $elapsed,
            'period_label' => $period['label'] ?? '',
        ],
    ];
}
