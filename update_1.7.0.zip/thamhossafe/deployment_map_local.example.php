<?php
/**
 * ตัวอย่าง override เซิร์ฟเวอร์กลาง
 * คัดลอกเป็น deployment_map_local.php บนเครื่องผู้พัฒนาเท่านั้น
 * ต้องโหลดก่อน deployment_map_config.php
 */
if (!defined('THAM_DEPLOYMENT_MAP_URL')) {
    define('THAM_DEPLOYMENT_MAP_URL', 'http://YOUR-SERVER/thamhossafe/map_dashboard.php');
}
if (!defined('THAM_LICENSE_ADMIN_ENABLED')) {
    define('THAM_LICENSE_ADMIN_ENABLED', true);
}
