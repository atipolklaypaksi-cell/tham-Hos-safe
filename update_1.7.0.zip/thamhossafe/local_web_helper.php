<?php
/**
 * Local Web = คำขอมาจาก IP ในเครือข่ายโรงพยาบาล (private/LAN)
 * ใช้จำกัด user บางคน และ Login ค้าง (keep_login) ไม่ให้ใช้จากอินเทอร์เน็ตภายนอก
 */

function tham_local_web_client_ip() {
    return trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
}

function tham_is_cgnat_ip($ip) {
    $ip = trim((string)$ip);
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        return false;
    }
    $long = ip2long($ip);
    if ($long === false) {
        return false;
    }
    $long = $long & 0xFFFFFFFF;
    // 100.64.0.0/10
    return ($long & 0xFFC00000) === 0x64400000;
}

/** true = เข้าจาก Local Web / LAN ใน รพ. */
function tham_is_local_web_request($ip = '') {
    $ip = trim((string)$ip);
    if ($ip === '') {
        $ip = tham_local_web_client_ip();
    }
    if ($ip === '127.0.0.1' || $ip === '::1') {
        return true;
    }
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return false;
    }
    if (tham_is_cgnat_ip($ip)) {
        return false;
    }
    // private / reserved = LAN
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false;
}

function tham_users_ensure_local_web_column($con) {
    static $done = false;
    if ($done || !$con) {
        return;
    }
    $done = true;
    $q = @mysqli_query($con, "SHOW COLUMNS FROM users LIKE 'local_web_only'");
    if ($q && mysqli_num_rows($q) === 0) {
        $ok = @mysqli_query($con, "ALTER TABLE users ADD COLUMN local_web_only TINYINT(1) NOT NULL DEFAULT 0 AFTER unit_ward");
        if (!$ok) {
            @mysqli_query($con, "ALTER TABLE users ADD COLUMN local_web_only TINYINT(1) NOT NULL DEFAULT 0");
        }
    }
}

function tham_user_local_web_only_flag($con, $userId) {
    $userId = (int)$userId;
    if (!$con || $userId <= 0) {
        return false;
    }
    tham_users_ensure_local_web_column($con);
    $q = @mysqli_query($con, "SELECT local_web_only FROM users WHERE id=$userId LIMIT 1");
    $r = $q ? mysqli_fetch_assoc($q) : null;
    return $r && (int)($r['local_web_only'] ?? 0) === 1;
}

function tham_local_web_deny_message() {
    return 'บัญชีนี้เข้าใช้งานได้เฉพาะ Local Web (เครือข่ายในโรงพยาบาล) เท่านั้น';
}

function tham_local_web_keep_deny_message() {
    return 'Login ค้างใช้ได้เฉพาะ Local Web (เครือข่ายในโรงพยาบาล) เท่านั้น';
}

/**
 * ตรวจก่อนตั้ง session หลัง login สำเร็จ
 * @return true = อนุญาต, false = ปฏิเสธ (ไม่ตั้ง session)
 */
function tham_local_web_allow_login($con, array $userRow) {
    tham_users_ensure_local_web_column($con);
    $only = (int)($userRow['local_web_only'] ?? 0) === 1;
    if (!$only) {
        // โหลดจาก DB ถ้าแถวไม่ครบคอลัมน์
        if (!array_key_exists('local_web_only', $userRow) && !empty($userRow['id'])) {
            $only = tham_user_local_web_only_flag($con, (int)$userRow['id']);
        }
    }
    if (!$only) {
        return true;
    }
    return tham_is_local_web_request();
}

function tham_local_web_clear_session() {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return;
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => time() - 42000,
            'path' => $p['path'] ?? '/',
            'domain' => $p['domain'] ?? '',
            'secure' => !empty($p['secure']),
            'httponly' => !empty($p['httponly']),
            'samesite' => $p['samesite'] ?? 'Lax',
        ]);
    }
    @session_destroy();
}

function tham_local_web_skip_page($page) {
    $skip = [
        'login.php',
        'logout.php',
        'oauth_callback.php',
        'check_license.php',
        'monitor_keep_login.php',
    ];
    return in_array($page, $skip, true);
}

/**
 * Gate ทุกหน้าหลังมี session — ไล่ user ที่จำกัด Local Web เมื่อเข้าจากนอก รพ.
 * และตัด session ที่มาจาก keep_login เมื่อไม่ใช่ Local Web
 */
function tham_local_web_gate($con) {
    if (php_sapi_name() === 'cli') {
        return;
    }
    if (session_status() !== PHP_SESSION_ACTIVE || empty($_SESSION['user_id'])) {
        return;
    }
    $page = basename((string)($_SERVER['PHP_SELF'] ?? ''));
    if (tham_local_web_skip_page($page)) {
        return;
    }

    $isLocal = tham_is_local_web_request();

    // Login ค้าง: ใช้ได้เฉพาะ Local Web
    if (!empty($_SESSION['keep_login_machine']) && !$isLocal) {
        tham_local_web_clear_session();
        if (!headers_sent()) {
            if (tham_local_web_wants_json()) {
                http_response_code(403);
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['ok' => false, 'error' => tham_local_web_keep_deny_message()], JSON_UNESCAPED_UNICODE);
            } else {
                header('Location: login.php?oauth_error=' . rawurlencode(tham_local_web_keep_deny_message()));
            }
        }
        exit;
    }

    $uid = (int)$_SESSION['user_id'];
    $flag = isset($_SESSION['local_web_only'])
        ? ((int)$_SESSION['local_web_only'] === 1)
        : tham_user_local_web_only_flag($con, $uid);
    $_SESSION['local_web_only'] = $flag ? 1 : 0;

    if ($flag && !$isLocal) {
        tham_local_web_clear_session();
        if (!headers_sent()) {
            if (tham_local_web_wants_json()) {
                http_response_code(403);
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['ok' => false, 'error' => tham_local_web_deny_message()], JSON_UNESCAPED_UNICODE);
            } else {
                header('Location: login.php?oauth_error=' . rawurlencode(tham_local_web_deny_message()));
            }
        }
        exit;
    }
}

function tham_local_web_wants_json() {
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
    $page = basename((string)($_SERVER['PHP_SELF'] ?? ''));
    if (stripos($page, 'api') !== false || stripos($page, 'fetch_') === 0 || stripos($page, 'save_') === 0) {
        return true;
    }
    $accept = (string)($_SERVER['HTTP_ACCEPT'] ?? '');
    return stripos($accept, 'application/json') !== false || stripos($uri, '_api') !== false;
}
