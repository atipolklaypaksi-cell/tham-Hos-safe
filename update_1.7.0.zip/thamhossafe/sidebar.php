<?php
$current_page = basename($_SERVER['PHP_SELF']);
require_once __DIR__ . '/menu_permissions_helper.php';
if (is_file(__DIR__ . '/deployment_map_local.php')) {
    require_once __DIR__ . '/deployment_map_local.php';
}
require_once __DIR__ . '/deployment_map_config.php';
if (isset($_SESSION['user_id']) && empty($_SESSION['menu_permissions_loaded'])) {
    if (!isset($con)) {
        include_once __DIR__ . '/connect.php';
        if (isset($con)) {
            mysqli_set_charset($con, 'utf8');
        }
    }
    if (isset($con)) {
        tham_menu_sync_postal_drug_permission($con);
        tham_menu_sync_allergy_followup_permission($con);
        tham_menu_sync_patient_opd_permission($con);
        tham_menu_sync_patient_ipd_permission($con);
        tham_menu_sync_med_error_report_permission($con);
        tham_menu_sync_invc_stock_permission($con);
        tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
    }
} elseif (isset($_SESSION['user_id']) && !empty($_SESSION['allowed_menus']) && is_array($_SESSION['allowed_menus'])) {
    // session เก่า — เติม home + รายงานรับยา ปณ. / SMC โดยไม่ต้อง login ใหม่
    $_SESSION['allowed_menus'] = tham_menu_expand_report_aliases($_SESSION['allowed_menus']);
    $af_role = $_SESSION['role'] ?? '';
    if (in_array($af_role, ['nurse', 'pharmacist', 'pharmacy_technician'], true)) {
        if (!in_array('allergy_followup', $_SESSION['allowed_menus'], true)) {
            $_SESSION['allowed_menus'][] = 'allergy_followup';
        }
        if (!in_array('allergy_report', $_SESSION['allowed_menus'], true)) {
            $_SESSION['allowed_menus'][] = 'allergy_report';
        }
        if (!in_array('allergy_history', $_SESSION['allowed_menus'], true)) {
            $_SESSION['allowed_menus'][] = 'allergy_history';
        }
        if (!in_array('allergy_eval_dashboard', $_SESSION['allowed_menus'], true)) {
            $_SESSION['allowed_menus'][] = 'allergy_eval_dashboard';
        }
        if (in_array($af_role, ['pharmacist', 'pharmacy_technician'], true)
            && !in_array('allergy_alert_settings', $_SESSION['allowed_menus'], true)) {
            $_SESSION['allowed_menus'][] = 'allergy_alert_settings';
        }
    }
}
if (isset($_SESSION['user_id'])) {
    tham_menu_ensure_page_access($current_page);
    if (!isset($con)) {
        include_once __DIR__ . '/connect.php';
        if (isset($con)) {
            mysqli_set_charset($con, 'utf8');
        }
    }
    if (isset($con)) {
        require_once __DIR__ . '/user_access_helper.php';
        tham_user_access_touch($con, (int)$_SESSION['user_id'], $current_page);
        require_once __DIR__ . '/tham_alert_helper.php';
        tham_alert_touch_web($con);
    }
}
?>
<style>
    @font-face {
        font-family: 'Caveat';
        font-style: normal;
        font-weight: 500;
        font-display: swap;
        src: url('fonts/caveat/Caveat-Medium.ttf') format('truetype');
    }
    @font-face {
        font-family: 'Caveat';
        font-style: normal;
        font-weight: 700;
        font-display: swap;
        src: url('fonts/caveat/Caveat-Bold.ttf') format('truetype');
    }

    /* Sidebar เขียวเข้ม อ่านสบายตา */
    #sidebar {
        background: linear-gradient(180deg, #1a4032 0%, #143326 55%, #0f2419 100%) !important;
        color: #fff !important;
        box-shadow: 4px 0 24px rgba(15, 36, 25, 0.3) !important;
    }
    #sidebar .sidebar-header {
        background: #0f2419 !important;
        border-bottom: 1px solid rgba(168, 213, 194, 0.12) !important;
    }
    #sidebar .sidebar-logo {
        background: rgba(116, 180, 155, 0.15) !important;
        color: #a8d5c2 !important;
    }
    #sidebar .sidebar-user {
        background: rgba(0, 0, 0, 0.15) !important;
        border-bottom: 1px solid rgba(168, 213, 194, 0.1) !important;
    }
    #sidebar .sidebar-unit-link {
        color: #a8d5c2 !important;
        font-size: 0.78rem;
        text-decoration: underline;
    }
    #sidebar .sidebar-unit-link:hover { color: #fff !important; }
    #sidebar ul li a {
        color: rgba(255, 255, 255, 0.82) !important;
        border-bottom-color: rgba(255, 255, 255, 0.05) !important;
    }
    #sidebar ul li a:hover {
        background: rgba(255, 255, 255, 0.07) !important;
        color: #fff !important;
    }
    #sidebar ul li.active > a {
        background: #2a6049 !important;
        border-left: 4px solid #74b49b !important;
        color: #fff !important;
    }
    #sidebar ul ul a {
        background: rgba(0, 0, 0, 0.18) !important;
        border-bottom-color: rgba(255, 255, 255, 0.03) !important;
    }
    #sidebar ul ul a:hover {
        background: rgba(255, 255, 255, 0.06) !important;
    }
    #sidebar ul ul li.active > a {
        background: rgba(61, 122, 94, 0.45) !important;
        color: #eef7f3 !important;
        border-left: 3px solid #74b49b !important;
    }
    #sidebar .developer-credit {
        font-family: 'Caveat', cursive !important;
        font-size: 1.4rem !important;
        color: #FFD700 !important;
        text-align: center;
        padding: 20px 15px;
        margin-top: auto;
        border-top: 1px dashed rgba(255, 255, 255, 0.2) !important;
        line-height: 1.2;
        transition: color 0.3s ease;
    }
    #sidebar .developer-credit:hover {
        color: #f8f9fa !important;
    }
    #sidebar .btn-sidebar-logout {
        background: rgba(255, 255, 255, 0.08) !important;
        border-color: rgba(168, 213, 194, 0.3) !important;
        color: rgba(255, 255, 255, 0.9) !important;
    }
    #sidebar .btn-sidebar-logout:hover {
        background: rgba(255, 255, 255, 0.16) !important;
        color: #fff !important;
    }
    #sidebar ul li a.dropdown-toggle {
        display: flex !important;
        justify-content: space-between;
        align-items: center;
        gap: 10px;
    }
    #sidebar ul li a.dropdown-toggle .sidebar-menu-text {
        flex: 1;
        min-width: 0;
        text-align: left;
    }
    #sidebar ul li a.dropdown-toggle::after {
        content: "";
        width: 8px;
        height: 8px;
        border-right: 2px solid currentColor;
        border-bottom: 2px solid currentColor;
        border-top: 0;
        border-left: 0;
        transform: rotate(45deg);
        flex-shrink: 0;
        transition: transform 0.3s ease;
    }
    #sidebar ul li a[aria-expanded="true"].dropdown-toggle::after {
        transform: rotate(-135deg);
    }
    #sidebar .sidebar-menu-sub {
        display: block;
        padding-left: 1.5rem;
        opacity: 0.75;
        font-size: 0.72rem;
        font-weight: 500;
        line-height: 1.2;
        margin-top: 2px;
    }
</style>
<?php
$safety_pages = [
    'monitor_drug_interaction.php',
    'monitor_drug_interaction_print.php',
    'monitor_drug_interaction_consult_print.php',
    'monitor_lab.php',
    'monitor_lab_renal.php',
    'monitor_lab_hepatic.php',
    'monitor_lab_other.php',
    'monitor_hla.php',
    'monitor_drug_usage.php',
    'monitor_max_dose.php',
    'monitor_warfarin.php',
    'monitor_mg_ml.php',
    'monitor_pediatric_dose.php',
    'monitor_dose_calculator.php',
    'monitor_antibiotic.php',
    'monitor_home_med.php',
    'monitor_opd_dup.php',
    'monitor_dup_therapy.php',
    'monitor_opd_order_qty.php',
    'monitor_drug_allergy.php',
];
$is_safety_active = in_array($current_page, $safety_pages, true);

$pharm_care_pages = ['smart_drug.php', 'smart_drug_chronic.php', 'smart_lab.php', 'patient_opd.php', 'patient_ipd.php', 'med_reconcile_discharge.php', 'med_recon_history.php'];
$is_pharm_care_active = in_array($current_page, $pharm_care_pages, true);
$med_error_pages = ['med_error.php', 'save_med_error.php', 'delete_med_error.php', 'action_error_type.php', 'export_med_error_excel.php', 'export_med_error_pdf.php', 'fetch_med_error_drugs_api.php', 'report_med_error.php'];
$is_med_error_active = in_array($current_page, $med_error_pages, true);

$drug_center_pages = ['dc_med_reconcile.php', 'dc_check_drug_all.php'];
$is_drug_center_active = in_array($current_page, $drug_center_pages, true);

$dose_calc_pages = ['dose_calculator.php', 'warfarin_calculator.php', 'mg_ml_calculator.php', 'pediatric_dose_calculator.php'];
$is_dose_calc_active = in_array($current_page, $dose_calc_pages, true);

$smart_pharma_pages = [
    'smart_pharma.php',
    'smart_pharma_opd.php',
    'smart_pharma_ipd.php',
    'smart_pharma_interventions.php',
    'smart_pharma_intervention_report.php',
    'smart_pharma_intervention_consult_print.php',
    'smart_pharma_settings.php',
    'smart_pharma_screen_hn.php',
    'smart_pharma_notifications.php',
    'smart_pharma_telegram.php',
    'smart_pharma_webhook.php',
];
$is_smart_pharma_active = in_array($current_page, $smart_pharma_pages, true);

$controlled_drug_pages = [
    'controlled_drug_narcotic.php',
    'controlled_drug_psychotropic.php',
    'controlled_drug_register_narcotic.php',
    'controlled_drug_register_psychotropic.php',
    'controlled_drug_settings_narcotic.php',
    'controlled_drug_settings_psychotropic.php',
    'controlled_drug_rooms.php',
    'controlled_drug_rooms_narcotic.php',
    'controlled_drug_rooms_psychotropic.php',
];
$is_controlled_drug_active = in_array($current_page, $controlled_drug_pages, true);

$amr_pages = ['amr_dashboard.php', 'amr_sensitivity.php', 'amr_cdss_consult_print.php', 'monitor_amr_drug.php', 'monitor_sepsis.php', 'monitor_sepsis_culture.php', 'amr_settings.php', 'amr_amass_dashboard.php', 'amr_amass_print.php', 'amr_amass_file.php', 'amr_connect.php', 'amr_antibiogram.php', 'amr_kpi.php'];
$is_amr_active = in_array($current_page, $amr_pages, true);

$is_drug_eval_j2 = $current_page === 'drug_eval_j2.php';
$network_drug_pages = ['network_drug_upload.php', 'network_drug_list.php', 'drug_refer.php', 'drug_refer_print.php', 'drug_refer_district.php', 'drug_refer_appointment.php', 'monitor_refer_back.php', 'monitor_refer_back_opd.php', 'monitor_refer_back_ipd.php', 'monitor_refer_back_interventions.php', 'monitor_refer_back_settings.php'];
$is_network_drug_active = in_array($current_page, $network_drug_pages, true);

$admin_pages = ['hosxp_setting.php', 'hosxp_master_setting.php', 'integrations_hub.php', 'data_purge_admin.php', 'alert_settings.php', 'alert_agent_machines.php', 'hosoffice_setting.php', 'jhcis_setting.php', 'drug_viewer_setting.php', 'robot_setting.php', 'hapysure_setting.php', 'provider_id_setting.php', 'invc_setting.php', 'hospital_connect.php', 'hospital_explore.php', 'amr_connect.php', 'warfarin_guideline_setting.php', 'display_mask_setting.php', 'users.php', 'user_access_log.php', 'menu_permissions.php', 'upgrade.php', 'admin_generate_key.php', 'server_health.php'];
$is_admin_active = in_array($current_page, $admin_pages, true);

$show_home = tham_menu_can('home');
$show_agent_download = isset($_SESSION['user_id']);
$show_safety = tham_menu_group_visible('group_safety');
$show_smart_pharma = tham_menu_group_visible('group_smart_pharma');
$show_controlled_drug = tham_menu_group_visible('group_controlled_drug');
$show_invc = tham_menu_can('invc.stock');
$show_amr = tham_menu_group_visible('group_amr');
$show_pharm_care = tham_menu_group_visible('group_pharm_care');
$show_med_error = tham_menu_group_visible('group_med_error')
    || tham_menu_can('pharm_care.med_error')
    || tham_menu_can('pharm_care.med_error_report');
if (!function_exists('af_alert_user_eligible') && isset($con)) {
    require_once __DIR__ . '/allergy_alert_helper.php';
}
$show_allergy_followup = tham_menu_can('allergy_followup');
$show_allergy_report = tham_menu_can('allergy_report') || $show_allergy_followup;
$show_allergy_history = tham_menu_can('allergy_history');
$show_allergy_eval_dash = tham_menu_can('allergy_eval_dashboard') || $show_allergy_followup || $show_allergy_history;
$show_allergy_alert_settings = tham_menu_can('allergy_alert_settings')
    || (function_exists('af_alert_user_eligible') && af_alert_user_eligible(isset($con) ? $con : null))
    || (($_SESSION['role'] ?? '') === 'admin');
$show_allergy_system = $show_allergy_followup || $show_allergy_report || $show_allergy_history || $show_allergy_eval_dash || $show_allergy_alert_settings;
$show_drug_center = tham_menu_group_visible('group_drug_center');
$show_dose_calc = tham_menu_group_visible('group_dose_calc');
$show_network_drug = tham_menu_group_visible('group_network_drug');
$show_dashboard_report = tham_menu_group_visible('group_dashboard_report');
$show_deployment_map = tham_menu_can('deployment.map');
$show_admin = tham_menu_group_visible('group_admin');

$dashboard_report_pages = ['report_dashboard.php', 'report_postal_drug.php', 'report_smc_clinic.php', 'rational_lab_use.php', 'rational_lab_use_dashboard.php'];
$is_dashboard_report_active = in_array($current_page, $dashboard_report_pages, true);
$is_allergy_followup_active = in_array($current_page, ['allergy_followup.php', 'allergy_followup_photo.php'], true);
$is_allergy_report_active = ($current_page === 'allergy_report.php');
$is_allergy_history_active = ($current_page === 'allergy_history.php');
$is_allergy_eval_dash_active = in_array($current_page, ['allergy_eval_dashboard.php'], true);
$is_allergy_alert_settings_active = ($current_page === 'allergy_alert_settings.php');
$is_allergy_system_active = $is_allergy_followup_active || $is_allergy_report_active || $is_allergy_history_active || $is_allergy_eval_dash_active || $is_allergy_alert_settings_active;

$af_unread = 0;
if (isset($con) && ($show_allergy_followup || $show_allergy_history || tham_menu_can('smart_pharma.settings'))) {
    $now = time();
    if (isset($_SESSION['af_unread_at'], $_SESSION['af_unread']) && ($now - (int)$_SESSION['af_unread_at']) < 30) {
        $af_unread = (int)$_SESSION['af_unread'];
    } else {
        $af_q = @mysqli_query($con, "SELECT COUNT(*) AS c FROM allergy_followup_notifications WHERE is_read = 0");
        if ($af_q && ($af_row = mysqli_fetch_assoc($af_q))) {
            $af_unread = (int)($af_row['c'] ?? 0);
        }
        $_SESSION['af_unread'] = $af_unread;
        $_SESSION['af_unread_at'] = $now;
    }
}
?>

<nav id="sidebar" class="d-flex flex-column">
    <div class="sidebar-header">
        <div class="sidebar-logo"><i class="fas fa-shield-virus"></i></div>
        <h3>THAM Hos-Safe</h3>
        <small>ระบบความปลอดภัยด้านยา</small>
    </div>

    <div class="sidebar-user">
        <div class="sidebar-user-label">เข้าสู่ระบบโดย</div>
        <div class="sidebar-user-name">
            <i class="fas fa-user-circle me-2"></i><?php echo htmlspecialchars($_SESSION['full_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
        </div>
        <?php
        if (!function_exists('tham_user_requires_unit') && isset($con)) {
            require_once __DIR__ . '/user_unit_helper.php';
        }
        $sb_unit = trim((string)($_SESSION['unit_ward'] ?? ''));
        $sb_need_unit = function_exists('tham_user_requires_unit') && tham_user_requires_unit();
        if ($sb_need_unit || $sb_unit !== ''):
        ?>
        <div class="sidebar-unit mt-2">
            <div class="small opacity-75">หน่วยงาน / หอผู้ป่วยสังกัด</div>
            <div class="fw-bold small"><?= $sb_unit !== '' ? htmlspecialchars($sb_unit, ENT_QUOTES, 'UTF-8') : 'ยังไม่ระบุ' ?></div>
            <a href="select_unit.php" class="sidebar-unit-link"><i class="fas fa-exchange-alt me-1"></i><?= $sb_unit !== '' ? 'เปลี่ยนหอผู้ป่วย' : 'ระบุหอผู้ป่วย' ?></a>
        </div>
        <?php endif; ?>
        <?php
        if (!function_exists('sp_backup_feature_on') && isset($con) && is_file(__DIR__ . '/smart_pharma_backup_helper.php')) {
            require_once __DIR__ . '/smart_pharma_backup_helper.php';
        }
        $sb_bk_on = function_exists('sp_backup_feature_on') && isset($con) && sp_backup_feature_on(null, $con);
        $sb_bk_role = function_exists('sp_backup_can_pick_room') && isset($con) && sp_backup_can_pick_room($con);
        if ($sb_bk_on && $sb_bk_role):
            $sb_room = function_exists('sp_backup_room_label') ? sp_backup_room_label() : '';
        ?>
        <div class="sidebar-unit mt-2">
            <div class="small opacity-75">ห้องจ่ายยา (Backup)</div>
            <div class="fw-bold small" id="spBkSidebarRoom"><?= $sb_room !== '' ? htmlspecialchars($sb_room, ENT_QUOTES, 'UTF-8') : 'ยังไม่เลือกกะนี้' ?></div>
            <div class="small" id="spBkSidebarStatus" style="opacity:.9"><?= $sb_room !== '' ? 'กำลังเฝ้า Alert' : 'เลือกห้องจ่ายยาเพื่อเริ่ม Backup' ?></div>
            <a href="select_dispense.php" class="sidebar-unit-link"><i class="fas fa-exchange-alt me-1"></i><?= $sb_room !== '' ? 'เปลี่ยนห้องจ่ายยา' : 'เลือกห้องจ่ายยา' ?></a>
        </div>
        <?php endif; ?>
        <a href="logout.php" class="btn btn-sidebar-logout w-100 mt-3">
            <i class="fas fa-sign-out-alt me-1"></i> ออกจากระบบ
        </a>
    </div>

    <ul class="list-unstyled components flex-grow-1 mb-0">
        <?php if ($show_home): ?>
        <li class="<?= $current_page === 'home.php' ? 'active' : '' ?>">
            <a href="home.php"><i class="fas fa-home me-2"></i> หน้าหลัก</a>
        </li>
        <?php endif; ?>

        <?php if ($show_safety): ?>
        <li class="<?= $is_safety_active ? 'active' : '' ?>">
            <a href="#safetySubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_safety_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text"><i class="fas fa-shield-alt me-2"></i> จัดการความปลอดภัยยา</span>
            </a>
            <ul class="collapse list-unstyled <?= $is_safety_active ? 'show' : '' ?>" id="safetySubmenu">
                <?php if (tham_menu_can('safety.interaction')): ?>
                <li class="<?= $current_page === 'monitor_drug_interaction.php' ? 'active' : '' ?>">
                    <a href="monitor_drug_interaction.php"><i class="fas fa-pills me-2"></i> Monitor Interaction</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.lab_renal')): ?>
                <li class="<?= in_array($current_page, ['monitor_lab.php', 'monitor_lab_renal.php'], true) ? 'active' : '' ?>">
                    <a href="monitor_lab_renal.php"><i class="fas fa-heartbeat me-2"></i> Monitor Lab ไต</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.lab_hepatic')): ?>
                <li class="<?= $current_page === 'monitor_lab_hepatic.php' ? 'active' : '' ?>">
                    <a href="monitor_lab_hepatic.php"><i class="fas fa-lungs me-2"></i> Monitor Lab ตับ</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.lab_other')): ?>
                <li class="<?= $current_page === 'monitor_lab_other.php' ? 'active' : '' ?>">
                    <a href="monitor_lab_other.php"><i class="fas fa-vial me-2"></i> Monitor Lab อื่นๆ</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.hla')): ?>
                <li class="<?= $current_page === 'monitor_hla.php' ? 'active' : '' ?>">
                    <a href="monitor_hla.php"><i class="fas fa-dna me-2"></i> Monitor ยีนแพ้ยา HLA</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.drug_usage')): ?>
                <li class="<?= $current_page === 'monitor_drug_usage.php' ? 'active' : '' ?>">
                    <a href="monitor_drug_usage.php"><i class="fas fa-prescription-bottle-alt me-2"></i> Monitor วิธีใช้ยา</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.max_dose')): ?>
                <li class="<?= $current_page === 'monitor_max_dose.php' ? 'active' : '' ?>">
                    <a href="monitor_max_dose.php"><i class="fas fa-tachometer-alt me-2"></i> Monitor Max Dose/Duration</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.warfarin')): ?>
                <li class="<?= $current_page === 'monitor_warfarin.php' ? 'active' : '' ?>">
                    <a href="monitor_warfarin.php"><i class="fas fa-heartbeat me-2"></i> Monitor Warfarin</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.mg_ml')): ?>
                <li class="<?= $current_page === 'monitor_mg_ml.php' ? 'active' : '' ?>">
                    <a href="monitor_mg_ml.php"><i class="fas fa-syringe me-2"></i> Monitor mg. to mL.</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.pediatric')): ?>
                <li class="<?= $current_page === 'monitor_pediatric_dose.php' ? 'active' : '' ?>">
                    <a href="monitor_pediatric_dose.php"><i class="fas fa-child me-2"></i> Monitor ยาเด็ก</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.dose_calculator')): ?>
                <li class="<?= $current_page === 'monitor_dose_calculator.php' ? 'active' : '' ?>">
                    <a href="monitor_dose_calculator.php"><i class="fas fa-calculator me-2"></i> Monitor เครื่องคำนวณยา</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.antibiotic')): ?>
                <li class="<?= $current_page === 'monitor_antibiotic.php' ? 'active' : '' ?>">
                    <a href="monitor_antibiotic.php"><i class="fas fa-bacteria me-2"></i> Monitor Antibiotic</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.home_med')): ?>
                <li class="<?= $current_page === 'monitor_home_med.php' ? 'active' : '' ?>">
                    <a href="monitor_home_med.php"><i class="fas fa-home me-2"></i> Monitor ยากลับบ้าน IPD</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.opd_dup')): ?>
                <li class="<?= $current_page === 'monitor_opd_dup.php' ? 'active' : '' ?>">
                    <a href="monitor_opd_dup.php"><i class="fas fa-history me-2"></i> Monitor ยาเหลือ OPD</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.dup_therapy')): ?>
                <li class="<?= $current_page === 'monitor_dup_therapy.php' ? 'active' : '' ?>">
                    <a href="monitor_dup_therapy.php"><i class="fas fa-layer-group me-2"></i> Monitor คู่ยาซ้ำซ้อน</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.opd_qty')): ?>
                <li class="<?= $current_page === 'monitor_opd_order_qty.php' ? 'active' : '' ?>">
                    <a href="monitor_opd_order_qty.php"><i class="fas fa-calculator me-2"></i> Monitor จำนวนสั่งยา (OPD)</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('safety.drug_allergy')): ?>
                <li class="<?= $current_page === 'monitor_drug_allergy.php' ? 'active' : '' ?>">
                    <a href="monitor_drug_allergy.php"><i class="fas fa-allergies me-2"></i> Monitor Drug Allergy</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if ($show_smart_pharma): ?>
        <li class="<?= $is_smart_pharma_active ? 'active' : '' ?>">
            <a href="#smartPharmaSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_smart_pharma_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text">
                    <span><i class="fas fa-user-shield me-2"></i> Smart Pharma</span>
                    <small class="sidebar-menu-sub">ระบบคัดกรองผู้ป่วย</small>
                </span>
            </a>
            <ul class="collapse list-unstyled <?= $is_smart_pharma_active ? 'show' : '' ?>" id="smartPharmaSubmenu">
                <?php if (tham_menu_can('smart_pharma.opd')): ?>
                <li class="<?= $current_page === 'smart_pharma_opd.php' ? 'active' : '' ?>">
                    <a href="smart_pharma_opd.php"><i class="fas fa-hospital-user me-2"></i> ผู้ป่วยนอก (OPD)</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('smart_pharma.ipd')): ?>
                <li class="<?= $current_page === 'smart_pharma_ipd.php' ? 'active' : '' ?>">
                    <a href="smart_pharma_ipd.php"><i class="fas fa-procedures me-2"></i> ผู้ป่วยใน (IPD)</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('smart_pharma.interventions')): ?>
                <li class="<?= $current_page === 'smart_pharma_interventions.php' ? 'active' : '' ?>">
                    <a href="smart_pharma_interventions.php"><i class="fas fa-notes-medical me-2"></i> Intervention Log</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('smart_pharma.intervention_report')): ?>
                <li class="<?= $current_page === 'smart_pharma_intervention_report.php' ? 'active' : '' ?>">
                    <a href="smart_pharma_intervention_report.php"><i class="fas fa-chart-pie me-2"></i> Intervention Report</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('smart_pharma.settings')): ?>
                <li class="<?= $current_page === 'smart_pharma_settings.php' ? 'active' : '' ?>">
                    <a href="smart_pharma_settings.php"><i class="fas fa-sliders-h me-2"></i> ตั้งค่าโมดูล<?php if (!empty($af_unread)): ?> <span class="badge bg-danger rounded-pill ms-1"><?= (int)$af_unread ?></span><?php endif; ?></a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('smart_pharma.screen_hn')): ?>
                <li class="<?= $current_page === 'smart_pharma_screen_hn.php' ? 'active' : '' ?>">
                    <a href="smart_pharma_screen_hn.php"><i class="fas fa-id-card me-2"></i> คัดกรองตาม HN</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('smart_pharma.notifications')): ?>
                <li class="<?= in_array($current_page, ['smart_pharma_notifications.php', 'smart_pharma_telegram.php', 'smart_pharma_webhook.php'], true) ? 'active' : '' ?>">
                    <a href="smart_pharma_notifications.php"><i class="fas fa-bell me-2"></i> แจ้งเตือน Alert</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if ($show_allergy_system): ?>
        <li class="<?= $is_allergy_system_active ? 'active' : '' ?>">
            <a href="#allergySystemSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_allergy_system_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text">
                    <span><i class="fas fa-allergies me-2"></i> ระบบแพ้ยา</span>
                    <small class="sidebar-menu-sub">แจ้งเคส ติดตาม และประวัติ HOSxP</small>
                </span>
            </a>
            <ul class="collapse list-unstyled <?= $is_allergy_system_active ? 'show' : '' ?>" id="allergySystemSubmenu">
                <?php if ($show_allergy_report): ?>
                <li class="<?= $is_allergy_report_active ? 'active' : '' ?>">
                    <a href="allergy_report.php"><i class="fas fa-camera me-2"></i> แจ้งเคสแพ้ยา</a>
                </li>
                <?php endif; ?>
                <?php if ($show_allergy_followup): ?>
                <li class="<?= $is_allergy_followup_active ? 'active' : '' ?>">
                    <a href="allergy_followup.php"><i class="fas fa-book-medical me-2"></i> ติดตามการแพ้ยา<?php if (!empty($af_unread)): ?> <span class="badge bg-danger rounded-pill ms-1"><?= (int)$af_unread ?></span><?php endif; ?> <span class="badge bg-danger rounded-pill ms-1" id="afPendingAckBadge" style="display:none;">0</span></a>
                </li>
                <?php endif; ?>
                <?php if ($show_allergy_history): ?>
                <li class="<?= $is_allergy_history_active ? 'active' : '' ?>">
                    <a href="allergy_history.php"><i class="fas fa-notes-medical me-2"></i> ประวัติแพ้ยาใน รพ.</a>
                </li>
                <?php endif; ?>
                <?php if ($show_allergy_eval_dash): ?>
                <li class="<?= $is_allergy_eval_dash_active ? 'active' : '' ?>">
                    <a href="allergy_eval_dashboard.php"><i class="fas fa-chart-pie me-2"></i> Dashboard การประเมินแพ้ยา</a>
                </li>
                <?php endif; ?>
                <?php if ($show_allergy_alert_settings): ?>
                <li class="<?= $is_allergy_alert_settings_active ? 'active' : '' ?>">
                    <a href="allergy_alert_settings.php"><i class="fas fa-bell me-2"></i> ตั้งค่าแจ้งเตือนแพ้ยา</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if ($show_controlled_drug): ?>
        <li class="<?= $is_controlled_drug_active ? 'active' : '' ?>">
            <a href="#controlledDrugSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_controlled_drug_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text">
                    <span><i class="fas fa-capsules me-2"></i> บริหารยาเสพติด/วัตถุออกฤทธิ์</span>
                    <small class="sidebar-menu-sub">สต๊อกคงคลังและรายงาน HOSxP</small>
                </span>
            </a>
            <ul class="collapse list-unstyled <?= $is_controlled_drug_active ? 'show' : '' ?>" id="controlledDrugSubmenu">
                <?php if (tham_menu_can('controlled_drug.narcotic')): ?>
                <li class="<?= $current_page === 'controlled_drug_narcotic.php' ? 'active' : '' ?>">
                    <a href="controlled_drug_narcotic.php"><i class="fas fa-hand-holding-medical me-2"></i> จ่ายยา (ยาเสพติด)</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('controlled_drug.psychotropic')): ?>
                <li class="<?= $current_page === 'controlled_drug_psychotropic.php' ? 'active' : '' ?>">
                    <a href="controlled_drug_psychotropic.php"><i class="fas fa-hand-holding-medical me-2"></i> จ่ายยา (วัตถุออกฤทธิ์)</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('controlled_drug.narcotic') || tham_menu_can('controlled_drug.psychotropic')): ?>
                <li class="<?= in_array($current_page, ['controlled_drug_rooms.php', 'controlled_drug_rooms_narcotic.php', 'controlled_drug_rooms_psychotropic.php'], true) ? 'active' : '' ?>">
                    <a href="controlled_drug_rooms.php"><i class="fas fa-door-open me-2"></i> จัดการห้องสต๊อก</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if ($show_amr): ?>
        <li class="<?= $is_amr_active ? 'active' : '' ?>">
            <a href="#amrSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_amr_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text">
                    <span><i class="fas fa-bacteria me-2"></i> AMR</span>
                    <small class="sidebar-menu-sub">เฝ้าระวังเชื้อดื้อยา</small>
                </span>
            </a>
            <ul class="collapse list-unstyled <?= $is_amr_active ? 'show' : '' ?>" id="amrSubmenu">
                <?php if (tham_menu_can('amr.dashboard')): ?>
                <li class="<?= $current_page === 'amr_dashboard.php' ? 'active' : '' ?>">
                    <a href="amr_dashboard.php"><i class="fas fa-chart-area me-2"></i> Dashboard เชื้อดื้อยา</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('amr.sensitivity')): ?>
                <li class="<?= $current_page === 'amr_sensitivity.php' ? 'active' : '' ?>">
                    <a href="amr_sensitivity.php"><i class="fas fa-vial me-2"></i> CDSS for Antibiotic</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('amr.monitor_drug')): ?>
                <li class="<?= $current_page === 'monitor_amr_drug.php' ? 'active' : '' ?>">
                    <a href="monitor_amr_drug.php"><i class="fas fa-exclamation-triangle me-2"></i> Monitor AMR Drug</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('amr.monitor_sepsis')): ?>
                <li class="<?= $current_page === 'monitor_sepsis.php' ? 'active' : '' ?>">
                    <a href="monitor_sepsis.php"><i class="fas fa-heartbeat me-2"></i> Monitor Sepsis by score</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('amr.monitor_sepsis_culture')): ?>
                <li class="<?= $current_page === 'monitor_sepsis_culture.php' ? 'active' : '' ?>">
                    <a href="monitor_sepsis_culture.php"><i class="fas fa-tint me-2"></i> Monitor Sepsis by culture</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('amr.amass')): ?>
                <li class="<?= $current_page === 'amr_amass_dashboard.php' || $current_page === 'amr_amass_print.php' ? 'active' : '' ?>">
                    <a href="amr_amass_dashboard.php"><i class="fas fa-file-medical me-2"></i> Dashboard AMASS</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('amr.antibiogram')): ?>
                <li class="<?= $current_page === 'amr_antibiogram.php' ? 'active' : '' ?>">
                    <a href="amr_antibiogram.php"><i class="fas fa-th me-2"></i> Antibiogram</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('amr.kpi')): ?>
                <li class="<?= $current_page === 'amr_kpi.php' ? 'active' : '' ?>">
                    <a href="amr_kpi.php"><i class="fas fa-percentage me-2"></i> KPI AMR</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('amr.settings')): ?>
                <li class="<?= $current_page === 'amr_settings.php' ? 'active' : '' ?>">
                    <a href="amr_settings.php"><i class="fas fa-cog me-2"></i> ตั้งค่า Dictionary</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if ($show_pharm_care): ?>
        <li class="<?= $is_pharm_care_active ? 'active' : '' ?>">
            <a href="#pharmCareSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_pharm_care_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text"><i class="fas fa-stethoscope me-2"></i> Patient EMR</span>
            </a>
            <ul class="collapse list-unstyled <?= $is_pharm_care_active ? 'show' : '' ?>" id="pharmCareSubmenu">
                <?php if (tham_menu_can('pharm_care.smart_drug')): ?>
                <li class="<?= $current_page === 'smart_drug.php' ? 'active' : '' ?>">
                    <a href="smart_drug.php"><i class="fas fa-capsules me-2"></i> ระบบ Smart Drug</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('pharm_care.smart_lab')): ?>
                <li class="<?= $current_page === 'smart_lab.php' ? 'active' : '' ?>">
                    <a href="smart_lab.php"><i class="fas fa-microscope me-2"></i> ระบบ Smart Lab</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('pharm_care.patient_opd')): ?>
                <li class="<?= $current_page === 'patient_opd.php' ? 'active' : '' ?>">
                    <a href="patient_opd.php"><i class="fas fa-user-injured me-2"></i> Patient OPD</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('pharm_care.patient_ipd')): ?>
                <li class="<?= $current_page === 'patient_ipd.php' ? 'active' : '' ?>">
                    <a href="patient_ipd.php"><i class="fas fa-procedures me-2"></i> Patient IPD</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('pharm_care.med_recon_discharge')): ?>
                <li class="<?= $current_page === 'med_reconcile_discharge.php' ? 'active' : '' ?>">
                    <a href="med_reconcile_discharge.php"><i class="fas fa-house-user me-2"></i> Med Reconcile ยากลับบ้าน</a>
                </li>
                <li class="<?= $current_page === 'med_recon_history.php' ? 'active' : '' ?>">
                    <a href="med_recon_history.php"><i class="fas fa-history me-2"></i> ประวัติการทำ Med Reconcile</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if ($show_med_error): ?>
        <li class="<?= $is_med_error_active ? 'active' : '' ?>">
            <a href="#medErrorSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_med_error_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text"><i class="fas fa-exclamation-triangle me-2"></i> Med error/Consult</span>
            </a>
            <ul class="collapse list-unstyled <?= $is_med_error_active ? 'show' : '' ?>" id="medErrorSubmenu">
                <?php if (tham_menu_can('pharm_care.med_error')): ?>
                <li class="<?= $current_page === 'med_error.php' ? 'active' : '' ?>">
                    <a href="med_error.php"><i class="fas fa-edit me-2"></i> Med error/Consult</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('pharm_care.med_error_report')): ?>
                <li class="<?= $current_page === 'report_med_error.php' ? 'active' : '' ?>">
                    <a href="report_med_error.php"><i class="fas fa-chart-bar me-2"></i> รายงาน ME/Consult</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if ($show_drug_center): ?>
        <li class="<?= $is_drug_center_active ? 'active' : '' ?>">
            <a href="#drugCenterSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_drug_center_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text">
                    <span><i class="fas fa-cloud me-2"></i> Drugs Center (PHR)</span>
                    <small class="sidebar-menu-sub">Med Reconcile / Check All</small>
                </span>
            </a>
            <ul class="collapse list-unstyled <?= $is_drug_center_active ? 'show' : '' ?>" id="drugCenterSubmenu">
                <?php if (tham_menu_can('drug_center.med_reconcile')): ?>
                <li class="<?= $current_page === 'dc_med_reconcile.php' ? 'active' : '' ?>">
                    <a href="dc_med_reconcile.php"><i class="fas fa-notes-medical me-2"></i> Med Reconcile (PHR)</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('drug_center.check_all')): ?>
                <li class="<?= $current_page === 'dc_check_drug_all.php' ? 'active' : '' ?>">
                    <a href="dc_check_drug_all.php"><i class="fas fa-shield-alt me-2"></i> Check Drug All</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if ($show_dose_calc): ?>
        <li class="<?= $is_dose_calc_active ? 'active' : '' ?>">
            <a href="#doseCalcSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_dose_calc_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text">
                    <span><i class="fas fa-calculator me-2"></i> ระบบช่วยคำนวณ</span>
                    <small class="sidebar-menu-sub">Dose Calculator</small>
                </span>
            </a>
            <ul class="collapse list-unstyled <?= $is_dose_calc_active ? 'show' : '' ?>" id="doseCalcSubmenu">
                <?php if (tham_menu_can('dose_calc.hub')): ?>
                <li class="<?= $current_page === 'dose_calculator.php' ? 'active' : '' ?>">
                    <a href="dose_calculator.php"><i class="fas fa-flask me-2"></i> เครื่องคำนวณยา</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('dose_calc.warfarin')): ?>
                <li class="<?= $current_page === 'warfarin_calculator.php' ? 'active' : '' ?>">
                    <a href="warfarin_calculator.php"><i class="fas fa-pills me-2"></i> คำนวณยา Warfarin</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('dose_calc.mg_ml')): ?>
                <li class="<?= $current_page === 'mg_ml_calculator.php' ? 'active' : '' ?>">
                    <a href="mg_ml_calculator.php"><i class="fas fa-syringe me-2"></i> คำนวณ mg → mL</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('dose_calc.pediatric')): ?>
                <li class="<?= $current_page === 'pediatric_dose_calculator.php' ? 'active' : '' ?>">
                    <a href="pediatric_dose_calculator.php"><i class="fas fa-child me-2"></i> คำนวณขนาดยาในเด็ก</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if (tham_menu_can('drug_eval.j2')): ?>
        <li class="<?= $is_drug_eval_j2 ? 'active' : '' ?>">
            <a href="drug_eval_j2.php"><i class="fas fa-clipboard-list me-2"></i> ประเมินยา จ2</a>
        </li>
        <?php endif; ?>

        <?php if ($show_network_drug): ?>
        <li class="<?= $is_network_drug_active ? 'active' : '' ?>">
            <a href="#networkDrugSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_network_drug_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text">
                    <span><i class="fas fa-network-wired me-2"></i> บัญชียาเครือข่าย</span>
                    <small class="sidebar-menu-sub">ยาเครือข่ายจังหวัด</small>
                </span>
            </a>
            <ul class="collapse list-unstyled <?= $is_network_drug_active ? 'show' : '' ?>" id="networkDrugSubmenu">
                <?php if (tham_menu_can('network_drug.upload')): ?>
                <li class="<?= $current_page === 'network_drug_upload.php' ? 'active' : '' ?>">
                    <a href="network_drug_upload.php"><i class="fas fa-file-upload me-2"></i> Upload ไฟล์</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('network_drug.list')): ?>
                <li class="<?= $current_page === 'network_drug_list.php' ? 'active' : '' ?>">
                    <a href="network_drug_list.php"><i class="fas fa-table me-2"></i> รายการบัญชียาเครือข่าย</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('network_drug.refer')): ?>
                <li class="<?= in_array($current_page, ['drug_refer.php', 'drug_refer_print.php'], true) ? 'active' : '' ?>">
                    <a href="drug_refer.php"><i class="fas fa-share-square me-2"></i> Refer ยาผู้ป่วย</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('network_drug.refer_district')): ?>
                <li class="<?= $current_page === 'drug_refer_district.php' ? 'active' : '' ?>">
                    <a href="drug_refer_district.php"><i class="fas fa-map-marked-alt me-2"></i> Refer ยาแยกเขต</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('network_drug.refer_appointment')): ?>
                <li class="<?= $current_page === 'drug_refer_appointment.php' ? 'active' : '' ?>">
                    <a href="drug_refer_appointment.php"><i class="fas fa-calendar-day me-2"></i> Refer ยาแยกตามวันนัด</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('network_drug.monitor_refer_back')): ?>
                <li class="<?= in_array($current_page, ['monitor_refer_back_opd.php', 'monitor_refer_back_ipd.php', 'monitor_refer_back_interventions.php', 'monitor_refer_back_settings.php'], true) ? 'active' : '' ?>">
                    <a href="monitor_refer_back_opd.php"><i class="fas fa-bell me-2"></i> Monitor Refer Back</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if ($show_invc): ?>
        <li class="<?= $current_page === 'invc_stock.php' ? 'active' : '' ?>">
            <a href="invc_stock.php">
                <span class="sidebar-menu-text">
                    <span><i class="fas fa-boxes me-2"></i> ระบบ INVC</span>
                    <small class="sidebar-menu-sub">สต็อกคงเหลือ · Min/Max · ประวัติเบิก</small>
                </span>
            </a>
        </li>
        <?php endif; ?>

        <?php if ($show_dashboard_report): ?>
        <li class="<?= $is_dashboard_report_active ? 'active' : '' ?>">
            <a href="#dashboardReportSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_dashboard_report_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text"><i class="fas fa-file-alt me-2"></i> Dashboard รายงาน</span>
            </a>
            <ul class="collapse list-unstyled <?= $is_dashboard_report_active ? 'show' : '' ?>" id="dashboardReportSubmenu">
                <?php if (tham_menu_can('rational_lab.dashboard')): ?>
                <li class="<?= in_array($current_page, ['rational_lab_use.php', 'rational_lab_use_dashboard.php'], true) ? 'active' : '' ?>">
                    <a href="rational_lab_use_dashboard.php"><i class="fas fa-clipboard-check me-2"></i> Rational Lab Use</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('rational_lab.report')): ?>
                <li class="<?= $current_page === 'report_dashboard.php' ? 'active' : '' ?>">
                    <a href="report_dashboard.php"><i class="fas fa-layer-group me-2"></i> รายงานการใช้แยกหมวด</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('report.postal_drug')): ?>
                <li class="<?= $current_page === 'report_postal_drug.php' ? 'active' : '' ?>">
                    <a href="report_postal_drug.php"><i class="fas fa-mail-bulk me-2"></i> รายงานการรับยา ปณ.</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('report.smc_clinic')): ?>
                <li class="<?= $current_page === 'report_smc_clinic.php' ? 'active' : '' ?>">
                    <a href="report_smc_clinic.php"><i class="fas fa-clinic-medical me-2"></i> รายงาน SMC / นอกเวลา</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if ($show_deployment_map): ?>
        <li>
            <a href="<?php echo htmlspecialchars(THAM_DEPLOYMENT_MAP_URL, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener noreferrer">
                <i class="fas fa-map-marked-alt me-2"></i> รพ.ที่ใช้ THAM Hos-Safe
                <i class="fas fa-external-link-alt ms-1 small opacity-75"></i>
            </a>
        </li>
        <?php endif; ?>
        <?php if ($show_agent_download): ?>
        <li class="<?= in_array($current_page, ['alert_agent.php', 'alert_agent_file.php'], true) ? 'active' : '' ?>">
            <a href="alert_agent.php"><i class="fas fa-download me-2"></i> ดาวน์โหลด THAM Notify</a>
        </li>
        <?php endif; ?>

        <?php if ($show_admin): ?>
        <li class="<?= $is_admin_active ? 'active' : '' ?>">
            <a href="#adminSubmenu" data-bs-toggle="collapse" aria-expanded="<?= $is_admin_active ? 'true' : 'false' ?>" class="dropdown-toggle">
                <span class="sidebar-menu-text"><i class="fas fa-cog me-2"></i> ตั้งค่าระบบ</span>
            </a>
            <ul class="collapse list-unstyled <?= $is_admin_active ? 'show' : '' ?>" id="adminSubmenu">
                <?php if (tham_menu_can('admin.hosxp')): ?>
                <li class="<?= $current_page === 'hosxp_setting.php' ? 'active' : '' ?>">
                    <a href="hosxp_setting.php"><i class="fas fa-network-wired me-2"></i> เชื่อมต่อ HOSxP</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.hosxp_master') || tham_menu_can('admin.hosxp')): ?>
                <li class="<?= $current_page === 'hosxp_master_setting.php' ? 'active' : '' ?>">
                    <a href="hosxp_master_setting.php"><i class="fas fa-database me-2"></i> เชื่อมต่อ HOSxP master</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.integrations_hub') || tham_menu_can('admin.hosxp') || ($_SESSION['role'] ?? '') === 'admin'): ?>
                <li class="<?= $current_page === 'integrations_hub.php' ? 'active' : '' ?>">
                    <a href="integrations_hub.php"><i class="fas fa-plug me-2"></i> เปิด/ปิดการเชื่อมต่อ</a>
                </li>
                <?php endif; ?>
                <?php if (($_SESSION['role'] ?? '') === 'admin' || tham_menu_can('admin.data_purge')): ?>
                <li class="<?= $current_page === 'data_purge_admin.php' ? 'active' : '' ?>">
                    <a href="data_purge_admin.php"><i class="fas fa-trash-alt me-2"></i> ล้างข้อมูลปฏิบัติการ</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.alert_pipelines') || tham_menu_can('admin.hosxp') || tham_menu_can('admin.hosxp_master')): ?>
                <li class="<?= $current_page === 'alert_settings.php' ? 'active' : '' ?>">
                    <a href="alert_settings.php"><i class="fas fa-bell me-2"></i> Alert pipelines</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.alert_agents') || tham_menu_can('admin.alert_pipelines') || tham_menu_can('admin.hosxp')): ?>
                <li class="<?= $current_page === 'alert_agent_machines.php' ? 'active' : '' ?>">
                    <a href="alert_agent_machines.php"><i class="fas fa-desktop me-2"></i> เครื่อง Alert Agent</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.hosoffice') || tham_menu_can('admin.hosxp')): ?>
                <li class="<?= $current_page === 'hosoffice_setting.php' ? 'active' : '' ?>">
                    <a href="hosoffice_setting.php"><i class="fas fa-building me-2"></i> เชื่อมต่อ HOSoffice</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.jhcis') || tham_menu_can('admin.hosxp')): ?>
                <li class="<?= $current_page === 'jhcis_setting.php' ? 'active' : '' ?>">
                    <a href="jhcis_setting.php"><i class="fas fa-clinic-medical me-2"></i> เชื่อมต่อ JHCIS PCC</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.drug_viewer') || tham_menu_can('admin.hosxp')): ?>
                <li class="<?= $current_page === 'drug_viewer_setting.php' ? 'active' : '' ?>">
                    <a href="drug_viewer_setting.php"><i class="fas fa-pills me-2"></i> เชื่อมต่อ Drug Viewer</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.robot') || tham_menu_can('admin.hosxp') || tham_menu_can('pharm_care.med_error')): ?>
                <li class="<?= $current_page === 'robot_setting.php' ? 'active' : '' ?>">
                    <a href="robot_setting.php"><i class="fas fa-robot me-2"></i> เชื่อมต่อ Robot OPD</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.hapysure') || tham_menu_can('admin.hosxp')): ?>
                <li class="<?= $current_page === 'hapysure_setting.php' ? 'active' : '' ?>">
                    <a href="hapysure_setting.php"><i class="fas fa-notes-medical me-2"></i> เชื่อมต่อ HAPYsure</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.provider_id') || tham_menu_can('admin.hosxp') || ($_SESSION['role'] ?? '') === 'admin'): ?>
                <li class="<?= $current_page === 'provider_id_setting.php' ? 'active' : '' ?>">
                    <a href="provider_id_setting.php"><i class="fas fa-id-card me-2"></i> ตั้งค่า Provider ID</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.invc') || tham_menu_can('admin.hosxp')): ?>
                <li class="<?= $current_page === 'invc_setting.php' ? 'active' : '' ?>">
                    <a href="invc_setting.php"><i class="fas fa-boxes me-2"></i> เชื่อมต่อ INVC</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.hospital_ds') || tham_menu_can('admin.hosxp')): ?>
                <li class="<?= in_array($current_page, ['hospital_connect.php', 'hospital_explore.php'], true) ? 'active' : '' ?>">
                    <a href="hospital_connect.php"><i class="fas fa-hospital me-2"></i> เชื่อมต่อรพ. ต่างๆ</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.amr_connect') || tham_menu_can('admin.hosxp')): ?>
                <li class="<?= $current_page === 'amr_connect.php' ? 'active' : '' ?>">
                    <a href="amr_connect.php"><i class="fas fa-bacteria me-2"></i> เชื่อมต่อ AMR</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.warfarin_guideline') || tham_menu_can('admin.hosxp')): ?>
                <li class="<?= $current_page === 'warfarin_guideline_setting.php' ? 'active' : '' ?>">
                    <a href="warfarin_guideline_setting.php"><i class="fas fa-book-medical me-2"></i> Guideline Warfarin</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.display_mask') || tham_menu_can('admin.hosxp') || ($_SESSION['role'] ?? '') === 'admin'): ?>
                <li class="<?= $current_page === 'display_mask_setting.php' ? 'active' : '' ?>">
                    <a href="display_mask_setting.php"><i class="fas fa-eye-slash me-2"></i> ตั้งค่าแสดงยา และ Lab</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.users')): ?>
                <li class="<?= $current_page === 'users.php' ? 'active' : '' ?>">
                    <a href="users.php"><i class="fas fa-user-shield me-2"></i> จัดการผู้ใช้งาน</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.menu_permissions')): ?>
                <li class="<?= $current_page === 'menu_permissions.php' ? 'active' : '' ?>">
                    <a href="menu_permissions.php"><i class="fas fa-key me-2"></i> สิทธิ์เข้าถึงเมนู</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.upgrade')): ?>
                <li class="<?= $current_page === 'upgrade.php' ? 'active' : '' ?>">
                    <a href="upgrade.php"><i class="fas fa-rocket me-2"></i> อัปเกรดระบบ</a>
                </li>
                <?php endif; ?>
                <?php if (tham_menu_can('admin.server_health')): ?>
                <li class="<?= $current_page === 'server_health.php' ? 'active' : '' ?>">
                    <a href="server_health.php"><i class="fas fa-heartbeat me-2"></i> Monitor เซิร์ฟเวอร์</a>
                </li>
                <?php endif; ?>
                <?php if (
                    defined('THAM_LICENSE_ADMIN_ENABLED')
                    && THAM_LICENSE_ADMIN_ENABLED
                    && is_file(__DIR__ . '/admin_generate_key.php')
                    && tham_menu_can('admin.license')
                ): ?>
                <li class="<?= $current_page === 'admin_generate_key.php' ? 'active' : '' ?>">
                    <a href="admin_generate_key.php"><i class="fas fa-key me-2"></i> สร้าง License</a>
                </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>
    </ul>

    <div class="developer-credit">
        Developed by<br>
        <span class="fw-bold">Pharm. Atipol Klaipaksi</span>
    </div>
</nav>
<?php
if (isset($_SESSION['user_id'])) {
    include __DIR__ . '/update_notifier_ui.php';
    include __DIR__ . '/allergy_alert_ui.php';
    include __DIR__ . '/smart_pharma_backup_ui.php';
    include __DIR__ . '/alert_agent_push_ui.php';
}
if (strpos($current_page, 'monitor_') === 0):
?>
<script src="js/monitor_hn_focus.js"></script>
<?php endif; ?>
