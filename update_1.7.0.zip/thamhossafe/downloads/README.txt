ไฟล์โปรแกรม THAM Notify วางในโฟลเดอร์นี้

ตอนนี้ใช้:
  THAM-Notify-1.1.0.exe

สร้างใหม่จากซอร์ส:
  bash agent/build.sh 1.1.0

หน้า alert_agent.php ให้ผู้ใช้ดาวน์โหลดแล้วเปิดเอง (คล้าย SCPH Notify)
ไม่ติดตั้งเงียบจากเบราว์เซอร์

อย่าใช้ THAM-Alert-Agent-1.0.x — ชุดเก่าที่ Antivirus จับพฤติกรรม
