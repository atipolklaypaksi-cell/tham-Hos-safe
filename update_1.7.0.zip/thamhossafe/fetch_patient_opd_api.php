<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    if (($_GET['action'] ?? '') === 'photo') {
        exit;
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/patient_opd_helper.php';
require_once __DIR__ . '/hapysure_helper.php';
if (empty($_SESSION['menu_permissions_loaded']) && isset($con)) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('pharm_care.patient_opd') && ($_SESSION['role'] ?? '') !== 'admin') {
    if (($_GET['action'] ?? $_POST['action'] ?? '') === 'photo') {
        http_response_code(403);
        exit;
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
    exit;
}

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? 'lookup'));
$hn = trim((string)($_GET['hn'] ?? $_POST['hn'] ?? ''));

if ($action === 'hapysure_bind') {
    header('Content-Type: application/json; charset=utf-8');
    $user = trim((string)($_POST['username'] ?? $_GET['username'] ?? hapysure_suggest_username()));
    $pass = (string)($_POST['password'] ?? '');
    if (!hapysure_session_save_credentials($user, $pass)) {
        echo json_encode(['ok' => false, 'error' => 'กรุณากรอก user และ password ของ HAPYsure'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'ok' => true,
        'has_credentials' => true,
        'suggest_user' => hapysure_suggest_username(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

session_write_close();

if ($action === 'photo') {
    if ($hn === '') {
        http_response_code(404);
        exit;
    }
    $blob = pop_fetch_photo_any($con, $hn);
    if ($blob === null || $blob === '') {
        http_response_code(404);
        exit;
    }
    $mime = pop_photo_mime($blob);
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . strlen($blob));
    header('Cache-Control: private, max-age=300');
    header('X-Content-Type-Options: nosniff');
    echo $blob;
    exit;
}

header('Content-Type: application/json; charset=utf-8');

if ($action === 'save_qty') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['ok' => false, 'error' => 'วิธีเรียกไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $raw = file_get_contents('php://input');
    $js = json_decode((string)$raw, true);
    if (!is_array($js)) {
        $js = $_POST;
    }
    $hn_save = trim((string)($js['hn'] ?? $hn));
    $vn_save = trim((string)($js['vn'] ?? ''));
    $items = $js['items'] ?? [];
    if (!is_array($items)) {
        $items = [];
    }
    echo json_encode(pop_save_drug_qtys($con, $hn_save, $vn_save, $items), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'hapysure_launch') {
    $status = hapysure_connect_status($con);
    if (empty($status['connected'])) {
        echo json_encode([
            'ok' => false,
            'connected' => false,
            'error' => hapysure_offline_message(),
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $vn = trim((string)($_GET['vn'] ?? $_POST['vn'] ?? ''));
    $date = trim((string)($_GET['vstdate'] ?? $_GET['date'] ?? $_POST['vstdate'] ?? ''));
    if ($date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        $date = '';
    }
    $payload = hapysure_payload($con, $hn, $vn, $date);
    echo json_encode([
        'ok' => true,
        'connected' => true,
        'launch_url' => $payload['launch_url'],
        'sso_url' => $payload['sso_url'],
        'has_credentials' => !empty($payload['has_credentials']),
        'suggest_user' => $payload['suggest_user'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($hn === '') {
    echo json_encode(['ok' => false, 'error' => 'กรุณากรอก HN'], JSON_UNESCAPED_UNICODE);
    exit;
}

$vn = trim((string)($_GET['vn'] ?? $_POST['vn'] ?? ''));
$an = trim((string)($_GET['an'] ?? $_POST['an'] ?? ''));
$date = trim((string)($_GET['vstdate'] ?? $_GET['date'] ?? $_POST['vstdate'] ?? ''));
$compare_vn = trim((string)($_GET['compare_vn'] ?? $_POST['compare_vn'] ?? ''));
$compare_an = trim((string)($_GET['compare_an'] ?? $_POST['compare_an'] ?? ''));
if ($date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    $date = '';
}

$result = pop_lookup($con, $hn, $vn, $an, $date, $compare_vn, $compare_an);
if (!empty($result['ok'])) {
    $cur = $result['current'] ?? [];
    $hn_launch = (string)(($result['patient']['hn_display'] ?? '') ?: ($result['patient']['hn'] ?? $hn));
    $result['hapysure'] = hapysure_payload($con, $hn_launch, $cur['vn'] ?? $vn, $cur['vstdate'] ?? $date);
}
echo json_encode($result, JSON_UNESCAPED_UNICODE);
