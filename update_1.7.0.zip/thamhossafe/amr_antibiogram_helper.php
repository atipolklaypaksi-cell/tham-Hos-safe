<?php
/**
 * Hospital cumulative antibiogram — CLSI M39 (first isolate, n<30 suppress)
 * Interpretation S/I/R: CLSI M100 (as stored by LIS)
 * Organism / specimen panels: NARST Thailand + WHO/GLASS
 */

function amr_abg_min_n_default() {
    return 30;
}

function amr_abg_drug_catalog() {
    return [
        'AMP' => ['label' => 'Ampicillin', 'short' => 'AMP'],
        'AMC' => ['label' => 'Amox/Clav', 'short' => 'AMC'],
        'SAM' => ['label' => 'Amp/Sulb', 'short' => 'SAM'],
        'PEN' => ['label' => 'Penicillin', 'short' => 'PEN'],
        'OXA' => ['label' => 'Oxacillin', 'short' => 'OXA'],
        'FOX' => ['label' => 'Cefoxitin', 'short' => 'FOX'],
        'CZ' => ['label' => 'Cefazolin', 'short' => 'CZ'],
        'CXM' => ['label' => 'Cefuroxime', 'short' => 'CXM'],
        'CTX' => ['label' => 'Cefotaxime', 'short' => 'CTX'],
        'CRO' => ['label' => 'Ceftriaxone', 'short' => 'CRO'],
        'CAZ' => ['label' => 'Ceftazidime', 'short' => 'CAZ'],
        'FEP' => ['label' => 'Cefepime', 'short' => 'FEP'],
        'TZP' => ['label' => 'Pip/Tazo', 'short' => 'TZP'],
        'SCF' => ['label' => 'Cefoperazone/Sulb', 'short' => 'SCF'],
        'ATM' => ['label' => 'Aztreonam', 'short' => 'ATM'],
        'ETP' => ['label' => 'Ertapenem', 'short' => 'ETP'],
        'IPM' => ['label' => 'Imipenem', 'short' => 'IPM'],
        'MEM' => ['label' => 'Meropenem', 'short' => 'MEM'],
        'DOR' => ['label' => 'Doripenem', 'short' => 'DOR'],
        'GEN' => ['label' => 'Gentamicin', 'short' => 'GEN'],
        'AMK' => ['label' => 'Amikacin', 'short' => 'AMK'],
        'CIP' => ['label' => 'Ciprofloxacin', 'short' => 'CIP'],
        'LVX' => ['label' => 'Levofloxacin', 'short' => 'LVX'],
        'SXT' => ['label' => 'TMP-SMX', 'short' => 'SXT'],
        'NIT' => ['label' => 'Nitrofurantoin', 'short' => 'NIT'],
        'ERY' => ['label' => 'Erythromycin', 'short' => 'ERY'],
        'CLI' => ['label' => 'Clindamycin', 'short' => 'CLI'],
        'VAN' => ['label' => 'Vancomycin', 'short' => 'VAN'],
        'TEC' => ['label' => 'Teicoplanin', 'short' => 'TEC'],
        'LNZ' => ['label' => 'Linezolid', 'short' => 'LNZ'],
        'TGC' => ['label' => 'Tigecycline', 'short' => 'TGC'],
        'COL' => ['label' => 'Colistin', 'short' => 'COL'],
        'FOS' => ['label' => 'Fosfomycin', 'short' => 'FOS'],
        'TCY' => ['label' => 'Tetracycline', 'short' => 'TCY'],
        'RIF' => ['label' => 'Rifampicin', 'short' => 'RIF'],
        'MXF' => ['label' => 'Moxifloxacin', 'short' => 'MXF'],
        'FUS' => ['label' => 'Fusidic acid', 'short' => 'FUS'],
        'CHL' => ['label' => 'Chloramphenicol', 'short' => 'CHL'],
    ];
}

function amr_abg_report_drugs() {
    return [
        ['code' => 'PEN', 'label' => 'Penicillin', 'short' => 'Penicillin', 'group' => 'BETA-LACTAMS'],
        ['code' => 'AMP', 'label' => 'Ampicillin', 'short' => 'Ampicillin', 'group' => 'BETA-LACTAMS'],
        ['code' => 'AMC', 'label' => 'Amoxicillin/Clavulanic acid', 'short' => 'Amox/Clav', 'group' => 'BETA-LACTAMS'],
        ['code' => 'SCF', 'label' => 'Cefoperazone/Sulbactam', 'short' => 'Cefoperazone/Sulb', 'group' => 'BETA-LACTAMS'],
        ['code' => 'TZP', 'label' => 'Piperacillin/Tazobactam', 'short' => 'Pip/Tazo', 'group' => 'BETA-LACTAMS'],
        ['code' => 'CTX', 'label' => 'Cefotaxime', 'short' => 'Cefotaxime', 'group' => 'BETA-LACTAMS'],
        ['code' => 'CAZ', 'label' => 'Ceftazidime', 'short' => 'Ceftazidime', 'group' => 'BETA-LACTAMS'],
        ['code' => 'CRO', 'label' => 'Ceftriaxone', 'short' => 'Ceftriaxone', 'group' => 'BETA-LACTAMS'],
        ['code' => 'OXA', 'label' => 'Oxacillin', 'short' => 'Oxacillin', 'group' => 'BETA-LACTAMS'],
        ['code' => 'ETP', 'label' => 'Ertapenem', 'short' => 'Ertapenem', 'group' => 'CARBAPENEMS'],
        ['code' => 'MEM', 'label' => 'Meropenem', 'short' => 'Meropenem', 'group' => 'CARBAPENEMS'],
        ['code' => 'IPM', 'label' => 'Imipenem', 'short' => 'Imipenem', 'group' => 'CARBAPENEMS'],
        ['code' => 'CIP', 'label' => 'Ciprofloxacin', 'short' => 'Ciprofloxacin', 'group' => 'QUINOLONES'],
        ['code' => 'LVX', 'label' => 'Levofloxacin', 'short' => 'Levofloxacin', 'group' => 'QUINOLONES'],
        ['code' => 'AMK', 'label' => 'Amikacin', 'short' => 'Amikacin', 'group' => 'AMINOGLYCOSIDES'],
        ['code' => 'GEN', 'label' => 'Gentamicin', 'short' => 'Gentamicin', 'group' => 'AMINOGLYCOSIDES'],
        ['code' => 'VAN', 'label' => 'Vancomycin', 'short' => 'Vancomycin', 'group' => 'GLYCOPEPTIDES'],
        ['code' => 'CLI', 'label' => 'Clindamycin', 'short' => 'Clindamycin', 'group' => 'MISCELLANEOUS'],
        ['code' => 'ERY', 'label' => 'Erythromycin', 'short' => 'Erythromycin', 'group' => 'MISCELLANEOUS'],
        ['code' => 'FOS', 'label' => 'Fosfomycin', 'short' => 'Fosfomycin', 'group' => 'MISCELLANEOUS'],
        ['code' => 'SXT', 'label' => 'cotrimoxazole', 'short' => 'Cotrimoxazole', 'group' => 'MISCELLANEOUS'],
        ['code' => 'NIT', 'label' => 'Nitrofurantoin (U)', 'short' => 'Nitrofurantoin (U)', 'group' => 'MISCELLANEOUS'],
    ];
}

function amr_abg_intrinsic_map() {
    return [
        'abau' => ['PEN', 'AMP', 'ETP', 'VAN', 'CLI', 'ERY', 'NIT'],
        'acin' => ['PEN', 'AMP', 'ETP', 'VAN', 'CLI', 'ERY', 'NIT'],
        'bpse' => ['PEN', 'AMP', 'AMC', 'GEN', 'AMK', 'VAN', 'CLI', 'ERY', 'NIT'],
        'entclo' => ['PEN', 'AMP', 'AMC', 'OXA', 'VAN', 'CLI', 'ERY', 'NIT'],
        'ecoli' => ['PEN', 'OXA', 'VAN', 'CLI', 'ERY'],
        'kpneu' => ['PEN', 'AMP', 'OXA', 'VAN', 'CLI', 'ERY'],
        'sal' => ['PEN', 'OXA', 'VAN', 'CLI', 'ERY', 'NIT'],
        'shig' => ['PEN', 'OXA', 'VAN', 'CLI', 'ERY', 'NIT'],
        'pmir' => ['PEN', 'OXA', 'VAN', 'CLI', 'ERY', 'NIT'],
        'paer' => ['PEN', 'AMP', 'AMC', 'CTX', 'CRO', 'OXA', 'ETP', 'VAN', 'CLI', 'ERY', 'SXT', 'NIT'],
        'steno' => ['PEN', 'AMP', 'AMC', 'TZP', 'CTX', 'CRO', 'OXA', 'ETP', 'MEM', 'IPM', 'AMK', 'GEN', 'VAN', 'CLI', 'ERY', 'NIT'],
        'efae' => ['CTX', 'CAZ', 'CRO', 'OXA', 'CLI', 'SXT', 'AMK', 'NIT'],
        'efcm' => ['CTX', 'CAZ', 'CRO', 'OXA', 'CLI', 'SXT', 'AMK', 'NIT'],
        'cons' => ['PEN'],
        'spyog' => ['AMP', 'AMC', 'SCF', 'TZP', 'CAZ', 'OXA', 'ETP', 'MEM', 'IPM', 'CIP', 'AMK', 'GEN', 'NIT'],
        'saga' => ['AMP', 'AMC', 'SCF', 'TZP', 'CAZ', 'OXA', 'ETP', 'MEM', 'IPM', 'CIP', 'AMK', 'GEN', 'NIT'],
    ];
}

function amr_abg_organism_catalog() {
    $mk = function ($label, $pattern, $sort, $group = '', $italic = true) {
        return [
            'label' => $label,
            'short' => $label,
            'italic' => $italic,
            'group' => $group,
            'standards' => ['NARST'],
            'pattern' => $pattern,
            'sort' => $sort,
            'drugs' => [],
        ];
    };
    return [
        'abau' => $mk('A. baumannii-calcoaceticus complex', '/acinetobacter\s+(baumannii|calcoaceticus|pittii|nosocomialis)|baumannii.?calcoaceticus|\ba\.?\s*baumannii/i', 10, 'Non-fermenter'),
        'acin' => $mk('Acinetobacter spp.', '/acinetobacter/i', 20, 'Non-fermenter', false),
        'bpse' => $mk('B. pseudomallei', '/burkholderia\s+pseudomallei|pseudomonas\s+pseudomallei|\bb\.?\s*pseudomallei/i', 30, 'Non-fermenter'),
        'entclo' => $mk('E. cloacae', '/enterobacter\s+(cloacae|hormaechei|asburiae)|enterobacter\s+cloacae\s+complex|\be\.?\s*cloacae/i', 40, 'Enterobacterales'),
        'ecoli' => $mk('E. coli', '/escherichia\s+coli|\be\.?\s*coli\b/i', 50, 'Enterobacterales'),
        'steno' => $mk('S. maltophilia', '/stenotrophomonas\s+maltophilia|xanthomonas\s+maltophilia|\bs\.?\s*maltophilia/i', 60, 'Non-fermenter'),
        'kpneu' => $mk('K. pneumoniae', '/klebsiella\s+pneumoniae|\bk\.?\s*pneumoniae/i', 70, 'Enterobacterales'),
        'pmir' => $mk('P. mirabilis', '/proteus\s+mirabilis|\bp\.?\s*mirabilis/i', 80, 'Enterobacterales'),
        'paer' => $mk('P. aeruginosa', '/pseudomonas\s+aeruginosa|\bp\.?\s*aeruginosa/i', 90, 'Non-fermenter'),
        'sal' => $mk('Salmonella spp.', '/salmonella/i', 100, 'Enterobacterales', false),
        'shig' => $mk('Shigella spp.', '/shigella/i', 105, 'Enterobacterales', false),
        'vibrio' => $mk('Vibrio spp.', '/\bvibrio\b/i', 108, 'Enterobacterales', false),
        'efae' => $mk('E. faecalis', '/enterococcus\s+faecalis|\be\.?\s*faecalis/i', 110, 'Gram-positive'),
        'efcm' => $mk('E. faecium', '/enterococcus\s+faecium|\be\.?\s*faecium/i', 120, 'Gram-positive'),
        'saur' => $mk('S. aureus', '/staphylococcus\s+aureus|\bs\.?\s*aureus\b/i', 130, 'Gram-positive'),
        'cons' => $mk('CoNS', '/staphylococcus\s+(epidermidis|hominis|haemolyticus|capitis|warneri|saprophyticus|lugdunensis)|coagulase.?neg|\bcons\b/i', 150, 'Gram-positive', false),
        'spyog' => $mk('S. pyogenes', '/streptococcus\s+pyogenes|group\s*a\s*strep|\bs\.?\s*pyogenes/i', 160, 'Gram-positive'),
        'saga' => $mk('S. agalactiae', '/streptococcus\s+agalactiae|group\s*b\s*strep|\bs\.?\s*agalactiae/i', 170, 'Gram-positive'),
        'spne' => $mk('S. pneumoniae', '/streptococcus\s+pneumoniae|\bs\.?\s*pneumoniae\b/i', 180, 'Gram-positive'),
        'ssuis' => $mk('S. suis', '/streptococcus\s+suis|\bs\.?\s*suis\b/i', 190, 'Gram-positive'),
    ];
}

function amr_abg_drug_alias_map() {
    static $map = null;
    if ($map !== null) {
        return $map;
    }
    $map = [];
    $pairs = [
        'AMP' => ['AMP', 'AM', 'AP', 'AMPICILLIN'],
        'AMC' => ['AMC', 'AUG', 'AUGMENTIN', 'AMOXICILCLAV', 'AMOXICILLCLAV', 'AMOXICILLINCLAVULANATE', 'AMOXICILLINCLAVULANICACID', 'AMOXICILLINCLAVU'],
        'SAM' => ['SAM', 'UNASYN', 'AMPICILLINSULBACTAM', 'AMPICILLSULB'],
        'PEN' => ['PEN', 'PG', 'P', 'PENICILLIN', 'PENICILLING', 'BENZYLPENICILLIN'],
        'OXA' => ['OXA', 'OX', 'OXACILLIN', 'METHICILLIN'],
        'FOX' => ['FOX', 'CEFOXITIN'],
        'CZ' => ['CZ', 'KZ', 'CFZ', 'CEFAZOLIN'],
        'CXM' => ['CXM', 'CEFUROXIME', 'ZINACEF', 'ZINNAT'],
        'CTX' => ['CTX', 'CEFOTAXIME', 'CLAFORAN'],
        'CRO' => ['CRO', 'CTR', 'CEFTRIAXONE', 'ROCEPHIN'],
        'CAZ' => ['CAZ', 'CEFTAZIDIME', 'FORTUM'],
        'FEP' => ['FEP', 'CEFEPIME', 'MAXIPIME'],
        'TZP' => ['TZP', 'PIPTAZ', 'TAZOCIN', 'PIPERACITAZO', 'PIPERACILLINTAZOBACTAM', 'PIPERACILLINTAZOBAC'],
        'SCF' => ['SCF', 'SULPERAZON', 'CEFOPERASULB', 'CEFOPERAZONESULBACTAM'],
        'ATM' => ['ATM', 'AZTREONAM', 'AZACTAM'],
        'ETP' => ['ETP', 'ERTAPENEM', 'INVANZ'],
        'IPM' => ['IPM', 'IP', 'IMIPENEM', 'TIENAM'],
        'MEM' => ['MEM', 'MEROPENEM', 'MERONEM'],
        'DOR' => ['DOR', 'DORIPENEM'],
        'GEN' => ['GEN', 'GM', 'CN', 'GENTAMICIN', 'GENTAMYCIN'],
        'AMK' => ['AMK', 'AK', 'AMI', 'AMIKACIN'],
        'CIP' => ['CIP', 'CFX', 'CIPROFLOXACIN', 'CIPROBAY'],
        'LVX' => ['LVX', 'LEV', 'LEVOFLOXACIN', 'CRAVIT', 'LEVOXIN'],
        'SXT' => ['SXT', 'SXTMP', 'COT', 'BACTRIM', 'COTRIMOXAZOLE', 'TRIMETHOSULFA', 'TRIMETHOPRIMSULFA', 'TRIMETHOPRIMSULFAMETHOXAZOLE', 'SULFAMETHOXAZ'],
        'NIT' => ['NIT', 'NITROFURANTOIN', 'NITROFURANTO', 'MACRODANTIN'],
        'ERY' => ['ERY', 'E', 'ERYTHROMYCIN'],
        'CLI' => ['CLI', 'DA', 'CM', 'CLINDAMYCIN', 'DALACIN'],
        'VAN' => ['VAN', 'VA', 'VANCOMYCIN', 'VANCOCIN'],
        'TEC' => ['TEC', 'TCO', 'TEICOPLANIN', 'TARGOCID'],
        'LNZ' => ['LNZ', 'LZD', 'LINEZOLID', 'ZYVOX'],
        'TGC' => ['TGC', 'TIGECYCLINE', 'TYGACIL'],
        'COL' => ['COL', 'CL', 'CS', 'COLISTIN', 'POLYMYXINE', 'POLYMYXINB', 'PB'],
        'FOS' => ['FOS', 'FOSFOMYCIN'],
        'TCY' => ['TCY', 'T', 'TE', 'TETRACYCLINE'],
        'RIF' => ['RIF', 'RA', 'RD', 'RIFAMPICIN', 'RIFAMPIN'],
        'MXF' => ['MXF', 'MXX', 'MOXIFLOXACIN', 'AVELOX'],
        'FUS' => ['FUS', 'FA', 'FUSIDICACID', 'FUCIDIN'],
        'CHL' => ['CHL', 'C', 'CHLORAMPHENICOL', 'CHLORAMPHENIC'],
    ];
    foreach ($pairs as $code => $aliases) {
        foreach ($aliases as $a) {
            $map[strtolower($a)] = $code;
        }
    }
    return $map;
}

function amr_abg_norm_key($s) {
    return strtolower(preg_replace('/[^a-z0-9]+/i', '', (string)$s));
}

function amr_abg_map_drug($name) {
    $raw = trim((string)$name);
    if ($raw === '') {
        return '';
    }
    if (function_exists('amr_sens_ast_expand_name')) {
        $raw = amr_sens_ast_expand_name($raw);
    }
    $up = strtoupper($raw);
    $cat = amr_abg_drug_catalog();
    if (isset($cat[$up])) {
        return $up;
    }
    $key = amr_abg_norm_key($raw);
    $alias = amr_abg_drug_alias_map();
    if (isset($alias[$key])) {
        return $alias[$key];
    }
    if (strlen($key) >= 6) {
        foreach ($alias as $ak => $code) {
            if (strlen($ak) < 6) {
                continue;
            }
            if (strpos($key, $ak) === 0 || strpos($ak, $key) === 0) {
                return $code;
            }
        }
    }
    return '';
}

function amr_abg_sir($raw) {
    $s = strtoupper(trim((string)$raw));
    if ($s === '' || $s === '-' || $s === '.' || $s === 'ND' || $s === 'NA' || $s === 'NT') {
        return '';
    }
    if (strpos($s, 'SDD') !== false) {
        return 'I';
    }
    if ($s === 'NS' || strpos($s, 'NONSUSCEPT') !== false) {
        return 'R';
    }
    if (preg_match('/\b([SIR])\b/', $s, $m)) {
        return $m[1];
    }
    $c = substr($s, 0, 1);
    return in_array($c, ['S', 'I', 'R'], true) ? $c : '';
}

function amr_abg_match_organism($name) {
    $t = trim((string)$name);
    if ($t === '') {
        return null;
    }
    if (preg_match('/no\s*growth|ไม่พบเชื้อ|ไม่พบแบคทีเรีย|no\s*organism|sterile|ปกติ|normal\s*flora|mixed\s*growth|contaminant/i', $t)) {
        return null;
    }
    foreach (amr_abg_organism_catalog() as $key => $row) {
        if (preg_match($row['pattern'], $t)) {
            return $key;
        }
    }
    return '';
}

function amr_abg_specimen_class($spec) {
    $s = strtolower(trim((string)$spec));
    if ($s === '') {
        return 'other';
    }
    if (preg_match('/blood|hemoculture|haemoculture|\bh\/c\b|bactec|เลือด|hemocul/i', $s)) {
        return 'blood';
    }
    if (preg_match('/csf|cerebrospinal|น้ำไขสันหลัง/i', $s)) {
        return 'csf';
    }
    if (preg_match('/stool|feces|faeces|rectal|อุจจาระ|rectum/i', $s)) {
        return 'stool';
    }
    if (preg_match('/urin|ปัสสาวะ|\bmsu\b|\bcled\b/i', $s)) {
        return 'urine';
    }
    if (preg_match('/sputum|เสมหะ|tracheal|endotrach|\bett\b|\bbal\b|bronch|aspirat|respiratory|ทางเดินหายใจ/i', $s)) {
        return 'respiratory';
    }
    if (preg_match('/pus|wound|หนอง|แผล|abscess|discharge|tissue|swab/i', $s)) {
        return 'pus';
    }
    return 'other';
}

function amr_abg_hn($hn) {
    $d = preg_replace('/\D+/', '', (string)$hn);
    if ($d === '' || preg_match('/^0+$/', $d)) {
        return '';
    }
    return str_pad(substr($d, -9), 9, '0', STR_PAD_LEFT);
}

function amr_abg_ymd($value) {
    $s = trim((string)$value);
    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $s, $m)) {
        return $m[1] . '-' . $m[2] . '-' . $m[3];
    }
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $s, $m)) {
        return sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[2], (int)$m[1]);
    }
    $ts = strtotime($s);
    return $ts ? date('Y-m-d', $ts) : '';
}

function amr_abg_parse_ast_list(array $items) {
    $out = [];
    foreach ($items as $drug => $sir) {
        if (is_array($sir)) {
            $drug = $sir['drug'] ?? '';
            $sir = $sir['sir'] ?? '';
        }
        $code = amr_abg_map_drug($drug);
        $cat = amr_abg_sir($sir);
        if ($code === '' || $cat === '') {
            continue;
        }
        $prev = $out[$code] ?? '';
        if ($prev === '' || ($cat === 'R') || ($cat === 'I' && $prev === 'S')) {
            $out[$code] = $cat;
        }
    }
    return $out;
}

function amr_abg_collect_mlab($con, $start, $end) {
    if (function_exists('amr_mlab_ensure_tables')) {
        amr_mlab_ensure_tables($con);
    }
    $start_esc = mysqli_real_escape_string($con, $start);
    $end_esc = mysqli_real_escape_string($con, $end);
    $labs = [];
    $sql = "SELECT lab_key, hn, an, specimen, organism, order_date, report_date
            FROM amr_mlab_lab
            WHERE COALESCE(order_date, report_date) BETWEEN '$start_esc' AND '$end_esc'";
    $q = mysqli_query($con, $sql);
    if (!$q) {
        return ['error' => mysqli_error($con), 'isolates' => []];
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $k = (string)($r['lab_key'] ?? '');
        if ($k === '') {
            continue;
        }
        $r['ast'] = [];
        $labs[$k] = $r;
    }
    if (empty($labs)) {
        return ['error' => '', 'isolates' => []];
    }
    $aq = mysqli_query($con, "SELECT a.lab_key, a.organism, a.drug, a.sir
        FROM amr_mlab_ast a
        INNER JOIN amr_mlab_lab l ON l.lab_key = a.lab_key
        WHERE COALESCE(l.order_date, l.report_date) BETWEEN '$start_esc' AND '$end_esc'");
    if ($aq) {
        while ($a = mysqli_fetch_assoc($aq)) {
            $k = (string)($a['lab_key'] ?? '');
            if (!isset($labs[$k]) || trim((string)($a['drug'] ?? '')) === '') {
                continue;
            }
            $labs[$k]['ast'][] = $a;
        }
    }
    $isolates = [];
    foreach ($labs as $lab_key => $lab) {
        $organism = trim((string)($lab['organism'] ?? ''));
        if ($organism === '') {
            foreach ($lab['ast'] ?? [] as $a) {
                $o = trim((string)($a['organism'] ?? ''));
                if ($o !== '') {
                    $organism = $o;
                    break;
                }
            }
        }
        $org_key = amr_abg_match_organism($organism);
        if ($org_key === null) {
            continue;
        }
        $ast = amr_abg_parse_ast_list($lab['ast'] ?? []);
        if (empty($ast)) {
            continue;
        }
        $od = amr_abg_ymd($lab['report_date'] ?? '');
        if ($od === '') {
            $od = amr_abg_ymd($lab['order_date'] ?? '');
        }
        $an = preg_replace('/\D+/', '', (string)($lab['an'] ?? ''));
        $origin = ($an !== '' && !preg_match('/^0+$/', $an)) ? 'ipd' : 'opd';
        $isolates[] = [
            'id' => (string)$lab_key,
            'hn' => amr_abg_hn($lab['hn'] ?? ''),
            'date' => $od,
            'specimen' => trim((string)($lab['specimen'] ?? '')),
            'spec_class' => amr_abg_specimen_class($lab['specimen'] ?? ''),
            'origin' => $origin,
            'org_key' => $org_key,
            'org_raw' => $organism,
            'ast' => $ast,
        ];
    }
    return ['error' => '', 'isolates' => $isolates];
}

function amr_abg_collect_hosxp($con, $start, $end) {
    if (!function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    }
    if (!function_exists('amr_amass_fetch_microbiology')) {
        require_once __DIR__ . '/amr_amass_helper.php';
    }
    $hos = hosxp_connect($con, 120);
    if ($hos && function_exists('hosxp_extend_read_timeout')) {
        hosxp_extend_read_timeout($hos, 180);
    }
    $fetched = amr_amass_fetch_microbiology($hos, $con, $start, $end);
    if (!empty($fetched['error'])) {
        return ['error' => $fetched['error'], 'isolates' => []];
    }
    $skip_cols = ['HN9_HIS' => 1, 'DATE_DATA' => 1, 'CDATE' => 1, 'SPECIMEN' => 1, 'CSOURCE' => 1, 'CRESULT' => 1];
    $isolates = [];
    $i = 0;
    foreach ($fetched['rows'] as $row) {
        $organism = trim((string)($row['CRESULT'] ?? ''));
        $org_key = amr_abg_match_organism($organism);
        if ($org_key === null) {
            continue;
        }
        $ast_in = [];
        foreach ($row as $k => $v) {
            if (isset($skip_cols[$k])) {
                continue;
            }
            $ast_in[] = ['drug' => $k, 'sir' => $v];
        }
        $ast = amr_abg_parse_ast_list($ast_in);
        if (empty($ast)) {
            continue;
        }
        $i++;
        $isolates[] = [
            'id' => 'h' . $i,
            'hn' => amr_abg_hn($row['HN9_HIS'] ?? ''),
            'date' => amr_abg_ymd($row['DATE_DATA'] ?? ($row['CDATE'] ?? '')),
            'specimen' => trim((string)($row['SPECIMEN'] ?? '')),
            'spec_class' => amr_abg_specimen_class($row['SPECIMEN'] ?? ''),
            'origin' => 'unk',
            'org_key' => $org_key,
            'org_raw' => $organism,
            'ast' => $ast,
        ];
    }
    return ['error' => '', 'isolates' => $isolates];
}

function amr_abg_first_isolates(array $isolates) {
    usort($isolates, function ($a, $b) {
        $da = (string)($a['date'] ?? '');
        $db = (string)($b['date'] ?? '');
        if ($da !== $db) {
            return strcmp($da, $db);
        }
        return strcmp((string)($a['id'] ?? ''), (string)($b['id'] ?? ''));
    });
    $seen = [];
    $out = [];
    foreach ($isolates as $iso) {
        $org = (string)($iso['org_key'] ?? '');
        if ($org === '') {
            $org = 'other:' . amr_abg_norm_key($iso['org_raw'] ?? '');
        }
        $hn = (string)($iso['hn'] ?? '');
        $key = ($hn !== '' ? $hn : ('id:' . ($iso['id'] ?? ''))) . '|' . $org;
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $iso['org_key'] = $org;
        $out[] = $iso;
    }
    return $out;
}

function amr_abg_filter_isolates(array $isolates, array $opts) {
    $specimen = (string)($opts['specimen'] ?? 'all');
    $origin = (string)($opts['origin'] ?? 'all');
    $out = [];
    foreach ($isolates as $iso) {
        $sc = $iso['spec_class'] ?? 'other';
        if ($specimen === 'blood' && $sc !== 'blood') {
            continue;
        }
        if ($specimen === 'urine' && $sc !== 'urine') {
            continue;
        }
        if (($specimen === 'respiratory' || $specimen === 'sputum') && $sc !== 'respiratory') {
            continue;
        }
        if ($specimen === 'stool' && $sc !== 'stool') {
            continue;
        }
        if ($specimen === 'sterile' && !in_array($sc, ['blood', 'csf'], true)) {
            continue;
        }
        if ($origin === 'ipd' && ($iso['origin'] ?? '') !== 'ipd') {
            continue;
        }
        if ($origin === 'opd' && ($iso['origin'] ?? '') !== 'opd') {
            continue;
        }
        $out[] = $iso;
    }
    return $out;
}

function amr_abg_cell_pct($s, $i, $r, $metric) {
    $n = $s + $i + $r;
    if ($n <= 0) {
        return null;
    }
    if ($metric === 'R') {
        return round(100.0 * $r / $n, 1);
    }
    if ($metric === 'NS') {
        return round(100.0 * ($i + $r) / $n, 1);
    }
    return round(100.0 * $s / $n, 2);
}

function amr_abg_phenotype_defs() {
    return [
        [
            'id' => 'mrsa',
            'label' => 'MRSA',
            'detail' => 'S. aureus ที่ Oxacillin หรือ Cefoxitin = R (ตัวแทน methicillin-resistant ตาม CLSI M100)',
            'orgs' => ['saur'],
            'rule' => 'any_r',
            'drugs' => ['OXA', 'FOX'],
        ],
        [
            'id' => '3gc_ns',
            'label' => '3GC-NS',
            'detail' => 'E. coli / K. pneumoniae ที่ Cefotaxime, Ceftriaxone หรือ Ceftazidime = R (ตัวแทน 3rd-generation cephalosporin non-susceptible — NARST/GLASS)',
            'orgs' => ['ecoli', 'kpneu'],
            'rule' => 'any_r',
            'drugs' => ['CTX', 'CRO', 'CAZ'],
        ],
        [
            'id' => 'cre',
            'label' => 'CRE',
            'detail' => 'Enterobacterales ที่ Ertapenem, Imipenem, Meropenem หรือ Doripenem = R',
            'orgs' => ['ecoli', 'kpneu', 'entclo', 'pmir'],
            'rule' => 'any_r',
            'drugs' => ['ETP', 'IPM', 'MEM', 'DOR'],
        ],
        [
            'id' => 'crab',
            'label' => 'CRAB',
            'detail' => 'A. baumannii ที่ Imipenem, Meropenem หรือ Doripenem = R',
            'orgs' => ['abau'],
            'rule' => 'any_r',
            'drugs' => ['IPM', 'MEM', 'DOR'],
        ],
        [
            'id' => 'crpa',
            'label' => 'CRPA',
            'detail' => 'P. aeruginosa ที่ Imipenem, Meropenem หรือ Doripenem = R',
            'orgs' => ['paer'],
            'rule' => 'any_r',
            'drugs' => ['IPM', 'MEM', 'DOR'],
        ],
        [
            'id' => 'vre',
            'label' => 'VRE',
            'detail' => 'Enterococcus ที่ Vancomycin = R',
            'orgs' => ['efae', 'efcm'],
            'rule' => 'any_r',
            'drugs' => ['VAN'],
        ],
    ];
}

function amr_abg_sheet_defs() {
    return [
        'all' => ['key' => 'all', 'title' => 'All Specimen', 'title_th' => 'ทุก specimen'],
        'blood' => ['key' => 'blood', 'title' => 'Blood-Hemoculture', 'title_th' => 'เลือด'],
        'urine' => ['key' => 'urine', 'title' => 'Urine', 'title_th' => 'ปัสสาวะ'],
        'respiratory' => ['key' => 'respiratory', 'title' => 'Respiratory Tract', 'title_th' => 'ทางเดินหายใจ'],
        'stool' => ['key' => 'stool', 'title' => 'Stool', 'title_th' => 'อุจจาระ'],
    ];
}

function amr_abg_period_en($start, $end) {
    $mon = [1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'];
    $ts = strtotime($start);
    $te = strtotime($end);
    $a = ($mon[(int)date('n', $ts)] ?? '') . '. ' . date('Y', $ts);
    $b = ($mon[(int)date('n', $te)] ?? '') . '. ' . date('Y', $te);
    return $a . '– ' . $b;
}

function amr_abg_is_mrsa(array $iso) {
    $ast = $iso['ast'] ?? [];
    return (($ast['OXA'] ?? '') === 'R') || (($ast['FOX'] ?? '') === 'R');
}

function amr_abg_make_cells($org_key, $n, array $counts, $min_n, $metric) {
    $intr = amr_abg_intrinsic_map()[$org_key] ?? [];
    $cells = [];
    foreach (amr_abg_report_drugs() as $d) {
        $code = $d['code'];
        if (in_array($code, $intr, true)) {
            $cells[$code] = [
                's' => 0, 'i' => 0, 'r' => 0, 'n' => 0,
                'pct' => null, 'suppressed' => false, 'intrinsic' => true, 'mark' => 'R',
            ];
            continue;
        }
        $c = $counts[$code] ?? ['S' => 0, 'I' => 0, 'R' => 0];
        $tn = $c['S'] + $c['I'] + $c['R'];
        if ($tn <= 0) {
            $cells[$code] = [
                's' => 0, 'i' => 0, 'r' => 0, 'n' => 0,
                'pct' => null, 'suppressed' => true, 'intrinsic' => false, 'mark' => 'r',
            ];
            continue;
        }
        $ok = ($n >= $min_n && $tn >= $min_n);
        $cells[$code] = [
            's' => $c['S'],
            'i' => $c['I'],
            'r' => $c['R'],
            'n' => $tn,
            'pct' => $ok ? amr_abg_cell_pct($c['S'], $c['I'], $c['R'], $metric) : null,
            'suppressed' => !$ok,
            'intrinsic' => false,
            'mark' => $ok ? '' : 'r',
        ];
    }
    return $cells;
}

function amr_abg_sheet_from_isolates(array $used, $min_n, $metric, $include_other) {
    $org_cat = amr_abg_organism_catalog();
    $by_org = [];
    $mrsa = ['n' => 0, 'cells' => []];
    foreach ($used as $iso) {
        $ok = (string)($iso['org_key'] ?? '');
        if ($ok === '' || strpos($ok, 'other:') === 0 || !isset($org_cat[$ok])) {
            if (!$include_other) {
                continue;
            }
            if ($ok === '' || !isset($org_cat[$ok])) {
                $ok = 'other:' . amr_abg_norm_key($iso['org_raw'] ?? 'unknown');
            }
        }
        if (!isset($by_org[$ok])) {
            $by_org[$ok] = ['n' => 0, 'cells' => [], 'raw' => $iso['org_raw'] ?? ''];
        }
        $by_org[$ok]['n']++;
        foreach ($iso['ast'] as $code => $sir) {
            if (!isset($by_org[$ok]['cells'][$code])) {
                $by_org[$ok]['cells'][$code] = ['S' => 0, 'I' => 0, 'R' => 0];
            }
            $by_org[$ok]['cells'][$code][$sir]++;
        }
        if ($ok === 'saur' && amr_abg_is_mrsa($iso)) {
            $mrsa['n']++;
            foreach ($iso['ast'] as $code => $sir) {
                if (!isset($mrsa['cells'][$code])) {
                    $mrsa['cells'][$code] = ['S' => 0, 'I' => 0, 'R' => 0];
                }
                $mrsa['cells'][$code][$sir]++;
            }
        }
    }

    $rows = [];
    foreach ($org_cat as $ok => $meta) {
        if (!isset($by_org[$ok])) {
            continue;
        }
        $n = (int)$by_org[$ok]['n'];
        $rows[] = [
            'key' => $ok,
            'label' => $meta['label'],
            'short' => $meta['short'],
            'italic' => !empty($meta['italic']),
            'group' => $meta['group'],
            'n' => $n,
            'reportable' => ($n >= $min_n),
            'cells' => amr_abg_make_cells($ok, $n, $by_org[$ok]['cells'], $min_n, $metric),
        ];
        if ($ok === 'saur' && $mrsa['n'] > 0) {
            $rows[] = [
                'key' => 'mrsa',
                'label' => 'MRSA',
                'short' => 'MRSA',
                'italic' => false,
                'group' => 'Gram-positive',
                'n' => $mrsa['n'],
                'reportable' => ($mrsa['n'] >= $min_n),
                'cells' => amr_abg_make_cells('saur', $mrsa['n'], $mrsa['cells'], $min_n, $metric),
            ];
        }
    }
    if ($include_other) {
        foreach ($by_org as $ok => $bucket) {
            if (isset($org_cat[$ok])) {
                continue;
            }
            $n = (int)$bucket['n'];
            $label = trim((string)$bucket['raw']);
            $rows[] = [
                'key' => $ok,
                'label' => $label !== '' ? $label : $ok,
                'short' => $label !== '' ? $label : $ok,
                'italic' => true,
                'group' => 'อื่นๆ',
                'n' => $n,
                'reportable' => ($n >= $min_n),
                'cells' => amr_abg_make_cells('', $n, $bucket['cells'], $min_n, $metric),
            ];
        }
    }
    $sup = 0;
    foreach ($rows as $r) {
        if (empty($r['reportable'])) {
            $sup++;
        }
    }
    return ['rows' => $rows, 'used' => count($used), 'suppressed_orgs' => $sup];
}

function amr_abg_filter_date(array $isolates, $start, $end) {
    $out = [];
    foreach ($isolates as $iso) {
        $d = (string)($iso['date'] ?? '');
        if ($d === '' || $d < $start || $d > $end) {
            continue;
        }
        $out[] = $iso;
    }
    return $out;
}

function amr_abg_phenotypes_from_isolates(array $used, $min_n) {
    $phenos = [];
    foreach (amr_abg_phenotype_defs() as $def) {
        $num = 0;
        $den = 0;
        foreach ($used as $iso) {
            if (!in_array($iso['org_key'], $def['orgs'], true)) {
                continue;
            }
            $tested = false;
            $hit = false;
            foreach ($def['drugs'] as $d) {
                if (!isset($iso['ast'][$d])) {
                    continue;
                }
                $tested = true;
                if ($iso['ast'][$d] === 'R') {
                    $hit = true;
                }
            }
            if (!$tested) {
                continue;
            }
            $den++;
            if ($hit) {
                $num++;
            }
        }
        $phenos[] = [
            'id' => $def['id'],
            'label' => $def['label'],
            'detail' => $def['detail'],
            'n' => $num,
            'd' => $den,
            'pct' => ($den >= $min_n && $den > 0) ? round(100.0 * $num / $den, 1) : null,
            'suppressed' => ($den < $min_n),
        ];
    }
    return $phenos;
}

function amr_abg_spec_counts(array $used) {
    $spec_counts = ['blood' => 0, 'urine' => 0, 'respiratory' => 0, 'stool' => 0, 'csf' => 0, 'pus' => 0, 'other' => 0];
    foreach ($used as $iso) {
        $sc = $iso['spec_class'] ?? 'other';
        if (!isset($spec_counts[$sc])) {
            $sc = 'other';
        }
        $spec_counts[$sc]++;
    }
    return $spec_counts;
}

function amr_abg_trend_pairs() {
    return [
        ['org' => 'ecoli', 'drugs' => ['CRO', 'CIP', 'AMC', 'TZP', 'MEM', 'GEN', 'SXT', 'NIT']],
        ['org' => 'kpneu', 'drugs' => ['CRO', 'CIP', 'TZP', 'MEM', 'ETP', 'GEN', 'SXT']],
        ['org' => 'paer', 'drugs' => ['CAZ', 'TZP', 'MEM', 'IPM', 'CIP', 'AMK']],
        ['org' => 'abau', 'drugs' => ['MEM', 'IPM', 'CIP', 'AMK', 'SCF']],
        ['org' => 'saur', 'drugs' => ['OXA', 'CLI', 'ERY', 'SXT', 'VAN']],
        ['org' => 'efae', 'drugs' => ['AMP', 'VAN']],
        ['org' => 'efcm', 'drugs' => ['AMP', 'VAN']],
    ];
}

function amr_abg_year_windows($end, $n = 3) {
    $end_y = (int)substr((string)$end, 0, 4);
    if ($end_y < 2000) {
        $end_y = (int)date('Y');
    }
    $n = max(2, min(5, (int)$n));
    $out = [];
    for ($y = $end_y - $n + 1; $y <= $end_y; $y++) {
        $ys = sprintf('%04d-01-01', $y);
        $ye = sprintf('%04d-12-31', $y);
        if ($ye > $end) {
            $ye = $end;
        }
        $out[] = [
            'year' => $y,
            'start' => $ys,
            'end' => $ye,
            'partial' => ($ye < sprintf('%04d-12-31', $y)),
        ];
    }
    return $out;
}

function amr_abg_cell_lookup(array $rows, $org_key, $drug) {
    foreach ($rows as $row) {
        if (($row['key'] ?? '') !== $org_key) {
            continue;
        }
        return $row['cells'][$drug] ?? null;
    }
    return null;
}

function amr_abg_dir_from_delta($delta, $worse_if_up = false) {
    if ($delta === null) {
        return 'na';
    }
    $abs = abs($delta);
    if ($abs < 5) {
        return 'flat';
    }
    $up = $delta > 0;
    if ($worse_if_up) {
        return $up ? 'worse' : 'better';
    }
    return $up ? 'better' : 'worse';
}

function amr_abg_build_compare(array $year_packs, $metric) {
    $years = [];
    foreach ($year_packs as $yp) {
        $years[] = (int)$yp['year'];
    }
    $first_y = $years[0];
    $last_y = $years[count($years) - 1];
    $drug_lab = [];
    foreach (amr_abg_report_drugs() as $d) {
        $drug_lab[$d['code']] = $d['short'];
    }
    $org_cat = amr_abg_organism_catalog();

    $pairs = [];
    foreach (amr_abg_trend_pairs() as $tp) {
        $ok = $tp['org'];
        $olabel = $org_cat[$ok]['label'] ?? $ok;
        foreach ($tp['drugs'] as $code) {
            $by = [];
            $usable = [];
            foreach ($year_packs as $yp) {
                $y = (int)$yp['year'];
                $cell = amr_abg_cell_lookup($yp['rows'], $ok, $code);
                if (!$cell || !empty($cell['intrinsic'])) {
                    $by[$y] = ['pct' => null, 'n' => 0, 'mark' => !empty($cell['intrinsic']) ? 'R' : 'r'];
                    continue;
                }
                $by[$y] = [
                    'pct' => $cell['pct'],
                    'n' => (int)($cell['n'] ?? 0),
                    'mark' => (string)($cell['mark'] ?? ''),
                ];
                if ($cell['pct'] !== null) {
                    $usable[$y] = (float)$cell['pct'];
                }
            }
            $delta = null;
            if (isset($usable[$first_y], $usable[$last_y])) {
                $delta = round($usable[$last_y] - $usable[$first_y], 1);
            }
            $pairs[] = [
                'org_key' => $ok,
                'org_label' => $olabel,
                'drug' => $code,
                'drug_label' => $drug_lab[$code] ?? $code,
                'by_year' => $by,
                'delta' => $delta,
                'dir' => amr_abg_dir_from_delta($delta, $metric !== 'S'),
            ];
        }
    }

    $phenos = [];
    $pheno_index = [];
    foreach ($year_packs as $yp) {
        foreach ($yp['phenotypes'] as $p) {
            $id = $p['id'];
            if (!isset($pheno_index[$id])) {
                $pheno_index[$id] = [
                    'id' => $id,
                    'label' => $p['label'],
                    'detail' => $p['detail'],
                    'by_year' => [],
                ];
            }
            $pheno_index[$id]['by_year'][$yp['year']] = [
                'pct' => $p['pct'],
                'n' => $p['n'],
                'd' => $p['d'],
                'suppressed' => !empty($p['suppressed']),
            ];
        }
    }
    foreach ($pheno_index as $id => $row) {
        $a = $row['by_year'][$first_y]['pct'] ?? null;
        $b = $row['by_year'][$last_y]['pct'] ?? null;
        $delta = ($a !== null && $b !== null) ? round($b - $a, 1) : null;
        $row['delta'] = $delta;
        $row['dir'] = amr_abg_dir_from_delta($delta, true);
        $phenos[] = $row;
    }

    $analysis = amr_abg_analyze($year_packs, $pairs, $phenos, $metric);
    $meta_years = [];
    foreach ($year_packs as $yp) {
        $meta_years[] = [
            'year' => $yp['year'],
            'start' => $yp['start'],
            'end' => $yp['end'],
            'partial' => !empty($yp['partial']),
            'used_isolates' => $yp['used_isolates'],
            'period_en' => amr_abg_period_en($yp['start'], $yp['end']),
        ];
    }
    return [
        'years' => $years,
        'year_meta' => $meta_years,
        'pairs' => $pairs,
        'phenotypes' => $phenos,
        'analysis' => $analysis,
    ];
}

function amr_abg_analyze(array $year_packs, array $pairs, array $phenos, $metric) {
    $n = count($year_packs);
    $first = $year_packs[0];
    $last = $year_packs[$n - 1];
    $y0 = (int)$first['year'];
    $y1 = (int)$last['year'];
    $be = (int)$y0 + 543;
    $bl = (int)$y1 + 543;
    $headline = 'บทวิเคราะห์ Antibiogram ย้อนหลัง ' . $n . ' ปีปฏิทิน (พ.ศ. ' . $be . '–' . $bl . ')';

    $bullets = [];
    $counts = [];
    foreach ($year_packs as $yp) {
        $counts[] = 'ปี ' . $yp['year'] . ' ' . number_format((int)$yp['used_isolates']) . ' ราย' . (!empty($yp['partial']) ? ' (ยังไม่ครบปี)' : '');
    }
    $bullets[] = 'จำนวน first isolate: ' . implode(' · ', $counts);

    $worse = [];
    $better = [];
    foreach ($pairs as $p) {
        if ($p['delta'] === null) {
            continue;
        }
        if ($p['dir'] === 'worse' && abs($p['delta']) >= 10) {
            $worse[] = $p;
        }
        if ($p['dir'] === 'better' && abs($p['delta']) >= 10) {
            $better[] = $p;
        }
    }
    usort($worse, function ($a, $b) {
        return abs($b['delta']) <=> abs($a['delta']);
    });
    usort($better, function ($a, $b) {
        return abs($b['delta']) <=> abs($a['delta']);
    });

    $fmt_pair = function ($p) use ($y0, $y1) {
        $a = $p['by_year'][$y0]['pct'] ?? null;
        $b = $p['by_year'][$y1]['pct'] ?? null;
        $sign = $p['delta'] > 0 ? '+' : '';
        return $p['org_label'] . ' ต่อ ' . $p['drug_label'] . ' จาก ' . number_format((float)$a, 1) . '% เป็น ' . number_format((float)$b, 1) . '% (' . $sign . $p['delta'] . ' จุด)';
    };

    if ($metric === 'S') {
        if ($worse) {
            $bits = array_map($fmt_pair, array_slice($worse, 0, 6));
            $bullets[] = 'ความไว (%S) ลดลงชัดเจน ≥ 10 จุดเปอร์เซ็นต์: ' . implode('; ', $bits);
        } else {
            $bullets[] = 'ไม่มีคู่เชื้อ–ยาในชุดเฝ้าระวังที่ %S ลดลง ≥ 10 จุด เมื่อเทียบปีแรกกับปีล่าสุด (นับเฉพาะช่องที่ n ≥ 30 ทั้งสองปี)';
        }
        if ($better) {
            $bits = array_map($fmt_pair, array_slice($better, 0, 4));
            $bullets[] = 'ความไวดีขึ้น ≥ 10 จุด: ' . implode('; ', $bits);
        }
        $below80 = [];
        foreach ($pairs as $p) {
            $b = $p['by_year'][$y1]['pct'] ?? null;
            $a = $p['by_year'][$y0]['pct'] ?? null;
            if ($b === null) {
                continue;
            }
            if ($b < 80 && ($a === null || $a >= 80 || $b < $a)) {
                $below80[] = $p['org_label'] . '–' . $p['drug_label'] . ' (' . number_format((float)$b, 1) . '%)';
            }
        }
        if ($below80) {
            $bullets[] = 'ยาที่ %S ปีล่าสุดต่ำกว่า 80% (เกณฑ์ที่ใช้เป็น empiric therapy ได้จำกัด): ' . implode(', ', array_slice($below80, 0, 10));
        }
    } else {
        if ($worse) {
            $bits = array_map($fmt_pair, array_slice($worse, 0, 6));
            $bullets[] = 'อัตราดื้อเพิ่มขึ้น ≥ 10 จุด: ' . implode('; ', $bits);
        }
    }

    $ph_bits = [];
    foreach ($phenos as $p) {
        if ($p['delta'] === null || abs($p['delta']) < 5) {
            continue;
        }
        $a = $p['by_year'][$y0]['pct'] ?? null;
        $b = $p['by_year'][$y1]['pct'] ?? null;
        $arrow = ($p['dir'] === 'worse') ? 'เพิ่มขึ้น' : (($p['dir'] === 'better') ? 'ลดลง' : 'คงที่');
        $ph_bits[] = $p['label'] . ' ' . $arrow . ' จาก ' . number_format((float)$a, 1) . '% เป็น ' . number_format((float)$b, 1) . '%';
    }
    if ($ph_bits) {
        $bullets[] = 'ฟีโนไทป์เฝ้าระวัง (NARST/GLASS): ' . implode('; ', $ph_bits);
    } else {
        $bullets[] = 'ฟีโนไทป์เฝ้าระวังเปลี่ยนแปลงไม่ถึง 5 จุดเปอร์เซ็นต์ หรือยังมีปีที่ n < 30 จึงยังไม่สรุปแนวโน้ม';
    }

    $actions = [];
    foreach (array_slice($worse, 0, 3) as $p) {
        if ($metric === 'S') {
            $actions[] = 'ทบทวนแนวทาง empiric สำหรับ ' . $p['org_label'] . ' โดยเฉพาะ ' . $p['drug_label'];
        }
    }
    foreach ($phenos as $p) {
        if ($p['dir'] === 'worse' && $p['delta'] !== null && abs($p['delta']) >= 10) {
            $actions[] = 'ติดตาม ' . $p['label'] . ' ใกล้ชิดในคณะกรรมการยา / ป้องกันการติดเชื้อ';
        }
    }
    if ($actions) {
        $bullets[] = 'ข้อเสนอเชิงปฏิบัติ: ' . implode('; ', array_values(array_unique($actions)));
    }

    $cautions = [
        'เปรียบเทียบเป็นปีปฏิทิน ใช้ first isolate ต่อผู้ป่วยต่อเชื้อในแต่ละปี ตาม CLSI M39',
        'ไม่สรุปแนวโน้มเมื่อ n < 30 หรือยาไม่ได้ทดสอบ',
        'เกณฑ์ S/I/R เป็นค่าที่ห้องปฏิบัติการแปลตาม CLSI M100 ในช่วงนั้น อาจมีผลต่อ %S ข้ามปีได้',
    ];
    if (!empty($last['partial'])) {
        $cautions[] = 'ปี ' . $y1 . ' เป็นข้อมูลถึง ' . $last['end'] . ' ยังไม่ครบปี — แนวโน้มปีนี้อาจเปลี่ยนเมื่อสิ้นปี';
    }

    return [
        'headline' => $headline,
        'bullets' => $bullets,
        'cautions' => $cautions,
    ];
}

function amr_abg_build_period_pack(array $isolates, array $opts) {
    $isolate_rule = (($opts['isolate_rule'] ?? 'first') === 'all') ? 'all' : 'first';
    $metric = $opts['metric'] ?? 'S';
    $min_n = (int)($opts['min_n'] ?? 30);
    $include_other = !empty($opts['include_other']);
    $start = (string)$opts['start'];
    $end = (string)$opts['end'];
    $sheets = [];
    $first_all = [];
    foreach (amr_abg_sheet_defs() as $skey => $sdef) {
        $filtered = amr_abg_filter_isolates($isolates, ['specimen' => $skey, 'origin' => 'all']);
        $used = ($isolate_rule === 'first') ? amr_abg_first_isolates($filtered) : $filtered;
        if ($skey === 'all') {
            $first_all = $used;
        }
        $built = amr_abg_sheet_from_isolates($used, $min_n, $metric, $include_other);
        $sheets[$skey] = [
            'key' => $skey,
            'title' => $sdef['title'],
            'title_th' => $sdef['title_th'],
            'heading' => 'Percentage of susceptible Organisms Isolated From ' . $sdef['title'] . ', {hospital}, (' . amr_abg_period_en($start, $end) . ')',
            'used_isolates' => $built['used'],
            'suppressed_orgs' => $built['suppressed_orgs'],
            'rows' => $built['rows'],
        ];
    }
    $phenos = amr_abg_phenotypes_from_isolates($first_all, $min_n);
    return [
        'sheets' => $sheets,
        'phenotypes' => $phenos,
        'first_all' => $first_all,
        'spec_counts' => amr_abg_spec_counts($first_all),
        'used_isolates' => count($first_all),
        'rows' => $sheets['all']['rows'],
    ];
}

function amr_abg_build($con, array $opts) {
    $start = (string)$opts['start'];
    $end = (string)$opts['end'];
    $isolate_rule = (($opts['isolate_rule'] ?? 'first') === 'all') ? 'all' : 'first';
    $metric = strtoupper((string)($opts['metric'] ?? 'S'));
    if (!in_array($metric, ['S', 'R', 'NS'], true)) {
        $metric = 'S';
    }
    $min_n = (int)($opts['min_n'] ?? amr_abg_min_n_default());
    if ($min_n < 1) {
        $min_n = 1;
    }
    if ($min_n > 100) {
        $min_n = 100;
    }
    $include_other = !empty($opts['include_other']);
    $compare_n = (int)($opts['compare_years'] ?? 0);
    if ($compare_n < 0) {
        $compare_n = 0;
    }
    if ($compare_n > 5) {
        $compare_n = 5;
    }
    $using_mlab = function_exists('amr_mlab_using_direct') && amr_mlab_using_direct($con);
    $source = $using_mlab ? 'mlab' : 'hosxp';

    if ($compare_n >= 2) {
        $windows = amr_abg_year_windows($end, $compare_n);
        $start = $windows[0]['start'];
    }

    if ($source === 'mlab') {
        $pack = amr_abg_collect_mlab($con, $start, $end);
    } else {
        $pack = amr_abg_collect_hosxp($con, $start, $end);
    }
    if ($pack['error'] !== '') {
        return ['error' => $pack['error']];
    }

    $raw_n = count($pack['isolates']);
    $origin_opts = ['origin' => $opts['origin'] ?? 'all'];
    $base = amr_abg_filter_isolates($pack['isolates'], $origin_opts);

    $build_opts = [
        'isolate_rule' => $isolate_rule,
        'metric' => $metric,
        'min_n' => $min_n,
        'include_other' => $include_other,
        'start' => $start,
        'end' => $end,
    ];
    $compare = null;
    $year_sheets = [];
    if ($compare_n >= 2) {
        $windows = amr_abg_year_windows($end, $compare_n);
        $year_packs = [];
        foreach ($windows as $w) {
            $slice = amr_abg_filter_date($base, $w['start'], $w['end']);
            $yp = amr_abg_build_period_pack($slice, array_merge($build_opts, ['start' => $w['start'], 'end' => $w['end']]));
            $year_packs[] = [
                'year' => $w['year'],
                'start' => $w['start'],
                'end' => $w['end'],
                'partial' => $w['partial'],
                'used_isolates' => $yp['used_isolates'],
                'rows' => $yp['rows'],
                'phenotypes' => $yp['phenotypes'],
                'sheets' => $yp['sheets'],
                'spec_counts' => $yp['spec_counts'],
            ];
            $year_sheets[(string)$w['year']] = $yp['sheets'];
        }
        $compare = amr_abg_build_compare($year_packs, $metric);
        $last_pack = $year_packs[count($year_packs) - 1];
        $main = [
            'sheets' => $last_pack['sheets'],
            'phenotypes' => $last_pack['phenotypes'],
            'spec_counts' => $last_pack['spec_counts'],
            'used_isolates' => $last_pack['used_isolates'],
            'rows' => $last_pack['rows'],
        ];
        $start = $windows[0]['start'];
    } else {
        $main = amr_abg_build_period_pack($base, $build_opts);
    }

    $hospital = '';
    $hospital_th = '';
    if (function_exists('amr_amass_cover_info')) {
        $cover = amr_amass_cover_info($con);
        $hospital = (string)($cover['hospital_name'] ?? '');
        $hospital_th = (string)($cover['hospital_name_th'] ?? '');
    }
    $hosp_print = $hospital !== '' ? $hospital : ($hospital_th !== '' ? $hospital_th : 'Hospital');
    $fill_h = function (&$sheets) use ($hosp_print) {
        foreach ($sheets as $k => $sh) {
            $sheets[$k]['heading'] = str_replace('{hospital}', $hosp_print, $sh['heading']);
        }
    };
    $fill_h($main['sheets']);
    foreach ($year_sheets as $yk => $ys) {
        $fill_h($year_sheets[$yk]);
    }

    $all = $main['sheets']['all'];
    $standards = [
        'รูปแบบตารางตาม Antibiogram โรงพยาบาล (WHONET / %S) — แยก All Specimen, Blood, Urine, Respiratory Tract, Stool',
        'CLSI M39 — first isolate ต่อผู้ป่วยต่อเชื้อในช่วงวิเคราะห์ · ไม่รายงาน % เมื่อ n < 30 (แสดง r)',
        'R = Intrinsic resistance ตาม CLSI M100 / WHONET',
        'CLSI M100 — เกณฑ์ S/I/R จาก LIS · NARST / WHO GLASS สำหรับชุดเชื้อเฝ้าระวัง',
    ];
    if ($compare_n >= 2) {
        $standards[] = 'เปรียบเทียบรายปีปฏิทิน ' . $compare_n . ' ปี — first isolate นับใหม่ในแต่ละปี · แนวโน้มใช้เกณฑ์เปลี่ยน ≥ 5 จุด (ติดตาม) และ ≥ 10 จุด (สำคัญ)';
    }

    return [
        'error' => '',
        'meta' => [
            'start' => $start,
            'end' => $end,
            'period_en' => amr_abg_period_en($start, $end),
            'source' => $source,
            'source_label' => $source === 'mlab' ? 'mLAB (ตาราง THAM Hos-Safe)' : 'HOSxP lab_head (LIS RTF)',
            'isolate_rule' => $isolate_rule,
            'metric' => $metric,
            'min_n' => $min_n,
            'specimen' => 'all',
            'origin' => (string)($opts['origin'] ?? 'all'),
            'hospital' => $hospital,
            'hospital_th' => $hospital_th,
            'raw_isolates' => $raw_n,
            'filtered_isolates' => count($base),
            'used_isolates' => $main['used_isolates'],
            'organisms' => count($all['rows']),
            'suppressed_orgs' => $all['suppressed_orgs'] ?? 0,
            'spec_counts' => $main['spec_counts'],
            'compare_years' => $compare_n,
            'standards' => $standards,
        ],
        'drugs' => amr_abg_report_drugs(),
        'rows' => $all['rows'],
        'sheets' => $main['sheets'],
        'phenotypes' => $main['phenotypes'],
        'compare' => $compare,
        'year_sheets' => $year_sheets,
    ];
}
