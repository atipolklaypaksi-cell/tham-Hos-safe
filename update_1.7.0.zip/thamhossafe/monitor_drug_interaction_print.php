<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('hosxp_tmt_drug_helper.php');
mysqli_set_charset($con, 'utf8');

function di_print_esc($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function di_print_thai_num($n) {
    return strtr((string)(int)$n, [
        '0' => '๐', '1' => '๑', '2' => '๒', '3' => '๓', '4' => '๔',
        '5' => '๕', '6' => '๖', '7' => '๗', '8' => '๘', '9' => '๙',
    ]);
}

function di_print_nl($s) {
    $s = trim((string)$s);
    if ($s === '') {
        return '—';
    }
    return nl2br(di_print_esc($s));
}

$tbl = mysqli_query($con, "SHOW TABLES LIKE 'monitor_drug_interaction_settings'");
if (!$tbl || mysqli_num_rows($tbl) === 0) {
    die('ยังไม่มีตารางตั้งค่า Drug Interaction — กรุณารัน upgrade.php');
}
ensure_di_dose_columns($con);
ensure_di_pdf_columns($con);

$ids = [];
if (!empty($_GET['ids'])) {
    foreach (preg_split('/[,\s]+/', (string)$_GET['ids']) as $p) {
        $n = (int)$p;
        if ($n > 0) {
            $ids[$n] = true;
        }
    }
}
$ids = array_keys($ids);

$where = ['TRIM(drug_icode) <> \'\'', 'TRIM(hosxp_icode) <> \'\''];
if (!empty($ids)) {
    $where[] = 'id IN (' . implode(',', array_map('intval', $ids)) . ')';
} else {
    $where[] = 'active_status = 1';
}
if (isset($_GET['alert']) && $_GET['alert'] === 'hard') {
    $where[] = "COALESCE(alert_level,'soft') = 'hard'";
}

$sql = 'SELECT * FROM monitor_drug_interaction_settings WHERE ' . implode(' AND ', $where)
    . ' ORDER BY drug_name ASC, hosxp_drug_name ASC';
$q = mysqli_query($con, $sql);
$rows = [];
if ($q) {
    while ($r = mysqli_fetch_assoc($q)) {
        $rows[] = $r;
    }
}

$hospital = 'โรงพยาบาล';
if (is_file(__DIR__ . '/amr_amass_helper.php')) {
    require_once __DIR__ . '/amr_amass_helper.php';
    if (function_exists('amr_amass_cover_info')) {
        $cover = amr_amass_cover_info($con);
        if (!empty($cover['hospital_name_th'])) {
            $hospital = $cover['hospital_name_th'];
        } elseif (!empty($cover['hospital_name'])) {
            $hospital = $cover['hospital_name'];
        }
    }
}

$pair_count = count($rows);
$print_date = date('d/m/Y');
$doc_no = 'SP-DI-' . date('Y');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>คู่ยา Fatal DI — <?php echo di_print_esc($hospital); ?></title>
    <style>
        @page { size: A4 portrait; margin: 10mm 10mm; }
        * { box-sizing: border-box; }
        body {
            font-family: 'Sarabun', 'TH Sarabun New', Tahoma, sans-serif;
            font-size: 10.5px;
            color: #111;
            background: #fff;
            margin: 0;
            line-height: 1.3;
        }
        .sheet { width: 100%; max-width: 190mm; margin: 0 auto; }
        .doc-head {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 8px;
        }
        .doc-head td {
            border: 1px solid #111;
            padding: 4px 8px;
            vertical-align: middle;
        }
        .doc-head .brand {
            width: 22%;
            text-align: center;
            font-weight: 800;
            font-size: 12px;
        }
        .doc-head .title {
            text-align: center;
            font-weight: 800;
            font-size: 15px;
        }
        .doc-head .title .sub { font-size: 12px; font-weight: 700; display: block; margin-top: 1px; }
        .doc-head .meta { width: 26%; font-size: 10.5px; }
        .doc-head .meta b { display: inline-block; min-width: 88px; }
        .lead {
            font-size: 12px;
            font-weight: 700;
            text-align: center;
            margin: 4px 0 8px;
        }
        .di-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 10.5px;
        }
        .di-table th, .di-table td {
            border: 1px solid #111;
            padding: 4px 5px;
            vertical-align: top;
            overflow-wrap: anywhere;
        }
        .di-table th {
            background: #f3f4f6;
            text-align: center;
            font-weight: 800;
            white-space: nowrap;
        }
        .di-table td.num { text-align: center; white-space: nowrap; font-weight: 700; }
        .di-table td.center { text-align: center; }
        .di-table .drug { font-weight: 700; }
        .hint { font-size: 10px; color: #475569; }
        .empty { text-align: center; padding: 18px; color: #64748b; }
        @media print {
            .no-print { display: none !important; }
            body { margin: 0; }
            .sheet { max-width: none; }
            a { color: inherit; text-decoration: none; }
            .di-table th { background: #eee !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
        @media screen {
            body { background: #e2e8f0; padding: 16px; }
            .sheet {
                background: #fff;
                box-shadow: 0 1px 8px rgba(0,0,0,.12);
                padding: 12px 14px;
                min-height: 260mm;
            }
        }
    </style>
</head>
<body>
<div class="sheet">
    <div class="no-print" style="margin-bottom:10px;">
        <button type="button" onclick="window.print()" style="padding:6px 12px;font-weight:700;">พิมพ์ / บันทึก PDF</button>
        <button type="button" onclick="window.close()" style="padding:6px 12px;">ปิด</button>
        <a href="monitor_drug_interaction.php?tab=settings" style="margin-left:8px;">กลับตั้งค่า</a>
        <span class="hint" style="margin-left:12px;">แนะนำ: กระดาษ A4 · แนวตั้ง (Portrait) · ขนาด 100% · ปลายทางเป็น PDF</span>
    </div>

    <table class="doc-head">
        <tr>
            <td class="brand" rowspan="2">
                THAM Hos-Safe<br>
                <?php echo di_print_esc($hospital); ?>
            </td>
            <td class="title" rowspan="2">
                คู่ยาที่มีอันตรกิริยารุนแรง
                <span class="sub">(Fatal Drug Interaction : Fatal DI)</span>
            </td>
            <td class="meta"><b>เลขที่เอกสาร</b> <?php echo di_print_esc($doc_no); ?></td>
        </tr>
        <tr>
            <td class="meta">
                <b>หน่วยรับผิดชอบ</b> คณะกรรมการความปลอดภัยด้านยา<br>
                <b>วันที่พิมพ์</b> <?php echo di_print_esc($print_date); ?>
            </td>
        </tr>
    </table>

    <div class="lead">
        คู่ยาที่มีอันตรกิริยารุนแรง (Fatal Drug Interaction : Fatal DI)
        <?php echo di_print_esc($hospital); ?>
        พิจารณาแล้ว Fatal DI มี <?php echo di_print_thai_num($pair_count); ?> คู่ ดังนี้
    </div>

    <table class="di-table">
        <thead>
            <tr>
                <th style="width:6%;">คู่ที่</th>
                <th style="width:13%;">ยาตัวที่ ๑</th>
                <th style="width:13%;">ยาตัวที่ ๒</th>
                <th style="width:8%;">onset</th>
                <th style="width:12%;">severity</th>
                <th style="width:10%;">documentation</th>
                <th style="width:20%;">effect</th>
                <th style="width:18%;">Reference</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!$rows): ?>
            <tr><td colspan="8" class="empty">ยังไม่มีรายการคู่ยาที่เปิดใช้งาน — ไปตั้งค่าที่ Monitor Interaction</td></tr>
            <?php else: ?>
            <?php foreach ($rows as $i => $r): ?>
            <tr>
                <td class="num"><?php echo di_print_thai_num($i + 1); ?></td>
                <td class="drug"><?php echo di_print_esc($r['drug_name']); ?></td>
                <td class="drug"><?php echo di_print_esc($r['hosxp_drug_name']); ?></td>
                <td class="center"><?php echo di_print_esc(trim((string)($r['pdf_onset'] ?? '')) !== '' ? $r['pdf_onset'] : '—'); ?></td>
                <td class="center"><?php echo di_print_esc(di_pdf_severity_label($r)); ?></td>
                <td class="center"><?php echo di_print_esc(trim((string)($r['pdf_documentation'] ?? '')) !== '' ? $r['pdf_documentation'] : '—'); ?></td>
                <td><?php echo di_print_nl($r['detail_text'] ?? ''); ?></td>
                <td><?php echo di_print_nl($r['pdf_reference'] ?? ''); ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<script>
window.addEventListener('load', function() {
    if (location.search.indexOf('autoprint=1') >= 0) {
        setTimeout(function() { window.print(); }, 250);
    }
});
</script>
</body>
</html>
