<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('allergy_report') && !tham_menu_can('allergy_followup')) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Method ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
    exit;
}

$flags = JSON_UNESCAPED_UNICODE;
$file = $_FILES['audio'] ?? null;
if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่พบไฟล์เสียง'], $flags);
    exit;
}
if (($file['size'] ?? 0) < 800) {
    echo json_encode(['status' => 'error', 'message' => 'คลิปสั้นเกินไป พูดให้นานขึ้นเล็กน้อย'], $flags);
    exit;
}
if (($file['size'] ?? 0) > 2 * 1024 * 1024) {
    echo json_encode(['status' => 'error', 'message' => 'ไฟล์เสียงใหญ่เกินไป พูดสั้นลง'], $flags);
    exit;
}

$bin = @file_get_contents($file['tmp_name']);
if (!is_string($bin) || $bin === '') {
    echo json_encode(['status' => 'error', 'message' => 'อ่านไฟล์เสียงไม่สำเร็จ'], $flags);
    exit;
}

$parsed = af_stt_parse_wav_pcm16($bin);
if (!$parsed['ok']) {
    echo json_encode(['status' => 'error', 'message' => $parsed['message']], $flags);
    exit;
}

$text = af_stt_recognize_google($parsed['pcm'], $parsed['rate']);
if ($text === null) {
    echo json_encode(['status' => 'error', 'message' => 'แปลงเสียงไม่สำเร็จ ตรวจอินเทอร์เน็ตของเซิร์ฟเวอร์แล้วลองใหม่'], $flags);
    exit;
}
if (trim($text) === '') {
    echo json_encode(['status' => 'error', 'message' => 'ไม่ได้ยินคำพูด พูดอีกครั้งให้ชัดขึ้น'], $flags);
    exit;
}

echo json_encode(['status' => 'success', 'text' => $text], $flags);
exit;

function af_stt_parse_wav_pcm16($bin) {
    if (strlen($bin) < 44 || substr($bin, 0, 4) !== 'RIFF' || substr($bin, 8, 4) !== 'WAVE') {
        return ['ok' => false, 'message' => 'ไฟล์เสียงไม่ใช่ WAV'];
    }
    $len = strlen($bin);
    $pos = 12;
    $channels = 1;
    $rate = 16000;
    $bits = 16;
    $pcm = null;
    while ($pos + 8 <= $len) {
        $id = substr($bin, $pos, 4);
        $sz = unpack('V', substr($bin, $pos + 4, 4));
        $sz = $sz ? (int)$sz[1] : 0;
        $pos += 8;
        if ($pos + $sz > $len) {
            break;
        }
        if ($id === 'fmt ') {
            if ($sz < 16) {
                return ['ok' => false, 'message' => 'ไฟล์ WAV ไม่สมบูรณ์'];
            }
            $audio_format = unpack('v', substr($bin, $pos, 2))[1];
            $channels = unpack('v', substr($bin, $pos + 2, 2))[1];
            $rate = unpack('V', substr($bin, $pos + 4, 4))[1];
            $bits = unpack('v', substr($bin, $pos + 14, 2))[1];
            if ((int)$audio_format !== 1 || (int)$bits !== 16) {
                return ['ok' => false, 'message' => 'รองรับเฉพาะ WAV PCM 16-bit'];
            }
            if ($rate < 8000 || $rate > 48000) {
                return ['ok' => false, 'message' => 'อัตราสุ่มเสียงไม่รองรับ'];
            }
        } elseif ($id === 'data') {
            $pcm = substr($bin, $pos, $sz);
            break;
        }
        $pos += $sz + ($sz % 2);
    }
    if ($pcm === null || $pcm === '') {
        return ['ok' => false, 'message' => 'ไม่พบข้อมูลเสียงในไฟล์'];
    }
    $channels = max(1, (int)$channels);
    if ($channels === 2) {
        $pcm = af_stt_mix_stereo_to_mono($pcm);
    } elseif ($channels !== 1) {
        return ['ok' => false, 'message' => 'จำนวนช่องเสียงไม่รองรับ'];
    }
    return ['ok' => true, 'pcm' => $pcm, 'rate' => (int)$rate];
}

function af_stt_mix_stereo_to_mono($pcm) {
    $n = intdiv(strlen($pcm), 4);
    $out = '';
    for ($i = 0; $i < $n; $i++) {
        $l = unpack('v', substr($pcm, $i * 4, 2))[1];
        $r = unpack('v', substr($pcm, $i * 4 + 2, 2))[1];
        $l = $l >= 32768 ? $l - 65536 : $l;
        $r = $r >= 32768 ? $r - 65536 : $r;
        $m = (int)round(($l + $r) / 2);
        if ($m < -32768) {
            $m = -32768;
        }
        if ($m > 32767) {
            $m = 32767;
        }
        $out .= pack('v', $m & 0xFFFF);
    }
    return $out;
}

function af_stt_recognize_google($pcm, $rate) {
    $rate = (int)$rate;
    if ($rate <= 0) {
        $rate = 16000;
    }
    $chunk_bytes = $rate * 2 * 8;
    $parts = [];
    $len = strlen($pcm);
    if ($len <= $chunk_bytes) {
        $parts[] = $pcm;
    } else {
        $step = $rate * 2 * 7;
        for ($off = 0; $off < $len; $off += $step) {
            $slice = substr($pcm, $off, $chunk_bytes);
            if (strlen($slice) < $rate * 2) {
                break;
            }
            $parts[] = $slice;
        }
    }
    $texts = [];
    foreach ($parts as $part) {
        $piece = af_stt_google_chunk($part, $rate);
        if ($piece === false) {
            return null;
        }
        if ($piece !== '') {
            $texts[] = $piece;
        }
    }
    return trim(preg_replace('/\s+/u', ' ', implode(' ', $texts)));
}

function af_stt_google_chunk($pcm, $rate) {
    $query = http_build_query([
        'client' => 'chromium',
        'lang' => 'th-TH',
        'output' => 'json',
        'key' => 'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw',
    ]);
    $url = 'https://www.google.com/speech-api/v2/recognize?' . $query;
    $ctx = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: audio/l16; rate=" . (int)$rate . "\r\nUser-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\nConnection: close\r\n",
            'content' => $pcm,
            'timeout' => 25,
            'ignore_errors' => true,
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false || trim($raw) === '' || strpos($raw, '{') === false) {
        return false;
    }
    $best = '';
    $best_conf = -1;
    foreach (preg_split("/\r\n|\n|\r/", $raw) as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $json = json_decode($line, true);
        if (!is_array($json) || empty($json['result']) || !is_array($json['result'])) {
            continue;
        }
        foreach ($json['result'] as $row) {
            $alts = $row['alternative'] ?? [];
            if (!is_array($alts) || !$alts) {
                continue;
            }
            $top = $alts[0];
            $t = trim((string)($top['transcript'] ?? ''));
            $c = isset($top['confidence']) ? (float)$top['confidence'] : 0;
            if ($t !== '' && $c >= $best_conf) {
                $best = $t;
                $best_conf = $c;
            }
        }
    }
    return $best;
}
