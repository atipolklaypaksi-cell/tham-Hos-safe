<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
session_write_close();

include('connect.php');
require_once __DIR__ . '/smart_lab_helper.php';
mysqli_set_charset($con, 'utf8');
dm_ensure_tables($con);

// เชื่อม HOSxP (ใช้สำหรับ ajax_graph)
$config = [];
$q_conf = mysqli_query($con, "SELECT config_name, config_value FROM sys_config");
if ($q_conf) {
    while ($r = mysqli_fetch_assoc($q_conf)) {
        $config[$r['config_name']] = $r['config_value'];
    }
}
$hos_con = null;
try {
    mysqli_report(MYSQLI_REPORT_OFF);
    $hos_con = mysqli_init();
    mysqli_options($hos_con, MYSQLI_OPT_CONNECT_TIMEOUT, 3);
    @mysqli_real_connect($hos_con, $config['h_host'] ?? '', $config['h_user'] ?? '', $config['h_pass'] ?? '', $config['h_db'] ?? 'hos');
    if (!$hos_con) {
        throw new Exception(mysqli_connect_error());
    }
    mysqli_set_charset($hos_con, 'utf8');
} catch (Exception $e) {
    die("
    <!DOCTYPE html><html lang='th'><head><meta charset='UTF-8'><link href='css/bootstrap.min.css' rel='stylesheet'><link href='css/all.min.css' rel='stylesheet'></head>
    <body class='bg-light'>
        <div class='container mt-5'>
            <div class='alert alert-danger text-center fw-bold shadow-sm p-4'>
                <i class='fas fa-plug fa-3x mb-3 text-danger d-block'></i>
                <h4 class='fw-bold'>ไม่สามารถเชื่อมต่อฐานข้อมูล HOSxP ได้</h4>
                <p class='text-danger small'><b>Error:</b> " . htmlspecialchars($e->getMessage()) . "</p>
                <a href='hosxp_setting.php' class='btn btn-danger mt-3'><i class='fas fa-cogs me-1'></i> ไปตั้งค่าการเชื่อมต่อ</a>
            </div>
        </div>
    </body></html>");
}

// ---------- AJAX กราฟแนวโน้ม ----------
if (isset($_GET['ajax_graph'])) {
    error_reporting(0);
    @ini_set('display_errors', '0');
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
    ob_start();
    header('Content-Type: application/json; charset=utf-8');

    $raw_ajax_hn = isset($_GET['hn']) ? trim($_GET['hn']) : '';
    if ($raw_ajax_hn !== '' && is_numeric($raw_ajax_hn) && strlen($raw_ajax_hn) < 9) {
        $raw_ajax_hn = str_pad($raw_ajax_hn, 9, '0', STR_PAD_LEFT);
    }
    $lab_code_raw = trim((string)($_GET['lab_code'] ?? ''));
    $lab_name_raw = trim((string)($_GET['lab_name'] ?? ''));
    $tmlt_raw = trim((string)($_GET['tmlt'] ?? ''));
    $graph_hosp = strtolower(trim((string)($_GET['hospital'] ?? 'local')));
    if ($graph_hosp === '') {
        $graph_hosp = 'local';
    }
    $include_network = !isset($_GET['network']) || $_GET['network'] === '1' || $_GET['network'] === 'on';
    $months = hds_lookback_months($_GET['months'] ?? 12, 12);
    $local_hospital_name = hds_local_hospital_name();
    $hn_esc = mysqli_real_escape_string($hos_con, $raw_ajax_hn);

    $cid = '';
    $q_cid = mysqli_query($hos_con, "SELECT cid FROM patient WHERE hn = '$hn_esc' LIMIT 1");
    if ($q_cid && ($cr = mysqli_fetch_assoc($q_cid))) {
        $cid = preg_replace('/\D+/', '', (string)($cr['cid'] ?? ''));
    }
    if ($tmlt_raw === '' && $lab_code_raw !== '' && $graph_hosp === 'local') {
        $code_esc = mysqli_real_escape_string($hos_con, $lab_code_raw);
        $q_t = mysqli_query($hos_con, "SELECT tmlt_code, CAST(CONVERT(lab_items_name USING utf8) AS CHAR) AS n FROM lab_items WHERE lab_items_code = '$code_esc' LIMIT 1");
        if ($q_t && ($tr = mysqli_fetch_assoc($q_t))) {
            $tmlt_raw = trim((string)($tr['tmlt_code'] ?? ''));
            if ($lab_name_raw === '') {
                $lab_name_raw = trim((string)($tr['n'] ?? ''));
            }
        }
    }

    $points = [];
    $sql_local = hds_smart_lab_trend_sql($raw_ajax_hn, $lab_code_raw, $tmlt_raw, $lab_name_raw, $months, 12, false);
    $q_history = mysqli_query($hos_con, $sql_local);
    $local_rows = [];
    if ($q_history) {
        while ($row = mysqli_fetch_assoc($q_history)) {
            $local_rows[] = $row;
        }
    }
    foreach (hds_pack_lab_trend_rows($local_rows, 'local', $local_hospital_name, $lab_code_raw, $tmlt_raw, $lab_name_raw, false) as $p) {
        $points[] = $p;
    }
    if ($include_network) {
        $net = hds_fetch_smart_lab_trend_network($con, hds_hn_variants($raw_ajax_hn), $cid, $lab_code_raw, $tmlt_raw, $lab_name_raw, $months, 12);
        foreach ($net['points'] ?? [] as $p) {
            $points[] = $p;
        }
    }

    usort($points, function ($a, $b) {
        $da = (string)($a['report_date'] ?: $a['order_date']);
        $db = (string)($b['report_date'] ?: $b['order_date']);
        if ($da !== $db) {
            return strcmp($db, $da);
        }
        return strcmp((string)($b['report_time'] ?: $b['order_time']), (string)($a['report_time'] ?: $a['order_time']));
    });
    if (count($points) > 40) {
        $points = array_slice($points, 0, 40);
    }

    $dates = [];
    $values = [];
    $raw_values = [];
    $hospitals = [];
    $hospital_codes = [];
    $normal_range = '';
    $text_count = 0;
    $num_count = 0;
    $match_via = $tmlt_raw !== '' ? 'tmlt' : ($lab_name_raw !== '' ? 'name' : 'code');
    foreach ($points as $row) {
        $raw_val = trim((string)($row['lab_order_result'] ?? ''));
        $point_hosp = (string)($row['hospital_code'] ?? $graph_hosp);
        $point_lab_name = trim((string)($row['lab_name'] ?? $lab_name_raw));
        if (dm_should_mask_lab($con, $point_lab_name, $point_hosp) || dm_should_mask_lab($con, $lab_name_raw, $point_hosp)) {
            $raw_val = dm_mask_message();
        }
        $hname = preg_replace('/^รพ\./u', '', (string)($row['hospital_name'] ?? ''));
        $dates[] = smart_lab_dt_label($row) . ($hname !== '' ? ' · ' . $hname : '');
        $raw_values[] = $raw_val;
        $hospitals[] = $hname !== '' ? $hname : 'รพ.นี้';
        $hospital_codes[] = (string)($row['hospital_code'] ?? 'local');
        $parsed_num = smart_lab_parse_numeric($raw_val);
        $values[] = $parsed_num !== null ? $parsed_num : 0.0;
        if ($normal_range === '' && !empty($row['lab_items_normal_value'])) {
            $normal_range = $row['lab_items_normal_value'];
        }
        if ($raw_val !== '') {
            if ($parsed_num !== null) {
                $num_count++;
            } else {
                $text_count++;
            }
        }
    }

    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
    if ($points) {
        $data_type = ($text_count > 0 && $text_count >= $num_count) ? 'text' : 'numeric';
        if ($data_type === 'numeric') {
            $dates = array_reverse($dates);
            $values = array_reverse($values);
            $raw_values = array_reverse($raw_values);
            $hospitals = array_reverse($hospitals);
            $hospital_codes = array_reverse($hospital_codes);
        }
        echo smart_lab_json([
            'status' => 'success',
            'data_type' => $data_type,
            'dates' => $dates,
            'values' => $values,
            'raw_values' => $raw_values,
            'hospitals' => $hospitals,
            'hospital_codes' => $hospital_codes,
            'normal_range' => $normal_range,
            'match' => ['via' => $match_via, 'tmlt' => $tmlt_raw, 'lab_code' => $lab_code_raw, 'name' => $lab_name_raw],
        ]);
    } else {
        echo smart_lab_json(['status' => 'error', 'message' => 'ไม่พบประวัติผล Lab ย้อนหลัง']);
    }
    exit;
}

$prefill_hn = isset($_GET['hn']) ? trim((string)$_GET['hn']) : '';
$include_network = !isset($_GET['network']) || $_GET['network'] === '1' || $_GET['network'] === 'on';
$lookback_months = hds_lookback_months($_GET['months'] ?? 12, 12);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Lab - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        .table-custom { box-shadow: 0 4px 15px rgba(0,0,0,0.05); border-radius: 10px; overflow: hidden; }
        .table-custom th { background-color: #f8f9fa; color: #495057; }
        #chartContainer { position: relative; height: 340px; width: 100%; }
        .history-scroll { max-height: 520px; overflow-y: auto; }
        .history-scroll::-webkit-scrollbar { width: 6px; }
        .chip {
            display: inline-block; font-size: 0.75rem; border-radius: 999px;
            padding: 2px 8px; margin: 2px 4px 2px 0;
            background: #eef7f3; color: #1a4032; border: 1px solid #c5d4a0;
        }
        .chip.miss { background: #f8f9fa; color: #6c757d; border-color: #dee2e6; }
        .chip.err { background: #fff3cd; color: #856404; border-color: #ffe69c; }
        .lab-hosp-badge {
            font-size: 0.65rem; font-weight: 700; background: #0f766e; color: #fff;
            border-radius: 8px; padding: 1px 7px;
        }
        .lab-hosp-badge.local { background: #1f4d3b; }
        #labHistoryList .lab-order-item {
            border: 0; border-bottom: 1px solid rgba(0,0,0,.08); cursor: pointer;
        }
        #labHistoryList .lab-order-item:hover { background: #f0fdfa; }
        #labHistoryList .lab-order-item.active { background: #0dcaf0 !important; color: #fff; }
        #labHistoryList .lab-order-item.active .text-muted,
        #labHistoryList .lab-order-item.active .text-secondary { color: rgba(255,255,255,.9) !important; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="fw-bold mb-0 text-dark"><i class="fas fa-microscope me-2 text-info"></i>ระบบ Smart Lab</h4>
        </div>

        <div class="container-fluid">
            <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                <div class="card-body p-4">
                    <form class="row g-3 align-items-end" id="smartLabForm">
                        <div class="col-md-4 col-sm-12">
                            <label class="fw-bold text-secondary mb-1">กรอก HN ผู้ป่วย</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light text-info"><i class="fas fa-id-card"></i></span>
                                <input type="text" id="search_hn" class="form-control form-control-lg fw-bold text-info border-info"
                                       value="<?php echo htmlspecialchars($prefill_hn); ?>"
                                       placeholder="ค้นหาประวัติ Lab..." required>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-12">
                            <label class="fw-bold text-secondary mb-1">ช่วงเวลาย้อนหลัง</label>
                            <select id="search_months" class="form-select form-select-lg">
                                <?php echo hds_lookback_options_html($lookback_months); ?>
                            </select>
                        </div>
                        <div class="col-md-3 col-sm-12">
                            <div class="form-check form-switch mt-1">
                                <input class="form-check-input" type="checkbox" role="switch" id="includeNetwork" <?php echo $include_network ? 'checked' : ''; ?>>
                                <label class="form-check-label fw-bold text-success" for="includeNetwork">เชื่อมต่อรพ.ในเครือข่าย</label>
                            </div>
                            <div class="small text-muted">โหลดครั้งเดียวแล้วสลับวันที่ได้ทันที</div>
                        </div>
                        <div class="col-md-2 col-sm-12">
                            <button type="submit" class="btn btn-info text-white btn-lg w-100 fw-bold shadow-sm" id="btnSearchLab">
                                <i class="fas fa-search me-2"></i> ค้นหา
                            </button>
                        </div>
                    </form>
                    <div id="networkStatus" class="mt-2"></div>
                    <div id="loadTiming" class="small text-muted mt-1"></div>
                </div>
            </div>

            <div id="labPatientBar" class="alert alert-success fw-bold shadow-sm mb-3 d-none">
                <i class="fas fa-user-check me-2"></i> ผู้ป่วย: <span class="text-dark" id="labPatientName">-</span>
                <span class="badge bg-success ms-2 fw-normal d-none" id="labNetBadge">รวมรพ.เครือข่าย</span>
                <span class="badge bg-light text-secondary border ms-2 fw-normal" id="labCacheHint"></span>
            </div>

            <div class="row" id="labResultPanel" style="display:none;">
                <div class="col-md-4 col-lg-3 mb-4">
                    <div class="card border-0 shadow-sm table-custom">
                        <div class="card-header bg-secondary text-white fw-bold py-3">
                            <i class="fas fa-calendar-alt me-1"></i> ประวัติวันที่ตรวจ
                        </div>
                        <div class="list-group list-group-flush history-scroll" id="labHistoryList">
                            <div class="text-center text-muted py-4 small">ยังไม่ได้ค้นหา</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 col-lg-9">
                    <h5 class="fw-bold text-info mb-3" id="labResultTitle">
                        <i class="fas fa-file-medical-alt me-2"></i> ผลการตรวจวันที่: <span id="labResultDate">-</span>
                        <span class="badge bg-primary ms-2 d-none" id="labResultForm"></span>
                        <span class="badge bg-success ms-2" id="labResultHosp"></span>
                    </h5>
                    <div class="card border-0 table-custom">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <th class="py-3 px-4">รายการ Lab (Lab Items)</th>
                                            <th class="py-3 text-center">ผลลัพธ์ (Result)</th>
                                            <th class="py-3 text-center">ค่าอ้างอิง (Normal Range)</th>
                                            <th class="text-center py-3">กราฟ/ประวัติ</th>
                                        </tr>
                                    </thead>
                                    <tbody id="labItemsBody">
                                        <tr><td colspan="4" class="text-center text-muted py-4">กรอก HN แล้วกดค้นหา</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="labEmptyState" class="alert alert-light border text-center text-muted py-5 d-none">
                <i class="fas fa-vials fa-2x mb-2 d-block"></i>
                กรอก HN แล้วกดค้นหาเพื่อดูประวัติ Lab
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="graphModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-info text-white py-3">
        <h5 class="modal-title fw-bold" id="modalLabTitle"><i class="fas fa-chart-area me-2"></i> แนวโน้มค่า Lab</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4 bg-light text-center">
          <div id="chartLoading" style="display:none;">
              <i class="fas fa-spinner fa-spin fa-3x text-info mb-3"></i>
              <p class="fw-bold text-secondary">กำลังโหลดข้อมูลประวัติ...</p>
          </div>
          <div id="chartContainer" style="display:none;">
              <canvas id="labChart"></canvas>
              <div id="labTrendLegend" class="mt-2 small text-start"></div>
          </div>
          <div id="textContainer" style="display:none;" class="text-start mt-2"></div>
          <div class="mt-3 p-2 bg-white rounded shadow-sm border">
              <span class="fw-bold text-secondary">ค่าอ้างอิงปกติ (Normal Value):</span>
              <span class="fw-bold text-dark fs-5 ms-2" id="modalNormalRange">-</span>
              <div id="labMatchHint" class="small text-muted mt-1"></div>
          </div>
      </div>
    </div>
  </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/chart.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
let labChartInstance = null;
let globalLabOrders = [];
let globalLabItemsByOrder = {};
let selectedLabOrderKey = null;
let currentLabHn = '';
let SMART_LAB_NETWORK = '1';
let SMART_LAB_MONTHS = '12';
const LAB_HOSP_COLORS = ['#0dcaf0', '#198754', '#fd7e14', '#6f42c1', '#dc3545', '#20c997', '#0d6efd', '#ffc107'];
let labLoadTimer = null;

function escapeHtml(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function formatLoadMs(ms) {
    ms = Math.max(0, parseInt(ms, 10) || 0);
    if (ms < 1000) return ms + ' ms';
    return (ms / 1000).toFixed(1) + ' วินาที';
}

function startLabClock() {
    stopLabClock();
    const t0 = Date.now();
    const tick = function () {
        const s = ((Date.now() - t0) / 1000).toFixed(1);
        $('#loadTiming').html('<i class="fas fa-clock me-1"></i>กำลังโหลด... <strong>' + s + '</strong> วินาที');
    };
    tick();
    labLoadTimer = setInterval(tick, 100);
}

function stopLabClock() {
    if (labLoadTimer) {
        clearInterval(labLoadTimer);
        labLoadTimer = null;
    }
}

function renderNetworkStatus(meta) {
    const sources = (meta && meta.network) || [];
    if (!sources.length) {
        $('#networkStatus').html('');
        return;
    }
    let html = '';
    sources.forEach(function (s) {
        const label = String(s.name || s.code || '').replace(/^รพ\./, '');
        if (s.ok && (s.rows || 0) > 0) {
            html += '<span class="chip"><i class="fas fa-check-circle text-success me-1"></i>'
                + escapeHtml(label) + ' ' + (s.rows || 0) + ' ใบ · ' + escapeHtml(formatLoadMs(s.ms || 0)) + '</span>';
        } else if (s.ok) {
            html += '<span class="chip miss"><i class="far fa-circle me-1"></i>'
                + escapeHtml(label) + ' ไม่พบ · ' + escapeHtml(formatLoadMs(s.ms || 0)) + '</span>';
        } else {
            const err = String(s.error || '');
            const timed = /timeout|หมดเวลา/i.test(err);
            html += '<span class="chip err" title="' + escapeHtml(err) + '"><i class="fas fa-exclamation-triangle me-1"></i>'
                + escapeHtml(label) + (timed ? ' หมดเวลา' : '')
                + (s.ms ? ' · ' + escapeHtml(formatLoadMs(s.ms)) : '') + '</span>';
        }
    });
    $('#networkStatus').html(html);
}

function renderOrderList(orders) {
    if (!orders.length) {
        $('#labHistoryList').html('<div class="text-center text-warning py-4 small">ไม่พบใบ Lab</div>');
        return;
    }
    let html = '';
    orders.forEach(function (o) {
        const key = o.order_key;
        const active = key === selectedLabOrderKey ? ' active' : '';
        const isLocal = (o.hospital_code || 'local') === 'local';
        html += '<button type="button" class="list-group-item list-group-item-action text-start lab-order-item' + active + '"'
            + ' data-order-key="' + escapeHtml(key) + '">'
            + '<div class="d-flex justify-content-between align-items-start">'
            + '<span><i class="fas fa-flask me-2"></i> ' + escapeHtml(o.date_show || '-') + '</span>'
            + '<small class="' + (active ? 'text-white' : 'text-muted') + '">' + escapeHtml(o.time_show || '') + '</small>'
            + '</div>';
        if (o.form_name) {
            html += '<div class="small fw-bold mt-1 ' + (active ? 'text-white' : 'text-secondary') + '">'
                + escapeHtml(o.form_name) + '</div>';
        }
        if (o.hospital_short) {
            html += '<span class="lab-hosp-badge' + (isLocal ? ' local' : '') + '">'
                + escapeHtml(o.hospital_short) + '</span>';
        }
        html += '</button>';
    });
    $('#labHistoryList').html(html);
}

function renderLabItems(orderKey) {
    const order = globalLabOrders.find(function (o) { return o.order_key === orderKey; });
    const items = globalLabItemsByOrder[orderKey] || [];
    if (!order) {
        $('#labItemsBody').html('<tr><td colspan="4" class="text-center text-danger py-4">ไม่พบใบสั่ง</td></tr>');
        return;
    }
    $('#labResultDate').text(order.date_label || '-');
    if (order.form_name) {
        $('#labResultForm').text(order.form_name).removeClass('d-none');
    } else {
        $('#labResultForm').text('').addClass('d-none');
    }
    $('#labResultHosp').text(order.hospital_short || order.hospital_name || '');

    if (!items.length) {
        $('#labItemsBody').html('<tr><td colspan="4" class="text-center text-muted py-4">ไม่มีรายการในใบนี้</td></tr>');
        return;
    }
    let html = '';
    const hosp = order.hospital_code || 'local';
    items.forEach(function (item) {
        const name = item.lab_items_name_ref || '';
        const code = item.lab_items_code || '';
        const result = item.lab_order_result || '-';
        const normal = item.lab_items_normal_value || '';
        const tmlt = item.tmlt_code || '';
        const masked = !!item.is_masked;
        html += '<tr>';
        html += '<td class="px-4 fw-bold text-secondary">' + escapeHtml(name);
        if (tmlt && !masked) {
            html += '<br><small class="text-muted fw-normal">TMLT ' + escapeHtml(tmlt) + '</small>';
        }
        html += '</td>';
        html += '<td class="text-center fs-5 ' + (masked ? 'text-danger' : 'text-dark') + ' fw-bold">' + escapeHtml(result) + '</td>';
        html += '<td class="text-center text-muted"><small>' + escapeHtml(normal) + '</small></td>';
        html += '<td class="text-center">';
        if (masked) {
            html += '<span class="badge bg-light text-secondary border"><i class="fas fa-lock me-1"></i>ปกปิด</span>';
        } else {
            html += '<button type="button" class="btn btn-sm btn-outline-info fw-bold btn-lab-trend"'
                + ' data-lab-code="' + escapeHtml(code) + '"'
                + ' data-lab-name="' + escapeHtml(name) + '"'
                + ' data-hospital="' + escapeHtml(hosp) + '"'
                + ' data-tmlt="' + escapeHtml(tmlt) + '">'
                + '<i class="fas fa-search-plus me-1"></i> ดูแนวโน้ม</button>';
        }
        html += '</td></tr>';
    });
    $('#labItemsBody').html(html);
}

function selectLabOrder(orderKey, pushUrl) {
    if (!orderKey) return;
    selectedLabOrderKey = orderKey;
    renderOrderList(globalLabOrders);
    renderLabItems(orderKey);
    if (pushUrl !== false) {
        try {
            const url = new URL(window.location.href);
            url.searchParams.set('hn', currentLabHn);
            url.searchParams.set('lab_order', orderKey);
            url.searchParams.set('network', SMART_LAB_NETWORK);
            url.searchParams.set('months', SMART_LAB_MONTHS);
            window.history.replaceState({ lab_order: orderKey }, '', url.toString());
        } catch (e) {}
    }
}

async function fetchSmartLabData() {
    let hn = $('#search_hn').val().trim();
    if (!hn) {
        alert('กรุณาระบุ HN ก่อนครับ');
        return;
    }
    if (!isNaN(hn) && hn.length > 0 && hn.length < 9) {
        hn = hn.padStart(9, '0');
        $('#search_hn').val(hn);
    }
    currentLabHn = hn;
    const includeNetwork = $('#includeNetwork').is(':checked');
    const months = parseInt($('#search_months').val(), 10);
    const monthsVal = [3, 6, 12, 36, 60, 0].indexOf(months) >= 0 ? months : 12;
    SMART_LAB_NETWORK = includeNetwork ? '1' : '0';
    SMART_LAB_MONTHS = String(monthsVal);
    try { localStorage.setItem('tham_network_hospitals', SMART_LAB_NETWORK); } catch (e) {}
    try { localStorage.setItem('tham_lookback_months', SMART_LAB_MONTHS); } catch (e) {}

    selectedLabOrderKey = null;
    globalLabOrders = [];
    globalLabItemsByOrder = {};
    $('#labEmptyState').addClass('d-none');
    $('#labResultPanel').show();
    $('#labPatientBar').removeClass('d-none');
    $('#labPatientName').text('กำลังโหลด...');
    $('#labNetBadge').toggleClass('d-none', !includeNetwork);
    $('#labCacheHint').text('');
    $('#networkStatus').html('');
    $('#labHistoryList').html('<div class="text-center text-primary py-5"><i class="fas fa-spinner fa-spin fa-2x"></i><div class="mt-2 small">กำลังโหลดวันที่ตรวจ...</div></div>');
    $('#labItemsBody').html('<tr><td colspan="4" class="text-center text-primary py-5"><i class="fas fa-spinner fa-spin fa-2x mb-2 d-block"></i>กำลังดึง Lab จาก HOSxP' + (includeNetwork ? ' และรพ.เครือข่าย' : '') + '...</td></tr>');
    startLabClock();

    try {
        const response = await fetch('fetch_smart_lab_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                hn: hn,
                months: monthsVal,
                include_network: includeNetwork
            })
        });
        const raw = await response.text();
        let data;
        try {
            data = JSON.parse(raw);
        } catch (e) {
            throw new Error('เซิร์ฟเวอร์ตอบกลับไม่ถูกต้อง');
        }
        stopLabClock();

        const t = (data.meta && data.meta.timing) || {};
        let timeHtml = t.total_ms != null
            ? ('ใช้เวลา <strong>' + formatLoadMs(t.total_ms) + '</strong>'
                + ' <span class="text-muted">(รพ.นี้ ' + formatLoadMs(t.local_ms || 0)
                + (includeNetwork ? ' · เครือข่าย ' + formatLoadMs(t.network_ms || 0) : '')
                + ')</span>')
            : '';
        const lookHtml = 'ย้อนหลัง ' + escapeHtml((data.meta && data.meta.lookback_label) || '');

        if (data.status !== 'success') {
            $('#labPatientName').text('-');
            $('#labHistoryList').html('<div class="text-danger py-4 px-2 small text-center">' + escapeHtml(data.message || 'เกิดข้อผิดพลาด') + '</div>');
            $('#labItemsBody').html('<tr><td colspan="4" class="text-center text-danger py-5">' + escapeHtml(data.message || 'เกิดข้อผิดพลาด') + '</td></tr>');
            $('#loadTiming').html(timeHtml || '');
            return;
        }

        globalLabOrders = data.orders || [];
        globalLabItemsByOrder = data.items_by_order || {};
        const patient = data.patient || {};
        $('#labPatientName').text(patient.fullname || ('HN ' + (patient.hn || hn)));
        renderNetworkStatus(data.meta || {});

        if (!globalLabOrders.length) {
            $('#labHistoryList').html('<div class="text-center text-warning py-4 small">ไม่พบประวัติผล Lab ที่ยืนยันแล้ว</div>');
            $('#labItemsBody').html('<tr><td colspan="4" class="text-center text-warning py-5">ไม่พบประวัติผล Lab</td></tr>');
            $('#labCacheHint').html('<i class="fas fa-info-circle me-1"></i>ไม่พบข้อมูล');
            $('#loadTiming').html(lookHtml + (timeHtml ? ' · ' + timeHtml : ''));
            return;
        }

        // เลือกใบจาก URL ถ้ามี ไม่งั้นใบแรก
        let wantKey = '';
        try {
            wantKey = new URLSearchParams(window.location.search).get('lab_order') || '';
        } catch (e) {}
        if (!wantKey || !globalLabItemsByOrder[wantKey]) {
            wantKey = globalLabOrders[0].order_key;
        }
        selectedLabOrderKey = wantKey;
        renderOrderList(globalLabOrders);
        renderLabItems(wantKey);
        $('#labCacheHint').html('<i class="fas fa-check me-1"></i>' + globalLabOrders.length + ' ใบ · สลับวันที่ทันที');
        $('#loadTiming').html(lookHtml + ' · ' + globalLabOrders.length + ' ใบ'
            + (timeHtml ? '<br>' + timeHtml : ''));

        try {
            const url = new URL(window.location.href);
            url.searchParams.set('hn', hn);
            url.searchParams.set('lab_order', wantKey);
            url.searchParams.set('network', SMART_LAB_NETWORK);
            url.searchParams.set('months', SMART_LAB_MONTHS);
            window.history.replaceState({ lab_order: wantKey }, '', url.toString());
        } catch (e) {}
    } catch (err) {
        stopLabClock();
        $('#labHistoryList').html('<div class="text-danger py-4 px-2 small text-center">' + escapeHtml(err.message || 'เชื่อมต่อไม่สำเร็จ') + '</div>');
        $('#labItemsBody').html('<tr><td colspan="4" class="text-center text-danger py-5">' + escapeHtml(err.message || 'เชื่อมต่อไม่สำเร็จ') + '</td></tr>');
        $('#loadTiming').text('');
    }
}

function hospitalColor(code, map) {
    if (!map[code]) {
        map[code] = LAB_HOSP_COLORS[Object.keys(map).length % LAB_HOSP_COLORS.length];
    }
    return map[code];
}

function openGraphModal(hn, labCode, labName, hospital, tmlt) {
    hn = hn || currentLabHn || '';
    hospital = hospital || 'local';
    tmlt = tmlt || '';
    labCode = labCode || '';
    labName = labName || '';
    if (!hn) {
        alert('ไม่พบ HN สำหรับดูแนวโน้ม');
        return;
    }
    document.getElementById('modalLabTitle').innerHTML = '<i class="fas fa-history me-2"></i> ประวัติค่า ' + escapeHtml(labName);
    document.getElementById('modalNormalRange').innerText = '-';
    document.getElementById('labMatchHint').innerText = '';
    const legend = document.getElementById('labTrendLegend');
    if (legend) legend.innerHTML = '';
    const modalEl = document.getElementById('graphModal');
    const graphModal = (bootstrap.Modal.getOrCreateInstance
        ? bootstrap.Modal.getOrCreateInstance(modalEl)
        : new bootstrap.Modal(modalEl));
    graphModal.show();
    document.getElementById('chartLoading').style.display = 'block';
    document.getElementById('chartContainer').style.display = 'none';
    document.getElementById('textContainer').style.display = 'none';

    const qs = new URLSearchParams({
        ajax_graph: 'true',
        hn: hn,
        lab_code: labCode,
        lab_name: labName,
        hospital: hospital,
        tmlt: tmlt,
        network: SMART_LAB_NETWORK,
        months: SMART_LAB_MONTHS
    });
    fetch('smart_lab.php?' + qs.toString())
        .then(function (r) { return r.text(); })
        .then(function (raw) {
            let data;
            try {
                data = JSON.parse(raw);
            } catch (e) {
                throw new Error('ตอบกลับไม่ถูกต้อง');
            }
            document.getElementById('chartLoading').style.display = 'none';
            if (data.status !== 'success') {
                document.getElementById('textContainer').style.display = 'block';
                document.getElementById('textContainer').innerHTML = '<div class="alert alert-danger mt-4">' + escapeHtml(data.message || 'ไม่พบข้อมูล') + '</div>';
                return;
            }
            document.getElementById('modalNormalRange').innerText = data.normal_range || 'ไม่มีข้อมูลในระบบ';
            const match = data.match || {};
            let hint = 'เทียบด้วยรหัส Lab ของรพ.นี้';
            if (match.via === 'tmlt' && match.tmlt) {
                hint = 'เทียบข้ามรพ.ด้วยรหัส TMLT ' + match.tmlt;
            } else if (match.via === 'name') {
                hint = 'เทียบข้ามรพ.ด้วยชื่อรายการ Lab';
            }
            document.getElementById('labMatchHint').innerText = hint;

            if (data.data_type === 'text') {
                document.getElementById('chartContainer').style.display = 'none';
                document.getElementById('textContainer').style.display = 'block';
                let html = '<ul class="list-group shadow-sm">';
                for (let i = 0; i < data.dates.length; i++) {
                    const val = data.raw_values[i] || '';
                    const valLower = val.toLowerCase();
                    let badgeClass = 'bg-secondary';
                    if (valLower.includes('positive') || val.includes('+') || valLower.includes('reactive')) badgeClass = 'bg-danger';
                    else if (valLower.includes('negative') || valLower.includes('non-reactive') || valLower.includes('normal')) badgeClass = 'bg-success';
                    const hosp = (data.hospitals && data.hospitals[i]) ? data.hospitals[i] : '';
                    html += '<li class="list-group-item d-flex justify-content-between align-items-center p-3">'
                        + '<span class="fw-bold text-secondary"><i class="fas fa-calendar-day me-2 text-info"></i> ' + escapeHtml(data.dates[i]) + '</span>'
                        + '<span class="d-flex align-items-center gap-2">'
                        + (hosp ? '<span class="badge bg-success">' + escapeHtml(hosp) + '</span>' : '')
                        + '<span class="badge ' + badgeClass + ' rounded-pill fs-6 px-3 py-2">' + escapeHtml(val || '-') + '</span>'
                        + '</span></li>';
                }
                html += '</ul>';
                document.getElementById('textContainer').innerHTML = html;
            } else {
                document.getElementById('textContainer').style.display = 'none';
                document.getElementById('chartContainer').style.display = 'block';
                renderChart(labName, data.dates, data.values, data.hospitals || [], data.hospital_codes || [], data.raw_values || []);
            }
        })
        .catch(function (err) {
            document.getElementById('chartLoading').style.display = 'none';
            document.getElementById('textContainer').style.display = 'block';
            document.getElementById('textContainer').innerHTML = '<div class="alert alert-danger mt-4">'
                + escapeHtml((err && err.message) || 'เกิดข้อผิดพลาดในการดึงข้อมูล') + '</div>';
        });
}

window.openGraphModal = openGraphModal;

function renderChart(labName, labels, dataValues, hospitals, hospitalCodes, rawValues) {
    rawValues = rawValues || [];
    const ctx = document.getElementById('labChart').getContext('2d');
    if (labChartInstance) labChartInstance.destroy();
    const colorMap = {};
    const pointColors = labels.map(function (_, i) {
        return hospitalColor(hospitalCodes[i] || 'local', colorMap);
    });
    const legendEl = document.getElementById('labTrendLegend');
    if (legendEl) {
        const seen = [];
        let html = '';
        labels.forEach(function (_, i) {
            const code = hospitalCodes[i] || 'local';
            if (seen.indexOf(code) >= 0) return;
            seen.push(code);
            html += '<span class="me-3"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:'
                + colorMap[code] + ';margin-right:4px;"></span>' + escapeHtml(hospitals[i] || code) + '</span>';
        });
        legendEl.innerHTML = html;
    }
    labChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'ค่า ' + labName,
                data: dataValues,
                borderColor: '#0dcaf0',
                backgroundColor: 'rgba(13, 202, 240, 0.12)',
                borderWidth: 3,
                pointBackgroundColor: pointColors,
                pointBorderColor: pointColors,
                pointRadius: 6,
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function (context) {
                            const i = context.dataIndex;
                            const hosp = hospitals[i] ? ' · ' + hospitals[i] : '';
                            const raw = rawValues[i] ? String(rawValues[i]) : '';
                            const num = context.parsed.y;
                            const shown = raw && raw !== String(num)
                                ? num.toLocaleString() + ' (' + raw + ')'
                                : (num != null ? num.toLocaleString() : raw || '-');
                            return 'ผลลัพธ์: ' + shown + hosp;
                        }
                    }
                }
            },
            scales: {
                y: { beginAtZero: false, grid: { color: '#f0f0f0' } },
                x: {
                    grid: { display: false },
                    ticks: { maxRotation: 55, minRotation: 55, autoSkip: true, maxTicksLimit: 10, font: { size: 10 } }
                }
            }
        }
    });
}

$(function () {
    // ค่าเริ่มต้นจาก localStorage
    if (!$('#search_hn').val()) {
        try {
            const savedNet = localStorage.getItem('tham_network_hospitals');
            if (savedNet === '0') $('#includeNetwork').prop('checked', false);
            else if (savedNet === '1') $('#includeNetwork').prop('checked', true);
            const savedMonths = localStorage.getItem('tham_lookback_months');
            if (savedMonths && $('#search_months option[value="' + savedMonths + '"]').length) {
                $('#search_months').val(savedMonths);
            }
        } catch (e) {}
    }

    $('#smartLabForm').on('submit', function (e) {
        e.preventDefault();
        fetchSmartLabData();
    });

    $('#labHistoryList').on('click', '.lab-order-item', function () {
        const key = $(this).attr('data-order-key');
        if (!key || key === selectedLabOrderKey) return;
        selectLabOrder(key, true);
    });

    $('#labItemsBody').on('click', '.btn-lab-trend', function (e) {
        e.preventDefault();
        e.stopPropagation();
        const $btn = $(this);
        openGraphModal(
            currentLabHn,
            $btn.attr('data-lab-code') || '',
            $btn.attr('data-lab-name') || '',
            $btn.attr('data-hospital') || 'local',
            $btn.attr('data-tmlt') || ''
        );
    });

    if ($('#search_hn').val().trim()) {
        fetchSmartLabData();
    } else {
        $('#labEmptyState').removeClass('d-none');
    }
});
</script>
</body>
</html>
