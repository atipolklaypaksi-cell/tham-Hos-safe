<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/med_error_helper.php';
mysqli_set_charset($con, 'utf8');
med_error_ensure_tables($con);

$has_start = isset($_GET['start_date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', trim((string)$_GET['start_date']));
$has_end = isset($_GET['end_date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', trim((string)$_GET['end_date']));
$start_date = $has_start ? trim((string)$_GET['start_date']) : '';
$end_date = $has_end ? trim((string)$_GET['end_date']) : '';

if ($start_date === '' || $end_date === '') {
    $dmin = '';
    $dmax = '';
    $q_range = mysqli_query($con, "SELECT MIN(DATE(incident_date)) AS dmin, MAX(DATE(incident_date)) AS dmax FROM med_error_records");
    if ($q_range && ($rr = mysqli_fetch_assoc($q_range))) {
        $dmin = ($rr['dmin'] && $rr['dmin'] !== '0000-00-00') ? $rr['dmin'] : '';
        $dmax = ($rr['dmax'] && $rr['dmax'] !== '0000-00-00') ? $rr['dmax'] : '';
    }
    if ($end_date === '') {
        $end_date = $dmax !== '' ? $dmax : date('Y-m-d');
        if ($end_date < date('Y-m-d')) {
            $end_date = date('Y-m-d');
        }
    }
    if ($start_date === '') {
        $start_date = $dmin !== '' ? $dmin : date('Y-m-01');
    }
}
if ($start_date > $end_date) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}
$start_esc = mysqli_real_escape_string($con, $start_date);
$end_esc = mysqli_real_escape_string($con, $end_date);
$report_filters = med_error_report_filters_from_request($_GET);
$prefill_hn = isset($_GET['hn']) ? htmlspecialchars(trim((string)$_GET['hn']), ENT_QUOTES, 'UTF-8') : '';

$opt_users = '';
$opt_filter_reporters = '<option value="">ทั้งหมด</option>';
$filter_reporter_name = '';
$q_users = mysqli_query($con, "SELECT id, full_name FROM users ORDER BY full_name ASC");
if ($q_users) {
    while ($ru = mysqli_fetch_assoc($q_users)) {
        $uid = (int)$ru['id'];
        $uname = htmlspecialchars($ru['full_name'], ENT_QUOTES, 'UTF-8');
        $selected = ($uid === (int)$_SESSION['user_id']) ? ' selected' : '';
        $opt_users .= '<option value="' . $uid . '"' . $selected . '>' . $uname . '</option>';
        $sel_filter = ($uid === (int)$report_filters['reporter_id']) ? ' selected' : '';
        $opt_filter_reporters .= '<option value="' . $uid . '"' . $sel_filter . '>' . $uname . '</option>';
        if ($uid === (int)$report_filters['reporter_id']) {
            $filter_reporter_name = (string)$ru['full_name'];
        }
    }
}

$error_data = [];
$categories = [];
$type_table_trs = '';
$q_err = mysqli_query($con, "SELECT id, category, name FROM med_error_types ORDER BY category ASC, name ASC");
if ($q_err) {
    while ($r = mysqli_fetch_assoc($q_err)) {
        $cat = $r['category'];
        if (!in_array($cat, $categories, true)) {
            $categories[] = $cat;
        }
        $error_data[$cat][] = ['id' => (int)$r['id'], 'name' => $r['name']];
        $cat_js = htmlspecialchars($r['category'], ENT_QUOTES, 'UTF-8');
        $name_js = htmlspecialchars($r['name'], ENT_QUOTES, 'UTF-8');
        $type_table_trs .= '<tr>
            <td>' . $cat_js . '</td>
            <td>' . $name_js . '</td>
            <td class="text-center">
                <button type="button" class="btn btn-sm btn-outline-warning text-dark fw-bold" onclick="editType(' . (int)$r['id'] . ', \'' . $cat_js . '\', \'' . $name_js . '\')"><i class="fas fa-edit"></i></button>
                <a href="action_error_type.php?action=delete&id=' . (int)$r['id'] . '" class="btn btn-sm btn-outline-danger" onclick="return confirm(\'ยืนยันลบหัวข้อนี้?\');"><i class="fas fa-trash"></i></a>
            </td>
        </tr>';
    }
}
$error_json = json_encode($error_data, JSON_UNESCAPED_UNICODE);

if ($report_filters['category'] !== '' && !in_array($report_filters['category'], $categories, true)) {
    $report_filters['category'] = '';
}
$date_where = "DATE(m.incident_date) BETWEEN '{$start_esc}' AND '{$end_esc}'";
$filter_sql = med_error_report_filter_sql($con, $report_filters);
if ($filter_sql) {
    $date_where .= ' AND ' . implode(' AND ', $filter_sql);
}
$range_qs = med_error_report_query_string($start_date, $end_date, $report_filters);
$range_label = date('d/m/Y', strtotime($start_date)) . ' – ' . date('d/m/Y', strtotime($end_date));
$filter_bits = med_error_report_filter_label($report_filters, $filter_reporter_name);
if ($filter_bits) {
    $range_label .= ' · ' . implode(' · ', $filter_bits);
}

$had_drugs = med_error_list_had_drugs($con);
$had_icodes = [];
$had_labels = [];
$had_table_trs = '';
foreach ($had_drugs as $hd) {
    if ($hd['icode'] !== '') {
        $had_icodes[$hd['icode']] = true;
    }
    $lab = function_exists('mb_strtolower') ? mb_strtolower($hd['label'], 'UTF-8') : strtolower($hd['label']);
    if ($lab !== '') {
        $had_labels[$lab] = true;
    }
    $icode_js = htmlspecialchars($hd['icode'], ENT_QUOTES, 'UTF-8');
    $label_js = htmlspecialchars($hd['label'], ENT_QUOTES, 'UTF-8');
    $had_table_trs .= '<tr data-had-id="' . (int)$hd['id'] . '">
        <td class="text-center">' . $icode_js . '</td>
        <td>' . $label_js . '</td>
        <td class="text-center">
            <button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteHadDrug(' . (int)$hd['id'] . ')"><i class="fas fa-trash"></i></button>
        </td>
    </tr>';
}
if ($had_table_trs === '') {
    $had_table_trs = '<tr id="hadEmptyRow"><td colspan="3" class="text-center text-muted py-3">ยังไม่มีรายการยา HAD</td></tr>';
}
$had_icodes_json = json_encode($had_icodes, JSON_UNESCAPED_UNICODE | JSON_FORCE_OBJECT);
$had_labels_json = json_encode($had_labels, JSON_UNESCAPED_UNICODE | JSON_FORCE_OBJECT);

$doctor_groups = med_error_list_doctor_groups($con);
$doctor_group_map = [];
$doctor_group_trs = '';
foreach ($doctor_groups as $dg) {
    if ($dg['code'] !== '') {
        $doctor_group_map[$dg['code']] = [
            'group' => $dg['group'],
            'name' => $dg['name'],
            'group_label' => $dg['group_label'],
        ];
    }
    $code_js = htmlspecialchars($dg['code'], ENT_QUOTES, 'UTF-8');
    $name_js = htmlspecialchars($dg['name'], ENT_QUOTES, 'UTF-8');
    $group_js = htmlspecialchars($dg['group'], ENT_QUOTES, 'UTF-8');
    $group_label_js = htmlspecialchars($dg['group_label'], ENT_QUOTES, 'UTF-8');
    $badge = 'bg-secondary';
    if ($dg['group'] === 'staff') {
        $badge = 'bg-primary';
    } elseif ($dg['group'] === 'intern') {
        $badge = 'bg-info text-dark';
    } elseif ($dg['group'] === 'extern') {
        $badge = 'bg-dark';
    }
    $doctor_group_trs .= '<tr data-doc-group-id="' . (int)$dg['id'] . '">
        <td class="text-center">' . $code_js . '</td>
        <td>' . $name_js . '</td>
        <td class="text-center"><span class="badge ' . $badge . '">' . $group_label_js . '</span></td>
        <td class="text-center">
            <button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteDoctorGroup(' . (int)$dg['id'] . ')"><i class="fas fa-trash"></i></button>
        </td>
    </tr>';
}
if ($doctor_group_trs === '') {
    $doctor_group_trs = '<tr id="doctorGroupEmptyRow"><td colspan="4" class="text-center text-muted py-3">ยังไม่ได้จัดกลุ่มแพทย์</td></tr>';
}
$doctor_group_map_json = json_encode($doctor_group_map, JSON_UNESCAPED_UNICODE | JSON_FORCE_OBJECT);

$total_errors = 0;
$count_near_miss = 0;
$count_reached = 0;
$count_harm = 0;
$cat_counts = [];
$level_counts = array_fill_keys(['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'], 0);
$type_counts = [];

$q_stats = mysqli_query($con, "SELECT m.error_level, t.category, t.name AS type_name
    FROM med_error_records m
    LEFT JOIN med_error_types t ON m.error_type_id = t.id
    WHERE {$date_where}");
if ($q_stats) {
    while ($s = mysqli_fetch_assoc($q_stats)) {
        $total_errors++;
        $lvl = strtoupper(trim((string)$s['error_level']));
        if (in_array($lvl, ['A', 'B'], true)) {
            $count_near_miss++;
        } elseif (in_array($lvl, ['C', 'D'], true)) {
            $count_reached++;
        } elseif (in_array($lvl, ['E', 'F', 'G', 'H', 'I'], true)) {
            $count_harm++;
        }
        if (isset($level_counts[$lvl])) {
            $level_counts[$lvl]++;
        }
        $cat = $s['category'] ?: 'ไม่ระบุ';
        if (!isset($cat_counts[$cat])) {
            $cat_counts[$cat] = 0;
        }
        $cat_counts[$cat]++;
        $tname = $s['type_name'] ?: 'ไม่ระบุ';
        if (!isset($type_counts[$tname])) {
            $type_counts[$tname] = 0;
        }
        $type_counts[$tname]++;
    }
}
arsort($type_counts);
$top_types = array_slice($type_counts, 0, 8, true);
$chart_cat_labels = array_keys($cat_counts);
$chart_cat_data = array_values($cat_counts);
$chart_level_labels = [];
$chart_level_data = [];
$chart_level_colors = [];
$level_color_map = [
    'A' => '#198754', 'B' => '#20c997', 'C' => '#0d6efd', 'D' => '#0dcaf0',
    'E' => '#ffc107', 'F' => '#fd7e14', 'G' => '#dc3545', 'H' => '#b02a37', 'I' => '#6f1d1b',
];
foreach ($level_counts as $lv => $cnt) {
    if ($cnt > 0) {
        $chart_level_labels[] = 'Level ' . $lv;
        $chart_level_data[] = $cnt;
        $chart_level_colors[] = $level_color_map[$lv];
    }
}
$chart_type_labels = array_keys($top_types);
$chart_type_data = array_values($top_types);

$history_trs = '';
$sql_hist = "SELECT m.*, t.category, t.name AS type_name, u.full_name AS reporter_name
             FROM med_error_records m
             LEFT JOIN med_error_types t ON m.error_type_id = t.id
             LEFT JOIN users u ON m.reporter_id = u.id
             WHERE {$date_where}
             ORDER BY m.incident_date DESC";
$q_hist = mysqli_query($con, $sql_hist);
if ($q_hist) {
    while ($r = mysqli_fetch_assoc($q_hist)) {
        $incident_ts = strtotime($r['incident_date']);
        $incident_day_str = $incident_ts ? date('d/m/Y', $incident_ts) : '';
        $incident_time_str = $incident_ts ? date('H:i', $incident_ts) : '';
        $date_input = $incident_ts ? date('Y-m-d', $incident_ts) : '';
        $time_input = $incident_ts ? date('H:i', $incident_ts) : '';
        $created_ts = !empty($r['created_at']) ? strtotime($r['created_at']) : 0;
        $created_str = $created_ts ? date('d/m/Y H:i', $created_ts) : '';
        $pat_name = htmlspecialchars((string)($r['patient_name'] ?? ''), ENT_QUOTES, 'UTF-8');

        $kind = med_error_sanitize_record_kind($r['record_kind'] ?? 'error');
        $kind_safe = htmlspecialchars($kind, ENT_QUOTES, 'UTF-8');
        $cat_badge = '<span class="badge bg-dark">' . htmlspecialchars((string)$r['category'], ENT_QUOTES, 'UTF-8') . '</span>';
        if ($kind === 'consult') {
            $cat_badge = '<span class="badge bg-info text-dark">Consult</span>';
        } elseif ($r['category'] === 'Prescribing Error') {
            $cat_badge = '<span class="badge bg-primary">Prescribing</span>';
        } elseif ($r['category'] === 'Transcribing Error') {
            $cat_badge = '<span class="badge bg-info text-dark">Transcribing</span>';
        } elseif ($r['category'] === 'Pre-dispensing error') {
            $cat_badge = '<span class="badge bg-secondary">Pre-dispensing</span>';
        } elseif ($r['category'] === 'Dispensing Error') {
            $cat_badge = '<span class="badge bg-warning text-dark">Dispensing</span>';
        } elseif ($r['category'] === 'Administration Error') {
            $cat_badge = '<span class="badge bg-danger">Administration</span>';
        }

        $intv_module = isset($r['intervention_module']) ? trim((string)$r['intervention_module']) : '';
        $intv_module_safe = htmlspecialchars($intv_module, ENT_QUOTES, 'UTF-8');
        $intv_badge = $intv_module !== '' ? '<br><span class="badge bg-success mt-1">Intervention: ' . $intv_module_safe . '</span>' : '';

        $lvl = (string)($r['error_level'] ?? '');
        $lvl_badge = '<span class="badge bg-secondary">' . htmlspecialchars($lvl, ENT_QUOTES, 'UTF-8') . '</span>';
        if ($kind === 'consult') {
            $lvl_badge = '<span class="badge bg-info text-dark">Consult</span>';
        } elseif (in_array($lvl, ['A', 'B', 'C', 'D'], true)) {
            $lvl_badge = '<span class="badge bg-success">Level ' . htmlspecialchars($lvl, ENT_QUOTES, 'UTF-8') . '</span>';
        }
        if (in_array($lvl, ['E', 'F'], true)) {
            $lvl_badge = '<span class="badge bg-warning text-dark">Level ' . htmlspecialchars($lvl, ENT_QUOTES, 'UTF-8') . '</span>';
        }
        if (in_array($lvl, ['G', 'H', 'I'], true)) {
            $lvl_badge = '<span class="badge bg-danger">Level ' . htmlspecialchars($lvl, ENT_QUOTES, 'UTF-8') . '</span>';
        }

        $desc_safe = htmlspecialchars((string)$r['description'], ENT_QUOTES, 'UTF-8');
        $solution_raw = isset($r['solution']) ? (string)$r['solution'] : '';
        $solution_safe = htmlspecialchars($solution_raw, ENT_QUOTES, 'UTF-8');
        $hn_safe = htmlspecialchars((string)$r['hn'], ENT_QUOTES, 'UTF-8');
        $cat_safe = htmlspecialchars((string)$r['category'], ENT_QUOTES, 'UTF-8');
        $type_name_safe = htmlspecialchars((string)($r['type_name'] ?? ''), ENT_QUOTES, 'UTF-8');
        if ($kind === 'consult') {
            $type_name_safe = 'ไม่ใช่ความคลาดเคลื่อนจริง';
        }
        $reporter_safe = htmlspecialchars((string)($r['reporter_name'] ?? ''), ENT_QUOTES, 'UTF-8');

        $ptype = strtoupper(trim((string)($r['patient_type'] ?? '')));
        $an_safe = htmlspecialchars(trim((string)($r['an'] ?? '')), ENT_QUOTES, 'UTF-8');
        $vn_safe = htmlspecialchars(trim((string)($r['vn'] ?? '')), ENT_QUOTES, 'UTF-8');
        $ptype_badge = '';
        if ($ptype === 'IPD') {
            $ptype_badge = '<span class="badge bg-danger">ผู้ป่วยใน</span>';
        } elseif ($ptype === 'OPD') {
            $ptype_badge = '<span class="badge bg-primary">ผู้ป่วยนอก</span>';
        }
        $visit_meta = '';
        if ($an_safe !== '') {
            $visit_meta .= '<div class="small text-muted">AN ' . $an_safe . '</div>';
        }
        if ($vn_safe !== '') {
            $visit_meta .= '<div class="small text-muted">VN ' . $vn_safe . '</div>';
        }

        $report_safe = htmlspecialchars(trim((string)($r['reporting_dept'] ?? '')), ENT_QUOTES, 'UTF-8');
        $error_dept_safe = htmlspecialchars(trim((string)($r['error_dept'] ?? '')), ENT_QUOTES, 'UTF-8');
        $dept_meta = '';
        if ($report_safe !== '') {
            $dept_label = ($kind === 'consult') ? 'จุดตรวจ: ' : 'รายงาน: ';
            $dept_meta .= '<div class="small text-primary mt-1">' . $dept_label . $report_safe . '</div>';
        }
        if ($kind !== 'consult' && $error_dept_safe !== '') {
            $dept_meta .= '<div class="small text-danger">เกิดที่: ' . $error_dept_safe . '</div>';
        }

        $error_drugs = med_error_parse_drugs($r['error_drugs'] ?? '[]');
        $correct_drugs = med_error_parse_drugs($r['correct_drugs'] ?? '[]');
        $error_drugs_text = med_error_drugs_list_text($error_drugs);
        $correct_drugs_text = med_error_drugs_list_text($correct_drugs);
        $error_drugs_safe = htmlspecialchars($error_drugs_text, ENT_QUOTES, 'UTF-8');
        $correct_drugs_safe = htmlspecialchars($correct_drugs_text, ENT_QUOTES, 'UTF-8');
        $error_drugs_json = htmlspecialchars(med_error_drugs_json($error_drugs), ENT_QUOTES, 'UTF-8');
        $correct_drugs_json = htmlspecialchars(med_error_drugs_json($correct_drugs), ENT_QUOTES, 'UTF-8');
        $drug_meta = '';
        if ($error_drugs_safe !== '') {
            $drug_meta .= '<div class="small text-danger mt-1">ยาที่ Error: ' . $error_drugs_safe . '</div>';
        }
        if ($correct_drugs_safe !== '') {
            $drug_meta .= '<div class="small text-success">ยาที่ถูกต้อง: ' . $correct_drugs_safe . '</div>';
        }
        $is_had = med_error_sanitize_yes_no($r['is_had'] ?? 'NO', 'NO');
        $is_robot = med_error_sanitize_yes_no($r['is_robot'] ?? 'NO', 'NO');
        $flag_meta = '';
        if ($is_had === 'YES') {
            $flag_meta .= '<span class="badge bg-danger me-1">HAD</span>';
        }
        if ($is_robot === 'YES') {
            $flag_meta .= '<span class="badge bg-primary me-1">Robot</span>';
        }
        $rx_type = med_error_sanitize_rx_type($r['rx_type'] ?? '', $ptype);
        $rx_label = med_error_rx_type_label($rx_type);
        $rx_safe = htmlspecialchars($rx_type, ENT_QUOTES, 'UTF-8');
        if ($rx_label !== '') {
            $flag_meta .= '<span class="badge bg-dark me-1">' . htmlspecialchars($rx_label, ENT_QUOTES, 'UTF-8') . '</span>';
        }
        if ($flag_meta !== '') {
            $drug_meta .= '<div class="mt-1">' . $flag_meta . '</div>';
        }

        $doc_code = trim((string)($r['order_doctor_code'] ?? ''));
        $doc_name = trim((string)($r['order_doctor_name'] ?? ''));
        $doc_group = med_error_sanitize_doctor_group($r['order_doctor_group'] ?? '');
        $doc_group_label = med_error_doctor_group_label($doc_group);
        $doc_code_safe = htmlspecialchars($doc_code, ENT_QUOTES, 'UTF-8');
        $doc_name_safe = htmlspecialchars($doc_name, ENT_QUOTES, 'UTF-8');
        $doc_group_safe = htmlspecialchars($doc_group, ENT_QUOTES, 'UTF-8');
        $doc_meta = '';
        if ($doc_name !== '' || $doc_code !== '') {
            $doc_badge = '';
            if ($doc_group_label !== '') {
                $doc_badge_class = 'bg-secondary';
                if ($doc_group === 'staff') {
                    $doc_badge_class = 'bg-primary';
                } elseif ($doc_group === 'intern') {
                    $doc_badge_class = 'bg-info text-dark';
                } elseif ($doc_group === 'extern') {
                    $doc_badge_class = 'bg-dark';
                }
                $doc_badge = ' <span class="badge ' . $doc_badge_class . '">' . htmlspecialchars($doc_group_label, ENT_QUOTES, 'UTF-8') . '</span>';
            }
            $doc_meta = '<div class="small text-muted mt-1"><i class="fas fa-user-md me-1"></i>' . ($doc_name_safe !== '' ? $doc_name_safe : $doc_code_safe) . $doc_badge . '</div>';
        }

        $history_trs .= "<tr>
            <td class='text-center text-nowrap' data-order='{$incident_ts}'>{$incident_day_str}</td>
            <td class='text-center text-nowrap'>{$incident_time_str}</td>
            <td class='text-center text-nowrap' data-order='{$created_ts}'><small>{$created_str}</small></td>
            <td class='text-center fw-bold text-primary'>{$hn_safe}{$visit_meta}</td>
            <td>{$pat_name}<div class='mt-1'>{$ptype_badge}</div>{$doc_meta}</td>
            <td>{$cat_badge}{$intv_badge}<br><small class='text-muted'>{$type_name_safe}</small>{$dept_meta}</td>
            <td class='text-center'>{$lvl_badge}</td>
            <td>{$desc_safe}{$drug_meta}</td>
            <td>{$solution_safe}</td>
            <td class='text-center'><small>{$reporter_safe}</small></td>
            <td class='text-center'>
                <div class='btn-group' role='group'>
                    <button type='button' class='btn btn-sm btn-outline-warning text-dark fw-bold'
                        data-id='{$r['id']}' data-hn='{$hn_safe}' data-name='{$pat_name}'
                        data-date='{$date_input}' data-time='{$time_input}' data-cat='{$cat_safe}'
                        data-type='" . htmlspecialchars((string)($r['error_type_id'] ?? ''), ENT_QUOTES, 'UTF-8') . "' data-lvl='" . htmlspecialchars($lvl, ENT_QUOTES, 'UTF-8') . "'
                        data-desc='{$desc_safe}' data-solution='{$solution_safe}' data-reporter='{$r['reporter_id']}'
                        data-intv-module='{$intv_module_safe}' data-ptype='{$ptype}' data-an='{$an_safe}' data-vn='{$vn_safe}'
                        data-reporting='{$report_safe}' data-error-dept='{$error_dept_safe}'
                        data-error-drugs='{$error_drugs_json}' data-correct-drugs='{$correct_drugs_json}'
                        data-had='{$is_had}' data-robot='{$is_robot}' data-rx-type='{$rx_safe}'
                        data-kind='{$kind_safe}' data-doctor-code='{$doc_code_safe}' data-doctor-name='{$doc_name_safe}' data-doctor-group='{$doc_group_safe}'
                        onclick='editRecord(this)' title='แก้ไข'><i class='fas fa-edit'></i></button>
                    <button type='button' class='btn btn-sm btn-outline-danger' onclick='deleteRecord({$r['id']})' title='ลบข้อมูล'><i class='fas fa-trash-alt'></i></button>
                </div>
            </td>
        </tr>";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>บันทึกความคลาดเคลื่อนทางยา (Medication Error)/ปรึกษาแพทย์ - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .readonly-field { background-color: #e9ecef !important; cursor: not-allowed; font-weight: bold; }
        .kpi-card { border-radius: 12px; border: none; box-shadow: 0 4px 12px rgba(0,0,0,0.06); }
        .kpi-value { font-size: 2rem; font-weight: 800; line-height: 1.1; }
        .chart-box { position: relative; height: 260px; }
        .ptype-toggle .btn { font-weight: 700; }
        .ptype-toggle .btn-check:checked + .btn-outline-primary { background-color: #0d6efd; color: #fff; }
        .ptype-toggle .btn-check:checked + .btn-outline-danger { background-color: #dc3545; color: #fff; }
        .ptype-toggle .btn-check:checked + .btn-outline-secondary { background-color: #6c757d; color: #fff; }
        .ptype-toggle .btn-check:checked + .btn-outline-dark { background-color: #212529; color: #fff; }
        .ptype-toggle .btn-check:checked + .btn-outline-info { background-color: #0dcaf0; color: #053b4b; }
        .drug-picker { position: relative; }
        .drug-search-wrap { position: relative; }
        .drug-chips { display: flex; flex-wrap: wrap; gap: 6px; min-height: 0; }
        .drug-chip { display: inline-flex; align-items: center; gap: 6px; background: #fff; border: 1px solid #dee2e6; border-radius: 999px; padding: 3px 10px; font-size: 0.85rem; max-width: 100%; }
        .drug-chip.error { border-color: #f1aeb5; background: #fff5f5; }
        .drug-chip.correct { border-color: #a3cfbb; background: #f0fff4; }
        .drug-chip .chip-x { border: 0; background: transparent; color: #888; cursor: pointer; line-height: 1; padding: 0; }
        .drug-suggest { position: absolute; left: 0; right: 0; top: 100%; z-index: 20; max-height: 240px; overflow-y: auto; background: #fff; border: 1px solid #ced4da; border-radius: 6px; box-shadow: 0 8px 18px rgba(0,0,0,0.08); }
        .modal .drug-suggest { z-index: 1080; }
        .drug-suggest button { display: flex; align-items: center; justify-content: space-between; gap: 8px; width: 100%; text-align: left; border: 0; background: #fff; padding: 8px 12px; font-size: 0.9rem; }
        .drug-suggest button:hover, .drug-suggest button.active { background: #e9f2ff; }
        .drug-suggest .suggest-plus { color: #198754; flex-shrink: 0; }
        .consult-item { border: 1px solid #9eeaf9; border-radius: 10px; background: #f4fcff; padding: 10px 12px; margin-bottom: 10px; }
        .consult-item:last-child { margin-bottom: 0; }
        .consult-item .consult-when { font-weight: 800; color: #0aa2c0; font-size: 0.95rem; }
        .consult-item .consult-meta { font-size: 12px; color: #4a6570; margin: 2px 0 6px; }
        .consult-item .consult-label { font-size: 11px; font-weight: 800; color: #0b7285; }
        .consult-item .consult-desc { white-space: pre-wrap; word-break: break-word; font-size: 13px; color: #223; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-3">

            <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                <h4 class="fw-bold mb-0 text-danger"><i class="fas fa-shield-alt me-2"></i>บันทึกความคลาดเคลื่อนทางยา (Medication Error)/ปรึกษาแพทย์</h4>
                <div class="d-flex gap-2">
                    <a class="btn btn-outline-danger btn-sm fw-bold" href="report_med_error.php"><i class="fas fa-chart-bar me-1"></i> รายงาน ME/Consult</a>
                    <button class="btn btn-outline-secondary btn-sm fw-bold" onclick="openManageTypesModal()"><i class="fas fa-cogs me-1"></i> ตั้งค่า</button>
                </div>
            </div>

            <div class="card border-danger mb-4 shadow-sm" id="formCard">
                <div class="card-header bg-danger text-white py-2" id="formHeader">
                    <h6 class="mb-0 fw-bold"><i class="fas fa-edit me-2"></i>ฟอร์มบันทึกเหตุการณ์</h6>
                </div>
                <div class="card-body bg-light p-4">
                    <form action="save_med_error.php" method="POST" id="medErrorForm">
                        <input type="hidden" name="record_id" id="record_id" value="">
                        <input type="hidden" name="patient_name" id="patient_name_hidden" value="">

                        <div class="row g-3 mb-3">
                            <div class="col-12">
                                <label class="form-label fw-bold">ประเภทความคลาดเคลื่อน</label>
                                <div class="btn-group w-100 ptype-toggle flex-wrap" role="group">
                                    <input type="radio" class="btn-check" name="record_kind" id="kind_error" value="error" checked>
                                    <label class="btn btn-outline-danger" for="kind_error"><i class="fas fa-exclamation-triangle me-1"></i>ความคลาดเคลื่อนจริง</label>
                                    <input type="radio" class="btn-check" name="record_kind" id="kind_consult" value="consult">
                                    <label class="btn btn-outline-info" for="kind_consult"><i class="fas fa-comments me-1"></i>ไม่ใช่ความคลาดเคลื่อนจริง (บันทึกการ Consult)</label>
                                </div>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-3">
                                <label class="form-label fw-bold">วันเกิดเหตุ</label>
                                <input type="date" class="form-control" name="incident_date" id="incident_date" required value="<?php echo date('Y-m-d'); ?>" onchange="fetchPatientName({checkConsult:false})">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold">เวลาเกิดเหตุ</label>
                                <input type="time" class="form-control" name="incident_time" id="incident_time" required value="<?php echo date('H:i'); ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold text-success">ผู้บันทึก (Reporter)</label>
                                <select class="form-select border-success fw-bold text-success" name="reporter_id" id="reporter_id" required>
                                    <?php echo $opt_users; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row g-3 mb-3 align-items-end">
                            <div class="col-md-5">
                                <label class="form-label fw-bold">ประเภทผู้ป่วย</label>
                                <div class="btn-group w-100 ptype-toggle" role="group">
                                    <input type="radio" class="btn-check" name="patient_type" id="ptype_opd" value="OPD" required>
                                    <label class="btn btn-outline-primary" for="ptype_opd"><i class="fas fa-clinic-medical me-1"></i>ผู้ป่วยนอก (OPD)</label>
                                    <input type="radio" class="btn-check" name="patient_type" id="ptype_ipd" value="IPD" required>
                                    <label class="btn btn-outline-danger" for="ptype_ipd"><i class="fas fa-procedures me-1"></i>ผู้ป่วยใน (IPD)</label>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label fw-bold">AN</label>
                                <input type="text" class="form-control readonly-field" name="an" id="e_an" readonly placeholder="ดึงจาก HOSxP">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label fw-bold">VN</label>
                                <input type="text" class="form-control readonly-field" name="vn" id="e_vn" readonly placeholder="ดึงจาก HOSxP">
                            </div>
                            <div class="col-md-3">
                                <div id="visitHint" class="small text-muted"></div>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-2">
                                <label class="form-label fw-bold text-primary">HN ผู้ป่วย (Enter)</label>
                                <input type="text" class="form-control border-primary fw-bold" name="hn" id="e_hn" required placeholder="ระบุ HN..." value="<?php echo $prefill_hn; ?>" onchange="fetchPatientName()">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold">ชื่อ - นามสกุล</label>
                                <input type="text" class="form-control readonly-field" id="e_patient_name" readonly placeholder="ดึงข้อมูลจาก HOSxP...">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold">แพทย์ผู้สั่งใช้ยา</label>
                                <input type="hidden" name="order_doctor_code" id="order_doctor_code" value="">
                                <input type="hidden" name="order_doctor_group" id="order_doctor_group" value="">
                                <div class="drug-picker">
                                    <input type="text" class="form-control" name="order_doctor_name" id="order_doctor_name" placeholder="ดึงจาก HOSxP หรือพิมพ์ค้นหา..." autocomplete="off">
                                    <div class="drug-suggest d-none" id="doctorSuggest"></div>
                                </div>
                                <div class="form-text" id="doctorHint">ถ้าไม่พบจาก visit ให้ค้นหาชื่อแพทย์เพื่อเลือก</div>
                            </div>
                            <div class="col-md-3 js-error-only">
                                <label class="form-label fw-bold text-warning">ระดับความรุนแรง (Severity)</label>
                                <select class="form-select border-warning fw-bold" name="error_level" id="error_level" required>
                                    <option value="">- เลือกระดับ -</option>
                                    <option value="A">A - โอกาสเกิดความคลาดเคลื่อน</option>
                                    <option value="B">B - คลาดเคลื่อน แต่ไม่ถึงผู้ป่วย</option>
                                    <option value="C">C - ถึงผู้ป่วย แต่ไม่เกิดอันตราย</option>
                                    <option value="D">D - ถึงผู้ป่วย เฝ้าระวังอาการ</option>
                                    <option value="E">E - อันตรายชั่วคราว ต้องรักษา</option>
                                    <option value="F">F - อันตรายชั่วคราว นอน รพ.</option>
                                    <option value="G">G - เกิดอันตรายถาวร</option>
                                    <option value="H">H - ต้องช่วยชีวิต (CPR)</option>
                                    <option value="I">I - เสียชีวิต</option>
                                </select>
                            </div>
                        </div>

                        <div class="row g-3 mb-3 js-error-only">
                            <div class="col-md-4">
                                <label class="form-label fw-bold text-danger">หมวดหมู่หลัก (Category)</label>
                                <select class="form-select border-danger fw-bold" name="error_category" id="error_category" required onchange="onErrorCategoryChange()">
                                    <option value="">- เลือกหมวดหมู่ -</option>
                                    <?php foreach ($categories as $c) { echo '<option value="' . htmlspecialchars($c, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($c, ENT_QUOTES, 'UTF-8') . '</option>'; } ?>
                                </select>
                            </div>
                            <div class="col-md-8">
                                <label class="form-label fw-bold text-danger">ลักษณะความคลาดเคลื่อน (Error Type)</label>
                                <select class="form-select border-danger" name="error_type_id" id="error_type_id" required>
                                    <option value="">- กรุณาเลือกหมวดหมู่หลักก่อน -</option>
                                </select>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-primary" id="reportingDeptLabel">หน่วยงานที่รายงาน</label>
                                <select class="form-select border-primary" name="reporting_dept" id="reporting_dept" required>
                                    <option value="">- เลือกหน่วยงาน -</option>
                                </select>
                                <input type="text" class="form-control mt-2 d-none" name="reporting_dept_other" id="reporting_dept_other" placeholder="ระบุหน่วยงานที่รายงาน...">
                                <div class="d-none mt-2" id="reporting_dept_ward_box">
                                    <input type="search" class="form-control form-control-sm mb-1" id="reporting_dept_ward_q" placeholder="ค้นหาหอผู้ป่วย แล้วเลือกจากรายการ" autocomplete="off">
                                    <select class="form-select border-primary" name="reporting_dept_ward" id="reporting_dept_ward">
                                        <option value="">- เลือกหอผู้ป่วย -</option>
                                    </select>
                                </div>
                                <div id="deptHint" class="form-text">ถ้าผู้ป่วยจำหน่ายแล้ว ให้เลือก ระบุหอผู้ป่วย</div>
                            </div>
                            <div class="col-md-6 js-error-only">
                                <label class="form-label fw-bold text-danger">หน่วยงานที่เกิด Error</label>
                                <select class="form-select border-danger" name="error_dept" id="error_dept" required>
                                    <option value="">- เลือกหน่วยงาน -</option>
                                </select>
                                <input type="text" class="form-control mt-2 d-none" name="error_dept_other" id="error_dept_other" placeholder="ระบุหน่วยงานที่เกิด Error...">
                                <div class="d-none mt-2" id="error_dept_ward_box">
                                    <input type="search" class="form-control form-control-sm mb-1" id="error_dept_ward_q" placeholder="ค้นหาหอผู้ป่วย แล้วเลือกจากรายการ" autocomplete="off">
                                    <select class="form-select border-danger" name="error_dept_ward" id="error_dept_ward">
                                        <option value="">- เลือกหอผู้ป่วย -</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <input type="hidden" name="intervention_module" id="intervention_module" value="">

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">บรรยายเหตุการณ์ (Description)</label>
                                <textarea class="form-control border-danger" name="description" id="description" rows="4" required placeholder="บรรยายเหตุการณ์ก่อน เช่น จ่ายยาอะไร ควรเป็นยาอะไร..."></textarea>
                                <div id="descDrugHint" class="form-text">ระบบจะแยกยาจากคำบรรยาย และจำยาที่เคยบันทึกไว้เพื่อช่วยกรอกครั้งถัดไป</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-success">การแก้ไขปัญหา (Solution / Action Taken)</label>
                                <textarea class="form-control border-success" name="solution" id="solution" rows="4" placeholder="ระบุวิธีการแก้ไข และยาที่ควรได้รับ..."></textarea>
                            </div>
                        </div>

                        <div class="row g-3 mb-3 js-error-only">
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-danger">ชื่อยาที่ Error</label>
                                <div class="drug-picker" data-kind="error">
                                    <div class="drug-chips mb-2" id="errorDrugChips"></div>
                                    <div class="drug-search-wrap">
                                        <div class="input-group">
                                            <input type="text" class="form-control border-danger" id="errorDrugSearch" placeholder="พิมพ์ชื่อยาเพื่อค้นหา..." autocomplete="off">
                                            <button type="button" class="btn btn-danger" id="errorDrugAddBtn" title="เพิ่มยา" onclick="addDrugFromSearch('error')"><i class="fas fa-plus"></i></button>
                                        </div>
                                        <div class="drug-suggest d-none" id="errorDrugSuggest"></div>
                                    </div>
                                </div>
                                <input type="hidden" name="error_drugs" id="error_drugs" value="[]">
                                <div class="form-text">ดึงจากคำบรรยายอัตโนมัติ และจำยาที่เคยบันทึกไว้เพื่อช่วยกรอกครั้งถัดไป</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-success">ชื่อยาที่ถูกต้อง</label>
                                <div class="drug-picker" data-kind="correct">
                                    <div class="drug-chips mb-2" id="correctDrugChips"></div>
                                    <div class="drug-search-wrap">
                                        <div class="input-group">
                                            <input type="text" class="form-control border-success" id="correctDrugSearch" placeholder="พิมพ์ชื่อยาที่ควรได้รับ..." autocomplete="off">
                                            <button type="button" class="btn btn-success" id="correctDrugAddBtn" title="เพิ่มยา" onclick="addDrugFromSearch('correct')"><i class="fas fa-plus"></i></button>
                                        </div>
                                        <div class="drug-suggest d-none" id="correctDrugSuggest"></div>
                                    </div>
                                </div>
                                <input type="hidden" name="correct_drugs" id="correct_drugs" value="[]">
                                <div class="form-text">ดึงจากยาที่แพทย์สั่ง / “ควรเป็น / แทน” และจำจากรายการที่เคยบันทึก</div>
                            </div>
                        </div>

                        <div class="row g-3 mb-3 js-error-only">
                            <div class="col-md-3">
                                <label class="form-label fw-bold text-danger">ยา HAD (High Alert Drug)</label>
                                <div class="btn-group w-100 ptype-toggle" role="group">
                                    <input type="radio" class="btn-check" name="is_had" id="had_yes" value="YES">
                                    <label class="btn btn-outline-danger" for="had_yes">Yes</label>
                                    <input type="radio" class="btn-check" name="is_had" id="had_no" value="NO" checked>
                                    <label class="btn btn-outline-secondary" for="had_no">No</label>
                                </div>
                                <div id="hadHint" class="form-text">ระบบเลือกอัตโนมัติจากรายการยา HAD ในตั้งค่า</div>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold">Robot</label>
                                <div class="btn-group w-100 ptype-toggle" role="group">
                                    <input type="radio" class="btn-check" name="is_robot" id="robot_yes" value="YES">
                                    <label class="btn btn-outline-primary" for="robot_yes">Yes</label>
                                    <input type="radio" class="btn-check" name="is_robot" id="robot_no" value="NO" checked>
                                    <label class="btn btn-outline-secondary" for="robot_no">No</label>
                                </div>
                                <div class="form-text">ค่าเริ่มต้น: No</div>
                            </div>
                            <div class="col-md-6 d-none" id="rxTypeWrap">
                                <label class="form-label fw-bold">ประเภทใบสั่งยา</label>
                                <div class="btn-group w-100 ptype-toggle" role="group">
                                    <input type="radio" class="btn-check" name="rx_type" id="rx_new" value="new">
                                    <label class="btn btn-outline-dark" for="rx_new">ยาสั่งใหม่</label>
                                    <input type="radio" class="btn-check" name="rx_type" id="rx_home" value="home">
                                    <label class="btn btn-outline-dark" for="rx_home">ยากลับบ้าน</label>
                                    <input type="radio" class="btn-check" name="rx_type" id="rx_continue" value="continue">
                                    <label class="btn btn-outline-dark" for="rx_continue">ยา Continue</label>
                                </div>
                                <div class="form-text">แสดงเฉพาะผู้ป่วยใน</div>
                            </div>
                        </div>

                        <div class="text-end mt-3">
                            <button type="button" class="btn btn-secondary px-3 d-none" id="btnCancelEdit" onclick="cancelEdit()"><i class="fas fa-times me-1"></i>ยกเลิกการแก้ไข</button>
                            <button type="reset" class="btn btn-secondary px-4" id="btnReset"><i class="fas fa-undo me-1"></i>ล้างข้อมูล</button>
                            <button type="submit" class="btn btn-danger px-4 fw-bold shadow-sm" id="btnSubmitForm"><i class="fas fa-save me-2"></i>บันทึกเหตุการณ์</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-bottom py-2">
                    <h6 class="mb-0 fw-bold"><i class="fas fa-filter text-danger me-2"></i>ตัวกรองการดูรายงาน</h6>
                </div>
                <div class="card-body py-3">
                    <?php
                    $rf_sel = function ($key, $val) use ($report_filters) {
                        return ((string)($report_filters[$key] ?? '') === (string)$val) ? ' selected' : '';
                    };
                    ?>
                    <form method="GET" action="med_error.php" class="row g-2 align-items-end">
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1"><i class="far fa-calendar-alt me-1"></i>ตั้งแต่วันที่</label>
                            <input type="date" name="start_date" class="form-control form-control-sm border-primary" value="<?php echo htmlspecialchars($start_date, ENT_QUOTES, 'UTF-8'); ?>">
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1"><i class="far fa-calendar-alt me-1"></i>ถึงวันที่</label>
                            <input type="date" name="end_date" class="form-control form-control-sm border-primary" value="<?php echo htmlspecialchars($end_date, ENT_QUOTES, 'UTF-8'); ?>">
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ประเภทความคลาดเคลื่อน</label>
                            <select name="record_kind" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="error"<?php echo $rf_sel('record_kind', 'error'); ?>>ความคลาดเคลื่อนจริง</option>
                                <option value="consult"<?php echo $rf_sel('record_kind', 'consult'); ?>>บันทึกการ Consult</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ประเภทผู้ป่วย</label>
                            <select name="patient_type" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="OPD"<?php echo $rf_sel('patient_type', 'OPD'); ?>>ผู้ป่วยนอก (OPD)</option>
                                <option value="IPD"<?php echo $rf_sel('patient_type', 'IPD'); ?>>ผู้ป่วยใน (IPD)</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">หมวดหมู่ (Category)</label>
                            <select name="category" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <?php foreach ($categories as $c): ?>
                                <option value="<?php echo htmlspecialchars($c, ENT_QUOTES, 'UTF-8'); ?>"<?php echo $rf_sel('category', $c); ?>><?php echo htmlspecialchars($c, ENT_QUOTES, 'UTF-8'); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ระดับความรุนแรง</label>
                            <select name="error_level" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <?php foreach (['A','B','C','D','E','F','G','H','I'] as $lv): ?>
                                <option value="<?php echo $lv; ?>"<?php echo $rf_sel('error_level', $lv); ?>>Level <?php echo $lv; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ยา HAD</label>
                            <select name="is_had" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="YES"<?php echo $rf_sel('is_had', 'YES'); ?>>Yes</option>
                                <option value="NO"<?php echo $rf_sel('is_had', 'NO'); ?>>No</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">Robot</label>
                            <select name="is_robot" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="YES"<?php echo $rf_sel('is_robot', 'YES'); ?>>Yes</option>
                                <option value="NO"<?php echo $rf_sel('is_robot', 'NO'); ?>>No</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ประเภทใบสั่งยา</label>
                            <select name="rx_type" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <?php foreach (med_error_rx_types() as $rx_key => $rx_label): ?>
                                <option value="<?php echo htmlspecialchars($rx_key, ENT_QUOTES, 'UTF-8'); ?>"<?php echo $rf_sel('rx_type', $rx_key); ?>><?php echo htmlspecialchars($rx_label, ENT_QUOTES, 'UTF-8'); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">ผู้บันทึก</label>
                            <select name="reporter_id" class="form-select form-select-sm">
                                <?php echo $opt_filter_reporters; ?>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2">
                            <label class="form-label fw-bold text-muted mb-1">กลุ่มแพทย์ผู้สั่งใช้ยา</label>
                            <select name="doctor_group" class="form-select form-select-sm">
                                <option value="">ทั้งหมด</option>
                                <option value="staff"<?php echo $rf_sel('doctor_group', 'staff'); ?>>Staff</option>
                                <option value="intern"<?php echo $rf_sel('doctor_group', 'intern'); ?>>Intern</option>
                                <option value="extern"<?php echo $rf_sel('doctor_group', 'extern'); ?>>Extern</option>
                                <option value="none"<?php echo $rf_sel('doctor_group', 'none'); ?>>ยังไม่จัดกลุ่ม</option>
                            </select>
                        </div>
                        <div class="col-6 col-lg-2 d-grid">
                            <button type="submit" class="btn btn-primary btn-sm fw-bold"><i class="fas fa-search me-1"></i>ดูรายงาน</button>
                        </div>
                        <div class="col-6 col-lg-2 d-grid">
                            <a href="med_error.php" class="btn btn-outline-secondary btn-sm">ล้างตัวกรอง</a>
                        </div>
                        <div class="col-12">
                            <span class="badge bg-light text-dark border px-3 py-2 text-wrap text-start">
                                <i class="fas fa-filter me-1 text-danger"></i>ช่วงรายงาน: <?php echo htmlspecialchars($range_label, ENT_QUOTES, 'UTF-8'); ?>
                            </span>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-6 col-lg-3">
                    <div class="card kpi-card h-100">
                        <div class="card-body">
                            <div class="text-muted small fw-bold mb-1"><i class="fas fa-exclamation-triangle text-danger me-1"></i>เหตุการณ์ทั้งหมด</div>
                            <div class="kpi-value text-danger"><?php echo (int)$total_errors; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card kpi-card h-100">
                        <div class="card-body">
                            <div class="text-muted small fw-bold mb-1"><i class="fas fa-shield-alt text-success me-1"></i>Near miss (A–B)</div>
                            <div class="kpi-value text-success"><?php echo (int)$count_near_miss; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card kpi-card h-100">
                        <div class="card-body">
                            <div class="text-muted small fw-bold mb-1"><i class="fas fa-user-injured text-primary me-1"></i>ถึงผู้ป่วย (C–D)</div>
                            <div class="kpi-value text-primary"><?php echo (int)$count_reached; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card kpi-card h-100">
                        <div class="card-body">
                            <div class="text-muted small fw-bold mb-1"><i class="fas fa-heartbeat text-warning me-1"></i>เกิดอันตราย (E–I)</div>
                            <div class="kpi-value text-warning"><?php echo (int)$count_harm; ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-lg-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white border-bottom py-2">
                            <h6 class="mb-0 fw-bold"><i class="fas fa-chart-pie text-danger me-2"></i>ตามหมวดหมู่ (Category)</h6>
                        </div>
                        <div class="card-body">
                            <?php if ($total_errors > 0): ?>
                            <div class="chart-box"><canvas id="chartCategory"></canvas></div>
                            <?php else: ?>
                            <div class="text-center text-muted py-5">ไม่มีข้อมูลในช่วงที่เลือก</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white border-bottom py-2">
                            <h6 class="mb-0 fw-bold"><i class="fas fa-chart-bar text-warning me-2"></i>ตามระดับความรุนแรง</h6>
                        </div>
                        <div class="card-body">
                            <?php if (count($chart_level_data) > 0): ?>
                            <div class="chart-box"><canvas id="chartLevel"></canvas></div>
                            <?php else: ?>
                            <div class="text-center text-muted py-5">ไม่มีข้อมูลในช่วงที่เลือก</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white border-bottom py-2">
                            <h6 class="mb-0 fw-bold"><i class="fas fa-list-ol text-primary me-2"></i>ลักษณะที่พบบ่อย (Top)</h6>
                        </div>
                        <div class="card-body">
                            <?php if (count($chart_type_data) > 0): ?>
                            <div class="chart-box"><canvas id="chartType"></canvas></div>
                            <?php else: ?>
                            <div class="text-center text-muted py-5">ไม่มีข้อมูลในช่วงที่เลือก</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-secondary shadow-sm">
                <div class="card-header bg-secondary text-white py-2 d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <h6 class="mb-0 fw-bold"><i class="fas fa-history me-2"></i>ประวัติความคลาดเคลื่อนทางยา <small class="fw-normal opacity-75">(<?php echo htmlspecialchars($range_label, ENT_QUOTES, 'UTF-8'); ?>)</small></h6>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="export_med_error_pdf.php?<?php echo htmlspecialchars($range_qs, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" class="btn btn-danger btn-sm fw-bold shadow-sm">
                            <i class="fas fa-file-pdf me-1"></i> ส่งออก PDF
                        </a>
                        <a href="export_med_error_excel.php?<?php echo htmlspecialchars($range_qs, ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-success btn-sm fw-bold shadow-sm">
                            <i class="fas fa-file-excel me-1"></i> ส่งออก Excel
                        </a>
                    </div>
                </div>
                <div class="card-body p-3">
                    <div class="table-responsive">
                        <table id="errorTable" class="table table-bordered table-striped w-100 align-middle">
                            <thead class="table-light text-center">
                                <tr>
                                    <th width="8%">วันเกิดเหตุ</th>
                                    <th width="6%">เวลาเกิดเหตุ</th>
                                    <th width="10%">วันเวลาที่บันทึก</th>
                                    <th width="6%">HN</th>
                                    <th width="12%">ชื่อผู้ป่วย / แพทย์ผู้สั่ง</th>
                                    <th width="12%">ประเภท</th>
                                    <th width="6%">ระดับ</th>
                                    <th width="16%">บรรยายเหตุการณ์</th>
                                    <th width="14%">การแก้ไขปัญหา</th>
                                    <th width="6%">ผู้บันทึก</th>
                                    <th width="4%">จัดการ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php echo $history_trs; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="consultHistoryModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content border-info">
            <div class="modal-header bg-info text-dark">
                <h6 class="modal-title fw-bold"><i class="fas fa-comments me-2"></i><span id="consultHistoryTitle">ประวัติการ Consult</span></h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="consultHistoryBody"></div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-info text-dark fw-bold" data-bs-dismiss="modal">รับทราบ</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="manageTypesModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content border-secondary">
            <div class="modal-header bg-secondary text-white">
                <h6 class="modal-title fw-bold"><i class="fas fa-cogs me-2"></i>ตั้งค่าความคลาดเคลื่อนทางยา</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 bg-light">
                <div class="card border-success shadow-sm mb-4">
                    <div class="card-header bg-success text-white py-2"><h6 class="mb-0 fw-bold" id="formTypeTitle"><i class="fas fa-plus me-1"></i>เพิ่ม/แก้ไข หัวข้อ</h6></div>
                    <div class="card-body">
                        <form action="action_error_type.php" method="POST" id="typeForm">
                            <input type="hidden" name="action" id="type_action" value="add">
                            <input type="hidden" name="type_id" id="type_id" value="">
                            <div class="row g-2">
                                <div class="col-md-5">
                                    <label class="form-label fw-bold">หมวดหมู่หลัก</label>
                                    <select class="form-select border-success" name="category" id="type_category" required>
                                        <option value="Prescribing Error">Prescribing Error (สั่งยาผิด)</option>
                                        <option value="Transcribing Error">Transcribing Error (คัดลอกผิด)</option>
                                        <option value="Pre-dispensing error">Pre-dispensing error (ก่อนจัด/จ่ายยา)</option>
                                        <option value="Dispensing Error">Dispensing Error (จัด/จ่ายยาผิด)</option>
                                        <option value="Administration Error">Administration Error (บริหารยาผิด)</option>
                                        <option value="Other">Other (อื่นๆ)</option>
                                    </select>
                                </div>
                                <div class="col-md-5">
                                    <label class="form-label fw-bold">ชื่อหัวข้อย่อย</label>
                                    <input type="text" class="form-control border-success" name="name" id="type_name" required placeholder="เช่น จัดยาผิดขนาด">
                                </div>
                                <div class="col-md-2 d-flex align-items-end">
                                    <button type="submit" class="btn btn-success fw-bold w-100" id="btnSaveType"><i class="fas fa-save me-1"></i>บันทึก</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <h6 class="fw-bold text-dark"><i class="fas fa-list me-1"></i>รายการหัวข้อที่มีในระบบ</h6>
                <div class="table-responsive bg-white border rounded mb-4">
                    <table class="table table-sm table-hover table-bordered mb-0 align-middle">
                        <thead class="table-light text-center">
                            <tr><th>หมวดหมู่หลัก (Category)</th><th>ชื่อหัวข้อย่อย (Error Type)</th><th width="15%">จัดการ</th></tr>
                        </thead>
                        <tbody>
                            <?php echo $type_table_trs; ?>
                        </tbody>
                    </table>
                </div>

                <div class="card border-danger shadow-sm">
                    <div class="card-header bg-danger text-white py-2 d-flex justify-content-between align-items-center gap-2">
                        <h6 class="mb-0 fw-bold"><i class="fas fa-exclamation-circle me-1"></i>รายการยา HAD (High Alert Drug)</h6>
                        <a href="action_error_type.php?action=had_sync" class="btn btn-sm btn-light text-danger fw-bold" onclick="return confirm('ดึงยา HAD จาก HOSxP ตาม Font Color สีแดง เข้ามารายการนี้?');">
                            <i class="fas fa-sync-alt me-1"></i>ดึงจาก HOSxP (สีแดง)
                        </a>
                    </div>
                    <div class="card-body">
                        <label class="form-label fw-bold">ค้นหาและเพิ่มยา HAD</label>
                        <div class="drug-picker" data-kind="had">
                            <input type="text" class="form-control border-danger mb-2" id="hadDrugSearch" placeholder="พิมพ์ชื่อยาจาก drugitems เพื่อเพิ่มในรายการ HAD..." autocomplete="off">
                            <div class="drug-suggest d-none" id="hadDrugSuggest"></div>
                        </div>
                        <div class="form-text mb-3">ยา HAD ใน HOSxP คือรายการที่ตั้ง <strong>Font Color เป็นสีแดง</strong> ในบัญชีรายการยา — กดดึงจาก HOSxP หรือเพิ่มเองได้</div>
                        <div class="table-responsive bg-white border rounded">
                            <table class="table table-sm table-hover table-bordered mb-0 align-middle" id="hadDrugTable">
                                <thead class="table-light text-center">
                                    <tr><th width="20%">icode</th><th>ชื่อยา (name + strength)</th><th width="12%">ลบ</th></tr>
                                </thead>
                                <tbody id="hadDrugTableBody">
                                    <?php echo $had_table_trs; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card border-primary shadow-sm mt-4">
                    <div class="card-header bg-primary text-white py-2">
                        <h6 class="mb-0 fw-bold"><i class="fas fa-user-md me-1"></i>จัดกลุ่มแพทย์ผู้สั่งใช้ยา (Staff / Intern / Extern)</h6>
                    </div>
                    <div class="card-body">
                        <p class="form-text mt-0 mb-3">กำหนดรายชื่อแพทย์เพื่อแยกรายงาน Staff, Intern และ Extern — ค้นหาจากตาราง doctor ของ HOSxP แล้วเลือกกลุ่ม</p>
                        <div class="row g-2 align-items-end mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">ค้นหาแพทย์จาก HOSxP</label>
                                <input type="hidden" id="setDoctorCode" value="">
                                <div class="drug-picker">
                                    <input type="text" class="form-control border-primary" id="setDoctorSearch" placeholder="พิมพ์ชื่อหรือรหัสแพทย์..." autocomplete="off">
                                    <div class="drug-suggest d-none" id="setDoctorSuggest"></div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold">กลุ่ม</label>
                                <select class="form-select border-primary" id="setDoctorGroup">
                                    <option value="staff">Staff</option>
                                    <option value="intern">Intern</option>
                                    <option value="extern">Extern</option>
                                </select>
                            </div>
                            <div class="col-md-3 d-grid">
                                <button type="button" class="btn btn-primary fw-bold" onclick="saveDoctorGroup()"><i class="fas fa-save me-1"></i>บันทึกกลุ่ม</button>
                            </div>
                        </div>
                        <div class="table-responsive bg-white border rounded">
                            <table class="table table-sm table-hover table-bordered mb-0 align-middle" id="doctorGroupTable">
                                <thead class="table-light text-center">
                                    <tr><th width="18%">รหัส</th><th>ชื่อแพทย์</th><th width="18%">กลุ่ม</th><th width="12%">ลบ</th></tr>
                                </thead>
                                <tbody id="doctorGroupTableBody">
                                    <?php echo $doctor_group_trs; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="vendor/jquery/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="vendor/chart.js/Chart.min.js"></script>
<script>
    const errorData = <?php echo $error_json ?: '{}'; ?>;
    const chartCatLabels = <?php echo json_encode($chart_cat_labels, JSON_UNESCAPED_UNICODE); ?>;
    const chartCatData = <?php echo json_encode($chart_cat_data); ?>;
    const chartLevelLabels = <?php echo json_encode($chart_level_labels, JSON_UNESCAPED_UNICODE); ?>;
    const chartLevelData = <?php echo json_encode($chart_level_data); ?>;
    const chartLevelColors = <?php echo json_encode($chart_level_colors); ?>;
    const chartTypeLabels = <?php echo json_encode($chart_type_labels, JSON_UNESCAPED_UNICODE); ?>;
    const chartTypeData = <?php echo json_encode($chart_type_data); ?>;
    let visitContext = { an: '', vn: '', suggested_type: '', ward_name: '', has_an: false, has_vn: false, visit_rooms: [], preferred_room: '' };
    let skipTypeCheck = false;
    let skipDeptDefaults = false;
    let skipHadAuto = false;
    let editingRecord = false;
    let skipConsultPopup = false;
    let lockOrderDoctor = false;
    const HAD_ICODES = <?php echo $had_icodes_json ?: '{}'; ?>;
    const HAD_LABELS = <?php echo $had_labels_json ?: '{}'; ?>;
    const DOCTOR_GROUP_MAP = <?php echo $doctor_group_map_json ?: '{}'; ?>;
    const DOCTOR_GROUP_LABELS = { staff: 'Staff', intern: 'Intern', extern: 'Extern' };
    const PHARM_IPD = <?php echo json_encode(med_error_pharmacy_ipd(), JSON_UNESCAPED_UNICODE); ?>;
    const PHARM_OPD = <?php echo json_encode(med_error_pharmacy_opd(), JSON_UNESCAPED_UNICODE); ?>;
    const CLINICAL_CATS = ['Administration Error', 'Prescribing Error', 'Transcribing Error'];
    const DISPENSING_CATS = ['Dispensing Error'];
    const OTHER_DEPT = '__other__';
    const WARD_DEPT = '__ward__';
    const WARD_LIST = <?php echo json_encode(med_error_list_wards($con), JSON_UNESCAPED_UNICODE); ?>;
    let errorDrugList = [];
    let correctDrugList = [];
    let dismissedErrorDrugs = {};
    let dismissedCorrectDrugs = {};
    let autoErrorIcodes = {};
    let autoCorrectIcodes = {};
    let drugSearchTimers = { error: null, correct: null, had: null, doctor: null, setDoctor: null };
    let lastDrugSuggest = { error: [], correct: [] };
    let descDrugTimer = null;
    let lastDescScan = '';

    $(document).ready(function() {
        $('#errorTable').DataTable({
            language: { sSearch: 'ค้นหา:', sLengthMenu: 'แสดง _MENU_ รายการ', sInfo: 'แสดง _START_ ถึง _END_ จาก _TOTAL_ รายการ', oPaginate: { sPrevious: 'ก่อนหน้า', sNext: 'ถัดไป' } },
            order: [[0, 'desc']],
            pageLength: 100,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'ทั้งหมด']]
        });

        const catColors = ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#198754', '#858796', '#5a5c69'];
        if (document.getElementById('chartCategory') && chartCatLabels.length > 0) {
            new Chart(document.getElementById('chartCategory').getContext('2d'), {
                type: 'doughnut',
                data: { labels: chartCatLabels, datasets: [{ data: chartCatData, backgroundColor: catColors }] },
                options: { responsive: true, maintainAspectRatio: false, legend: { position: 'bottom', labels: { boxWidth: 12, fontSize: 11 } } }
            });
        }
        if (document.getElementById('chartLevel') && chartLevelLabels.length > 0) {
            new Chart(document.getElementById('chartLevel').getContext('2d'), {
                type: 'bar',
                data: { labels: chartLevelLabels, datasets: [{ label: 'จำนวน', data: chartLevelData, backgroundColor: chartLevelColors }] },
                options: { responsive: true, maintainAspectRatio: false, legend: { display: false }, scales: { yAxes: [{ ticks: { beginAtZero: true, precision: 0 } }] } }
            });
        }
        if (document.getElementById('chartType') && chartTypeLabels.length > 0) {
            new Chart(document.getElementById('chartType').getContext('2d'), {
                type: 'horizontalBar',
                data: { labels: chartTypeLabels, datasets: [{ label: 'จำนวน', data: chartTypeData, backgroundColor: '#e74a3b' }] },
                options: { responsive: true, maintainAspectRatio: false, legend: { display: false }, scales: { xAxes: [{ ticks: { beginAtZero: true, precision: 0 } }] } }
            });
        }

        if (document.getElementById('e_hn').value.trim() !== '') {
            fetchPatientName();
        }

        document.getElementById('ptype_opd').addEventListener('change', onPatientTypeChange);
        document.getElementById('ptype_ipd').addEventListener('change', onPatientTypeChange);
        document.getElementById('kind_error').addEventListener('change', toggleRecordKind);
        document.getElementById('kind_consult').addEventListener('change', toggleRecordKind);
        document.getElementById('medErrorForm').addEventListener('submit', function(e) {
            if (isConsultMode()) {
                if (!document.getElementById('e_hn').value.trim()) {
                    e.preventDefault();
                    alert('กรุณาระบุ HN ผู้ป่วย');
                    return;
                }
                if (!getSelectedPatientType()) {
                    e.preventDefault();
                    alert('กรุณาเลือกผู้ป่วยใน หรือผู้ป่วยนอก');
                    return;
                }
                if (!document.getElementById('description').value.trim()) {
                    e.preventDefault();
                    alert('กรุณาบรรยายเหตุการณ์');
                    return;
                }
                if (!confirmPatientTypeIfMismatch()) {
                    e.preventDefault();
                }
                return;
            }
            if (!getSelectedPatientType()) {
                e.preventDefault();
                alert('กรุณาเลือกผู้ป่วยใน หรือผู้ป่วยนอก');
                return;
            }
            if (getSelectedPatientType() === 'IPD' && !document.querySelector('input[name="rx_type"]:checked')) {
                e.preventDefault();
                alert('กรุณาเลือกประเภทใบสั่งยา');
                return;
            }
            if (!confirmPatientTypeIfMismatch()) {
                e.preventDefault();
            }
            syncDrugHidden();
        });
        document.getElementById('e_hn').addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                fetchPatientName();
            }
        });
        document.getElementById('medErrorForm').addEventListener('reset', function() {
            visitContext = { an: '', vn: '', suggested_type: '', ward_name: '', has_an: false, has_vn: false, visit_rooms: [], preferred_room: '' };
            document.getElementById('visitHint').textContent = '';
            document.getElementById('deptHint').textContent = '';
            skipDeptDefaults = false;
            skipHadAuto = false;
            editingRecord = false;
            skipConsultPopup = false;
            lockOrderDoctor = false;
            clearOrderDoctor();
            refreshDeptSelects('', '');
            resetDrugLists();
            setRobot('NO');
            setRxType('');
            toggleRxTypeWrap();
            setRecordKind('error');
            toggleRecordKind();
        });
        document.getElementById('reporting_dept').addEventListener('change', function() { toggleOtherDept('reporting'); });
        document.getElementById('error_dept').addEventListener('change', function() { toggleOtherDept('error'); });
        ['reporting', 'error'].forEach(function(kind) {
            const els = wardEls(kind);
            if (!els.q) return;
            els.q.addEventListener('input', function() {
                fillWardSelect(kind, els.sel.value, els.q.value);
            });
        });
        fillWardSelect('reporting', '', '');
        fillWardSelect('error', '', '');
        bindDrugPicker('error');
        bindDrugPicker('correct');
        bindHadDrugPicker();
        bindDoctorPicker();
        bindSetDoctorPicker();
        toggleRxTypeWrap();
        toggleRecordKind();
        document.getElementById('description').addEventListener('input', onDescriptionInput);
        document.getElementById('description').addEventListener('blur', function() { scanDescriptionDrugs(true); });
        document.getElementById('solution').addEventListener('input', onDescriptionInput);
        document.getElementById('solution').addEventListener('blur', function() { scanDescriptionDrugs(true); });
    });

    function drugEsc(s) {
        return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
    }

    function drugList(kind) {
        return kind === 'correct' ? correctDrugList : errorDrugList;
    }

    function setDrugList(kind, list) {
        if (kind === 'correct') correctDrugList = list;
        else errorDrugList = list;
        renderDrugChips(kind);
        syncDrugHidden();
        updateHadAuto();
    }

    function resetDrugLists() {
        errorDrugList = [];
        correctDrugList = [];
        dismissedErrorDrugs = {};
        dismissedCorrectDrugs = {};
        autoErrorIcodes = {};
        autoCorrectIcodes = {};
        lastDescScan = '';
        renderDrugChips('error');
        renderDrugChips('correct');
        syncDrugHidden();
        const hint = document.getElementById('descDrugHint');
        if (hint) hint.textContent = 'ระบบจะแยกยาจากคำบรรยาย และจำยาที่เคยบันทึกไว้เพื่อช่วยกรอกครั้งถัดไป';
        hideDrugSuggest('error');
        hideDrugSuggest('correct');
        lastDrugSuggest = { error: [], correct: [] };
        updateHadAuto();
    }

    function syncDrugHidden() {
        document.getElementById('error_drugs').value = JSON.stringify(errorDrugList);
        document.getElementById('correct_drugs').value = JSON.stringify(correctDrugList);
    }

    function renderDrugChips(kind) {
        const box = document.getElementById(kind === 'correct' ? 'correctDrugChips' : 'errorDrugChips');
        const list = drugList(kind);
        const cls = kind === 'correct' ? 'correct' : 'error';
        if (!list.length) {
            box.innerHTML = '';
            return;
        }
        box.innerHTML = list.map(function(d, i) {
            return '<span class="drug-chip ' + cls + '">'
                + '<span>' + drugEsc(d.label || d.name) + '</span>'
                + '<button type="button" class="chip-x" onclick="removeDrug(\'' + kind + '\',' + i + ')" title="ลบ">&times;</button>'
                + '</span>';
        }).join('');
    }

    function applyAutoDrugs(kind, drugs) {
        const dismissed = kind === 'correct' ? dismissedCorrectDrugs : dismissedErrorDrugs;
        const prevAuto = kind === 'correct' ? autoCorrectIcodes : autoErrorIcodes;
        const keep = drugList(kind).filter(function(d) {
            return !prevAuto[d.icode];
        });
        const nextAuto = {};
        (drugs || []).forEach(function(d) {
            if (!d || !d.icode || dismissed[d.icode]) return;
            if (keep.some(function(x) { return x.icode === d.icode; })) return;
            keep.push({
                icode: d.icode,
                name: d.name || d.label || '',
                strength: d.strength || '',
                label: d.label || d.name || ''
            });
            nextAuto[d.icode] = true;
        });
        if (kind === 'correct') autoCorrectIcodes = nextAuto;
        else autoErrorIcodes = nextAuto;
        setDrugList(kind, keep);
        return Object.keys(nextAuto).length;
    }

    function addDrug(kind, drug, fromAuto) {
        if (!drug || !drug.icode) return false;
        const list = drugList(kind);
        if (list.some(function(d) { return d.icode === drug.icode; })) return false;
        if (fromAuto) {
            const dismissed = kind === 'correct' ? dismissedCorrectDrugs : dismissedErrorDrugs;
            if (dismissed[drug.icode]) return false;
        }
        list.push({
            icode: drug.icode,
            name: drug.name || drug.label || '',
            strength: drug.strength || '',
            label: drug.label || drug.name || ''
        });
        setDrugList(kind, list);
        return true;
    }

    function removeDrug(kind, index) {
        const list = drugList(kind).slice();
        const removed = list.splice(index, 1)[0];
        if (removed && removed.icode) {
            if (kind === 'correct') dismissedCorrectDrugs[removed.icode] = true;
            else dismissedErrorDrugs[removed.icode] = true;
        }
        setDrugList(kind, list);
    }

    function hideDrugSuggest(kind) {
        const box = document.getElementById(kind === 'correct' ? 'correctDrugSuggest' : 'errorDrugSuggest');
        if (!box) return;
        box.classList.add('d-none');
        box.innerHTML = '';
    }

    function showDrugSuggest(kind, drugs) {
        const box = document.getElementById(kind === 'correct' ? 'correctDrugSuggest' : 'errorDrugSuggest');
        lastDrugSuggest[kind] = drugs || [];
        if (!box) return;
        if (!drugs || !drugs.length) {
            box.innerHTML = '<div class="px-3 py-2 text-muted small">ไม่พบยา</div>';
            box.classList.remove('d-none');
            return;
        }
        box.innerHTML = drugs.map(function(d, i) {
            return '<button type="button" data-idx="' + i + '">'
                + '<span>' + drugEsc(d.label || d.name) + '</span>'
                + '<i class="fas fa-plus suggest-plus" title="เพิ่มยา"></i>'
                + '</button>';
        }).join('');
        box.classList.remove('d-none');
        Array.prototype.forEach.call(box.querySelectorAll('button'), function(btn) {
            btn.addEventListener('mousedown', function(e) {
                e.preventDefault();
                const d = drugs[parseInt(btn.getAttribute('data-idx'), 10)];
                pickSuggestedDrug(kind, d);
            });
        });
    }

    function pickSuggestedDrug(kind, drug) {
        if (!addDrug(kind, drug, false)) {
            alert('ยานี้อยู่ในรายการแล้ว');
            return;
        }
        const inp = document.getElementById(kind === 'correct' ? 'correctDrugSearch' : 'errorDrugSearch');
        inp.value = '';
        lastDrugSuggest[kind] = [];
        hideDrugSuggest(kind);
        inp.focus();
    }

    function addDrugFromSearch(kind) {
        const cached = lastDrugSuggest[kind] || [];
        if (cached.length) {
            pickSuggestedDrug(kind, cached[0]);
            return;
        }
        const inp = document.getElementById(kind === 'correct' ? 'correctDrugSearch' : 'errorDrugSearch');
        const q = inp.value.trim();
        if (q.length < 2) {
            alert('พิมพ์ชื่อยาอย่างน้อย 2 ตัวอักษร แล้วกด + เพื่อเพิ่ม');
            inp.focus();
            return;
        }
        fetch('fetch_med_error_drugs_api.php?action=search&q=' + encodeURIComponent(q))
            .then(function(res) { return res.json(); })
            .then(function(data) {
                const drugs = (data && data.drugs) ? data.drugs : [];
                lastDrugSuggest[kind] = drugs;
                if (!drugs.length) {
                    showDrugSuggest(kind, []);
                    alert('ไม่พบยาใน drugitems กรุณาพิมพ์ชื่อให้ตรงขึ้น แล้วเลือกจากรายการ');
                    return;
                }
                pickSuggestedDrug(kind, drugs[0]);
            }).catch(function() {
                alert('ค้นหายาไม่สำเร็จ');
            });
    }

    function bindDrugPicker(kind) {
        const inp = document.getElementById(kind === 'correct' ? 'correctDrugSearch' : 'errorDrugSearch');
        inp.addEventListener('input', function() {
            const q = inp.value.trim();
            clearTimeout(drugSearchTimers[kind]);
            if (q.length < 2) {
                lastDrugSuggest[kind] = [];
                hideDrugSuggest(kind);
                return;
            }
            drugSearchTimers[kind] = setTimeout(function() {
                fetch('fetch_med_error_drugs_api.php?action=search&q=' + encodeURIComponent(q))
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        showDrugSuggest(kind, (data && data.drugs) ? data.drugs : []);
                    }).catch(function() {
                        hideDrugSuggest(kind);
                    });
            }, 250);
        });
        inp.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') hideDrugSuggest(kind);
            if (e.key === 'Enter') {
                e.preventDefault();
                addDrugFromSearch(kind);
            }
        });
        inp.addEventListener('blur', function() {
            setTimeout(function() { hideDrugSuggest(kind); }, 180);
        });
        const addBtn = document.getElementById(kind === 'correct' ? 'correctDrugAddBtn' : 'errorDrugAddBtn');
        if (addBtn) {
            addBtn.addEventListener('mousedown', function(e) { e.preventDefault(); });
        }
    }

    function onDescriptionInput() {
        clearTimeout(descDrugTimer);
        descDrugTimer = setTimeout(function() { scanDescriptionDrugs(false); }, 700);
    }

    function scanDescriptionDrugs(force) {
        if (isConsultMode()) return;
        const text = document.getElementById('description').value.trim();
        const solution = document.getElementById('solution').value.trim();
        const hint = document.getElementById('descDrugHint');
        const combined = text + '\n' + solution;
        if (text.length < 6 && solution.length < 6) {
            if (hint) hint.textContent = 'ระบบจะแยกยาจากคำบรรยาย และจำยาที่เคยบันทึกไว้เพื่อช่วยกรอกครั้งถัดไป';
            return;
        }
        if (!force && combined === lastDescScan) return;
        lastDescScan = combined;
        const body = new URLSearchParams({
            action: 'from_text',
            text: text,
            solution: solution,
            hn: document.getElementById('e_hn').value.trim(),
            an: document.getElementById('e_an').value.trim(),
            vn: document.getElementById('e_vn').value.trim(),
            date: document.getElementById('incident_date').value.trim()
        });
        fetch('fetch_med_error_drugs_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        }).then(function(res) { return res.json(); })
          .then(function(data) {
              const errorDrugs = (data && (data.error_drugs || data.drugs)) ? (data.error_drugs || data.drugs) : [];
              const correctDrugs = (data && data.correct_drugs) ? data.correct_drugs : [];
              const addedError = applyAutoDrugs('error', errorDrugs);
              const addedCorrect = applyAutoDrugs('correct', correctDrugs);
              if (hint) {
                  const parts = [];
                  if (addedError) parts.push('ยาที่ Error ' + addedError + ' รายการ');
                  if (addedCorrect) parts.push('ยาที่ถูกต้อง ' + addedCorrect + ' รายการ');
                  if (parts.length) {
                      hint.innerHTML = '<span class="text-danger">ดึงจากคำบรรยายแล้ว: ' + parts.join(' · ') + ' (ลบได้ถ้าไม่ใช่)</span>';
                  } else if (errorDrugs.length || correctDrugs.length) {
                      hint.innerHTML = '<span class="text-muted">พบชื่อยาในคำบรรยายที่เลือกไว้แล้ว</span>';
                  } else {
                      hint.textContent = 'ระบบจะแยกยาจากคำบรรยาย และจำยาที่เคยบันทึกไว้เพื่อช่วยกรอกครั้งถัดไป';
                  }
              }
          }).catch(function() {});
    }

    function getRecordKind() {
        const el = document.querySelector('input[name="record_kind"]:checked');
        return el ? el.value : 'error';
    }

    function isConsultMode() {
        return getRecordKind() === 'consult';
    }

    function setRecordKind(kind) {
        if (kind === 'consult') {
            document.getElementById('kind_consult').checked = true;
        } else {
            document.getElementById('kind_error').checked = true;
        }
    }

    function toggleRecordKind() {
        const consult = isConsultMode();
        Array.prototype.forEach.call(document.querySelectorAll('.js-error-only'), function(el) {
            el.classList.toggle('d-none', consult);
        });
        ['error_level', 'error_category', 'error_type_id', 'error_dept'].forEach(function(id) {
            const el = document.getElementById(id);
            if (el) el.required = !consult;
        });
        document.getElementById('e_hn').required = true;
        document.getElementById('reporting_dept').required = true;
        document.getElementById('ptype_opd').required = true;
        document.getElementById('ptype_ipd').required = true;
        const errOther = document.getElementById('error_dept_other');
        if (consult && errOther) {
            errOther.required = false;
        }
        const errWard = document.getElementById('error_dept_ward');
        if (consult && errWard) {
            errWard.required = false;
        }
        const lab = document.getElementById('reportingDeptLabel');
        const otherRep = document.getElementById('reporting_dept_other');
        if (lab) lab.textContent = consult ? 'จุดตรวจ' : 'หน่วยงานที่รายงาน';
        if (otherRep) otherRep.placeholder = consult ? 'ระบุจุดตรวจ...' : 'ระบุหน่วยงานที่รายงาน...';
        refreshDeptSelects();
        const hint = document.getElementById('descDrugHint');
        const desc = document.getElementById('description');
        const submitBtn = document.getElementById('btnSubmitForm');
        if (consult) {
            if (hint) hint.textContent = 'บันทึกการ Consult — ไม่นับเป็น Medication Error';
            if (desc) desc.placeholder = 'บรรยายประเด็นที่ Consult...';
            if (submitBtn && !editingRecord) {
                submitBtn.innerHTML = '<i class="fas fa-save me-2"></i>บันทึก Consult';
                submitBtn.classList.remove('btn-danger');
                submitBtn.classList.add('btn-info', 'text-dark');
            }
            if (!editingRecord) {
                document.getElementById('formCard').classList.remove('border-danger');
                document.getElementById('formCard').classList.add('border-info');
                document.getElementById('formHeader').classList.remove('bg-danger');
                document.getElementById('formHeader').classList.add('bg-info', 'text-dark');
                applyDeptDefaults();
            }
        } else {
            if (hint) hint.textContent = 'ระบบจะแยกยาจากคำบรรยาย และจำยาที่เคยบันทึกไว้เพื่อช่วยกรอกครั้งถัดไป';
            if (desc) desc.placeholder = 'บรรยายเหตุการณ์ก่อน เช่น จ่ายยาอะไร ควรเป็นยาอะไร...';
            if (submitBtn && !editingRecord) {
                submitBtn.innerHTML = '<i class="fas fa-save me-2"></i>บันทึกเหตุการณ์';
                submitBtn.classList.remove('btn-info', 'text-dark');
                submitBtn.classList.add('btn-danger');
            }
            if (!editingRecord) {
                document.getElementById('formCard').classList.remove('border-info');
                document.getElementById('formCard').classList.add('border-danger');
                document.getElementById('formHeader').classList.remove('bg-info', 'text-dark');
                document.getElementById('formHeader').classList.add('bg-danger');
                document.getElementById('formHeader').classList.add('text-white');
                applyDeptDefaults();
            }
            toggleRxTypeWrap();
        }
        toggleOtherDept('reporting');
        if (!consult) toggleOtherDept('error');
    }

    function getSelectedPatientType() {
        const el = document.querySelector('input[name="patient_type"]:checked');
        return el ? el.value : '';
    }

    function patientTypeLabel(type) {
        if (type === 'IPD') return 'ผู้ป่วยใน (IPD)';
        if (type === 'OPD') return 'ผู้ป่วยนอก (OPD)';
        return type || '-';
    }

    function setPatientType(type, skipCheck) {
        skipTypeCheck = !!skipCheck;
        if (type === 'IPD') {
            document.getElementById('ptype_ipd').checked = true;
        } else if (type === 'OPD') {
            document.getElementById('ptype_opd').checked = true;
        } else {
            document.getElementById('ptype_ipd').checked = false;
            document.getElementById('ptype_opd').checked = false;
        }
        skipTypeCheck = false;
        toggleRxTypeWrap();
    }

    function setRxType(value) {
        const v = String(value || '').toLowerCase();
        const newEl = document.getElementById('rx_new');
        const homeEl = document.getElementById('rx_home');
        const contEl = document.getElementById('rx_continue');
        if (newEl) newEl.checked = (v === 'new');
        if (homeEl) homeEl.checked = (v === 'home');
        if (contEl) contEl.checked = (v === 'continue');
    }

    function toggleRxTypeWrap() {
        const wrap = document.getElementById('rxTypeWrap');
        if (!wrap) return;
        const isIpd = !isConsultMode() && getSelectedPatientType() === 'IPD';
        wrap.classList.toggle('d-none', !isIpd);
        Array.prototype.forEach.call(document.querySelectorAll('input[name="rx_type"]'), function(el) {
            el.required = isIpd;
            if (!isIpd) el.checked = false;
        });
    }

    function updateVisitHint() {
        const hint = document.getElementById('visitHint');
        const parts = [];
        if (visitContext.suggested_type) {
            parts.push('HOSxP แนะนำ: ' + patientTypeLabel(visitContext.suggested_type));
        }
        if (visitContext.ward_name) {
            parts.push('หอผู้ป่วย ' + visitContext.ward_name);
        }
        hint.textContent = parts.join(' · ');
        hint.className = 'small ' + (visitContext.suggested_type === 'IPD' ? 'text-danger' : (visitContext.suggested_type === 'OPD' ? 'text-primary' : 'text-muted'));
    }

    function confirmPatientTypeIfMismatch() {
        if (skipTypeCheck) return true;
        const selected = getSelectedPatientType();
        const suggested = visitContext.suggested_type || '';
        if (!selected || !suggested || selected === suggested) return true;

        let msg = '';
        if (selected === 'OPD' && visitContext.has_an) {
            msg = 'พบ AN ' + (visitContext.an || '-') + ' ของผู้ป่วยรายนี้ ซึ่งโดยปกติถือเป็นผู้ป่วยใน (IPD)\nแต่เลือกไว้เป็นผู้ป่วยนอก (OPD)\n\nยืนยันว่าเลือกถูกต้องหรือไม่?';
        } else if (selected === 'IPD' && visitContext.has_vn && !visitContext.has_an) {
            msg = 'พบ VN ' + (visitContext.vn || '-') + ' ของผู้ป่วยรายนี้ ซึ่งโดยปกติถือเป็นผู้ป่วยนอก (OPD)\nแต่เลือกไว้เป็นผู้ป่วยใน (IPD)\n\nยืนยันว่าเลือกถูกต้องหรือไม่?';
        } else {
            msg = 'ประเภทผู้ป่วยที่เลือกเป็น ' + patientTypeLabel(selected)
                + '\nแต่ข้อมูล HOSxP แนะนำเป็น ' + patientTypeLabel(suggested)
                + '\nAN: ' + (visitContext.an || '-') + '   VN: ' + (visitContext.vn || '-')
                + '\n\nยืนยันว่าเลือกถูกต้องหรือไม่?';
        }
        if (window.confirm(msg)) {
            return true;
        }
        setPatientType(suggested, true);
        return false;
    }

    function onPatientTypeChange() {
        confirmPatientTypeIfMismatch();
        toggleRxTypeWrap();
        if (!skipDeptDefaults && !editingRecord) {
            applyDeptDefaults();
        }
    }

    function applyVisitContext(data) {
        visitContext = {
            an: data.an || '',
            vn: data.vn || '',
            suggested_type: data.suggested_type || '',
            ward_name: data.ward_name || '',
            has_an: !!data.has_an,
            has_vn: !!data.has_vn,
            visit_rooms: Array.isArray(data.visit_rooms) ? data.visit_rooms : [],
            preferred_room: data.preferred_room || ''
        };
        document.getElementById('e_an').value = visitContext.an;
        document.getElementById('e_vn').value = visitContext.vn;
        if (!lockOrderDoctor) {
            setOrderDoctor(data.order_doctor_code || '', data.order_doctor_name || '', data.order_doctor_group || '', true);
        }
        updateVisitHint();
        const selected = getSelectedPatientType();
        if (!editingRecord) {
            if (!selected && visitContext.suggested_type) {
                setPatientType(visitContext.suggested_type, true);
            } else {
                confirmPatientTypeIfMismatch();
            }
        }
        if (editingRecord || skipDeptDefaults) {
            refreshDeptSelects();
            skipDeptDefaults = false;
            editingRecord = false;
            return;
        }
        applyDeptDefaults();
    }

    function onErrorCategoryChange() {
        updateSubTypes();
        applyDeptDefaults();
    }

    function currentPatientKind() {
        const selected = getSelectedPatientType();
        if (selected === 'IPD' || selected === 'OPD') return selected;
        if (visitContext.suggested_type === 'IPD' || visitContext.suggested_type === 'OPD') return visitContext.suggested_type;
        if (visitContext.has_an) return 'IPD';
        if (visitContext.has_vn) return 'OPD';
        return '';
    }

    function pharmacyDefault() {
        return currentPatientKind() === 'IPD' ? PHARM_IPD : (currentPatientKind() === 'OPD' ? PHARM_OPD : '');
    }

    function clinicalDefault() {
        if (currentPatientKind() === 'IPD') return visitContext.ward_name || '';
        if (currentPatientKind() === 'OPD') {
            return visitContext.preferred_room || ((visitContext.visit_rooms[0] && visitContext.visit_rooms[0].name) || '');
        }
        return visitContext.ward_name || visitContext.preferred_room || '';
    }

    function clinicalOptions() {
        const names = [];
        const seen = {};
        function add(name) {
            name = (name || '').trim();
            if (!name || seen[name]) return;
            seen[name] = true;
            names.push(name);
        }
        if (visitContext.ward_name) add(visitContext.ward_name);
        (visitContext.visit_rooms || []).forEach(function(r) { add(r && r.name); });
        return names;
    }

    function deptOptionHtml(value, selected) {
        const esc = String(value)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;');
        const sel = (value === selected) ? ' selected' : '';
        return '<option value="' + esc + '"' + sel + '>' + esc + '</option>';
    }

    function fillOneDeptSelect(selId, selected) {
        const sel = document.getElementById(selId);
        const keep = (selected !== undefined && selected !== null) ? selected : sel.value;
        const seen = {};
        const emptyLabel = (selId === 'reporting_dept' && isConsultMode()) ? '- เลือกจุดตรวจ -' : '- เลือกหน่วยงาน -';
        let html = '<option value="">' + emptyLabel + '</option>';
        html += '<optgroup label="ห้องยา">';
        html += deptOptionHtml(PHARM_IPD, keep);
        html += deptOptionHtml(PHARM_OPD, keep);
        html += '</optgroup>';
        seen[PHARM_IPD] = true;
        seen[PHARM_OPD] = true;
        const clinical = clinicalOptions();
        if (clinical.length) {
            html += '<optgroup label="จาก visit ผู้ป่วย">';
            clinical.forEach(function(name) {
                if (seen[name]) return;
                seen[name] = true;
                html += deptOptionHtml(name, keep);
            });
            html += '</optgroup>';
        }
        if (keep && keep !== OTHER_DEPT && keep !== WARD_DEPT && !seen[keep]) {
            html += deptOptionHtml(keep, keep);
            seen[keep] = true;
        }
        html += '<option value="' + WARD_DEPT + '"' + (keep === WARD_DEPT ? ' selected' : '') + '>ระบุหอผู้ป่วย</option>';
        html += '<option value="' + OTHER_DEPT + '"' + (keep === OTHER_DEPT ? ' selected' : '') + '>อื่นๆ (ระบุเอง)</option>';
        sel.innerHTML = html;
        if (keep && seen[keep]) {
            sel.value = keep;
        } else if (keep === WARD_DEPT) {
            sel.value = WARD_DEPT;
        } else if (keep === OTHER_DEPT) {
            sel.value = OTHER_DEPT;
        } else if (keep) {
            sel.value = keep;
        }
        toggleOtherDept(selId === 'reporting_dept' ? 'reporting' : 'error');
    }

    function refreshDeptSelects(keepReporting, keepError) {
        fillOneDeptSelect('reporting_dept', keepReporting !== undefined ? keepReporting : document.getElementById('reporting_dept').value);
        fillOneDeptSelect('error_dept', keepError !== undefined ? keepError : document.getElementById('error_dept').value);
        updateDeptHint();
    }

    function wardEls(kind) {
        const prefix = kind === 'reporting' ? 'reporting_dept_ward' : 'error_dept_ward';
        return {
            box: document.getElementById(prefix + '_box'),
            sel: document.getElementById(prefix),
            q: document.getElementById(prefix + '_q')
        };
    }

    function isKnownWard(name) {
        return WARD_LIST.indexOf((name || '').trim()) !== -1;
    }

    function fillWardSelect(kind, selected, filter) {
        const els = wardEls(kind);
        if (!els.sel) return;
        const q = (filter || '').trim().toLowerCase();
        let html = '<option value="">- เลือกหอผู้ป่วย -</option>';
        WARD_LIST.forEach(function(name) {
            if (q && name.toLowerCase().indexOf(q) === -1 && name !== selected) return;
            html += deptOptionHtml(name, selected || '');
        });
        if (selected && !isKnownWard(selected)) {
            html += deptOptionHtml(selected, selected);
        }
        els.sel.innerHTML = html;
        if (selected) els.sel.value = selected;
    }

    function toggleOtherDept(kind) {
        const sel = document.getElementById(kind === 'reporting' ? 'reporting_dept' : 'error_dept');
        const other = document.getElementById(kind === 'reporting' ? 'reporting_dept_other' : 'error_dept_other');
        const ward = wardEls(kind);
        const showWard = sel.value === WARD_DEPT;
        const showOther = sel.value === OTHER_DEPT;
        const allowRequired = kind !== 'error' || !isConsultMode();
        if (showOther) {
            other.classList.remove('d-none');
            other.required = allowRequired;
        } else {
            other.classList.add('d-none');
            other.required = false;
        }
        if (ward.box && ward.sel) {
            ward.box.classList.toggle('d-none', !showWard);
            ward.sel.required = showWard && allowRequired;
            if (showWard && !ward.sel.options.length) {
                fillWardSelect(kind, ward.sel.value, ward.q ? ward.q.value : '');
            }
        }
    }

    function updateDeptHint() {
        const hint = document.getElementById('deptHint');
        const rooms = visitContext.visit_rooms || [];
        const kind = currentPatientKind();
        if (kind === 'OPD' && rooms.length > 1) {
            hint.innerHTML = '<span class="text-warning fw-bold">พบ ' + rooms.length + ' ห้องตรวจใน VN นี้ กรุณาเลือกห้องที่ถูกต้อง</span>';
        } else if (kind === 'IPD' && visitContext.ward_name) {
            hint.textContent = 'หอผู้ป่วยปัจจุบัน: ' + visitContext.ward_name + ' · ถ้าจำหน่ายแล้วให้เลือก ระบุหอผู้ป่วย';
        } else {
            hint.textContent = 'ถ้าผู้ป่วยจำหน่ายแล้ว ให้เลือก ระบุหอผู้ป่วย';
        }
    }

    function applyDeptDefaults() {
        const clinical = clinicalDefault();
        if (isConsultMode()) {
            refreshDeptSelects(clinical || '', '');
            if (clinical) document.getElementById('reporting_dept').value = clinical;
            toggleOtherDept('reporting');
            updateDeptHint();
            return;
        }
        const cat = document.getElementById('error_category').value;
        const pharm = pharmacyDefault();
        let reporting = '';
        let errorDept = '';
        if (CLINICAL_CATS.indexOf(cat) !== -1) {
            reporting = pharm;
            errorDept = clinical;
        } else if (DISPENSING_CATS.indexOf(cat) !== -1) {
            reporting = clinical;
            errorDept = pharm;
        }
        refreshDeptSelects(reporting || '', errorDept || '');
        if (reporting) document.getElementById('reporting_dept').value = reporting;
        if (errorDept) document.getElementById('error_dept').value = errorDept;
        toggleOtherDept('reporting');
        toggleOtherDept('error');
        updateDeptHint();
    }

    function setDeptValue(selId, otherId, value) {
        value = (value || '').trim();
        refreshDeptSelects(
            selId === 'reporting_dept' ? value : undefined,
            selId === 'error_dept' ? value : undefined
        );
        const sel = document.getElementById(selId);
        const other = document.getElementById(otherId);
        const kind = selId === 'reporting_dept' ? 'reporting' : 'error';
        const hasOpt = Array.prototype.some.call(sel.options, function(o) { return o.value === value; });
        const ward = wardEls(kind);
        if (value && !hasOpt && isKnownWard(value)) {
            sel.value = WARD_DEPT;
            other.value = '';
            fillWardSelect(kind, value, '');
            if (ward.q) ward.q.value = '';
        } else if (value && !hasOpt) {
            sel.value = OTHER_DEPT;
            other.value = value;
            other.classList.remove('d-none');
            if (ward.sel) ward.sel.value = '';
        } else {
            sel.value = value;
            other.value = '';
            other.classList.add('d-none');
            if (ward.sel) ward.sel.value = '';
        }
        toggleOtherDept(kind);
    }

    function updateSubTypes() {
        const cat = document.getElementById('error_category').value;
        const typeSelect = document.getElementById('error_type_id');
        typeSelect.innerHTML = '<option value="">- เลือกหมวดหมู่ย่อย -</option>';
        if (cat && errorData[cat]) {
            errorData[cat].forEach(function(t) {
                typeSelect.innerHTML += '<option value="' + t.id + '">' + t.name + '</option>';
            });
        }
    }

    function fetchPatientName(opts) {
        opts = opts || {};
        const hn = document.getElementById('e_hn').value.trim();
        const wantConsult = opts.checkConsult !== false && !skipConsultPopup;
        skipConsultPopup = false;
        if (hn === '') return;
        const date = document.getElementById('incident_date').value || '';
        fetch('fetch_patient_api.php?hn=' + encodeURIComponent(hn) + '&date=' + encodeURIComponent(date))
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.status === 'success') {
                    const name = data.full_name || ((data.pname || '') + (data.fname || '') + ' ' + (data.lname || ''));
                    document.getElementById('e_patient_name').value = name;
                    document.getElementById('patient_name_hidden').value = name;
                    applyVisitContext(data);
                } else {
                    document.getElementById('e_patient_name').value = 'ไม่พบประวัติใน HOSxP';
                    document.getElementById('patient_name_hidden').value = '';
                    visitContext = { an: '', vn: '', suggested_type: '', ward_name: '', has_an: false, has_vn: false, visit_rooms: [], preferred_room: '' };
                    document.getElementById('e_an').value = '';
                    document.getElementById('e_vn').value = '';
                    document.getElementById('visitHint').textContent = '';
                    if (!lockOrderDoctor) {
                        clearOrderDoctor('ไม่พบประวัติใน HOSxP — ค้นหาหรือเลือกแพทย์ได้');
                    }
                    refreshDeptSelects('', '');
                }
                if (wantConsult) {
                    showConsultHistory(hn, (data && data.consult_history) ? data.consult_history : []);
                }
            }).catch(function() {
                document.getElementById('e_patient_name').value = 'เชื่อมต่อข้อมูลไม่สำเร็จ';
            });
    }

    function showConsultHistory(hn, items) {
        if (!items || !items.length) {
            return;
        }
        const title = document.getElementById('consultHistoryTitle');
        const body = document.getElementById('consultHistoryBody');
        const modalEl = document.getElementById('consultHistoryModal');
        if (!body || !modalEl) {
            return;
        }
        if (title) {
            title.textContent = 'เคย Consult ไว้แล้ว ' + items.length + ' รายการ  (HN ' + hn + ')';
        }
        body.innerHTML = items.map(function(it) {
            const when = [it.incident_date_th || '', it.incident_time || ''].filter(Boolean).join('  ');
            const ptype = it.patient_type === 'IPD' ? 'ผู้ป่วยใน' : (it.patient_type === 'OPD' ? 'ผู้ป่วยนอก' : '');
            const meta = [];
            if (ptype) meta.push(ptype);
            if (it.an) meta.push('AN ' + it.an);
            if (it.vn) meta.push('VN ' + it.vn);
            if (it.doctor_name) meta.push('แพทย์ ' + it.doctor_name);
            if (it.place) meta.push('จุดตรวจ ' + it.place);
            if (it.reporter_name) meta.push('ผู้บันทึก ' + it.reporter_name);
            let html = '<div class="consult-item">';
            html += '<div class="consult-when"><i class="fas fa-calendar-alt me-1"></i>' + drugEsc(when || '-') + '</div>';
            if (meta.length) {
                html += '<div class="consult-meta">' + drugEsc(meta.join(' · ')) + '</div>';
            }
            html += '<div class="consult-label">เรื่องที่ Consult</div>';
            html += '<div class="consult-desc">' + drugEsc(it.description || '-') + '</div>';
            if (it.solution) {
                html += '<div class="consult-label mt-2">การแก้ไข / คำแนะนำ</div>';
                html += '<div class="consult-desc">' + drugEsc(it.solution) + '</div>';
            }
            html += '</div>';
            return html;
        }).join('');
        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();
    }

    function setHad(value) {
        if (String(value).toUpperCase() === 'YES') {
            document.getElementById('had_yes').checked = true;
        } else {
            document.getElementById('had_no').checked = true;
        }
    }

    function setRobot(value) {
        if (String(value).toUpperCase() === 'YES') {
            document.getElementById('robot_yes').checked = true;
        } else {
            document.getElementById('robot_no').checked = true;
        }
    }

    function drugIsHad(d) {
        if (!d) return false;
        const icode = String(d.icode || '');
        if (icode && HAD_ICODES[icode]) return true;
        const lab = String(d.label || d.name || '').trim().toLowerCase();
        return lab !== '' && !!HAD_LABELS[lab];
    }

    function updateHadAuto() {
        if (skipHadAuto) return;
        const isHad = errorDrugList.concat(correctDrugList).some(drugIsHad);
        setHad(isHad ? 'YES' : 'NO');
        const hint = document.getElementById('hadHint');
        if (hint) {
            hint.textContent = isHad
                ? 'พบยาตรงกับรายการ HAD — ระบบเลือก Yes อัตโนมัติ'
                : 'ระบบเลือกอัตโนมัติจากรายการยา HAD ในตั้งค่า';
        }
    }

    function hideHadSuggest() {
        const box = document.getElementById('hadDrugSuggest');
        if (!box) return;
        box.classList.add('d-none');
        box.innerHTML = '';
    }

    function showHadSuggest(drugs) {
        const box = document.getElementById('hadDrugSuggest');
        if (!box) return;
        if (!drugs || !drugs.length) {
            box.innerHTML = '<div class="px-3 py-2 text-muted small">ไม่พบยา</div>';
            box.classList.remove('d-none');
            return;
        }
        box.innerHTML = drugs.map(function(d, i) {
            return '<button type="button" data-idx="' + i + '">' + drugEsc(d.label || d.name) + '</button>';
        }).join('');
        box.classList.remove('d-none');
        Array.prototype.forEach.call(box.querySelectorAll('button'), function(btn) {
            btn.addEventListener('mousedown', function(e) {
                e.preventDefault();
                const d = drugs[parseInt(btn.getAttribute('data-idx'), 10)];
                addHadDrug(d);
                const inp = document.getElementById('hadDrugSearch');
                inp.value = '';
                hideHadSuggest();
            });
        });
    }

    function bindHadDrugPicker() {
        const inp = document.getElementById('hadDrugSearch');
        if (!inp) return;
        inp.addEventListener('input', function() {
            const q = inp.value.trim();
            clearTimeout(drugSearchTimers.had);
            if (q.length < 2) {
                hideHadSuggest();
                return;
            }
            drugSearchTimers.had = setTimeout(function() {
                fetch('fetch_med_error_drugs_api.php?action=search&q=' + encodeURIComponent(q))
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        showHadSuggest((data && data.drugs) ? data.drugs : []);
                    }).catch(function() {
                        hideHadSuggest();
                    });
            }, 250);
        });
        inp.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') hideHadSuggest();
            if (e.key === 'Enter') {
                e.preventDefault();
                const first = document.querySelector('#hadDrugSuggest button');
                if (first) first.dispatchEvent(new MouseEvent('mousedown'));
            }
        });
        inp.addEventListener('blur', function() {
            setTimeout(function() { hideHadSuggest(); }, 180);
        });
    }

    function addHadDrug(drug) {
        if (!drug || !drug.icode) return;
        const body = new URLSearchParams({
            action: 'had_add',
            ajax: '1',
            icode: drug.icode || '',
            name: drug.name || '',
            strength: drug.strength || ''
        });
        fetch('action_error_type.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        }).then(function(res) { return res.json(); })
          .then(function(data) {
              if (!data || !data.ok) {
                  alert((data && data.message) || 'เพิ่มยา HAD ไม่สำเร็จ');
                  return;
              }
              HAD_ICODES[data.icode] = true;
              const lab = String(data.label || '').trim().toLowerCase();
              if (lab) HAD_LABELS[lab] = true;
              appendHadRow(data);
              updateHadAuto();
          }).catch(function() {
              alert('เพิ่มยา HAD ไม่สำเร็จ');
          });
    }

    function appendHadRow(data) {
        const tbody = document.getElementById('hadDrugTableBody');
        if (!tbody) return;
        const empty = document.getElementById('hadEmptyRow');
        if (empty) empty.remove();
        const tr = document.createElement('tr');
        tr.setAttribute('data-had-id', String(data.id));
        tr.innerHTML = '<td class="text-center">' + drugEsc(data.icode) + '</td>'
            + '<td>' + drugEsc(data.label || data.name) + '</td>'
            + '<td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteHadDrug(' + parseInt(data.id, 10) + ')"><i class="fas fa-trash"></i></button></td>';
        tbody.appendChild(tr);
    }

    function deleteHadDrug(id) {
        id = parseInt(id, 10);
        if (!id || !confirm('ยืนยันลบยานี้จากรายการ HAD?')) return;
        fetch('action_error_type.php?action=had_delete&ajax=1&id=' + id)
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (!data || !data.ok) {
                    alert((data && data.message) || 'ไม่สามารถลบยา HAD ได้');
                    return;
                }
                const row = document.querySelector('#hadDrugTableBody tr[data-had-id="' + id + '"]');
                if (row) {
                    const icode = (row.cells[0] && row.cells[0].textContent) ? row.cells[0].textContent.trim() : '';
                    const lab = (row.cells[1] && row.cells[1].textContent) ? row.cells[1].textContent.trim().toLowerCase() : '';
                    if (icode) delete HAD_ICODES[icode];
                    if (lab) delete HAD_LABELS[lab];
                    row.remove();
                }
                const tbody = document.getElementById('hadDrugTableBody');
                if (tbody && !tbody.querySelector('tr')) {
                    tbody.innerHTML = '<tr id="hadEmptyRow"><td colspan="3" class="text-center text-muted py-3">ยังไม่มีรายการยา HAD</td></tr>';
                }
                updateHadAuto();
            }).catch(function() {
                alert('ไม่สามารถลบยา HAD ได้');
            });
    }

    function editRecord(btn) {
        skipConsultPopup = true;
        document.getElementById('record_id').value = btn.getAttribute('data-id');
        document.getElementById('e_hn').value = btn.getAttribute('data-hn');
        document.getElementById('e_patient_name').value = btn.getAttribute('data-name');
        document.getElementById('patient_name_hidden').value = btn.getAttribute('data-name') || '';
        document.getElementById('incident_date').value = btn.getAttribute('data-date') || '';
        document.getElementById('incident_time').value = btn.getAttribute('data-time') || '';
        document.getElementById('error_level').value = btn.getAttribute('data-lvl');
        document.getElementById('description').value = btn.getAttribute('data-desc');
        document.getElementById('solution').value = btn.getAttribute('data-solution') || '';
        document.getElementById('reporter_id').value = btn.getAttribute('data-reporter');
        document.getElementById('intervention_module').value = btn.getAttribute('data-intv-module') || '';
        document.getElementById('error_category').value = btn.getAttribute('data-cat');
        editingRecord = true;
        setRecordKind(btn.getAttribute('data-kind') || 'error');
        toggleRecordKind();
        const ptype = btn.getAttribute('data-ptype') || '';
        const an = btn.getAttribute('data-an') || '';
        const vn = btn.getAttribute('data-vn') || '';
        const reporting = btn.getAttribute('data-reporting') || '';
        const errorDept = btn.getAttribute('data-error-dept') || '';
        visitContext = {
            an: an,
            vn: vn,
            suggested_type: ptype,
            ward_name: '',
            has_an: an !== '',
            has_vn: vn !== '',
            visit_rooms: [],
            preferred_room: ''
        };
        document.getElementById('e_an').value = an;
        document.getElementById('e_vn').value = vn;
        setPatientType(ptype, true);
        updateVisitHint();
        updateSubTypes();
        skipDeptDefaults = true;
        skipHadAuto = true;
        setDeptValue('reporting_dept', 'reporting_dept_other', reporting);
        setDeptValue('error_dept', 'error_dept_other', errorDept);
        dismissedErrorDrugs = {};
        dismissedCorrectDrugs = {};
        autoErrorIcodes = {};
        autoCorrectIcodes = {};
        try {
            setDrugList('error', JSON.parse(btn.getAttribute('data-error-drugs') || '[]'));
        } catch (e1) { setDrugList('error', []); }
        try {
            setDrugList('correct', JSON.parse(btn.getAttribute('data-correct-drugs') || '[]'));
        } catch (e2) { setDrugList('correct', []); }
        setHad(btn.getAttribute('data-had') || 'NO');
        setRobot(btn.getAttribute('data-robot') || 'NO');
        setRxType(btn.getAttribute('data-rx-type') || '');
        toggleRxTypeWrap();
        lockOrderDoctor = true;
        setOrderDoctor(btn.getAttribute('data-doctor-code') || '', btn.getAttribute('data-doctor-name') || '', btn.getAttribute('data-doctor-group') || '', false);
        skipHadAuto = false;
        lastDescScan = document.getElementById('description').value.trim() + '\n' + document.getElementById('solution').value.trim();
        if (document.getElementById('e_hn').value.trim() !== '') {
            fetchPatientName();
        }
        setTimeout(function() {
            document.getElementById('error_type_id').value = btn.getAttribute('data-type');
        }, 50);

        document.getElementById('formCard').classList.remove('border-danger', 'border-info');
        document.getElementById('formCard').classList.add('border-warning');
        document.getElementById('formHeader').classList.remove('bg-danger', 'bg-info', 'text-white');
        document.getElementById('formHeader').classList.add('bg-warning', 'text-dark');
        const submitBtn = document.getElementById('btnSubmitForm');
        submitBtn.innerHTML = '<i class="fas fa-save me-2"></i>อัปเดตข้อมูล';
        submitBtn.classList.remove('btn-danger', 'btn-info');
        submitBtn.classList.add('btn-warning', 'text-dark');
        document.getElementById('btnCancelEdit').classList.remove('d-none');
        document.getElementById('btnReset').classList.add('d-none');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function cancelEdit() { window.location.reload(); }

    function deleteRecord(id) {
        const confirmText = prompt("คำเตือน: คุณกำลังจะลบประวัติความคลาดเคลื่อน\n\nพิมพ์คำว่า 'delete' เพื่อยืนยัน:");
        if (confirmText === 'delete') {
            window.location.href = 'delete_med_error.php?id=' + id;
        } else if (confirmText !== null && confirmText !== '') {
            alert("พิมพ์คำว่า 'delete' ไม่ถูกต้อง ข้อมูลจะไม่ถูกลบ");
        }
    }

    function openManageTypesModal() {
        document.getElementById('typeForm').reset();
        document.getElementById('type_action').value = 'add';
        document.getElementById('type_id').value = '';
        document.getElementById('formTypeTitle').innerHTML = '<i class="fas fa-plus me-1"></i>เพิ่มหัวข้อใหม่';
        document.getElementById('btnSaveType').innerHTML = '<i class="fas fa-plus me-1"></i>เพิ่ม';
        document.getElementById('btnSaveType').className = 'btn btn-success fw-bold w-100';
        new bootstrap.Modal(document.getElementById('manageTypesModal')).show();
    }

    function editType(id, category, name) {
        document.getElementById('type_action').value = 'edit';
        document.getElementById('type_id').value = id;
        document.getElementById('type_category').value = category;
        document.getElementById('type_name').value = name;
        document.getElementById('formTypeTitle').innerHTML = '<i class="fas fa-edit me-1"></i>แก้ไขหัวข้อ';
        document.getElementById('btnSaveType').innerHTML = '<i class="fas fa-save me-1"></i>อัปเดต';
        document.getElementById('btnSaveType').className = 'btn btn-warning text-dark fw-bold w-100';
    }

    function doctorGroupFromMap(code, name) {
        code = String(code || '').trim();
        if (code && DOCTOR_GROUP_MAP[code] && DOCTOR_GROUP_MAP[code].group) {
            return DOCTOR_GROUP_MAP[code].group;
        }
        const nkey = String(name || '').trim().toLowerCase();
        if (nkey) {
            const keys = Object.keys(DOCTOR_GROUP_MAP);
            for (let i = 0; i < keys.length; i++) {
                const row = DOCTOR_GROUP_MAP[keys[i]];
                if (row && String(row.name || '').trim().toLowerCase() === nkey && row.group) {
                    return row.group;
                }
            }
        }
        return '';
    }

    function doctorGroupLabel(group) {
        return DOCTOR_GROUP_LABELS[group] || '';
    }

    function setDoctorHint(text) {
        const hint = document.getElementById('doctorHint');
        if (hint) hint.textContent = text || '';
    }

    function hideDoctorSuggest(id) {
        const box = document.getElementById(id || 'doctorSuggest');
        if (!box) return;
        box.classList.add('d-none');
        box.innerHTML = '';
    }

    function setOrderDoctor(code, name, group, fromVisit) {
        code = String(code || '').trim();
        name = String(name || '').trim();
        group = String(group || '').trim().toLowerCase();
        if (!group) group = doctorGroupFromMap(code, name);
        document.getElementById('order_doctor_code').value = code;
        document.getElementById('order_doctor_name').value = name;
        document.getElementById('order_doctor_group').value = group;
        if (!name && !code) {
            setDoctorHint('ถ้าไม่พบจาก visit ให้ค้นหาชื่อแพทย์เพื่อเลือก');
            return;
        }
        const gLabel = doctorGroupLabel(group);
        if (fromVisit) {
            setDoctorHint(gLabel
                ? ('ดึงจาก HOSxP · กลุ่ม ' + gLabel)
                : 'ดึงจาก HOSxP — ถ้าไม่ใช่แพทย์ที่ต้องการ ให้ค้นหาเลือกใหม่');
        } else if (gLabel) {
            setDoctorHint('กลุ่ม ' + gLabel);
        } else if (code) {
            setDoctorHint('เลือกจากรายชื่อ HOSxP — ยังไม่ได้จัดกลุ่มในตั้งค่า');
        } else {
            setDoctorHint('บันทึกชื่อที่พิมพ์ไว้ — ถ้าต้องการรหัสแพทย์ ให้เลือกจากรายการค้นหา');
        }
    }

    function clearOrderDoctor(hint) {
        document.getElementById('order_doctor_code').value = '';
        document.getElementById('order_doctor_name').value = '';
        document.getElementById('order_doctor_group').value = '';
        setDoctorHint(hint || 'ถ้าไม่พบจาก visit ให้ค้นหาชื่อแพทย์เพื่อเลือก');
        hideDoctorSuggest('doctorSuggest');
    }

    function showDoctorSuggest(boxId, list, onPick) {
        const box = document.getElementById(boxId);
        if (!box) return;
        if (!list || !list.length) {
            box.innerHTML = '<div class="px-3 py-2 text-muted small">ไม่พบแพทย์</div>';
            box.classList.remove('d-none');
            return;
        }
        box.innerHTML = list.map(function(d, i) {
            const extra = d.group_label ? '<span class="badge bg-light text-dark border">' + drugEsc(d.group_label) + '</span>' : '';
            return '<button type="button" data-idx="' + i + '"><span>' + drugEsc(d.text || d.name) + '</span>' + extra + '</button>';
        }).join('');
        box.classList.remove('d-none');
        Array.prototype.forEach.call(box.querySelectorAll('button'), function(btn) {
            btn.addEventListener('mousedown', function(e) {
                e.preventDefault();
                const d = list[parseInt(btn.getAttribute('data-idx'), 10)];
                if (d) onPick(d);
                hideDoctorSuggest(boxId);
            });
        });
    }

    function searchHosxpDoctors(term, done) {
        fetch('fetch_patient_api.php?action=search_doctor&q=' + encodeURIComponent(term))
            .then(function(res) { return res.json(); })
            .then(function(data) {
                done((data && data.results) ? data.results : []);
            }).catch(function() {
                done([]);
            });
    }

    function bindDoctorPicker() {
        const inp = document.getElementById('order_doctor_name');
        if (!inp) return;
        inp.addEventListener('input', function() {
            const q = inp.value.trim();
            document.getElementById('order_doctor_code').value = '';
            document.getElementById('order_doctor_group').value = doctorGroupFromMap('', q);
            clearTimeout(drugSearchTimers.doctor);
            if (q.length < 2) {
                hideDoctorSuggest('doctorSuggest');
                setDoctorHint(q ? 'พิมพ์อย่างน้อย 2 ตัวอักษรเพื่อค้นหาแพทย์' : 'ถ้าไม่พบจาก visit ให้ค้นหาชื่อแพทย์เพื่อเลือก');
                return;
            }
            drugSearchTimers.doctor = setTimeout(function() {
                searchHosxpDoctors(q, function(list) {
                    showDoctorSuggest('doctorSuggest', list, function(d) {
                        setOrderDoctor(d.code || '', d.name || '', d.group || '', false);
                    });
                });
            }, 250);
        });
        inp.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') hideDoctorSuggest('doctorSuggest');
        });
        inp.addEventListener('blur', function() {
            setTimeout(function() { hideDoctorSuggest('doctorSuggest'); }, 180);
        });
    }

    function bindSetDoctorPicker() {
        const inp = document.getElementById('setDoctorSearch');
        if (!inp) return;
        inp.addEventListener('input', function() {
            const q = inp.value.trim();
            document.getElementById('setDoctorCode').value = '';
            clearTimeout(drugSearchTimers.setDoctor);
            if (q.length < 2) {
                hideDoctorSuggest('setDoctorSuggest');
                return;
            }
            drugSearchTimers.setDoctor = setTimeout(function() {
                searchHosxpDoctors(q, function(list) {
                    showDoctorSuggest('setDoctorSuggest', list, function(d) {
                        document.getElementById('setDoctorCode').value = d.code || '';
                        inp.value = d.name || '';
                        if (d.group) document.getElementById('setDoctorGroup').value = d.group;
                    });
                });
            }, 250);
        });
        inp.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') hideDoctorSuggest('setDoctorSuggest');
        });
        inp.addEventListener('blur', function() {
            setTimeout(function() { hideDoctorSuggest('setDoctorSuggest'); }, 180);
        });
    }

    function doctorGroupBadgeClass(group) {
        if (group === 'staff') return 'bg-primary';
        if (group === 'intern') return 'bg-info text-dark';
        if (group === 'extern') return 'bg-dark';
        return 'bg-secondary';
    }

    function saveDoctorGroup() {
        const code = document.getElementById('setDoctorCode').value.trim();
        const name = document.getElementById('setDoctorSearch').value.trim();
        const group = document.getElementById('setDoctorGroup').value;
        if (!code) {
            alert('กรุณาค้นหาและเลือกแพทย์จาก HOSxP ก่อน');
            return;
        }
        const fd = new FormData();
        fd.append('action', 'doctor_group_save');
        fd.append('ajax', '1');
        fd.append('doctor_code', code);
        fd.append('doctor_name', name);
        fd.append('group_key', group);
        fetch('action_error_type.php', { method: 'POST', body: fd })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (!data || !data.ok) {
                    alert((data && data.message) ? data.message : 'ไม่สามารถบันทึกกลุ่มแพทย์ได้');
                    return;
                }
                DOCTOR_GROUP_MAP[data.code] = {
                    group: data.group,
                    name: data.name,
                    group_label: data.group_label
                };
                const tbody = document.getElementById('doctorGroupTableBody');
                const empty = document.getElementById('doctorGroupEmptyRow');
                if (empty) empty.remove();
                let row = tbody.querySelector('tr[data-doc-group-id="' + data.id + '"]');
                const html = '<td class="text-center">' + drugEsc(data.code) + '</td>'
                    + '<td>' + drugEsc(data.name) + '</td>'
                    + '<td class="text-center"><span class="badge ' + doctorGroupBadgeClass(data.group) + '">' + drugEsc(data.group_label) + '</span></td>'
                    + '<td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteDoctorGroup(' + data.id + ')"><i class="fas fa-trash"></i></button></td>';
                if (row) {
                    row.innerHTML = html;
                } else {
                    row = document.createElement('tr');
                    row.setAttribute('data-doc-group-id', String(data.id));
                    row.innerHTML = html;
                    tbody.appendChild(row);
                }
                document.getElementById('setDoctorCode').value = '';
                document.getElementById('setDoctorSearch').value = '';
                const curCode = document.getElementById('order_doctor_code').value.trim();
                if (curCode && curCode === data.code) {
                    setOrderDoctor(curCode, document.getElementById('order_doctor_name').value, data.group, false);
                }
            }).catch(function() {
                alert('ไม่สามารถบันทึกกลุ่มแพทย์ได้');
            });
    }

    function deleteDoctorGroup(id) {
        if (!confirm('ยืนยันลบแพทย์ออกจากกลุ่มนี้?')) return;
        const fd = new FormData();
        fd.append('action', 'doctor_group_delete');
        fd.append('ajax', '1');
        fd.append('id', String(id));
        fetch('action_error_type.php', { method: 'POST', body: fd })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (!data || !data.ok) {
                    alert((data && data.message) ? data.message : 'ไม่สามารถลบกลุ่มแพทย์ได้');
                    return;
                }
                const row = document.querySelector('#doctorGroupTableBody tr[data-doc-group-id="' + id + '"]');
                if (row) {
                    const code = (row.cells[0] && row.cells[0].textContent) ? row.cells[0].textContent.trim() : '';
                    if (code && DOCTOR_GROUP_MAP[code]) delete DOCTOR_GROUP_MAP[code];
                    row.remove();
                }
                const tbody = document.getElementById('doctorGroupTableBody');
                if (tbody && !tbody.querySelector('tr')) {
                    tbody.innerHTML = '<tr id="doctorGroupEmptyRow"><td colspan="4" class="text-center text-muted py-3">ยังไม่ได้จัดกลุ่มแพทย์</td></tr>';
                }
            }).catch(function() {
                alert('ไม่สามารถลบกลุ่มแพทย์ได้');
            });
    }
</script>
</body>
</html>
