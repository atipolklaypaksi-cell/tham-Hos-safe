<?php
/**
 * Monitor เครื่องคำนวณยา — ดึงรายการจาก dose_calculator.php แล้วผูกยา HOSxP เพื่อตรวจใบสั่ง
 */

function mdc_catalog() {
    static $cat = null;
    if ($cat !== null) {
        return $cat;
    }
    $cat = [
        'methylpred' => [
            'label' => 'Methylpred 23/24 hr',
            'group' => 'thrombolysis',
            'group_label' => 'Thrombolysis / Methylpred',
            'check_kind' => 'weight_total_mg',
            'hint' => 'Bolus 30 mg/kg + infusion 5.4 mg/kg/hr × ชั่วโมง (Amp 1000 mg)',
            'need_bw' => true,
            'need_age' => false,
            'mappable' => true,
            'default_hours' => 24,
            'amp_mg' => 1000,
        ],
        'rtpa_stemi' => [
            'label' => 'rT-PA STEMI',
            'group' => 'thrombolysis',
            'group_label' => 'Thrombolysis / Methylpred',
            'check_kind' => 'weight_total_mg',
            'hint' => '15 mg bolus + 0.75 mg/kg (max 50) + 0.5 mg/kg (max 30) · รวมไม่เกิน 100 mg',
            'need_bw' => true,
            'mappable' => true,
        ],
        'rtpa_stroke' => [
            'label' => 'rT-PA STROKE',
            'group' => 'thrombolysis',
            'group_label' => 'Thrombolysis / Methylpred',
            'check_kind' => 'weight_total_mg',
            'hint' => '0.9 mg/kg (สูงสุด 90 mg)',
            'need_bw' => true,
            'mappable' => true,
        ],
        'tnk_stroke' => [
            'label' => 'TNK Stroke',
            'group' => 'thrombolysis',
            'group_label' => 'Thrombolysis / Methylpred',
            'check_kind' => 'weight_total_mg',
            'hint' => 'ขนาดตามช่วงน้ำหนัก (15–25 mg)',
            'need_bw' => true,
            'mappable' => true,
        ],
        'tnk_stemi' => [
            'label' => 'TNK STEMI',
            'group' => 'thrombolysis',
            'group_label' => 'Thrombolysis / Methylpred',
            'check_kind' => 'weight_total_mg',
            'hint' => 'ขนาดตามช่วงน้ำหนัก (30–50 mg) · อายุ >75 ปี ลดครึ่ง',
            'need_bw' => true,
            'need_age' => true,
            'mappable' => true,
        ],
        'midazolam' => [
            'label' => 'Midazolam',
            'group' => 'sedation',
            'group_label' => 'Sedation / Analgesia',
            'check_kind' => 'midazolam',
            'hint' => 'Bolus 0.05–0.15 mg/kg · infusion สูงสุด 100 mcg/kg/hr',
            'need_bw' => true,
            'mappable' => true,
            'bolus_min_mg_kg' => 0.05,
            'bolus_max_mg_kg' => 0.15,
            'max_mcg_kg_hr' => 100,
            'warn_mcg_kg_hr' => 20,
        ],
        'fentanyl' => [
            'label' => 'Fentanyl',
            'group' => 'sedation',
            'group_label' => 'Sedation / Analgesia',
            'check_kind' => 'weight_range_mcg',
            'hint' => 'Bolus ประมาณ 1 mcg/kg',
            'need_bw' => true,
            'mappable' => true,
            'min_mcg_kg' => 0.5,
            'max_mcg_kg' => 2,
        ],
        'dobutamine' => [
            'label' => 'Dobutamine',
            'group' => 'vasoactive',
            'group_label' => 'Vasoactive / Infusion',
            'check_kind' => 'mcg_kg_min',
            'hint' => 'แนะนำ ≤ 20 mcg/kg/min · Max 40',
            'need_bw' => true,
            'mappable' => true,
            'warn_mcg_kg_min' => 20,
            'max_mcg_kg_min' => 40,
            'stock_mg_ml' => 12.5,
        ],
        'dopamine' => [
            'label' => 'Dopamine',
            'group' => 'vasoactive',
            'group_label' => 'Vasoactive / Infusion',
            'check_kind' => 'mcg_kg_min',
            'hint' => 'Low 1–5 · Medium 5–15 · High 20–50 mcg/kg/min',
            'need_bw' => true,
            'mappable' => true,
            'warn_mcg_kg_min' => 20,
            'max_mcg_kg_min' => 50,
            'stock_mg_ml' => 40,
        ],
        'norepinephrine' => [
            'label' => 'NE (Norepinephrine)',
            'group' => 'vasoactive',
            'group_label' => 'Vasoactive / Infusion',
            'check_kind' => 'mcg_kg_min',
            'hint' => 'ช่วงยา 0.01–3 mcg/kg/min · ≥ 3 เกิน Max',
            'need_bw' => true,
            'mappable' => true,
            'warn_mcg_kg_min' => 1,
            'max_mcg_kg_min' => 3,
            'stock_mg_ml' => 1,
        ],
        'cisatracurium' => [
            'label' => 'Cisatracurium',
            'group' => 'vasoactive',
            'group_label' => 'Vasoactive / Infusion',
            'check_kind' => 'mcg_kg_min',
            'hint' => 'Infusion mcg/kg/min ตามน้ำหนัก',
            'need_bw' => true,
            'mappable' => true,
            'warn_mcg_kg_min' => 5,
            'max_mcg_kg_min' => 10,
            'stock_mg_ml' => 2,
        ],
        'adrenaline' => [
            'label' => 'Adrenaline',
            'group' => 'vasoactive',
            'group_label' => 'Vasoactive / Infusion',
            'check_kind' => 'mcg_kg_min',
            'hint' => 'Infusion mcg/kg/min ตามน้ำหนัก',
            'need_bw' => true,
            'mappable' => true,
            'warn_mcg_kg_min' => 0.3,
            'max_mcg_kg_min' => 1,
            'stock_mg_ml' => 1,
        ],
        'alprostadil' => [
            'label' => 'Alprostadil',
            'group' => 'neonatal',
            'group_label' => 'Neonatal / อื่น ๆ',
            'check_kind' => 'mcg_kg_min',
            'hint' => 'Infusion mcg/kg/min ตามน้ำหนัก',
            'need_bw' => true,
            'mappable' => true,
            'warn_mcg_kg_min' => 0.05,
            'max_mcg_kg_min' => 0.1,
            'stock_mg_ml' => 0.5,
        ],
        'calcium_glu' => [
            'label' => 'Calcium gluconate',
            'group' => 'neonatal',
            'group_label' => 'Neonatal / อื่น ๆ',
            'check_kind' => 'weight_range_mg',
            'hint' => 'Initial 100–200 mg/kg · Maintenance 200–800 mg/kg',
            'need_bw' => true,
            'mappable' => true,
            'min_mg_kg' => 100,
            'max_mg_kg' => 800,
        ],
        'indomethacin' => [
            'label' => 'Indomethacin',
            'group' => 'neonatal',
            'group_label' => 'Neonatal / อื่น ๆ',
            'check_kind' => 'weight_range_mg',
            'hint' => '0.1–0.25 mg/kg ต่อครั้ง ตามอายุหลังเกิด',
            'need_bw' => true,
            'mappable' => true,
            'min_mg_kg' => 0.1,
            'max_mg_kg' => 0.25,
        ],
        'nac' => [
            'label' => 'NAC (Paracetamol OD)',
            'group' => 'antidote',
            'group_label' => 'Antidote / อื่น ๆ',
            'check_kind' => 'weight_total_mg',
            'hint' => '150 + 50 + 100 mg/kg (คิดน้ำหนักสูงสุด 110 kg)',
            'need_bw' => true,
            'mappable' => true,
            'amp_mg' => 300,
        ],
        'iloprost' => [
            'label' => 'Iloprost',
            'group' => 'vasoactive',
            'group_label' => 'Vasoactive / Infusion',
            'check_kind' => 'ng_kg_min',
            'hint' => 'Infusion ng/kg/min ตามน้ำหนัก',
            'need_bw' => true,
            'mappable' => true,
            'warn_ng_kg_min' => 2,
            'max_ng_kg_min' => 4,
        ],
        'kcl' => [
            'label' => 'KCL',
            'group' => 'electrolyte',
            'group_label' => 'Electrolyte / NTG',
            'check_kind' => 'meq_hr',
            'hint' => 'Peripheral < 10 mEq/hr · Central 10–20 · เกิน 20 อันตราย',
            'need_bw' => false,
            'mappable' => true,
            'warn_meq_hr' => 10,
            'max_meq_hr' => 20,
        ],
        'ntg' => [
            'label' => 'NTG',
            'group' => 'electrolyte',
            'group_label' => 'Electrolyte / NTG',
            'check_kind' => 'mcg_min',
            'hint' => 'HF/edema max 200 mcg/min · Angina max 400',
            'need_bw' => false,
            'mappable' => true,
            'warn_mcg_min' => 200,
            'max_mcg_min' => 400,
        ],
        'arv_ped' => [
            'label' => 'ARV เด็ก',
            'group' => 'table',
            'group_label' => 'ตารางยา (เด็ก)',
            'check_kind' => 'weight_range_mg',
            'hint' => 'ตรวจ mg/kg จากวิธีใช้ เทียบช่วงที่ตั้งค่า (หรือช่วงกว้างจากตารางเครื่องคำนวณ)',
            'need_bw' => true,
            'mappable' => true,
            'min_mg_kg' => 1,
            'max_mg_kg' => 8,
        ],
        'tb' => [
            'label' => 'TB',
            'group' => 'table',
            'group_label' => 'ตารางยา (เด็ก)',
            'check_kind' => 'weight_range_mg',
            'hint' => 'ตรวจ mg/kg จากวิธีใช้ เทียบช่วงที่ตั้งค่า',
            'need_bw' => true,
            'mappable' => true,
            'min_mg_kg' => 5,
            'max_mg_kg' => 25,
        ],
        'lbw' => [
            'label' => 'LBW / วิสัญญี',
            'group' => 'utility',
            'group_label' => 'เครื่องมือช่วย',
            'check_kind' => 'none',
            'hint' => 'ใช้คำนวณ Lean Body Weight ไม่ได้ผูกยา Monitor',
            'need_bw' => true,
            'mappable' => false,
        ],
    ];
    return $cat;
}

function mdc_catalog_item($calc_type) {
    $all = mdc_catalog();
    return $all[$calc_type] ?? null;
}

function mdc_mappable_types() {
    $out = [];
    foreach (mdc_catalog() as $k => $item) {
        if (!empty($item['mappable'])) {
            $out[$k] = $item;
        }
    }
    return $out;
}

/** คำค้นยา HOSxP ที่จะผูกกับแต่ละสูตร — ไม่ทับรายการที่ผู้ใช้เพิ่ม/แก้ไขแล้ว */
function mdc_bind_specs() {
    return [
        'methylpred' => [
            'require' => [['methylprednisolone', 'methylpred', 'solumedrol', 'solu medrol']],
            'exclude' => ['cream', 'ointment', 'lotion', 'eye', 'drop', 'tablet', 'tab '],
            'alert_level' => 'hard',
        ],
        'rtpa_stemi' => [
            'require' => [['alteplase', 'actilyse', 'rt pa', 'rtpa']],
            'alert_level' => 'hard',
        ],
        'rtpa_stroke' => [
            'require' => [['alteplase', 'actilyse', 'rt pa', 'rtpa']],
            'alert_level' => 'hard',
        ],
        'tnk_stemi' => [
            'require' => [['tenecteplase', 'metalyse']],
            'alert_level' => 'hard',
        ],
        'tnk_stroke' => [
            'require' => [['tenecteplase', 'metalyse']],
            'alert_level' => 'hard',
        ],
        'midazolam' => [
            'require' => [['midazolam', 'dormicum']],
            'exclude' => ['syrup', 'oral'],
            'alert_level' => 'hard',
        ],
        'fentanyl' => [
            'require' => [['fentanyl']],
            'exclude' => ['patch', 'transdermal', 'ors'],
            'alert_level' => 'hard',
        ],
        'dobutamine' => [
            'require' => [['dobutamine']],
            'alert_level' => 'hard',
        ],
        'dopamine' => [
            'require' => [['dopamine']],
            'exclude' => ['levodopa', 'l dopa'],
            'alert_level' => 'hard',
        ],
        'norepinephrine' => [
            'require' => [['norepinephrine', 'noradrenaline', 'levophed']],
            'alert_level' => 'hard',
        ],
        'cisatracurium' => [
            'require' => [['cisatracurium', 'nimbex']],
            'alert_level' => 'hard',
        ],
        'adrenaline' => [
            'require' => [['adrenaline', 'epinephrine']],
            'exclude' => ['lidocaine', 'lignocaine', 'xylocaine', 'norepinephrine', 'noradrenaline'],
            'alert_level' => 'hard',
        ],
        'alprostadil' => [
            'require' => [['alprostadil', 'prostin']],
            'alert_level' => 'hard',
        ],
        'calcium_glu' => [
            'require' => [['calcium gluconate']],
            'exclude' => ['tpn'],
            'alert_level' => 'hard',
        ],
        'indomethacin' => [
            'require' => [['indomethacin', 'indometacin']],
            'exclude' => ['25 mg', '25mg', 'capsule', 'cap '],
            'alert_level' => 'hard',
        ],
        'nac' => [
            'require' => [['acetylcysteine', 'n acetylcysteine']],
            'exclude' => ['sachet', 'granule'],
            'need_inj' => true,
            'alert_level' => 'hard',
        ],
        'iloprost' => [
            'require' => [['iloprost', 'ventavis']],
            'alert_level' => 'hard',
        ],
        'kcl' => [
            'require' => [
                ['kcl', 'potassium chloride', 'potassiumcl', 'potassium cl'],
                ['inj', 'injection', 'meq'],
            ],
            'exclude' => ['elixir', 'tpn', 'ringer', 'ors', 'balance salt', 'acetate', 'oral'],
            'alert_level' => 'hard',
        ],
        'ntg' => [
            'require' => [['nitroglycerin', 'glyceryl trinitrate', 'trinitrin']],
            'exclude' => ['guaifenesin', 'guaiacolate'],
            'alert_level' => 'hard',
        ],
        'arv_ped' => [
            'require' => [['zidovudine', 'lamivudine', 'nevirapine']],
            'exclude' => ['heb-b', 'tenofovir', 'abacavir', 'dolutegravir', 'kivexa'],
            'skip_combo' => true,
            'alert_level' => 'soft',
        ],
        'tb' => [
            'require' => [['isoniazid', 'rifampicin', 'rifampin', 'pyrazinamide', 'ethambutol']],
            'exclude' => ['rifapentine'],
            'skip_combo' => true,
            'alert_level' => 'soft',
        ],
    ];
}

function mdc_bind_norm($s) {
    $s = strtolower((string)$s);
    $s = str_replace(['-', '_', '/', '(', ')', ',', '.', '+', '*'], ' ', $s);
    $s = preg_replace('/\s+/u', ' ', $s);
    return trim($s);
}

function mdc_bind_has($blob, $needle) {
    $n = mdc_bind_norm($needle);
    if ($n === '') {
        return false;
    }
    return (bool)preg_match('/(?:^| )' . preg_quote($n, '/') . '(?: |$)/u', ' ' . $blob . ' ');
}

function mdc_bind_drug_matches(array $drug, array $spec) {
    $local = (string)($drug['name_local'] ?? '');
    $tmt = (string)($drug['name_tmt'] ?? '');
    $blob = mdc_bind_norm($local . ' ' . $tmt);
    if ($blob === '') {
        return false;
    }
    if (!empty($spec['skip_combo']) && (strpos($local, '+') !== false || strpos($tmt, '+') !== false)) {
        return false;
    }
    foreach ($spec['exclude'] ?? [] as $ex) {
        if (mdc_bind_has($blob, $ex)) {
            return false;
        }
    }
    foreach ($spec['require'] ?? [] as $group) {
        $ok = false;
        foreach ((array)$group as $n) {
            if (mdc_bind_has($blob, $n)) {
                $ok = true;
                break;
            }
        }
        if (!$ok) {
            return false;
        }
    }
    if (!empty($spec['need_inj'])) {
        if (!mdc_bind_has($blob, 'inj') && !mdc_bind_has($blob, 'injection') && !mdc_bind_has($blob, 'amp')) {
            return false;
        }
    }
    return true;
}

/**
 * ผูกยา HOSxP เข้าสูตรเครื่องคำนวณ — ข้ามคู่สูตร+icode ที่มีอยู่แล้ว (แก้/ลบของผู้ใช้ไม่ถูกทับ)
 * @return array{inserted:int,skipped:int,unmatched:array,by_type:array}
 */
function mdc_import_hosxp_bindings($con, $hos) {
    mdc_ensure_table($con);
    $out = ['inserted' => 0, 'skipped' => 0, 'unmatched' => [], 'by_type' => []];
    if (!$hos) {
        $out['error'] = 'ไม่สามารถเชื่อมต่อ HOSxP';
        return $out;
    }
    $drugs = hosxp_fetch_active_drugs_tmt($hos);
    if (empty($drugs)) {
        $out['error'] = 'ไม่พบรายการยา HOSxP';
        return $out;
    }
    $existing = [];
    $q = mysqli_query($con, 'SELECT calc_type, icode FROM monitor_dose_calculator_settings');
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $existing[trim((string)$r['calc_type']) . '|' . trim((string)$r['icode'])] = true;
        }
    }
    foreach (mdc_bind_specs() as $calc_type => $spec) {
        $meta = mdc_catalog_item($calc_type);
        if (!$meta || empty($meta['mappable'])) {
            continue;
        }
        $hits = 0;
        $level = (($spec['alert_level'] ?? '') === 'soft') ? 'soft' : 'hard';
        $hours_sql = isset($meta['default_hours']) ? mdc_sql_num($meta['default_hours']) : 'NULL';
        $stock_sql = isset($meta['stock_mg_ml']) ? mdc_sql_num($meta['stock_mg_ml']) : 'NULL';
        $min_sql = 'NULL';
        $max_sql = 'NULL';
        if (isset($meta['min_mg_kg'])) {
            $min_sql = mdc_sql_num($meta['min_mg_kg']);
        }
        if (isset($meta['max_mg_kg'])) {
            $max_sql = mdc_sql_num($meta['max_mg_kg']);
        }
        $type_esc = mdc_escape($con, $calc_type);
        $lvl_esc = mdc_escape($con, $level);
        foreach ($drugs as $d) {
            if (!mdc_bind_drug_matches($d, $spec)) {
                continue;
            }
            $icode = trim((string)($d['icode'] ?? ''));
            if ($icode === '') {
                continue;
            }
            $key = $calc_type . '|' . $icode;
            if (isset($existing[$key])) {
                $out['skipped']++;
                $hits++;
                continue;
            }
            $name = trim((string)($d['name_tmt'] ?? ''));
            if ($name === '') {
                $name = trim((string)($d['name_local'] ?? $icode));
            }
            $ic_esc = mdc_escape($con, $icode);
            $name_esc = mdc_escape($con, $name);
            $sql = "INSERT INTO monitor_dose_calculator_settings
                (calc_type, icode, drug_name, alert_level, alert_message, tolerance_pct, default_hours, stock_mg_ml, mg_per_kg_min, mg_per_kg_max, active)
                VALUES ('$type_esc', '$ic_esc', '$name_esc', '$lvl_esc', NULL, NULL, $hours_sql, $stock_sql, $min_sql, $max_sql, 1)";
            if (mysqli_query($con, $sql)) {
                $existing[$key] = true;
                $out['inserted']++;
                $hits++;
                $out['by_type'][$calc_type] = ($out['by_type'][$calc_type] ?? 0) + 1;
            }
        }
        if ($hits === 0) {
            $out['unmatched'][] = $meta['label'] ?? $calc_type;
        }
    }
    return $out;
}

function mdc_ensure_table($con) {
    $q = mysqli_query($con, "SHOW TABLES LIKE 'monitor_dose_calculator_settings'");
    if ($q && mysqli_num_rows($q) > 0) {
        mdc_ensure_config_table($con);
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_dose_calculator.sql');
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '' && !mysqli_query($con, $stmt)) {
            return false;
        }
    }
    return true;
}

function mdc_ensure_config_table($con) {
    $q = mysqli_query($con, "SHOW TABLES LIKE 'monitor_dose_calculator_config'");
    if ($q && mysqli_num_rows($q) > 0) {
        return true;
    }
    mysqli_query($con, "CREATE TABLE IF NOT EXISTS monitor_dose_calculator_config (
        id TINYINT NOT NULL PRIMARY KEY,
        tolerance_pct DECIMAL(5,2) NOT NULL DEFAULT 10.00
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    mysqli_query($con, "INSERT IGNORE INTO monitor_dose_calculator_config (id, tolerance_pct) VALUES (1, 10.00)");
    return true;
}

function mdc_escape($con, $v) {
    return mysqli_real_escape_string($con, (string)($v ?? ''));
}

function mdc_fmt($val, $digits = 2) {
    if ($val === null || $val === '' || !is_numeric($val)) {
        return '—';
    }
    $n = (float)$val;
    $s = number_format($n, $digits, '.', '');
    $s = rtrim(rtrim($s, '0'), '.');
    return $s === '' ? '0' : $s;
}

function mdc_default_tolerance_pct() {
    return 10.0;
}

function mdc_clamp_tolerance_pct($v) {
    $n = (float)$v;
    if ($n < 0) {
        $n = 0;
    }
    if ($n > 100) {
        $n = 100;
    }
    return $n;
}

function mdc_get_monitor_tolerance_pct($con) {
    mdc_ensure_config_table($con);
    $q = mysqli_query($con, "SELECT tolerance_pct FROM monitor_dose_calculator_config WHERE id=1 LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return mdc_clamp_tolerance_pct($r['tolerance_pct'] ?? mdc_default_tolerance_pct());
    }
    return mdc_default_tolerance_pct();
}

function mdc_save_monitor_tolerance_pct($con, $pct) {
    mdc_ensure_config_table($con);
    $n = mdc_clamp_tolerance_pct($pct);
    mysqli_query($con, "INSERT INTO monitor_dose_calculator_config (id, tolerance_pct) VALUES (1, $n)
        ON DUPLICATE KEY UPDATE tolerance_pct=$n");
    return $n;
}

function mdc_effective_tolerance_pct(array $rule, $global_pct) {
    if (isset($rule['tolerance_pct']) && $rule['tolerance_pct'] !== '' && $rule['tolerance_pct'] !== null) {
        return mdc_clamp_tolerance_pct($rule['tolerance_pct']);
    }
    return mdc_clamp_tolerance_pct($global_pct);
}

function mdc_alert_level(array $rule) {
    return (($rule['alert_level'] ?? '') === 'soft') ? 'soft' : 'hard';
}

function mdc_load_rules($con, array $rule_ids = [], $active_only = true) {
    mdc_ensure_table($con);
    $sql = "SELECT * FROM monitor_dose_calculator_settings";
    $where = [];
    if ($active_only) {
        $where[] = 'active = 1';
    }
    $filter = [];
    foreach ($rule_ids as $rid) {
        $rid = (int)$rid;
        if ($rid > 0) {
            $filter[$rid] = true;
        }
    }
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY calc_type ASC, drug_name ASC, id ASC';
    $q = mysqli_query($con, $sql);
    $out = [];
    if (!$q) {
        return $out;
    }
    while ($r = mysqli_fetch_assoc($q)) {
        if (!empty($filter) && !isset($filter[(int)$r['id']])) {
            continue;
        }
        $type = trim((string)($r['calc_type'] ?? ''));
        $meta = mdc_catalog_item($type);
        if (!$meta || empty($meta['mappable'])) {
            continue;
        }
        if (trim((string)($r['icode'] ?? '')) === '') {
            continue;
        }
        $r['_meta'] = $meta;
        $out[] = $r;
    }
    return $out;
}

function mdc_build_rule_map_by_icode(array $rules) {
    $map = [];
    foreach ($rules as $r) {
        $ic = trim((string)($r['icode'] ?? ''));
        if ($ic === '') {
            continue;
        }
        $map[$ic][] = $r;
    }
    return $map;
}

function mdc_tnk_stroke_mg($bw) {
    if ($bw < 60) {
        return 15.0;
    }
    if ($bw < 70) {
        return 17.5;
    }
    if ($bw < 80) {
        return 20.0;
    }
    if ($bw < 90) {
        return 22.5;
    }
    return 25.0;
}

function mdc_tnk_stemi_mg($bw, $age = null) {
    if ($bw < 60) {
        $mg = 30.0;
    } elseif ($bw < 70) {
        $mg = 35.0;
    } elseif ($bw < 80) {
        $mg = 40.0;
    } elseif ($bw < 90) {
        $mg = 45.0;
    } else {
        $mg = 50.0;
    }
    if ($age !== null && (int)$age > 75) {
        $mg = $mg / 2;
    }
    return $mg;
}

function mdc_rtpa_stemi_total_mg($bw) {
    $bolus = 15.0;
    $drip1 = min(0.75 * $bw, 50);
    $drip2 = min(0.5 * $bw, 30);
    $total = $bolus + $drip1 + $drip2;
    if ($total > 100) {
        $remain = 100 - $bolus;
        $sum = $drip1 + $drip2;
        if ($sum > 0) {
            $drip1 = $remain * ($drip1 / $sum);
            $drip2 = $remain * ($drip2 / $sum);
        }
        $total = 100;
    }
    return $total;
}

function mdc_extract_mcg_kg_min($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|ug|ไมโครกรัม)\s*\/\s*kg\s*\/\s*min\b/iu', $text, $m)) {
        return (float)$m[1];
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|ug)\s*\/\s*kg\/min\b/iu', $text, $m2)) {
        return (float)$m2[1];
    }
    return null;
}

function mdc_extract_mcg_kg_hr($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|ug)\s*\/\s*kg\s*\/\s*(?:hr|hour|ชม)\b/iu', $text, $m)) {
        return (float)$m[1];
    }
    return null;
}

function mdc_extract_mcg_min($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|ug)\s*\/\s*min\b/iu', $text, $m)) {
        return (float)$m[1];
    }
    return null;
}

function mdc_extract_ng_kg_min($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*ng\s*\/\s*kg\s*\/\s*min\b/iu', $text, $m)) {
        return (float)$m[1];
    }
    return null;
}

function mdc_extract_meq_hr($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mEq|meq|mEq)\s*\/\s*(?:hr|hour|ชม)\b/iu', $text, $m)) {
        return (float)$m[1];
    }
    return null;
}

function mdc_extract_mcg($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return null;
    }
    if (preg_match('/(\d+(?:\.\d+)?)\s*(?:mcg|µg|ug)\b/iu', $text, $m)) {
        $after = substr($text, strpos($text, $m[0]) + strlen($m[0]));
        if (preg_match('/^\s*\/\s*(?:kg|min|hr)/iu', $after)) {
            return null;
        }
        return (float)$m[1];
    }
    return null;
}

function mdc_dose_from_rate_conc($rate_ml_hr, $conc_mg_ml, $bw) {
    if (!($rate_ml_hr > 0) || !($conc_mg_ml > 0) || !($bw > 0)) {
        return null;
    }
    return ($rate_ml_hr * $conc_mg_ml * 1000) / ($bw * 60);
}

function mdc_within_tol($found, $expected, $tol_pct) {
    if ($expected === null || $found === null) {
        return null;
    }
    $expected = (float)$expected;
    $found = (float)$found;
    if ($expected == 0.0) {
        return abs($found) < 1e-6;
    }
    $tol = max(0, (float)$tol_pct) / 100.0;
    $lo = $expected * (1 - $tol);
    $hi = $expected * (1 + $tol);
    return $found >= $lo && $found <= $hi;
}

function mdc_expected_total_mg(array $rule, $bw, $age, $method) {
    $type = $rule['calc_type'] ?? '';
    $bw = (float)$bw;
    if ($bw <= 0) {
        return null;
    }
    if ($type === 'methylpred') {
        $hours = null;
        if (function_exists('mmgml_extract_hours')) {
            $hours = mmgml_extract_hours($method);
        }
        if (!($hours > 0)) {
            $hours = (float)($rule['default_hours'] ?? 0);
        }
        if (!($hours > 0)) {
            $hours = 24;
        }
        if (abs($hours - 47) < 0.01) {
            $hours = 47;
        }
        return (30 * $bw) + (5.4 * $bw * $hours);
    }
    if ($type === 'rtpa_stemi') {
        return mdc_rtpa_stemi_total_mg($bw);
    }
    if ($type === 'rtpa_stroke') {
        return min(0.9 * $bw, 90);
    }
    if ($type === 'tnk_stroke') {
        return mdc_tnk_stroke_mg($bw);
    }
    if ($type === 'tnk_stemi') {
        return mdc_tnk_stemi_mg($bw, $age);
    }
    if ($type === 'nac') {
        $bwCalc = min($bw, 110);
        return 300 * $bwCalc;
    }
    return null;
}

function mdc_range_mg_kg(array $rule) {
    $meta = $rule['_meta'] ?? mdc_catalog_item($rule['calc_type'] ?? '') ?: [];
    $min_raw = $rule['mg_per_kg_min'] ?? null;
    $max_raw = $rule['mg_per_kg_max'] ?? null;
    $min = ($min_raw !== null && $min_raw !== '')
        ? (float)$min_raw
        : (isset($meta['min_mg_kg']) ? (float)$meta['min_mg_kg'] : null);
    $max = ($max_raw !== null && $max_raw !== '')
        ? (float)$max_raw
        : (isset($meta['max_mg_kg']) ? (float)$meta['max_mg_kg'] : null);
    return [$min, $max];
}

function mdc_evaluate_order(array $rule, array $ctx) {
    $meta = $rule['_meta'] ?? mdc_catalog_item($rule['calc_type'] ?? '') ?: [];
    $kind = $meta['check_kind'] ?? 'none';
    $method = trim((string)($ctx['method'] ?? ''));
    $bw = isset($ctx['weight_kg']) && $ctx['weight_kg'] !== null && (float)$ctx['weight_kg'] > 0
        ? (float)$ctx['weight_kg'] : null;
    $age = isset($ctx['age']) && $ctx['age'] !== null && $ctx['age'] !== '' ? (int)$ctx['age'] : null;
    $qty = isset($ctx['qty']) ? (float)$ctx['qty'] : null;
    $tol = (float)($ctx['tolerance_pct'] ?? mdc_default_tolerance_pct());
    $level_rule = mdc_alert_level($rule);
    $label = $meta['label'] ?? ($rule['calc_type'] ?? '');

    $need_bw = !empty($meta['need_bw']);
    if ($kind === 'none') {
        return ['status' => 'skip', 'message' => 'ไม่ใช้ตรวจ Monitor'];
    }
    if ($need_bw && $bw === null) {
        return [
            'status' => 'unverifiable',
            'level' => 'soft',
            'message' => 'ไม่มีน้ำหนัก — ไม่สามารถเทียบสูตร ' . $label,
            'expected_display' => $meta['hint'] ?? '',
            'found_display' => '—',
        ];
    }

    $found_mg = function_exists('mmgml_extract_dose_mg_for_ml')
        ? mmgml_extract_dose_mg_for_ml($method)
        : null;
    $rate = function_exists('mmgml_extract_rate_ml_hr') ? mmgml_extract_rate_ml_hr($method) : null;
    $mix = function_exists('mmgml_extract_mix_mg_per_ml') ? mmgml_extract_mix_mg_per_ml($method) : null;
    $conc = null;
    if (is_array($mix) && !empty($mix['mg_per_ml'])) {
        $conc = (float)$mix['mg_per_ml'];
    } elseif (!empty($rule['stock_mg_ml'])) {
        $conc = (float)$rule['stock_mg_ml'];
    } elseif (!empty($meta['stock_mg_ml'])) {
        $conc = (float)$meta['stock_mg_ml'];
    }

    if ($kind === 'weight_total_mg') {
        $expected = mdc_expected_total_mg($rule, $bw, $age, $method);
        $found = $found_mg;
        $expected_disp = $expected !== null ? mdc_fmt($expected, 1) . ' mg' : '—';
        $found_disp = $found !== null ? mdc_fmt($found, 1) . ' mg' : '—';
        if ($found === null && $qty !== null && $qty > 0 && !empty($meta['amp_mg'])) {
            $found = $qty * (float)$meta['amp_mg'];
            $found_disp = mdc_fmt($qty, 1) . ' × ' . mdc_fmt($meta['amp_mg'], 0) . ' mg';
        }
        if ($expected === null) {
            return [
                'status' => 'unverifiable',
                'message' => 'คำนวณขนาดที่ควรได้ไม่ได้',
                'expected_display' => $expected_disp,
                'found_display' => $found_disp,
            ];
        }
        if ($found === null) {
            return [
                'status' => 'unverifiable',
                'message' => 'อ่านขนาดยาจากวิธีใช้/จำนวนจ่ายไม่ได้ — ควรได้ ' . $expected_disp,
                'expected_display' => $expected_disp,
                'found_display' => $found_disp,
                'suggest_value_text' => $expected_disp,
            ];
        }
        $ok = mdc_within_tol($found, $expected, $tol);
        $dir = $found > $expected ? 'high' : ($found < $expected ? 'low' : null);
        if ($ok) {
            return [
                'status' => 'pass',
                'message' => 'ตรงสูตร ' . $label . ' (±' . mdc_fmt($tol, 1) . '%)',
                'expected_display' => $expected_disp,
                'found_display' => $found_disp,
                'dose_direction' => null,
            ];
        }
        $lvl = $level_rule;
        $ratio = $expected > 0 ? $found / $expected : 0;
        if ($ratio >= 1.5 || $ratio <= 0.5) {
            $lvl = 'hard';
        }
        return [
            'status' => 'alert',
            'level' => $lvl,
            'message' => 'ไม่ตรงสูตร ' . $label . ' (พบ ' . $found_disp . ' ควรได้ ' . $expected_disp . ')',
            'expected_display' => $expected_disp,
            'found_display' => $found_disp,
            'dose_direction' => $dir,
            'suggest_value_text' => $expected_disp,
        ];
    }

    if ($kind === 'weight_range_mg' || $kind === 'weight_range_mcg') {
        $unit = $kind === 'weight_range_mcg' ? 'mcg' : 'mg';
        $found = $kind === 'weight_range_mcg' ? mdc_extract_mcg($method) : $found_mg;
        if ($kind === 'weight_range_mcg' && $found === null && $found_mg !== null) {
            $found = $found_mg * 1000;
        }
        list($min_kg, $max_kg) = mdc_range_mg_kg($rule);
        if ($kind === 'weight_range_mcg') {
            $min_kg = isset($meta['min_mcg_kg']) ? (float)$meta['min_mcg_kg'] : $min_kg;
            $max_kg = isset($meta['max_mcg_kg']) ? (float)$meta['max_mcg_kg'] : $max_kg;
        }
        $lo = ($min_kg !== null && $bw) ? $min_kg * $bw : null;
        $hi = ($max_kg !== null && $bw) ? $max_kg * $bw : null;
        $expected_disp = ($lo !== null || $hi !== null)
            ? mdc_fmt($lo, 2) . '–' . mdc_fmt($hi, 2) . ' ' . $unit
            : '—';
        $found_disp = $found !== null ? mdc_fmt($found, 2) . ' ' . $unit : '—';
        if ($found === null) {
            return [
                'status' => 'unverifiable',
                'message' => 'อ่านขนาดจากวิธีใช้ไม่ได้ — ช่วงที่ควรได้ ' . $expected_disp,
                'expected_display' => $expected_disp,
                'found_display' => $found_disp,
                'suggest_value_text' => $expected_disp,
            ];
        }
        $pad = $tol / 100.0;
        $lo_t = $lo !== null ? $lo * (1 - $pad) : null;
        $hi_t = $hi !== null ? $hi * (1 + $pad) : null;
        $ok = true;
        $dir = null;
        if ($lo_t !== null && $found < $lo_t) {
            $ok = false;
            $dir = 'low';
        }
        if ($hi_t !== null && $found > $hi_t) {
            $ok = false;
            $dir = 'high';
        }
        if ($ok) {
            return [
                'status' => 'pass',
                'message' => 'อยู่ในช่วง ' . $label,
                'expected_display' => $expected_disp,
                'found_display' => $found_disp,
            ];
        }
        return [
            'status' => 'alert',
            'level' => $dir === 'high' ? $level_rule : 'soft',
            'message' => ($dir === 'high' ? 'สูงเกิน' : 'ต่ำกว่า') . 'ช่วง ' . $label . ' (' . $found_disp . ' / ' . $expected_disp . ')',
            'expected_display' => $expected_disp,
            'found_display' => $found_disp,
            'dose_direction' => $dir,
            'suggest_value_text' => $expected_disp,
        ];
    }

    if ($kind === 'mcg_kg_min' || $kind === 'midazolam') {
        $dose = mdc_extract_mcg_kg_min($method);
        $dose_hr = mdc_extract_mcg_kg_hr($method);
        if ($kind === 'midazolam' && $found_mg !== null && $bw > 0) {
            $mgkg = $found_mg / $bw;
            $bmin = (float)($meta['bolus_min_mg_kg'] ?? 0.05);
            $bmax = (float)($meta['bolus_max_mg_kg'] ?? 0.15);
            $pad = $tol / 100.0;
            $expected_disp = mdc_fmt($bmin * $bw, 2) . '–' . mdc_fmt($bmax * $bw, 2) . ' mg (bolus)';
            $found_disp = mdc_fmt($found_mg, 2) . ' mg';
            if ($mgkg >= $bmin * (1 - $pad) && $mgkg <= $bmax * (1 + $pad)) {
                return [
                    'status' => 'pass',
                    'message' => 'Bolus อยู่ในช่วง ' . $label,
                    'expected_display' => $expected_disp,
                    'found_display' => $found_disp,
                ];
            }
            if ($dose === null && $dose_hr === null) {
                $dir = $mgkg > $bmax ? 'high' : 'low';
                return [
                    'status' => 'alert',
                    'level' => $dir === 'high' ? $level_rule : 'soft',
                    'message' => 'Bolus นอกช่วง ' . $label . ' (' . $found_disp . ' / ' . $expected_disp . ')',
                    'expected_display' => $expected_disp,
                    'found_display' => $found_disp,
                    'dose_direction' => $dir,
                    'suggest_value_text' => $expected_disp,
                ];
            }
        }
        if ($dose === null && $dose_hr !== null) {
            $dose = $dose_hr / 60.0;
        }
        if ($dose === null) {
            $dose = mdc_dose_from_rate_conc($rate, $conc, $bw);
        }
        if ($kind === 'midazolam' && $dose_hr === null && $dose !== null) {
            $dose_hr = $dose * 60;
        }
        if ($kind === 'midazolam') {
            $max_hr = (float)($meta['max_mcg_kg_hr'] ?? 100);
            $warn_hr = (float)($meta['warn_mcg_kg_hr'] ?? 20);
            $val = $dose_hr !== null ? $dose_hr : ($dose !== null ? $dose * 60 : null);
            $expected_disp = '≤ ' . mdc_fmt($max_hr, 0) . ' mcg/kg/hr';
            $found_disp = $val !== null ? mdc_fmt($val, 2) . ' mcg/kg/hr' : '—';
            if ($val === null) {
                return [
                    'status' => 'unverifiable',
                    'message' => 'อ่านอัตรา infusion Midazolam จากวิธีใช้ไม่ได้',
                    'expected_display' => $expected_disp,
                    'found_display' => $found_disp,
                ];
            }
            if ($val > $max_hr) {
                return [
                    'status' => 'alert',
                    'level' => 'hard',
                    'message' => 'เกิน Recommended (> ' . mdc_fmt($max_hr, 0) . ' mcg/kg/hr)',
                    'expected_display' => $expected_disp,
                    'found_display' => $found_disp,
                    'dose_direction' => 'high',
                ];
            }
            if ($val > $warn_hr) {
                return [
                    'status' => 'alert',
                    'level' => 'soft',
                    'message' => 'อยู่ในช่วงสูงของ ' . $label,
                    'expected_display' => $expected_disp,
                    'found_display' => $found_disp,
                    'dose_direction' => 'high',
                ];
            }
            return [
                'status' => 'pass',
                'message' => 'Infusion ' . $label . ' อยู่ในช่วง',
                'expected_display' => $expected_disp,
                'found_display' => $found_disp,
            ];
        }
        $max = (float)($meta['max_mcg_kg_min'] ?? 0);
        $warn = (float)($meta['warn_mcg_kg_min'] ?? 0);
        $expected_disp = $max > 0 ? '≤ ' . mdc_fmt($max, 2) . ' mcg/kg/min' : $meta['hint'];
        $found_disp = $dose !== null ? mdc_fmt($dose, 3) . ' mcg/kg/min' : '—';
        if ($dose === null) {
            return [
                'status' => 'unverifiable',
                'message' => 'อ่าน mcg/kg/min หรือ rate จากวิธีใช้ไม่ได้ — ' . $label,
                'expected_display' => $expected_disp,
                'found_display' => $found_disp,
            ];
        }
        if ($max > 0 && $dose > $max) {
            return [
                'status' => 'alert',
                'level' => 'hard',
                'message' => 'เกิน Max ' . $label . ' (> ' . mdc_fmt($max, 2) . ' mcg/kg/min)',
                'expected_display' => $expected_disp,
                'found_display' => $found_disp,
                'dose_direction' => 'high',
            ];
        }
        if ($warn > 0 && $dose > $warn) {
            return [
                'status' => 'alert',
                'level' => 'soft',
                'message' => 'สูงกว่าขนาดแนะนำ ' . $label . ' (> ' . mdc_fmt($warn, 2) . ' mcg/kg/min)',
                'expected_display' => $expected_disp,
                'found_display' => $found_disp,
                'dose_direction' => 'high',
            ];
        }
        return [
            'status' => 'pass',
            'message' => $label . ' ' . $found_disp,
            'expected_display' => $expected_disp,
            'found_display' => $found_disp,
        ];
    }

    if ($kind === 'mcg_min') {
        $dose = mdc_extract_mcg_min($method);
        if ($dose === null && $rate !== null && $conc !== null) {
            $dose = $rate * $conc * 1000 / 60;
        }
        $max = (float)($meta['max_mcg_min'] ?? 400);
        $warn = (float)($meta['warn_mcg_min'] ?? 200);
        $expected_disp = '≤ ' . mdc_fmt($max, 0) . ' mcg/min';
        $found_disp = $dose !== null ? mdc_fmt($dose, 1) . ' mcg/min' : '—';
        if ($dose === null) {
            return [
                'status' => 'unverifiable',
                'message' => 'อ่าน mcg/min จากวิธีใช้ไม่ได้',
                'expected_display' => $expected_disp,
                'found_display' => $found_disp,
            ];
        }
        if ($dose > $max) {
            return [
                'status' => 'alert', 'level' => 'hard', 'dose_direction' => 'high',
                'message' => 'เกิน Max NTG (> ' . mdc_fmt($max, 0) . ' mcg/min)',
                'expected_display' => $expected_disp, 'found_display' => $found_disp,
            ];
        }
        if ($dose > $warn) {
            return [
                'status' => 'alert', 'level' => 'soft', 'dose_direction' => 'high',
                'message' => 'สูงกว่า Max ของ HF/edema (> ' . mdc_fmt($warn, 0) . ' mcg/min)',
                'expected_display' => $expected_disp, 'found_display' => $found_disp,
            ];
        }
        return [
            'status' => 'pass', 'message' => 'NTG ' . $found_disp,
            'expected_display' => $expected_disp, 'found_display' => $found_disp,
        ];
    }

    if ($kind === 'meq_hr') {
        $dose = mdc_extract_meq_hr($method);
        if ($dose === null && $rate !== null) {
            $kcl_conc = !empty($rule['stock_mg_ml']) ? (float)$rule['stock_mg_ml'] : 20;
            $dose = ($kcl_conc * $rate) / 1000;
        }
        $max = (float)($meta['max_meq_hr'] ?? 20);
        $warn = (float)($meta['warn_meq_hr'] ?? 10);
        $expected_disp = '≤ ' . mdc_fmt($max, 0) . ' mEq/hr';
        $found_disp = $dose !== null ? mdc_fmt($dose, 2) . ' mEq/hr' : '—';
        if ($dose === null) {
            return [
                'status' => 'unverifiable',
                'message' => 'อ่าน mEq/hr จากวิธีใช้ไม่ได้',
                'expected_display' => $expected_disp, 'found_display' => $found_disp,
            ];
        }
        if ($dose > $max) {
            return [
                'status' => 'alert', 'level' => 'hard', 'dose_direction' => 'high',
                'message' => 'KCL เกิน 20 mEq/hr — อันตราย',
                'expected_display' => $expected_disp, 'found_display' => $found_disp,
            ];
        }
        if ($dose >= $warn) {
            return [
                'status' => 'alert', 'level' => 'soft', 'dose_direction' => 'high',
                'message' => 'KCL 10–20 mEq/hr ต้อง Central line / closely monitor',
                'expected_display' => $expected_disp, 'found_display' => $found_disp,
            ];
        }
        return [
            'status' => 'pass', 'message' => 'KCL ' . $found_disp . ' — Peripheral ได้',
            'expected_display' => $expected_disp, 'found_display' => $found_disp,
        ];
    }

    if ($kind === 'ng_kg_min') {
        $dose = mdc_extract_ng_kg_min($method);
        $max = (float)($meta['max_ng_kg_min'] ?? 4);
        $warn = (float)($meta['warn_ng_kg_min'] ?? 2);
        $expected_disp = '≤ ' . mdc_fmt($max, 2) . ' ng/kg/min';
        $found_disp = $dose !== null ? mdc_fmt($dose, 3) . ' ng/kg/min' : '—';
        if ($dose === null) {
            return [
                'status' => 'unverifiable',
                'message' => 'อ่าน ng/kg/min จากวิธีใช้ไม่ได้',
                'expected_display' => $expected_disp, 'found_display' => $found_disp,
            ];
        }
        if ($dose > $max) {
            return [
                'status' => 'alert', 'level' => 'hard', 'dose_direction' => 'high',
                'message' => 'เกิน Max Iloprost',
                'expected_display' => $expected_disp, 'found_display' => $found_disp,
            ];
        }
        if ($dose > $warn) {
            return [
                'status' => 'alert', 'level' => 'soft', 'dose_direction' => 'high',
                'message' => 'ช่วงสูงของ Iloprost',
                'expected_display' => $expected_disp, 'found_display' => $found_disp,
            ];
        }
        return [
            'status' => 'pass', 'message' => 'Iloprost ' . $found_disp,
            'expected_display' => $expected_disp, 'found_display' => $found_disp,
        ];
    }

    return [
        'status' => 'unverifiable',
        'message' => 'ยังไม่รองรับการตรวจสูตรนี้',
        'expected_display' => $meta['hint'] ?? '',
        'found_display' => '—',
    ];
}

function mdc_sql_num($v) {
    if ($v === null || $v === '') {
        return 'NULL';
    }
    return (string)(float)$v;
}
