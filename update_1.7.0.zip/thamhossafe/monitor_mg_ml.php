<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('monitor_mg_ml_helper.php');
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
mysqli_set_charset($con, 'utf8');

mmgml_ensure_table($con);
sp_monitor_settings_changed($con, 'mg_ml');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_ml_exempt') {
    $saved = mmgml_save_ml_extract_opts($con, [
        'exempt_strength_paren' => !empty($_POST['exempt_strength_paren']),
        'units_text' => $_POST['ml_paren_units'] ?? '',
    ]);
    $_SESSION['mmgml_msg'] = !empty($saved['exempt_strength_paren'])
        ? 'บันทึกยกเว้นรูปแบบความแรงยาในวงเล็บแล้ว — นับ mL จากรูปแบบเช่น 50 MG (1 ml)'
        : 'ปิดการยกเว้นรูปแบบความแรงยาในวงเล็บแล้ว — จะอ่านปริมาตร mL ทุกแบบในวิธีใช้';
    header('Location: monitor_mg_ml.php');
    exit;
}

if ((isset($_GET['tab']) && $_GET['tab'] === 'settings') || (isset($_POST['action']) && in_array($_POST['action'], ['add_mmgml', 'edit_mmgml', 'delete_mmgml', 'scan_tmt', 'import_inject_catalog'], true))) {
    header('Location: mg_ml_calculator.php?tab=settings');
    exit;
}

$default_start = date('Y-m-d', strtotime('-3 days'));
$default_end = date('Y-m-d');

$ml_extract_opts = mmgml_get_ml_extract_opts($con);

$monitor_rules = [];
$q_rules = mysqli_query($con, "SELECT * FROM monitor_mg_ml_settings WHERE active = 1 ORDER BY drug_name ASC, id ASC");
if ($q_rules) {
    while ($r = mysqli_fetch_assoc($q_rules)) {
        $monitor_rules[] = $r;
    }
}

$flash_msg = $_SESSION['mmgml_msg'] ?? '';
$flash_err = $_SESSION['mmgml_error'] ?? '';
unset($_SESSION['mmgml_msg'], $_SESSION['mmgml_error']);
session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor mg. to mL. - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .section-hard .table thead { background-color: #dc3545 !important; color: #fff !important; }
        .section-soft .table thead { background-color: #fd7e14 !important; color: #fff !important; }
        .section-pass .table thead { background-color: #198754 !important; color: #fff !important; }
        .section-unverifiable .table thead { background-color: #6c757d !important; color: #fff !important; }
        .mmgml-range-btn.active { background-color: #0d6efd !important; border-color: #0d6efd !important; color: #fff !important; }
        .ml-mismatch { background: #fee2e2; border-left: 3px solid #dc3545; padding: 4px 8px; border-radius: 4px; font-weight: 600; }
        .ml-pass { background: #dcfce7; border-left: 3px solid #198754; padding: 4px 8px; border-radius: 4px; font-weight: 600; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-2 text-dark">
                <i class="fas fa-syringe me-2" style="color:#0d6efd;"></i>
                Monitor mg. to mL.
            </h4>
            <p class="text-muted small mb-3">
                ตรวจการแปลงขนาดยา <b>mg → mL</b> ในวิธีใช้ (OPD/IPD) จากรายการยาที่ตั้งใน
                <a href="mg_ml_calculator.php?tab=settings" class="fw-bold">คำนวณ mg → mL</a>
                — ตัวอย่าง <code>IV 70 MG (0.28 ml)</code> ที่ 250 mg/mL ต้องได้ 0.28 mL
                · รูปแบบความแรงยาในวงเล็บ เช่น <code>IV (4 mg:250 ml)</code> ตั้งค่ายกเว้นได้ด้านล่าง
            </p>

            <?php if ($flash_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo htmlspecialchars($flash_msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            <?php if ($flash_err): ?>
            <div class="alert alert-danger alert-dismissible fade show"><?php echo htmlspecialchars($flash_err); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <div class="bg-white border p-4 rounded shadow-sm">
                    <div class="filter-box p-3 mb-3">
                        <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-filter me-2"></i>ตัวกรองรายงาน</h6>
                        <div class="row g-2 align-items-end">
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">วันที่สั่งยา ตั้งแต่</label>
                                <input type="text" id="filter_start" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_start); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ถึงวันที่</label>
                                <input type="text" id="filter_end" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_end); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">HN (ไม่บังคับ)</label>
                                <input type="text" id="filter_hn" class="form-control form-control-sm bg-white" placeholder="ทุก HN" autocomplete="off">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-sm fw-bold text-white w-100 shadow-sm" style="background:#0d6efd;" id="btnFetchMMGML" onclick="fetchMMGMLData()">
                                    <i class="fas fa-sync-alt me-1"></i> ประมวลผล
                                </button>
                            </div>
                        </div>
                        <div class="row g-2 mt-2 align-items-center">
                            <div class="col-auto"><label class="form-label small fw-bold mb-0 text-secondary">ช่วงเร็ว:</label></div>
                            <div class="col">
                                <div class="btn-group btn-group-sm flex-wrap">
                                    <button type="button" class="btn btn-outline-secondary fw-bold mmgml-range-btn" data-days="1" onclick="setMMGMLDateRange(1)">วันนี้</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mmgml-range-btn active" data-days="3" onclick="setMMGMLDateRange(3)">3 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mmgml-range-btn" data-days="7" onclick="setMMGMLDateRange(7)">7 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold mmgml-range-btn" data-days="30" onclick="setMMGMLDateRange(30)">30 วัน</button>
                                </div>
                            </div>
                        </div>
                        <form method="post" class="border rounded bg-white p-2 mt-3">
                            <input type="hidden" name="action" value="save_ml_exempt">
                            <input type="hidden" name="exempt_strength_paren" value="0">
                            <div class="row g-2 align-items-end">
                                <div class="col-lg-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="exempt_strength_paren" id="exempt_strength_paren" value="1"
                                            <?php echo !empty($ml_extract_opts['exempt_strength_paren']) ? 'checked' : ''; ?>>
                                        <label class="form-check-label small fw-bold" for="exempt_strength_paren">
                                            ยกเว้นรูปแบบความแรงยาในวงเล็บ — ไม่นับเป็น alert
                                        </label>
                                    </div>
                                    <div class="form-text small mb-0">
                                        เช่น <code>IV (4 mg:250 ml)</code> คือความแรงยา ไม่ใช่ปริมาตรที่ระบุ
                                        — นับ mL จากรูปแบบ <code>50 MG (1 ml)</code> หรือ <code>(0.28 ml)</code>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <label class="form-label small fw-bold mb-1" for="ml_paren_units">หน่วยที่ตามด้วยวงเล็บ ( )</label>
                                    <input type="text" name="ml_paren_units" id="ml_paren_units" class="form-control form-control-sm bg-white"
                                        value="<?php echo htmlspecialchars($ml_extract_opts['units_text'] ?? 'mg, gm, g, mcg, ug'); ?>"
                                        placeholder="mg, gm, g, mcg, ug">
                                    <div class="form-text small mb-0">คั่นด้วยจุลภาค — เพิ่มหน่วยอื่นได้</div>
                                </div>
                                <div class="col-lg-2">
                                    <button type="submit" class="btn btn-sm btn-outline-primary fw-bold w-100">
                                        <i class="fas fa-save me-1"></i> บันทึกยกเว้น
                                    </button>
                                </div>
                            </div>
                        </form>
                        <div id="hnFocusBanner" class="alert alert-warning py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                        <div id="reportMeta" class="alert alert-info py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                    </div>

                    <div class="border rounded p-3 mb-3" id="mmgmlRuleFilterBox">
                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                            <label class="form-label fw-bold small mb-0">
                                <i class="fas fa-filter me-1 text-primary"></i> เลือกยาที่ต้องการรายงาน
                                <span class="text-muted fw-normal">(ดึงจากคำนวณ mg → mL)</span>
                            </label>
                            <div class="d-flex flex-wrap gap-2">
                                <a href="mg_ml_calculator.php?tab=settings" class="btn btn-sm btn-outline-primary fw-bold">
                                    <i class="fas fa-cogs me-1"></i> ตั้งค่ารายการยา
                                </a>
                                <div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-outline-primary fw-bold" onclick="mmgmlSelectAllRules(true)">เลือกทั้งหมด</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold" onclick="mmgmlSelectAllRules(false)">ยกเลิกทั้งหมด</button>
                                </div>
                            </div>
                        </div>
                        <div class="mb-2">
                            <input type="text" id="mmgmlRuleSearch" class="form-control form-control-sm" placeholder="ค้นหายาในรายการ...">
                            <div class="form-text small">ระบบตรวจทีละยาพร้อมกันหลายรายการ — ย่อช่วงวันที่ถ้ายังช้า</div>
                        </div>
                        <?php if (empty($monitor_rules)): ?>
                        <div class="small text-muted">ยังไม่มีรายการยาที่เปิดใช้งาน — ไปตั้งค่าที่
                            <a href="mg_ml_calculator.php?tab=settings" class="fw-bold">คำนวณ mg → mL → ตั้งค่ารายการยา</a>
                        </div>
                        <?php else: ?>
                        <div class="row g-2">
                            <?php foreach ($monitor_rules as $mr):
                                $lvl = mmgml_alert_level($mr);
                                $badge = $lvl === 'hard'
                                    ? '<span class="badge bg-danger ms-1">Hard</span>'
                                    : '<span class="badge bg-warning text-dark ms-1">Soft</span>';
                                $conc = (float)($mr['mg_per_ml'] ?? 0) > 0
                                    ? mmgml_format_mg($mr['mg_per_ml']) . ' mg/mL'
                                    : '';
                                $extra_badges = '';
                                if (!empty($mr['use_weight'])) {
                                    $extra_badges .= '<span class="badge bg-info text-dark ms-1">BW</span>';
                                }
                                if (!empty($mr['check_qty'])) {
                                    $extra_badges .= '<span class="badge bg-secondary ms-1">Amp</span>';
                                }
                                if (!empty($mr['check_rate'])) {
                                    $extra_badges .= '<span class="badge bg-dark ms-1">Rate</span>';
                                }
                            ?>
                            <div class="col-md-6 col-xl-4 mmgml-rule-item">
                                <div class="form-check border rounded px-2 py-1 bg-white h-100">
                                    <input class="form-check-input mmgml-rule-cb" type="checkbox" value="<?php echo (int)$mr['id']; ?>"
                                           id="mmgml_rule_cb_<?php echo (int)$mr['id']; ?>" checked>
                                    <label class="form-check-label small" for="mmgml_rule_cb_<?php echo (int)$mr['id']; ?>">
                                        <span class="fw-bold text-dark"><?php echo htmlspecialchars($mr['drug_name']); ?></span>
                                        <small class="text-muted">(<?php echo htmlspecialchars($mr['icode']); ?>)</small>
                                        <?php if ($conc): ?><br><small class="text-primary"><?php echo htmlspecialchars($conc); ?></small><?php endif; ?>
                                        <?php echo $badge . $extra_badges; ?>
                                    </label>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="section-hard mb-4">
                        <h6 class="fw-bold text-danger mb-2"><i class="fas fa-exclamation-circle me-2"></i>Hard Alert <span id="hardCount" class="badge bg-danger">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small">
                                    <tr>
                                        <th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th>
                                        <th>วันที่สั่ง</th><th class="text-start">ยา</th>
                                        <th class="text-start">วิธีใช้</th>
                                        <th>mg</th><th>mL (ระบุ)</th><th>mL (คำนวณ)</th><th>mg/mL</th>
                                        <th>qty</th>
                                        <th>หอผู้ป่วย</th><th class="text-start">ข้อความแจ้งเตือน</th>
                                    </tr>
                                </thead>
                                <tbody id="hardTbody"><tr><td colspan="13" class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</td></tr></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="section-soft mb-2">
                        <h6 class="fw-bold text-warning mb-2"><i class="fas fa-exclamation-triangle me-2"></i>Soft Alert <span id="softCount" class="badge bg-warning text-dark">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small">
                                    <tr>
                                        <th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th>
                                        <th>วันที่สั่ง</th><th class="text-start">ยา</th>
                                        <th class="text-start">วิธีใช้</th>
                                        <th>mg</th><th>mL (ระบุ)</th><th>mL (คำนวณ)</th><th>mg/mL</th>
                                        <th>qty</th>
                                        <th>หอผู้ป่วย</th><th class="text-start">ข้อความแจ้งเตือน</th>
                                    </tr>
                                </thead>
                                <tbody id="softTbody"><tr><td colspan="13" class="text-center py-4 text-muted">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="section-unverifiable mb-4">
                        <h6 class="fw-bold text-secondary mb-2"><i class="fas fa-question-circle me-2"></i>ตรวจสอบไม่ได้ <span id="unverifiableCount" class="badge bg-secondary">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small">
                                    <tr>
                                        <th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th>
                                        <th>วันที่สั่ง</th><th class="text-start">ยา</th>
                                        <th class="text-start">วิธีใช้</th>
                                        <th>mg</th><th>mL (ระบุ)</th><th>mL (คำนวณ)</th><th>mg/mL</th>
                                        <th>qty</th>
                                        <th>หอผู้ป่วย</th><th class="text-start">หมายเหตุ</th>
                                    </tr>
                                </thead>
                                <tbody id="unverifiableTbody"><tr><td colspan="13" class="text-center py-4 text-muted">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="section-pass mt-4">
                        <h6 class="fw-bold text-success mb-2"><i class="fas fa-check-circle me-2"></i>รายการผ่าน <span id="passCount" class="badge bg-success">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small">
                                    <tr>
                                        <th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th>
                                        <th>วันที่สั่ง</th><th class="text-start">ยา</th>
                                        <th class="text-start">วิธีใช้</th>
                                        <th>mg</th><th>mL (ระบุ)</th><th>mL (คำนวณ)</th><th>ผลต่าง</th><th>mg/mL</th>
                                        <th>qty</th>
                                        <th>สถานะ</th>
                                    </tr>
                                </thead>
                                <tbody id="passTbody"><tr><td colspan="13" class="text-center py-4 text-muted">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/monitor_hn_filter.js"></script>
<script src="js/flatpickr.min.js"></script>
<script>
let fpStart, fpEnd;

function mmgmlEsc(s) {
    if (s == null) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

$(function() {
    if (typeof flatpickr !== 'undefined') {
        fpStart = flatpickr('#filter_start', { dateFormat: 'Y-m-d' });
        fpEnd = flatpickr('#filter_end', { dateFormat: 'Y-m-d' });
    }
    monitorInitHnFilter({
        clearHref: 'monitor_mg_ml.php',
        fetchFn: fetchMMGMLData,
        autofetch: fetchMMGMLData
    });
});

function getSelectedMmgmlRuleIds() {
    const ids = [];
    $('.mmgml-rule-cb:checked').each(function() { ids.push($(this).val()); });
    return ids;
}

function mmgmlSelectAllRules(on) {
    $('.mmgml-rule-cb').prop('checked', !!on);
}

$(document).on('input', '#mmgmlRuleSearch', function() {
    const q = (($(this).val() || '') + '').toLowerCase();
    $('.mmgml-rule-item').each(function() {
        const t = (($(this).text() || '') + '').toLowerCase();
        $(this).toggle(!q || t.indexOf(q) !== -1);
    });
});

function mmgmlFriendlyFetchError(text, status) {
    const raw = String(text || '');
    if (status === 504 || /504|Gateway Time-out/i.test(raw)) {
        return 'ประมวลผลนานเกินกำหนด (504) — ลองย่อช่วงวันที่ หรือเลือกยาน้อยลง แล้วกดประมวลผลอีกครั้ง';
    }
    if (status === 502 || /Bad Gateway/i.test(raw)) {
        return 'เซิร์ฟเวอร์ไม่ตอบ (502) — ลองใหม่ในอีกสักครู่';
    }
    const stripped = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    return (stripped || ('HTTP ' + status)).substring(0, 240);
}

function setMMGMLDateRange(days) {
    const end = new Date();
    const start = new Date();
    if (days <= 1) {
        start.setHours(0,0,0,0);
    } else {
        start.setDate(end.getDate() - (days - 1));
    }
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    if (fpStart) fpStart.setDate(fmt(start), true); else $('#filter_start').val(fmt(start));
    if (fpEnd) fpEnd.setDate(fmt(end), true); else $('#filter_end').val(fmt(end));
    $('.mmgml-range-btn').removeClass('active');
    $('.mmgml-range-btn[data-days="' + days + '"]').addClass('active');
}

function renderMMGMLRow(item) {
    const when = item.order_time
        ? item.order_date + ' <span class="text-dark">' + mmgmlEsc(item.order_time) + '</span>'
        : mmgmlEsc(item.order_date);
    const calcHtml = '<div class="ml-mismatch small">' + mmgmlEsc(item.expected_ml_display || '') + '</div>';
    let detail = '';
    if (item.detail_text) {
        detail = '<div class="text-muted small mt-1">' + mmgmlEsc(item.detail_text) + '</div>';
    }
    let extra = '';
    if (item.weight_kg) {
        extra += '<div class="text-muted small">BW ' + mmgmlEsc(String(item.weight_kg)) + ' kg';
        if (item.weight_source === 'calculator') {
            extra += ' <span class="text-success" title="จากระบบช่วยคำนวณ">(เครื่องคำนวณ)</span>';
        } else if (item.weight_stale && item.weight_vstdate) {
            extra += ' <span title="ใช้น้ำหนักล่าสุด อนุโลม×2">(' + mmgmlEsc(item.weight_vstdate) + ')</span>';
        }
        extra += '</div>';
    }
    if (item.fixed_dose_exempt) {
        extra += '<div class="text-success small">ขนาดคงที่</div>';
    }
    if (item.rate_display) {
        extra += '<div class="text-muted small">Rate ' + mmgmlEsc(item.rate_display) + '</div>';
    }
    const qtyCell = item.qty_display
        ? mmgmlEsc(item.qty_display)
        : (item.qty !== undefined && item.qty !== null && item.qty !== '' ? mmgmlEsc(String(item.qty)) : '—');
    return '<tr>'
        + '<td class="text-center fw-bold">' + mmgmlEsc(item.hn) + '</td>'
        + '<td class="text-center"><span class="badge ' + (item.type_patient === 'IPD' ? 'bg-secondary' : 'bg-info text-dark') + '">' + mmgmlEsc(item.type_patient) + '</span></td>'
        + '<td>' + mmgmlEsc(item.ptname) + '</td>'
        + '<td class="text-center small">' + when + '</td>'
        + '<td class="text-start"><b>' + mmgmlEsc(item.drug_name) + '</b><br><small class="text-muted">icode: ' + mmgmlEsc(item.icode) + '</small>' + extra + '</td>'
        + '<td class="text-start small">' + mmgmlEsc(item.method || '-') + '</td>'
        + '<td class="text-center small fw-bold">' + mmgmlEsc(item.dose_mg_display || '—') + '</td>'
        + '<td class="text-center small text-danger fw-bold">' + mmgmlEsc(item.stated_ml_display || '—') + '</td>'
        + '<td class="text-center small">' + calcHtml + '</td>'
        + '<td class="text-center small">' + mmgmlEsc(item.mg_per_ml_display || '—') + '</td>'
        + '<td class="text-center small fw-bold">' + qtyCell + '</td>'
        + '<td class="text-center small">' + mmgmlEsc(item.ward_display || '-') + '</td>'
        + '<td class="text-start small text-danger fw-bold">' + mmgmlEsc(item.alert_message) + detail
        + (window.MonIv ? MonIv.btn(item, item.alert_message || '') : '')
        + '</td>'
        + '</tr>';
}

function renderMMGMLUnverifiableRow(item) {
    const when = item.order_time
        ? item.order_date + ' <span class="text-dark">' + mmgmlEsc(item.order_time) + '</span>'
        : mmgmlEsc(item.order_date);
    const qtyCell = item.qty_display
        ? mmgmlEsc(item.qty_display)
        : (item.qty !== undefined && item.qty !== null && item.qty !== '' ? mmgmlEsc(String(item.qty)) : '—');
    return '<tr>'
        + '<td class="text-center fw-bold">' + mmgmlEsc(item.hn) + '</td>'
        + '<td class="text-center"><span class="badge ' + (item.type_patient === 'IPD' ? 'bg-secondary' : 'bg-info text-dark') + '">' + mmgmlEsc(item.type_patient) + '</span></td>'
        + '<td>' + mmgmlEsc(item.ptname) + '</td>'
        + '<td class="text-center small">' + when + '</td>'
        + '<td class="text-start"><b>' + mmgmlEsc(item.drug_name) + '</b><br><small class="text-muted">icode: ' + mmgmlEsc(item.icode) + '</small></td>'
        + '<td class="text-start small">' + mmgmlEsc(item.method || '-') + '</td>'
        + '<td class="text-center small">' + mmgmlEsc(item.dose_mg_display || '—') + '</td>'
        + '<td class="text-center small">' + mmgmlEsc(item.stated_ml_display || '—') + '</td>'
        + '<td class="text-center small">—</td>'
        + '<td class="text-center small">' + mmgmlEsc(item.mg_per_ml_display || '—') + '</td>'
        + '<td class="text-center small fw-bold">' + qtyCell + '</td>'
        + '<td class="text-center small">' + mmgmlEsc(item.ward_display || '-') + '</td>'
        + '<td class="text-start small text-secondary fw-bold">' + mmgmlEsc(item.alert_message || 'ตรวจสอบไม่ได้')
        + (window.MonIv ? MonIv.btn(item, item.alert_message || 'ตรวจสอบไม่ได้') : '')
        + '</td>'
        + '</tr>';
}

function renderMMGMLPassRow(item) {
    const when = item.order_time
        ? item.order_date + ' <span class="text-dark">' + mmgmlEsc(item.order_time) + '</span>'
        : mmgmlEsc(item.order_date);
    const calcHtml = '<div class="ml-pass small">' + mmgmlEsc(item.expected_ml_display || '') + '</div>';
    let extra = '';
    if (item.weight_kg) {
        extra += '<div class="text-muted small">BW ' + mmgmlEsc(String(item.weight_kg)) + ' kg';
        if (item.weight_source === 'calculator') {
            extra += ' <span class="text-success" title="จากระบบช่วยคำนวณ">(เครื่องคำนวณ)</span>';
        } else if (item.weight_stale && item.weight_vstdate) {
            extra += ' <span title="ใช้น้ำหนักล่าสุด อนุโลม×2">(' + mmgmlEsc(item.weight_vstdate) + ')</span>';
        }
        extra += '</div>';
    }
    if (item.fixed_dose_exempt) {
        extra += '<div class="text-success small">ขนาดคงที่</div>';
    }
    const qtyCell = item.qty_display
        ? mmgmlEsc(item.qty_display)
        : (item.qty !== undefined && item.qty !== null && item.qty !== '' ? mmgmlEsc(String(item.qty)) : '—');
    return '<tr>'
        + '<td class="text-center fw-bold">' + mmgmlEsc(item.hn) + '</td>'
        + '<td class="text-center"><span class="badge ' + (item.type_patient === 'IPD' ? 'bg-secondary' : 'bg-info text-dark') + '">' + mmgmlEsc(item.type_patient) + '</span></td>'
        + '<td>' + mmgmlEsc(item.ptname) + '</td>'
        + '<td class="text-center small">' + when + '</td>'
        + '<td class="text-start"><b>' + mmgmlEsc(item.drug_name) + '</b><br><small class="text-muted">icode: ' + mmgmlEsc(item.icode) + '</small>' + extra + '</td>'
        + '<td class="text-start small">' + mmgmlEsc(item.method || '-') + '</td>'
        + '<td class="text-center small fw-bold">' + mmgmlEsc(item.dose_mg_display || '—') + '</td>'
        + '<td class="text-center small">' + mmgmlEsc(item.stated_ml_display || '—') + '</td>'
        + '<td class="text-center small">' + calcHtml + '</td>'
        + '<td class="text-center small">' + mmgmlEsc(item.diff_ml_display || '—') + '</td>'
        + '<td class="text-center small">' + mmgmlEsc(item.mg_per_ml_display || '—') + '</td>'
        + '<td class="text-center small fw-bold">' + qtyCell + '</td>'
        + '<td class="text-start small text-success fw-bold">' + mmgmlEsc(item.pass_message || 'ผ่านเกณฑ์') + '</td>'
        + '</tr>';
}

let mmgmlFetchGen = 0;
let mmgmlAbortCtl = null;
const MMGML_PARALLEL = 5;

function mmgmlItemSortKey(item) {
    return String(item.rxdate || '') + ' ' + String(item.order_time || '') + ' ' + String(item.hn || '');
}

function mmgmlSortItems(list) {
    return list.slice().sort(function (a, b) {
        return mmgmlItemSortKey(b).localeCompare(mmgmlItemSortKey(a));
    });
}

function mmgmlPaintTables(agg, isFinal) {
    const hard = mmgmlSortItems(agg.hard);
    const soft = mmgmlSortItems(agg.soft);
    const unverifiable = mmgmlSortItems(agg.unverifiable);
    const passed = mmgmlSortItems(agg.passed);
    $('#hardCount').text(hard.length);
    $('#softCount').text(soft.length);
    $('#unverifiableCount').text(unverifiable.length);
    $('#passCount').text(passed.length);

    if (hard.length === 0) {
        $('#hardTbody').html(isFinal
            ? '<tr><td colspan="13" class="text-center py-4 text-success fw-bold"><i class="fas fa-check-circle me-2"></i>ไม่พบ Hard Alert</td></tr>'
            : '<tr><td colspan="13" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังตรวจ...</td></tr>');
    } else {
        $('#hardTbody').html(hard.map(renderMMGMLRow).join(''));
    }
    if (soft.length === 0) {
        $('#softTbody').html(isFinal
            ? '<tr><td colspan="13" class="text-center py-4 text-muted">ไม่พบ Soft Alert</td></tr>'
            : '<tr><td colspan="13" class="text-center py-4 text-muted">กำลังตรวจ...</td></tr>');
    } else {
        $('#softTbody').html(soft.map(renderMMGMLRow).join(''));
    }
    if (unverifiable.length === 0) {
        $('#unverifiableTbody').html(isFinal
            ? '<tr><td colspan="13" class="text-center py-4 text-muted">—</td></tr>'
            : '<tr><td colspan="13" class="text-center py-4 text-muted">กำลังตรวจ...</td></tr>');
    } else {
        $('#unverifiableTbody').html(unverifiable.map(renderMMGMLUnverifiableRow).join(''));
    }
    if (passed.length === 0) {
        $('#passTbody').html(isFinal
            ? '<tr><td colspan="13" class="text-center py-4 text-muted">ยังไม่พบรายการที่ผ่านเงื่อนไข</td></tr>'
            : '<tr><td colspan="13" class="text-center py-4 text-muted">กำลังตรวจ...</td></tr>');
    } else {
        $('#passTbody').html(passed.map(renderMMGMLPassRow).join(''));
    }
}

async function mmgmlPostRules(ruleIds, signal) {
    const r = await fetch('fetch_monitor_mg_ml_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        signal: signal,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams(monitorAppendHn({
            start_date: $('#filter_start').val() || '',
            end_date: $('#filter_end').val() || '',
            rule_ids: ruleIds.join(',')
        }))
    });
    const text = await r.text();
    try {
        return JSON.parse(text);
    } catch (e) {
        throw new Error(mmgmlFriendlyFetchError(text, r.status));
    }
}

async function fetchMMGMLData() {
    const selected = [];
    $('.mmgml-rule-cb:checked').each(function () {
        selected.push({
            id: $(this).val(),
            name: (($(this).closest('.form-check').find('label .fw-bold').first().text() || '') + '').trim()
        });
    });
    if (selected.length === 0) {
        alert('กรุณาเลือกอย่างน้อย 1 กฎ');
        return;
    }

    const gen = ++mmgmlFetchGen;
    if (mmgmlAbortCtl) {
        try { mmgmlAbortCtl.abort(); } catch (e) {}
    }
    const ac = new AbortController();
    mmgmlAbortCtl = ac;

    const t0 = Date.now();
    const agg = { hard: [], soft: [], passed: [], unverifiable: [], orders_scanned: 0, orders_checked: 0, truncated: false };
    const failed = [];
    let done = 0;
    let lastPaint = 0;
    const workers = Math.min(MMGML_PARALLEL, selected.length);

    $('#btnFetchMMGML').prop('disabled', true);
    $('#hardTbody').html('<tr><td colspan="13" class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin me-2"></i>กำลังตรวจทีละยา (พร้อมกัน ' + workers + ' รายการ)...</td></tr>');
    $('#softTbody').html('<tr><td colspan="13" class="text-center py-4 text-muted">—</td></tr>');
    $('#unverifiableTbody').html('<tr><td colspan="13" class="text-center py-4 text-muted">—</td></tr>');
    $('#passTbody').html('<tr><td colspan="13" class="text-center py-4 text-muted">—</td></tr>');
    $('#hardCount').text(0);
    $('#softCount').text(0);
    $('#unverifiableCount').text(0);
    $('#passCount').text(0);
    $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info')
        .html('<i class="fas fa-spinner fa-spin me-1"></i> เริ่มตรวจ 0/' + selected.length + ' ยา (พร้อมกัน ' + workers + ' รายการ)');

    function updateMeta(currentName, isFinal) {
        if (gen !== mmgmlFetchGen) return;
        const sec = ((Date.now() - t0) / 1000).toFixed(1);
        let html = '<i class="fas fa-info-circle me-1"></i> ตรวจแล้ว ' + done + '/' + selected.length + ' ยา'
            + ' | พร้อมกัน ' + workers + ' รายการ'
            + ' | Hard: ' + agg.hard.length
            + ' | Soft: ' + agg.soft.length
            + ' | ตรวจสอบไม่ได้: ' + agg.unverifiable.length
            + ' | ผ่าน: ' + agg.passed.length
            + ' | สแกน: ' + agg.orders_scanned
            + ' | ' + sec + ' วินาที';
        if (!isFinal && currentName) html += ' | ล่าสุด: ' + mmgmlEsc(currentName);
        if (agg.truncated) html += ' | <span class="text-danger">บางยามีใบยาถึงขีดจำกัด</span>';
        if (failed.length) html += ' | <span class="text-danger">ไม่สำเร็จ ' + failed.length + ' ยา</span>';
        if (isFinal && failed.length) {
            html += '<div class="small fw-normal mt-1">' + failed.map(function (f) { return mmgmlEsc(f); }).join('<br>') + '</div>';
        }
        $('#reportMeta').toggleClass('alert-danger', failed.length > 0 && isFinal)
            .toggleClass('alert-info', !(failed.length > 0 && isFinal))
            .html(html);
    }

    async function runOne(rule) {
        const data = await mmgmlPostRules([rule.id], ac.signal);
        if (data.status !== 'success') {
            throw new Error(data.message || 'เกิดข้อผิดพลาด');
        }
        const m = data.meta || {};
        agg.hard.push.apply(agg.hard, data.hard_alerts || []);
        agg.soft.push.apply(agg.soft, data.soft_alerts || []);
        agg.passed.push.apply(agg.passed, data.passed_items || []);
        agg.unverifiable.push.apply(agg.unverifiable, data.unverifiable_items || []);
        agg.orders_scanned += m.orders_scanned || 0;
        agg.orders_checked += m.orders_checked || 0;
        if (m.truncated) agg.truncated = true;
    }

    let next = 0;
    async function worker() {
        while (next < selected.length) {
            if (gen !== mmgmlFetchGen) return;
            const rule = selected[next++];
            try {
                await runOne(rule);
            } catch (err) {
                if (err && err.name === 'AbortError') throw err;
                failed.push((rule.name || rule.id) + ' — ' + (err && err.message ? err.message : 'เชื่อมต่อไม่สำเร็จ'));
            }
            done++;
            updateMeta(rule.name, false);
            if (done - lastPaint >= 5 || done === selected.length) {
                lastPaint = done;
                mmgmlPaintTables(agg, false);
            }
        }
    }

    try {
        await Promise.all(Array.from({ length: workers }, worker));
    } catch (err) {
        if (err && err.name === 'AbortError') return;
        if (gen !== mmgmlFetchGen) return;
        $('#btnFetchMMGML').prop('disabled', false);
        $('#hardTbody').html('<tr><td colspan="13" class="text-center text-danger py-4">' + mmgmlEsc(err.message || 'เชื่อมต่อ API ไม่สำเร็จ') + '</td></tr>');
        return;
    }

    if (gen !== mmgmlFetchGen) return;
    $('#btnFetchMMGML').prop('disabled', false);
    mmgmlPaintTables(agg, true);
    updateMeta('', true);
}
</script>
<?php
$mon_iv_module = 'mg_ml';
$mon_iv_title = 'mg to mL';
include __DIR__ . '/monitor_intervention_ui.php';
?>
</body>
</html>
