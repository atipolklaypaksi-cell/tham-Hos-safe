<?php
/**
 * สต็อก INVC (อ่านอย่างเดียวจาก INV_STOCK)
 * คงเหลือ = INV_MD.QTY_ON_HAND
 * ประวัติเบิกจ่าย = CARD ที่ R_S_STATUS = S (จ่ายออกจากคลัง)
 */

function invc_stock_months() {
    return 6;
}

function invc_stock_min_cover() {
    return 1;
}

function invc_stock_max_cover() {
    return 4;
}

function invc_stock_sql_str($value) {
    return "N'" . str_replace("'", "''", (string)$value) . "'";
}

function invc_stock_num($value) {
    if ($value === null || $value === '') {
        return 0.0;
    }
    return (float)$value;
}

function invc_stock_flag($qty, $min, $max) {
    $qty = invc_stock_num($qty);
    $min = invc_stock_num($min);
    $max = invc_stock_num($max);
    if ($min > 0 && $qty < $min) {
        return 'low';
    }
    if ($max > 0 && $qty > $max) {
        return 'high';
    }
    return 'ok';
}

function invc_stock_suggest($issued_qty, $months = null) {
    $months = $months === null ? invc_stock_months() : max(1, (int)$months);
    $issued = invc_stock_num($issued_qty);
    $monthly = $issued / $months;
    $suggest_min = $monthly > 0 ? (int)ceil($monthly * invc_stock_min_cover()) : 0;
    $suggest_max = $monthly > 0 ? (int)ceil($monthly * invc_stock_max_cover()) : 0;
    if ($suggest_max > 0 && $suggest_max < $suggest_min) {
        $suggest_max = $suggest_min;
    }
    return [
        'issued_qty' => round($issued, 2),
        'monthly_avg' => round($monthly, 2),
        'suggest_min' => $suggest_min,
        'suggest_max' => $suggest_max,
    ];
}

function invc_stock_usage_map(PDO $pdo) {
    $months = invc_stock_months();
    $sql = "SELECT WORKING_CODE AS code,
                   SUM(CAST(ACTIVE_QTY1 AS decimal(18,4))) AS qty
            FROM [CARD]
            WHERE R_S_STATUS = 'S'
              AND (CANCEL_FLAG IS NULL OR CANCEL_FLAG <> 'Y')
              AND OPERATE_DATE >= DATEADD(month, -" . (int)$months . ", CAST(GETDATE() AS date))
            GROUP BY WORKING_CODE";
    $st = invc_query($pdo, $sql);
    if (!$st) {
        return null;
    }
    $map = [];
    while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
        $code = trim((string)($row['code'] ?? ''));
        if ($code === '') {
            continue;
        }
        $map[$code] = invc_stock_num($row['qty'] ?? 0);
    }
    $st->closeCursor();
    return $map;
}

/** วันที่จ่ายล่าสุดต่อรหัสยา (สถานะ S) */
function invc_stock_last_dispense_map(PDO $pdo) {
    $sql = "SELECT WORKING_CODE AS code,
                   MAX(OPERATE_DATE) AS last_dt
            FROM [CARD]
            WHERE R_S_STATUS = 'S'
              AND (CANCEL_FLAG IS NULL OR CANCEL_FLAG <> 'Y')
            GROUP BY WORKING_CODE";
    $st = invc_query($pdo, $sql);
    if (!$st) {
        return null;
    }
    $map = [];
    while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
        $code = trim((string)($row['code'] ?? ''));
        if ($code === '') {
            continue;
        }
        $dt = invc_stock_date($row['last_dt'] ?? '');
        if ($dt !== '') {
            $map[$code] = $dt;
        }
    }
    $st->closeCursor();
    return $map;
}

function invc_stock_apply_pending(array $row, array $pending_map) {
    $code = $row['code'] ?? '';
    $info = $pending_map[$code] ?? null;
    $row['pending_recv'] = false;
    $row['pending_pack'] = 0;
    $row['pending_order'] = 0;
    $row['pending_recv_date'] = '';
    $row['pending_lines'] = 0;
    $row['last_dispense'] = '';
    if ($info && !empty($info['pending']) && invc_stock_num($row['qty'] ?? 0) <= 0) {
        $row['pending_recv'] = true;
        $row['pending_pack'] = round(invc_stock_num($info['pack'] ?? 0), 2);
        $row['pending_order'] = round(invc_stock_num($info['order_qty'] ?? 0), 2);
        $row['pending_recv_date'] = (string)($info['recv_date'] ?? '');
        $row['pending_lines'] = (int)($info['order_lines'] ?? 0);
        $row['last_dispense'] = (string)($info['last_dispense'] ?? '');
    }
    return $row;
}

function invc_stock_date($value) {
    if ($value instanceof DateTimeInterface) {
        return $value->format('Y-m-d');
    }
    $text = trim((string)$value);
    if ($text === '') {
        return '';
    }
    if (preg_match('/^(\d{4}-\d{2}-\d{2})/', $text, $m)) {
        return $m[1];
    }
    $ts = strtotime($text);
    return $ts ? date('Y-m-d', $ts) : '';
}

function invc_stock_lots_map(PDO $pdo) {
    $sql = "SELECT WORKING_CODE, LOTNO, QTY_ON_HAND, EXPIRED_DATE, LOCATION
            FROM [INV_MD_C]
            WHERE QTY_ON_HAND > 0";
    $st = invc_query($pdo, $sql);
    if (!$st) {
        return null;
    }
    $map = [];
    while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
        $code = trim((string)($row['WORKING_CODE'] ?? ''));
        if ($code === '') {
            continue;
        }
        $map[$code][] = $row;
    }
    $st->closeCursor();
    return $map;
}

function invc_stock_lots_for_code(PDO $pdo, $code) {
    $code_sql = invc_stock_sql_str($code);
    $st = invc_query($pdo, "SELECT WORKING_CODE, LOTNO, QTY_ON_HAND, EXPIRED_DATE, LOCATION
                            FROM [INV_MD_C]
                            WHERE WORKING_CODE = $code_sql AND QTY_ON_HAND > 0");
    if (!$st) {
        return null;
    }
    $rows = [];
    while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
        $rows[] = $row;
    }
    $st->closeCursor();
    return $rows;
}

/**
 * ไล่ใช้ล็อตที่หมดอายุก่อน
 * - soon/expired: หมดอายุภายใน 6 เดือน หรือหมดแล้ว
 * - risk: อัตราใช้ต่อเดือนไม่พอให้หมดล็อตนี้ก่อนถึงวัน EXP
 */
function invc_stock_analyze_lots(array $raw_lots, $monthly) {
    $monthly = invc_stock_num($monthly);
    $today = new DateTimeImmutable('today');
    $soon_until = $today->modify('+6 months');
    $lots = [];
    foreach ($raw_lots as $raw) {
        $qty = invc_stock_num($raw['QTY_ON_HAND'] ?? 0);
        if ($qty <= 0) {
            continue;
        }
        $lots[] = [
            'lot_no' => trim((string)($raw['LOTNO'] ?? '')),
            'qty' => round($qty, 2),
            'exp' => invc_stock_date($raw['EXPIRED_DATE'] ?? ''),
            'location' => trim((string)($raw['LOCATION'] ?? '')),
            '_qty' => $qty,
        ];
    }
    usort($lots, function ($a, $b) {
        if ($a['exp'] === $b['exp']) {
            return strcmp($a['lot_no'], $b['lot_no']);
        }
        if ($a['exp'] === '') {
            return 1;
        }
        if ($b['exp'] === '') {
            return -1;
        }
        return strcmp($a['exp'], $b['exp']);
    });

    $before = 0.0;
    $exp_flag = 'none';
    $use_risk = false;
    $rank = ['none' => 0, 'ok' => 1, 'soon' => 2, 'expired' => 3];
    foreach ($lots as &$lot) {
        $qty = $lot['_qty'];
        unset($lot['_qty']);
        $lot['days_left'] = null;
        $lot['level'] = 'none';
        $lot['risk'] = false;
        $lot['short_qty'] = 0;
        if ($lot['exp'] === '') {
            $before += $qty;
            continue;
        }
        $exp = DateTimeImmutable::createFromFormat('!Y-m-d', $lot['exp']);
        if (!$exp) {
            $before += $qty;
            continue;
        }
        $days = (int)$today->diff($exp)->format('%r%a');
        $lot['days_left'] = $days;
        if ($days < 0) {
            $level = 'expired';
        } elseif ($exp <= $soon_until) {
            $level = 'soon';
        } else {
            $level = 'ok';
        }
        $lot['level'] = $level;
        if ($rank[$level] > $rank[$exp_flag]) {
            $exp_flag = $level;
        }
        if ($monthly > 0) {
            $months_left = $days > 0 ? ($days / 30.0) : 0;
            $can_use = $monthly * $months_left;
            $usable = max(0, $can_use - $before);
            $short = $qty - $usable;
            if ($short > 0.01) {
                $lot['risk'] = true;
                $lot['short_qty'] = round($short, 2);
                $use_risk = true;
            }
        }
        $before += $qty;
    }
    unset($lot);
    if ($exp_flag === 'none' && !empty($lots)) {
        $exp_flag = 'ok';
    }
    return [
        'lots' => $lots,
        'exp_flag' => $exp_flag,
        'use_risk' => $use_risk,
    ];
}

function invc_stock_alert_rank(array $row) {
    if (($row['exp_flag'] ?? '') === 'expired') {
        return 0;
    }
    if (($row['exp_flag'] ?? '') === 'soon') {
        return 1;
    }
    if (!empty($row['use_risk'])) {
        return 2;
    }
    if (!empty($row['pending_recv'])) {
        return 3;
    }
    if (($row['flag'] ?? '') === 'low') {
        return 4;
    }
    if (($row['flag'] ?? '') === 'high') {
        return 5;
    }
    return 6;
}

function invc_stock_apply_lots(array $row, array $raw_lots) {
    $analyzed = invc_stock_analyze_lots($raw_lots, $row['monthly_rate'] ?? 0);
    $row['lots'] = $analyzed['lots'];
    $row['exp_flag'] = $analyzed['exp_flag'];
    $row['use_risk'] = $analyzed['use_risk'];
    return $row;
}

function invc_stock_row(array $raw, array $usage) {
    $code = trim((string)($raw['WORKING_CODE'] ?? ''));
    $qty = invc_stock_num($raw['QTY_ON_HAND'] ?? 0);
    $min = invc_stock_num($raw['MIN_LEVEL'] ?? 0);
    $max = invc_stock_num($raw['MAX_LEVEL'] ?? 0);
    $suggest = invc_stock_suggest($usage[$code] ?? 0);
    return [
        'code' => $code,
        'name' => trim((string)($raw['DRUG_NAME'] ?? '')),
        'unit' => trim((string)($raw['SALE_UNIT'] ?? '')),
        'form' => trim((string)($raw['DOSAGE_FORM'] ?? '')),
        'location' => trim((string)($raw['LOCATION'] ?? '')),
        'qty' => round($qty, 2),
        'min' => round($min, 2),
        'max' => round($max, 2),
        'rate_stored' => round(invc_stock_num($raw['RATE_PER_MONTH'] ?? 0), 2),
        'issued_6m' => $suggest['issued_qty'],
        'monthly_rate' => $suggest['monthly_avg'],
        'suggest_min' => $suggest['suggest_min'],
        'suggest_max' => $suggest['suggest_max'],
        'flag' => invc_stock_flag($qty, $min, $max),
        'inactive' => (strtoupper(trim((string)($raw['NOUSE'] ?? ''))) === 'Y'
            || strtoupper(trim((string)($raw['OUT_OF_LIST'] ?? ''))) === 'Y'),
    ];
}

function invc_stock_list(PDO $pdo, $q, $status, $include_inactive, $page, $per_page, $sort, $con = null, $force_sheet = false) {
    $q = trim((string)$q);
    $q = str_replace(['%', '_', '[', ']'], '', $q);
    if (mb_strlen($q, 'UTF-8') > 80) {
        $q = mb_substr($q, 0, 80, 'UTF-8');
    }
    $status = in_array($status, ['all', 'low', 'high', 'ok', 'zero', 'soon', 'risk', 'pending'], true) ? $status : 'all';
    $sort = in_array($sort, ['alert', 'name', 'qty', 'rate', 'code'], true) ? $sort : 'alert';
    $page = max(1, (int)$page);
    $per_page = max(10, min(200, (int)$per_page));

    $where = '1=1';
    if (!$include_inactive) {
        $where .= " AND (NOUSE IS NULL OR NOUSE <> 'Y') AND (OUT_OF_LIST IS NULL OR OUT_OF_LIST <> 'Y')";
    }
    if ($q !== '') {
        $like = invc_stock_sql_str('%' . $q . '%');
        $where .= " AND (DRUG_NAME LIKE $like OR WORKING_CODE LIKE $like)";
    }
    $usage = invc_stock_usage_map($pdo);
    if ($usage === null) {
        return ['ok' => false, 'error' => invc_last_error() ?: 'อ่านประวัติเบิก 6 เดือนไม่ได้'];
    }
    $lot_map = invc_stock_lots_map($pdo);
    if ($lot_map === null) {
        return ['ok' => false, 'error' => invc_last_error() ?: 'อ่าน Lot ของ INVC ไม่ได้'];
    }

    $pending_map = [];
    $gsheet_meta = ['enabled' => false, 'ok' => true, 'error' => '', 'row_count' => 0];
    if ($con) {
        if (!function_exists('invc_gsheet_load_orders')) {
            require_once __DIR__ . '/invc_gsheet_helper.php';
        }
        $sheet = invc_gsheet_load_orders($con, $force_sheet);
        $gsheet_meta = [
            'enabled' => !empty($sheet['enabled']),
            'ok' => !empty($sheet['ok']),
            'error' => (string)($sheet['error'] ?? ''),
            'row_count' => (int)($sheet['row_count'] ?? 0),
            'from_cache' => !empty($sheet['from_cache']),
            'mode' => (string)($sheet['mode'] ?? ''),
            'sheet_title' => (string)($sheet['sheet_title'] ?? ''),
        ];
        if (!empty($sheet['ok']) && !empty($sheet['enabled']) && !empty($sheet['orders'])) {
            $last_map = invc_stock_last_dispense_map($pdo);
            if ($last_map === null) {
                $gsheet_meta['ok'] = false;
                $gsheet_meta['error'] = invc_last_error() ?: 'อ่านวันที่จ่ายล่าสุดไม่ได้';
            } else {
                $pending_map = invc_gsheet_pending_map($sheet['orders'], $last_map);
            }
        }
    }

    $sql = "SELECT WORKING_CODE, DRUG_NAME, SALE_UNIT, DOSAGE_FORM, LOCATION,
                   QTY_ON_HAND, MIN_LEVEL, MAX_LEVEL, RATE_PER_MONTH, NOUSE, OUT_OF_LIST
            FROM [INV_MD]
            WHERE $where";
    $st = invc_query($pdo, $sql);
    if (!$st) {
        return ['ok' => false, 'error' => invc_last_error() ?: 'อ่านสต็อก INVC ไม่ได้'];
    }
    $rows = [];
    $summary = ['total' => 0, 'low' => 0, 'high' => 0, 'ok' => 0, 'zero' => 0, 'soon' => 0, 'risk' => 0, 'pending' => 0];
    while ($raw = $st->fetch(PDO::FETCH_ASSOC)) {
        $code = trim((string)($raw['WORKING_CODE'] ?? ''));
        $row = invc_stock_apply_lots(invc_stock_row($raw, $usage), $lot_map[$code] ?? []);
        $row = invc_stock_apply_pending($row, $pending_map);
        $summary['total']++;
        $summary[$row['flag']]++;
        if ($row['qty'] <= 0) {
            $summary['zero']++;
        }
        if ($row['exp_flag'] === 'soon' || $row['exp_flag'] === 'expired') {
            $summary['soon']++;
        }
        if (!empty($row['use_risk'])) {
            $summary['risk']++;
        }
        if (!empty($row['pending_recv'])) {
            $summary['pending']++;
        }
        if ($status === 'zero' && $row['qty'] > 0) {
            continue;
        }
        if ($status === 'pending' && empty($row['pending_recv'])) {
            continue;
        }
        if (in_array($status, ['low', 'high', 'ok'], true) && $row['flag'] !== $status) {
            continue;
        }
        if ($status === 'soon' && $row['exp_flag'] !== 'soon' && $row['exp_flag'] !== 'expired') {
            continue;
        }
        if ($status === 'risk' && empty($row['use_risk'])) {
            continue;
        }
        $rows[] = $row;
    }
    $st->closeCursor();
    usort($rows, function ($a, $b) use ($sort) {
        if ($sort === 'name') {
            return strcmp($a['name'], $b['name']);
        }
        if ($sort === 'code') {
            return strcmp($a['code'], $b['code']);
        }
        if ($sort === 'qty') {
            return $a['qty'] <=> $b['qty'];
        }
        if ($sort === 'rate') {
            return $b['monthly_rate'] <=> $a['monthly_rate'];
        }
        $fa = invc_stock_alert_rank($a);
        $fb = invc_stock_alert_rank($b);
        if ($fa !== $fb) {
            return $fa <=> $fb;
        }
        return strcmp($a['name'], $b['name']);
    });
    $filtered = count($rows);
    $pages = max(1, (int)ceil($filtered / $per_page));
    if ($page > $pages) {
        $page = $pages;
    }
    $slice = array_slice($rows, ($page - 1) * $per_page, $per_page);
    return [
        'ok' => true,
        'summary' => $summary,
        'gsheet' => $gsheet_meta,
        'months' => invc_stock_months(),
        'min_cover' => invc_stock_min_cover(),
        'max_cover' => invc_stock_max_cover(),
        'page' => $page,
        'pages' => $pages,
        'per_page' => $per_page,
        'filtered' => $filtered,
        'rows' => array_values($slice),
    ];
}

function invc_stock_history(PDO $pdo, $code, $limit = 80) {
    $code = trim((string)$code);
    if ($code === '' || !preg_match('/^[A-Za-z0-9._-]+$/', $code)) {
        return ['ok' => false, 'error' => 'รหัสรายการไม่ถูกต้อง'];
    }
    $code_sql = invc_stock_sql_str($code);
    $st = invc_query($pdo, "SELECT TOP 1 WORKING_CODE, DRUG_NAME, SALE_UNIT, DOSAGE_FORM, LOCATION,
                                   QTY_ON_HAND, MIN_LEVEL, MAX_LEVEL, RATE_PER_MONTH, NOUSE, OUT_OF_LIST
                            FROM [INV_MD] WHERE WORKING_CODE = $code_sql");
    if (!$st) {
        return ['ok' => false, 'error' => invc_last_error() ?: 'อ่านรายการไม่ได้'];
    }
    $raw = $st->fetch(PDO::FETCH_ASSOC);
    $st->closeCursor();
    if (!$raw) {
        return ['ok' => false, 'error' => 'ไม่พบรายการนี้ใน INVC'];
    }
    $months = invc_stock_months();
    $month_sql = "SELECT YEAR(OPERATE_DATE) AS y, MONTH(OPERATE_DATE) AS m,
                         SUM(CAST(ACTIVE_QTY1 AS decimal(18,4))) AS qty,
                         COUNT(*) AS n
                  FROM [CARD]
                  WHERE WORKING_CODE = $code_sql
                    AND R_S_STATUS = 'S'
                    AND (CANCEL_FLAG IS NULL OR CANCEL_FLAG <> 'Y')
                    AND OPERATE_DATE >= DATEADD(month, -" . (int)$months . ", CAST(GETDATE() AS date))
                  GROUP BY YEAR(OPERATE_DATE), MONTH(OPERATE_DATE)
                  ORDER BY YEAR(OPERATE_DATE), MONTH(OPERATE_DATE)";
    $mst = invc_query($pdo, $month_sql);
    $by_month = [];
    if ($mst) {
        while ($r = $mst->fetch(PDO::FETCH_ASSOC)) {
            $by_month[] = [
                'year' => (int)($r['y'] ?? 0),
                'month' => (int)($r['m'] ?? 0),
                'qty' => round(invc_stock_num($r['qty'] ?? 0), 2),
                'count' => (int)($r['n'] ?? 0),
            ];
        }
        $mst->closeCursor();
    }
    $issued = 0;
    foreach ($by_month as $m) {
        $issued += invc_stock_num($m['qty'] ?? 0);
    }
    $limit = max(1, min(200, (int)$limit));
    $hist_sql = "SELECT TOP $limit c.OPERATE_DATE, c.R_S_NUMBER, c.DEPT_ID, d.DEPT_NAME,
                        c.ACTIVE_QTY1, c.REMAIN_QTY, c.VALUE
                 FROM [CARD] c
                 LEFT JOIN [DEPT_ID] d ON d.DEPT_ID = c.DEPT_ID
                 WHERE c.WORKING_CODE = $code_sql
                   AND c.R_S_STATUS = 'S'
                   AND (c.CANCEL_FLAG IS NULL OR c.CANCEL_FLAG <> 'Y')
                 ORDER BY c.OPERATE_DATE DESC, c.RECORD_NUMBER DESC";
    $hst = invc_query($pdo, $hist_sql);
    if (!$hst) {
        return ['ok' => false, 'error' => invc_last_error() ?: 'อ่านประวัติเบิกไม่ได้'];
    }
    $history = [];
    while ($r = $hst->fetch(PDO::FETCH_ASSOC)) {
        $dt = (string)($r['OPERATE_DATE'] ?? '');
        $history[] = [
            'date' => $dt !== '' ? substr($dt, 0, 10) : '',
            'doc_no' => trim((string)($r['R_S_NUMBER'] ?? '')),
            'dept_id' => trim((string)($r['DEPT_ID'] ?? '')),
            'dept_name' => trim((string)($r['DEPT_NAME'] ?? '')),
            'qty' => round(invc_stock_num($r['ACTIVE_QTY1'] ?? 0), 2),
            'remain' => round(invc_stock_num($r['REMAIN_QTY'] ?? 0), 2),
            'value' => round(invc_stock_num($r['VALUE'] ?? 0), 2),
        ];
    }
    $hst->closeCursor();
    $raw_lots = invc_stock_lots_for_code($pdo, $code);
    if ($raw_lots === null) {
        return ['ok' => false, 'error' => invc_last_error() ?: 'อ่าน Lot ไม่ได้'];
    }
    $item = invc_stock_apply_lots(invc_stock_row($raw, [$code => $issued]), $raw_lots);
    return [
        'ok' => true,
        'item' => $item,
        'months' => $months,
        'by_month' => $by_month,
        'history' => $history,
    ];
}
