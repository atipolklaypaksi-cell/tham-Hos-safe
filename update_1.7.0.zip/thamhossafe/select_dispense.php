<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/user_unit_helper.php';
require_once __DIR__ . '/smart_pharma_backup_helper.php';

tham_user_load_unit_session($con, (int)$_SESSION['user_id']);
if (!sp_backup_feature_on(null, $con) || !sp_backup_can_pick_room($con)) {
    header('Location: home.php');
    exit;
}

$rooms = sp_backup_dispense_rooms();
$current = sp_backup_room_key();
$cfg = sp_backup_get_config($con);
if ($current === 'opd' && empty($cfg['backup_opd'])) {
    $current = !empty($cfg['backup_ipd']) ? 'ipd' : '';
}
if ($current === 'ipd' && empty($cfg['backup_ipd'])) {
    $current = !empty($cfg['backup_opd']) ? 'opd' : '';
}
if ($current === '') {
    $current = !empty($cfg['backup_opd']) ? 'opd' : (!empty($cfg['backup_ipd']) ? 'ipd' : '');
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $res = sp_backup_set_room($con, (int)$_SESSION['user_id'], $_POST['dispense_room'] ?? '');
    if (!empty($res['ok'])) {
        if (is_file(__DIR__ . '/tham_alert_helper.php')) {
            require_once __DIR__ . '/tham_alert_helper.php';
            if (function_exists('tham_alert_record_login')) {
                tham_alert_record_login($con, (int)$_SESSION['user_id'], 'dispense');
            }
        }
        $back = trim((string)($_SESSION['hosxp_j2_return'] ?? ''));
        unset($_SESSION['hosxp_j2_return'], $_SESSION['hosxp_j2_first'], $_SESSION['hosxp_j2_room_hint']);
        if ($back !== '' && preg_match('/^drug_eval_j2\.php\?[A-Za-z0-9_%=&.\-]+$/', $back)) {
            header('Location: ' . $back);
            exit;
        }
        if (!function_exists('tham_login_return_url_consume') && is_file(__DIR__ . '/user_unit_helper.php')) {
            require_once __DIR__ . '/user_unit_helper.php';
        }
        $ret = function_exists('tham_login_return_url_consume') ? tham_login_return_url_consume() : '';
        header('Location: ' . ($ret !== '' ? $ret : 'home.php'));
        exit;
    }
    $error = $res['error'] ?? 'บันทึกไม่สำเร็จ';
    $current = sp_backup_room_key($_POST['dispense_room'] ?? '');
}
$cfg = $cfg ?? sp_backup_get_config($con);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เลือกห้องจ่ายยา - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #ecfeff 0%, #ccfbf1 50%, #99f6e4 100%);
            min-height: 100vh;
        }
        .room-card {
            max-width: 640px;
            border: 0;
            border-radius: 16px;
            box-shadow: 0 12px 32px rgba(15, 118, 110, 0.14);
        }
        .room-hero {
            background: linear-gradient(135deg, #115e59 0%, #0f766e 100%);
            color: #fff;
            border-radius: 16px 16px 0 0;
            padding: 1.25rem 1.5rem;
        }
        .room-choice {
            border: 2px solid #99f6e4;
            border-radius: 12px;
            padding: 1rem 1.1rem;
            cursor: pointer;
            background: #fff;
            height: 100%;
        }
        .room-choice:hover, .room-opt:checked + .room-choice {
            border-color: #0f766e;
            background: #f0fdfa;
            box-shadow: 0 0 0 3px rgba(15, 118, 110, .12);
        }
        .room-opt { position: absolute; opacity: 0; pointer-events: none; }
        .btn-room { background: #0f766e; color: #fff; border: 0; }
        .btn-room:hover { background: #115e59; color: #fff; }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center p-3">
<div class="card room-card w-100">
    <div class="room-hero">
        <div class="small opacity-75 mb-1"><i class="fas fa-user-shield me-1"></i>Smart Pharma Backup</div>
        <h4 class="fw-bold mb-1">กำหนดสถานที่ทำงาน</h4>
        <div class="small opacity-75">เลือกห้องจ่ายยาของกะนี้ — ระบบจะเฝ้าระวัง Alert ฝั่งนั้นให้ โดยไม่ยิง HOSxP จากทุกเครื่อง</div>
    </div>
    <div class="card-body p-4">
        <div class="mb-3 small text-muted">
            ผู้ใช้: <b><?= htmlspecialchars((string)($_SESSION['full_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></b>
        </div>
        <?php if ($error !== ''): ?>
            <div class="alert alert-danger py-2"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="row g-3">
                <?php foreach ($rooms as $key => $label):
                    $enabled = ($key === 'opd' && !empty($cfg['backup_opd'])) || ($key === 'ipd' && !empty($cfg['backup_ipd']));
                    $id = 'room_' . $key;
                ?>
                <div class="col-md-6">
                    <input class="room-opt" type="radio" name="dispense_room" id="<?= $id ?>" value="<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>"
                           <?= $current === $key ? 'checked' : '' ?> <?= $enabled ? '' : 'disabled' ?> required>
                    <label class="room-choice d-block" for="<?= $id ?>">
                        <div class="fw-bold mb-1">
                            <i class="fas <?= $key === 'ipd' ? 'fa-procedures' : 'fa-hospital-user' ?> me-1 text-teal"></i>
                            <?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?>
                        </div>
                        <div class="small text-muted">
                            <?php if ($enabled): ?>
                                Backup <?= strtoupper($key) ?> — เมื่อพบ Alert จะแจ้งเตือนคล้ายเคสแพ้ยา
                            <?php else: ?>
                                ยังไม่เปิดโหมด Backup ฝั่งนี้ในตั้งค่าโมดูล
                            <?php endif; ?>
                        </div>
                    </label>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="d-grid gap-2 mt-4">
                <button type="submit" class="btn btn-room btn-lg fw-bold">
                    <i class="fas fa-check me-1"></i> เริ่มทำงานที่ห้องนี้
                </button>
                <?php if (!empty($_SESSION['dispense_room_confirmed'])): ?>
                    <a href="home.php" class="btn btn-outline-secondary">ยกเลิก</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>
</body>
</html>
