<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
mysqli_set_charset($con, 'utf8');
$prefill_hn = isset($_GET['hn']) ? htmlspecialchars((string)$_GET['hn'], ENT_QUOTES, 'UTF-8') : '';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>คำนวณยา Warfarin - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .wf-input-yellow { background: #fff3cd !important; border-color: #ffc107 !important; font-weight: 700; }
        .wf-result { background: #fce7f3; border: 1px solid #f9a8d4; border-radius: 8px; padding: 0.85rem 1rem; }
        .wf-result .val { font-size: 1.35rem; font-weight: 800; color: #9d174d; }
        .wf-result-green { background: #dcfce7; border-color: #86efac; }
        .wf-result-green .val { color: #166534; }
        .wf-result-blue { background: #dbeafe; border-color: #93c5fd; }
        .wf-result-blue .val { color: #1d4ed8; }
        .wf-guide-box {
            background: #fff7ed; border: 1px solid #fdba74; border-radius: 10px;
            padding: 0.85rem 1rem; min-height: 5.5rem;
        }
        .wf-guide-box.in-target { background: #f0fdf4; border-color: #86efac; }
        .wf-guide-box.warn-high { background: #fef2f2; border-color: #fca5a5; }
        .wf-hint {
            background: #0d6efd; color: #fff; border-radius: 8px;
            padding: 0.65rem 1rem; font-weight: 600; font-size: 0.95rem;
        }
        .wf-patient-box { background: #ecfdf5; border: 1px solid #6ee7b7; border-radius: 10px; }
        .wf-method-box {
            background: #ffedd5; border: 1px solid #fdba74; border-radius: 8px;
            padding: 1rem; font-weight: 700; white-space: pre-wrap;
        }
        .wf-day-chip {
            display: inline-flex; flex-direction: column; align-items: center; justify-content: flex-start;
            min-width: 6.2rem; text-align: center; vertical-align: top;
            background: #fff; border: 1px solid #cbd5e1; border-radius: 8px;
            padding: 0.4rem 0.45rem 0.5rem; margin: 0.15rem; font-size: 0.82rem;
        }
        .wf-day-chip strong { display: block; color: #0f766e; font-size: .78rem; margin-bottom: 2px; }
        .wf-day-chip .wf-day-mg { color: #64748b; font-size: .75rem; margin-top: 2px; }
        .wf-pill-legend { display: flex; flex-wrap: wrap; gap: .65rem 1.1rem; font-size: .82rem; color: #475569; margin-bottom: .55rem; }
        .wf-pill-legend .item { display: inline-flex; align-items: center; gap: .35rem; font-weight: 700; }
        .wf-pills { display: inline-flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: 3px; min-height: 42px; }
        .wf-pill { display: inline-block; vertical-align: middle; flex: 0 0 auto; }
        .wf-pill svg { display: block; }
        .wf-sched-pills { min-width: 7rem; }
        .wf-inr-btn {
            display: inline-flex; align-items: center; gap: 0.4rem;
            border: 1px solid #93c5fd; background: #eff6ff; color: #1e3a8a;
            border-radius: 999px; padding: 0.35rem 0.85rem; font-weight: 700;
            cursor: pointer; text-decoration: none;
        }
        .wf-inr-btn:hover { background: #dbeafe; color: #1e3a8a; }
        .wf-inr-btn .wf-inr-val { font-size: 1.15rem; color: #b91c1c; }
        .wf-inr-btn.wf-inr-empty { border-color: #cbd5e1; background: #f8fafc; color: #64748b; }
        .wf-inr-btn.wf-inr-empty .wf-inr-val { color: #64748b; font-size: 0.95rem; }
        .wf-inr-btn.wf-inr-warn { border-color: #fcd34d; background: #fffbeb; color: #92400e; }
        .wf-inr-btn.wf-inr-warn .wf-inr-val { color: #b45309; }
        .wf-inr-btn.wf-inr-high { border-color: #fca5a5; background: #fef2f2; color: #991b1b; }
        .wf-inr-btn.wf-inr-high .wf-inr-val { color: #dc2626; }
        .wf-inr-btn.wf-inr-ok { border-color: #86efac; background: #f0fdf4; color: #166534; }
        .wf-inr-btn.wf-inr-ok .wf-inr-val { color: #15803d; }
        .wf-strength-box {
            border: 1px solid #ffc107; border-radius: 8px; padding: 0.55rem 0.75rem;
            min-height: 2.75rem;
        }
        .wf-strength-box .form-check {
            margin: 0.15rem 0.35rem 0.15rem 0; padding-left: 1.6rem;
        }
        .wf-strength-box .form-check-input { cursor: pointer; }
        .wf-strength-box .form-check-label { cursor: pointer; font-weight: 700; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-1 text-dark">
                <i class="fas fa-pills me-2 text-danger"></i>คำนวณยา Warfarin
            </h4>
            <p class="text-muted small mb-3">ค้นหา HN → ดึงรายการ Warfarin และ mg/สัปดาห์ → เลือกปรับ % → แนะนำวิธีใช้ใกล้เคียง</p>

            <div class="card border-0 shadow-sm mb-3 wf-patient-box">
                <div class="card-body py-3">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">HN <span class="text-danger">*</span></label>
                            <input type="text" id="wf_hn" class="form-control form-control-lg fw-bold border-success" placeholder="กรอก HN" value="<?= $prefill_hn ?>">
                        </div>
                        <div class="col-md-2">
                            <button type="button" id="wfBtnLookup" class="btn btn-success btn-lg w-100 fw-bold">
                                <i class="fas fa-search me-1"></i> ค้นหา
                            </button>
                        </div>
                        <div class="col-md-5">
                            <div id="wfPatientInfo" class="small text-muted">ยังไม่ได้เลือกผู้ป่วย</div>
                        </div>
                        <div class="col-md-2">
                            <div id="wfInrBox" class="text-md-end">
                                <span class="wf-inr-btn wf-inr-empty" id="wfInrBtn" title="ค้นหา HN เพื่อดู INR" style="pointer-events:none;opacity:.65;">
                                    <i class="fas fa-chart-line"></i>
                                    <span>INR</span>
                                    <span class="wf-inr-val" id="wfInrVal">—</span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div id="wfMsg" class="mt-2 small" style="display:none;"></div>
                </div>
            </div>

            <!-- Modal: INR history chart -->
            <div class="modal fade" id="wfInrModal" tabindex="-1" aria-labelledby="wfInrModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold" id="wfInrModalLabel">
                                <i class="fas fa-chart-line me-2 text-danger"></i>INR ย้อนหลัง
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                                <div class="small text-muted" id="wfInrModalSub">—</div>
                                <div class="small">
                                    <span class="badge text-bg-success">เป้า 2.0–3.0</span>
                                    <span class="badge text-bg-warning text-dark">ต่ำ &lt;2</span>
                                    <span class="badge text-bg-danger">สูง &gt;3</span>
                                </div>
                            </div>
                            <div style="position:relative;height:280px;">
                                <canvas id="wfInrChart"></canvas>
                            </div>
                            <div class="table-responsive mt-3" style="max-height:220px;overflow:auto;">
                                <table class="table table-sm table-bordered mb-0 text-center">
                                    <thead class="table-light sticky-top">
                                        <tr><th>วันที่</th><th>INR</th><th>ผลดิบ</th></tr>
                                    </thead>
                                    <tbody id="wfInrHistTbody">
                                        <tr><td colspan="3" class="text-muted">—</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <h5 class="fw-bold mb-2">รายการยา Warfarin</h5>
                    <div class="wf-hint mb-3">*** OPD: Visit ล่าสุด · IPD: รายการที่ยังไม่มีวันที่หยุด (ถ้าหยุดครบ → ใช้รายการล่าสุด) ***</div>
                    <div class="table-responsive mb-3">
                        <table class="table table-sm table-bordered bg-white mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>ยา</th>
                                    <th>ความแรง</th>
                                    <th>วิธีใช้</th>
                                    <th>mg/สัปดาห์</th>
                                    <th>วันที่สั่งยา</th>
                                    <th>แหล่ง</th>
                                </tr>
                            </thead>
                            <tbody id="wf_items_tbody">
                                <tr><td colspan="6" class="text-muted">ค้นหา HN เพื่อโหลดรายการ</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">dose เดิม (mg/สัปดาห์)</label>
                            <input type="number" id="wf_current" class="form-control wf-input-yellow" min="0" step="0.1" value="">
                        </div>
                        <div class="col-md-9">
                            <label class="form-label fw-bold mb-1">เลือกความแรงเม็ดปรับยา (mg)</label>
                            <div id="wf_strengths" class="wf-strength-box wf-input-yellow d-flex flex-wrap align-items-center gap-2">
                                <!-- filled by JS -->
                            </div>
                            <div class="form-text">ติ๊กได้หลายค่า เช่น 2 กับ 3 — ค่าเริ่มต้นตามยาใน Visit ล่าสุด</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <h5 class="fw-bold mb-2">ปรับขนาดยา <span class="text-muted fw-normal small">ตาม Guideline</span></h5>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold mb-1">เลือกแนวทาง Target INR</label>
                            <select id="wf_protocol" class="form-select wf-input-yellow"></select>
                            <div class="form-text" id="wf_protocol_ind">—</div>
                        </div>
                        <div class="col-md-6">
                            <div id="wfGuideBox" class="wf-guide-box">
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-1 mb-1">
                                    <div class="small text-muted mb-0">คำแนะนำจาก Guideline (ตาม INR ล่าสุด)</div>
                                    <a href="warfarin_guideline_setting.php" class="btn btn-sm btn-outline-secondary py-0 px-2" title="ไปแก้ไขที่ตั้งค่า">
                                        <i class="fas fa-cog me-1"></i>ตั้งค่า
                                    </a>
                                </div>
                                <div class="fw-bold" id="wfGuideSummary">ค้นหา HN เพื่อดูคำแนะนำ</div>
                                <div class="small mt-1" id="wfGuideMeta"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">ทิศทาง</label>
                            <select id="wf_direction" class="form-select wf-input-yellow">
                                <option value="up">เพิ่มขนาดยา (+)</option>
                                <option value="down">ลดขนาดยา (−)</option>
                                <option value="hold">คงขนาดยาเดิม</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">เปอร์เซ็นต์</label>
                            <select id="wf_pct" class="form-select wf-input-yellow">
                                <option value="0">0%</option>
                                <option value="5">5%</option>
                                <option value="10">10%</option>
                                <option value="15" selected>15%</option>
                                <option value="20">20%</option>
                                <option value="25">25%</option>
                                <option value="30">30%</option>
                                <option value="35">35%</option>
                                <option value="40">40%</option>
                                <option value="45">45%</option>
                                <option value="50">50%</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold mb-1">หรือกำหนด dose ใหม่เอง</label>
                            <input type="number" id="wf_target_manual" class="form-control" min="0" step="0.1" placeholder="ว่าง = ใช้ %">
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="button" id="wfBtnCalc" class="btn btn-primary btn-lg w-100 fw-bold">
                                <i class="fas fa-calculator me-1"></i> คำนวณ
                            </button>
                        </div>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <div class="wf-result">
                                <div class="small text-muted">① เป้าที่คำนวณ</div>
                                <div class="val"><span id="wf_target">—</span> <span class="fs-6 fw-bold">mg/สัปดาห์</span></div>
                                <div class="small mt-1">ตั้งใจปรับ <strong id="wf_adj_pct">—</strong>%</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="wf-result wf-result-green">
                                <div class="small fw-bold text-success">② ที่ใช้ปรับจริง (ใกล้เคียง)</div>
                                <div class="val"><span id="wf_actual">—</span> <span class="fs-6 fw-bold">mg/สัปดาห์</span></div>
                                <div class="small text-muted">ต่างจากเป้า <span id="wf_diff">—</span> mg</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="wf-result wf-result-blue">
                                <div class="small fw-bold text-primary">③ คิดเป็น % จริง จาก dose เดิม</div>
                                <div class="val"><span id="wf_actual_pct">—</span> %</div>
                                <div class="small text-muted" id="wf_pct_note">—</div>
                            </div>
                        </div>
                    </div>
                    <h6 class="fw-bold mb-2">วิธีใช้ยาที่แนะนำ</h6>
                    <div class="wf-pill-legend" id="wf_pill_legend">
                        <span class="item">
                            <svg class="wf-pill" width="28" height="28" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="16.5" fill="#fb923c" stroke="#c2410c" stroke-width="1.6"/><line x1="20" y1="4.5" x2="20" y2="35.5" stroke="#9a3412" stroke-width="1.5" stroke-linecap="round"/><text x="11.5" y="23.5" text-anchor="middle" font-size="9" font-family="Sarabun, Tahoma, sans-serif" font-weight="800" fill="#9a3412" stroke="#fff" stroke-width="0.6" paint-order="stroke">2</text><text x="28.5" y="23.5" text-anchor="middle" font-size="7" font-family="Sarabun, Tahoma, sans-serif" font-weight="800" fill="#9a3412" stroke="#fff" stroke-width="0.6" paint-order="stroke">mg</text></svg>
                            2 mg สีส้ม
                        </span>
                        <span class="item">
                            <svg class="wf-pill" width="28" height="28" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="16.5" fill="#38bdf8" stroke="#0369a1" stroke-width="1.6"/><line x1="20" y1="4.5" x2="20" y2="35.5" stroke="#0c4a6e" stroke-width="1.5" stroke-linecap="round"/><text x="11.5" y="23.5" text-anchor="middle" font-size="9" font-family="Sarabun, Tahoma, sans-serif" font-weight="800" fill="#0c4a6e" stroke="#fff" stroke-width="0.6" paint-order="stroke">3</text><text x="28.5" y="23.5" text-anchor="middle" font-size="7" font-family="Sarabun, Tahoma, sans-serif" font-weight="800" fill="#0c4a6e" stroke="#fff" stroke-width="0.6" paint-order="stroke">mg</text></svg>
                            3 mg สีฟ้า
                        </span>
                        <span class="item">
                            <svg class="wf-pill" width="28" height="28" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="16.5" fill="#f9a8d4" stroke="#be185d" stroke-width="1.6"/><line x1="20" y1="4.5" x2="20" y2="35.5" stroke="#9d174d" stroke-width="1.5" stroke-linecap="round"/><text x="11.5" y="23.5" text-anchor="middle" font-size="9" font-family="Sarabun, Tahoma, sans-serif" font-weight="800" fill="#9d174d" stroke="#fff" stroke-width="0.6" paint-order="stroke">5</text><text x="28.5" y="23.5" text-anchor="middle" font-size="7" font-family="Sarabun, Tahoma, sans-serif" font-weight="800" fill="#9d174d" stroke="#fff" stroke-width="0.6" paint-order="stroke">mg</text></svg>
                            5 mg สีชมพู
                        </span>
                        <span class="item text-muted fw-normal">ครึ่งเม็ด = ครึ่งรูป</span>
                    </div>
                    <div class="wf-method-box mb-3" id="wf_method">—</div>
                    <div id="wf_day_chips" class="mb-3"></div>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered bg-white mb-0 text-center">
                            <thead class="table-light">
                                <tr>
                                    <th>วัน</th>
                                    <th>วิธีใช้ (เม็ด)</th>
                                    <th>รูปเม็ดยา</th>
                                    <th>mg</th>
                                </tr>
                            </thead>
                            <tbody id="wf_sched_tbody">
                                <tr><td colspan="4" class="text-muted">กดคำนวณเพื่อดูตาราง</td></tr>
                            </tbody>
                        </table>
                    </div>

                    <hr class="my-4">
                    <div class="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-2">
                        <div>
                            <h6 class="fw-bold mb-0">ประวัติการได้รับยา Warfarin</h6>
                            <div class="small text-muted" id="wfHistNote">ค้นหา HN เพื่อดูประวัติ dose / INR / การปรับยา</div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered bg-white mb-0 align-middle">
                            <thead class="table-light text-center">
                                <tr>
                                    <th style="min-width:6.5rem">วันที่</th>
                                    <th style="min-width:6rem">Warfarin<br><span class="fw-normal small">(mg/สัปดาห์)</span></th>
                                    <th style="min-width:7rem">จำนวนสั่ง</th>
                                    <th style="min-width:12rem">วิธีใช้ยา</th>
                                    <th style="min-width:5rem">INR</th>
                                    <th style="min-width:5.5rem">ปรับเทียบก่อนหน้า</th>
                                    <th style="min-width:8rem">สรุปความเหมาะสม</th>
                                    <th>รายละเอียด</th>
                                </tr>
                            </thead>
                            <tbody id="wf_hist_tbody">
                                <tr><td colspan="8" class="text-muted text-center">ยังไม่มีข้อมูล</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/chart.min.js"></script>
<script src="js/warfarin_calculator.js?v=20260907b"></script>
</body>
</html>
