<?php
/**
 * Smart Pharma — คัดกรองโมดูลเสริมจาก Monitor ความปลอดภัยยา
 * drug_usage | max_dose | warfarin | mg_ml | pediatric_dose | dose_calculator | opd_qty | drug_allergy | opd_dup | home_med | antibiotic | amr_drug
 */
require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
require_once __DIR__ . '/monitor_drug_usage_helper.php';
require_once __DIR__ . '/monitor_max_dose_helper.php';
require_once __DIR__ . '/monitor_warfarin_helper.php';
require_once __DIR__ . '/monitor_mg_ml_helper.php';
require_once __DIR__ . '/dose_calculator_helper.php';
require_once __DIR__ . '/monitor_opd_order_qty_helper.php';
require_once __DIR__ . '/monitor_drug_allergy_helper.php';
require_once __DIR__ . '/pediatric_dose_helper.php';
require_once __DIR__ . '/monitor_dose_calculator_helper.php';
require_once __DIR__ . '/monitor_home_med_helper.php';
require_once __DIR__ . '/monitor_opd_dup_helper.php';
require_once __DIR__ . '/monitor_antibiotic_helper.php';
require_once __DIR__ . '/monitor_dup_therapy_helper.php';

function sp_extra_module_defs() {
    return [
        'drug_usage' => [
            'label_th' => 'วิธีใช้ยา',
            'label_en' => 'Drug Usage',
            'icon' => 'prescription-bottle-alt',
            'color' => 'teal',
            'enabled' => 1,
            'enabled_opd' => 1,
            'enabled_ipd' => 1,
            'sort_order' => 90,
        ],
        'max_dose' => [
            'label_th' => 'Max Dose/Duration',
            'label_en' => 'Max Dose/Duration',
            'icon' => 'tachometer-alt',
            'color' => 'purple',
            'enabled' => 1,
            'enabled_opd' => 1,
            'enabled_ipd' => 1,
            'sort_order' => 100,
        ],
        'warfarin' => [
            'label_th' => 'Monitor Warfarin',
            'label_en' => 'Warfarin',
            'icon' => 'heartbeat',
            'color' => 'danger',
            'enabled' => 1,
            'enabled_opd' => 1,
            'enabled_ipd' => 1,
            'sort_order' => 105,
        ],
        'mg_ml' => [
            'label_th' => 'mg. to mL.',
            'label_en' => 'mg to mL',
            'icon' => 'syringe',
            'color' => 'primary',
            'enabled' => 1,
            'enabled_opd' => 1,
            'enabled_ipd' => 1,
            'sort_order' => 110,
        ],
        'pediatric_dose' => [
            'label_th' => 'Monitor ยาเด็ก',
            'label_en' => 'Pediatric Dose',
            'icon' => 'child',
            'color' => 'pink',
            'enabled' => 1,
            'enabled_opd' => 1,
            'enabled_ipd' => 1,
            'sort_order' => 115,
        ],
        'dose_calculator' => [
            'label_th' => 'เครื่องคำนวณยา',
            'label_en' => 'Dose Calculator',
            'icon' => 'calculator',
            'color' => 'pink',
            'enabled' => 1,
            'enabled_opd' => 1,
            'enabled_ipd' => 1,
            'sort_order' => 116,
        ],
        'opd_qty' => [
            'label_th' => 'จำนวนสั่งยา (OPD)',
            'label_en' => 'OPD Order Qty',
            'icon' => 'calculator',
            'color' => 'info',
            'enabled' => 1,
            'enabled_opd' => 1,
            'enabled_ipd' => 0,
            'sort_order' => 120,
        ],
        'drug_allergy' => [
            'label_th' => 'Drug Allergy',
            'label_en' => 'Drug Allergy',
            'icon' => 'allergies',
            'color' => 'danger',
            'enabled' => 1,
            'enabled_opd' => 1,
            'enabled_ipd' => 1,
            'sort_order' => 130,
        ],
        'opd_dup' => [
            'label_th' => 'ยาเหลือ OPD',
            'label_en' => 'OPD Leftover Duplicate',
            'icon' => 'history',
            'color' => 'warning',
            'enabled' => 1,
            'enabled_opd' => 1,
            'enabled_ipd' => 0,
            'sort_order' => 135,
        ],
        'home_med' => [
            'label_th' => 'ยากลับบ้าน IPD',
            'label_en' => 'Home Med Duplicate',
            'icon' => 'home',
            'color' => 'warning',
            'enabled' => 1,
            'enabled_opd' => 0,
            'enabled_ipd' => 1,
            'sort_order' => 140,
        ],
        'antibiotic' => [
            'label_th' => 'Monitor Antibiotic',
            'label_en' => 'Antibiotic Duration',
            'icon' => 'bacteria',
            'color' => 'success',
            'enabled' => 1,
            'enabled_opd' => 0,
            'enabled_ipd' => 1,
            'sort_order' => 150,
        ],
        'amr_drug' => [
            'label_th' => 'Monitor AMR Drug',
            'label_en' => 'AMR Drug',
            'icon' => 'exclamation-triangle',
            'color' => 'danger',
            'enabled' => 1,
            'enabled_opd' => 0,
            'enabled_ipd' => 1,
            'sort_order' => 155,
        ],
        'dup_therapy' => [
            'label_th' => 'คู่ยาซ้ำซ้อน',
            'label_en' => 'Therapeutic Duplication',
            'icon' => 'layer-group',
            'color' => 'indigo',
            'enabled' => 1,
            'enabled_opd' => 1,
            'enabled_ipd' => 1,
            'sort_order' => 125,
        ],
    ];
}

/** ใส่โมดูลใหม่ลง smart_pharma_modules (INSERT IGNORE) */
function sp_ensure_extra_modules($con) {
    foreach (sp_extra_module_defs() as $key => $def) {
        $key_esc = mysqli_real_escape_string($con, $key);
        $th = mysqli_real_escape_string($con, $def['label_th']);
        $en = mysqli_real_escape_string($con, $def['label_en']);
        $icon = mysqli_real_escape_string($con, $def['icon']);
        $color = mysqli_real_escape_string($con, $def['color']);
        $en_g = (int)$def['enabled'];
        $opd = (int)$def['enabled_opd'];
        $ipd = (int)$def['enabled_ipd'];
        $sort = (int)$def['sort_order'];
        mysqli_query(
            $con,
            "INSERT IGNORE INTO smart_pharma_modules
                (module_key, label_th, label_en, icon, color, enabled, enabled_opd, enabled_ipd, sort_order)
             VALUES ('$key_esc', '$th', '$en', '$icon', '$color', $en_g, $opd, $ipd, $sort)"
        );
        if ($key === 'home_med' || $key === 'opd_dup' || $key === 'amr_drug') {
            mysqli_query($con, "UPDATE smart_pharma_modules SET label_th='$th' WHERE module_key='$key_esc'");
        }
    }
}

function sp_extra_hn_set(array $hn_list) {
    $set = [];
    foreach ($hn_list as $hn) {
        $hn = trim((string)$hn);
        if ($hn === '') {
            continue;
        }
        $set[$hn] = true;
        $t = ltrim($hn, '0');
        if ($t === '') {
            $t = '0';
        }
        $set[$t] = true;
        $set[str_pad($t, 9, '0', STR_PAD_LEFT)] = true;
    }
    return $set;
}

function sp_extra_hn_in_set($hn, array $set) {
    $hn = trim((string)$hn);
    if ($hn === '' || empty($set)) {
        return false;
    }
    if (isset($set[$hn])) {
        return true;
    }
    $t = ltrim($hn, '0');
    if ($t === '') {
        $t = '0';
    }
    return isset($set[$t]) || isset($set[str_pad($t, 9, '0', STR_PAD_LEFT)]);
}

function sp_extra_order_hn_list(array $orders) {
    $hns = [];
    foreach ($orders as $o) {
        $hn = trim((string)($o['hn'] ?? ''));
        if ($hn !== '') {
            $hns[$hn] = true;
        }
    }
    return array_keys($hns);
}

/**
 * ดึงใบยาแบบเบา (opitemrece อย่างเดียว) แล้วเติมชื่อยา/ความแรง/วิธีใช้ทีหลัง
 * เส้นทางเดียวกับ monitor_dup_therapy / mg-ml lean — เลี่ยง JOIN TMT + drugusage + opi_dispense ทั้งตาราง
 */
function sp_extra_fetch_orders_for_date($hos, $screen_date, array $hn_list, array $icodes, $need_strength = false, $opd_only = false) {
    if (empty($hn_list) || empty($icodes) || !$hos) {
        return [];
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$screen_date)) {
        return [];
    }
    $date_esc = mysqli_real_escape_string($hos, $screen_date);
    $hn_set = sp_extra_hn_set($hn_list);
    $icode_list = [];
    foreach ($icodes as $ic) {
        $ic = trim((string)$ic);
        if ($ic !== '') {
            $icode_list[$ic] = true;
        }
    }
    $icode_list = array_keys($icode_list);
    if (empty($hn_set) || empty($icode_list)) {
        return [];
    }

    $hn_keys = array_keys($hn_set);
    $use_hn_sql = count($hn_keys) > 0 && count($hn_keys) <= 80;
    $limit = 20000;
    $rows = [];
    foreach (array_chunk($icode_list, 80) as $chunk) {
        if (count($rows) >= $limit) {
            break;
        }
        $in = function_exists('mmgml_sql_in_strings')
            ? mmgml_sql_in_strings($hos, $chunk)
            : implode(',', array_map(function ($v) use ($hos) {
                return "'" . mysqli_real_escape_string($hos, $v) . "'";
            }, $chunk));
        if ($in === '') {
            continue;
        }
        $hn_clause = '';
        if ($use_hn_sql) {
            $hn_in = function_exists('mmgml_sql_in_strings')
                ? mmgml_sql_in_strings($hos, $hn_keys)
                : implode(',', array_map(function ($v) use ($hos) {
                    return "'" . mysqli_real_escape_string($hos, $v) . "'";
                }, $hn_keys));
            if ($hn_in !== '') {
                $hn_clause = " AND o.hn IN ($hn_in)";
            }
        }
        $remain = $limit - count($rows);
        $sql = "SELECT o.hn, o.vn, o.an, o.vstdate, o.rxdate, o.rxtime, o.icode, o.qty, o.item_no,
                       CAST(IFNULL(NULLIF(o.unitprice, 0), 0) AS DECIMAL(16,4)) AS unitprice,
                       IFNULL(o.drugusage,'') AS drugusage, IFNULL(o.sp_use,'') AS sp_use, IFNULL(o.hos_guid,'') AS hos_guid
                FROM opitemrece o
                WHERE o.icode IN ($in)
                  AND o.rxdate = '$date_esc'
                  AND o.qty > 0
                  $hn_clause
                LIMIT $remain";
        $q = mysqli_query($hos, $sql);
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
        }
    }

    if (!$use_hn_sql) {
        $filtered = [];
        foreach ($rows as $r) {
            if (sp_extra_hn_in_set($r['hn'] ?? '', $hn_set)) {
                $filtered[] = $r;
            }
        }
        $rows = $filtered;
    }
    if ($opd_only) {
        $filtered = [];
        foreach ($rows as $r) {
            $vn = trim((string)($r['vn'] ?? ''));
            $an = trim((string)($r['an'] ?? ''));
            if ($vn !== '' && $an === '') {
                $filtered[] = $r;
            }
        }
        $rows = $filtered;
    }
    return sp_extra_enrich_orders($hos, $rows, $need_strength);
}

function sp_extra_enrich_orders($hos, array $rows, $need_strength = false) {
    if (!$rows || !$hos) {
        return $rows;
    }
    $icodes = [];
    $dusage = [];
    $spuse = [];
    $guidsNeedDisp = [];
    foreach ($rows as $r) {
        $ic = trim((string)($r['icode'] ?? ''));
        if ($ic !== '') {
            $icodes[$ic] = true;
        }
        $du = trim((string)($r['drugusage'] ?? ''));
        if ($du !== '') {
            $dusage[$du] = true;
        }
        $sp = trim((string)($r['sp_use'] ?? ''));
        if ($sp !== '') {
            $spuse[$sp] = true;
        } else {
            $g = trim((string)($r['hos_guid'] ?? ''));
            if ($g !== '') {
                $guidsNeedDisp[$g] = true;
            }
        }
    }

    $utf8 = function ($expr) {
        return function_exists('mmgml_sql_utf8') ? mmgml_sql_utf8($expr) : "CAST(CONVERT($expr USING utf8) AS CHAR)";
    };
    $in_sql = function ($vals) use ($hos) {
        if (function_exists('mmgml_sql_in_strings')) {
            return mmgml_sql_in_strings($hos, $vals);
        }
        $out = [];
        foreach ($vals as $v) {
            $v = trim((string)$v);
            if ($v !== '') {
                $out[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
            }
        }
        return implode(',', $out);
    };

    $drugMap = [];
    $icIn = $in_sql(array_keys($icodes));
    if ($icIn !== '') {
        $nameExpr = $utf8("IFNULL(d.name,'')");
        $unitExpr = $utf8("IFNULL(d.units,'')");
        $priceExpr = 'CAST(IFNULL(d.unitprice, 0) AS DECIMAL(16,4)) AS unitprice';
        if ($need_strength && function_exists('hosxp_sql_tmt_join')) {
            $tmtStrExpr = $utf8(function_exists('hosxp_sql_tmt_strength') ? hosxp_sql_tmt_strength('d', 'tm') : "IFNULL(d.strength,'')");
            $tmtNameExpr = function_exists('hosxp_sql_tmt_drug_name')
                ? hosxp_sql_tmt_drug_name('d', 'tm')
                : $nameExpr;
            $tmtJoin = hosxp_sql_tmt_join('d', 'tm');
            $q = mysqli_query($hos, "SELECT d.icode, {$nameExpr} AS name, {$tmtNameExpr} AS tmt_name,
                                            {$tmtStrExpr} AS strength, {$unitExpr} AS units, {$priceExpr}
                                     FROM drugitems d {$tmtJoin}
                                     WHERE d.icode IN ({$icIn})");
        } else {
            $hosStrExpr = $utf8("IFNULL(d.strength,'')");
            $q = mysqli_query($hos, "SELECT d.icode, {$nameExpr} AS name, '' AS tmt_name,
                                            {$hosStrExpr} AS strength, {$unitExpr} AS units, {$priceExpr}
                                     FROM drugitems d
                                     WHERE d.icode IN ({$icIn})");
        }
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $drugMap[(string)$r['icode']] = $r;
            }
        }
    }

    $duMap = [];
    $duIn = $in_sql(array_keys($dusage));
    if ($duIn !== '') {
        $duExpr = $utf8("CONCAT(IFNULL(name1,''),' ',IFNULL(name2,''),' ',IFNULL(name3,''))");
        $q = mysqli_query($hos, "SELECT drugusage, {$duExpr} AS method FROM drugusage WHERE drugusage IN ({$duIn})");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $duMap[(string)$r['drugusage']] = trim((string)($r['method'] ?? ''));
            }
        }
    }

    $spMap = [];
    $spIn = $in_sql(array_keys($spuse));
    if ($spIn !== '') {
        $spExpr = $utf8("CONCAT(IFNULL(name1,''),' ',IFNULL(name2,''),' ',IFNULL(name3,''))");
        $q = mysqli_query($hos, "SELECT sp_use, {$spExpr} AS method FROM sp_use WHERE sp_use IN ({$spIn})");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $spMap[(string)$r['sp_use']] = trim((string)($r['method'] ?? ''));
            }
        }
    }

    $dispMap = [];
    foreach (array_chunk(array_keys($guidsNeedDisp), 150) as $gchunk) {
        $gIn = $in_sql($gchunk);
        if ($gIn === '') {
            continue;
        }
        $odExpr = $utf8("CONCAT(IFNULL(usage_line1,''),' ',IFNULL(usage_line2,''),' ',IFNULL(usage_line3,''))");
        $q = mysqli_query($hos, "SELECT hos_guid, {$odExpr} AS method FROM opi_dispense WHERE hos_guid IN ({$gIn})");
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $dispMap[(string)$r['hos_guid']] = trim((string)($r['method'] ?? ''));
        }
    }

    foreach ($rows as &$r) {
        $ic = (string)($r['icode'] ?? '');
        $du = trim((string)($r['drugusage'] ?? ''));
        $sp = trim((string)($r['sp_use'] ?? ''));
        $g = (string)($r['hos_guid'] ?? '');
        $drug = $drugMap[$ic] ?? [];
        if ($sp !== '') {
            $method = $spMap[$sp] ?? '';
        } else {
            $method = $dispMap[$g] ?? '';
            if (function_exists('mb_strlen')) {
                $ok = mb_strlen(trim($method), 'UTF-8') >= 8;
            } else {
                $ok = strlen(trim($method)) >= 8;
            }
            if (!$ok) {
                $method = $duMap[$du] ?? '';
            }
        }
        $r['method'] = $method;
        $r['drug_name'] = trim((string)($drug['name'] ?? ''));
        $r['tmt_name'] = trim((string)($drug['tmt_name'] ?? ''));
        $r['strength'] = $need_strength ? trim((string)($drug['strength'] ?? '')) : '';
        $r['units'] = trim((string)($drug['units'] ?? ''));
        $up = (float)($r['unitprice'] ?? 0);
        if ($up <= 0 && isset($drug['unitprice'])) {
            $r['unitprice'] = $drug['unitprice'];
        }
    }
    unset($r);
    return $rows;
}

function sp_extra_prefetch_age_map($hos, array $hn_list, $as_of_date) {
    $age_map = [];
    if (!$hos || empty($hn_list)) {
        return $age_map;
    }
    $hn_in = [];
    foreach ($hn_list as $hn) {
        foreach ([$hn, ltrim((string)$hn, '0'), str_pad(ltrim((string)$hn, '0') === '' ? '0' : ltrim((string)$hn, '0'), 9, '0', STR_PAD_LEFT)] as $h) {
            $h = trim((string)$h);
            if ($h !== '') {
                $hn_in[$h] = "'" . mysqli_real_escape_string($hos, $h) . "'";
            }
        }
    }
    if (empty($hn_in)) {
        return $age_map;
    }
    $today = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$as_of_date) ? $as_of_date : date('Y-m-d');
    $qage = mysqli_query($hos, "SELECT hn, birthday FROM patient WHERE hn IN (" . implode(',', array_values($hn_in)) . ")");
    if (!$qage) {
        return $age_map;
    }
    while ($ar = mysqli_fetch_assoc($qage)) {
        $bd = trim((string)($ar['birthday'] ?? ''));
        if ($bd === '' || $bd === '0000-00-00') {
            continue;
        }
        $age = null;
        if (function_exists('monitor_lab_patient_age_years')) {
            $age = (int)monitor_lab_patient_age_years($bd, $today);
        } else {
            $ts = strtotime($bd);
            if ($ts) {
                $age = (int)floor((strtotime($today) - $ts) / 31557600);
            }
        }
        if ($age === null) {
            continue;
        }
        $hn = (string)$ar['hn'];
        $age_map[$hn] = $age;
        $age_map[ltrim($hn, '0')] = $age;
        $t = ltrim($hn, '0');
        if ($t === '') {
            $t = '0';
        }
        $age_map[str_pad($t, 9, '0', STR_PAD_LEFT)] = $age;
    }
    return $age_map;
}

function sp_extra_order_patient_keys(array $order, $screen_date, array $patients_by_hn) {
    $hn = trim((string)($order['hn'] ?? ''));
    $keys = [];
    $candidates = [$hn, ltrim($hn, '0')];
    $t = ltrim($hn, '0');
    if ($t === '') {
        $t = '0';
    }
    $candidates[] = str_pad($t, 9, '0', STR_PAD_LEFT);
    foreach (array_unique($candidates) as $h) {
        if ($h === '' || !isset($patients_by_hn[$h])) {
            continue;
        }
        foreach ($patients_by_hn[$h] as $pat) {
            foreach (sp_patient_screen_key_variants($pat, $screen_date) as $k) {
                $keys[$k] = true;
            }
            $keys[sp_patient_di_key($pat, $screen_date)] = true;
            $keys[$h . '||' . $screen_date] = true;
        }
    }
    return array_keys($keys);
}

function sp_extra_index_patients_by_hn(array $patients) {
    $by = [];
    foreach ($patients as $p) {
        $hn = trim((string)($p['hn'] ?? ''));
        if ($hn === '') {
            continue;
        }
        $variants = [$hn, ltrim($hn, '0')];
        $t = ltrim($hn, '0');
        if ($t === '') {
            $t = '0';
        }
        $variants[] = str_pad($t, 9, '0', STR_PAD_LEFT);
        foreach (array_unique($variants) as $h) {
            $by[$h][] = $p;
        }
    }
    return $by;
}

function sp_extra_push_alert(array &$bucket, $pkey, $level, $line, array $item = []) {
    if (!isset($bucket[$pkey])) {
        $bucket[$pkey] = ['hard' => false, 'lines' => [], 'items' => []];
    }
    if ($level === 'hard') {
        $bucket[$pkey]['hard'] = true;
    }
    $bucket[$pkey]['lines'][] = $line;
    if (!empty($item)) {
        $bucket[$pkey]['items'][] = sp_extra_slim_item($item);
    }
}

function sp_extra_slim_item(array $item) {
    $out = [];
    foreach ([
        'icode', 'drug', 'drug_name', 'hme_drug_name', 'hme_icode',
        'remaining_text', 'an', 'hn', 'duration', 'alert_level',
        'rule_key', 'pair_label', 'drugs_a', 'drugs_b', 'method',
        'sir', 'drugName', 'microtype',
    ] as $k) {
        if (!array_key_exists($k, $item)) {
            continue;
        }
        $v = $item[$k];
        if (is_scalar($v) || $v === null) {
            $out[$k] = $v;
        }
    }
    return $out;
}

function sp_extra_run_batch($fn, $con, $hos, $screen_date, array $patients) {
    try {
        if (function_exists('hosxp_ensure_connection')) {
            hosxp_ensure_connection($con, $hos);
        }
        return $fn($con, $hos, $screen_date, $patients);
    } catch (Throwable $e) {
        return [
            'no_rules' => false,
            'results' => [],
            'has_drug' => [],
            'error' => $e->getMessage(),
        ];
    }
}

function sp_extra_finalize_bucket(array $bucket) {
    $results = [];
    foreach ($bucket as $pkey => $data) {
        $lines = array_values(array_unique($data['lines']));
        $summary = implode('; ', array_slice($lines, 0, 3));
        if (count($lines) > 3) {
            $summary .= ' (+' . (count($lines) - 3) . ')';
        }
        $results[$pkey] = sp_result_alert(
            !empty($data['hard']) ? 'hard' : 'soft',
            $summary,
            $lines,
            $data['items']
        );
    }
    return $results;
}

function sp_extra_mark_has_drug(array &$has_drug, array $keys) {
    foreach ($keys as $k) {
        $has_drug[$k] = true;
    }
}

/** วิธีใช้ยา */
function sp_batch_drug_usage_map($con, $hos, $screen_date, array $patients) {
    $rules = mdu_load_active_rules($con);
    if (empty($rules)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $rule_by = [];
    foreach ($rules as $r) {
        $ic = trim((string)($r['icode'] ?? ''));
        if ($ic !== '') {
            $rule_by[$ic][] = $r;
        }
    }
    $hn_list = sp_extract_hn_list($patients);
    $orders = sp_extra_fetch_orders_for_date($hos, $screen_date, $hn_list, array_keys($rule_by));
    $by_hn = sp_extra_index_patients_by_hn($patients);
    $bucket = [];
    $has_drug = [];
    foreach ($orders as $order) {
        $icode = trim((string)($order['icode'] ?? ''));
        $keys = sp_extra_order_patient_keys($order, $screen_date, $by_hn);
        if (empty($keys) || empty($rule_by[$icode])) {
            continue;
        }
        sp_extra_mark_has_drug($has_drug, $keys);
        $method = trim(preg_replace('/\s+/u', ' ', (string)($order['method'] ?? '')));
        foreach ($rule_by[$icode] as $rule) {
            if (mdu_method_passes($method, $rule['required_regex'] ?? '')) {
                continue;
            }
            $level = mdu_alert_level($rule);
            $drug = trim((string)($rule['drug_name'] ?? $order['drug_name'] ?? $icode));
            $msg = trim((string)($rule['alert_message'] ?? 'วิธีใช้ยาไม่ตรงเงื่อนไข'));
            $line = $drug . ' — ' . $msg;
            foreach ($keys as $k) {
                sp_extra_push_alert($bucket, $k, $level, $line);
            }
        }
    }
    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/** Max Dose / Duration */
function sp_batch_max_dose_map($con, $hos, $screen_date, array $patients) {
    $rules = mmdd_load_active_rules($con);
    if (empty($rules)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $rule_by = [];
    foreach ($rules as $r) {
        $ic = trim((string)($r['icode'] ?? ''));
        if ($ic !== '') {
            $rule_by[$ic][] = $r;
        }
    }
    $hn_list = sp_extract_hn_list($patients);
    $orders = sp_extra_fetch_orders_for_date($hos, $screen_date, $hn_list, array_keys($rule_by), true);
    $by_hn = sp_extra_index_patients_by_hn($patients);
    $bucket = [];
    $has_drug = [];
    $duration_cache = [];
    $duration_icodes = [];
    foreach ($rule_by as $ic => $rs) {
        if (mmdd_icode_needs_duration($rs)) {
            $duration_icodes[$ic] = true;
        }
    }
    $lookback = mmdd_duration_lookback_days($rules);
    if ($lookback > 0 && $duration_icodes && $orders) {
        $pairs = [];
        foreach ($orders as $order) {
            $icode = trim((string)($order['icode'] ?? ''));
            $hn = trim((string)($order['hn'] ?? ''));
            if ($hn === '' || $icode === '' || empty($duration_icodes[$icode])) {
                continue;
            }
            $pairs[$hn . '|' . $icode] = true;
        }
        if ($pairs) {
            $duration_cache['_lookback'] = $lookback;
            mmdd_prefetch_rx_dates($hos, array_keys($pairs), $screen_date, $lookback, $duration_cache);
        }
    }
    foreach ($orders as $order) {
        $icode = trim((string)($order['icode'] ?? ''));
        $keys = sp_extra_order_patient_keys($order, $screen_date, $by_hn);
        if (empty($keys) || empty($rule_by[$icode])) {
            continue;
        }
        sp_extra_mark_has_drug($has_drug, $keys);
        $method = trim(preg_replace('/\s+/u', ' ', (string)($order['method'] ?? '')));
        $parsed = hosxp_parse_drug_daily_dose_mg([
            'qty' => $order['qty'] ?? 0,
            'strength' => $order['strength'] ?? '',
            'units' => $order['units'] ?? '',
            'method' => $method,
        ]);
        $daily_mg = isset($parsed['mg_dose']) ? (float)$parsed['mg_dose'] : null;
        $rxdate = trim((string)($order['rxdate'] ?? $screen_date));
        $consecutive = 0;
        if (!empty($duration_icodes[$icode])) {
            $consecutive = mmdd_consecutive_days($hos, $order['hn'] ?? '', $icode, $rxdate !== '' ? $rxdate : $screen_date, $duration_cache);
        }
        foreach ($rule_by[$icode] as $rule) {
            $reasons = mmdd_build_trigger_reasons($rule, $daily_mg, $consecutive);
            if (empty($reasons)) {
                continue;
            }
            $level = mmdd_alert_level($rule);
            $msg = mmdd_default_alert_message($rule, $reasons, $daily_mg, $consecutive);
            $drug = trim((string)($order['tmt_name'] ?? ''));
            if ($drug === '') {
                $drug = trim((string)($rule['drug_name'] ?? $order['drug_name'] ?? $icode));
            }
            $strength = trim((string)($order['strength'] ?? ''));
            $units = trim((string)($order['units'] ?? ''));
            $daily_mg_display = function_exists('di_format_daily_mg_display')
                ? di_format_daily_mg_display([
                    'qty' => $order['qty'] ?? 0,
                    'strength' => $strength,
                    'units' => $units,
                    'method' => $method,
                ])
                : ($daily_mg !== null ? (rtrim(rtrim(number_format($daily_mg, 2, '.', ''), '0'), '.') . ' mg/วัน') : '');
            $rx_date_fmt = $rxdate !== '' ? date('d/m/Y', strtotime($rxdate)) : '-';
            $rx_time_fmt = function_exists('di_format_time') && function_exists('monitor_lab_normalize_hosxp_time')
                ? di_format_time(monitor_lab_normalize_hosxp_time($order['rxtime'] ?? ''))
                : trim((string)($order['rxtime'] ?? ''));
            $detail_rule = trim((string)($rule['detail_text'] ?? ''));
            $line_parts = [$drug];
            if ($method !== '') {
                $line_parts[] = 'วิธีใช้: ' . $method;
            }
            if ($daily_mg_display !== '') {
                $line_parts[] = $daily_mg_display;
            }
            $line_parts[] = $msg;
            $line = implode(' — ', $line_parts);
            $item = [
                'drug_name' => $drug,
                'icode' => $icode,
                'method' => $method,
                'qty' => $order['qty'] ?? '',
                'strength' => $strength,
                'units' => $units,
                'daily_mg' => $daily_mg,
                'daily_mg_display' => $daily_mg_display,
                'max_dose_mg_per_day' => (float)($rule['max_dose_mg_per_day'] ?? 0),
                'consecutive_days' => $consecutive,
                'max_duration_days' => (int)($rule['max_duration_days'] ?? 0),
                'trigger_reasons' => $reasons,
                'order_date' => $rx_date_fmt,
                'order_time' => $rx_time_fmt,
                'alert_message' => $msg,
                'detail_text' => $detail_rule,
            ];
            foreach ($keys as $k) {
                sp_extra_push_alert($bucket, $k, $level, $line, $item);
            }
        }
    }
    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/** mg → mL */
function sp_batch_mg_ml_map($con, $hos, $screen_date, array $patients) {
    $rules = mmgml_load_active_rules($con);
    if (empty($rules)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $rule_by = mmgml_build_rule_map_by_icode($rules);
    $hn_list = sp_extract_hn_list($patients);
    $orders = sp_extra_fetch_orders_for_date($hos, $screen_date, $hn_list, array_keys($rule_by));
    $by_hn = sp_extra_index_patients_by_hn($patients);

    $vitals_cache = [];
    $dc_overrides = [];
    $order_hns = sp_extra_order_hn_list($orders);
    if (mmgml_rules_need_weight($rules) && !empty($order_hns)) {
        $lookback = mmgml_max_weight_lookback_days($rules);
        $vitals_cache = mmgml_prefetch_vitals($hos, $con, $order_hns, $screen_date, $screen_date, $lookback);
        $dc_overrides = dc_prefetch_vitals_overrides($con, $order_hns);
    }

    $bucket = [];
    $has_drug = [];
    $pending = [];
    foreach ($orders as $order) {
        $icode = trim((string)($order['icode'] ?? ''));
        $keys = sp_extra_order_patient_keys($order, $screen_date, $by_hn);
        if (empty($keys) || empty($rule_by[$icode])) {
            continue;
        }
        sp_extra_mark_has_drug($has_drug, $keys);
        $method = trim(preg_replace('/\s+/u', ' ', (string)($order['method'] ?? '')));
        $order_date = !empty($order['rxdate']) ? $order['rxdate'] : ($order['vstdate'] ?? $screen_date);
        $qty = isset($order['qty']) ? (float)$order['qty'] : null;
        $row = $order;
        $row['method'] = $method;

        foreach ($rule_by[$icode] as $rule) {
            $lookback = (int)($rule['weight_lookback_days'] ?? 365);
            $weight_info = mmgml_get_weight_info_from_cache($vitals_cache, $order['hn'] ?? '', $order_date, $lookback);
            $weight_info = dc_merge_weight_override($weight_info, $dc_overrides, $order['hn'] ?? '');
            $ctx = [
                'weight_kg' => $weight_info['bw'],
                'weight_stale' => !empty($weight_info['stale']),
                'weight_vstdate' => $weight_info['vstdate'],
                'qty' => $qty,
                'drug_name' => trim((string)($order['drug_name'] ?? '')),
            ];
            $eval = mmgml_evaluate_method($rule, $method, $ctx);
            $pending[] = [
                'rule' => $rule,
                'row' => $row,
                'eval' => $eval,
                'weight_kg' => $weight_info['bw'],
                'weight_stale' => !empty($weight_info['stale']),
                'keys' => $keys,
            ];
        }
    }

    mmgml_apply_combined_qty_checks($pending);

    $combined_qty_alerted = [];
    foreach ($pending as $p) {
        $eval = $p['eval'];
        if (!is_array($eval) || empty($eval['mismatches'])) {
            continue;
        }
        $rule = $p['rule'];
        $keys = $p['keys'];

        // แจ้ง Amp รวม Bolus+Infusion ครั้งเดียวต่อใบสั่ง (ไม่ซ้ำสองบรรทัด)
        $only_combined_qty = true;
        $has_combined_qty = false;
        foreach ($eval['mismatches'] as $m) {
            if (($m['type'] ?? '') === 'qty' && !empty($m['combined'])) {
                $has_combined_qty = true;
            } else {
                $only_combined_qty = false;
            }
        }
        if ($has_combined_qty && $only_combined_qty) {
            $gk = mmgml_same_rx_group_key($p['row'], (int)($rule['id'] ?? 0));
            if (isset($combined_qty_alerted[$gk])) {
                continue;
            }
            $combined_qty_alerted[$gk] = true;
        }

        $level = mmgml_alert_level($rule);
        $msg = mmgml_default_alert_message($rule, $eval);
        $drug = trim((string)($rule['drug_name'] ?? $p['row']['drug_name'] ?? $p['row']['icode'] ?? ''));
        $line = $drug . ' — ' . $msg;
        foreach ($keys as $k) {
            sp_extra_push_alert($bucket, $k, $level, $line);
        }
    }
    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/**
 * Monitor ยาเด็ก — ตรวจ mg/kg ตามน้ำหนัก (เฉพาะเด็ก อายุ ≤15 หรือ BW≤40 ถ้าไม่มีอายุ)
 */
function sp_batch_pediatric_dose_map($con, $hos, $screen_date, array $patients) {
    if (function_exists('pdc_ensure_table')) {
        pdc_ensure_table($con);
    }
    $rules = pdc_load_monitor_rules($con, []);
    if (empty($rules)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $rule_by = pdc_build_icode_rule_map($hos, $rules);
    if (empty($rule_by)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }

    $hn_list = sp_extract_hn_list($patients);
    $orders = sp_extra_fetch_orders_for_date($hos, $screen_date, $hn_list, array_keys($rule_by), true);
    $by_hn = sp_extra_index_patients_by_hn($patients);

    $order_hns = sp_extra_order_hn_list($orders);
    $vitals_cache = [];
    $dc_overrides = [];
    if (!empty($order_hns)) {
        $vitals_cache = mmgml_prefetch_vitals($hos, $con, $order_hns, $screen_date, $screen_date, 365);
        if (function_exists('dc_prefetch_vitals_overrides')) {
            $dc_overrides = dc_prefetch_vitals_overrides($con, $order_hns);
        }
    }
    $age_map = !empty($order_hns) ? sp_extra_prefetch_age_map($hos, $order_hns, $screen_date) : [];

    $tol_pct = pdc_get_monitor_tolerance_pct($con);
    $bucket = [];
    $has_drug = [];

    foreach ($orders as $order) {
        $icode = trim((string)($order['icode'] ?? ''));
        $keys = sp_extra_order_patient_keys($order, $screen_date, $by_hn);
        if (empty($keys) || empty($rule_by[$icode])) {
            continue;
        }

        $method = trim(preg_replace('/\s+/u', ' ', (string)($order['method'] ?? '')));
        if (pdc_is_nebulization_method($method)) {
            continue;
        }

        $hn = trim((string)($order['hn'] ?? ''));
        $order_date = !empty($order['rxdate']) ? $order['rxdate'] : ($order['vstdate'] ?? $screen_date);
        $weight_info = mmgml_get_weight_info_from_cache($vitals_cache, $hn, $order_date, 365);
        if (function_exists('dc_merge_weight_override')) {
            $weight_info = dc_merge_weight_override($weight_info, $dc_overrides, $hn);
        }
        $bw = isset($weight_info['bw']) ? (float)$weight_info['bw'] : null;
        if ($bw !== null && $bw <= 0) {
            $bw = null;
        }

        $age = $age_map[$hn] ?? $age_map[ltrim($hn, '0')] ?? null;
        // เฉพาะเด็ก — ผู้ใหญ่ที่มียากลุ่มนี้ถือว่าไม่เข้าเงื่อนไข
        $is_child = false;
        if ($age !== null) {
            $is_child = ($age <= 15);
        } elseif ($bw !== null) {
            $is_child = ($bw <= 40);
        }
        if (!$is_child) {
            continue;
        }

        sp_extra_mark_has_drug($has_drug, $keys);

        $row = $order;
        $row['method'] = $method;
        $matched = $rule_by[$icode];
        $evals = [];
        foreach ($matched as $rule) {
            if (pdc_should_exclude_order($rule, $row)) {
                continue;
            }
            $parsed = pdc_parse_order_daily_mg($row, $rule);
            $daily_mg = $parsed['daily_mg'] ?? null;
            if ($daily_mg !== null && $daily_mg <= 0) {
                $daily_mg = null;
            }
            $rule_tol = pdc_effective_tolerance_pct($rule, $tol_pct, $con);
            $evals[] = array_merge(
                pdc_evaluate_order($rule, $bw, $daily_mg, $method, $rule_tol, $parsed),
                ['_rule' => $rule, '_parse' => $parsed]
            );
        }
        $eval = pdc_pick_eval($evals);
        if (!$eval || ($eval['status'] ?? '') !== 'alert') {
            continue;
        }

        $rule = $eval['_rule'] ?? $matched[0];
        $level = (($eval['level'] ?? '') === 'hard') ? 'hard' : 'soft';
        $drug = trim((string)($order['drug_name'] ?? $rule['drug_name'] ?? $icode));
        $msg = trim((string)($eval['message'] ?? $eval['reason'] ?? 'ขนาดยาเด็กนอกช่วง'));
        $line = $drug . ' — ' . $msg;
        $item = [
            'icode' => $icode,
            'drug_name' => $drug,
            'method' => $method,
            'strength' => trim((string)($order['strength'] ?? '')),
            'weight_kg' => $bw,
            'age' => $age,
            'daily_mg' => $eval['daily_mg'] ?? null,
            'dose_direction' => $eval['dose_direction'] ?? null,
            'alert_message' => $msg,
            'suggest_text' => $eval['suggest_text'] ?? '',
        ];
        foreach ($keys as $k) {
            sp_extra_push_alert($bucket, $k, $level, $line, $item);
        }
    }

    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/** Monitor เครื่องคำนวณยา */
function sp_batch_dose_calculator_map($con, $hos, $screen_date, array $patients) {
    if (function_exists('mdc_ensure_table')) {
        mdc_ensure_table($con);
    }
    $rules = mdc_load_rules($con, [], true);
    if (empty($rules)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $rule_by = mdc_build_rule_map_by_icode($rules);
    if (empty($rule_by)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $hn_list = sp_extract_hn_list($patients);
    $orders = sp_extra_fetch_orders_for_date($hos, $screen_date, $hn_list, array_keys($rule_by), true);
    $by_hn = sp_extra_index_patients_by_hn($patients);

    $order_hns = sp_extra_order_hn_list($orders);
    $vitals_cache = [];
    $dc_overrides = [];
    if (!empty($order_hns)) {
        $vitals_cache = mmgml_prefetch_vitals($hos, $con, $order_hns, $screen_date, $screen_date, 365);
        if (function_exists('dc_prefetch_vitals_overrides')) {
            $dc_overrides = dc_prefetch_vitals_overrides($con, $order_hns);
        }
    }
    $age_map = !empty($order_hns) ? sp_extra_prefetch_age_map($hos, $order_hns, $screen_date) : [];

    $tol_pct = mdc_get_monitor_tolerance_pct($con);
    $bucket = [];
    $has_drug = [];
    foreach ($orders as $order) {
        $icode = trim((string)($order['icode'] ?? ''));
        $keys = sp_extra_order_patient_keys($order, $screen_date, $by_hn);
        if (empty($keys) || empty($rule_by[$icode])) {
            continue;
        }
        sp_extra_mark_has_drug($has_drug, $keys);
        $method = trim(preg_replace('/\s+/u', ' ', (string)($order['method'] ?? '')));
        $order_date = !empty($order['rxdate']) ? $order['rxdate'] : ($order['vstdate'] ?? $screen_date);
        $hn = trim((string)($order['hn'] ?? ''));
        $weight_info = mmgml_get_weight_info_from_cache($vitals_cache, $hn, $order_date, 365);
        $weight_info = dc_merge_weight_override($weight_info, $dc_overrides, $hn);
        $bw = isset($weight_info['bw']) ? (float)$weight_info['bw'] : null;
        if ($bw !== null && $bw <= 0) {
            $bw = null;
        }
        $age = $age_map[$hn] ?? $age_map[ltrim($hn, '0')] ?? null;
        foreach ($rule_by[$icode] as $rule) {
            $eval = mdc_evaluate_order($rule, [
                'method' => $method,
                'weight_kg' => $bw,
                'age' => $age,
                'qty' => isset($order['qty']) ? (float)$order['qty'] : null,
                'tolerance_pct' => mdc_effective_tolerance_pct($rule, $tol_pct),
            ]);
            if (($eval['status'] ?? '') !== 'alert') {
                continue;
            }
            $level = (($eval['level'] ?? '') === 'hard') ? 'hard' : 'soft';
            $drug = trim((string)($order['drug_name'] ?? $rule['drug_name'] ?? $icode));
            $msg = trim((string)($eval['message'] ?? 'ไม่ตรงสูตรเครื่องคำนวณ'));
            $line = $drug . ' — ' . $msg;
            $item = [
                'icode' => $icode,
                'drug_name' => $drug,
                'method' => $method,
                'calc_type' => $rule['calc_type'] ?? '',
                'weight_kg' => $bw,
                'found_display' => $eval['found_display'] ?? '',
                'expected_display' => $eval['expected_display'] ?? '',
                'alert_message' => $msg,
            ];
            foreach ($keys as $k) {
                sp_extra_push_alert($bucket, $k, $level, $line, $item);
            }
        }
    }
    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/** จำนวนสั่งยา OPD */
function sp_batch_opd_qty_map($con, $hos, $screen_date, array $patients) {
    $rules = moq_load_active_rules($con);
    if (empty($rules)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $min_excess_value = (float)((moq_load_config($con)['min_excess_value'] ?? 0));
    $rule_pack = moq_build_rule_map_by_icode($hos, $rules);
    $rule_map = $rule_pack[0] ?? [];
    if (empty($rule_map)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $hn_list = sp_extract_hn_list($patients);
    $orders = sp_extra_fetch_orders_for_date($hos, $screen_date, $hn_list, array_keys($rule_map), true, true);
    $by_hn = sp_extra_index_patients_by_hn($patients);
    $vns = [];
    $order_hns = [];
    foreach ($orders as $o) {
        $vn = trim((string)($o['vn'] ?? ''));
        if ($vn !== '') {
            $vns[$vn] = true;
        }
        $ohn = trim((string)($o['hn'] ?? ''));
        if ($ohn !== '') {
            $order_hns[] = $ohn;
        }
    }
    $appts_by_hn = moq_fetch_appointments_by_hn($hos, $order_hns, $screen_date, $screen_date);
    $appts_by_vn = moq_fetch_appointments_by_vn($hos, array_keys($vns));
    $bucket = [];
    $has_drug = [];
    $excess_pending = [];
    $excess_sum = [];
    foreach ($orders as $order) {
        $icode = trim((string)($order['icode'] ?? ''));
        $keys = sp_extra_order_patient_keys($order, $screen_date, $by_hn);
        if (empty($keys) || empty($rule_map[$icode])) {
            continue;
        }
        sp_extra_mark_has_drug($has_drug, $keys);
        $vn = trim((string)($order['vn'] ?? ''));
        $rxdate = trim((string)($order['rxdate'] ?? $screen_date));
        $appts = moq_filter_appointments_for_order(
            moq_lookup_hn_appointments($appts_by_hn, $order['hn'] ?? ''),
            $rxdate
        );
        if (empty($appts) && $vn !== '') {
            $appts = moq_filter_appointments_for_order($appts_by_vn[$vn] ?? [], $rxdate);
        }
        $method = trim((string)($order['method'] ?? ''));
        $units = trim((string)($order['units'] ?? ''));
        $qty = (float)($order['qty'] ?? 0);
        foreach ($rule_map[$icode] as $rule) {
            $exclude = moq_get_rule_exclude_set($rule);
            if (!empty($exclude[$icode])) {
                continue;
            }
            $excess = isset($rule['excess_pills_allowed'])
                ? (float)$rule['excess_pills_allowed']
                : (isset($rule['excess_pills']) ? (float)$rule['excess_pills'] : moq_default_excess_pills());
            $shortage = isset($rule['shortage_pills_allowed'])
                ? (float)$rule['shortage_pills_allowed']
                : (isset($rule['shortage_pills']) ? (float)$rule['shortage_pills'] : moq_default_shortage_pills());
            $eval = moq_evaluate_order_against_appointments(
                $qty, $method, $units, $rxdate, $appts, $excess, $shortage, $con,
                $rule['monitor_scope'] ?? 'both'
            );
            $status = $eval['status'] ?? 'skip';
            if ($status !== 'shortage' && $status !== 'excess') {
                continue;
            }
            $detail = moq_attach_excess_value($eval['eval'] ?? [], $qty, $order['unitprice'] ?? 0);
            $nextdate = trim((string)(($eval['appointment']['nextdate'] ?? '') ?: ($detail['nextdate'] ?? '')));
            if ($status === 'shortage') {
                $level = moq_alert_level($rule['alert_level_shortage'] ?? 'soft');
                $msg = moq_default_shortage_message($rule, $detail, $nextdate);
            } else {
                $level = moq_alert_level($rule['alert_level_excess'] ?? 'soft');
                $msg = moq_default_excess_message($rule, $detail, $nextdate);
            }
            $drug = trim((string)($rule['drug_name'] ?? $order['drug_name'] ?? $icode));
            $line = $drug . ' — ' . $msg;
            if ($status === 'excess' && $min_excess_value > 0) {
                $rk = moq_rx_group_key($order['hn'] ?? '', $vn, $rxdate);
                $excess_sum[$rk] = ($excess_sum[$rk] ?? 0) + (float)($detail['excess_value'] ?? 0);
                $excess_pending[$rk][] = ['keys' => $keys, 'level' => $level, 'line' => $line];
                continue;
            }
            foreach ($keys as $k) {
                sp_extra_push_alert($bucket, $k, $level, $line);
            }
        }
    }
    foreach ($excess_pending as $rk => $items) {
        if ((float)($excess_sum[$rk] ?? 0) < $min_excess_value) {
            continue;
        }
        foreach ($items as $item) {
            foreach ($item['keys'] as $k) {
                sp_extra_push_alert($bucket, $k, $item['level'], $item['line']);
            }
        }
    }
    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/** Drug Allergy */
function sp_batch_drug_allergy_map($con, $hos, $screen_date, array $patients) {
    mda_ensure_tables($con);
    mda_ensure_config($con);
    $cfg = mda_load_config($con);
    $cross_rules = mda_load_cross_rules($con, true);
    if (empty($cfg) && empty($cross_rules)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }

    $hn_list = sp_extract_hn_list($patients);
    if (empty($hn_list)) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => []];
    }

    $date_esc = mysqli_real_escape_string($hos, $screen_date);
    $hn_in = [];
    foreach ($hn_list as $hn) {
        foreach ([$hn, ltrim($hn, '0'), str_pad(ltrim($hn, '0') === '' ? '0' : ltrim($hn, '0'), 9, '0', STR_PAD_LEFT)] as $h) {
            $h = trim((string)$h);
            if ($h !== '') {
                $hn_in[] = "'" . mysqli_real_escape_string($hos, $h) . "'";
            }
        }
    }
    $hn_in = array_values(array_unique($hn_in));
    $exclude_clause = mda_build_exclude_clause($hos, $cfg['mda_exclude_hns'] ?? '');
    $tmt_expr = hosxp_sql_tmt_drug_name('d', 'tm');

    $sql = "SELECT o.hn, o.vn, o.an, o.vstdate, o.rxdate, o.rxtime, o.icode, o.qty,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS local_name,
            $tmt_expr AS tmt_name,
            CAST(CONVERT(IFNULL(tm.active_ingredient,'') USING utf8) AS CHAR) AS active_ingredient,
            dp.pharmacology_group_id, dp.pharmacology_group_id_2, dp.pharmacology_group_id_3, dp.pharmacology_group_id_4
        FROM opitemrece o
        INNER JOIN drugitems d ON d.icode = o.icode
        " . hosxp_sql_tmt_join('d', 'tm') . "
        LEFT JOIN drugitems_pharmacology_group dp ON dp.icode = o.icode
        WHERE o.hn IN (" . implode(',', $hn_in) . ")
          AND o.rxdate = '$date_esc'
          AND o.qty > 0
          $exclude_clause
        ORDER BY o.rxdate DESC, o.rxtime DESC
        LIMIT 20000";
    $q = mysqli_query($hos, $sql);
    $orders = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $orders[] = $r;
        }
    }
    if (empty($orders)) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => []];
    }

    $pharma_index = mda_build_pharma_index($hos);
    $allergies_by_hn = [];
    $sql_al = "SELECT hn, agent, symptom, report_date
        FROM opd_allergy
        WHERE hn IN (" . implode(',', $hn_in) . ")";
    $qa = mysqli_query($hos, $sql_al);
    if ($qa) {
        while ($a = mysqli_fetch_assoc($qa)) {
            $h = trim((string)($a['hn'] ?? ''));
            if ($h !== '') {
                $allergies_by_hn[$h][] = $a;
                $allergies_by_hn[ltrim($h, '0')][] = $a;
            }
        }
    }

    $by_hn = sp_extra_index_patients_by_hn($patients);
    $bucket = [];
    $has_drug = [];
    foreach ($orders as $order) {
        $keys = sp_extra_order_patient_keys($order, $screen_date, $by_hn);
        if (empty($keys)) {
            continue;
        }
        sp_extra_mark_has_drug($has_drug, $keys);
        $hn = trim((string)($order['hn'] ?? ''));
        $allergies = $allergies_by_hn[$hn] ?? $allergies_by_hn[ltrim($hn, '0')] ?? [];
        if (empty($allergies)) {
            continue;
        }
        $rx = [
            'hn' => $hn,
            'vn' => $order['vn'] ?? '',
            'an' => $order['an'] ?? '',
            'vstdate' => $order['vstdate'] ?? '',
            'rxdate' => $order['rxdate'] ?? '',
            'rxtime' => $order['rxtime'] ?? '',
            'icode' => $order['icode'] ?? '',
            'qty' => $order['qty'] ?? 0,
            'local_name' => $order['local_name'] ?? '',
            'tmt_name' => $order['tmt_name'] ?? '',
            'active_ingredient' => $order['active_ingredient'] ?? '',
            'pharmacology_group_id' => $order['pharmacology_group_id'] ?? '',
            'pharmacology_group_id_2' => $order['pharmacology_group_id_2'] ?? '',
            'pharmacology_group_id_3' => $order['pharmacology_group_id_3'] ?? '',
            'pharmacology_group_id_4' => $order['pharmacology_group_id_4'] ?? '',
        ];
        $eval = mda_evaluate_prescription($rx, $allergies, $cfg, $cross_rules, $pharma_index);
        foreach (['hard', 'soft'] as $lvl) {
            foreach ($eval[$lvl] ?? [] as $item) {
                $drug = trim((string)($item['drug_name_tmt'] ?? $item['drug_name_local'] ?? $rx['tmt_name'] ?? $rx['local_name'] ?? $rx['icode']));
                $agent = trim((string)($item['allergy_agent'] ?? ''));
                $detail = trim((string)($item['detail'] ?? $item['match_type_label'] ?? $item['match_type'] ?? 'Drug Allergy'));
                $line = $drug . ($agent !== '' ? ' ↔ ' . $agent : '') . ' — ' . $detail;
                foreach ($keys as $k) {
                    sp_extra_push_alert($bucket, $k, $lvl, $line, $item);
                }
            }
        }
    }
    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/** Monitor Warfarin — ความเหมาะสมของการปรับขนาดตาม Guideline + INR */
function sp_batch_warfarin_map($con, $hos, $screen_date, array $patients) {
    mwf_ensure_tables($con);
    $rules = mwf_rules_by_verdict($con, true);
    if (empty($rules)) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }

    $hn_list = sp_extract_hn_list($patients);
    if (empty($hn_list)) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => []];
    }

    $scope = 'all';
    $seen_type = [];
    foreach ($patients as $p) {
        $t = strtoupper(trim((string)($p['patient_type'] ?? '')));
        if ($t === 'OPD' || $t === 'IPD') {
            $seen_type[$t] = true;
        }
    }
    if (count($seen_type) === 1) {
        $scope = strtolower(array_key_first($seen_type));
    }

    $wf_hns = mwf_filter_hns_with_warfarin($hos, $hn_list, $screen_date, $scope);
    if (empty($wf_hns)) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => []];
    }

    $config = mwf_get_config($con);
    $defaultProtocol = $config['default_protocol_id'] ?? 'inr_2_3';
    $inrMaxDays = (int)($config['inr_assess_max_days'] ?? 5);
    $by_hn = sp_extra_index_patients_by_hn($patients);
    $bucket = [];
    $has_drug = [];

    foreach ($wf_hns as $hn) {
        $keys = sp_extra_order_patient_keys(['hn' => $hn], $screen_date, $by_hn);
        if (empty($keys)) {
            continue;
        }
        sp_extra_mark_has_drug($has_drug, $keys);

        $pref = function_exists('wf_hn_pref_get') ? wf_hn_pref_get($con, $hn) : [];
        $protocolId = trim((string)($pref['protocol_id'] ?? '')) ?: $defaultProtocol;
        $eval = mwf_evaluate_hn_date($con, $hos, $hn, $screen_date, $protocolId, $inrMaxDays, $rules, $scope);
        foreach ($eval['alerts'] as $alert) {
            $level = (($alert['alert_level'] ?? '') === 'soft') ? 'soft' : 'hard';
            $msg = trim((string)($alert['alert_message'] ?? 'พบการสั่ง Warfarin ที่ต้องตรวจสอบ'));
            $mg = $alert['mg_week'] ?? null;
            $inr = $alert['inr'] ?? null;
            $parts = ['Warfarin'];
            if ($mg !== null && $mg !== '') {
                $parts[] = rtrim(rtrim(number_format((float)$mg, 2, '.', ''), '0'), '.') . ' mg/สัปดาห์';
            }
            if ($inr !== null && $inr !== '') {
                $parts[] = 'INR ' . $inr;
            }
            $line = implode(' ', $parts) . ' — ' . $msg;
            foreach ($keys as $k) {
                sp_extra_push_alert($bucket, $k, $level, $line, $alert);
            }
        }
    }
    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/** ยากลับบ้าน HME ซ้ำกับยา OPD ก่อน admit — IPD เท่านั้น */
function sp_batch_home_med_map($con, $hos, $screen_date, array $patients) {
    $cfg = mhm_get_config($con);
    if (empty($cfg['monitor_active'])) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $an_list = [];
    $by_an = [];
    foreach ($patients as $p) {
        $an = trim((string)($p['an'] ?? ''));
        if ($an === '') {
            continue;
        }
        $an_list[$an] = true;
        $by_an[$an][] = $p;
    }
    if (empty($an_list)) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => []];
    }
    try {
        $scan = mhm_scan($con, $hos, $screen_date, $screen_date, array_keys($an_list));
    } catch (Throwable $e) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => [], 'error' => $e->getMessage()];
    }
    $bucket = [];
    $has_drug = [];
    foreach ($patients as $pat) {
        if (trim((string)($pat['an'] ?? '')) === '') {
            continue;
        }
        $keys = [];
        foreach (sp_patient_screen_key_variants($pat, $screen_date) as $k) {
            $keys[$k] = true;
        }
        $keys[sp_patient_di_key($pat, $screen_date)] = true;
        sp_extra_mark_has_drug($has_drug, array_keys($keys));
    }
    $alerts = array_merge($scan['hard_alerts'] ?? [], $scan['soft_alerts'] ?? []);
    foreach ($alerts as $alert) {
        $an = trim((string)($alert['an'] ?? ''));
        $pats = $by_an[$an] ?? [];
        if (empty($pats)) {
            continue;
        }
        $level = (($alert['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
        $drug = trim((string)($alert['hme_drug_name'] ?? $alert['hme_icode'] ?? ''));
        $line = $drug . ' — ซ้ำกับยา OPD ก่อน admit (เหลือ ' . trim((string)($alert['remaining_text'] ?? '')) . ')';
        foreach ($pats as $pat) {
            $keys = [];
            foreach (sp_patient_screen_key_variants($pat, $screen_date) as $k) {
                $keys[$k] = true;
            }
            $keys[sp_patient_di_key($pat, $screen_date)] = true;
            $key_list = array_keys($keys);
            sp_extra_mark_has_drug($has_drug, $key_list);
            foreach ($key_list as $k) {
                sp_extra_push_alert($bucket, $k, $level, $line, $alert);
            }
        }
    }
    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/** ยาเหลือ OPD — ใบยาวันนี้ซ้ำกับยาเดิมที่ยังเหลือ (OPD เท่านั้น) */
function sp_batch_opd_dup_map($con, $hos, $screen_date, array $patients) {
    if (!function_exists('mopd_get_config')) {
        require_once __DIR__ . '/monitor_opd_dup_helper.php';
    }
    $cfg = mopd_get_config($con);
    if (empty($cfg['monitor_active'])) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $opd_pats = [];
    $hn_list = [];
    $by_vn = [];
    $by_hn = [];
    foreach ($patients as $p) {
        if (trim((string)($p['an'] ?? '')) !== '') {
            continue;
        }
        $vn = trim((string)($p['vn'] ?? ''));
        if ($vn === '') {
            continue;
        }
        $opd_pats[] = $p;
        $hn = trim((string)($p['hn'] ?? ''));
        if ($hn !== '') {
            $hn_list[$hn] = true;
        }
        $by_vn[$vn][] = $p;
        $hn_disp = ltrim($hn, '0') ?: $hn;
        if ($hn_disp !== '') {
            $by_hn[$hn_disp][] = $p;
        }
    }
    if (empty($opd_pats) || empty($hn_list)) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => []];
    }
    try {
        $scan = mopd_scan($con, $hos, $screen_date, $screen_date, 0, 1, array_keys($hn_list));
    } catch (Throwable $e) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => [], 'error' => $e->getMessage()];
    }
    $bucket = [];
    $has_drug = [];
    foreach ($opd_pats as $pat) {
        $keys = [];
        foreach (sp_patient_screen_key_variants($pat, $screen_date) as $k) {
            $keys[$k] = true;
        }
        $keys[sp_patient_di_key($pat, $screen_date)] = true;
        sp_extra_mark_has_drug($has_drug, array_keys($keys));
    }
    $alerts = array_merge($scan['hard_alerts'] ?? [], $scan['soft_alerts'] ?? []);
    foreach ($alerts as $alert) {
        $vn = trim((string)($alert['an'] ?? $alert['vn'] ?? ''));
        $pats = $vn !== '' ? ($by_vn[$vn] ?? []) : [];
        if (empty($pats)) {
            $hn = ltrim((string)($alert['hn'] ?? ''), '0') ?: (string)($alert['hn'] ?? '');
            $pats = $hn !== '' ? ($by_hn[$hn] ?? []) : [];
        }
        if (empty($pats)) {
            continue;
        }
        $level = (($alert['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
        $drug = trim((string)($alert['hme_drug_name'] ?? $alert['hme_icode'] ?? ''));
        $remain = trim((string)($alert['remaining_text'] ?? ''));
        $line = $drug . ' — ซ้ำกับยาเดิมที่ยังเหลือ' . ($remain !== '' ? ' (เหลือ ' . $remain . ')' : '');
        foreach ($pats as $pat) {
            $keys = [];
            foreach (sp_patient_screen_key_variants($pat, $screen_date) as $k) {
                $keys[$k] = true;
            }
            $keys[sp_patient_di_key($pat, $screen_date)] = true;
            $key_list = array_keys($keys);
            sp_extra_mark_has_drug($has_drug, $key_list);
            foreach ($key_list as $k) {
                sp_extra_push_alert($bucket, $k, $level, $line, $alert);
            }
        }
    }
    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/** ยาปฏิชีวนะฉีด IPD ใช้ต่อเนื่องเกินเกณฑ์ — IPD เท่านั้น */
function sp_batch_antibiotic_map($con, $hos, $screen_date, array $patients) {
    $cfg = mab_get_config($con);
    if (empty($cfg['monitor_active'])) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $by_an = [];
    $by_hn = [];
    foreach ($patients as $p) {
        $an = trim((string)($p['an'] ?? ''));
        if ($an !== '') {
            $by_an[$an][] = $p;
        }
        $hn = ltrim((string)($p['hn'] ?? ''), '0') ?: (string)($p['hn'] ?? '');
        if ($hn !== '') {
            $by_hn[$hn][] = $p;
        }
    }
    if (empty($by_an) && empty($by_hn)) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => []];
    }
    try {
        $scan = mab_scan($con, $hos, [
            'an_list' => array_keys($by_an),
            'attach_consults' => false,
        ]);
    } catch (Throwable $e) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => [], 'error' => $e->getMessage()];
    }
    $bucket = [];
    $has_drug = [];
    foreach ($patients as $pat) {
        if (trim((string)($pat['an'] ?? '')) === '') {
            continue;
        }
        $keys = [];
        foreach (sp_patient_screen_key_variants($pat, $screen_date) as $k) {
            $keys[$k] = true;
        }
        $keys[sp_patient_di_key($pat, $screen_date)] = true;
        sp_extra_mark_has_drug($has_drug, array_keys($keys));
    }
    $min = (int)($cfg['min_duration_days'] ?? 10);
    foreach (($scan['items'] ?? []) as $it) {
        $an = trim((string)($it['an'] ?? ''));
        $pats = $an !== '' ? ($by_an[$an] ?? []) : [];
        if (empty($pats)) {
            $hn = ltrim((string)($it['hn'] ?? ''), '0') ?: (string)($it['hn'] ?? '');
            $pats = $hn !== '' ? ($by_hn[$hn] ?? []) : [];
        }
        if (empty($pats)) {
            continue;
        }
        $level = (($it['alert_level'] ?? $cfg['alert_level'] ?? 'soft') === 'hard') ? 'hard' : 'soft';
        $drug = trim((string)($it['drug'] ?? $it['icode'] ?? ''));
        $dur = (int)($it['duration'] ?? 0);
        $line = $drug . ' — ยาปฏิชีวนะฉีดใช้ต่อเนื่อง ' . $dur . ' วัน (เกณฑ์ > ' . $min . ' วัน)';
        foreach ($pats as $pat) {
            $keys = [];
            foreach (sp_patient_screen_key_variants($pat, $screen_date) as $k) {
                $keys[$k] = true;
            }
            $keys[sp_patient_di_key($pat, $screen_date)] = true;
            $key_list = array_keys($keys);
            sp_extra_mark_has_drug($has_drug, $key_list);
            foreach ($key_list as $k) {
                sp_extra_push_alert($bucket, $k, $level, $line, $it);
            }
        }
    }
    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

/** คู่ยาซ้ำซ้อน (Therapeutic Duplication) — ใช้เส้นทางเดียวกับ monitor_dup_therapy (ดึงใบยาเบาๆ เป็นชุด) */
function sp_batch_dup_therapy_map($con, $hos, $screen_date, array $patients) {
    if (!function_exists('mdt_load_active_rules')) {
        require_once __DIR__ . '/monitor_dup_therapy_helper.php';
    }
    try {
        mdt_ensure_table($con, false);
        $rules = mdt_load_active_rules($con);
        if (empty($rules)) {
            return ['no_rules' => true, 'results' => [], 'has_drug' => []];
        }
        $hn_list = sp_extract_hn_list($patients);
        if (empty($hn_list)) {
            return ['no_rules' => false, 'results' => [], 'has_drug' => []];
        }
        $screened = mdt_screen_rules(
            $hos,
            $rules,
            $screen_date,
            $screen_date,
            mdt_get_filter_config($con),
            $hn_list,
            ['skip_patient_enrich' => true]
        );
        if (!empty($screened['error'])) {
            return ['no_rules' => false, 'results' => [], 'has_drug' => [], 'error' => $screened['error']];
        }
        $by_hn = sp_extra_index_patients_by_hn($patients);
        $has_drug = [];
        foreach (($screened['matched_hns'] ?? []) as $hn) {
            $keys = sp_extra_order_patient_keys([
                'hn' => $hn,
                'vn' => '',
                'an' => '',
            ], $screen_date, $by_hn);
            sp_extra_mark_has_drug($has_drug, $keys);
        }
        $bucket = [];
        foreach (array_merge($screened['hard_alerts'] ?? [], $screened['soft_alerts'] ?? []) as $item) {
            $level = (($item['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
            $keys = sp_extra_order_patient_keys([
                'hn' => $item['hn_full'] ?? $item['hn'] ?? '',
                'vn' => $item['vn'] ?? '',
                'an' => $item['an'] ?? '',
            ], $screen_date, $by_hn);
            if (empty($keys)) {
                continue;
            }
            $msg = trim((string)($item['alert_message'] ?? '')) ?: ('พบคู่ยาซ้ำซ้อน: ' . ($item['pair_label'] ?? ''));
            $da = trim((string)($item['drugs_a'] ?? ''));
            $db = trim((string)($item['drugs_b'] ?? ''));
            $line = $msg;
            if ($da !== '' || $db !== '') {
                $line .= ' — ' . $da . ($da !== '' && $db !== '' ? ' + ' : '') . $db;
            }
            foreach ($keys as $pkey) {
                sp_extra_push_alert($bucket, $pkey, $level, $line, [
                    'rule_key' => $item['rule_key'] ?? '',
                    'pair_label' => $item['pair_label'] ?? '',
                    'drugs_a' => $da,
                    'drugs_b' => $db,
                ]);
            }
        }
        return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
    } catch (Throwable $e) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => [], 'error' => $e->getMessage()];
    }
}

function sp_amr_drug_load_helpers() {
    static $ok = null;
    if ($ok !== null) {
        return $ok;
    }
    foreach ([
        __DIR__ . '/amr_helper.php',
        __DIR__ . '/amr_dictionary_helper.php',
        __DIR__ . '/amr_sensitivity_helper.php',
        __DIR__ . '/monitor_lab_renal_dosing_helper.php',
        __DIR__ . '/monitor_amr_drug_helper.php',
    ] as $f) {
        if (!is_file($f)) {
            $ok = false;
            return $ok;
        }
        require_once $f;
    }
    $ok = function_exists('mad_scan');
    return $ok;
}

function sp_amr_drug_alert_line(array $row, $kind) {
    $drug = trim((string)($row['drugName'] ?? $row['generic_name'] ?? $row['icode'] ?? ''));
    $org = trim((string)($row['microtype'] ?? $row['result'] ?? ''));
    $org_bit = $org !== '' ? ' ต่อ ' . $org : '';
    if ($kind === 'R') {
        $line = $drug . ' — ไม่เหมาะสม (R)' . $org_bit;
        if (!empty($row['need_escalate'])) {
            $line .= ' · ควรเปลี่ยนยา';
        }
        return $line;
    }
    if ($kind === 'I') {
        return $drug . ' — ระวัง (I)' . $org_bit;
    }
    if ($kind === 'deesc') {
        return $drug . ' — สามารถ De-escalate';
    }
    if ($kind === 'renal_avoid') {
        return $drug . ' — ควรหลีกเลี่ยงตามไต';
    }
    return $drug . ' — ควรปรับขนาดตามไต';
}

/** Monitor AMR Drug — ยาปฏิชีวนะ IPD เทียบ AST (R/I/Escalate/ไต) */
function sp_batch_amr_drug_map($con, $hos, $screen_date, array $patients) {
    if (!sp_amr_drug_load_helpers()) {
        return ['no_rules' => true, 'results' => [], 'has_drug' => []];
    }
    $by_an = [];
    $by_hn = [];
    foreach ($patients as $p) {
        $an = preg_replace('/\D+/', '', (string)($p['an'] ?? ''));
        if ($an === '') {
            continue;
        }
        $by_an[$an][] = $p;
        $hn = ltrim((string)($p['hn'] ?? ''), '0') ?: (string)($p['hn'] ?? '');
        if ($hn !== '') {
            $by_hn[$hn][] = $p;
        }
    }
    if (empty($by_an)) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => []];
    }
    try {
        $scan = mad_scan($hos, $con, '30d', array_keys($by_an), $screen_date);
    } catch (Throwable $e) {
        return ['no_rules' => false, 'results' => [], 'has_drug' => [], 'error' => $e->getMessage()];
    }
    $bucket = [];
    $has_drug = [];
    foreach ($patients as $pat) {
        if (preg_replace('/\D+/', '', (string)($pat['an'] ?? '')) === '') {
            continue;
        }
        $keys = [];
        foreach (sp_patient_screen_key_variants($pat, $screen_date) as $k) {
            $keys[$k] = true;
        }
        $keys[sp_patient_di_key($pat, $screen_date)] = true;
        sp_extra_mark_has_drug($has_drug, array_keys($keys));
    }

    $push = static function (array $rows, $level, $kind) use (&$bucket, &$has_drug, $by_an, $by_hn, $screen_date) {
        foreach ($rows as $row) {
            $an = preg_replace('/\D+/', '', (string)($row['an'] ?? ''));
            $pats = $an !== '' ? ($by_an[$an] ?? []) : [];
            if (empty($pats)) {
                $hn = ltrim((string)($row['hn'] ?? ''), '0') ?: (string)($row['hn'] ?? '');
                $pats = $hn !== '' ? ($by_hn[$hn] ?? []) : [];
            }
            if (empty($pats)) {
                continue;
            }
            $line = sp_amr_drug_alert_line($row, $kind);
            foreach ($pats as $pat) {
                $keys = [];
                foreach (sp_patient_screen_key_variants($pat, $screen_date) as $k) {
                    $keys[$k] = true;
                }
                $keys[sp_patient_di_key($pat, $screen_date)] = true;
                $key_list = array_keys($keys);
                sp_extra_mark_has_drug($has_drug, $key_list);
                foreach ($key_list as $k) {
                    sp_extra_push_alert($bucket, $k, $level, $line, $row);
                }
            }
        }
    };

    $push($scan['rows'] ?? [], 'hard', 'R');
    $push($scan['rows_caution'] ?? [], 'soft', 'I');
    $push($scan['rows_deescalate'] ?? [], 'soft', 'deesc');
    foreach (($scan['rows_renal'] ?? []) as $row) {
        $st = (string)($row['renal']['status'] ?? '');
        if ($st === 'avoid') {
            $push([$row], 'hard', 'renal_avoid');
        } elseif ($st === 'adjust') {
            $push([$row], 'soft', 'renal_adjust');
        }
    }

    return ['no_rules' => false, 'results' => sp_extra_finalize_bucket($bucket), 'has_drug' => $has_drug];
}

function sp_screen_extra_cached(array $ctx, $module_key, $pkey, array $patient = [], $screen_date = '') {
    $batch = $ctx[$module_key] ?? null;
    if (!$batch || !empty($batch['no_rules'])) {
        return sp_result_na('ยังไม่ตั้งกฎ');
    }
    foreach (array_merge([$pkey], sp_patient_screen_key_variants($patient, $screen_date), sp_di_batch_lookup_keys($patient, $screen_date)) as $k) {
        if (!empty($batch['results'][$k])) {
            return $batch['results'][$k];
        }
    }
    foreach (array_merge([$pkey], sp_patient_screen_key_variants($patient, $screen_date), sp_di_batch_lookup_keys($patient, $screen_date)) as $k) {
        if (!empty($batch['has_drug'][$k])) {
            return sp_result_pass('ไม่เข้าเงื่อนไข');
        }
    }
    return sp_result_na('ไม่มียาในกลุ่มนี้');
}
