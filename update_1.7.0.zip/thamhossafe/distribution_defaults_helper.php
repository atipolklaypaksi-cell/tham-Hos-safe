<?php
/**
 * ค่าเริ่มต้นสำหรับแพ็กกระจาย รพ.อื่น
 * เปิดด้วย: environment THAM_DISTRIBUTION=1 หรือ define('THAM_DISTRIBUTION', true)
 * จะ seed ครั้งเดียว (sys_config feat_distribution_seeded=1) — ปิด Sheet/ระบบเสริมที่เป็น optional
 */

function tham_distribution_mode_on() {
    if (defined('THAM_DISTRIBUTION') && THAM_DISTRIBUTION) {
        return true;
    }
    $env = getenv('THAM_DISTRIBUTION');
    return $env === '1' || strtolower((string)$env) === 'true' || strtolower((string)$env) === 'yes';
}

function tham_distribution_seed_defaults($con) {
    if (!$con || !tham_distribution_mode_on()) {
        return false;
    }
    if (!is_file(__DIR__ . '/integrations_hub_helper.php')) {
        return false;
    }
    require_once __DIR__ . '/integrations_hub_helper.php';
    if (ih_sys_get($con, 'feat_distribution_seeded', '') === '1') {
        return false;
    }

    // ปิดของเสริมที่มักไม่มีใน รพ.อื่น — HOSxP คงเปิด
    $off = [
        'hosoffice',
        'jhcis',
        'drug_viewer',
        'robot',
        'hapysure',
        'invc',
        'google_sheet_invc',
        'google_sheet_allergy',
        'hospital_ds',
        'amr',
        'provider_id',
        'hosxp_master',
    ];
    foreach ($off as $code) {
        ih_set_enabled($con, $code, false);
    }
    ih_sys_set($con, 'invc_gsheet_enabled', '0');
    ih_sys_set($con, 'feat_distribution_seeded', '1');
    return true;
}
