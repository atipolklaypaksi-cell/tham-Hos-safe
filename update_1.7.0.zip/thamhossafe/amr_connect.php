<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/amr_mlab_helper.php';
mysqli_set_charset($con, 'utf8');
amr_mlab_ensure_tables($con);
$cfg = amr_mlab_get_config($con);
$sync = amr_mlab_last_sync($con);
$last = $sync['last'] ?? null;
$interval_opts = amr_mlab_sync_interval_options();
$sync_interval = amr_mlab_norm_sync_interval($cfg['sync_interval_min'] ?? 10);
$sync_interval_label = amr_mlab_sync_interval_label($sync_interval);
$cron_url = (isset($_SERVER['REQUEST_SCHEME']) ? $_SERVER['REQUEST_SCHEME'] : 'http')
    . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')
    . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/thamhossafe'), '/')
    . '/cron_amr_mlab_sync.php?key=' . rawurlencode($cfg['cron_secret'] ?? '');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>เชื่อมต่อ AMR - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background: #f4f7f6; }
        .amr-hero {
            background: linear-gradient(135deg, #1f4d3b 0%, #146c4a 100%);
            color: #fff; border-radius: 16px; padding: 1.2rem 1.4rem; margin-bottom: 1.1rem;
        }
        .src-card { border: 2px solid #d7e4dc; border-radius: 12px; padding: 14px; cursor: pointer; height: 100%; background: #fff; }
        .src-card.active { border-color: #1f4d3b; background: #f3faf6; box-shadow: 0 0 0 3px rgba(31,77,59,.12); }
        .src-card h6 { font-weight: 800; }
        code.cron { font-size: .78rem; word-break: break-all; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="amr-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="small text-uppercase" style="letter-spacing:.08em;opacity:.75;">ตั้งค่าระบบ · AMR</div>
                    <h4 class="fw-bold mb-1">เชื่อมต่อ AMR / mLAB</h4>
                    <p class="mb-0 small" style="opacity:.9;">เลือกดึงผลเพาะเชื้อผ่าน HOSxP หรือเชื่อมฐาน mLAB โดยตรง แล้วซิงก์เข้า THAM Hos-Safe</p>
                </div>
                <a href="amr_dashboard.php" class="btn btn-light btn-sm"><i class="fas fa-chart-area me-1"></i>Dashboard</a>
            </div>

            <form id="amrConnForm">
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body">
                        <h6 class="fw-bold mb-3"><i class="fas fa-plug me-2 text-success"></i>แหล่งข้อมูล AMR</h6>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="src-card <?php echo ($cfg['source'] ?? '') !== 'mlab' ? 'active' : ''; ?>" id="cardHosxp">
                                    <input type="radio" class="form-check-input me-2" name="source" value="hosxp" <?php echo ($cfg['source'] ?? '') !== 'mlab' ? 'checked' : ''; ?>>
                                    <h6 class="d-inline"><i class="fas fa-hospital me-1"></i> ผ่าน HOSxP</h6>
                                    <div class="small text-muted mt-2 mb-0">ใช้ <code>lab_head.result_rtf</code> จากฐาน HOSxP ตามการตั้งค่า «เชื่อมต่อ HOSxP» — แบบเดิม</div>
                                </label>
                            </div>
                            <div class="col-md-6">
                                <label class="src-card <?php echo ($cfg['source'] ?? '') === 'mlab' ? 'active' : ''; ?>" id="cardMlab">
                                    <input type="radio" class="form-check-input me-2" name="source" value="mlab" <?php echo ($cfg['source'] ?? '') === 'mlab' ? 'checked' : ''; ?>>
                                    <h6 class="d-inline"><i class="fas fa-database me-1"></i> ฐานข้อมูล mLAB โดยตรง</h6>
                                    <div class="small text-muted mt-2 mb-0">ซิงก์ไฟล์ DBF เข้าตาราง <code>amr_mlab_lab</code> / <code>amr_mlab_ast</code> ในฐาน THAM Hos-Safe — Dashboard อ่านจากตารางนี้ ไม่ได้อ่านไฟล์ DBF ตอนโหลดข้อมูล</div>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card shadow-sm border-0 mb-3" id="mlabBox">
                    <div class="card-body">
                        <div class="alert alert-warning py-2 px-3 small mb-3">
                            ไฟล์ mLAB เป็น FoxPro (<code>SP.DBF</code> <code>OR.DBF</code> <code>CODE.DBF</code>) เก็บได้ทั้ง Windows และ Linux
                            THAM Hos-Safe อ่านจากพาธบนเครื่องที่รันเว็บ หรือดึงผ่านแชร์ SMB แล้วซิงก์เข้า MySQL
                        </div>
                        <h6 class="fw-bold mb-2"><i class="fas fa-server me-2 text-success"></i>วิธีเก็บไฟล์ mLAB ของโรงพยาบาลนี้</h6>
                        <div class="row g-2 mb-3">
                            <div class="col-md-3">
                                <label class="src-card py-2 <?php echo ($cfg['dbf_mode'] ?? 'auto') === 'auto' ? 'active' : ''; ?>" id="modeAuto">
                                    <input type="radio" class="form-check-input me-1" name="dbf_mode" value="auto" <?php echo ($cfg['dbf_mode'] ?? 'auto') === 'auto' ? 'checked' : ''; ?>>
                                    <span class="fw-bold">อัตโนมัติ</span>
                                    <div class="small text-muted mt-1 mb-0">เดาจากพอร์ต 445 / 3306 และพาธที่กรอก</div>
                                </label>
                            </div>
                            <div class="col-md-3">
                                <label class="src-card py-2 <?php echo ($cfg['dbf_mode'] ?? '') === 'smb' ? 'active' : ''; ?>" id="modeSmb">
                                    <input type="radio" class="form-check-input me-1" name="dbf_mode" value="smb" <?php echo ($cfg['dbf_mode'] ?? '') === 'smb' ? 'checked' : ''; ?>>
                                    <span class="fw-bold">Windows / Samba</span>
                                    <div class="small text-muted mt-1 mb-0">ดึงจากแชร์ไฟล์ เช่น <code>//IP/C/MLAB/DATA</code></div>
                                </label>
                            </div>
                            <div class="col-md-3">
                                <label class="src-card py-2 <?php echo ($cfg['dbf_mode'] ?? '') === 'local' ? 'active' : ''; ?>" id="modeLocal">
                                    <input type="radio" class="form-check-input me-1" name="dbf_mode" value="local" <?php echo ($cfg['dbf_mode'] ?? '') === 'local' ? 'checked' : ''; ?>>
                                    <span class="fw-bold">โฟลเดอร์ Linux / NFS</span>
                                    <div class="small text-muted mt-1 mb-0">อ่านพาธตรง เช่น <code>/var/mlab/DATA</code></div>
                                </label>
                            </div>
                            <div class="col-md-3">
                                <label class="src-card py-2 <?php echo ($cfg['dbf_mode'] ?? '') === 'mysql' ? 'active' : ''; ?>" id="modeMysql">
                                    <input type="radio" class="form-check-input me-1" name="dbf_mode" value="mysql" <?php echo ($cfg['dbf_mode'] ?? '') === 'mysql' ? 'checked' : ''; ?>>
                                    <span class="fw-bold">MySQL</span>
                                    <div class="small text-muted mt-1 mb-0">ฐาน mLAB เป็น MySQL แล้ว</div>
                                </label>
                            </div>
                        </div>

                        <h6 class="fw-bold mb-3"><i class="fas fa-network-wired me-2 text-primary"></i>Host / บัญชี (MySQL หรือแชร์ SMB)</h6>
                        <div class="row g-3 mb-3">
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Host / IP</label>
                                <input type="text" class="form-control form-control-sm" name="host" id="mlab_host" value="<?php echo htmlspecialchars($cfg['host']); ?>" placeholder="เช่น 192.168.1.20">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold">Port</label>
                                <input type="number" class="form-control form-control-sm" name="port" id="mlab_port" value="<?php echo htmlspecialchars($cfg['port']); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold">Database</label>
                                <input type="text" class="form-control form-control-sm" name="db" id="mlab_db" value="<?php echo htmlspecialchars($cfg['db']); ?>" placeholder="เช่น mlab">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold">Username</label>
                                <input type="text" class="form-control form-control-sm" name="user" id="mlab_user" value="<?php echo htmlspecialchars($cfg['user']); ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Password</label>
                                <input type="password" class="form-control form-control-sm" name="pass" id="mlab_pass" value="<?php echo $cfg['pass'] !== '' ? '********' : ''; ?>" autocomplete="new-password">
                                <div class="form-text">เว้น ******** ไว้ถ้าไม่ต้องการเปลี่ยนรหัส</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">ดึงย้อนหลังครั้งแรก (วัน)</label>
                                <input type="number" class="form-control form-control-sm" name="lookback_days" min="7" max="3650" value="<?php echo htmlspecialchars($cfg['lookback_days']); ?>">
                            </div>
                        </div>

                        <h6 class="fw-bold mb-2 mt-2"><i class="fas fa-folder-open me-2 text-warning"></i>ไฟล์ DBF</h6>
                        <p class="small text-muted mb-2">Windows ใช้แชร์ด้านล่าง · Linux/NFS ใส่พาธที่เซิร์ฟเวอร์ THAM อ่านได้โดยตรง</p>
                        <div class="row g-3" id="smbFields">
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">ชื่อแชร์ SMB</label>
                                <input type="text" class="form-control form-control-sm" name="smb_share" id="mlab_smb_share" value="<?php echo htmlspecialchars($cfg['smb_share']); ?>" placeholder="Windows: C · Linux Samba: mlab">
                            </div>
                            <div class="col-md-8">
                                <label class="form-label small fw-bold">โฟลเดอร์ในแชร์</label>
                                <input type="text" class="form-control form-control-sm" name="smb_remote" id="mlab_smb_remote" value="<?php echo htmlspecialchars($cfg['smb_remote']); ?>" placeholder="เช่น MLAB/DATA หรือ DATA">
                            </div>
                        </div>
                        <div class="row g-3 mt-0">
                            <div class="col-md-8">
                                <label class="form-label small fw-bold">พาธโฟลเดอร์ DATA บนเซิร์ฟเวอร์ THAM</label>
                                <input type="text" class="form-control form-control-sm" name="dbf_path" id="mlab_dbf" value="<?php echo htmlspecialchars($cfg['dbf_path']); ?>" placeholder="เช่น /var/mlab/DATA หรือ /mnt/mlab/DATA">
                                <div class="form-text">โหมด SMB ไม่ต้องใส่พาธนี้ ระบบเก็บสำเนาที่โฟลเดอร์ <code>mlab_DATA</code> ของโปรเจกต์เอง (ใน Docker คือ <code>/var/www/html/mlab_DATA</code>) · โหมด Linux/NFS ค่อยใส่พาธที่ PHP ในคอนเทนเนอร์มองเห็น</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body">
                        <h6 class="fw-bold mb-3" id="syncIntervalTitle"><i class="fas fa-sync-alt me-2"></i>ซิงก์อัตโนมัติทุก <?php echo htmlspecialchars($sync_interval_label); ?></h6>
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" role="switch" name="sync_enabled" id="syncEnabled" value="1" <?php echo ($cfg['sync_enabled'] ?? '') === '1' ? 'checked' : ''; ?>>
                            <label class="form-check-label fw-bold" for="syncEnabled">เปิดซิงก์ข้อมูลใหม่เข้า THAM Hos-Safe อัตโนมัติ</label>
                        </div>
                        <div class="row g-3 mb-3">
                            <div class="col-md-4">
                                <label class="form-label small fw-bold" for="syncInterval">ความถี่ซิงก์อัตโนมัติ</label>
                                <select class="form-select form-select-sm" name="sync_interval_min" id="syncInterval">
                                    <?php foreach ($interval_opts as $mins => $label): ?>
                                        <option value="<?php echo (int)$mins; ?>" <?php echo $sync_interval === (int)$mins ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($label); ?><?php echo (int)$mins === 10 ? ' (ค่าเริ่มต้น)' : ''; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <p class="small text-muted mb-2">กดซิงก์แล้วข้อมูลถูกเก็บในฐาน THAM Hos-Safe ตาราง <code>amr_mlab_lab</code> / <code>amr_mlab_ast</code> · รอบอัตโนมัติดึงเฉพาะรายการใหม่หรือที่เพิ่งอัปเดต ไม่ดึงทั้งปีย้ำ · เซิร์ฟเวอร์ตรวจทุก 5 นาที แต่จะซิงก์จริงตามช่วงที่เลือก · เมื่อเลือกแหล่งนี้ Dashboard จะอ่านจากตาราง THAM แล้วแปลงผล S/I/R เป็น MRSA / ESBL / CRE / CRAB ให้เอง</p>
                        <div class="small text-muted mb-2">cron บนเซิร์ฟเวอร์ (ตรวจทุก 5 นาที):</div>
                        <pre class="bg-light border rounded p-2 cron mb-2">*/5 * * * * php <?php echo htmlspecialchars(__DIR__ . '/cron_amr_mlab_sync.php'); ?></pre>
                        <div class="small text-muted mb-1">หรือเรียกผ่าน HTTP:</div>
                        <pre class="bg-light border rounded p-2 cron" id="cronUrl"><?php echo htmlspecialchars($cron_url); ?></pre>
                        <div class="row g-3 mt-2 align-items-end">
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Cron secret</label>
                                <input type="text" class="form-control form-control-sm font-monospace" name="cron_secret" value="<?php echo htmlspecialchars($cfg['cron_secret']); ?>">
                            </div>
                            <div class="col-md-8 small text-muted" id="syncMeta">
                                <?php if ($last): ?>
                                    ซิงก์ล่าสุด: <?php echo htmlspecialchars($last['ended_at'] ?? $last['started_at'] ?? '-'); ?>
                                    · สถานะ <?php echo htmlspecialchars($last['status'] ?? ''); ?>
                                    · ใหม่ <?php echo (int)($last['inserted_n'] ?? 0); ?>
                                    · อัปเดต <?php echo (int)($last['updated_n'] ?? 0); ?>
                                    · ใบแล็บในระบบ <?php echo number_format((int)($sync['lab_count'] ?? 0)); ?>
                                    <?php if (!empty($sync['min_date'])): ?>
                                        · ช่วง <?php echo htmlspecialchars($sync['min_date']); ?> → <?php echo htmlspecialchars($sync['max_date'] ?? ''); ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    ยังไม่เคยซิงก์ · ใบแล็บในระบบ <?php echo number_format((int)($sync['lab_count'] ?? 0)); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex flex-wrap gap-2 mb-4">
                    <button type="submit" class="btn btn-success fw-bold" id="btnSave">
                        <i class="fas fa-save me-1"></i> บันทึก
                    </button>
                    <button type="button" class="btn btn-outline-primary fw-bold" id="btnTest">
                        <i class="fas fa-plug me-1"></i> ทดสอบการเชื่อมต่อ
                    </button>
                    <button type="button" class="btn btn-outline-secondary fw-bold" id="btnSync">
                        <i class="fas fa-cloud-download-alt me-1"></i> ซิงก์ข้อมูลใหม่ตอนนี้
                    </button>
                    <button type="button" class="btn btn-outline-warning fw-bold" id="btnSyncFull">
                        <i class="fas fa-history me-1"></i> ซิงก์ย้อนหลังครั้งแรก
                    </button>
                    <button type="button" class="btn btn-dark fw-bold" id="btnCloneAll">
                        <i class="fas fa-database me-1"></i> ดึงทั้งฐาน mLAB
                    </button>
                </div>
                <div id="cloneBox" class="card shadow-sm border-0 mb-3 d-none">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="fw-bold mb-0"><i class="fas fa-clone me-2"></i>ความคืบหน้าดึงทั้งฐาน</h6>
                            <span class="small text-muted" id="clonePct">0%</span>
                        </div>
                        <div class="progress mb-2" style="height:10px;">
                            <div class="progress-bar bg-success" id="cloneBar" role="progressbar" style="width:0%"></div>
                        </div>
                        <div class="small text-muted mb-2" id="cloneSummary"></div>
                        <pre class="bg-light border rounded p-2 small mb-0" id="cloneLog" style="max-height:220px;overflow:auto;"></pre>
                    </div>
                </div>
                <div id="amrConnMsg" class="small"></div>
                <div id="amrConnHint" class="alert alert-info small mt-2 d-none"></div>
            </form>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
function amrFormPayload() {
    const pass = $('#mlab_pass').val();
    const body = {
        source: $('input[name="source"]:checked').val() || 'hosxp',
        host: $('#mlab_host').val(),
        port: $('#mlab_port').val(),
        db: $('#mlab_db').val(),
        user: $('#mlab_user').val(),
        dbf_path: $('#mlab_dbf').val(),
        dbf_mode: $('input[name="dbf_mode"]:checked').val() || 'auto',
        smb_share: $('#mlab_smb_share').val(),
        smb_remote: $('#mlab_smb_remote').val(),
        lookback_days: $('input[name="lookback_days"]').val(),
        sync_enabled: $('#syncEnabled').is(':checked') ? 1 : 0,
        sync_interval_min: $('#syncInterval').val(),
        cron_secret: $('input[name="cron_secret"]').val()
    };
    if (pass && pass !== '********') body.pass = pass;
    return body;
}
function toggleSource() {
    const mlab = $('input[name="source"]:checked').val() === 'mlab';
    $('#mlabBox').toggleClass('opacity-50', !mlab);
    $('#cardHosxp').toggleClass('active', !mlab);
    $('#cardMlab').toggleClass('active', mlab);
}
function toggleDbfMode() {
    const mode = $('input[name="dbf_mode"]:checked').val() || 'auto';
    $('#modeAuto').toggleClass('active', mode === 'auto');
    $('#modeSmb').toggleClass('active', mode === 'smb');
    $('#modeLocal').toggleClass('active', mode === 'local');
    $('#modeMysql').toggleClass('active', mode === 'mysql');
    $('#smbFields').toggleClass('d-none', mode === 'local' || mode === 'mysql');
}
$('input[name="source"]').on('change', toggleSource);
$('input[name="dbf_mode"]').on('change', toggleDbfMode);
$('#syncInterval').on('change', function() {
    const t = $('#syncInterval option:selected').text().replace(/\s*\(ค่าเริ่มต้น\)\s*$/, '');
    $('#syncIntervalTitle').html('<i class="fas fa-sync-alt me-2"></i>ซิงก์อัตโนมัติทุก ' + t);
});
toggleSource();
toggleDbfMode();
function showMsg(ok, text, hint) {
    $('#amrConnMsg').attr('class', 'small fw-bold ' + (ok ? 'text-success' : 'text-danger')).text(text || '');
    if (hint) {
        $('#amrConnHint').removeClass('d-none').text(hint);
    } else {
        $('#amrConnHint').addClass('d-none').text('');
    }
}
function postAction(action, extra) {
    const body = Object.assign(amrFormPayload(), extra || {}, { action: action });
    return fetch('fetch_amr_connect_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(body)
    }).then(function(r) { return r.json(); });
}
$('#amrConnForm').on('submit', function(e) {
    e.preventDefault();
    const btn = $('#btnSave');
    btn.prop('disabled', true);
    postAction('save').then(function(res) {
        showMsg(res.status === 'success', res.message || 'บันทึกแล้ว');
    }).catch(function() {
        showMsg(false, 'บันทึกไม่สำเร็จ');
    }).finally(function() { btn.prop('disabled', false); });
});
$('#btnTest').on('click', function() {
    const btn = $(this);
    btn.prop('disabled', true);
    postAction('test').then(function(res) {
        const t = res.test || {};
        const bits = [];
        if (t.sql_message) bits.push('SQL: ' + t.sql_message);
        if (t.sql_tables && t.sql_tables.length) bits.push('ตาราง: ' + t.sql_tables.slice(0, 12).join(', '));
        if (t.dbf_message) bits.push('DBF: ' + t.dbf_message);
        if (t.dbf_files && t.dbf_files.length) bits.push(t.dbf_files.join(', '));
        showMsg(res.status === 'success', bits.join(' · ') || res.message, t.hint || '');
    }).catch(function() {
        showMsg(false, 'ทดสอบไม่สำเร็จ');
    }).finally(function() { btn.prop('disabled', false); });
});
function fmtSyncMeta(s, n, extra) {
    extra = extra || {};
    let t = '';
    if (s) {
        t = 'ซิงก์ล่าสุด: ' + (s.ended_at || s.started_at) + ' · ' + (s.status || '') + ' · ใหม่ ' + (s.inserted_n || 0) + ' · อัปเดต ' + (s.updated_n || 0) + ' · ใบแล็บในระบบ ' + (n || 0).toLocaleString();
    } else {
        t = 'ใบแล็บในระบบ ' + (n || 0).toLocaleString();
    }
    if (extra.min_date) t += ' · ช่วง ' + extra.min_date + ' → ' + (extra.max_date || '');
    return t;
}
function runSync(full) {
    showMsg(true, 'กำลังซิงก์...');
    postAction('sync', { full: full ? 1 : 0 }).then(function(res) {
        showMsg(res.status === 'success', res.message || 'ซิงก์เสร็จแล้ว');
        const s = (res.sync || {}).last;
        const n = (res.sync || {}).lab_count;
        $('#syncMeta').text(fmtSyncMeta(s, n, res.sync || {}));
    }).catch(function() {
        showMsg(false, 'ซิงก์ไม่สำเร็จ');
    });
}
$('#btnSync').on('click', function() { runSync(false); });
$('#btnSyncFull').on('click', function() { runSync(true); });

function cloneLog(line) {
    const el = document.getElementById('cloneLog');
    el.textContent += line + '\n';
    el.scrollTop = el.scrollHeight;
}
function cloneProgress(done, total) {
    const pct = total ? Math.round(100 * done / total) : 0;
    $('#cloneBar').css('width', pct + '%');
    $('#clonePct').text(pct + '% · ' + done + '/' + total);
}
async function runPool(items, limit, worker) {
    let i = 0;
    async function run() {
        while (i < items.length) {
            const idx = i++;
            await worker(items[idx], idx);
        }
    }
    const n = Math.min(limit, items.length);
    const jobs = [];
    for (let k = 0; k < n; k++) jobs.push(run());
    await Promise.all(jobs);
}
$('#btnCloneAll').on('click', async function() {
    if (!confirm('ดึงใบแล็บที่ยังขาดจาก mLAB เข้า THAM Hos-Safe (เดือนที่ครบแล้วจะข้าม)\nใช้เวลาตามจำนวนเดือนที่เหลือ อย่าปิดหน้านี้')) {
        return;
    }
    const btn = $(this);
    btn.prop('disabled', true);
    $('#btnSync, #btnSyncFull, #btnSave').prop('disabled', true);
    $('#cloneBox').removeClass('d-none');
    $('#cloneLog').text('');
    cloneProgress(0, 1);
    showMsg(true, 'กำลังดึงไฟล์จาก mLAB และนับจำนวนรายการตามปี...');
    cloneLog('กำลังดึง SMB และวางแผนช่วงปี...');
    let planRes;
    try {
        planRes = await postAction('clone_plan');
    } catch (e) {
        showMsg(false, 'วางแผนดึงทั้งฐานไม่สำเร็จ');
        btn.prop('disabled', false);
        $('#btnSync, #btnSyncFull, #btnSave').prop('disabled', false);
        return;
    }
    if (!planRes || planRes.status !== 'success' || !planRes.plan || !planRes.plan.ok) {
        showMsg(false, (planRes && planRes.message) || 'วางแผนไม่สำเร็จ');
        cloneLog((planRes && planRes.message) || 'ล้มเหลว');
        btn.prop('disabled', false);
        $('#btnSync, #btnSyncFull, #btnSave').prop('disabled', false);
        return;
    }
    const plan = planRes.plan;
    const allChunks = plan.chunks || [];
    const skippedReady = allChunks.filter(function(c) { return c.done; });
    const chunks = allChunks.filter(function(c) { return !c.done; });
    const thamN = plan.lab_count || 0;
    $('#cloneSummary').text(
        'mLAB ' + (plan.sp_nrec || 0).toLocaleString() + ' ใบ (' + (plan.min_date || '-') + ' → ' + (plan.max_date || '-') + ')'
        + ' · ใน THAM ตอนนี้ ' + thamN.toLocaleString() + ' ใบ'
        + (plan.tham_min ? ' (' + plan.tham_min + ' → ' + plan.tham_max + ')' : '')
        + ' · ข้าม ' + skippedReady.length + ' เดือนที่ครบ · เหลือ ' + chunks.length + ' เดือน ขนาน 2 ชุด'
    );
    cloneLog(plan.message || 'วางแผนแล้ว');
    cloneLog('ข้าม ' + skippedReady.length + ' เดือนที่มีข้อมูลครบแล้ว · เหลือ ' + chunks.length + ' เดือน');
    if (!chunks.length) {
        showMsg(true, 'ข้อมูลทั้งฐานครบแล้ว ไม่ต้องดึงซ้ำ');
        cloneLog('ไม่เหลือเดือนที่ต้องดึง');
        cloneProgress(1, 1);
        btn.prop('disabled', false);
        $('#btnSync, #btnSyncFull, #btnSave').prop('disabled', false);
        return;
    }
    showMsg(true, 'กำลังดึงเดือนที่ยังขาด ' + chunks.length + ' เดือน...');
    let done = 0;
    let okN = 0;
    let failN = 0;
    let skipN = skippedReady.length;
    let ins = 0;
    let upd = 0;
    cloneProgress(skipN, allChunks.length);
    await runPool(chunks, 2, async function(ch) {
        cloneLog('เริ่ม ' + ch.label + ' (~' + (ch.est || 0).toLocaleString() + ' ใบ · ในระบบแล้ว ' + (ch.have || 0).toLocaleString() + ')');
        let res = null;
        try {
            res = await postAction('clone_chunk', { start: ch.start, end: ch.end, label: ch.label, est: ch.est, skip_pull: 1 });
        } catch (e) {
            res = null;
        }
        if (!res || res.status !== 'success') {
            cloneLog('ลองใหม่ ' + ch.label);
            try {
                res = await postAction('clone_chunk', { start: ch.start, end: ch.end, label: ch.label, est: ch.est, skip_pull: 1 });
            } catch (e2) {
                res = null;
            }
        }
        done++;
        if (res && res.status === 'success') {
            okN++;
            const r = res.result || {};
            if (res.skipped) {
                skipN++;
                cloneLog('ข้าม ' + ch.label + ' · มีอยู่แล้ว ' + (r.skipped || ch.have || 0).toLocaleString() + ' ใบ');
            } else {
                ins += r.inserted || 0;
                upd += r.updated || 0;
                cloneLog('เสร็จ ' + ch.label + ' · ใหม่ ' + (r.inserted || 0) + ' · อัปเดต ' + (r.updated || 0));
            }
            const s = (res.sync || {}).last;
            $('#syncMeta').text(fmtSyncMeta(s, (res.sync || {}).lab_count, res.sync || {}));
        } else {
            failN++;
            cloneLog('ไม่สำเร็จ ' + ch.label + ' · ' + ((res && res.message) || 'timeout / เครือข่าย'));
        }
        cloneProgress(skippedReady.length + done, allChunks.length);
    });
    const msg = failN
        ? ('ดึงครบ ' + okN + '/' + chunks.length + ' เดือนที่เหลือ · ไม่สำเร็จ ' + failN + ' เดือน — กดปุ่มอีกครั้ง ระบบจะข้ามเดือนที่ครบแล้ว')
        : ('ดึงทั้งฐานเสร็จแล้ว · ใหม่ ' + ins.toLocaleString() + ' · อัปเดต ' + upd.toLocaleString() + ' · ข้าม ' + skipN.toLocaleString() + ' เดือน');
    showMsg(failN === 0, msg);
    cloneLog(msg);
    btn.prop('disabled', false);
    $('#btnSync, #btnSyncFull, #btnSave').prop('disabled', false);
});
</script>
</body>
</html>
