<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

$af_action_early = $_GET['action'] ?? $_POST['action'] ?? 'poll';
if ($af_action_early === 'poll') {
    if (!defined('THAM_LICENSE_NO_SESSION')) {
        define('THAM_LICENSE_NO_SESSION', true);
    }
    if (!defined('THAM_SKIP_UNIT_GATE')) {
        define('THAM_SKIP_UNIT_GATE', true);
    }
    session_write_close();
}

include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/allergy_followup_helper.php';
require_once __DIR__ . '/allergy_alert_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}

$role = $_SESSION['role'] ?? '';
$can_access = af_alert_can_manage_access($role);
$can_settings = af_alert_can_manage_settings($con, $role);
$eligible = af_alert_user_eligible($con, $role);
if (!$can_settings && !$eligible && !$can_access) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], JSON_UNESCAPED_UNICODE);
    exit;
}

$action = $af_action_early;
$flags = JSON_UNESCAPED_UNICODE;
$user_id = (int)$_SESSION['user_id'];

if ($action === 'role_access') {
    if (!$can_access && !tham_menu_can('allergy_alert_settings')) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], $flags);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'can_manage' => $can_access,
        'roles' => af_alert_get_role_access($con),
        'labels' => tham_menu_role_labels(),
    ], $flags);
    exit;
}

if ($action === 'save_role_access' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_access) {
        echo json_encode(['status' => 'error', 'message' => 'เฉพาะผู้ดูแลระบบปรับสิทธิ์ได้'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $roles = $raw['roles'] ?? $raw;
    if (!is_array($roles)) {
        echo json_encode(['status' => 'error', 'message' => 'ข้อมูลไม่ถูกต้อง'], $flags);
        exit;
    }
    $res = af_alert_save_role_access($con, $roles);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'roles' => $res['roles']], $flags);
    exit;
}

if ($action === 'save_room_config' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_settings) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $res = af_alert_save_room_config($con, $raw);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'rooms' => $res['rooms']], $flags);
    exit;
}

session_write_close();

if ($action === 'poll') {
    if (!$eligible) {
        echo json_encode([
            'status' => 'success',
            'eligible' => false,
            'pending' => 0,
            'cases' => [],
            'settings' => af_alert_get_settings($con, $user_id),
        ], $flags);
        exit;
    }
    $pending = af_alert_pending_cases($con);
    echo json_encode([
        'status' => 'success',
        'eligible' => true,
        'pending' => $pending['count'],
        'cases' => $pending['cases'],
        'settings' => af_alert_get_settings($con, $user_id),
    ], $flags);
    exit;
}

if ($action === 'get_settings') {
    echo json_encode([
        'status' => 'success',
        'eligible' => $eligible,
        'settings' => af_alert_get_settings($con, $user_id),
    ], $flags);
    exit;
}

if ($action === 'save_settings' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $res = af_alert_save_settings($con, $user_id, $raw);
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'บันทึกไม่สำเร็จ'], $flags);
        exit;
    }
    echo json_encode(['status' => 'success', 'settings' => $res['settings']], $flags);
    exit;
}

if ($action === 'telegram_notify') {
    if (!$can_settings && !tham_menu_can('allergy_alert_settings')) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], $flags);
        exit;
    }
    $sp_on = false;
    $chat_n = 0;
    if (is_file(__DIR__ . '/smart_pharma_notifications_helper.php')) {
        require_once __DIR__ . '/smart_pharma_notifications_helper.php';
        if (function_exists('sp_notifications_get_config')) {
            $cfg = sp_notifications_get_config($con);
            $sp_on = !empty($cfg['telegram_enabled']);
        }
    }
    if (is_file(__DIR__ . '/smart_pharma_telegram_helper.php')) {
        require_once __DIR__ . '/smart_pharma_telegram_helper.php';
        if (function_exists('sp_telegram_ensure_tables')) {
            sp_telegram_ensure_tables($con);
        }
        if (function_exists('sp_telegram_list_chats')) {
            foreach (sp_telegram_list_chats($con) as $c) {
                if (!empty($c['active'])) {
                    $chat_n++;
                }
            }
        }
    }
    echo json_encode([
        'status' => 'success',
        'telegram_notify' => af_telegram_notify_enabled($con),
        'smart_pharma_telegram' => $sp_on,
        'active_chats' => $chat_n,
    ], $flags);
    exit;
}

if ($action === 'save_telegram_notify' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_settings && !tham_menu_can('allergy_alert_settings')) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์'], $flags);
        exit;
    }
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }
    $enabled = !empty($raw['enabled']);
    af_set_telegram_notify($con, $enabled);
    echo json_encode([
        'status' => 'success',
        'telegram_notify' => af_telegram_notify_enabled($con),
    ], $flags);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'unknown action'], $flags);
