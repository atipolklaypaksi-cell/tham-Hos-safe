<?php
/**
 * ฟอร์มบันทึก Intervention ใช้ร่วมกันในหน้า Monitor
 * ตั้ง $mon_iv_module และ $mon_iv_title ก่อน include
 */
if (!isset($con) || !($con instanceof mysqli)) {
    return;
}
$mon_iv_module = trim((string)($mon_iv_module ?? ''));
$mon_iv_title = trim((string)($mon_iv_title ?? 'Monitor'));
if ($mon_iv_module === '') {
    return;
}
if (!function_exists('tham_list_consult_pharmacists')) {
    require_once __DIR__ . '/opduser_auth_helper.php';
}
$mon_iv_uid = (int)($_SESSION['user_id'] ?? 0);
$mon_iv_pharmacists = function_exists('tham_list_consult_pharmacists')
    ? tham_list_consult_pharmacists($con, $mon_iv_uid)
    : [];
?>
<div class="modal fade" id="monIvModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold"><i class="fas fa-notes-medical me-2 text-danger"></i>บันทึก Intervention — <?php echo htmlspecialchars($mon_iv_title, ENT_QUOTES, 'UTF-8'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="small text-muted mb-2" id="monIvCase"></div>
                <div class="border rounded p-2 mb-3 bg-light small" id="monIvSummary"></div>
                <div class="row g-2">
                    <div class="col-md-8">
                        <label class="form-label small fw-bold">เภสัชกรที่ Consult</label>
                        <select id="monIvPharmacist" class="form-select form-select-sm">
                            <?php if (empty($mon_iv_pharmacists)): ?>
                            <option value="<?php echo $mon_iv_uid; ?>"><?php echo htmlspecialchars(trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'ผู้ใช้ปัจจุบัน')), ENT_QUOTES, 'UTF-8'); ?></option>
                            <?php else: ?>
                            <?php foreach ($mon_iv_pharmacists as $ph):
                                $ph_name = trim((string)($ph['full_name'] ?: $ph['username']));
                                $ph_pos = trim((string)($ph['entryposition'] ?? ''));
                                $ph_label = $ph_pos !== '' ? ($ph_name . ' (' . $ph_pos . ')') : $ph_name;
                            ?>
                            <option value="<?php echo (int)$ph['id']; ?>"<?php echo ((int)$ph['id'] === $mon_iv_uid) ? ' selected' : ''; ?>><?php echo htmlspecialchars($ph_label, ENT_QUOTES, 'UTF-8'); ?></option>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold">รอตอบกลับ</label>
                        <select id="monIvWait" class="form-select form-select-sm">
                            <option value="0" selected>ทันที</option>
                            <?php for ($d = 1; $d <= 7; $d++): ?>
                            <option value="<?php echo $d; ?>"><?php echo $d; ?> วัน</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">การแทรกแซง</label>
                        <select id="monIvType" class="form-select form-select-sm">
                            <option value="recommend">แนะนำ / Consult</option>
                            <option value="adjust">ปรับยา</option>
                            <option value="reject">ไม่จ่าย / Hold</option>
                            <option value="followup">ติดตาม</option>
                            <option value="document">บันทึกเท่านั้น</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">ใช่ความคลาดเคลื่อนไหม</label>
                        <select id="monIvDeviation" class="form-select form-select-sm" onchange="AlertMute.sync('monIvDeviation')">
                            <option value="">— ไม่ระบุ —</option>
                            <option value="ความคลาดเคลื่อนจริง">ความคลาดเคลื่อนจริง</option>
                            <option value="ไม่ใช่ความคลาดเคลื่อน">ไม่ใช่ความคลาดเคลื่อน</option>
                        </select>
                        <?php require_once __DIR__ . '/monitor_alert_mute_ui.php'; monitor_alert_mute_box('monIvDeviation'); ?>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">หมายเหตุ</label>
                        <textarea id="monIvNote" class="form-control form-control-sm" rows="2" placeholder="รายละเอียดที่ต้องการบันทึกใน Intervention และใส่ในใบปรึกษา"></textarea>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">รายละเอียดหลัง Consult <span class="fw-normal text-muted">(บันทึกภายหลังได้ใน Intervention Report)</span></label>
                        <div class="d-flex flex-wrap gap-1 mb-1">
                            <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="MonIv.chip('แพทย์ Off')">แพทย์ Off</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="MonIv.chip('แพทย์ Hold')">แพทย์ Hold</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="MonIv.chip('แพทย์ลดขนาดยา')">แพทย์ลดขนาดยา</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="MonIv.chip('แพทย์ให้ยาต่อ')">แพทย์ให้ยาต่อ</button>
                            <button type="button" class="btn btn-outline-secondary btn-sm py-0" onclick="MonIv.chip('')">อื่นๆ</button>
                        </div>
                        <textarea id="monIvAfter" class="form-control form-control-sm" rows="2" placeholder="เลือกตัวช่วยด้านบน หรือพิมพ์รายละเอียดเอง"></textarea>
                    </div>
                </div>
                <div id="monIvMsg" class="alert mt-3 mb-0 py-2 small d-none"></div>
            </div>
            <div class="modal-footer flex-wrap">
                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">ปิดหน้าต่าง</button>
                <button type="button" class="btn btn-success btn-sm fw-bold" onclick="MonIv.save(true)">
                    <i class="fas fa-print me-1"></i> บันทึกและพิมพ์ใบปรึกษาแพทย์
                </button>
                <button type="button" class="btn btn-sm fw-bold text-white" style="background:#0d9488;" onclick="MonIv.save(false)">บันทึก Intervention</button>
            </div>
        </div>
    </div>
</div>
<script>
window.MonIv = (function () {
    var MODULE = <?php echo json_encode($mon_iv_module, JSON_UNESCAPED_UNICODE); ?>;
    var current = null;
    var modal = null;
    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
        });
    }
    function show(ok, text) {
        var el = document.getElementById('monIvMsg');
        if (!el) return;
        el.className = 'alert mt-3 mb-0 py-2 small ' + (ok ? 'alert-success' : 'alert-danger');
        el.textContent = text || '';
    }
    function chip(text) {
        var box = document.getElementById('monIvAfter');
        if (!box) return;
        var phrase = String(text || '').trim();
        if (!phrase) { box.focus(); return; }
        var cur = box.value.replace(/\s+$/, '');
        if (!cur) box.value = phrase + ' ';
        else if (cur.indexOf(phrase) === -1) box.value = cur + '\n' + phrase + ' ';
        box.focus();
    }
    function btn(item, summary) {
        item = item || {};
        var payload = {
            hn: item.hn_full || item.hn || '',
            vn: item.vn || item.opd_vn || '',
            an: item.an || item.prior_an || '',
            ptname: item.ptname || '',
            vstdate: String(item.order_date_iso || item.vstdate || item.order_date || item.rxdate || item.date || item.hme_date || '').slice(0, 10),
            alert_level: item.alert_level || 'soft',
            drug_name: item.drug_name || item.drug_name_tmt || item.hme_drug_name || item.drugs_a || '',
            alert_summary: summary || item.alert_summary || item.alert_message || item.detail_text || item.warning_msg || '',
            ward_name: item.ward_display || item.ward_name || '',
            type_patient: item.type_patient || ''
        };
        if (item.drugs_b) {
            payload.drug_name = (payload.drug_name ? payload.drug_name + ' + ' : '') + item.drugs_b;
        }
        return '<div class="mt-1"><button type="button" class="btn btn-sm btn-success fw-bold py-0 px-2" data-mon-iv="'
            + encodeURIComponent(JSON.stringify(payload))
            + '" onclick="MonIv.openBtn(this)"><i class="fas fa-notes-medical me-1"></i>บันทึก Intervention</button></div>';
    }
    function openBtn(el) {
        var raw = '';
        try { raw = decodeURIComponent(el.getAttribute('data-mon-iv') || ''); } catch (e) { raw = ''; }
        var data = {};
        try { data = JSON.parse(raw || '{}'); } catch (e2) { data = {}; }
        open(data);
    }
    function open(data) {
        current = data || {};
        document.getElementById('monIvType').value = 'recommend';
        document.getElementById('monIvDeviation').value = '';
        if (window.AlertMute) {
            AlertMute.set('monIvDeviation', {
                hn: current.hn || '',
                vn: current.vn || '',
                an: current.an || '',
                patient_type: current.type_patient || ''
            });
        }
        document.getElementById('monIvNote').value = '';
        document.getElementById('monIvAfter').value = '';
        document.getElementById('monIvCase').innerHTML = '<b>HN ' + esc(current.hn) + '</b>'
            + (current.ptname ? ' · ' + esc(current.ptname) : '')
            + (current.an ? ' · AN ' + esc(current.an) : '')
            + (current.vn ? ' · VN ' + esc(current.vn) : '');
        var sum = current.alert_summary || current.drug_name || '';
        document.getElementById('monIvSummary').textContent = sum || '—';
        show(true, '');
        document.getElementById('monIvMsg').classList.add('d-none');
        if (!modal && window.bootstrap) modal = new bootstrap.Modal(document.getElementById('monIvModal'));
        if (modal) modal.show();
    }
    function save(andPrint) {
        if (!current || !current.hn) { show(false, 'ไม่พบข้อมูลผู้ป่วย'); return; }
        var printWin = null;
        if (andPrint) printWin = window.open('about:blank', '_blank');
        var sel = document.getElementById('monIvPharmacist');
        var opt = sel.options[sel.selectedIndex];
        var body = new URLSearchParams();
        body.set('action', 'start');
        body.set('module_key', MODULE);
        body.set('hn', current.hn || '');
        body.set('vn', current.vn || '');
        body.set('an', current.an || '');
        body.set('ptname', current.ptname || '');
        body.set('vstdate', current.vstdate || '');
        body.set('alert_level', current.alert_level || 'soft');
        body.set('drug_name', current.drug_name || '');
        body.set('alert_summary', current.alert_summary || '');
        body.set('ward_name', current.ward_name || '');
        body.set('type_patient', current.type_patient || '');
        body.set('pharmacist_user_id', sel.value || '');
        body.set('pharmacist_name', opt ? opt.text.replace(/\s*\([^)]*\)\s*$/, '').trim() : '');
        body.set('intervention_type', document.getElementById('monIvType').value || 'recommend');
        body.set('deviation_category', document.getElementById('monIvDeviation').value || '');
        body.set('mute_visit', (window.AlertMute && AlertMute.checked('monIvDeviation')) ? '1' : '0');
        body.set('note_text', document.getElementById('monIvNote').value || '');
        body.set('consult_result', document.getElementById('monIvAfter').value || '');
        body.set('reply_wait_days', document.getElementById('monIvWait').value || '0');
        fetch('fetch_monitor_intervention_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        }).then(function (r) { return r.json(); }).then(function (res) {
            if (!res || res.status !== 'success') {
                if (printWin) printWin.close();
                show(false, (res && res.message) || 'บันทึกไม่สำเร็จ');
                return;
            }
            show(true, andPrint ? 'บันทึก Intervention และเปิดใบปรึกษาแล้ว' : 'บันทึก Intervention แล้ว');
            if (andPrint && res.print_url && printWin) {
                printWin.location = res.print_url + (res.print_url.indexOf('?') >= 0 ? '&' : '?') + 'autoprint=1';
            } else if (printWin) {
                printWin.close();
            }
        }).catch(function (e) {
            if (printWin) printWin.close();
            show(false, String(e));
        });
    }
    return { btn: btn, openBtn: openBtn, open: open, save: save, chip: chip };
})();
</script>
