<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_mg_ml_helper.php');
include(__DIR__ . '/dose_calculator_helper.php');
include(__DIR__ . '/monitor_dose_calculator_helper.php');
mysqli_set_charset($con, 'utf8');
mdc_ensure_table($con);
dc_ensure_tables($con);
set_time_limit(180);

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

function mdc_req($key, $default = '') {
    if (isset($_POST[$key])) {
        return is_string($_POST[$key]) ? trim($_POST[$key]) : $_POST[$key];
    }
    if (isset($_GET[$key])) {
        return is_string($_GET[$key]) ? trim($_GET[$key]) : $_GET[$key];
    }
    return $default;
}

$start_date = (string)mdc_req('start_date', date('Y-m-d', strtotime('-3 days')));
$end_date = (string)mdc_req('end_date', date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-3 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if (strtotime($start_date) > strtotime($end_date)) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$tol_raw = mdc_req('tolerance_pct', '');
$tol_pct = ($tol_raw === '' || $tol_raw === null)
    ? mdc_get_monitor_tolerance_pct($con)
    : mdc_clamp_tolerance_pct($tol_raw);

$rule_ids = [];
foreach (explode(',', (string)mdc_req('rule_ids', '')) as $rid) {
    $rid = (int)trim($rid);
    if ($rid > 0) {
        $rule_ids[] = $rid;
    }
}

header('Content-Type: application/json; charset=utf-8');
$rules = mdc_load_rules($con, $rule_ids, true);
if (empty($rules)) {
    ob_clean();
    echo json_encode([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'passed_items' => [],
        'unverifiable_items' => [],
        'meta' => ['message' => 'ยังไม่มีรายการยาที่เปิดใช้งาน — ไปตั้งค่า Monitor เครื่องคำนวณ', 'rule_count' => 0],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$hos = hosxp_connect($con);
if (!$hos) {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}

$t0 = microtime(true);
$rule_by_icode = mdc_build_rule_map_by_icode($rules);
$icode_list = array_keys($rule_by_icode);
if (empty($icode_list)) {
    mysqli_close($hos);
    ob_clean();
    echo json_encode([
        'status' => 'success',
        'hard_alerts' => [],
        'soft_alerts' => [],
        'passed_items' => [],
        'unverifiable_items' => [],
        'meta' => ['message' => 'ยังไม่ได้ผูก icode', 'rule_count' => count($rules)],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$order_limit = 4000;
$hn_raw = function_exists('monitor_req_hn') ? monitor_req_hn() : (string)mdc_req('hn', '');
$order_rows = mmgml_fetch_orders_lean($hos, $icode_list, $start_date, $end_date, 0, $order_limit, $hn_raw);
$truncated = count($order_rows) >= $order_limit;
$order_rows = mmgml_enrich_monitor_orders($hos, $order_rows);

$hn_for_vitals = [];
foreach ($order_rows as $row) {
    $hn = trim($row['hn'] ?? '');
    if ($hn !== '') {
        $hn_for_vitals[$hn] = true;
    }
}
$vitals_cache = [];
$dc_overrides = [];
if (!empty($hn_for_vitals)) {
    $vitals_cache = mmgml_prefetch_vitals($hos, $con, array_keys($hn_for_vitals), $start_date, $end_date, 365);
    $dc_overrides = dc_prefetch_vitals_overrides($con, array_keys($hn_for_vitals));
}

$age_map = [];
if (!empty($hn_for_vitals)) {
    $hnIn = mmgml_sql_in_strings($hos, array_keys($hn_for_vitals));
    if ($hnIn !== '') {
        $qage = mysqli_query($hos, "SELECT hn, birthday FROM patient WHERE hn IN ({$hnIn})");
        if ($qage) {
            $today = date('Y-m-d');
            while ($ar = mysqli_fetch_assoc($qage)) {
                $bd = trim((string)($ar['birthday'] ?? ''));
                if ($bd === '' || $bd === '0000-00-00') {
                    continue;
                }
                $age_map[(string)$ar['hn']] = function_exists('monitor_lab_patient_age_years')
                    ? (int)monitor_lab_patient_age_years($bd, $today) : null;
            }
        }
    }
}

$hard_alerts = [];
$soft_alerts = [];
$passed_items = [];
$unverifiable_items = [];
$seen = [];
$orders_scanned = 0;
$orders_checked = 0;

foreach ($order_rows as $row) {
    $orders_scanned++;
    $icode = trim($row['icode'] ?? '');
    $matched = $rule_by_icode[$icode] ?? [];
    if (!$matched) {
        continue;
    }
    $hn = trim((string)($row['hn'] ?? ''));
    $age = $age_map[$hn] ?? null;
    $method = trim(preg_replace('/\s+/u', ' ', (string)($row['method'] ?? '')));
    $order_date = !empty($row['rxdate']) ? $row['rxdate'] : ($row['vstdate'] ?? '');
    $weight_info = mmgml_get_weight_info_from_cache($vitals_cache, $hn, $order_date, 365);
    $weight_info = dc_merge_weight_override($weight_info, $dc_overrides, $hn);
    $bw = isset($weight_info['bw']) ? (float)$weight_info['bw'] : null;
    if ($bw !== null && $bw <= 0) {
        $bw = null;
    }

    foreach ($matched as $rule) {
        $orders_checked++;
        $item_tol = mdc_effective_tolerance_pct($rule, $tol_pct);
        $eval = mdc_evaluate_order($rule, [
            'method' => $method,
            'weight_kg' => $bw,
            'age' => $age,
            'qty' => isset($row['qty']) ? (float)$row['qty'] : null,
            'tolerance_pct' => $item_tol,
        ]);
        if (($eval['status'] ?? '') === 'skip') {
            continue;
        }
        $dedupe = implode('|', [$hn, $row['vn'] ?? '', $row['an'] ?? '', $icode, $row['item_no'] ?? '', $rule['id'] ?? '', $method]);
        if (isset($seen[$dedupe])) {
            continue;
        }
        $seen[$dedupe] = true;

        $type_patient = $row['type_patient'] ?? ((trim((string)($row['vn'] ?? '')) === '') ? 'IPD' : 'OPD');
        $ward = trim((string)($row['ward_name'] ?? ''));
        $bedno = trim((string)($row['bedno'] ?? ''));
        $ward_display = $type_patient === 'OPD' ? 'ผู้ป่วยนอก' : trim($ward . ($ward && $bedno ? ' / ' : '') . $bedno);
        if ($ward_display === '') {
            $ward_display = '-';
        }
        $rx_time = '';
        if (function_exists('di_format_time') && function_exists('monitor_lab_normalize_hosxp_time')) {
            $rx_time = di_format_time(monitor_lab_normalize_hosxp_time($row['rxtime'] ?? ''));
        }
        $meta = $rule['_meta'] ?? [];
        $item = [
            'hn' => $hn,
            'ptname' => $row['ptname'] ?? '',
            'icode' => $icode,
            'drug_name' => $row['drug_name'] ?? ($rule['drug_name'] ?? ''),
            'calc_type' => $rule['calc_type'] ?? '',
            'calc_label' => $meta['label'] ?? ($rule['calc_type'] ?? ''),
            'method' => $method,
            'type_patient' => $type_patient,
            'ward_display' => $ward_display,
            'rxdate' => $order_date,
            'order_date' => $order_date ? date('d/m/Y', strtotime($order_date)) : '-',
            'order_time' => $rx_time,
            'qty' => isset($row['qty']) ? (float)$row['qty'] : null,
            'age' => $age,
            'weight_kg' => $bw,
            'weight_source' => !empty($weight_info['source']) ? $weight_info['source'] : 'hosxp',
            'weight_vstdate' => $weight_info['vstdate'] ?? null,
            'found_display' => $eval['found_display'] ?? '—',
            'expected_display' => $eval['expected_display'] ?? '—',
            'suggest_value_text' => $eval['suggest_value_text'] ?? '',
            'alert_message' => $eval['message'] ?? '',
            'pass_message' => $eval['message'] ?? '',
            'dose_direction' => $eval['dose_direction'] ?? null,
            'tolerance_pct' => $item_tol,
        ];
        $st = $eval['status'] ?? '';
        if ($st === 'alert' && ($eval['level'] ?? '') === 'hard') {
            $hard_alerts[] = $item;
        } elseif ($st === 'alert') {
            $soft_alerts[] = $item;
        } elseif ($st === 'pass') {
            $passed_items[] = $item;
        } else {
            $unverifiable_items[] = $item;
        }
    }
}

mysqli_close($hos);
ob_clean();
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
echo json_encode([
    'status' => 'success',
    'hard_alerts' => sp_alert_mute_filter_rows($con, $hard_alerts),
    'soft_alerts' => sp_alert_mute_filter_rows($con, $soft_alerts),
    'passed_items' => $passed_items,
    'unverifiable_items' => $unverifiable_items,
    'meta' => [
        'rule_count' => count($rules),
        'matched_icodes' => count($icode_list),
        'orders_scanned' => $orders_scanned,
        'orders_checked' => $orders_checked,
        'elapsed_ms' => (int)round((microtime(true) - $t0) * 1000),
        'tolerance_pct' => $tol_pct,
        'truncated' => !empty($truncated),
        'start_date' => $start_date,
        'end_date' => $end_date,
    ],
], JSON_UNESCAPED_UNICODE);
