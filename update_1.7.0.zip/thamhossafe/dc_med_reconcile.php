<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/drug_center_helper.php';
mysqli_set_charset($con, 'utf8');

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
tham_menu_ensure_page_access('dc_med_reconcile.php');

$prefill_hn = htmlspecialchars($_GET['hn'] ?? '', ENT_QUOTES, 'UTF-8');
$default_hcode = htmlspecialchars(provider_oauth_session_hcode(), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Med Reconcile (Drugs Center) - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .patient-bar { background: #eef7f3; border: 1px solid #c5d4a0; border-radius: 8px; }
        .drug-table-wrap { max-height: 640px; overflow-y: auto; }
        .order-group-row td {
            background: #e9ecef !important;
            color: #495057;
            border-top: 2px solid #ced4da;
        }
        .drug-name-primary {
            color: #0d6efd;
            font-weight: 700;
            font-size: 1.05rem;
        }
        .usage-cell {
            white-space: pre-wrap;
            font-weight: 700;
            font-size: 0.9rem;
            color: #212529;
        }
        .badge-src-hosxp { background: #198754; }
        .badge-src-phr { background: #6c757d; }
        #medTable.table-striped > tbody > tr.org-tint > * {
            --bs-table-bg-type: transparent;
            --bs-table-accent-bg: transparent;
        }
        tr.org-tint td { border-color: rgba(0,0,0,.06); }
        tr.org-tint:hover td { filter: brightness(0.97); }
        .org-legend {
            display: flex; flex-wrap: wrap; gap: .4rem .75rem;
            font-size: .8rem; color: #495057;
            align-items: center;
        }
        .org-legend-item {
            display: inline-flex; align-items: center; gap: .35rem;
            cursor: pointer;
            border: 1px solid #ced4da;
            border-radius: 999px;
            padding: .2rem .65rem;
            background: #fff;
            user-select: none;
        }
        .org-legend-item:hover { border-color: #0d6efd; }
        .org-legend-item.active {
            border-color: #198754;
            box-shadow: 0 0 0 2px rgba(25,135,84,.2);
            font-weight: 700;
        }
        .org-legend-item.dimmed { opacity: .45; }
        .org-legend-swatch {
            width: 14px; height: 14px; border-radius: 3px;
            border: 1px solid rgba(0,0,0,.12);
            flex-shrink: 0;
        }
        .filter-toolbar {
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-2 text-dark">
                <i class="fas fa-notes-medical me-2 text-success"></i>
                Med Reconcile (Drugs Center / PHR)
            </h4>
            <p class="text-muted small mb-3">
                ดึงประวัติรับยาย้อนหลังจาก PHR กลาง ตาม
                <a href="https://docs.google.com/document/d/1oJZ700FIOCNr8QcdvhCGPWfuLAre2q2s797VOE1Vp68/edit?usp=sharing" target="_blank" rel="noopener">API Drug Center §5</a>
                — รายการของ รพ.ตนเอง (ตั้งค่า hcode ได้ที่
                <a href="hosxp_setting.php">ตั้งค่า HOSxP</a>)
                จะดึงจากฐาน HOSxP เมื่อมีประวัติ แล้วรวม PHR จากสถานพยาบาลอื่น (ตัดซ้ำเฉพาะ TPU วันเดียวกัน) · กรองตาม รพ./ชื่อยาได้
            </p>

            <?php echo drug_center_status_banner_html(); ?>

            <div class="filter-box p-3 mb-3">
                <div class="row g-2 align-items-end">
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">HN</label>
                        <input type="text" id="hn" class="form-control form-control-sm" value="<?php echo $prefill_hn; ?>" placeholder="ไม่ต้องใส่ 0 นำหน้า" inputmode="numeric">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold mb-1">CID (บัตรประชาชน)</label>
                        <input type="text" id="cid" class="form-control form-control-sm" maxlength="13" placeholder="13 หลัก">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">hcode</label>
                        <input type="text" id="hcode" class="form-control form-control-sm" value="<?php echo $default_hcode; ?>" placeholder="รหัส รพ.">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold mb-1">history_mode</label>
                        <select id="history_mode" class="form-select form-select-sm">
                            <option value="">ภายในวันปัจจุบัน</option>
                            <option value="7D">7 วัน</option>
                            <option value="1M">1 เดือน</option>
                            <option value="3M">3 เดือน</option>
                            <option value="6M" selected>6 เดือน</option>
                            <option value="1Y">1 ปี</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="button" class="btn btn-success btn-sm fw-bold" id="btnLookup"><i class="fas fa-user me-1"></i>ดึงจาก HN</button>
                        <button type="button" class="btn btn-primary btn-sm fw-bold" id="btnRun"><i class="fas fa-sync-alt me-1"></i>ดึง Med Reconcile</button>
                    </div>
                </div>
            </div>

            <div id="patientBar" class="patient-bar p-3 mb-3 d-none">
                <strong id="ptLabel"></strong>
                <span class="text-muted small ms-2" id="ptMeta"></span>
            </div>

            <div id="msg" class="alert d-none"></div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white fw-bold d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <span><i class="fas fa-pills me-1 text-success"></i> รายการยา (เรียงตามวันที่)</span>
                    <span class="small text-muted" id="resultMeta"></span>
                </div>
                <div class="filter-toolbar px-3 py-2">
                    <div class="row g-2 align-items-end mb-2">
                        <div class="col-md-5">
                            <label class="form-label small fw-bold mb-1"><i class="fas fa-filter me-1"></i>กรองรายการยา</label>
                            <input type="text" id="drugFilterText" class="form-control form-control-sm" placeholder="พิมพ์ชื่อยา หรือ TPU / icode..." disabled>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold mb-1">เลือกจากรายชื่อยา</label>
                            <select id="drugFilterSelect" class="form-select form-select-sm" disabled>
                                <option value="all">-- แสดงยาทั้งหมด --</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="button" class="btn btn-outline-secondary btn-sm fw-bold" id="btnClearFilters" disabled>
                                <i class="fas fa-undo me-1"></i>ล้างตัวกรอง
                            </button>
                        </div>
                    </div>
                    <div id="orgLegend"></div>
                </div>
                <div class="card-body p-0">
                    <div class="drug-table-wrap">
                        <table id="medTable" class="table table-hover table-striped align-middle mb-0">
                            <thead class="table-light text-center sticky-top">
                                <tr>
                                    <th width="5%">ลำดับ</th>
                                    <th class="text-start" width="32%">รายการยา</th>
                                    <th width="10%">จำนวนสั่งยา (qty)</th>
                                    <th class="text-start" width="18%">สถานพยาบาล</th>
                                    <th class="text-start" width="35%">วิธีใช้ / Rate</th>
                                </tr>
                            </thead>
                            <tbody id="tbBody">
                                <tr><td colspan="5" class="text-center text-muted py-4">ยังไม่ได้ดึงข้อมูล</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/bootstrap.bundle.min.js"></script>
<?php echo drug_center_status_banner_script(); ?>
<script>
(function () {
    var allRows = [];
    var colorMap = {};
    var selectedOrgs = null; // null = ทั้งหมด, Set of keys = กรอง
    var resultMetaBase = '';

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
    function showMsg(type, text) {
        var el = document.getElementById('msg');
        el.className = 'alert alert-' + type;
        el.textContent = text;
        el.classList.remove('d-none');
    }
    function hideMsg() {
        document.getElementById('msg').classList.add('d-none');
    }

    function dateSortKey(dateStr) {
        var s = String(dateStr || '').trim();
        var m = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
        if (m) {
            return m[3] + '-' + String(m[2]).padStart(2, '0') + '-' + String(m[1]).padStart(2, '0');
        }
        m = s.match(/(\d{4})-(\d{2})-(\d{2})/);
        return m ? (m[1] + '-' + m[2] + '-' + m[3]) : '';
    }

    /** เรียงตามวันที่ใหม่→เก่า (วันเดียวกัน: HOSxP ก่อน) */
    function sortRows(rows) {
        return rows.slice().sort(function (a, b) {
            var da = dateSortKey(a.date);
            var db = dateSortKey(b.date);
            if (da !== db) return db.localeCompare(da);
            var sa = a.source === 'hosxp' ? 0 : 1;
            var sb = b.source === 'hosxp' ? 0 : 1;
            if (sa !== sb) return sa - sb;
            return String(a.code_text || '').localeCompare(String(b.code_text || ''), 'th');
        });
    }

    function formatQty(row) {
        var q = row.qty;
        if (q == null || q === '') return '<span class="text-muted">-</span>';
        var n = parseFloat(q);
        var txt = (!isNaN(n) && String(n) === String(q)) ? n : q;
        return '<span class="fw-bold fs-5">' + esc(txt) + '</span>';
    }

    function usageText(row) {
        var u = String(
            row.usage_display || row.method || row.patient_instruction || row.instruction || ''
        ).trim();
        return u || '-';
    }

    function drugName(row) {
        return String(row.code_text == null ? '' : row.code_text).trim() || '-';
    }

    var ORG_PALETTE = [
        '#d1e7dd', '#cfe2ff', '#fff3cd', '#f8d7da', '#e2d9f3',
        '#d2f4ea', '#ffe5d0', '#d7f5ff', '#fce7f3', '#e9ecef'
    ];
    var localHcode = String(document.getElementById('hcode').value || '').replace(/\D+/g, '').replace(/^0+/, '') || '10699';

    function orgColorKey(code) {
        var c = String(code == null ? '' : code).replace(/\D+/g, '');
        c = c.replace(/^0+/, '') || c;
        return c || '_unknown';
    }

    function buildOrgColorMap(rows) {
        var map = {};
        var next = 1;
        map[localHcode] = ORG_PALETTE[0];
        rows.forEach(function (row) {
            var key = orgColorKey(row.organization_code);
            if (map[key]) return;
            map[key] = ORG_PALETTE[next % ORG_PALETTE.length];
            next += 1;
        });
        return map;
    }

    function listOrgItems(rows) {
        var seen = {};
        var items = [];
        rows.forEach(function (row) {
            var key = orgColorKey(row.organization_code);
            if (seen[key]) return;
            seen[key] = true;
            var name = String(row.organization_name == null ? '' : row.organization_name).trim();
            var label = name || (key === '_unknown' ? 'ไม่ระบุสถานพยาบาล' : ('รหัส ' + key));
            var isLocal = (key === localHcode) || row.source === 'hosxp';
            items.push({
                key: key,
                label: label,
                color: colorMap[key] || ORG_PALETTE[ORG_PALETTE.length - 1],
                isLocal: isLocal
            });
        });
        items.sort(function (a, b) {
            if (a.isLocal !== b.isLocal) return a.isLocal ? -1 : 1;
            return a.label.localeCompare(b.label, 'th');
        });
        return items;
    }

    function setFilterControlsEnabled(on) {
        document.getElementById('drugFilterText').disabled = !on;
        document.getElementById('drugFilterSelect').disabled = !on;
        document.getElementById('btnClearFilters').disabled = !on;
    }

    function fillDrugSelect(rows) {
        var sel = document.getElementById('drugFilterSelect');
        var names = {};
        rows.forEach(function (row) {
            var n = drugName(row);
            if (n && n !== '-') names[n] = true;
        });
        var list = Object.keys(names).sort(function (a, b) {
            return a.localeCompare(b, 'th');
        });
        var keep = sel.value || 'all';
        sel.innerHTML = '<option value="all">-- แสดงยาทั้งหมด --</option>'
            + list.map(function (n) {
                return '<option value="' + esc(n) + '">' + esc(n) + '</option>';
            }).join('');
        if (keep !== 'all' && names[keep]) sel.value = keep;
        else sel.value = 'all';
    }

    function renderOrgLegend(rows) {
        var el = document.getElementById('orgLegend');
        var items = listOrgItems(rows);
        if (!items.length) {
            el.innerHTML = '';
            return;
        }
        var allActive = !selectedOrgs;
        el.innerHTML = '<div class="org-legend">'
            + '<span class="text-muted fw-bold me-1">กรองสถานพยาบาล:</span>'
            + '<button type="button" class="btn btn-sm ' + (allActive ? 'btn-success' : 'btn-outline-secondary') + ' py-0 px-2" id="btnOrgAll">ทั้งหมด</button>'
            + items.map(function (it) {
                var active = allActive || (selectedOrgs && selectedOrgs[it.key]);
                return '<span class="org-legend-item' + (active ? ' active' : ' dimmed') + '" data-org="' + esc(it.key) + '" title="คลิกเพื่อกรอง">'
                    + '<span class="org-legend-swatch" style="background:' + it.color + '"></span>'
                    + esc(it.label)
                    + (it.key !== '_unknown' ? ' <span class="text-muted">(' + esc(it.key) + ')</span>' : '')
                    + (it.isLocal ? ' <span class="badge bg-success">รพ.นี้</span>' : '')
                    + '</span>';
            }).join('')
            + '</div>';

        var btnAll = document.getElementById('btnOrgAll');
        if (btnAll) {
            btnAll.addEventListener('click', function () {
                selectedOrgs = null;
                applyFilters();
            });
        }
        el.querySelectorAll('.org-legend-item').forEach(function (chip) {
            chip.addEventListener('click', function () {
                var key = chip.getAttribute('data-org');
                if (!selectedOrgs) {
                    selectedOrgs = {};
                    selectedOrgs[key] = true;
                } else if (selectedOrgs[key]) {
                    delete selectedOrgs[key];
                    if (!Object.keys(selectedOrgs).length) selectedOrgs = null;
                } else {
                    selectedOrgs[key] = true;
                }
                applyFilters();
            });
        });
    }

    function getFilteredRows() {
        var text = document.getElementById('drugFilterText').value.trim().toLowerCase();
        var drugSel = document.getElementById('drugFilterSelect').value;
        return allRows.filter(function (row) {
            var orgKey = orgColorKey(row.organization_code);
            if (selectedOrgs && !selectedOrgs[orgKey]) return false;
            var name = drugName(row);
            if (drugSel && drugSel !== 'all' && name !== drugSel) return false;
            if (text) {
                var hay = [
                    name,
                    row.tpu_code,
                    row.icode,
                    row.organization_name,
                    row.organization_code,
                    usageText(row)
                ].join(' ').toLowerCase();
                if (hay.indexOf(text) === -1) return false;
            }
            return true;
        });
    }

    function updateResultMeta(shown) {
        var meta = resultMetaBase || '';
        if (allRows.length && shown !== allRows.length) {
            meta = 'แสดง ' + shown + '/' + allRows.length + ' รายการ'
                + (meta ? ' · ' + meta.replace(/^พบ\s+\d+\s+รายการ\s*·?\s*/, '') : '');
        }
        document.getElementById('resultMeta').textContent = meta;
    }

    function renderTable(rows) {
        var tb = document.getElementById('tbBody');
        if (!rows.length) {
            tb.innerHTML = '<tr><td colspan="5" class="text-center text-muted py-4">'
                + (allRows.length ? 'ไม่พบรายการตามเงื่อนไขตัวกรอง' : 'ไม่พบรายการยา')
                + '</td></tr>';
            return;
        }
        rows = sortRows(rows);
        var html = '';
        var lastDate = null;
        var rowNo = 0;
        rows.forEach(function (row) {
            var d = row.date || '-';
            if (d !== lastDate) {
                html += '<tr class="order-group-row"><td colspan="5" class="fw-bold small py-2">'
                    + '<i class="far fa-calendar-alt me-1"></i> วันที่ ' + esc(d)
                    + '</td></tr>';
                lastDate = d;
            }
            rowNo += 1;
            var name = drugName(row);
            var badges = [];
            if (row.icode) {
                badges.push('<small class="badge bg-white text-secondary border shadow-sm"><i class="fas fa-barcode me-1"></i>' + esc(row.icode) + '</small>');
            }
            if (row.tpu_code) {
                badges.push('<small class="badge bg-white text-teal border shadow-sm" style="color:#0d9488">TPU ' + esc(row.tpu_code) + '</small>');
            }
            if (!badges.length) {
                badges.push('<small class="badge bg-white text-secondary border shadow-sm">-</small>');
            }
            var src = row.source === 'hosxp'
                ? '<span class="badge badge-src-hosxp">HOSxP</span>'
                : '<span class="badge badge-src-phr">PHR</span>';
            var cat = String(row.patien_category == null ? '' : row.patien_category).trim();
            var catBadge = cat
                ? (' <span class="badge bg-white text-secondary border">' + esc(cat) + '</span>')
                : '';
            var orgName = String(row.organization_name == null ? '' : row.organization_name).trim();
            var orgCode = String(row.organization_code == null ? '' : row.organization_code).trim();
            var orgKey = orgColorKey(orgCode);
            var bg = colorMap[orgKey] || ORG_PALETTE[ORG_PALETTE.length - 1];
            var orgCell = orgName
                ? (esc(orgName) + (orgCode ? '<div class="small text-muted">' + esc(orgCode) + '</div>' : ''))
                : esc(orgCode || '-');

            html += '<tr class="org-tint" style="background-color:' + bg + '">'
                + '<td class="text-center fw-bold text-secondary" style="background-color:' + bg + '">' + rowNo + '</td>'
                + '<td class="align-middle" style="background-color:' + bg + '">'
                +   '<span class="drug-name-primary"><i class="fas fa-pills me-1 text-primary"></i>' + esc(name) + '</span>'
                +   '<br>' + badges.join(' ') + ' ' + src + catBadge
                + '</td>'
                + '<td class="text-center align-middle" style="background-color:' + bg + '">' + formatQty(row) + '</td>'
                + '<td class="align-middle small" style="background-color:' + bg + '">' + orgCell + '</td>'
                + '<td class="align-middle" style="background-color:' + bg + '"><div class="usage-cell">' + esc(usageText(row)) + '</div></td>'
                + '</tr>';
        });
        tb.innerHTML = html;
    }

    function applyFilters() {
        renderOrgLegend(allRows);
        var filtered = getFilteredRows();
        updateResultMeta(filtered.length);
        renderTable(filtered);
    }

    function loadRows(rows, metaText) {
        allRows = Array.isArray(rows) ? rows : [];
        selectedOrgs = null;
        document.getElementById('drugFilterText').value = '';
        localHcode = String(document.getElementById('hcode').value || '').replace(/\D+/g, '').replace(/^0+/, '') || localHcode;
        colorMap = buildOrgColorMap(allRows);
        resultMetaBase = metaText || '';
        fillDrugSelect(allRows);
        setFilterControlsEnabled(allRows.length > 0);
        applyFilters();
    }

    document.getElementById('drugFilterText').addEventListener('input', function () {
        applyFilters();
    });
    document.getElementById('drugFilterSelect').addEventListener('change', function () {
        applyFilters();
    });
    document.getElementById('btnClearFilters').addEventListener('click', function () {
        selectedOrgs = null;
        document.getElementById('drugFilterText').value = '';
        document.getElementById('drugFilterSelect').value = 'all';
        applyFilters();
    });

    document.getElementById('btnLookup').addEventListener('click', function () {
        doLookupHn(false);
    });

    document.getElementById('hn').addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            doLookupHn(true);
        }
    });

    function doLookupHn(thenReconcile) {
        var hn = document.getElementById('hn').value.trim();
        if (!hn) { showMsg('warning', 'กรุณาระบุ HN'); return; }
        hideMsg();
        var btn = document.getElementById('btnLookup');
        btn.disabled = true;
        fetch('fetch_drug_center_api.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'lookup_hn', hn: hn, recent_days: 7})
        }).then(function (r) { return r.json(); }).then(function (j) {
            btn.disabled = false;
            if (!j || j.status !== 'ok') {
                showMsg('danger', (j && j.message) || 'ค้นหา HN ไม่สำเร็จ');
                document.getElementById('patientBar').classList.remove('d-none');
                document.getElementById('ptLabel').textContent = '- (HN ' + hn + ')';
                document.getElementById('ptMeta').textContent = 'ไม่พบใน HOSxP';
                return;
            }
            if (j.hn) document.getElementById('hn').value = j.hn;
            document.getElementById('cid').value = j.cid || '';
            document.getElementById('patientBar').classList.remove('d-none');
            document.getElementById('ptLabel').textContent = (j.ptname || '-') + ' (HN ' + j.hn + ')';
            document.getElementById('ptMeta').textContent = j.cid
                ? ('CID: ' + j.cid + ' · ยาล่าสุดที่มี TPU: ' + (j.codes || []).length + ' รายการ')
                : 'ไม่พบ CID ใน HOSxP';
            if (!j.cid) {
                showMsg('warning', 'ไม่พบเลขบัตรประชาชนของ HN นี้ใน HOSxP — กรอก CID เองได้');
                return;
            }
            hideMsg();
            if (thenReconcile) {
                doMedReconcile();
            }
        }).catch(function (e) {
            btn.disabled = false;
            showMsg('danger', String(e));
        });
    }

    document.getElementById('btnRun').addEventListener('click', function () {
        doMedReconcile();
    });

    document.getElementById('cid').addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            doMedReconcile();
        }
    });

    function doMedReconcile() {
        hideMsg();
        var payload = {
            action: 'med_reconcile',
            hn: document.getElementById('hn').value.trim(),
            cid: document.getElementById('cid').value.trim(),
            hcode: document.getElementById('hcode').value.trim(),
            history_mode: document.getElementById('history_mode').value,
            page: 1,
            row: 200
        };
        var btn = document.getElementById('btnRun');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>กำลังดึง...';
        fetch('fetch_drug_center_api.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        }).then(function (r) { return r.json(); }).then(function (j) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-sync-alt me-1"></i>ดึง Med Reconcile';
            if (!j || j.status !== 'ok') {
                loadRows([], '');
                document.getElementById('tbBody').innerHTML =
                    '<tr><td colspan="5" class="text-center text-danger py-4">' + esc((j && j.message) || 'ไม่สำเร็จ') + '</td></tr>';
                showMsg('danger', (j && j.message) || 'เรียก API ไม่สำเร็จ');
                return;
            }
            if (j.cid) document.getElementById('cid').value = j.cid;
            if (j.hn) document.getElementById('hn').value = j.hn;
            var rows = (j.data && j.data.data) ? j.data.data : [];
            var pag = (j.data && j.data.pagination) ? j.data.pagination : {};
            var meta = 'พบ ' + (pag.total != null ? pag.total : rows.length) + ' รายการ';
            if (j.hosxp_used) meta += ' · HOSxP ' + (j.hosxp_count || 0) + ' รายการ';
            if (j.phr_dropped) meta += ' · ตัด PHR ซ้ำ ' + j.phr_dropped;
            if (j.local_hname) meta += ' · รพ.นี้: ' + j.local_hname;
            if (!rows.length) {
                loadRows([], meta);
                showMsg('info', j.message || 'สำเร็จ แต่ไม่มีรายการ');
                return;
            }
            hideMsg();
            showMsg('success', j.message || 'สำเร็จ');
            loadRows(rows, meta);
        }).catch(function (e) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-sync-alt me-1"></i>ดึง Med Reconcile';
            showMsg('danger', String(e));
        });
    }
})();
</script>
</body>
</html>
