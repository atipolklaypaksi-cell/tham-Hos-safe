<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
session_write_close();
include('warfarin_helper.php');
require_once __DIR__ . '/warfarin_guideline_helper.php';
mysqli_set_charset($con, 'utf8');

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$raw = file_get_contents('php://input');
$body = [];
if ($raw !== false && $raw !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
        if ($action === '' && !empty($body['action'])) {
            $action = $body['action'];
        }
    }
}

if ($action === 'lookup') {
    $hn = trim((string)($_GET['hn'] ?? $body['hn'] ?? ''));
    $hos = hosxp_connect($con);
    if (!$hos) {
        echo json_encode(['status' => 'error', 'message' => 'เชื่อมต่อ HOSxP ไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    mysqli_set_charset($hos, 'utf8');
    $res = wf_lookup_patient_warfarin($hos, $hn);
    if (empty($res['ok'])) {
        mysqli_close($hos);
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'ไม่พบข้อมูล'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $patient_hn = $res['patient']['hn'] ?? $hn;
    $res['inr'] = wf_fetch_inr($con, $hos, $patient_hn, 72, 80);
    $inr_max_months = wf_inr_max_age_months($con);
    $res['inr']['max_age_months'] = $inr_max_months;
    $visit_ymd = trim((string)($res['patient']['visit_date'] ?? $res['visit']['vstdate'] ?? ''));
    if ($visit_ymd === '') {
        $visit_ymd = date('Y-m-d');
    }
    if (!empty($res['inr']['latest']['order_date'])) {
        $od = $res['inr']['latest']['order_date'];
        $odN = wf_ymd_normalize($od);
        $visitN = wf_ymd_normalize($visit_ymd);
        $sameDay = ($odN !== '' && $odN === $visitN);
        $res['inr']['latest']['same_day'] = $sameDay;
        $res['inr']['latest']['carried'] = !$sameDay;
        $res['inr']['latest']['stale'] = wf_inr_is_older_than_months($od, date('Y-m-d'), $inr_max_months)
            || wf_inr_is_older_than_months($od, $visit_ymd, $inr_max_months);
    }
    $res['guidelines'] = wf_guideline_load($con);
    $pref = wf_hn_pref_get($con, $patient_hn);
    $res['hn_pref'] = $pref;
    $protocol_override = trim((string)($_GET['protocol_id'] ?? $body['protocol_id'] ?? ''));
    $protocol_id = $protocol_override !== '' ? $protocol_override : ($pref['protocol_id'] ?: 'inr_2_3');
    if ($protocol_override !== '' && $protocol_override !== ($pref['protocol_id'] ?? '')) {
        // client เลือก guideline แล้ว — ใช้ค่านั้นประเมินประวัติทันที
        $pref['protocol_id'] = $protocol_id;
        $res['hn_pref'] = $pref;
    }
    $inr_val = $res['inr']['latest']['value'] ?? null;
    $res['guideline_match'] = null;
    if (!empty($res['inr']['latest']['stale'])) {
        $res['guideline_match'] = [
            'ok' => false,
            'error' => 'ผล INR นานกว่า ' . $inr_max_months . ' เดือน — ประเมินไม่ได้',
        ];
    } elseif (!empty($res['inr']['latest']['carried'])) {
        $labTh = trim((string)($res['inr']['latest']['date_th'] ?? ''));
        $res['guideline_match'] = [
            'ok' => false,
            'error' => 'ใช้ผล Lab ก่อนหน้า' . ($labTh !== '' ? ' (' . $labTh . ')' : '') . ' ไม่ได้เจาะใหม่ — ประเมินไม่ได้',
        ];
    } elseif ($inr_val !== null) {
        $match = wf_guideline_match($con, $inr_val, $protocol_id);
        if (!empty($match['ok'])) {
            $res['guideline_match'] = $match;
        }
    }
    $res['therapy_history'] = wf_build_therapy_history(
        $con,
        $hos,
        $patient_hn,
        $protocol_id,
        $res['inr'],
        36,
        5
    );
    $topHist = $res['therapy_history']['rows'][0] ?? null;
    if (is_array($topHist) && !empty($res['inr']['latest'])) {
        if (!empty($topHist['inr_stale'])) {
            $res['inr']['latest']['stale'] = true;
            $res['guideline_match'] = [
                'ok' => false,
                'error' => 'ผล INR นานกว่า ' . $inr_max_months . ' เดือน — ประเมินไม่ได้',
            ];
        } elseif (!empty($topHist['inr_carried'])) {
            $res['inr']['latest']['carried'] = true;
            $res['inr']['latest']['same_day'] = false;
            $labTh = trim((string)($topHist['inr_date_th'] ?? $res['inr']['latest']['date_th'] ?? ''));
            $res['guideline_match'] = [
                'ok' => false,
                'error' => 'ใช้ผล Lab ก่อนหน้า' . ($labTh !== '' ? ' (' . $labTh . ')' : '') . ' ไม่ได้เจาะใหม่ — ประเมินไม่ได้',
            ];
        }
    }
    mysqli_close($hos);
    echo json_encode(['status' => 'success', 'data' => $res], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'recommend') {
    $current = (float)($body['current_mg_week'] ?? $_POST['current_mg_week'] ?? 0);
    $pct = (float)($body['pct'] ?? $_POST['pct'] ?? 0);
    $direction = strtolower(trim((string)($body['direction'] ?? $_POST['direction'] ?? 'up')));
    $strengths_raw = $body['strengths'] ?? $_POST['strengths'] ?? null;
    $strength_single = $body['strength_mg'] ?? $_POST['strength_mg'] ?? null;
    $target_override = $body['target_mg_week'] ?? $_POST['target_mg_week'] ?? null;

    if ($target_override !== null && $target_override !== '' && is_numeric($target_override)) {
        $target = (float)$target_override;
        $adj_pct = ($current > 0) ? (($target - $current) / $current * 100) : 0;
    } else {
        if (!($current > 0)) {
            echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ dose เดิม (mg/สัปดาห์)'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        if ($direction === 'hold' || abs($pct) < 1e-9) {
            $target = $current;
            $adj_pct = 0;
        } else {
            $factor = ($direction === 'down') ? (1 - abs($pct) / 100) : (1 + abs($pct) / 100);
            $target = $current * $factor;
            $adj_pct = ($direction === 'down') ? -abs($pct) : abs($pct);
        }
    }

    if (is_array($strengths_raw)) {
        $strengths = $strengths_raw;
    } elseif ($strengths_raw !== null && $strengths_raw !== '') {
        $strengths = preg_split('/\s*,\s*/', (string)$strengths_raw);
    } elseif ($strength_single !== null && $strength_single !== '') {
        $strengths = [$strength_single];
    } else {
        $strengths = [5];
    }

    $baseline_items = $body['baseline_items'] ?? $_POST['baseline_items'] ?? null;
    if (!is_array($baseline_items)) {
        $baseline_items = null;
    }

    $rec = wf_recommend_schedule($target, $strengths, $baseline_items);
    if (empty($rec['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $rec['error'] ?? 'คำนวณไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $rec['current_mg_week'] = round($current, 2);
    $rec['adjust_pct'] = round($adj_pct, 2);
    $actual = (float)($rec['actual_mg_week'] ?? 0);
    $actual_pct = ($current > 0) ? (($actual - $current) / $current * 100) : 0;
    $rec['actual_adjust_pct'] = round($actual_pct, 1);
    echo json_encode(['status' => 'success', 'data' => $rec], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'action ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
