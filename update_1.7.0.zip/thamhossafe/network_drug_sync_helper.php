<?php
/**
 * ซิงก์บัญชียาเครือข่ายจากแหล่งในหน้าเชื่อมต่อรพ. (hospital_connect)
 */

require_once __DIR__ . '/hospital_ds_helper.php';
require_once __DIR__ . '/network_drug_helper.php';

function nd_sync_cfg_keys() {
    return [
        'nd_sync_enabled' => 'enabled',
        'nd_sync_freq' => 'freq',
        'nd_sync_time' => 'time',
        'nd_sync_cron_secret' => 'cron_secret',
        'nd_sync_last_at' => 'last_at',
        'nd_sync_last_ok' => 'last_ok',
        'nd_sync_last_message' => 'last_message',
        'nd_sync_last_detail' => 'last_detail',
    ];
}

function nd_sync_freq_options() {
    return [
        'daily' => 'ทุกวัน',
        'hours12' => 'ทุก 12 ชั่วโมง',
        'hours6' => 'ทุก 6 ชั่วโมง',
        'hours3' => 'ทุก 3 ชั่วโมง',
        'days2' => 'ทุก 2 วัน',
        'weekly' => 'ทุกสัปดาห์',
    ];
}

function nd_sync_norm_freq($raw) {
    $raw = trim((string)$raw);
    return isset(nd_sync_freq_options()[$raw]) ? $raw : 'daily';
}

function nd_sync_norm_time($raw) {
    $raw = trim((string)$raw);
    if (preg_match('/^(\d{1,2}):(\d{2})$/', $raw, $m)) {
        $h = max(0, min(23, (int)$m[1]));
        $i = max(0, min(59, (int)$m[2]));
        return sprintf('%02d:%02d', $h, $i);
    }
    return '02:00';
}

function nd_sync_freq_uses_clock($freq) {
    return in_array(nd_sync_norm_freq($freq), ['daily', 'days2', 'weekly'], true);
}

function nd_sync_interval_seconds($freq) {
    switch (nd_sync_norm_freq($freq)) {
        case 'hours3':
            return 3 * 3600;
        case 'hours6':
            return 6 * 3600;
        case 'hours12':
            return 12 * 3600;
        case 'days2':
            return 2 * 86400;
        case 'weekly':
            return 7 * 86400;
        default:
            return 86400;
    }
}

function nd_sync_cfg_defaults() {
    return [
        'enabled' => '0',
        'freq' => 'daily',
        'time' => '02:00',
        'cron_secret' => '',
        'last_at' => '',
        'last_ok' => '',
        'last_message' => '',
        'last_detail' => '',
    ];
}

function nd_sync_get_config($con) {
    $cfg = nd_sync_cfg_defaults();
    $names = array_keys(nd_sync_cfg_keys());
    $in = "'" . implode("','", $names) . "'";
    $q = @mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ($in)");
    $map = nd_sync_cfg_keys();
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $k = $map[$r['config_name']] ?? '';
            if ($k !== '') {
                $cfg[$k] = (string)($r['config_value'] ?? '');
            }
        }
    }
    $cfg['enabled'] = !empty($cfg['enabled']) && $cfg['enabled'] !== '0' ? '1' : '0';
    $cfg['freq'] = nd_sync_norm_freq($cfg['freq']);
    $cfg['time'] = nd_sync_norm_time($cfg['time']);
    if (trim($cfg['cron_secret']) === '') {
        $cfg['cron_secret'] = bin2hex(random_bytes(12));
        nd_sync_cfg_put($con, 'nd_sync_cron_secret', $cfg['cron_secret']);
    }
    return $cfg;
}

function nd_sync_cfg_put($con, $name, $val) {
    $k = mysqli_real_escape_string($con, $name);
    $v = mysqli_real_escape_string($con, (string)$val);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$k'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
}

function nd_sync_save_config($con, array $in) {
    $cur = nd_sync_get_config($con);
    $next = [
        'enabled' => !empty($in['enabled']) ? '1' : '0',
        'freq' => nd_sync_norm_freq($in['freq'] ?? $cur['freq']),
        'time' => nd_sync_norm_time($in['time'] ?? $cur['time']),
        'cron_secret' => trim((string)($in['cron_secret'] ?? $cur['cron_secret'])),
    ];
    if ($next['cron_secret'] === '') {
        $next['cron_secret'] = $cur['cron_secret'] !== '' ? $cur['cron_secret'] : bin2hex(random_bytes(12));
    }
    nd_sync_cfg_put($con, 'nd_sync_enabled', $next['enabled']);
    nd_sync_cfg_put($con, 'nd_sync_freq', $next['freq']);
    nd_sync_cfg_put($con, 'nd_sync_time', $next['time']);
    nd_sync_cfg_put($con, 'nd_sync_cron_secret', $next['cron_secret']);
    return nd_sync_get_config($con);
}

function nd_sync_tz() {
    static $tz = null;
    if ($tz === null) {
        $tz = new DateTimeZone('Asia/Bangkok');
    }
    return $tz;
}

function nd_sync_now_ts() {
    return (new DateTime('now', nd_sync_tz()))->getTimestamp();
}

function nd_sync_now_str() {
    return (new DateTime('now', nd_sync_tz()))->format('Y-m-d H:i:s');
}

function nd_sync_parse_ts($raw) {
    $raw = trim((string)$raw);
    if ($raw === '') {
        return 0;
    }
    $d = DateTime::createFromFormat('Y-m-d H:i:s', $raw, nd_sync_tz());
    if ($d instanceof DateTime) {
        return $d->getTimestamp();
    }
    $d = date_create($raw, nd_sync_tz());
    return $d instanceof DateTime ? $d->getTimestamp() : 0;
}

function nd_sync_today_slot_ts($hh, $mm) {
    $d = new DateTime('now', nd_sync_tz());
    $d->setTime((int)$hh, (int)$mm, 0);
    return $d->getTimestamp();
}

function nd_sync_mark_result($con, $ok, $message, $detail = '') {
    nd_sync_cfg_put($con, 'nd_sync_last_at', nd_sync_now_str());
    nd_sync_cfg_put($con, 'nd_sync_last_ok', $ok ? '1' : '0');
    nd_sync_cfg_put($con, 'nd_sync_last_message', nd_truncate_str($message, 500));
    nd_sync_cfg_put($con, 'nd_sync_last_detail', nd_truncate_str($detail, 2000));
}

function nd_sync_cron_url() {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
    $base = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/thamhossafe'))), '/');
    return $scheme . '://' . $host . $base . '/cron_network_drug_sync.php';
}

function nd_sync_is_due(array $cfg, $force = false) {
    if ($force) {
        return ['due' => true, 'wait_sec' => 0, 'reason' => 'force'];
    }
    if (($cfg['enabled'] ?? '0') !== '1') {
        return ['due' => false, 'wait_sec' => 0, 'reason' => 'disabled'];
    }
    $freq = nd_sync_norm_freq($cfg['freq'] ?? 'daily');
    $last_ts = nd_sync_parse_ts($cfg['last_at'] ?? '');
    $now = nd_sync_now_ts();
    if (in_array($freq, ['hours3', 'hours6', 'hours12'], true)) {
        $need = nd_sync_interval_seconds($freq) - 60;
        if (!$last_ts) {
            return ['due' => true, 'wait_sec' => 0, 'reason' => 'first'];
        }
        $elapsed = $now - $last_ts;
        if ($elapsed >= $need) {
            return ['due' => true, 'wait_sec' => 0, 'reason' => 'interval'];
        }
        return ['due' => false, 'wait_sec' => max(0, $need - $elapsed), 'reason' => 'wait'];
    }
    $time = nd_sync_norm_time($cfg['time'] ?? '02:00');
    $parts = explode(':', $time);
    $hh = (int)$parts[0];
    $mm = (int)($parts[1] ?? 0);
    $today_slot = nd_sync_today_slot_ts($hh, $mm);
    $period = nd_sync_interval_seconds($freq);
    if ($now < $today_slot) {
        return ['due' => false, 'wait_sec' => $today_slot - $now, 'reason' => 'wait_clock'];
    }
    if (!$last_ts) {
        return ['due' => true, 'wait_sec' => 0, 'reason' => 'first_slot'];
    }
    if ($last_ts >= $today_slot) {
        $next = $today_slot + $period;
        return ['due' => false, 'wait_sec' => max(0, $next - $now), 'reason' => 'already'];
    }
    if (($now - $last_ts) >= ($period - 120)) {
        return ['due' => true, 'wait_sec' => 0, 'reason' => 'clock'];
    }
    $next = $last_ts + $period;
    if ($next < $today_slot) {
        $next = $today_slot + $period;
    }
    return ['due' => false, 'wait_sec' => max(0, $next - $now), 'reason' => 'wait_period'];
}

function nd_sync_drugitems_sql($after_icode = '', $limit = 1500, $with_tmt = true) {
    $limit = max(100, min(2000, (int)$limit));
    $after = trim((string)$after_icode);
    $extra = '';
    if ($after !== '') {
        $extra = ' AND d.icode > ' . hds_sql_quote($after);
    }
    $icode = hds_sql_th("TRIM(IFNULL(d.icode,''))");
    $tpu = hds_sql_th("TRIM(IFNULL(d.tpu_code_list,''))");
    $name = hds_sql_th("IFNULL(d.name,'')");
    $generic = hds_sql_th("IFNULL(d.generic_name,'')");
    $strength = hds_sql_th("IFNULL(d.strength,'')");
    $units = hds_sql_th("IFNULL(d.units,'')");
    $form = hds_sql_th("IFNULL(d.dosageform,'')");
    $join = '';
    $name_filter = '';
    if ($with_tmt) {
        $join = ' INNER JOIN tmt_tpu_code tm ON d.tpu_code_list = tm.tpu_code ';
        $tmt = hds_sql_th("TRIM(CONCAT(IFNULL(tm.active_ingredient,''),' ',IFNULL(tm.strength,'')))");
        $strength = hds_sql_th("COALESCE(NULLIF(TRIM(tm.strength),''), IFNULL(d.strength,''))");
        $name_filter = " AND TRIM(IFNULL(d.tpu_code_list,'')) <> ''"
            . " AND TRIM(CONCAT(IFNULL(tm.active_ingredient,''),' ',IFNULL(tm.strength,''))) <> ''"
            . " AND CAST(CONVERT(d.name USING utf8) AS BINARY) NOT REGEXP 'ยาเดิม|ไม่มีในรพ'";
    } else {
        $tmt = $name;
    }
    return "SELECT $icode AS icode,
                   $tpu AS tpu_code_list,
                   $name AS name,
                   $generic AS generic_name,
                   $strength AS strength,
                   $tmt AS tmtdrug,
                   $units AS units,
                   $form AS dosageform
            FROM drugitems d
            $join
            WHERE IFNULL(d.istatus,'Y') IN ('Y','y')
              AND d.icode IS NOT NULL AND TRIM(d.icode) <> ''
              $name_filter
              $extra
            ORDER BY d.icode ASC
            LIMIT $limit";
}

function nd_sync_decode_cell($v) {
    $s = trim((string)$v);
    if ($s === '') {
        return '';
    }
    if (function_exists('hds_unhex_utf8')) {
        $s = hds_unhex_utf8($s);
    }
    return nd_clean_cell($s);
}

function nd_sync_fetch_hospital($con, array $source) {
    $hosname = trim((string)($source['name'] ?? $source['code'] ?? ''));
    if ($hosname === '') {
        return ['ok' => false, 'error' => 'ไม่มีชื่อโรงพยาบาล', 'rows' => []];
    }
    $limit = 1500;
    $rows = [];
    $with_tmt = true;
    $after = '';
    $pages = 0;
    while ($pages < 20) {
        $pages++;
        $sql = nd_sync_drugitems_sql($after, $limit, $with_tmt);
        $q = hds_query_sql($con, $source, $sql, ['timeout' => 40, 'max_points' => $limit + 20]);
        if (empty($q['ok'])) {
            $err = (string)($q['error'] ?? 'คิวรีไม่สำเร็จ');
            return ['ok' => false, 'error' => $err, 'rows' => [], 'via' => $q['via'] ?? ''];
        }
        $chunk = $q['rows'] ?? [];
        if (!$chunk) {
            break;
        }
        $last_icode = $after;
        foreach ($chunk as $r) {
            $icode = nd_sync_decode_cell($r['icode'] ?? '');
            $row = [
                'tpu_code_list' => nd_sync_decode_cell($r['tpu_code_list'] ?? ''),
                'name' => nd_sync_decode_cell($r['name'] ?? ''),
                'generic_name' => nd_sync_decode_cell($r['generic_name'] ?? ''),
                'strength' => nd_sync_decode_cell($r['strength'] ?? ''),
                'tmtdrug' => nd_sync_decode_cell($r['tmtdrug'] ?? ''),
                'units' => nd_sync_decode_cell($r['units'] ?? ''),
                'dosageform' => nd_sync_decode_cell($r['dosageform'] ?? ''),
                'hosname' => $hosname,
            ];
            if (!nd_row_is_listed($row)) {
                if ($icode !== '') {
                    $last_icode = $icode;
                }
                continue;
            }
            $rows[] = $row;
            if ($icode !== '') {
                $last_icode = $icode;
            }
        }
        if (count($chunk) < $limit || $last_icode === '' || $last_icode === $after) {
            break;
        }
        $after = $last_icode;
    }
    return [
        'ok' => true,
        'error' => '',
        'rows' => $rows,
        'via' => (string)($q['via'] ?? ''),
        'hosname' => $hosname,
    ];
}

function nd_sync_all($con, array $opt = []) {
    hds_ensure_tables($con);
    nd_ensure_tables($con);
    $sources = hds_active_sources($con);
    if (!$sources) {
        $msg = 'ยังไม่มีแหล่งข้อมูลที่เปิดใช้งานในหน้าเชื่อมต่อรพ.';
        nd_sync_mark_result($con, false, $msg);
        return ['status' => 'error', 'message' => $msg, 'hospitals' => []];
    }
    $user_id = (int)($opt['user_id'] ?? 0);
    $user_name = trim((string)($opt['user_name'] ?? 'ระบบ (เชื่อมต่อรพ.)'));
    $results = [];
    $ok_n = 0;
    $fail_n = 0;
    $total_rows = 0;
    foreach ($sources as $src) {
        $code = trim((string)($src['code'] ?? ''));
        $name = trim((string)($src['name'] ?? $code));
        $fetch = nd_sync_fetch_hospital($con, $src);
        if (empty($fetch['ok'])) {
            $fail_n++;
            $results[] = [
                'code' => $code,
                'name' => $name,
                'ok' => false,
                'error' => $fetch['error'] ?? 'ดึงข้อมูลไม่สำเร็จ',
                'row_count' => 0,
            ];
            continue;
        }
        $rows = $fetch['rows'] ?? [];
        if (!$rows) {
            $fail_n++;
            $results[] = [
                'code' => $code,
                'name' => $name,
                'ok' => false,
                'error' => 'ไม่พบรายการยาที่ใช้งาน',
                'row_count' => 0,
            ];
            continue;
        }
        $filename = 'hospital_connect:' . ($code !== '' ? $code : $name) . ' ' . substr(nd_sync_now_str(), 0, 16);
        $imp = nd_import_rows($con, $rows, $filename, $user_id, $user_name, $name);
        if (($imp['status'] ?? '') !== 'success') {
            $fail_n++;
            $results[] = [
                'code' => $code,
                'name' => $name,
                'ok' => false,
                'error' => $imp['message'] ?? 'นำเข้าไม่สำเร็จ',
                'row_count' => 0,
            ];
            continue;
        }
        $ok_n++;
        $n = (int)($imp['row_count'] ?? count($rows));
        $total_rows += $n;
        $results[] = [
            'code' => $code,
            'name' => $name,
            'ok' => true,
            'error' => '',
            'row_count' => $n,
            'via' => $fetch['via'] ?? '',
        ];
    }
    $msg = 'ซิงก์สำเร็จ ' . $ok_n . '/' . count($sources) . ' รพ. (' . $total_rows . ' แถว)';
    if ($fail_n > 0) {
        $msg .= ' · ไม่สำเร็จ ' . $fail_n . ' รพ.';
    }
    $detail = [];
    foreach ($results as $r) {
        $detail[] = ($r['ok'] ? 'OK' : 'ERR') . ' ' . $r['name'] . ($r['ok'] ? (' ' . $r['row_count'] . ' แถว') : (' — ' . $r['error']));
    }
    nd_sync_mark_result($con, $ok_n > 0 && $fail_n === 0, $msg, implode("\n", $detail));
    return [
        'status' => ($ok_n > 0 && $fail_n === 0) ? 'success' : ($ok_n > 0 ? 'partial' : 'error'),
        'message' => $msg,
        'ok' => $ok_n,
        'fail' => $fail_n,
        'row_count' => $total_rows,
        'hospitals' => $results,
    ];
}
