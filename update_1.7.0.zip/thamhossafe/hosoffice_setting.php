<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/hosoffice_helper.php';
mysqli_set_charset($con, 'utf8');
hosoffice_ensure_config($con);
$cfg = hosoffice_load_config($con);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เชื่อมต่อ HOSoffice - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .ho-hero {
            background: linear-gradient(135deg, #0f3d4c 0%, #155e75 55%, #0e7490 100%);
            color: #fff; border-radius: 16px; padding: 1.2rem 1.4rem; margin-bottom: 1.1rem;
        }
        .ho-badge { background: rgba(255,255,255,.18); border: 1px solid rgba(255,255,255,.28); }
        .ho-stat { border: 0; border-radius: 12px; }
        .ho-stat .n { font-size: 1.45rem; font-weight: 800; }
        .ho-table-list { max-height: 280px; overflow: auto; }
        .ho-table-list button { text-align: left; }
        .ho-preview { font-size: .8rem; }
        .ho-preview th { white-space: nowrap; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="ho-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="small text-uppercase" style="letter-spacing:.08em;opacity:.75;">ตั้งค่าระบบ · HOSoffice</div>
                    <h4 class="fw-bold mb-1">เชื่อมต่อ HOSoffice</h4>
                    <p class="mb-0 small" style="opacity:.92;">อ่านข้อมูลสำนักงาน / บุคลากร / บัญชี จากฐาน <code>hosoffice</code> เท่านั้น ไม่มีการเขียนหรือแก้ข้อมูลต้นทาง</p>
                </div>
                <span class="badge ho-badge px-3 py-2 fs-6"><i class="fas fa-lock me-1"></i> Read Only</span>
            </div>

            <div class="row g-3 mb-3" id="statRow">
                <div class="col-6 col-lg-3">
                    <div class="card ho-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">สถานะ</div>
                        <div class="n" id="statStatus">กำลังตรวจ…</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card ho-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">ตาราง</div>
                        <div class="n" id="statTables">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card ho-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">บุคลากร</div>
                        <div class="n" id="statPerson">—</div>
                    </div></div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card ho-stat shadow-sm"><div class="card-body py-3">
                        <div class="small text-muted">เวลาตอบ</div>
                        <div class="n" id="statMs">—</div>
                    </div></div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-lg-5">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h6 class="fw-bold mb-3"><i class="fas fa-network-wired me-2 text-info"></i>ข้อมูลการเชื่อมต่อ</h6>
                            <form id="hoForm">
                                <div class="row g-3">
                                    <div class="col-8">
                                        <label class="form-label small fw-bold">Host / IP</label>
                                        <input type="text" class="form-control" name="ho_host" id="ho_host" value="<?php echo htmlspecialchars($cfg['ho_host']); ?>">
                                    </div>
                                    <div class="col-4">
                                        <label class="form-label small fw-bold">Port</label>
                                        <input type="number" class="form-control" name="ho_port" id="ho_port" value="<?php echo htmlspecialchars($cfg['ho_port']); ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label small fw-bold">Database Name</label>
                                        <input type="text" class="form-control" name="ho_db" id="ho_db" value="<?php echo htmlspecialchars($cfg['ho_db']); ?>">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Username</label>
                                        <input type="text" class="form-control" name="ho_user" id="ho_user" value="<?php echo htmlspecialchars($cfg['ho_user']); ?>">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Password</label>
                                        <input type="password" class="form-control" name="ho_pass" id="ho_pass" value="<?php echo ($cfg['ho_pass'] ?? '') !== '' ? '********' : ''; ?>" autocomplete="new-password">
                                        <div class="form-text">เว้น ******** ไว้ถ้าไม่ต้องการเปลี่ยนรหัส</div>
                                    </div>
                                </div>
                                <div class="alert alert-info small mt-3 mb-0">
                                    <i class="fas fa-shield-alt me-1"></i>
                                    บัญชีนี้ถูกบังคับเป็น <b>Read Only</b> ทั้งในระบบ (SELECT/SHOW เท่านั้น) และที่สิทธิ์ MySQL ของ user <code>web</code>
                                </div>
                                <div class="d-flex justify-content-end gap-2 mt-3">
                                    <button type="button" class="btn btn-outline-info fw-bold" id="btnTest">
                                        <i class="fas fa-plug me-1"></i> ทดสอบการเชื่อมต่อ
                                    </button>
                                    <button type="submit" class="btn btn-info text-white fw-bold">
                                        <i class="fas fa-save me-1"></i> บันทึก
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body">
                            <h6 class="fw-bold mb-2"><i class="fas fa-table me-2 text-success"></i>ดูตาราง (อ่านอย่างเดียว)</h6>
                            <div class="input-group input-group-sm mb-2">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" class="form-control" id="tableQ" placeholder="ค้นหาชื่อตาราง เช่น hr_person, acc_">
                            </div>
                            <div class="ho-table-list list-group mb-3" id="tableList">
                                <div class="text-muted small p-2">กำลังโหลดรายการตาราง…</div>
                            </div>
                            <div id="previewBox" class="d-none">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div class="fw-bold" id="previewTitle"></div>
                                    <span class="badge bg-secondary" id="previewHint">ซ่อนคอลัมน์อ่อนไหว</span>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered bg-white ho-preview mb-0">
                                        <thead class="table-light" id="previewHead"></thead>
                                        <tbody id="previewBody"></tbody>
                                    </table>
                                </div>
                            </div>
                            <div id="previewEmpty" class="small text-muted">เลือกตารางด้านบนเพื่อดูตัวอย่าง 20 แถวแรก</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
function formBody(extra) {
    const body = {
        ho_host: document.getElementById('ho_host').value.trim(),
        ho_port: document.getElementById('ho_port').value.trim(),
        ho_db: document.getElementById('ho_db').value.trim(),
        ho_user: document.getElementById('ho_user').value.trim(),
        ho_pass: document.getElementById('ho_pass').value
    };
    return Object.assign(body, extra || {});
}
function api(action, extra) {
    return fetch('fetch_hosoffice_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign(formBody({ action: action }), extra || {}))
    }).then(async function (res) {
        const text = await res.text();
        try { return JSON.parse(text); }
        catch (e) { throw new Error('ไฟล์ API ตอบกลับไม่ใช่ JSON'); }
    });
}
function applyPing(ping) {
    const ok = ping && ping.ok;
    document.getElementById('statStatus').textContent = ok ? 'เชื่อมต่อได้' : 'เชื่อมต่อไม่ได้';
    document.getElementById('statStatus').className = 'n ' + (ok ? 'text-success' : 'text-danger');
    document.getElementById('statTables').textContent = ok ? (ping.table_count || 0).toLocaleString() : '—';
    const person = ((ping && ping.stats) || []).find(function (s) { return s.table === 'hr_person'; });
    document.getElementById('statPerson').textContent = person ? person.count.toLocaleString() : '—';
    document.getElementById('statMs').textContent = ping && ping.ms != null ? (ping.ms + ' ms') : '—';
}
function loadTables(q) {
    const box = document.getElementById('tableList');
    box.innerHTML = '<div class="text-muted small p-2">กำลังค้นหา…</div>';
    api('tables', { q: q || '' }).then(function (data) {
        const tables = data.tables || [];
        if (!tables.length) {
            box.innerHTML = '<div class="text-muted small p-2">ไม่พบตาราง</div>';
            return;
        }
        box.innerHTML = tables.map(function (t) {
            return '<button type="button" class="list-group-item list-group-item-action py-1 px-2 font-monospace" data-table="' + t.replace(/"/g, '') + '">' + t + '</button>';
        }).join('');
    }).catch(function () {
        box.innerHTML = '<div class="text-danger small p-2">โหลดรายการตารางไม่สำเร็จ</div>';
    });
}
function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function previewTable(table) {
    document.getElementById('previewEmpty').classList.add('d-none');
    document.getElementById('previewBox').classList.remove('d-none');
    document.getElementById('previewTitle').textContent = table;
    document.getElementById('previewHead').innerHTML = '';
    document.getElementById('previewBody').innerHTML = '<tr><td class="text-muted">กำลังอ่าน…</td></tr>';
    api('preview', { table: table }).then(function (data) {
        const preview = data.preview || {};
        const cols = preview.columns || [];
        const rows = preview.rows || [];
        if (preview.error) {
            document.getElementById('previewBody').innerHTML = '<tr><td class="text-danger">' + esc(preview.error) + '</td></tr>';
            return;
        }
        document.getElementById('previewHead').innerHTML = '<tr>' + cols.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') + '</tr>';
        if (!rows.length) {
            document.getElementById('previewBody').innerHTML = '<tr><td colspan="' + cols.length + '" class="text-muted">ไม่มีข้อมูล</td></tr>';
            return;
        }
        document.getElementById('previewBody').innerHTML = rows.map(function (r) {
            return '<tr>' + cols.map(function (c) { return '<td>' + esc(r[c]) + '</td>'; }).join('') + '</tr>';
        }).join('');
    }).catch(function () {
        document.getElementById('previewBody').innerHTML = '<tr><td class="text-danger">อ่านตัวอย่างไม่สำเร็จ</td></tr>';
    });
}

document.getElementById('btnTest').addEventListener('click', function () {
    const btn = this;
    const html = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังทดสอบ...';
    api('test').then(function (data) {
        applyPing(data.ping || {});
        alert((data.status === 'success' ? '✅ ' : '❌ ') + data.message);
        if (data.status === 'success') loadTables(document.getElementById('tableQ').value.trim());
    }).catch(function (err) {
        alert('❌ ' + (err.message || 'ทดสอบไม่สำเร็จ'));
    }).finally(function () {
        btn.innerHTML = html;
        btn.disabled = false;
    });
});

document.getElementById('hoForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    const html = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> กำลังบันทึก...';
    api('save').then(function (data) {
        alert((data.status === 'success' ? '✅ ' : '❌ ') + (data.message || ''));
        if (data.status === 'success') api('test').then(function (t) { applyPing(t.ping || {}); });
    }).catch(function () {
        alert('❌ บันทึกไม่สำเร็จ');
    }).finally(function () {
        btn.innerHTML = html;
        btn.disabled = false;
    });
});

let tmr = null;
document.getElementById('tableQ').addEventListener('input', function () {
    clearTimeout(tmr);
    const q = this.value.trim();
    tmr = setTimeout(function () { loadTables(q); }, 250);
});
document.getElementById('tableList').addEventListener('click', function (e) {
    const btn = e.target.closest('[data-table]');
    if (!btn) return;
    previewTable(btn.getAttribute('data-table'));
});

api('test').then(function (data) {
    applyPing(data.ping || {});
    if (data.status === 'success') loadTables('');
    else document.getElementById('tableList').innerHTML = '<div class="text-danger small p-2">' + esc(data.message || 'เชื่อมต่อไม่ได้') + '</div>';
}).catch(function () {
    document.getElementById('statStatus').textContent = 'ตรวจไม่ได้';
});
</script>
</body>
</html>
