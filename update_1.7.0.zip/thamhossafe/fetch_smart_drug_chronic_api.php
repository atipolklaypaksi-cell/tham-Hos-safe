<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

include('connect.php');
require_once __DIR__ . '/smart_drug_chronic_helper.php';
session_write_close();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = [];
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'list'));

if ($action === 'list') {
    echo json_encode([
        'status' => 'success',
        'items' => sd_chronic_list($con),
        'groups' => sd_chronic_groups($con),
        'defaults' => sd_chronic_default_groups(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'search') {
    echo json_encode([
        'status' => 'success',
        'items' => sd_chronic_search($con, $input['q'] ?? ''),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'add') {
    $res = sd_chronic_add($con, $input['tpu_code'] ?? '', $input['drug_name'] ?? '', $input['source_label'] ?? 'เพิ่มเอง');
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['message'] ?? '',
        'items' => sd_chronic_list($con),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'set_group') {
    $res = sd_chronic_set_group($con, $input['id'] ?? 0, $input['source_label'] ?? '');
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['message'] ?? '',
        'items' => sd_chronic_list($con),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'delete') {
    $ok = sd_chronic_delete($con, $input['id'] ?? 0);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'message' => $ok ? '' : 'ลบไม่สำเร็จ',
        'items' => sd_chronic_list($con),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'import_group') {
    if (!function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    }
    $hos = hosxp_connect($con, 20);
    if (!$hos) {
        echo json_encode(['status' => 'error', 'message' => 'เชื่อมต่อ HOSxP ไม่ได้']);
        exit;
    }
    $n = sd_chronic_import_group($con, $hos, $input['property_name'] ?? '');
    mysqli_close($hos);
    if ($n < 0) {
        echo json_encode(['status' => 'error', 'message' => 'นำเข้ากลุ่มนี้ไม่ได้']);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'added' => $n,
        'items' => sd_chronic_list($con),
        'groups' => sd_chronic_groups($con),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'ไม่รู้จักคำสั่ง']);
