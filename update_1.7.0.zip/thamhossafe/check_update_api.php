<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include __DIR__ . '/connect.php';
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/update_check_helper.php';

$user_id = (int)$_SESSION['user_id'];
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = array_merge($_GET, $_POST);
}

$action = trim((string)($input['action'] ?? 'check'));

if ($action === 'snooze') {
    $days = (int)($input['days'] ?? 0);
    $until = tham_update_set_snooze($con, $user_id, $days);
    if ($until === false) {
        echo json_encode(['status' => 'error', 'message' => 'รองรับเฉพาะ 7 หรือ 30 วัน'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'message' => 'จะเตือนอีกครั้งในอีก ' . $days . ' วัน',
        'snooze_until' => $until,
        'days' => $days,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'clear_snooze') {
    tham_update_clear_snooze($con, $user_id);
    echo json_encode(['status' => 'success', 'message' => 'ยกเลิกการเลื่อนเตือนแล้ว'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'set_auto_check') {
    $enabled = !empty($input['enabled']) && $input['enabled'] !== '0' && $input['enabled'] !== false;
    tham_update_set_auto_check($con, $enabled);
    echo json_encode([
        'status' => 'success',
        'auto_check' => $enabled,
        'message' => $enabled ? 'เปิดเช็คอัปเดตอัตโนมัติแล้ว' : 'ปิดเช็คอัปเดตอัตโนมัติแล้ว',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$force = !empty($input['force']);
echo json_encode(tham_update_check_status($con, $user_id, $force), JSON_UNESCAPED_UNICODE);
exit;
