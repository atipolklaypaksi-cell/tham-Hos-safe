<?php
/**
 * นำเข้าสมุดติดตามการแพ้ยาจาก Google Sheet ปีงบ 2569
 * และเทียบกับประวัติแพ้ยาใน HOSxP (opd_allergy)
 */

function af_gsheet_csv_url() {
    return 'https://docs.google.com/spreadsheets/d/1EGvG1dttjckx0o98OkNB5u2kmlc4W5CPU3aBXqcR4rA/export?format=csv&gid=1217796612';
}

function af_sheet_summary_map() {
    return [
        'ไม่แพ้ยา' => 'not_allergy',
        'ปิดเคสไม่ได้' => 'unclosed',
        'กำลังประเมิน' => '',
        'เฝ้าระวัง' => 'monitor',
        'adrs type a' => 'adr_type_a',
        'adr type a' => 'adr_type_a',
        'แพ้ยา' => 'allergy',
    ];
}

function af_sheet_lower($s) {
    $s = (string)$s;
    return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
}

function af_map_sheet_summary($raw) {
    $raw = trim(preg_replace('/\s+/', ' ', (string)$raw));
    if ($raw === '') {
        return '';
    }
    $low = af_sheet_lower($raw);
    if (strpos($low, 'บัตรเดิม') !== false || strpos($low, 'รพ.อื่น') !== false || strpos($low, 'รพ อื่น') !== false) {
        return 'existing_history';
    }
    $map = af_sheet_summary_map();
    if (isset($map[$low])) {
        return $map[$low];
    }
    foreach ($map as $k => $code) {
        if ($k !== '' && strpos($low, $k) !== false) {
            return $code;
        }
    }
    return '';
}

function af_map_sheet_channel($raw) {
    $raw = trim((string)$raw);
    $low = af_sheet_lower($raw);
    if ($low === '') {
        return 'other';
    }
    if (strpos($low, 'ไลน์') !== false || strpos($low, 'ไลน') !== false) {
        return 'line_pharmacy';
    }
    if (strpos($low, 'mr') !== false) {
        return 'line_mr';
    }
    if (strpos($low, 'โทร') !== false) {
        return 'phone';
    }
    if (strpos($low, 'web') !== false || strpos($low, 'เว็บ') !== false) {
        return 'webapp';
    }
    return 'other';
}

function af_parse_sheet_date($s) {
    $s = trim((string)$s);
    if ($s === '') {
        return '';
    }
    $ts = strtotime(str_replace('/', '-', $s));
    if ($ts) {
        return date('Y-m-d', $ts);
    }
    return '';
}

function af_parse_sheet_time($s) {
    $s = trim((string)$s);
    if (preg_match('/^(\d{1,2})[.:](\d{2})/', $s, $m)) {
        $h = max(0, min(23, (int)$m[1]));
        $i = max(0, min(59, (int)$m[2]));
        return sprintf('%02d:%02d:00', $h, $i);
    }
    return null;
}

function af_fetch_gsheet_csv() {
    $url = af_gsheet_csv_url();
    $csv = '';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_USERAGENT => 'THAM-HosSafe-AllergyFollowup',
        ]);
        $csv = (string)curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300 || $csv === '') {
            return ['ok' => false, 'error' => 'ดึง Google Sheet ไม่สำเร็จ (HTTP ' . $code . ')', 'csv' => ''];
        }
    } else {
        $csv = (string)@file_get_contents($url);
        if ($csv === '') {
            return ['ok' => false, 'error' => 'ดึง Google Sheet ไม่สำเร็จ', 'csv' => ''];
        }
    }
    if (strncmp($csv, "\xEF\xBB\xBF", 3) === 0) {
        $csv = substr($csv, 3);
    }
    return ['ok' => true, 'error' => '', 'csv' => $csv];
}

function af_parse_gsheet_rows($csv) {
    $fh = fopen('php://temp', 'r+');
    fwrite($fh, $csv);
    rewind($fh);
    $header = fgetcsv($fh);
    if (!$header) {
        fclose($fh);
        return [];
    }
    $out = [];
    $rownum = 1;
    while (($r = fgetcsv($fh)) !== false) {
        $rownum++;
        if (!is_array($r) || count($r) < 4) {
            continue;
        }
        $date = af_parse_sheet_date($r[0] ?? '');
        $hn = preg_replace('/\s+/', '', (string)($r[3] ?? ''));
        $name = trim(preg_replace('/\s+/', ' ', (string)($r[2] ?? '')));
        if ($date === '' || ($hn === '' && $name === '')) {
            continue;
        }
        $summary_raw = trim((string)($r[8] ?? ''));
        $summary = af_map_sheet_summary($summary_raw);
        $channel_raw = trim((string)($r[6] ?? ''));
        $time = af_parse_sheet_time($r[1] ?? '');
        $key = sha1($date . '|' . ($time ?: '') . '|' . $hn . '|' . $name);
        $out[] = [
            'import_key' => $key,
            'sheet_row' => $rownum,
            'case_date' => $date,
            'notify_time' => $time,
            'ptname' => $name,
            'hn' => $hn,
            'ward' => trim((string)($r[4] ?? '')),
            'ward_detail' => trim((string)($r[5] ?? '')),
            'channel' => af_map_sheet_channel($channel_raw),
            'channel_raw' => $channel_raw,
            'owner_name' => trim((string)($r[7] ?? '')),
            'summary_result' => $summary,
            'summary_raw' => $summary_raw,
            'referral_note' => trim((string)($r[9] ?? '')),
            'assessment_detail' => trim((string)($r[10] ?? '')),
        ];
    }
    fclose($fh);
    return $out;
}

function af_import_gsheet_cases($con) {
    af_ensure_tables($con);
    $got = af_fetch_gsheet_csv();
    if (empty($got['ok'])) {
        return ['ok' => false, 'error' => $got['error'] ?? 'ดึงชีตไม่สำเร็จ', 'inserted' => 0, 'updated' => 0, 'total' => 0];
    }
    $rows = af_parse_gsheet_rows($got['csv']);
    if (empty($rows)) {
        return ['ok' => false, 'error' => 'ไม่พบแถวข้อมูลในชีต', 'inserted' => 0, 'updated' => 0, 'total' => 0];
    }
    $inserted = 0;
    $updated = 0;
    $failed = 0;
    foreach ($rows as $r) {
        $key = mysqli_real_escape_string($con, $r['import_key']);
        $date = mysqli_real_escape_string($con, $r['case_date']);
        $time_sql = $r['notify_time'] ? ("'" . mysqli_real_escape_string($con, $r['notify_time']) . "'") : 'NULL';
        $time_part = $r['notify_time'] ? mysqli_real_escape_string($con, $r['notify_time']) : '00:00:00';
        $hn = mysqli_real_escape_string($con, $r['hn']);
        $name = mysqli_real_escape_string($con, $r['ptname']);
        $ward = mysqli_real_escape_string($con, $r['ward']);
        $detail = mysqli_real_escape_string($con, $r['ward_detail']);
        $ch = mysqli_real_escape_string($con, $r['channel']);
        $rep = mysqli_real_escape_string($con, $r['channel_raw'] !== '' ? $r['channel_raw'] : 'สมุด Google Sheet');
        $owner = mysqli_real_escape_string($con, $r['owner_name']);
        $sum = mysqli_real_escape_string($con, $r['summary_result']);
        $ref = mysqli_real_escape_string($con, $r['referral_note']);
        $ass = mysqli_real_escape_string($con, $r['assessment_detail']);
        $closed = ($r['summary_result'] !== '' && $r['summary_result'] !== 'unclosed');
        $stage = $closed ? 'closed' : ($r['summary_result'] === 'unclosed' ? 'following' : 'reported');
        $status = af_status_from_stage($stage);
        $reported_dt = $date . ' ' . $time_part;
        $closed_at_sql = $closed ? "IFNULL(closed_at, '" . $reported_dt . "')" : 'NULL';
        $closed_at_ins = $closed ? "'" . $reported_dt . "'" : 'NULL';
        $exist = mysqli_query($con, "SELECT id FROM allergy_followup_cases WHERE import_key='$key' LIMIT 1");
        $er = $exist ? mysqli_fetch_assoc($exist) : null;
        if ($er) {
            $id = (int)$er['id'];
            $ok = mysqli_query($con, "UPDATE allergy_followup_cases SET
                case_date='$date', notify_time=$time_sql, hn='$hn', ptname='$name',
                ward='$ward', ward_detail='$detail', channel='$ch', reporter_name='$rep',
                owner_name='$owner', summary_result='$sum', referral_note='$ref',
                assessment_detail='$ass', status='$status', workflow_stage='$stage',
                source_tag='gsheet_2569', created_at='$reported_dt',
                closed_at=$closed_at_sql,
                closed_by_name=IF('$owner'='' OR closed_by_name!='', closed_by_name, '$owner')
                WHERE id=$id");
            if ($ok) {
                $updated++;
            } else {
                $failed++;
            }
        } else {
            $ok = mysqli_query($con, "INSERT INTO allergy_followup_cases
                (case_date, notify_time, hn, ptname, ward, ward_detail, channel,
                 reporter_user_id, reporter_name, owner_user_id, owner_name,
                 summary_result, referral_note, assessment_detail, status,
                 workflow_stage, closed_at, closed_by_name, import_key, source_tag, created_at)
                VALUES ('$date', $time_sql, '$hn', '$name', '$ward', '$detail', '$ch',
                        0, '$rep', 0, '$owner',
                        '$sum', '$ref', '$ass', '$status',
                        '$stage', $closed_at_ins, '$owner', '$key', 'gsheet_2569', '$reported_dt')");
            if ($ok) {
                $inserted++;
            } else {
                $failed++;
            }
        }
    }
    mysqli_query($con, "UPDATE allergy_followup_events e
        INNER JOIN allergy_followup_cases c ON c.id = e.case_id
        SET e.created_at = CONCAT(c.case_date, ' ', IFNULL(c.notify_time, '00:00:00')),
            e.actor_name = IF(IFNULL(e.actor_name,'')='', c.reporter_name, e.actor_name)
        WHERE e.event_type='reported' AND c.source_tag='gsheet_2569'");
    $hosxp_matched = 0;
    $hosxp_missing = 0;
    $q = mysqli_query($con, "SELECT hn, ptname, ward_detail, assessment_detail, summary_result
        FROM allergy_followup_cases WHERE source_tag='gsheet_2569'");
    $probe = [];
    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $probe[] = [
                'hn' => (string)$row['hn'],
                'ward_detail' => (string)$row['ward_detail'],
                'assessment_detail' => (string)$row['assessment_detail'],
                'summary_result' => (string)$row['summary_result'],
            ];
        }
    }
    if ($probe) {
        $probe = af_attach_hosxp_flags($con, $probe);
        foreach ($probe as $c) {
            if (!empty($c['hosxp_logged'])) {
                $hosxp_matched++;
            } elseif (($c['hosxp_label'] ?? '') === 'ยังไม่พบใน HOSxP') {
                $hosxp_missing++;
            }
        }
    }
    return [
        'ok' => true,
        'error' => '',
        'inserted' => $inserted,
        'updated' => $updated,
        'failed' => $failed,
        'total' => count($rows),
        'hosxp_matched' => $hosxp_matched,
        'hosxp_missing' => $hosxp_missing,
    ];
}

function af_norm_drug_token($s) {
    $s = strtolower(trim((string)$s));
    $s = preg_replace('/[^a-z0-9ก-๙]+/u', '', $s);
    return $s;
}

function af_extract_drug_hints($text) {
    $text = (string)$text;
    $hints = [];
    if (preg_match_all('/([A-Za-z][A-Za-z0-9\-]{2,})\s*=/', $text, $m)) {
        foreach ($m[1] as $x) {
            $hints[] = af_norm_drug_token($x);
        }
    }
    if (preg_match_all('/\b([A-Za-z][A-Za-z][A-Za-z0-9\-]{2,})\b/', $text, $m)) {
        $skip = ['mala', 'sjs', 'ten', 'dress', 'adrs', 'nsaid', 'nsaids', 'dose', 'type', 'plan', 'hold', 'temp', 'observe', 'from', 'with', 'that', 'this', 'order'];
        foreach ($m[1] as $x) {
            $n = af_norm_drug_token($x);
            if (strlen($n) < 4 || in_array($n, $skip, true)) {
                continue;
            }
            $hints[] = $n;
        }
    }
    return array_values(array_unique(array_filter($hints)));
}

function af_attach_hosxp_flags($con, array $cases) {
    if (empty($cases)) {
        return $cases;
    }
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 20) : null;
    if (!$hos) {
        foreach ($cases as &$c) {
            $c['hosxp_logged'] = false;
            $c['hosxp_match'] = '';
            $c['hosxp_agents'] = [];
            $c['hosxp_label'] = '';
        }
        unset($c);
        return $cases;
    }
    $all_hn = [];
    foreach ($cases as $c) {
        foreach (af_hn_variants($c['hn'] ?? '') as $v) {
            $all_hn[$v] = true;
        }
    }
    $map = [];
    if ($all_hn) {
        $in = [];
        foreach (array_keys($all_hn) as $v) {
            $in[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
        }
        $chunk = array_chunk($in, 400);
        foreach ($chunk as $part) {
            $sql = "SELECT hn,
                    CAST(CONVERT(IFNULL(agent,'') USING utf8) AS CHAR) AS agent,
                    CAST(CONVERT(IFNULL(symptom,'') USING utf8) AS CHAR) AS symptom
                FROM opd_allergy
                WHERE hn IN (" . implode(',', $part) . ")";
            $q = @mysqli_query($hos, $sql);
            if (!$q) {
                continue;
            }
            while ($r = mysqli_fetch_assoc($q)) {
                $disp = af_hn_display($r['hn'] ?? '');
                $pad = ctype_digit((string)$r['hn']) ? str_pad((string)$r['hn'], 9, '0', STR_PAD_LEFT) : (string)$r['hn'];
                $agent = trim((string)$r['agent']);
                if ($agent === '') {
                    continue;
                }
                foreach ([$disp, $pad, (string)$r['hn']] as $k) {
                    if ($k === '') {
                        continue;
                    }
                    if (!isset($map[$k])) {
                        $map[$k] = [];
                    }
                    $map[$k][$agent] = true;
                }
            }
        }
    }
    @mysqli_close($hos);

    foreach ($cases as &$c) {
        $agents = [];
        foreach (af_hn_variants($c['hn'] ?? '') as $v) {
            if (!empty($map[$v])) {
                $agents = array_merge($agents, array_keys($map[$v]));
            }
        }
        $agents = array_values(array_unique($agents));
        $logged = !empty($agents);
        $match = '';
        if ($logged) {
            $match = 'hn';
            $blob = strtolower(($c['ward_detail'] ?? '') . ' ' . ($c['assessment_detail'] ?? ''));
            $hints = af_extract_drug_hints($blob);
            foreach ($agents as $ag) {
                $na = af_norm_drug_token($ag);
                foreach ($hints as $h) {
                    if ($na !== '' && $h !== '' && (strpos($na, $h) !== false || strpos($h, $na) !== false)) {
                        $match = 'drug';
                        break 2;
                    }
                }
            }
        }
        $need = in_array(($c['summary_result'] ?? ''), ['allergy', 'existing_history', 'monitor', 'adr_type_a'], true);
        $c['hosxp_logged'] = $logged;
        $c['hosxp_match'] = $match;
        $c['hosxp_agents'] = array_slice($agents, 0, 8);
        if ($logged) {
            $c['hosxp_label'] = 'ลงข้อมูลใน HOSxP แล้ว';
        } elseif ($need) {
            $c['hosxp_label'] = 'ยังไม่พบใน HOSxP';
        } else {
            $c['hosxp_label'] = '';
        }
    }
    unset($c);
    return $cases;
}
