<?php
/**
 * เชื่อมต่อไป HAPYsure (CPOE)
 * เก็บเฉพาะ URL ต้นทางใน sys_config — ไม่เก็บรหัสผ่าน
 */

function hapysure_config_keys() {
    return ['hapysure_base_url', 'hapysure_login_path'];
}

function hapysure_default_config() {
    return [
        'hapysure_base_url' => 'https://192.168.6.10:8443',
        'hapysure_login_path' => '/login',
    ];
}

function hapysure_upsert_config($con, $key, $value) {
    $k = mysqli_real_escape_string($con, $key);
    $v = mysqli_real_escape_string($con, (string)$value);
    $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
    if ($chk && mysqli_num_rows($chk) > 0) {
        return (bool)mysqli_query($con, "UPDATE sys_config SET config_value='$v' WHERE config_name='$k'");
    }
    return (bool)mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('$k', '$v')");
}

function hapysure_ensure_config($con) {
    foreach (hapysure_default_config() as $key => $value) {
        $k = mysqli_real_escape_string($con, $key);
        $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='$k' LIMIT 1");
        if (!$chk || mysqli_num_rows($chk) === 0) {
            hapysure_upsert_config($con, $key, $value);
        }
    }
}

function hapysure_load_config($con) {
    hapysure_ensure_config($con);
    $cfg = hapysure_default_config();
    $keys = "'" . implode("','", array_map(static function ($k) use ($con) {
        return mysqli_real_escape_string($con, $k);
    }, hapysure_config_keys())) . "'";
    $q = mysqli_query($con, "SELECT config_name, config_value FROM sys_config WHERE config_name IN ($keys)");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $cfg[$r['config_name']] = (string)$r['config_value'];
        }
    }
    $cfg['hapysure_base_url'] = hapysure_normalize_base($cfg['hapysure_base_url'] ?? '');
    $cfg['hapysure_login_path'] = hapysure_normalize_path($cfg['hapysure_login_path'] ?? '/login');
    return $cfg;
}

function hapysure_save_config($con, array $input) {
    $next = hapysure_load_config($con);
    if (array_key_exists('hapysure_base_url', $input)) {
        $next['hapysure_base_url'] = hapysure_normalize_base($input['hapysure_base_url']);
    }
    if (array_key_exists('hapysure_login_path', $input)) {
        $next['hapysure_login_path'] = hapysure_normalize_path($input['hapysure_login_path']);
    }
    foreach (hapysure_config_keys() as $key) {
        hapysure_upsert_config($con, $key, $next[$key] ?? '');
    }
    return hapysure_load_config($con);
}

function hapysure_normalize_base($url) {
    $url = trim((string)$url);
    $url = preg_replace('#\s+#', '', $url);
    $url = rtrim($url, '/');
    if ($url === '') {
        return '';
    }
    if (!preg_match('#^https?://#i', $url)) {
        $url = 'https://' . ltrim($url, '/');
    }
    $p = parse_url($url);
    $scheme = strtolower((string)($p['scheme'] ?? ''));
    $host = strtolower((string)($p['host'] ?? ''));
    if (!in_array($scheme, ['http', 'https'], true)) {
        return '';
    }
    if ($host === '' || !preg_match('/^[a-z0-9][a-z0-9.-]*[a-z0-9]$|^[a-z0-9]$/', $host)) {
        return '';
    }
    $port = isset($p['port']) ? (':' . (int)$p['port']) : '';
    return $scheme . '://' . $host . $port;
}

function hapysure_normalize_path($path) {
    $path = trim((string)$path);
    if ($path === '') {
        return '/login';
    }
    if (!preg_match('#^/#', $path)) {
        $path = '/' . ltrim($path, '/');
    }
    if (!preg_match('#^/[a-zA-Z0-9/_\-]*$#', $path)) {
        return '/login';
    }
    return $path;
}

function hapysure_login_url($base, $path = '/login') {
    $base = hapysure_normalize_base($base);
    if ($base === '') {
        return '';
    }
    return $base . hapysure_normalize_path($path);
}

function hapysure_session_save_credentials($username, $password) {
    $username = trim((string)$username);
    $password = (string)$password;
    if ($username === '' || $password === '') {
        return false;
    }
    $_SESSION['hapysure_user'] = $username;
    $_SESSION['hapysure_pass'] = $password;
    return true;
}

function hapysure_session_clear_credentials() {
    unset($_SESSION['hapysure_user'], $_SESSION['hapysure_pass']);
}

function hapysure_suggest_username() {
    $saved = trim((string)($_SESSION['hapysure_user'] ?? ''));
    if ($saved !== '') {
        return $saved;
    }
    $profile = $_SESSION['provider_profile'] ?? [];
    if (is_array($profile)) {
        $pid = trim((string)($profile['provider_id'] ?? $profile['data']['provider_id'] ?? ''));
        if ($pid === '' && isset($profile['data']) && is_array($profile['data'])) {
            $pid = trim((string)($profile['data']['provider_id'] ?? ''));
        }
        if ($pid !== '') {
            return $pid;
        }
    }
    $u = trim((string)($_SESSION['username'] ?? ''));
    if (strpos($u, 'pid_') === 0) {
        $u = substr($u, 4);
    }
    return $u;
}

function hapysure_session_credentials() {
    $user = trim((string)($_SESSION['hapysure_user'] ?? ''));
    $pass = (string)($_SESSION['hapysure_pass'] ?? '');
    return [
        'user' => $user,
        'pass' => $pass,
        'ok' => $user !== '' && $pass !== '',
    ];
}

function hapysure_launch_url($base, $hn, $vn, $vstdate) {
    $base = hapysure_normalize_base($base);
    if ($base === '') {
        return '';
    }
    $hn = trim((string)$hn);
    $vn = trim((string)$vn);
    $vstdate = substr(trim((string)$vstdate), 0, 10);
    if ($hn === '') {
        return $base;
    }
    $params = ['hn' => $hn];
    if ($vn !== '') {
        $params['vn'] = $vn;
    }
    if ($vstdate !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $vstdate)) {
        $params['vstdate'] = $vstdate;
    }
    $params['status'] = 'NEW';
    return $base . '/cpoe-detail?' . http_build_query($params);
}

function hapysure_tcp_probe($host, $port, $timeout = 3) {
    $host = trim((string)$host);
    $port = (int)$port;
    $out = ['ok' => false, 'errno' => 0, 'error' => '', 'ms' => 0];
    if ($host === '' || $port <= 0) {
        $out['error'] = 'ไม่ได้ระบุโฮสต์หรือพอร์ต';
        return $out;
    }
    $errno = 0;
    $errstr = '';
    $t0 = microtime(true);
    $fp = @fsockopen($host, $port, $errno, $errstr, max(1, min(8, (int)$timeout)));
    $out['ms'] = round((microtime(true) - $t0) * 1000, 1);
    $out['errno'] = (int)$errno;
    $out['error'] = trim((string)$errstr);
    if ($fp) {
        fclose($fp);
        $out['ok'] = true;
        $out['error'] = '';
    }
    return $out;
}

function hapysure_offline_message() {
    return 'ไม่เชื่อมต่อ HAPYsure ยังไม่สามารถใช้งานได้';
}

function hapysure_connect_status($con) {
    $cfg = hapysure_load_config($con);
    $base = $cfg['hapysure_base_url'] ?? '';
    if ($base === '') {
        return ['ok' => false, 'connected' => false, 'error' => hapysure_offline_message()];
    }
    $p = parse_url($base);
    $host = (string)($p['host'] ?? '');
    $scheme = strtolower((string)($p['scheme'] ?? 'https'));
    $port = (int)($p['port'] ?? ($scheme === 'http' ? 80 : 443));
    if ($host === '' || $port <= 0) {
        return ['ok' => false, 'connected' => false, 'error' => hapysure_offline_message()];
    }
    $probe = hapysure_tcp_probe($host, $port, 3);
    if (empty($probe['ok'])) {
        return ['ok' => false, 'connected' => false, 'error' => hapysure_offline_message()];
    }
    return ['ok' => true, 'connected' => true, 'error' => ''];
}

function hapysure_payload($con, $hn = '', $vn = '', $vstdate = '') {
    $cfg = hapysure_load_config($con);
    $url = hapysure_launch_url($cfg['hapysure_base_url'], $hn, $vn, $vstdate);
    $qs = [];
    if (trim((string)$hn) !== '') {
        $qs['hn'] = $hn;
    }
    if (trim((string)$vn) !== '') {
        $qs['vn'] = $vn;
    }
    $date = substr(trim((string)$vstdate), 0, 10);
    if ($date !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        $qs['vstdate'] = $date;
    }
    $sso = 'hapysure_sso.php' . ($qs ? ('?' . http_build_query($qs)) : '');
    $creds = hapysure_session_credentials();
    return [
        'configured' => $cfg['hapysure_base_url'] !== '',
        'base_url' => $cfg['hapysure_base_url'],
        'launch_url' => $url,
        'sso_url' => $sso,
        'has_credentials' => !empty($creds['ok']),
        'suggest_user' => hapysure_suggest_username(),
    ];
}
