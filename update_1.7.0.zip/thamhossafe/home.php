<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
mysqli_set_charset($con, 'utf8');
if (is_file(__DIR__ . '/user_unit_helper.php')) {
    require_once __DIR__ . '/user_unit_helper.php';
    if (function_exists('tham_user_load_unit_session')) {
        tham_user_load_unit_session($con, (int)$_SESSION['user_id']);
    }
}
if (is_file(__DIR__ . '/smart_pharma_backup_helper.php')) {
    require_once __DIR__ . '/smart_pharma_backup_helper.php';
}
if (is_file(__DIR__ . '/home_ipd_ward_helper.php')) {
    require_once __DIR__ . '/home_ipd_ward_helper.php';
}
$hiw_show = function_exists('hiw_can_view') && hiw_can_view($con);
$hiw_boot = null;
if ($hiw_show && function_exists('hiw_get_overview')) {
    // force=false ใช้ cache สั้นๆ แต่ต้องมี orders.timing ครบ — ถ้ารูปแบบเก่าให้ดึงใหม่
    $hiw_boot = hiw_get_overview($con, false);
    if (is_array($hiw_boot) && (empty($hiw_boot['orders']) || !isset($hiw_boot['orders']['key_minutes']))) {
        $hiw_boot = hiw_get_overview($con, true);
    }
}
$hiw_boot_json = '';
if (is_array($hiw_boot)) {
    $flags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $hiw_boot_json = json_encode([
        'status' => !empty($hiw_boot['ok']) ? 'success' : 'error',
        'msg' => !empty($hiw_boot['ok']) ? 'ok' : ($hiw_boot['error'] ?? 'โหลดไม่สำเร็จ'),
        'data' => $hiw_boot,
    ], $flags);
    if ($hiw_boot_json === false) {
        $hiw_boot_json = '{"status":"error","msg":"encode failed","data":null}';
    }
}
$hiw_css_ver = @filemtime(__DIR__ . '/css/home_ipd_ward.css') ?: time();
$hiw_js_ver = @filemtime(__DIR__ . '/js/home_ipd_ward.js') ?: time();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>หน้าหลัก - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <?php if ($hiw_show): ?>
    <link href="css/home_ipd_ward.css?v=<?= (int)$hiw_css_ver ?>" rel="stylesheet">
    <?php endif; ?>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>

    <div id="content" class="content p-4<?= $hiw_show ? ' hiw-content' : '' ?>">
        <?php if ($hiw_show): ?>
        <div id="hiwRoot" class="hiw-wrap hiw-wrap-full" aria-live="polite"
             data-api="fetch_home_ipd_ward_api.php"></div>
        <script type="application/json" id="hiwBoot"><?= $hiw_boot_json ?></script>
        <?php else: ?>
        <div class="page-hero mb-4">
            <h2 class="fw-bold mb-1"><i class="fas fa-shield-virus me-2"></i>ยินดีต้อนรับ, <?php echo htmlspecialchars($_SESSION['full_name'], ENT_QUOTES, 'UTF-8'); ?></h2>
            <p class="mb-0 text-muted">ระบบจัดการความปลอดภัยด้านยาและเชื่อมต่อ HOSxP</p>
        </div>

        <?php if (!empty($_SESSION['provider_oauth_warning'])): ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-1"></i>
                <?php echo htmlspecialchars($_SESSION['provider_oauth_warning'], ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <?php unset($_SESSION['provider_oauth_warning']); ?>
        <?php endif; ?>
        <?php if (!empty($_SESSION['provider_oauth_notice'])): ?>
            <div class="alert alert-success py-2 small">
                <i class="fas fa-link me-1"></i>
                <?php echo htmlspecialchars($_SESSION['provider_oauth_notice'], ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <?php unset($_SESSION['provider_oauth_notice']); ?>
        <?php elseif (!empty($_SESSION['login_via']) && $_SESSION['login_via'] === 'provider_id'): ?>
            <div class="alert alert-info py-2 small">
                <i class="fas fa-id-card me-1"></i>
                เข้าสู่ระบบด้วย Provider ID
                <?php if (!empty($_SESSION['moph_access_token_idp'])): ?>
                    — พร้อมใช้งาน Drugs Center
                <?php else: ?>
                    — ยังไม่มี moph token สำหรับ Drugs Center
                <?php endif; ?>
                <?php if (!empty($_SESSION['role'])): ?>
                    · role: <strong><?php echo htmlspecialchars($_SESSION['role'], ENT_QUOTES, 'UTF-8'); ?></strong>
                <?php endif; ?>
            </div>
        <?php elseif (!empty($_SESSION['auth_source']) && $_SESSION['auth_source'] === 'provider_id'): ?>
            <div class="alert alert-info py-2 small">
                <i class="fas fa-id-card me-1"></i>
                เข้าสู่ระบบด้วย Provider ID
                <?php if (!empty($_SESSION['moph_access_token_idp'])): ?>
                    — พร้อมใช้งาน Drugs Center
                <?php else: ?>
                    — ยังไม่มี moph token สำหรับ Drugs Center
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-md-6 col-xl-4">
                <a href="alert_agent.php" class="home-card">
                    <div class="home-card-icon text-success"><i class="fas fa-download"></i></div>
                    <h5 class="fw-bold">ดาวน์โหลด THAM Notify</h5>
                    <p class="text-muted mb-0 small">โปรแกรมแจ้งเตือนบนเครื่อง เปิดเองแบบ SCPH Notify — รับ consult / เตือนยา แม้ไม่ได้เปิดเว็บ</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_drug_interaction.php" class="home-card">
                    <div class="home-card-icon text-danger"><i class="fas fa-pills"></i></div>
                    <h5 class="fw-bold">Monitor Interaction</h5>
                    <p class="text-muted mb-0 small">ตรวจสอบปฏิกิริยาระหว่างยา</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_lab_renal.php" class="home-card">
                    <div class="home-card-icon text-primary"><i class="fas fa-heartbeat"></i></div>
                    <h5 class="fw-bold">Monitor Lab ไต</h5>
                    <p class="text-muted mb-0 small">เฝ้าระวัง CrCl / CKD-EPI</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_lab_hepatic.php" class="home-card">
                    <div class="home-card-icon text-warning"><i class="fas fa-lungs"></i></div>
                    <h5 class="fw-bold">Monitor Lab ตับ</h5>
                    <p class="text-muted mb-0 small">เฝ้าระวัง AST / ALT / Bilirubin</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_hla.php" class="home-card">
                    <div class="home-card-icon" style="color:#9b59b6;"><i class="fas fa-dna"></i></div>
                    <h5 class="fw-bold">Monitor ยีนแพ้ยา HLA</h5>
                    <p class="text-muted mb-0 small">คัดกรอง HLA-B ก่อนยาควบคุมโรคข้อ</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_drug_usage.php" class="home-card">
                    <div class="home-card-icon" style="color:#0d9488;"><i class="fas fa-prescription-bottle-alt"></i></div>
                    <h5 class="fw-bold">Monitor วิธีใช้ยา</h5>
                    <p class="text-muted mb-0 small">ตรวจวิธีใช้ เช่น Methotrexate วัน/สัปดาห์</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_max_dose.php" class="home-card">
                    <div class="home-card-icon" style="color:#7c3aed;"><i class="fas fa-tachometer-alt"></i></div>
                    <h5 class="fw-bold">Monitor Max Dose/Duration</h5>
                    <p class="text-muted mb-0 small">ตรวจ mg/วัน และระยะเวลาสั่งยาเกินขีดจำกัด</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_warfarin.php" class="home-card">
                    <div class="home-card-icon" style="color:#0f766e;"><i class="fas fa-heartbeat"></i></div>
                    <h5 class="fw-bold">Monitor Warfarin</h5>
                    <p class="text-muted mb-0 small">เฝ้าระวังความเหมาะสมตาม Guideline + INR</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_mg_ml.php" class="home-card">
                    <div class="home-card-icon" style="color:#0d6efd;"><i class="fas fa-syringe"></i></div>
                    <h5 class="fw-bold">Monitor mg. to mL.</h5>
                    <p class="text-muted mb-0 small">ตรวจการแปลง mg → mL ในวิธีใช้ยา (IPD/OPD)</p>
                </a>
            </div>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('safety.pediatric')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_pediatric_dose.php" class="home-card">
                    <div class="home-card-icon" style="color:#db2777;"><i class="fas fa-child"></i></div>
                    <h5 class="fw-bold">Monitor ยาเด็ก</h5>
                    <p class="text-muted mb-0 small">ตรวจขนาดยาเด็กตาม mg/kg จากรายการในคำนวณขนาดยาในเด็ก</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('safety.antibiotic')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_antibiotic.php" class="home-card">
                    <div class="home-card-icon" style="color:#047857;"><i class="fas fa-bacteria"></i></div>
                    <h5 class="fw-bold">Monitor Antibiotic</h5>
                    <p class="text-muted mb-0 small">ดักจับการใช้ปฏิชีวนะฉีด IPD เกินเกณฑ์วัน (ค่าเริ่มต้น &gt; 10 วัน)</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('amr.dashboard')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="amr_dashboard.php" class="home-card">
                    <div class="home-card-icon" style="color:#dc2626;"><i class="fas fa-virus"></i></div>
                    <h5 class="fw-bold">AMR Dashboard</h5>
                    <p class="text-muted mb-0 small">เฝ้าระวังเชื้อดื้อยา IPD — NI/CI, แยกเชื้อ / หอผู้ป่วย / specimen</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('amr.sensitivity')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="amr_sensitivity.php" class="home-card">
                    <div class="home-card-icon" style="color:#0f766e;"><i class="fas fa-vial"></i></div>
                    <h5 class="fw-bold">CDSS for Antibiotic</h5>
                    <p class="text-muted mb-0 small">ผลเพาะเชื้อ / AST, ประวัติยาปฏิชีวนะ และ eGFR</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('amr.monitor_drug')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_amr_drug.php" class="home-card">
                    <div class="home-card-icon text-danger"><i class="fas fa-exclamation-triangle"></i></div>
                    <h5 class="fw-bold">Monitor AMR Drug</h5>
                    <p class="text-muted mb-0 small">ดักยาปฏิชีวนะที่กำลังให้แต่ผลเพาะเชื้อเป็น R</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('amr.monitor_sepsis')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_sepsis.php" class="home-card">
                    <div class="home-card-icon" style="color:#b91c1c;"><i class="fas fa-heartbeat"></i></div>
                    <h5 class="fw-bold">Monitor Sepsis by score</h5>
                    <p class="text-muted mb-0 small">ประเมิน qSOFA / SIRS / SOFA และคะแนนที่ตั้งค่าเอง</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('amr.monitor_sepsis_culture')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_sepsis_culture.php" class="home-card">
                    <div class="home-card-icon" style="color:#b91c1c;"><i class="fas fa-tint"></i></div>
                    <h5 class="fw-bold">Monitor Sepsis by culture</h5>
                    <p class="text-muted mb-0 small">ผลเพาะเลือดที่พบเชื้อ — ตรวจว่าได้ยาปฏิชีวนะแล้วหรือยัง</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('amr.amass')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="amr_amass_dashboard.php" class="home-card">
                    <div class="home-card-icon" style="color:#0f766e;"><i class="fas fa-file-medical"></i></div>
                    <h5 class="fw-bold">Dashboard AMASS</h5>
                    <p class="text-muted mb-0 small">รายงาน AMR ตาม AMASS v4.0 build 4028 — Dashboard และพิมพ์ PDF</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('amr.antibiogram')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="amr_antibiogram.php" class="home-card">
                    <div class="home-card-icon" style="color:#0f766e;"><i class="fas fa-th"></i></div>
                    <h5 class="fw-bold">Antibiogram</h5>
                    <p class="text-muted mb-0 small">%S สะสมตาม CLSI M39 · แปลผล M100 · ชุดเชื้อ NARST / WHO GLASS</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('amr.kpi')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="amr_kpi.php" class="home-card">
                    <div class="home-card-icon" style="color:#0f766e;"><i class="fas fa-percentage"></i></div>
                    <h5 class="fw-bold">KPI AMR</h5>
                    <p class="text-muted mb-0 small">ร้อยละผู้ป่วย CAP ที่ใช้ยากลุ่ม Medium watch (AWaRe) · แยกกลุ่มชุมชน / กลุ่มเสี่ยง</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('safety.home_med')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_home_med.php" class="home-card">
                    <div class="home-card-icon" style="color:#c2410c;"><i class="fas fa-home"></i></div>
                    <h5 class="fw-bold">Monitor ยากลับบ้าน IPD</h5>
                    <p class="text-muted mb-0 small">IPD HME เทียบยา OPD ก่อน admit — กันจ่ายซ้ำ</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('safety.opd_dup')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_opd_dup.php" class="home-card">
                    <div class="home-card-icon" style="color:#c2410c;"><i class="fas fa-history"></i></div>
                    <h5 class="fw-bold">Monitor ยาเหลือ OPD</h5>
                    <p class="text-muted mb-0 small">ใบยา OPD เทียบยาเดิมที่ยังเหลือที่บ้าน — กันจ่ายซ้ำก่อนหมด</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('safety.dup_therapy')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_dup_therapy.php" class="home-card">
                    <div class="home-card-icon" style="color:#4338ca;"><i class="fas fa-layer-group"></i></div>
                    <h5 class="fw-bold">Monitor คู่ยาซ้ำซ้อน</h5>
                    <p class="text-muted mb-0 small">ตรวจ Therapeutic Duplication ในวันเดียวกัน เช่น Paracetamol + สูตรผสม, NSAID สองชนิด</p>
                </a>
            </div>
            <?php endif; ?>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_opd_order_qty.php" class="home-card">
                    <div class="home-card-icon" style="color:#0891b2;"><i class="fas fa-calculator"></i></div>
                    <h5 class="fw-bold">Monitor จำนวนสั่งยา</h5>
                    <p class="text-muted mb-0 small">OPD — ตรวจ qty ถึงวันนัด (ไม่ให้ขาด / เกินได้ 10 วัน)</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="monitor_drug_allergy.php" class="home-card">
                    <div class="home-card-icon text-danger"><i class="fas fa-allergies"></i></div>
                    <h5 class="fw-bold">Monitor Drug Allergy</h5>
                    <p class="text-muted mb-0 small">ตรวจแพ้ยาด้วยชื่อ TMT + ข้ามกลุ่ม</p>
                </a>
            </div>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('allergy_report') || tham_menu_can('allergy_followup')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="allergy_report.php" class="home-card">
                    <div class="home-card-icon" style="color:#be123c;"><i class="fas fa-camera"></i></div>
                    <h5 class="fw-bold">แจ้งเคสแพ้ยา</h5>
                    <p class="text-muted mb-0 small">พยาบาลส่งรูปอาการและรายละเอียดจากหอผู้ป่วย</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('allergy_followup')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="allergy_followup.php" class="home-card">
                    <div class="home-card-icon" style="color:#be123c;"><i class="fas fa-book-medical"></i></div>
                    <h5 class="fw-bold">ติดตามการแพ้ยา</h5>
                    <p class="text-muted mb-0 small">พยาบาลส่งรูปอาการ — เภสัชประเมินและติดตามเคส</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('allergy_history')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="allergy_history.php" class="home-card">
                    <div class="home-card-icon" style="color:#9f1239;"><i class="fas fa-notes-medical"></i></div>
                    <h5 class="fw-bold">ประวัติแพ้ยาใน รพ.</h5>
                    <p class="text-muted mb-0 small">ดึงบันทึกแพ้ยาจาก HOSxP — DRESS / SJS / TEN / MALA</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('allergy_eval_dashboard') || tham_menu_can('allergy_followup')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="allergy_eval_dashboard.php" class="home-card">
                    <div class="home-card-icon" style="color:#be123c;"><i class="fas fa-chart-pie"></i></div>
                    <h5 class="fw-bold">Dashboard การประเมินแพ้ยา</h5>
                    <p class="text-muted mb-0 small">สรุปเป็นรายตามเภสัช — ตั้งค่ามูลค่าต่อประเภทเคส</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('pharm_care.patient_opd') || tham_menu_can('pharm_care.smart_lab')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="patient_opd.php" class="home-card">
                    <div class="home-card-icon" style="color:#0aa2c0;"><i class="fas fa-user-injured"></i></div>
                    <h5 class="fw-bold">Patient OPD</h5>
                    <p class="text-muted mb-0 small">ดูประวัติผู้ป่วย OPD — ยา / LAB / visit / สิทธิ์ / นัดหมาย</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('pharm_care.patient_ipd') || tham_menu_can('pharm_care.patient_opd')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="patient_ipd.php" class="home-card">
                    <div class="home-card-icon" style="color:#1488a3;"><i class="fas fa-procedures"></i></div>
                    <h5 class="fw-bold">Patient IPD</h5>
                    <p class="text-muted mb-0 small">Medication Profile ผู้ป่วยใน — Continuous / Oneday / Order คล้าย PharMS</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('pharm_care.med_recon_discharge') || tham_menu_can('pharm_care.smart_drug')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="med_reconcile_discharge.php" class="home-card">
                    <div class="home-card-icon text-success"><i class="fas fa-house-user"></i></div>
                    <h5 class="fw-bold">Med Reconcile ยากลับบ้าน</h5>
                    <p class="text-muted mb-0 small">เทียบยาก่อน Admit · ขณะ Admit · HME กลับบ้าน</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="med_recon_history.php" class="home-card">
                    <div class="home-card-icon" style="color:#b45309;"><i class="fas fa-history"></i></div>
                    <h5 class="fw-bold">ประวัติการทำ Med Reconcile</h5>
                    <p class="text-muted mb-0 small">แยกตาม AN และผู้ทำ · ดูรายการที่ดึงจาก Visit กับที่เพิ่มนอกสถานพยาบาล</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('pharm_care.med_error')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="med_error.php" class="home-card">
                    <div class="home-card-icon text-danger"><i class="fas fa-exclamation-triangle"></i></div>
                    <h5 class="fw-bold">Med error/Consult</h5>
                    <p class="text-muted mb-0 small">บันทึกความคลาดเคลื่อนทางยา / ปรึกษาแพทย์ และรายงานสรุป</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('pharm_care.med_error_report') || tham_menu_can('pharm_care.med_error')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="report_med_error.php" class="home-card">
                    <div class="home-card-icon text-danger"><i class="fas fa-chart-bar"></i></div>
                    <h5 class="fw-bold">รายงาน ME/Consult</h5>
                    <p class="text-muted mb-0 small">สรุปจำนวนที่บันทึก ME / Consult รายบุคคล</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('drug_center.med_reconcile')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="dc_med_reconcile.php" class="home-card">
                    <div class="home-card-icon" style="color:#0d9488;"><i class="fas fa-notes-medical"></i></div>
                    <h5 class="fw-bold">Med Reconcile (PHR)</h5>
                    <p class="text-muted mb-0 small">ประวัติรับยาจาก Drugs Center / PHR กลาง</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('drug_center.check_all')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="dc_check_drug_all.php" class="home-card">
                    <div class="home-card-icon text-danger"><i class="fas fa-shield-alt"></i></div>
                    <h5 class="fw-bold">Check Drug All</h5>
                    <p class="text-muted mb-0 small">ตรวจ Interaction + Allergy + Med Reconcile จาก PHR</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (function_exists('tham_menu_can') && tham_menu_can('dose_calc.hub')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="dose_calculator.php" class="home-card">
                    <div class="home-card-icon" style="color:#db2777;"><i class="fas fa-calculator"></i></div>
                    <h5 class="fw-bold">ระบบช่วยคำนวณยา</h5>
                    <p class="text-muted mb-0 small">Methylpred · rT-PA · TNK ตามน้ำหนัก</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (function_exists('tham_menu_can') && tham_menu_can('dose_calc.warfarin')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="warfarin_calculator.php" class="home-card">
                    <div class="home-card-icon" style="color:#dc2626;"><i class="fas fa-pills"></i></div>
                    <h5 class="fw-bold">คำนวณยา Warfarin</h5>
                    <p class="text-muted mb-0 small">ดึง mg/สัปดาห์จาก HN · ปรับ % · แนะนำวิธีใช้</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (function_exists('tham_menu_can') && tham_menu_can('dose_calc.mg_ml')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="mg_ml_calculator.php" class="home-card">
                    <div class="home-card-icon" style="color:#0d6efd;"><i class="fas fa-syringe"></i></div>
                    <h5 class="fw-bold">คำนวณ mg → mL</h5>
                    <p class="text-muted mb-0 small">ค้นหา HN · แปลงขนาดยาฉีดตามความเข้มข้นที่ตั้งค่า</p>
                </a>
            </div>
            <?php endif; ?>
            <?php if (function_exists('tham_menu_can') && tham_menu_can('dose_calc.pediatric')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="pediatric_dose_calculator.php" class="home-card">
                    <div class="home-card-icon" style="color:#db2777;"><i class="fas fa-child"></i></div>
                    <h5 class="fw-bold">คำนวณขนาดยาในเด็ก</h5>
                    <p class="text-muted mb-0 small">ดึงน้ำหนักจาก HN · ช่วง mg/kg · mg/dose · mL/dose</p>
                </a>
            </div>
            <?php endif; ?>
            <div class="col-md-6 col-xl-4">
                <a href="smart_pharma_opd.php" class="home-card">
                    <div class="home-card-icon" style="color:#17a2b8;"><i class="fas fa-hospital-user"></i></div>
                    <h5 class="fw-bold">Smart Pharma OPD</h5>
                    <p class="text-muted mb-0 small">คัดกรองผู้ป่วยนอกรายวัน</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="smart_pharma_ipd.php" class="home-card">
                    <div class="home-card-icon" style="color:#0d9488;"><i class="fas fa-procedures"></i></div>
                    <h5 class="fw-bold">Smart Pharma IPD</h5>
                    <p class="text-muted mb-0 small">คัดกรองผู้ป่วยในรายวัน</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="hosxp_setting.php" class="home-card">
                    <div class="home-card-icon text-olive"><i class="fas fa-network-wired"></i></div>
                    <h5 class="fw-bold">ตั้งค่า HOSxP</h5>
                    <p class="text-muted mb-0 small">เชื่อมต่อและกำหนด Lab Code</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="hosxp_master_setting.php" class="home-card">
                    <div class="home-card-icon" style="color:#d97706;"><i class="fas fa-database"></i></div>
                    <h5 class="fw-bold">เชื่อมต่อ HOSxP master</h5>
                    <p class="text-muted mb-0 small">สำรองไว้ดึงรายการเฉพาะที่คิวรีเบา</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="hosoffice_setting.php" class="home-card">
                    <div class="home-card-icon" style="color:#0e7490;"><i class="fas fa-building"></i></div>
                    <h5 class="fw-bold">เชื่อมต่อ HOSoffice</h5>
                    <p class="text-muted mb-0 small">อ่านข้อมูลสำนักงานแบบ Read Only</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="jhcis_setting.php" class="home-card">
                    <div class="home-card-icon" style="color:#059669;"><i class="fas fa-clinic-medical"></i></div>
                    <h5 class="fw-bold">เชื่อมต่อ JHCIS PCC</h5>
                    <p class="text-muted mb-0 small">ฐาน jhcisdb · อ่านอย่างเดียว</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="robot_setting.php" class="home-card">
                    <div class="home-card-icon" style="color:#2563eb;"><i class="fas fa-robot"></i></div>
                    <h5 class="fw-bold">เชื่อมต่อ Robot OPD</h5>
                    <p class="text-muted mb-0 small">MySQL ระบบ Robot OPD · อ่านอย่างเดียว</p>
                </a>
            </div>
            <?php if (!function_exists('tham_menu_can') || tham_menu_can('invc.stock')): ?>
            <div class="col-md-6 col-xl-4">
                <a href="invc_stock.php" class="home-card">
                    <div class="home-card-icon" style="color:#4f46e5;"><i class="fas fa-boxes"></i></div>
                    <h5 class="fw-bold">ระบบ INVC</h5>
                    <p class="text-muted mb-0 small">สต็อกคงเหลือ ค้นชื่อ ประวัติเบิก และ Min/Max</p>
                </a>
            </div>
            <?php endif; ?>
            <div class="col-md-6 col-xl-4">
                <a href="invc_setting.php" class="home-card">
                    <div class="home-card-icon" style="color:#4f46e5;"><i class="fas fa-boxes"></i></div>
                    <h5 class="fw-bold">เชื่อมต่อ INVC</h5>
                    <p class="text-muted mb-0 small">คลังยา SQL Server · Read Only</p>
                </a>
            </div>
            <div class="col-md-6 col-xl-4">
                <a href="hospital_connect.php" class="home-card">
                    <div class="home-card-icon" style="color:#2563eb;"><i class="fas fa-hospital"></i></div>
                    <h5 class="fw-bold">เชื่อมต่อรพ. ต่างๆ</h5>
                    <p class="text-muted mb-0 small">ฐาน MySQL แต่ละรพ. · Explore แบบอ่านอย่างเดียว</p>
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<?php if ($hiw_show): ?>
<script src="js/home_ipd_ward.js?v=<?= (int)$hiw_js_ver ?>"></script>
<?php endif; ?>
</body>
</html>
