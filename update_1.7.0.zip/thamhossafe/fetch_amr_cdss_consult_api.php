<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
session_write_close();
include(__DIR__ . '/amr_cdss_consult_helper.php');
mysqli_set_charset($con, 'utf8');

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

$actor_id = (int)($_SESSION['user_id'] ?? 0);
$actor_name = trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? ''));
$action = $_POST['action'] ?? $_GET['action'] ?? '';

acc_ensure_tables($con);

function acc_api_parse_case() {
    $case = [];
    $raw = '';
    if (!empty($_POST['payload_json'])) {
        $raw = (string)$_POST['payload_json'];
    } elseif (!empty($_POST['case_json'])) {
        $raw = (string)$_POST['case_json'];
    }
    if ($raw !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            $case = $decoded;
        }
    }
    if (empty($case)) {
        $case = $_POST;
    }
    return $case;
}

function acc_api_ensure_id($con, array $case, $actor_id) {
    $id = (int)($case['consult_id'] ?? $case['id'] ?? 0);
    if ($id > 0) {
        return $id;
    }
    $order = $case['lab_order_number'] ?? $case['order'] ?? '';
    $found = acc_find_by_order($con, $order);
    if ($found) {
        return (int)$found['id'];
    }
    $up = acc_upsert_from_case($con, $case, [
        'created_by' => $actor_id,
        'updated_by' => $actor_id,
    ]);
    return !empty($up['ok']) ? (int)$up['id'] : 0;
}

if ($action === 'pharmacists') {
    ob_clean();
    echo json_encode([
        'status' => 'success',
        'pharmacists' => acc_list_pharmacists($con, $actor_id),
        'current_user_id' => $actor_id,
        'current_user_name' => $actor_name,
        'reply_wait_days' => acc_get_reply_wait_days($con),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'get') {
    $id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
    $order = $_GET['order'] ?? $_POST['order'] ?? $_GET['lab_order_number'] ?? $_POST['lab_order_number'] ?? '';
    $row = null;
    if ($id > 0) {
        $row = acc_get_consult($con, $id);
    } elseif ($order !== '') {
        $row = acc_find_by_order($con, $order);
    }
    ob_clean();
    echo json_encode([
        'status' => 'success',
        'consult' => $row ? acc_format_consult_row($row) : null,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'list') {
    $hn = $_GET['hn'] ?? $_POST['hn'] ?? '';
    $an = $_GET['an'] ?? $_POST['an'] ?? '';
    $order = $_GET['order'] ?? $_POST['order'] ?? $_GET['lab_order_number'] ?? '';
    if (trim((string)$hn) === '' && trim((string)$an) === '' && trim((string)$order) === '') {
        ob_clean();
        echo json_encode(['status' => 'success', 'consults' => [], 'count' => 0], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $rows = acc_list_consults($con, [
        'hn' => $_GET['hn'] ?? $_POST['hn'] ?? '',
        'an' => $_GET['an'] ?? $_POST['an'] ?? '',
        'lab_order_number' => $_GET['order'] ?? $_POST['order'] ?? $_GET['lab_order_number'] ?? '',
        'limit' => (int)($_GET['limit'] ?? $_POST['limit'] ?? 50),
    ]);
    ob_clean();
    echo json_encode(['status' => 'success', 'consults' => $rows, 'count' => count($rows)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'history') {
    $hn = $_GET['hn'] ?? $_POST['hn'] ?? '';
    $order = $_GET['order'] ?? $_POST['order'] ?? $_GET['lab_order_number'] ?? $_POST['lab_order_number'] ?? '';
    $consult_id = (int)($_GET['consult_id'] ?? $_POST['consult_id'] ?? 0);
    if ($consult_id <= 0 && trim((string)$hn) === '' && trim((string)$order) === '') {
        ob_clean();
        echo json_encode(['status' => 'success', 'history' => [], 'consults' => [], 'count' => 0], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $consults = acc_list_consults($con, [
        'hn' => $hn,
        'limit' => 50,
    ]);
    if (!$consults && $order !== '') {
        $consults = acc_list_consults($con, [
            'lab_order_number' => $order,
            'limit' => 20,
        ]);
    }
    if ($consult_id <= 0 && $order !== '') {
        $found = acc_find_by_order($con, $order);
        if ($found) {
            $consult_id = (int)$found['id'];
        }
    }
    $hist_opts = ['limit' => (int)($_GET['limit'] ?? $_POST['limit'] ?? 100)];
    if ($consult_id > 0 && empty($_GET['all_hn']) && empty($_POST['all_hn'])) {
        $hist_opts['consult_id'] = $consult_id;
    } elseif ($hn !== '') {
        $hist_opts['hn'] = $hn;
    } elseif ($order !== '') {
        $hist_opts['lab_order_number'] = $order;
    }
    $rows = acc_list_history($con, $hist_opts);
    ob_clean();
    echo json_encode([
        'status' => 'success',
        'history' => $rows,
        'consults' => $consults,
        'count' => count($rows),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'start' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $case = acc_api_parse_case();
    $pharmacist_id = (int)($_POST['pharmacist_user_id'] ?? $actor_id);
    $pharmacist_name = trim((string)($_POST['pharmacist_name'] ?? ''));
    $note = trim((string)($_POST['consult_note'] ?? ''));
    $wait = isset($_POST['reply_wait_days'])
        ? acc_normalize_reply_wait_days($_POST['reply_wait_days'])
        : acc_get_reply_wait_days($con);
    $res = acc_start_consult($con, $case, $pharmacist_id, $pharmacist_name, $note, $actor_id, $wait, $actor_name);
    ob_clean();
    if (empty($res['ok'])) {
        echo json_encode(['status' => 'error', 'message' => $res['error'] ?? 'ไม่สามารถเริ่ม Consult ได้'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'message' => $res['message'],
        'id' => $res['id'],
        'consult' => $res['consult'],
        'print_url' => $res['print_url'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'reprint' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $case = acc_api_parse_case();
    $id = acc_api_ensure_id($con, $case, $actor_id);
    if ($id <= 0) {
        ob_clean();
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบ Consult'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $res = acc_reprint($con, $id, $actor_id, $actor_name);
    ob_clean();
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['message'] ?? ($res['error'] ?? ''),
        'consult' => $res['consult'] ?? null,
        'print_url' => $res['print_url'] ?? '',
        'id' => $id,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'close' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $case = acc_api_parse_case();
    $id = acc_api_ensure_id($con, $case, $actor_id);
    if ($id <= 0) {
        ob_clean();
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบ Consult'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $res = acc_close_consult(
        $con,
        $id,
        trim((string)($_POST['consult_note'] ?? '')),
        trim((string)($_POST['doctor_reply'] ?? '')),
        $actor_id,
        $actor_name,
        (int)($_POST['pharmacist_user_id'] ?? $actor_id),
        trim((string)($_POST['pharmacist_name'] ?? ''))
    );
    ob_clean();
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['message'] ?? ($res['error'] ?? ''),
        'consult' => $res['consult'] ?? null,
        'id' => $id,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_result' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $case = acc_api_parse_case();
    $id = acc_api_ensure_id($con, $case, $actor_id);
    if ($id <= 0) {
        ob_clean();
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบ Consult'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $res = acc_save_result(
        $con,
        $id,
        trim((string)($_POST['consult_note'] ?? '')),
        trim((string)($_POST['doctor_reply'] ?? '')),
        $actor_id,
        $actor_name,
        (int)($_POST['pharmacist_user_id'] ?? $actor_id),
        trim((string)($_POST['pharmacist_name'] ?? ''))
    );
    ob_clean();
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['message'] ?? ($res['error'] ?? ''),
        'consult' => $res['consult'] ?? null,
        'id' => $id,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'reset_waiting' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $case = acc_api_parse_case();
    $id = acc_api_ensure_id($con, $case, $actor_id);
    if ($id <= 0) {
        ob_clean();
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบ Consult'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $res = acc_reset_waiting($con, $id, $actor_id, trim((string)($_POST['consult_note'] ?? '')), $actor_name);
    ob_clean();
    echo json_encode([
        'status' => !empty($res['ok']) ? 'success' : 'error',
        'message' => $res['message'] ?? ($res['error'] ?? ''),
        'consult' => $res['consult'] ?? null,
        'id' => $id,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

ob_clean();
echo json_encode(['status' => 'error', 'message' => 'Unknown action'], JSON_UNESCAPED_UNICODE);
exit;
