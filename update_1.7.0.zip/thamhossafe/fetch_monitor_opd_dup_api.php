<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_opd_dup_helper.php');
include(__DIR__ . '/monitor_opd_dup_consult_helper.php');
mysqli_set_charset($con, 'utf8');
mopdc_ensure_tables($con);
set_time_limit(180);

function mopd_api_req($key, $default = '') {
    if (isset($_POST[$key]) && (is_string($_POST[$key]) || is_numeric($_POST[$key]))) {
        return trim((string)$_POST[$key]);
    }
    if (isset($_GET[$key]) && (is_string($_GET[$key]) || is_numeric($_GET[$key]))) {
        return trim((string)$_GET[$key]);
    }
    return $default;
}

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

$start_date = mopd_api_req('start_date', date('Y-m-d', strtotime('-3 days')));
$end_date = mopd_api_req('end_date', date('Y-m-d'));
$shard = (int)mopd_api_req('shard', '0');
$shards = (int)mopd_api_req('shards', '1');
if ($shards < 1) {
    $shards = 1;
}
if ($shards > 16) {
    $shards = 16;
}
if ($shard < 0) {
    $shard = 0;
}
$shard = $shard % $shards;

$hn_raw = mopd_api_req('hn', '');
$hn_filter = [];
if ($hn_raw !== '') {
    $hn_filter[] = $hn_raw;
}

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-3 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if (strtotime($start_date) > strtotime($end_date)) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

$hos = hosxp_connect($con, 180);
if (!$hos) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}
mysqli_set_charset($hos, 'utf8');
if (function_exists('hosxp_extend_read_timeout')) {
    hosxp_extend_read_timeout($hos, 180);
}

$result = mopd_scan($con, $hos, $start_date, $end_date, $shard, $shards, $hn_filter);
mysqli_close($hos);

if (!empty($result['meta']['error']) && empty($result['hard_alerts']) && empty($result['soft_alerts'])
    && empty($result['patients'])
    && strpos((string)$result['meta']['error'], 'SQL') !== false) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'error',
        'message' => $result['meta']['error'],
        'meta' => $result['meta'],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$patients = mopdc_attach_to_patients($con, $result['patients'] ?? []);
$hard_alerts = mopdc_attach_to_alerts($con, $result['hard_alerts'] ?? []);
$soft_alerts = mopdc_attach_to_alerts($con, $result['soft_alerts'] ?? []);
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';
$patients = sp_alert_mute_filter_rows($con, $patients);
$hard_alerts = sp_alert_mute_filter_rows($con, $hard_alerts);
$soft_alerts = sp_alert_mute_filter_rows($con, $soft_alerts);

ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'status' => 'success',
    'patients' => $patients,
    'hard_alerts' => $hard_alerts,
    'soft_alerts' => $soft_alerts,
    'meta' => $result['meta'],
], JSON_UNESCAPED_UNICODE);
exit;
