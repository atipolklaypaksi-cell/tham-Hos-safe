<?php
/**
 * API ตั้งค่าเชื่อมต่อ AMR / mLAB
 */
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();
set_time_limit(600);
ini_set('memory_limit', '1024M');
include(__DIR__ . '/connect.php');
session_write_close();
require_once __DIR__ . '/amr_mlab_helper.php';
mysqli_set_charset($con, 'utf8');

function amr_conn_json(array $payload, $code = 200) {
    ob_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    amr_conn_json(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบ'], 401);
}

amr_mlab_ensure_tables($con);
$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}
$action = trim((string)($input['action'] ?? $_GET['action'] ?? 'get'));

if ($action === 'get') {
    $cfg = amr_mlab_get_config($con);
    $cfg['pass'] = $cfg['pass'] !== '' ? '********' : '';
    $sync = amr_mlab_last_sync($con);
    amr_conn_json([
        'status' => 'success',
        'config' => $cfg,
        'sync' => $sync,
    ]);
}

if ($action === 'save') {
    $cfg = amr_mlab_save_config($con, $input);
    $cfg['pass'] = $cfg['pass'] !== '' ? '********' : '';
    amr_conn_json([
        'status' => 'success',
        'message' => 'บันทึกการเชื่อมต่อ AMR แล้ว',
        'config' => $cfg,
        'sync' => amr_mlab_last_sync($con),
    ]);
}

if ($action === 'test') {
    $cfg = amr_mlab_get_config($con);
    foreach (['host', 'port', 'db', 'user', 'dbf_path', 'dbf_mode', 'smb_share', 'smb_remote'] as $k) {
        if (isset($input[$k])) {
            $cfg[$k] = trim((string)$input[$k]);
        }
    }
    if (isset($input['pass']) && (string)$input['pass'] !== '' && (string)$input['pass'] !== '********') {
        $cfg['pass'] = (string)$input['pass'];
    }
    $test = amr_mlab_test_connection($cfg);
    amr_conn_json([
        'status' => ($test['sql_ok'] || $test['dbf_ok']) ? 'success' : 'error',
        'message' => $test['sql_ok'] || $test['dbf_ok']
            ? 'ทดสอบการเชื่อมต่อแล้ว'
            : 'ยังเชื่อม mLAB ไม่ได้ — ตรวจ Host/รหัสผ่าน หรือโฟลเดอร์ DBF',
        'test' => $test,
    ]);
}

if ($action === 'sync') {
    $full = !empty($input['full']);
    $res = amr_mlab_sync($con, $full);
    amr_conn_json([
        'status' => $res['status'] === 'ok' ? 'success' : 'error',
        'message' => $res['message'] !== '' ? $res['message'] : 'ซิงก์เสร็จแล้ว',
        'result' => $res,
        'sync' => amr_mlab_last_sync($con),
    ]);
}

if ($action === 'clone_plan') {
    set_time_limit(300);
    $plan = amr_mlab_clone_plan($con, true);
    amr_conn_json([
        'status' => !empty($plan['ok']) ? 'success' : 'error',
        'message' => !empty($plan['ok'])
            ? ('พบใบแล็บใน mLAB ' . number_format((int)$plan['sp_nrec']) . ' รายการ · เหลือ ' . (int)($plan['pending_n'] ?? count($plan['chunks'])) . ' เดือนที่ยังไม่ครบ')
            : ($plan['error'] ?? 'วางแผนดึงทั้งฐานไม่สำเร็จ'),
        'plan' => $plan,
        'sync' => amr_mlab_last_sync($con),
    ]);
}

if ($action === 'clone_chunk') {
    set_time_limit(0);
    ignore_user_abort(true);
    $start = substr(trim((string)($input['start'] ?? '')), 0, 10);
    $end = substr(trim((string)($input['end'] ?? '')), 0, 10);
    $label = trim((string)($input['label'] ?? ''));
    if ($label === '') {
        $label = substr($start, 0, 7);
    }
    $est = (int)($input['est'] ?? 0);
    $force = !empty($input['force']);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
        amr_conn_json(['status' => 'error', 'message' => 'ช่วงวันที่ไม่ถูกต้อง'], 400);
    }
    if (amr_mlab_clone_chunk_is_done($con, $label, $start, $end, $est, $force)) {
        $have = amr_mlab_lab_count_range($con, $start, $end);
        amr_conn_json([
            'status' => 'success',
            'skipped' => true,
            'message' => $label . ' มีข้อมูลครบแล้ว ข้าม',
            'result' => [
                'status' => 'ok',
                'inserted' => 0,
                'updated' => 0,
                'skipped' => $have,
                'message' => 'ข้ามเดือนที่มีข้อมูลครบแล้ว',
            ],
            'sync' => amr_mlab_last_sync($con),
            'chunk' => ['start' => $start, 'end' => $end, 'label' => $label, 'have' => $have, 'est' => $est],
        ]);
    }
    $res = amr_mlab_sync($con, true, [
        'start' => $start,
        'end' => $end,
        'skip_pull' => true,
        'clone' => true,
    ]);
    if (($res['status'] ?? '') === 'ok') {
        $have = amr_mlab_lab_count_range($con, $start, $end);
        amr_mlab_clone_mark_done($con, $label, $end, $have);
    }
    amr_conn_json([
        'status' => $res['status'] === 'ok' ? 'success' : 'error',
        'message' => $res['message'] !== '' ? $res['message'] : 'ดึงช่วงนี้เสร็จแล้ว',
        'result' => $res,
        'sync' => amr_mlab_last_sync($con),
        'chunk' => ['start' => $start, 'end' => $end, 'label' => $label],
    ]);
}

amr_conn_json(['status' => 'error', 'message' => 'action ไม่ถูกต้อง']);
