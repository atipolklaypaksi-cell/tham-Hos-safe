<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/med_error_helper.php';
mysqli_set_charset($con, 'utf8');
med_error_ensure_tables($con);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id > 0) {
    $ok = mysqli_query($con, "DELETE FROM med_error_records WHERE id = $id");
    if ($ok) {
        echo "<script>alert('ลบข้อมูลเหตุการณ์เรียบร้อยแล้ว'); window.location.href='med_error.php';</script>";
    } else {
        echo "<script>alert(" . json_encode('เกิดข้อผิดพลาดในการลบ: ' . mysqli_error($con), JSON_UNESCAPED_UNICODE) . "); window.location.href='med_error.php';</script>";
    }
} else {
    header('Location: med_error.php');
}
mysqli_close($con);
