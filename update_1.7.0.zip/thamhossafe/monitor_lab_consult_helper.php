<?php
/**
 * Monitor Lab — Consult / ใบปรึกษาแพทย์ + ประวัติ (แบบ Monitor Antibiotic)
 */

function mlc_consult_statuses() {
    return [
        'waiting' => 'รอ Consult',
        'in_progress' => 'รอตอบกลับ',
        'closed' => 'ปิด Consult',
    ];
}

function mlc_consult_normalize_status($status) {
    $s = trim((string)$status);
    if ($s === 'in_progress' || $s === 'progress' || $s === 'consulting') {
        return 'in_progress';
    }
    if ($s === 'closed' || $s === 'done' || $s === 'resolved') {
        return 'closed';
    }
    return 'waiting';
}

function mlc_consult_status_label($status) {
    $map = mlc_consult_statuses();
    $status = mlc_consult_normalize_status($status);
    return $map[$status] ?? $status;
}

function mlc_ensure_tables($con) {
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_lab_consults.sql');
    if ($sql !== false && trim($sql) !== '') {
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
            if ($stmt === '') {
                continue;
            }
            @mysqli_query($con, $stmt);
        }
    }
    $chk = @mysqli_query($con, "SHOW TABLES LIKE 'monitor_lab_consults'");
    if (!($chk && mysqli_num_rows($chk) > 0)) {
        return false;
    }
    $col = @mysqli_query($con, "SHOW COLUMNS FROM monitor_lab_consults LIKE 'lab_value'");
    if ($col && ($info = mysqli_fetch_assoc($col))) {
        $type = strtolower((string)($info['Type'] ?? ''));
        if (strpos($type, 'text') === false) {
            @mysqli_query($con, "ALTER TABLE monitor_lab_consults MODIFY COLUMN lab_value TEXT NULL");
        }
    }
    return true;
}

function mlc_normalize_reply_wait_days($days) {
    return max(0, min(30, (int)$days));
}

function mlc_reply_wait_label($days) {
    $days = (int)$days;
    return $days <= 0 ? 'ทันที' : ($days . ' วัน');
}

function mlc_get_reply_wait_days($con) {
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='mlc_reply_wait_days' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $val = (int)$r['config_value'];
        if ((string)$r['config_value'] === '3') {
            @mysqli_query($con, "UPDATE sys_config SET config_value='0' WHERE config_name='mlc_reply_wait_days' AND config_value='3'");
            return 0;
        }
        return mlc_normalize_reply_wait_days($val);
    }
    @mysqli_query($con, "INSERT IGNORE INTO sys_config (config_name, config_value) VALUES ('mlc_reply_wait_days', '0')");
    return 0;
}

function mlc_consult_outcome_options() {
    return [
        'stop' => 'หยุดยา',
        'hold' => 'hold ยา',
        'reduce' => 'ลดขนาดยา',
        'continue' => 'ให้ยาต่อ',
        'other' => 'อื่นๆ ระบุ',
    ];
}

function mlc_parse_consult_outcome($text) {
    $raw = trim((string)$text);
    $options = mlc_consult_outcome_options();
    if ($raw === '') {
        return ['key' => '', 'extra' => '', 'raw' => ''];
    }
    foreach ($options as $k => $lab) {
        $short = $k === 'other' ? 'อื่นๆ' : $lab;
        if ($raw === $lab || $raw === $short || $raw === ('ผลการปรึกษา: ' . $lab) || $raw === ('ผลการปรึกษา: ' . $short)) {
            return ['key' => $k, 'extra' => '', 'raw' => $raw];
        }
    }
    $lines = preg_split("/\r\n|\n|\r/", $raw);
    $first = trim((string)($lines[0] ?? ''));
    $rest = trim(implode("\n", array_slice($lines, 1)));
    if (preg_match('/^ผลการปรึกษา:\s*(.+)$/u', $first, $m)) {
        $payload = trim($m[1]);
        foreach ($options as $k => $lab) {
            $short = $k === 'other' ? 'อื่นๆ' : $lab;
            if ($payload === $lab || $payload === $short || mb_strpos($payload, $short, 0, 'UTF-8') === 0) {
                $after = trim(mb_substr($payload, mb_strlen($short), null, 'UTF-8'));
                $after = preg_replace('/^[—\-–:\s]+/u', '', $after);
                $extra = trim($after . ($rest !== '' ? "\n" . $rest : ''));
                return ['key' => $k, 'extra' => $extra, 'raw' => $raw];
            }
        }
    }
    return ['key' => '', 'extra' => $raw, 'raw' => $raw];
}

function mlc_consult_outcome_checked_html($text) {
    $parsed = mlc_parse_consult_outcome($text);
    $parts = [];
    foreach (mlc_consult_outcome_options() as $k => $lab) {
        $mark = ($parsed['key'] === $k) ? '☑' : '☐';
        $suffix = '';
        if ($k === 'other' && $parsed['key'] === 'other' && $parsed['extra'] !== '') {
            $suffix = ' ' . $parsed['extra'];
        }
        $parts[] = $mark . ' ' . $lab . $suffix;
    }
    return implode(' &nbsp;&nbsp; ', $parts);
}

function mlc_list_pharmacists($con, $prefer_user_id = 0) {
    require_once __DIR__ . '/opduser_auth_helper.php';
    return tham_list_consult_pharmacists($con, $prefer_user_id);
}

function mlc_resolve_pharmacist($con, $user_id, $fallback_name = '') {
    $user_id = (int)$user_id;
    if ($user_id > 0) {
        $q = mysqli_query($con, "SELECT id, full_name, username FROM users WHERE id = $user_id LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            $name = trim((string)($r['full_name'] ?? ''));
            if ($name === '') {
                $name = trim((string)($r['username'] ?? ''));
            }
            return ['id' => (int)$r['id'], 'name' => $name];
        }
    }
    return ['id' => 0, 'name' => trim((string)$fallback_name)];
}

function mlc_case_key($organ, $hn, $icode, $order_date, $order_time, $lab_key) {
    $hn = ltrim(trim((string)$hn), '0');
    $icode = trim((string)$icode);
    $order_date = substr(trim((string)$order_date), 0, 10);
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $order_date, $m)) {
        $order_date = sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[2], (int)$m[1]);
    }
    $order_time = substr(trim((string)$order_time), 0, 8);
    $lab_key = trim((string)$lab_key);
    $organ = trim((string)$organ);
    return $organ . '|' . $hn . '|' . $icode . '|' . $order_date . '|' . $order_time . '|' . $lab_key;
}

function mlc_lab_key_from_item(array $item) {
    $organ = $item['organ'] ?? 'renal';
    if ($organ === 'other') {
        return trim((string)($item['lab_items_code'] ?? $item['lab_type'] ?? ''));
    }
    return trim((string)($item['lab_type'] ?? ''));
}

function mlc_case_key_from_item(array $item) {
    return mlc_case_key(
        $item['organ'] ?? 'renal',
        $item['hn'] ?? '',
        $item['icode'] ?? '',
        $item['order_date_iso'] ?? ($item['order_date'] ?? ''),
        $item['order_time'] ?? '',
        mlc_lab_key_from_item($item)
    );
}

function mlc_get_consult($con, $id) {
    mlc_ensure_tables($con);
    $id = (int)$id;
    if ($id <= 0) {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM monitor_lab_consults WHERE id = $id LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function mlc_find_by_key($con, $case_key) {
    mlc_ensure_tables($con);
    $k = mysqli_real_escape_string($con, trim((string)$case_key));
    if ($k === '') {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM monitor_lab_consults WHERE case_key = '$k' LIMIT 1");
    return ($q && ($r = mysqli_fetch_assoc($q))) ? $r : null;
}

function mlc_format_consult_row(array $r) {
    $status = mlc_consult_normalize_status($r['status'] ?? 'waiting');
    return [
        'id' => (int)($r['id'] ?? 0),
        'organ' => (string)($r['organ'] ?? ''),
        'case_key' => (string)($r['case_key'] ?? ''),
        'hn' => (string)($r['hn'] ?? ''),
        'an' => (string)($r['an'] ?? ''),
        'vn' => (string)($r['vn'] ?? ''),
        'icode' => (string)($r['icode'] ?? ''),
        'drug_name' => (string)($r['drug_name'] ?? ''),
        'method_text' => (string)($r['method_text'] ?? ''),
        'qty' => $r['qty'] ?? '',
        'ward_name' => (string)($r['ward_name'] ?? ''),
        'ptname' => (string)($r['ptname'] ?? ''),
        'order_date' => (string)($r['order_date'] ?? ''),
        'order_time' => (string)($r['order_time'] ?? ''),
        'lab_type' => (string)($r['lab_type'] ?? ''),
        'lab_value' => (string)($r['lab_value'] ?? ''),
        'warning_msg' => (string)($r['warning_msg'] ?? ''),
        'alert_level' => (string)($r['alert_level'] ?? 'soft'),
        'actual_dose' => (string)($r['actual_dose'] ?? ''),
        'recommended_dose' => strip_tags((string)($r['recommended_dose'] ?? '')),
        'status' => $status,
        'status_label' => mlc_consult_status_label($status),
        'pharmacist_user_id' => (int)($r['pharmacist_user_id'] ?? 0),
        'pharmacist_name' => (string)($r['pharmacist_name'] ?? ''),
        'consult_note' => (string)($r['consult_note'] ?? ''),
        'doctor_reply' => (string)($r['doctor_reply'] ?? ''),
        'reply_wait_days' => (int)($r['reply_wait_days'] ?? 0),
        'reply_due_at' => (string)($r['reply_due_at'] ?? ''),
        'started_at' => (string)($r['started_at'] ?? ''),
        'closed_at' => (string)($r['closed_at'] ?? ''),
        'printed_at' => (string)($r['printed_at'] ?? ''),
    ];
}

function mlc_lab_value_print_html($lab_type, $lab_value) {
    $raw = str_replace(["\r\n", "\r"], "\n", trim((string)$lab_value));
    $type = trim((string)$lab_type);
    if ($raw === '') {
        return $type !== '' ? '<strong>' . htmlspecialchars($type) . '</strong>' : '-';
    }
    $is_detail = (strpos($raw, "\n") !== false)
        || (stripos($raw, 'Child-Pugh') !== false)
        || (stripos($raw, 'MELD') !== false)
        || (strpos($raw, '→') !== false);
    $lines = array_values(array_filter(array_map('trim', explode("\n", $raw)), static function ($l) {
        return $l !== '';
    }));
    $html = '';
    foreach ($lines as $i => $line) {
        $is_group = preg_match('/^(Child-Pugh|MELD-Na|MELD|Clinical)\b/u', $line)
            && strpos($line, '→') === false
            && stripos($line, 'mg/dL') === false
            && stripos($line, 'mmol') === false;
        $cls = ($i === 0 || $is_group) ? 'lab-head' : 'lab-line';
        $html .= '<div class="' . $cls . '">' . htmlspecialchars($line) . '</div>';
    }
    if (!$is_detail && $type !== '' && stripos($raw, $type) === false) {
        return '<strong>' . htmlspecialchars($type) . '</strong>' . $html;
    }
    return $html !== '' ? $html : htmlspecialchars($raw);
}

function mlc_default_consult_virtual(array $item) {
    return [
        'id' => 0,
        'organ' => (string)($item['organ'] ?? ''),
        'case_key' => mlc_case_key_from_item($item),
        'hn' => (string)($item['hn'] ?? ''),
        'status' => 'waiting',
        'status_label' => mlc_consult_status_label('waiting'),
        'consult_note' => '',
        'doctor_reply' => '',
        'pharmacist_name' => '',
        'reply_wait_days' => 0,
        'reply_due_at' => '',
        'printed_at' => '',
    ];
}

function mlc_process_timeouts($con) {
    mlc_ensure_tables($con);
    $q = mysqli_query($con, "SELECT * FROM monitor_lab_consults
        WHERE status = 'in_progress' AND reply_due_at IS NOT NULL AND reply_due_at <= NOW()");
    if (!$q) {
        return 0;
    }
    $n = 0;
    while ($row = mysqli_fetch_assoc($q)) {
        $id = (int)$row['id'];
        if (mysqli_query($con, "UPDATE monitor_lab_consults SET
            status='waiting', reply_due_at=NULL, updated_at=NOW() WHERE id=$id")) {
            $n++;
            $after = mlc_get_consult($con, $id);
            mlc_log_history($con, [
                'consult_id' => $id,
                'row' => $after ?: $row,
                'action_key' => 'timeout_reply',
                'action_label' => 'หมดเวลารอตอบ — กลับเป็นรอ Consult',
                'status_before' => 'in_progress',
                'status_after' => 'waiting',
                'actor_name' => 'ระบบ',
            ]);
        }
    }
    return $n;
}

function mlc_index_by_keys($con, array $keys) {
    mlc_ensure_tables($con);
    mlc_process_timeouts($con);
    $map = [];
    $keys = array_values(array_unique(array_filter(array_map('trim', $keys))));
    if (empty($keys)) {
        return $map;
    }
    $in = [];
    foreach ($keys as $k) {
        $in[] = "'" . mysqli_real_escape_string($con, $k) . "'";
    }
    foreach (array_chunk($in, 200) as $chunk) {
        $q = mysqli_query($con, 'SELECT * FROM monitor_lab_consults WHERE case_key IN (' . implode(',', $chunk) . ')');
        if (!$q) {
            continue;
        }
        while ($r = mysqli_fetch_assoc($q)) {
            $map[$r['case_key']] = mlc_format_consult_row($r);
        }
    }
    return $map;
}

function mlc_attach_to_alerts($con, $organ, array $alerts) {
    $keys = [];
    foreach ($alerts as $it) {
        $it['organ'] = $organ;
        $keys[] = mlc_case_key_from_item($it);
    }
    $map = mlc_index_by_keys($con, $keys);
    foreach ($alerts as &$it) {
        $it['organ'] = $organ;
        $k = mlc_case_key_from_item($it);
        $it['case_key'] = $k;
        $it['consult'] = $map[$k] ?? mlc_default_consult_virtual($it);
    }
    unset($it);
    return $alerts;
}

function mlc_esc_date($con, $date) {
    $date = substr(trim((string)$date), 0, 10);
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $date, $m)) {
        $date = sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[2], (int)$m[1]);
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return 'NULL';
    }
    return "'" . mysqli_real_escape_string($con, $date) . "'";
}

function mlc_upsert_from_case($con, array $case, array $extra = []) {
    mlc_ensure_tables($con);
    $organ = in_array(($case['organ'] ?? ''), ['renal', 'hepatic', 'other'], true) ? $case['organ'] : 'renal';
    $case['organ'] = $organ;
    $key = trim((string)($case['case_key'] ?? ''));
    if ($key === '') {
        $key = mlc_case_key_from_item($case);
    }
    if ($key === '' || trim((string)($case['hn'] ?? '')) === '') {
        return ['ok' => false, 'error' => 'ข้อมูลเคสไม่ครบ'];
    }
    $existing = mlc_find_by_key($con, $key);
    $hn = mysqli_real_escape_string($con, ltrim(trim((string)($case['hn'] ?? '')), '0'));
    $an = mysqli_real_escape_string($con, trim((string)($case['an'] ?? '')));
    $vn = mysqli_real_escape_string($con, trim((string)($case['vn'] ?? '')));
    $icode = mysqli_real_escape_string($con, trim((string)($case['icode'] ?? '')));
    $drug = mysqli_real_escape_string($con, trim((string)($case['drug_name'] ?? $case['drug'] ?? '')));
    $method = mysqli_real_escape_string($con, trim((string)($case['method_text'] ?? $case['drug_method'] ?? $case['method'] ?? '')));
    $qty = is_numeric($case['qty'] ?? '') ? (float)$case['qty'] : 'NULL';
    $ward = mysqli_real_escape_string($con, trim((string)($case['ward_name'] ?? $case['wname'] ?? '')));
    $ptname = mysqli_real_escape_string($con, trim((string)($case['ptname'] ?? '')));
    $odate = mlc_esc_date($con, $case['order_date_iso'] ?? ($case['order_date'] ?? ''));
    $otime = mysqli_real_escape_string($con, substr(trim((string)($case['order_time'] ?? '')), 0, 12));
    $lab_type = mysqli_real_escape_string($con, trim((string)($case['lab_type'] ?? mlc_lab_key_from_item($case))));
    $lab_value = mysqli_real_escape_string($con, (string)($case['lab_value'] ?? ''));
    $warn = mysqli_real_escape_string($con, trim((string)($case['warning_msg'] ?? '')));
    $lvl = (($case['alert_level'] ?? '') === 'hard') ? 'hard' : 'soft';
    $actual = mysqli_real_escape_string($con, strip_tags((string)($case['actual_dose'] ?? '')));
    $rec = mysqli_real_escape_string($con, strip_tags((string)($case['recommended_dose'] ?? '')));
    $key_esc = mysqli_real_escape_string($con, $key);
    $organ_esc = mysqli_real_escape_string($con, $organ);
    $updated_by = (int)($extra['updated_by'] ?? $extra['created_by'] ?? 0);
    $created_by = (int)($extra['created_by'] ?? $updated_by);

    $set = "organ='$organ_esc', hn='$hn', an='$an', vn='$vn', icode='$icode', drug_name='$drug',
        method_text='$method', qty=" . ($qty === 'NULL' ? 'NULL' : $qty) . ", ward_name='$ward', ptname='$ptname',
        order_date=$odate, order_time='$otime', lab_type='$lab_type', lab_value='$lab_value',
        warning_msg='$warn', alert_level='$lvl', actual_dose='$actual', recommended_dose='$rec',
        updated_by=" . ($updated_by > 0 ? $updated_by : 'NULL');

    if ($existing) {
        $id = (int)$existing['id'];
        if (!mysqli_query($con, "UPDATE monitor_lab_consults SET $set WHERE id=$id")) {
            return ['ok' => false, 'error' => mysqli_error($con)];
        }
        return ['ok' => true, 'id' => $id, 'row' => mlc_get_consult($con, $id)];
    }
    $sql = "INSERT INTO monitor_lab_consults
        (organ, case_key, hn, an, vn, icode, drug_name, method_text, qty, ward_name, ptname,
         order_date, order_time, lab_type, lab_value, warning_msg, alert_level, actual_dose, recommended_dose,
         status, created_by, updated_by)
        VALUES ('$organ_esc', '$key_esc', '$hn', '$an', '$vn', '$icode', '$drug', '$method',
            " . ($qty === 'NULL' ? 'NULL' : $qty) . ", '$ward', '$ptname', $odate, '$otime',
            '$lab_type', '$lab_value', '$warn', '$lvl', '$actual', '$rec',
            'waiting', " . ($created_by > 0 ? $created_by : 'NULL') . ", " . ($updated_by > 0 ? $updated_by : 'NULL') . ")";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $id = (int)mysqli_insert_id($con);
    return ['ok' => true, 'id' => $id, 'row' => mlc_get_consult($con, $id)];
}

function mlc_start_consult($con, array $case, $pharmacist_user_id, $pharmacist_name, $note, $actor_user_id, $reply_wait_days = null, $actor_name = '') {
    $up = mlc_upsert_from_case($con, $case, [
        'created_by' => $actor_user_id,
        'updated_by' => $actor_user_id,
    ]);
    if (empty($up['ok'])) {
        return $up;
    }
    $id = (int)$up['id'];
    $before = mlc_get_consult($con, $id);
    $pharm = mlc_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name);
    $wait = mlc_normalize_reply_wait_days($reply_wait_days ?? mlc_get_reply_wait_days($con));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $due_sql = $wait <= 0 ? 'NULL' : "DATE_ADD(NOW(), INTERVAL $wait DAY)";
    $sql = "UPDATE monitor_lab_consults SET
        status='in_progress',
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'NULL') . ",
        pharmacist_name='$name_esc',
        consult_note='$note_esc',
        reply_wait_days=$wait,
        reply_due_at=$due_sql,
        closed_at=NULL,
        started_at=IFNULL(started_at, NOW()),
        printed_at=NOW(),
        updated_by=$actor
        WHERE id=$id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $row = mlc_get_consult($con, $id);
    mlc_log_history($con, [
        'consult_id' => $id,
        'row' => $row,
        'action_key' => 'start',
        'action_label' => 'เริ่ม Consult + พิมพ์ใบปรึกษา',
        'status_before' => $before['status'] ?? 'waiting',
        'status_after' => 'in_progress',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'reply_due_at' => $row['reply_due_at'] ?? null,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
        'meta' => ['reply_wait_days' => $wait],
    ]);
    return [
        'ok' => true,
        'id' => $id,
        'consult' => mlc_format_consult_row($row),
        'print_url' => 'monitor_lab_consult_print.php?id=' . $id,
        'message' => 'เริ่ม Consult แล้ว — รอตอบกลับ' . ($wait <= 0 ? 'ทันที' : ('ภายใน ' . $wait . ' วัน')),
    ];
}

function mlc_close_consult($con, $consult_id, $note, $doctor_reply, $actor_user_id, $actor_name = '', $pharmacist_user_id = 0, $pharmacist_name = '') {
    $consult_id = (int)$consult_id;
    $row = mlc_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $pharm = mlc_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name !== '' ? $pharmacist_name : ($row['pharmacist_name'] ?? ''));
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $reply_esc = mysqli_real_escape_string($con, trim((string)$doctor_reply));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $sql = "UPDATE monitor_lab_consults SET
        status='closed',
        closed_at=NOW(),
        reply_due_at=NULL,
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'pharmacist_user_id') . ",
        pharmacist_name=IF('$name_esc'='', pharmacist_name, '$name_esc'),
        consult_note=IF('$note_esc'='', consult_note, '$note_esc'),
        doctor_reply=IF('$reply_esc'='', doctor_reply, '$reply_esc'),
        updated_by=$actor
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = mlc_get_consult($con, $consult_id);
    mlc_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'close',
        'action_label' => 'ปิดการ Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => 'closed',
        'pharmacist_name' => $pharm['name'],
        'note_text' => $note,
        'doctor_reply' => $doctor_reply,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => mlc_format_consult_row($after), 'message' => 'ปิด Consult แล้ว'];
}

function mlc_save_result($con, $consult_id, $note, $doctor_reply, $actor_user_id, $actor_name = '', $pharmacist_user_id = 0, $pharmacist_name = '') {
    $consult_id = (int)$consult_id;
    $row = mlc_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $pharm = mlc_resolve_pharmacist($con, $pharmacist_user_id, $pharmacist_name);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $reply_esc = mysqli_real_escape_string($con, trim((string)$doctor_reply));
    $name_esc = mysqli_real_escape_string($con, $pharm['name']);
    $pid = (int)$pharm['id'];
    $actor = (int)$actor_user_id;
    $sql = "UPDATE monitor_lab_consults SET
        pharmacist_user_id=" . ($pid > 0 ? $pid : 'pharmacist_user_id') . ",
        pharmacist_name=IF('$name_esc'='', pharmacist_name, '$name_esc'),
        consult_note=IF('$note_esc'='', consult_note, '$note_esc'),
        doctor_reply=IF('$reply_esc'='', doctor_reply, '$reply_esc'),
        updated_by=$actor
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = mlc_get_consult($con, $consult_id);
    mlc_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'save_result',
        'action_label' => 'บันทึกผล Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => $after['status'] ?? '',
        'pharmacist_name' => $pharm['name'] !== '' ? $pharm['name'] : ($row['pharmacist_name'] ?? ''),
        'note_text' => $note,
        'doctor_reply' => $doctor_reply,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => mlc_format_consult_row($after), 'message' => 'บันทึกผล Consult เรียบร้อย'];
}

function mlc_reset_waiting($con, $consult_id, $actor_user_id, $note = '', $actor_name = '') {
    $consult_id = (int)$consult_id;
    $row = mlc_get_consult($con, $consult_id);
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบ Consult'];
    }
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $note_sql = $note_esc !== '' ? ", consult_note='$note_esc'" : '';
    $actor = (int)$actor_user_id;
    $sql = "UPDATE monitor_lab_consults SET
        status='waiting', reply_due_at=NULL, closed_at=NULL, updated_by=$actor
        $note_sql
        WHERE id=$consult_id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => mysqli_error($con)];
    }
    $after = mlc_get_consult($con, $consult_id);
    mlc_log_history($con, [
        'consult_id' => $consult_id,
        'row' => $after,
        'action_key' => 'reset',
        'action_label' => 'ตั้งเป็นรอ Consult',
        'status_before' => $row['status'] ?? '',
        'status_after' => 'waiting',
        'note_text' => $note,
        'actor_user_id' => $actor_user_id,
        'actor_name' => $actor_name,
    ]);
    return ['ok' => true, 'id' => $consult_id, 'consult' => mlc_format_consult_row($after)];
}

function mlc_mark_printed($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return false;
    }
    return (bool)mysqli_query($con, "UPDATE monitor_lab_consults SET printed_at=NOW() WHERE id=$id");
}

function mlc_log_history($con, array $data) {
    mlc_ensure_tables($con);
    $row = $data['row'] ?? [];
    $consult_id = (int)($data['consult_id'] ?? ($row['id'] ?? 0));
    $organ = mysqli_real_escape_string($con, (string)($row['organ'] ?? ''));
    $hn = mysqli_real_escape_string($con, (string)($row['hn'] ?? ''));
    $an = mysqli_real_escape_string($con, (string)($row['an'] ?? ''));
    $icode = mysqli_real_escape_string($con, (string)($row['icode'] ?? ''));
    $drug = mysqli_real_escape_string($con, (string)($row['drug_name'] ?? ''));
    $action_key = mysqli_real_escape_string($con, (string)($data['action_key'] ?? ''));
    $action_label = mysqli_real_escape_string($con, (string)($data['action_label'] ?? $action_key));
    $sb = mysqli_real_escape_string($con, (string)($data['status_before'] ?? ''));
    $sa = mysqli_real_escape_string($con, (string)($data['status_after'] ?? ''));
    $pharm = mysqli_real_escape_string($con, (string)($data['pharmacist_name'] ?? ($row['pharmacist_name'] ?? '')));
    $note = mysqli_real_escape_string($con, (string)($data['note_text'] ?? ''));
    $reply = mysqli_real_escape_string($con, (string)($data['doctor_reply'] ?? ''));
    $reply_due = !empty($data['reply_due_at'])
        ? "'" . mysqli_real_escape_string($con, (string)$data['reply_due_at']) . "'"
        : 'NULL';
    $meta = '';
    if (!empty($data['meta']) && is_array($data['meta'])) {
        $meta = mysqli_real_escape_string($con, json_encode($data['meta'], JSON_UNESCAPED_UNICODE));
    }
    $actor_id = (int)($data['actor_user_id'] ?? 0);
    $actor_name = mysqli_real_escape_string($con, (string)($data['actor_name'] ?? ''));
    $sql = "INSERT INTO monitor_lab_consult_history
        (consult_id, organ, hn, an, icode, drug_name, action_key, action_label,
         status_before, status_after, pharmacist_name, note_text, doctor_reply, reply_due_at, meta_json,
         actor_user_id, actor_name)
        VALUES
        ($consult_id, '$organ', '$hn', '$an', '$icode', '$drug', '$action_key', '$action_label',
         '$sb', '$sa', '$pharm', '$note', '$reply', $reply_due, " . ($meta !== '' ? "'$meta'" : 'NULL') . ",
         " . ($actor_id > 0 ? $actor_id : 'NULL') . ", '$actor_name')";
    return (bool)@mysqli_query($con, $sql);
}

function mlc_list_history($con, array $opts = []) {
    mlc_ensure_tables($con);
    $where = ['1=1'];
    if (!empty($opts['consult_id'])) {
        $where[] = 'consult_id=' . (int)$opts['consult_id'];
    }
    if (!empty($opts['hn'])) {
        $where[] = "hn='" . mysqli_real_escape_string($con, ltrim(trim((string)$opts['hn']), '0')) . "'";
    }
    if (!empty($opts['organ'])) {
        $where[] = "organ='" . mysqli_real_escape_string($con, (string)$opts['organ']) . "'";
    }
    $limit = max(1, min(500, (int)($opts['limit'] ?? 100)));
    $sql = 'SELECT * FROM monitor_lab_consult_history WHERE ' . implode(' AND ', $where)
        . ' ORDER BY created_at DESC, id DESC LIMIT ' . $limit;
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'id' => (int)$r['id'],
                'consult_id' => (int)$r['consult_id'],
                'created_at' => $r['created_at'],
                'drug_name' => $r['drug_name'],
                'action_key' => $r['action_key'],
                'action_label' => $r['action_label'],
                'status_before' => $r['status_before'],
                'status_after' => $r['status_after'],
                'status_before_label' => mlc_consult_status_label($r['status_before']),
                'status_after_label' => mlc_consult_status_label($r['status_after']),
                'pharmacist_name' => $r['pharmacist_name'],
                'note_text' => $r['note_text'],
                'doctor_reply' => $r['doctor_reply'],
                'reply_due_at' => $r['reply_due_at'],
                'actor_name' => $r['actor_name'],
            ];
        }
    }
    return $rows;
}
