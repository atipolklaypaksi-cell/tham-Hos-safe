<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start();
session_start();

include(__DIR__ . '/connect.php');
include(__DIR__ . '/hosxp_tmt_drug_helper.php');
include(__DIR__ . '/monitor_warfarin_helper.php');
mysqli_set_charset($con, 'utf8');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

$start_date = isset($_REQUEST['start_date']) ? trim((string)$_REQUEST['start_date']) : date('Y-m-d', strtotime('-7 days'));
$end_date = isset($_REQUEST['end_date']) ? trim((string)$_REQUEST['end_date']) : date('Y-m-d');
$protocol_id = isset($_REQUEST['protocol_id']) ? trim((string)$_REQUEST['protocol_id']) : '';
$scope = isset($_REQUEST['scope']) ? trim((string)$_REQUEST['scope']) : '';
$mode = isset($_REQUEST['mode']) ? strtolower(trim((string)$_REQUEST['mode'])) : '';
$hns_raw = isset($_REQUEST['hns']) ? $_REQUEST['hns'] : '';
$hn_one = function_exists('monitor_req_hn') ? monitor_req_hn() : trim((string)($_REQUEST['hn'] ?? ''));
if ($hn_one !== '' && (is_string($hns_raw) ? trim($hns_raw) === '' : empty($hns_raw))) {
    $hns_raw = $hn_one;
}

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $start_date = date('Y-m-d', strtotime('-7 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $end_date = date('Y-m-d');
}
if (strtotime($start_date) > strtotime($end_date)) {
    $tmp = $start_date;
    $start_date = $end_date;
    $end_date = $tmp;
}

if ($mode === '') {
    $mode = (is_string($hns_raw) && trim($hns_raw) !== '') || is_array($hns_raw) ? 'scan' : 'hns';
}

$isList = ($mode === 'hns' || $mode === 'list');
set_time_limit($isList ? 60 : 75);

$jsonFlags = JSON_UNESCAPED_UNICODE;
if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
    $jsonFlags |= JSON_INVALID_UTF8_SUBSTITUTE;
}

function mwf_api_json($payload, $flags) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, $flags);
    exit;
}

$hos = hosxp_connect($con, $isList ? 60 : 90);
if (!$hos) {
    mwf_api_json(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], $jsonFlags);
}
mysqli_set_charset($hos, 'utf8');

try {
    if ($isList) {
        $config = mwf_get_config($con);
        if (empty($config['monitor_active'])) {
            try { @mysqli_close($hos); } catch (Throwable $e2) {}
            mwf_api_json([
                'status' => 'success',
                'hns' => [],
                'count' => 0,
                'truncated' => false,
                'summary' => ['ok' => 0, 'mismatch' => 0, 'other' => 0, 'total' => 0],
                'dashboard' => [],
                'hard_alerts' => [],
                'soft_alerts' => [],
                'meta' => [
                    'message' => 'Monitor Warfarin ถูกปิดใช้งาน — ไปที่แท็บตั้งค่าเพื่อเปิด',
                    'hn_count' => 0,
                    'row_count' => 0,
                    'scope' => $config['monitor_scope'],
                    'scope_label' => mwf_scope_label($config['monitor_scope']),
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                ],
            ], $jsonFlags);
        }
        $scopeUse = $scope !== '' ? mwf_normalize_scope($scope) : $config['monitor_scope'];
        $hns = mwf_fetch_warfarin_hns($hos, $start_date, $end_date, 400, $scopeUse);
        try { @mysqli_close($hos); } catch (Throwable $e2) {}
        mwf_api_json([
            'status' => 'success',
            'hns' => $hns,
            'count' => count($hns),
            'truncated' => count($hns) >= 400,
            'meta' => [
                'hn_count' => count($hns),
                'scope' => $scopeUse,
                'scope_label' => mwf_scope_label($scopeUse),
                'start_date' => $start_date,
                'end_date' => $end_date,
            ],
        ], $jsonFlags);
    }

    $hnList = mwf_parse_hn_list($hns_raw, 12);
    if (empty($hnList)) {
        try { @mysqli_close($hos); } catch (Throwable $e2) {}
        mwf_api_json(['status' => 'error', 'message' => 'ไม่ระบุ HN สำหรับประมวลผล'], $jsonFlags);
    }

    $result = mwf_scan($con, $hos, $start_date, $end_date, $protocol_id, $scope, $hnList);
} catch (Throwable $e) {
    try { @mysqli_close($hos); } catch (Throwable $e2) {}
    mwf_api_json([
        'status' => 'error',
        'message' => 'ประมวลผลชุดนี้ไม่สำเร็จ — ระบบจะย่อยชุดแล้วยิงใหม่',
    ], $jsonFlags);
}
try { mysqli_close($hos); } catch (Throwable $e) {}
require_once __DIR__ . '/smart_pharma_alert_log_helper.php';

mwf_api_json([
    'status' => 'success',
    'summary' => $result['summary'] ?? ['ok' => 0, 'mismatch' => 0, 'other' => 0, 'total' => 0],
    'dashboard' => $result['dashboard'] ?? [],
    'hard_alerts' => sp_alert_mute_filter_rows($con, $result['hard_alerts'] ?? []),
    'soft_alerts' => sp_alert_mute_filter_rows($con, $result['soft_alerts'] ?? []),
    'meta' => $result['meta'] ?? [],
    'hns' => $hnList,
    'count' => count($hnList),
], $jsonFlags);
