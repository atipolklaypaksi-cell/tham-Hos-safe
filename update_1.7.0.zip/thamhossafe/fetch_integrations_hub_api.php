<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['ok' => false, 'error' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/integrations_hub_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
$role = (string)($_SESSION['role'] ?? '');
if ($role !== 'admin' && !tham_menu_can('admin.integrations_hub')) {
    echo json_encode(['ok' => false, 'error' => 'เฉพาะ Admin'], JSON_UNESCAPED_UNICODE);
    exit;
}
session_write_close();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = array_merge($_GET, $_POST);
}
$action = trim((string)($input['action'] ?? 'list'));

if ($action === 'list') {
    echo json_encode(['ok' => true, 'items' => ih_list_status($con)], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'set') {
    $code = trim((string)($input['code'] ?? ''));
    $enabled = !empty($input['enabled']) && (string)$input['enabled'] !== '0';
    if ($code === '' || !isset(ih_connection_defs()[$code])) {
        echo json_encode(['ok' => false, 'error' => 'รหัสการเชื่อมต่อไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // sync กับคีย์เดิมของ INVC setting
    if ($code === 'google_sheet_invc') {
        ih_sys_set($con, 'invc_gsheet_enabled', $enabled ? '1' : '0');
    }
    $ok = ih_set_enabled($con, $code, $enabled);
    echo json_encode([
        'ok' => $ok,
        'code' => $code,
        'enabled' => $enabled ? 1 : 0,
        'error' => $ok ? '' : 'บันทึกไม่สำเร็จ',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'set_many') {
    $map = $input['items'] ?? null;
    if (!is_array($map)) {
        echo json_encode(['ok' => false, 'error' => 'รูปแบบไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $saved = 0;
    foreach ($map as $code => $en) {
        $code = trim((string)$code);
        if (!isset(ih_connection_defs()[$code])) {
            continue;
        }
        $on = !empty($en) && (string)$en !== '0';
        if ($code === 'google_sheet_invc') {
            ih_sys_set($con, 'invc_gsheet_enabled', $on ? '1' : '0');
        }
        if (ih_set_enabled($con, $code, $on)) {
            $saved++;
        }
    }
    echo json_encode(['ok' => true, 'saved' => $saved, 'items' => ih_list_status($con)], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'action ไม่รองรับ'], JSON_UNESCAPED_UNICODE);
