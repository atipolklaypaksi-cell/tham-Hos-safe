<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
mysqli_set_charset($con, 'utf8');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/tham_alert_helper.php';

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
if (!tham_menu_can('admin.alert_agents') && !tham_menu_can('admin.alert_pipelines') && !tham_menu_can('admin.hosxp') && ($_SESSION['role'] ?? '') !== 'admin') {
    echo "<script>alert('คุณไม่มีสิทธิ์เข้าหน้าเครื่อง Alert Agent'); window.location='home.php';</script>";
    exit;
}
tham_alert_ensure_tables($con);
$login_prompt_on = tham_alert_lan_auto_enabled($con);
$allergy_alert_on = tham_alert_allergy_case_enabled($con);
$j2_alert_on = tham_alert_j2_eval_enabled($con);
$role_labels = tham_menu_role_labels();
$h = function ($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
};
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เครื่อง Alert Agent - THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        .ta-hero {
            background: linear-gradient(135deg, #0f766e 0%, #1d4ed8 55%, #4f46e5 100%);
            color: #fff; border-radius: 12px; padding: 1.15rem 1.4rem;
        }
        .pipe-sel { min-width: 150px; font-size: .82rem; }
        .ag-switch { min-width: 3.2rem; }
        .ag-switch .form-check-input { width: 2.4em; height: 1.25em; cursor: pointer; }
        tr.agent-off td { background: #f8fafc; }
        tr.agent-off td:nth-child(n) { color: #64748b; }
        tr.agent-hidden td { background: #f8fafc; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="ta-hero mb-4">
                <div class="small opacity-75 mb-1"><i class="fas fa-cog me-1"></i>ตั้งค่าระบบ</div>
                <h4 class="fw-bold mb-1">เครื่อง Alert Agent</h4>
                <small>รายการเครื่องที่เคย Login เว็บ — เครื่องที่เปิด THAM Notify 1.1.3 ขึ้นไปจะอัปเดตเองเมื่อมีเวอร์ชันใหม่ หรือกด <b>อัปเดต</b> จากหน้านี้</small>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body py-3">
                    <div class="fw-bold"><i class="fas fa-tv me-1 text-primary"></i>เครื่อง Monitor — Login ค้างไว้</div>
                    <div class="small text-muted mt-1">เซสชันปกติหมดในประมาณ 24 นาทีถ้าไม่มีการใช้งาน จึงหลุดบ่อย เปิดสวิตช์ <b>Login ค้าง</b> ที่เครื่องที่ใช้ดู Smart Pharma Alert แล้วเครื่องนั้นจะไม่ถูกตัดออกจากระบบ ค่าเริ่มต้นคือ <b>CCTV-PHAMA</b> (10.10.81.156) และ <b>DRUG-130</b> (10.10.80.127) ต้องเคย Login อย่างน้อย 1 ครั้งบนเครื่องนั้น ถ้าต้องการให้หลุดตามปกติ ให้ปิดสวิตช์ — <b class="text-danger">Login ค้างใช้ได้เฉพาะ Local Web (LAN ในโรงพยาบาล) เท่านั้น</b> ไม่ทำงานเมื่อเข้าจากอินเทอร์เน็ตภายนอก</div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body d-flex flex-wrap align-items-center gap-3 py-3">
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" id="loginPromptSw" role="switch" <?= $login_prompt_on ? 'checked' : '' ?> style="width:2.6em;height:1.35em;cursor:pointer">
                    </div>
                    <div class="flex-grow-1">
                        <div class="fw-bold">ชวนดาวน์โหลด THAM Notify ตอน Login</div>
                        <div class="small text-muted" id="loginPromptHint"><?= $login_prompt_on
                            ? 'เปิดอยู่ — หลัง Login จะชวนไปหน้าดาวน์โหลด THAM Notify (เปิดเอง ไม่ยิงไฟล์ติดตั้งเงียบ)'
                            : 'ปิดอยู่ — ผู้ใช้เข้าเว็บแล้วจะไม่ขึ้นหน้าต่างชวนดาวน์โหลด (ค่าเริ่มต้น)' ?></div>
                    </div>
                    <span class="badge <?= $login_prompt_on ? 'bg-success' : 'bg-secondary' ?>" id="loginPromptBadge"><?= $login_prompt_on ? 'เปิด' : 'ปิด' ?></span>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body py-3">
                    <div class="d-flex flex-wrap align-items-center gap-3">
                        <div class="form-check form-switch mb-0">
                            <input class="form-check-input" type="checkbox" id="allergyAlertSw" role="switch" <?= $allergy_alert_on ? 'checked' : '' ?> style="width:2.6em;height:1.35em;cursor:pointer">
                        </div>
                        <div class="flex-grow-1">
                            <div class="fw-bold">แจ้งเคสแพ้ยาใหม่จากหอผู้ป่วย</div>
                            <div class="small text-muted" id="allergyAlertHint"><?= $allergy_alert_on
                                ? 'เปิดอยู่ — เมื่อหอผู้ป่วยแจ้งเคสใหม่ จะขึ้นป๊อปอัปตามผู้รับที่ตั้งด้านล่าง'
                                : 'ปิดอยู่ — ยังไม่ส่งป๊อปอัปเมื่อมีเคสแพ้ยาใหม่' ?></div>
                        </div>
                        <span class="badge <?= $allergy_alert_on ? 'bg-success' : 'bg-secondary' ?>" id="allergyAlertBadge"><?= $allergy_alert_on ? 'เปิด' : 'ปิด' ?></span>
                    </div>
                    <hr class="my-3">
                    <div class="row g-3">
                        <div class="col-lg-6">
                            <div class="fw-bold small mb-2">ส่งถึงเครื่องไหน</div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="allergyTarget" id="allergyTargetIpd" value="phar_ipd">
                                <label class="form-check-label" for="allergyTargetIpd">เฉพาะห้องจ่ายยาผู้ป่วยใน</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="allergyTarget" id="allergyTargetOpd" value="phar_opd">
                                <label class="form-check-label" for="allergyTargetOpd">เฉพาะห้องจ่ายยาผู้ป่วยนอก</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="allergyTarget" id="allergyTargetBoth" value="both" checked>
                                <label class="form-check-label" for="allergyTargetBoth">ทั้งห้องจ่ายยาผู้ป่วยในและผู้ป่วยนอก</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="allergyTarget" id="allergyTargetMachines" value="machines">
                                <label class="form-check-label" for="allergyTargetMachines">เลือกเครื่องเอง</label>
                            </div>
                            <div id="allergyMachineBox" class="border rounded p-2 mt-2 bg-light" style="max-height:220px;overflow:auto;display:none">
                                <div class="small text-muted mb-1">เฉพาะเครื่องที่ลง THAM Notify แล้ว และผูกช่องทางไว้</div>
                                <div id="allergyMachines"></div>
                            </div>
                            <div class="small text-muted mt-2" id="allergyWho">ห้องจ่ายยาผู้ป่วยใน คือเครื่องที่คอลัมน์ช่องทางเป็น Pharmacy IPD</div>
                        </div>
                        <div class="col-lg-6">
                            <div class="fw-bold small mb-2">รายละเอียดในป๊อปอัป</div>
                            <div class="form-check"><input class="form-check-input allergy-field" type="checkbox" id="afHn" data-field="hn" checked><label class="form-check-label" for="afHn">HN</label></div>
                            <div class="form-check"><input class="form-check-input allergy-field" type="checkbox" id="afName" data-field="ptname" checked><label class="form-check-label" for="afName">ชื่อผู้ป่วย</label></div>
                            <div class="form-check"><input class="form-check-input allergy-field" type="checkbox" id="afWard" data-field="ward" checked><label class="form-check-label" for="afWard">หอผู้ป่วย</label></div>
                            <div class="form-check"><input class="form-check-input allergy-field" type="checkbox" id="afReporter" data-field="reporter" checked><label class="form-check-label" for="afReporter">ผู้แจ้ง</label></div>
                            <div class="form-check"><input class="form-check-input allergy-field" type="checkbox" id="afLink" data-field="link" checked><label class="form-check-label" for="afLink">ลิงก์เปิดเคส</label></div>
                            <div class="small text-muted mt-2 mb-1">ตัวอย่างข้อความ</div>
                            <pre id="allergyPreview" class="small bg-light border rounded p-2 mb-2" style="white-space:pre-wrap"></pre>
                            <button type="button" class="btn btn-primary btn-sm" id="allergySaveBtn">บันทึกการส่ง</button>
                            <span class="small text-success ms-2" id="allergySaveMsg"></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body d-flex flex-wrap align-items-center gap-3 py-3">
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" id="j2AlertSw" role="switch" <?= $j2_alert_on ? 'checked' : '' ?> style="width:2.6em;height:1.35em;cursor:pointer">
                    </div>
                    <div class="flex-grow-1">
                        <div class="fw-bold">แจ้งประเมินยา จ2 ตอนคีย์ใน HOSxP</div>
                        <div class="small text-muted" id="j2AlertHint"><?= $j2_alert_on
                            ? 'เปิดอยู่ — เมื่อเครื่องนั้นคีย์ยาที่มีแบบประเมิน เช่น Bevacizumab จะขึ้นป๊อปอัป และลิงก์เข้าเว็บเป็นผู้ใช้ HOSxP คนนั้น'
                            : 'ปิดอยู่ — ยังไม่ส่งป๊อปอัปประเมินยา จ2' ?></div>
                    </div>
                    <span class="badge <?= $j2_alert_on ? 'bg-success' : 'bg-secondary' ?>" id="j2AlertBadge"><?= $j2_alert_on ? 'เปิด' : 'ปิด' ?></span>
                </div>
            </div>

            <div class="alert alert-info py-2 small mb-3">
                <i class="fas fa-info-circle me-1"></i>
                ชนิดเครื่องดูจากเบราว์เซอร์ตอน Login (User-Agent) และจากว่าลง Windows Agent หรือไม่
                — <b>ใน รพ.</b> = IP วง LAN ส่วนตัว (เช่น 10.x / 192.168.x)
                · <b>นอก รพ.</b> = อินเทอร์เน็ตหรือมือถือ
                — มือถือ/แท็บเล็ตลง Agent ไม่ได้ เพราะตัวติดตั้งเป็นโปรแกรม Windows
                · เครื่องที่ยังเป็น 1.1.2 หรือเก่ากว่า ต้องเปิดไฟล์ 1.1.3 ครั้งแรกก่อน จากนั้นเวอร์ชันถัดไปจะอัปเดตเอง
            </div>
            <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
                <span class="badge bg-success" id="agInstalled">ลง Agent แล้ว 0</span>
                <span class="badge bg-dark" id="agOnline">Agent ออนไลน์ 0</span>
                <span class="badge bg-info text-dark" id="agWebOnline">เปิดเว็บอยู่ 0</span>
                <span class="badge text-bg-light border" id="agPc">PC 0</span>
                <span class="badge text-bg-warning" id="agMobile">มือถือ 0</span>
                <span class="badge text-bg-info" id="agTablet">แท็บเล็ต 0</span>
                <span class="badge bg-success" id="agLan">ใน รพ. 0</span>
                <span class="badge bg-secondary" id="agWan">นอก รพ. 0</span>
                <span class="badge bg-secondary" id="agNoAgent">ยังไม่ลง Agent 0</span>
                <span class="badge bg-warning text-dark" id="agWait">รอระบุ 0</span>
                <span class="badge bg-danger" id="agOff">ปิดระบบ 0</span>
                <button type="button" class="btn btn-outline-dark btn-sm" id="btnShowHidden">แสดงเครื่องที่ซ่อน (0)</button>
                <button type="button" class="btn btn-warning btn-sm ms-auto" id="btnUpdateAll">อัปเดตทุกเครื่องที่พร้อม</button>
                <a class="btn btn-outline-secondary btn-sm" href="alert_settings.php">Alert pipelines</a>
                <a class="btn btn-outline-secondary btn-sm" href="alert_agent.php">ดาวน์โหลด Agent</a>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>ลง Agent</th>
                                    <th>ชนิดเครื่อง</th>
                                    <th>เครือข่าย</th>
                                    <th>ระบบ</th>
                                    <th>Login ค้าง</th>
                                    <th>ผูกเป็น</th>
                                    <th>ชื่อเครื่อง / IP</th>
                                    <th>ผู้ login ล่าสุด</th>
                                    <th>เห็นล่าสุด</th>
                                    <th>ทดสอบ</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="agentBody">
                                <tr><td colspan="11" class="text-muted text-center py-4">กำลังโหลด...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="loginModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">ประวัติ Login เครื่อง</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="small text-muted mb-2" id="loginModalSub"></div>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead><tr><th>เวลา</th><th>ผู้ใช้</th><th>บทบาท</th><th>สถานที่ทำงาน</th><th>IP</th><th>เครือข่าย</th></tr></thead>
                        <tbody id="loginBody"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const ROLE_LABELS = <?= json_encode($role_labels, JSON_UNESCAPED_UNICODE) ?>;
const ROOM_LABELS = { opd: 'ห้องจ่ายยาผู้ป่วยนอก', ipd: 'ห้องจ่ายยาผู้ป่วยใน' };
const PIPE_OPTS = [
    { id: '', label: 'ยังไม่ระบุ' },
    { id: 'ward', label: 'Ward' },
    { id: 'doctor', label: 'Doctor' },
    { id: 'phar_opd', label: 'Pharmacy OPD' },
    { id: 'phar_ipd', label: 'Pharmacy IPD' }
];
function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function ageText(sec) {
    sec = Number(sec || 0);
    if (sec < 0) sec = 0;
    if (sec < 60) return sec + ' วินาทีที่แล้ว';
    if (sec < 3600) return Math.floor(sec / 60) + ' นาทีที่แล้ว';
    if (sec < 86400) return Math.floor(sec / 3600) + ' ชั่วโมงที่แล้ว';
    return Math.floor(sec / 86400) + ' วันที่แล้ว';
}
function roleLabel(r) { return ROLE_LABELS[r] || r || '—'; }
function roomLabel(r) { return ROOM_LABELS[r] || (r ? r : '—'); }
function netBadge(r) {
    const kind = r.network_kind || (r.is_lan ? 'lan' : '');
    const label = r.network_label || (kind === 'lan' ? 'ใน รพ.' : (kind ? 'นอก รพ.' : 'ไม่ทราบ'));
    const detail = r.network_detail || '';
    let cls = 'bg-secondary';
    let icon = 'fa-globe';
    if (kind === 'lan') {
        cls = 'bg-success';
        icon = 'fa-hospital';
    } else if (kind === 'cgnat') {
        cls = 'bg-warning text-dark';
        icon = 'fa-broadcast-tower';
    } else if (kind === 'wan') {
        cls = 'bg-secondary';
        icon = 'fa-globe';
    }
    return '<span class="badge ' + cls + '" title="' + esc(detail || label) + '">' +
        '<i class="fas ' + icon + ' me-1"></i>' + esc(label) + '</span>' +
        (detail ? '<div class="small text-muted mt-1">' + esc(detail) + '</div>' : '');
}
function pipeSelect(cur) {
    return '<select class="form-select form-select-sm pipe-sel js-pipe">' +
        PIPE_OPTS.map(function (o) {
            return '<option value="' + o.id + '"' + (String(cur || '') === o.id ? ' selected' : '') + '>' + o.label + '</option>';
        }).join('') + '</select>';
}
function api(action, data) {
    const opt = { credentials: 'same-origin' };
    if (data) {
        opt.method = 'POST';
        opt.headers = { 'Content-Type': 'application/json' };
        opt.body = JSON.stringify(Object.assign({ action: action }, data));
        return fetch('fetch_tham_alert_api.php', opt).then(function (r) { return r.json(); });
    }
    return fetch('fetch_tham_alert_api.php?action=' + encodeURIComponent(action) + (data && data.id ? '' : ''), opt)
        .then(function (r) { return r.json(); });
}
let allAgents = [];
let showHidden = false;
function render(rows) {
    allAgents = rows || [];
    const hiddenN = allAgents.filter(function (r) { return r.ui_hidden; }).length;
    const btnH = document.getElementById('btnShowHidden');
    if (btnH) btnH.textContent = (showHidden ? 'กลับไปรายการปกติ' : 'แสดงเครื่องที่ซ่อน') + ' (' + hiddenN + ')';
    rows = allAgents.filter(function (r) { return showHidden ? !!r.ui_hidden : !r.ui_hidden; });
    const body = document.getElementById('agentBody');
    const installed = (rows || []).filter(function (r) { return r.agent_installed; }).length;
    const online = (rows || []).filter(function (r) { return r.online; }).length;
    const wait = (rows || []).filter(function (r) { return r.unspecified; }).length;
    const off = (rows || []).filter(function (r) { return r.agent_installed && !r.enabled; }).length;
    const webOn = (rows || []).filter(function (r) { return !r.agent_installed && r.web_online; }).length;
    const pcN = (rows || []).filter(function (r) { return r.device_kind === 'pc'; }).length;
    const moN = (rows || []).filter(function (r) { return r.device_kind === 'mobile'; }).length;
    const tbN = (rows || []).filter(function (r) { return r.device_kind === 'tablet'; }).length;
    const lanN = (rows || []).filter(function (r) { return r.is_lan; }).length;
    const wanN = (rows || []).filter(function (r) { return !r.is_lan && (r.network_kind === 'wan' || r.network_kind === 'cgnat'); }).length;
    document.getElementById('agInstalled').textContent = 'ลง Agent แล้ว ' + installed;
    document.getElementById('agOnline').textContent = 'Agent ออนไลน์ ' + online;
    document.getElementById('agWebOnline').textContent = 'เปิดเว็บอยู่ ' + webOn;
    document.getElementById('agPc').textContent = 'PC ' + pcN;
    document.getElementById('agMobile').textContent = 'มือถือ ' + moN;
    document.getElementById('agTablet').textContent = 'แท็บเล็ต ' + tbN;
    document.getElementById('agLan').textContent = 'ใน รพ. ' + lanN;
    document.getElementById('agWan').textContent = 'นอก รพ. ' + wanN;
    document.getElementById('agNoAgent').textContent = 'ยังไม่ลง Agent ' + ((rows ? rows.length : 0) - installed);
    document.getElementById('agWait').textContent = 'รอระบุ ' + wait;
    document.getElementById('agOff').textContent = 'ปิดระบบ ' + off;
    if (!rows || !rows.length) {
        body.innerHTML = '<tr><td colspan="10" class="text-muted text-center py-4">' +
            (showHidden ? 'ยังไม่มีเครื่องที่ซ่อน' : 'ยังไม่มีเครื่อง — เมื่อมีคน Login เว็บ หรือ Agent poll จะขึ้นที่นี่') +
            '</td></tr>';
        return;
    }
    body.innerHTML = rows.map(function (r) {
        let agentBadge = r.agent_installed
            ? (r.online
                ? '<span class="badge bg-success">ลงแล้ว · ออนไลน์</span>'
                : '<span class="badge bg-primary">ลงแล้ว · ออฟไลน์</span>')
            : (r.web_online
                ? '<span class="badge bg-info text-dark">ยังไม่ลง · เปิดเว็บอยู่</span>'
                : '<span class="badge bg-secondary">ยังไม่ลง Agent</span><div class="small text-muted mt-1">แค่ Login เว็บ</div>');
        if (r.agent_installed) {
            agentBadge += '<div class="small text-muted">v' + esc(r.agent_version || '?') + '</div>';
            if (r.duplicate_agent) {
                agentBadge += '<div class="small text-danger fw-bold">มีโปรแกรมซ้ำ ' + (r.live_versions || []).map(esc).join(' + ') + ' อัปเดตเลยไม่จบและมีเสียงรัว — เปิด Task Manager แล้วจบ THAMNotify ให้หมด</div>';
            } else if (!r.update_available) {
                agentBadge += '<div class="small text-success fw-bold">อัปเดตแล้ว</div>';
            } else if (r.update_capable) {
                var noisy = (r.live_versions || [r.agent_version]).some(function (v) {
                    return v === '1.1.3' || v === '1.1.4' || v === '1.1.5';
                });
                agentBadge += '<div class="small text-warning fw-bold">' + (r.update_pushed ? 'สั่งอัปเดตแล้ว รอเครื่องดึง' : 'มี v' + esc(r.latest_version) + ' จะอัปเดตเอง') + '</div>';
                if (noisy) {
                    agentBadge += '<div class="small text-danger">ตัวนี้มีเสียงทุก 2 นาทีเพราะอัปเดตไม่จบ — เปิด Task Manager แล้วจบ THAMNotify ให้หมด จากนั้นมันจะเปิดกลับแล้วติดตั้งเอง</div>';
                }
            } else {
                agentBadge += '<div class="small text-danger">ตัวที่รันอยู่ยังเป็น v' + esc(r.agent_version || '?') + ' ปิดที่ถาดระบบแล้วเปิด 1.1.3</div>';
            }
        }
        if (!r.agent_installed && r.install_waiting_file) {
            agentBadge += '<div class="small text-warning fw-bold mt-1">รอเปิดไฟล์ที่เครื่อง</div>';
        } else if (!r.agent_installed && r.install_push_pending && r.web_online) {
            agentBadge += '<div class="small text-success fw-bold mt-1">กำลังส่งไปที่เบราว์เซอร์</div>';
        } else if (!r.agent_installed && r.install_queued) {
            agentBadge += '<div class="small text-muted mt-1">คิวไว้แล้ว</div>';
        }
        const pickedWard = (r.pipeline === 'ward')
            ? String(r.last_unit_ward || r.group_name || '').trim()
            : String(r.group_name || '').trim();
        const customName = String(r.display_name || '').trim();
        const autoName = String(r.station_id || r.computername || '').trim();
        const canName = r.pipeline === 'phar_opd' || r.pipeline === 'phar_ipd';
        const who = r.last_user_name
            ? esc(r.last_user_name) + '<div class="small text-muted">' + esc(roleLabel(r.last_user_role)) +
                (r.last_dispense_room ? ' · ' + esc(roomLabel(r.last_dispense_room)) : '') +
                (pickedWard ? ' · หอ ' + esc(pickedWard) : '') + '</div>'
            : '<span class="text-muted">—</span>';
        const machineTitle = customName || autoName || (r.agent_installed ? '—' : 'ยังไม่มีชื่อเครื่อง');
        const machine = '<div class="fw-bold">' + esc(machineTitle) + '</div>' +
            (customName && autoName && customName !== autoName ? '<div class="small text-muted">' + esc(autoName) + '</div>' : '') +
            '<div class="small"><code>' + esc(r.ip_address || '—') + '</code>' +
            (pickedWard ? ' · หอ ' + esc(pickedWard) : '') + '</div>' +
            (canName
                ? '<input type="text" class="form-control form-control-sm js-mname mt-1" maxlength="80" placeholder="ตั้งชื่อเครื่อง" value="' + esc(customName) + '" data-saved="' + esc(customName) + '" style="max-width:190px">'
                : '') +
            (r.windows_user ? '<div class="small text-muted">Windows: ' + esc(r.windows_user) + '</div>' : '');
        const kind = r.device_kind || 'unknown';
        const kindCls = kind === 'pc' ? 'bg-dark' : (kind === 'mobile' ? 'bg-warning text-dark' : (kind === 'tablet' ? 'bg-info text-dark' : 'bg-secondary'));
        const kindIcon = kind === 'pc' ? 'fa-desktop' : (kind === 'mobile' ? 'fa-mobile-alt' : (kind === 'tablet' ? 'fa-tablet-alt' : 'fa-question'));
        const kindCell = '<span class="badge ' + kindCls + '"><i class="fas ' + kindIcon + ' me-1"></i>' + esc(r.device_detail || r.device_label || 'ไม่ทราบ') + '</span>';
        const netCell = netBadge(r);
        const on = r.enabled !== false;
        const keep = !!r.keep_login;
        const keepSw = '<div class="form-check form-switch ag-switch mb-0">' +
                '<input class="form-check-input js-keep-login" type="checkbox"' + (keep ? ' checked' : '') + ' title="Login ค้างสำหรับจอ Monitor — ใช้ได้เฉพาะ Local Web (LAN ใน รพ.) เท่านั้น">' +
                '<label class="form-check-label small fw-bold ' + (keep ? 'text-primary' : 'text-muted') + '">' + (keep ? 'ค้าง' : 'ปกติ') + '</label>' +
              '</div>';
        const sw = r.agent_installed
            ? '<div class="form-check form-switch ag-switch mb-0">' +
                '<input class="form-check-input js-enabled" type="checkbox"' + (on ? ' checked' : '') + ' title="' + (on ? 'ปิดระบบเครื่องนี้' : 'เปิดระบบเครื่องนี้') + '">' +
                '<label class="form-check-label small fw-bold ' + (on ? 'text-success' : 'text-danger') + '">' + (on ? 'เปิด' : 'ปิด') + '</label>' +
              '</div>'
            : '<span class="text-muted small">—</span>';
        const canInstall = r.can_install_agent !== false && kind !== 'mobile' && kind !== 'tablet';
        let testBtn = r.agent_installed && on
            ? '<button type="button" class="btn btn-outline-primary btn-sm py-0 px-2 btn-test">Send</button>'
            : (!r.agent_installed && canInstall
                ? '<button type="button" class="btn btn-success btn-sm py-0 px-2 btn-push" title="' +
                    (r.web_online ? 'ส่งตัวติดตั้งไปยังเบราว์เซอร์เครื่องนี้ทันที' : 'คิวไว้ เมื่อเครื่องนี้เปิดเว็บ THAM จะเริ่มดาวน์โหลด') + '">' +
                    (r.web_online ? 'ลงให้' : 'คิวติดตั้ง') + '</button>'
                : (!r.agent_installed
                    ? '<span class="small text-muted">ลง Agent ไม่ได้</span>'
                    : '<button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2" disabled>Send</button>'));
        if (r.agent_installed && r.update_available && r.update_capable) {
            testBtn += ' <button type="button" class="btn btn-warning btn-sm py-0 px-2 btn-upd">อัปเดต</button>';
        }
        let seen;
        if (r.agent_installed && r.agent_age_sec != null) {
            seen = 'Agent ' + ageText(r.agent_age_sec);
            if (r.web_online) seen += '<div class="text-info">เว็บ ' + ageText(r.web_age_sec) + '</div>';
        } else if (r.web_age_sec != null) {
            seen = (r.web_online ? '<span class="text-info fw-bold">เว็บ ' + ageText(r.web_age_sec) + '</span>' : 'เว็บ ' + ageText(r.web_age_sec));
            if (r.last_login_at) seen += '<div class="text-muted">Login ' + ageText(r.age_sec) + '</div>';
        } else {
            seen = r.last_login_at ? 'Login ' + ageText(r.age_sec) : ageText(r.age_sec);
        }
        return '<tr data-id="' + r.id + '" data-installed="' + (r.agent_installed ? '1' : '0') + '" data-enabled="' + (on ? '1' : '0') + '" data-hidden="' + (r.ui_hidden ? '1' : '0') + '"' +
            ((r.agent_installed && !on) || r.ui_hidden ? ' class="' + (r.ui_hidden ? 'agent-hidden' : 'agent-off') + '"' : '') + '>' +
            '<td>' + agentBadge + '</td>' +
            '<td>' + kindCell + '</td>' +
            '<td>' + netCell + '</td>' +
            '<td>' + sw + '</td>' +
            '<td>' + keepSw + '</td>' +
            '<td>' + pipeSelect(r.unspecified ? '' : r.pipeline) +
                (r.pipeline === 'ward'
                    ? (pickedWard
                        ? '<div class="small text-success fw-bold mt-1">' + esc(pickedWard) + '</div>'
                        : '<div class="small text-muted mt-1">ยังไม่เลือกหอ</div>')
                    : '') + '</td>' +
            '<td>' + machine + '</td>' +
            '<td>' + who + '</td>' +
            '<td class="small">' + seen + '</td>' +
            '<td>' + testBtn + '</td>' +
            '<td class="text-nowrap text-end">' +
                '<button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2 btn-log">ประวัติ</button> ' +
                (r.ui_hidden
                    ? '<button type="button" class="btn btn-outline-success btn-sm py-0 px-2 btn-hide">ยกเลิกซ่อน</button> '
                    : '<button type="button" class="btn btn-outline-dark btn-sm py-0 px-2 btn-hide">ซ่อน</button> ') +
                '<button type="button" class="btn btn-outline-danger btn-sm py-0 px-2 btn-del">ลบ</button>' +
            '</td></tr>';
    }).join('');
}
var allergyCfg = { target: 'both', agent_ids: [], fields: { hn: true, ptname: true, ward: true, reporter: true, link: true } };
var allergyDirty = false;
var allergyAgents = [];
function allergyTargetText(target) {
    if (target === 'phar_ipd') return 'เฉพาะเครื่องห้องจ่ายยาผู้ป่วยใน';
    if (target === 'phar_opd') return 'เฉพาะเครื่องห้องจ่ายยาผู้ป่วยนอก';
    if (target === 'machines') return 'เฉพาะเครื่องที่เลือก';
    return 'เครื่องห้องจ่ายยาผู้ป่วยในและผู้ป่วยนอก';
}
function setAllergyAlertUi(on) {
    const sw = document.getElementById('allergyAlertSw');
    const hint = document.getElementById('allergyAlertHint');
    const badge = document.getElementById('allergyAlertBadge');
    if (sw) sw.checked = !!on;
    if (hint) hint.textContent = on
        ? 'เปิดอยู่ — เคสใหม่จะขึ้นป๊อปอัปที่' + allergyTargetText(allergyCfg.target)
        : 'ปิดอยู่ — ยังไม่ส่งป๊อปอัปเมื่อมีเคสแพ้ยาใหม่';
    if (badge) {
        badge.textContent = on ? 'เปิด' : 'ปิด';
        badge.className = 'badge ' + (on ? 'bg-success' : 'bg-secondary');
    }
}
function allergyFieldOn(name) {
    const el = document.querySelector('.allergy-field[data-field="' + name + '"]');
    return !!(el && el.checked);
}
function refreshAllergyPreview() {
    const lines = ['เคสแพ้ยาใหม่จากหอผู้ป่วย'];
    const who = [];
    if (allergyFieldOn('hn')) who.push('HN 000123456');
    if (allergyFieldOn('ptname')) who.push('ตัวอย่าง ผู้ป่วย');
    if (who.length) lines.push(who.join('  '));
    if (allergyFieldOn('ward')) lines.push('หอ อายุรกรรม');
    if (allergyFieldOn('reporter')) lines.push('ผู้แจ้ง พยาบาลเวร');
    if (allergyFieldOn('link')) lines.push('เปิดดูเคส http://61.7.167.197/thamhossafe/allergy_report.php?case=1');
    const pre = document.getElementById('allergyPreview');
    if (pre) pre.textContent = lines.join('\n');
    const box = document.getElementById('allergyMachineBox');
    const picked = document.querySelector('input[name="allergyTarget"]:checked');
    const target = picked ? picked.value : 'both';
    if (box) box.style.display = target === 'machines' ? 'block' : 'none';
    const whoLine = document.getElementById('allergyWho');
    if (whoLine) {
        const names = allergyRecipientNames(target);
        whoLine.textContent = names.length
            ? ('จะส่งถึง ' + names.join(', '))
            : 'ยังไม่มีเครื่องที่ลง Agent และเปิดรับแจ้งในกลุ่มนี้';
    }
}
function allergyRecipientNames(target) {
    let rows = (allergyAgents || []).filter(function (r) {
        return r.agent_installed && r.enabled;
    });
    if (target === 'phar_ipd' || target === 'phar_opd') {
        rows = rows.filter(function (r) { return r.pipeline === target; });
    } else if (target === 'both') {
        rows = rows.filter(function (r) { return r.pipeline === 'phar_ipd' || r.pipeline === 'phar_opd'; });
    } else {
        const on = {};
        document.querySelectorAll('#allergyMachines input[data-agent]:checked').forEach(function (el) {
            on[el.getAttribute('data-agent')] = true;
        });
        rows = rows.filter(function (r) { return !!on[String(r.id)]; });
    }
    return rows.map(function (r) { return r.display_name || r.station_id || r.computername || ('เครื่อง ' + r.id); });
}
function renderAllergyMachines() {
    const box = document.getElementById('allergyMachines');
    if (!box) return;
    const keep = {};
    box.querySelectorAll('input[data-agent]').forEach(function (el) { keep[el.getAttribute('data-agent')] = el.checked; });
    const selected = allergyDirty ? keep : null;
    const rows = (allergyAgents || []).filter(function (r) { return r.agent_installed; });
    const order = { phar_ipd: 0, phar_opd: 1 };
    rows.sort(function (a, b) {
        const da = order[a.pipeline] === undefined ? 9 : order[a.pipeline];
        const db = order[b.pipeline] === undefined ? 9 : order[b.pipeline];
        if (da !== db) return da - db;
        return String(a.station_id || '').localeCompare(String(b.station_id || ''));
    });
    if (!rows.length) {
        box.innerHTML = '<div class="small text-muted">ยังไม่มีเครื่องที่ลง Agent</div>';
        return;
    }
    const chosen = {};
    (allergyCfg.agent_ids || []).forEach(function (id) { chosen[String(id)] = true; });
    box.innerHTML = rows.map(function (r) {
        const id = String(r.id);
        const on = selected ? !!selected[id] : !!chosen[id];
        const pipe = r.pipeline === 'phar_ipd' ? 'ห้องจ่ายยาผู้ป่วยใน' : (r.pipeline === 'phar_opd' ? 'ห้องจ่ายยาผู้ป่วยนอก' : (r.pipeline || 'ยังไม่ระบุช่องทาง'));
        const name = r.display_name || r.station_id || r.computername || ('เครื่อง ' + id);
        return '<div class="form-check">' +
            '<input class="form-check-input" type="checkbox" data-agent="' + esc(id) + '" id="agm' + esc(id) + '"' + (on ? ' checked' : '') + '>' +
            '<label class="form-check-label" for="agm' + esc(id) + '">' + esc(name) +
            ' <span class="text-muted">(' + esc(pipe) + ')</span></label></div>';
    }).join('');
}
function applyAllergyConfig(cfg, agents) {
    if (cfg) allergyCfg = cfg;
    if (agents) allergyAgents = agents;
    if (!allergyDirty && cfg) {
        const radio = document.querySelector('input[name="allergyTarget"][value="' + cfg.target + '"]');
        if (radio) radio.checked = true;
        document.querySelectorAll('.allergy-field').forEach(function (el) {
            const key = el.getAttribute('data-field');
            el.checked = !cfg.fields || cfg.fields[key] !== false;
        });
    }
    renderAllergyMachines();
    refreshAllergyPreview();
    const sw = document.getElementById('allergyAlertSw');
    if (sw) setAllergyAlertUi(sw.checked);
}
function setLoginPromptUi(on) {
    const sw = document.getElementById('loginPromptSw');
    const hint = document.getElementById('loginPromptHint');
    const badge = document.getElementById('loginPromptBadge');
    if (sw) sw.checked = !!on;
    if (hint) hint.textContent = on
        ? 'เปิดอยู่ — หลัง Login จะชวนไปหน้าดาวน์โหลด THAM Notify (เปิดเอง ไม่ยิงไฟล์ติดตั้งเงียบ)'
        : 'ปิดอยู่ — ผู้ใช้เข้าเว็บแล้วจะไม่ขึ้นหน้าต่างชวนดาวน์โหลด (ค่าเริ่มต้น)';
    if (badge) {
        badge.textContent = on ? 'เปิด' : 'ปิด';
        badge.className = 'badge ' + (on ? 'bg-success' : 'bg-secondary');
    }
}
function load() {
    fetch('fetch_tham_alert_api.php?action=agents', { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (data.status !== 'success') {
                document.getElementById('agentBody').innerHTML =
                    '<tr><td colspan="10" class="text-danger text-center py-4">' + esc(data.message || 'โหลดไม่สำเร็จ') + '</td></tr>';
                return;
            }
            if (data.login_prompt !== undefined) setLoginPromptUi(Number(data.login_prompt) === 1);
            if (data.allergy_config) applyAllergyConfig(data.allergy_config, data.agents || []);
            else if (data.agents) allergyAgents = data.agents;
            if (data.allergy_alert !== undefined) setAllergyAlertUi(Number(data.allergy_alert) === 1);
            render(data.agents || []);
        })
        .catch(function () {
            document.getElementById('agentBody').innerHTML =
                '<tr><td colspan="10" class="text-danger text-center py-4">เชื่อมต่อไม่สำเร็จ</td></tr>';
        });
}
document.querySelectorAll('input[name="allergyTarget"], .allergy-field').forEach(function (el) {
    el.addEventListener('change', function () {
        allergyDirty = true;
        refreshAllergyPreview();
    });
});
document.getElementById('allergyMachines').addEventListener('change', function () {
    allergyDirty = true;
});
document.getElementById('allergySaveBtn').addEventListener('click', function () {
    const picked = document.querySelector('input[name="allergyTarget"]:checked');
    const ids = [];
    document.querySelectorAll('#allergyMachines input[data-agent]:checked').forEach(function (el) {
        ids.push(Number(el.getAttribute('data-agent')));
    });
    const fields = {};
    document.querySelectorAll('.allergy-field').forEach(function (el) {
        fields[el.getAttribute('data-field')] = el.checked ? 1 : 0;
    });
    const btn = this;
    const msg = document.getElementById('allergySaveMsg');
    btn.disabled = true;
    if (msg) msg.textContent = '';
    fetch('fetch_tham_alert_api.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'set_allergy_config',
            target: picked ? picked.value : 'both',
            agent_ids: ids,
            fields: fields
        })
    }).then(function (r) { return r.json(); }).then(function (data) {
        btn.disabled = false;
        if (data.status === 'success') {
            allergyDirty = false;
            applyAllergyConfig(data.allergy_config, allergyAgents);
            if (msg) {
                msg.className = 'small text-success ms-2';
                msg.textContent = 'บันทึกแล้ว';
            }
        } else if (msg) {
            msg.className = 'small text-danger ms-2';
            msg.textContent = data.message || 'บันทึกไม่สำเร็จ';
        }
    }).catch(function () {
        btn.disabled = false;
        if (msg) {
            msg.className = 'small text-danger ms-2';
            msg.textContent = 'เชื่อมต่อไม่สำเร็จ';
        }
    });
});
document.getElementById('j2AlertSw').addEventListener('change', function () {
    const sw = this;
    fetch('fetch_tham_alert_api.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'set_j2_eval', enabled: sw.checked ? 1 : 0 })
    }).then(function (r) { return r.json(); }).then(function (data) {
        if (data.status !== 'success') {
            sw.checked = !sw.checked;
            alert(data.message || 'บันทึกไม่สำเร็จ');
            return;
        }
        const on = Number(data.j2_eval) === 1;
        const hint = document.getElementById('j2AlertHint');
        const badge = document.getElementById('j2AlertBadge');
        if (hint) hint.textContent = on
            ? 'เปิดอยู่ — เมื่อเครื่องนั้นคีย์ยาที่มีแบบประเมิน เช่น Bevacizumab จะขึ้นป๊อปอัป และลิงก์เข้าเว็บเป็นผู้ใช้ HOSxP คนนั้น'
            : 'ปิดอยู่ — ยังไม่ส่งป๊อปอัปประเมินยา จ2';
        if (badge) {
            badge.textContent = on ? 'เปิด' : 'ปิด';
            badge.className = 'badge ' + (on ? 'bg-success' : 'bg-secondary');
        }
    }).catch(function () {
        sw.checked = !sw.checked;
        alert('เชื่อมต่อไม่สำเร็จ');
    });
});
document.getElementById('allergyAlertSw').addEventListener('change', function () {
    const sw = this;
    fetch('fetch_tham_alert_api.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'set_allergy_alert', enabled: sw.checked ? 1 : 0 })
    }).then(function (r) { return r.json(); }).then(function (data) {
        if (data.status === 'success') {
            setAllergyAlertUi(Number(data.allergy_alert) === 1);
        } else {
            sw.checked = !sw.checked;
            alert(data.message || 'บันทึกไม่สำเร็จ');
        }
    }).catch(function () {
        sw.checked = !sw.checked;
        alert('เชื่อมต่อไม่สำเร็จ');
    });
});
document.getElementById('loginPromptSw').addEventListener('change', function () {
    const sw = this;
    fetch('fetch_tham_alert_api.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'set_login_prompt', enabled: sw.checked ? 1 : 0 })
    }).then(function (r) { return r.json(); }).then(function (data) {
        if (data.status === 'success') {
            setLoginPromptUi(Number(data.login_prompt) === 1);
        } else {
            sw.checked = !sw.checked;
            alert(data.message || 'บันทึกไม่สำเร็จ');
        }
    }).catch(function () {
        sw.checked = !sw.checked;
        alert('เชื่อมต่อไม่สำเร็จ');
    });
});
const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
document.getElementById('agentBody').addEventListener('keydown', function (e) {
    const inp = e.target.closest('.js-mname');
    if (!inp) return;
    if (e.key === 'Enter') {
        e.preventDefault();
        inp.blur();
    }
});
document.getElementById('agentBody').addEventListener('focusout', function (e) {
    const inp = e.target.closest('.js-mname');
    if (!inp) return;
    const name = inp.value.trim();
    if (name === (inp.getAttribute('data-saved') || '')) return;
    const tr = inp.closest('tr');
    inp.disabled = true;
    fetch('fetch_tham_alert_api.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'set_agent_name', id: Number(tr.dataset.id), name: name })
    }).then(function (r) { return r.json(); }).then(function (data) {
        inp.disabled = false;
        if (data.status === 'success') render(data.agents || []);
        else alert(data.message || 'บันทึกชื่อเครื่องไม่สำเร็จ');
    }).catch(function () {
        inp.disabled = false;
        alert('เชื่อมต่อไม่สำเร็จ');
    });
});
document.getElementById('agentBody').addEventListener('change', function (e) {
    const keep = e.target.closest('.js-keep-login');
    if (keep) {
        const tr = keep.closest('tr');
        fetch('fetch_tham_alert_api.php', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'set_agent_keep_login', id: Number(tr.dataset.id), enabled: keep.checked ? 1 : 0 })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (data.status === 'success') render(data.agents || []);
            else { keep.checked = !keep.checked; alert(data.message || 'บันทึกไม่สำเร็จ'); }
        }).catch(function () { keep.checked = !keep.checked; alert('เชื่อมต่อไม่สำเร็จ'); });
        return;
    }
    const sel = e.target.closest('.js-pipe');
    const sw = e.target.closest('.js-enabled');
    if (!sel && !sw) return;
    const tr = (sel || sw).closest('tr');
    if (sw) {
        fetch('fetch_tham_alert_api.php', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'set_agent_enabled', id: Number(tr.dataset.id), enabled: sw.checked ? 1 : 0 })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (data.status === 'success') render(data.agents || []);
            else { sw.checked = !sw.checked; alert(data.message || 'บันทึกไม่สำเร็จ'); }
        }).catch(function () { sw.checked = !sw.checked; alert('เชื่อมต่อไม่สำเร็จ'); });
        return;
    }
    fetch('fetch_tham_alert_api.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'bind_agent', id: Number(tr.dataset.id), pipeline: sel.value })
    }).then(function (r) { return r.json(); }).then(function (data) {
        if (data.status === 'success') render(data.agents || []);
        else alert(data.message || 'บันทึกไม่สำเร็จ');
    });
});
document.getElementById('agentBody').addEventListener('click', function (e) {
    const tr = e.target.closest('tr');
    if (!tr || !tr.dataset.id) return;
    const id = Number(tr.dataset.id);
    if (e.target.closest('.btn-hide')) {
        const hide = tr.getAttribute('data-hidden') !== '1';
        fetch('fetch_tham_alert_api.php', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'set_agent_hidden', id: id, hidden: hide ? 1 : 0 })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (data.status === 'success') render(data.agents || []);
            else alert(data.message || 'บันทึกไม่สำเร็จ');
        }).catch(function () { alert('เชื่อมต่อไม่สำเร็จ'); });
        return;
    }
    if (e.target.closest('.btn-del')) {
        if (!confirm('ลบเครื่องนี้และประวัติ Login?')) return;
        fetch('fetch_tham_alert_api.php', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'delete_agent', id: id })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (data.status === 'success') render(data.agents || []);
        });
        return;
    }
    if (e.target.closest('.btn-upd')) {
        fetch('fetch_tham_alert_api.php', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'push_update', id: id })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (data.status === 'success') {
                render(data.agents || []);
                alert('สั่งอัปเดตแล้ว เครื่องจะโหลดเวอร์ชันใหม่แล้วเปิดใหม่เอง');
            } else {
                alert(data.message || 'สั่งอัปเดตไม่สำเร็จ');
            }
        }).catch(function () { alert('เชื่อมต่อไม่สำเร็จ'); });
        return;
    }
    if (e.target.closest('.btn-push')) {
        fetch('fetch_tham_alert_api.php', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'push_install', id: id })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (data.status === 'success') {
                render(data.agents || []);
            } else {
                alert(data.message || 'ส่งไม่สำเร็จ');
            }
        }).catch(function () { alert('เชื่อมต่อไม่สำเร็จ'); });
        return;
    }
    if (e.target.closest('.btn-test')) {
        if (tr.getAttribute('data-installed') !== '1') {
            alert('เครื่องนี้ยังไม่ได้ลง THAM Alert Agent — Login เว็บไม่ได้ติดตั้งโปรแกรมให้อัตโนมัติ กรุณาดาวน์โหลดไปลงที่เครื่อง');
            return;
        }
        if (tr.getAttribute('data-enabled') === '0') {
            alert('เครื่องนี้ปิดระบบ Alert อยู่ — เปิดสวิตช์ที่คอลัมน์ ระบบ ก่อนทดสอบ');
            return;
        }
        const msg = prompt('ข้อความทดสอบ', 'ทดสอบการแจ้งเตือน THAM Alert Agent');
        if (msg === null) return;
        fetch('fetch_tham_alert_api.php', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'test_agent', id: id, message: msg })
        }).then(function (r) { return r.json(); }).then(function (data) {
            alert(data.status === 'success'
                ? (data.online
                    ? (data.queued ? 'ส่งข้อความทดสอบแล้ว' : 'ส่งแล้ว (อาจซ้ำกับข้อความทดสอบวินาทีนี้)')
                    : (data.message || 'โปรแกรมบนเครื่องนี้ไม่ได้ทำงาน'))
                : (data.message || 'ส่งไม่สำเร็จ'));
        });
        return;
    }
    if (e.target.closest('.btn-log')) {
        document.getElementById('loginModalSub').textContent = 'เครื่อง #' + id;
        document.getElementById('loginBody').innerHTML = '<tr><td colspan="6" class="text-muted">กำลังโหลด...</td></tr>';
        loginModal.show();
        fetch('fetch_tham_alert_api.php?action=agent_logins&id=' + id, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                const rows = data.logins || [];
                if (!rows.length) {
                    document.getElementById('loginBody').innerHTML = '<tr><td colspan="6" class="text-muted">ยังไม่มีประวัติ Login</td></tr>';
                    return;
                }
                document.getElementById('loginBody').innerHTML = rows.map(function (l) {
                    return '<tr><td class="small">' + esc(l.created_at) + '</td>' +
                        '<td>' + esc(l.full_name || l.username) + '</td>' +
                        '<td>' + esc(roleLabel(l.role)) + '</td>' +
                        '<td>' + esc(l.unit_ward ? l.unit_ward : roomLabel(l.dispense_room)) + '</td>' +
                        '<td><code>' + esc(l.ip_address) + '</code></td>' +
                        '<td>' + netBadge(l) + '</td></tr>';
                }).join('');
            });
    }
});
document.getElementById('btnShowHidden').addEventListener('click', function () {
    showHidden = !showHidden;
    render(allAgents);
});
document.getElementById('btnUpdateAll').addEventListener('click', function () {
    if (!confirm('สั่งให้ทุกเครื่องที่เป็น THAM Notify 1.1.3 ขึ้นไป และยังไม่ใช่เวอร์ชันล่าสุด โหลดอัปเดตเอง?')) return;
    fetch('fetch_tham_alert_api.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'push_update', id: 0 })
    }).then(function (r) { return r.json(); }).then(function (data) {
        if (data.status === 'success') {
            render(data.agents || []);
            alert('สั่งอัปเดต ' + (data.queued || 0) + ' เครื่องแล้ว');
        } else {
            alert(data.message || 'ไม่มีเครื่องที่อัปเดตได้');
        }
    }).catch(function () { alert('เชื่อมต่อไม่สำเร็จ'); });
});
refreshAllergyPreview();
load();
setInterval(load, 20000);
</script>
</body>
</html>
