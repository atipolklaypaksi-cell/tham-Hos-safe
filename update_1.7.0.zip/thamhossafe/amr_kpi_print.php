<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include(__DIR__ . '/connect.php');
require_once __DIR__ . '/amr_kpi_helper.php';
if (is_file(__DIR__ . '/amr_amass_annex.php')) {
    require_once __DIR__ . '/amr_amass_annex.php';
}
if (is_file(__DIR__ . '/amr_amass_helper.php')) {
    require_once __DIR__ . '/amr_amass_helper.php';
}
mysqli_set_charset($con, 'utf8');

$settings = amr_kpi_settings_get($con);
$cap_icd = array_values(array_filter($settings['cap_icd'] ?? [], function ($r) {
    return !isset($r['active']) || (int)$r['active'];
}));
$immuno_icd = array_values(array_filter($settings['immuno_icd'] ?? [], function ($r) {
    return !isset($r['active']) || (int)$r['active'];
}));
$aware_catalog = amr_kpi_aware_catalog();
$hosp_atb = amr_kpi_hospital_atb_by_aware($con);

$hospital = 'โรงพยาบาล';
if (function_exists('amr_amass_cover_info')) {
    $cover = amr_amass_cover_info($con);
    if (!empty($cover['hospital_name_th'])) {
        $hospital = $cover['hospital_name_th'];
    } elseif (!empty($cover['hospital_name'])) {
        $hospital = $cover['hospital_name'];
    }
}
session_write_close();

function kpi_p_esc($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

$print_date = date('d/m/Y H:i');
$lookback = (int)$settings['lookback_days'];
$prior = (int)$settings['prior_admit_days'];
$principal = !empty($settings['principal_only']);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>รายงาน KPI AMR — CAP Medium watch</title>
    <style>
        @page { size: A4 portrait; margin: 10mm 12mm; }
        * { box-sizing: border-box; }
        body {
            font-family: 'Sarabun', 'TH Sarabun New', Tahoma, sans-serif;
            font-size: 11px;
            color: #111;
            background: #fff;
            margin: 0;
            line-height: 1.35;
        }
        .toolbar {
            position: sticky; top: 0; z-index: 20;
            background: #f8fafc; border-bottom: 1px solid #cbd5e1;
            padding: 8px 12px; display: flex; gap: 8px; align-items: center; flex-wrap: wrap;
        }
        .toolbar button {
            padding: 6px 14px; font-weight: 700; border: 1px solid #64748b;
            background: #0f766e; color: #fff; border-radius: 6px; cursor: pointer;
        }
        .toolbar .hint { color: #64748b; font-size: 12px; }
        .sheet { width: 100%; max-width: 190mm; margin: 0 auto; padding: 8px 4px 24px; }
        .print-header {
            border-bottom: 2px solid #0f766e;
            margin-bottom: 10px; padding-bottom: 8px; text-align: center;
        }
        .print-header .org { font-size: 14px; font-weight: 800; }
        .print-header .title { font-size: 16px; font-weight: 800; margin: 2px 0; color: #0f766e; }
        .print-header .meta { font-size: 10.5px; color: #475569; }
        h2 {
            font-size: 12.5px; font-weight: 800; color: #0f766e;
            margin: 14px 0 6px; padding-bottom: 3px;
            border-bottom: 1px solid #99f6e4;
            page-break-after: avoid;
        }
        h3 { font-size: 11.5px; font-weight: 800; margin: 8px 0 4px; page-break-after: avoid; }
        p, li, dd, dt { font-size: 11px; }
        .def-box {
            border: 1px solid #cbd5e1; border-radius: 6px; padding: 8px 10px; margin-bottom: 8px;
            background: #f8fafc;
        }
        .def-box .formula {
            font-weight: 800; margin: 6px 0;
            padding: 4px 8px; border: 1px dashed #94a3b8; border-radius: 4px; background: #fff;
        }
        dl { margin: 0; }
        dt { font-weight: 800; color: #334155; margin-top: 6px; }
        dd { margin: 2px 0 0 12px; }
        ul { margin: 4px 0 0; padding-left: 1.2rem; }
        table {
            width: 100%; border-collapse: collapse; margin: 4px 0 8px;
            font-size: 10px;
        }
        th, td {
            border: 1px solid #94a3b8; padding: 3px 5px; vertical-align: top;
        }
        th { background: #0f766e; color: #fff; font-weight: 700; text-align: left; }
        td.num, th.num { text-align: right; white-space: nowrap; }
        .tag-yes { color: #be123c; font-weight: 800; }
        .tag-no { color: #047857; font-weight: 700; }
        .kpi-row { display: flex; gap: 8px; flex-wrap: wrap; margin: 6px 0 10px; }
        .kpi-cell {
            flex: 1 1 30%; min-width: 140px;
            border: 1px solid #99f6e4; border-radius: 6px; padding: 8px; text-align: center;
            background: #f0fdfa;
        }
        .kpi-cell.rose {
            border-color: #fecdd3; background: #fff1f2;
        }
        .kpi-cell .n { font-size: 18px; font-weight: 800; color: #0f766e; }
        .kpi-cell.rose .n { color: #be123c; }
        .kpi-cell .l { font-size: 10px; color: #475569; font-weight: 700; }
        .kpi-cell .s { font-size: 10px; font-weight: 700; }
        .chip {
            display: inline-block; border: 1px solid #cbd5e1; border-radius: 999px;
            padding: 1px 8px; margin: 0 4px 4px 0; font-size: 10px; background: #f1f5f9;
        }
        .note { color: #64748b; font-size: 10px; margin: 2px 0 6px; }
        .warn { color: #b45309; font-weight: 700; }
        .section { page-break-inside: avoid; }
        .avoid-break { page-break-inside: avoid; }
        .footer {
            margin-top: 16px; padding-top: 8px; border-top: 1px solid #cbd5e1;
            font-size: 10px; color: #64748b; text-align: center;
        }
        #resultWait { padding: 12px; text-align: center; color: #b45309; font-weight: 700; }
        #resultBlock.hidden, #resultWait.hidden { display: none; }
        @media print {
            .toolbar { display: none !important; }
            .sheet { max-width: none; padding: 0; }
            a { color: inherit; text-decoration: none; }
        }
    </style>
</head>
<body>
<div class="toolbar">
    <button type="button" onclick="window.print()">พิมพ์ / บันทึก PDF</button>
    <button type="button" style="background:#64748b;" onclick="window.close()">ปิด</button>
    <span class="hint">แนะนำ: กระดาษ A4 · แนวตั้ง · ขนาด 100% · ปลายทางเป็น PDF</span>
</div>

<div class="sheet">
    <div class="print-header">
        <div class="org"><?php echo kpi_p_esc($hospital); ?></div>
        <div class="title">รายงาน KPI AMR — CAP Medium watch (non-MDR risk)</div>
        <div class="meta">สูตรแม่แบบ AMR-SP 02 · พิมพ์เมื่อ <?php echo kpi_p_esc($print_date); ?></div>
        <div class="meta" id="hdrRange">ช่วงรายงาน: รอโหลดผลลัพธ์จากหน้า KPI…</div>
    </div>

    <div class="section">
        <h2>1. นิยามตัวชี้วัด</h2>
        <div class="def-box">
            <div><b>ร้อยละผู้ป่วย CAP กลุ่ม non-MDR risk ที่ได้รับยากลุ่ม Medium-Watch</b></div>
            <div class="note" style="font-style:italic;">Proportion of non-MDR-risk CAP patients receiving Medium-Watch antibiotics (AWaRe)</div>
            <dl>
                <dt>ประชากรเป้าหมาย (ตัวส่วน B)</dt>
                <dd>
                    ผู้ป่วยในที่มี ICD ปอดอักเสบ ที่ได้รับยาปฏิชีวนะ และเป็นกลุ่ม <b>non-MDR risk (CAP ชุมชน)</b> คือ
                    <ul>
                        <li>ไม่เคย admit IPD ใน <?php echo (int)$prior; ?> วันก่อนหน้า (ค่าที่ตั้ง)</li>
                        <li>ไม่เป็น immunocompromised (ICD ย้อนหลัง <?php echo (int)$lookback; ?> วัน)</li>
                    </ul>
                </dd>
                <dt>ตัวเศษ (A)</dt>
                <dd>ผู้ป่วยในตัวส่วนที่ได้รับยาปฏิชีวนะกลุ่ม <b>Medium watch</b> ตาม WHO AWaRe</dd>
            </dl>
            <div class="formula">ร้อยละ = (A / B) × 100 · ต้องไม่ผลักภาระไปยา Reserve</div>
            <dl>
                <dt>กลุ่มที่แยกเปรียบเทียบ (ไม่นับในตัวชี้วัดหลัก)</dt>
                <dd>CAP ทั้งหมด · CAP กลุ่มเสี่ยง (immuno และ admit <?php echo (int)$prior; ?> วัน) · immuno อย่างเดียว · admit ก่อนอย่างเดียว</dd>
                <dt>เงื่อนไขวินิจฉัย</dt>
                <dd><?php echo $principal ? 'ใช้เฉพาะวินิจฉัยหลัก (diagtype 1)' : 'ใช้ทุกรหัสวินิจฉัยที่ตรง prefix'; ?></dd>
            </dl>
        </div>
    </div>

    <div class="section">
        <h2>2. ICD ปอดอักเสบ (CAP) ที่ใช้ดึง</h2>
        <p class="note">prefix ตรงกับรหัสใน iptdiag · จำนวน <?php echo count($cap_icd); ?> รายการที่เปิดใช้</p>
        <?php if (!$cap_icd): ?>
            <p class="warn">ยังไม่ได้ตั้งรหัส ICD ของ CAP</p>
        <?php else: ?>
            <table>
                <thead><tr><th style="width:18%">ICD prefix</th><th>คำอธิบาย</th></tr></thead>
                <tbody>
                <?php foreach ($cap_icd as $r): ?>
                    <tr>
                        <td><b><?php echo kpi_p_esc($r['icd_prefix'] ?? ''); ?></b></td>
                        <td><?php echo kpi_p_esc($r['label'] ?? ''); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="section">
        <h2>3. ICD immunocompromised ที่ใช้ตัดออกจาก non-MDR risk</h2>
        <p class="note">ค้นในประวัติ IPD/OPD ย้อนหลัง <?php echo (int)$lookback; ?> วัน · จำนวน <?php echo count($immuno_icd); ?> รายการที่เปิดใช้</p>
        <?php if (!$immuno_icd): ?>
            <p class="warn">ยังไม่ได้ตั้งรหัส ICD immunocompromised</p>
        <?php else: ?>
            <table>
                <thead><tr><th style="width:18%">ICD prefix</th><th>คำอธิบาย</th></tr></thead>
                <tbody>
                <?php foreach ($immuno_icd as $r): ?>
                    <tr>
                        <td><b><?php echo kpi_p_esc($r['icd_prefix'] ?? ''); ?></b></td>
                        <td><?php echo kpi_p_esc($r['label'] ?? ''); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="section">
        <h2>4. ยาปฏิชีวนะ (TMT / generic) ที่จำแนกแต่ละกลุ่ม AWaRe</h2>
        <p class="note">
            ระบบดึงยาปฏิชีวนะจาก HOSxP (opitemrece / medplan_ipd) แล้วจับคู่ชื่อ TMT/generic กับแผนที่ AWaRe
            · ตัวชี้วัดหลักนับ <b>Medium watch</b> และเฝ้าระวัง <b>Reserve</b>
        </p>

        <h3>4.1 แผนที่จำแนก AWaRe (อ้างอิงระบบ)</h3>
        <?php
        $show_groups = ['Medium watch', 'Reserve', 'High watch', 'Low watch', 'Access'];
        foreach ($show_groups as $gname):
            $list = $aware_catalog[$gname] ?? [];
            if (!$list) {
                continue;
            }
        ?>
            <div class="avoid-break">
                <h3><?php echo kpi_p_esc($gname); ?> (<?php echo count($list); ?> รายการ)</h3>
                <div>
                    <?php foreach ($list as $nm): ?>
                        <span class="chip"><?php echo kpi_p_esc($nm); ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <h3>4.2 ยาปฏิชีวนะที่ตั้งค่าในโรงพยาบาล (รายการที่ระบบดึงจริง)</h3>
        <?php foreach ($hosp_atb['notes'] as $n): ?>
            <p class="note warn"><?php echo kpi_p_esc($n); ?></p>
        <?php endforeach; ?>
        <?php if (empty($hosp_atb['by_aware'])): ?>
            <p class="note">ยังไม่มีรายการยา ATB ของโรงพยาบาล — การจำแนกจะใช้ชื่อยาจาก TMT ตามแผนที่ด้านบน</p>
        <?php else: ?>
            <?php foreach ($hosp_atb['by_aware'] as $gname => $drugs): ?>
                <div class="avoid-break">
                    <h3><?php echo kpi_p_esc($gname); ?> — <?php echo count($drugs); ?> รายการ</h3>
                    <table>
                        <thead>
                            <tr>
                                <th style="width:14%">icode</th>
                                <th>ชื่อที่ใช้จำแนก / TMT</th>
                                <th>ชื่อในระบบ</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($drugs as $d): ?>
                            <tr>
                                <td><?php echo kpi_p_esc($d['icode']); ?></td>
                                <td><b><?php echo kpi_p_esc($d['name']); ?></b></td>
                                <td><?php echo kpi_p_esc($d['drug_name'] !== '' ? $d['drug_name'] : ($d['generic_name'] ?? '')); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div id="resultWait">กำลังโหลดผลลัพธ์รายงานจากหน้า KPI…</div>
    <div id="resultBlock" class="hidden">
        <h2>5. ผลลัพธ์รายงาน</h2>
        <div id="resultMeta" class="note"></div>
        <div class="kpi-row" id="resultKpis"></div>
        <div id="resultCompare"></div>
        <div id="resultVerdict"></div>
        <div id="resultCohorts"></div>
        <div id="resultReserve"></div>
        <div id="resultMix"></div>
        <h3>รายชื่อ CAP ชุมชน (ตัวชี้วัดหลัก · สูงสุด 400 ราย)</h3>
        <div id="resultRowsCommunity"></div>
        <h3>รายชื่อกลุ่มเสี่ยง AND</h3>
        <div id="resultRowsRisk"></div>
        <h3>รายชื่อที่ใช้ยา Reserve</h3>
        <div id="resultRowsReserve"></div>
    </div>

    <div class="footer">
        KPI AMR · AMS Quality · <?php echo kpi_p_esc($hospital); ?> · สร้างจากระบบ ThamHosSafe
    </div>
</div>

<script>
(function () {
    const STORAGE_KEY = 'amr_kpi_print_payload_v1';
    let maskNames = true;

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
    function pct(v) { return v == null || v === '' ? '–' : (Number(v).toFixed(1) + '%'); }
    function yn(v, yesTxt, noTxt) {
        return v ? ('<span class="tag-yes">' + esc(yesTxt || 'ใช่') + '</span>') : ('<span class="tag-no">' + esc(noTxt || 'ไม่') + '</span>');
    }
    function displayName(r) {
        if (maskNames) return 'ผู้ป่วย';
        return r && r.pt_name ? r.pt_name : '';
    }
    function fyShort(be) { return Number(be) - 2500; }
    function deltaTxt(curr, prev) {
        if (curr == null || prev == null) return '–';
        const d = Math.round(10 * (Number(curr) - Number(prev))) / 10;
        if (Math.abs(d) < 0.05) return '0.0';
        return (d > 0 ? '+' : '') + d.toFixed(1);
    }

    function pickOfficial(data) {
        return (data && data.official_community) ? data.official_community
            : ((data && data.official) ? data.official : {});
    }

    function rowsTable(rows, emptyMsg) {
        if (!rows || !rows.length) {
            return '<p class="note">' + esc(emptyMsg) + '</p>';
        }
        let h = '<table><thead><tr>'
            + '<th>HN</th><th>AN</th><th>ชื่อ</th><th>อายุ</th><th>Admit</th><th>หอ</th>'
            + '<th>ICD CAP</th><th>Immuno</th><th>Admit ก่อน</th><th>Medium</th><th>Reserve</th><th>ยา ATB</th>'
            + '</tr></thead><tbody>';
        rows.forEach(function (r) {
            h += '<tr>'
                + '<td>' + esc(r.hn) + '</td>'
                + '<td>' + esc(r.an) + '</td>'
                + '<td>' + esc(displayName(r)) + '</td>'
                + '<td>' + esc(r.age_y) + (r.sex ? ' ' + esc(r.sex) : '') + '</td>'
                + '<td>' + esc(r.regdate) + (r.dchdate ? '<br>' + esc(r.dchdate) : '') + '</td>'
                + '<td>' + esc(r.ward_name) + '</td>'
                + '<td>' + esc(r.cap_icds) + '</td>'
                + '<td>' + (r.immuno ? yn(1, 'มี') + '<br><span class="note">' + esc(r.immuno_text) + '</span>' : yn(0, '', 'ไม่มี')) + '</td>'
                + '<td>' + (r.prior_admit ? yn(1, 'มี') + '<br><span class="note">' + esc(r.prior_text) + '</span>' : yn(0, '', 'ไม่มี')) + '</td>'
                + '<td>' + (r.used_medium_watch ? yn(1, 'ใช้') + '<br><span class="note">' + esc((r.medium_watch_drugs || []).join(', ')) + '</span>' : yn(0, '', 'ไม่ใช้')) + '</td>'
                + '<td>' + (r.used_reserve ? yn(1, 'ใช้') + '<br><span class="note">' + esc((r.reserve_drugs || []).join(', ')) + '</span>' : yn(0, '', 'ไม่ใช้')) + '</td>'
                + '<td>' + esc(r.drug_text || '–') + '</td>'
                + '</tr>';
        });
        return h + '</tbody></table>';
    }

    function compareBlock(ctx) {
        if (!ctx || !ctx.evalYears) return '';
        const fyMap = ctx.fyMap || {};
        const calMap = ctx.calMap || {};
        const fys = [2567, 2568, 2569, 2570].filter(function (be) {
            return fyMap[be] && fyMap[be].pct != null;
        });
        if (!fys.length) return '';
        let h = '<h2>5.0 เปรียบเทียบหลายปีปฏิทิน (CAP ชุมชน · แบ่งช่วง 6 เดือน)</h2>';
        h += '<table><thead><tr><th>รายการ</th>';
        fys.forEach(function (be) { h += '<th class="num">ปี ' + fyShort(be) + '</th>'; });
        h += '</tr></thead><tbody>';
        const defs = [
            ['A / B', function (c) { return (c.a || 0) + ' / ' + (c.b || 0); }],
            ['Medium %', function (c) { return pct(c.pct); }],
            ['Reserve %', function (c) { return pct(c.reserve_pct); }],
            ['ใช้ Reserve (ราย)', function (c) { return String(c.reserve_n || 0); }]
        ];
        defs.forEach(function (def) {
            h += '<tr><td>' + esc(def[0]) + '</td>';
            fys.forEach(function (be) {
                h += '<td class="num">' + esc(def[1](fyMap[be] || {})) + '</td>';
            });
            h += '</tr>';
        });
        h += '<tr><td>Δ Medium จากปีก่อน</td>';
        fys.forEach(function (be, i) {
            const cur = fyMap[be];
            const prev = i > 0 ? fyMap[fys[i - 1]] : null;
            h += '<td class="num">' + esc(i === 0 ? '–' : deltaTxt(cur && cur.pct, prev && prev.pct)) + '</td>';
        });
        h += '</tr><tr><td>Δ Reserve จากปีก่อน</td>';
        fys.forEach(function (be, i) {
            const cur = fyMap[be];
            const prev = i > 0 ? fyMap[fys[i - 1]] : null;
            h += '<td class="num">' + esc(i === 0 ? '–' : deltaTxt(cur && cur.reserve_pct, prev && prev.reserve_pct)) + '</td>';
        });
        h += '</tr></tbody></table>';

        const calYears = Object.keys(calMap).map(Number).sort();
        if (calYears.length) {
            h += '<h3>Baseline ปีปฏิทิน</h3><table><thead><tr>'
                + '<th>ปีปฏิทิน</th><th class="num">A / B</th><th class="num">Medium %</th><th class="num">Reserve %</th>'
                + '</tr></thead><tbody>';
            calYears.forEach(function (y) {
                const c = calMap[y] || {};
                h += '<tr><td>' + fyShort(y + 543) + ' (' + y + ')</td>'
                    + '<td class="num">' + esc((c.a || 0) + ' / ' + (c.b || 0)) + '</td>'
                    + '<td class="num">' + esc(pct(c.pct)) + '</td>'
                    + '<td class="num">' + esc(pct(c.reserve_pct)) + '</td></tr>';
            });
            h += '</tbody></table>';
        }
        return h;
    }

    function mixBlock(data) {
        const cs = data.cohorts || {};
        const blocks = [
            ['community', 'CAP ชุมชน (ตัวชี้วัดหลัก)'],
            ['risk_and', 'กลุ่มเสี่ยง AND'],
            ['all', 'CAP ทั้งหมด']
        ];
        let h = '<h2>5.2 ยา Medium watch ที่พบในช่วงรายงาน</h2>';
        blocks.forEach(function (pair) {
            const key = pair[0], label = pair[1];
            const c = cs[key] || {};
            const mix = c.medium_mix || [];
            const aware = c.aware_mix || [];
            h += '<div class="avoid-break"><h3>' + esc(label) + '</h3>';
            if (aware.length) {
                h += '<table><thead><tr><th>AWaRe</th><th class="num">รายการใช้</th></tr></thead><tbody>';
                aware.forEach(function (m) {
                    h += '<tr><td>' + esc(m.aware) + '</td><td class="num">' + esc(m.n) + '</td></tr>';
                });
                h += '</tbody></table>';
            }
            h += '<b>Medium watch</b>';
            if (!mix.length) {
                h += '<p class="note">ไม่พบ</p></div>';
                return;
            }
            h += '<table><thead><tr><th>ยา</th><th class="num">ราย</th></tr></thead><tbody>';
            mix.forEach(function (m) {
                h += '<tr><td>' + esc(m.name) + '</td><td class="num">' + esc(m.n) + '</td></tr>';
            });
            h += '</tbody></table></div>';
        });
        return h;
    }

    function reserveBlock(data) {
        const cs = data.cohorts || {};
        const oc = pickOfficial(data);
        const orisk = data.official_risk_and || {};
        const oall = data.official || {};
        const blocks = [
            ['community', 'CAP ชุมชน (ตัวชี้วัดหลัก)', oc],
            ['risk_and', 'กลุ่มเสี่ยง AND', orisk],
            ['all', 'CAP ทั้งหมด', oall]
        ];

        let h = '<h2>5.1 รายงาน Reserve (เฝ้าระวังผลักภาระ)</h2>';
        h += '<p class="note">เมื่อลด Medium watch ต้องยืนยันว่าไม่ได้ผลักภาระไปยา Reserve — ร้อยละ = ผู้ป่วยที่ได้ Reserve / ผู้ป่วยที่ได้ยาปฏิชีวนะในกลุ่ม</p>';

        h += '<div class="kpi-row">';
        blocks.forEach(function (pair) {
            const off = pair[2] || {};
            const c = cs[pair[0]] || {};
            const rn = off.reserve_n != null ? off.reserve_n : (c.reserve_n || 0);
            const rb = off.b != null ? off.b : (c.reserve_b != null ? c.reserve_b : (c.denominator || 0));
            const rp = off.reserve_pct != null ? off.reserve_pct : c.reserve_pct;
            h += '<div class="kpi-cell rose"><div class="n">' + esc(pct(rp)) + '</div>'
                + '<div class="l">% Reserve · ' + esc(pair[1]) + '</div>'
                + '<div class="s">' + esc(rn) + ' / ' + esc(rb) + ' ราย</div></div>';
        });
        h += '</div>';

        const order = ['community', 'risk_and', 'immuno_only', 'prior_only', 'risk_or', 'all'];
        h += '<h3>สรุป Reserve ตามกลุ่มประชากร</h3>';
        h += '<table><thead><tr>'
            + '<th>กลุ่ม</th><th class="num">ได้ ATB (B)</th><th class="num">ใช้ Reserve</th><th class="num">Reserve %</th>'
            + '<th>ยา Reserve ที่พบบ่อย</th>'
            + '</tr></thead><tbody>';
        order.forEach(function (k) {
            const c = cs[k];
            if (!c) return;
            let off = null;
            if (k === 'community') off = oc;
            else if (k === 'risk_and') off = orisk;
            else if (k === 'all') off = oall;
            const rn = off && off.reserve_n != null ? off.reserve_n : (c.reserve_n || 0);
            const rb = off && off.b != null ? off.b : (c.reserve_b != null ? c.reserve_b : (c.denominator || 0));
            const rp = off && off.reserve_pct != null ? off.reserve_pct : c.reserve_pct;
            const top = (c.reserve_mix || []).slice(0, 5).map(function (m) {
                return m.name + ' (' + m.n + ')';
            }).join(', ') || '–';
            h += '<tr><td>' + esc(c.label) + '</td>'
                + '<td class="num">' + esc(rb) + '</td>'
                + '<td class="num">' + esc(rn) + '</td>'
                + '<td class="num">' + esc(pct(rp)) + '</td>'
                + '<td>' + esc(top) + '</td></tr>';
        });
        h += '</tbody></table>';

        h += '<h3>รายการยา Reserve ที่พบ (แยกตามกลุ่ม)</h3>';
        blocks.forEach(function (pair) {
            const c = cs[pair[0]] || {};
            const rmix = c.reserve_mix || [];
            h += '<div class="avoid-break"><h3>' + esc(pair[1]) + '</h3>';
            if (!rmix.length) {
                h += '<p class="note">ไม่พบยา Reserve ในกลุ่มนี้</p></div>';
                return;
            }
            h += '<table><thead><tr><th>ยา Reserve</th><th class="num">ราย</th></tr></thead><tbody>';
            rmix.forEach(function (m) {
                h += '<tr><td>' + esc(m.name) + '</td><td class="num">' + esc(m.n) + '</td></tr>';
            });
            h += '</tbody></table></div>';
        });
        return h;
    }

    function collectReserveRows(data) {
        const seen = {};
        const out = [];
        [].concat(data.rows_community || [], data.rows_risk_and || [], data.rows_all || []).forEach(function (r) {
            if (!r || !r.used_reserve) return;
            const k = String(r.an || '');
            if (k && seen[k]) return;
            if (k) seen[k] = true;
            out.push(r);
        });
        return out;
    }

    function render(payload) {
        const data = payload.data || payload;
        const ctx = payload.kpiCtx || data.kpiCtx || {};
        maskNames = payload.maskNames !== false;
        const meta = data.meta || {};
        const oc = pickOfficial(data);
        const orisk = data.official_risk_and || {};
        const oall = data.official || {};
        const cs = data.cohorts || {};

        document.getElementById('hdrRange').textContent =
            'ช่วง admit: ' + (meta.start || '–') + ' ถึง ' + (meta.end || '–')
            + ' · immuno ย้อนหลัง ' + (meta.lookback_days != null ? meta.lookback_days : '–') + ' วัน'
            + ' · admit ก่อน ' + (meta.prior_admit_days != null ? meta.prior_admit_days : '–') + ' วัน'
            + ' · CAP ทั้งหมด ' + (meta.n_all != null ? meta.n_all : '–') + ' ราย'
            + (maskNames ? ' · ปกปิดชื่อผู้ป่วย' : ' · แสดงชื่อผู้ป่วย');

        document.getElementById('resultMeta').innerHTML =
            'ปีปฏิทินที่เลือก: ' + (ctx.fyBe ? (Number(ctx.fyBe) - 2500) : '–')
            + (ctx.evalYears ? ' · เปรียบเทียบหลายปีปฏิทิน (แบ่งช่วง 6 เดือน)' : '')
            + (meta.principal_only ? ' · เฉพาะวินิจฉัยหลัก' : ' · ทุกรหัสวินิจฉัย')
            + ((meta.notes && meta.notes.length) ? (' · ' + meta.notes.map(esc).join(' / ')) : '');

        document.getElementById('resultKpis').innerHTML =
            '<div class="kpi-cell"><div class="n">' + esc(pct(oc.pct)) + '</div>'
            + '<div class="l">% Medium · CAP ชุมชน (ตัวชี้วัดหลัก)</div>'
            + '<div class="s">' + esc((oc.a || 0) + ' / ' + (oc.b || 0)) + '</div></div>'
            + '<div class="kpi-cell"><div class="n">' + esc(pct(orisk.pct)) + '</div>'
            + '<div class="l">% Medium · กลุ่มเสี่ยง AND</div>'
            + '<div class="s">' + esc((orisk.a || 0) + ' / ' + (orisk.b || 0)) + '</div></div>'
            + '<div class="kpi-cell"><div class="n">' + esc(pct(oall.pct)) + '</div>'
            + '<div class="l">% Medium · CAP ทั้งหมด</div>'
            + '<div class="s">' + esc((oall.a || 0) + ' / ' + (oall.b || 0)) + '</div></div>'
            + '<div class="kpi-cell rose"><div class="n">' + esc(pct(oc.reserve_pct)) + '</div>'
            + '<div class="l">% Reserve · CAP ชุมชน</div>'
            + '<div class="s">' + esc((oc.reserve_n || 0) + ' / ' + (oc.b || 0)) + '</div></div>'
            + '<div class="kpi-cell rose"><div class="n">' + esc(pct(orisk.reserve_pct)) + '</div>'
            + '<div class="l">% Reserve · กลุ่มเสี่ยง AND</div>'
            + '<div class="s">' + esc((orisk.reserve_n || 0) + ' / ' + (orisk.b || 0)) + '</div></div>'
            + '<div class="kpi-cell rose"><div class="n">' + esc(pct(oall.reserve_pct)) + '</div>'
            + '<div class="l">% Reserve · CAP ทั้งหมด</div>'
            + '<div class="s">' + esc((oall.reserve_n || 0) + ' / ' + (oall.b || 0)) + '</div></div>';

        const cmpEl = document.getElementById('resultCompare');
        if (cmpEl) cmpEl.innerHTML = compareBlock(ctx);

        const order = ['community', 'risk_and', 'immuno_only', 'prior_only', 'risk_or', 'all'];
        let ch = '<h3>สรุปตามกลุ่มประชากร (Medium + Reserve)</h3><table><thead><tr>'
            + '<th>กลุ่ม</th><th class="num">จำนวน</th><th class="num">ใช้ Medium</th><th class="num">Medium %</th>'
            + '<th class="num">ใช้ Reserve</th><th class="num">Reserve %</th>'
            + '</tr></thead><tbody>';
        order.forEach(function (k) {
            const c = cs[k];
            if (!c) return;
            let off = null;
            if (k === 'community') off = oc;
            else if (k === 'risk_and') off = orisk;
            else if (k === 'all') off = oall;
            const rn = off && off.reserve_n != null ? off.reserve_n : (c.reserve_n || 0);
            const rp = off && off.reserve_pct != null ? off.reserve_pct : c.reserve_pct;
            ch += '<tr><td>' + esc(c.label) + '</td>'
                + '<td class="num">' + esc(c.denominator || 0) + '</td>'
                + '<td class="num">' + esc(c.numerator || 0) + '</td>'
                + '<td class="num">' + esc(pct(c.pct)) + '</td>'
                + '<td class="num">' + esc(rn) + '</td>'
                + '<td class="num">' + esc(pct(rp)) + '</td></tr>';
        });
        ch += '</tbody></table>';
        document.getElementById('resultCohorts').innerHTML = ch;
        document.getElementById('resultReserve').innerHTML = reserveBlock(data);
        document.getElementById('resultMix').innerHTML = mixBlock(data);
        document.getElementById('resultRowsCommunity').innerHTML =
            rowsTable(data.rows_community, 'ไม่พบ CAP ชุมชนในช่วงนี้');
        document.getElementById('resultRowsRisk').innerHTML =
            rowsTable(data.rows_risk_and, 'ไม่พบกลุ่มเสี่ยง AND');
        document.getElementById('resultRowsReserve').innerHTML =
            rowsTable(collectReserveRows(data), 'ไม่พบผู้ป่วยที่ใช้ยา Reserve ในช่วงนี้');

        document.getElementById('resultWait').classList.add('hidden');
        document.getElementById('resultBlock').classList.remove('hidden');
    }

    function boot() {
        let raw = null;
        try { raw = sessionStorage.getItem(STORAGE_KEY); } catch (e) {}
        if (!raw) {
            document.getElementById('resultWait').innerHTML =
                '<span class="warn">ยังไม่มีผลลัพธ์ — กรุณากลับไปหน้า KPI AMR กด «ดึงข้อมูล» แล้วกด «พิมพ์ PDF» อีกครั้ง</span>';
            return;
        }
        try {
            const payload = JSON.parse(raw);
            render(payload);
            setTimeout(function () { window.print(); }, 400);
        } catch (e) {
            document.getElementById('resultWait').innerHTML =
                '<span class="warn">อ่านผลลัพธ์ไม่สำเร็จ: ' + esc(e.message || e) + '</span>';
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
</script>
</body>
</html>
