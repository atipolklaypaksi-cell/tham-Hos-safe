<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/amr_dictionary_helper.php';
require_once __DIR__ . '/amr_mlab_helper.php';
require_once __DIR__ . '/amr_amass_helper.php';
require_once __DIR__ . '/amr_amass_engine.php';
mysqli_set_charset($con, 'utf8');
amr_dict_ensure_tables($con);
amr_amass_seed_ward_aliases($con);
$amass_micro_source = amr_amass_dataset_source($con, 'microbiology');
$amass_micro_source_label = $amass_micro_source === 'mlab'
    ? 'mLAB (ตาราง THAM Hos-Safe)'
    : 'HOSxP lab_head';
$pkg = amr_amass_package_status();
$staged = amr_amass_staged_status();
$kpis = amr_amass_result_kpis();
$tables = amr_amass_dashboard_tables();
$meta = $tables['meta'] ?? [];
$have_data = 0;
foreach ($staged as $s) {
    if (!empty($s['exists'])) {
        $have_data++;
    }
}
$has_report = !empty($tables['meta']) || !empty($tables['section2']);
$report_links = [
    ['amr_amass_print.php', 'รายงานหลัก', 'AMR surveillance report'],
    ['amr_amass_print.php?section=sec1', 'Section 1', 'Data overview'],
    ['amr_amass_print.php?section=sec2', 'Section 2', 'AMR proportion report'],
    ['amr_amass_print.php?section=sec3', 'Section 3', 'AMR proportion by origin'],
    ['amr_amass_print.php?section=sec4', 'Section 4', 'AMR frequency report'],
    ['amr_amass_print.php?section=sec5', 'Section 5', 'AMR frequency by origin'],
    ['amr_amass_print.php?section=sec6', 'Section 6', 'Mortality'],
    ['amr_amass_print.php?section=annex-b', 'Annex B', 'Data indicators'],
    ['amr_amass_print.php?section=annex-c', 'Annex C', 'Cluster signals'],
    ['amr_amass_print.php?section=annex-d', 'Annex D', 'AMU'],
];
$amass_start = date('Y') . '-01-01';
$amass_end = date('Y-m-d');
$compare_year_options = [];
for ($y = (int)date('Y'); $y >= (int)date('Y') - 10; $y--) {
    $compare_year_options[] = $y;
}
$default_compare_year = (int)date('Y') - 1;
$default_compare_months = [];
for ($slot = 1; $slot <= 3; $slot++) {
    $default_compare_months[$slot] = date('Y-m', strtotime('-' . $slot . ' month'));
}
$cover = amr_amass_cover_info($con);
$hospital_name = $cover['hospital_name'];
$hospital_name_th = $cover['hospital_name_th'] !== '' ? $cover['hospital_name_th'] : $hospital_name;
$periods = amr_amass_list_periods();
session_write_close();
function amass_kpi($v) {
    $v = trim((string)$v);
    return $v === '' ? '–' : $v;
}
function amass_with_total($kind, array $rows) {
    if (empty($rows) || $kind === 'pct' || $kind === 'pct_origin') {
        return $rows;
    }
    foreach ($rows as $row) {
        $label = (string)($row['Organism'] ?? $row['drug_name'] ?? '');
        if ($label === 'Total:' || $label === 'Total') {
            return $rows;
        }
    }
    if ($kind === 'freq') {
        $n = 0;
        $denom = 0;
        $denom_key = '';
        if (isset($rows[0]['Tested_patients'])) {
            $denom_key = 'Tested_patients';
        } elseif (isset($rows[0]['Patient_days'])) {
            $denom_key = 'Patient_days';
        }
        foreach ($rows as $row) {
            if (is_numeric($row['Number_of_patients'] ?? '')) {
                $n += (int)$row['Number_of_patients'];
            }
            if ($denom_key !== '' && $denom === 0 && is_numeric($row[$denom_key] ?? '')) {
                $denom = (int)$row[$denom_key];
            }
        }
        $total = $rows[0];
        $total['Organism'] = 'Total:';
        $total['Number_of_patients'] = $n;
        if ($denom_key === 'Tested_patients' && function_exists('amr_amass_freq_per_100k')) {
            $f = amr_amass_freq_per_100k($n, $denom);
            $total['frequency_per_tested'] = $f['rate'];
            $total['frequency_per_tested_lci'] = $f['lo'];
            $total['frequency_per_tested_uci'] = $f['hi'];
        }
        $rows[] = $total;
        return $rows;
    }
    if ($kind === 'mort_origin') {
        $by = [];
        foreach ($rows as $row) {
            $origin = (string)($row['Infection_origin'] ?? '');
            if ($origin === '') {
                continue;
            }
            if (!isset($by[$origin])) {
                $by[$origin] = ['d' => 0, 'n' => 0];
            }
            if (is_numeric($row['Number_of_deaths'] ?? '')) {
                $by[$origin]['d'] += (int)$row['Number_of_deaths'];
            }
            if (is_numeric($row['Total_number_of_patients'] ?? '')) {
                $by[$origin]['n'] += (int)$row['Total_number_of_patients'];
            }
        }
        foreach ($by as $origin => $sum) {
            $ci = function_exists('amr_amass_wilson') ? amr_amass_wilson($sum['d'], $sum['n']) : ['pct' => '', 'lo' => '', 'hi' => ''];
            $rows[] = [
                'Organism' => 'Total:',
                'Infection_origin' => $origin,
                'Number_of_deaths' => $sum['d'],
                'Total_number_of_patients' => $sum['n'],
                'Mortality(%)' => $ci['pct'],
                'Mortality_lower_95ci' => $ci['lo'],
                'Mortality_upper_95ci' => $ci['hi'],
            ];
        }
        return $rows;
    }
    if ($kind === 'amu') {
        $sum = 0;
        foreach ($rows as $row) {
            if (is_numeric($row['prescriptions'] ?? '')) {
                $sum += (int)$row['prescriptions'];
            }
        }
        $rows[] = ['drug_name' => 'Total:', 'prescriptions' => $sum];
    }
    return $rows;
}
function amass_render_table($rows, $cols) {
    if (empty($rows)) {
        echo '<p class="small text-muted mb-0">ยังไม่มีผลวิเคราะห์ — กดดึงข้อมูลและสร้าง Dashboard</p>';
        return;
    }
    echo '<div class="table-responsive"><table class="table table-sm table-bordered amass-table mb-0"><thead><tr>';
    foreach ($cols as $key => $label) {
        echo '<th>' . htmlspecialchars($label) . '</th>';
    }
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        $is_total = in_array((string)($row['Organism'] ?? $row['drug_name'] ?? $row['Antibiotic'] ?? $row['Month'] ?? $row['AWaRe_classification'] ?? $row['Department'] ?? $row['Route_of_administration'] ?? $row['Antifungal'] ?? ''), ['Total:', 'Total'], true);
        echo '<tr' . ($is_total ? ' class="total"' : '') . '>';
        foreach ($cols as $key => $label) {
            $v = $row[$key] ?? '';
            $cls = [];
            if (is_numeric($v)) {
                $cls[] = 'num';
            }
            if ($key === 'Organism' || $key === 'drug_name') {
                $cls[] = $is_total ? 'total-label' : 'org';
            }
            $attr = $cls ? ' class="' . implode(' ', $cls) . '"' : '';
            echo '<td' . $attr . '>' . htmlspecialchars((string)$v) . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}

function amass_render_viz($id, $kind, $rows, $cols, $compare_key = '') {
    $rows = amass_with_total($kind, array_values($rows));
    if (empty($rows)) {
        echo '<p class="small text-muted mb-0">ยังไม่มีผลวิเคราะห์ — กดดึงข้อมูลและสร้าง Dashboard</p>';
        return;
    }
    $safe_id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$id);
    echo '<div class="amass-viz" id="' . htmlspecialchars($safe_id) . '">';
    echo '<div class="d-flex flex-wrap gap-2 align-items-center mb-2">';
    echo '<div class="btn-group btn-group-sm" role="group">';
    echo '<button type="button" class="btn btn-success amass-viz-chart"><i class="fas fa-chart-bar me-1"></i>กราฟ</button>';
    echo '<button type="button" class="btn btn-outline-success amass-viz-table"><i class="fas fa-table me-1"></i>ตารางตัวเลข</button>';
    echo '</div>';
    echo '<span class="small text-muted">คลิกแท่งกราฟเพื่อดูตัวเลข</span>';
    echo '</div>';
    echo '<div class="amass-viz-orgs d-flex flex-wrap gap-1 mb-2"></div>';
    echo '<div class="amass-viz-detail d-none border rounded p-2 bg-white mb-2 small"></div>';
    echo '<div class="amass-viz-charts"></div>';
    echo '<div class="amass-viz-table-wrap d-none">';
    amass_render_table($rows, $cols);
    echo '</div>';
    echo '<script type="application/json" class="amass-viz-data">'
        . json_encode([
            'kind' => $kind,
            'compare_key' => $compare_key !== '' ? $compare_key : $kind,
            'rows' => array_values($rows),
        ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP)
        . '</script>';
    echo '</div>';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Dashboard AMASS — THAM Hos-Safe</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <style>
        .amass-hero {
            background: linear-gradient(135deg, #0f3d32 0%, #146c4a 55%, #0f766e 100%);
            color: #fff; border-radius: 16px; padding: 1.3rem 1.5rem; margin-bottom: 1.1rem;
        }
        .amass-hero h1 { font-size: 1.4rem; font-weight: 800; margin: 0; }
        .amass-hero .sub { opacity: .88; font-size: .9rem; margin-top: .35rem; }
        .amass-badge { background: rgba(255,255,255,.16); border-radius: 999px; padding: .2rem .7rem; font-size: .75rem; font-weight: 700; }
        .amass-card { background: #fff; border: 1px solid #d7e4dc; border-radius: 14px; padding: 1rem 1.1rem; height: 100%; }
        .amass-card h6 { font-weight: 800; margin: 0 0 .35rem; }
        .amass-card p { color: #5f7468; font-size: .82rem; margin: 0; }
        .amass-sec { font-size: .72rem; font-weight: 700; color: #0f766e; letter-spacing: .04em; text-transform: uppercase; }
        .ok-box { background: #f0faf5; border: 1px solid #9ad0b8; border-radius: 12px; padding: 1rem 1.1rem; }
        .wait-box { background: #fffbeb; border: 1px dashed #f59e0b; border-radius: 12px; padding: 1rem 1.1rem; }
        .file-ok { color: #146c4a; }
        .file-miss { color: #b45309; }
        .amass-kpi { font-size: 1.6rem; font-weight: 800; color: #1f4d3b; }
        .ov-chart { position: relative; height: 96px; margin-top: .45rem; }
        .ov-vals { margin-top: .45rem; }
        .ov-vals div { display: flex; justify-content: space-between; gap: 8px; font-size: .78rem; line-height: 1.45; }
        .ov-vals .ov-lab { color: #5f7468; }
        .ov-vals .ov-num { font-weight: 800; font-variant-numeric: tabular-nums; color: #12261c; }
        .amass-drop { border: 1px dashed #74b49b; border-radius: 10px; padding: .8rem; text-align: center; cursor: pointer; background: #f8fcfa; }
        .amass-drop.dragover { background: #e7f7ef; }
        .chk { font-size: .82rem; }
        .amass-table { font-size: .8rem; font-family: Helvetica, Arial, "Liberation Sans", sans-serif; }
        .amass-table th { white-space: nowrap; background: #d3d3d3; font-weight: 700; }
        .amass-table td.num { text-align: right; font-variant-numeric: tabular-nums; }
        .amass-table td.org { font-style: italic; font-weight: 700; }
        .amass-table tr.total td { font-weight: 700; font-style: normal; }
        .amass-table tr.total td.org, .amass-table td.total-label { font-style: normal; font-weight: 700; }
        .delta-up { color: #b91c1c; font-weight: 700; }
        .delta-down { color: #146c4a; font-weight: 700; }
        .delta-zero { color: #64748b; }
        .amass-tabs { border-bottom: 2px solid #d7e4dc; }
        .amass-tabs .nav-link {
            color: #4b6358; font-weight: 700; border: 0; border-bottom: 3px solid transparent;
            padding: .55rem 1rem; background: transparent;
        }
        .amass-tabs .nav-link:hover { color: #146c4a; }
        .amass-tabs .nav-link.active {
            color: #0f3d32; border-bottom-color: #146c4a; background: transparent;
        }
        .amass-chart-box { background: #f8fcfa; border: 1px solid #d7e4dc; border-radius: 12px; padding: .7rem .9rem .85rem; margin-bottom: .8rem; }
        .amass-chart-box h6 { font-size: .92rem; font-style: italic; font-weight: 700; font-family: Helvetica, Arial, sans-serif; margin: 0 0 .35rem; }
        .amass-chart-canvas { position: relative; width: 100%; }
        .compare-org-btn { border-radius: 999px; }
        .compare-org-btn.active { background: #146c4a; color: #fff; border-color: #146c4a; }
        #compareDetail .pair { font-weight: 800; color: #0f3d32; }
        #compareDetail .num { font-variant-numeric: tabular-nums; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-3">
            <div class="amass-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <span class="amass-badge">AMASS v<?php echo htmlspecialchars($pkg['version']); ?> · build <?php echo htmlspecialchars($pkg['build']); ?> · <?php echo htmlspecialchars($pkg['released']); ?></span>
                    <h1 class="mt-2">Dashboard AMASS</h1>
                    <div class="sub"><?php echo htmlspecialchars($hospital_name_th); ?> — รายงานเฝ้าระวังเชื้อดื้อยาตาม WHO GLASS (Sections 1–6)</div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-light btn-sm" id="btnHeroSettings">
                        <i class="fas fa-cog me-1"></i>ตั้งค่า
                    </button>
                    <a href="amr_amass_print.php" class="btn btn-outline-light btn-sm"><i class="fas fa-file-pdf me-1"></i>พิมพ์ PDF</a>
                </div>
            </div>

            <ul class="nav amass-tabs mb-3" id="amassPageTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="tab-dashboard-btn" data-bs-toggle="tab" data-bs-target="#tab-dashboard" type="button" role="tab">Dashboard</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="tab-settings-btn" data-bs-toggle="tab" data-bs-target="#tab-settings" type="button" role="tab">ตั้งค่า</button>
                </li>
            </ul>
            <div class="tab-content">
            <div class="tab-pane fade show active" id="tab-dashboard" role="tabpanel">

            <div class="row g-3 mb-3">
                <div class="col-lg-6">
                    <div class="ok-box h-100">
                        <div class="fw-bold mb-1"><i class="fas fa-check-circle me-1 text-success"></i>ชุดโปรแกรมบนเซิร์ฟเวอร์</div>
                        <div class="small text-muted mb-2">
                            ตรวจแล้วครบ <?php echo (int)$pkg['ok_count']; ?>/<?php echo (int)$pkg['total']; ?> รายการ
                            — วิเคราะห์ใน <?php echo htmlspecialchars($pkg['os']); ?>
                        </div>
                        <ul class="chk mb-0 ps-3">
                            <?php foreach ($pkg['items'] as $it): ?>
                            <li class="<?php echo !empty($it['exists']) ? 'file-ok' : 'file-miss'; ?>">
                                <?php echo !empty($it['exists']) ? '✓' : '✗'; ?>
                                <?php echo htmlspecialchars($it['label']); ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="<?php echo $kpis['has_results'] ? 'ok-box' : 'wait-box'; ?> h-100">
                        <div class="fw-bold mb-1">ดึงข้อมูลแล้วสร้าง Dashboard ในระบบ</div>
                        <div class="small mb-2">
                            Microbiology: <strong><?php echo htmlspecialchars($amass_micro_source_label); ?></strong>
                            · ยาและ admit จาก HOSxP
                            · <a href="amr_connect.php">เปลี่ยนแหล่งข้อมูล AMR</a>
                        </div>
                        <ol class="small mb-2 ps-3">
                            <li>เลือกช่วงวันที่ — ระบบดึงเป็นรายเดือนคู่ขนาน (สูงสุด 3 งาน) เพื่อไม่ให้ค้างเมื่อรันทั้งปี</li>
                            <li>รวมไฟล์ทั้งช่วง แล้ววิเคราะห์ตาม AMASS ทั้งช่วง (เดดูปทั้งช่วง ไม่เฉลี่ยรายเดือน)</li>
                            <li>ถ้าเปิดเปรียบเทียบช่วงเวลา ระบบจะดึงแต่ละปี/เดือนแยกกัน แล้วเทียบ %R แบบเดียวกับ Dashboard รายงาน</li>
                        </ol>
                        <div class="d-flex flex-wrap gap-2 align-items-end mb-2">
                            <div>
                                <label class="form-label small mb-1">ตั้งแต่</label>
                                <input type="date" id="amassStart" class="form-control form-control-sm" value="<?php echo htmlspecialchars($amass_start); ?>">
                            </div>
                            <div>
                                <label class="form-label small mb-1">ถึง</label>
                                <input type="date" id="amassEnd" class="form-control form-control-sm" value="<?php echo htmlspecialchars($amass_end); ?>">
                            </div>
                            <button type="button" class="btn btn-success btn-sm" id="btnAmassAll">
                                <i class="fas fa-play me-1"></i>ดึงข้อมูลและสร้าง Dashboard
                            </button>
                            <button type="button" class="btn btn-outline-success btn-sm" id="btnAmassAnalyze">วิเคราะห์ไฟล์ที่มีอยู่</button>
                        </div>
                        <div class="border rounded p-2 mt-2 mb-2 bg-light">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" id="enableCompare">
                                <label class="form-check-label small fw-bold" for="enableCompare">เปรียบเทียบช่วงเวลา</label>
                            </div>
                            <div id="comparePanel" class="d-none">
                                <div class="row g-2 align-items-end">
                                    <div class="col-md-4">
                                        <label class="form-label small mb-1">โหมดเปรียบเทียบ</label>
                                        <select id="compareMode" class="form-select form-select-sm">
                                            <option value="prev_year">ช่วงเดียวกันปีก่อน</option>
                                            <option value="year" selected>เทียบเป็นปี</option>
                                            <option value="month">เทียบเป็นเดือน</option>
                                            <option value="custom">กำหนดช่วงเอง</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3 compare-year d-none">
                                        <label class="form-label small mb-1">จำนวนปีที่เทียบ</label>
                                        <select id="compareYearCount" class="form-select form-select-sm">
                                            <option value="1">1 ปี</option>
                                            <option value="2">2 ปี</option>
                                            <option value="3" selected>3 ปี</option>
                                        </select>
                                    </div>
                                    <?php for ($slot = 1; $slot <= 3; $slot++): ?>
                                    <div class="col-md-3 compare-year compare-year-pick d-none" data-slot="<?php echo $slot; ?>">
                                        <label class="form-label small mb-1">ปีที่ <?php echo $slot; ?></label>
                                        <select id="compareYear<?php echo $slot; ?>" class="form-select form-select-sm">
                                            <?php foreach ($compare_year_options as $y): ?>
                                            <option value="<?php echo (int)$y; ?>"<?php echo $y === ($default_compare_year - ($slot - 1)) ? ' selected' : ''; ?>><?php echo (int)$y; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <?php endfor; ?>
                                    <div class="col-md-3 compare-month d-none">
                                        <label class="form-label small mb-1">จำนวนเดือนที่เทียบ</label>
                                        <select id="compareMonthCount" class="form-select form-select-sm">
                                            <option value="1">1 เดือน</option>
                                            <option value="2">2 เดือน</option>
                                            <option value="3">3 เดือน</option>
                                        </select>
                                    </div>
                                    <?php for ($slot = 1; $slot <= 3; $slot++): ?>
                                    <div class="col-md-3 compare-month compare-month-pick d-none" data-slot="<?php echo $slot; ?>">
                                        <label class="form-label small mb-1">เดือนที่ <?php echo $slot; ?></label>
                                        <input type="month" id="compareMonth<?php echo $slot; ?>" class="form-control form-control-sm"
                                            value="<?php echo htmlspecialchars($default_compare_months[$slot] ?? date('Y-m')); ?>">
                                    </div>
                                    <?php endfor; ?>
                                    <div class="col-md-4 compare-custom d-none">
                                        <label class="form-label small mb-1">เปรียบเทียบ ตั้งแต่</label>
                                        <input type="date" id="compareStart" class="form-control form-control-sm" value="<?php echo htmlspecialchars(date('Y', strtotime('-1 year')) . '-01-01'); ?>">
                                    </div>
                                    <div class="col-md-4 compare-custom d-none">
                                        <label class="form-label small mb-1">เปรียบเทียบ ถึง</label>
                                        <input type="date" id="compareEnd" class="form-control form-control-sm" value="<?php echo htmlspecialchars(date('Y-m-d', strtotime('-1 year'))); ?>">
                                    </div>
                                </div>
                                <div class="small text-muted mt-2">เปิดช่องนี้แล้วกดดึงข้อมูล — ระบบจะดึงแต่ละช่วงเป็นรายเดือนคู่ขนาน แล้วเทียบ %R (ช่วงแรกเป็นฐาน ค่าต่างเป็นจุดเปอร์เซ็นต์)</div>
                            </div>
                        </div>
                        <div class="progress mb-2 d-none" id="amassProgressWrap" style="height:8px">
                            <div class="progress-bar bg-success" id="amassProgress" role="progressbar" style="width:0%"></div>
                        </div>
                        <div id="amassExportStatus" class="small text-muted mb-2">ช่วง 1 ปีจะดึงเป็นรายเดือนคู่ขนาน แล้วรวมก่อนวิเคราะห์ทั้งช่วง</div>
                        <div class="small mb-2">ไฟล์ข้อมูลชุดรัน: <strong id="stagedCount"><?php echo (int)$have_data; ?>/3</strong>
                            <span class="text-muted" id="stagedRangeHint"></span>
                        </div>
                        <ul class="small mb-2" id="stagedList">
                            <?php foreach ($staged as $key => $s): ?>
                            <li id="stage-<?php echo htmlspecialchars($key); ?>" class="<?php echo !empty($s['exists']) ? 'file-ok' : 'file-miss'; ?>">
                                <?php echo htmlspecialchars($s['filename']); ?>
                                — <?php echo !empty($s['exists']) ? ('มีไฟล์' . ($s['source'] ? ' (' . $s['source'] . ')' : '')) : 'ยังไม่มี'; ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="d-flex flex-wrap gap-2 mb-2">
                            <button type="button" class="btn btn-outline-success btn-sm amass-export-btn" data-dataset="drug" title="ส่งออกตามช่วงวันที่ที่เลือก">
                                <i class="fas fa-download me-1"></i>drug_data.xlsx
                            </button>
                            <button type="button" class="btn btn-outline-success btn-sm amass-export-btn" data-dataset="admission">
                                <i class="fas fa-download me-1"></i>hospital_admission_data.xlsx
                            </button>
                            <button type="button" class="btn btn-outline-success btn-sm amass-export-btn" data-dataset="microbiology">
                                <i class="fas fa-download me-1"></i>microbiology_data.xlsx
                            </button>
                            <button type="button" class="btn btn-success btn-sm" id="btnAmassExportZip">
                                <i class="fas fa-file-archive me-1"></i>ส่งออกทั้ง 3 ไฟล์ (.zip)
                            </button>
                        </div>
                        <div class="small text-muted mb-2">ส่งออกตามช่อง «ตั้งแต่–ถึง» ด้านบน — ถ้าไฟล์ชุดรันยังไม่ตรงช่วง ระบบจะดึง microbiology จากแหล่งที่ตั้งค่า (HOSxP หรือ mLAB) และดึงยา/admit จาก HOSxP ก่อนแล้วค่อยดาวน์โหลด</div>
                        <div class="amass-drop" id="resultDrop">
                            <div class="fw-bold small">วาง ResultData (.zip / .pdf / .csv)</div>
                            <div class="text-muted" style="font-size:.75rem" id="resultDropHint">
                                <?php echo $kpis['has_results'] ? ('มีผลรันแล้ว · CSV ' . (int)$kpis['csv_count'] . ' ไฟล์') : 'ยังไม่มีผลรันของโรงพยาบาล'; ?>
                            </div>
                            <input type="file" id="resultFile" class="d-none" accept=".zip,.pdf,.csv,.xlsx">
                        </div>
                    </div>
                </div>
            </div>

            <h6 class="fw-bold mb-2">รายงานจากข้อมูลโรงพยาบาล</h6>
            <div class="d-flex flex-wrap gap-2 mb-3">
                <?php if (!empty($has_report)): ?>
                    <?php foreach ($report_links as $ex): ?>
                    <a class="btn btn-success btn-sm" href="<?php echo htmlspecialchars($ex[0]); ?>" target="_blank">
                        <i class="fas fa-file-alt me-1"></i><?php echo htmlspecialchars($ex[1]); ?>
                        <span class="opacity-75">· <?php echo htmlspecialchars($ex[2]); ?></span>
                    </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <span class="small text-muted">ยังไม่มีรายงาน — กดดึงข้อมูลและสร้าง Dashboard ก่อน</span>
                <?php endif; ?>
            </div>

            <h6 class="fw-bold mb-2" id="amassOverviewTitle">Overview</h6>
            <div class="row g-3 mb-3" id="amassOverview">
                <?php
                $sec1 = $kpis['micro_n'] !== '' ? number_format((float)$kpis['micro_n']) : '–';
                $sec1sub = $kpis['date_min'] !== '' ? ($kpis['date_min'] . ' – ' . $kpis['date_max']) : 'รอวิเคราะห์';
                $dedup_n = isset($meta['blood_priority_dedup']) ? number_format((float)$meta['blood_priority_dedup']) : '–';
                $adm_n = $kpis['adm_n'] !== '' ? number_format((float)$kpis['adm_n']) : '–';
                $pdays = $kpis['patient_days'] !== '' ? number_format((float)$kpis['patient_days']) : '–';
                $sec2n = !empty($tables['section2']) ? count($tables['section2']) . ' คู่เชื้อ-ยา' : '–';
                $sections = [
                    ['1', 'Data overview', 'ภาพรวม microbiology / admit / ช่วงวันที่', $sec1, $sec1sub],
                    ['2', 'AMR proportion report', 'สัดส่วน %R จากเลือด เดดูปเชื้อแรกต่อผู้ป่วย', $dedup_n, $kpis['has_results'] ? $sec2n : 'รอวิเคราะห์'],
                    ['3', 'AMR proportion by origin', 'สัดส่วน %R แยก Community vs Hospital origin', $adm_n, $kpis['has_results'] ? 'ดูตารางด้านล่าง' : 'รอวิเคราะห์'],
                    ['4', 'AMR frequency report', 'ความถี่ต่อ 100,000 ผู้ป่วยที่เจาะเลือดเพาะเชื้อ', $adm_n, $kpis['has_results'] ? 'per 100,000 tested' : 'รอวิเคราะห์'],
                    ['5', 'AMR frequency by origin', 'ความถี่ต่อ 100,000 tested แยกตาม origin', $pdays, $kpis['patient_days'] !== '' ? 'patient-days / tested' : 'รอวิเคราะห์'],
                    ['6', 'Mortality involving AMR', 'เสียชีวิตในผู้ป่วย BSI เชื้อเฝ้าระวัง แยกตาม origin', $dedup_n, $kpis['has_results'] ? 'ดูตารางด้านล่าง' : 'รอวิเคราะห์'],
                ];
                foreach ($sections as $sec):
                ?>
                <div class="col-md-6 col-xl-4">
                    <div class="amass-card">
                        <div class="amass-sec">Section <?php echo $sec[0]; ?></div>
                        <h6><?php echo htmlspecialchars($sec[1]); ?></h6>
                        <p><?php echo htmlspecialchars($sec[2]); ?></p>
                        <div class="amass-kpi mt-2"><?php echo htmlspecialchars($sec[3]); ?></div>
                        <div class="small text-muted"><?php echo htmlspecialchars($sec[4]); ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <h6 class="fw-bold mb-2">รายงานหลัก (Sections 1–6)</h6>
            <div class="amass-card mb-3">
                <div class="amass-sec">เปรียบเทียบรายการ</div>
                <h6>Section 2 %R ตามช่วงที่ดึง</h6>
                <p class="mb-2">เปิด «เปรียบเทียบช่วงเวลา» ด้านบน แล้วกดดึงข้อมูล — กราฟนี้แสดง %R ของแต่ละช่วง สีเดียวกันใช้กับกราฟ Annex B/C/D และ Section อื่นด้านล่างด้วย คลิกแท่งกราฟเพื่อดูตัวเลข</p>
                <div id="compareSummary" class="row g-2 mb-2"></div>
                <div id="compareToolbar" class="d-none d-flex flex-wrap gap-2 align-items-center mb-2">
                    <div class="btn-group btn-group-sm" role="group" aria-label="มุมมองเปรียบเทียบ">
                        <button type="button" class="btn btn-success" id="compareViewChart"><i class="fas fa-chart-bar me-1"></i>กราฟ</button>
                        <button type="button" class="btn btn-outline-success" id="compareViewTable"><i class="fas fa-table me-1"></i>ตารางตัวเลข</button>
                    </div>
                    <span class="small text-muted">คลิกแท่งกราฟเพื่อดู R/n และ %R</span>
                </div>
                <div id="compareOrgs" class="d-none d-flex flex-wrap gap-1 mb-2"></div>
                <div id="compareDetail" class="d-none border rounded p-2 bg-white mb-2 small"></div>
                <div id="compareCharts" class="d-none"></div>
                <div id="compareResult"></div>
            </div>
            <?php if (!empty($meta)): ?>
            <p class="small text-muted mb-3">วิเคราะห์ล่าสุด <?php echo htmlspecialchars($meta['ran_at'] ?? ''); ?>
                · เลือดเดดูป <?php echo (int)($meta['blood_priority_dedup'] ?? 0); ?> isolate
                · %R = isolate ที่ผล R / ที่ตรวจยา ตาม AMASS v4.0
                · Annex B/D คำนวณใน PHP · Annex C เป็น Poisson ward-week (ไม่ใช่ SaTScan)</p>
            <?php endif; ?>

            <div class="amass-card mb-3">
                <div class="amass-sec">Section 2</div>
                <h6>AMR proportion report (blood, first isolate per patient)</h6>
                <?php amass_render_viz('viz-sec2', 'pct', $tables['section2'] ?? [], [
                    'Organism' => 'เชื้อ',
                    'Antibiotic' => 'ยา',
                    'Non-susceptible(N)' => 'R (n)',
                    'Total(N)' => 'ตรวจ (n)',
                    'Non-susceptible(%)' => '%R',
                    'lower95CI(%)*' => '95% CI ล่าง',
                    'upper95CI(%)*' => '95% CI บน',
                ], 'section2'); ?>
            </div>
            <div class="amass-card mb-3">
                <div class="amass-sec">Section 3</div>
                <h6>AMR proportion report with stratification by infection origin</h6>
                <?php amass_render_viz('viz-sec3', 'pct_origin', $tables['section3'] ?? [], [
                    'Organism' => 'เชื้อ',
                    'Antibiotic' => 'ยา',
                    'Infection_origin' => 'Origin',
                    'Non-susceptible(N)' => 'R (n)',
                    'Total(N)' => 'ตรวจ (n)',
                    'Non-susceptible(%)' => '%R',
                    'lower95CI(%)*' => '95% CI ล่าง',
                    'upper95CI(%)*' => '95% CI บน',
                ], 'section3'); ?>
            </div>
            <div class="row g-3 mb-3">
                <div class="col-lg-6">
                    <div class="amass-card">
                        <div class="amass-sec">Section 4</div>
                        <h6>AMR frequency report (per 100,000 tested)</h6>
                        <?php
                        if (!empty($tables['section4freq'])) {
                            amass_render_viz('viz-sec4', 'freq', $tables['section4freq'], [
                                'Organism' => 'เชื้อ',
                                'Number_of_patients' => 'ผู้ป่วย',
                                'frequency_per_tested' => 'ต่อ แสน tested',
                            ], 'section4freq');
                        } else {
                            echo '<p class="small text-muted mb-0">รันวิเคราะห์อีกครั้งเพื่อความถี่ต่อ 100,000 tested — ตาราง mortality อยู่ Section 6</p>';
                        }
                        ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="amass-card">
                        <div class="amass-sec">Section 6</div>
                        <h6>Mortality involving AMR (by origin)</h6>
                        <?php amass_render_viz('viz-sec6', 'mort_origin', $tables['section6'] ?? [], [
                            'Organism' => 'เชื้อ',
                            'Infection_origin' => 'Origin',
                            'Number_of_deaths' => 'เสียชีวิต',
                            'Total_number_of_patients' => 'ผู้ป่วย',
                            'Mortality(%)' => '%',
                        ], 'section6'); ?>
                    </div>
                </div>
            </div>
            <div class="row g-3 mb-3">
                <div class="col-lg-6">
                    <div class="amass-card">
                        <div class="amass-sec">Section 5</div>
                        <h6>AMR frequency — community-origin (per 100,000 tested)</h6>
                        <?php
                        if (!empty($tables['section5c_freq'])) {
                            amass_render_viz('viz-sec5c', 'freq', $tables['section5c_freq'], [
                                'Organism' => 'เชื้อ',
                                'Number_of_patients' => 'ผู้ป่วย',
                                'frequency_per_tested' => 'ต่อ แสน tested',
                            ], 'section5c_freq');
                        } else {
                            amass_render_viz('viz-sec5c', 'freq', $tables['section5c'] ?? [], [
                                'Organism' => 'เชื้อ',
                                'Number_of_patients' => 'ผู้ป่วย',
                                'Incidence_per_100000_patient_days' => 'ต่อ แสน pt-days',
                            ], 'section5c');
                        }
                        ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="amass-card">
                        <div class="amass-sec">Section 5</div>
                        <h6>AMR frequency — hospital-origin (per 100,000 tested)</h6>
                        <?php
                        if (!empty($tables['section5h_freq'])) {
                            amass_render_viz('viz-sec5h', 'freq', $tables['section5h_freq'], [
                                'Organism' => 'เชื้อ',
                                'Number_of_patients' => 'ผู้ป่วย',
                                'frequency_per_tested' => 'ต่อ แสน tested',
                            ], 'section5h_freq');
                        } else {
                            amass_render_viz('viz-sec5h', 'freq', $tables['section5h'] ?? [], [
                                'Organism' => 'เชื้อ',
                                'Number_of_patients' => 'ผู้ป่วย',
                                'Incidence_per_100000_patient_days' => 'ต่อ แสน pt-days',
                            ], 'section5h');
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="amass-card mb-4">
                <div class="amass-sec">Annex B</div>
                <h6>Data indicators — ปนเปื้อนเลือด / AMR ที่ต้องรายงาน / AST ที่ผิดปกติ</h6>
                <?php amass_render_viz('viz-annexb', 'annex_b', $tables['annex_b'] ?? [], [
                    'Description' => 'ตัวชี้วัด',
                    'Number' => 'จำนวน',
                    'Denominator' => 'ตัวหาร',
                    'Proportion' => 'สัดส่วน',
                ]); ?>
                <?php if (!empty($tables['annex_b_month'])): ?>
                <h6 class="mt-3">รายเดือน</h6>
                <?php amass_render_viz('viz-annexb-month', 'annex_b_month', $tables['annex_b_month'], [
                    'Month' => 'เดือน',
                    'blood_culture_contamination_rate' => 'ปนเปื้อน',
                    'notifiable_antibiotic_pathogen' => 'AMR ที่ต้องรายงาน',
                    'potential_AST_errors' => 'AST ผิดปกติ',
                    'Total_blood_positive_and_negative(N)' => 'เลือด (n)',
                    'Total_blood_positive_AST(N)' => 'มี AST (n)',
                ]); ?>
                <?php endif; ?>
                <?php if (!empty($tables['annex_b_cont'])): ?>
                <h6 class="mt-3">เชื้อที่เป็นไปได้ว่าปนเปื้อน</h6>
                <?php amass_render_viz('viz-annexb-cont', 'annex_b_cont', $tables['annex_b_cont'], [
                    'Organism' => 'เชื้อ',
                    'Number_of_possible_contaminants' => 'จำนวน',
                    'Percent_of_contaminants' => '% ของปนเปื้อน',
                ]); ?>
                <?php endif; ?>
            </div>
            <div class="amass-card mb-4">
                <div class="amass-sec">Annex C</div>
                <h6>Cluster signals — Poisson ward-week (ไม่ใช่ SaTScan)</h6>
                <?php if (empty($tables['annex_c'])): ?>
                <p class="small text-muted">ไม่พบสัญญาณ cluster ในช่วงนี้ — กราฟด้านล่างคือ isolate ดื้อยา origin โรงพยาบาลตามวอร์ด</p>
                <?php else: amass_render_table($tables['annex_c'], [
                    'AMR_pathogen' => 'AMR',
                    'Ward' => 'วอร์ด',
                    'Week' => 'สัปดาห์',
                    'observed_cases' => 'พบ',
                    'expected_cases' => 'คาด',
                    'observed_expected_ratio' => 'O/E',
                    'p_value' => 'p',
                ]); endif; ?>
                <?php if (!empty($tables['annex_c_ward'])): ?>
                <h6 class="mt-3">Hospital-origin AMR ตามวอร์ด</h6>
                <?php amass_render_viz('viz-annexc-ward', 'annex_c_ward', $tables['annex_c_ward'], [
                    'AMR_pathogen' => 'AMR',
                    'Organism' => 'เชื้อ',
                    'Ward' => 'วอร์ด',
                    'Hospital_origin_isolates' => 'isolate',
                ]); ?>
                <?php endif; ?>
            </div>
            <div class="amass-card mb-4">
                <div class="amass-sec">Annex D</div>
                <h6>Antimicrobial use — DOT / LOT / AWaRe จาก drug_data</h6>
                <?php if (!empty($tables['annex_d_summary'])): ?>
                <div id="annexDSummaryWrap">
                <?php amass_render_table($tables['annex_d_summary'], [
                    'Parameter' => 'ตัวชี้วัด',
                    'Value' => 'ค่า',
                ]); ?>
                </div>
                <?php endif; ?>
                <?php if (!empty($tables['annex_d_dot'])): ?>
                <h6 class="mt-3">DOT ยาฉีด (parenteral)</h6>
                <?php amass_render_viz('viz-annexd-dot', 'annex_d_dot', $tables['annex_d_dot'], [
                    'RANK' => 'อันดับ',
                    'Antibiotic' => 'ยา',
                    'AWaRe_classification' => 'AWaRe',
                    'DOT' => 'DOT',
                    'DOT_percent_text' => '% DOT',
                    'DOT_per1000patient_days' => 'ต่อพัน pt-days',
                ]); ?>
                <?php endif; ?>
                <?php if (!empty($tables['annex_d_aware'])): ?>
                <h6 class="mt-3">DOT ตาม AWaRe</h6>
                <?php amass_render_viz('viz-annexd-aware', 'annex_d_aware', $tables['annex_d_aware'], [
                    'AWaRe_classification' => 'AWaRe',
                    'DOT' => 'DOT',
                    'DOT_percent_text' => '% DOT',
                    'DOT_per1000patient_days' => 'ต่อพัน pt-days',
                ]); ?>
                <?php endif; ?>
                <?php if (!empty($tables['annex_d_dept'])): ?>
                <h6 class="mt-3">DOT ตามแผนก</h6>
                <?php amass_render_viz('viz-annexd-dept', 'annex_d_dept', $tables['annex_d_dept'], [
                    'Department' => 'แผนก',
                    'DOT' => 'DOT',
                    'DOT_percent_text' => '% DOT',
                    'DOT_per1000patient_days' => 'ต่อพัน pt-days',
                ]); ?>
                <?php endif; ?>
                <?php if (!empty($tables['annex_d_month'])): ?>
                <h6 class="mt-3">AMU รายเดือน</h6>
                <?php amass_render_viz('viz-annexd-month', 'annex_d_month', $tables['annex_d_month'], [
                    'Month' => 'เดือน',
                    'Number_of_drug_records' => 'รายการยา',
                    'Number_of_antibiotic_records' => 'ยาปฏิชีวนะ',
                    'Number_of_antifungal_records' => 'ยาต้านเชื้อรา',
                ]); ?>
                <?php endif; ?>
                <?php if (!empty($tables['annex_d_route'])): ?>
                <h6 class="mt-3">AMU ตามเส้นทางยา</h6>
                <?php amass_render_viz('viz-annexd-route', 'annex_d_route', $tables['annex_d_route'], [
                    'Route_of_administration' => 'เส้นทาง',
                    'Number_of_antibiotic_records' => 'ยาปฏิชีวนะ',
                    'Number_of_antifungal_records' => 'ยาต้านเชื้อรา',
                ]); ?>
                <?php endif; ?>
                <h6 class="mt-3">ยาที่สั่งบ่อย</h6>
                <?php amass_render_viz('viz-annexd', 'amu', $tables['amu'] ?? [], [
                    'drug_name' => 'ยา',
                    'prescriptions' => 'ใบสั่ง',
                ]); ?>
            </div>

            <h6 class="fw-bold mb-2">ภาคผนวก (Annexes A–F)</h6>
            <div class="row g-3 mb-4">
                <?php
                $annex = [
                    ['A', 'Notifiable bacterial infections', 'รายงานโรคติดเชื้อแบคทีเรียที่ต้องเฝ้าระวัง', ''],
                    ['B', 'Data indicators', 'ปนเปื้อนเลือด / AMR ที่ต้องรายงาน / AST ผิดปกติ — คำนวณในระบบแล้ว', 'example_annex_b'],
                    ['C', 'Cluster signals', 'Poisson ward-week ของ MRSA/VRE/CRE/CRAB/CRPA (ไม่ใช่ SaTScan)', 'example_annex_c'],
                    ['D', 'Antimicrobial use (AMU)', 'DOT, LOT, AWaRe, เส้นทางยา และแผนก จาก drug_data', 'example_annex_d'],
                    ['E', 'Epidemiology of BSI', 'ระบาดวิทยาติดเชื้อในกระแสเลือด', ''],
                    ['F', 'AMASS-FUNGI', 'เชื้อราในเลือด และการใช้ยาต้านเชื้อรา', ''],
                ];
                foreach ($annex as $a):
                ?>
                <div class="col-md-6 col-xl-4">
                    <div class="amass-card">
                        <div class="amass-sec">Annex <?php echo $a[0]; ?></div>
                        <h6><?php echo htmlspecialchars($a[1]); ?></h6>
                        <p><?php echo htmlspecialchars($a[2]); ?></p>
                        <?php if ($a[3] !== ''): ?>
                        <a class="small" href="amr_amass_file.php?key=<?php echo urlencode($a[3]); ?>" target="_blank">เปิดตัวอย่าง PDF</a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            </div>

            <div class="tab-pane fade" id="tab-settings" role="tabpanel">
            <div class="amass-card mb-3">
                <div class="amass-sec">AMASS dictionary · SECTION_05</div>
                <h6>ข้อมูลปกและผู้ติดต่อในรายงาน</h6>
                <p class="mb-3">ค่าเหล่านี้ไปที่หน้าปก PDF ตามรูปแบบ AMASS (country, hospital_name, contact_person, contact_address, contact_email, notes_on_the_cover)</p>
                <div class="row g-2">
                    <div class="col-md-8">
                        <label class="form-label small mb-1">hospital_name (ชื่อในรายงานภาษาอังกฤษ)</label>
                        <input type="text" id="cover_hospital_name" class="form-control form-control-sm"
                            value="<?php echo htmlspecialchars($cover['hospital_name']); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small mb-1">country</label>
                        <input type="text" id="cover_country" class="form-control form-control-sm"
                            value="<?php echo htmlspecialchars($cover['country']); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small mb-1">ชื่อแสดงในระบบ (ไทย)</label>
                        <input type="text" id="cover_hospital_name_th" class="form-control form-control-sm"
                            value="<?php echo htmlspecialchars($cover['hospital_name_th']); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small mb-1">contact_person</label>
                        <input type="text" id="cover_contact_person" class="form-control form-control-sm"
                            value="<?php echo htmlspecialchars($cover['contact_person']); ?>">
                    </div>
                    <div class="col-md-8">
                        <label class="form-label small mb-1">contact_address</label>
                        <input type="text" id="cover_contact_address" class="form-control form-control-sm"
                            value="<?php echo htmlspecialchars($cover['contact_address']); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small mb-1">contact_email</label>
                        <input type="email" id="cover_contact_email" class="form-control form-control-sm"
                            value="<?php echo htmlspecialchars($cover['contact_email']); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small mb-1">notes_on_the_cover</label>
                        <input type="text" id="cover_notes" class="form-control form-control-sm"
                            value="<?php echo htmlspecialchars($cover['notes_on_the_cover']); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small mb-1">notes_on_fungal_identification (Annex F)</label>
                        <input type="text" id="cover_fungal" class="form-control form-control-sm"
                            value="<?php echo htmlspecialchars($cover['notes_on_fungal_identification']); ?>">
                    </div>
                </div>
                <div class="mt-3">
                    <button type="button" class="btn btn-success btn-sm" id="btnSaveHospital">
                        <i class="fas fa-save me-1"></i>บันทึกข้อมูลปก
                    </button>
                    <a href="amr_amass_print.php" class="btn btn-outline-success btn-sm ms-1" target="_blank">ดูหน้าปก PDF</a>
                    <a href="amr_settings.php" class="btn btn-outline-secondary btn-sm ms-1">ตั้งค่า Dictionary</a>
                </div>
            </div>
            </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/chart.min.js"></script>
<script src="https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"></script>
<script src="js/amr_amass_export.js"></script>
<script src="js/amr_amass_viz.js?v=compare-annex-1"></script>
<script>
(function() {
    if (window.AmassViz) {
        AmassViz.mountAll();
    }
    const settingsBtn = document.getElementById('tab-settings-btn');
    const heroSettings = document.getElementById('btnHeroSettings');
    if (heroSettings && settingsBtn) {
        heroSettings.addEventListener('click', function() { settingsBtn.click(); });
    }
    if (location.hash === '#settings' && settingsBtn) {
        settingsBtn.click();
    }

    const zone = document.getElementById('resultDrop');
    const input = document.getElementById('resultFile');
    const hint = document.getElementById('resultDropHint');
    const statusEl = document.getElementById('amassExportStatus');
    const btnAll = document.getElementById('btnAmassAll');
    const btnAnalyze = document.getElementById('btnAmassAnalyze');
    const btnExportZip = document.getElementById('btnAmassExportZip');
    const exportBtns = Array.prototype.slice.call(document.querySelectorAll('.amass-export-btn'));
    const progressWrap = document.getElementById('amassProgressWrap');
    const progressBar = document.getElementById('amassProgress');
    let lastStaged = <?php echo json_encode($staged, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?>;
    const EXPORT_SETS = {
        drug: { dataset: 'drug', filename: 'drug_data.xlsx', label: 'ยา' },
        admission: { dataset: 'admission', filename: 'hospital_admission_data.xlsx', label: 'admit' },
        microbiology: { dataset: 'microbiology', filename: 'microbiology_data.xlsx', label: 'เพาะเชื้อ' }
    };

    function setStatus(msg, isError) {
        if (!statusEl) return;
        statusEl.className = 'small mb-2 ' + (isError ? 'text-danger' : 'text-muted');
        statusEl.textContent = msg;
    }

    function setProgress(pct) {
        if (!progressWrap || !progressBar) return;
        const n = Math.max(0, Math.min(100, Number(pct) || 0));
        progressWrap.classList.toggle('d-none', n <= 0);
        progressBar.style.width = n + '%';
    }

    function setBusy(busy) {
        if (btnAll) btnAll.disabled = busy;
        if (btnAnalyze) btnAnalyze.disabled = busy;
        if (btnExportZip) btnExportZip.disabled = busy;
        exportBtns.forEach(function (b) { b.disabled = busy; });
    }

    function isoFromDate(d) {
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return y + '-' + m + '-' + day;
    }

    function shiftYear(iso, dy) {
        const d = new Date(iso + 'T00:00:00');
        d.setFullYear(d.getFullYear() + dy);
        return isoFromDate(d);
    }

    function monthEnd(ym) {
        const p = String(ym || '').split('-');
        const y = parseInt(p[0], 10);
        const m = parseInt(p[1], 10);
        if (!y || !m) return '';
        return isoFromDate(new Date(y, m, 0));
    }

    function toggleComparePanel() {
        const on = !!(document.getElementById('enableCompare') || {}).checked;
        const panel = document.getElementById('comparePanel');
        if (panel) panel.classList.toggle('d-none', !on);
        const mode = (document.getElementById('compareMode') || {}).value || 'year';
        document.querySelectorAll('.compare-custom').forEach(function(el) {
            el.classList.toggle('d-none', !(on && mode === 'custom'));
        });
        document.querySelectorAll('.compare-year').forEach(function(el) {
            el.classList.toggle('d-none', !(on && mode === 'year'));
        });
        document.querySelectorAll('.compare-month').forEach(function(el) {
            el.classList.toggle('d-none', !(on && mode === 'month'));
        });
        if (on && mode === 'year') toggleCompareYearPickers();
        if (on && mode === 'month') toggleCompareMonthPickers();
        if (btnAll) {
            btnAll.innerHTML = on
                ? '<i class="fas fa-play me-1"></i>ดึงและเปรียบเทียบ'
                : '<i class="fas fa-play me-1"></i>ดึงข้อมูลและสร้าง Dashboard';
        }
    }

    function toggleCompareYearPickers() {
        const n = parseInt((document.getElementById('compareYearCount') || {}).value, 10) || 1;
        document.querySelectorAll('.compare-year-pick').forEach(function(el) {
            const slot = parseInt(el.getAttribute('data-slot'), 10);
            el.style.display = slot <= n ? '' : 'none';
        });
    }

    function toggleCompareMonthPickers() {
        const n = parseInt((document.getElementById('compareMonthCount') || {}).value, 10) || 1;
        document.querySelectorAll('.compare-month-pick').forEach(function(el) {
            const slot = parseInt(el.getAttribute('data-slot'), 10);
            el.style.display = slot <= n ? '' : 'none';
        });
    }

    function resolveComparePeriods(mainStart, mainEnd) {
        const on = !!(document.getElementById('enableCompare') || {}).checked;
        if (!on) {
            return [{ start: mainStart, end: mainEnd, label: mainStart + ' ถึง ' + mainEnd }];
        }
        const mode = (document.getElementById('compareMode') || {}).value || 'year';
        const today = isoFromDate(new Date());
        if (mode === 'year') {
            const n = parseInt((document.getElementById('compareYearCount') || {}).value, 10) || 1;
            const thisY = new Date().getFullYear();
            const out = [];
            const seen = {};
            for (let i = 1; i <= n; i++) {
                const y = (document.getElementById('compareYear' + i) || {}).value;
                if (!y || seen[y]) continue;
                seen[y] = true;
                const yi = parseInt(y, 10);
                out.push({
                    start: y + '-01-01',
                    end: yi === thisY ? today : (y + '-12-31'),
                    label: 'ปี ' + y
                });
            }
            return out;
        }
        if (mode === 'month') {
            const n = parseInt((document.getElementById('compareMonthCount') || {}).value, 10) || 1;
            const out = [];
            const seen = {};
            for (let i = 1; i <= n; i++) {
                const ym = (document.getElementById('compareMonth' + i) || {}).value;
                if (!ym || seen[ym]) continue;
                seen[ym] = true;
                const end = monthEnd(ym);
                out.push({ start: ym + '-01', end: end, label: ym });
            }
            return out;
        }
        if (mode === 'custom') {
            const cs = (document.getElementById('compareStart') || {}).value || '';
            const ce = (document.getElementById('compareEnd') || {}).value || '';
            if (!cs || !ce) throw new Error('กรุณาเลือกช่วงเปรียบเทียบ');
            return [
                { start: mainStart, end: mainEnd, label: 'ช่วง A' },
                { start: cs, end: ce, label: 'ช่วง B' }
            ];
        }
        return [
            { start: mainStart, end: mainEnd, label: 'ช่วงนี้' },
            { start: shiftYear(mainStart, -1), end: shiftYear(mainEnd, -1), label: 'ปีก่อน' }
        ];
    }

    const enableCompare = document.getElementById('enableCompare');
    const compareMode = document.getElementById('compareMode');
    const compareYearCount = document.getElementById('compareYearCount');
    const compareMonthCount = document.getElementById('compareMonthCount');
    if (enableCompare) enableCompare.addEventListener('change', toggleComparePanel);
    if (compareMode) compareMode.addEventListener('change', toggleComparePanel);
    if (compareYearCount) compareYearCount.addEventListener('change', toggleCompareYearPickers);
    if (compareMonthCount) compareMonthCount.addEventListener('change', toggleCompareMonthPickers);
    toggleComparePanel();

    const COMPARE_COLORS = ['#0d9488', '#f59e0b', '#6366f1', '#ef4444'];
    const compareState = { data: null, view: 'chart', org: '' };
    let compareChartObjs = [];
    let overviewChartObjs = [];

    function destroyOverviewCharts() {
        overviewChartObjs.forEach(function(ch) {
            try { ch.destroy(); } catch (e) {}
        });
        overviewChartObjs = [];
    }

    function fmtOverviewN(v) {
        if (v === '' || v == null || isNaN(Number(v))) return '–';
        return Number(v).toLocaleString('en-US', { maximumFractionDigits: 0 });
    }

    function renderOverviewCompare(res) {
        const host = document.getElementById('amassOverview');
        const title = document.getElementById('amassOverviewTitle');
        const periods = (res && res.overview_periods) || [];
        if (!host || periods.length < 2 || typeof Chart === 'undefined') return;
        destroyOverviewCharts();
        const labels = periods.map(function(p) { return p.label || ''; });
        if (title) {
            title.textContent = 'Overview · เปรียบเทียบ ' + labels.join(' · ');
        }
        const specs = [
            { id: '1', title: 'Data overview', desc: 'จำนวนรายการ microbiology แต่ละช่วง', key: 'micro', extra: function(p) { return (p.date_min || '') + (p.date_max ? (' – ' + p.date_max) : ''); } },
            { id: '2', title: 'AMR proportion report', desc: 'เลือดเดดูป (first isolate) และคู่เชื้อ-ยา', key: 'dedup', extra: function(p) { return (p.pairs || 0) + ' คู่เชื้อ-ยา'; } },
            { id: '3', title: 'AMR proportion by origin', desc: 'BSI Community vs Hospital origin', stacked: true, keys: ['com_bsi', 'hos_bsi'], names: ['Community', 'Hospital'] },
            { id: '4', title: 'AMR frequency report', desc: 'ผู้ป่วยที่เจาะเลือดเพาะเชื้อ (tested)', key: 'tested', extra: function(p) { return 'admit ' + fmtOverviewN(p.admit); } },
            { id: '5', title: 'AMR frequency by origin', desc: 'Patient-days ของแต่ละช่วง', key: 'patient_days' },
            { id: '6', title: 'Mortality involving AMR', desc: 'จำนวนเสียชีวิตในตาราง Section 6', key: 'deaths' }
        ];
        host.innerHTML = specs.map(function(spec, idx) {
            let vals = '';
            if (spec.stacked) {
                vals = periods.map(function(p, i) {
                    return '<div><span class="ov-lab">' + esc(p.label) + '</span><span class="ov-num">'
                        + 'CO ' + fmtOverviewN(p.com_bsi) + ' · HO ' + fmtOverviewN(p.hos_bsi) + '</span></div>';
                }).join('');
            } else {
                vals = periods.map(function(p) {
                    const extra = spec.extra ? spec.extra(p) : '';
                    return '<div><span class="ov-lab">' + esc(p.label) + (extra ? (' · ' + esc(extra)) : '')
                        + '</span><span class="ov-num">' + fmtOverviewN(p[spec.key]) + '</span></div>';
                }).join('');
            }
            return '<div class="col-md-6 col-xl-4"><div class="amass-card">'
                + '<div class="amass-sec">Section ' + spec.id + '</div>'
                + '<h6>' + esc(spec.title) + '</h6>'
                + '<p>' + esc(spec.desc) + '</p>'
                + '<div class="ov-chart"><canvas id="ovChart' + idx + '"></canvas></div>'
                + '<div class="ov-vals">' + vals + '</div>'
                + '</div></div>';
        }).join('');
        specs.forEach(function(spec, idx) {
            const canvas = document.getElementById('ovChart' + idx);
            if (!canvas) return;
            let datasets;
            if (spec.stacked) {
                datasets = spec.keys.map(function(k, ki) {
                    return {
                        label: spec.names[ki],
                        data: periods.map(function(p) { return Number(p[k] || 0); }),
                        backgroundColor: COMPARE_COLORS[ki % COMPARE_COLORS.length],
                        borderRadius: 3,
                        maxBarThickness: 18
                    };
                });
            } else {
                datasets = [{
                    label: spec.title,
                    data: periods.map(function(p) { return Number(p[spec.key] || 0); }),
                    backgroundColor: periods.map(function(_p, i) { return COMPARE_COLORS[i % COMPARE_COLORS.length]; }),
                    borderRadius: 3,
                    maxBarThickness: 22
                }];
            }
            const chart = new Chart(canvas.getContext('2d'), {
                type: 'bar',
                data: { labels: labels, datasets: datasets },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: !!spec.stacked, position: 'top', labels: { boxWidth: 10, font: { size: 10 } } },
                        tooltip: {
                            callbacks: {
                                label: function(item) {
                                    return (item.dataset.label || '') + ': ' + fmtOverviewN(item.raw);
                                }
                            }
                        }
                    },
                    scales: {
                        x: { ticks: { font: { size: 10 } }, grid: { display: false } },
                        y: { beginAtZero: true, ticks: { font: { size: 9 }, callback: function(v) { return fmtOverviewN(v); } } }
                    }
                }
            });
            overviewChartObjs.push(chart);
        });
    }

    function destroyCompareCharts() {
        compareChartObjs.forEach(function(ch) {
            try { ch.destroy(); } catch (e) {}
        });
        compareChartObjs = [];
    }

    function uniqueOrgs(rows) {
        const seen = {};
        const out = [];
        (rows || []).forEach(function(row) {
            const o = row.Organism || '';
            if (!o || seen[o]) return;
            seen[o] = true;
            out.push(o);
        });
        return out;
    }

    function formatDelta(d) {
        if (d === '' || d == null) return '–';
        return (Number(d) > 0 ? '+' : '') + d;
    }

    function renderCompareSummary(res) {
        const periods = res.periods || [];
        const boxSum = document.getElementById('compareSummary');
        if (!boxSum) return;
        boxSum.innerHTML = periods.map(function(p) {
            const m = p.meta || {};
            return '<div class="col-md-4"><div class="border rounded p-2 bg-white">'
                + '<div class="small fw-bold">' + esc(p.label) + '</div>'
                + '<div class="small text-muted">เลือดเดดูป ' + esc(m.blood_priority_dedup || 0)
                + ' · micro ' + esc(m.micro_rows || 0)
                + (m.drug_rows ? (' · drug ' + esc(m.drug_rows)) : '')
                + (m.annex_d_dot ? (' · DOT ' + esc(m.annex_d_dot)) : '')
                + '</div></div></div>';
        }).join('');
    }

    function renderCompareTableHtml(res) {
        const periods = res.periods || [];
        if (!periods.length) return '<p class="small text-muted mb-0">ยังไม่มีผลเปรียบเทียบ</p>';
        let html = '<div class="table-responsive"><table class="table table-sm table-bordered amass-table mb-0"><thead><tr>'
            + '<th>รายการ</th><th>ยา</th>';
        periods.forEach(function(p, i) {
            html += '<th>' + esc(p.label) + ' R/n</th><th>' + esc(p.label) + ' %R</th>';
            if (i > 0) html += '<th>ต่าง</th>';
        });
        html += '</tr></thead><tbody>';
        (res.section2 || []).forEach(function(row) {
            if (compareState.org && row.Organism !== compareState.org) return;
            html += '<tr><td>' + esc(row.Organism) + '</td><td>' + esc(row.Antibiotic) + '</td>';
            periods.forEach(function(_p, i) {
                html += '<td class="num">' + esc(row['p' + i + '_r']) + '/' + esc(row['p' + i + '_n']) + '</td>';
                html += '<td class="num">' + esc(row['p' + i + '_pct']) + '</td>';
                if (i > 0) {
                    const d = row['p' + i + '_delta'];
                    let cls = 'num';
                    const txt = formatDelta(d);
                    if (d !== '' && d != null) {
                        if (Number(d) > 0) cls += ' delta-up';
                        else if (Number(d) < 0) cls += ' delta-down';
                        else cls += ' delta-zero';
                    }
                    html += '<td class="' + cls + '">' + esc(txt) + '</td>';
                }
            });
            html += '</tr>';
        });
        html += '</tbody></table></div>';
        html += '<p class="small text-muted mt-2 mb-0">ต่าง = จุดเปอร์เซ็นต์ %R เทียบช่วงแรก (แดง = ดื้อยาเพิ่ม)</p>';
        return html;
    }

    function showCompareDetail(row, periods) {
        const box = document.getElementById('compareDetail');
        if (!box || !row) return;
        let html = '<div class="pair mb-1">' + esc(row.Organism) + ' · ' + esc(row.Antibiotic) + '</div>';
        html += '<div class="row g-2">';
        periods.forEach(function(p, i) {
            const d = i > 0 ? row['p' + i + '_delta'] : '';
            let deltaHtml = '';
            if (i > 0 && d !== '' && d != null) {
                const cls = Number(d) > 0 ? 'delta-up' : (Number(d) < 0 ? 'delta-down' : 'delta-zero');
                deltaHtml = ' <span class="' + cls + '">ต่าง ' + esc(formatDelta(d)) + '</span>';
            }
            html += '<div class="col-md-4"><div class="border rounded p-2">'
                + '<div class="text-muted">' + esc(p.label) + '</div>'
                + '<div class="num fw-bold">' + esc(row['p' + i + '_pct']) + '%</div>'
                + '<div class="num text-muted">R/n ' + esc(row['p' + i + '_r']) + '/' + esc(row['p' + i + '_n']) + deltaHtml + '</div>'
                + '</div></div>';
        });
        html += '</div>';
        box.innerHTML = html;
        box.classList.remove('d-none');
        box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function renderCompareOrgPills(res) {
        const wrap = document.getElementById('compareOrgs');
        if (!wrap) return;
        const orgs = uniqueOrgs(res.section2 || []);
        wrap.classList.remove('d-none');
        wrap.innerHTML = ['<button type="button" class="btn btn-sm btn-outline-success compare-org-btn' + (compareState.org === '' ? ' active' : '') + '" data-org="">ทั้งหมด</button>']
            .concat(orgs.map(function(o) {
                const on = compareState.org === o ? ' active' : '';
                return '<button type="button" class="btn btn-sm btn-outline-success compare-org-btn' + on + '" data-org="' + esc(o) + '">' + esc(o) + '</button>';
            })).join('');
        wrap.querySelectorAll('.compare-org-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                compareState.org = btn.getAttribute('data-org') || '';
                applyCompareView();
            });
        });
    }

    function renderCompareCharts(res) {
        const host = document.getElementById('compareCharts');
        if (!host || typeof Chart === 'undefined') return;
        destroyCompareCharts();
        const periods = res.periods || [];
        const rows = (res.section2 || []).filter(function(row) {
            return !compareState.org || row.Organism === compareState.org;
        });
        const orgs = uniqueOrgs(rows);
        if (!orgs.length) {
            host.innerHTML = '<p class="small text-muted mb-0">ยังไม่มีผลเปรียบเทียบ</p>';
            return;
        }
        host.innerHTML = orgs.map(function(org, idx) {
            return '<div class="amass-chart-box"><h6>' + esc(org) + '</h6>'
                + '<div class="amass-chart-canvas"><canvas id="amassCmpChart' + idx + '"></canvas></div></div>';
        }).join('');
        orgs.forEach(function(org, idx) {
            const orgRows = rows.filter(function(r) { return r.Organism === org; });
            const canvas = document.getElementById('amassCmpChart' + idx);
            if (!canvas) return;
            const h = Math.max(170, orgRows.length * 28 + 48);
            canvas.parentNode.style.height = h + 'px';
            const datasets = periods.map(function(p, i) {
                return {
                    label: p.label || ('ช่วง ' + (i + 1)),
                    data: orgRows.map(function(r) {
                        const v = r['p' + i + '_pct'];
                        return (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
                    }),
                    backgroundColor: COMPARE_COLORS[i % COMPARE_COLORS.length],
                    borderRadius: 3,
                    maxBarThickness: 18
                };
            });
            const chart = new Chart(canvas.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: orgRows.map(function(r) { return r.Antibiotic; }),
                    datasets: datasets
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    onClick: function(_evt, elements) {
                        if (!elements || !elements.length) return;
                        const ix = elements[0].index;
                        if (orgRows[ix]) showCompareDetail(orgRows[ix], periods);
                    },
                    onHover: function(evt, elements) {
                        if (evt && evt.native && evt.native.target) {
                            evt.native.target.style.cursor = (elements && elements.length) ? 'pointer' : 'default';
                        }
                    },
                    plugins: {
                        legend: { position: 'top', labels: { boxWidth: 12, font: { size: 11 } } },
                        tooltip: {
                            callbacks: {
                                title: function(items) {
                                    const ix = items && items[0] ? items[0].dataIndex : 0;
                                    return org + ' · ' + (orgRows[ix] ? orgRows[ix].Antibiotic : '');
                                },
                                label: function(item) {
                                    const row = orgRows[item.dataIndex];
                                    const i = item.datasetIndex;
                                    if (!row) return item.formattedValue;
                                    return item.dataset.label + ': ' + String(row['p' + i + '_pct']) + '%  ('
                                        + String(row['p' + i + '_r']) + '/' + String(row['p' + i + '_n']) + ')';
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            beginAtZero: true,
                            max: 100,
                            title: { display: true, text: '%R', font: { size: 11 } },
                            ticks: { font: { size: 10 } }
                        },
                        y: { ticks: { font: { size: 10 } } }
                    }
                }
            });
            compareChartObjs.push(chart);
        });
    }

    function setCompareViewButtons() {
        const chartBtn = document.getElementById('compareViewChart');
        const tableBtn = document.getElementById('compareViewTable');
        if (!chartBtn || !tableBtn) return;
        const isChart = compareState.view === 'chart';
        chartBtn.className = 'btn ' + (isChart ? 'btn-success' : 'btn-outline-success');
        tableBtn.className = 'btn ' + (isChart ? 'btn-outline-success' : 'btn-success');
    }

    function applyCompareView() {
        const res = compareState.data;
        if (!res) return;
        const toolbar = document.getElementById('compareToolbar');
        const charts = document.getElementById('compareCharts');
        const table = document.getElementById('compareResult');
        const detail = document.getElementById('compareDetail');
        if (toolbar) toolbar.classList.remove('d-none');
        if (detail) detail.classList.add('d-none');
        setCompareViewButtons();
        renderCompareOrgPills(res);
        if (compareState.view === 'chart' && typeof Chart !== 'undefined') {
            if (charts) charts.classList.remove('d-none');
            if (table) {
                table.classList.add('d-none');
                table.innerHTML = '';
            }
            renderCompareCharts(res);
        } else {
            destroyCompareCharts();
            if (charts) {
                charts.classList.add('d-none');
                charts.innerHTML = '';
            }
            if (table) {
                table.classList.remove('d-none');
                table.innerHTML = renderCompareTableHtml(res);
            }
        }
    }

    function renderAnnexDSummaryCompare(res) {
        const wrap = document.getElementById('annexDSummaryWrap');
        if (!wrap) return;
        const periods = res && res.periods ? res.periods : [];
        const rows = res && res.annex_d_summary ? res.annex_d_summary : [];
        if (periods.length < 2 || !rows.length) return;
        let html = '<div class="table-responsive"><table class="table table-sm table-bordered amass-table mb-0"><thead><tr><th>ตัวชี้วัด</th>';
        periods.forEach(function(p) {
            html += '<th>' + esc(p.label) + '</th>';
        });
        html += '</tr></thead><tbody>';
        rows.forEach(function(r) {
            html += '<tr><td>' + esc(r.Parameter || '') + '</td>';
            periods.forEach(function(_p, i) {
                html += '<td class="num">' + esc(r['p' + i + '_val']) + '</td>';
            });
            html += '</tr>';
        });
        html += '</tbody></table></div>';
        wrap.innerHTML = html;
    }

    function applyAnnexCompare(res) {
        if (window.AmassViz && typeof AmassViz.setCompare === 'function') {
            AmassViz.setCompare(res);
        }
        renderAnnexDSummaryCompare(res);
    }

    function renderCompare(res) {
        compareState.data = res;
        renderCompareSummary(res);
        renderOverviewCompare(res);
        applyCompareView();
        applyAnnexCompare(res);
        return '';
    }

    const compareViewChart = document.getElementById('compareViewChart');
    const compareViewTable = document.getElementById('compareViewTable');
    if (compareViewChart) {
        compareViewChart.addEventListener('click', function() {
            compareState.view = 'chart';
            applyCompareView();
        });
    }
    if (compareViewTable) {
        compareViewTable.addEventListener('click', function() {
            compareState.view = 'table';
            applyCompareView();
        });
    }

    if (btnAll) {
        btnAll.addEventListener('click', async function() {
            const start = document.getElementById('amassStart').value;
            const end = document.getElementById('amassEnd').value;
            let periods;
            try {
                periods = resolveComparePeriods(start, end);
            } catch (e) {
                setStatus(e.message || String(e), true);
                return;
            }
            if (!periods.length || !periods[0].start || !periods[0].end) {
                setStatus('กรุณาเลือกช่วงวันที่', true);
                return;
            }
            setBusy(true);
            setProgress(2);
            try {
                const pack = await AmassExport.exportPeriods({
                    periods: periods,
                    onStatus: setStatus,
                    onProgress: setProgress
                });
                if (pack.staged) renderStaged(pack.staged);
                const box = document.getElementById('compareResult');
                if (pack.comparison && box) {
                    try {
                        sessionStorage.setItem('amassCompare', JSON.stringify(pack.comparison));
                    } catch (e) {}
                    setStatus('ดึงและเปรียบเทียบ ' + periods.length + ' ช่วงแล้ว — กำลังรีเฟรชตาราง');
                    window.location.reload();
                } else {
                    setStatus((pack.periods[0] && pack.periods[0].analysis && pack.periods[0].analysis.message) || 'สร้าง Dashboard แล้ว');
                    window.location.reload();
                }
            } catch (e) {
                setStatus(e.message || String(e), true);
                setProgress(0);
            } finally {
                setBusy(false);
            }
        });
    }

    function renderStaged(staged) {
        lastStaged = staged || lastStaged;
        let n = 0;
        const ranges = [];
        ['drug', 'admission', 'microbiology'].forEach(function(key) {
            const el = document.getElementById('stage-' + key);
            if (!el || !staged || !staged[key]) return;
            const s = staged[key];
            if (s.exists) n++;
            el.className = s.exists ? 'file-ok' : 'file-miss';
            let extra = '';
            if (s.exists && s.start_date && s.end_date) {
                extra = ' · ' + s.start_date + ' ถึง ' + s.end_date;
                ranges.push(s.start_date + '_' + s.end_date);
            }
            el.textContent = s.filename + ' — ' + (s.exists
                ? ('มีไฟล์' + (s.source ? ' (' + s.source + ')' : '') + extra)
                : 'ยังไม่มี');
        });
        const c = document.getElementById('stagedCount');
        if (c) c.textContent = n + '/3';
        const hint = document.getElementById('stagedRangeHint');
        if (hint) {
            const uniq = ranges.filter(function (v, i, a) { return a.indexOf(v) === i; });
            hint.textContent = uniq.length === 1
                ? (' · ช่วงไฟล์ ' + uniq[0].replace('_', ' ถึง '))
                : '';
        }
    }

    async function runFileExport(datasets, zip) {
        const start = document.getElementById('amassStart').value;
        const end = document.getElementById('amassEnd').value;
        if (!start || !end) {
            setStatus('กรุณาเลือกช่วงวันที่', true);
            return;
        }
        setBusy(true);
        setProgress(4);
        try {
            const pack = await AmassExport.exportFiles({
                start: start,
                end: end,
                datasets: datasets,
                zip: zip,
                staged: lastStaged,
                onStatus: setStatus,
                onProgress: setProgress
            });
            if (pack.staged) renderStaged(pack.staged);
            setStatus(zip
                ? 'กำลังดาวน์โหลด AMASS_HOSxP zip ตามช่วง ' + start + ' ถึง ' + end
                : 'กำลังดาวน์โหลด ' + datasets.map(function (d) { return d.filename; }).join(', '));
        } catch (e) {
            setStatus(e.message || String(e), true);
            setProgress(0);
        } finally {
            setBusy(false);
        }
    }

    exportBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
            const ds = EXPORT_SETS[btn.getAttribute('data-dataset')];
            if (ds) runFileExport([ds], false);
        });
    });
    if (btnExportZip) {
        btnExportZip.addEventListener('click', function () {
            runFileExport([EXPORT_SETS.drug, EXPORT_SETS.admission, EXPORT_SETS.microbiology], true);
        });
    }

    const btnSaveHospital = document.getElementById('btnSaveHospital');
    if (btnSaveHospital) {
        btnSaveHospital.addEventListener('click', async function() {
            function val(id) {
                return (document.getElementById(id) || {}).value || '';
            }
            const payload = {
                action: 'save_cover',
                hospital_name: val('cover_hospital_name'),
                hospital_name_th: val('cover_hospital_name_th'),
                country: val('cover_country'),
                contact_person: val('cover_contact_person'),
                contact_address: val('cover_contact_address'),
                contact_email: val('cover_contact_email'),
                notes_on_the_cover: val('cover_notes'),
                notes_on_fungal_identification: val('cover_fungal')
            };
            btnSaveHospital.disabled = true;
            try {
                const res = await fetch('fetch_amr_amass_api.php', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                }).then(function(r) { return r.json(); });
                if (res.status !== 'success') throw new Error(res.message || 'บันทึกไม่สำเร็จ');
                setStatus('บันทึกข้อมูลปกแล้ว: ' + (res.hospital_name || payload.hospital_name));
            } catch (e) {
                setStatus(e.message || String(e), true);
            } finally {
                btnSaveHospital.disabled = false;
            }
        });
    }
    const btnAnalyzeEl = document.getElementById('btnAmassAnalyze');
    if (btnAnalyzeEl) {
        btnAnalyzeEl.addEventListener('click', async function() {
            const start = (document.getElementById('amassStart') || {}).value || '';
            const end = (document.getElementById('amassEnd') || {}).value || '';
            setBusy(true);
            try {
                setStatus('กำลังวิเคราะห์ไฟล์ชุดรัน...');
                const res = await AmassExport.analyze({ start: start, end: end });
                if (res.status !== 'success') throw new Error(res.message || 'วิเคราะห์ไม่สำเร็จ');
                setStatus(res.message || 'สร้าง Dashboard แล้ว');
                window.location.reload();
            } catch (e) {
                setStatus(e.message || String(e), true);
            } finally {
                setBusy(false);
            }
        });
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    try {
        const saved = sessionStorage.getItem('amassCompare');
        if (saved) {
            const parsed = JSON.parse(saved);
            if (parsed && parsed.section2) {
                const keys = (parsed.periods || []).map(function (p) { return p.key; }).filter(Boolean);
                if (keys.length >= 2 && !parsed.annex_d_dot && window.AmassExport && AmassExport.compareMulti) {
                    AmassExport.compareMulti(keys).then(function (fresh) {
                        if (fresh && fresh.status === 'success' && fresh.annex_d_dot) {
                            try { sessionStorage.setItem('amassCompare', JSON.stringify(fresh)); } catch (e) {}
                            renderCompare(fresh);
                            return;
                        }
                        renderCompare(parsed);
                    }).catch(function () {
                        renderCompare(parsed);
                    });
                } else {
                    renderCompare(parsed);
                }
            }
        }
    } catch (e) {}

    if (!zone || !input) return;
    zone.addEventListener('click', function() { input.click(); });
    ['dragenter', 'dragover'].forEach(function(evt) {
        zone.addEventListener(evt, function(e) { e.preventDefault(); zone.classList.add('dragover'); });
    });
    ['dragleave', 'drop'].forEach(function(evt) {
        zone.addEventListener(evt, function(e) { e.preventDefault(); zone.classList.remove('dragover'); });
    });
    zone.addEventListener('drop', function(e) {
        if (e.dataTransfer.files[0]) uploadResult(e.dataTransfer.files[0]);
    });
    input.addEventListener('change', function() {
        if (this.files[0]) uploadResult(this.files[0]);
        this.value = '';
    });
    function uploadResult(file) {
        const fd = new FormData();
        fd.append('action', 'upload_result');
        fd.append('file', file);
        hint.textContent = 'กำลังเก็บ ' + file.name + '...';
        fetch('fetch_amr_amass_api.php', { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (res.status !== 'success') {
                    hint.textContent = res.message || 'อัปโหลดไม่สำเร็จ';
                    return;
                }
                hint.textContent = res.message || 'เก็บไฟล์แล้ว';
                window.location.reload();
            })
            .catch(function() { hint.textContent = 'อัปโหลดไม่สำเร็จ'; });
    }
})();
</script>
</body>
</html>
