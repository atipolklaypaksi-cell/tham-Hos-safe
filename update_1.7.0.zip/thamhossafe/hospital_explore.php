<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
require_once __DIR__ . '/hospital_ds_helper.php';
mysqli_set_charset($con, 'utf8');
hds_ensure_tables($con);
$id = (int)($_GET['id'] ?? 0);
$row = $id ? hds_get($con, $id) : null;
if (!$row) {
    header('Location: hospital_connect.php');
    exit;
}
$item = hds_public_row($row);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explore <?php echo htmlspecialchars($item['name']); ?> - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .ex-hero {
            background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 60%, #0ea5e9 100%);
            color: #fff; border-radius: 16px; padding: 1rem 1.25rem; margin-bottom: 1rem;
        }
        .ex-tables { max-height: 420px; overflow: auto; }
        .ex-tables button { text-align: left; font-family: ui-monospace, monospace; font-size: .82rem; }
        .ex-preview { font-size: .8rem; }
        .ex-preview th { white-space: nowrap; }
        textarea.sql { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: .85rem; min-height: 110px; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="ex-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <a href="hospital_connect.php" class="small text-white text-decoration-none" style="opacity:.8;"><i class="fas fa-arrow-left me-1"></i> แหล่งข้อมูล</a>
                    <h4 class="fw-bold mb-1 mt-1">Explore · <?php echo htmlspecialchars($item['name']); ?></h4>
                    <div class="small" style="opacity:.9;">
                        MySQL · <?php echo htmlspecialchars(($item['host'] ?: '-') . ':' . $item['port']); ?>
                        · ฐาน <code><?php echo htmlspecialchars($item['dbname']); ?></code>
                        · user <?php echo htmlspecialchars($item['username']); ?>
                    </div>
                </div>
                <div class="d-flex flex-column align-items-end gap-1">
                    <span class="badge bg-light text-dark">Read Only · ซ่อนคอลัมน์อ่อนไหว</span>
                    <?php if (($item['via'] ?? '') === 'grafana'): ?>
                        <span class="badge bg-info text-dark">คิวรีผ่าน Grafana</span>
                    <?php else: ?>
                        <span class="badge bg-success">เชื่อมตรง</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-lg-4">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <label class="form-label small fw-bold">ฐานข้อมูล</label>
                            <select class="form-select form-select-sm mb-2" id="dbSel">
                                <option value="<?php echo htmlspecialchars($item['dbname']); ?>"><?php echo htmlspecialchars($item['dbname']); ?></option>
                            </select>
                            <div class="input-group input-group-sm mb-2">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" class="form-control" id="tableQ" placeholder="ค้นหาตาราง เช่น ovst, patient">
                            </div>
                            <div class="ex-tables list-group" id="tableList">
                                <div class="text-muted small p-2">กำลังโหลดตาราง…</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="card shadow-sm border-0 mb-3">
                        <div class="card-body">
                            <h6 class="fw-bold mb-2"><i class="fas fa-terminal me-1 text-primary"></i> คิวรี (SELECT เท่านั้น)</h6>
                            <textarea class="form-control sql mb-2" id="sqlBox" placeholder="SELECT * FROM ovst ORDER BY vstdate DESC">SELECT * FROM ovst ORDER BY vstdate DESC</textarea>
                            <button type="button" class="btn btn-sm btn-primary" id="btnRun"><i class="fas fa-play me-1"></i> Run</button>
                            <span class="small text-muted ms-2">จำกัด 100 แถว · ไม่สามารถ INSERT/UPDATE/DELETE ได้</span>
                        </div>
                    </div>
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="fw-bold mb-0" id="previewTitle">ผลลัพธ์</h6>
                                <span class="badge bg-secondary" id="previewMeta"></span>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered bg-white ex-preview mb-0">
                                    <thead class="table-light" id="previewHead"></thead>
                                    <tbody id="previewBody">
                                        <tr><td class="text-muted">เลือกตารางด้านซ้าย หรือกด Run</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
const API = 'fetch_hospital_connect_api.php';
const DS_ID = <?php echo (int)$item['id']; ?>;
function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function api(action, extra) {
    return fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ action: action, id: DS_ID, db: document.getElementById('dbSel').value }, extra || {}))
    }).then(async function (res) {
        const text = await res.text();
        try { return JSON.parse(text); }
        catch (e) { throw new Error('API ตอบกลับไม่ใช่ JSON'); }
    });
}
function currentDb() { return document.getElementById('dbSel').value; }
function renderGrid(title, preview) {
    document.getElementById('previewTitle').textContent = title;
    const cols = preview.columns || [];
    const rows = preview.rows || [];
    document.getElementById('previewMeta').textContent = preview.total != null
        ? (rows.length + ' / ' + Number(preview.total).toLocaleString() + ' แถว')
        : (rows.length + ' แถว');
    if (preview.error) {
        document.getElementById('previewHead').innerHTML = '';
        document.getElementById('previewBody').innerHTML = '<tr><td class="text-danger">' + esc(preview.error) + '</td></tr>';
        return;
    }
    if (!cols.length) {
        document.getElementById('previewHead').innerHTML = '';
        document.getElementById('previewBody').innerHTML = '<tr><td class="text-muted">' + esc(preview.message || 'ไม่มีคอลัมน์') + '</td></tr>';
        return;
    }
    document.getElementById('previewHead').innerHTML = '<tr>' + cols.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') + '</tr>';
    if (!rows.length) {
        document.getElementById('previewBody').innerHTML = '<tr><td colspan="' + cols.length + '" class="text-muted">ไม่มีข้อมูล</td></tr>';
        return;
    }
    document.getElementById('previewBody').innerHTML = rows.map(function (r) {
        return '<tr>' + cols.map(function (c) {
            const v = r[c];
            return '<td>' + (v == null ? '<span class="text-muted">NULL</span>' : esc(v)) + '</td>';
        }).join('') + '</tr>';
    }).join('');
}
function loadDbs() {
    return api('databases').then(function (data) {
        const sel = document.getElementById('dbSel');
        const cur = sel.value;
        const dbs = data.databases || [];
        if (!dbs.length) return;
        sel.innerHTML = dbs.map(function (d) {
            return '<option value="' + esc(d) + '"' + (d === cur ? ' selected' : '') + '>' + esc(d) + '</option>';
        }).join('');
        if (dbs.indexOf(cur) < 0) sel.value = dbs[0];
    });
}
function loadTables() {
    const box = document.getElementById('tableList');
    box.innerHTML = '<div class="text-muted small p-2">กำลังค้นหา…</div>';
    api('tables', { q: document.getElementById('tableQ').value.trim() }).then(function (data) {
        const tables = data.tables || [];
        if (!tables.length) {
            box.innerHTML = '<div class="text-muted small p-2">' + esc(data.message || 'ไม่พบตาราง') + '</div>';
            return;
        }
        box.innerHTML = tables.map(function (t) {
            return '<button type="button" class="list-group-item list-group-item-action py-1 px-2" data-table="' + esc(t) + '">' + esc(t) + '</button>';
        }).join('');
    }).catch(function (err) {
        box.innerHTML = '<div class="text-danger small p-2">' + esc(err.message || 'โหลดตารางไม่สำเร็จ') + '</div>';
    });
}
function previewTable(table) {
    document.getElementById('sqlBox').value = 'SELECT * FROM `' + table + '` LIMIT 40';
    document.getElementById('previewBody').innerHTML = '<tr><td class="text-muted">กำลังอ่าน…</td></tr>';
    api('preview', { table: table }).then(function (data) {
        renderGrid(table, data.preview || {});
    }).catch(function (err) {
        renderGrid(table, { columns: [], rows: [], error: err.message || 'อ่านไม่สำเร็จ' });
    });
}
document.getElementById('tableList').addEventListener('click', function (e) {
    const btn = e.target.closest('[data-table]');
    if (!btn) return;
    previewTable(btn.getAttribute('data-table'));
});
let tmr = null;
document.getElementById('tableQ').addEventListener('input', function () {
    clearTimeout(tmr);
    tmr = setTimeout(loadTables, 250);
});
document.getElementById('dbSel').addEventListener('change', loadTables);
document.getElementById('btnRun').addEventListener('click', function () {
    const sql = document.getElementById('sqlBox').value;
    document.getElementById('previewBody').innerHTML = '<tr><td class="text-muted">กำลังรันคิวรี…</td></tr>';
    api('query', { sql: sql }).then(function (data) {
        renderGrid('Query', data.result || { error: data.message });
    }).catch(function (err) {
        renderGrid('Query', { columns: [], rows: [], error: err.message || 'คิวรีไม่สำเร็จ' });
    });
});
loadDbs().finally(loadTables);
</script>
</body>
</html>
