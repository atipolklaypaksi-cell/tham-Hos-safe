<?php
/**
 * ดึงทั้งฐาน mLAB เข้า THAM Hos-Safe ทีละเดือน (เฉพาะเดือนที่มีข้อมูล)
 * CLI: php amr_mlab_clone_cli.php
 *      php amr_mlab_clone_cli.php --from=2010 --to=2015
 */
ini_set('display_errors', 1);
error_reporting(E_ALL);
set_time_limit(0);
ini_set('memory_limit', '1024M');

if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    echo "CLI only\n";
    exit(1);
}

include(__DIR__ . '/connect.php');
require_once __DIR__ . '/amr_mlab_helper.php';
mysqli_set_charset($con, 'utf8');
amr_mlab_ensure_tables($con);

$from = null;
$to = null;
foreach ($argv as $arg) {
    if (preg_match('/^--from=(\d{4})$/', $arg, $m)) {
        $from = (int)$m[1];
    }
    if (preg_match('/^--to=(\d{4})$/', $arg, $m)) {
        $to = (int)$m[1];
    }
}

echo "วางแผนดึงทั้งฐาน mLAB...\n";
$plan = amr_mlab_clone_plan($con, true);
if (empty($plan['ok'])) {
    fwrite(STDERR, ($plan['error'] ?? 'วางแผนไม่สำเร็จ') . "\n");
    exit(1);
}
echo 'mLAB ' . number_format((int)$plan['sp_nrec']) . ' ใบ · ' . ($plan['min_date'] ?? '-') . ' → ' . ($plan['max_date'] ?? '-') . "\n";
echo 'THAM ตอนนี้ ' . number_format((int)$plan['lab_count']) . ' ใบ';
if (!empty($plan['tham_min'])) {
    echo ' · ' . $plan['tham_min'] . ' → ' . $plan['tham_max'];
}
echo "\n";

$chunks = $plan['chunks'];
if ($from || $to) {
    $chunks = array_values(array_filter($chunks, function ($c) use ($from, $to) {
        $y = (int)substr($c['start'], 0, 4);
        if ($from && $y < $from) {
            return false;
        }
        if ($to && $y > $to) {
            return false;
        }
        return true;
    }));
}

$total = count($chunks);
$okN = 0;
$failN = 0;
$skipN = 0;
foreach ($chunks as $i => $ch) {
    $n = $i + 1;
    if (!empty($ch['done'])) {
        $skipN++;
        echo "[$n/$total] {$ch['label']} ข้าม (มีแล้ว {$ch['have']}/{$ch['est']})\n";
        continue;
    }
    echo "[$n/$total] {$ch['label']} {$ch['start']} → {$ch['end']} ... ";
    if (amr_mlab_clone_chunk_is_done($con, $ch['label'], $ch['start'], $ch['end'], (int)$ch['est'])) {
        $skipN++;
        echo "ข้าม\n";
        continue;
    }
    $res = amr_mlab_sync($con, true, [
        'start' => $ch['start'],
        'end' => $ch['end'],
        'skip_pull' => true,
        'clone' => true,
    ]);
    if (($res['status'] ?? '') === 'ok') {
        $okN++;
        $have = amr_mlab_lab_count_range($con, $ch['start'], $ch['end']);
        amr_mlab_clone_mark_done($con, $ch['label'], $ch['end'], $have);
        echo 'ใหม่ ' . (int)$res['inserted'] . ' · อัปเดต ' . (int)$res['updated'] . "\n";
    } else {
        $failN++;
        echo 'ไม่สำเร็จ: ' . ($res['message'] ?? '') . "\n";
    }
}

$sync = amr_mlab_last_sync($con);
echo "เสร็จ {$okN} เดือน · ข้าม {$skipN} · ไม่สำเร็จ {$failN} · ใบแล็บใน THAM " . number_format((int)$sync['lab_count']) . "\n";
exit($failN ? 1 : 0);
