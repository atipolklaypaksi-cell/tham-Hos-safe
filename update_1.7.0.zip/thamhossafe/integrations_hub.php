<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include __DIR__ . '/connect.php';
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/integrations_hub_helper.php';
mysqli_set_charset($con, 'utf8');
if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
$role = (string)($_SESSION['role'] ?? '');
if ($role !== 'admin' && !tham_menu_can('admin.integrations_hub') && !tham_menu_can('admin.hosxp')) {
    header('Location: home.php');
    exit;
}
$items = ih_list_status($con);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เปิด/ปิดการเชื่อมต่อ - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .ih-hero {
            background: linear-gradient(135deg, #1e3a5f 0%, #0f766e 55%, #115e59 100%);
            color: #fff; border-radius: 14px; padding: 1.15rem 1.4rem; margin-bottom: 1.1rem;
        }
        .ih-card { border: 0; border-radius: 12px; }
        .ih-row {
            display: flex; align-items: flex-start; gap: 12px; padding: 14px 16px;
            border-bottom: 1px solid #e9ecef;
        }
        .ih-row:last-child { border-bottom: 0; }
        .ih-ico {
            width: 40px; height: 40px; border-radius: 10px; background: #f0fdfa;
            color: #0f766e; display: flex; align-items: center; justify-content: center; flex: 0 0 auto;
        }
        .ih-row.is-off .ih-ico { background: #f1f5f9; color: #64748b; }
        .form-check-input { width: 2.4em; height: 1.25em; cursor: pointer; }
        .form-check-input:checked { background-color: #0f766e; border-color: #0f766e; }
        .badge-req { background: #fef3c7; color: #92400e; }
    </style>
</head>
<body class="bg-light">
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <div class="ih-hero d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <div class="small text-uppercase" style="letter-spacing:.08em;opacity:.75;">ตั้งค่าระบบ · Integrations</div>
                    <h4 class="fw-bold mb-1"><i class="fas fa-plug me-2"></i>เปิด / ปิดการเชื่อมต่อ</h4>
                    <p class="mb-0 small" style="opacity:.92;">
                        รวมสวิตช์ทุกระบบภายนอกไว้จุดเดียว — เมื่อปิด ระบบจะไม่พยายามเชื่อมต่อ (กันค้างตอนกระจาย รพ.อื่น)
                        · รายละเอียด host/รหัสผ่านยังตั้งที่หน้าเชื่อมต่อเดิม
                    </p>
                </div>
                <div class="d-flex gap-2">
                    <a href="data_purge_admin.php" class="btn btn-light btn-sm fw-bold"><i class="fas fa-trash-alt me-1"></i> ล้างข้อมูล</a>
                    <span class="badge bg-light text-dark px-3 py-2">Admin</span>
                </div>
            </div>

            <div id="ihAlert" class="alert d-none" role="alert"></div>

            <div class="card ih-card shadow-sm mb-3">
                <div class="card-body p-0" id="ihList">
                    <?php foreach ($items as $it): ?>
                    <div class="ih-row <?php echo empty($it['enabled']) ? 'is-off' : ''; ?>" data-code="<?php echo htmlspecialchars($it['code']); ?>">
                        <div class="ih-ico"><i class="fas <?php echo htmlspecialchars($it['icon']); ?>"></i></div>
                        <div class="flex-grow-1">
                            <div class="d-flex flex-wrap align-items-center gap-2">
                                <span class="fw-bold"><?php echo htmlspecialchars($it['label']); ?></span>
                                <?php if (!empty($it['required'])): ?>
                                <span class="badge badge-req">แนะนำเปิด</span>
                                <?php endif; ?>
                                <a href="<?php echo htmlspecialchars($it['setting']); ?>" class="small">ตั้งค่าละเอียด</a>
                            </div>
                            <div class="small text-muted"><?php echo htmlspecialchars($it['desc']); ?></div>
                        </div>
                        <div class="form-check form-switch m-0 pt-1">
                            <input class="form-check-input ih-toggle" type="checkbox" role="switch"
                                data-code="<?php echo htmlspecialchars($it['code']); ?>"
                                <?php echo !empty($it['enabled']) ? 'checked' : ''; ?>
                                <?php echo !empty($it['required']) ? 'title="ระบบหลัก — ปิดได้แต่เมนูส่วนใหญ่จะใช้ไม่ได้"' : ''; ?>>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="alert alert-info small mb-0">
                <i class="fas fa-info-circle me-1"></i>
                สำหรับแพ็กกระจาย Docker: ปิด Google Sheet / INVC / HOSoffice / Drug Viewer ไว้ก่อน แล้วเปิดทีละระบบหลังตั้งค่า host ของ รพ.นั้น
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
function ihFlash(msg, ok) {
    const $a = $('#ihAlert').removeClass('d-none alert-success alert-danger')
        .addClass(ok ? 'alert-success' : 'alert-danger').text(msg);
    setTimeout(function () { $a.addClass('d-none'); }, 3500);
}
$('#ihList').on('change', '.ih-toggle', function () {
    const code = this.getAttribute('data-code');
    const enabled = this.checked ? 1 : 0;
    const $row = $(this).closest('.ih-row');
    const el = this;
    el.disabled = true;
    fetch('fetch_integrations_hub_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'set', code: code, enabled: enabled })
    })
    .then(r => r.json())
    .then(function (data) {
        if (!data || !data.ok) {
            el.checked = !enabled;
            ihFlash((data && data.error) || 'บันทึกไม่สำเร็จ', false);
            return;
        }
        $row.toggleClass('is-off', !enabled);
        ihFlash((enabled ? 'เปิด' : 'ปิด') + 'แล้ว: ' + code, true);
    })
    .catch(function () {
        el.checked = !enabled;
        ihFlash('เชื่อมต่อ API ไม่สำเร็จ', false);
    })
    .finally(function () { el.disabled = false; });
});
</script>
</body>
</html>
