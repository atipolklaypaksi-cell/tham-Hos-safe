<?php
/**
 * ติดตามการแพ้ยา — พยาบาลส่งรูป / เภสัชประเมินสมุดเคส
 */

function af_channels() {
    return [
        'webapp' => 'เว็บแอป (พยาบาล)',
        'line_pharmacy' => 'ไลน์ห้องยา',
        'line_mr' => 'ไลน์ MR',
        'phone' => 'โทรศัพท์',
        'other' => 'อื่นๆ',
    ];
}

function af_summary_options() {
    return [
        '' => 'รอประเมิน',
        'allergy' => 'แพ้ยา',
        'monitor' => 'เฝ้าระวัง',
        'not_allergy' => 'ไม่แพ้ยา',
        'adr_type_a' => 'ADRs type A',
        'existing_history' => 'บัตรเดิม/ประวัติ รพ.อื่น',
        'unclosed' => 'ปิดเคสไม่ได้',
    ];
}

function af_default_wards() {
    return [
        'อายุรกรรมชาย', 'อายุรกรรมหญิง', 'ศัลยกรรมชาย', 'ศัลยกรรมหญิง',
        'สูติ-นรีเวช', 'กุมารเวชกรรม', 'เด็กเล็ก', 'ER', 'ICU', 'ICU1', 'ICU2', 'ICU3',
        'CCU', 'LR', 'OR', 'ห้องคลอด', 'OPD', 'หอผู้ป่วยวิสัญญีวิทยา',
    ];
}

function af_workflow_stages() {
    return [
        'reported' => 'แจ้งแพ้ยา',
        'acknowledged' => 'เภสัชรับเคส',
        'following' => 'ติดตาม',
        'closed' => 'ปิดเคส',
    ];
}

/** ชื่อเจ้าของเคสเมื่อส่งต่อเวรถัดไปโดยไม่ระบุชื่อ */
function af_shift_handover_label() {
    return 'ส่งต่อเวร (ไม่ระบุชื่อ)';
}

function af_is_shift_handover_name($name) {
    $n = trim((string)$name);
    if ($n === '') {
        return false;
    }
    return $n === af_shift_handover_label()
        || $n === 'ส่งต่อให้เวรถัดไป (ไม่ระบุชื่อ)'
        || $n === 'ส่งต่อเวร(ไม่ระบุชื่อ)';
}

function af_case_is_shift_handover(array $case) {
    if (($case['workflow_stage'] ?? '') === 'closed') {
        return false;
    }
    return af_is_shift_handover_name($case['owner_name'] ?? '')
        || af_is_shift_handover_name($case['ack_by_name'] ?? '')
        || af_is_shift_handover_name($case['receiver_name'] ?? '');
}

function af_assessed_drugs_block_title() {
    return 'รายการยาที่แพ้หรือเกิด ADR:';
}

function af_upsert_assessed_drugs_block($text, $drugs_text) {
    // ลบหัวข้อเก่าก่อน แล้วใส่หัวข้อใหม่
    $text = af_upsert_text_block($text, 'รายการยาที่ประเมิน:', '');
    return af_upsert_text_block($text, af_assessed_drugs_block_title(), $drugs_text);
}

function af_assessed_drugs_short_text($raw) {
    $rows = af_normalize_assessed_drugs($raw);
    if (!$rows) {
        return '';
    }
    $parts = [];
    foreach ($rows as $r) {
        $n = trim((string)($r['name'] ?? ''));
        if ($n !== '') {
            $parts[] = $n;
        }
    }
    return implode(', ', $parts);
}

function af_shift_handover_sql_cond($con = null) {
    $names = [
        af_shift_handover_label(),
        'ส่งต่อให้เวรถัดไป (ไม่ระบุชื่อ)',
        'ส่งต่อเวร(ไม่ระบุชื่อ)',
    ];
    $ors = [];
    foreach ($names as $n) {
        $esc = $con ? mysqli_real_escape_string($con, $n) : addslashes($n);
        $ors[] = "owner_name='$esc'";
        $ors[] = "ack_by_name='$esc'";
    }
    return "(IFNULL(workflow_stage,'') <> 'closed' AND (" . implode(' OR ', $ors) . '))';
}

function af_workflow_stage_label($stage, $followup_count = 0) {
    $stage = trim((string)$stage);
    if ($stage === 'following') {
        $n = max(1, (int)$followup_count);
        return 'ติดตามครั้งที่ ' . $n;
    }
    $map = af_workflow_stages();
    return $map[$stage] ?? 'แจ้งแพ้ยา';
}

function af_status_from_stage($stage) {
    if ($stage === 'closed') {
        return 'done';
    }
    if ($stage === 'reported') {
        return 'new';
    }
    return 'reviewing';
}

function af_ensure_tables($con) {
    static $ready = false;
    if ($ready) {
        return true;
    }
    $q = mysqli_query($con, "SHOW TABLES LIKE 'allergy_followup_cases'");
    if (!$q || mysqli_num_rows($q) === 0) {
        $sql = @file_get_contents(__DIR__ . '/sql/allergy_followup.sql');
        if ($sql === false || trim($sql) === '') {
            return false;
        }
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
            if ($stmt !== '' && !mysqli_query($con, $stmt)) {
                return false;
            }
        }
    }
    af_ensure_workflow_schema($con);
    $ready = true;
    return true;
}

function af_ensure_workflow_schema($con) {
    static $schema_ready = false;
    if ($schema_ready) {
        return;
    }
    $alters = [
        'workflow_stage' => "ALTER TABLE allergy_followup_cases ADD COLUMN workflow_stage VARCHAR(20) NOT NULL DEFAULT 'reported' AFTER assessed_by",
        'ack_at' => "ALTER TABLE allergy_followup_cases ADD COLUMN ack_at DATETIME NULL DEFAULT NULL AFTER workflow_stage",
        'ack_by' => "ALTER TABLE allergy_followup_cases ADD COLUMN ack_by INT NOT NULL DEFAULT 0 AFTER ack_at",
        'ack_by_name' => "ALTER TABLE allergy_followup_cases ADD COLUMN ack_by_name VARCHAR(255) NOT NULL DEFAULT '' AFTER ack_by",
        'followup_count' => "ALTER TABLE allergy_followup_cases ADD COLUMN followup_count INT NOT NULL DEFAULT 0 AFTER ack_by_name",
        'last_followup_at' => "ALTER TABLE allergy_followup_cases ADD COLUMN last_followup_at DATETIME NULL DEFAULT NULL AFTER followup_count",
        'closed_at' => "ALTER TABLE allergy_followup_cases ADD COLUMN closed_at DATETIME NULL DEFAULT NULL AFTER last_followup_at",
        'closed_by' => "ALTER TABLE allergy_followup_cases ADD COLUMN closed_by INT NOT NULL DEFAULT 0 AFTER closed_at",
        'closed_by_name' => "ALTER TABLE allergy_followup_cases ADD COLUMN closed_by_name VARCHAR(255) NOT NULL DEFAULT '' AFTER closed_by",
        'import_key' => "ALTER TABLE allergy_followup_cases ADD COLUMN import_key VARCHAR(80) NOT NULL DEFAULT '' AFTER closed_by_name",
        'source_tag' => "ALTER TABLE allergy_followup_cases ADD COLUMN source_tag VARCHAR(40) NOT NULL DEFAULT '' AFTER import_key",
        'allergy_chronology' => "ALTER TABLE allergy_followup_cases ADD COLUMN allergy_chronology MEDIUMTEXT NULL AFTER assessment_detail",
        'naranjo_assessment' => "ALTER TABLE allergy_followup_cases ADD COLUMN naranjo_assessment MEDIUMTEXT NULL AFTER allergy_chronology",
        'regiscar_assessment' => "ALTER TABLE allergy_followup_cases ADD COLUMN regiscar_assessment MEDIUMTEXT NULL AFTER naranjo_assessment",
        'assessed_drugs' => "ALTER TABLE allergy_followup_cases ADD COLUMN assessed_drugs MEDIUMTEXT NULL AFTER regiscar_assessment",
        'reporter_ward' => "ALTER TABLE allergy_followup_cases ADD COLUMN reporter_ward VARCHAR(120) NOT NULL DEFAULT '' AFTER reporter_name",
    ];
    foreach ($alters as $col => $sql) {
        $cq = mysqli_query($con, "SHOW COLUMNS FROM allergy_followup_cases LIKE '" . mysqli_real_escape_string($con, $col) . "'");
        if ($cq && mysqli_num_rows($cq) === 0) {
            @mysqli_query($con, $sql);
        }
    }
    $pq = mysqli_query($con, "SHOW COLUMNS FROM allergy_followup_photos LIKE 'photo_kind'");
    if ($pq && mysqli_num_rows($pq) === 0) {
        @mysqli_query($con, "ALTER TABLE allergy_followup_photos ADD COLUMN photo_kind VARCHAR(20) NOT NULL DEFAULT 'nurse' AFTER uploaded_by_name");
        @mysqli_query($con, "UPDATE allergy_followup_photos p
            INNER JOIN allergy_followup_cases c ON c.id = p.case_id
            INNER JOIN users u ON u.id = p.uploaded_by
            SET p.photo_kind = 'progress'
            WHERE p.uploaded_by > 0
              AND p.uploaded_by <> c.reporter_user_id
              AND u.role IN ('pharmacist','admin','pharmacy_technician')");
    }
    $idx = mysqli_query($con, "SHOW INDEX FROM allergy_followup_cases WHERE Key_name='idx_af_stage'");
    if ($idx && mysqli_num_rows($idx) === 0) {
        @mysqli_query($con, "ALTER TABLE allergy_followup_cases ADD KEY idx_af_stage (workflow_stage)");
    }
    $idx2 = mysqli_query($con, "SHOW INDEX FROM allergy_followup_cases WHERE Key_name='idx_af_import'");
    if ($idx2 && mysqli_num_rows($idx2) === 0) {
        @mysqli_query($con, "ALTER TABLE allergy_followup_cases ADD KEY idx_af_import (import_key)");
    }
    $rwq = mysqli_query($con, "SHOW COLUMNS FROM allergy_followup_cases LIKE 'reporter_ward'");
    if ($rwq && mysqli_num_rows($rwq) > 0) {
        $rwbf = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='af_reporter_ward_backfill' LIMIT 1");
        $rw_done = false;
        if ($rwbf && ($rw_row = mysqli_fetch_assoc($rwbf))) {
            $rw_done = (string)$rw_row['config_value'] === '1';
        }
        if (!$rw_done) {
            @mysqli_query($con, "UPDATE allergy_followup_cases c
                INNER JOIN users u ON u.id = c.reporter_user_id
                SET c.reporter_ward = TRIM(IFNULL(u.unit_ward, ''))
                WHERE IFNULL(c.reporter_ward, '') = ''
                  AND TRIM(IFNULL(u.unit_ward, '')) <> ''");
            $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='af_reporter_ward_backfill' LIMIT 1");
            if ($chk && mysqli_num_rows($chk) > 0) {
                mysqli_query($con, "UPDATE sys_config SET config_value='1' WHERE config_name='af_reporter_ward_backfill'");
            } else {
                mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('af_reporter_ward_backfill','1')");
            }
        }
    }
    mysqli_query($con, "CREATE TABLE IF NOT EXISTS allergy_followup_events (
        id INT AUTO_INCREMENT PRIMARY KEY,
        case_id INT NOT NULL,
        event_type VARCHAR(40) NOT NULL DEFAULT '',
        followup_no INT NOT NULL DEFAULT 0,
        note TEXT NULL,
        actor_user_id INT NOT NULL DEFAULT 0,
        actor_name VARCHAR(255) NOT NULL DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_af_evt_case (case_id, id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");

    $bf = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='af_workflow_backfill' LIMIT 1");
    $bf_done = false;
    if ($bf && ($bf_row = mysqli_fetch_assoc($bf))) {
        $bf_done = (string)$bf_row['config_value'] === '1';
    }
    if (!$bf_done) {
        $need = mysqli_query($con, "SELECT id, summary_result, owner_name, assessed_at, assessed_by, created_at
            FROM allergy_followup_cases
            WHERE ack_at IS NULL AND closed_at IS NULL
              AND IFNULL(summary_result,'') != 'unclosed'
              AND (
                (summary_result IS NOT NULL AND summary_result != '')
                OR (assessed_at IS NOT NULL AND assessed_at != '0000-00-00 00:00:00')
              )");
        if ($need) {
            while ($r = mysqli_fetch_assoc($need)) {
                $id = (int)$r['id'];
                $sum = trim((string)$r['summary_result']);
                $stage = $sum !== '' ? 'closed' : 'acknowledged';
                $st = af_status_from_stage($stage);
                $owner = mysqli_real_escape_string($con, (string)$r['owner_name']);
                $extra = '';
                if ($stage === 'closed') {
                    $extra = ", closed_at=IFNULL(NULLIF(assessed_at,'0000-00-00 00:00:00'), created_at), closed_by=assessed_by, closed_by_name='$owner'";
                } else {
                    $extra = ", ack_at=IFNULL(NULLIF(assessed_at,'0000-00-00 00:00:00'), created_at), ack_by=assessed_by, ack_by_name='$owner'";
                }
                mysqli_query($con, "UPDATE allergy_followup_cases SET workflow_stage='$stage', status='$st' $extra WHERE id=$id AND closed_at IS NULL AND ack_at IS NULL");
            }
        }
        mysqli_query($con, "INSERT INTO allergy_followup_events (case_id, event_type, note, actor_user_id, actor_name, created_at)
            SELECT c.id, 'reported', IFNULL(c.ward_detail,''), c.reporter_user_id, c.reporter_name, c.created_at
            FROM allergy_followup_cases c
            LEFT JOIN allergy_followup_events e ON e.case_id=c.id AND e.event_type='reported'
            WHERE e.id IS NULL");
        $chk = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='af_workflow_backfill' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            mysqli_query($con, "UPDATE sys_config SET config_value='1' WHERE config_name='af_workflow_backfill'");
        } else {
            mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('af_workflow_backfill','1')");
        }
    }
    $schema_ready = true;
}

/** สถานะจุดบน timeline บันทึกการแพ้ยาของเภสัชกร */
function af_chronology_status_labels() {
    return [
        '' => '',
        'start' => 'เริ่มยาครั้งแรก',
        'dose' => 'ทานยา',
        'onset' => 'จุดเกิดอาการ',
        'stop' => 'หยุดยาที่สงสัย',
        'note' => 'หมายเหตุ',
    ];
}

/**
 * ทำความสะอาดรายการ chronology จาก JSON/array
 * @return array<int, array{date:string,time:string,drug:string,event:string,status:string}>
 */
function af_normalize_chronology($raw) {
    if (is_string($raw)) {
        $raw = trim($raw);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        $raw = is_array($decoded) ? $decoded : [];
    }
    if (!is_array($raw)) {
        return [];
    }
    $allowed = array_keys(af_chronology_status_labels());
    $out = [];
    foreach ($raw as $row) {
        if (!is_array($row)) {
            continue;
        }
        $date = trim((string)($row['date'] ?? ''));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            continue;
        }
        $time = trim((string)($row['time'] ?? ''));
        if ($time !== '' && preg_match('/^\d{2}:\d{2}/', $time)) {
            $time = substr($time, 0, 5);
        } else {
            $time = '';
        }
        $drug = trim((string)($row['drug'] ?? ''));
        $event = trim((string)($row['event'] ?? ''));
        $status = trim((string)($row['status'] ?? ''));
        if (!in_array($status, $allowed, true)) {
            $status = '';
        }
        if ($drug === '' && $event === '' && $status === '') {
            continue;
        }
        $out[] = [
            'date' => $date,
            'time' => $time,
            'drug' => mb_substr($drug, 0, 255),
            'event' => mb_substr($event, 0, 1000),
            'status' => $status,
        ];
    }
    usort($out, function ($a, $b) {
        $ka = $a['date'] . ' ' . ($a['time'] !== '' ? $a['time'] : '99:99');
        $kb = $b['date'] . ' ' . ($b['time'] !== '' ? $b['time'] : '99:99');
        return strcmp($ka, $kb);
    });
    return array_values($out);
}

function af_chronology_encode(array $items) {
    $items = af_normalize_chronology($items);
    if (!$items) {
        return '';
    }
    return json_encode($items, JSON_UNESCAPED_UNICODE);
}

function af_chronology_decode($raw) {
    return af_normalize_chronology($raw);
}

/** ข้อความสรุป timeline สำหรับแปะในผลการประเมิน / โน้ตไทม์ไลน์ */
function af_chronology_to_text(array $items) {
    $items = af_normalize_chronology($items);
    if (!$items) {
        return '';
    }
    $labels = af_chronology_status_labels();
    $thaiMonths = [1 => 'ม.ค.', 2 => 'ก.พ.', 3 => 'มี.ค.', 4 => 'เม.ย.', 5 => 'พ.ค.', 6 => 'มิ.ย.',
        7 => 'ก.ค.', 8 => 'ส.ค.', 9 => 'ก.ย.', 10 => 'ต.ค.', 11 => 'พ.ย.', 12 => 'ธ.ค.'];
    $lines = ['Timeline บันทึกการแพ้ยา:'];
    foreach ($items as $row) {
        $parts = explode('-', $row['date']);
        $d = (int)($parts[2] ?? 0);
        $m = (int)($parts[1] ?? 0);
        $y = (int)($parts[0] ?? 0);
        $be = $y > 0 ? ($y + 543) % 100 : 0;
        $dateLabel = $d . ' ' . ($thaiMonths[$m] ?? '') . ' ' . sprintf('%02d', $be);
        if ($row['time'] !== '') {
            $dateLabel .= ' (' . $row['time'] . ' น.)';
        }
        $bits = [$dateLabel];
        if ($row['drug'] !== '') {
            $bits[] = $row['drug'];
        }
        if ($row['event'] !== '') {
            $bits[] = $row['event'];
        }
        if ($row['status'] !== '' && isset($labels[$row['status']]) && $labels[$row['status']] !== '') {
            $bits[] = '[' . $labels[$row['status']] . ']';
        }
        $lines[] = '- ' . implode(' | ', $bits);
    }
    return implode("\n", $lines);
}

/**
 * แทนที่บล็อกข้อความที่ขึ้นต้นด้วย $heading (บรรทัดต่อท้ายขึ้นต้นด้วย $line_prefix)
 * ถ้ายังไม่มีบล็อก จะต่อท้าย — ใช้ให้ Timeline/Naranjo ในโน้ตเป็นชุดล่าสุดเสมอ
 */
function af_upsert_text_block($text, $heading, $block, $line_prefix = '-') {
    $text = (string)$text;
    $heading = (string)$heading;
    $block = trim((string)$block);
    if ($heading === '') {
        return $text;
    }
    $h = preg_quote($heading, '/');
    $prefix = preg_quote((string)$line_prefix, '/');
    $pattern = '/' . $h . '(?:\r?\n' . $prefix . '[^\n]*)*/u';
    if (preg_match($pattern, $text)) {
        if ($block === '') {
            return trim(preg_replace($pattern, '', $text, 1));
        }
        return trim(preg_replace_callback($pattern, function () use ($block) {
            return $block;
        }, $text, 1));
    }
    if ($block === '') {
        return $text;
    }
    $trim = trim($text);
    return $trim === '' ? $block : ($trim . "\n" . $block);
}

function af_chronology_sql_fragment($con, $raw, $force_clear = false) {
    if ($raw === null && !$force_clear) {
        return '';
    }
    $encoded = af_chronology_encode(is_array($raw) || is_string($raw) ? $raw : []);
    if ($encoded === '') {
        return ", allergy_chronology=NULL";
    }
    return ", allergy_chronology='" . mysqli_real_escape_string($con, $encoded) . "'";
}

/** สรุปผลที่ต้องระบุรายการยา (TMT / พิมพ์เอง) */
function af_summary_needs_drugs($summary) {
    return in_array((string)$summary, ['allergy', 'monitor', 'adr_type_a', 'existing_history'], true);
}

/**
 * รายการยาที่ประเมิน — เลือกจาก TMT หรือพิมพ์ชื่อเอง ได้หลายตัว
 * @return array<int, array{name:string,icode:string,tmt_name:string,source:string}>
 */
function af_normalize_assessed_drugs($raw) {
    if (is_string($raw)) {
        $raw = trim($raw);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        $raw = is_array($decoded) ? $decoded : [];
    }
    if (!is_array($raw)) {
        return [];
    }
    $out = [];
    $seen = [];
    foreach ($raw as $row) {
        if (is_string($row)) {
            $row = ['name' => $row];
        }
        if (!is_array($row)) {
            continue;
        }
        $name = trim((string)($row['name'] ?? $row['text'] ?? $row['drug'] ?? ''));
        $icode = trim((string)($row['icode'] ?? ''));
        $tmt = trim((string)($row['tmt_name'] ?? $row['name_tmt'] ?? ''));
        $source = trim((string)($row['source'] ?? ''));
        if ($name === '' && $tmt !== '') {
            $name = $tmt;
        }
        if ($name === '') {
            continue;
        }
        if ($source !== 'tmt' && $source !== 'free') {
            $source = ($icode !== '' || $tmt !== '') ? 'tmt' : 'free';
        }
        $name = mb_substr($name, 0, 255);
        $icode = mb_substr($icode, 0, 40);
        $tmt = mb_substr($tmt, 0, 255);
        $key = strtolower($icode !== '' ? ('i:' . $icode) : ('n:' . $name));
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = [
            'name' => $name,
            'icode' => $icode,
            'tmt_name' => $tmt,
            'source' => $source,
        ];
        if (count($out) >= 40) {
            break;
        }
    }
    return $out;
}

function af_assessed_drugs_encode($raw) {
    $rows = af_normalize_assessed_drugs($raw);
    if (!$rows) {
        return '';
    }
    $json = json_encode($rows, JSON_UNESCAPED_UNICODE);
    return $json === false ? '' : $json;
}

function af_assessed_drugs_decode($raw) {
    return af_normalize_assessed_drugs($raw);
}

function af_assessed_drugs_to_text($raw) {
    $rows = af_normalize_assessed_drugs($raw);
    if (!$rows) {
        return '';
    }
    $lines = [af_assessed_drugs_block_title()];
    foreach ($rows as $r) {
        $lab = $r['name'];
        if ($r['tmt_name'] !== '' && $r['tmt_name'] !== $r['name']) {
            $lab .= ' [' . $r['tmt_name'] . ']';
        } elseif ($r['icode'] !== '') {
            $lab .= ' (icode ' . $r['icode'] . ')';
        }
        $lines[] = '- ' . $lab;
    }
    return implode("\n", $lines);
}

function af_assessed_drugs_sql_fragment($con, $raw, $force_clear = false) {
    if ($raw === null && !$force_clear) {
        return '';
    }
    $encoded = af_assessed_drugs_encode(is_array($raw) || is_string($raw) ? $raw : []);
    if ($encoded === '') {
        return ", assessed_drugs=NULL";
    }
    return ", assessed_drugs='" . mysqli_real_escape_string($con, $encoded) . "'";
}

function af_fmt_date($date) {
    $date = substr(trim((string)$date), 0, 10);
    if ($date === '' || $date === '0000-00-00' || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m)) {
        return '';
    }
    return sprintf('%02d/%02d/%04d', (int)$m[3], (int)$m[2], (int)$m[1]);
}

/** คำถาม Naranjo ADR Probability Scale (10 ข้อ) + คะแนน yes/no/dk */
function af_naranjo_questions() {
    return [
        1 => [
            'q' => 'เคยมีการสรุปหรือรายงานปฏิกิริยานี้กับยาชนิดนี้มาแล้วหรือไม่?',
            'yes' => 1, 'no' => 0, 'dk' => 0,
        ],
        2 => [
            'q' => 'อาการไม่พึงประสงค์นี้เกิดขึ้นหลังจากได้รับยาที่คิดว่าเป็นสาเหตุหรือไม่?',
            'yes' => 2, 'no' => -1, 'dk' => 0,
        ],
        3 => [
            'q' => 'อาการไม่พึงประสงค์นี้ดีขึ้นเมื่อหยุดยาดังกล่าว หรือเมื่อให้ยาต้านที่เฉพาะเจาะจงหรือไม่?',
            'yes' => 1, 'no' => 0, 'dk' => 0,
        ],
        4 => [
            'q' => 'อาการไม่พึงประสงค์ดังกล่าวเกิดขึ้นอีกเมื่อเริ่มให้ยาใหม่หรือไม่?',
            'yes' => 2, 'no' => -1, 'dk' => 0,
        ],
        5 => [
            'q' => 'ปฏิกิริยาที่เกิดขึ้นสามารถเกิดจากสาเหตุอื่น (นอกเหนือจากยา) ของผู้ป่วยได้หรือไม่?',
            'yes' => -1, 'no' => 2, 'dk' => 0,
        ],
        6 => [
            'q' => 'ปฏิกิริยาดังกล่าวเกิดขึ้นอีก เมื่อให้ยาหลอกหรือไม่?',
            'yes' => -1, 'no' => 1, 'dk' => 0,
        ],
        7 => [
            'q' => 'สามารถตรวจวัดปริมาณยาได้ในเลือด (หรือของเหลวอื่น) ในปริมาณความเข้มข้นที่เป็นพิษหรือไม่?',
            'yes' => 1, 'no' => 0, 'dk' => 0,
        ],
        8 => [
            'q' => 'ปฏิกิริยารุนแรงขึ้น เมื่อเพิ่มขนาดยาหรือลดความรุนแรงลงเมื่อลดขนาดยาหรือไม่?',
            'yes' => 1, 'no' => 0, 'dk' => 0,
        ],
        9 => [
            'q' => 'ผู้ป่วยเคยมีปฏิกิริยาเหมือนหรือคล้ายคลึงกันนี้มาก่อนในการได้รับยาครั้งก่อนๆ หรือไม่?',
            'yes' => 1, 'no' => 0, 'dk' => 0,
        ],
        10 => [
            'q' => 'อาการไม่พึงประสงค์นี้ ได้รับการยืนยันโดยมีผลปฏิบัติการหรือผลจากการตรวจสอบอื่นๆยืนยัน?',
            'yes' => 1, 'no' => 0, 'dk' => 0,
        ],
    ];
}

function af_naranjo_category($score) {
    $score = (int)$score;
    if ($score >= 9) {
        return ['code' => 'definite', 'label' => 'ใช่แน่ (Definite)'];
    }
    if ($score >= 5) {
        return ['code' => 'probable', 'label' => 'น่าจะใช่ (Probable)'];
    }
    if ($score >= 1) {
        return ['code' => 'possible', 'label' => 'อาจจะใช่ (Possible)'];
    }
    return ['code' => 'doubtful', 'label' => 'น่าสงสัย (Doubtful)'];
}

/**
 * @return array{answers:array<int,string>,score:int|null,category:string,category_label:string,answered:int}|null
 */
function af_normalize_naranjo($raw) {
    if (is_string($raw)) {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }
        $decoded = json_decode($raw, true);
        $raw = is_array($decoded) ? $decoded : [];
    }
    if (!is_array($raw)) {
        return null;
    }
    // allow clearing with empty answers
    $src = $raw['answers'] ?? $raw;
    if (!is_array($src)) {
        return null;
    }
    $qs = af_naranjo_questions();
    $answers = [];
    $score = 0;
    $answered = 0;
    foreach ($qs as $n => $q) {
        $ans = strtolower(trim((string)($src[$n] ?? $src[(string)$n] ?? '')));
        if (!in_array($ans, ['yes', 'no', 'dk'], true)) {
            $answers[$n] = '';
            continue;
        }
        $answers[$n] = $ans;
        $score += (int)$q[$ans];
        $answered++;
    }
    if ($answered === 0) {
        return null;
    }
    $cat = af_naranjo_category($score);
    return [
        'answers' => $answers,
        'score' => $score,
        'category' => $cat['code'],
        'category_label' => $cat['label'],
        'answered' => $answered,
    ];
}

function af_naranjo_encode($raw) {
    $norm = af_normalize_naranjo($raw);
    if ($norm === null) {
        return '';
    }
    return json_encode($norm, JSON_UNESCAPED_UNICODE);
}

function af_naranjo_decode($raw) {
    return af_normalize_naranjo($raw);
}

function af_naranjo_to_text($raw) {
    $n = af_normalize_naranjo($raw);
    if ($n === null) {
        return '';
    }
    return 'Naranjo: คะแนน ' . $n['score'] . ' — ' . $n['category_label']
        . ' (ตอบครบ ' . $n['answered'] . '/10 ข้อ)';
}

function af_naranjo_sql_fragment($con, $raw, $force_clear = false) {
    if ($raw === null && !$force_clear) {
        return '';
    }
    $encoded = af_naranjo_encode($raw);
    if ($encoded === '') {
        return ", naranjo_assessment=NULL";
    }
    return ", naranjo_assessment='" . mysqli_real_escape_string($con, $encoded) . "'";
}

/** RegiSCAR Score for DRESS (ตาม MDCalc / RegiSCAR validation) */
function af_regiscar_questions() {
    return [
        'fever' => [
            'q' => 'มีไข้ (≥38.5 °C)',
            'options' => [
                'no_unknown' => ['label' => 'ไม่ทราบ/ไม่มีข้อมูล', 'score' => -1],
                'yes' => ['label' => 'ใช่', 'score' => 0],
            ],
        ],
        'lymph_nodes' => [
            'q' => 'ต่อมน้ำเหลืองโต (≥2 ตำแหน่ง, >1 ซม.)',
            'options' => [
                'no_unknown' => ['label' => 'ไม่ทราบ/ไม่มีข้อมูล', 'score' => 0],
                'yes' => ['label' => 'ใช่', 'score' => 1],
            ],
        ],
        'atypical_lymphocytes' => [
            'q' => 'ลิมโฟไซต์ผิดปกติ (Atypical lymphocytes)',
            'options' => [
                'no_unknown' => ['label' => 'ไม่ทราบ/ไม่มีข้อมูล', 'score' => 0],
                'yes' => ['label' => 'ใช่', 'score' => 1],
            ],
        ],
        'eosinophilia' => [
            'q' => 'อีโอซิโนฟีเลีย (Eosinophilia)',
            'options' => [
                'none' => ['label' => '0–699 เซลล์ หรือ <10% (ไม่มี)', 'score' => 0],
                'mild' => ['label' => '700–1,499 เซลล์ หรือ 10–19.9%', 'score' => 1],
                'severe' => ['label' => '≥1,500 เซลล์ หรือ ≥20%', 'score' => 2],
            ],
        ],
        'rash_extent' => [
            'q' => 'ผื่นผิวหนังครอบคลุมมากกว่า 50% ของพื้นที่ผิว',
            'options' => [
                'no_unknown' => ['label' => 'ไม่ทราบ/ไม่มีข้อมูล', 'score' => 0],
                'yes' => ['label' => 'ใช่', 'score' => 1],
            ],
        ],
        'rash_suggestive' => [
            'q' => 'ผื่นลักษณะเข้าได้กับ DRESS (อย่างน้อย 2 ใน: บวม, infiltration, purpura, scaling)',
            'options' => [
                'no' => ['label' => 'ไม่ใช่', 'score' => -1],
                'unknown' => ['label' => 'ไม่ทราบ', 'score' => 0],
                'yes' => ['label' => 'ใช่', 'score' => 1],
            ],
        ],
        'biopsy' => [
            'q' => 'ผลชิ้นเนื้อผิวหนังเข้าได้กับ DRESS',
            'options' => [
                'no' => ['label' => 'ไม่ใช่', 'score' => -1],
                'yes_unknown' => ['label' => 'ใช่ / ไม่ทราบ', 'score' => 0],
            ],
        ],
        'organ' => [
            'q' => 'อวัยวะภายในถูกกระทบ (ตับ ไต ปอด หัวใจ ฯลฯ)',
            'options' => [
                '0' => ['label' => 'ไม่มี (0)', 'score' => 0],
                '1' => ['label' => '1 อวัยวะ', 'score' => 1],
                '2' => ['label' => '≥2 อวัยวะ', 'score' => 2],
            ],
        ],
        'resolution' => [
            'q' => 'อาการดีขึ้นใช้เวลา ≥15 วัน',
            'options' => [
                'no_unknown' => ['label' => 'ไม่ทราบ/ไม่มีข้อมูล', 'score' => -1],
                'yes' => ['label' => 'ใช่', 'score' => 0],
            ],
        ],
        'alt_excluded' => [
            'q' => 'ตัดสาเหตุอื่นออกแล้ว (≥3 การตรวจทางชีวภาพเป็นลบ)',
            'options' => [
                'no_unknown' => ['label' => 'ไม่ทราบ/ไม่มีข้อมูล', 'score' => 0],
                'yes' => ['label' => 'ใช่', 'score' => 1],
            ],
        ],
    ];
}

function af_regiscar_category($score) {
    $score = (int)$score;
    if ($score >= 6) {
        return ['code' => 'definite', 'label' => 'ใช่แน่ DRESS (Definite)'];
    }
    if ($score >= 4) {
        return ['code' => 'probable', 'label' => 'น่าจะเป็น DRESS (Probable)'];
    }
    if ($score >= 2) {
        return ['code' => 'possible', 'label' => 'อาจเป็น DRESS (Possible)'];
    }
    return ['code' => 'no', 'label' => 'ไม่เข้าเกณฑ์ DRESS (No case)'];
}

function af_normalize_regiscar($raw) {
    if (is_string($raw)) {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }
        $decoded = json_decode($raw, true);
        $raw = is_array($decoded) ? $decoded : [];
    }
    if (!is_array($raw)) {
        return null;
    }
    $src = $raw['answers'] ?? $raw;
    if (!is_array($src)) {
        return null;
    }
    $qs = af_regiscar_questions();
    $answers = [];
    $score = 0;
    $answered = 0;
    foreach ($qs as $key => $q) {
        $ans = trim((string)($src[$key] ?? ''));
        if ($ans === '' || !isset($q['options'][$ans])) {
            $answers[$key] = '';
            continue;
        }
        $answers[$key] = $ans;
        $score += (int)$q['options'][$ans]['score'];
        $answered++;
    }
    if ($answered === 0) {
        return null;
    }
    $cat = af_regiscar_category($score);
    return [
        'answers' => $answers,
        'score' => $score,
        'category' => $cat['code'],
        'category_label' => $cat['label'],
        'answered' => $answered,
    ];
}

function af_regiscar_encode($raw) {
    $norm = af_normalize_regiscar($raw);
    if ($norm === null) {
        return '';
    }
    return json_encode($norm, JSON_UNESCAPED_UNICODE);
}

function af_regiscar_decode($raw) {
    return af_normalize_regiscar($raw);
}

function af_regiscar_to_text($raw) {
    $n = af_normalize_regiscar($raw);
    if ($n === null) {
        return '';
    }
    return 'RegiSCAR (DRESS): คะแนน ' . $n['score'] . ' — ' . $n['category_label']
        . ' (ตอบ ' . $n['answered'] . '/10 ข้อ)';
}

function af_regiscar_sql_fragment($con, $raw, $force_clear = false) {
    if ($raw === null && !$force_clear) {
        return '';
    }
    $encoded = af_regiscar_encode($raw);
    if ($encoded === '') {
        return ", regiscar_assessment=NULL";
    }
    return ", regiscar_assessment='" . mysqli_real_escape_string($con, $encoded) . "'";
}

function af_config_get($con, $name, $default = '') {
    $name_esc = mysqli_real_escape_string($con, (string)$name);
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='$name_esc' LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return $default;
    }
    $v = trim((string)$row['config_value']);
    return $v !== '' ? $v : $default;
}

function af_parse_lab_number($raw) {
    $s = trim((string)$raw);
    if ($s === '') {
        return null;
    }
    $s = str_replace([',', '%', ' '], '', $s);
    if (!preg_match('/-?\d+(?:\.\d+)?/', $s, $m)) {
        return null;
    }
    return (float)$m[0];
}

/** ดึงผล lab ล่าสุดตาม lab_items_code จาก HOSxP */
function af_fetch_latest_lab($hos, $hn, $code, $months = 36) {
    $code = trim((string)$code);
    $hn = trim((string)$hn);
    if ($code === '' || $hn === '' || !$hos) {
        return null;
    }
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hn_in = function_exists('monitor_lab_hn_sql_in')
        ? monitor_lab_hn_sql_in($hos, $hn)
        : ("'" . mysqli_real_escape_string($hos, $hn) . "'");
    $code_in = function_exists('monitor_lab_codes_sql_in')
        ? monitor_lab_codes_sql_in($hos, $code)
        : ("'" . mysqli_real_escape_string($hos, $code) . "'");
    if ($code_in === "''" || $code_in === '') {
        return null;
    }
    $months = max(1, min(120, (int)$months));
    $sql = "SELECT lo.lab_order_result, lh.order_date, lh.order_time, lo.lab_items_code,
                   CAST(CONVERT(COALESCE(li.lab_items_name, '') USING utf8) AS CHAR) AS lab_name
            FROM lab_head lh
            INNER JOIN lab_order lo ON lh.lab_order_number = lo.lab_order_number
            LEFT JOIN lab_items li ON li.lab_items_code = lo.lab_items_code
            WHERE lh.hn IN ($hn_in)
              AND lo.lab_items_code IN ($code_in)
              AND lo.lab_order_result IS NOT NULL
              AND TRIM(lo.lab_order_result) != ''
              AND lh.order_date >= DATE_SUB(CURDATE(), INTERVAL $months MONTH)
            ORDER BY lh.order_date DESC, lh.order_time DESC, lh.lab_order_number DESC
            LIMIT 1";
    $q = @mysqli_query($hos, $sql);
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return null;
    }
    $raw = trim((string)($row['lab_order_result'] ?? ''));
    $val = af_parse_lab_number($raw);
    $od = trim((string)($row['order_date'] ?? ''));
    $ot = trim((string)($row['order_time'] ?? ''));
    if (strlen($ot) >= 5) {
        $ot = substr($ot, 0, 5);
    }
    return [
        'code' => (string)($row['lab_items_code'] ?? $code),
        'name' => (string)($row['lab_name'] ?? ''),
        'raw' => $raw,
        'value' => $val,
        'order_date' => $od,
        'order_time' => $ot,
    ];
}

/**
 * Lab สำหรับประเมิน RegiSCAR/DRESS: Atypical lymphocytes + Eosinophil
 * แจ้งเตือนเมื่อ Atypical > 5 และ Eosinophil > 10
 */
function af_fetch_dress_labs($con, $hn) {
    $hn = preg_replace('/\s+/', '', (string)$hn);
    $atyp_code = af_config_get($con, 'h_code_atypical_lymphocytes', '1107');
    $eos_code = af_config_get($con, 'h_code_eosinophil', '1109');
    $out = [
        'ok' => false,
        'hn' => $hn,
        'atypical_code' => $atyp_code,
        'eosinophil_code' => $eos_code,
        'atypical' => null,
        'eosinophil' => null,
        'dress_alert' => false,
        'suggest' => [
            'atypical_lymphocytes' => '',
            'eosinophilia' => '',
        ],
        'message' => '',
    ];
    if ($hn === '') {
        $out['message'] = 'ไม่มี HN';
        return $out;
    }
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 12) : null;
    if (!$hos) {
        $out['message'] = 'เชื่อมต่อ HOSxP ไม่ได้';
        return $out;
    }
    $out['ok'] = true;
    $out['atypical'] = af_fetch_latest_lab($hos, $hn, $atyp_code);
    $out['eosinophil'] = af_fetch_latest_lab($hos, $hn, $eos_code);

    $atyp_v = isset($out['atypical']['value']) ? $out['atypical']['value'] : null;
    $eos_v = isset($out['eosinophil']['value']) ? $out['eosinophil']['value'] : null;

    if ($atyp_v !== null) {
        $out['suggest']['atypical_lymphocytes'] = ($atyp_v > 5) ? 'yes' : 'no_unknown';
    }
    if ($eos_v !== null) {
        // ค่า < 100 ถือเป็น % ตาม CBC; ค่าสูงถือเป็น absolute count
        if ($eos_v >= 100) {
            if ($eos_v >= 1500) {
                $out['suggest']['eosinophilia'] = 'severe';
            } elseif ($eos_v >= 700) {
                $out['suggest']['eosinophilia'] = 'mild';
            } else {
                $out['suggest']['eosinophilia'] = 'none';
            }
        } else {
            if ($eos_v >= 20) {
                $out['suggest']['eosinophilia'] = 'severe';
            } elseif ($eos_v >= 10) {
                $out['suggest']['eosinophilia'] = 'mild';
            } else {
                $out['suggest']['eosinophilia'] = 'none';
            }
        }
    }

    $out['dress_alert'] = ($atyp_v !== null && $eos_v !== null && $atyp_v > 5 && $eos_v > 10);
    return $out;
}

function af_log_event($con, $case_id, $type, $note = '', $followup_no = 0) {
    $case_id = (int)$case_id;
    if ($case_id <= 0) {
        return false;
    }
    $user = af_current_user();
    $type_esc = mysqli_real_escape_string($con, $type);
    $note_esc = mysqli_real_escape_string($con, trim((string)$note));
    $n = (int)$followup_no;
    $uid = (int)$user['id'];
    $name = mysqli_real_escape_string($con, $user['name']);
    return (bool)mysqli_query($con, "INSERT INTO allergy_followup_events
        (case_id, event_type, followup_no, note, actor_user_id, actor_name)
        VALUES ($case_id, '$type_esc', $n, '$note_esc', $uid, '$name')");
}

/** รวมข้อความสำหรับไทม์ไลน์ — ไม่ซ้ำระหว่าง note กับผลการประเมิน */
function af_timeline_detail_note($note = '', $assessment = '', $referral = '', $summary_label = '') {
    $parts = [];
    $note = trim((string)$note);
    $assessment = trim((string)$assessment);
    $referral = trim((string)$referral);
    $summary_label = trim((string)$summary_label);
    if ($note !== '') {
        $parts[] = $note;
    } elseif ($assessment !== '') {
        $parts[] = $assessment;
        $assessment = '';
    }
    if ($assessment !== '' && $assessment !== $note) {
        $parts[] = 'ผลการประเมิน: ' . $assessment;
    }
    if ($referral !== '') {
        $parts[] = 'ส่งต่อ: ' . $referral;
    }
    if ($summary_label !== '') {
        $parts[] = 'สรุปผล: ' . $summary_label;
    }
    return implode("\n", $parts);
}

/**
 * เคสเก่าที่ assessment_detail ไม่อยู่ใน event — แปะลงช่วง followup/closed/ack ตอนแสดง
 */
function af_attach_assessment_to_events(array $events, array $row) {
    $assess = trim((string)($row['assessment_detail'] ?? ''));
    $referral = trim((string)($row['referral_note'] ?? ''));
    $sum = trim((string)($row['summary_result'] ?? ''));
    $sum_label = ($sum !== '' && isset(af_summary_options()[$sum])) ? af_summary_options()[$sum] : '';
    if ($assess === '' && $referral === '' && $sum_label === '') {
        return $events;
    }
    $already = false;
    foreach ($events as $ev) {
        $n = (string)($ev['note'] ?? '');
        if (($ev['event_type'] ?? '') === 'assessment' || ($assess !== '' && strpos($n, $assess) !== false)) {
            $already = true;
            break;
        }
    }
    if ($already) {
        return $events;
    }
    $extra = af_timeline_detail_note('', $assess, $referral, $sum_label);
    if ($extra === '') {
        return $events;
    }
    $touched = false;
    foreach ($events as $i => $ev) {
        $t = (string)($ev['event_type'] ?? '');
        if (!in_array($t, ['acknowledged', 'followup', 'closed'], true)) {
            continue;
        }
        $note = trim((string)($ev['note'] ?? ''));
        $events[$i]['note_display'] = $note === '' ? $extra : ($note . "\n" . $extra);
        $touched = true;
    }
    if (!$touched) {
        $events[] = [
            'id' => 0,
            'event_type' => 'assessment',
            'followup_no' => 0,
            'label' => 'บันทึกการประเมิน',
            'note' => $extra,
            'note_display' => $extra,
            'actor_name' => trim((string)($row['owner_name'] ?? $row['ack_by_name'] ?? '')),
            'created_at' => (string)($row['assessed_at'] ?? $row['updated_at'] ?? ''),
            'created_at_fmt' => af_fmt_dt($row['assessed_at'] ?? $row['updated_at'] ?? ''),
        ];
    }
    return $events;
}

function af_case_events($con, $case_id) {
    $case_id = (int)$case_id;
    $out = [];
    $q = mysqli_query($con, "SELECT * FROM allergy_followup_events WHERE case_id=$case_id ORDER BY id ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $type = (string)$r['event_type'];
            $no = (int)$r['followup_no'];
            $label = af_workflow_stage_label($type === 'followup' ? 'following' : $type, $no);
            if ($type === 'followup') {
                $label = 'ติดตามครั้งที่ ' . max(1, $no);
            } elseif ($type === 'reported') {
                $label = 'แจ้งแพ้ยา';
            } elseif ($type === 'acknowledged') {
                $label = 'เภสัชรับเคส';
            } elseif ($type === 'transferred') {
                $label = 'ส่งต่อเคส';
            } elseif ($type === 'closed') {
                $label = 'ปิดเคส';
            } elseif ($type === 'assessment') {
                $label = 'บันทึกการประเมิน';
            }
            $out[] = [
                'id' => (int)$r['id'],
                'event_type' => $type,
                'followup_no' => $no,
                'label' => $label,
                'note' => (string)($r['note'] ?? ''),
                'note_display' => (string)($r['note'] ?? ''),
                'actor_name' => (string)($r['actor_name'] ?? ''),
                'created_at' => (string)($r['created_at'] ?? ''),
                'created_at_fmt' => af_fmt_dt($r['created_at'] ?? ''),
            ];
        }
    }
    return $out;
}

/**
 * แก้ไขข้อความในไทม์ไลน์ — ทำได้แม้เคสปิดแล้ว (เภสัช/admin)
 */
function af_update_event($con, $event_id, $note) {
    if (!af_can_assess()) {
        return ['ok' => false, 'error' => 'ไม่มีสิทธิ์แก้ไขไทม์ไลน์'];
    }
    $event_id = (int)$event_id;
    if ($event_id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบรายการไทม์ไลน์'];
    }
    af_ensure_tables($con);
    $q = mysqli_query($con, "SELECT * FROM allergy_followup_events WHERE id=$event_id LIMIT 1");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return ['ok' => false, 'error' => 'ไม่พบรายการไทม์ไลน์'];
    }
    $case_id = (int)($row['case_id'] ?? 0);
    $note = trim((string)$note);
    $note_esc = mysqli_real_escape_string($con, $note);
    $ok = mysqli_query($con, "UPDATE allergy_followup_events SET note='$note_esc' WHERE id=$event_id");
    if (!$ok) {
        return ['ok' => false, 'error' => 'บันทึกไทม์ไลน์ไม่สำเร็จ'];
    }
    // ถ้าเป็นช่วงแจ้งแพ้ยา ซิงก์รายละเอียดเคสด้วย
    if ((string)($row['event_type'] ?? '') === 'reported' && $case_id > 0) {
        mysqli_query($con, "UPDATE allergy_followup_cases SET ward_detail='$note_esc' WHERE id=$case_id");
    }
    // ถ้าเป็นช่วงประเมิน/ปิด และโน้ตมีข้อความประเมิน ให้ sync assessment_detail เมื่อว่างหรือตรงกับของเดิมบางส่วน
    if ($case_id > 0 && in_array((string)($row['event_type'] ?? ''), ['assessment', 'closed', 'followup'], true)) {
        if (preg_match('/ผลการประเมิน:\s*(.+?)(?:\nส่งต่อ:|\nสรุปผล:|$)/s', $note, $m)) {
            $assess = trim($m[1]);
            if ($assess !== '') {
                $a_esc = mysqli_real_escape_string($con, $assess);
                mysqli_query($con, "UPDATE allergy_followup_cases SET assessment_detail='$a_esc' WHERE id=$case_id");
            }
        }
    }
    return ['ok' => true, 'case' => af_get_case($con, $case_id, true), 'event_id' => $event_id];
}

function af_fmt_dt($dt) {
    $dt = trim((string)$dt);
    if ($dt === '' || $dt === '0000-00-00 00:00:00') {
        return '';
    }
    $ts = strtotime($dt);
    return $ts ? date('d/m/Y H:i', $ts) : $dt;
}

function af_reported_datetime(array $row) {
    $date = trim((string)($row['case_date'] ?? ''));
    $time = trim((string)($row['notify_time'] ?? ''));
    if ($date === '') {
        return (string)($row['created_at'] ?? '');
    }
    if (preg_match('/^(\d{1,2}):(\d{2})/', $time, $m)) {
        $time = sprintf('%02d:%02d:00', (int)$m[1], (int)$m[2]);
    } else {
        $time = '00:00:00';
    }
    return $date . ' ' . $time;
}

function af_workflow_payload(array $row, array $events = []) {
    $stage = trim((string)($row['workflow_stage'] ?? 'reported'));
    if ($stage === '') {
        $stage = 'reported';
    }
    $fu = (int)($row['followup_count'] ?? 0);
    $recv = af_current_receiver($row);
    return [
        'workflow_stage' => $stage,
        'workflow_label' => af_workflow_stage_label($stage, $fu),
        'ack_at' => (string)($row['ack_at'] ?? ''),
        'ack_at_fmt' => af_fmt_dt($row['ack_at'] ?? ''),
        'ack_by' => (int)($row['ack_by'] ?? 0),
        'ack_by_name' => (string)($row['ack_by_name'] ?? ''),
        'receiver_user_id' => (int)($recv['id'] ?? 0),
        'receiver_name' => (string)($recv['name'] ?? ''),
        'followup_count' => $fu,
        'last_followup_at' => (string)($row['last_followup_at'] ?? ''),
        'last_followup_at_fmt' => af_fmt_dt($row['last_followup_at'] ?? ''),
        'closed_at' => (string)($row['closed_at'] ?? ''),
        'closed_at_fmt' => af_fmt_dt($row['closed_at'] ?? ''),
        'closed_by_name' => (string)($row['closed_by_name'] ?? ''),
        'reported_at_fmt' => af_fmt_dt(af_reported_datetime($row)),
        'events' => $events,
    ];
}

function af_parse_actor_id($ack_user_id) {
    if (is_int($ack_user_id) || is_float($ack_user_id)) {
        return (int)$ack_user_id;
    }
    $s = trim((string)$ack_user_id);
    if ($s === '') {
        return 0;
    }
    if (stripos($s, 'u:') === 0) {
        return (int)substr($s, 2);
    }
    if (stripos($s, 'n:') === 0) {
        return 0;
    }
    return (int)$s;
}

function af_parse_actor_name($ack_user_id, $ack_name) {
    $name = trim((string)$ack_name);
    $raw = trim((string)$ack_user_id);
    if ($name === '' && stripos($raw, 'n:') === 0) {
        $name = trim(substr($raw, 2));
    }
    return $name;
}

/**
 * หา user id/name สำหรับผู้รับเคส — ค่าเริ่มต้นคือผู้ login
 */
function af_resolve_ack_actor($con, $ack_user_id = 0, $ack_name = '', $fallback_to_me = true) {
    $user = af_current_user();
    $uid = af_parse_actor_id($ack_user_id);
    $name = af_parse_actor_name($ack_user_id, $ack_name);
    if ($name !== '' && (strpos($name, 'เลือกผู้รับเคส') !== false)) {
        $name = '';
    }
    if ($uid > 0) {
        $q = mysqli_query($con, "SELECT id, full_name FROM users WHERE id=$uid LIMIT 1");
        $r = $q ? mysqli_fetch_assoc($q) : null;
        if ($r) {
            $uid = (int)$r['id'];
            if ($name === '') {
                $name = trim((string)($r['full_name'] ?? ''));
            }
        }
    }
    if ($uid <= 0 && $name !== '') {
        $esc = mysqli_real_escape_string($con, $name);
        $q = mysqli_query($con, "SELECT id, full_name FROM users WHERE full_name='$esc' LIMIT 1");
        $r = $q ? mysqli_fetch_assoc($q) : null;
        if ($r) {
            $uid = (int)$r['id'];
            $name = trim((string)($r['full_name'] ?? $name));
        }
    }
    if ($fallback_to_me) {
        if ($uid <= 0) {
            $uid = (int)$user['id'];
        }
        if ($name === '') {
            $name = trim((string)$user['name']);
        }
    }
    return ['id' => $uid, 'name' => $name];
}

function af_current_receiver(array $case) {
    $id = (int)($case['ack_by'] ?? 0);
    $name = trim((string)($case['ack_by_name'] ?? ''));
    if ($id <= 0 && $name === '') {
        $id = (int)($case['owner_user_id'] ?? 0);
        $name = trim((string)($case['owner_name'] ?? ''));
    }
    return ['id' => $id, 'name' => $name];
}

function af_receiver_same(array $a, array $b) {
    $aid = (int)($a['id'] ?? 0);
    $bid = (int)($b['id'] ?? 0);
    $an = trim((string)($a['name'] ?? ''));
    $bn = trim((string)($b['name'] ?? ''));
    if ($aid > 0 && $bid > 0) {
        return $aid === $bid;
    }
    if ($an !== '' && $bn !== '') {
        return $an === $bn;
    }
    return $aid === $bid && $an === $bn;
}

/** บันทึกประวัติรับเคส หรือส่งต่อในไทม์ไลน์ */
function af_log_receiver_change($con, array $case, array $new_actor, $note = '') {
    $id = (int)($case['id'] ?? 0);
    if ($id <= 0) {
        return '';
    }
    $prev = af_current_receiver($case);
    $new_name = trim((string)($new_actor['name'] ?? ''));
    $has_prev = ((int)($prev['id'] ?? 0) > 0) || trim((string)($prev['name'] ?? '')) !== '';
    if (!$has_prev) {
        $txt = trim((string)$note);
        if ($txt === '') {
            $txt = 'รับเคสโดย ' . ($new_name !== '' ? $new_name : 'ผู้ใช้ปัจจุบัน');
        }
        af_log_event($con, $id, 'acknowledged', $txt);
        return 'acknowledged';
    }
    if (af_receiver_same($prev, $new_actor)) {
        return '';
    }
    $from = trim((string)$prev['name']);
    if ($from === '') {
        $from = 'ไม่ระบุ';
    }
    $to = $new_name !== '' ? $new_name : 'ไม่ระบุ';
    $txt = 'ส่งต่อจาก ' . $from . ' ไปยัง ' . $to;
    $extra = trim((string)$note);
    if ($extra !== '' && strpos($extra, 'ส่งต่อจาก') === false) {
        $txt .= "\n" . $extra;
    }
    af_log_event($con, $id, 'transferred', $txt);
    return 'transferred';
}

function af_set_case_receiver($con, $case_id, array $actor, $advance_if_reported = true, $current_stage = '') {
    $case_id = (int)$case_id;
    $uid = (int)($actor['id'] ?? 0);
    $name = mysqli_real_escape_string($con, trim((string)($actor['name'] ?? '')));
    $extra = '';
    if ($advance_if_reported && ($current_stage === 'reported' || $current_stage === '')) {
        $extra = ", workflow_stage='acknowledged', status='reviewing'";
    }
    return (bool)mysqli_query($con, "UPDATE allergy_followup_cases SET
        ack_at=IFNULL(ack_at, NOW()), ack_by=$uid, ack_by_name='$name',
        owner_user_id=$uid, owner_name='$name'
        $extra
        WHERE id=$case_id");
}

function af_transfer_case($con, $case_id, $to_user_id = 0, $to_name = '', $note = '') {
    if (!af_can_assess()) {
        return ['ok' => false, 'error' => 'ไม่มีสิทธิ์ส่งต่อเคส'];
    }
    $case = af_get_case($con, $case_id, false);
    if (!$case) {
        return ['ok' => false, 'error' => 'ไม่พบเคส'];
    }
    $raw_to = is_string($to_user_id) ? trim($to_user_id) : $to_user_id;
    $to_shift = ($raw_to === '__shift__') || af_is_shift_handover_name($to_name);
    if ($to_shift) {
        $actor = ['id' => 0, 'name' => af_shift_handover_label()];
        $note = trim((string)$note);
        if ($note === '') {
            $note = 'ส่งต่อให้เวรถัดไป (ไม่ระบุชื่อ)';
        }
    } else {
        $actor = af_resolve_ack_actor($con, $to_user_id, $to_name, false);
        if (trim($actor['name']) === '' && (int)$actor['id'] <= 0) {
            return ['ok' => false, 'error' => 'กรุณาเลือกผู้รับเคส'];
        }
    }
    $prev = af_current_receiver($case);
    $has_prev = ((int)$prev['id'] > 0) || trim((string)$prev['name']) !== '';
    if ($has_prev && af_receiver_same($prev, $actor)) {
        return ['ok' => false, 'error' => 'กรุณาเลือกผู้รับคนใหม่เพื่อส่งต่อเคส'];
    }
    af_log_receiver_change($con, $case, $actor, $note);
    $stage = (string)($case['workflow_stage'] ?? 'reported');
    if (!af_set_case_receiver($con, (int)$case_id, $actor, true, $stage)) {
        return ['ok' => false, 'error' => 'ส่งต่อเคสไม่สำเร็จ'];
    }
    return ['ok' => true, 'case' => af_get_case($con, (int)$case_id, true)];
}

function af_advance_ack($con, $case_id, $note = '', $ack_user_id = 0, $ack_name = '') {
    $case = af_get_case($con, $case_id, false);
    if (!$case) {
        return ['ok' => false, 'error' => 'ไม่พบเคส'];
    }
    if (($case['workflow_stage'] ?? '') === 'closed') {
        return ['ok' => false, 'error' => 'เคสปิดแล้ว'];
    }
    $actor = af_resolve_ack_actor($con, $ack_user_id, $ack_name);
    $id = (int)$case_id;
    af_log_receiver_change($con, $case, $actor, $note);
    $stage = (string)($case['workflow_stage'] ?? 'reported');
    if (!af_set_case_receiver($con, $id, $actor, true, $stage === 'closed' ? 'closed' : $stage)) {
        return ['ok' => false, 'error' => 'รับเคสไม่สำเร็จ'];
    }
    return ['ok' => true, 'case' => af_get_case($con, $id, true)];
}

/**
 * แก้ไขสถานะ workflow + ผู้รับเคส (เภสัช/admin)
 */
function af_update_workflow($con, $case_id, $stage, $ack_user_id = 0, $ack_name = '', $note = '') {
    if (!af_can_assess()) {
        return ['ok' => false, 'error' => 'ไม่มีสิทธิ์แก้ไขสถานะ'];
    }
    $case = af_get_case($con, $case_id, false);
    if (!$case) {
        return ['ok' => false, 'error' => 'ไม่พบเคส'];
    }
    $stage = trim((string)$stage);
    $allowed = ['reported', 'acknowledged', 'following', 'closed'];
    if (!in_array($stage, $allowed, true)) {
        return ['ok' => false, 'error' => 'สถานะไม่ถูกต้อง'];
    }
    $id = (int)$case_id;
    $actor = af_resolve_ack_actor($con, $ack_user_id, $ack_name);
    $uid = (int)$actor['id'];
    $name = mysqli_real_escape_string($con, $actor['name']);
    $me = af_current_user();
    $me_id = (int)$me['id'];
    $me_name = mysqli_real_escape_string($con, $me['name']);
    $sets = [];

    if ($stage === 'reported') {
        $sets[] = "workflow_stage='reported'";
        $sets[] = "status='new'";
        $sets[] = "ack_at=NULL";
        $sets[] = "ack_by=0";
        $sets[] = "ack_by_name=''";
        $sets[] = "closed_at=NULL";
        $sets[] = "closed_by=0";
        $sets[] = "closed_by_name=''";
    } elseif ($stage === 'acknowledged') {
        $sets[] = "workflow_stage='acknowledged'";
        $sets[] = "status='reviewing'";
        $sets[] = "ack_at=IFNULL(ack_at, NOW())";
        $sets[] = "ack_by=$uid";
        $sets[] = "ack_by_name='$name'";
        $sets[] = "owner_user_id=$uid";
        $sets[] = "owner_name='$name'";
        $sets[] = "closed_at=NULL";
        $sets[] = "closed_by=0";
        $sets[] = "closed_by_name=''";
    } elseif ($stage === 'following') {
        $sets[] = "workflow_stage='following'";
        $sets[] = "status='reviewing'";
        $sets[] = "ack_at=IFNULL(ack_at, NOW())";
        $sets[] = "ack_by=$uid";
        $sets[] = "ack_by_name='$name'";
        $sets[] = "owner_user_id=$uid";
        $sets[] = "owner_name='$name'";
        $sets[] = "closed_at=NULL";
        $sets[] = "closed_by=0";
        $sets[] = "closed_by_name=''";
        if ((int)($case['followup_count'] ?? 0) <= 0) {
            $sets[] = "followup_count=1";
            $sets[] = "last_followup_at=IFNULL(last_followup_at, NOW())";
        }
    } else { // closed
        $sets[] = "workflow_stage='closed'";
        $sets[] = "status='done'";
        $sets[] = "ack_at=IFNULL(ack_at, NOW())";
        $sets[] = "ack_by=IF(IFNULL(ack_by,0)=0, $uid, ack_by)";
        $sets[] = "ack_by_name=IF(IFNULL(ack_by_name,'')='', '$name', ack_by_name)";
        $sets[] = "closed_at=IFNULL(closed_at, NOW())";
        $sets[] = "closed_by=IF(IFNULL(closed_by,0)=0, $me_id, closed_by)";
        $sets[] = "closed_by_name=IF(IFNULL(closed_by_name,'')='', '$me_name', closed_by_name)";
    }

    $sql = "UPDATE allergy_followup_cases SET " . implode(', ', $sets) . " WHERE id=$id";
    if (!mysqli_query($con, $sql)) {
        return ['ok' => false, 'error' => 'บันทึกสถานะไม่สำเร็จ'];
    }
    $label = af_workflow_stage_label($stage, (int)($case['followup_count'] ?? 0));
    $note_txt = trim((string)$note);
    $stage_changed = (string)($case['workflow_stage'] ?? 'reported') !== $stage;
    if ($stage !== 'reported') {
        af_log_receiver_change($con, $case, $actor, $note_txt);
    }
    if ($stage_changed || $note_txt !== '') {
        if ($note_txt === '') {
            $note_txt = 'ปรับสถานะเป็น ' . $label;
            if ($stage !== 'reported' && $actor['name'] !== '') {
                $note_txt .= ' (ผู้รับเคส: ' . $actor['name'] . ')';
            }
        }
        $evt = $stage === 'reported' ? 'reported' : ($stage === 'closed' ? 'closed' : ($stage === 'following' ? 'followup' : 'acknowledged'));
        // ถ้าแค่เปลี่ยนผู้รับในสถานะเดิม ไม่ต้องซ้ำ event รับเคส
        $skip_dup_ack = (!$stage_changed && $evt === 'acknowledged');
        if (!$skip_dup_ack) {
            af_log_event($con, $id, $evt, $note_txt, $stage === 'following' ? max(1, (int)($case['followup_count'] ?? 1)) : 0);
        }
    }
    return ['ok' => true, 'case' => af_get_case($con, $id, true)];
}

function af_add_followup($con, $case_id, $note = '', array $extra = []) {
    $case = af_get_case($con, $case_id, false);
    if (!$case) {
        return ['ok' => false, 'error' => 'ไม่พบเคส'];
    }
    if (($case['workflow_stage'] ?? '') === 'closed') {
        return ['ok' => false, 'error' => 'เคสปิดแล้ว ไม่สามารถติดตามเพิ่ม'];
    }
    $user = af_current_user();
    $id = (int)$case_id;
    $n = (int)($case['followup_count'] ?? 0) + 1;
    $uid = (int)$user['id'];
    $name = mysqli_real_escape_string($con, $user['name']);
    $assessment = trim((string)($extra['assessment_detail'] ?? ''));
    $referral = trim((string)($extra['referral_note'] ?? ''));
    if ($assessment === '') {
        $assessment = trim((string)($case['assessment_detail'] ?? ''));
    }
    if ($referral === '') {
        $referral = trim((string)($case['referral_note'] ?? ''));
    }
    if (array_key_exists('allergy_chronology', $extra)) {
        $assessment = af_upsert_text_block($assessment, 'Timeline บันทึกการแพ้ยา:', af_chronology_to_text($extra['allergy_chronology']));
        $extra['assessment_detail'] = $assessment;
    }
    if (array_key_exists('assessed_drugs', $extra)) {
        $sum_for_drugs = trim((string)($extra['summary_result'] ?? $case['summary_result'] ?? ''));
        $drugs_raw = af_summary_needs_drugs($sum_for_drugs) ? $extra['assessed_drugs'] : [];
        $assessment = af_upsert_assessed_drugs_block($assessment, af_assessed_drugs_to_text($drugs_raw));
        $extra['assessment_detail'] = $assessment;
        $extra['assessed_drugs'] = $drugs_raw;
    }
    $ack_sql = '';
    if (($case['workflow_stage'] ?? '') === 'reported') {
        $ack_sql = ", ack_at=IFNULL(ack_at, NOW()), ack_by=IF(ack_by=0, $uid, ack_by), ack_by_name=IF(ack_by_name='', '$name', ack_by_name)";
        af_log_event($con, $id, 'acknowledged', 'รับเคสอัตโนมัติเมื่อเริ่มติดตาม');
    }
    $extra_sql = '';
    if (trim((string)($extra['assessment_detail'] ?? '')) !== '') {
        $extra_sql .= ", assessment_detail='" . mysqli_real_escape_string($con, trim((string)$extra['assessment_detail'])) . "'";
    }
    if (trim((string)($extra['referral_note'] ?? '')) !== '') {
        $extra_sql .= ", referral_note='" . mysqli_real_escape_string($con, trim((string)$extra['referral_note'])) . "'";
    }
    if (array_key_exists('allergy_chronology', $extra)) {
        $extra_sql .= af_chronology_sql_fragment($con, $extra['allergy_chronology'], true);
    }
    if (array_key_exists('naranjo_assessment', $extra)) {
        $extra_sql .= af_naranjo_sql_fragment($con, $extra['naranjo_assessment'], true);
    }
    if (array_key_exists('regiscar_assessment', $extra)) {
        $extra_sql .= af_regiscar_sql_fragment($con, $extra['regiscar_assessment'], true);
    }
    if (array_key_exists('assessed_drugs', $extra)) {
        $extra_sql .= af_assessed_drugs_sql_fragment($con, $extra['assessed_drugs'], true);
    }
    if (array_key_exists('owner_user_id', $extra) || array_key_exists('owner_name', $extra)) {
        $oid = (int)($extra['owner_user_id'] ?? 0);
        $oname = trim((string)($extra['owner_name'] ?? ''));
        if ($oname === '' && $oid > 0) {
            $qo = mysqli_query($con, "SELECT full_name FROM users WHERE id=$oid LIMIT 1");
            $ro = $qo ? mysqli_fetch_assoc($qo) : null;
            $oname = trim((string)($ro['full_name'] ?? ''));
        }
        if ($oname !== '' || $oid > 0) {
            $oname_esc = mysqli_real_escape_string($con, $oname);
            $extra_sql .= ", owner_user_id=$oid, owner_name='$oname_esc'";
            $prev_recv = af_current_receiver($case);
            $has_prev_recv = ((int)$prev_recv['id'] > 0) || trim((string)$prev_recv['name']) !== '';
            if ($has_prev_recv) {
                $recv_logged = af_log_receiver_change($con, $case, ['id' => $oid, 'name' => $oname], '');
                if ($recv_logged !== '') {
                    $extra_sql .= ", ack_by=$oid, ack_by_name='$oname_esc', ack_at=IFNULL(ack_at, NOW())";
                }
            }
        }
    }
    mysqli_query($con, "UPDATE allergy_followup_cases SET
        workflow_stage='following', status='reviewing',
        followup_count=$n, last_followup_at=NOW()
        $ack_sql $extra_sql
        WHERE id=$id");
    $evt_note = af_timeline_detail_note($note, $assessment, $referral);
    if ($evt_note === '') {
        $evt_note = 'ติดตามครั้งที่ ' . $n;
    }
    // แนบสรุป chronology ให้เป็นชุดล่าสุดเสมอ (แทนที่บล็อกเดิมถ้ามี)
    if (array_key_exists('allergy_chronology', $extra)) {
        $chrono_txt = af_chronology_to_text($extra['allergy_chronology']);
        $evt_note = af_upsert_text_block($evt_note, 'Timeline บันทึกการแพ้ยา:', $chrono_txt);
    }
    if (array_key_exists('naranjo_assessment', $extra)) {
        $nar_txt = af_naranjo_to_text($extra['naranjo_assessment']);
        if ($nar_txt !== '' && strpos($evt_note, 'Naranjo:') === false) {
            $evt_note = trim($evt_note . "\n" . $nar_txt);
        }
    }
    if (array_key_exists('regiscar_assessment', $extra)) {
        $reg_txt = af_regiscar_to_text($extra['regiscar_assessment']);
        if ($reg_txt !== '' && strpos($evt_note, 'RegiSCAR') === false) {
            $evt_note = trim($evt_note . "\n" . $reg_txt);
        }
    }
    af_log_event($con, $id, 'followup', $evt_note, $n);
    return ['ok' => true, 'followup_no' => $n, 'case' => af_get_case($con, $id, true)];
}

function af_close_case($con, $case_id, $summary, $note = '', $assessment = '', $referral = '', $chronology = null, $naranjo = null, $regiscar = null, $owner_user_id = null, $owner_name = null, $assessed_drugs = null) {
    $case = af_get_case($con, $case_id, false);
    if (!$case) {
        return ['ok' => false, 'error' => 'ไม่พบเคส'];
    }
    $summary = trim((string)$summary);
    if ($summary === '' || !isset(af_summary_options()[$summary])) {
        return ['ok' => false, 'error' => 'กรุณาเลือกสรุปผลก่อนปิดเคส (แพ้ยา / ไม่แพ้ยา / อื่นๆ)'];
    }
    $user = af_current_user();
    $id = (int)$case_id;
    $uid = (int)$user['id'];
    $name = mysqli_real_escape_string($con, $user['name']);
    $assessment = trim((string)$assessment);
    if ($chronology !== null) {
        $assessment = af_upsert_text_block($assessment, 'Timeline บันทึกการแพ้ยา:', af_chronology_to_text($chronology));
    }
    if ($assessed_drugs !== null) {
        if (!af_summary_needs_drugs($summary)) {
            $assessed_drugs = [];
        }
        $assessment = af_upsert_assessed_drugs_block($assessment, af_assessed_drugs_to_text($assessed_drugs));
    }
    $sum_esc = mysqli_real_escape_string($con, $summary);
    $ass_esc = mysqli_real_escape_string($con, $assessment);
    $ref_esc = mysqli_real_escape_string($con, trim((string)$referral));
    $label = af_summary_options()[$summary];
    $ack_sql = '';
    if (($case['workflow_stage'] ?? '') === 'reported') {
        $ack_sql = ", ack_at=IFNULL(ack_at, NOW()), ack_by=IF(ack_by=0, $uid, ack_by), ack_by_name=IF(ack_by_name='', '$name', ack_by_name)";
    }
    $owner_sql = '';
    if ($owner_user_id !== null || $owner_name !== null) {
        $oid = (int)($owner_user_id ?? 0);
        $oname = trim((string)($owner_name ?? ''));
        if ($oname === '' && $oid > 0) {
            $qo = mysqli_query($con, "SELECT full_name FROM users WHERE id=$oid LIMIT 1");
            $ro = $qo ? mysqli_fetch_assoc($qo) : null;
            $oname = trim((string)($ro['full_name'] ?? ''));
        }
        if ($oname !== '' || $oid > 0) {
            $oname_esc = mysqli_real_escape_string($con, $oname);
            $owner_sql = ", owner_user_id=$oid, owner_name='$oname_esc'";
            $recv_logged = af_log_receiver_change($con, $case, ['id' => $oid, 'name' => $oname], '');
            if ($recv_logged !== '') {
                $owner_sql .= ", ack_by=$oid, ack_by_name='$oname_esc', ack_at=IFNULL(ack_at, NOW())";
            }
        }
    } elseif (trim((string)($case['owner_name'] ?? '')) === '') {
        $owner_sql = ", owner_user_id=$uid, owner_name='$name'";
    }
    $ass_sql = $ass_esc !== '' ? ", assessment_detail='$ass_esc'" : '';
    $ref_sql = $ref_esc !== '' ? ", referral_note='$ref_esc'" : '';
    $chrono_sql = ($chronology !== null) ? af_chronology_sql_fragment($con, $chronology, true) : '';
    $naranjo_sql = ($naranjo !== null) ? af_naranjo_sql_fragment($con, $naranjo, true) : '';
    $regiscar_sql = ($regiscar !== null) ? af_regiscar_sql_fragment($con, $regiscar, true) : '';
    $drugs_sql = ($assessed_drugs !== null) ? af_assessed_drugs_sql_fragment($con, $assessed_drugs, true) : '';
    mysqli_query($con, "UPDATE allergy_followup_cases SET
        workflow_stage='closed', status='done',
        summary_result='$sum_esc',
        closed_at=NOW(), closed_by=$uid, closed_by_name='$name',
        assessed_at=NOW(), assessed_by=$uid
        $ack_sql $owner_sql $ass_sql $ref_sql $chrono_sql $naranjo_sql $regiscar_sql $drugs_sql
        WHERE id=$id");
    $assess_for_note = trim((string)$assessment);
    if ($assess_for_note === '') {
        $assess_for_note = trim((string)($case['assessment_detail'] ?? ''));
    }
    $ref_for_note = trim((string)$referral);
    if ($ref_for_note === '') {
        $ref_for_note = trim((string)($case['referral_note'] ?? ''));
    }
    $evt_note = af_timeline_detail_note($note !== '' ? $note : 'ปิดเคส', $assess_for_note, $ref_for_note, $label);
    $chrono_src = $chronology !== null ? $chronology : ($case['allergy_chronology'] ?? []);
    $chrono_txt = af_chronology_to_text($chrono_src);
    $evt_note = af_upsert_text_block($evt_note, 'Timeline บันทึกการแพ้ยา:', $chrono_txt);
    $drugs_src = $assessed_drugs !== null ? $assessed_drugs : ($case['assessed_drugs'] ?? []);
    $evt_note = af_upsert_assessed_drugs_block($evt_note, af_assessed_drugs_to_text($drugs_src));
    $nar_src = $naranjo !== null ? $naranjo : ($case['naranjo_assessment'] ?? null);
    $nar_txt = af_naranjo_to_text($nar_src);
    if ($nar_txt !== '' && strpos($evt_note, 'Naranjo:') === false) {
        $evt_note = trim($evt_note . "\n" . $nar_txt);
    }
    $reg_src = $regiscar !== null ? $regiscar : ($case['regiscar_assessment'] ?? null);
    $reg_txt = af_regiscar_to_text($reg_src);
    if ($reg_txt !== '' && strpos($evt_note, 'RegiSCAR') === false) {
        $evt_note = trim($evt_note . "\n" . $reg_txt);
    }
    af_log_event($con, $id, 'closed', $evt_note);
    return ['ok' => true, 'case' => af_get_case($con, $id, true)];
}

function af_dashboard_counts($con, array $filters = []) {
    if (!empty($filters['force_empty'])) {
        return af_counts_from_cases([]);
    }
    $scope = trim((string)($filters['force_ward_scope'] ?? $filters['scope_ward'] ?? ''));
    if ($scope !== '') {
        $list_filters = $filters;
        $list_filters['workflow_stage'] = 'all';
        $list_filters['summary_result'] = 'all';
        return af_counts_from_cases(af_list_cases($con, $list_filters));
    }
    $where = ['1=1'];
    $start = trim((string)($filters['start_date'] ?? ''));
    $end = trim((string)($filters['end_date'] ?? ''));
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $start)) {
        $where[] = "case_date >= '" . mysqli_real_escape_string($con, $start) . "'";
    }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
        $where[] = "case_date <= '" . mysqli_real_escape_string($con, $end) . "'";
    }
    $ward = trim((string)($filters['ward'] ?? ''));
    if ($ward !== '') {
        $escw = mysqli_real_escape_string($con, $ward);
        $where[] = "(ward = '$escw' OR ward LIKE CONCAT('%', '$escw', '%'))";
    }
    if (!empty($filters['exclude_import'])) {
        $where[] = "(IFNULL(import_key,'') = '')";
    }
    $only_mine = !empty($filters['only_mine']);
    if ($only_mine) {
        $uid = (int)($filters['user_id'] ?? 0);
        $where[] = 'reporter_user_id = ' . $uid;
    }
    $shift_cond = af_shift_handover_sql_cond($con);
    $sql = "SELECT
        SUM(workflow_stage='reported' OR workflow_stage IS NULL OR workflow_stage='') AS reported,
        SUM(workflow_stage='acknowledged') AS acknowledged,
        SUM(workflow_stage='following') AS following,
        SUM(workflow_stage='closed') AS closed,
        SUM($shift_cond) AS shift_handover,
        COUNT(*) AS total
        FROM allergy_followup_cases WHERE " . implode(' AND ', $where);
    $q = mysqli_query($con, $sql);
    $row = $q ? mysqli_fetch_assoc($q) : [];
    $counts = [
        'reported' => (int)($row['reported'] ?? 0),
        'acknowledged' => (int)($row['acknowledged'] ?? 0),
        'following' => (int)($row['following'] ?? 0),
        'closed' => (int)($row['closed'] ?? 0),
        'shift_handover' => (int)($row['shift_handover'] ?? 0),
        'total' => (int)($row['total'] ?? 0),
    ];
    $sum = [
        'allergy' => 0, 'not_allergy' => 0, 'monitor' => 0, 'adr_type_a' => 0, 'existing_history' => 0, 'unclosed' => 0,
    ];
    $qs = mysqli_query($con, "SELECT summary_result, COUNT(*) AS c FROM allergy_followup_cases
        WHERE " . implode(' AND ', $where) . " AND workflow_stage='closed' GROUP BY summary_result");
    if ($qs) {
        while ($r = mysqli_fetch_assoc($qs)) {
            $k = (string)($r['summary_result'] ?? '');
            if (isset($sum[$k]) && $k !== 'unclosed') {
                $sum[$k] = (int)$r['c'];
            }
        }
    }
    $qu = mysqli_query($con, "SELECT COUNT(*) AS c FROM allergy_followup_cases
        WHERE " . implode(' AND ', $where) . " AND summary_result='unclosed'");
    $ur = $qu ? mysqli_fetch_assoc($qu) : null;
    $sum['unclosed'] = (int)($ur['c'] ?? 0);
    $counts['closed_summary'] = $sum;
    return $counts;
}

function af_can_assess() {
    $role = strtolower(trim((string)($_SESSION['role'] ?? '')));
    if (in_array($role, ['admin', 'pharmacist', 'pharmacy_technician'], true)) {
        return true;
    }
    // ผู้ที่ได้รับเมนู "ติดตามการแพ้ยา" ให้ประเมินเคสได้ (Timeline / Naranjo / RegiSCAR)
    $allowed = $_SESSION['allowed_menus'] ?? null;
    if (is_array($allowed) && in_array('allergy_followup', $allowed, true)) {
        return true;
    }
    return false;
}

function af_can_delete_case(array $case = null) {
    if (af_can_assess()) {
        return true;
    }
    if (!$case) {
        return false;
    }
    $uid = (int)($_SESSION['user_id'] ?? 0);
    return $uid > 0 && $uid === (int)($case['reporter_user_id'] ?? 0);
}

/**
 * ลบเคสแพ้ยาพร้อมรูป / event / notification ที่เกี่ยวข้อง
 */
function af_delete_case($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบเคส'];
    }
    af_ensure_tables($con);
    $case = af_get_case($con, $id, false);
    if (!$case) {
        return ['ok' => false, 'error' => 'ไม่พบเคส'];
    }
    if (!af_can_delete_case($case)) {
        return ['ok' => false, 'error' => 'ไม่มีสิทธิ์ลบเคสนี้'];
    }

    $photos = [];
    $qp = mysqli_query($con, "SELECT id, stored_name FROM allergy_followup_photos WHERE case_id=$id");
    if ($qp) {
        while ($r = mysqli_fetch_assoc($qp)) {
            $photos[] = $r;
        }
    }
    $dir = af_upload_dir();
    foreach ($photos as $p) {
        $path = $dir . '/' . basename((string)($p['stored_name'] ?? ''));
        if ($path !== $dir . '/' && is_file($path)) {
            @unlink($path);
        }
    }

    mysqli_query($con, "DELETE FROM allergy_followup_photos WHERE case_id=$id");
    mysqli_query($con, "DELETE FROM allergy_followup_events WHERE case_id=$id");
    mysqli_query($con, "DELETE FROM allergy_followup_notifications WHERE case_id=$id");
    $ok = mysqli_query($con, "DELETE FROM allergy_followup_cases WHERE id=$id");
    if (!$ok) {
        return ['ok' => false, 'error' => 'ลบเคสไม่สำเร็จ'];
    }
    return ['ok' => true, 'id' => $id];
}

function af_current_user() {
    return [
        'id' => (int)($_SESSION['user_id'] ?? 0),
        'name' => trim((string)($_SESSION['full_name'] ?? '')),
        'role' => (string)($_SESSION['role'] ?? ''),
    ];
}

function af_hn_variants($hn) {
    $hn = trim((string)$hn);
    $out = [];
    if ($hn === '') {
        return $out;
    }
    $out[] = $hn;
    if (ctype_digit($hn)) {
        $pad = str_pad($hn, 9, '0', STR_PAD_LEFT);
        $trim = ltrim($hn, '0');
        if ($trim === '') {
            $trim = '0';
        }
        $out[] = $pad;
        $out[] = $trim;
    }
    return array_values(array_unique($out));
}

function af_hn_display($hn) {
    $hn = trim((string)$hn);
    if ($hn !== '' && ctype_digit($hn)) {
        return ltrim($hn, '0') ?: '0';
    }
    return $hn;
}

function af_upload_dir() {
    $dir = __DIR__ . '/uploads/allergy_followup';
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }
    if (is_dir($dir)) {
        @chmod($dir, 0777);
    }
    $deny = $dir . '/.htaccess';
    if (!is_file($deny)) {
        @file_put_contents($deny, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
    }
    return $dir;
}

function af_allowed_mimes() {
    return [
        'image/jpeg' => 'jpg',
        'image/pjpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
    ];
}

function af_detect_mime($tmp) {
    if (!is_file($tmp)) {
        return '';
    }
    if (function_exists('finfo_open')) {
        $f = finfo_open(FILEINFO_MIME_TYPE);
        if ($f) {
            $mime = (string)finfo_file($f, $tmp);
            finfo_close($f);
            if ($mime !== '') {
                return strtolower($mime);
            }
        }
    }
    $info = @getimagesize($tmp);
    return strtolower((string)($info['mime'] ?? ''));
}

function af_unread_notification_count($con) {
    if (!af_ensure_tables($con)) {
        return 0;
    }
    $q = mysqli_query($con, "SELECT COUNT(*) AS c FROM allergy_followup_notifications WHERE is_read = 0");
    $row = $q ? mysqli_fetch_assoc($q) : null;
    return (int)($row['c'] ?? 0);
}

function af_list_pharmacists($con) {
    $out = [];
    $seen = [];
    $q = mysqli_query($con, "SELECT id, full_name FROM users
        WHERE full_name IS NOT NULL AND TRIM(full_name) <> ''
          AND role IN ('pharmacist','admin','pharmacy_technician')
        ORDER BY full_name ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $name = trim((string)$r['full_name']);
            $key = mb_strtolower($name, 'UTF-8');
            if ($name === '' || isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $out[] = ['id' => (int)$r['id'], 'name' => $name];
        }
    }
    $q2 = mysqli_query($con, "SELECT DISTINCT name FROM (
            SELECT owner_name AS name FROM allergy_followup_cases
            WHERE owner_name IS NOT NULL AND TRIM(owner_name) <> ''
            UNION
            SELECT ack_by_name AS name FROM allergy_followup_cases
            WHERE ack_by_name IS NOT NULL AND TRIM(ack_by_name) <> ''
        ) names
        ORDER BY name ASC");
    if ($q2) {
        while ($r = mysqli_fetch_assoc($q2)) {
            $name = trim((string)$r['name']);
            $key = mb_strtolower($name, 'UTF-8');
            if ($name === '' || isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $uid = 0;
            $esc = mysqli_real_escape_string($con, $name);
            $uq = mysqli_query($con, "SELECT id FROM users WHERE full_name='$esc' LIMIT 1");
            if ($uq && ($ur = mysqli_fetch_assoc($uq))) {
                $uid = (int)$ur['id'];
            }
            $out[] = ['id' => $uid, 'name' => $name];
        }
    }
    return $out;
}

function af_list_wards($con) {
    $names = af_default_wards();
    $q = mysqli_query($con, "SELECT DISTINCT ward FROM allergy_followup_cases
        WHERE ward IS NOT NULL AND TRIM(ward) <> '' ORDER BY ward ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $names[] = trim((string)$r['ward']);
        }
    }
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 8) : null;
    if ($hos) {
        $sql = "SELECT CAST(CONVERT(IFNULL(name, ward) USING utf8) AS CHAR) AS name
                FROM ward
                WHERE name IS NOT NULL AND TRIM(name) <> ''
                ORDER BY name";
        $hw = @mysqli_query($hos, $sql);
        if ($hw) {
            while ($r = mysqli_fetch_assoc($hw)) {
                $n = trim((string)$r['name']);
                if ($n !== '') {
                    $names[] = $n;
                }
            }
        }
        @mysqli_close($hos);
    }
    $out = [];
    $seen = [];
    foreach ($names as $n) {
        $n = trim((string)$n);
        $key = mb_strtolower($n, 'UTF-8');
        if ($n === '' || isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = $n;
    }
    natcasesort($out);
    return array_values($out);
}

function af_lookup_patient($con, $hn) {
    require_once __DIR__ . '/med_error_helper.php';
    $pt = med_error_fetch_patient_from_hosxp($con, $hn);
    if (!$pt) {
        return null;
    }
    $pt['ward'] = af_lookup_current_ward($con, $pt['hn']);
    $pt['is_admitted'] = $pt['ward'] !== '';
    $pt['allergies'] = af_lookup_hosxp_allergies($con, $pt['hn']);
    $pt['hn_display'] = af_hn_display($pt['hn']);
    return $pt;
}

function af_lookup_current_ward($con, $hn) {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 8) : null;
    if (!$hos) {
        return '';
    }
    $variants = af_hn_variants($hn);
    if (empty($variants)) {
        @mysqli_close($hos);
        return '';
    }
    $in = [];
    foreach ($variants as $v) {
        $in[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    $in_sql = implode(',', $in);
    // ห้ามเทียบ DATE กับ '' — MySQL ขึ้น Incorrect DATE value แล้ว query ล้ม
    $sql = "SELECT CAST(CONVERT(IFNULL(w.name, i.ward) USING utf8) AS CHAR) AS ward_name
            FROM ipt i
            LEFT JOIN ward w ON w.ward = i.ward
            WHERE i.hn IN ($in_sql)
              AND (i.dchdate IS NULL OR i.dchdate = '0000-00-00')
            ORDER BY i.an DESC
            LIMIT 1";
    $q = @mysqli_query($hos, $sql);
    $row = ($q && mysqli_num_rows($q) > 0) ? mysqli_fetch_assoc($q) : null;
    @mysqli_close($hos);
    return trim((string)($row['ward_name'] ?? ''));
}

function af_user_ward_scope() {
    if (!function_exists('tham_user_scoped_ward')) {
        require_once __DIR__ . '/user_unit_helper.php';
    }
    return tham_user_scoped_ward();
}

function af_ward_name_matches($a, $b) {
    $na = function_exists('mb_strtolower') ? mb_strtolower(trim((string)$a), 'UTF-8') : strtolower(trim((string)$a));
    $nb = function_exists('mb_strtolower') ? mb_strtolower(trim((string)$b), 'UTF-8') : strtolower(trim((string)$b));
    if ($na === '' || $nb === '') {
        return false;
    }
    if ($na === $nb) {
        return true;
    }
    return (function_exists('mb_strpos') ? mb_strpos($na, $nb) !== false : strpos($na, $nb) !== false)
        || (function_exists('mb_strpos') ? mb_strpos($nb, $na) !== false : strpos($nb, $na) !== false);
}

function af_hosxp_table_exists($hos, $table) {
    static $cache = [];
    $table = trim((string)$table);
    if ($table === '' || !$hos) {
        return false;
    }
    if (array_key_exists($table, $cache)) {
        return $cache[$table];
    }
    $esc = mysqli_real_escape_string($hos, $table);
    $q = @mysqli_query($hos, "SHOW TABLES LIKE '$esc'");
    $cache[$table] = ($q && mysqli_num_rows($q) > 0);
    return $cache[$table];
}

function af_hosxp_ward_codes_for_name($hos, $ward_name) {
    $ward_name = trim((string)$ward_name);
    if ($ward_name === '' || !$hos) {
        return [];
    }
    $esc = mysqli_real_escape_string($hos, $ward_name);
    $like = mysqli_real_escape_string($hos, '%' . $ward_name . '%');
    $sql = "SELECT ward, CAST(CONVERT(IFNULL(name, ward) USING utf8) AS CHAR) AS name
            FROM ward
            WHERE ward = '$esc' OR name = '$esc' OR CAST(CONVERT(IFNULL(name, ward) USING utf8) AS CHAR) LIKE '$like'";
    $q = @mysqli_query($hos, $sql);
    $codes = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $code = trim((string)($r['ward'] ?? ''));
            $name = trim((string)($r['name'] ?? ''));
            if ($code !== '' && ($name === '' || af_ward_name_matches($name, $ward_name) || $code === $ward_name)) {
                $codes[$code] = true;
            }
        }
    }
    if (!$codes) {
        $codes[$ward_name] = true;
    }
    return array_keys($codes);
}

function af_hns_admitted_in_ward($con, array $hns, $ward_name) {
    static $cache = [];
    $ward_name = trim((string)$ward_name);
    $hns = array_values(array_unique(array_filter(array_map('trim', $hns), function ($h) {
        return $h !== '';
    })));
    sort($hns);
    if ($ward_name === '' || !$hns) {
        return [];
    }
    $ckey = $ward_name . ':' . md5(implode('|', $hns));
    if (isset($cache[$ckey])) {
        return $cache[$ckey];
    }
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 8) : null;
    if (!$hos) {
        return [];
    }
    $codes = af_hosxp_ward_codes_for_name($hos, $ward_name);
    $code_sql = [];
    foreach ($codes as $c) {
        $code_sql[] = "'" . mysqli_real_escape_string($hos, $c) . "'";
    }
    $in_codes = $code_sql ? implode(',', $code_sql) : "''";
    $like = mysqli_real_escape_string($hos, '%' . $ward_name . '%');
    $name_match = "(CAST(CONVERT(IFNULL(w.name, i.ward) USING utf8) AS CHAR) LIKE '$like')";
    $allowed = [];
    $chunks = array_chunk($hns, 250);
    $has_stat = af_hosxp_table_exists($hos, 'ipt_ward_stat');
    $has_adm = af_hosxp_table_exists($hos, 'iptadm');
    foreach ($chunks as $chunk) {
        $in = [];
        foreach ($chunk as $hn) {
            foreach (af_hn_variants($hn) as $v) {
                $in[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
            }
        }
        if (!$in) {
            continue;
        }
        $in_sql = implode(',', array_unique($in));
        $current_an = "(i.dchdate IS NULL OR i.dchdate = '0000-00-00')";
        $extra = '';
        if ($has_stat) {
            $extra .= " OR EXISTS (
                SELECT 1 FROM ipt_ward_stat iw
                LEFT JOIN ward w2 ON w2.ward = iw.ward
                WHERE iw.an = i.an
                  AND (iw.ward IN ($in_codes) OR CAST(CONVERT(IFNULL(w2.name, iw.ward) USING utf8) AS CHAR) LIKE '$like')
            )";
        }
        if ($has_adm) {
            $extra .= " OR EXISTS (
                SELECT 1 FROM iptadm ia
                LEFT JOIN ward w3 ON w3.ward = ia.ward
                WHERE ia.an = i.an
                  AND (ia.ward IN ($in_codes) OR CAST(CONVERT(IFNULL(w3.name, ia.ward) USING utf8) AS CHAR) LIKE '$like')
            )";
        }
        $sql = "SELECT DISTINCT i.hn
                FROM ipt i
                LEFT JOIN ward w ON w.ward = i.ward
                WHERE i.hn IN ($in_sql)
                  AND $current_an
                  AND (
                    i.ward IN ($in_codes)
                    OR $name_match
                    $extra
                  )";
        $q = @mysqli_query($hos, $sql);
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $hn = trim((string)($r['hn'] ?? ''));
                if ($hn === '') {
                    continue;
                }
                foreach (af_hn_variants($hn) as $v) {
                    $allowed[$v] = true;
                }
                $allowed[$hn] = true;
            }
        }
    }
    @mysqli_close($hos);
    $cache[$ckey] = $allowed;
    return $allowed;
}

function af_users_unit_wards($con, array $user_ids) {
    $out = [];
    $ids = [];
    foreach ($user_ids as $id) {
        $id = (int)$id;
        if ($id > 0) {
            $ids[$id] = $id;
        }
    }
    if (!$ids || !$con) {
        return $out;
    }
    $q = @mysqli_query($con, 'SELECT id, unit_ward FROM users WHERE id IN (' . implode(',', $ids) . ')');
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $out[(int)$r['id']] = trim((string)($r['unit_ward'] ?? ''));
        }
    }
    return $out;
}

function af_case_in_ward_scope(array $case, $scope_ward, array $allowed_hns, array $reporter_units = []) {
    $scope_ward = trim((string)$scope_ward);
    if ($scope_ward === '') {
        return true;
    }
    if (af_ward_name_matches($case['ward'] ?? '', $scope_ward)) {
        return true;
    }
    if (af_ward_name_matches($case['reporter_ward'] ?? '', $scope_ward)) {
        return true;
    }
    $rid = (int)($case['reporter_user_id'] ?? 0);
    if ($rid > 0 && af_ward_name_matches($reporter_units[$rid] ?? '', $scope_ward)) {
        return true;
    }
    if (!$allowed_hns) {
        return false;
    }
    foreach (af_hn_variants($case['hn'] ?? '') as $v) {
        if (isset($allowed_hns[$v])) {
            return true;
        }
    }
    return false;
}

function af_filter_cases_by_ward_scope($con, array $cases, $scope_ward) {
    $scope_ward = trim((string)$scope_ward);
    if ($scope_ward === '' || !$cases) {
        return $cases;
    }
    $hns = [];
    $rep_ids = [];
    foreach ($cases as $c) {
        $hn = trim((string)($c['hn'] ?? ''));
        if ($hn !== '') {
            $hns[] = $hn;
        }
        $rid = (int)($c['reporter_user_id'] ?? 0);
        if ($rid > 0) {
            $rep_ids[$rid] = $rid;
        }
    }
    $allowed = af_hns_admitted_in_ward($con, $hns, $scope_ward);
    $reporter_units = af_users_unit_wards($con, array_values($rep_ids));
    $out = [];
    foreach ($cases as $c) {
        if (af_case_in_ward_scope($c, $scope_ward, $allowed, $reporter_units)) {
            $out[] = $c;
        }
    }
    return $out;
}

function af_apply_viewer_scope(array $filters) {
    if (!function_exists('tham_user_sees_all_wards')) {
        require_once __DIR__ . '/user_unit_helper.php';
    }
    $see_all = tham_user_sees_all_wards();
    $scope = af_user_ward_scope();
    $filters['see_all_wards'] = $see_all;
    $filters['scope_ward'] = $scope;
    if ($see_all) {
        return $filters;
    }
    $filters['ward'] = '';
    if ($scope === '') {
        $filters['force_empty'] = true;
        return $filters;
    }
    $filters['force_ward_scope'] = $scope;
    return $filters;
}

function af_counts_from_cases(array $cases) {
    $counts = [
        'reported' => 0, 'acknowledged' => 0, 'following' => 0, 'closed' => 0, 'shift_handover' => 0, 'total' => 0,
    ];
    $sum = [
        'allergy' => 0, 'not_allergy' => 0, 'monitor' => 0, 'adr_type_a' => 0, 'existing_history' => 0, 'unclosed' => 0,
    ];
    foreach ($cases as $c) {
        $counts['total']++;
        $st = trim((string)($c['workflow_stage'] ?? ''));
        if ($st === '' || $st === 'reported') {
            $counts['reported']++;
        } elseif (isset($counts[$st])) {
            $counts[$st]++;
        }
        if (!empty($c['is_shift_handover']) || af_case_is_shift_handover($c)) {
            $counts['shift_handover']++;
        }
        if ($st === 'closed') {
            $k = (string)($c['summary_result'] ?? '');
            if (isset($sum[$k]) && $k !== 'unclosed') {
                $sum[$k]++;
            }
        }
        if ((string)($c['summary_result'] ?? '') === 'unclosed') {
            $sum['unclosed']++;
        }
    }
    $counts['closed_summary'] = $sum;
    return $counts;
}

function af_lookup_hosxp_allergies($con, $hn) {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $hos = function_exists('hosxp_connect') ? @hosxp_connect($con, 8) : null;
    if (!$hos) {
        return [];
    }
    $variants = af_hn_variants($hn);
    if (empty($variants)) {
        @mysqli_close($hos);
        return [];
    }
    $in = [];
    foreach ($variants as $v) {
        $in[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    $in_sql = implode(',', $in);
    $sql = "SELECT CAST(CONVERT(IFNULL(agent,'') USING utf8) AS CHAR) AS agent,
                   CAST(CONVERT(IFNULL(symptom,'') USING utf8) AS CHAR) AS symptom,
                   report_date
            FROM opd_allergy
            WHERE hn IN ($in_sql)
            ORDER BY report_date DESC, opd_allergy_id DESC
            LIMIT 20";
    $q = @mysqli_query($hos, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $agent = trim((string)$r['agent']);
            if ($agent === '') {
                continue;
            }
            $rd = substr(trim((string)($r['report_date'] ?? '')), 0, 10);
            if ($rd === '0000-00-00') {
                $rd = '';
            }
            $rows[] = [
                'agent' => $agent,
                'symptom' => trim((string)$r['symptom']),
                'report_date' => $rd,
                'report_date_fmt' => af_fmt_date($rd),
            ];
        }
    }
    @mysqli_close($hos);
    return $rows;
}

function af_photo_kind($kind)
{
    $kind = strtolower(trim((string)$kind));
    return $kind === 'progress' ? 'progress' : 'nurse';
}

function af_photo_public($row) {
    $id = (int)($row['id'] ?? 0);
    return [
        'id' => $id,
        'orig_name' => (string)($row['orig_name'] ?? ''),
        'uploaded_at' => (string)($row['uploaded_at'] ?? ''),
        'uploaded_by_name' => (string)($row['uploaded_by_name'] ?? ''),
        'kind' => af_photo_kind($row['photo_kind'] ?? 'nurse'),
        'url' => 'allergy_followup_photo.php?id=' . $id,
    ];
}

function af_case_photos($con, $case_id) {
    $case_id = (int)$case_id;
    $photos = [];
    $q = mysqli_query($con, "SELECT * FROM allergy_followup_photos WHERE case_id=$case_id ORDER BY id ASC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $photos[] = af_photo_public($r);
        }
    }
    return $photos;
}

function af_format_case(array $row, array $photos = [], array $events = []) {
    $summary = (string)($row['summary_result'] ?? '');
    $opts = af_summary_options();
    $ch = af_channels();
    $channel = (string)($row['channel'] ?? '');
    $notify = (string)($row['notify_time'] ?? '');
    if (strlen($notify) >= 5) {
        $notify = substr($notify, 0, 5);
    }
    $nurse_photos = array_values(array_filter($photos, function ($p) {
        return af_photo_kind($p['kind'] ?? 'nurse') === 'nurse';
    }));
    $progress_photos = array_values(array_filter($photos, function ($p) {
        return af_photo_kind($p['kind'] ?? '') === 'progress';
    }));
    $base = [
        'id' => (int)$row['id'],
        'case_date' => (string)$row['case_date'],
        'notify_time' => $notify,
        'hn' => (string)$row['hn'],
        'hn_display' => af_hn_display($row['hn'] ?? ''),
        'ptname' => (string)$row['ptname'],
        'ward' => (string)$row['ward'],
        'ward_detail' => (string)($row['ward_detail'] ?? ''),
        'channel' => $channel,
        'channel_label' => $ch[$channel] ?? $channel,
        'reporter_user_id' => (int)($row['reporter_user_id'] ?? 0),
        'reporter_name' => (string)($row['reporter_name'] ?? ''),
        'reporter_ward' => (string)($row['reporter_ward'] ?? ''),
        'owner_user_id' => (int)($row['owner_user_id'] ?? 0),
        'owner_name' => (string)($row['owner_name'] ?? ''),
        'summary_result' => $summary,
        'summary_label' => $opts[$summary] ?? ($summary !== '' ? $summary : 'รอประเมิน'),
        'referral_note' => (string)($row['referral_note'] ?? ''),
        'assessment_detail' => (string)($row['assessment_detail'] ?? ''),
        'allergy_chronology' => af_chronology_decode($row['allergy_chronology'] ?? ''),
        'naranjo_assessment' => af_naranjo_decode($row['naranjo_assessment'] ?? ''),
        'regiscar_assessment' => af_regiscar_decode($row['regiscar_assessment'] ?? ''),
        'assessed_drugs' => af_assessed_drugs_decode($row['assessed_drugs'] ?? ''),
        'assessed_drugs_text' => af_assessed_drugs_short_text($row['assessed_drugs'] ?? ''),
        'is_shift_handover' => af_case_is_shift_handover($row),
        'status' => (string)($row['status'] ?? 'new'),
        'created_at' => (string)($row['created_at'] ?? ''),
        'updated_at' => (string)($row['updated_at'] ?? ''),
        'assessed_at' => (string)($row['assessed_at'] ?? ''),
        'photo_count' => count($nurse_photos),
        'photos' => $nurse_photos,
        'nurse_photos' => $nurse_photos,
        'progress_photos' => $progress_photos,
        'progress_photo_count' => count($progress_photos),
        'source_tag' => (string)($row['source_tag'] ?? ''),
        'hosxp_logged' => !empty($row['hosxp_logged']),
        'hosxp_match' => (string)($row['hosxp_match'] ?? ''),
        'hosxp_agents' => is_array($row['hosxp_agents'] ?? null) ? $row['hosxp_agents'] : [],
        'hosxp_label' => (string)($row['hosxp_label'] ?? ''),
    ];
    $merged = array_merge($base, af_workflow_payload($row, $events));
    $merged['is_shift_handover'] = af_case_is_shift_handover($merged);
    return $merged;
}

function af_case_row($con, $id)
{
    $id = (int)$id;
    if ($id <= 0) {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM allergy_followup_cases WHERE id=$id LIMIT 1");
    return ($q && mysqli_num_rows($q) > 0) ? mysqli_fetch_assoc($q) : null;
}

function af_can_upload_photos(array $case, array $user, $can_assess = false)
{
    if ($can_assess) {
        return true;
    }
    $uid = (int)($user['id'] ?? 0);
    return $uid > 0 && $uid === (int)($case['reporter_user_id'] ?? 0);
}

function af_get_case($con, $id, $with_photos = true) {
    $id = (int)$id;
    $row = af_case_row($con, $id);
    if (!$row) {
        return null;
    }
    $photos = $with_photos ? af_case_photos($con, $id) : [];
    $events = af_attach_assessment_to_events(af_case_events($con, $id), $row);
    $case = af_format_case($row, $photos, $events);
    if ($with_photos) {
        require_once __DIR__ . '/allergy_followup_import_helper.php';
        $arr = af_attach_hosxp_flags($con, [$case]);
        $case = $arr[0] ?? $case;
    }
    if (!function_exists('tham_user_sees_all_wards')) {
        require_once __DIR__ . '/user_unit_helper.php';
    }
    if (!tham_user_sees_all_wards()) {
        $scope = af_user_ward_scope();
        if ($scope === '') {
            return null;
        }
        $visible = af_filter_cases_by_ward_scope($con, [$case], $scope);
        if (!$visible) {
            return null;
        }
        $case = $visible[0];
    }
    return $case;
}

function af_list_cases($con, array $filters = []) {
    if (!empty($filters['force_empty'])) {
        return [];
    }
    $where = ['1=1'];
    $start = trim((string)($filters['start_date'] ?? ''));
    $end = trim((string)($filters['end_date'] ?? ''));
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $start)) {
        $where[] = "case_date >= '" . mysqli_real_escape_string($con, $start) . "'";
    }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
        $where[] = "case_date <= '" . mysqli_real_escape_string($con, $end) . "'";
    }
    $ward = trim((string)($filters['ward'] ?? ''));
    if ($ward !== '') {
        $escw = mysqli_real_escape_string($con, $ward);
        $where[] = "(ward = '$escw' OR ward LIKE CONCAT('%', '$escw', '%'))";
    }
    $summary = $filters['summary_result'] ?? null;
    if ($summary !== null && $summary !== 'all') {
        if ($summary === '' || $summary === 'pending') {
            $where[] = "(summary_result IS NULL OR summary_result = '')";
        } else {
            $where[] = "summary_result = '" . mysqli_real_escape_string($con, (string)$summary) . "'";
        }
    }
    $stage = trim((string)($filters['workflow_stage'] ?? ''));
    if ($stage !== '' && $stage !== 'all') {
        if ($stage === 'reported') {
            $where[] = "(workflow_stage='reported' OR workflow_stage IS NULL OR workflow_stage='')";
        } elseif ($stage === 'shift_handover') {
            $where[] = af_shift_handover_sql_cond($con);
        } else {
            $where[] = "workflow_stage = '" . mysqli_real_escape_string($con, $stage) . "'";
        }
    }
    $qtext = trim((string)($filters['q'] ?? ''));
    if ($qtext !== '') {
        $like = '%' . mysqli_real_escape_string($con, $qtext) . '%';
        $hn_disp = mysqli_real_escape_string($con, af_hn_display($qtext));
        $where[] = "(hn LIKE '$like' OR hn LIKE '%$hn_disp%' OR ptname LIKE '$like' OR ward_detail LIKE '$like' OR owner_name LIKE '$like' OR reporter_name LIKE '$like' OR assessment_detail LIKE '$like')";
    }
    $only_mine = !empty($filters['only_mine']);
    if ($only_mine) {
        $uid = (int)($filters['user_id'] ?? 0);
        $where[] = 'reporter_user_id = ' . $uid;
    }
    if (!empty($filters['exclude_import'])) {
        $where[] = "(IFNULL(import_key,'') = '')";
    }
    $sql = 'SELECT * FROM allergy_followup_cases WHERE ' . implode(' AND ', $where)
        . ' ORDER BY case_date DESC, notify_time DESC, id DESC LIMIT 2000';
    $q = mysqli_query($con, $sql);
    $rows = [];
    $ids = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = $r;
            $ids[] = (int)$r['id'];
        }
    }
    $photos_map = [];
    if (!empty($ids)) {
        $in = implode(',', $ids);
        $qp = mysqli_query($con, "SELECT * FROM allergy_followup_photos WHERE case_id IN ($in) ORDER BY id ASC");
        if ($qp) {
            while ($p = mysqli_fetch_assoc($qp)) {
                $cid = (int)$p['case_id'];
                if (!isset($photos_map[$cid])) {
                    $photos_map[$cid] = [];
                }
                $photos_map[$cid][] = af_photo_public($p);
            }
        }
    }
    $out = [];
    foreach ($rows as $r) {
        $cid = (int)$r['id'];
        $out[] = af_format_case($r, $photos_map[$cid] ?? []);
    }
    require_once __DIR__ . '/allergy_followup_import_helper.php';
    $out = af_attach_hosxp_flags($con, $out);
    $scope = trim((string)($filters['force_ward_scope'] ?? $filters['scope_ward'] ?? ''));
    if ($scope !== '') {
        $out = af_filter_cases_by_ward_scope($con, $out, $scope);
    }
    return $out;
}

function af_save_case($con, array $data, $allow_assess = false) {
    af_ensure_tables($con);
    $id = (int)($data['id'] ?? 0);
    $user = af_current_user();
    $hn = preg_replace('/\s+/', '', (string)($data['hn'] ?? ''));
    $ptname = trim((string)($data['ptname'] ?? ''));
    $ward = trim((string)($data['ward'] ?? ''));
    $ward_detail = trim((string)($data['ward_detail'] ?? ''));
    $channel = trim((string)($data['channel'] ?? 'webapp'));
    if (!isset(af_channels()[$channel])) {
        $channel = 'other';
    }
    $case_date = trim((string)($data['case_date'] ?? date('Y-m-d')));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $case_date)) {
        $case_date = date('Y-m-d');
    }
    $notify_time = trim((string)($data['notify_time'] ?? date('H:i:s')));
    if (preg_match('/^\d{2}:\d{2}$/', $notify_time)) {
        $notify_time .= ':00';
    }
    if (!preg_match('/^\d{2}:\d{2}:\d{2}$/', $notify_time)) {
        $notify_time = date('H:i:s');
    }
    if ($hn === '' && $ptname === '') {
        return ['ok' => false, 'error' => 'กรุณาระบุ HN หรือชื่อผู้ป่วย'];
    }
    if ($hn !== '' && $ptname === '') {
        $pt = af_lookup_patient($con, $hn);
        if ($pt) {
            $ptname = $pt['full_name'];
            $hn = $pt['hn'];
            if ($ward === '') {
                $ward = $pt['ward'];
            }
        }
    }

    $hn_esc = mysqli_real_escape_string($con, $hn);
    $pt_esc = mysqli_real_escape_string($con, $ptname);
    $ward_esc = mysqli_real_escape_string($con, $ward);
    $detail_esc = mysqli_real_escape_string($con, $ward_detail);
    $ch_esc = mysqli_real_escape_string($con, $channel);
    $date_esc = mysqli_real_escape_string($con, $case_date);
    $time_esc = mysqli_real_escape_string($con, $notify_time);

    $owner_id = 0;
    $owner_name = '';
    $summary = '';
    $status = 'new';
    $referral = '';
    $assessment = '';
    $chronology_raw = null; // null = ไม่แตะคอลัมน์
    $naranjo_raw = null;
    $regiscar_raw = null;
    $assessed_drugs_raw = null;
    $assessed_at_sql = 'NULL';
    $assessed_by = 0;
    $cur_stage = 'reported';
    if ($id > 0) {
        $cur = af_get_case($con, $id, false);
        if ($cur) {
            $cur_stage = (string)($cur['workflow_stage'] ?? 'reported');
            $status = (string)($cur['status'] ?? af_status_from_stage($cur_stage));
            $summary = (string)($cur['summary_result'] ?? '');
            $owner_id = (int)($cur['owner_user_id'] ?? 0);
            $owner_name = (string)($cur['owner_name'] ?? '');
            $referral = (string)($cur['referral_note'] ?? '');
            $assessment = (string)($cur['assessment_detail'] ?? '');
        }
    }
    if ($allow_assess) {
        $owner_id = (int)($data['owner_user_id'] ?? $owner_id);
        $owner_name = trim((string)($data['owner_name'] ?? $owner_name));
        if ($owner_name === '' && $owner_id > 0) {
            $qo = mysqli_query($con, "SELECT full_name FROM users WHERE id=$owner_id LIMIT 1");
            $ro = $qo ? mysqli_fetch_assoc($qo) : null;
            $owner_name = trim((string)($ro['full_name'] ?? ''));
        }
        if (array_key_exists('summary_result', $data)) {
            $summary = (string)$data['summary_result'];
            if ($summary !== '' && !isset(af_summary_options()[$summary])) {
                $summary = '';
            }
        }
        $referral = trim((string)($data['referral_note'] ?? $referral));
        $assessment = trim((string)($data['assessment_detail'] ?? $assessment));
        if (array_key_exists('allergy_chronology', $data)) {
            $chronology_raw = $data['allergy_chronology'];
        }
        if (array_key_exists('naranjo_assessment', $data)) {
            $naranjo_raw = $data['naranjo_assessment'];
        }
        if (array_key_exists('regiscar_assessment', $data)) {
            $regiscar_raw = $data['regiscar_assessment'];
        }
        if (array_key_exists('assessed_drugs', $data)) {
            $assessed_drugs_raw = $data['assessed_drugs'];
            if (!af_summary_needs_drugs($summary)) {
                $assessed_drugs_raw = [];
            }
        }
        $status = af_status_from_stage($cur_stage);
        if ($cur_stage !== 'closed' && $summary !== '') {
            $assessed_at_sql = 'NOW()';
            $assessed_by = (int)$user['id'];
        }
    }
    $owner_esc = mysqli_real_escape_string($con, $owner_name);
    $sum_esc = mysqli_real_escape_string($con, $summary);
    $st_esc = mysqli_real_escape_string($con, $status);
    $ref_esc = mysqli_real_escape_string($con, $referral);
    $ass_esc = mysqli_real_escape_string($con, $assessment);
    $chrono_sql = ($allow_assess && $chronology_raw !== null)
        ? af_chronology_sql_fragment($con, $chronology_raw, true)
        : '';
    $naranjo_sql = ($allow_assess && $naranjo_raw !== null)
        ? af_naranjo_sql_fragment($con, $naranjo_raw, true)
        : '';
    $regiscar_sql = ($allow_assess && $regiscar_raw !== null)
        ? af_regiscar_sql_fragment($con, $regiscar_raw, true)
        : '';
    $drugs_sql = ($allow_assess && $assessed_drugs_raw !== null)
        ? af_assessed_drugs_sql_fragment($con, $assessed_drugs_raw, true)
        : '';

    if ($id > 0) {
        $sql = "UPDATE allergy_followup_cases SET
            case_date='$date_esc', notify_time='$time_esc', hn='$hn_esc', ptname='$pt_esc',
            ward='$ward_esc', ward_detail='$detail_esc', channel='$ch_esc'";
        if ($allow_assess) {
            $sql .= ", owner_user_id=$owner_id, owner_name='$owner_esc',
            summary_result='$sum_esc', status='$st_esc',
            referral_note='$ref_esc', assessment_detail='$ass_esc'" . $chrono_sql . $naranjo_sql . $regiscar_sql . $drugs_sql;
            if ($assessed_at_sql !== 'NULL') {
                $sql .= ", assessed_at=$assessed_at_sql, assessed_by=$assessed_by";
            }
        }
        $sql .= " WHERE id=$id";
        $ok = mysqli_query($con, $sql);
        if (!$ok) {
            return ['ok' => false, 'error' => 'บันทึกไม่สำเร็จ'];
        }
        return ['ok' => true, 'id' => $id, 'case' => af_get_case($con, $id)];
    }

    $rep_id = (int)$user['id'];
    $rep_name = mysqli_real_escape_string($con, $user['name']);
    $rep_ward = trim((string)($_SESSION['unit_ward'] ?? ''));
    if ($rep_ward === '' && $rep_id > 0) {
        $uq = @mysqli_query($con, "SELECT unit_ward FROM users WHERE id=$rep_id LIMIT 1");
        $ur = $uq ? mysqli_fetch_assoc($uq) : null;
        $rep_ward = trim((string)($ur['unit_ward'] ?? ''));
    }
    $rep_ward_esc = mysqli_real_escape_string($con, $rep_ward);
    $ok = mysqli_query($con, "INSERT INTO allergy_followup_cases
        (case_date, notify_time, hn, ptname, ward, ward_detail, channel,
         reporter_user_id, reporter_name, reporter_ward, owner_user_id, owner_name,
         summary_result, referral_note, assessment_detail, status, assessed_at, assessed_by, workflow_stage)
        VALUES ('$date_esc', '$time_esc', '$hn_esc', '$pt_esc', '$ward_esc', '$detail_esc', '$ch_esc',
                $rep_id, '$rep_name', '$rep_ward_esc', $owner_id, '$owner_esc',
                '', '$ref_esc', '$ass_esc', 'new', NULL, 0, 'reported')");
    if (!$ok) {
        return ['ok' => false, 'error' => 'สร้างเคสไม่สำเร็จ'];
    }
    $new_id = (int)mysqli_insert_id($con);
    af_log_event($con, $new_id, 'reported', $ward_detail);
    if (!function_exists('tham_alert_notify_allergy_case')) {
        require_once __DIR__ . '/tham_alert_helper.php';
    }
    tham_alert_notify_allergy_case($con, [
        'id' => $new_id,
        'hn' => $hn,
        'ptname' => $ptname,
        'ward' => $ward,
        'ward_detail' => $ward_detail,
        'reporter_name' => $user['name'] ?? '',
    ]);
    return ['ok' => true, 'id' => $new_id, 'case' => af_get_case($con, $new_id)];
}

function af_store_uploaded_files($con, $case_id, array $files, array $user, $kind = 'nurse') {
    $case_id = (int)$case_id;
    if ($case_id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบเคส', 'saved' => 0, 'photos' => []];
    }
    $kind = af_photo_kind($kind);
    $kind_esc = mysqli_real_escape_string($con, $kind);
    $dir = af_upload_dir();
    if (!is_dir($dir) || !is_writable($dir)) {
        return ['ok' => false, 'error' => 'โฟลเดอร์อัปโหลดไม่มีสิทธิ์เขียน', 'saved' => 0, 'photos' => []];
    }
    $allowed = af_allowed_mimes();
    $saved = [];
    $items = af_normalize_files_array($files);
    if (count($items) > 8) {
        $items = array_slice($items, 0, 8);
    }
    $ini_too_big = false;
    $bad_mime = false;
    $write_fail = false;
    foreach ($items as $f) {
        $tmp = $f['tmp_name'] ?? '';
        $err = (int)($f['error'] ?? UPLOAD_ERR_NO_FILE);
        $size = (int)($f['size'] ?? 0);
        $orig = (string)($f['name'] ?? 'photo');
        if ($err === UPLOAD_ERR_NO_FILE || ($tmp === '' && $err === UPLOAD_ERR_OK)) {
            continue;
        }
        if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
            $ini_too_big = true;
            continue;
        }
        if ($err !== UPLOAD_ERR_OK || $tmp === '' || !is_uploaded_file($tmp)) {
            continue;
        }
        if ($size <= 0 || $size > 8 * 1024 * 1024) {
            continue;
        }
        $mime = af_detect_mime($tmp);
        if ($mime === 'image/jpg') {
            $mime = 'image/jpeg';
        }
        if (!isset($allowed[$mime])) {
            $bad_mime = true;
            continue;
        }
        $ext = $allowed[$mime];
        $stored = $case_id . '_' . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $dest = $dir . '/' . $stored;
        if (!@move_uploaded_file($tmp, $dest)) {
            $write_fail = true;
            continue;
        }
        $orig_esc = mysqli_real_escape_string($con, mb_substr($orig, 0, 200, 'UTF-8'));
        $stored_esc = mysqli_real_escape_string($con, $stored);
        $mime_esc = mysqli_real_escape_string($con, $mime);
        $by = (int)$user['id'];
        $by_name = mysqli_real_escape_string($con, $user['name']);
        mysqli_query($con, "INSERT INTO allergy_followup_photos
            (case_id, stored_name, orig_name, mime, file_size, uploaded_by, uploaded_by_name, photo_kind)
            VALUES ($case_id, '$stored_esc', '$orig_esc', '$mime_esc', $size, $by, '$by_name', '$kind_esc')");
        $pid = (int)mysqli_insert_id($con);
        if ($pid > 0) {
            $saved[] = $pid;
        } else {
            @unlink($dest);
            $write_fail = true;
        }
    }
    if (empty($saved)) {
        if ($ini_too_big) {
            $hint = 'ไฟล์ใหญ่เกินขีดจำกัดเซิร์ฟเวอร์ — ระบบจะย่อรูปให้อัตโนมัติ กรุณาลองใหม่อีกครั้ง';
        } elseif ($bad_mime) {
            $hint = 'รองรับเฉพาะ JPG/PNG/WEBP — ถ้าเป็น iPhone ให้ตั้งกล้องเป็น Most Compatible';
        } elseif ($write_fail) {
            $hint = 'บันทึกไฟล์ลงเซิร์ฟเวอร์ไม่สำเร็จ กรุณาติดต่อผู้ดูแลระบบ';
        } else {
            $hint = 'ไม่สามารถบันทึกรูปได้ (รองรับ JPG/PNG/WEBP สูงสุด 8MB)';
        }
        return ['ok' => false, 'error' => $hint, 'saved' => 0, 'photos' => []];
    }
    $hn = '';
    $pt = '';
    $qc = mysqli_query($con, "SELECT hn, ptname FROM allergy_followup_cases WHERE id=$case_id LIMIT 1");
    if ($qc && ($rc = mysqli_fetch_assoc($qc))) {
        $hn = af_hn_display($rc['hn'] ?? '');
        $pt = (string)($rc['ptname'] ?? '');
    }
    if ($kind === 'nurse') {
        $msg = 'พยาบาลแนบรูปแพ้ยา ' . count($saved) . ' ไฟล์ — HN ' . ($hn !== '' ? $hn : '-') . ($pt !== '' ? ' ' . $pt : '');
        $msg_esc = mysqli_real_escape_string($con, mb_substr($msg, 0, 480, 'UTF-8'));
        $photo_id = (int)$saved[0];
        mysqli_query($con, "INSERT INTO allergy_followup_notifications (case_id, photo_id, message)
            VALUES ($case_id, $photo_id, '$msg_esc')");
        af_notify_telegram_photo($con, $case_id, count($saved), $hn, $pt);
    }
    return ['ok' => true, 'saved' => count($saved), 'photos' => af_case_photos($con, $case_id)];
}

function af_normalize_files_array($files) {
    if (!is_array($files)) {
        return [];
    }
    if (isset($files['tmp_name']) && !is_array($files['tmp_name'])) {
        return [$files];
    }
    if (isset($files['tmp_name']) && is_array($files['tmp_name'])) {
        $out = [];
        foreach ($files['tmp_name'] as $i => $tmp) {
            $out[] = [
                'name' => $files['name'][$i] ?? 'photo',
                'type' => $files['type'][$i] ?? '',
                'tmp_name' => $tmp,
                'error' => $files['error'][$i] ?? UPLOAD_ERR_NO_FILE,
                'size' => $files['size'][$i] ?? 0,
            ];
        }
        return $out;
    }
    $out = [];
    foreach ($files as $f) {
        if (is_array($f) && isset($f['tmp_name'])) {
            $out[] = $f;
        }
    }
    return $out;
}

function af_get_photo_row($con, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return null;
    }
    $q = mysqli_query($con, "SELECT * FROM allergy_followup_photos WHERE id=$id LIMIT 1");
    return $q ? mysqli_fetch_assoc($q) : null;
}

function af_delete_photo($con, $id) {
    $row = af_get_photo_row($con, $id);
    if (!$row) {
        return false;
    }
    $path = af_upload_dir() . '/' . basename((string)$row['stored_name']);
    if (is_file($path)) {
        @unlink($path);
    }
    $id = (int)$row['id'];
    return (bool)mysqli_query($con, "DELETE FROM allergy_followup_photos WHERE id=$id");
}

function af_list_notifications($con, $limit = 30, $unread_only = true) {
    $limit = max(1, min(100, (int)$limit));
    $sql = "SELECT n.*, c.hn, c.ptname, c.ward, c.ward_detail
            FROM allergy_followup_notifications n
            LEFT JOIN allergy_followup_cases c ON c.id = n.case_id";
    if ($unread_only) {
        $sql .= " WHERE n.is_read = 0";
    }
    $sql .= " ORDER BY n.id DESC LIMIT $limit";
    $q = mysqli_query($con, $sql);
    $rows = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $rows[] = [
                'id' => (int)$r['id'],
                'case_id' => (int)$r['case_id'],
                'photo_id' => (int)$r['photo_id'],
                'message' => (string)$r['message'],
                'is_read' => (int)$r['is_read'],
                'created_at' => (string)$r['created_at'],
                'hn' => af_hn_display($r['hn'] ?? ''),
                'ptname' => (string)($r['ptname'] ?? ''),
                'ward' => (string)($r['ward'] ?? ''),
                'ward_detail' => (string)($r['ward_detail'] ?? ''),
                'photo_url' => ((int)$r['photo_id'] > 0) ? ('allergy_followup_photo.php?id=' . (int)$r['photo_id']) : '',
                'open_url' => 'allergy_followup.php?open=' . (int)$r['case_id'],
            ];
        }
    }
    return $rows;
}

function af_mark_notifications_read($con, $ids, $user_id) {
    if (!is_array($ids) || empty($ids)) {
        return 0;
    }
    $clean = [];
    foreach ($ids as $id) {
        $id = (int)$id;
        if ($id > 0) {
            $clean[] = $id;
        }
    }
    if (empty($clean)) {
        return 0;
    }
    $user_id = (int)$user_id;
    $in = implode(',', $clean);
    mysqli_query($con, "UPDATE allergy_followup_notifications
        SET is_read=1, read_at=NOW(), read_by=$user_id
        WHERE id IN ($in) AND is_read=0");
    return mysqli_affected_rows($con);
}

function af_mark_all_notifications_read($con, $user_id) {
    $user_id = (int)$user_id;
    mysqli_query($con, "UPDATE allergy_followup_notifications
        SET is_read=1, read_at=NOW(), read_by=$user_id
        WHERE is_read=0");
    return mysqli_affected_rows($con);
}

function af_assess_case($con, array $data) {
    $id = (int)($data['id'] ?? 0);
    if ($id <= 0) {
        return ['ok' => false, 'error' => 'ไม่พบเคส'];
    }
    $cur = af_get_case($con, $id, false);
    if (!$cur) {
        return ['ok' => false, 'error' => 'ไม่พบเคส'];
    }
    $assess = trim((string)($data['assessment_detail'] ?? ''));
    $new_chrono = null;
    $chrono_changed = false;
    if (array_key_exists('allergy_chronology', $data)) {
        $new_chrono = af_normalize_chronology($data['allergy_chronology']);
        $old_chrono = af_normalize_chronology($cur['allergy_chronology'] ?? []);
        $chrono_changed = json_encode($new_chrono, JSON_UNESCAPED_UNICODE) !== json_encode($old_chrono, JSON_UNESCAPED_UNICODE);
        $chrono_txt = af_chronology_to_text($new_chrono);
        $assess = af_upsert_text_block($assess, 'Timeline บันทึกการแพ้ยา:', $chrono_txt);
        $data['assessment_detail'] = $assess;
    }
    $drugs_changed = false;
    $new_drugs = null;
    if (array_key_exists('assessed_drugs', $data)) {
        $sum_tmp = trim((string)($data['summary_result'] ?? $cur['summary_result'] ?? ''));
        $new_drugs = af_summary_needs_drugs($sum_tmp) ? af_normalize_assessed_drugs($data['assessed_drugs']) : [];
        $old_drugs = af_normalize_assessed_drugs($cur['assessed_drugs'] ?? []);
        $drugs_changed = json_encode($new_drugs, JSON_UNESCAPED_UNICODE) !== json_encode($old_drugs, JSON_UNESCAPED_UNICODE);
        $assess = af_upsert_assessed_drugs_block($assess, af_assessed_drugs_to_text($new_drugs));
        $data['assessment_detail'] = $assess;
        $data['assessed_drugs'] = $new_drugs;
    }
    $merged = array_merge($cur, $data);
    $merged['id'] = $id;
    $merged['assessment_detail'] = $assess;
    $res = af_save_case($con, $merged, true);
    if (empty($res['ok'])) {
        return $res;
    }

    // บันทึกลงไทม์ไลน์เมื่อมีรายละเอียดประเมิน / สรุปผล / ส่งต่อ / chronology
    $parts = [];
    $summary = trim((string)($data['summary_result'] ?? ''));
    $referral = trim((string)($data['referral_note'] ?? ''));
    $opts = af_summary_options();
    if ($assess !== '') {
        $parts[] = $assess;
    }
    if ($summary !== '' && isset($opts[$summary]) && $opts[$summary] !== '') {
        $parts[] = 'สรุปผล: ' . $opts[$summary];
    }
    if ($referral !== '') {
        $parts[] = 'ส่งต่อ: ' . $referral;
    }
    if ($new_chrono !== null) {
        $chrono_txt = af_chronology_to_text($new_chrono);
        $joined = implode("\n", $parts);
        $joined = af_upsert_text_block($joined, 'Timeline บันทึกการแพ้ยา:', $chrono_txt);
        $parts = $joined === '' ? [] : [$joined];
    }
    if ($new_drugs !== null) {
        $joined = implode("\n", $parts);
        $joined = af_upsert_assessed_drugs_block($joined, af_assessed_drugs_to_text($new_drugs));
        $parts = $joined === '' ? [] : [$joined];
    }
    $naranjo_changed = false;
    if (array_key_exists('naranjo_assessment', $data)) {
        $new_nar = af_normalize_naranjo($data['naranjo_assessment']);
        $old_nar = af_normalize_naranjo($cur['naranjo_assessment'] ?? null);
        $naranjo_changed = json_encode($new_nar, JSON_UNESCAPED_UNICODE) !== json_encode($old_nar, JSON_UNESCAPED_UNICODE);
        $nar_txt = af_naranjo_to_text($new_nar);
        if ($nar_txt !== '' && strpos(implode("\n", $parts), 'Naranjo:') === false) {
            $parts[] = $nar_txt;
        }
    }
    $regiscar_changed = false;
    if (array_key_exists('regiscar_assessment', $data)) {
        $new_reg = af_normalize_regiscar($data['regiscar_assessment']);
        $old_reg = af_normalize_regiscar($cur['regiscar_assessment'] ?? null);
        $regiscar_changed = json_encode($new_reg, JSON_UNESCAPED_UNICODE) !== json_encode($old_reg, JSON_UNESCAPED_UNICODE);
        $reg_txt = af_regiscar_to_text($new_reg);
        if ($reg_txt !== '' && strpos(implode("\n", $parts), 'RegiSCAR') === false) {
            $parts[] = $reg_txt;
        }
    }
    $prev_assess = trim((string)($cur['assessment_detail'] ?? ''));
    $prev_sum = trim((string)($cur['summary_result'] ?? ''));
    $prev_ref = trim((string)($cur['referral_note'] ?? ''));
    $new_owner = [
        'id' => (int)($data['owner_user_id'] ?? $cur['owner_user_id'] ?? 0),
        'name' => trim((string)($data['owner_name'] ?? $cur['owner_name'] ?? '')),
    ];
    $changed = ($assess !== $prev_assess) || ($summary !== $prev_sum) || ($referral !== $prev_ref) || $chrono_changed || $drugs_changed || $naranjo_changed || $regiscar_changed;
    if ($changed) {
        $note = $parts ? implode("\n", $parts) : 'บันทึกการประเมิน';
        af_log_event($con, $id, 'assessment', $note);
        $res['case'] = af_get_case($con, $id, true);
    }
    if (array_key_exists('owner_user_id', $data) || array_key_exists('owner_name', $data)) {
        $recv_logged = af_log_receiver_change($con, $cur, $new_owner, '');
        if ($recv_logged !== '') {
            af_set_case_receiver($con, $id, $new_owner, false, (string)($cur['workflow_stage'] ?? ''));
        }
        if (!empty($res['ok'])) {
            $res['case'] = af_get_case($con, $id, true);
        }
    }
    return $res;
}

/**
 * เปิดส่ง Telegram ติดตามแพ้ยาเมื่อมีกฎแจ้งเตือนโมดูล allergy_followup ที่เปิดอยู่
 * (ตั้งที่ Smart Pharma → แจ้งเตือน Alert → กฎแจ้งเตือน)
 */
function af_telegram_notify_enabled($con) {
    $dests = af_telegram_rule_destinations($con);
    return !empty($dests);
}

/** @deprecated ใช้กฎแจ้งเตือนแทน — คงไว้ให้ API เก่าไม่พัง */
function af_set_telegram_notify($con, $enabled) {
    $val = $enabled ? '1' : '0';
    $q = mysqli_query($con, "SELECT config_name FROM sys_config WHERE config_name='af_telegram_notify' LIMIT 1");
    if ($q && mysqli_num_rows($q) > 0) {
        mysqli_query($con, "UPDATE sys_config SET config_value='$val' WHERE config_name='af_telegram_notify'");
    } else {
        mysqli_query($con, "INSERT INTO sys_config (config_name, config_value) VALUES ('af_telegram_notify', '$val')");
    }
}

/** ปลายทาง Telegram จากกฎโมดูล allergy_followup (dedupe ตาม chat_id จริง) */
function af_telegram_rule_destinations($con) {
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $cache = [];
    $tg_helper = __DIR__ . '/smart_pharma_telegram_helper.php';
    $nt_helper = __DIR__ . '/smart_pharma_notifications_helper.php';
    if (!is_file($tg_helper)) {
        return $cache;
    }
    require_once $tg_helper;
    if (is_file($nt_helper)) {
        require_once $nt_helper;
    }
    if (function_exists('sp_notifications_get_config')) {
        $cfg = sp_notifications_get_config($con);
        if (empty($cfg['telegram_enabled'])) {
            return $cache;
        }
    }
    if (!function_exists('sp_telegram_list_rules')) {
        return $cache;
    }
    foreach (sp_telegram_list_rules($con) as $r) {
        if (trim((string)($r['module_key'] ?? '')) !== 'allergy_followup') {
            continue;
        }
        if (empty($r['active']) || empty($r['chat_active'])) {
            continue;
        }
        $tg_chat = trim((string)($r['telegram_chat_id'] ?? ''));
        if ($tg_chat === '') {
            continue;
        }
        $token = function_exists('sp_telegram_resolve_bot_token') ? sp_telegram_resolve_bot_token($r) : '';
        if ($token === '') {
            continue;
        }
        $ptype = in_array(($r['patient_type'] ?? ''), ['OPD', 'IPD'], true) ? $r['patient_type'] : 'OPD';
        if (!isset($cache[$tg_chat])) {
            $cache[$tg_chat] = [
                'chat_id' => $tg_chat,
                'bot_token' => $token,
                'patient_type' => $ptype,
                'chat_label' => (string)($r['chat_label'] ?? ''),
            ];
        }
    }
    return $cache;
}

function af_notify_telegram_photo($con, $case_id, $photo_count, $hn, $ptname) {
    $dests = af_telegram_rule_destinations($con);
    if (empty($dests)) {
        return;
    }
    $tg_helper = __DIR__ . '/smart_pharma_telegram_helper.php';
    $nt_helper = __DIR__ . '/smart_pharma_notifications_helper.php';
    require_once $tg_helper;
    if (is_file($nt_helper)) {
        require_once $nt_helper;
    }
    if (!function_exists('sp_telegram_api_send')) {
        return;
    }
    if (is_file(__DIR__ . '/smart_pharma_notify_helper.php')) {
        require_once __DIR__ . '/smart_pharma_notify_helper.php';
    }
    $cfg = function_exists('sp_notifications_get_config') ? sp_notifications_get_config($con) : [];
    $base = rtrim((string)($cfg['base_url'] ?? ''), '/');
    $link = $base !== '' ? ($base . '/allergy_followup.php?open=' . (int)$case_id) : ('allergy_followup.php?open=' . (int)$case_id);
    $text = "<b>ติดตามการแพ้ยา</b>\n"
        . "พยาบาลแนบรูป " . (int)$photo_count . " ไฟล์\n"
        . "HN: " . htmlspecialchars($hn !== '' ? $hn : '-', ENT_QUOTES, 'UTF-8') . "\n"
        . "ผู้ป่วย: " . htmlspecialchars($ptname !== '' ? $ptname : '-', ENT_QUOTES, 'UTF-8') . "\n"
        . "<a href=\"" . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . "\">เปิดเคส</a>";
    $screen_date = date('Y-m-d');
    $hn_save = preg_replace('/\D+/', '', (string)$hn);
    if ($hn_save === '') {
        $hn_save = trim((string)$hn);
    }
    $batch = date('YmdHis') . '-' . substr(uniqid('', true), -6);
    foreach ($dests as $dest) {
        $token = (string)($dest['bot_token'] ?? '');
        $chat_id = trim((string)($dest['chat_id'] ?? ''));
        if ($token === '' || $chat_id === '') {
            continue;
        }
        $ok = @sp_telegram_api_send($token, $chat_id, $text);
        $sent_ok = is_array($ok) ? !empty($ok['ok']) : (bool)$ok;
        if ($sent_ok && function_exists('sp_notify_mark_sent')) {
            $dedupe = implode('|', [
                'AF',
                'allergy_followup',
                (string)(int)$case_id,
                $batch,
                $chat_id,
            ]);
            $ptype = in_array(($dest['patient_type'] ?? ''), ['OPD', 'IPD'], true) ? $dest['patient_type'] : 'OPD';
            sp_notify_mark_sent(
                $con,
                'smart_pharma_telegram_sent',
                $dedupe,
                $ptype,
                $screen_date,
                $hn_save,
                'allergy_followup',
                'hard',
                $chat_id,
                'chat_id'
            );
        }
    }
}
