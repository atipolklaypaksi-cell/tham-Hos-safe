<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

include('connect.php');
require_once __DIR__ . '/menu_permissions_helper.php';
require_once __DIR__ . '/hospital_ds_helper.php';
require_once __DIR__ . '/med_reconcile_discharge_helper.php';

if (empty($_SESSION['menu_permissions_loaded'])) {
    tham_menu_load_session_permissions($con, (int)$_SESSION['user_id'], $_SESSION['role'] ?? '');
}
session_write_close();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_GET;
}
$action = trim((string)($input['action'] ?? 'lookup'));

if ($action === 'get_settings') {
    $settings = mrd_load_settings($con);
    echo json_encode([
        'status' => 'success',
        'settings' => $settings,
        'defaults' => mrd_default_settings(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_settings') {
    $settings = $input['settings'] ?? [];
    if (!is_array($settings)) {
        $settings = [];
    }
    $user = (string)($_SESSION['username'] ?? $_SESSION['user_id'] ?? '');
    $ok = mrd_save_settings($con, $settings, $user);
    if (!$ok) {
        echo json_encode(['status' => 'error', 'message' => 'บันทึกตั้งค่าไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode([
        'status' => 'success',
        'settings' => mrd_load_settings($con),
        'message' => 'บันทึกตั้งค่าแล้ว',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$con_hosxp = function_exists('hosxp_connect') ? @hosxp_connect($con, 20) : null;
if (!$con_hosxp) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถเชื่อมต่อ HOSxP ได้'], JSON_UNESCAPED_UNICODE);
    exit;
}
@mysqli_set_charset($con_hosxp, 'utf8');

if ($action === 'lookup') {
    $hn = trim((string)($input['hn'] ?? ''));
    $prefer_an = trim((string)($input['an'] ?? ''));
    if ($hn === '') {
        mysqli_close($con_hosxp);
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ HN'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $patient = mrd_fetch_patient($con_hosxp, $hn, $prefer_an);
    if (!$patient) {
        mysqli_close($con_hosxp);
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบผู้ป่วยใน HOSxP'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // ดึง Visit ทั้งหมด แล้วแยก: IPD สำหรับ AN / Visit สำหรับเลือกก่อน Admit
    $all_visits = mrd_fetch_visits($con_hosxp, $patient['hn'], 80, false);
    $ipd_visits = array_values(array_filter($all_visits, function ($v) {
        return ($v['visit_type'] ?? '') === 'ipd';
    }));
    // ถ้ายังไม่มี AN จาก patient แต่มี IPD ในรายการ — ใช้ AN ล่าสุดก่อนกรอง Visit
    if (empty($patient['an']) && $ipd_visits) {
        $patient = mrd_fetch_patient($con_hosxp, $patient['hn'], $ipd_visits[0]['an'] ?? '');
    }
    // Visit สำหรับเลือกก่อน Admit:
    // - OPD ที่มีรายการยา
    // - IPD ที่มี HME (ไม่รวม AN ที่กำลังเทียบอยู่)
    $current_an = trim((string)($patient['an'] ?? ''));
    $visits = array_values(array_filter($all_visits, function ($v) use ($current_an) {
        $type = $v['visit_type'] ?? '';
        if ($type === 'opd') {
            return (int)($v['drug_count'] ?? 0) > 0;
        }
        if ($type === 'ipd') {
            if ($current_an !== '' && (string)($v['an'] ?? '') === $current_an) {
                return false;
            }
            return (int)($v['hme_count'] ?? 0) > 0;
        }
        return false;
    }));
    $visits = array_slice($visits, 0, 50);
    $hosxp_recon = [];
    if (!empty($patient['an'])) {
        $hosxp_recon = mrd_fetch_hosxp_medrecon($con_hosxp, $patient['an']);
    }
    $smart_medrecon = mrd_fetch_smart_medrecon_history($con, $patient['hn'] ?? $hn);

    // ค่าเริ่มต้น Visit ก่อน Admit = OPD ล่าสุดก่อนวัน admit ถ้าไม่มีใช้ IPD HME ล่าสุด
    $default_keys = [];
    $admit_iso = $patient['admit_date'] ?? '';
    foreach ($visits as $v) {
        if (($v['visit_type'] ?? '') !== 'opd') {
            continue;
        }
        if ($admit_iso !== '' && ($v['vstdate_iso'] ?? '') >= $admit_iso) {
            continue;
        }
        $default_keys[] = $v['visit_key'];
        break;
    }
    if (!$default_keys) {
        foreach ($visits as $v) {
            if ($admit_iso !== '' && ($v['vstdate_iso'] ?? '') >= $admit_iso) {
                continue;
            }
            $default_keys[] = $v['visit_key'];
            break;
        }
    }

    mysqli_close($con_hosxp);
    echo json_encode([
        'status' => 'success',
        'patient' => $patient,
        'visits' => $visits,
        'ipd_visits' => $ipd_visits,
        'default_visit_keys' => $default_keys,
        'hosxp_medrecon' => $hosxp_recon,
        'hosxp_medrecon_count' => count($hosxp_recon),
        'smart_medrecon' => $smart_medrecon,
        'smart_medrecon_count' => count($smart_medrecon),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'compare') {
    $hn = trim((string)($input['hn'] ?? ''));
    $an = trim((string)($input['an'] ?? ''));
    $visit_keys = $input['visit_keys'] ?? [];
    if (!is_array($visit_keys)) {
        $visit_keys = [];
    }
    $visit_keys = array_values(array_filter(array_map('strval', $visit_keys)));
    $smart_rows = $input['smart_recon_rows'] ?? null;
    $prefer_smart = !empty($input['prefer_smart_recon']);
    $prefer_hosxp = !empty($input['prefer_hosxp_recon']);

    if ($hn === '') {
        mysqli_close($con_hosxp);
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ HN'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $patient = mrd_fetch_patient($con_hosxp, $hn, $an);
    if (!$patient) {
        mysqli_close($con_hosxp);
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบผู้ป่วย'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($an === '') {
        $an = $patient['an'] ?? '';
    }
    // ถ้ายังว่าง — ใช้ IPD ล่าสุดจาก visit list
    if ($an === '') {
        $visits = mrd_fetch_visits($con_hosxp, $patient['hn'], 20);
        foreach ($visits as $v) {
            if (($v['visit_type'] ?? '') === 'ipd' && !empty($v['an'])) {
                $an = $v['an'];
                $patient = mrd_fetch_patient($con_hosxp, $patient['hn'], $an);
                break;
            }
        }
    }

    $use_visits = count($visit_keys) > 0;
    $explicit = $prefer_smart || $prefer_hosxp || $use_visits;
    $pre_parts = [];
    $pre_labels = [];
    if ($prefer_smart && is_array($smart_rows) && count($smart_rows) > 0) {
        $smart_pre = mrd_normalize_client_rows($smart_rows);
        if ($smart_pre) {
            $pre_parts[] = $smart_pre;
            $pre_labels[] = 'smart_drug_medrecon';
        }
    }
    if ($prefer_hosxp && $an !== '') {
        $hosxp_pre = mrd_fetch_hosxp_medrecon($con_hosxp, $an);
        if ($hosxp_pre) {
            $pre_parts[] = $hosxp_pre;
            $pre_labels[] = 'hosxp_medrecon';
        }
    }
    if ($use_visits) {
        $visit_pre = mrd_fetch_drugs_by_visit_keys($con_hosxp, $visit_keys);
        if ($visit_pre) {
            $pre_parts[] = $visit_pre;
            $pre_labels[] = 'visit';
        }
    }
    if (!$explicit) {
        if (is_array($smart_rows) && count($smart_rows) > 0) {
            $smart_pre = mrd_normalize_client_rows($smart_rows);
            if ($smart_pre) {
                $pre_parts[] = $smart_pre;
                $pre_labels[] = 'smart_drug_medrecon';
            }
        }
        if (!$pre_parts && $an !== '') {
            $hosxp_pre = mrd_fetch_hosxp_medrecon($con_hosxp, $an);
            if ($hosxp_pre) {
                $pre_parts[] = $hosxp_pre;
                $pre_labels[] = 'hosxp_medrecon';
            }
        }
    }
    $pre = mrd_merge_pre_prefer_earlier($pre_parts);
    $pre_source = $pre_labels ? implode('+', $pre_labels) : 'visit';

    $admit = $an !== '' ? mrd_fetch_admit_drugs($con_hosxp, $an) : [];
    $hme = $an !== '' ? mrd_fetch_hme_drugs($con_hosxp, $an) : [];
    $settings = mrd_load_settings($con);
    $built = mrd_build_three_way($pre, $admit, $hme, $settings);
    $bch = $an !== '' ? mrd_latest_bch_order($con_hosxp, $an) : null;
    $irx = $an !== '' ? mrd_latest_irx_order($con_hosxp, $an) : null;
    $admit_source = 'none';
    if ($bch && $irx) {
        $admit_source = 'bch_irx';
    } elseif ($bch) {
        $admit_source = 'bch';
    } elseif ($irx) {
        $admit_source = 'irx';
    } elseif ($admit) {
        $lbl = (string)($admit[0]['source_label'] ?? '');
        $admit_source = (stripos($lbl, 'Medplan') !== false) ? 'medplan' : 'opitemrece';
    }

    mysqli_close($con_hosxp);
    echo json_encode([
        'status' => 'success',
        'patient' => $patient,
        'an' => $an,
        'bch_order' => $bch,
        'irx_order' => $irx,
        'admit_source' => $admit_source,
        'pre_source' => $pre_source,
        'pre' => $pre,
        'admit' => $admit,
        'hme' => $hme,
        'rows' => $built['rows'],
        'summary' => $built['summary'],
        'visit_keys' => $visit_keys,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

mysqli_close($con_hosxp);
echo json_encode(['status' => 'error', 'message' => 'unknown action'], JSON_UNESCAPED_UNICODE);
