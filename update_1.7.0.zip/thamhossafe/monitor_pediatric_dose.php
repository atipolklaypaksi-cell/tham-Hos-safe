<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php');
    exit;
}
include('connect.php');
include('pediatric_dose_helper.php');
mysqli_set_charset($con, 'utf8');

pdc_ensure_table($con);

$focus_hn = trim((string)($_GET['hn'] ?? $_GET['filter_hn'] ?? ''));
$focus_date = trim((string)($_GET['date'] ?? ''));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $focus_date)) {
    $focus_date = '';
}

if (isset($_GET['tab']) && $_GET['tab'] === 'settings') {
    header('Location: pediatric_dose_calculator.php?tab=settings');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_tolerance') {
    $saved = pdc_save_monitor_tolerance_pct($con, $_POST['tolerance_pct'] ?? pdc_default_tolerance_pct());
    $_SESSION['pdc_mon_msg'] = 'บันทึกคลาดเคลื่อนที่ยอมรับได้ ±' . pdc_fmt($saved, 1) . '% เรียบร้อย';
    $redir = 'monitor_pediatric_dose.php';
    $keep_hn = trim((string)($_POST['keep_hn'] ?? $_GET['hn'] ?? ''));
    $keep_date = trim((string)($_POST['keep_date'] ?? $_GET['date'] ?? ''));
    $qs = [];
    if ($keep_hn !== '') {
        $qs[] = 'hn=' . rawurlencode($keep_hn);
    }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $keep_date)) {
        $qs[] = 'date=' . rawurlencode($keep_date);
    }
    if ($qs) {
        $redir .= '?' . implode('&', $qs);
    }
    header('Location: ' . $redir);
    exit;
}

$default_start = date('Y-m-d', strtotime('-3 days'));
$default_end = date('Y-m-d');
if ($focus_date !== '') {
    $default_start = $focus_date;
    $default_end = $focus_date;
}
$tol_pct = pdc_get_monitor_tolerance_pct($con);
$flash_msg = $_SESSION['pdc_mon_msg'] ?? '';
unset($_SESSION['pdc_mon_msg']);

$monitor_rules = pdc_load_monitor_rules($con, []);

session_write_close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Monitor ยาเด็ก - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <link href="css/flatpickr.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', Tahoma, sans-serif; background-color: #f4f7f6; }
        .filter-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; }
        .section-hard .table thead { background-color: #dc3545 !important; color: #fff !important; }
        .section-soft .table thead { background-color: #fd7e14 !important; color: #fff !important; }
        .section-pass .table thead { background-color: #198754 !important; color: #fff !important; }
        .section-unverifiable .table thead { background-color: #6c757d !important; color: #fff !important; }
        .pdc-range-btn.active { background-color: #db2777 !important; border-color: #db2777 !important; color: #fff !important; }
        .pdc-mismatch { background: #fee2e2; border-left: 3px solid #dc3545; padding: 4px 8px; border-radius: 4px; font-weight: 600; }
        .pdc-ok { background: #dcfce7; border-left: 3px solid #198754; padding: 4px 8px; border-radius: 4px; font-weight: 600; }
        .pdc-dir-high { background: #dc3545; color: #fff; font-size: 0.72rem; letter-spacing: 0.02em; }
        .pdc-dir-low { background: #0d6efd; color: #fff; font-size: 0.72rem; letter-spacing: 0.02em; }
        .pdc-dose-high { background: #fff5f5; }
        .pdc-dose-low { background: #eff6ff; }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include('sidebar.php'); ?>
    <div id="content" class="content">
        <div class="container-fluid py-4">
            <h4 class="fw-bold mb-2 text-dark">
                <i class="fas fa-child me-2" style="color:#db2777;"></i>
                Monitor ยาเด็ก
            </h4>
            <p class="text-muted small mb-3">
                ตรวจขนาดยาในเด็ก (mg/kg × น้ำหนัก) จากใบยา OPD/IPD โดยใช้รายการยาที่ตั้งใน
                <a href="pediatric_dose_calculator.php?tab=settings" class="fw-bold">คำนวณขนาดยาในเด็ก</a>
                — ยอมคลาดเคลื่อนจากช่วงที่ควรได้: ตั้งค่าทั้งระบบด้านล่าง (ค่าเริ่มต้น ±20%) หรือกำหนด ±% ต่อรายการยาใน
                <a href="pediatric_dose_calculator.php?tab=settings" class="fw-bold">ตั้งค่ารายการยา</a>
                <span class="ms-2">
                    <span class="badge pdc-dir-high"><i class="fas fa-arrow-up"></i> High</span> สูงเกิน
                    <span class="badge pdc-dir-low ms-1"><i class="fas fa-arrow-down"></i> Low</span> ต่ำเกิน
                </span>
            </p>

            <?php if ($flash_msg): ?>
            <div class="alert alert-success alert-dismissible fade show"><?php echo htmlspecialchars($flash_msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <div class="bg-white border p-4 rounded shadow-sm">
                    <div class="filter-box p-3 mb-3">
                        <h6 class="fw-bold text-secondary mb-3"><i class="fas fa-filter me-2"></i>ตัวกรองรายงาน</h6>
                        <div class="row g-2 align-items-end">
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">วันที่สั่งยา ตั้งแต่</label>
                                <input type="text" id="filter_start" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_start); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">ถึงวันที่</label>
                                <input type="text" id="filter_end" class="form-control form-control-sm bg-white" value="<?php echo htmlspecialchars($default_end); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-1">HN (ไม่บังคับ)</label>
                                <input type="text" id="filter_hn" name="filter_hn" class="form-control form-control-sm bg-white" placeholder="ทุก HN" autocomplete="off" value="<?php echo htmlspecialchars($focus_hn); ?>">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-sm fw-bold text-white w-100 shadow-sm" style="background:#db2777;" id="btnFetchPdcMon" onclick="fetchPdcMonData()">
                                    <i class="fas fa-sync-alt me-1"></i> ประมวลผล
                                </button>
                            </div>
                            <div class="col-md-3">
                                <form method="post" class="d-flex align-items-end gap-1" id="pdcTolForm">
                                    <input type="hidden" name="action" value="save_tolerance">
                                    <input type="hidden" name="keep_hn" value="<?php echo htmlspecialchars($focus_hn); ?>">
                                    <input type="hidden" name="keep_date" value="<?php echo htmlspecialchars($focus_date); ?>">
                                    <div class="flex-grow-1">
                                        <label class="form-label small fw-bold mb-1" for="tolerance_pct">ยอมคลาดเคลื่อน ± (ทั้งระบบ)</label>
                                        <div class="input-group input-group-sm">
                                            <input type="number" name="tolerance_pct" id="tolerance_pct" class="form-control bg-white" min="0" max="100" step="1" value="<?php echo htmlspecialchars(pdc_fmt($tol_pct, 1)); ?>">
                                            <span class="input-group-text">%</span>
                                            <button type="submit" class="btn btn-outline-secondary fw-bold" title="บันทึกค่านี้ไว้ใช้ครั้งถัดไป">บันทึก</button>
                                        </div>
                                    </div>
                                </form>
                                <div class="form-text small mb-0">ค่าเริ่มต้น 20% — เกิน/ต่ำกว่าช่วงที่ควรได้ไม่เกินนี้ถือว่าผ่าน</div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-check mt-1">
                                    <input class="form-check-input" type="checkbox" id="filter_kids_only" checked>
                                    <label class="form-check-label small fw-bold" for="filter_kids_only">
                                        เฉพาะเด็ก (อายุ ≤ 15 ปี)
                                    </label>
                                    <div class="form-text small mb-0">ถ้าไม่มีวันเกิด จะตัดน้ำหนัก &gt; 40 kg</div>
                                </div>
                            </div>
                        </div>
                        <div class="row g-2 mt-2 align-items-center">
                            <div class="col-auto"><label class="form-label small fw-bold mb-0 text-secondary">ช่วงเร็ว:</label></div>
                            <div class="col">
                                <div class="btn-group btn-group-sm flex-wrap">
                                    <button type="button" class="btn btn-outline-secondary fw-bold pdc-range-btn" data-days="1" onclick="setPdcMonDateRange(1)">วันนี้</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold pdc-range-btn<?php echo $focus_date === '' ? ' active' : ''; ?>" data-days="3" onclick="setPdcMonDateRange(3)">3 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold pdc-range-btn" data-days="7" onclick="setPdcMonDateRange(7)">7 วัน</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold pdc-range-btn" data-days="30" onclick="setPdcMonDateRange(30)">30 วัน</button>
                                </div>
                            </div>
                        </div>
                        <div id="hnFocusBanner" class="alert alert-warning py-2 px-3 mt-2 mb-0 small fw-bold<?php echo $focus_hn === '' ? ' d-none' : ''; ?>">
                            <?php if ($focus_hn !== ''): ?>
                            <i class="fas fa-link me-1"></i> เปิดจาก Smart Pharma · HN <b><?php echo htmlspecialchars($focus_hn); ?></b><?php echo $focus_date !== '' ? ' · วันที่ ' . htmlspecialchars($focus_date) : ''; ?>
                            <a href="monitor_pediatric_dose.php" class="ms-2">ดูทุก HN</a>
                            <?php endif; ?>
                        </div>
                        <div id="reportMeta" class="alert alert-info py-2 px-3 mt-2 mb-0 small fw-bold d-none"></div>
                    </div>

                    <div class="border rounded p-3 mb-3" id="pdcRuleFilterBox">
                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                            <label class="form-label fw-bold small mb-0">
                                <i class="fas fa-filter me-1 text-danger"></i> เลือกยาที่ต้องการรายงาน
                                <span class="text-muted fw-normal">(ดึงจากคำนวณขนาดยาในเด็ก)</span>
                            </label>
                            <div class="d-flex flex-wrap gap-2">
                                <a href="pediatric_dose_calculator.php?tab=settings" class="btn btn-sm btn-outline-danger fw-bold">
                                    <i class="fas fa-cogs me-1"></i> ตั้งค่ารายการยา
                                </a>
                                <div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-outline-primary fw-bold" onclick="pdcMonSelectAllRules(true)">เลือกทั้งหมด</button>
                                    <button type="button" class="btn btn-outline-secondary fw-bold" onclick="pdcMonSelectAllRules(false)">ยกเลิกทั้งหมด</button>
                                </div>
                            </div>
                        </div>
                        <div class="mb-2">
                            <input type="text" id="pdcRuleSearch" class="form-control form-control-sm" placeholder="ค้นหายาในรายการ...">
                            <div class="form-text small">ระบบตรวจทีละยาพร้อมกันหลายรายการ — ย่อช่วงวันที่ถ้ายังช้า</div>
                        </div>
                        <?php if (empty($monitor_rules)): ?>
                        <div class="small text-muted">ยังไม่มีรายการยาที่เปิดใช้งาน — ไปตั้งค่าที่
                            <a href="pediatric_dose_calculator.php?tab=settings" class="fw-bold">คำนวณขนาดยาในเด็ก → ตั้งค่ารายการยา</a>
                        </div>
                        <?php else: ?>
                        <div class="row g-2">
                            <?php foreach ($monitor_rules as $mr):
                                $cat = $mr['category'] ?? 'oral';
                                $cat_badge = $cat === 'inject'
                                    ? '<span class="badge bg-secondary ms-1">ยาฉีด</span>'
                                    : ($cat === 'other'
                                        ? '<span class="badge bg-dark ms-1">อื่น ๆ</span>'
                                        : '<span class="badge bg-info text-dark ms-1">ยาน้ำ</span>');
                                $kg = pdc_fmt_range($mr['mg_per_kg_min'] ?? null, $mr['mg_per_kg_max'] ?? null);
                                $unit = pdc_unit_label($mr['dose_unit'] ?? '');
                            ?>
                            <div class="col-md-6 col-xl-4 pdc-rule-item">
                                <div class="form-check border rounded px-2 py-1 bg-white h-100">
                                    <input class="form-check-input pdc-rule-cb" type="checkbox" value="<?php echo (int)$mr['id']; ?>"
                                           id="pdc_rule_cb_<?php echo (int)$mr['id']; ?>" checked>
                                    <label class="form-check-label small" for="pdc_rule_cb_<?php echo (int)$mr['id']; ?>">
                                        <span class="fw-bold text-dark"><?php echo htmlspecialchars($mr['drug_name']); ?></span>
                                        <?php if (!empty($mr['icode'])): ?>
                                        <small class="text-muted">(<?php echo htmlspecialchars($mr['icode']); ?>)</small>
                                        <?php endif; ?>
                                        <?php echo $cat_badge; ?>
                                        <?php if ($kg !== '' && $kg !== '—'): ?>
                                        <br><small class="text-primary"><?php echo htmlspecialchars($kg . ' ' . $unit); ?></small>
                                        <?php endif; ?>
                                        <?php if (isset($mr['tolerance_pct']) && $mr['tolerance_pct'] !== null && $mr['tolerance_pct'] !== ''): ?>
                                        <br><small class="text-secondary">±<?php echo htmlspecialchars(pdc_fmt($mr['tolerance_pct'], 1)); ?>%</small>
                                        <?php endif; ?>
                                    </label>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php
                    $thead = '<th>HN</th><th>OPD/IPD</th><th class="text-start">ชื่อ-สกุล</th>'
                        . '<th>อายุ</th><th>วันที่สั่ง</th><th class="text-start">ยา</th>'
                        . '<th class="text-start">ความแรง</th><th class="text-start">วิธีใช้</th><th>BW</th>'
                        . '<th>mg/วัน</th><th>mg/kg/วัน</th><th title="Low / High dose">↑↓</th><th>ช่วงที่ควรได้</th>'
                        . '<th>หอผู้ป่วย</th><th class="text-start">ข้อความ</th>';
                    $colspan = 15;
                    ?>

                    <div class="section-hard mb-4">
                        <h6 class="fw-bold text-danger mb-2"><i class="fas fa-exclamation-circle me-2"></i>Hard Alert <span id="hardCount" class="badge bg-danger">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small"><tr><?php echo $thead; ?></tr></thead>
                                <tbody id="hardTbody"><tr><td colspan="<?php echo $colspan; ?>" class="text-center py-4 text-muted">กดปุ่มประมวลผลเพื่อดึงข้อมูล</td></tr></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="section-soft mb-2">
                        <h6 class="fw-bold text-warning mb-2"><i class="fas fa-exclamation-triangle me-2"></i>Soft Alert <span id="softCount" class="badge bg-warning text-dark">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small"><tr><?php echo $thead; ?></tr></thead>
                                <tbody id="softTbody"><tr><td colspan="<?php echo $colspan; ?>" class="text-center py-4 text-muted">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="section-unverifiable mb-4">
                        <h6 class="fw-bold text-secondary mb-2"><i class="fas fa-question-circle me-2"></i>ตรวจสอบไม่ได้ <span id="unverifiableCount" class="badge bg-secondary">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small"><tr><?php echo $thead; ?></tr></thead>
                                <tbody id="unverifiableTbody"><tr><td colspan="<?php echo $colspan; ?>" class="text-center py-4 text-muted">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="section-pass mt-4">
                        <h6 class="fw-bold text-success mb-2"><i class="fas fa-check-circle me-2"></i>รายการผ่าน <span id="passCount" class="badge bg-success">0</span></h6>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border mb-0">
                                <thead class="text-center small"><tr><?php echo $thead; ?></tr></thead>
                                <tbody id="passTbody"><tr><td colspan="<?php echo $colspan; ?>" class="text-center py-4 text-muted">—</td></tr></tbody>
                            </table>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/monitor_hn_filter.js?v=20260924pdc2"></script>
<script src="js/flatpickr.min.js"></script>
<script>
let fpStart, fpEnd;
const PDC_COLSPAN = 15;
const PDC_FOCUS_HN = <?php echo json_encode($focus_hn, JSON_UNESCAPED_UNICODE); ?>;

function pdcDoseDirBadge(item) {
    const d = item.dose_direction;
    if (d === 'high') {
        return '<span class="badge pdc-dir-high" title="High dose — สูงเกินช่วง"><i class="fas fa-arrow-up me-1"></i>High</span>';
    }
    if (d === 'low') {
        return '<span class="badge pdc-dir-low" title="Low dose — ต่ำกว่าช่วง"><i class="fas fa-arrow-down me-1"></i>Low</span>';
    }
    return '<span class="text-muted">—</span>';
}

function pdcEsc(s) {
    if (s == null) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

$(function() {
    if (typeof flatpickr !== 'undefined') {
        fpStart = flatpickr('#filter_start', { dateFormat: 'Y-m-d' });
        fpEnd = flatpickr('#filter_end', { dateFormat: 'Y-m-d' });
    }
    const urlDate = (typeof monitorUrlParam === 'function') ? monitorUrlParam('date') : '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(urlDate)) {
        $('.pdc-range-btn').removeClass('active');
    }
    const hnInput = document.getElementById('filter_hn');
    if (hnInput && PDC_FOCUS_HN && !String(hnInput.value || '').trim()) {
        hnInput.value = PDC_FOCUS_HN;
    }
    monitorInitHnFilter({
        clearHref: 'monitor_pediatric_dose.php',
        fetchFn: fetchPdcMonData,
        autofetch: fetchPdcMonData
    });
    if (hnInput && PDC_FOCUS_HN && !String(hnInput.value || '').trim()) {
        hnInput.value = PDC_FOCUS_HN;
    }
});

function pdcMonSelectAllRules(on) {
    $('.pdc-rule-cb').prop('checked', !!on);
}

$(document).on('input', '#pdcRuleSearch', function() {
    const q = (($(this).val() || '') + '').toLowerCase();
    $('.pdc-rule-item').each(function() {
        const t = (($(this).text() || '') + '').toLowerCase();
        $(this).toggle(!q || t.indexOf(q) !== -1);
    });
});

function pdcFriendlyFetchError(text, status) {
    const raw = String(text || '');
    if (status === 504 || /504|Gateway Time-out/i.test(raw)) {
        return 'ประมวลผลนานเกินกำหนด (504) — ลองย่อช่วงวันที่ หรือเลือกยาน้อยลง แล้วกดประมวลผลอีกครั้ง';
    }
    if (status === 502 || /Bad Gateway/i.test(raw)) {
        return 'เซิร์ฟเวอร์ไม่ตอบ (502) — ลองใหม่ในอีกสักครู่';
    }
    const stripped = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    return (stripped || ('HTTP ' + status)).substring(0, 240);
}

function setPdcMonDateRange(days) {
    const end = new Date();
    const start = new Date();
    if (days <= 1) {
        start.setHours(0,0,0,0);
    } else {
        start.setDate(end.getDate() - (days - 1));
    }
    const fmt = d => d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    if (fpStart) fpStart.setDate(fmt(start), true); else $('#filter_start').val(fmt(start));
    if (fpEnd) fpEnd.setDate(fmt(end), true); else $('#filter_end').val(fmt(end));
    $('.pdc-range-btn').removeClass('active');
    $('.pdc-range-btn[data-days="' + days + '"]').addClass('active');
}

function renderPdcMonRow(item, kind) {
    const when = item.order_time
        ? item.order_date + ' <span class="text-dark">' + pdcEsc(item.order_time) + '</span>'
        : pdcEsc(item.order_date);
    let extra = '';
    if (item.rule_name && item.rule_name !== item.drug_name) {
        extra += '<div class="text-muted small">กฎ: ' + pdcEsc(item.rule_name) + '</div>';
    }
    if (item.weight_source === 'calculator') {
        extra += '<div class="text-success small">(น้ำหนักจากเครื่องคำนวณ)</div>';
    } else if (item.weight_vstdate) {
        extra += '<div class="text-muted small">ชั่ง ' + pdcEsc(item.weight_vstdate) + '</div>';
    }
    const msgClass = kind === 'pass' ? 'text-success' : (kind === 'unverifiable' ? 'text-secondary' : 'text-danger');
    const suggestLine = (kind !== 'pass' && item.suggest_value_text)
        ? '<div class="small fw-bold text-success mt-1">ควรให้ ' + pdcEsc(item.suggest_value_text) + '</div>'
        : '';
    const rangeHtml = kind === 'pass'
        ? '<div class="pdc-ok small">' + pdcEsc(item.expected_display || '—') + '</div>' + suggestLine
        : (kind === 'unverifiable'
            ? pdcEsc(item.expected_display || '—')
            : '<div class="pdc-mismatch small">' + pdcEsc(item.expected_display || '—') + '</div>' + suggestLine);
    const bw = item.weight_kg ? pdcEsc(String(item.weight_kg)) + ' kg' : '—';
    const age = (item.age !== null && item.age !== undefined && item.age !== '') ? pdcEsc(String(item.age)) : '—';
    const parseNote = item.parse_note
        ? '<div class="text-muted small fw-normal">' + pdcEsc(item.parse_note) + '</div>'
        : '';
    const doseCellClass = item.dose_direction === 'high'
        ? ' pdc-dose-high'
        : (item.dose_direction === 'low' ? ' pdc-dose-low' : '');
    return '<tr>'
        + '<td class="text-center fw-bold">' + pdcEsc(item.hn) + '</td>'
        + '<td class="text-center"><span class="badge ' + (item.type_patient === 'IPD' ? 'bg-secondary' : 'bg-info text-dark') + '">' + pdcEsc(item.type_patient) + '</span></td>'
        + '<td>' + pdcEsc(item.ptname) + '</td>'
        + '<td class="text-center small">' + age + '</td>'
        + '<td class="text-center small">' + when + '</td>'
        + '<td class="text-start"><b>' + pdcEsc(item.drug_name) + '</b><br><small class="text-muted">icode: ' + pdcEsc(item.icode) + '</small>' + extra + '</td>'
        + '<td class="text-start small">' + pdcEsc(item.strength_display || '—') + '</td>'
        + '<td class="text-start small">' + pdcEsc(item.method || '-') + '</td>'
        + '<td class="text-center small fw-bold">' + bw + '</td>'
        + '<td class="text-center small fw-bold' + doseCellClass + '">' + pdcEsc(item.daily_mg_display || '—') + parseNote + '</td>'
        + '<td class="text-center small">' + pdcEsc(item.mg_kg_display || '—') + '</td>'
        + '<td class="text-center">' + pdcDoseDirBadge(item) + '</td>'
        + '<td class="text-center small">' + rangeHtml + '</td>'
        + '<td class="text-center small">' + pdcEsc(item.ward_display || '-') + '</td>'
        + '<td class="text-start small ' + msgClass + ' fw-bold">' + pdcEsc(item.alert_message || item.pass_message || '')
        + (kind !== 'pass' && window.MonIv ? MonIv.btn(item, item.alert_message || '') : '')
        + '</td>'
        + '</tr>';
}

let pdcFetchGen = 0;
let pdcAbortCtl = null;
const PDC_PARALLEL = 5;

function pdcItemSortKey(item) {
    return String(item.rxdate || '') + ' ' + String(item.order_time || '') + ' ' + String(item.hn || '');
}

function pdcSortItems(list) {
    return list.slice().sort(function (a, b) {
        return pdcItemSortKey(b).localeCompare(pdcItemSortKey(a));
    });
}

function pdcEmptyRow(msg) {
    return '<tr><td colspan="' + PDC_COLSPAN + '" class="text-center py-4 text-muted">' + msg + '</td></tr>';
}

function pdcNormHn(s) {
    const d = String(s == null ? '' : s).replace(/\D+/g, '').replace(/^0+/, '');
    return d;
}

function pdcFocusHn() {
    const el = document.getElementById('filter_hn');
    const typed = el ? String(el.value || '').trim() : '';
    if (typed) return typed;
    if (typeof PDC_FOCUS_HN === 'string' && PDC_FOCUS_HN.trim()) return PDC_FOCUS_HN.trim();
    if (typeof monitorFilterHn === 'function') {
        const fromHelper = String(monitorFilterHn() || '').trim();
        if (fromHelper) return fromHelper;
    }
    if (typeof monitorUrlParam === 'function') {
        const fromUrl = String(monitorUrlParam('hn') || '').trim();
        if (fromUrl) return fromUrl;
    }
    try {
        return String(new URLSearchParams(location.search).get('hn') || '').trim();
    } catch (e) {
        return '';
    }
}

function pdcFilterByHn(list, hnRaw) {
    const hn = String(hnRaw == null ? pdcFocusHn() : hnRaw).trim();
    if (!hn) return list || [];
    const want = pdcNormHn(hn);
    if (!want) return list || [];
    return (list || []).filter(function (it) {
        const got = pdcNormHn((it && (it.hn_full || it.hn)) || '');
        return got !== '' && got === want;
    });
}

function pdcPaintTables(agg, isFinal, focusHn) {
    const hn = (focusHn == null) ? pdcFocusHn() : focusHn;
    const hard = pdcSortItems(pdcFilterByHn(agg.hard, hn));
    const soft = pdcSortItems(pdcFilterByHn(agg.soft, hn));
    const unverifiable = pdcSortItems(pdcFilterByHn(agg.unverifiable, hn));
    const passed = pdcSortItems(pdcFilterByHn(agg.passed, hn));
    $('#hardCount').text(hard.length);
    $('#softCount').text(soft.length);
    $('#unverifiableCount').text(unverifiable.length);
    $('#passCount').text(passed.length);

    $('#hardTbody').html(hard.length
        ? hard.map(function (it) { return renderPdcMonRow(it, 'hard'); }).join('')
        : pdcEmptyRow(isFinal
            ? '<span class="text-success fw-bold"><i class="fas fa-check-circle me-2"></i>ไม่พบ Hard Alert</span>'
            : '<i class="fas fa-spinner fa-spin me-2"></i>กำลังตรวจ...'));
    $('#softTbody').html(soft.length
        ? soft.map(function (it) { return renderPdcMonRow(it, 'soft'); }).join('')
        : pdcEmptyRow(isFinal ? 'ไม่พบ Soft Alert' : 'กำลังตรวจ...'));
    $('#unverifiableTbody').html(unverifiable.length
        ? unverifiable.map(function (it) { return renderPdcMonRow(it, 'unverifiable'); }).join('')
        : pdcEmptyRow(isFinal ? '—' : 'กำลังตรวจ...'));
    $('#passTbody').html(passed.length
        ? passed.map(function (it) { return renderPdcMonRow(it, 'pass'); }).join('')
        : pdcEmptyRow(isFinal ? 'ยังไม่พบรายการที่ผ่านเงื่อนไข' : 'กำลังตรวจ...'));
}

async function pdcPostRules(ruleIds, signal, focusHn) {
    const hn = String(focusHn == null ? pdcFocusHn() : focusHn).trim();
    const body = new URLSearchParams();
    body.set('start_date', $('#filter_start').val() || '');
    body.set('end_date', $('#filter_end').val() || '');
    body.set('rule_ids', ruleIds.join(','));
    body.set('kids_only', $('#filter_kids_only').is(':checked') ? '1' : '0');
    body.set('tolerance_pct', $('#tolerance_pct').val() || '20');
    if (hn) {
        body.set('hn', hn);
        body.set('filter_hn', hn);
    }
    const apiUrl = hn
        ? ('fetch_monitor_pediatric_dose_api.php?hn=' + encodeURIComponent(hn))
        : 'fetch_monitor_pediatric_dose_api.php';
    const r = await fetch(apiUrl, {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        signal: signal,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString()
    });
    const text = await r.text();
    try {
        return JSON.parse(text);
    } catch (e) {
        throw new Error(pdcFriendlyFetchError(text, r.status));
    }
}

async function fetchPdcMonData() {
    const selected = [];
    $('.pdc-rule-cb:checked').each(function () {
        selected.push({
            id: $(this).val(),
            name: (($(this).closest('.form-check').find('label .fw-bold').first().text() || '') + '').trim()
        });
    });
    if (selected.length === 0) {
        alert('กรุณาเลือกอย่างน้อย 1 รายการยา');
        return;
    }

    const focusHn = pdcFocusHn();
    const gen = ++pdcFetchGen;
    if (pdcAbortCtl) {
        try { pdcAbortCtl.abort(); } catch (e) {}
    }
    const ac = new AbortController();
    pdcAbortCtl = ac;

    const t0 = Date.now();
    const agg = { hard: [], soft: [], passed: [], unverifiable: [], orders_scanned: 0, orders_checked: 0, orders_excluded: 0 };
    const failed = [];
    let done = 0;
    let lastPaint = 0;
    const workers = Math.min(PDC_PARALLEL, selected.length);

    $('#btnFetchPdcMon').prop('disabled', true);
    $('#hardTbody').html(pdcEmptyRow('<i class="fas fa-spinner fa-spin me-2"></i>กำลังตรวจทีละยา (พร้อมกัน ' + workers + ' รายการ)...'));
    $('#softTbody').html(pdcEmptyRow('—'));
    $('#unverifiableTbody').html(pdcEmptyRow('—'));
    $('#passTbody').html(pdcEmptyRow('—'));
    $('#hardCount').text(0);
    $('#softCount').text(0);
    $('#unverifiableCount').text(0);
    $('#passCount').text(0);
    $('#reportMeta').removeClass('d-none alert-danger').addClass('alert-info')
        .html('<i class="fas fa-spinner fa-spin me-1"></i> เริ่มตรวจ 0/' + selected.length + ' ยา (พร้อมกัน ' + workers + ' รายการ)'
            + (focusHn ? (' · กรอง HN ' + pdcEsc(focusHn)) : ''));

    function updateMeta(currentName, isFinal) {
        if (gen !== pdcFetchGen) return;
        const sec = ((Date.now() - t0) / 1000).toFixed(1);
        const hardN = pdcFilterByHn(agg.hard, focusHn).length;
        const softN = pdcFilterByHn(agg.soft, focusHn).length;
        const unvN = pdcFilterByHn(agg.unverifiable, focusHn).length;
        const passN = pdcFilterByHn(agg.passed, focusHn).length;
        let html = '<i class="fas fa-info-circle me-1"></i> ตรวจแล้ว ' + done + '/' + selected.length + ' ยา'
            + ' | พร้อมกัน ' + workers + ' รายการ'
            + (focusHn ? (' | กรอง HN ' + pdcEsc(focusHn)) : '')
            + ' | ยอม ±' + pdcEsc($('#tolerance_pct').val() || '20') + '%'
            + ' | Hard: ' + hardN
            + ' | Soft: ' + softN
            + ' | ตรวจสอบไม่ได้: ' + unvN
            + ' | ผ่าน: ' + passN
            + ' | สแกน: ' + agg.orders_scanned
            + ' | ยกเว้น: ' + agg.orders_excluded
            + ' | ' + sec + ' วินาที';
        if (!isFinal && currentName) html += ' | ล่าสุด: ' + pdcEsc(currentName);
        if (failed.length) html += ' | <span class="text-danger">ไม่สำเร็จ ' + failed.length + ' ยา</span>';
        if (isFinal && failed.length) {
            html += '<div class="small fw-normal mt-1">' + failed.map(function (f) { return pdcEsc(f); }).join('<br>') + '</div>';
        }
        $('#reportMeta').toggleClass('alert-danger', failed.length > 0 && isFinal)
            .toggleClass('alert-info', !(failed.length > 0 && isFinal))
            .html(html);
    }

    async function runOne(rule) {
        const data = await pdcPostRules([rule.id], ac.signal, focusHn);
        if (data.status !== 'success') {
            throw new Error(data.message || 'เกิดข้อผิดพลาด');
        }
        const m = data.meta || {};
        agg.hard.push.apply(agg.hard, pdcFilterByHn(data.hard_alerts || [], focusHn));
        agg.soft.push.apply(agg.soft, pdcFilterByHn(data.soft_alerts || [], focusHn));
        agg.passed.push.apply(agg.passed, pdcFilterByHn(data.passed_items || [], focusHn));
        agg.unverifiable.push.apply(agg.unverifiable, pdcFilterByHn(data.unverifiable_items || [], focusHn));
        agg.orders_scanned += m.orders_scanned || 0;
        agg.orders_checked += m.orders_checked || 0;
        agg.orders_excluded += m.orders_excluded || 0;
    }

    let next = 0;
    async function worker() {
        while (next < selected.length) {
            if (gen !== pdcFetchGen) return;
            const rule = selected[next++];
            try {
                await runOne(rule);
            } catch (err) {
                if (err && err.name === 'AbortError') throw err;
                failed.push((rule.name || rule.id) + ' — ' + (err && err.message ? err.message : 'เชื่อมต่อไม่สำเร็จ'));
            }
            done++;
            updateMeta(rule.name, false);
            if (done - lastPaint >= 5 || done === selected.length) {
                lastPaint = done;
                pdcPaintTables(agg, false, focusHn);
            }
        }
    }

    try {
        await Promise.all(Array.from({ length: workers }, worker));
    } catch (err) {
        if (err && err.name === 'AbortError') return;
        if (gen !== pdcFetchGen) return;
        $('#btnFetchPdcMon').prop('disabled', false);
        $('#hardTbody').html('<tr><td colspan="' + PDC_COLSPAN + '" class="text-center text-danger py-4">' + pdcEsc(err.message || 'เชื่อมต่อ API ไม่สำเร็จ') + '</td></tr>');
        return;
    }

    if (gen !== pdcFetchGen) return;
    $('#btnFetchPdcMon').prop('disabled', false);
    pdcPaintTables(agg, true, focusHn);
    updateMeta('', true);
}
</script>
<?php
$mon_iv_module = 'pediatric_dose';
$mon_iv_title = 'ยาเด็ก';
include __DIR__ . '/monitor_intervention_ui.php';
?>
</body>
</html>
