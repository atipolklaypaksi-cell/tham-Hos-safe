<?php
session_start();
if (!isset($_SESSION['user_id']) && !isset($_SESSION['full_name'])) {
    header('Location: login.php?return=' . rawurlencode('smart_drug.php'));
    exit;
}
$mr_login_name = trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? ''));
$mr_login_role = trim((string)($_SESSION['role'] ?? ''));
$mr_login_entryposition = trim((string)($_SESSION['entryposition'] ?? ''));
require_once __DIR__ . '/provider_oauth_helper.php';
require_once __DIR__ . '/drug_center_helper.php';
$sd_dc_oauth = provider_oauth_status_summary();
$sd_dc_ready = !empty($sd_dc_oauth['has_moph_token']) && drug_center_is_configured();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Smart Drug - THAM SAFE</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/all.min.css" rel="stylesheet">
    <script src="js/chart.min.js"></script>
    <style>
        body { font-family: 'Sarabun', sans-serif; background-color: #f4f7f6; }
        .card { border: none; box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075); margin-bottom: 20px; }
        .visit-list-panel {
            max-height: 520px;
            overflow-y: auto;
            border-right: 1px solid #dee2e6;
            background: #fafbfc;
        }
        #btnMedReconHist {
            background: #fde68a;
            border: 2px solid #b45309;
            box-shadow: 0 0 0 3px rgba(180, 83, 9, 0.28);
            animation: mrHistPulse 1.6s ease-in-out infinite;
        }
        @keyframes mrHistPulse {
            0%, 100% { box-shadow: 0 0 0 3px rgba(180, 83, 9, 0.28); }
            50% { box-shadow: 0 0 0 6px rgba(180, 83, 9, 0.08); }
        }
        .visit-item {
            padding: 10px 12px;
            border-bottom: 1px solid #e9ecef;
            cursor: pointer;
            transition: background 0.15s;
        }
        .visit-item:hover { background: #e8f4fd; }
        .visit-item.active {
            background: #1f4d3b;
            color: #fff;
        }
        .visit-item.active .visit-meta { color: rgba(255,255,255,0.85); }
        .visit-item.active .visit-type-icon i { color: #fff !important; }
        .visit-date { font-weight: 700; font-size: 0.95rem; }
        .visit-meta { font-size: 0.8rem; color: #6c757d; }
        .visit-badge {
            font-size: 0.7rem;
            padding: 2px 8px;
            border-radius: 10px;
            background: rgba(0,0,0,0.08);
        }
        .visit-badge-opd {
            background: #0d6efd;
            color: #fff;
            font-weight: 700;
        }
        .visit-badge-ipd {
            background: #e67e22;
            color: #fff;
            font-weight: 700;
        }
        .visit-type-icon {
            width: 1.25rem;
            text-align: center;
        }
        .visit-item.active .visit-badge-opd,
        .visit-item.active .visit-badge-ipd {
            background: rgba(255,255,255,0.25);
            color: #fff;
        }
        .visit-item.active .visit-badge {
            background: rgba(255,255,255,0.2);
            color: #fff;
        }
        .drug-table-wrap { max-height: 520px; overflow-y: auto; }
        .clickable-drug { cursor: pointer; color: #0d6efd; text-decoration: underline; font-weight: bold; }
        .clickable-drug:hover { color: #0a58ca; }
        #chartContainer { position: relative; height: 350px; }
        .panel-title {
            background: #495057;
            color: #fff;
            padding: 10px 14px;
            font-weight: 700;
            font-size: 0.9rem;
        }
        .selected-visit-bar {
            background: #eef7f3;
            border-bottom: 1px solid #c5d4a0;
            padding: 10px 16px;
            font-weight: 600;
            color: #1a4032;
        }
        .ipd-scope-toggle .btn {
            font-size: 0.75rem;
            font-weight: 700;
            padding: 0.15rem 0.55rem;
        }
        .mr-ipd-scope {
            font-size: 0.82rem;
            font-weight: 600;
        }
        #drugTable .col-calc-qty { display: none; }
        #drugTable.show-calc-qty .col-calc-qty { display: table-cell; }
        .order-group-row td {
            background: #e9ecef !important;
            color: #495057;
            border-top: 2px solid #ced4da;
        }
        .badge-hme {
            background: #198754;
            color: #fff;
            font-size: 0.68rem;
            vertical-align: middle;
        }
        .badge-chronic {
            background: #198754;
            color: #fff;
            font-size: 0.68rem;
            font-weight: 700;
            vertical-align: middle;
        }
        .visit-badge-hosp {
            display: inline-block;
            font-size: 0.65rem;
            font-weight: 700;
            background: #0f766e;
            color: #fff;
            border-radius: 8px;
            padding: 1px 7px;
            max-width: 9.5rem;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .visit-item.active .visit-badge-hosp {
            background: rgba(255,255,255,0.28);
        }
        .visit-badge-hosp.local { background: #1f4d3b; }
        #networkStatus .chip {
            display: inline-block;
            font-size: 0.75rem;
            border-radius: 999px;
            padding: 2px 8px;
            margin: 2px 4px 2px 0;
            background: #eef7f3;
            color: #1a4032;
            border: 1px solid #c5d4a0;
        }
        #networkStatus .chip.miss { background: #f8f9fa; color: #6c757d; border-color: #dee2e6; }
        #networkStatus .chip.err { background: #fff3cd; color: #856404; border-color: #ffe69c; }
        .med-tl-scroll {
            overflow: auto;
            max-height: 480px;
            background: #fff;
        }
        .med-tl-table {
            border-collapse: separate;
            border-spacing: 0;
            min-width: 100%;
            margin: 0;
        }
        .med-tl-table th,
        .med-tl-table td {
            border-right: 1px solid #e9ecef;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }
        .med-tl-table thead th {
            position: sticky;
            top: 0;
            z-index: 3;
            background: #f4f7f6;
            font-size: 0.72rem;
            font-weight: 700;
            padding: 8px 6px;
            white-space: nowrap;
        }
        .med-tl-table th.med-tl-name,
        .med-tl-table td.med-tl-name {
            position: sticky;
            left: 0;
            z-index: 2;
            background: #fff;
            min-width: 260px;
            max-width: 320px;
            text-align: left;
            padding: 8px 10px;
            box-shadow: 4px 0 8px rgba(0,0,0,0.04);
            vertical-align: top;
        }
        .med-tl-table thead th.med-tl-name { z-index: 4; background: #eef7f3; }
        .med-tl-drug-title { font-weight: 700; color: #0d6efd; cursor: pointer; line-height: 1.3; }
        .med-tl-usage {
            font-size: 0.72rem;
            color: #495057;
            line-height: 1.35;
            margin-top: 3px;
            white-space: normal;
        }
        .med-tl-latest-mg {
            font-size: 0.75rem;
            font-weight: 800;
            color: #b02a37;
            margin-top: 3px;
        }
        .med-tl-date {
            min-width: 88px;
            max-width: 110px;
            text-align: center;
            cursor: pointer;
            line-height: 1.25;
        }
        .med-tl-date:hover { background: #e8f4fd; }
        .med-tl-date.active,
        .med-tl-table td.med-tl-col.active { background: #eef7f3; }
        .med-tl-table thead th.med-tl-date.active { background: #cfe8db; }
        .med-tl-cell { text-align: center; padding: 4px 3px; min-width: 88px; vertical-align: middle; }
        .med-tl-dot {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-width: 52px;
            min-height: 34px;
            padding: 4px 6px;
            border-radius: 7px;
            color: #fff;
            font-weight: 800;
            font-size: 0.72rem;
            cursor: pointer;
            line-height: 1.15;
            gap: 1px;
        }
        .med-tl-dot .mg-line { white-space: nowrap; }
        .med-tl-dot .mg-delta {
            font-size: 0.68rem;
            font-weight: 800;
            letter-spacing: 0.02em;
        }
        .med-tl-dot .mg-delta.up,
        .med-tl-dot .mg-delta.down,
        .med-tl-dot .mg-delta.same { color: rgba(255,255,255,0.95); }
        .med-tl-dot .qty-line {
            font-size: 0.62rem;
            font-weight: 600;
            opacity: 0.9;
        }
        .med-tl-dot.opd { background: #0d6efd; }
        .med-tl-dot.ipd { background: #e67e22; }
        .med-tl-dot.hme { background: #198754; }
        /* เพิ่ม/ลด mg/วัน — ทับสีประเภท Visit */
        .med-tl-dot.up { background: #198754 !important; }
        .med-tl-dot.down { background: #e83e8c !important; }
        .med-tl-dot:hover { filter: brightness(1.08); }
        .med-tl-legend { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
        .med-tl-legend span { color: #495057; font-weight: 600; }
        .med-tl-lg {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 3px;
            margin-right: 4px;
            vertical-align: -1px;
        }
        .med-tl-lg.opd { background: #0d6efd; }
        .med-tl-lg.ipd { background: #e67e22; }
        .med-tl-lg.hme { background: #198754; }
        .med-tl-empty { color: #ced4da; font-size: 0.7rem; }
        #medReconModal .modal-dialog { max-width: 1100px; }
        #medReconModal .mr-visit-list {
            max-height: 220px;
            overflow-y: auto;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            background: #fafbfc;
        }
        #medReconModal .mr-visit-row {
            padding: 8px 12px;
            border-bottom: 1px solid #e9ecef;
            cursor: pointer;
        }
        #medReconModal .mr-visit-row:hover { background: #e8f4fd; }
        #medReconModal .mr-visit-row:last-child { border-bottom: 0; }
        #medReconDrugTableWrap { max-height: 360px; overflow: auto; }
        #medReconDrugTable .mr-drug-ro .mr-dn { font-weight: 700; font-size: 0.88rem; line-height: 1.35; }
        #medReconDrugTable .mr-drug-ro .mr-dm { font-size: 0.8rem; color: #495057; line-height: 1.35; margin-top: 2px; white-space: pre-wrap; }
        #medReconDrugTable .mr-dup { display: inline-block; margin-left: 4px; padding: 0 6px; border-radius: 999px; background: #fde8ea; color: #9b2332; font-size: 0.72rem; font-weight: 800; vertical-align: 1px; }
        #medReconDrugTable .mr-dose-chg { font-size: 0.78rem; color: #8a3b12; font-weight: 700; margin-top: 2px; line-height: 1.35; }
        #medReconDrugTable textarea.mr-drug-method {
            min-height: 40px;
            font-size: 0.82rem;
            resize: vertical;
        }
        #medReconModal .modal-dialog { max-width: 1280px; }
        #medReconDrugTable .mr-hosp-label {
            font-size: 0.72rem; color: #0f766e; font-weight: 700;
            line-height: 1.2; margin-top: 3px;
        }
        #medReconDrugTable input[type="date"],
        #medReconDrugTable .mr-order-place,
        #medReconDrugTable .mr-order-date-text,
        #medReconDrugTable .mr-appt-date-text { font-size: 0.75rem; }
        #medReconDrugTable td.mr-date-cell { min-width: 132px; }
        .mr-cal-wrap { position: relative; }
        .mr-cal-wrap .form-control { padding-right: 1.65rem; cursor: pointer; }
        .mr-cal-btn {
            position: absolute; right: 1px; top: 1px; bottom: 1px; width: 1.55rem;
            border: 0; background: transparent; color: #0f766e; pointer-events: none;
        }
        .mr-cal-native {
            position: absolute; right: 0; top: 0; width: 1.7rem; height: 100%;
            opacity: 0; cursor: pointer; border: 0; padding: 0;
        }
        .mr-usage-wrap { position: relative; }
        #medPostopModal .modal-dialog { max-width: 1360px; }
        #medPostopModal .mp-head {
            background: linear-gradient(135deg, #0f766e 0%, #115e59 55%, #134e4a 100%);
            color: #fff;
        }
        #medPostopModal .mp-admit-list {
            max-height: 240px;
            overflow-y: auto;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            background: #fafbfc;
        }
        #medPostopModal .mp-admit-row {
            padding: 8px 12px;
            border-bottom: 1px solid #e9ecef;
            cursor: pointer;
            display: flex;
            gap: 8px;
            align-items: flex-start;
            margin: 0;
        }
        #medPostopModal .mp-admit-row:hover { background: #e8f4fd; }
        #medPostopModal .mp-admit-row:last-child { border-bottom: 0; }
        #medPostopModal .mp-patient-box {
            background: #f0fdfa; border: 1px solid #99f6e4; border-radius: 10px; padding: 12px 14px;
        }
        #medPostopModal .mp-patient-box .form-label {
            font-size: 0.92rem; font-weight: 800; color: #0f766e; margin-bottom: 2px;
        }
        #medPostopModal .mp-patient-box .form-control {
            font-size: 1.05rem; font-weight: 600; min-height: 42px;
        }
        #medPostopModal .mp-patient-box #mp_pttype {
            font-size: 1.05rem; font-weight: 700; min-height: 44px; color: #0e7490;
            background: #ecfeff; border-color: #67e8f9;
        }
        #medPostopModal .mp-patient-box #mp_allergy {
            font-size: 1.15rem; font-weight: 800; min-height: 48px; color: #9a3412;
            background: #fff7ed; border-color: #fdba74;
        }
        #medPostopModal .mp-date-cell { min-width: 108px; text-align: center; }
        #medPostopModal .mp-date-cell .mp-od {
            display: block; font-size: 0.95rem; font-weight: 800; color: #0f766e;
            background: #ecfdf5; border: 1px solid #99f6e4; border-radius: 6px;
            padding: 6px 4px; line-height: 1.25;
        }
        #medPostopModal .mp-date-cell .mp-od small {
            display: block; font-size: 0.7rem; font-weight: 700; color: #64748b; margin-bottom: 2px;
        }
        #medPostopModal .mp-date-cell .mp-off {
            display: block; margin-top: 4px; font-size: 0.82rem; font-weight: 800; color: #b45309;
            background: #fff7ed; border: 1px solid #fdba74; border-radius: 6px; padding: 4px 3px;
        }
        #medPostopModal .mp-date-cell .mp-off small {
            display: block; font-size: 0.65rem; font-weight: 700; color: #92400e;
        }
        #medPostopDrugWrap { max-height: 420px; overflow: auto; border: 1px solid #d1e7dd; border-radius: 10px; }
        #medPostopDrugTable thead th {
            position: sticky; top: 0; z-index: 2;
            background: #ecfdf5; color: #115e59; font-size: 0.8rem; vertical-align: middle;
            line-height: 1.25;
        }
        #medPostopDrugTable thead tr:first-child th { top: 0; z-index: 3; }
        #medPostopDrugTable thead tr:nth-child(2) th { top: 36px; }
        #medPostopDrugTable .mp-inj { background: #e8f8ef; }
        #medPostopDrugTable .mp-other { background: #f5f0ff; }
        #medPostopDrugTable .mp-chk { text-align: center; width: 68px; }
        #medPostopDrugTable .mp-chk input { transform: scale(1.2); cursor: pointer; }
        #medPostopDrugTable .mp-drug-ro { padding: 2px 0; }
        #medPostopDrugTable .mp-drug-ro .mp-dn {
            font-weight: 800; font-size: 1.02rem; line-height: 1.35; color: #0f172a;
            border: 0; background: transparent; padding: 0; width: 100%; resize: vertical; min-height: 1.6em;
        }
        #medPostopDrugTable .mp-drug-ro .mp-dm {
            font-size: 0.92rem; color: #334155; line-height: 1.4; margin-top: 4px; font-weight: 600;
            border: 0; background: transparent; padding: 0; width: 100%; resize: vertical; min-height: 1.5em;
            white-space: pre-wrap;
        }
        #medPostopDrugTable .mp-drug-ro .mp-icode {
            font-size: 0.75rem; color: #94a3b8; margin-top: 2px;
        }
        #medPostopDrugTable textarea.mp-note { font-size: 0.88rem; min-height: 64px; resize: vertical; }
        #medPostopDrugTable .mp-group-row td {
            background: #0f766e; color: #fff; font-weight: 800; font-size: 0.85rem;
            padding: 7px 10px;
        }
        .mp-note-banner {
            background: #fff7ed; border: 1px solid #fdba74; border-radius: 8px;
            padding: 8px 12px; font-size: 0.82rem; color: #9a3412;
        }
        #medReconDrugTable .mr-action-group label {
            font-size: 0.72rem;
            margin-right: 4px;
            white-space: nowrap;
        }
        .mr-doctor-wrap, .mr-drug-wrap { position: relative; }
        .mr-doctor-suggest, .mr-drug-suggest, .mr-usage-suggest {
            position: absolute; left: 0; right: 0; top: 100%; z-index: 1080;
            max-height: 220px; overflow-y: auto;
            background: #fff; border: 1px solid #ced4da; border-radius: 0 0 8px 8px;
            box-shadow: 0 8px 18px rgba(0,0,0,.12); display: none;
        }
        .mr-doctor-suggest .item, .mr-drug-suggest .item, .mr-usage-suggest .item {
            padding: 6px 10px; cursor: pointer; font-size: 0.85rem;
            border-bottom: 1px solid #f1f3f5;
        }
        .mr-doctor-suggest .item:hover,
        .mr-doctor-suggest .item.active,
        .mr-drug-suggest .item:hover,
        .mr-drug-suggest .item.active { background: #e8f4fd; }
        .mr-doctor-suggest .empty, .mr-drug-suggest .empty, .mr-usage-suggest .empty { padding: 8px 10px; color: #6c757d; font-size: 0.8rem; }
        .mr-drug-suggest .item .sub, .mr-usage-suggest .item .sub { display: block; font-size: 0.75rem; color: #6c757d; margin-top: 2px; }
        .mr-usage-suggest .item.active, .mr-usage-suggest .item:hover { background: #e8f4fd; }
        .mr-allergy-no-hint {
            color: #198754;
            font-weight: 700;
            font-size: 0.78rem;
            line-height: 1.2;
            margin-top: 2px;
            white-space: nowrap;
        }
        .mr-allergy-no-hint.is-hidden { display: none; }
    </style>
</head>
<body>

<div class="wrapper">
    <?php include('sidebar.php'); ?>

    <div id="content" class="content">
        <div class="container-fluid">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold mb-0 text-dark"><i class="fas fa-capsules me-2 text-warning"></i>ระบบ Smart Drug (Medication Timeline)</h4>
                <a href="smart_drug_chronic.php" class="btn btn-outline-success btn-sm fw-bold"><i class="fas fa-notes-medical me-1"></i>ตั้งค่ารายการยาเรื้อรัง</a>
            </div>

            <div class="card p-4 rounded-3 shadow-sm border-primary">
                <div class="row align-items-end g-3">
                    <div class="col-md-5">
                        <label class="form-label fw-bold text-primary">ระบุ HN ผู้ป่วย:</label>
                        <div class="input-group">
                            <span class="input-group-text bg-primary text-white"><i class="fas fa-id-card"></i></span>
                            <input type="text" id="search_hn" class="form-control form-control-lg border-primary fw-bold text-primary" placeholder="กรอก HN (ไม่ต้องใส่ 0 นำหน้า)" value="<?php echo isset($_GET['hn']) ? htmlspecialchars($_GET['hn']) : ''; ?>" onkeypress="if(event.keyCode==13) fetchSmartDrugData()">
                            <button class="btn btn-primary btn-lg fw-bold" onclick="fetchSmartDrugData()"><i class="fas fa-search me-1"></i> ค้นหา</button>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold text-secondary">ช่วงเวลาย้อนหลัง:</label>
                        <select id="search_months" class="form-select form-select-lg">
                            <option value="3">3 เดือน</option>
                            <option value="6">6 เดือน</option>
                            <option value="12" selected>1 ปี</option>
                            <option value="36">3 ปี</option>
                            <option value="60">5 ปี</option>
                            <option value="0">ทั้งหมด</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check form-switch mt-1">
                            <input class="form-check-input" type="checkbox" role="switch" id="includeNetwork" checked>
                            <label class="form-check-label fw-bold text-success" for="includeNetwork">เชื่อมต่อรพ.ในเครือข่าย</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="includeJhcis">
                            <label class="form-check-label fw-bold" style="color:#059669;" for="includeJhcis">เชื่อมต่อ JHCIS PCC</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="includeDrugCenter">
                            <label class="form-check-label fw-bold text-primary" for="includeDrugCenter">เชื่อมต่อ Drug Center (PHR)</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="showTmtName">
                            <label class="form-check-label fw-bold text-secondary" for="showTmtName">แสดงชื่อยาจาก TMT</label>
                        </div>
                        <button type="button" class="btn btn-outline-secondary btn-sm mt-1" id="btnTmtExcept">ตั้งค่ายกเว้นชื่อแบรนด์</button>
                        <div id="nameModeHint" class="small text-muted">ปิด = แสดงชื่อจาก drugitems.name ทั้งรายการ</div>
                        <div class="small text-muted">ค่าเริ่มต้น: เปิดเครือข่าย · ปิด JHCIS · ปิด Drug Center · ย้อนหลัง 1 ปี</div>
                        <div id="resultMeta" class="small text-muted mt-1"></div>
                    </div>
                </div>
                <div id="drugCenterBanner" class="alert py-2 px-3 small mb-0 mt-2 <?php echo $sd_dc_ready ? 'alert-success d-none' : 'alert-warning'; ?>">
                    <i class="fas fa-cloud me-1"></i>
                    <strong>Drug Center:</strong>
                    <span id="drugCenterBannerText">
                        <?php if ($sd_dc_ready): ?>
                            พร้อมใช้งาน (Login Provider ID แล้ว)
                        <?php elseif (empty($sd_dc_oauth['has_moph_token'])): ?>
                            ยังไม่ได้ Login ผ่าน Provider ID — ต้องเข้าสู่ระบบด้วย Provider ID จึงจะดึง Med Reconcile / แพ้ยา จาก Drug Center ได้
                            <a href="#" id="drugCenterLoginLink" class="alert-link fw-bold ms-1" onclick="return goProviderLoginForDrugCenter();">ไปหน้า Login</a>
                        <?php else: ?>
                            ยังไม่ได้ตั้งค่า Drugs Center apiKey
                        <?php endif; ?>
                    </span>
                </div>
                <div id="dcVisitModeBar" class="mt-2 d-none">
                    <div class="btn-group btn-group-sm" role="group" aria-label="โหมด Visit Drug Center">
                        <input type="radio" class="btn-check" name="dcVisitMode" id="dcVisitAll" value="all" autocomplete="off" checked>
                        <label class="btn btn-outline-primary" for="dcVisitAll">แสดงทั้งหมด (รวมซ้ำ)</label>
                        <input type="radio" class="btn-check" name="dcVisitMode" id="dcVisitDedupe" value="dedupe" autocomplete="off">
                        <label class="btn btn-outline-primary" for="dcVisitDedupe">ตัดซ้ำ — ใช้ข้อมูลรพ./JHCIS/เครือข่ายเป็นหลัก</label>
                    </div>
                    <span id="dcMergeMeta" class="small text-muted ms-2"></span>
                </div>
                <div id="networkStatus" class="mt-2"></div>
                <div id="patientInfoRow" class="row mt-3" style="display:none;">
                    <div class="col-12">
                        <div class="d-flex align-items-center gap-3 p-3 rounded-3 border border-success bg-white shadow-sm">
                            <i class="fas fa-user-circle fa-2x text-success"></i>
                            <div>
                                <div class="fw-bold fs-5 text-dark" id="patientName">-</div>
                                <div class="small text-muted">HN: <span id="patientHnDisplay" class="fw-bold text-primary"></span></div>
                                <div id="patientAllergy" class="mt-1 fw-bold"></div>
                            </div>
                            <button type="button" id="mrHistPatientTab" class="btn fw-bold ms-auto" style="display:none;background:#fde68a;border:2px solid #b45309;" onclick="openMedReconHistory()">
                                <i class="fas fa-folder-open me-1"></i>
                                <div class="small">เคยทำ Med Reconciliation</div>
                                <div>ล่าสุด <span id="mrHistPatientWhen">-</span></div>
                            </button>
                            <button type="button" id="mrHistPatientHidden" class="btn fw-bold ms-auto text-start" style="display:none;background:#fff7ed;border:2px solid #c2410c;color:#9a3412;max-width:340px;" onclick="mrHistReveal()" title="ประวัตินี้อยู่คนละ AN กับ Visit ที่เลือก">
                                <i class="fas fa-eye-slash me-1"></i>
                                <span id="mrHistPatientHiddenAn" class="small">มีประวัติ Medication Reconciliation ใน AN</span>
                                <div class="small fw-normal">ซ่อนไว้เป็นค่าเริ่มต้น · กดเพื่อเปิดดู</div>
                            </button>
                    </div>
                </div>
            </div>

            <div class="card rounded-3 border-secondary shadow-sm">
                <div class="card-header bg-secondary text-white fw-bold py-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div><i class="fas fa-history me-2"></i>ประวัติการรับยา (OPD + IPD)
                        <span class="badge bg-light text-dark ms-1 fw-normal"><i class="fas fa-hospital-user text-primary"></i> OPD</span>
                        <span class="badge bg-light text-dark ms-1 fw-normal"><i class="fas fa-procedures text-warning"></i> IPD</span>
                        <span class="badge bg-success ms-1 fw-normal"><i class="fas fa-home"></i> HME ยากลับบ้าน</span>
                        <span class="badge bg-info text-dark ms-1 fw-normal"><i class="fas fa-hospital"></i> รพ.เครือข่าย</span>
                        <span class="badge ms-1 fw-normal" style="background:#059669;"><i class="fas fa-clinic-medical"></i> JHCIS PCC</span>
                    </div>
                    <div class="d-flex align-items-center flex-wrap gap-2">
                        <label class="me-1 mb-0 text-white fw-bold" style="white-space: nowrap;"><i class="fas fa-hospital"></i> รพ.:</label>
                        <select id="hospitalFilter" class="form-select form-select-sm fw-bold border-0 shadow-sm" style="min-width: 170px;" onchange="onHospitalFilterChange()">
                            <option value="all">ทุกโรงพยาบาล</option>
                        </select>
                        <label class="me-2 mb-0 text-white fw-bold" style="white-space: nowrap;"><i class="fas fa-filter"></i> กรองชื่อยา:</label>
                        <select id="drugFilter" class="form-select form-select-sm fw-bold border-0 shadow-sm text-primary" style="min-width: 220px; cursor: pointer;" onchange="filterTableByDrug()">
                            <option value="all">-- แสดงยาทั้งหมด --</option>
                        </select>
                        <div class="form-check form-check-inline mb-0 ms-1">
                            <input class="form-check-input" type="checkbox" id="toggleCalcQtyCol" onchange="toggleCalcQtyColumn()">
                            <label class="form-check-label text-white fw-bold small" for="toggleCalcQtyCol" style="white-space: nowrap;">แสดงจำนวนคำนวณ mg</label>
                        </div>
                        <button type="button" class="btn btn-sm fw-bold text-dark" id="btnMedReconHist" style="display:none;" onclick="openMedReconHistory()" title="เปิดประวัติ Medication Reconciliation">
                            <i class="fas fa-exclamation-circle me-1"></i> มีประวัติ Med Recon · ล่าสุด <span id="mrHistLatestLabel"></span>
                        </button>
                        <button type="button" class="btn btn-sm fw-bold" id="btnMedReconHistHidden" style="display:none;background:#fff7ed;border:2px solid #c2410c;color:#9a3412;" onclick="mrHistReveal()" title="ประวัตินี้อยู่คนละ AN กับ Visit ที่เลือก กดเพื่อเปิดดู">
                            <i class="fas fa-eye-slash me-1"></i> <span id="mrHistHiddenAn">มีประวัติ Medication Reconciliation ใน AN</span>
                        </button>
                        <button type="button" class="btn btn-sm btn-warning fw-bold text-dark" id="btnMedRecon" onclick="openMedReconModal()" title="พิมพ์ใบ Medication Reconciliation">
                            <i class="fas fa-print me-1"></i> Med Recon
                        </button>
                        <button type="button" class="btn btn-sm fw-bold text-white" id="btnMedPostop" onclick="openMedPostopModal()" title="ยาที่ได้รับก่อนและหลังผ่าตัด (Post-op) / Review treatment" style="background:#0f766e;border-color:#0f766e;">
                            <i class="fas fa-procedures me-1"></i> Med Post-op
                        </button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="row g-0">
                        <div class="col-md-3 col-lg-3">
                            <div class="panel-title"><i class="fas fa-list me-1"></i> Visit List</div>
                            <div id="visitList" class="visit-list-panel">
                                <div class="text-center text-muted py-5 px-2 small">ค้นหา HN เพื่อแสดงรายการ Visit</div>
                            </div>
                        </div>
                        <div class="col-md-9 col-lg-9">
                            <div id="selectedVisitBar" class="selected-visit-bar">
                                <i class="fas fa-calendar-check me-1"></i> เลือก Visit จากรายการด้านซ้าย
                            </div>
                            <div class="drug-table-wrap">
                                <table id="drugTable" class="table table-hover table-striped align-middle mb-0">
                                    <thead class="table-light text-center sticky-top">
                                        <tr>
                                            <th width="5%">ลำดับ</th>
                                            <th class="text-start" width="26%">รายการยา (icode)</th>
                                            <th width="10%">จำนวนสั่งยา (qty)</th>
                                            <th class="col-calc-qty" width="10%">จำนวนคำนวณ mg</th>
                                            <th width="12%">mg/วัน (วิธีใช้)</th>
                                            <th class="text-start" width="39%">วิธีใช้ / Rate</th>
                                        </tr>
                                    </thead>
                                    <tbody id="drugHistoryTbody">
                                        <tr><td colspan="6" class="text-center text-muted py-5"><i class="fas fa-search fa-2x mb-3 d-block text-black-50"></i> กรุณาค้นหาด้วย HN เพื่อดึงข้อมูลจาก HOSxP</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="medTimelineSection" class="mt-4" style="display:none;">
                <div class="card rounded-3 border-secondary shadow-sm">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <div>
                            <span class="fw-bold text-dark"><i class="fas fa-stream me-2 text-success"></i>Timeline การได้รับยา</span>
                            <span id="medTimelineMeta" class="small text-muted ms-2"></span>
                            <div class="small text-muted mt-1">ซ้ายไปขวา = เก่า → ใหม่ · แสดงวิธีใช้และ mg/วันล่าสุด · ช่อง Visit = mg/วัน พร้อมสัญลักษณ์เพิ่ม/ลดเทียบครั้งก่อน · คลิกช่องเพื่อเปิด Visit</div>
                        </div>
                        <div class="med-tl-legend small">
                            <span><i class="med-tl-lg opd"></i>OPD</span>
                            <span><i class="med-tl-lg ipd"></i>IPD</span>
                            <span><i class="med-tl-lg hme"></i>HME ยากลับบ้าน</span>
                            <span class="text-success">↑ เพิ่ม mg/วัน (เขียว)</span>
                            <span style="color:#e83e8c;font-weight:700;">↓ ลด mg/วัน (ชมพู)</span>
                            <span class="text-muted">ตัวเลขในช่อง = mg/วัน</span>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div id="medTimelineWrap" class="med-tl-scroll"></div>
                    </div>
                </div>
            </div>

            <div id="analysisSection" class="mt-4" style="display:none;">
                <div class="card rounded-3 shadow border-info">
                    <div class="card-header bg-info text-white d-flex justify-content-between align-items-center py-3">
                        <span class="fw-bold"><i class="fas fa-chart-line me-2"></i>Timeline & Cumulative Dose: <span id="selectedDrugLabel" class="badge bg-warning text-dark fs-6 ms-2"></span></span>
                        <button class="btn btn-sm btn-light text-danger fw-bold" onclick="$('#analysisSection').fadeOut()"><i class="fas fa-times"></i> ปิดกราฟ</button>
                    </div>
                    <div class="card-body p-4">
                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
                            <div class="d-flex flex-wrap gap-3 align-items-center">
                                <span class="fw-bold text-secondary"><i class="fas fa-sliders-h me-1"></i> แสดงในกราฟ:</span>
                                <div class="form-check form-check-inline mb-0">
                                    <input class="form-check-input" type="checkbox" id="chartShowQty" checked onchange="refreshChart()">
                                    <label class="form-check-label fw-bold" for="chartShowQty">จำนวนสั่งยา (qty)</label>
                                </div>
                                <div class="form-check form-check-inline mb-0">
                                    <input class="form-check-input" type="checkbox" id="chartShowMg" checked onchange="refreshChart()">
                                    <label class="form-check-label fw-bold" for="chartShowMg">mg/วัน (วิธีใช้)</label>
                                </div>
                            </div>
                            <div class="d-flex gap-2 flex-wrap">
                                <div id="cumQtyBox" class="shadow-sm bg-white border border-primary border-2 rounded-3 px-3 py-2 text-end">
                                    <small class="text-muted d-block fw-bold mb-0">สะสมจำนวนสั่งยา</small>
                                    <span id="cumQtyValue" class="fs-4 fw-bold text-primary">0</span>
                                    <small id="cumQtyUnit" class="text-primary fw-bold">หน่วย</small>
                                </div>
                                <div id="cumMgBox" class="shadow-sm bg-white border border-danger border-2 rounded-3 px-3 py-2 text-end">
                                    <small class="text-muted d-block fw-bold mb-0">สะสม mg/วัน</small>
                                    <span id="cumMgValue" class="fs-4 fw-bold text-danger">0</span>
                                    <small class="text-danger fw-bold">mg/วัน</small>
                                </div>
                            </div>
                        </div>
                        <div id="chartContainer" style="position: relative; height: 320px; width: 100%;">
                            <canvas id="drugTimelineChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Med Reconciliation editor -->
<div class="modal fade" id="tmtExceptModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h5 class="modal-title fw-bold">ยกเว้นรายการยา — แสดงชื่อแบรนด์</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="small text-muted mb-2">ตั้งตาม <b>ชื่อ TMT</b> เมื่อเปิดแสดงชื่อยาจาก TMT ถ้าชื่อ TMT ตรงรายการนี้ จะแสดง <b>drugitems.name</b> ของแต่ละรพ. แทน (ใช้ได้กับรพ.เครือข่าย)</p>
                <div class="input-group mb-2">
                    <input type="text" id="tmtExceptQ" class="form-control form-control-sm" placeholder="ค้นชื่อ TMT หรือชื่อแบรนด์" autocomplete="off">
                    <button type="button" class="btn btn-primary btn-sm" id="tmtExceptSearch">ค้นหา</button>
                </div>
                <div id="tmtExceptHits" class="border rounded mb-3" style="max-height:220px;overflow:auto;"></div>
                <div class="fw-bold small mb-1">รายการที่ยกเว้น <span class="text-muted fw-normal" id="tmtExceptCount"></span></div>
                <div id="tmtExceptList" class="border rounded" style="max-height:280px;overflow:auto;"></div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="medReconModal" tabindex="-1" aria-labelledby="medReconModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-success text-white py-2">
                <h5 class="modal-title fw-bold" id="medReconModalLabel">
                    <i class="fas fa-notes-medical me-2"></i>Medication Reconciliation &amp; Doctor's Order Sheet
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3 mb-3">
                    <div class="col-lg-5">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="fw-bold mb-0"><i class="fas fa-list-check me-1"></i> เลือก Visit (ได้หลาย Visit)</label>
                            <div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-outline-secondary" onclick="medReconSelectVisits(true)">ทั้งหมด</button>
                                <button type="button" class="btn btn-outline-secondary" onclick="medReconSelectVisits(false)">ล้าง</button>
                            </div>
                        </div>
                        <div id="medReconVisitList" class="mr-visit-list"></div>
                        <div class="small text-muted mt-1 mb-1">ค่าเริ่มต้นเลือก Visit ล่าสุดที่มียาใช้ต่อเนื่อง หรือยาในรายการโรคเรื้อรัง และมีรหัส TMT ของแต่ละสถานพยาบาล · สถานพยาบาลอื่นถ้า Visit นั้นเกิน 6 เดือนเทียบวันนี้ จะไม่ถูกเลือก · ติ๊กเพิ่ม Visit อื่นได้ · ยาซ้ำแสดงครั้งเดียว · IPD ดึงเฉพาะ HME จนกว่าจะสลับเป็นทั้งหมด</div>
                        <div id="mrIpdScopeWrap" class="mr-ipd-scope border rounded p-2 bg-white mb-2" style="display:none">
                            <div class="small text-muted mb-1">ยา OPD ดึงทั้งหมด · ยา IPD ค่าเริ่มต้นเฉพาะ HME</div>
                            <div class="form-check form-check-inline mb-0">
                                <input class="form-check-input" type="radio" name="mr_ipd_scope" id="mr_ipd_scope_hme" value="hme" checked onchange="onMrIpdScopeChange()">
                                <label class="form-check-label" for="mr_ipd_scope_hme">เฉพาะ HME</label>
                            </div>
                            <div class="form-check form-check-inline mb-0">
                                <input class="form-check-input" type="radio" name="mr_ipd_scope" id="mr_ipd_scope_all" value="all" onchange="onMrIpdScopeChange()">
                                <label class="form-check-label" for="mr_ipd_scope_all">ทั้งหมด (คลังห้องยา)</label>
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary btn-sm fw-bold mt-1" onclick="medReconLoadDrugsFromVisits()">
                            <i class="fas fa-sync-alt me-1"></i> โหลดรายการยาจาก Visit ที่เลือก
                        </button>
                    </div>
                    <div class="col-lg-7">
                        <div class="row g-2">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold mb-0">ชื่อผู้ป่วย</label>
                                <input type="text" id="mr_patient_name" class="form-control form-control-sm">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold mb-0">HN</label>
                                <input type="text" id="mr_hn" class="form-control form-control-sm" readonly>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold mb-0">VN / AN</label>
                                <input type="text" id="mr_vn" class="form-control form-control-sm">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-bold mb-0">อายุ</label>
                                <input type="text" id="mr_age" class="form-control form-control-sm">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold mb-0">เพศ</label>
                                <select id="mr_sex" class="form-select form-select-sm">
                                    <option value="">-</option>
                                    <option value="M">ชาย</option>
                                    <option value="F">หญิง</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold mb-0">วันที่รับบริการ</label>
                                <input type="text" id="mr_service_date" class="form-control form-control-sm" placeholder="เช่น 10/09/2569">
                            </div>
                            <div class="col-md-8">
                                <label class="form-label small fw-bold mb-0">วันนัดครั้งต่อไป <span class="text-muted fw-normal">(แสดงเฉพาะหลังวันนี้)</span></label>
                                <textarea id="mr_next_appt" class="form-control form-control-sm" rows="3" placeholder="ดึงจาก HOSxP รพ.เครือข่าย และ PCC — แสดงเฉพาะนัดหลังวันนี้"></textarea>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold mb-0">Admit วันที่/เวลา</label>
                                <input type="text" id="mr_admit_dt" class="form-control form-control-sm" placeholder="เช่น 10 ก.ย. 2569 เวลา 11:48 น.">
                            </div>
                            <div class="col-md-5">
                                <label class="form-label small fw-bold mb-0">แพทย์เจ้าของไข้</label>
                                <div class="mr-doctor-wrap">
                                    <input type="text" id="mr_doctor" class="form-control form-control-sm" placeholder="พิมพ์ชื่อแพทย์เพื่อค้นหา..." autocomplete="off">
                                    <div id="mrDoctorSuggest" class="mr-doctor-suggest"></div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold mb-0">หอผู้ป่วย (IPD ปัจจุบัน)</label>
                                <input type="text" id="mr_ward" class="form-control form-control-sm" placeholder="ดึงจาก IPD ปัจจุบัน">
                            </div>
                            <div class="col-md-8">
                                <label class="form-label small fw-bold mb-0">แพ้ยา</label>
                                <div class="d-flex flex-wrap align-items-start gap-3">
                                    <div class="mr-allergy-no-wrap text-center" style="min-width:72px">
                                        <div class="form-check mb-0 d-flex justify-content-center gap-1">
                                            <input class="form-check-input" type="radio" name="mr_allergy" id="mr_allergy_no" value="N" checked>
                                            <label class="form-check-label fw-bold" for="mr_allergy_no">NO</label>
                                        </div>
                                        <div id="mr_allergy_no_hint" class="mr-allergy-no-hint">ไม่แพ้ยา (HOSxP)</div>
                                    </div>
                                    <div class="form-check mb-0 mt-1">
                                        <input class="form-check-input" type="radio" name="mr_allergy" id="mr_allergy_yes" value="Y">
                                        <label class="form-check-label fw-bold" for="mr_allergy_yes">Yes</label>
                                    </div>
                                    <div class="flex-grow-1" style="min-width:180px">
                                        <input type="text" id="mr_allergy_text" class="form-control form-control-sm" placeholder="ระบุยาที่แพ้ (ถ้ามี)">
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="border rounded p-2 bg-light small">
                                    <div class="fw-bold mb-1">แหล่งที่มา / ถุงยาเดิม</div>
                                    <div class="d-flex flex-wrap gap-3">
                                        <label class="mb-0"><input type="radio" name="mr_source" value="sakaeo" checked> รพ.สระแก้ว</label>
                                        <label class="mb-0"><input type="radio" name="mr_source" value="other"> ที่อื่น <input type="text" id="mr_source_other" class="form-control form-control-sm d-inline-block" style="width:140px" placeholder="ระบุ"></label>
                                        <label class="mb-0"><input type="radio" name="mr_bag" value="yes" checked> มีถุงยาเดิม</label>
                                        <label class="mb-0"><input type="radio" name="mr_bag" value="no"> ไม่มีถุงยาเดิม</label>
                                        <label class="mb-0"><input type="radio" name="mr_identify" value="yes" checked> ระบุรายการยา ได้</label>
                                        <label class="mb-0"><input type="radio" name="mr_identify" value="no"> ไม่ได้ (ส่งต่อห้องยา)</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="fw-bold"><i class="fas fa-pills me-1"></i> รายการยา (จาก Visit อ่านอย่างเดียว · เพิ่มรายการใหม่ค้นหาได้)
                        <span class="badge bg-secondary" id="mrDrugCount">0</span>
                        <span class="fw-normal text-muted small ms-1">เพิ่มรายการเลือกวันที่จากปฏิทิน · วิธีใช้พิมพ์รหัส HOSxP เช่น 13pt แล้วกด Enter</span>
                    </div>
                    <div class="d-flex gap-2 align-items-center">
                        <label class="mb-0 small fw-normal"><input type="checkbox" id="mrShowDup" checked onchange="medReconToggleDup()"> แสดงรายการซ้ำ</label>
                        <button type="button" class="btn btn-sm btn-outline-success" onclick="medReconAddRow()"><i class="fas fa-plus me-1"></i>เพิ่มรายการ</button>
                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="medReconClearRows()"><i class="fas fa-trash me-1"></i>ล้างทั้งหมด</button>
                    </div>
                </div>
                <div id="medReconDrugTableWrap">
                    <table class="table table-sm table-bordered align-middle mb-0" id="medReconDrugTable">
                        <thead class="table-light text-center sticky-top">
                            <tr>
                                <th width="3%">#</th>
                                <th width="12%">วันที่สั่ง<br><span class="fw-normal text-muted" style="font-size:0.72rem;">สถานที่สั่ง</span></th>
                                <th width="11%">วันที่นัด</th>
                                <th width="28%">รายการยา / วิธีใช้</th>
                                <th width="10%">จำนวนเม็ดยา</th>
                                <th width="15%">Admit <span class="text-muted fw-normal">(ไม่ติ๊กเริ่มต้น)</span></th>
                                <th width="15%">Home <span class="text-muted fw-normal">(ไม่ติ๊กเริ่มต้น)</span></th>
                                <th width="9%">หมายเหตุ</th>
                                <th width="4%"></th>
                            </tr>
                        </thead>
                        <tbody id="medReconDrugBody"></tbody>
                    </table>
                </div>
                <div class="mt-2">
                    <label class="form-label small fw-bold mb-1" for="mr_note">Note: MR</label>
                    <textarea id="mr_note" class="form-control form-control-sm" rows="2" placeholder="บันทึกเพิ่มเติม จะแสดงในใบพิมพ์ส่วน Note: MR"></textarea>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                <button type="button" class="btn btn-success fw-bold" onclick="medReconPrint()">
                    <i class="fas fa-print me-1"></i> พิมพ์ใบ Med Reconciliation
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="medReconHistModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header py-2 text-white" style="background:#b45309;">
                <h5 class="modal-title fw-bold"><i class="fas fa-history me-2"></i>ประวัติ Medication Reconciliation</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-lg-4">
                        <div id="mrHistList" class="list-group small"></div>
                    </div>
                    <div class="col-lg-8">
                        <div id="mrHistDetail" class="border rounded p-3 bg-light">เลือกรายการด้านซ้ายเพื่อเปิดดู</div>
                    </div>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                <button type="button" class="btn btn-outline-danger fw-bold" id="btnMrHistDelete" style="display:none;" onclick="medReconDeleteHistory()">
                    <i class="fas fa-trash me-1"></i> ลบ
                </button>
                <button type="button" class="btn btn-success fw-bold" id="btnMrHistLoad" style="display:none;" onclick="medReconLoadHistoryIntoForm()">
                    <i class="fas fa-pen me-1"></i> แก้ไข
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Med Post-op / Review treatment -->
<div class="modal fade" id="medPostopModal" tabindex="-1" aria-labelledby="medPostopModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header mp-head py-2">
                <h5 class="modal-title fw-bold" id="medPostopModalLabel">
                    <i class="fas fa-procedures me-2"></i>ยาที่ได้รับก่อนและหลังผ่าตัด (Post-op) / Review treatment
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3 mb-3">
                    <div class="col-lg-4">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="fw-bold mb-0"><i class="fas fa-bed me-1"></i> AN ที่กำลัง Admit</label>
                        </div>
                        <div id="mpAdmitList" class="mp-admit-list mb-2">
                            <div class="p-3 text-muted small">กำลังโหลด...</div>
                        </div>
                        <div class="small text-muted mb-2">Med Post-op ใช้ได้เฉพาะผู้ป่วยที่ <b>กำลัง Admit</b> · ดึงยา Continuous (Active) แบบ Patient IPD</div>
                        <button type="button" class="btn btn-primary btn-sm fw-bold" onclick="medPostopReload()">
                            <i class="fas fa-sync-alt me-1"></i> โหลดยา Continuous (Active)
                        </button>
                    </div>
                    <div class="col-lg-8">
                        <div class="mp-patient-box">
                            <div class="row g-2">
                                <div class="col-md-6">
                                    <label class="form-label">ชื่อผู้ป่วย</label>
                                    <input type="text" id="mp_patient_name" class="form-control">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">HN</label>
                                    <input type="text" id="mp_hn" class="form-control" readonly>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">AN</label>
                                    <input type="text" id="mp_an" class="form-control" readonly>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">อายุ</label>
                                    <input type="text" id="mp_age" class="form-control">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">วันที่เอกสาร</label>
                                    <input type="date" id="mp_date" class="form-control">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">หอผู้ป่วย</label>
                                    <input type="text" id="mp_ward" class="form-control">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">สิทธิการรักษา</label>
                                    <input type="text" id="mp_pttype" class="form-control" placeholder="ดึงจาก HOSxP ตาม AN">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">ประวัติแพ้ยา</label>
                                    <input type="text" id="mp_allergy" class="form-control" placeholder="ไม่แพ้ยา / ระบุยาที่แพ้">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                    <div class="fw-bold" style="font-size:1.05rem;">
                        <i class="fas fa-pills me-1 text-success"></i> รายการยา Continuous (Active)
                        <span class="badge" id="mpDrugCount" style="background:#0f766e;">0</span>
                        <span class="fw-normal text-muted small ms-1">วันเริ่มยา = วันที่สั่ง · แสดงวันที่ off ถ้ามี</span>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="medPostopAddBlankRow()">
                        <i class="fas fa-plus me-1"></i> เพิ่มแถว
                    </button>
                </div>
                <div id="medPostopDrugWrap">
                    <table class="table table-bordered align-middle mb-0" id="medPostopDrugTable">
                        <thead class="text-center">
                            <tr>
                                <th rowspan="2" style="width:11%;vertical-align:middle;">วันเริ่มยา<br><span class="fw-normal text-muted" style="font-size:0.72rem;">(= วันที่สั่ง) / off</span></th>
                                <th style="width:38%;">รายการยา / วิธีการใช้ยา</th>
                                <th colspan="5">รายการยาที่ได้รับ Post op / Review treatment</th>
                                <th rowspan="2" style="width:3%;"></th>
                            </tr>
                            <tr>
                                <th class="fw-normal text-muted" style="font-size:0.75rem;">ชื่อยา · วิธีใช้ (แบบ Med Recon)</th>
                                <th style="width:8%;">ใช้ต่อ<br>วิธีเดิม</th>
                                <th style="width:8%;">เปลี่ยน<br>วิธีใช้</th>
                                <th style="width:7%;">งดใช้</th>
                                <th style="width:7%;">หยุดยา</th>
                                <th style="width:15%;">หมายเหตุ</th>
                            </tr>
                        </thead>
                        <tbody id="medPostopDrugBody"></tbody>
                    </table>
                </div>
                <div class="mp-note-banner mt-3">
                    <i class="fas fa-info-circle me-1"></i>
                    กรณีสั่งใช้ยาหลังผ่าตัด Post-op หรือ Review treatment หากต้องการปรับวิธีการใช้ยา
                    แพทย์สามารถระบุวิธีการใช้ยาแบบใหม่ในช่อง <b>หมายเหตุ</b> ได้
                </div>
                <div class="row g-2 mt-3">
                    <div class="col-md-6">
                        <div class="border rounded p-2 bg-light h-100">
                            <div class="fw-bold small mb-2" style="color:#0f766e;">พยาบาล</div>
                            <div class="row g-2">
                                <div class="col-7"><input type="text" id="mp_nurse" class="form-control form-control-sm" placeholder="ชื่อพยาบาล"></div>
                                <div class="col-5"><input type="datetime-local" id="mp_nurse_dt" class="form-control form-control-sm"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="border rounded p-2 bg-light h-100">
                            <div class="fw-bold small mb-2">แพทย์</div>
                            <div class="row g-2">
                                <div class="col-7"><input type="text" id="mp_doctor" class="form-control form-control-sm" placeholder="ชื่อแพทย์"></div>
                                <div class="col-5"><input type="datetime-local" id="mp_doctor_dt" class="form-control form-control-sm"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                <button type="button" class="btn fw-bold text-white" style="background:#0f766e;" onclick="medPostopPrint()">
                    <i class="fas fa-print me-1"></i> พิมพ์ใบ Med Post-op
                </button>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.7.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
let globalHistoryData = [];
let globalVisits = [];
let globalPatient = null;
let selectedVisitKey = null;
let medReconRows = [];
let medReconVisitAppts = [];
let medReconHospitalName = 'โรงพยาบาลสมเด็จพระยุพราชสระแก้ว';
const MR_LOGIN_NAME = <?php echo json_encode($mr_login_name, JSON_UNESCAPED_UNICODE); ?>;
const MR_LOGIN_ROLE = <?php echo json_encode($mr_login_role, JSON_UNESCAPED_UNICODE); ?>;
const MR_LOGIN_ENTRYPOSITION = <?php echo json_encode($mr_login_entryposition, JSON_UNESCAPED_UNICODE); ?>;
const MR_PHARMACIST_NAME = MR_LOGIN_NAME;
const SD_DC_OAUTH = <?php echo json_encode($sd_dc_oauth, JSON_UNESCAPED_UNICODE); ?>;
const SD_DC_READY = <?php echo $sd_dc_ready ? 'true' : 'false'; ?>;
let drugChart = null;
let currentChartDrug = null;
let selectedHospitalCode = 'all';
let tmtExceptNames = {};
let smartDrugLoadTimer = null;
let ipdShowAll = false;
let mrIpdShowAll = false;
/** ประวัติจาก Drug Center (แยกเก็บเพื่อสลับโหมดแสดงทั้งหมด / ตัดซ้ำ) */
let dcHistoryRaw = [];
let dcVisitsRaw = [];
let dcAllergyRaw = null;
let baseHistoryData = [];
let baseVisits = [];
let baseAllergy = null;
const LOOKBACK_LABELS = { 3: '3 เดือน', 6: '6 เดือน', 12: '1 ปี', 36: '3 ปี', 60: '5 ปี', 0: 'ทั้งหมด' };

$(document).ready(function() {
    try {
        var saved = localStorage.getItem('tham_network_hospitals');
        if (saved === '0') {
            $('#includeNetwork').prop('checked', false);
        } else if (saved === '1') {
            $('#includeNetwork').prop('checked', true);
        }
        var savedJhcis = localStorage.getItem('tham_jhcis_pcc');
        if (savedJhcis === '1') {
            $('#includeJhcis').prop('checked', true);
        } else if (savedJhcis === '0') {
            $('#includeJhcis').prop('checked', false);
        }
        var savedDc = localStorage.getItem('tham_drug_center');
        if (savedDc === '1') {
            $('#includeDrugCenter').prop('checked', true);
        }
        var savedDcMode = localStorage.getItem('tham_drug_center_visit_mode');
        if (savedDcMode === 'dedupe') {
            $('#dcVisitDedupe').prop('checked', true);
        } else {
            $('#dcVisitAll').prop('checked', true);
        }
        updateDrugCenterBanner();
        var savedMonths = localStorage.getItem('tham_lookback_months');
        if (savedMonths !== null && $('#search_months option[value="' + savedMonths + '"]').length) {
            $('#search_months').val(savedMonths);
        }
        var savedTmt = localStorage.getItem('tham_smart_drug_tmt_name');
        if (savedTmt === '0') {
            $('#showTmtName').prop('checked', false);
        } else if (savedTmt === '1') {
            $('#showTmtName').prop('checked', true);
        }
        updateDrugNameModeHint();
        loadTmtExcept();
    } catch (e) {}
    $('#includeNetwork').on('change', function () {
        try { localStorage.setItem('tham_network_hospitals', this.checked ? '1' : '0'); } catch (e) {}
    });
    $('#includeJhcis').on('change', function () {
        try { localStorage.setItem('tham_jhcis_pcc', this.checked ? '1' : '0'); } catch (e) {}
    });
    $('#includeDrugCenter').on('change', function () {
        try { localStorage.setItem('tham_drug_center', this.checked ? '1' : '0'); } catch (e) {}
        updateDrugCenterBanner();
        if (baseHistoryData && baseHistoryData.length) {
            applyDrugCenterMerge();
        }
    });
    $('input[name="dcVisitMode"]').on('change', function () {
        try { localStorage.setItem('tham_drug_center_visit_mode', this.value); } catch (e) {}
        applyDrugCenterMerge();
    });
    $('#showTmtName').on('change', function () {
        try { localStorage.setItem('tham_smart_drug_tmt_name', this.checked ? '1' : '0'); } catch (e) {}
        applyDrugNameMode();
    });
    $('#btnTmtExcept').on('click', function () {
        $('#tmtExceptHits').html('<div class="p-2 text-muted small">ค้นหายาแล้วกดยกเว้น</div>');
        bootstrap.Modal.getOrCreateInstance(document.getElementById('tmtExceptModal')).show();
        loadTmtExcept();
    });
    $('#tmtExceptSearch').on('click', searchTmtExcept);
    $('#tmtExceptQ').on('keydown', function (e) {
        if (e.key === 'Enter') searchTmtExcept();
    });
    $('#tmtExceptHits').on('click', '[data-tmt-except-add]', function () {
        const hits = $('#tmtExceptHits').data('hits') || [];
        const it = hits[Number($(this).attr('data-tmt-except-add'))];
        if (!it) return;
        fetch('fetch_smart_drug_tmt_except_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'add',
                icode: it.icode,
                tpu_code: it.tpu_code || '',
                name_local: it.name_local || '',
                name_tmt: it.name_tmt || ''
            })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (!data || data.status !== 'success') {
                alert((data && data.message) || 'บันทึกไม่สำเร็จ');
                return;
            }
            tmtExceptApply(data.items || []);
        });
    });
    $('#tmtExceptList').on('click', '[data-tmt-except-del]', function () {
        const id = Number($(this).attr('data-tmt-except-del'));
        if (!id) return;
        fetch('fetch_smart_drug_tmt_except_api.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'delete', id: id })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (data && data.status === 'success') tmtExceptApply(data.items || []);
        });
    });
    $('#search_months').on('change', function () {
        try { localStorage.setItem('tham_lookback_months', this.value); } catch (e) {}
    });
    if ($('#search_hn').val().trim() !== '') {
        fetchSmartDrugData();
    }
});

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function extractMgFromText(text) {
    if (!text) return null;
    let mcgMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:mcg|µg|μg|ug|ไมโครกรัม)/i);
    if (mcgMatch) return parseFloat(mcgMatch[1]) / 1000;
    let mgMatch = text.match(/(\d+(?:\.\d+)?)\s*mg(?![a-z])/i);
    if (mgMatch) return parseFloat(mgMatch[1]);
    let gMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:g|gm|gram|กร\.?|กรัม)(?![a-zA-Z])/i);
    if (gMatch) return parseFloat(gMatch[1]) * 1000;
    return null;
}

function parseQtyFromUsage(text) {
    if (!text) return null;
    let half = text.match(/(\d+(?:\.\d+)?)\s*เม็ด\s*ครึ่ง/i);
    if (half) return { qty: parseFloat(half[1]) + 0.5, unit: 'เม็ด' };
    if (/เม็ด\s*ครึ่ง|ครึ่ง\s*เม็ด/i.test(text)) return { qty: 0.5, unit: 'เม็ด' };

    let pill = text.match(/(?:ครั้งละ|รับประทานครั้งละ|ทานครั้งละ|ใช้ครั้งละ)?\s*(\d+(?:\.\d+)?)\s*เม็ด/i);
    if (pill) return { qty: parseFloat(pill[1]), unit: 'เม็ด' };

    let cap = text.match(/(\d+(?:\.\d+)?)\s*(?:capsules?|cap\b|tablets?|tabs?\b)/i);
    if (cap) return { qty: parseFloat(cap[1]), unit: 'เม็ด' };

    let spoon = text.match(/(\d+(?:\.\d+)?)\s*ช้อน(?:โต๊ะ|โต้ะ|ชา|tea)?/i);
    if (spoon) return { qty: parseFloat(spoon[1]), unit: 'ช้อน' };

    let sachet = text.match(/(\d+(?:\.\d+)?)\s*(?:ซอง|sachet)/i);
    if (sachet) return { qty: parseFloat(sachet[1]), unit: 'ซอง' };

    return null;
}

function parseStrengthMg(strength, units) {
    const s = String(strength ?? '').trim().toLowerCase();
    let u = String(units ?? '').trim().toLowerCase();
    // รหัสหน่วยขาย JHCIS เช่น 027, 006 ไม่ใช่ความแรง
    if (/^\d{2,4}$/.test(u)) u = '';
    const combined = (s + ' ' + u).trim();
    if (!combined) return null;

    const hasMass = /\bmcg\b|µg|μg|\bug\b|ไมโครกรัม|\bmg\b|มิลลิกรัม|มก\.?|\b(?:gm|grams?|กรัม)\b/i.test(combined)
        || /(?:^|[\s(])\d+(?:\.\d+)?\s*g(?:\b|\.|$)/i.test(combined);
    const hasVolumeOnly = /\b(?:ml|cc|มล\.?|ซีซี)\b/i.test(combined) && !hasMass;
    if (hasVolumeOnly) return null;

    // ยาผสม เช่น 875/125 mg — ใช้ตัวเลขแรก (ส่วนประกอบหลัก)
    // บางระบบติดหน่วย g ผิด (เช่น 875/125 g) ให้ถือเป็น mg เมื่อค่าสูง
    const ratio = combined.match(/(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)/);
    if (ratio) {
        const a = parseFloat(ratio[1]);
        if (/\bmcg\b|µg|μg|\bug\b|ไมโครกรัม/i.test(combined)) return a / 1000;
        if (/\bmg\b|มิลลิกรัม|มก\./i.test(combined) || a >= 50) return a;
        if (/\b(?:g|gm|gram|กร\.?|กรัม)\b/i.test(combined)) return a * 1000;
        return a;
    }

    let mcgMatch = combined.match(/(\d+(?:\.\d+)?)\s*(?:mcg|µg|μg|ug|ไมโครกรัม)/i);
    if (mcgMatch) return parseFloat(mcgMatch[1]) / 1000;
    let mgMatch = combined.match(/(\d+(?:\.\d+)?)\s*(?:mg|มิลลิกรัม|มก\.?)/i);
    if (mgMatch) return parseFloat(mgMatch[1]);
    let gMatch = combined.match(/(\d+(?:\.\d+)?)\s*(?:gm|grams?|กรัม|กร\.)\b/i)
        || combined.match(/(\d+(?:\.\d+)?)\s*g\b/i);
    if (gMatch) return parseFloat(gMatch[1]) * 1000;

    // ใช้ตัวเลขจากช่องความแรงเท่านั้น ไม่ดึงจากรหัสหน่วย
    const numMatch = s.match(/(\d+(?:\.\d+)?)/);
    if (!numMatch) return null;
    const num = parseFloat(numMatch[1]);
    if (!isFinite(num) || num <= 0) return null;
    if (/^\d+(?:\.\d+)?$/.test(s)) return num;
    return null;
}

function parseTimesPerDay(text) {
    if (!text) return { times: null, timesMax: null, note: '' };
    const t = String(text).replace(/\s+/g, ' ').trim();

    let m = t.match(/วันละ\s*(\d+(?:\.\d+)?)\s*ครั้ง/i);
    if (m) {
        const n = parseFloat(m[1]);
        return { times: n, timesMax: null, note: 'วันละ ' + n + ' ครั้ง' };
    }
    if (/วันละ\s*(?:หนึ่ง)?ครั้ง|วันละครั้ง/i.test(t)) {
        return { times: 1, timesMax: null, note: 'วันละ 1 ครั้ง' };
    }

    m = t.match(/ทุก\s*(\d+(?:\.\d+)?)\s*(?:-|–|ถึง|ถึง\s*)?\s*(\d+(?:\.\d+)?)?\s*(?:ชั่วโมง|ชม\.?|hrs?|hours?)/i);
    if (m) {
        const a = parseFloat(m[1]);
        const b = m[2] ? parseFloat(m[2]) : a;
        if (a > 0 && b > 0) {
            const lo = Math.min(a, b);
            const hi = Math.max(a, b);
            const tMin = 24 / hi;
            const tMax = 24 / lo;
            const note = (lo === hi) ? ('ทุก ' + lo + ' ชม.') : ('ทุก ' + lo + '-' + hi + ' ชม.');
            return { times: tMin, timesMax: (tMax !== tMin ? tMax : null), note: note };
        }
    }

    m = t.match(/\bq\s*\.?\s*(\d+(?:\.\d+)?)\s*h\b/i);
    if (m) {
        const hrs = parseFloat(m[1]);
        if (hrs > 0) {
            return { times: 24 / hrs, timesMax: null, note: 'ทุก ' + hrs + ' ชม.' };
        }
    }

    // JHCIS เช่น "1เม็ด 3เวลาหลังอาหาร"
    m = t.match(/(\d+(?:\.\d+)?)\s*เวลา/i);
    if (m) {
        const n = parseFloat(m[1]);
        if (n > 0) return { times: n, timesMax: null, note: 'วันละ ' + n + ' ครั้ง' };
    }

    if (/\bqid\b|วันละ\s*สี่|four times daily/i.test(t) || /เช้า.+(?:กลางวัน|เที่ยง).+เย็น.+(?:ก่อนนอน|นอน)/i.test(t)) {
        return { times: 4, timesMax: null, note: 'วันละ 4 ครั้ง' };
    }
    if (/\btid\b|วันละ\s*สาม|three times daily/i.test(t) || /เช้า.+(?:กลางวัน|เที่ยง).+เย็น/i.test(t)) {
        return { times: 3, timesMax: null, note: 'วันละ 3 ครั้ง' };
    }
    if (/\bbid\b|วันละ\s*สอง|twice daily/i.test(t) || /เช้า.+(?:และ)?\s*เย็น/i.test(t)) {
        return { times: 2, timesMax: null, note: 'วันละ 2 ครั้ง' };
    }
    if (/\b(?:od|qd|qhs|once daily)\b/i.test(t) || /ก่อนนอน|ก่อนเข้านอน|\bhs\b/i.test(t)) {
        return { times: 1, timesMax: null, note: 'วันละ 1 ครั้ง' };
    }
    // JHCIS เช่น "1เม็ด หลังอาหารเช้า"
    if (/(?:หลังอาหาร|ก่อนอาหาร)?\s*เช้า\s*$/i.test(t) && !/กลางวัน|เที่ยง|เย็น|ก่อนนอน/i.test(t)) {
        return { times: 1, timesMax: null, note: 'วันละ 1 ครั้ง' };
    }
    return { times: null, timesMax: null, note: '' };
}

function formatStrengthLabel(item) {
    let s = String(item.strength ?? '').trim();
    let u = String(item.units ?? '').trim();
    if (/^\d{2,4}$/.test(u)) u = '';
    if (!s) return '';
    // 875/125 g ใน HOSxP มักเป็น mg ของยาผสม
    if (/^\d+(?:\.\d+)?\s*\/\s*\d+(?:\.\d+)?\s*g$/i.test(s) && parseFloat(s) >= 50) {
        s = s.replace(/\s*g$/i, ' mg');
    }
    if (/mg|mcg|µg|μg|g\b|ml|iu|unit|%/i.test(s)) return s;
    if (u && !new RegExp('\\b' + u.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i').test(s)) {
        return (s + ' ' + u).trim();
    }
    return s;
}

function parseDrugDose(item) {
    const usage = (item.method || '').trim();
    const orderQty = parseFloat(item.qty);
    const name = (item.drug_name || item.drug_name_local || '').trim();
    let strengthMg = parseStrengthMg(item.strength, item.units);
    if (strengthMg === null && name) {
        strengthMg = parseStrengthMg(name, '');
    }

    let pillQty = null;
    let pillUnit = 'หน่วย';
    const fromUsage = parseQtyFromUsage(usage);
    if (fromUsage) {
        pillQty = fromUsage.qty;
        pillUnit = fromUsage.unit;
    } else if (!isNaN(orderQty) && orderQty > 0) {
        pillQty = orderQty;
        const u = (item.units || '').trim();
        if (/เม็ด|tab|cap/i.test(u)) pillUnit = 'เม็ด';
        else if (u) pillUnit = u;
    }

    let mgPerDose = null;
    let mgNote = '';
    if (strengthMg !== null && fromUsage) {
        mgPerDose = strengthMg * fromUsage.qty;
        mgNote = 'ความแรง × ครั้งละ';
    } else {
        mgPerDose = extractMgFromText(usage);
    }

    const freq = parseTimesPerDay(usage);
    let mgDay = null;
    let mgDayMax = null;
    if (mgPerDose !== null && freq.times) {
        mgDay = mgPerDose * freq.times;
        if (freq.timesMax) mgDayMax = mgPerDose * freq.timesMax;
        mgNote = freq.note || 'จากวิธีใช้';
    } else if (mgPerDose !== null) {
        mgDay = mgPerDose;
        mgNote = 'ต่อครั้ง (ไม่ระบุจำนวนครั้ง/วัน)';
    }

    return {
        pill_qty: fromUsage ? fromUsage.qty : pillQty,
        pill_unit: fromUsage ? fromUsage.unit : pillUnit,
        mg_dose: mgDay,
        mg_dose_max: mgDayMax,
        mg_note: mgNote,
        usage_display: usage || '-',
        strength_label: formatStrengthLabel(item)
    };
}

function enrichDose(item) {
    const parsed = parseDrugDose(item);
    item.pill_qty = parsed.pill_qty;
    item.pill_unit = parsed.pill_unit;
    item.mg_dose = parsed.mg_dose;
    item.mg_dose_max = parsed.mg_dose_max;
    item.mg_note = parsed.mg_note;
    item.usage_display = parsed.usage_display;
    item.strength_label = parsed.strength_label;
    return item;
}

function formatQtyDisplay(qty, unit, colorClass) {
    if (qty === null || qty === undefined || isNaN(qty)) return '<span class="text-muted">-</span>';
    const display = Number.isInteger(qty) ? qty : qty.toLocaleString(undefined, { maximumFractionDigits: 2 });
    const cls = colorClass || 'text-primary';
    return `<span class="fw-bold ${cls} fs-5">${display}</span> <span class="text-muted fw-bold">${escapeHtml(unit || '')}</span>`;
}

function formatOrderQtyDisplay(item) {
    const qty = parseFloat(item.qty);
    let unit = (item.units || '').trim();
    if (/^\d{2,4}$/.test(unit)) unit = '';
    unit = unit || 'หน่วย';
    return formatQtyDisplay(isNaN(qty) ? null : qty, unit, 'text-success');
}

function toggleCalcQtyColumn() {
    $('#drugTable').toggleClass('show-calc-qty', $('#toggleCalcQtyCol').is(':checked'));
}

function showPatientAllergy(allergy) {
    const $el = $('#patientAllergy');
    const has = !!(allergy && allergy.has_allergy);
    const text = String((allergy && allergy.text) || '').trim();
    if (has && text) {
        $el.removeClass('text-success').addClass('text-danger').html('แพ้ยา: ' + escapeHtml(text));
    } else {
        $el.removeClass('text-danger').addClass('text-success').text('ไม่แพ้ยา');
    }
}

function smartDrugProviderLoginReturnUrl() {
    let path = 'smart_drug.php';
    const hn = String($('#hnInput').val() || '').trim();
    if (hn) {
        path += '?hn=' + encodeURIComponent(hn);
    }
    return path;
}

function goProviderLoginForDrugCenter() {
    const ret = smartDrugProviderLoginReturnUrl();
    window.location.href = 'login.php?provider_login=1&return=' + encodeURIComponent(ret);
    return false;
}

function updateDrugCenterBanner() {
    const on = $('#includeDrugCenter').is(':checked');
    const $box = $('#drugCenterBanner');
    const $txt = $('#drugCenterBannerText');
    if (!on) {
        $box.addClass('d-none');
        $('#dcVisitModeBar').addClass('d-none');
        return;
    }
    $box.removeClass('d-none alert-success alert-warning alert-danger');
    if (SD_DC_READY) {
        $box.addClass('alert-success');
        $txt.html('เปิดใช้แล้ว — จะดึง Med Reconcile และแพ้ยาจาก Drug Center หลังค้นหา HN (ต้อง Login Provider ID)');
    } else if (!(SD_DC_OAUTH && SD_DC_OAUTH.has_moph_token)) {
        $box.addClass('alert-warning');
        $txt.html('ยังไม่ได้ Login ผ่าน Provider ID — ต้องเข้าสู่ระบบด้วย Provider ID จึงจะดึง Med Reconcile / แพ้ยา จาก Drug Center ได้ <a href="#" class="alert-link fw-bold" onclick="return goProviderLoginForDrugCenter();">ไปหน้า Login</a>');
    } else {
        $box.addClass('alert-warning');
        $txt.html('ยังไม่ได้ตั้งค่า Drugs Center apiKey');
    }
}

function mergeAllergyTexts(a, b) {
    const agents = [];
    function pushFrom(src) {
        if (!src) return;
        (src.agents || []).forEach(function (x) {
            const t = String(x || '').trim();
            if (t && agents.indexOf(t) < 0) agents.push(t);
        });
        if ((!src.agents || !src.agents.length) && src.has_allergy && src.text) {
            String(src.text).split(/[,;]/).forEach(function (x) {
                const t = String(x || '').trim();
                if (t && t.indexOf('ไม่แพ้') < 0 && agents.indexOf(t) < 0) agents.push(t);
            });
        }
    }
    pushFrom(a);
    pushFrom(b);
    if (!agents.length) {
        return a || b || { has_allergy: false, text: '', agents: [] };
    }
    return { has_allergy: true, text: agents.join(', '), agents: agents };
}

function dcDedupeKey(item) {
    const d = String(item.vstdate_iso || item.order_date_iso || '').slice(0, 10);
    const tpu = String(item.tpu_code || '').trim().toLowerCase();
    if (tpu) return 'tpu:' + tpu + '|' + d;
    const name = String(item.drug_name || item.name || '').trim().toLowerCase().replace(/\s+/g, ' ');
    return 'n:' + name + '|' + d;
}

function applyDrugCenterMerge() {
    const useDc = $('#includeDrugCenter').is(':checked') && dcHistoryRaw.length;
    if (!useDc) {
        globalHistoryData = (baseHistoryData || []).slice();
        globalVisits = (baseVisits || []).slice();
        showPatientAllergy(baseAllergy);
        $('#dcVisitModeBar').addClass('d-none');
        $('#dcMergeMeta').text('');
        if (globalHistoryData.length) {
            populateHospitalFilter(globalVisits, {});
            populateDrugFilter(globalHistoryData);
            renderVisitList(visibleVisits());
            if (globalVisits.length) {
                selectVisit(visibleVisits()[0] ? visibleVisits()[0].visit_key : globalVisits[0].visit_key);
            }
        }
        return;
    }
    $('#dcVisitModeBar').removeClass('d-none');
    const mode = $('input[name="dcVisitMode"]:checked').val() || 'all';
    let dcHist = dcHistoryRaw.slice();
    let dropped = 0;
    if (mode === 'dedupe') {
        const prefer = {};
        (baseHistoryData || []).forEach(function (it) {
            prefer[dcDedupeKey(it)] = true;
        });
        dcHist = dcHist.filter(function (it) {
            const k = dcDedupeKey(it);
            if (prefer[k]) {
                dropped++;
                return false;
            }
            return true;
        });
    }
    const dcVisits = [];
    const vkeys = {};
    dcHist.forEach(function (it) {
        const vk = it.visit_key;
        if (!vk || vkeys[vk]) return;
        vkeys[vk] = true;
        const v = (dcVisitsRaw || []).find(function (x) { return x.visit_key === vk; });
        if (v) dcVisits.push(v);
    });
    globalHistoryData = (baseHistoryData || []).concat(dcHist.map(enrichDose));
    globalVisits = (baseVisits || []).concat(dcVisits);
    globalVisits.sort(function (a, b) {
        return String(b.vstdate_iso || '').localeCompare(String(a.vstdate_iso || ''));
    });
    showPatientAllergy(mergeAllergyTexts(baseAllergy, dcAllergyRaw));
    $('#dcMergeMeta').text(
        'Drug Center +' + dcHist.length + ' รายการ · Visit +' + dcVisits.length
        + (mode === 'dedupe' && dropped ? (' · ตัดซ้ำ ' + dropped) : '')
    );
    populateHospitalFilter(globalVisits, {});
    populateDrugFilter(globalHistoryData);
    renderVisitList(visibleVisits());
    if (globalVisits.length) {
        selectVisit(visibleVisits()[0] ? visibleVisits()[0].visit_key : globalVisits[0].visit_key);
    }
}

async function fetchDrugCenterForSmartDrug(hn, months) {
    dcHistoryRaw = [];
    dcVisitsRaw = [];
    dcAllergyRaw = null;
    if (!$('#includeDrugCenter').is(':checked')) {
        $('#dcVisitModeBar').addClass('d-none');
        return null;
    }
    if (!SD_DC_READY) {
        updateDrugCenterBanner();
        $('#dcMergeMeta').text('ข้าม Drug Center — ยังไม่มี Provider ID token');
        return null;
    }
    try {
        const res = await fetch('fetch_drug_center_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'smart_drug_dc', hn: hn, months: months })
        });
        const data = await res.json();
        if (!data || data.status !== 'ok') {
            $('#dcMergeMeta').text((data && data.message) || 'ดึง Drug Center ไม่สำเร็จ');
            if (data && data.need_provider) updateDrugCenterBanner();
            return data;
        }
        dcHistoryRaw = data.history || [];
        dcVisitsRaw = data.visits || [];
        dcAllergyRaw = data.allergy || null;
        return data;
    } catch (e) {
        $('#dcMergeMeta').text('เชื่อม Drug Center ไม่สำเร็จ');
        return null;
    }
}

function showPatientInfo(patient, allergy) {
    globalPatient = patient || null;
    if (!patient || !patient.full_name) {
        $('#patientInfoRow').hide();
        return;
    }
    $('#patientName').text(patient.full_name);
    $('#patientHnDisplay').text(patient.hn || $('#search_hn').val().trim());
    showPatientAllergy(allergy);
    $('#patientInfoRow').show();
    loadMedReconHistory(patient.hn || $('#search_hn').val().trim());
}

function clearPatientInfo() {
    globalPatient = null;
    $('#patientInfoRow').hide();
    $('#patientName').text('-');
    $('#patientHnDisplay').text('');
    $('#patientAllergy').text('').removeClass('text-danger text-success');
    $('#btnMedReconHist, #mrHistPatientTab, #btnMedReconHistHidden, #mrHistPatientHidden').hide();
    medReconHistItems = [];
    mrHistUnhiddenAn = '';
}

function formatMgDisplay(mg, note, mgMax) {
    if (mg === null || mg === undefined || isNaN(mg)) return '<span class="text-muted">-</span>';
    const fmt = (v) => {
        const frac = (v > 0 && v < 1) ? 4 : 2;
        return v.toLocaleString(undefined, { maximumFractionDigits: frac });
    };
    let num = fmt(mg);
    if (mgMax !== null && mgMax !== undefined && !isNaN(mgMax) && mgMax > mg) {
        num += '–' + fmt(mgMax);
    }
    let html = `<span class="fw-bold text-danger fs-5">${num}</span> <span class="text-muted fw-bold">mg/วัน</span>`;
    if (note) html += `<br><small class="text-muted">${escapeHtml(note)}</small>`;
    return html;
}

function formatLoadMs(ms) {
    ms = parseInt(ms, 10) || 0;
    if (ms < 1000) return ms + ' ms';
    return (ms / 1000).toFixed(1) + ' วินาที';
}

function startSmartDrugClock() {
    stopSmartDrugClock();
    const t0 = Date.now();
    const tick = function () {
        const s = ((Date.now() - t0) / 1000).toFixed(1);
        $('#resultMeta').html('<i class="fas fa-clock me-1"></i>กำลังโหลด... <strong>' + s + '</strong> วินาที');
    };
    tick();
    smartDrugLoadTimer = setInterval(tick, 100);
}

function stopSmartDrugClock() {
    if (smartDrugLoadTimer) {
        clearInterval(smartDrugLoadTimer);
        smartDrugLoadTimer = null;
    }
}

function timingSummary(meta) {
    const t = (meta && meta.timing) ? meta.timing : {};
    if (!t.total_ms && t.total_ms !== 0) return '';
    let s = 'ใช้เวลา <strong>' + formatLoadMs(t.total_ms) + '</strong>';
    const parts = [];
    if (t.local_ms || t.local_ms === 0) parts.push('รพ.นี้ ' + formatLoadMs(t.local_ms));
    if (t.network_ms > 0) parts.push('เครือข่ายขนาน ' + formatLoadMs(t.network_ms));
    if (t.jhcis_ms > 0) parts.push('JHCIS ' + formatLoadMs(t.jhcis_ms));
    if (parts.length) s += ' <span class="text-muted">(' + parts.join(' · ') + ')</span>';
    return s;
}

function lookbackLabel(months) {
    const n = parseInt(months, 10);
    if (LOOKBACK_LABELS.hasOwnProperty(n)) return LOOKBACK_LABELS[n];
    return n > 0 ? n + ' เดือน' : 'ทั้งหมด';
}

async function fetchSmartDrugData() {
    let hn = $('#search_hn').val().trim();
    if (!hn) { alert('กรุณาระบุ HN ก่อนครับ'); return; }

    if (!isNaN(hn) && hn.length > 0 && hn.length < 9) {
        hn = hn.padStart(9, '0');
        $('#search_hn').val(hn);
    }

    selectedVisitKey = null;
    medReconRows = [];
    $('#resultMeta').text('');
    $('#networkStatus').html('');
    selectedHospitalCode = 'all';
    $('#hospitalFilter').html('<option value="all">ทุกโรงพยาบาล</option>');
    clearPatientInfo();

    const includeNetwork = $('#includeNetwork').is(':checked');
    const includeJhcis = $('#includeJhcis').is(':checked');
    const includeDc = $('#includeDrugCenter').is(':checked');
    $('#visitList').html('<div class="text-center text-primary py-5"><i class="fas fa-spinner fa-spin fa-2x"></i><div class="mt-2 small">กำลังโหลด Visit...</div></div>');
    $('#drugHistoryTbody').html('<tr><td colspan="6" class="text-center text-primary py-5"><i class="fas fa-spinner fa-spin fa-2x mb-2 d-block"></i> กำลังดึงข้อมูลจาก HOSxP' + (includeNetwork ? ' และรพ.ในเครือข่าย' : '') + (includeJhcis ? ' และ JHCIS PCC' : '') + (includeDc ? ' และ Drug Center' : '') + '...</td></tr>');
    $('#selectedVisitBar').html('<i class="fas fa-calendar-check me-1"></i> กำลังโหลด...');
    $('#analysisSection').hide();
    hideMedTimeline();
    startSmartDrugClock();
    dcHistoryRaw = [];
    dcVisitsRaw = [];
    dcAllergyRaw = null;
    baseHistoryData = [];
    baseVisits = [];
    baseAllergy = null;

    const months = parseInt($('#search_months').val(), 10);
    const monthsVal = [3, 6, 12, 36, 60, 0].indexOf(months) >= 0 ? months : 12;
    const limit = monthsVal === 0 ? 5000 : 3000;
    try { localStorage.setItem('tham_lookback_months', String(monthsVal)); } catch (e) {}

    try {
        const response = await fetch('fetch_hosxp_history_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ hn: hn, months: monthsVal, limit: limit, include_network: includeNetwork, include_jhcis: includeJhcis })
        });

        const raw = await response.text();
        let data;
        try {
            data = JSON.parse(raw);
        } catch (e) {
            throw new Error('เซิร์ฟเวอร์ตอบกลับไม่ถูกต้อง — ลองเลือกช่วงเวลาที่สั้นลง');
        }

        stopSmartDrugClock();
        const timeHtml = timingSummary(data.meta || {});
        const lookHtml = 'ย้อนหลัง ' + lookbackLabel((data.meta && data.meta.months != null) ? data.meta.months : monthsVal);

        if (data.status === 'success') {
            medReconVisitAppts = Array.isArray(data.visit_appointments) ? data.visit_appointments : [];
        }

        if (data.status === 'success' && data.history && data.history.length > 0) {
            baseHistoryData = data.history.map(enrichDose);
            baseVisits = data.visits || [];
            baseAllergy = data.allergy || null;
            globalHistoryData = baseHistoryData.slice();
            globalVisits = baseVisits.slice();
            showPatientInfo(data.patient, data.allergy);
            populateHospitalFilter(globalVisits, data.meta || {});
            populateDrugFilter(globalHistoryData);
            renderNetworkStatus(data.meta || {});
            renderVisitList(visibleVisits());

            if (globalVisits.length > 0) {
                selectVisit(visibleVisits()[0] ? visibleVisits()[0].visit_key : globalVisits[0].visit_key);
            }

            if (includeDc) {
                $('#dcMergeMeta').text('กำลังดึง Drug Center...');
                await fetchDrugCenterForSmartDrug(hn, monthsVal);
                applyDrugCenterMerge();
            } else {
                $('#dcVisitModeBar').addClass('d-none');
            }

            const ipdCount = globalVisits.filter(v => v.visit_type === 'ipd').length;
            const opdCount = globalVisits.length - ipdCount;
            const netHit = (data.meta && data.meta.network_hit) ? data.meta.network_hit : 0;
            const jhcisRows = (data.meta && data.meta.jhcis && data.meta.jhcis.rows) ? data.meta.jhcis.rows : 0;
            let metaText = `${globalVisits.length} Visit (OPD ${opdCount} · IPD ${ipdCount}) · ${globalHistoryData.length} รายการยา`;
            if (netHit > 0) metaText += ` · พบยาจากรพ.เครือข่าย ${netHit} แห่ง`;
            if (jhcisRows > 0) metaText += ` · JHCIS ${jhcisRows} รายการ`;
            if (dcHistoryRaw.length) metaText += ` · Drug Center ${dcHistoryRaw.length} รายการ`;
            metaText += ` · ${lookHtml}`;
            if (data.meta && data.meta.truncated) metaText += ' — สูงสุด ' + (data.meta.limit || limit) + ' รายการ';
            if (data.meta && data.meta.widened) metaText += ' · ไม่พบในช่วงที่เลือก จึงแสดงประวัติทั้งหมด';
            $('#resultMeta').html(metaText + (timeHtml ? '<br>' + timeHtml : ''));
        } else if (data.status === 'success') {
            baseHistoryData = [];
            baseVisits = [];
            baseAllergy = data.allergy || null;
            globalHistoryData = [];
            globalVisits = [];
            showPatientInfo(data.patient, data.allergy);
            renderNetworkStatus(data.meta || {});
            if (includeDc) {
                $('#dcMergeMeta').text('กำลังดึง Drug Center...');
                await fetchDrugCenterForSmartDrug(hn, monthsVal);
                applyDrugCenterMerge();
                if (globalHistoryData.length) {
                    const ipdCount = globalVisits.filter(v => v.visit_type === 'ipd').length;
                    $('#resultMeta').html(`Drug Center ${dcHistoryRaw.length} รายการ · Visit ${globalVisits.length} (IPD ${ipdCount}) · ${lookHtml}` + (timeHtml ? ' · ' + timeHtml : ''));
                }
            }
            if (!globalHistoryData.length) {
                $('#visitList').html('<div class="text-center text-warning py-4 px-2 small">ไม่พบ Visit ที่มีรายการยา</div>');
                $('#drugHistoryTbody').html('<tr><td colspan="6" class="text-center text-warning py-5">ไม่พบประวัติการรับยาในช่วงเวลาที่เลือก</td></tr>');
                $('#selectedVisitBar').html('<i class="fas fa-info-circle me-1"></i> ไม่พบข้อมูล');
                $('#resultMeta').html(lookHtml + (timeHtml ? ' · ' + timeHtml : ''));
                hideMedTimeline();
            }
        } else {
            $('#visitList').html('<div class="text-danger py-4 px-2 small text-center">' + escapeHtml(data.message) + '</div>');
            $('#drugHistoryTbody').html('<tr><td colspan="6" class="text-center text-danger py-5">' + escapeHtml(data.message || 'เกิดข้อผิดพลาด') + '</td></tr>');
            $('#resultMeta').html(timeHtml || '');
        }
    } catch (err) {
        stopSmartDrugClock();
        $('#visitList').html('<div class="text-danger py-4 px-2 small text-center">' + escapeHtml(err.message) + '</div>');
        $('#drugHistoryTbody').html('<tr><td colspan="6" class="text-center text-danger py-5">' + escapeHtml(err.message) + '</td></tr>');
        console.error(err);
    }
}

function hospitalShortName(name) {
    return String(name || '').replace(/^โรงพยาบาล/u, '').replace(/^รพ\./u, '').trim() || 'รพ.';
}

function mrHospitalFromItem(item) {
    let name = String((item && item.hospital_name) || '').trim();
    let code = String((item && item.hospital_code) || '').trim();
    if ((!name || !code) && item && item.visit_key) {
        const v = (globalVisits || []).find(x => (x.visit_key || ('opd:' + x.vn)) === item.visit_key);
        if (v) {
            if (!name) name = String(v.hospital_name || '').trim();
            if (!code) code = String(v.hospital_code || '').trim();
        }
    }
    return { hospital_name: name, hospital_code: code || 'local' };
}

function mrHospitalPrintLabel(name) {
    let s = hospitalShortName(name);
    if (!s || s === 'รพ.') return '';
    s = s.replace(/^สมเด็จพระยุพราช/u, 'รพร.').trim();
    if (s === 'นี้ (HOSxP)' || s === 'นี้') s = 'สระแก้ว';
    return s;
}

function hospitalBadge(visit) {
    const name = visit.hospital_name || '';
    if (!name) return '';
    const isLocal = (visit.hospital_code || 'local') === 'local';
    return `<div class="mt-1"><span class="visit-badge-hosp${isLocal ? ' local' : ''}" title="${escapeHtml(name)}">${escapeHtml(hospitalShortName(name))}</span></div>`;
}

function visibleVisits() {
    if (selectedHospitalCode === 'all') return globalVisits;
    return globalVisits.filter(v => (v.hospital_code || 'local') === selectedHospitalCode);
}

function populateHospitalFilter(visits, meta) {
    const seen = {};
    const opts = [['all', 'ทุกโรงพยาบาล']];
    const localName = (meta.local_hospital && meta.local_hospital.name) ? meta.local_hospital.name : 'รพ.นี้ (HOSxP)';
    opts.push(['local', localName]);
    seen.local = true;
    (visits || []).forEach(v => {
        const c = v.hospital_code || 'local';
        if (seen[c]) return;
        seen[c] = true;
        opts.push([c, v.hospital_name || c]);
    });
    let html = '';
    opts.forEach(([val, label]) => {
        html += `<option value="${escapeHtml(val)}">${escapeHtml(label)}</option>`;
    });
    $('#hospitalFilter').html(html);
    selectedHospitalCode = 'all';
}

function onHospitalFilterChange() {
    selectedHospitalCode = $('#hospitalFilter').val() || 'all';
    const list = visibleVisits();
    renderVisitList(list);
    if (list.length) {
        selectVisit(list[0].visit_key);
    } else {
        $('#drugHistoryTbody').html('<tr><td colspan="6" class="text-center text-muted py-4">ไม่มี Visit ของรพ.นี้</td></tr>');
        $('#selectedVisitBar').html('<i class="fas fa-info-circle me-1"></i> ไม่มี Visit ของรพ.ที่เลือก');
        hideMedTimeline();
    }
}

function renderNetworkStatus(meta) {
    const sources = ((meta && meta.network) ? meta.network.slice() : []);
    if (meta && meta.jhcis) {
        sources.push(meta.jhcis);
    }
    if (!sources.length) {
        $('#networkStatus').html('');
        return;
    }
    let html = '';
    sources.forEach(s => {
        const label = hospitalShortName(s.name || s.code);
        if (s.ok && (s.rows || 0) > 0) {
            html += `<span class="chip" title="${escapeHtml(s.name || '')}"><i class="fas fa-check-circle text-success me-1"></i>${escapeHtml(label)} ${s.visits} visit / ${s.rows} ยา · ${formatLoadMs(s.ms)}</span>`;
        } else if (s.ok) {
            html += `<span class="chip miss" title="เชื่อมได้ แต่ไม่พบผู้ป่วย"><i class="far fa-circle me-1"></i>${escapeHtml(label)} ไม่พบ · ${formatLoadMs(s.ms)}</span>`;
        } else {
            const timedOut = /timeout|timed out|หมดเวลา/i.test(s.error || '');
            html += `<span class="chip err" title="${escapeHtml(s.error || '')}"><i class="fas fa-exclamation-triangle me-1"></i>${escapeHtml(label)}${timedOut ? ' หมดเวลา' : (s.error ? ' · ' + escapeHtml(s.error) : '')}${s.ms ? ' · ' + formatLoadMs(s.ms) : ''}</span>`;
        }
    });
    $('#networkStatus').html(html);
}

function visitKeyOf(row) {
    return row.visit_key || ('opd:' + (row.vn || ''));
}

function countVisitDrugs(visitKey, hmeOnly) {
    return globalHistoryData.filter(i => {
        if (visitKeyOf(i) !== visitKey) return false;
        return hmeOnly ? !!i.is_hme : true;
    }).length;
}

function visitHasChronicDrug(v) {
    const vk = visitKeyOf(v);
    const ipdHmeOnly = v.visit_type === 'ipd' && !mrIpdShowAll;
    return (globalHistoryData || []).some(function (item) {
        if (visitKeyOf(item) !== vk || !item.is_chronic) return false;
        if (ipdHmeOnly && !item.is_hme) return false;
        return true;
    });
}

function medReconVisitWithinMonths(v, months) {
    const iso = String(v.vstdate_iso || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return true;
    const d = new Date(iso + 'T00:00:00');
    if (isNaN(d.getTime())) return true;
    const limit = new Date();
    limit.setHours(0, 0, 0, 0);
    limit.setMonth(limit.getMonth() - months);
    return d >= limit;
}

function medReconDefaultVisitKeys() {
    const groups = {};
    visibleVisits().forEach(function (v) {
        const code = String(v.hospital_code || 'local');
        if (!groups[code]) groups[code] = [];
        groups[code].push(v);
    });
    const keys = [];
    Object.keys(groups).forEach(function (code) {
        const list = groups[code].slice().sort(function (a, b) {
            const da = String(a.vstdate_iso || '') + ' ' + String(a.vsttime_display || '');
            const db = String(b.vstdate_iso || '') + ' ' + String(b.vsttime_display || '');
            return db.localeCompare(da);
        });
        const hit = list.find(function (v) {
            if (!visitHasChronicDrug(v)) return false;
            if (code !== 'local' && !medReconVisitWithinMonths(v, 6)) return false;
            return true;
        });
        if (hit) keys.push(visitKeyOf(hit));
    });
    if (!keys.length) {
        const latest = medReconLatestVisit();
        if (latest) keys.push(visitKeyOf(latest));
    }
    return keys;
}

function ipdScopeButtonsHtml(showAll, hmeCount, totalCount) {
    const hmeOn = !showAll;
    return `<span class="ipd-scope-toggle btn-group btn-group-sm ms-2" role="group">
        <button type="button" class="btn ${hmeOn ? 'btn-success' : 'btn-outline-success'}" onclick="setIpdShowAll(false)">เฉพาะ HME</button>
        <button type="button" class="btn ${showAll ? 'btn-secondary' : 'btn-outline-secondary'}" onclick="setIpdShowAll(true)">ทั้งหมด</button>
    </span>
    <span class="small fw-normal text-muted ms-2">${hmeOn ? (hmeCount + ' HME') : (totalCount + ' รายการ')} / ${totalCount} ยา</span>`;
}

function setIpdShowAll(all) {
    ipdShowAll = !!all;
    const visit = getSelectedVisit();
    if (visit) {
        updateSelectedVisitBar(visit);
    }
    filterTableByDrug();
}

function updateSelectedVisitBar(visit) {
    const typeLabel = visit.visit_type === 'ipd'
        ? `<span class="badge visit-badge-ipd ms-1"><i class="fas fa-procedures"></i> IPD</span>`
        : `<span class="badge visit-badge-opd ms-1"><i class="fas fa-hospital-user"></i> OPD</span>`;
    const ref = visit.visit_type === 'ipd'
        ? `AN: <strong>${escapeHtml(visit.an)}</strong>${visit.ward_name ? ' · ' + escapeHtml(visit.ward_name) : ''}`
        : `VN: <strong>${escapeHtml(visit.vn)}</strong>`;
    const hosp = visit.hospital_name
        ? `<span class="badge bg-success ms-1">${escapeHtml(hospitalShortName(visit.hospital_name))}</span>`
        : '';
    const vk = visitKeyOf(visit);
    const total = visit.drug_count || countVisitDrugs(vk, false);
    const hmeCount = countVisitDrugs(vk, true);
    const scope = visit.visit_type === 'ipd' ? ipdScopeButtonsHtml(ipdShowAll, hmeCount, total) : `<span class="text-muted ms-2">(${ref} · ${total} รายการยา)</span>`;
    const ipdRef = visit.visit_type === 'ipd' ? `<span class="text-muted ms-2">(${ref})</span>` : '';
    $('#selectedVisitBar').html(
        `<i class="fas fa-calendar-check me-1"></i> Visit: <strong>${escapeHtml(visit.vstdate_display)}</strong> ${escapeHtml(visit.vsttime_display || '')} ` +
        typeLabel + hosp + ipdRef + scope
    );
}

function visitTypeBadge(visit) {
    if (visit.visit_type === 'ipd') {
        return '<span class="visit-badge visit-badge-ipd"><i class="fas fa-procedures me-1"></i>IPD</span>';
    }
    return '<span class="visit-badge visit-badge-opd"><i class="fas fa-hospital-user me-1"></i>OPD</span>';
}

function visitRefLabel(visit) {
    if (visit.source_kind === 'drug_center') {
        if (visit.visit_type === 'ipd') {
            return visit.an ? ('AN: ' + escapeHtml(visit.an)) : 'PHR (ไม่มี AN/VN)';
        }
        return visit.vn ? ('VN: ' + escapeHtml(visit.vn)) : 'PHR (ไม่มี VN)';
    }
    if (visit.visit_type === 'ipd') {
        let s = 'AN: ' + escapeHtml(visit.an || '-');
        if (visit.ward_name) s += ' · ' + escapeHtml(visit.ward_name);
        return s;
    }
    return 'VN: ' + escapeHtml(visit.vn || '-');
}

function renderVisitList(visits) {
    if (!visits.length) {
        $('#visitList').html('<div class="text-center text-muted py-4 small">ไม่มี Visit</div>');
        return;
    }

    let html = '';
    let seq = visits.length;
    visits.forEach(v => {
        const vk = v.visit_key || ('opd:' + (v.vn || ''));
        const active = (vk === selectedVisitKey) ? ' active' : '';
        const safeKey = escapeHtml(vk).replace(/'/g, '&#39;');
        html += `
            <div class="visit-item${active}" data-visit-key="${escapeHtml(vk)}" onclick="selectVisit('${safeKey}')">
                <div class="d-flex justify-content-between align-items-start gap-2">
                    <div class="flex-grow-1">
                        <div class="visit-date d-flex align-items-center gap-2">
                            <span class="visit-type-icon">${v.visit_type === 'ipd' ? '<i class="fas fa-procedures text-warning"></i>' : '<i class="fas fa-hospital-user text-primary"></i>'}</span>
                            <span>${seq}. ${escapeHtml(v.vstdate_display)}</span>
                        </div>
                        <div class="visit-meta"><i class="far fa-clock me-1"></i>${escapeHtml(v.vsttime_display || (v.source_kind === 'drug_center' ? 'ไม่ระบุเวลา' : '-'))}</div>
                        <div class="visit-meta small">${visitRefLabel(v)}</div>
                        ${hospitalBadge(v)}
                    </div>
                    <div class="text-end">
                        ${visitTypeBadge(v)}
                        <div class="mt-1"><span class="visit-badge">${v.visit_type === 'ipd' ? (countVisitDrugs(vk, true) + ' HME / ' + (v.drug_count || 0) + ' ยา') : ((v.drug_count || 0) + ' ยา')}</span></div>
                    </div>
                </div>
            </div>`;
        seq--;
    });
    $('#visitList').html(html);
}

function selectVisit(visitKey) {
    selectedVisitKey = visitKey;
    $('.visit-item').removeClass('active');
    $('.visit-item[data-visit-key="' + visitKey + '"]').addClass('active');

    const visit = globalVisits.find(v => (v.visit_key || ('opd:' + v.vn)) === visitKey);
    if (visit) {
        if (visit.visit_type === 'ipd') {
            ipdShowAll = false;
        }
        updateSelectedVisitBar(visit);
    }

    $('#analysisSection').hide();
    filterTableByDrug();
    if (medReconHistItems.length) mrHistRenderButton(medReconHistItems);
}

function isCombinationDrugName(name) {
    const s = String(name || '');
    if (!s) return false;
    if (/[+＋]/.test(s)) return true;
    // Amoxicillin/clavulanic acid
    if (/\/\s*[A-Za-zก-๙]/.test(s) && !/\d+(?:\.\d+)?\s*(?:mcg|µg|μg|ug|mg|g|ml|%)?\s*\/\s*\d/i.test(s)) {
        return true;
    }
    // สูตรเข้มข้น/ปริมาตร เช่น 900 mg/100 mL — ใช้ชื่อ drugitems
    if (/\d+(?:\.\d+)?\s*(?:mcg|µg|μg|ug|mg|g)\s*\/\s*\d+(?:\.\d+)?\s*(?:ml|mL)/i.test(s)) {
        return true;
    }
    const check = s.replace(/\d+(?:\.\d+)?\s*(?:mcg|µg|μg|ug|mg|g|iu|%)\s*\/\s*\d+(?:\.\d+)?\s*(?:ml|mL)?/gi, ' ');
    const strengthHits = check.match(/\d+(?:\.\d+)?\s*(?:mcg|µg|μg|ug|mg|g)\b/gi);
    return !!(strengthHits && strengthHits.length >= 2);
}

function normTmtExceptName(name) {
    return String(name || '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function isTmtNameExcept(item) {
    if (!item) return false;
    const tmt = normTmtExceptName(item.drug_name || '');
    return !!(tmt && tmtExceptNames[tmt]);
}

function prefersLocalDrugName(item) {
    if (!item) return false;
    if (isTmtNameExcept(item)) return true;
    const tmt = String(item.drug_name || '');
    const st = String(item.strength || item.strength_label || '');
    return isCombinationDrugItem(item)
        || isCombinationDrugName(tmt)
        || /[+＋]/.test(tmt)
        || /\d+(?:\.\d+)?\s*(?:mcg|µg|μg|ug|mg|g)\s*\/\s*\d+(?:\.\d+)?\s*(?:ml|mL)/i.test(tmt + ' ' + st);
}

function localNameWithStrength(item) {
    const name = getLocalDrugName(item) || String((item && item.drug_name) || '').trim() || '-';
    let st = localStrengthLabel(item);
    if (!st) {
        const u = String((item && item.units) || '').trim();
        if (/\d+(?:\.\d+)?\s*(?:ml|mL)/i.test(u)) st = u;
    }
    return nameWithStrength(name, st);
}

function isCombinationDrugItem(item) {
    if (!item) return false;
    return isCombinationDrugName(item.drug_name)
        || isCombinationDrugName(item.drug_name_local)
        || isCombinationDrugName(item.strength)
        || isCombinationDrugName(item.strength_label);
}

function useTmtDrugNames() {
    return $('#showTmtName').length ? $('#showTmtName').is(':checked') : false;
}

function updateDrugNameModeHint() {
    const on = useTmtDrugNames();
    const exceptN = Object.keys(tmtExceptNames).length;
    $('#nameModeHint').text(on
        ? ('เปิด = ชื่อ TMT · ยาผสมและชื่อ TMT ที่ยกเว้น ' + exceptN + ' รายการ ใช้ drugitems.name')
        : 'ปิด = แสดงชื่อจาก drugitems.name ทั้งรายการ');
    $('#showTmtName').next('label').toggleClass('text-primary', on).toggleClass('text-secondary', !on);
}

function tmtExceptApply(items) {
    tmtExceptNames = {};
    (items || []).forEach(function (it) {
        const key = normTmtExceptName(it.name_tmt || '');
        if (key) tmtExceptNames[key] = true;
    });
    const n = (items || []).length;
    $('#tmtExceptCount').text(n ? '(' + n + ')' : '');
    if (!n) {
        $('#tmtExceptList').html('<div class="p-3 text-muted small">ยังไม่มีรายการยกเว้น</div>');
    } else {
        let html = '';
        items.forEach(function (it) {
            const sample = (it.name_local && it.name_local !== it.name_tmt) ? it.name_local : '';
            html += '<div class="d-flex align-items-center gap-2 px-2 py-2 border-bottom">'
                + '<div class="flex-grow-1"><div class="fw-bold">' + escapeHtml(it.name_tmt || '-') + '</div>'
                + (sample ? '<div class="small text-muted">ตัวอย่างแบรนด์: ' + escapeHtml(sample) + '</div>' : '')
                + '</div>'
                + '<button type="button" class="btn btn-sm btn-outline-danger" data-tmt-except-del="' + it.id + '">ลบ</button>'
                + '</div>';
        });
        $('#tmtExceptList').html(html);
    }
    applyDrugNameMode();
}

function loadTmtExcept() {
    return fetch('fetch_smart_drug_tmt_except_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'list' })
    }).then(function (r) { return r.json(); }).then(function (data) {
        if (data && data.status === 'success') tmtExceptApply(data.items || []);
    }).catch(function () {});
}

function searchTmtExcept() {
    const q = String($('#tmtExceptQ').val() || '').trim();
    if (q.length < 2) {
        $('#tmtExceptHits').html('<div class="p-2 text-muted small">พิมพ์อย่างน้อย 2 ตัวอักษร</div>');
        return;
    }
    $('#tmtExceptHits').html('<div class="p-2 text-muted small">กำลังค้นหา...</div>');
    fetch('fetch_smart_drug_tmt_except_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'search', q: q })
    }).then(function (r) { return r.json(); }).then(function (data) {
        const items = (data && data.items) || [];
        if (!items.length) {
            $('#tmtExceptHits').html('<div class="p-2 text-muted small">' + escapeHtml(data && data.message ? data.message : 'ไม่พบรายการยา') + '</div>');
            return;
        }
        // รวมตามชื่อ TMT — หนึ่งชื่อ TMT = หนึ่งรายการยกเว้น
        const byTmt = {};
        const uniq = [];
        items.forEach(function (it) {
            const key = normTmtExceptName(it.name_tmt || '');
            if (!key || byTmt[key]) return;
            byTmt[key] = true;
            uniq.push(it);
        });
        if (!uniq.length) {
            $('#tmtExceptHits').html('<div class="p-2 text-muted small">ไม่พบชื่อ TMT</div>');
            return;
        }
        let html = '';
        uniq.forEach(function (it, i) {
            const sample = (it.name_local && it.name_local !== it.name_tmt) ? it.name_local : '';
            html += '<div class="d-flex align-items-center gap-2 px-2 py-2 border-bottom">'
                + '<div class="flex-grow-1"><div class="fw-bold">' + escapeHtml(it.name_tmt || '-') + '</div>'
                + (sample ? '<div class="small text-muted">ตัวอย่างแบรนด์: ' + escapeHtml(sample) + '</div>' : '')
                + '</div>'
                + '<button type="button" class="btn btn-sm btn-success" data-tmt-except-add="' + i + '">ยกเว้น</button>'
                + '</div>';
        });
        $('#tmtExceptHits').html(html);
        $('#tmtExceptHits').data('hits', uniq);
    }).catch(function () {
        $('#tmtExceptHits').html('<div class="p-2 text-danger small">ค้นหาไม่สำเร็จ</div>');
    });
}

function applyDrugNameMode() {
    updateDrugNameModeHint();
    if (globalHistoryData && globalHistoryData.length) {
        const keep = $('#drugFilter').val();
        populateDrugFilter(globalHistoryData);
        if (keep) $('#drugFilter').val(keep);
        if (selectedVisitKey) renderTable(getFilteredItems());
        renderMedTimeline();
        if (currentChartDrug) plotDrugTimeline(currentChartDrug);
    }
    if ($('#medReconModal').hasClass('show')) {
        medReconLoadDrugsFromVisits({ silent: true });
    }
}

function getLocalDrugName(item) {
    return String((item && item.drug_name_local) || '').trim();
}

function getPrimaryDrugName(item) {
    const local = getLocalDrugName(item);
    const tmt = (item.drug_name || '').trim();
    if (!useTmtDrugNames()) {
        return local || tmt || '-';
    }
    if (prefersLocalDrugName(item) || isCombinationDrugItem(item) || isCombinationDrugName(tmt) || isCombinationDrugName(local)) {
        return local || tmt || '-';
    }
    return (tmt || local || '-');
}

function getTmtDrugName(item) {
    if (!useTmtDrugNames()) return '';
    if (prefersLocalDrugName(item)) return '';
    const tmt = (item.drug_name || '').trim();
    const primary = getPrimaryDrugName(item);
    if (!tmt || tmt === primary) return '';
    return tmt;
}

/** รวมชื่อยาที่ต่างการสะกด/มี-ไม่มีความแรง ให้เป็นคีย์เดียว (เช่น ENALAPRIL MALIATE ≈ enalapril maleate 20 mg) */
function normalizeDrugKey(name) {
    let s = String(name || '')
        .toLowerCase()
        .replace(/maliate/g, 'maleate')
        .replace(/[()\[\]{},.;:]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
    if (!s) return '';
    s = s.replace(/\b\d+(?:\.\d+)?(?:\s*\/\s*\d+(?:\.\d+)?)?\s*(?:mcg|µg|μg|ug|mg|g|gm|ml|iu|units?|%|มก\.?|กรัม|ไมโครกรัม)(?:\s*\/\s*\d+(?:\.\d+)?\s*(?:ml|mL))?.*$/i, '');
    s = s.replace(/\b(?:tab|tablet|cap|capsule|inj|injection|syrup|ซอง|เม็ด|แคปซูล)\b/gi, '');
    s = s.replace(/\s+/g, ' ').trim();
    return s;
}

function getDrugGroupKey(item) {
    const keys = [
        normalizeDrugKey(item.drug_name),
        normalizeDrugKey(item.drug_name_local),
        normalizeDrugKey(getPrimaryDrugName(item))
    ].filter(Boolean);
    if (!keys.length) return '-';
    // เลือกคีย์ที่สั้นที่สุดที่ยังมีความหมาย (ตัดความแรงออกแล้ว)
    keys.sort((a, b) => a.length - b.length || a.localeCompare(b));
    return keys[0];
}

function nameHasStrengthText(name) {
    return /\d+(?:\.\d+)?\s*(?:mcg|µg|μg|ug|mg|g|gm|ml|iu|%|มก)/i.test(String(name || ''));
}

function localStrengthLabel(item) {
    return formatStrengthLabel({
        strength: item && item.strength_local != null ? item.strength_local : '',
        units: (item && item.units) || ''
    });
}

function displayStrengthLabel(item) {
    if (!useTmtDrugNames() || prefersLocalDrugName(item)) {
        return localStrengthLabel(item);
    }
    return item.strength_label || formatStrengthLabel(item);
}

function nameWithStrength(name, strength) {
    const n = String(name || '').trim();
    const s = String(strength || '').trim();
    if (!n) return s || '-';
    if (!s) return n;
    const nLow = n.toLowerCase().replace(/\s+/g, ' ');
    const sLow = s.toLowerCase().replace(/\s+/g, ' ');
    if (nLow.indexOf(sLow) >= 0) return n;
    return (n + ' · ' + s).replace(/\s+/g, ' ').trim();
}

function nameHasVolumeText(name) {
    return /\d+(?:\.\d+)?\s*(?:ml|mL)\b/i.test(String(name || ''));
}

function extractVolumeText(item) {
    const parts = [item && item.drug_name, item && item.strength, item && item.strength_label, item && item.units];
    for (let i = 0; i < parts.length; i++) {
        const s = String(parts[i] || '');
        const conc = s.match(/\d+(?:\.\d+)?\s*(?:mcg|µg|μg|ug|mg|g)\s*\/\s*\d+(?:\.\d+)?\s*(?:ml|mL)/i);
        if (conc) return conc[0].replace(/\s+/g, ' ');
        const vol = s.match(/(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*(?:ml|mL)\b/i);
        if (vol) return vol[0].replace(/\s+/g, ' ');
    }
    return '';
}

function withTmtVolume(name, item) {
    const n = String(name || '').trim();
    if (!n || nameHasVolumeText(n)) return n;
    const vol = extractVolumeText(item);
    if (!vol) return n;
    return nameWithStrength(n, vol);
}

function getDrugDisplayLabel(item) {
    const local = getLocalDrugName(item);
    const tmt = (item.drug_name || '').trim();
    const primary = getPrimaryDrugName(item);
    if (!useTmtDrugNames()) {
        return nameWithStrength(local || primary || tmt || '-', localStrengthLabel(item));
    }
    // ยาผสม / สูตรเข้มข้นหลายหน่วย: drugitems.name + drugitems.strength
    if (prefersLocalDrugName(item)) {
        return localNameWithStrength(item);
    }
    if (tmt && (nameHasStrengthText(tmt) || nameHasVolumeText(tmt))) {
        return tmt;
    }
    const strength = item.strength_label || formatStrengthLabel(item);
    return nameWithStrength(primary || tmt || local || '-', strength);
}

function pickBestDrugLabel(items) {
    if (!items || !items.length) return '-';
    let best = items[0];
    let bestScore = -1;
    items.forEach(it => {
        const label = getDrugDisplayLabel(it);
        let score = 0;
        if (nameHasStrengthText(label)) score += 3;
        if ((it.drug_name || '').trim()) score += 2;
        if (it.strength_label) score += 1;
        if (score > bestScore) {
            bestScore = score;
            best = it;
        }
    });
    return getDrugDisplayLabel(best);
}

function getSelectedVisit() {
    return globalVisits.find(v => (v.visit_key || ('opd:' + v.vn)) === selectedVisitKey) || null;
}

function getOrderGroupKey(item) {
    const d = item.order_date_display || item.vstdate_display || '-';
    const t = (item.order_time_display || item.vsttime_display || '').substring(0, 8);
    return d + (t ? ' ' + t : '');
}

function sortItemsForVisit(items) {
    const visit = getSelectedVisit();
    if (visit && visit.visit_type === 'ipd') {
        return [...items].sort((a, b) => {
            const ka = a.order_sort_key || (a.vstdate_iso + ' ' + (a.vsttime_display || ''));
            const kb = b.order_sort_key || (b.vstdate_iso + ' ' + (b.vsttime_display || ''));
            const c = ka.localeCompare(kb);
            if (c !== 0) return c;
            return String(a.item_no || '').localeCompare(String(b.item_no || ''), undefined, { numeric: true });
        });
    }
    return items;
}

function renderDrugRow(item, rowNo, showHme) {
    if (item && item.is_masked) {
        const msg = escapeHtml(item.drug_name || item.usage_display || 'กรุณาติดต่อ รพ.ต้นสังกัด');
        return `
        <tr>
            <td class="text-center fw-bold text-secondary">${rowNo}</td>
            <td class="align-middle">
                <span class="fs-6 text-danger fw-bold"><i class="fas fa-lock me-1"></i> ${msg}</span>
            </td>
            <td class="text-center align-middle text-muted">-</td>
            <td class="text-center align-middle col-calc-qty text-muted">-</td>
            <td class="text-center align-middle text-muted">-</td>
            <td class="text-danger align-middle"><small class="fw-bold">${msg}</small></td>
        </tr>`;
    }
    const displayName = getDrugDisplayLabel(item);
    const primaryName = escapeHtml(displayName);
    const groupKey = escapeHtml(getDrugGroupKey(item));
    const tmtName = getTmtDrugName(item);
    const strengthShow = displayStrengthLabel(item);
    const showStrengthLine = strengthShow && displayName.toLowerCase().indexOf(String(strengthShow).toLowerCase()) < 0;
    const hmeBadge = (showHme && item.is_hme)
        ? ' <span class="badge badge-hme" title="ยากลับบ้าน (Home Medication)"><i class="fas fa-home me-1"></i>HME</span>'
        : '';
    return `
        <tr>
            <td class="text-center fw-bold text-secondary">${rowNo}</td>
            <td class="align-middle">
                <span class="clickable-drug fs-6" data-drug-key="${groupKey}" data-drug="${escapeHtml(getPrimaryDrugName(item))}" onclick="plotDrugTimeline(this.dataset.drugKey || this.dataset.drug)">
                    <i class="fas fa-pills me-1 text-primary"></i> ${primaryName}${hmeBadge}
                </span><br>
                <small class="badge bg-white text-secondary border mt-1 shadow-sm"><i class="fas fa-barcode me-1"></i> ${escapeHtml(item.icode || '-')}</small>
                ${tmtName ? `<br><small class="text-muted">${escapeHtml(tmtName)}</small>` : ''}
                ${showStrengthLine ? `<br><small class="text-dark fw-bold">ความแรง ${escapeHtml(strengthShow)}</small>` : ''}
            </td>
            <td class="text-center align-middle">${formatOrderQtyDisplay(item)}</td>
            <td class="text-center align-middle col-calc-qty">${formatQtyDisplay(item.pill_qty, item.pill_unit, 'text-primary')}</td>
            <td class="text-center align-middle">${formatMgDisplay(item.mg_dose, item.mg_note, item.mg_dose_max)}</td>
            <td class="text-dark align-middle"><small class="fw-bold">${escapeHtml(item.usage_display || '-')}</small></td>
        </tr>`;
}

function getFilteredItems() {
    let items = globalHistoryData.filter(i => (i.visit_key || ('opd:' + i.vn)) === selectedVisitKey);
    const visit = getSelectedVisit();
    if (visit && visit.visit_type === 'ipd' && !ipdShowAll) {
        items = items.filter(i => !!i.is_hme);
    }
    const selectedDrug = $('#drugFilter').val();
    if (selectedDrug && selectedDrug !== 'all') {
        items = items.filter(i => getDrugGroupKey(i) === selectedDrug || getPrimaryDrugName(i) === selectedDrug);
    }
    return sortItemsForVisit(items);
}

function renderTable(items) {
    const visit = getSelectedVisit();
    const isIpd = visit && visit.visit_type === 'ipd';
    if (!items.length) {
        let empty = 'ไม่มีรายการยาใน Visit นี้';
        if (isIpd && !ipdShowAll) {
            empty = 'ไม่มีรายการ HME ใน Visit นี้ — กด <b>ทั้งหมด</b> เพื่อดูยาคลังห้องยา';
        }
        $('#drugHistoryTbody').html('<tr><td colspan="6" class="text-center text-muted py-4">' + empty + '</td></tr>');
        return;
    }

    let html = '';
    let lastGroup = null;
    let rowNo = 0;
    items.forEach((item) => {
        if (isIpd) {
            const groupKey = getOrderGroupKey(item);
            if (groupKey !== lastGroup) {
                html += `
                    <tr class="order-group-row">
                        <td colspan="6" class="fw-bold small py-2">
                            <i class="far fa-calendar-alt me-1"></i> สั่งยา ${escapeHtml(groupKey)}
                        </td>
                    </tr>`;
                lastGroup = groupKey;
            }
        }
        rowNo += 1;
        html += renderDrugRow(item, rowNo, isIpd);
    });
    $('#drugHistoryTbody').html(html);
    toggleCalcQtyColumn();
}

function plotDrugTimeline(drugKeyOrName) {
    currentChartDrug = drugKeyOrName;
    const matched = globalHistoryData.filter(d =>
        getDrugGroupKey(d) === drugKeyOrName || getPrimaryDrugName(d) === drugKeyOrName
    );
    $('#selectedDrugLabel').text(pickBestDrugLabel(matched) || drugKeyOrName);
    $('#analysisSection').fadeIn();
    refreshChart();
    $('html, body').animate({ scrollTop: $('#analysisSection').offset().top - 50 }, 500);
}

function refreshChart() {
    if (!currentChartDrug) return;

    const showQty = $('#chartShowQty').is(':checked');
    const showMg = $('#chartShowMg').is(':checked');

    $('#cumQtyBox').toggle(showQty);
    $('#cumMgBox').toggle(showMg);

    if (!showQty && !showMg) {
        if (drugChart) { drugChart.destroy(); drugChart = null; }
        return;
    }

    const drugRecords = globalHistoryData
        .filter(d => getDrugGroupKey(d) === currentChartDrug || getPrimaryDrugName(d) === currentChartDrug)
        .sort((a, b) => {
            const da = a.vstdate_iso + ' ' + (a.vsttime_display || '');
            const db = b.vstdate_iso + ' ' + (b.vsttime_display || '');
            return da.localeCompare(db);
        });

    if (!drugRecords.length) return;

    const labels = drugRecords.map(r =>
        r.vstdate_display + ' ' + (r.vsttime_display || '').substring(0, 5)
    );

    const datasets = [];
    let totalQty = 0;
    let totalMg = 0;
    let qtyUnit = (drugRecords[0].units || '').trim() || 'หน่วย';

    if (showQty) {
        const qtyData = drugRecords.map(r => {
            const v = parseFloat(r.qty);
            if (!isNaN(v)) totalQty += v;
            return !isNaN(v) ? v : null;
        });
        datasets.push({
            label: 'จำนวนสั่งยา (' + qtyUnit + ')',
            data: qtyData,
            borderColor: '#0d6efd',
            backgroundColor: 'rgba(13, 110, 253, 0.08)',
            borderWidth: 2,
            tension: 0.3,
            fill: false,
            yAxisID: 'yQty',
            spanGaps: true,
            pointRadius: 5
        });
    }

    if (showMg) {
        const mgData = drugRecords.map(r => {
            const v = r.mg_dose;
            if (v !== null && !isNaN(v)) totalMg += v;
            return (v !== null && !isNaN(v)) ? v : null;
        });
        datasets.push({
            label: 'mg/วัน (วิธีใช้)',
            data: mgData,
            borderColor: '#dc3545',
            backgroundColor: 'rgba(220, 53, 69, 0.08)',
            borderWidth: 2,
            tension: 0.3,
            fill: false,
            yAxisID: 'yMg',
            spanGaps: true,
            pointRadius: 5
        });
    }

    $('#cumQtyValue').text(totalQty.toLocaleString(undefined, { maximumFractionDigits: 2 }));
    $('#cumQtyUnit').text(qtyUnit);
    $('#cumMgValue').text(totalMg.toLocaleString(undefined, { maximumFractionDigits: 2 }));

    const scales = {
        x: { grid: { display: false }, title: { display: true, text: 'วันที่ Visit' } }
    };

    if (showQty) {
        scales.yQty = {
            type: 'linear',
            position: 'left',
            beginAtZero: true,
            title: { display: true, text: 'จำนวนสั่งยา (' + qtyUnit + ')' },
            grid: { color: '#eef2ff' }
        };
    }
    if (showMg) {
        scales.yMg = {
            type: 'linear',
            position: showQty ? 'right' : 'left',
            beginAtZero: true,
            title: { display: true, text: 'mg/วัน' },
            grid: { drawOnChartArea: !showQty, color: '#fde8e8' }
        };
    }

    const ctx = document.getElementById('drugTimelineChart').getContext('2d');
    if (drugChart) drugChart.destroy();

    drugChart = new Chart(ctx, {
        type: 'line',
        data: { labels, datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: { legend: { display: true, position: 'top' } },
            scales
        }
    });
}

function populateDrugFilter(history) {
    const byKey = {};
    (history || []).forEach(i => {
        const key = getDrugGroupKey(i);
        if (!key || key === '-') return;
        if (!byKey[key]) byKey[key] = [];
        byKey[key].push(i);
    });
    const keys = Object.keys(byKey).sort((a, b) =>
        pickBestDrugLabel(byKey[a]).localeCompare(pickBestDrugLabel(byKey[b]), 'th')
    );
    let sel = $('#drugFilter');
    sel.empty().append('<option value="all">-- แสดงยาทั้งหมด --</option>');
    keys.forEach(k => {
        const label = pickBestDrugLabel(byKey[k]);
        sel.append(`<option value="${escapeHtml(k)}">${escapeHtml(label)}</option>`);
    });
}

function filterTableByDrug() {
    if (!selectedVisitKey) return;
    $('#analysisSection').hide();
    renderTable(getFilteredItems());
    renderMedTimeline();
}

function hideMedTimeline() {
    $('#medTimelineSection').hide();
    $('#medTimelineWrap').html('');
    $('#medTimelineMeta').text('');
}

function getTimelineHistory() {
    let items = globalHistoryData;
    if (selectedHospitalCode !== 'all') {
        items = items.filter(i => (i.hospital_code || 'local') === selectedHospitalCode);
    }
    const selectedDrug = $('#drugFilter').val();
    if (selectedDrug && selectedDrug !== 'all') {
        items = items.filter(i => getDrugGroupKey(i) === selectedDrug || getPrimaryDrugName(i) === selectedDrug);
    }
    return items;
}

function formatTlQty(qty) {
    const v = parseFloat(qty);
    if (isNaN(v)) return '';
    return v.toLocaleString(undefined, { maximumFractionDigits: 1 });
}

function formatTlMg(mg, mgMax) {
    if (mg === null || mg === undefined || isNaN(mg)) return '';
    const a = Number(mg);
    const b = (mgMax !== null && mgMax !== undefined && !isNaN(mgMax)) ? Number(mgMax) : null;
    const fmt = (n) => n.toLocaleString(undefined, { maximumFractionDigits: 2 });
    if (b !== null && b !== a) return fmt(a) + '–' + fmt(b);
    return fmt(a);
}

function tlItemSortKey(item) {
    return String(item.order_sort_key || ((item.order_date_iso || item.vstdate_iso || '') + ' ' + (item.order_time_display || item.vsttime_display || '')));
}

/** รวม mg/วัน ของยาใน visit เดียว */
function tlVisitDoseSummary(rows) {
    let totalQty = 0;
    let hasQty = false;
    let kind = 'opd';
    let best = null;
    const tips = [];
    (rows || []).forEach(item => {
        const q = parseFloat(item.qty);
        if (!isNaN(q)) { totalQty += q; hasQty = true; }
        if (item.is_hme) kind = 'hme';
        else if (item.visit_type === 'ipd' && kind !== 'hme') kind = 'ipd';

        const mg = (item.mg_dose !== null && item.mg_dose !== undefined && !isNaN(item.mg_dose))
            ? Number(item.mg_dose) : null;
        const mgMax = (item.mg_dose_max !== null && item.mg_dose_max !== undefined && !isNaN(item.mg_dose_max))
            ? Number(item.mg_dose_max) : null;
        if (mg !== null) {
            if (!best || mg > best.mg || (mg === best.mg && (item.usage_display || '').length > (best.usage || '').length)) {
                best = {
                    mg,
                    mgMax,
                    usage: String(item.usage_display || item.method || '').trim()
                };
            }
        }
        const unit = (item.units || '').trim();
        tips.push([
            getDrugDisplayLabel(item),
            (item.vstdate_display || '') + ' ' + (item.vsttime_display || ''),
            (item.visit_type === 'ipd' ? 'IPD' : 'OPD') + (item.is_hme ? ' · HME' : ''),
            hospitalShortName(item.hospital_name || ''),
            !isNaN(q) ? ('จำนวน ' + formatTlQty(q) + (unit ? ' ' + unit : '')) : '',
            mg !== null ? (formatTlMg(mg, mgMax) + ' mg/วัน') : '',
            item.usage_display || item.method || ''
        ].filter(Boolean).join(' · '));
    });
    return {
        kind,
        totalQty,
        hasQty,
        mg: best ? best.mg : null,
        mgMax: best ? best.mgMax : null,
        usage: best ? best.usage : '',
        tips
    };
}

function tlLatestItem(items) {
    const list = (items || []).slice().sort((a, b) => String(tlItemSortKey(b)).localeCompare(String(tlItemSortKey(a))));
    return list[0] || null;
}

function renderMedTimeline() {
    const items = getTimelineHistory();
    const visits = visibleVisits().slice().sort((a, b) => {
        const c = String(a.vstdate_iso || '').localeCompare(String(b.vstdate_iso || ''));
        if (c !== 0) return c;
        return String(a.vsttime_display || '').localeCompare(String(b.vsttime_display || ''));
    });

    if (!items.length || !visits.length) {
        hideMedTimeline();
        return;
    }

    const byDrugVisit = {};
    const groupItems = {};
    const lastDate = {};
    items.forEach(item => {
        const key = getDrugGroupKey(item);
        if (!key || key === '-') return;
        const vk = item.visit_key || ('opd:' + item.vn);
        if (!byDrugVisit[key]) byDrugVisit[key] = {};
        if (!byDrugVisit[key][vk]) byDrugVisit[key][vk] = [];
        byDrugVisit[key][vk].push(item);
        if (!groupItems[key]) groupItems[key] = [];
        groupItems[key].push(item);
        const iso = item.vstdate_iso || '';
        if (!lastDate[key] || iso > lastDate[key]) lastDate[key] = iso;
    });

    const drugs = Object.keys(byDrugVisit).sort((a, b) => {
        const c = String(lastDate[b] || '').localeCompare(String(lastDate[a] || ''));
        if (c !== 0) return c;
        return pickBestDrugLabel(groupItems[a]).localeCompare(pickBestDrugLabel(groupItems[b]), 'th');
    });

    $('#medTimelineMeta').text(drugs.length + ' รายการยา · ' + visits.length + ' Visit');

    let html = '<table class="med-tl-table"><thead><tr>';
    html += '<th class="med-tl-name">รายการยา / วิธีใช้ / mg/วันล่าสุด</th>';
    visits.forEach(v => {
        const vk = v.visit_key || ('opd:' + v.vn);
        const active = (vk === selectedVisitKey) ? ' active' : '';
        const safeKey = escapeHtml(vk).replace(/'/g, '&#39;');
        const type = v.visit_type === 'ipd' ? 'IPD' : 'OPD';
        const hosp = hospitalShortName(v.hospital_name || '');
        html += `<th class="med-tl-date${active}" title="${escapeHtml((v.vstdate_display || '') + ' ' + (v.vsttime_display || '') + ' ' + type + (hosp ? ' · ' + hosp : ''))}" onclick="selectVisit('${safeKey}')">
            <div>${escapeHtml(v.vstdate_display || '-')}</div>
            <div class="text-muted fw-normal">${escapeHtml((v.vsttime_display || '').substring(0, 5))}</div>
            <div><span class="badge ${v.visit_type === 'ipd' ? 'visit-badge-ipd' : 'visit-badge-opd'}">${type}</span></div>
            ${hosp ? `<div class="small text-muted text-truncate" style="max-width:90px">${escapeHtml(hosp)}</div>` : ''}
        </th>`;
    });
    html += '</tr></thead><tbody>';

    drugs.forEach(key => {
        const label = pickBestDrugLabel(groupItems[key]);
        const safeKey = escapeHtml(key);
        const safeLabel = escapeHtml(label);
        const latest = tlLatestItem(groupItems[key]);
        const latestUsage = String((latest && (latest.usage_display || latest.method)) || '').trim();
        const latestMgTxt = (latest && latest.mg_dose !== null && latest.mg_dose !== undefined && !isNaN(latest.mg_dose))
            ? (formatTlMg(latest.mg_dose, latest.mg_dose_max) + ' mg/วัน')
            : '';
        const strengthHint = (() => {
            const it = (groupItems[key] || []).find(x => x.strength_label || x.strength_local) || (groupItems[key] || [])[0];
            if (!it) return '';
            const st = displayStrengthLabel(it);
            if (!st || nameHasStrengthText(label) || String(label).toLowerCase().indexOf(st.toLowerCase()) >= 0) return '';
            return `<div class="small text-muted fw-bold">ความแรง ${escapeHtml(st)}</div>`;
        })();

        html += `<tr><td class="med-tl-name">
            <span class="med-tl-drug-title clickable-drug" data-drug-key="${safeKey}" onclick="plotDrugTimeline(this.dataset.drugKey)">${safeLabel}</span>
            ${strengthHint}
            ${latestUsage ? `<div class="med-tl-usage">${escapeHtml(latestUsage)}</div>` : ''}
            ${latestMgTxt ? `<div class="med-tl-latest-mg">ล่าสุด ${escapeHtml(latestMgTxt)}</div>` : '<div class="med-tl-latest-mg text-muted fw-normal">ล่าสุด - mg/วัน</div>'}
        </td>`;

        let prevMg = null;
        visits.forEach(v => {
            const vk = v.visit_key || ('opd:' + v.vn);
            const active = (vk === selectedVisitKey) ? ' active' : '';
            const rows = (byDrugVisit[key] && byDrugVisit[key][vk]) ? byDrugVisit[key][vk] : [];
            html += `<td class="med-tl-cell med-tl-col${active}">`;
            if (!rows.length) {
                html += '<span class="med-tl-empty">·</span>';
            } else {
                const safeVisit = escapeHtml(vk).replace(/'/g, '&#39;');
                const sum = tlVisitDoseSummary(rows);
                const mgTxt = formatTlMg(sum.mg, sum.mgMax);
                let deltaHtml = '';
                let deltaTip = '';
                let deltaClass = '';
                if (sum.mg !== null && prevMg !== null) {
                    const diff = Math.round((sum.mg - prevMg) * 1000) / 1000;
                    if (diff > 0) {
                        deltaHtml = `<span class="mg-delta up">↑ เพิ่ม</span>`;
                        deltaTip = 'เพิ่มจากครั้งก่อน ' + formatTlMg(prevMg) + ' → ' + mgTxt + ' mg/วัน';
                        deltaClass = ' up';
                    } else if (diff < 0) {
                        deltaHtml = `<span class="mg-delta down">↓ ลด</span>`;
                        deltaTip = 'ลดจากครั้งก่อน ' + formatTlMg(prevMg) + ' → ' + mgTxt + ' mg/วัน';
                        deltaClass = ' down';
                    } else {
                        deltaHtml = `<span class="mg-delta same">＝</span>`;
                        deltaTip = 'เท่าเดิม ' + mgTxt + ' mg/วัน';
                    }
                } else if (sum.mg !== null) {
                    deltaHtml = `<span class="mg-delta same">เริ่ม</span>`;
                    deltaTip = 'ครั้งแรกในช่วงที่แสดง · ' + mgTxt + ' mg/วัน';
                }

                const mainLine = mgTxt
                    ? `<span class="mg-line">${escapeHtml(mgTxt)}</span>`
                    : `<span class="mg-line">${sum.hasQty ? escapeHtml(formatTlQty(sum.totalQty)) : '●'}</span>`;
                const qtyLine = (sum.hasQty && mgTxt)
                    ? `<span class="qty-line">จำนวน ${escapeHtml(formatTlQty(sum.totalQty))}</span>`
                    : '';

                const tipExtra = deltaTip ? ('\n' + deltaTip) : '';
                html += `<span class="med-tl-dot ${sum.kind}${deltaClass}" title="${escapeHtml(sum.tips.join('\n') + tipExtra)}" onclick="selectVisit('${safeVisit}')">
                    ${deltaHtml}
                    ${mainLine}
                    ${qtyLine}
                </span>`;

                if (sum.mg !== null) prevMg = sum.mg;
            }
            html += '</td>';
        });
        html += '</tr>';
    });
    html += '</tbody></table>';

    const wrap = document.getElementById('medTimelineWrap');
    const keepScroll = $('#medTimelineSection').is(':visible');
    const sl = wrap ? wrap.scrollLeft : 0;
    const st = wrap ? wrap.scrollTop : 0;
    $('#medTimelineWrap').html(html);
    $('#medTimelineSection').show();
    if (wrap) {
        if (keepScroll) {
            wrap.scrollLeft = sl;
            wrap.scrollTop = st;
        } else {
            wrap.scrollLeft = wrap.scrollWidth;
        }
    }
}

/* ========== Medication Reconciliation print ========== */
const MR_TH_MONTHS_SHORT = ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
const MR_TH_MONTHS_FULL = ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
const MR_ACTIONS = [
    { key: 'continue', label: 'ใช้ต่อ' },
    { key: 'change', label: 'เปลี่ยน' },
    { key: 'hold', label: 'งด' },
    { key: 'off', label: 'หยุด' }
];

function mrParseIsoDate(iso) {
    if (!iso) return null;
    const m = String(iso).match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (!m) return null;
    return { y: parseInt(m[1], 10), m: parseInt(m[2], 10), d: parseInt(m[3], 10) };
}

function mrFormatDateShort(iso, time) {
    const p = mrParseIsoDate(iso);
    if (!p) return iso || '';
    const be = p.y + 543;
    let s = p.d + ' ' + MR_TH_MONTHS_SHORT[p.m - 1] + ' ' + be;
    const t = String(time || '').substring(0, 5);
    if (t) s += ' เวลา ' + t + ' น.';
    return s;
}

function mrPrintStamp() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + (d.getFullYear() + 543)
        + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

function mrFormatDateFull(iso, time) {
    const p = mrParseIsoDate(iso);
    if (!p) {
        const now = new Date();
        return mrFormatDateFull(
            now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0'),
            time || (String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0'))
        );
    }
    const be = p.y + 543;
    let s = p.d + ' ' + MR_TH_MONTHS_FULL[p.m - 1] + ' ' + be;
    const t = String(time || '').substring(0, 5);
    if (t) s += ' ' + t + ' น.';
    return s;
}

function mrFormatDisplayDate(iso) {
    const p = mrParseIsoDate(iso);
    if (!p) return iso || '';
    return String(p.d).padStart(2, '0') + '/' + String(p.m).padStart(2, '0') + '/' + (p.y + 543);
}

function mrParseDisplayDate(text) {
    const s = String(text || '').trim();
    let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (m) {
        return m[1] + '-' + String(m[2]).padStart(2, '0') + '-' + String(m[3]).padStart(2, '0');
    }
    m = s.match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/);
    if (!m) return '';
    let d = parseInt(m[1], 10);
    let mo = parseInt(m[2], 10);
    let y = parseInt(m[3], 10);
    if (y > 2400) y -= 543;
    if (mo < 1 || mo > 12 || d < 1 || d > 31 || y < 1900 || y > 2200) return '';
    return y + '-' + String(mo).padStart(2, '0') + '-' + String(d).padStart(2, '0');
}

function mrComboLocalName(item) {
    if (!item) return '';
    const local = getLocalDrugName(item);
    const tmt = String(item.drug_name || '').trim();
    if (!local) return '';
    if (/[+＋]/.test(tmt) || /[+＋]/.test(local)) return local;
    return '';
}

function mrBuildDrugText(item) {
    const name = getDrugDisplayLabel(item) || getPrimaryDrugName(item) || '';
    const units = String(item.units || '').trim();
    let form = '';
    if (units && !new RegExp(units.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(name)) {
        form = units;
    }
    const method = String(item.usage_display || item.method || '').trim();
    return [name, form, method].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
}

/** คีย์รวมยาซ้ำ: ชื่อยาที่ตัดความแรงแล้วก่อน แล้วจึงใช้ icode */
function mrDrugMergeKey(item) {
    const gk = getDrugGroupKey(item);
    if (gk && gk !== '-' && gk.length >= 3) return 'nm:' + gk;
    const icode = String(item.icode || '').trim();
    if (icode) return 'ic:' + icode;
    const name = normalizeDrugKey(getPrimaryDrugName(item) || item.drug_name_local || item.drug_name || '');
    if (name) return 'nm:' + name;
    return 'row:' + (item.visit_key || '') + ':' + String(item.item_no || '') + ':' + String(item.order_sort_key || '');
}

function mrItemSortKey(item) {
    return String(item.order_sort_key || ((item.order_date_iso || item.vstdate_iso || '') + ' ' + (item.order_time_display || item.vsttime_display || '')));
}

/** แยกชื่อยา / วิธีใช้: ชื่อจากรายการที่ดีที่สุด วิธีใช้จากรายการล่าสุด */
function mrBuildMergedDrugParts(candidates, latestItem) {
    const list = (candidates && candidates.length) ? candidates : [latestItem];
    const nameSrc = list.slice().sort((a, b) => {
        const comboA = isCombinationDrugItem(a) ? 1 : 0;
        const comboB = isCombinationDrugItem(b) ? 1 : 0;
        if (comboA !== comboB) return comboB - comboA;
        if (comboA) {
            const la = String(a.drug_name_local || '').trim().length;
            const lb = String(b.drug_name_local || '').trim().length;
            return lb - la;
        }
        const la = getDrugDisplayLabel(a);
        const lb = getDrugDisplayLabel(b);
        let sa = 0, sb = 0;
        if (nameHasStrengthText(la)) sa += 3;
        if (nameHasStrengthText(lb)) sb += 3;
        if ((a.drug_name || '').trim()) sa += 2;
        if ((b.drug_name || '').trim()) sb += 2;
        if (a.strength_label) sa += 1;
        if (b.strength_label) sb += 1;
        return sb - sa;
    })[0] || latestItem;

    let name = getDrugDisplayLabel(nameSrc) || getPrimaryDrugName(nameSrc) || '';
    const comboLocal = mrComboLocalName(latestItem) || mrComboLocalName(nameSrc);
    if (comboLocal) {
        name = comboLocal;
    } else if (useTmtDrugNames() && (prefersLocalDrugName(nameSrc) || prefersLocalDrugName(latestItem))) {
        name = localNameWithStrength(latestItem || nameSrc);
    }
    const units = String((latestItem && latestItem.units) || nameSrc.units || '').trim();
    if (units && !new RegExp(units.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(name)) {
        name = (name + ' ' + units).replace(/\s+/g, ' ').trim();
    }
    const method = String((latestItem && (latestItem.usage_display || latestItem.method)) || '').trim();
    const drug_text = [name, method].filter(Boolean).join('\n');
    return {
        drug_name: name,
        method: method,
        drug_text: drug_text,
        icode: String((latestItem && latestItem.icode) || nameSrc.icode || '').trim()
    };
}

function mrFormatMgDay(n) {
    const r = Math.round(Number(n) * 100) / 100;
    if (!isFinite(r)) return '';
    if (Math.abs(r - Math.round(r)) < 0.001) return String(Math.round(r));
    return String(r);
}

function mrMgPerDay(item) {
    if (!item) return null;
    const method = String(item.method || '').trim();
    const usage = String(item.usage_display || '').trim();
    const parsed = parseDrugDose(Object.assign({}, item, {
        method: method || (usage && usage !== '-' ? usage : '')
    }));
    const mg = parsed && parsed.mg_dose;
    if (mg == null || !isFinite(mg) || mg <= 0) return null;
    return mg;
}

function mrDoseChangeText(candidates, latestItem) {
    const list = (candidates || []).slice().sort((a, b) => mrItemSortKey(a).localeCompare(mrItemSortKey(b)));
    if (list.length < 2) return '';
    const to = mrMgPerDay(latestItem);
    if (to == null) return '';
    for (let i = list.length - 2; i >= 0; i--) {
        const from = mrMgPerDay(list[i]);
        if (from == null) continue;
        if (Math.abs(from - to) < 0.05) return '';
        const dir = to < from ? 'ลด' : 'เพิ่ม';
        return 'เปลี่ยนวิธีใช้ ' + dir + ' จาก ' + mrFormatMgDay(from) + ' mg ต่อวัน เป็น ' + mrFormatMgDay(to) + ' mg ต่อวัน';
    }
    return '';
}

function mrDrugMatchKeys(item) {
    const stop = {
        sodium: 1, potassium: 1, calcium: 1, chloride: 1, sulfate: 1, phosphate: 1,
        acetate: 1, maleate: 1, besylate: 1, hydrochloride: 1, magnesium: 1, glucose: 1
    };
    const out = [];
    const add = function (k) {
        if (!k || k.length < 4 || out.indexOf(k) >= 0) return;
        out.push(k);
    };
    [item && item.drug_name, item && item.drug_name_local, getPrimaryDrugName(item)].forEach(function (name) {
        const k = normalizeDrugKey(name);
        add(k);
        String(k || '').split(' ').forEach(function (w) {
            if (w.length >= 5 && !stop[w]) add(w);
        });
    });
    return out;
}

function mrGroupSameDrugs(items) {
    const parent = items.map(function (_, i) { return i; });
    const find = function (i) {
        while (parent[i] !== i) {
            parent[i] = parent[parent[i]];
            i = parent[i];
        }
        return i;
    };
    const union = function (a, b) {
        const pa = find(a);
        const pb = find(b);
        if (pa !== pb) parent[pb] = pa;
    };
    const index = {};
    items.forEach(function (item, i) {
        mrDrugMatchKeys(item).forEach(function (k) {
            if (index[k] == null) index[k] = i;
            else union(i, index[k]);
        });
    });
    const groups = {};
    items.forEach(function (item, i) {
        const g = find(i);
        if (!groups[g]) groups[g] = [];
        groups[g].push(item);
    });
    return Object.values(groups);
}

function mrBuildMergedDrugText(candidates, latestItem) {
    return mrBuildMergedDrugParts(candidates, latestItem).drug_text.replace(/\n/g, ' ');
}

function mrStripCombinationFormula(name) {
    let s = String(name || '').trim();
    if (!s || !isCombinationDrugName(s)) return s;
    let cut = s.replace(/\s*[-–·,]\s*\d+(?:\.\d+)?\s*(?:mcg|µg|μg|ug|mg|g|ml)\b.*$/i, '').trim();
    if (cut && cut !== s) return cut;
    cut = s.replace(/\s+\d+(?:\.\d+)?\s*(?:mcg|µg|μg|ug|mg|g|ml)\s*[+＋].*$/i, '').trim();
    return cut || s;
}

function mrComposeDrugText(name, method) {
    return [String(name || '').trim(), String(method || '').trim()].filter(Boolean).join('\n');
}

function mrFormatQtyText(qty, units) {
    if (qty === '' || qty == null || qty === undefined) return '';
    const n = parseFloat(qty);
    if (isNaN(n) || n < 0) return '';
    const num = Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100);
    const u = String(units || '').trim();
    return u ? (num + ' ' + u) : num;
}

function mrNewRow(partial) {
    const row = Object.assign({
        id: 'mr_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
        order_date: '',
        order_date_iso: '',
        appt_date: '',
        appt_date_iso: '',
        icode: '',
        drug_name: '',
        method: '',
        drug_text: '',
        hospital_name: '',
        hospital_code: '',
        is_manual: false,
        admit_action: '',
        home_action: '',
        remark: '',
        qty: '',
        units: ''
    }, partial || {});
    if (!row.drug_text) {
        row.drug_text = mrComposeDrugText(row.drug_name, row.method);
    } else if (!row.drug_name && row.drug_text) {
        const parts = String(row.drug_text).split(/\n/);
        row.drug_name = (parts[0] || '').trim();
        row.method = parts.slice(1).join('\n').trim();
    }
    return row;
}

/** Visit ล่าสุดที่มียา (IPD นับ HME ก่อน ถ้าไม่มีค่อยใช้ยาทั้งหมด) */
function medReconLatestVisit() {
    const visits = visibleVisits().slice().sort((a, b) => {
        const da = String(a.vstdate_iso || '') + ' ' + String(a.vsttime_display || '');
        const db = String(b.vstdate_iso || '') + ' ' + String(b.vsttime_display || '');
        return db.localeCompare(da);
    });
    const hasVisible = (v, ipdHmeOnly) => {
        const vk = visitKeyOf(v);
        if ((v.drug_count || countVisitDrugs(vk, false) || 0) <= 0) return false;
        if (v.visit_type === 'ipd' && ipdHmeOnly) return countVisitDrugs(vk, true) > 0;
        return true;
    };
    return visits.find(v => hasVisible(v, true))
        || visits.find(v => hasVisible(v, false))
        || visits[0]
        || null;
}

function openMedReconModal() {
    if (!globalVisits.length) {
        alert('กรุณาค้นหา HN และรอโหลด Visit ก่อนครับ');
        return;
    }
    medReconHistEditId = '';
    mrIpdShowAll = false;
    $('#mr_ipd_scope_hme').prop('checked', true);
    $('#mr_note').val('');
    mrInitDoctorAutocomplete();
    mrInitAllergyUi();
    medReconRenderVisitList();
    medReconFillPatientDefaults();
    medReconLoadDrugsFromVisits({ silent: true });
    const modal = new bootstrap.Modal(document.getElementById('medReconModal'));
    modal.show();
    medReconFetchContext();
}

function medReconRenderVisitList() {
    const visits = visibleVisits();
    if (!visits.length) {
        $('#medReconVisitList').html('<div class="p-3 text-muted small">ไม่มี Visit</div>');
        return;
    }
    const defaultKeys = {};
    medReconDefaultVisitKeys().forEach(function (k) { defaultKeys[k] = true; });
    let html = '';
    visits.forEach(v => {
        const vk = v.visit_key || ('opd:' + (v.vn || ''));
        const checked = defaultKeys[vk] ? ' checked' : '';
        const chronicBadge = visitHasChronicDrug(v) ? ' <span class="badge badge-chronic">ยาเรื้อรัง</span>' : '';
        const ref = v.visit_type === 'ipd'
            ? ('AN ' + (v.an || '-'))
            : ('VN ' + (v.vn || '-'));
        html += `<label class="mr-visit-row d-flex align-items-start gap-2 mb-0">
            <input type="checkbox" class="form-check-input mt-1 mr-visit-cb" value="${escapeHtml(vk)}"${checked}>
            <span class="flex-grow-1">
                <span class="fw-bold">${escapeHtml(v.vstdate_display || '-')}</span>
                <span class="text-muted small ms-1">${escapeHtml((v.vsttime_display || '').substring(0, 5))}</span>
                <span class="badge ${v.visit_type === 'ipd' ? 'visit-badge-ipd' : 'visit-badge-opd'} ms-1">${v.visit_type === 'ipd' ? 'IPD' : 'OPD'}</span>${chronicBadge}
                <div class="small text-muted">${escapeHtml(ref)} · ${v.visit_type === 'ipd' ? (countVisitDrugs(vk, true) + ' HME / ' + (v.drug_count || 0) + ' ยา') : ((v.drug_count || 0) + ' ยา')}${v.hospital_name ? ' · ' + escapeHtml(hospitalShortName(v.hospital_name)) : ''}</div>
            </span>
        </label>`;
    });
    $('#medReconVisitList').html(html);
    $('#medReconVisitList .mr-visit-cb').off('change.medrecon').on('change.medrecon', function () {
        medReconLoadDrugsFromVisits({ silent: true });
        medReconFetchContext();
    });
}

function medReconSelectVisits(all) {
    $('#medReconVisitList .mr-visit-cb').prop('checked', !!all);
    medReconLoadDrugsFromVisits({ silent: true });
    medReconFetchContext();
}

function medReconSelectedHasIpd() {
    const keys = medReconSelectedVisitKeys();
    return globalVisits.some(v => keys.indexOf(visitKeyOf(v)) >= 0 && v.visit_type === 'ipd');
}

function medReconSyncIpdScopeUi() {
    const hasIpd = medReconSelectedHasIpd();
    $('#mrIpdScopeWrap').toggle(hasIpd);
}

function onMrIpdScopeChange() {
    mrIpdShowAll = $('#mr_ipd_scope_all').is(':checked');
    medReconLoadDrugsFromVisits({ silent: true });
}

function medReconSelectedVisitKeys() {
    const keys = [];
    $('#medReconVisitList .mr-visit-cb:checked').each(function () {
        keys.push(this.value);
    });
    return keys;
}

function medReconPickPrimaryVisit() {
    const keys = medReconSelectedVisitKeys();
    const visits = globalVisits.filter(v => keys.indexOf(v.visit_key || ('opd:' + v.vn)) >= 0);
    if (!visits.length) return getSelectedVisit() || visibleVisits()[0] || null;
    const sorted = visits.slice().sort((a, b) => {
        const da = String(a.vstdate_iso || '') + ' ' + String(a.vsttime_display || '');
        const db = String(b.vstdate_iso || '') + ' ' + String(b.vsttime_display || '');
        return db.localeCompare(da);
    });
    return sorted.find(v => v.visit_type === 'ipd') || sorted[0];
}

function medReconFillPatientDefaults() {
    const p = globalPatient || {};
    const hn = p.hn || $('#search_hn').val().trim();
    $('#mr_patient_name').val(p.full_name || '');
    $('#mr_hn').val(hn);
    $('#mr_age').val(p.age_y != null ? p.age_y : '');
    $('#mr_sex').val(p.sex || '');
    $('#mr_next_appt').val('');

    const visit = medReconPickPrimaryVisit();
    if (visit) {
        const vnAn = visit.visit_type === 'ipd' ? (visit.an || '') : (visit.vn || '');
        $('#mr_vn').val(vnAn);
        $('#mr_service_date').val(visit.vstdate_display || '');
        $('#mr_ward').val(visit.ward_name || '');
        $('#mr_admit_dt').val(mrFormatDateShort(visit.admit_date || visit.vstdate_iso, visit.vsttime_display));
    } else {
        $('#mr_vn').val('');
        $('#mr_service_date').val('');
        $('#mr_ward').val('');
        $('#mr_admit_dt').val('');
    }
    $('#mr_doctor').val('');
    // แพ้ยา/หอผู้ป่วย จะถูกเติมจาก HOSxP ใน medReconFetchContext
    $('#mr_allergy_no').prop('checked', true);
    $('#mr_allergy_text').val('');
    medReconSyncAllergyHint();
}

function medReconSyncAllergyHint() {
    const noAllergy = $('#mr_allergy_no').is(':checked');
    $('#mr_allergy_no_hint').toggleClass('is-hidden', !noAllergy);
    if (noAllergy) {
        const t = $('#mr_allergy_text').val().trim();
        // ไม่ใส่ข้อความยาวในช่องพิมพ์ — แสดงอักษรเขียวใต้ NO แทน
        if (t === 'ไม่แพ้ยา(HOSxP)' || t === 'ไม่แพ้ยา (HOSxP)') {
            $('#mr_allergy_text').val('');
        }
    }
}

function mrInitAllergyUi() {
    const $no = $('#mr_allergy_no');
    if ($no.data('mr-allergy-ui')) return;
    $no.data('mr-allergy-ui', 1);
    $('input[name="mr_allergy"]').on('change', medReconSyncAllergyHint);
}

let mrDoctorTimer = null;
let mrDoctorItems = [];
let mrDoctorActive = -1;

function mrHideDoctorSuggest() {
    $('#mrDoctorSuggest').hide().empty();
    mrDoctorActive = -1;
}

function mrRenderDoctorSuggest(items) {
    mrDoctorItems = items || [];
    mrDoctorActive = -1;
    const $box = $('#mrDoctorSuggest');
    if (!mrDoctorItems.length) {
        $box.html('<div class="empty">ไม่พบแพทย์ที่ตรงกับคำค้น</div>').show();
        return;
    }
    let html = '';
    mrDoctorItems.forEach((it, idx) => {
        html += `<div class="item" data-idx="${idx}">${escapeHtml(it.text || it.name || '')}</div>`;
    });
    $box.html(html).show();
}

function mrPickDoctor(idx) {
    const it = mrDoctorItems[idx];
    if (!it) return;
    $('#mr_doctor').val(it.name || '');
    mrHideDoctorSuggest();
}

async function mrSearchDoctor(term) {
    term = String(term || '').trim();
    if (term.length < 1) {
        mrHideDoctorSuggest();
        return;
    }
    try {
        const res = await fetch('fetch_smart_drug_medrecon_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'search_doctor', q: term })
        });
        const data = await res.json();
        if (data.status === 'success') {
            mrRenderDoctorSuggest(data.results || []);
        } else {
            mrHideDoctorSuggest();
        }
    } catch (e) {
        mrHideDoctorSuggest();
    }
}

function mrInitDoctorAutocomplete() {
    const $inp = $('#mr_doctor');
    if ($inp.data('mr-ac')) return;
    $inp.data('mr-ac', 1);
    $inp.on('input', function () {
        const term = this.value;
        clearTimeout(mrDoctorTimer);
        mrDoctorTimer = setTimeout(() => mrSearchDoctor(term), 220);
    });
    $inp.on('keydown', function (e) {
        const $items = $('#mrDoctorSuggest .item');
        if (!$items.length || !$('#mrDoctorSuggest').is(':visible')) return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            mrDoctorActive = Math.min(mrDoctorActive + 1, $items.length - 1);
            $items.removeClass('active').eq(mrDoctorActive).addClass('active');
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            mrDoctorActive = Math.max(mrDoctorActive - 1, 0);
            $items.removeClass('active').eq(mrDoctorActive).addClass('active');
        } else if (e.key === 'Enter') {
            if (mrDoctorActive >= 0) {
                e.preventDefault();
                mrPickDoctor(mrDoctorActive);
            }
        } else if (e.key === 'Escape') {
            mrHideDoctorSuggest();
        }
    });
    $(document).on('mousedown', '#mrDoctorSuggest .item', function (e) {
        e.preventDefault();
        mrPickDoctor(Number($(this).data('idx')));
    });
    $inp.on('blur', function () {
        setTimeout(mrHideDoctorSuggest, 180);
    });
}

async function medReconFetchContext() {
    const hn = $('#mr_hn').val().trim() || $('#search_hn').val().trim();
    if (!hn) return;

    // แพทย์: ดึงจาก Visit ล่าสุด · หอผู้ป่วย: จาก IPD ปัจจุบันใน API
    const latest = medReconLatestVisit();
    const primary = medReconPickPrimaryVisit();
    let an = '', vn = '';
    if (latest) {
        if (latest.visit_type === 'ipd') an = latest.an || '';
        else vn = latest.vn || '';
    }
    if (!vn && primary && primary.visit_type !== 'ipd') {
        vn = primary.vn || '';
    }

    try {
        const res = await fetch('fetch_smart_drug_medrecon_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ hn, an, vn })
        });
        const data = await res.json();
        if (data.status !== 'success') return;
        if (data.hospital_name) medReconHospitalName = data.hospital_name;

        const pt = data.patient || {};
        if (pt.full_name) $('#mr_patient_name').val(pt.full_name);
        if (pt.hn) $('#mr_hn').val(pt.hn);
        if (pt.age_y != null) $('#mr_age').val(pt.age_y);
        if (pt.sex) $('#mr_sex').val(pt.sex);

        const cur = data.current_ipd || {};
        const v = data.visit || {};
        // หอผู้ป่วย: ใช้ IPD ปัจจุบันเป็นหลัก
        const ward = cur.ward_name || '';
        if (ward) $('#mr_ward').val(ward);
        else if (!$('#mr_ward').val()) $('#mr_ward').val(v.ward_name || (primary && primary.ward_name) || '');

        // ค่าเริ่มต้นแพทย์จาก Visit ล่าสุด (แก้ไขได้)
        const doctor = v.doctor_name || cur.doctor_name || '';
        if (doctor) $('#mr_doctor').val(doctor);

        const dispVn = cur.an || v.an || v.vn || (primary ? ((primary.visit_type === 'ipd' ? primary.an : primary.vn) || '') : '');
        if (dispVn) $('#mr_vn').val(dispVn);
        if (v.service_date || cur.admit_date) {
            const sd = v.service_date || cur.admit_date;
            const st = v.admit_time || v.service_time || cur.admit_time;
            $('#mr_service_date').val(mrFormatDisplayDate(sd));
            $('#mr_admit_dt').val(mrFormatDateShort(v.admit_date || cur.admit_date || sd, st));
        }

        const al = data.allergy || {};
        const allergyText = String(al.text || '').trim();
        if (al.has_allergy) {
            $('#mr_allergy_yes').prop('checked', true);
            $('#mr_allergy_text').val(allergyText);
        } else {
            $('#mr_allergy_no').prop('checked', true);
            // แสดง "ไม่แพ้ยา (HOSxP)" เป็นอักษรเขียวใต้ NO ไม่ใส่ในช่องข้อความ
            $('#mr_allergy_text').val(allergyText && allergyText !== 'ไม่แพ้ยา(HOSxP)' && allergyText !== 'ไม่แพ้ยา (HOSxP)' ? allergyText : '');
        }
        medReconSyncAllergyHint();

        if (Array.isArray(data.visit_appointments) && data.visit_appointments.length) {
            medReconVisitAppts = data.visit_appointments;
        }
        const ap = data.appointment || {};
        const items = Array.isArray(data.appointments) && data.appointments.length
            ? data.appointments
            : ((ap.items && ap.items.length) ? ap.items : []);
        const lines = items.map(function (a) { return String(a.display || '').trim(); }).filter(Boolean);
        if (lines.length) {
            $('#mr_next_appt').val(lines.join('\n'));
        } else if (ap.display) {
            $('#mr_next_appt').val(String(ap.display).trim());
        }
        mrApplyVisitAppointments();
        mrFillNextApptFromRows();
    } catch (e) {
        console.warn('med recon context', e);
    }
}

function mrPickFollowAppt(cands, anchor) {
    if (!cands || !cands.length) return null;
    const list = cands.slice().sort(function (a, b) {
        const anext = String(a.nextdate || '');
        const bnext = String(b.nextdate || '');
        const aAfter = anchor && anext > anchor ? 0 : 1;
        const bAfter = anchor && bnext > anchor ? 0 : 1;
        if (aAfter !== bAfter) return aAfter - bAfter;
        return anext.localeCompare(bnext);
    });
    const follow = list.find(function (a) { return !anchor || String(a.nextdate || '') > anchor; });
    if (follow) return follow;
    const sameDay = list.find(function (a) { return !anchor || String(a.nextdate || '') >= anchor; });
    return sameDay || list[list.length - 1];
}

function mrResolveAdmitIso(row) {
    const direct = String((row && row.admit_date_iso) || '').slice(0, 10);
    if (direct && direct !== '0000-00-00') return direct;
    const visit = (globalVisits || []).find(function (v) {
        return (v.visit_key || '') === ((row && row.visit_key) || '');
    });
    if (!visit || visit.visit_type !== 'ipd') return '';
    const admit = String(visit.admit_date || visit.vstdate_iso || '').slice(0, 10);
    return (admit && admit !== '0000-00-00') ? admit : '';
}

function mrMatchVisitAppt(row, list) {
    const iso = String(row.order_date_iso || '').slice(0, 10);
    const came = mrCameIso(row);
    const admit = mrResolveAdmitIso(row);
    const vn = String(row.vn || '').trim();
    const an = String(row.an || '').trim();
    const hosp = String(row.hospital_code || 'local');
    const sameHosp = (list || []).filter(function (a) {
        return String(a.hospital_code || 'local') === hosp;
    });
    // IPD / HME: นัดถูกจองในวันที่มา Admit ไม่ใช่วันสั่ง HME
    const cameDay = came || admit || iso;
    if (cameDay) {
        const onCame = sameHosp.filter(function (a) {
            return String(a.vstdate || '').slice(0, 10) === cameDay;
        });
        const hit = mrPickFollowAppt(onCame, cameDay);
        if (hit) return hit;
    }
    const anchor = iso || cameDay;
    const cands = sameHosp.filter(function (a) {
        const vd = String(a.vstdate || '').slice(0, 10);
        const avn = String(a.vn || '').trim();
        const aan = String(a.an || '').trim();
        if (an && aan && aan === an) return true;
        if (vn && avn && avn === vn) return true;
        if (iso && vd === iso) return true;
        return false;
    });
    return mrPickFollowAppt(cands, anchor);
}

function mrApptHospitalName(hit) {
    let name = String((hit && hit.hospital_name) || '').trim();
    const code = String((hit && hit.hospital_code) || 'local');
    if (!name && code === 'local') name = String(medReconHospitalName || '').trim();
    if (!name && code === 'local') name = 'รพ.สมเด็จพระยุพราชสระแก้ว';
    return name;
}

function mrApptDisplayLine(hit, withHospital) {
    const iso = String((hit && hit.nextdate) || '').slice(0, 10);
    let s = mrFormatDisplayDate(iso);
    if (!s) return '';
    const t = String((hit && hit.nexttime) || '').slice(0, 5);
    if (t && t !== '00:00') s += ' ' + t;
    const clinic = String((hit && hit.clinic_name) || '').trim();
    const doctor = String((hit && hit.doctor_name) || '').trim();
    if (clinic) s += ' · ' + clinic;
    if (doctor) s += ' · ' + doctor;
    if (withHospital) {
        const place = mrApptHospitalName(hit);
        if (place && s.indexOf(' · ' + place) < 0) s += ' · ' + place;
    }
    return s;
}

function mrPushApptLine(lines, seen, line, toFront) {
    if (!line || seen[line]) return;
    for (let i = lines.length - 1; i >= 0; i--) {
        const old = lines[i];
        if (old !== line && line.indexOf(old + ' · ') === 0) {
            delete seen[old];
            lines.splice(i, 1);
        }
    }
    seen[line] = true;
    if (toFront) lines.unshift(line);
    else lines.push(line);
}

function mrCameIso(row) {
    const admit = mrResolveAdmitIso(row);
    if (admit) return admit;
    const vst = String((row && row.vstdate_iso) || '').slice(0, 10);
    if (vst && vst !== '0000-00-00') return vst;
    return String((row && row.order_date_iso) || '').slice(0, 10);
}

function mrTodayIso() {
    const d = new Date();
    const z = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
}

function mrLineNextdateIso(line) {
    const m = String(line || '').trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (!m) return '';
    const y = parseInt(m[3], 10) - 543;
    if (y < 1900 || y > 2500) return '';
    return y + '-' + String(m[2]).padStart(2, '0') + '-' + String(m[1]).padStart(2, '0');
}

function mrFillNextApptFromRows() {
    const lines = [];
    const seen = {};
    const today = mrTodayIso();
    String($('#mr_next_appt').val() || '').split('\n').forEach(function (line) {
        const t = line.trim();
        const iso = mrLineNextdateIso(t);
        if (!t || seen[t] || (iso && iso <= today)) return;
        seen[t] = true;
        lines.push(t);
    });
    const admits = {};
    (globalVisits || []).forEach(function (v) {
        if (v.visit_type !== 'ipd') return;
        const d = String(v.admit_date || v.vstdate_iso || '').slice(0, 10);
        if (d && d !== '0000-00-00') admits[d] = true;
    });
    (medReconRows || []).forEach(function (row) {
        const d = mrResolveAdmitIso(row);
        if (d) admits[d] = true;
    });
    (medReconVisitAppts || []).forEach(function (a) {
        const vd = String(a.vstdate || '').slice(0, 10);
        const nd = String(a.nextdate || '').slice(0, 10);
        const hosp = String(a.hospital_code || 'local');
        const onVisit = (medReconRows || []).some(function (row) {
            if (String(row.hospital_code || 'local') !== hosp) return false;
            const came = mrCameIso(row);
            return came && came === vd;
        });
        if (!vd || !nd || nd <= today) return;
        if (!onVisit && !admits[vd]) return;
        mrPushApptLine(lines, seen, mrApptDisplayLine(a, true), true);
    });
    const blob = lines.join('\n');
    (medReconRows || []).forEach(function (row) {
        const iso = String(row.appt_date_iso || '').slice(0, 10);
        if (!iso || iso <= today) return;
        const hit = mrMatchVisitAppt(row, medReconVisitAppts || []);
        const line = hit ? mrApptDisplayLine(hit, true) : mrFormatDisplayDate(iso);
        const p = mrParseIsoDate(iso);
        const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
        const thai = p ? (p.d + ' ' + months[p.m - 1] + ' ' + (p.y + 543)) : '';
        if (!line || seen[line] || (thai && blob.indexOf(thai) >= 0) || blob.indexOf(mrFormatDisplayDate(iso)) >= 0) return;
        mrPushApptLine(lines, seen, line, false);
    });
    $('#mr_next_appt').val(lines.join('\n'));
}

function mrApplyVisitAppointments(skipRender) {
    const list = medReconVisitAppts || [];
    if (!list.length || !medReconRows.length) return;
    if (!skipRender) medReconSyncRowsFromDom();
    let changed = false;
    medReconRows.forEach(function (row) {
        if (row.is_manual) return;
        const admit = mrResolveAdmitIso(row);
        if (!admit && row.appt_date_iso) return;
        const hit = mrMatchVisitAppt(row, list);
        if (!hit || !hit.nextdate) return;
        row.appt_date_iso = String(hit.nextdate).slice(0, 10);
        row.appt_date = mrFormatDisplayDate(row.appt_date_iso);
        row.appt_label = mrApptDisplayLine(hit);
        row.appt_clinic = hit.clinic_name || '';
        changed = true;
    });
    if (changed && !skipRender) medReconRenderDrugTable();
}

function medReconLoadDrugsFromVisits(opts) {
    const silent = !!(opts && opts.silent);
    const keys = medReconSelectedVisitKeys();
    if (!keys.length) {
        if (!silent) alert('กรุณาเลือกอย่างน้อย 1 Visit');
        medReconRows = [];
        medReconRenderDrugTable();
        return;
    }

    const items = globalHistoryData.filter(i => {
        const vk = i.visit_key || ('opd:' + i.vn);
        if (keys.indexOf(vk) < 0) return false;
        if (mrIpdShowAll) return true;
        const visit = globalVisits.find(v => visitKeyOf(v) === vk);
        if (visit && visit.visit_type === 'ipd') {
            return !!i.is_hme;
        }
        return true;
    });
    const flat = [];
    mrGroupSameDrugs(items).forEach(group => {
        const ordered = group.slice().sort((a, b) => mrItemSortKey(a).localeCompare(mrItemSortKey(b)));
        const latest = ordered[ordered.length - 1];
        const dup = ordered.length > 1;
        const doseChange = dup ? mrDoseChangeText(ordered, latest) : '';
        ordered.forEach(src => {
            flat.push({
                src: src,
                dup: dup,
                dup_prev: dup && src !== latest,
                dose_change: src === latest ? doseChange : ''
            });
        });
    });
    flat.sort((a, b) => mrItemSortKey(b.src).localeCompare(mrItemSortKey(a.src)));
    medReconRows = flat.map(entry => {
        const item = entry.src;
        const parts = mrBuildMergedDrugParts([item], item);
        const hosp = mrHospitalFromItem(item);
        const qtyRaw = (item.qty != null && item.qty !== '') ? item.qty : '';
        const visit = (globalVisits || []).find(v => (v.visit_key || '') === (item.visit_key || ''));
        return mrNewRow({
            order_date: item.order_date_display || item.vstdate_display || '',
            order_date_iso: item.order_date_iso || item.vstdate_iso || '',
            vstdate_iso: item.vstdate_iso || '',
            vn: item.vn || (visit && visit.vn) || '',
            an: item.an || (visit && visit.an) || '',
            admit_date_iso: (visit && (visit.admit_date || (visit.visit_type === 'ipd' ? visit.vstdate_iso : ''))) || item.admit_date || '',
            visit_key: item.visit_key || (visit && visit.visit_key) || '',
            icode: parts.icode,
            drug_name: parts.drug_name,
            method: parts.method,
            drug_text: parts.drug_text,
            dup: entry.dup,
            dup_prev: entry.dup_prev,
            dose_change: entry.dose_change,
            hospital_name: hosp.hospital_name,
            hospital_code: hosp.hospital_code,
            is_manual: false,
            admit_action: '',
            home_action: '',
            remark: '',
            qty: qtyRaw,
            units: String(item.units || '').trim()
        });
    });
    mrApplyVisitAppointments(true);
    mrFillNextApptFromRows();
    medReconRenderDrugTable();
    medReconPersistLocal();
    medReconSyncIpdScopeUi();
    if (!silent) medReconFetchContext();
}

function medReconPersistLocal() {
    try {
        const hn = ($('#mr_hn').val() || $('#search_hn').val() || '').trim();
        if (!hn) return;
        medReconSyncRowsFromDom();
        const rows = (medReconRows || []).map(r => ({
            icode: r.icode || '',
            drug_name: r.drug_name || '',
            method: r.method || '',
            drug_text: r.drug_text || '',
            dup: !!r.dup,
            dup_prev: !!r.dup_prev,
            dose_change: r.dose_change || '',
            order_date: r.order_date || '',
            order_date_iso: r.order_date_iso || '',
            appt_date: r.appt_date || '',
            appt_date_iso: r.appt_date_iso || '',
            hospital_name: r.hospital_name || '',
            hospital_code: r.hospital_code || '',
            admit_action: r.admit_action || '',
            home_action: r.home_action || '',
            remark: r.remark || '',
            qty: r.qty || '',
            units: r.units || '',
            strength: r.strength || '',
            source_label: 'Smart Drug Med Recon'
        })).filter(r => String(r.drug_name || r.drug_text || '').trim() !== '');
        if (!rows.length) return;
        const key = 'tham_smart_medrecon_v1';
        const all = JSON.parse(localStorage.getItem(key) || '{}') || {};
        const pack = {
            hn: hn,
            saved_at: new Date().toISOString(),
            rows: rows
        };
        all[hn] = pack;
        if (/^\d+$/.test(hn)) {
            all[hn.padStart(9, '0')] = pack;
            all[String(parseInt(hn, 10))] = pack;
        }
        localStorage.setItem(key, JSON.stringify(all));
    } catch (e) {
        console.warn('medReconPersistLocal', e);
    }
}

function medReconActionRadios(prefix, rowId, selected) {
    return MR_ACTIONS.map(a => {
        const id = prefix + '_' + rowId + '_' + a.key;
        const checked = selected === a.key ? ' checked' : '';
        return `<label class="mb-0"><input type="radio" name="${prefix}_${rowId}" value="${a.key}"${checked}> ${a.label}</label>`;
    }).join(' ');
}

function medReconDrugCellHtml(row) {
    if (!row.is_manual) {
        const name = mrStripCombinationFormula(String(row.drug_name || '').trim() || String(row.drug_text || '').trim());
        const method = String(row.method || '').trim();
        const dup = row.dup ? '<span class="mr-dup">ซ้ำ</span>' : '';
        const chg = String(row.dose_change || '').trim();
        return `<div class="mr-drug-ro">
            <div><span class="mr-dn">${escapeHtml(name)}</span>${dup}</div>
            ${method ? `<div class="mr-dm">${escapeHtml(method)}</div>` : ''}
            ${chg ? `<div class="mr-dose-chg">${escapeHtml(chg)}</div>` : ''}
        </div>`;
    }
    return `<div class="mr-drug-wrap">
            <input type="text" class="form-control form-control-sm mr-drug-name-input" value="${escapeHtml(row.drug_name || '')}" placeholder="พิมพ์ชื่อยาเพื่อค้นหาจาก HOSxP..." autocomplete="off">
            <div class="mr-drug-suggest"></div>
        </div>
        <div class="mr-usage-wrap mt-1">
            <textarea class="form-control form-control-sm mr-drug-method" placeholder="พิมพ์รหัสวิธีใช้ HOSxP เช่น 13pt แล้วกด Enter">${escapeHtml(row.method || '')}</textarea>
            <div class="mr-usage-suggest"></div>
        </div>`;
}

function mrDateInputHtml(textClass, shown, iso, title) {
    return `<div class="mr-cal-wrap">
        <input type="text" class="form-control form-control-sm ${textClass}" value="${escapeHtml(shown)}" placeholder="วว/ดด/ปปปป" autocomplete="off" title="${escapeHtml(title || 'วัน/เดือน/ปี')}">
        <button type="button" class="mr-cal-btn" tabindex="-1"><i class="fas fa-calendar-alt"></i></button>
        <input type="date" class="mr-cal-native" value="${escapeHtml(iso || '')}" tabindex="-1">
    </div>`;
}

function mrOpenDatePicker(native, textValue) {
    if (!native) return;
    const iso = mrParseDisplayDate(textValue);
    if (iso) native.value = iso;
    if (typeof native.showPicker === 'function') {
        try { native.showPicker(); return; } catch (e) {}
    }
    native.focus();
    native.click();
}

function mrBindDatePickers() {
    $('#medReconDrugBody').off('click.mrcal').on('click.mrcal', '.mr-order-date-text, .mr-appt-date-text', function () {
        const $wrap = $(this).closest('.mr-cal-wrap');
        mrOpenDatePicker($wrap.find('.mr-cal-native')[0], $(this).val());
    });
    $('#medReconDrugBody').off('change.mrcal').on('change.mrcal', '.mr-cal-native', function () {
        const iso = this.value || '';
        $(this).closest('.mr-cal-wrap').find('.mr-order-date-text, .mr-appt-date-text').val(iso ? mrFormatDisplayDate(iso) : '');
    });
}

function mrDateCellHtml(row) {
    if (row.is_manual) {
        const orderShown = row.order_date_iso ? mrFormatDisplayDate(row.order_date_iso) : (row.order_date || '');
        const apptShown = row.appt_date_iso ? mrFormatDisplayDate(row.appt_date_iso) : (row.appt_date || '');
        return `<td class="mr-date-cell">
            ${mrDateInputHtml('mr-order-date-text', orderShown, row.order_date_iso || '', 'วัน/เดือน/ปี')}
            <input type="text" class="form-control form-control-sm mt-1 mr-order-place" value="${escapeHtml(row.hospital_name || '')}" placeholder="สถานที่สั่ง" autocomplete="off">
        </td>
        <td class="mr-date-cell">
            ${mrDateInputHtml('mr-appt-date-text', apptShown, row.appt_date_iso || '', row.appt_clinic ? ('วัน/เดือน/ปี · นัดจาก HOSxP · ' + row.appt_clinic) : 'วัน/เดือน/ปี')}
            ${row.appt_clinic ? `<div class="small text-muted">${escapeHtml(row.appt_clinic)}</div>` : ''}
        </td>`;
    }
    return `<td class="mr-date-cell">
            <input type="text" class="form-control form-control-sm mr-order-date" value="${escapeHtml(row.order_date || '')}">
            ${row.hospital_name ? `<div class="mr-hosp-label" title="${escapeHtml(row.hospital_name)}">${escapeHtml(mrHospitalPrintLabel(row.hospital_name))}</div>` : ''}
        </td>
        <td class="mr-date-cell">
            <div class="small fw-bold" title="${escapeHtml(row.appt_clinic ? ('นัดจาก HOSxP · ' + row.appt_clinic) : 'วันที่นัด')}">${escapeHtml(row.appt_label || row.appt_date || '')}</div>
            <input type="hidden" class="mr-appt-date-pick" value="${escapeHtml(row.appt_date_iso || '')}">
        </td>`;
}

function mrShowDupRows() {
    const box = document.getElementById('mrShowDup');
    return !box || box.checked;
}

function medReconToggleDup() {
    if ($('#medReconDrugBody tr[data-row-id]').length) medReconSyncRowsFromDom();
    medReconRenderDrugTable();
}

function medReconRenderDrugTable() {
    const visibleRows = medReconRows.filter(r => mrShowDupRows() || !r.dup_prev);
    if (!visibleRows.length) {
        let msg = 'ยังไม่มีรายการยา — ติ๊ก Visit ด้านซ้ายเพื่อโหลด หรือกดเพิ่มรายการเอง';
        if (medReconSelectedHasIpd() && !mrIpdShowAll) {
            msg = 'ไม่มีรายการ HME ใน Visit IPD ที่เลือก — สลับเป็น <b>ทั้งหมด (คลังห้องยา)</b> เพื่อดูยาในวอร์ด';
        }
        $('#medReconDrugBody').html('<tr><td colspan="9" class="text-center text-muted py-4">' + msg + '</td></tr>');
        $('#mrDrugCount').text('0');
        return;
    }
    let html = '';
    visibleRows.forEach((row, idx) => {
        html += `<tr data-row-id="${escapeHtml(row.id)}" data-manual="${row.is_manual ? '1' : '0'}">
            <td class="text-center fw-bold">${idx + 1}</td>
            ${mrDateCellHtml(row)}
            <td>${medReconDrugCellHtml(row)}</td>
            <td class="text-center">
                <input type="text" class="form-control form-control-sm text-center mr-qty" value="${escapeHtml(row.qty != null && row.qty !== '' ? row.qty : '')}" placeholder="-">
                ${row.units ? `<div class="small text-muted">${escapeHtml(row.units)}</div>` : ''}
            </td>
            <td class="mr-action-group">${medReconActionRadios('admit', row.id, row.admit_action)}</td>
            <td class="mr-action-group">${medReconActionRadios('home', row.id, row.home_action)}</td>
            <td><input type="text" class="form-control form-control-sm mr-remark" value="${escapeHtml(row.remark)}"></td>
            <td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger" onclick="medReconDeleteRow('${escapeHtml(row.id)}')" title="ลบ"><i class="fas fa-times"></i></button></td>
        </tr>`;
    });
    $('#medReconDrugBody').html(html);
    $('#mrDrugCount').text(String(visibleRows.length));
    medReconBindDrugSearch();
    mrBindDatePickers();
}

function medReconSyncRowsFromDom() {
    if (!$('#medReconDrugBody tr[data-row-id]').length) return;
    const next = [];
    $('#medReconDrugBody tr[data-row-id]').each(function () {
        const id = String($(this).attr('data-row-id') || $(this).data('row-id') || '');
        const prev = medReconRows.find(r => r.id === id) || mrNewRow({ id });
        const isManual = !!prev.is_manual || String($(this).attr('data-manual')) === '1';
        let drug_name = prev.drug_name || '';
        let method = prev.method || '';
        let icode = prev.icode || '';
        let drug_text = prev.drug_text || '';
        if (isManual) {
            drug_name = $(this).find('.mr-drug-name-input').val() || '';
            method = $(this).find('.mr-drug-method').val() || '';
            drug_text = mrComposeDrugText(drug_name, method);
        } else {
            const dn = ($(this).find('.mr-dn').first().text() || '').trim();
            const dm = ($(this).find('.mr-dm').first().text() || '').trim();
            if (dn) drug_name = dn;
            if (dm) method = dm;
            // รองรับ DOM เก่าที่เป็น textarea รวมบรรทัดเดียว
            const legacy = $(this).find('textarea.mr-drug-text').val();
            if (legacy && !drug_name) {
                const parts = String(legacy).split(/\n/);
                drug_name = (parts[0] || '').trim();
                method = parts.slice(1).join('\n').trim() || method;
                if (!method && parts.length === 1) {
                    drug_text = String(legacy).trim();
                }
            }
            drug_text = mrComposeDrugText(drug_name, method) || drug_text || '';
        }
        const $orderText = $(this).find('.mr-order-date-text');
        const $orderPick = $(this).find('.mr-order-date-pick');
        let order_date = prev.order_date || '';
        let order_date_iso = prev.order_date_iso || '';
        if ($orderText.length) {
            order_date = ($orderText.val() || '').trim();
            order_date_iso = mrParseDisplayDate(order_date);
            if (order_date_iso) order_date = mrFormatDisplayDate(order_date_iso);
        } else if ($orderPick.length) {
            order_date_iso = $orderPick.val() || '';
            order_date = order_date_iso ? mrFormatDisplayDate(order_date_iso) : '';
        } else {
            order_date = $(this).find('.mr-order-date').val() || '';
        }
        const $apptText = $(this).find('.mr-appt-date-text');
        let appt_date_iso = '';
        let appt_date = prev.appt_date || '';
        let appt_label = prev.appt_label || '';
        if ($apptText.length) {
            const rawAppt = ($apptText.val() || '').trim();
            appt_date_iso = mrParseDisplayDate(rawAppt);
            appt_date = appt_date_iso ? mrFormatDisplayDate(appt_date_iso) : rawAppt;
            if (appt_date_iso && appt_date_iso === (prev.appt_date_iso || '') && prev.appt_label) {
                appt_label = prev.appt_label;
            } else {
                appt_label = appt_date;
            }
        } else {
            appt_date_iso = $(this).find('.mr-appt-date-pick').val() || '';
            if (!appt_date_iso) appt_date_iso = prev.appt_date_iso || '';
            appt_date = appt_date_iso ? mrFormatDisplayDate(appt_date_iso) : (prev.appt_date || '');
        }
        let hospital_name = prev.hospital_name || '';
        const $place = $(this).find('.mr-order-place');
        if ($place.length) {
            hospital_name = $place.val() || '';
        }
        next.push({
            id,
            order_date,
            order_date_iso,
            vstdate_iso: prev.vstdate_iso || '',
            appt_date,
            appt_date_iso,
            appt_label,
            appt_clinic: prev.appt_clinic || '',
            vn: prev.vn || '',
            an: prev.an || '',
            admit_date_iso: prev.admit_date_iso || '',
            visit_key: prev.visit_key || '',
            hospital_name,
            hospital_code: prev.hospital_code || '',
            icode,
            drug_name,
            method,
            drug_text,
            dup: !!prev.dup,
            dup_prev: !!prev.dup_prev,
            dose_change: prev.dose_change || '',
            is_manual: isManual,
            admit_action: $(this).find('input[name="admit_' + id + '"]:checked').val() || '',
            home_action: $(this).find('input[name="home_' + id + '"]:checked').val() || '',
            remark: $(this).find('.mr-remark').val() || '',
            qty: $(this).find('.mr-qty').val() || prev.qty || '',
            units: prev.units || ''
        });
    });
    const seen = {};
    next.forEach(r => { seen[r.id] = r; });
    medReconRows = medReconRows.map(r => seen[r.id] || r);
}

function mrRowDateSeed(row) {
    const empty = {
        order_date: '',
        order_date_iso: '',
        appt_date: '',
        appt_date_iso: '',
        appt_label: '',
        appt_clinic: '',
        hospital_name: ''
    };
    if (!row) return empty;
    let orderIso = row.order_date_iso || mrParseDisplayDate(row.order_date || '');
    let apptIso = row.appt_date_iso || mrParseDisplayDate(row.appt_date || row.appt_label || '');
    const place = row.is_manual
        ? (row.hospital_name || '')
        : (mrHospitalPrintLabel(row.hospital_name || '') || row.hospital_name || '');
    return {
        order_date: orderIso ? mrFormatDisplayDate(orderIso) : (row.order_date || ''),
        order_date_iso: orderIso || '',
        appt_date: apptIso ? mrFormatDisplayDate(apptIso) : (row.appt_date || ''),
        appt_date_iso: apptIso || '',
        appt_label: row.appt_label || (apptIso ? mrFormatDisplayDate(apptIso) : (row.appt_date || '')),
        appt_clinic: row.appt_clinic || '',
        hospital_name: place
    };
}

function medReconAddRow() {
    medReconSyncRowsFromDom();
    const seed = mrRowDateSeed(medReconRows[0]);
    medReconRows.push(mrNewRow({
        order_date: seed.order_date,
        order_date_iso: seed.order_date_iso,
        appt_date: seed.appt_date,
        appt_date_iso: seed.appt_date_iso,
        appt_label: seed.appt_label,
        appt_clinic: seed.appt_clinic,
        drug_name: '',
        method: '',
        drug_text: '',
        hospital_name: seed.hospital_name,
        is_manual: true,
        admit_action: '',
        home_action: ''
    }));
    medReconRenderDrugTable();
    const wrap = document.getElementById('medReconDrugTableWrap');
    if (wrap) wrap.scrollTop = wrap.scrollHeight;
    const $last = $('#medReconDrugBody tr[data-row-id]').last().find('.mr-drug-name-input');
    if ($last.length) $last.focus();
}

let mrDrugTimers = {};
let mrDrugSuggestCache = {};
let mrDrugActiveIdx = {};

function mrHideDrugSuggest($wrap) {
    $wrap.find('.mr-drug-suggest').hide().empty();
    const rowId = $wrap.closest('tr').data('row-id');
    if (rowId) mrDrugActiveIdx[rowId] = -1;
}

async function mrSearchDrugForRow($input) {
    const term = String($input.val() || '').trim();
    const $wrap = $input.closest('.mr-drug-wrap');
    const $box = $wrap.find('.mr-drug-suggest');
    const rowId = $wrap.closest('tr').data('row-id');
    if (term.length < 1) {
        mrHideDrugSuggest($wrap);
        return;
    }
    const hn = $('#mr_hn').val().trim() || $('#search_hn').val().trim();
    try {
        const res = await fetch('fetch_smart_drug_medrecon_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'search_drug', q: term, hn })
        });
        const data = await res.json();
        const items = (data.status === 'success') ? (data.results || []) : [];
        mrDrugSuggestCache[rowId] = items;
        mrDrugActiveIdx[rowId] = -1;
        if (!items.length) {
            $box.html('<div class="empty">ไม่พบยาที่ตรงกับคำค้น</div>').show();
            return;
        }
        let html = '';
        items.forEach((it, idx) => {
            const sub = it.method ? `<span class="sub">${escapeHtml(it.method)}</span>` : '';
            html += `<div class="item" data-idx="${idx}">${escapeHtml(it.text || it.name || '')}${sub}</div>`;
        });
        $box.html(html).show();
    } catch (e) {
        mrHideDrugSuggest($wrap);
    }
}

function mrPickDrugForRow($wrap, idx) {
    const rowId = $wrap.closest('tr').data('row-id');
    const items = mrDrugSuggestCache[rowId] || [];
    const it = items[idx];
    if (!it) return;
    const $tr = $wrap.closest('tr');
    const tmtName = String(it.name_tmt || '').trim();
    const localName = String(it.name_local || '').trim();
    const fillName = (localName && /[+＋]/.test(tmtName)) ? localName : (it.name || localName || tmtName);
    $wrap.find('.mr-drug-name-input').val(fillName);
    $tr.find('.mr-drug-method').val(it.method || '');
    const row = medReconRows.find(r => r.id === rowId);
    if (row) {
        row.icode = it.icode || '';
        row.drug_name = fillName;
        row.method = it.method || '';
        row.drug_text = mrComposeDrugText(row.drug_name, row.method);
        row.is_manual = true;
        row.units = it.units || row.units || '';
        if (it.qty != null && it.qty !== '') {
            row.qty = it.qty;
            $tr.find('.mr-qty').val(it.qty);
        }
    }
    mrHideDrugSuggest($wrap);
}

function medReconBindDrugSearch() {
    $('#medReconDrugBody .mr-drug-name-input').off('.mrdrug').on('input.mrdrug', function () {
        const $inp = $(this);
        const rowId = $inp.closest('tr').data('row-id');
        clearTimeout(mrDrugTimers[rowId]);
        mrDrugTimers[rowId] = setTimeout(() => mrSearchDrugForRow($inp), 220);
    }).on('keydown.mrdrug', function (e) {
        const $wrap = $(this).closest('.mr-drug-wrap');
        const $items = $wrap.find('.mr-drug-suggest .item');
        const rowId = $wrap.closest('tr').data('row-id');
        if (!$items.length || !$wrap.find('.mr-drug-suggest').is(':visible')) return;
        let active = mrDrugActiveIdx[rowId] != null ? mrDrugActiveIdx[rowId] : -1;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            active = Math.min(active + 1, $items.length - 1);
            mrDrugActiveIdx[rowId] = active;
            $items.removeClass('active').eq(active).addClass('active');
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            active = Math.max(active - 1, 0);
            mrDrugActiveIdx[rowId] = active;
            $items.removeClass('active').eq(active).addClass('active');
        } else if (e.key === 'Enter') {
            if (active >= 0) {
                e.preventDefault();
                mrPickDrugForRow($wrap, active);
            }
        } else if (e.key === 'Escape') {
            mrHideDrugSuggest($wrap);
        }
    }).on('blur.mrdrug', function () {
        const $wrap = $(this).closest('.mr-drug-wrap');
        setTimeout(() => mrHideDrugSuggest($wrap), 180);
    });

    $('#medReconDrugBody').off('mousedown.mrdrug').on('mousedown.mrdrug', '.mr-drug-suggest .item', function (e) {
        e.preventDefault();
        const $wrap = $(this).closest('.mr-drug-wrap');
        mrPickDrugForRow($wrap, Number($(this).data('idx')));
    });
    medReconBindUsageSearch();
}

let mrUsageTimers = {};
let mrUsageSuggestCache = {};
let mrUsageActiveIdx = {};

function mrUsageQuery(val) {
    const s = String(val || '').trim();
    if (s.length < 2 || s.length > 24 || /\n/.test(s)) return '';
    if (s.length > 16 && /\s/.test(s)) return '';
    return s;
}

function mrPlaceFloatSuggest($box, $anchor) {
    const el = $anchor && $anchor[0];
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const openUp = (window.innerHeight - rect.bottom) < 190 && rect.top > 190;
    $box.css({
        position: 'fixed',
        left: Math.max(8, rect.left) + 'px',
        width: Math.max(rect.width, 320) + 'px',
        right: 'auto',
        top: openUp ? 'auto' : (rect.bottom + 2) + 'px',
        bottom: openUp ? (window.innerHeight - rect.top + 2) + 'px' : 'auto',
        zIndex: 2000
    });
}

function mrHideUsageSuggest($wrap) {
    $wrap.find('.mr-usage-suggest').hide().empty().css({ position: '', left: '', width: '', right: '', top: '', bottom: '' });
    const rowId = $wrap.closest('tr').data('row-id');
    if (rowId) mrUsageActiveIdx[rowId] = -1;
}

async function mrSearchUsageForRow($input) {
    const term = mrUsageQuery($input.val());
    const $wrap = $input.closest('.mr-usage-wrap');
    const $box = $wrap.find('.mr-usage-suggest');
    const rowId = $wrap.closest('tr').data('row-id');
    if (!term) {
        mrHideUsageSuggest($wrap);
        return;
    }
    try {
        const res = await fetch('fetch_smart_drug_medrecon_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'search_usage', q: term })
        });
        const data = await res.json();
        const items = (data.status === 'success') ? (data.results || []) : [];
        mrUsageSuggestCache[rowId] = items;
        mrUsageActiveIdx[rowId] = items.length ? 0 : -1;
        if (!items.length) {
            $box.html('<div class="empty">ไม่พบรหัสวิธีใช้ใน HOSxP</div>');
            mrPlaceFloatSuggest($box, $input);
            $box.show();
            return;
        }
        let html = '';
        items.forEach((it, idx) => {
            html += `<div class="item${idx === 0 ? ' active' : ''}" data-idx="${idx}"><b>${escapeHtml(it.code || '')}</b><span class="sub">${escapeHtml(it.text || '')}</span></div>`;
        });
        $box.html(html);
        mrPlaceFloatSuggest($box, $input);
        $box.show();
    } catch (e) {
        mrHideUsageSuggest($wrap);
    }
}

function mrPickUsageForRow($wrap, idx) {
    const rowId = $wrap.closest('tr').data('row-id');
    const items = mrUsageSuggestCache[rowId] || [];
    const it = items[idx];
    if (!it) return;
    const $tr = $wrap.closest('tr');
    $tr.find('.mr-drug-method').val(it.text || '');
    const row = medReconRows.find(r => r.id === rowId);
    if (row) {
        row.method = it.text || '';
        row.usage_code = it.code || '';
        row.drug_text = mrComposeDrugText(row.drug_name, row.method);
    }
    mrHideUsageSuggest($wrap);
}

function medReconBindUsageSearch() {
    $('#medReconDrugBody .mr-drug-method').off('.mrusage').on('input.mrusage', function () {
        const $inp = $(this);
        const rowId = $inp.closest('tr').data('row-id');
        clearTimeout(mrUsageTimers[rowId]);
        mrUsageTimers[rowId] = setTimeout(() => mrSearchUsageForRow($inp), 180);
    }).on('keydown.mrusage', function (e) {
        const $wrap = $(this).closest('.mr-usage-wrap');
        const $box = $wrap.find('.mr-usage-suggest');
        const $items = $box.find('.item');
        const rowId = $wrap.closest('tr').data('row-id');
        if (!$items.length || !$box.is(':visible')) return;
        let active = mrUsageActiveIdx[rowId] != null ? mrUsageActiveIdx[rowId] : 0;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            active = Math.min(active + 1, $items.length - 1);
            mrUsageActiveIdx[rowId] = active;
            $items.removeClass('active').eq(active).addClass('active');
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            active = Math.max(active - 1, 0);
            mrUsageActiveIdx[rowId] = active;
            $items.removeClass('active').eq(active).addClass('active');
        } else if (e.key === 'Enter') {
            e.preventDefault();
            mrPickUsageForRow($wrap, active >= 0 ? active : 0);
        } else if (e.key === 'Escape') {
            mrHideUsageSuggest($wrap);
        }
    }).on('blur.mrusage', function () {
        const $wrap = $(this).closest('.mr-usage-wrap');
        setTimeout(() => mrHideUsageSuggest($wrap), 180);
    });

    $('#medReconDrugBody').off('mousedown.mrusage').on('mousedown.mrusage', '.mr-usage-suggest .item', function (e) {
        e.preventDefault();
        const $wrap = $(this).closest('.mr-usage-wrap');
        mrPickUsageForRow($wrap, Number($(this).data('idx')));
    });
}

function medReconDeleteRow(id) {
    medReconSyncRowsFromDom();
    medReconRows = medReconRows.filter(r => r.id !== id);
    medReconRenderDrugTable();
}

function medReconClearRows() {
    if (!confirm('ล้างรายการยาทั้งหมด?')) return;
    medReconRows = [];
    medReconRenderDrugTable();
}

function mrMark(action, want) {
    return action === want ? '/' : '';
}

function mrCb(checked) {
    return checked ? '☑' : '☐';
}

function mrCode39Svg(text) {
    // Minimal Code39 bars for HN display (no external lib)
    const map = {
        '0':'nnnwwnwnn','1':'wnnwnnnnw','2':'nnwwnnnnw','3':'wnwwnnnnn','4':'nnnwwnnnw',
        '5':'wnnwwnnnn','6':'nnwwwnnnn','7':'nnnwnnwnw','8':'wnnwnnwnn','9':'nnwwnnwnn',
        'A':'wnnnnwnnw','B':'nnwnnwnnw','C':'wnwnnwnnn','D':'nnnnwwnnw','E':'wnnnwwnnn',
        'F':'nnwnwwnnn','G':'nnnnnwwnw','H':'wnnnnwwnn','I':'nnwnnwwnn','J':'nnnnwwwnn',
        'K':'wnnnnnnww','L':'nnwnnnnww','M':'wnwnnnnwn','N':'nnnnwnnww','O':'wnnnwnnwn',
        'P':'nnwnwnnwn','Q':'nnnnnnwww','R':'wnnnnnwwn','S':'nnwnnnwwn','T':'nnnnwnwwn',
        'U':'wwnnnnnnw','V':'nwwnnnnnw','W':'wwwnnnnnn','X':'nwnnwnnnw','Y':'wwnnwnnnn',
        'Z':'nwwnwnnnn','-':'nwnnnnwnw','.':'wwnnnnwnn',' ':'nwwnnnwnn','*':'nwnnwnwnn',
        '$':'nwnwnwnnn','/':'nwnwnnnwn','+':'nwnnnwnwn','%':'nnnwnwnwn'
    };
    const raw = String(text || '').toUpperCase().replace(/[^0-9A-Z\-. $/+%]/g, '');
    if (!raw) return '';
    const data = '*' + raw + '*';
    let bars = '';
    let x = 0;
    const narrow = 1, wide = 3, height = 36;
    for (let i = 0; i < data.length; i++) {
        const pattern = map[data[i]];
        if (!pattern) continue;
        for (let j = 0; j < 9; j++) {
            const w = pattern[j] === 'w' ? wide : narrow;
            if (j % 2 === 0) {
                bars += `<rect x="${x}" y="0" width="${w}" height="${height}" fill="#000"/>`;
            }
            x += w;
        }
        x += narrow; // inter-character gap
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${x}" height="${height + 14}" viewBox="0 0 ${x} ${height + 14}">${bars}<text x="${x / 2}" y="${height + 12}" text-anchor="middle" font-size="10" font-family="monospace">${escapeHtml(raw)}</text></svg>`;
}

/** วันที่/เวลาบันทึก (พ.ศ.) สำหรับช่องลายเซ็น */
function mrSignNowParts() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return {
        date: pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + (d.getFullYear() + 543),
        time: pad(d.getHours()) + ':' + pad(d.getMinutes())
    };
}

/** วางชื่อ + วันเวลา ผู้ Login ในช่องลายเซ็นตามตำแหน่ง */
function mrSignSlotsForLogin() {
    const name = String(MR_LOGIN_NAME || '').trim();
    const role = String(MR_LOGIN_ROLE || '').trim();
    const ep = String(MR_LOGIN_ENTRYPOSITION || '').trim();
    const when = mrSignNowParts();
    const slots = {
        nurse_name: '', pharmacist_name: '', doctor_admit_name: '',
        nurse_date: '', nurse_time: '',
        pharmacist_date: '', pharmacist_time: '',
        doctor_admit_date: '', doctor_admit_time: ''
    };
    if (!name) return slots;

    const isNurseRole = role === 'nurse';
    const isPharmRole = role === 'pharmacist' || role === 'pharmacy_technician';
    const isDoctorRole = role === 'doctor';
    const isNurseEp = /พยาบาล|นักวิชาการสาธารณ|นักวิชาการสาธารณะ/.test(ep);
    const isPharmEp = /เภสัชกร|เจ้าพนักงานเภสัชกรรม/.test(ep);
    const isDoctorEp = /แพทย์/.test(ep) && !/แผนไทย|แผนจีน|ทันต/.test(ep);

    if (isDoctorRole || (!isNurseRole && !isPharmRole && isDoctorEp)) {
        slots.doctor_admit_name = name;
        slots.doctor_admit_date = when.date;
        slots.doctor_admit_time = when.time;
    } else if (isPharmRole || (!isNurseRole && isPharmEp)) {
        slots.pharmacist_name = name;
        slots.pharmacist_date = when.date;
        slots.pharmacist_time = when.time;
    } else if (isNurseRole || isNurseEp) {
        slots.nurse_name = name;
        slots.nurse_date = when.date;
        slots.nurse_time = when.time;
    }
    return slots;
}

/** HTML ช่องวันที่/เวลา — มีค่า = แสดงเวลาบันทึก, ไม่มี = เส้นว่างให้เขียน */
function mrSignWhenHtml(dateStr, timeStr) {
    const d = String(dateStr || '').trim();
    const t = String(timeStr || '').trim();
    if (d && t) {
        return 'วันที่ <b class="sign-dt">' + escapeHtml(d) + '</b> เวลา <b class="sign-dt">' + escapeHtml(t) + '</b>';
    }
    return 'วันที่ <span class="ln"></span> เวลา <span class="ln ln-sm"></span>';
}

function medReconCollectMeta() {
    if ((medReconVisitAppts || []).length && (medReconRows || []).length) {
        mrApplyVisitAppointments(true);
    }
    medReconSyncRowsFromDom();
    const allergyYes = $('#mr_allergy_yes').is(':checked');
    let allergyText = $('#mr_allergy_text').val().trim();
    if (!allergyYes && !allergyText) {
        allergyText = 'ไม่แพ้ยา (HOSxP)';
    }
    const signs = mrSignSlotsForLogin();
    return {
        hospital_name: medReconHospitalName,
        patient_name: $('#mr_patient_name').val().trim(),
        hn: $('#mr_hn').val().trim(),
        vn: $('#mr_vn').val().trim(),
        age: $('#mr_age').val().trim(),
        sex: $('#mr_sex').val(),
        service_date: $('#mr_service_date').val().trim(),
        admit_dt: $('#mr_admit_dt').val().trim(),
        doctor: $('#mr_doctor').val().trim(),
        ward: $('#mr_ward').val().trim(),
        allergy_yes: allergyYes,
        allergy_text: allergyText,
        source: $('input[name="mr_source"]:checked').val() || 'sakaeo',
        source_other: $('#mr_source_other').val().trim(),
        bag: $('input[name="mr_bag"]:checked').val() || 'yes',
        identify: $('input[name="mr_identify"]:checked').val() || 'yes',
        next_appt: $('#mr_next_appt').val().trim(),
        note_mr: $('#mr_note').val().trim(),
        rows: medReconRows.filter(r => mrShowDupRows() || !r.dup_prev),
        nurse_name: signs.nurse_name,
        pharmacist_name: signs.pharmacist_name,
        doctor_admit_name: signs.doctor_admit_name,
        nurse_date: signs.nurse_date,
        nurse_time: signs.nurse_time,
        pharmacist_date: signs.pharmacist_date,
        pharmacist_time: signs.pharmacist_time,
        doctor_admit_date: signs.doctor_admit_date,
        doctor_admit_time: signs.doctor_admit_time,
        print_stamp: mrPrintStamp(),
        print_at: mrFormatDateFull(
            new Date().toISOString().slice(0, 10),
            String(new Date().getHours()).padStart(2, '0') + ':' + String(new Date().getMinutes()).padStart(2, '0')
        )
    };
}

function mrApptPrintHtml(text) {
    const parts = String(text || '')
        .split(/\r?\n+/)
        .map(s => s.trim())
        .filter(Boolean);
    if (!parts.length) return '................................';
    if (parts.length === 1) return escapeHtml(parts[0]);
    return parts.map(p => `<span class="appt-item">${escapeHtml(p)}</span>`).join('');
}

function medReconBuildPrintHtml(meta) {
    const rowsPerPage = 12;
    const drugs = meta.rows.filter(r => {
        return String(r.drug_name || r.method || r.drug_text || '').trim() !== '';
    });
    const totalPages = Math.max(1, Math.ceil(Math.max(drugs.length, 1) / rowsPerPage));
    let pages = '';
    const otherLine = (meta.source === 'other' && meta.source_other)
        ? escapeHtml(meta.source_other)
        : '........................';

    for (let page = 0; page < totalPages; page++) {
        const chunk = drugs.slice(page * rowsPerPage, (page + 1) * rowsPerPage);
        const placeOf = (r) => r.is_manual
            ? String(r.hospital_name || '').trim()
            : mrHospitalPrintLabel(r.hospital_name || '');
        const dateKeyOf = (r) => {
            const date = String(r.order_date || '').trim();
            const place = placeOf(r);
            if (!date && !place) return '';
            return date + '\n' + place;
        };
        const dateSpan = new Array(chunk.length).fill(1);
        const dateSkip = new Array(chunk.length).fill(false);
        for (let i = 0; i < chunk.length; i++) {
            if (dateSkip[i]) continue;
            const key = dateKeyOf(chunk[i]);
            if (!key) continue;
            let n = 1;
            while (i + n < chunk.length && dateKeyOf(chunk[i + n]) === key) {
                dateSkip[i + n] = true;
                n++;
            }
            dateSpan[i] = n;
        }
        const apptKeyOf = (r) => String(r.appt_date || '').trim();
        const apptSpan = new Array(chunk.length).fill(1);
        const apptSkip = new Array(chunk.length).fill(false);
        for (let i = 0; i < chunk.length; i++) {
            if (apptSkip[i]) continue;
            const key = apptKeyOf(chunk[i]);
            if (!key) continue;
            let n = 1;
            while (i + n < chunk.length && apptKeyOf(chunk[i + n]) === key) {
                apptSkip[i + n] = true;
                n++;
            }
            apptSpan[i] = n;
        }
        let body = '';
        chunk.forEach((r, i) => {
            const n = page * rowsPerPage + i + 1;
            const name = mrStripCombinationFormula(String(r.drug_name || '').trim());
            const method = String(r.method || '').trim();
            let label = '';
            const dupMark = r.dup ? '<span class="dup">ซ้ำ</span>' : '';
            const doseChg = String(r.dose_change || '').trim();
            if (name || method) {
                label = `<span class="dn">${n}. ${escapeHtml(name)}${dupMark}</span>`;
                if (method) label += `<span class="dm">${escapeHtml(method)}</span>`;
                if (doseChg) label += `<span class="dm chg">${escapeHtml(doseChg)}</span>`;
            } else {
                const text = String(r.drug_text || '').trim();
                if (text) {
                    const lines = text.split(/\n/);
                    label = `<span class="dn">${n}. ${escapeHtml(mrStripCombinationFormula(lines[0] || ''))}</span>`;
                    if (lines.length > 1) label += `<span class="dm">${escapeHtml(lines.slice(1).join(' ').trim())}</span>`;
                }
            }
            const place = placeOf(r);
            const dateText = String(r.order_date || '').trim();
            const dateHtml = (dateText || place)
                ? ((dateText ? `<span class="dd">${escapeHtml(dateText)}</span>` : '') + (place ? `<span class="dh">${escapeHtml(place)}</span>` : ''))
                : '';
            const apptHtml = escapeHtml(r.appt_label || r.appt_date || '');
            const qtyHtml = mrFormatQtyText(r.qty, r.units);
            const dateCell = dateSkip[i]
                ? ''
                : `<td class="c date"${dateSpan[i] > 1 ? ` rowspan="${dateSpan[i]}"` : ''}>${dateHtml}</td>`;
            const apptCell = apptSkip[i]
                ? ''
                : `<td class="c appt"${apptSpan[i] > 1 ? ` rowspan="${apptSpan[i]}"` : ''}>${apptHtml}</td>`;
            body += `<tr>
                ${dateCell}
                ${apptCell}
                <td class="drug">${label}</td>
                <td class="c qty">${qtyHtml ? escapeHtml(qtyHtml) : ''}</td>
                <td class="c mark">${mrMark(r.admit_action, 'continue')}</td>
                <td class="c mark">${mrMark(r.admit_action, 'change')}</td>
                <td class="c mark">${mrMark(r.admit_action, 'hold')}</td>
                <td class="c mark">${mrMark(r.admit_action, 'off')}</td>
                <td class="c mark">${mrMark(r.home_action, 'continue')}</td>
                <td class="c mark">${mrMark(r.home_action, 'change')}</td>
                <td class="c mark">${mrMark(r.home_action, 'hold')}</td>
                <td class="c mark">${mrMark(r.home_action, 'off')}</td>
                <td class="remark">${escapeHtml(r.remark || '')}</td>
            </tr>`;
        });

        pages += `<section class="sheet">
            <header class="hdr">
                <div class="hdr-main">
                    <div class="title">Medication Reconciliation &amp; Doctor's Order Sheet</div>
                    <div class="hosp">${escapeHtml(meta.hospital_name)}</div>
                </div>
                <div class="page-no">หน้า ${page + 1} / ${totalPages}</div>
            </header>

            <div class="meta-grid">
                <div class="box src-box">
                    <div class="line">ผู้ป่วยรับยาครั้งสุดท้ายจาก :
                        <span class="opt">${mrCb(meta.source === 'sakaeo')} รพ.สระแก้ว</span>
                        <span class="opt">${mrCb(meta.source === 'other')} ที่อื่น ${otherLine}</span>
                    </div>
                    <div class="line">
                        <span class="opt">${mrCb(meta.bag === 'yes')} มีถุงยาเดิม</span>
                        <span class="opt">${mrCb(meta.bag === 'no')} ไม่มีถุงยาเดิม</span>
                    </div>
                    <div class="line">ระบุรายการยา :
                        <span class="opt">${mrCb(meta.identify === 'yes')} ได้</span>
                        <span class="opt">${mrCb(meta.identify === 'no')} ไม่ได้ (ส่งต่อห้องยา)</span>
                    </div>
                    <div class="line admit"><strong>Admit date/time :</strong> ${escapeHtml(meta.admit_dt || '................................')}</div>
                </div>
                <div class="box pt-box">
                    <div class="pt-line"><span class="k">Name</span><span class="v">${escapeHtml(meta.patient_name || '-')}</span></div>
                    <div class="pt-line">
                        <span class="k">HN</span><span class="v short">${escapeHtml(meta.hn || '-')}</span>
                        <span class="k">VN/AN</span><span class="v short">${escapeHtml(meta.vn || '-')}</span>
                    </div>
                    <div class="pt-line">
                        <span class="k">Age</span><span class="v short">${escapeHtml(meta.age || '-')} ปี</span>
                        <span class="k">Sex</span><span class="v short">${mrCb(meta.sex === 'M')} ชาย &nbsp; ${mrCb(meta.sex === 'F')} หญิง</span>
                    </div>
                    <div class="pt-line"><span class="k">วันที่รับบริการ</span><span class="v">${escapeHtml(meta.service_date || '-')}</span></div>
                    <div class="pt-line${/\n/.test(meta.next_appt || '') ? ' appt' : ''}"><span class="k">วันนัดครั้งต่อไป</span><span class="v${/\n/.test(meta.next_appt || '') ? ' appt-list' : ''}">${mrApptPrintHtml(meta.next_appt)}</span></div>
                    <div class="pt-line"><span class="k">แพทย์เจ้าของไข้</span><span class="v">${escapeHtml(meta.doctor || '-')}</span></div>
                    <div class="pt-line"><span class="k">หอผู้ป่วย</span><span class="v">${escapeHtml(meta.ward || '-')}</span></div>
                    <div class="pt-line allergy">
                        <span class="k">แพ้ยา</span>
                        <span class="v">${mrCb(!meta.allergy_yes)} NO &nbsp; ${mrCb(!!meta.allergy_yes)} Yes ${escapeHtml(meta.allergy_text || (meta.allergy_yes ? '' : 'ไม่แพ้ยา(HOSxP)'))}</span>
                        <span class="bc">${mrCode39Svg(meta.hn)}</span>
                    </div>
                </div>
            </div>

            <table class="mr">
                <thead>
                    <tr>
                        <th rowspan="2" class="col-date">วันที่สั่ง<br><span class="sub">สถานที่สั่ง</span></th>
                        <th rowspan="2" class="col-appt">วันที่นัด</th>
                        <th rowspan="2" class="col-drug">รายการยา<br><span class="sub">ยาประจำตัวที่ใช้ก่อน Admit</span></th>
                        <th rowspan="2" class="col-qty">จำนวน<br><span class="sub">เม็ดยา</span></th>
                        <th colspan="4" class="grp-admit">คำสั่งใช้ยาระหว่าง Admit</th>
                        <th colspan="4" class="grp-home">คำสั่งใช้ยากลับบ้าน</th>
                        <th rowspan="2" class="col-note">หมายเหตุ</th>
                    </tr>
                    <tr>
                        <th class="act">ใช้ต่อ</th><th class="act">เปลี่ยน</th><th class="act">งด</th><th class="act">หยุด</th>
                        <th class="act">ใช้ต่อ</th><th class="act">เปลี่ยน</th><th class="act">งด</th><th class="act">หยุด</th>
                    </tr>
                </thead>
                <tbody>${body}</tbody>
            </table>

            <footer class="ftr">
                <div class="note-mr"><span class="k">Note: MR</span>${meta.note_mr ? `<div class="note-mr-text">${escapeHtml(meta.note_mr)}</div>` : ''}</div>
                <div class="sign-sheet">
                    <div class="sign-cols">
                        <div class="sign-col">
                            <div class="sign-role">พยาบาล</div>
                            <div class="sign-who">${escapeHtml(meta.nurse_name || '')}</div>
                            <div class="sign-when">${mrSignWhenHtml(meta.nurse_date, meta.nurse_time)}</div>
                            <div class="sign-duty">พยาบาลผู้ซักประวัติ</div>
                        </div>
                        <div class="sign-col">
                            <div class="sign-role">เภสัช</div>
                            <div class="sign-who">${escapeHtml(meta.pharmacist_name || '')}</div>
                            <div class="sign-when">${mrSignWhenHtml(meta.pharmacist_date, meta.pharmacist_time)}</div>
                            <div class="sign-duty">เภสัชผู้จำแนกประวัติยา</div>
                        </div>
                        <div class="sign-col">
                            <div class="sign-role">แพทย์</div>
                            <div class="sign-who">${escapeHtml(meta.doctor_admit_name || '')}</div>
                            <div class="sign-when">${mrSignWhenHtml(meta.doctor_admit_date, meta.doctor_admit_time)}</div>
                            <div class="sign-duty">แพทย์ผู้สั่งใช้ยา Admit</div>
                        </div>
                        <div class="sign-col">
                            <div class="sign-role">แพทย์</div>
                            <div class="sign-who"></div>
                            <div class="sign-when">วันที่ <span class="ln"></span> เวลา <span class="ln ln-sm"></span></div>
                            <div class="sign-duty">แพทย์ผู้สั่งใช้ยา กลับบ้าน</div>
                        </div>
                    </div>
                    <div class="sign-foot">
                        <div class="sign-stamp">${escapeHtml(meta.print_stamp || '')}</div>
                        <div class="sign-note">กรุณานำใบนี้แนบเอกสารกับใบสั่งยาผู้ป่วย เนื่องจากจำเป็นต้องใช้ข้อมูลในการคำนวณค่าใช้จ่ายของยา<br>เมื่อแพทย์ได้จำหน่าย Discharge แล้วให้ Scan Medication Reconciliation ส่งให้ห้องยาผู้ป่วยใน &nbsp;รอเภสัชบันทึก</div>
                    </div>
                </div>
            </footer>
        </section>`;
    }

    return `<!DOCTYPE html>
<html lang="th"><head>
<meta charset="UTF-8">
<title>Medication Reconciliation - ${escapeHtml(meta.hn)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
@page { size: A4 portrait; margin: 8mm 7mm; }
* { box-sizing: border-box; }
html, body {
    margin: 0; padding: 0;
    font-family: 'Sarabun', 'Noto Sans Thai', 'TH Sarabun New', Tahoma, sans-serif;
    color: #111; background: #fff;
    font-size: 13px; line-height: 1.3;
    -webkit-font-smoothing: antialiased;
    text-rendering: optimizeLegibility;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}
.no-print {
    position: sticky; top: 0; z-index: 9;
    display: flex; gap: 8px; align-items: center; flex-wrap: wrap;
    padding: 10px 14px; background: #eef7f3; border-bottom: 1px solid #c5d4a0;
    font-family: inherit;
}
.no-print button {
    border: 0; border-radius: 6px; padding: 8px 16px; font-weight: 700; cursor: pointer;
    font-family: inherit; font-size: 14px;
}
.btn-print { background: #1f4d3b; color: #fff; }
.btn-close { background: #6c757d; color: #fff; }
.sheet {
    width: 100%;
    max-width: 196mm;
    margin: 0 auto 12px;
    page-break-after: always;
    break-inside: auto;
}
table.mr tr, table.mr thead { break-inside: avoid; page-break-inside: avoid; }
.sheet:last-of-type { page-break-after: auto; margin-bottom: 0; }
/* กันหน้าสุดท้ายมีแต่ลายเซ็น — แถวสุดท้ายติด footer */
table.mr tbody tr:last-child { page-break-after: avoid; break-after: avoid; }
.ftr { page-break-inside: avoid; break-inside: avoid; page-break-before: avoid; break-before: avoid; }

.hdr {
    display: flex; align-items: flex-start; justify-content: space-between;
    gap: 12px; margin-bottom: 7px; padding-bottom: 5px;
    border-bottom: 2px solid #1f4d3b;
}
.hdr-main { flex: 1; text-align: center; }
.hdr .title { font-size: 17px; font-weight: 800; letter-spacing: 0; color: #1a4032; }
.hdr .hosp { font-size: 14px; margin-top: 2px; font-weight: 700; }
.page-no {
    flex: 0 0 auto; font-size: 11.5px; font-weight: 700;
    border: 1px solid #333; border-radius: 4px; padding: 3px 8px; white-space: nowrap;
}

.meta-grid {
    display: grid; grid-template-columns: 1fr 1.15fr; gap: 6px; margin-bottom: 7px;
}
.box {
    border: 1.2px solid #222; border-radius: 3px; padding: 5px 8px;
}
.src-box .line { margin-bottom: 4px; font-weight: 600; }
.src-box .opt { margin-right: 10px; }
.src-box .admit { margin-top: 6px; padding-top: 5px; border-top: 1px dashed #999; }

.pt-line { display: flex; align-items: baseline; gap: 6px; margin-bottom: 2px; }
.pt-line .k { font-weight: 700; min-width: 96px; color: #222; flex: 0 0 auto; font-size: 12.5px; }
.pt-line .v {
    flex: 1; min-width: 0; border-bottom: 1px dotted #777;
    padding: 0 2px 1px; font-weight: 700; font-size: 13px;
}
.pt-line .v.short { flex: 1 1 38%; }
.pt-line.appt { align-items: flex-start; }
.pt-line .v.appt-list {
    border-bottom: none; padding: 0;
    display: flex; flex-direction: column; gap: 2px;
}
.pt-line .v.appt-list .appt-item {
    display: block; border-bottom: 1px dotted #777;
    padding: 0 2px 1px; font-weight: 700; line-height: 1.3;
}
.pt-line.allergy { align-items: flex-end; margin-top: 2px; }
.pt-line.allergy .v { white-space: normal; line-height: 1.3; font-weight: 800; }
.pt-line.allergy .bc { margin-left: 6px; flex: 0 0 auto; }
.pt-line.allergy .bc svg { height: 28px; width: auto; max-width: 38mm; display: block; }

table.mr { width: 100%; border-collapse: collapse; table-layout: fixed; }
table.mr th, table.mr td {
    border: 1px solid #222; padding: 3px 4px; vertical-align: top;
}
table.mr thead th {
    background: #eef5f1 !important; font-size: 11.5px; font-weight: 800; text-align: center;
    vertical-align: middle; line-height: 1.15;
}
table.mr thead th.grp-admit { background: #dceee5 !important; }
table.mr thead th.grp-home { background: #e8eef8 !important; }
table.mr .sub { display: block; font-weight: 600; font-size: 10.5px; color: #333; margin-top: 1px; }
table.mr th.col-date, table.mr td.date { width: 72px; }
table.mr th.col-appt, table.mr td.appt { width: 86px; }
table.mr td.date, table.mr td.appt {
    font-size: 11px; font-weight: 700; line-height: 1.2;
    text-align: center; vertical-align: middle;
    padding: 2px 2px; overflow: visible;
}
table.mr td.date .dd {
    display: block; white-space: normal; font-size: 11px; letter-spacing: 0;
}
table.mr td.appt { white-space: normal; letter-spacing: 0; }
table.mr td.date .dh {
    display: block; font-size: 10px; font-weight: 700;
    color: #1a4032; margin-top: 1px; line-height: 1.15;
    white-space: normal;
}
table.mr th.col-drug { width: 36%; }
table.mr td.drug { width: 36%; }
table.mr th.col-qty, table.mr td.qty {
    width: 58px; font-size: 12px; font-weight: 700;
    white-space: normal; line-height: 1.2;
}
table.mr th.act {
    width: 22px; max-width: 22px;
    font-size: 11px; padding: 4px 1px;
    writing-mode: vertical-rl;
    text-orientation: mixed;
    letter-spacing: 0.02em;
    height: 42px;
}
table.mr td.mark { width: 20px; max-width: 20px; padding: 2px 0; }
table.mr th.col-note, table.mr td.remark { width: 42px; font-size: 12px; }
table.mr td.drug {
    text-align: left; font-size: 12.5px; line-height: 1.25;
    word-wrap: break-word; overflow-wrap: break-word;
    white-space: normal; vertical-align: middle;
}
table.mr td.drug .dn { display: block; font-weight: 800; }
table.mr td.drug .dup { display: inline-block; margin-left: 4px; padding: 0 5px; border-radius: 8px; background: #fde8ea !important; color: #9b2332; font-size: 11px; font-weight: 800; vertical-align: 1px; }
table.mr td.drug .dm { display: block; font-weight: 600; font-size: 12px; color: #222; margin-top: 1px; }
table.mr td.drug .dm.chg { color: #8a3b12; font-size: 11px; }
table.mr td.c { text-align: center; }
table.mr td.mark { font-size: 15px; font-weight: 800; line-height: 1.1; vertical-align: middle; }
table.mr tbody tr { height: 26px; }
table.mr tbody tr:nth-child(even) td { background: #fafcfa !important; }

.ftr { margin-top: 4px; }
.ftr .note-mr {
    font-weight: 800; font-size: 18px; line-height: 1.25;
    color: #c40000; margin: 5px 0 7px; padding: 5px 8px;
    border: 2px solid #c40000; background: #fff1f1 !important;
    min-height: 32px;
}
.ftr .note-mr .k { font-size: 16px; letter-spacing: 0.3px; }
.ftr .note-mr .note-mr-text {
    font-weight: 800; font-size: 20px; color: #c40000;
    white-space: pre-wrap; line-height: 1.3; margin-top: 2px;
}
.ftr .sign-sheet { border: 1.2px solid #222; }
.ftr .sign-cols { display: grid; grid-template-columns: repeat(4, 1fr); }
.ftr .sign-col {
    text-align: center; padding: 4px 4px 5px;
    border-right: 1px solid #222;
}
.ftr .sign-col:last-child { border-right: 0; }
.ftr .sign-role { font-weight: 800; font-size: 12.5px; line-height: 1.2; }
.ftr .sign-who { min-height: 1.3em; font-weight: 800; font-size: 12px; line-height: 1.25; margin-top: 2px; }
.ftr .sign-when { font-size: 11px; margin-top: 7px; white-space: normal; }
.ftr .sign-when .ln {
    display: inline-block; width: 52px; border-bottom: 1px solid #222;
    height: 11px; vertical-align: baseline; margin: 0 2px;
}
.ftr .sign-when .ln-sm { width: 36px; }
.ftr .sign-when .sign-dt { font-weight: 800; font-size: 11px; }
.ftr .sign-duty { font-size: 10.5px; font-weight: 700; margin-top: 5px; line-height: 1.2; }
.ftr .sign-foot {
    display: flex; gap: 8px; align-items: flex-start;
    border-top: 1px solid #222; padding: 3px 6px 4px;
}
.ftr .sign-stamp { flex: 0 0 auto; font-size: 11px; font-weight: 700; white-space: nowrap; padding-top: 1px; }
.ftr .sign-note { flex: 1; font-size: 10.5px; line-height: 1.35; font-weight: 600; }

@media print {
    .no-print { display: none !important; }
    html, body {
        background: #fff !important; width: 210mm;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }
    .sheet { width: 196mm; max-width: 196mm; margin: 0; overflow: hidden; }
    table.mr thead th { background: #eef5f1 !important; }
    table.mr thead th.grp-admit { background: #dceee5 !important; }
    table.mr thead th.grp-home { background: #e8eef8 !important; }
    .ftr .note-mr { background: #fff1f1 !important; }
}
@media screen {
    body { background: #edf1ef; padding-bottom: 24px; }
    .sheet {
        background: #fff; padding: 10mm 9mm;
        box-shadow: 0 2px 14px rgba(0,0,0,0.12); margin-top: 14px;
    }
}
</style>
</head><body>
<div class="no-print">
  <button class="btn-print" onclick="window.print()">พิมพ์เอกสาร</button>
  <button class="btn-close" onclick="window.close()">ปิด</button>
  <span style="color:#1a4032;font-weight:600;">A4 แนวตั้ง · Scale 100% · เปิด Background graphics เพื่อสีหัวตารางเหมือนทุกเครื่อง</span>
</div>
${pages}
<script>(function(){
function go(){try{window.focus();window.print();}catch(e){}}
function waitFont(){
  if(document.fonts&&document.fonts.ready){
    document.fonts.ready.then(function(){setTimeout(go,100);}).catch(function(){setTimeout(go,280);});
  } else { setTimeout(go,320); }
}
if(document.readyState==="complete") waitFont(); else window.onload=waitFont;
})();<\/script>
</body></html>`;
}

let medReconHistItems = [];
let medReconHistPayload = null;
let medReconHistCurrentId = '';
let medReconHistEditId = '';
let mrHistUnhiddenAn = '';

function mrHistCurrentLocalAn() {
    const visit = getSelectedVisit();
    if (!visit || visit.visit_type !== 'ipd') return '';
    if (String(visit.hospital_code || 'local') !== 'local') return '';
    return String(visit.an || '').trim();
}

function mrHistAnPhrase(ans) {
    const show = ans.slice(0, 3).map(function (a) { return 'AN ' + a; });
    let text = 'มีประวัติ Medication Reconciliation ใน ' + show.join(', ');
    if (ans.length > 3) text += ' และอีก ' + (ans.length - 3) + ' AN';
    return text;
}

function mrHistLocalPack(hn) {
    try {
        const all = JSON.parse(localStorage.getItem('tham_smart_medrecon_v1') || '{}') || {};
        const keys = [hn];
        if (/^\d+$/.test(String(hn || ''))) {
            keys.push(String(hn).padStart(9, '0'));
            keys.push(String(parseInt(hn, 10)));
        }
        for (let i = 0; i < keys.length; i++) {
            const pack = all[keys[i]];
            if (pack && Array.isArray(pack.rows) && pack.rows.length) return pack;
        }
    } catch (e) {}
    return null;
}

function mrHistRenderButton(items) {
    medReconHistItems = items || [];
    const latest = medReconHistItems[0];
    $('#btnMedReconHist, #mrHistPatientTab, #btnMedReconHistHidden, #mrHistPatientHidden').hide();
    if (!latest) return;
    const when = latest.saved_at_th || latest.saved_at || '-';
    const n = medReconHistItems.length;
    const label = when + (n > 1 ? ' (' + n + ' ครั้ง)' : '');
    $('#mrHistLatestLabel').text(label);
    $('#mrHistPatientWhen').text(label);

    const currentAn = mrHistCurrentLocalAn();
    const otherAns = [];
    let sameAn = false;
    medReconHistItems.forEach(function (it) {
        const an = String(it.an || '').trim();
        if (!an) return;
        if (currentAn && an === currentAn) sameAn = true;
        else if (otherAns.indexOf(an) < 0) otherAns.push(an);
    });
    if (currentAn && !sameAn && otherAns.length && mrHistUnhiddenAn !== currentAn) {
        const text = mrHistAnPhrase(otherAns);
        $('#mrHistHiddenAn, #mrHistPatientHiddenAn').text(text);
        $('#btnMedReconHistHidden, #mrHistPatientHidden').show();
        return;
    }
    $('#btnMedReconHist').show();
    $('#mrHistPatientTab').show();
}

function mrHistReveal() {
    const an = mrHistCurrentLocalAn();
    if (!an) return;
    mrHistUnhiddenAn = an;
    mrHistRenderButton(medReconHistItems);
    openMedReconHistory();
}

async function loadMedReconHistory(hn) {
    hn = String(hn || '').trim();
    if (!hn) {
        mrHistRenderButton([]);
        return;
    }
    try {
        const res = await fetch('fetch_smart_drug_medrecon_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'history_list', hn: hn })
        });
        const data = await res.json();
        if (String(hn) !== String((globalPatient && globalPatient.hn) || $('#search_hn').val() || '').trim()
            && String(parseInt(hn, 10) || hn) !== String(parseInt((globalPatient && globalPatient.hn) || $('#search_hn').val(), 10) || '')) {
            return;
        }
        mrHistRenderButton((data.status === 'success' && data.items) ? data.items : []);
    } catch (e) {
        $('#btnMedReconHist, #mrHistPatientTab, #btnMedReconHistHidden, #mrHistPatientHidden').hide();
    }
}

function openMedReconHistory() {
    if (!medReconHistItems.length) return;
    let html = '';
    medReconHistItems.forEach(function (it, idx) {
        const place = [it.an ? ('AN ' + it.an) : '', it.vn ? ('VN ' + it.vn) : ''].filter(Boolean).join(' · ');
        html += `<button type="button" class="list-group-item list-group-item-action${idx === 0 ? ' active' : ''}" data-id="${escapeHtml(it.id)}">
            <div class="fw-bold">${escapeHtml(it.saved_at_th || '-')}</div>
            <div class="text-muted">${escapeHtml(it.source_label || '')}${place ? ' · ' + escapeHtml(place) : ''} · ${escapeHtml(String(it.drug_count || 0))} รายการ</div>
            ${it.saved_name ? `<div>ผู้บันทึก ${escapeHtml(it.saved_name)}</div>` : ''}
        </button>`;
    });
    $('#mrHistList').html(html);
    $('#mrHistDetail').html('กำลังเปิด...');
    $('#btnMrHistLoad, #btnMrHistDelete').hide();
    medReconHistPayload = null;
    medReconHistCurrentId = '';
    const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('medReconHistModal'));
    modal.show();
    mrHistOpenItem(medReconHistItems[0].id);
}

async function mrHistOpenItem(id) {
    $('#mrHistList .list-group-item').removeClass('active');
    $('#mrHistList .list-group-item').filter(function () { return $(this).data('id') == id; }).addClass('active');
    $('#mrHistDetail').html('<div class="text-muted">กำลังโหลด...</div>');
    $('#btnMrHistLoad, #btnMrHistDelete').hide();
    medReconHistPayload = null;
    medReconHistCurrentId = id;
    try {
        const res = await fetch('fetch_smart_drug_medrecon_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'history_get', id: id })
        });
        const data = await res.json();
        if (data.status !== 'success') {
            $('#mrHistDetail').html('<div class="text-danger">' + escapeHtml(data.message || 'เปิดประวัติไม่ได้') + '</div>');
            return;
        }
        medReconHistPayload = data.source === 'smart_drug' ? data.payload : null;
        const p = data.payload || {};
        const rows = Array.isArray(p.rows) ? p.rows : [];
        let body = '';
        rows.forEach(function (r, i) {
            const name = String(r.drug_name || r.drug_text || '').trim();
            body += `<tr>
                <td class="text-center">${i + 1}</td>
                <td>${escapeHtml(r.order_date || '')}${r.hospital_name ? `<div class="small text-muted">${escapeHtml(r.hospital_name)}</div>` : ''}</td>
                <td><div class="fw-bold">${escapeHtml(name)}</div>${r.method ? `<div class="small">${escapeHtml(r.method)}</div>` : ''}</td>
                <td class="text-center">${escapeHtml(String(r.qty || ''))} ${escapeHtml(r.units || '')}</td>
            </tr>`;
        });
        const src = data.source === 'hosxp' ? 'HOSxP' : 'Smart Drug';
        $('#mrHistDetail').html(`
            <div class="d-flex justify-content-between flex-wrap gap-2 mb-2">
                <div>
                    <div class="fw-bold fs-5">${escapeHtml(p.patient_name || (globalPatient && globalPatient.full_name) || '-')}</div>
                    <div class="small">HN ${escapeHtml(p.hn || '')} · ${escapeHtml(p.vn || '')} ${p.an ? '· AN ' + escapeHtml(p.an) : ''}</div>
                </div>
                <div class="text-end">
                    <div class="badge text-dark" style="background:#fde68a;">ล่าสุดในรายการนี้ ${escapeHtml(data.saved_at_th || '-')}</div>
                    <div class="small text-muted">${escapeHtml(src)}${data.saved_name ? ' · ' + escapeHtml(data.saved_name) : ''}</div>
                </div>
            </div>
            ${p.note_mr ? `<div class="small mb-2"><span class="fw-bold">Note:</span> ${escapeHtml(p.note_mr)}</div>` : ''}
            <div class="table-responsive bg-white border rounded">
                <table class="table table-sm mb-0">
                    <thead class="table-light"><tr><th width="6%">#</th><th width="18%">วันที่สั่ง</th><th>รายการยา</th><th width="14%">จำนวน</th></tr></thead>
                    <tbody>${body || '<tr><td colspan="4" class="text-center text-muted py-3">ไม่มีรายการยา</td></tr>'}</tbody>
                </table>
            </div>`);
        if (medReconHistPayload) $('#btnMrHistLoad, #btnMrHistDelete').show();
    } catch (e) {
        $('#mrHistDetail').html('<div class="text-danger">เปิดประวัติไม่ได้</div>');
    }
}

function mrHistForgetLocal(hn) {
    try {
        const key = 'tham_smart_medrecon_v1';
        const all = JSON.parse(localStorage.getItem(key) || '{}') || {};
        const keys = [String(hn || '')];
        if (/^\d+$/.test(String(hn || ''))) {
            keys.push(String(hn).padStart(9, '0'));
            keys.push(String(parseInt(hn, 10)));
        }
        keys.forEach(function (k) { if (k) delete all[k]; });
        localStorage.setItem(key, JSON.stringify(all));
    } catch (e) {}
}

async function medReconDeleteHistory() {
    const id = medReconHistCurrentId;
    if (!id || String(id).indexOf('local:') !== 0) {
        alert('ลบได้เฉพาะประวัติที่บันทึกจาก Smart Drug');
        return;
    }
    const typed = window.prompt('ยืนยันลบประวัติ Medication Reconciliation นี้\nพิมพ์คำว่า delete');
    if (typed === null) return;
    if (String(typed).trim() !== 'delete') {
        alert('ยกเลิกการลบ เพราะต้องพิมพ์ delete');
        return;
    }
    const hn = ($('#search_hn').val() || (globalPatient && globalPatient.hn) || '').trim();
    try {
        const res = await fetch('fetch_smart_drug_medrecon_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'history_delete', id: id, confirm: 'delete' })
        });
        const data = await res.json();
        if (data.status !== 'success') {
            alert(data.message || 'ลบไม่สำเร็จ');
            return;
        }
        if (medReconHistEditId === id) medReconHistEditId = '';
        mrHistForgetLocal(hn);
        await loadMedReconHistory(hn);
        if (!medReconHistItems.length) {
            const histModal = bootstrap.Modal.getInstance(document.getElementById('medReconHistModal'));
            if (histModal) histModal.hide();
            return;
        }
        openMedReconHistory();
    } catch (e) {
        alert('ลบไม่สำเร็จ');
    }
}

function medReconLoadHistoryIntoForm() {
    const p = medReconHistPayload;
    if (!p) return;
    medReconHistEditId = medReconHistCurrentId || '';
    if (!globalVisits.length) {
        alert('รอโหลด Visit ของ HN นี้ก่อน แล้วเปิดประวัตินี้อีกครั้ง');
        return;
    }
    const histModal = bootstrap.Modal.getInstance(document.getElementById('medReconHistModal'));
    if (histModal) histModal.hide();
    mrIpdShowAll = false;
    $('#mr_ipd_scope_hme').prop('checked', true);
    mrInitDoctorAutocomplete();
    mrInitAllergyUi();
    medReconRenderVisitList();
    $('#mr_patient_name').val(p.patient_name || '');
    $('#mr_hn').val(p.hn || (globalPatient && globalPatient.hn) || '');
    if (p.vn) $('#mr_vn').val(p.vn);
    if (p.age) $('#mr_age').val(p.age);
    if (p.sex) $('#mr_sex').val(p.sex);
    if (p.service_date) $('#mr_service_date').val(p.service_date);
    if (p.admit_dt) $('#mr_admit_dt').val(p.admit_dt);
    if (p.doctor) $('#mr_doctor').val(p.doctor);
    if (p.ward) $('#mr_ward').val(p.ward);
    if (p.allergy_yes) $('#mr_allergy_yes').prop('checked', true);
    else $('#mr_allergy_no').prop('checked', true);
    if (p.allergy_text) $('#mr_allergy_text').val(p.allergy_text);
    if (p.source) $('input[name="mr_source"][value="' + p.source + '"]').prop('checked', true);
    if (p.source_other) $('#mr_source_other').val(p.source_other);
    if (p.bag) $('input[name="mr_bag"][value="' + p.bag + '"]').prop('checked', true);
    if (p.identify) $('input[name="mr_identify"][value="' + p.identify + '"]').prop('checked', true);
    if (p.next_appt) $('#mr_next_appt').val(p.next_appt);
    $('#mr_note').val(p.note_mr || '');
    medReconRows = (p.rows || []).map(function (r) { return mrNewRow(r); });
    medReconRenderDrugTable();
    const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('medReconModal'));
    modal.show();
}

$(document).on('click', '#mrHistList .list-group-item', function () {
    mrHistOpenItem($(this).data('id'));
});

async function medReconSaveHistory(meta) {
    if (!meta || !meta.hn) return;
    try {
        await fetch('fetch_smart_drug_medrecon_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'history_save',
                hn: meta.hn,
                id: medReconHistEditId || '',
                payload: meta
            })
        });
        loadMedReconHistory(meta.hn);
    } catch (e) {}
}

function medReconPrint() {
    try {
        const meta = medReconCollectMeta();
        medReconPersistLocal();
        if (!meta.hn) {
            alert('ไม่พบ HN');
            return;
        }
        const hasDrug = meta.rows.some(r => String(r.drug_name || r.method || r.drug_text || '').trim() !== '');
        if (!hasDrug) {
            if (!confirm('ยังไม่มีรายการยา — พิมพ์แบบฟอร์มว่างหรือไม่?')) return;
        } else {
            medReconSaveHistory(meta);
        }
        const html = medReconBuildPrintHtml(meta);

        // 1) ลองเปิดหน้าต่างใหม่
        let opened = null;
        try {
            opened = window.open('', '_blank');
        } catch (eOpen) {
            opened = null;
        }
        if (opened && opened.document) {
            opened.document.open();
            opened.document.write(html);
            opened.document.close();
            try { opened.focus(); } catch (eF) {}
            return;
        }

        // 2) ถ้า popup ถูกบล็อก — พิมพ์ผ่าน iframe ซ่อน
        let frame = document.getElementById('medReconPrintFrame');
        if (!frame) {
            frame = document.createElement('iframe');
            frame.id = 'medReconPrintFrame';
            frame.setAttribute('title', 'Med Reconciliation Print');
            frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0;pointer-events:none;';
            document.body.appendChild(frame);
        }
        const doc = frame.contentWindow.document;
        doc.open();
        doc.write(html);
        doc.close();
        // ให้ script ในเอกสารรอฟอนต์ Sarabun แล้วพิมพ์เอง (ไม่เรียก print ซ้ำ)
    } catch (e) {
        console.error('medReconPrint', e);
        alert('พิมพ์ไม่สำเร็จ: ' + (e && e.message ? e.message : String(e)));
    }
}

/* ========== Med Post-op / Review treatment ========== */
let medPostopRows = [];
let medPostopAdmits = [];

function mpLocalDatetimeValue(d) {
    const x = d || new Date();
    const pad = n => String(n).padStart(2, '0');
    return x.getFullYear() + '-' + pad(x.getMonth() + 1) + '-' + pad(x.getDate())
        + 'T' + pad(x.getHours()) + ':' + pad(x.getMinutes());
}

function mpFmtShortDate(isoOrTh) {
    const s = String(isoOrTh || '').trim();
    if (!s || s.indexOf('0000') === 0) return '';
    if (/^\d{4}-\d{2}-\d{2}/.test(s)) {
        const p = s.slice(0, 10).split('-');
        return p[2] + '/' + p[1] + '/' + (parseInt(p[0], 10) + 543);
    }
    // ดึง yyyy-mm-dd ที่ซ่อนอยู่ในสตริง (เช่น datetime)
    const m = s.match(/(\d{4})-(\d{2})-(\d{2})/);
    if (m) return m[3] + '/' + m[2] + '/' + (parseInt(m[1], 10) + 543);
    return s;
}

/** วันเริ่มยา: ใช้ orderdate (ISO) ก่อน แล้วค่อยข้อความไทย */
function mpOrderStartText(row) {
    return mpFmtShortDate((row && (row.orderdate || row.orderdate_dmy || row.orderdate_th)) || '');
}
function mpOffText(row) {
    return mpFmtShortDate((row && (row.offdate || row.offdate_dmy || row.offdate_th)) || '');
}

function medPostopRenderAdmitList(list, selectedAn) {
    medPostopAdmits = list || [];
    const $box = $('#mpAdmitList').empty();
    if (!medPostopAdmits.length) {
        $box.html('<div class="p-3 text-danger small">ไม่พบ AN ที่กำลัง Admit — Med Post-op ใช้ได้เฉพาะผู้ป่วยที่ Admit อยู่</div>');
        return;
    }
    medPostopAdmits.forEach(function (a, i) {
        const an = String(a.an || '');
        const chk = (selectedAn && selectedAn === an) || (!selectedAn && i === 0) ? ' checked' : '';
        const reg = mpFmtShortDate(a.regdate);
        $box.append(
            '<label class="mp-admit-row">'
            + '<input type="radio" class="form-check-input mt-1 mp-admit-cb" name="mp_admit_an" value="' + escapeHtml(an) + '"' + chk + '>'
            + '<span class="flex-grow-1">'
            + '<span class="fw-bold">AN ' + escapeHtml(an) + '</span>'
            + ' <span class="badge visit-badge-ipd ms-1">Admit</span>'
            + '<div class="small text-muted">' + escapeHtml(a.ward_name || '-') + (reg ? (' · รับ ' + escapeHtml(reg)) : '') + '</div>'
            + '</span></label>'
        );
    });
    const picked = $('#mpAdmitList .mp-admit-cb:checked').val() || medPostopAdmits[0].an;
    $('#mp_an').val(picked || '');
    $('#mpAdmitList .mp-admit-cb').off('change.mpadmit').on('change.mpadmit', function () {
        $('#mp_an').val(this.value);
        const hit = medPostopAdmits.find(x => String(x.an) === String(this.value));
        if (hit && hit.ward_name) $('#mp_ward').val(hit.ward_name);
        medPostopReload();
    });
}

function openMedPostopModal() {
    const hn = ((globalPatient && globalPatient.hn) || $('#search_hn').val() || '').trim();
    if (!hn) {
        alert('กรุณาค้นหา HN ก่อนครับ');
        return;
    }
    const p = globalPatient || {};
    $('#mp_patient_name').val(p.full_name || '');
    $('#mp_hn').val(hn);
    $('#mp_an').val('');
    $('#mp_age').val(p.age_text || (p.age_y != null ? (p.age_y + ' ปี') : ''));
    $('#mp_ward').val('');
    $('#mp_pttype').val('');
    $('#mp_date').val(new Date().toISOString().slice(0, 10));
    const alg = mergeAllergyTexts(baseAllergy, dcAllergyRaw);
    $('#mp_allergy').val((alg && alg.has_allergy && alg.text) ? alg.text : 'ไม่แพ้ยา');
    $('#mp_nurse').val(MR_LOGIN_NAME || '');
    $('#mp_nurse_dt').val(mpLocalDatetimeValue());
    $('#mp_doctor').val('');
    $('#mp_doctor_dt').val('');
    medPostopRows = [];
    medPostopRenderRows();
    $('#mpAdmitList').html('<div class="p-3 text-muted small">กำลังตรวจสอบสถานะ Admit...</div>');
    const modal = new bootstrap.Modal(document.getElementById('medPostopModal'));
    modal.show();

    fetch('fetch_smart_drug_postop_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'admit_list', hn: hn })
    })
    .then(r => r.json())
    .then(data => {
        if (!data || !data.ok) {
            $('#mpAdmitList').html('<div class="p-3 text-danger small">' + escapeHtml((data && data.error) || 'โหลดรายการ Admit ไม่สำเร็จ') + '</div>');
            return;
        }
        if (data.patient && data.patient.full_name) $('#mp_patient_name').val(data.patient.full_name);
        if (data.patient && (data.patient.age_text || data.patient.age_y != null)) {
            $('#mp_age').val(data.patient.age_text || (data.patient.age_y + ' ปี'));
        }
        if (data.allergy) {
            $('#mp_allergy').val(data.allergy.has_allergy && data.allergy.text ? data.allergy.text : 'ไม่แพ้ยา');
        }
        const admits = data.admissions || [];
        if (!admits.length) {
            medPostopRenderAdmitList([]);
            alert('ผู้ป่วยนี้ไม่ได้กำลัง Admit — Med Post-op ใช้ได้เฉพาะผู้ป่วยที่ Admit อยู่');
            return;
        }
        const prefer = (getSelectedVisit() && getSelectedVisit().visit_type === 'ipd')
            ? String(getSelectedVisit().an || '') : '';
        medPostopRenderAdmitList(admits, prefer);
        const hit = admits.find(a => String(a.an) === String($('#mp_an').val()));
        if (hit && hit.ward_name) $('#mp_ward').val(hit.ward_name);
        medPostopReload();
    })
    .catch(function () {
        $('#mpAdmitList').html('<div class="p-3 text-danger small">เชื่อมต่อ API ไม่สำเร็จ</div>');
    });
}

function medPostopReload() {
    const hn = ($('#mp_hn').val() || '').trim();
    const an = ($('#mpAdmitList .mp-admit-cb:checked').val() || $('#mp_an').val() || '').trim();
    if (!an) {
        alert('กรุณาเลือก AN ที่กำลัง Admit');
        return;
    }
    $('#mp_an').val(an);
    $('#mpDrugCount').text('…');
    fetch('fetch_smart_drug_postop_api.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'active_meds', hn: hn, an: an })
    })
    .then(r => r.json())
    .then(data => {
        if (!data || !data.ok) {
            alert((data && data.error) || 'โหลดยา Continuous Active ไม่สำเร็จ');
            if (data && data.admissions) medPostopRenderAdmitList(data.admissions, an);
            medPostopRows = [];
            medPostopRenderRows();
            return;
        }
        if (data.hn) $('#mp_hn').val(data.hn);
        if (data.an) $('#mp_an').val(data.an);
        if (data.admissions) medPostopRenderAdmitList(data.admissions, data.an);
        if (data.patient && data.patient.full_name) $('#mp_patient_name').val(data.patient.full_name);
        if (data.patient && (data.patient.age_text || data.patient.age_y != null)) {
            $('#mp_age').val(data.patient.age_text || (data.patient.age_y + ' ปี'));
        }
        if (data.admission && data.admission.ward_name) $('#mp_ward').val(data.admission.ward_name);
        if (data.admission) {
            const ptCode = String(data.admission.pttype || '').trim();
            const ptName = String(data.admission.pttype_name || '').trim();
            let ptText = ptName || ptCode;
            if (ptName && ptCode && ptName.indexOf(ptCode) !== 0) {
                ptText = ptCode + ' — ' + ptName;
            }
            $('#mp_pttype').val(ptText);
        }
        if (data.allergy) {
            $('#mp_allergy').val(data.allergy.has_allergy && data.allergy.text ? data.allergy.text : 'ไม่แพ้ยา');
        }
        medPostopRows = (data.meds || []).map(function (m) {
            const od = String(m.orderdate || '').trim();
            const off = String(m.offdate || '').trim();
            return {
                icode: m.icode || '',
                hosp_drug: m.name || '',
                postop_drug: '',
                usage: m.usage || '',
                orderdate: od,
                orderdate_th: m.orderdate_th || m.orderdate_dmy || '',
                orderdate_dmy: m.orderdate_dmy || '',
                offdate: off,
                offdate_th: m.offdate_th || m.offdate_dmy || '',
                offdate_dmy: m.offdate_dmy || '',
                action: '',
                note: '',
                group: m.group || (m.is_injection ? 'injection' : 'other'),
                med_plan_number: m.med_plan_number || 0
            };
        });
        if (!medPostopRows.length) {
            alert(data.warning || 'ไม่พบยา Continuous (Active) ของ AN นี้');
        }
        medPostopRenderRows();
    })
    .catch(function () {
        alert('เชื่อมต่อ API ไม่สำเร็จ');
        $('#mpDrugCount').text('0');
    });
}

function medPostopAddBlankRow() {
    medPostopSyncFromDom();
    medPostopRows.push({
        icode: '', hosp_drug: '', postop_drug: '', usage: '',
        orderdate: '', orderdate_th: '', orderdate_dmy: '',
        offdate: '', offdate_th: '', offdate_dmy: '',
        action: '', note: '', group: 'other', med_plan_number: 0
    });
    medPostopRenderRows();
}

function medPostopSyncFromDom() {
    const next = [];
    $('#medPostopDrugBody tr[data-mp-i]').each(function () {
        const i = parseInt(this.getAttribute('data-mp-i'), 10);
        if (isNaN(i) || !medPostopRows[i]) return;
        const $tr = $(this);
        const act = $tr.find('input[type="radio"]:checked').val() || '';
        const prev = medPostopRows[i];
        next.push({
            icode: prev.icode || '',
            hosp_drug: ($tr.find('.mp-dn').val() || $tr.find('.mp-hosp').val() || '').trim(),
            postop_drug: '',
            usage: ($tr.find('.mp-dm').val() || $tr.find('.mp-use').val() || '').trim(),
            orderdate: prev.orderdate || this.getAttribute('data-orderdate') || '',
            orderdate_th: prev.orderdate_th || '',
            orderdate_dmy: prev.orderdate_dmy || '',
            offdate: prev.offdate || this.getAttribute('data-offdate') || '',
            offdate_th: prev.offdate_th || '',
            offdate_dmy: prev.offdate_dmy || '',
            action: act,
            note: $tr.find('.mp-note').val() || '',
            group: prev.group || 'other',
            med_plan_number: prev.med_plan_number || 0
        });
    });
    if (next.length) medPostopRows = next;
}

function medPostopRenderRows() {
    const $body = $('#medPostopDrugBody').empty();
    if (!medPostopRows.length) {
        $body.html('<tr><td colspan="8" class="text-center text-muted py-4">ยังไม่มีรายการ — เลือก AN ที่ Admit แล้วกดโหลดยา</td></tr>');
        $('#mpDrugCount').text('0');
        return;
    }
    let lastGroup = '';
    let seq = 0;
    medPostopRows.forEach(function (row, idx) {
        const g = row.group === 'injection' ? 'injection' : 'other';
        if (g !== lastGroup) {
            lastGroup = g;
            const label = g === 'injection' ? 'Injection Form' : 'Other Form';
            $body.append('<tr class="mp-group-row"><td colspan="8">' + label + '</td></tr>');
        }
        seq += 1;
        const chk = function (v) {
            return '<td class="mp-chk"><input type="radio" name="mp_act_' + idx + '" value="' + v + '"'
                + (row.action === v ? ' checked' : '') + '></td>';
        };
        const od = mpOrderStartText(row);
        const off = mpOffText(row);
        const dateHtml = '<div class="mp-date-cell">'
            + (od
                ? ('<div class="mp-od"><small>วันเริ่มยา</small>' + escapeHtml(od) + '</div>')
                : '<div class="mp-od text-muted"><small>วันเริ่มยา</small>—</div>')
            + (off ? ('<div class="mp-off"><small>วันที่ off</small>' + escapeHtml(off) + '</div>') : '')
            + '</div>';
        const rowCls = g === 'injection' ? 'mp-inj' : 'mp-other';
        const nameRows = Math.max(2, Math.min(4, String(row.hosp_drug || '').split(/\n/).length + 1));
        const useRows = Math.max(2, Math.min(5, Math.ceil(String(row.usage || '').length / 42) + 1));
        $body.append(
            '<tr class="' + rowCls + '" data-mp-i="' + idx + '"'
            + ' data-orderdate="' + escapeHtml(row.orderdate || '') + '"'
            + ' data-offdate="' + escapeHtml(row.offdate || '') + '">'
            + '<td class="text-center">' + dateHtml + '</td>'
            + '<td><div class="mp-drug-ro">'
            + '<textarea class="mp-dn mp-hosp" rows="' + nameRows + '" placeholder="ชื่อยา">' + escapeHtml(row.hosp_drug || '') + '</textarea>'
            + '<textarea class="mp-dm mp-use" rows="' + useRows + '" placeholder="วิธีการใช้ยา">' + escapeHtml(row.usage || '') + '</textarea>'
            + (row.icode ? '<div class="mp-icode">icode ' + escapeHtml(row.icode) + '</div>' : '')
            + '</div></td>'
            + chk('continue') + chk('change') + chk('hold') + chk('stop')
            + '<td><textarea class="form-control form-control-sm mp-note" rows="3" placeholder="วิธีใช้ใหม่ / หมายเหตุ">' + escapeHtml(row.note || '') + '</textarea></td>'
            + '<td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger" onclick="medPostopRemoveRow(' + idx + ')"><i class="fas fa-times"></i></button></td>'
            + '</tr>'
        );
    });
    $('#mpDrugCount').text(String(seq));
    $('#medPostopDrugBody').off('change.mpact').on('change.mpact', 'input[type="radio"]', function () {
        const $tr = $(this).closest('tr');
        const i = parseInt($tr.attr('data-mp-i'), 10);
        if (isNaN(i) || !medPostopRows[i]) return;
        medPostopRows[i].action = this.value;
    });
}

function medPostopRemoveRow(idx) {
    medPostopSyncFromDom();
    medPostopRows.splice(idx, 1);
    medPostopRenderRows();
}

function medPostopCollectMeta() {
    medPostopSyncFromDom();
    return {
        patient_name: ($('#mp_patient_name').val() || '').trim(),
        hn: ($('#mp_hn').val() || '').trim(),
        an: ($('#mp_an').val() || '').trim(),
        age: ($('#mp_age').val() || '').trim(),
        ward: ($('#mp_ward').val() || '').trim(),
        pttype: ($('#mp_pttype').val() || '').trim(),
        allergy: ($('#mp_allergy').val() || '').trim(),
        date: ($('#mp_date').val() || '').trim(),
        nurse: ($('#mp_nurse').val() || '').trim(),
        nurse_dt: ($('#mp_nurse_dt').val() || '').trim(),
        doctor: ($('#mp_doctor').val() || '').trim(),
        doctor_dt: ($('#mp_doctor_dt').val() || '').trim(),
        rows: medPostopRows.slice()
    };
}

function mpFmtDateTh(iso) {
    if (!iso) return '';
    const p = String(iso).slice(0, 10).split('-');
    if (p.length !== 3) return iso;
    const y = parseInt(p[0], 10) + 543;
    return p[2] + '/' + p[1] + '/' + y;
}

function mpFmtDt(local) {
    if (!local) return '';
    const m = String(local).match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
    if (!m) return local;
    const y = parseInt(m[1], 10) + 543;
    return m[3] + '/' + m[2] + '/' + y + ' เวลา ' + m[4] + ':' + m[5] + ' น.';
}

function medPostopActionMark(action, key) {
    return action === key ? '☑' : '☐';
}

function medPostopBuildPrintHtml(meta) {
    const items = [];
    (meta.rows || []).forEach(function (r) {
        if (!(r.hosp_drug || r.usage || r.note || r.action)) return;
        items.push(r);
    });
    let bodyRows = '';
    if (!items.length) {
        bodyRows = '<tr><td colspan="7" class="empty-msg">ไม่มีรายการยา</td></tr>';
    } else {
        items.forEach(function (r, idx) {
            const n = idx + 1;
            const isLast = idx === items.length - 1;
            const od = mpOrderStartText(r);
            const off = mpOffText(r);
            const startCell = '<div class="dno">' + n + '</div>'
                + '<div class="dod-lbl">วันเริ่มยา</div>'
                + '<div class="dod">' + escapeHtml(od || '—') + '</div>'
                + (off ? ('<div class="doff-lbl">off</div><div class="doff">' + escapeHtml(off) + '</div>') : '');
            const drugCell = '<div class="dn">' + escapeHtml(r.hosp_drug || '') + '</div>'
                + (r.usage ? ('<div class="du">' + escapeHtml(r.usage).replace(/\n/g, '<br>') + '</div>') : '');
            bodyRows += '<tr' + (isLast ? ' class="keep-tail"' : '') + '>'
                + '<td class="c">' + startCell + '</td>'
                + '<td class="drug">' + drugCell + '</td>'
                + '<td class="chk">' + medPostopActionMark(r.action, 'continue') + '</td>'
                + '<td class="chk">' + medPostopActionMark(r.action, 'change') + '</td>'
                + '<td class="chk">' + medPostopActionMark(r.action, 'hold') + '</td>'
                + '<td class="chk">' + medPostopActionMark(r.action, 'stop') + '</td>'
                + '<td class="note-cell">' + escapeHtml(r.note || '') + '</td>'
                + '</tr>';
        });
    }
    return '<!DOCTYPE html><html lang="th"><head><meta charset="utf-8"><title>Med Post-op</title>'
        + '<link rel="preconnect" href="https://fonts.googleapis.com">'
        + '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
        + '<link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;600;700;800&display=swap" rel="stylesheet">'
        + '<style>'
        + '@page{size:A4 portrait;margin:8mm 9mm;}'
        + '*{box-sizing:border-box;}'
        + 'html,body{margin:0;padding:0;}'
        + 'body{font-family:"Sarabun","Noto Sans Thai","TH Sarabun New",Tahoma,sans-serif;'
        + 'font-size:14.5px;color:#1a2332;margin:0;line-height:1.35;'
        + '-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;}'
        + '.banner{background:#0f766e;color:#fff;border-radius:8px;padding:10px 12px 8px;'
        + 'margin-bottom:7px;text-align:center;}'
        + '.banner h1{font-size:22px;margin:0;font-weight:800;line-height:1.25;letter-spacing:0;}'
        + '.banner .sub{font-size:12.5px;opacity:.95;margin-top:2px;font-weight:600;}'
        + '.meta{display:grid;grid-template-columns:1.35fr .85fr .85fr;gap:0;margin-bottom:7px;'
        + 'border:1.5px solid #0f766e;border-radius:8px;overflow:hidden;}'
        + '.meta div{padding:6px 10px;background:#f0fdfa;border-bottom:1px solid #99f6e4;'
        + 'font-size:14.5px;line-height:1.35;font-weight:600;}'
        + '.meta .wide{grid-column:1/-1;}'
        + '.meta .pttype{background:#ecfeff;color:#0e7490;font-size:14.5px;font-weight:700;}'
        + '.meta .allergy{background:#fff7ed;color:#9a3412;font-size:15.5px;font-weight:800;}'
        + '.meta b{color:#0f766e;font-weight:800;margin-right:5px;font-size:13px;}'
        + '.meta .pttype b{color:#0e7490;}.meta .allergy b{color:#9a3412;}'
        + 'table.mp-tbl{width:100%;border-collapse:collapse;table-layout:fixed;}'
        + 'col.c-no{width:12%;}col.c-drug{width:46%;}col.c-chk{width:7%;}col.c-note{width:14%;}'
        + 'th,td{border:1.25px solid #1f2937;padding:5px 5px;vertical-align:top;}'
        + 'th{background:#d1fae5;color:#065f46;font-size:11.5px;font-weight:800;text-align:center;line-height:1.2;}'
        + 'th.subh{background:#ecfdf5;font-size:11px;font-weight:700;}'
        + 'thead{display:table-header-group;}'
        + 'tbody tr{page-break-inside:avoid;break-inside:avoid;}'
        + 'tr.keep-tail{page-break-after:avoid;break-after:avoid;}'
        + 'td.c{text-align:center;vertical-align:middle;font-size:12px;line-height:1.2;}'
        + 'td.c .dno{font-weight:800;font-size:13.5px;margin-bottom:1px;}'
        + 'td.c .dod-lbl,td.c .doff-lbl{font-size:9.5px;font-weight:700;color:#64748b;}'
        + 'td.c .dod{color:#0f766e;font-weight:800;font-size:13.5px;}'
        + 'td.c .doff{color:#b45309;font-weight:800;font-size:12px;}'
        + 'td.drug{vertical-align:middle;}'
        + 'td.drug .dn{font-weight:800;font-size:14.5px;margin-bottom:2px;line-height:1.3;}'
        + 'td.drug .du{font-size:13px;color:#334155;line-height:1.35;font-weight:600;}'
        + 'td.chk{text-align:center;vertical-align:middle;font-size:16px;}'
        + 'td.note-cell{font-size:12px;}'
        + 'td.empty-msg{text-align:center;color:#64748b;padding:14px;}'
        + '.tail{page-break-inside:avoid;break-inside:avoid;page-break-before:avoid;break-before:avoid;}'
        + '.tip{margin-top:7px;font-size:11.5px;color:#9a3412;background:#fff7ed;border:1.25px solid #fb923c;'
        + 'border-radius:7px;padding:6px 9px;line-height:1.35;}'
        + '.foot{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px;}'
        + '.box{border:1.25px solid #0f766e;border-radius:8px;padding:8px 10px;min-height:58px;background:#f8fffd;}'
        + '.box .ttl{font-weight:800;color:#0f766e;font-size:13px;margin-bottom:2px;}'
        + '.box .nm{font-size:13px;min-height:18px;font-weight:600;}'
        + '.box .dt{font-size:11.5px;color:#475569;margin-top:4px;}'
        + '@media print{'
        + 'body{-webkit-print-color-adjust:exact;print-color-adjust:exact;}'
        + '.banner{background:#0f766e!important;}'
        + 'th{background:#d1fae5!important;}'
        + '}'
        + '</style></head><body>'
        + '<div class="banner"><h1>ยาที่ได้รับก่อนและหลังผ่าตัด (Post-op)</h1>'
        + '<div class="sub">หรือ Review treatment (Doctor’s Order Sheet)</div></div>'
        + '<div class="meta">'
        + '<div><b>ชื่อ</b>' + escapeHtml(meta.patient_name || '-') + '</div>'
        + '<div><b>HN</b>' + escapeHtml(meta.hn || '-') + '</div>'
        + '<div><b>AN</b>' + escapeHtml(meta.an || '-') + '</div>'
        + '<div><b>อายุ</b>' + escapeHtml(meta.age || '-') + '</div>'
        + '<div><b>หอผู้ป่วย</b>' + escapeHtml(meta.ward || '-') + '</div>'
        + '<div><b>วันที่</b>' + escapeHtml(mpFmtDateTh(meta.date) || '-') + '</div>'
        + '<div class="wide pttype"><b>สิทธิการรักษา</b>' + escapeHtml(meta.pttype || '-') + '</div>'
        + '<div class="wide allergy"><b>ประวัติแพ้ยา</b>' + escapeHtml(meta.allergy || '-') + '</div>'
        + '</div>'
        + '<table class="mp-tbl"><colgroup>'
        + '<col class="c-no"><col class="c-drug"><col class="c-chk"><col class="c-chk"><col class="c-chk"><col class="c-chk"><col class="c-note">'
        + '</colgroup><thead>'
        + '<tr>'
        + '<th rowspan="2" style="vertical-align:middle;"># / วันเริ่มยา<br><span style="font-weight:600;font-size:10px;">(= วันที่สั่ง) · off</span></th>'
        + '<th>รายการยา / วิธีการใช้ยา</th>'
        + '<th colspan="5">รายการยาที่ได้รับ Post op / Review treatment</th>'
        + '</tr>'
        + '<tr>'
        + '<th class="subh">ชื่อยา · วิธีใช้</th>'
        + '<th class="subh">ใช้ต่อวิธีเดิม</th>'
        + '<th class="subh">เปลี่ยนวิธีใช้</th>'
        + '<th class="subh">งดใช้</th>'
        + '<th class="subh">หยุดยา</th>'
        + '<th class="subh">หมายเหตุ</th>'
        + '</tr>'
        + '</thead><tbody>' + bodyRows + '</tbody></table>'
        + '<div class="tail">'
        + '<div class="tip">*** กรณีสั่งใช้ยาหลังผ่าตัด Post-op หรือ Review treatment หากต้องการปรับวิธีการใช้ยา '
        + 'แพทย์สามารถระบุวิธีการใช้ยาแบบใหม่ในช่อง “หมายเหตุ” ได้ ***</div>'
        + '<div class="foot">'
        + '<div class="box"><div class="ttl">พยาบาล</div><div class="nm">' + escapeHtml(meta.nurse || '……………………………………………') + '</div>'
        + '<div class="dt">วันที่/เวลา ' + escapeHtml(mpFmtDt(meta.nurse_dt) || '…………………..…. เวลา …………..') + '</div></div>'
        + '<div class="box"><div class="ttl">แพทย์</div><div class="nm">' + escapeHtml(meta.doctor || '…………………………..…………') + '</div>'
        + '<div class="dt">วันที่/เวลา ' + escapeHtml(mpFmtDt(meta.doctor_dt) || '…………………..…. เวลา …………..') + '</div></div>'
        + '</div></div>'
        + '<script>(function(){function go(){try{window.focus();window.print();}catch(e){}}'
        + 'function waitFont(){if(document.fonts&&document.fonts.ready){document.fonts.ready.then(function(){setTimeout(go,80);}).catch(function(){setTimeout(go,200);});}'
        + 'else{setTimeout(go,250);}}'
        + 'if(document.readyState==="complete")waitFont();else window.onload=waitFont;})();<\/script>'
        + '</body></html>';
}

function medPostopPrint() {
    try {
        const meta = medPostopCollectMeta();
        if (!meta.hn && !meta.an) {
            alert('ไม่พบ HN/AN');
            return;
        }
        const hasDrug = meta.rows.some(r => String(r.hosp_drug || r.usage || '').trim() !== '');
        if (!hasDrug && !confirm('ยังไม่มีรายการยา — พิมพ์แบบฟอร์มว่างหรือไม่?')) return;
        const html = medPostopBuildPrintHtml(meta);
        let opened = null;
        try { opened = window.open('', '_blank'); } catch (e0) { opened = null; }
        if (opened && opened.document) {
            opened.document.open();
            opened.document.write(html);
            opened.document.close();
            try { opened.focus(); } catch (e1) {}
            return;
        }
        let frame = document.getElementById('medPostopPrintFrame');
        if (!frame) {
            frame = document.createElement('iframe');
            frame.id = 'medPostopPrintFrame';
            frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0;pointer-events:none;';
            document.body.appendChild(frame);
        }
        const doc = frame.contentWindow.document;
        doc.open();
        doc.write(html);
        doc.close();
        setTimeout(function () {
            try {
                frame.contentWindow.focus();
                frame.contentWindow.print();
            } catch (e2) {
                alert('เบราว์เซอร์บล็อกหน้าต่างพิมพ์ — กรุณาอนุญาต popup');
            }
        }, 350);
    } catch (e) {
        console.error('medPostopPrint', e);
        alert('พิมพ์ไม่สำเร็จ: ' + (e && e.message ? e.message : String(e)));
    }
}
</script>
</body>
</html>
