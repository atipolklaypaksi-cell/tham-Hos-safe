<?php
/**
 * Monitor ยากลับบ้าน (HME)
 * คนไข้ IPD ที่มียาประเภท HME — เทียบกับยา OPD ก่อน admit และ HME จาก IPD ครั้งก่อน (re-admit ก่อนวันนัด)
 */

function mhm_default_config() {
    return [
        'lookback_days' => 90,
        'match_mode' => 'icode_or_tmt',
        'min_remaining_days' => 1,
        'include_unknown_remaining' => 1,
        'exclude_prn' => 1,
        'alert_level_remaining' => 'soft',
        'alert_level_unknown' => 'soft',
        'exclude_icodes' => [],
        'monitor_active' => 1,
        'hide_low_remaining' => 1,
        'hide_low_remaining_days' => 20,
        'hide_short_hme' => 1,
        'hide_short_hme_days' => 14,
        'unitprice_exception' => 100,
    ];
}

function mhm_ensure_tables($con) {
    $q = mysqli_query($con, "SHOW TABLES LIKE 'monitor_home_med_config'");
    if ($q && mysqli_num_rows($q) > 0) {
        mysqli_query($con, "INSERT IGNORE INTO monitor_home_med_config (id) VALUES (1)");
        mhm_ensure_config_columns($con);
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_home_med.sql');
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '' && !mysqli_query($con, $stmt)) {
            return false;
        }
    }
    mhm_ensure_config_columns($con);
    return true;
}

function mhm_ensure_config_columns($con) {
    $need = [
        'hide_low_remaining' => "TINYINT(1) NOT NULL DEFAULT 1",
        'hide_low_remaining_days' => "INT NOT NULL DEFAULT 20",
        'hide_short_hme' => "TINYINT(1) NOT NULL DEFAULT 1",
        'hide_short_hme_days' => "INT NOT NULL DEFAULT 14",
        'unitprice_exception' => "DECIMAL(10,2) NOT NULL DEFAULT 100.00",
    ];
    foreach ($need as $col => $def) {
        $q = @mysqli_query($con, "SHOW COLUMNS FROM monitor_home_med_config LIKE '$col'");
        if ($q && mysqli_num_rows($q) === 0) {
            @mysqli_query($con, "ALTER TABLE monitor_home_med_config ADD COLUMN $col $def");
        }
    }
    @mysqli_query($con, "ALTER TABLE monitor_home_med_config
        MODIFY COLUMN alert_level_remaining VARCHAR(10) NOT NULL DEFAULT 'soft'");
    @mysqli_query($con, "ALTER TABLE monitor_home_med_config
        MODIFY COLUMN alert_level_unknown VARCHAR(10) NOT NULL DEFAULT 'soft'");
    $flag = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='mhm_soft_alert_default_v1' LIMIT 1");
    if (!$flag || mysqli_num_rows($flag) === 0) {
        @mysqli_query($con, "UPDATE monitor_home_med_config SET alert_level_remaining='soft' WHERE id=1 AND LOWER(IFNULL(alert_level_remaining,''))='hard'");
        @mysqli_query($con, "INSERT IGNORE INTO sys_config (config_name, config_value) VALUES ('mhm_soft_alert_default_v1','1')");
    }
    $flag_val = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name='mhm_min_order_value_v1' LIMIT 1");
    if (!$flag_val || mysqli_num_rows($flag_val) === 0) {
        @mysqli_query($con, "UPDATE monitor_home_med_config SET unitprice_exception=100 WHERE id=1 AND unitprice_exception=50");
        @mysqli_query($con, "INSERT IGNORE INTO sys_config (config_name, config_value) VALUES ('mhm_min_order_value_v1','1')");
    }
}

function mhm_normalize_match_mode($mode) {
    return strtolower(trim((string)$mode)) === 'icode' ? 'icode' : 'icode_or_tmt';
}

function mhm_normalize_alert_level($level) {
    return strtolower(trim((string)$level)) === 'hard' ? 'hard' : 'soft';
}

function mhm_alert_badge_html($level) {
    if (mhm_normalize_alert_level($level) === 'hard') {
        return '<span class="badge bg-danger">Hard Alert</span>';
    }
    return '<span class="badge bg-warning text-dark">Soft Alert</span>';
}

function mhm_decode_exclude_icodes($raw) {
    if (is_array($raw)) {
        $list = $raw;
    } else {
        $raw = trim((string)$raw);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        $list = is_array($decoded) ? $decoded : preg_split('/[\s,;]+/', $raw);
    }
    $out = [];
    foreach ($list as $ic) {
        $ic = trim((string)$ic);
        if ($ic !== '') {
            $out[$ic] = true;
        }
    }
    return array_keys($out);
}

function mhm_get_config($con) {
    mhm_ensure_tables($con);
    $cfg = mhm_default_config();
    $q = mysqli_query($con, 'SELECT * FROM monitor_home_med_config WHERE id = 1 LIMIT 1');
    $row = $q ? mysqli_fetch_assoc($q) : null;
    if (!$row) {
        return $cfg;
    }
    $cfg['lookback_days'] = max(7, min(365, (int)($row['lookback_days'] ?? 90)));
    $cfg['match_mode'] = mhm_normalize_match_mode($row['match_mode'] ?? 'icode_or_tmt');
    $cfg['min_remaining_days'] = max(0, min(180, (int)($row['min_remaining_days'] ?? 1)));
    $cfg['include_unknown_remaining'] = !empty($row['include_unknown_remaining']) ? 1 : 0;
    $cfg['exclude_prn'] = !empty($row['exclude_prn']) ? 1 : 0;
    $cfg['alert_level_remaining'] = mhm_normalize_alert_level($row['alert_level_remaining'] ?? 'soft');
    $cfg['alert_level_unknown'] = mhm_normalize_alert_level($row['alert_level_unknown'] ?? 'soft');
    $cfg['exclude_icodes'] = mhm_decode_exclude_icodes($row['exclude_icodes'] ?? '[]');
    $cfg['monitor_active'] = !empty($row['monitor_active']) ? 1 : 0;
    $cfg['hide_low_remaining'] = array_key_exists('hide_low_remaining', $row)
        ? (!empty($row['hide_low_remaining']) ? 1 : 0) : 1;
    $cfg['hide_low_remaining_days'] = max(0, min(365, (int)($row['hide_low_remaining_days'] ?? 20)));
    $cfg['hide_short_hme'] = array_key_exists('hide_short_hme', $row)
        ? (!empty($row['hide_short_hme']) ? 1 : 0) : 1;
    $cfg['hide_short_hme_days'] = max(0, min(365, (int)($row['hide_short_hme_days'] ?? 14)));
    $cfg['unitprice_exception'] = max(0, (float)($row['unitprice_exception'] ?? 100));
    return $cfg;
}

function mhm_save_config($con, array $in) {
    mhm_ensure_tables($con);
    $lookback = max(7, min(365, (int)($in['lookback_days'] ?? 90)));
    $mode = mhm_normalize_match_mode($in['match_mode'] ?? 'icode_or_tmt');
    $min_rem = max(0, min(180, (int)($in['min_remaining_days'] ?? 1)));
    $unk = !empty($in['include_unknown_remaining']) ? 1 : 0;
    $prn = !empty($in['exclude_prn']) ? 1 : 0;
    $lvl_rem = mhm_normalize_alert_level($in['alert_level_remaining'] ?? 'soft');
    $lvl_unk = mhm_normalize_alert_level($in['alert_level_unknown'] ?? 'soft');
    $active = !empty($in['monitor_active']) ? 1 : 0;
    $hide_low = !empty($in['hide_low_remaining']) ? 1 : 0;
    $hide_days = max(0, min(365, (int)($in['hide_low_remaining_days'] ?? 20)));
    $hide_short = !empty($in['hide_short_hme']) ? 1 : 0;
    $hide_short_days = max(0, min(365, (int)($in['hide_short_hme_days'] ?? 14)));
    $price_ex = max(0, (float)($in['unitprice_exception'] ?? 100));
    $price_sql = number_format($price_ex, 2, '.', '');
    $exclude = mhm_decode_exclude_icodes($in['exclude_icodes'] ?? []);
    $exclude_json = mysqli_real_escape_string($con, json_encode(array_values($exclude), JSON_UNESCAPED_UNICODE));
    $mode_esc = mysqli_real_escape_string($con, $mode);
    $lvl_rem_esc = mysqli_real_escape_string($con, $lvl_rem);
    $lvl_unk_esc = mysqli_real_escape_string($con, $lvl_unk);
    $sql = "INSERT INTO monitor_home_med_config
            (id, lookback_days, match_mode, min_remaining_days, include_unknown_remaining,
             exclude_prn, alert_level_remaining, alert_level_unknown, exclude_icodes, monitor_active,
             hide_low_remaining, hide_low_remaining_days, hide_short_hme, hide_short_hme_days, unitprice_exception)
            VALUES (1, $lookback, '$mode_esc', $min_rem, $unk, $prn, '$lvl_rem_esc', '$lvl_unk_esc', '$exclude_json', $active,
                    $hide_low, $hide_days, $hide_short, $hide_short_days, $price_sql)
            ON DUPLICATE KEY UPDATE
                lookback_days = VALUES(lookback_days),
                match_mode = VALUES(match_mode),
                min_remaining_days = VALUES(min_remaining_days),
                include_unknown_remaining = VALUES(include_unknown_remaining),
                exclude_prn = VALUES(exclude_prn),
                alert_level_remaining = VALUES(alert_level_remaining),
                alert_level_unknown = VALUES(alert_level_unknown),
                exclude_icodes = VALUES(exclude_icodes),
                monitor_active = VALUES(monitor_active),
                hide_low_remaining = VALUES(hide_low_remaining),
                hide_low_remaining_days = VALUES(hide_low_remaining_days),
                hide_short_hme = VALUES(hide_short_hme),
                hide_short_hme_days = VALUES(hide_short_hme_days),
                unitprice_exception = VALUES(unitprice_exception)";
    return (bool)mysqli_query($con, $sql);
}

function mhm_sql_hme_filter($o = 'o', $ion = 'ion', $oh = 'oh') {
    return "
        AND (
            LOWER(TRIM(IFNULL($ion.order_type,''))) = 'hme'
            OR TRIM(IFNULL($o.item_type,'')) = 'H'
            OR $oh.opi_guid IS NOT NULL
        )
    ";
}

function mhm_sql_hme_joins($o = 'o') {
    return "
        LEFT JOIN ipt_order_no ion ON ion.order_no = $o.order_no
        LEFT JOIN opitemrece_home oh ON oh.opi_guid = $o.hos_guid AND oh.opitemrece_home_type_id = 2
    ";
}

function mhm_sql_order_date($o = 'o') {
    return "COALESCE(NULLIF($o.rxdate, '0000-00-00'), $o.vstdate)";
}

function mhm_norm_name($s) {
    $s = trim(preg_replace('/\s+/u', ' ', (string)$s));
    if ($s === '') {
        return '';
    }
    return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
}

function mhm_is_prn_method($method) {
    $m = trim((string)$method);
    return $m !== '' && (bool)preg_match('/prn|เมื่อมีอาการ|ตามอาการ|เมื่อจำเป็น|if needed|as needed/iu', $m);
}

function mhm_coverage_days($qty, $method) {
    $qty = (float)$qty;
    if ($qty <= 0) {
        return null;
    }
    $daily = function_exists('di_parse_daily_dose') ? di_parse_daily_dose($method) : null;
    if ($daily === null || $daily <= 0) {
        return null;
    }
    return max(1, (int)ceil($qty / $daily));
}

function mhm_days_between($from, $to) {
    $from = trim((string)$from);
    $to = trim((string)$to);
    if ($from === '' || $to === '' || $from === '0000-00-00' || $to === '0000-00-00') {
        return null;
    }
    $a = strtotime($from);
    $b = strtotime($to);
    if (!$a || !$b) {
        return null;
    }
    return (int)floor(($b - $a) / 86400);
}

/** จำนวนวันหลังจากได้ HME ถึงวันนัดข้างหน้า (25/08 → 22/09 = 28 วัน) */
function mhm_days_hme_to_appointment($hme_date, $nextdate) {
    return mhm_days_between($hme_date, $nextdate);
}

function mhm_days_hme_to_appointment_text($days) {
    if ($days === null) {
        return '';
    }
    $days = (int)$days;
    if ($days < 0) {
        return 'นัดก่อนได้ยา ' . abs($days) . ' วัน';
    }
    if ($days === 0) {
        return 'วันเดียวกับวันนัด';
    }
    return $days . ' วัน';
}

/** นัดที่อยู่หลังวันสั่งยาเท่านั้น — ตัดนัดวันเดียวกับวันสั่ง (และนัดย้อนหลัง) */
function mhm_future_appointments(array $appointments, $order_date) {
    $order_date = substr(trim((string)$order_date), 0, 10);
    $out = [];
    foreach ($appointments as $a) {
        if (!is_array($a)) {
            continue;
        }
        $date = substr(trim((string)($a['date'] ?? $a['nextdate'] ?? '')), 0, 10);
        if ($date === '' || $date === '0000-00-00') {
            continue;
        }
        $days = $order_date !== '' ? mhm_days_hme_to_appointment($order_date, $date) : null;
        if ($days !== null && $days <= 0) {
            continue;
        }
        $row = $a;
        $row['date'] = $date;
        if (empty($row['date_fmt'])) {
            $row['date_fmt'] = mhm_format_date($date);
        }
        $row['days'] = $days;
        $row['days_text'] = mhm_days_hme_to_appointment_text($days);
        $out[] = $row;
    }
    return $out;
}

function mhm_next_from_appointments(array $appointments) {
    $first = $appointments[0] ?? null;
    if (!$first) {
        return mhm_empty_appointment_lookup();
    }
    return [
        'appointments' => $appointments,
        'next_appointment' => $first['date'] ?? '',
        'next_appointment_fmt' => $first['date_fmt'] ?? mhm_format_date($first['date'] ?? ''),
        'next_appointment_time' => $first['time'] ?? '',
        'next_appointment_clinic' => $first['clinic'] ?? ($first['clinic_name'] ?? ''),
        'next_appointment_doctor' => $first['doctor'] ?? ($first['doctor_name'] ?? ''),
    ];
}

function mhm_format_appointment_item(array $a) {
    $date = substr(trim((string)($a['nextdate'] ?? $a['date'] ?? '')), 0, 10);
    $clinic = trim((string)($a['clinic_name'] ?? ''));
    if ($clinic === '') {
        $clinic = trim((string)($a['clinic'] ?? ''));
    }
    $time = mhm_format_appt_time($a['nexttime'] ?? $a['time'] ?? '');
    $doctor = trim((string)($a['doctor_name'] ?? ''));
    if ($doctor === '') {
        $doctor = trim((string)($a['doctor'] ?? ''));
    }
    return [
        'date' => $date,
        'date_fmt' => mhm_format_date($date),
        'time' => $time,
        'clinic' => $clinic,
        'doctor' => $doctor,
        'vstdate' => substr(trim((string)($a['vstdate'] ?? '')), 0, 10),
    ];
}

/**
 * นัดที่สั่งใน visit นั้น — วันที่มา / วันที่สั่งนัด (oapp.vstdate) = วันที่สั่งยา
 */
function mhm_appointments_for_visit_date(array $appointments, $visit_date) {
    $visit_date = substr(trim((string)$visit_date), 0, 10);
    $has_vst = false;
    foreach ($appointments as $a) {
        if (!is_array($a)) {
            continue;
        }
        if (substr(trim((string)($a['vstdate'] ?? '')), 0, 10) !== '') {
            $has_vst = true;
            break;
        }
    }
    if (!$has_vst || $visit_date === '') {
        return $appointments;
    }
    $out = [];
    foreach ($appointments as $a) {
        if (!is_array($a)) {
            continue;
        }
        $vd = substr(trim((string)($a['vstdate'] ?? '')), 0, 10);
        if ($vd === $visit_date) {
            $out[] = $a;
        }
    }
    return $out;
}

function mhm_empty_appointment_lookup() {
    return [
        'appointments' => [],
        'next_appointment' => '',
        'next_appointment_fmt' => '',
        'next_appointment_time' => '',
        'next_appointment_clinic' => '',
        'next_appointment_doctor' => '',
    ];
}

function mhm_attach_appt_days(array $item, $nextdate, array $appointments = []) {
    if (empty($appointments) && trim((string)$nextdate) !== '') {
        $appointments = [['date' => $nextdate, 'date_fmt' => mhm_format_date($nextdate)]];
    }
    $rows = mhm_future_appointments($appointments, $item['hme_date'] ?? '');
    $item['appointment_days'] = $rows;
    $first = $rows[0] ?? null;
    $item['days_to_appointment'] = $first['days'] ?? null;
    $item['days_to_appointment_text'] = $first['days_text'] ?? '';
    return $item;
}

function mhm_format_date($d) {
    $d = trim((string)$d);
    if ($d === '' || $d === '0000-00-00') {
        return '-';
    }
    $ts = strtotime($d);
    return $ts ? date('d/m/Y', $ts) : $d;
}

function mhm_format_appt_time($t) {
    $t = trim((string)$t);
    if ($t === '' || $t === '00:00:00' || $t === '00:00' || $t === '0000') {
        return '';
    }
    if (preg_match('/^(\d{1,2}):(\d{2})(?::\d{2})?$/', $t, $m)) {
        return sprintf('%02d:%02d', (int)$m[1], (int)$m[2]);
    }
    if (preg_match('/^(\d{2})(\d{2})$/', $t, $m)) {
        return $m[1] . ':' . $m[2];
    }
    return $t;
}

function mhm_sql_in_list($hos, array $values) {
    $out = [];
    foreach ($values as $v) {
        $v = trim((string)$v);
        if ($v !== '') {
            $out[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
        }
    }
    return implode(',', array_values(array_unique($out)));
}

function mhm_hn_variants($hn) {
    $hn = trim((string)$hn);
    if ($hn === '') {
        return [];
    }
    $trim = ltrim($hn, '0');
    if ($trim === '') {
        $trim = '0';
    }
    return array_values(array_unique([$hn, $trim, str_pad($trim, 9, '0', STR_PAD_LEFT)]));
}

function mhm_drugs_match(array $hme, array $opd, $match_mode) {
    $ic_h = trim((string)($hme['icode'] ?? ''));
    $ic_o = trim((string)($opd['icode'] ?? ''));
    if ($ic_h !== '' && $ic_h === $ic_o) {
        return 'icode';
    }
    if ($match_mode !== 'icode_or_tmt') {
        return '';
    }
    $tmt_h = mhm_norm_name($hme['tmt_name'] ?? '');
    $tmt_o = mhm_norm_name($opd['tmt_name'] ?? '');
    if ($tmt_h !== '' && $tmt_h === $tmt_o) {
        return 'tmt';
    }
    return '';
}

function mhm_sql_hme_select_list() {
    $order_date = mhm_sql_order_date('o');
    $method_expr = di_sql_method_expr('o');
    $tmt_expr = hosxp_sql_tmt_drug_name('d', 'tm');
    return "
            o.hn, o.an, o.icode, o.qty, o.rxdate, o.rxtime, o.vstdate,
            IFNULL(o.order_no, '') AS order_no,
            $order_date AS hme_date,
            $method_expr AS method,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
            $tmt_expr AS tmt_name,
            CAST(IFNULL(d.unitprice, 0) AS DECIMAL(16,4)) AS unitprice,
            COALESCE(NULLIF(i.regdate, '0000-00-00'), $order_date) AS admit_date,
            CAST(CONVERT(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) USING utf8) AS CHAR) AS ptname,
            CAST(CONVERT(IFNULL(w.name, '') USING utf8) AS CHAR) AS ward_name
    ";
}

function mhm_sql_hme_from_core() {
    return "
        FROM opitemrece o
        INNER JOIN ipt i ON i.an = o.an
        INNER JOIN drugitems d ON d.icode = o.icode
        " . hosxp_sql_tmt_join('d', 'tm') . "
        " . di_sql_method_joins('o') . "
        LEFT JOIN patient p ON p.hn = o.hn
        LEFT JOIN ward w ON w.ward = i.ward
    ";
}

function mhm_query_rows($hos, $sql) {
    $q = @mysqli_query($hos, $sql);
    if (!$q) {
        return ['ok' => false, 'error' => mysqli_error($hos), 'rows' => []];
    }
    $rows = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $rows[] = $r;
    }
    return ['ok' => true, 'error' => '', 'rows' => $rows];
}

function mhm_hme_row_key(array $r) {
    return trim((string)($r['an'] ?? '')) . '|' . trim((string)($r['icode'] ?? '')) . '|'
        . trim((string)($r['hme_date'] ?? '')) . '|' . trim((string)($r['order_no'] ?? '')) . '|'
        . trim((string)($r['rxdate'] ?? '')) . '|' . trim((string)($r['rxtime'] ?? ''));
}

function mhm_fetch_hme_orders($hos, $start_date, $end_date, array $an_filter = [], array $hn_filter = []) {
    $start_esc = mysqli_real_escape_string($hos, $start_date);
    $end_esc = mysqli_real_escape_string($hos, $end_date);
    $vst_start = date('Y-m-d', strtotime($start_date . ' -2 days'));
    $vst_end = date('Y-m-d', strtotime($end_date . ' +2 days'));
    $vst_start_esc = mysqli_real_escape_string($hos, $vst_start);
    $vst_end_esc = mysqli_real_escape_string($hos, $vst_end);
    $an_sql = mhm_sql_in_list($hos, $an_filter);
    $an_clause = $an_sql !== '' ? "AND o.an IN ($an_sql)" : '';
    $hn_clause = '';
    if (!empty($hn_filter)) {
        if (function_exists('monitor_hn_sql_clause')) {
            $hn_clause = monitor_hn_sql_clause($hos, $hn_filter, 'o.hn');
        } else {
            $hn_vals = [];
            foreach ($hn_filter as $hn) {
                foreach (mhm_hn_variants($hn) as $v) {
                    $hn_vals[$v] = true;
                }
            }
            $hn_sql = mhm_sql_in_list($hos, array_keys($hn_vals));
            if ($hn_sql !== '') {
                $hn_clause = "AND o.hn IN ($hn_sql)";
            }
        }
    }
    $base_where = "
        o.an IS NOT NULL AND o.an <> '' AND o.an <> '0'
        AND o.qty > 0
        AND o.vstdate >= '$vst_start_esc'
        AND o.vstdate <= '$vst_end_esc'
        $an_clause
        $hn_clause
    ";
    $select = mhm_sql_hme_select_list();
    $from = mhm_sql_hme_from_core();
    $limit = ($an_sql !== '' || $hn_clause !== '') ? 8000 : 12000;

    $parts = [
        "SELECT $select $from WHERE $base_where AND o.item_type IN ('H','h') LIMIT $limit",
        "SELECT $select $from
            INNER JOIN ipt_order_no ion ON ion.order_no = o.order_no
            WHERE $base_where AND ion.order_type IN ('HME','hme') LIMIT $limit",
        "SELECT $select $from
            INNER JOIN opitemrece_home oh ON oh.opi_guid = o.hos_guid AND oh.opitemrece_home_type_id = 2
            WHERE $base_where LIMIT $limit",
    ];

    $merged = [];
    $errors = [];
    $any_ok = false;
    foreach ($parts as $sql) {
        $res = mhm_query_rows($hos, $sql);
        if (!empty($res['ok'])) {
            $any_ok = true;
            foreach ($res['rows'] as $r) {
                $d = substr(trim((string)($r['hme_date'] ?? '')), 0, 10);
                if ($d < $start_date || $d > $end_date) {
                    continue;
                }
                $merged[mhm_hme_row_key($r)] = $r;
            }
        } else {
            $errors[] = $res['error'] ?? '';
        }
    }

    if (!$any_ok) {
        $order_date = mhm_sql_order_date('o');
        $fallback = "SELECT $select $from
            " . mhm_sql_hme_joins('o') . "
            WHERE $base_where
              AND $order_date BETWEEN '$start_esc' AND '$end_esc'
              " . mhm_sql_hme_filter('o', 'ion', 'oh') . "
            LIMIT $limit";
        $res = mhm_query_rows($hos, $fallback);
        if (empty($res['ok'])) {
            return ['ok' => false, 'error' => $res['error'] ?: implode('; ', $errors), 'rows' => []];
        }
        return ['ok' => true, 'error' => '', 'rows' => $res['rows']];
    }

    return ['ok' => true, 'error' => '', 'rows' => array_values($merged)];
}

function mhm_fetch_opd_orders($hos, array $hn_list, $min_date, $max_date) {
    $keys = [];
    foreach ($hn_list as $hn) {
        foreach (mhm_hn_variants($hn) as $v) {
            $keys[$v] = true;
        }
    }
    $hn_list = array_keys($keys);
    if (empty($hn_list)) {
        return ['ok' => true, 'error' => '', 'rows' => []];
    }
    $min_esc = mysqli_real_escape_string($hos, $min_date);
    $max_esc = mysqli_real_escape_string($hos, $max_date);
    $order_date = mhm_sql_order_date('o');
    $method_expr = di_sql_method_expr('o');
    $tmt_expr = hosxp_sql_tmt_drug_name('d', 'tm');
    $rows = [];
    foreach (array_chunk($hn_list, 40) as $chunk) {
        $hn_sql = mhm_sql_in_list($hos, $chunk);
        if ($hn_sql === '') {
            continue;
        }
        $sql = "
            SELECT
                o.hn, o.vn, o.icode, o.qty, o.rxdate, o.vstdate,
                $order_date AS opd_date,
                $method_expr AS method,
                CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
                $tmt_expr AS tmt_name,
                CAST(IFNULL(d.unitprice, 0) AS DECIMAL(16,4)) AS unitprice
            FROM opitemrece o
            INNER JOIN drugitems d ON d.icode = o.icode
            " . hosxp_sql_tmt_join('d', 'tm') . "
            " . di_sql_method_joins('o') . "
            WHERE o.hn IN ($hn_sql)
              AND o.vn IS NOT NULL AND o.vn <> '' AND o.vn <> '0'
              AND (o.an IS NULL OR o.an = '' OR o.an = '0')
              AND o.qty > 0
              AND o.vstdate >= '$min_esc'
              AND o.vstdate <= '$max_esc'
            LIMIT 8000
        ";
        $res = mhm_query_rows($hos, $sql);
        if (empty($res['ok'])) {
            return ['ok' => false, 'error' => $res['error'] ?? 'unknown', 'rows' => []];
        }
        foreach ($res['rows'] as $r) {
            $rows[] = $r;
        }
    }
    return ['ok' => true, 'error' => '', 'rows' => $rows];
}

function mhm_index_opd_by_hn(array $opd_rows) {
    $by = [];
    foreach ($opd_rows as $row) {
        foreach (mhm_hn_variants($row['hn'] ?? '') as $hn) {
            $by[$hn][] = $row;
        }
    }
    return $by;
}

function mhm_fetch_next_appointments($hos, array $hn_list, $from_date, $vstdate_min = '', $vstdate_max = '', $limit = 20) {
    $keys = [];
    foreach ($hn_list as $hn) {
        foreach (mhm_hn_variants($hn) as $v) {
            $keys[$v] = true;
        }
    }
    $hn_list = array_keys($keys);
    if (empty($hn_list)) {
        return [];
    }
    $from_esc = mysqli_real_escape_string($hos, $from_date);
    $vstdate_min = substr(trim((string)$vstdate_min), 0, 10);
    $vstdate_max = substr(trim((string)$vstdate_max), 0, 10);
    if ($vstdate_min !== '' && $vstdate_max !== '' && $vstdate_min > $vstdate_max) {
        $tmp = $vstdate_min;
        $vstdate_min = $vstdate_max;
        $vstdate_max = $tmp;
    }
    if ($vstdate_min !== '' && $vstdate_max !== '') {
        $vmin = mysqli_real_escape_string($hos, $vstdate_min);
        $vmax = mysqli_real_escape_string($hos, $vstdate_max);
        $date_sql = "AND o.vstdate BETWEEN '$vmin' AND '$vmax' AND o.nextdate >= o.vstdate";
    } else {
        $date_sql = "AND o.nextdate >= '$from_esc'";
    }
    $map = [];
    foreach (array_chunk($hn_list, 40) as $chunk) {
        $hn_sql = mhm_sql_in_list($hos, $chunk);
        if ($hn_sql === '') {
            continue;
        }
        $sql = "
            SELECT
                o.hn, o.vstdate, o.nextdate, o.nexttime, o.clinic, o.doctor,
                CAST(CONVERT(IFNULL(c.name, '') USING utf8) AS CHAR) AS clinic_name,
                CAST(CONVERT(IFNULL(doc.name, '') USING utf8) AS CHAR) AS doctor_name
            FROM oapp o
            LEFT JOIN clinic c ON c.clinic = o.clinic
            LEFT JOIN doctor doc ON doc.code = o.doctor
            WHERE o.hn IN ($hn_sql)
              AND o.nextdate IS NOT NULL
              AND o.nextdate <> '0000-00-00'
              $date_sql
            ORDER BY o.hn ASC, o.nextdate ASC, o.nexttime ASC
        ";
        $res = mhm_query_rows($hos, $sql);
        if (empty($res['ok'])) {
            $sql = "
                SELECT
                    o.hn, o.vstdate, o.nextdate, o.nexttime, o.clinic, o.doctor,
                    CAST(CONVERT(IFNULL(c.name, '') USING utf8) AS CHAR) AS clinic_name,
                    '' AS doctor_name
                FROM oapp o
                LEFT JOIN clinic c ON c.clinic = o.clinic
                WHERE o.hn IN ($hn_sql)
                  AND o.nextdate IS NOT NULL
                  AND o.nextdate <> '0000-00-00'
                  $date_sql
                ORDER BY o.hn ASC, o.nextdate ASC, o.nexttime ASC
            ";
            $res = mhm_query_rows($hos, $sql);
        }
        if (empty($res['ok'])) {
            $sql = "
                SELECT o.hn, o.vstdate, o.nextdate, o.nexttime, o.clinic, '' AS doctor, '' AS clinic_name, '' AS doctor_name
                FROM oapp o
                WHERE o.hn IN ($hn_sql)
                  AND o.nextdate IS NOT NULL
                  AND o.nextdate <> '0000-00-00'
                  $date_sql
                ORDER BY o.hn ASC, o.nextdate ASC, o.nexttime ASC
            ";
            $res = mhm_query_rows($hos, $sql);
            if (empty($res['ok'])) {
                continue;
            }
        }
        foreach ($res['rows'] as $row) {
            $appt = [
                'vstdate' => substr(trim((string)($row['vstdate'] ?? '')), 0, 10),
                'nextdate' => substr(trim((string)($row['nextdate'] ?? '')), 0, 10),
                'nexttime' => trim((string)($row['nexttime'] ?? '')),
                'clinic' => trim((string)($row['clinic'] ?? '')),
                'clinic_name' => trim((string)($row['clinic_name'] ?? '')),
                'doctor' => trim((string)($row['doctor'] ?? '')),
                'doctor_name' => trim((string)($row['doctor_name'] ?? '')),
            ];
            if ($appt['nextdate'] === '' || $appt['nextdate'] === '0000-00-00') {
                continue;
            }
            $dedupe = $appt['vstdate'] . '|' . $appt['nextdate'] . '|' . mhm_format_appt_time($appt['nexttime'])
                . '|' . ($appt['clinic_name'] !== '' ? $appt['clinic_name'] : $appt['clinic']);
            foreach (mhm_hn_variants($row['hn'] ?? '') as $hv) {
                $prev = $map[$hv][$dedupe] ?? null;
                if (!$prev || ($appt['doctor_name'] !== '' && ($prev['doctor_name'] ?? '') === '')) {
                    $map[$hv][$dedupe] = $appt;
                }
            }
        }
    }
    foreach ($map as $hn => $list) {
        $arr = array_values($list);
        usort($arr, function ($a, $b) {
            $c = strcmp((string)$a['nextdate'], (string)$b['nextdate']);
            if ($c !== 0) {
                return $c;
            }
            return strcmp((string)($a['nexttime'] ?? ''), (string)($b['nexttime'] ?? ''));
        });
        $map[$hn] = array_slice($arr, 0, max(1, min(200, (int)$limit)));
    }
    return $map;
}

function mhm_lookup_appointment(array $map, $hn) {
    $raw = [];
    foreach (mhm_hn_variants($hn) as $hv) {
        if (!empty($map[$hv]) && is_array($map[$hv])) {
            $raw = $map[$hv];
            break;
        }
    }
    if (empty($raw)) {
        return mhm_empty_appointment_lookup();
    }
    if (isset($raw['nextdate'])) {
        $raw = [$raw];
    }
    $seen = [];
    $list = [];
    foreach ($raw as $a) {
        if (!is_array($a)) {
            continue;
        }
        $item = mhm_format_appointment_item($a);
        if ($item['date'] === '' || $item['date'] === '0000-00-00') {
            continue;
        }
        $k = ($item['vstdate'] ?? '') . '|' . $item['date'] . '|' . $item['time'] . '|' . $item['clinic'];
        if (isset($seen[$k])) {
            continue;
        }
        $seen[$k] = true;
        $list[] = $item;
    }
    usort($list, function ($a, $b) {
        $c = strcmp((string)$a['date'], (string)$b['date']);
        return $c !== 0 ? $c : strcmp((string)($a['time'] ?? ''), (string)($b['time'] ?? ''));
    });
    $first = $list[0] ?? null;
    return [
        'appointments' => $list,
        'next_appointment' => $first['date'] ?? '',
        'next_appointment_fmt' => $first['date_fmt'] ?? '',
        'next_appointment_time' => $first['time'] ?? '',
        'next_appointment_clinic' => $first['clinic'] ?? '',
        'next_appointment_doctor' => $first['doctor'] ?? '',
    ];
}

function mhm_build_alert(array $hme, array $opd, $match_type, array $cfg) {
    $admit = trim((string)($hme['admit_date'] ?? ''));
    $opd_date = trim((string)($opd['opd_date'] ?? $opd['rxdate'] ?? ''));
    $elapsed = mhm_days_between($opd_date, $admit);
    $coverage = mhm_coverage_days($opd['qty'] ?? 0, $opd['method'] ?? '');
    $remaining = ($coverage !== null && $elapsed !== null) ? $coverage - $elapsed : null;

    $min_rem = (int)$cfg['min_remaining_days'];
    if ($remaining !== null) {
        if ($remaining < $min_rem || $remaining < 0) {
            return null;
        }
        $level = $cfg['alert_level_remaining'];
        $remain_txt = $remaining . ' วัน';
    } else {
        return null;
    }

    $hme_name = trim((string)($hme['tmt_name'] ?? '')) ?: trim((string)($hme['drug_name'] ?? ''));
    $opd_name = trim((string)($opd['tmt_name'] ?? '')) ?: trim((string)($opd['drug_name'] ?? ''));
    $match_label = $match_type === 'icode' ? 'icode เดียวกัน' : 'TMT เดียวกัน';
    $prior_source = (($opd['source'] ?? '') === 'ipd_hme') ? 'ipd_hme' : 'opd';
    $prior_appt = substr(trim((string)($opd['prior_appt'] ?? '')), 0, 10);
    if ($prior_source === 'ipd_hme') {
        $msg = 'ยา HME ซ้ำกับ HME จาก IPD ครั้งก่อน (' . $match_label . ') — re-admit ก่อนวันนัด '
            . mhm_format_date($prior_appt) . ' — เหลือประมาณ ' . $remain_txt . ' ณ วัน admit';
    } else {
        $msg = 'ยา HME ซ้ำกับยา OPD ก่อน admit (' . $match_label . ') — เหลือประมาณ ' . $remain_txt
            . ' ณ วัน admit — เสี่ยงจ่ายซ้ำสิ้นเปลือง';
    }

    $ward = trim((string)($hme['ward_name'] ?? ''));

    return [
        'hn' => ltrim((string)($hme['hn'] ?? ''), '0') ?: (string)($hme['hn'] ?? ''),
        'hn_full' => (string)($hme['hn'] ?? ''),
        'an' => (string)($hme['an'] ?? ''),
        'ptname' => trim((string)($hme['ptname'] ?? '')),
        'ward_display' => $ward !== '' ? $ward : '-',
        'admit_date' => $admit,
        'admit_date_fmt' => mhm_format_date($admit),
        'hme_date' => trim((string)($hme['hme_date'] ?? '')),
        'hme_date_fmt' => mhm_format_date($hme['hme_date'] ?? ''),
        'hme_time' => trim((string)($hme['rxtime'] ?? '')),
        'hme_drug_name' => $hme_name,
        'hme_icode' => trim((string)($hme['icode'] ?? '')),
        'hme_qty' => $hme['qty'] ?? '',
        'hme_method' => trim(preg_replace('/\s+/u', ' ', (string)($hme['method'] ?? ''))),
        'opd_drug_name' => $opd_name,
        'opd_icode' => trim((string)($opd['icode'] ?? '')),
        'opd_qty' => $opd['qty'] ?? '',
        'opd_method' => trim(preg_replace('/\s+/u', ' ', (string)($opd['method'] ?? ''))),
        'opd_date' => $opd_date,
        'opd_date_fmt' => mhm_format_date($opd_date),
        'opd_vn' => trim((string)($opd['vn'] ?? '')),
        'prior_source' => $prior_source,
        'prior_an' => trim((string)($opd['an'] ?? '')),
        'prior_appt' => $prior_appt,
        'prior_appt_fmt' => $prior_appt !== '' ? mhm_format_date($prior_appt) : '',
        'match_type' => $match_type,
        'match_label' => $match_label,
        'coverage_days' => $coverage,
        'days_since_opd' => $elapsed,
        'remaining_days' => $remaining,
        'remaining_text' => $remain_txt,
        'alert_level' => $level,
        'alert_message' => $msg,
    ];
}

function mhm_find_best_opd_match(array $hme, array $opd_list, array $cfg) {
    $lookback = (int)$cfg['lookback_days'];
    $admit = trim((string)($hme['admit_date'] ?? ''));
    $exclude = array_flip($cfg['exclude_icodes'] ?? []);
    $best = null;
    $best_score = null;
    $best_date = '';
    foreach ($opd_list as $opd) {
        $opd_ic = trim((string)($opd['icode'] ?? ''));
        if ($opd_ic !== '' && isset($exclude[$opd_ic])) {
            continue;
        }
        if (!empty($cfg['exclude_prn']) && mhm_is_prn_method($opd['method'] ?? '')) {
            continue;
        }
        $opd_date = trim((string)($opd['opd_date'] ?? ''));
        if ($opd_date === '' || ($admit !== '' && $opd_date > $admit)) {
            continue;
        }
        $elapsed = mhm_days_between($opd_date, $admit);
        if ($elapsed === null || $elapsed > $lookback) {
            continue;
        }
        $match_type = mhm_drugs_match($hme, $opd, $cfg['match_mode']);
        if ($match_type === '') {
            continue;
        }
        $coverage = mhm_coverage_days($opd['qty'] ?? 0, $opd['method'] ?? '');
        $remaining = ($coverage !== null && $elapsed !== null) ? $coverage - $elapsed : null;
        $score = $remaining !== null ? (float)$remaining : -0.5;
        if ($best === null || $score > $best_score || ($score === $best_score && $opd_date > $best_date)) {
            $best_score = $score;
            $best_date = $opd_date;
            $best = [
                'opd' => $opd,
                'match_type' => $match_type,
                'elapsed' => $elapsed,
                'coverage' => $coverage,
                'remaining' => $remaining,
            ];
        }
    }
    return $best;
}

/**
 * นัดที่จองระหว่าง admit ครั้งก่อน กับ admit ครั้งนี้
 * คืน nextdate เมื่อ admit ใหม่เกิดก่อนวันนัดนั้น
 */
function mhm_readmit_appt_before(array $appointments, $prior_admit, $prior_hme_date, $current_admit) {
    $prior_admit = substr(trim((string)$prior_admit), 0, 10);
    $prior_hme_date = substr(trim((string)$prior_hme_date), 0, 10);
    $current_admit = substr(trim((string)$current_admit), 0, 10);
    if ($prior_hme_date === '' || $current_admit === '' || $current_admit <= $prior_hme_date) {
        return '';
    }
    $best = '';
    foreach ($appointments as $a) {
        if (!is_array($a)) {
            continue;
        }
        $vst = substr(trim((string)($a['vstdate'] ?? '')), 0, 10);
        $next = substr(trim((string)($a['date'] ?? $a['nextdate'] ?? '')), 0, 10);
        if ($vst === '' || $next === '' || $next === '0000-00-00') {
            continue;
        }
        if ($prior_admit !== '' && $vst < $prior_admit) {
            continue;
        }
        if ($vst >= $current_admit) {
            continue;
        }
        if ($next <= $prior_hme_date || $current_admit >= $next) {
            continue;
        }
        if ($best === '' || $next < $best) {
            $best = $next;
        }
    }
    return $best;
}

function mhm_find_best_prior_hme(array $hme, array $prior_list, array $appointments, array $cfg) {
    $lookback = (int)$cfg['lookback_days'];
    $admit = trim((string)($hme['admit_date'] ?? ''));
    $an = trim((string)($hme['an'] ?? ''));
    $exclude = array_flip($cfg['exclude_icodes'] ?? []);
    $best = null;
    $best_score = null;
    $best_date = '';
    foreach ($prior_list as $prior) {
        $prior_an = trim((string)($prior['an'] ?? ''));
        if ($prior_an === '' || $prior_an === $an) {
            continue;
        }
        $opd_ic = trim((string)($prior['icode'] ?? ''));
        if ($opd_ic !== '' && isset($exclude[$opd_ic])) {
            continue;
        }
        if (!empty($cfg['exclude_prn']) && mhm_is_prn_method($prior['method'] ?? '')) {
            continue;
        }
        $opd_date = trim((string)($prior['opd_date'] ?? ''));
        if ($opd_date === '' || ($admit !== '' && $opd_date >= $admit)) {
            continue;
        }
        $elapsed = mhm_days_between($opd_date, $admit);
        if ($elapsed === null || $elapsed > $lookback) {
            continue;
        }
        $appt = mhm_readmit_appt_before($appointments, $prior['prior_admit'] ?? '', $opd_date, $admit);
        if ($appt === '') {
            continue;
        }
        $match_type = mhm_drugs_match($hme, $prior, $cfg['match_mode']);
        if ($match_type === '') {
            continue;
        }
        $coverage = mhm_coverage_days($prior['qty'] ?? 0, $prior['method'] ?? '');
        $remaining = ($coverage !== null && $elapsed !== null) ? $coverage - $elapsed : null;
        $score = $remaining !== null ? (float)$remaining : -0.5;
        if ($best === null || $score > $best_score || ($score === $best_score && $opd_date > $best_date)) {
            $row = $prior;
            $row['source'] = 'ipd_hme';
            $row['prior_appt'] = $appt;
            $best_score = $score;
            $best_date = $opd_date;
            $best = [
                'opd' => $row,
                'match_type' => $match_type,
                'elapsed' => $elapsed,
                'coverage' => $coverage,
                'remaining' => $remaining,
            ];
        }
    }
    return $best;
}

function mhm_pick_better_match($a, $b) {
    if (!$a || empty($a['opd'])) {
        return $b;
    }
    if (!$b || empty($b['opd'])) {
        return $a;
    }
    $a_known = $a['remaining'] !== null;
    $b_known = $b['remaining'] !== null;
    if ($a_known !== $b_known) {
        return $b_known ? $b : $a;
    }
    $da = trim((string)($a['opd']['opd_date'] ?? ''));
    $db = trim((string)($b['opd']['opd_date'] ?? ''));
    if ($db !== $da) {
        return $db > $da ? $b : $a;
    }
    $sa = $a_known ? (float)$a['remaining'] : -0.5;
    $sb = $b_known ? (float)$b['remaining'] : -0.5;
    return $sb > $sa ? $b : $a;
}

function mhm_format_drug_item(array $hme, $match, array $cfg) {
    $hme_name = trim((string)($hme['tmt_name'] ?? '')) ?: trim((string)($hme['drug_name'] ?? ''));
    $item = [
        'hme_drug_name' => $hme_name,
        'hme_icode' => trim((string)($hme['icode'] ?? '')),
        'hme_qty' => $hme['qty'] ?? '',
        'hme_method' => trim(preg_replace('/\s+/u', ' ', (string)($hme['method'] ?? ''))),
        'hme_date' => trim((string)($hme['hme_date'] ?? '')),
        'hme_date_fmt' => mhm_format_date($hme['hme_date'] ?? ''),
        'hme_time' => trim((string)($hme['rxtime'] ?? '')),
        'prior_opd' => false,
        'alert_level' => '',
        'remaining_days' => null,
        'remaining_text' => '',
        'match_type' => '',
        'match_label' => '',
        'opd_drug_name' => '',
        'opd_icode' => '',
        'opd_qty' => '',
        'opd_method' => '',
        'opd_date' => '',
        'opd_date_fmt' => '',
        'opd_vn' => '',
        'prior_source' => '',
        'prior_an' => '',
        'prior_appt' => '',
        'prior_appt_fmt' => '',
        'coverage_days' => null,
        'days_since_opd' => null,
        'unitprice' => (float)($hme['unitprice'] ?? 0),
        'hme_coverage_days' => mhm_coverage_days($hme['qty'] ?? 0, $hme['method'] ?? ''),
    ];
    if (!$match || empty($match['opd'])) {
        return $item;
    }
    $opd = $match['opd'];
    $remaining = $match['remaining'];
    $min_rem = (int)$cfg['min_remaining_days'];
    $match_type = $match['match_type'] ?? '';
    $item['prior_opd'] = true;
    $item['match_type'] = $match_type;
    $item['match_label'] = $match_type === 'icode' ? 'icode เดียวกัน' : 'TMT เดียวกัน';
    $item['remaining_days'] = $remaining;
    $item['coverage_days'] = $match['coverage'];
    $item['days_since_opd'] = $match['elapsed'];
    $item['opd_drug_name'] = trim((string)($opd['tmt_name'] ?? '')) ?: trim((string)($opd['drug_name'] ?? ''));
    $item['opd_icode'] = trim((string)($opd['icode'] ?? ''));
    $item['opd_qty'] = $opd['qty'] ?? '';
    $item['opd_method'] = trim(preg_replace('/\s+/u', ' ', (string)($opd['method'] ?? '')));
    $item['opd_date'] = trim((string)($opd['opd_date'] ?? ''));
    $item['opd_date_fmt'] = mhm_format_date($item['opd_date']);
    $item['opd_vn'] = trim((string)($opd['vn'] ?? ''));
    $item['prior_source'] = (($opd['source'] ?? '') === 'ipd_hme') ? 'ipd_hme' : 'opd';
    $item['prior_an'] = trim((string)($opd['an'] ?? ''));
    $item['prior_appt'] = substr(trim((string)($opd['prior_appt'] ?? '')), 0, 10);
    $item['prior_appt_fmt'] = $item['prior_appt'] !== '' ? mhm_format_date($item['prior_appt']) : '';
    $item['opd_unitprice'] = (float)($opd['unitprice'] ?? $item['unitprice'] ?? 0);
    $item['remaining_qty'] = mhm_remaining_qty($item);
    $item['remaining_value'] = mhm_remaining_value($item);
    $item['remaining_qty_text'] = mhm_fmt_remaining_qty($item['remaining_qty']);
    if ($remaining !== null) {
        $item['remaining_text'] = $remaining . ' วัน';
        if ($item['remaining_qty_text'] !== '') {
            $item['remaining_text'] .= ' · ' . $item['remaining_qty_text'];
        }
        if ($item['remaining_value'] !== null) {
            $item['remaining_text'] .= ' · ' . number_format((float)$item['remaining_value'], 2) . ' บาท';
        }
        if ($remaining >= $min_rem) {
            $item['alert_level'] = $cfg['alert_level_remaining'];
        }
    } else {
        $item['remaining_text'] = 'ไม่ทราบ (คำนวณวิธีใช้ไม่ได้)';
        if (!empty($cfg['include_unknown_remaining'])) {
            $item['alert_level'] = $cfg['alert_level_unknown'];
        }
    }
    return $item;
}

/** จำนวนยาเดิมที่เหลือ ณ วันสั่งใหม่ (remaining_days × ปริมาณต่อวัน) */
function mhm_remaining_qty(array $item) {
    if (!isset($item['remaining_days']) || $item['remaining_days'] === null || $item['remaining_days'] === '') {
        return null;
    }
    $remain = (int)$item['remaining_days'];
    if ($remain < 0) {
        return null;
    }
    $method = (string)($item['opd_method'] ?? '');
    $daily = function_exists('di_parse_daily_dose') ? di_parse_daily_dose($method) : null;
    if ($daily !== null && $daily > 0) {
        return $remain * (float)$daily;
    }
    $coverage = $item['coverage_days'] ?? null;
    $qty = (float)($item['opd_qty'] ?? 0);
    if ($coverage !== null && $coverage !== '' && (float)$coverage > 0 && $qty > 0) {
        return $qty * ($remain / (float)$coverage);
    }
    return null;
}

/** ข้อความจำนวนยาที่เหลือ เช่น 24 เม็ด */
function mhm_fmt_remaining_qty($qty) {
    if ($qty === null || $qty === '') {
        return '';
    }
    $n = (float)$qty;
    if ($n < 0) {
        return '';
    }
    if (abs($n - round($n)) < 0.05) {
        return ((int)round($n)) . ' เม็ด';
    }
    $s = rtrim(rtrim(number_format($n, 2, '.', ''), '0'), '.');
    return $s . ' เม็ด';
}

/** มูลค่ายาคงเหลือ = จำนวนที่เหลือ × ราคาต่อหน่วยของยาเดิม */
function mhm_remaining_value(array $item) {
    $qty = array_key_exists('remaining_qty', $item) ? $item['remaining_qty'] : mhm_remaining_qty($item);
    $price = (float)($item['opd_unitprice'] ?? $item['unitprice'] ?? 0);
    if ($qty === null || $qty < 0 || $price <= 0) {
        return null;
    }
    return round((float)$qty * $price, 2);
}

/** มูลค่ายาคงเหลือรวมของทั้งใบสั่ง = ผลรวม (จำนวนที่เหลือ × ราคา) ของยาเดิมที่ยังนับว่าเหลือ */
function mhm_drugs_rx_remaining_value(array $drugs) {
    $sum = 0.0;
    $any = false;
    foreach ($drugs as $d) {
        if (empty($d['prior_opd']) || !empty($d['remaining_ignored'])) {
            continue;
        }
        $val = array_key_exists('remaining_value', $d) ? $d['remaining_value'] : mhm_remaining_value($d);
        if ($val === null) {
            continue;
        }
        $any = true;
        $sum += (float)$val;
    }
    return $any ? round($sum, 2) : null;
}

/** ทั้งใบสั่งมียาเดิมคงเหลือรวมต่ำกว่าเกณฑ์บาท — ตั้ง 0 = ไม่ตัด */
function mhm_drugs_rx_value_below_min(array $drugs, array $cfg) {
    $min = (float)($cfg['min_remaining_value'] ?? 0);
    if ($min <= 0) {
        return false;
    }
    $sum = mhm_drugs_rx_remaining_value($drugs);
    if ($sum === null) {
        return false;
    }
    return $sum < $min;
}

function mhm_prior_order_key(array $d) {
    if (empty($d['prior_opd'])) {
        return '';
    }
    $date = substr(trim((string)($d['opd_date'] ?? '')), 0, 10);
    if (($d['prior_source'] ?? '') === 'ipd_hme') {
        return 'hme|' . trim((string)($d['prior_an'] ?? '')) . '|' . $date;
    }
    $vn = trim((string)($d['opd_vn'] ?? ''));
    return 'opd|' . ($vn !== '' ? $vn : $date) . '|' . $date;
}

/**
 * ใบสั่งยาเดิมที่มูลค่าคงเหลือรวมต่ำกว่าเกณฑ์ จะไม่นับว่าเคยได้
 * คืนรายการยาที่ถูกตัด เพื่อไม่ให้ค้างใน alert
 */
function mhm_drop_low_value_prior_orders(array $drugs, array $cfg) {
    $min = (float)($cfg['unitprice_exception'] ?? 100);
    $dropped = [];
    if ($min <= 0) {
        return [$drugs, $dropped];
    }
    $groups = [];
    foreach ($drugs as $i => $d) {
        if (empty($d['prior_opd']) || !empty($d['remaining_ignored'])) {
            continue;
        }
        $key = mhm_prior_order_key($d);
        if ($key === '') {
            continue;
        }
        $groups[$key][] = $i;
    }
    foreach ($groups as $idxs) {
        $subset = [];
        foreach ($idxs as $i) {
            $subset[] = $drugs[$i];
        }
        $sum = mhm_drugs_rx_remaining_value($subset);
        if ($sum === null || $sum >= $min) {
            continue;
        }
        $note = 'มูลค่ายาเดิมที่เหลือของใบนี้ ' . number_format($sum, 2) . ' บาท ต่ำกว่าเกณฑ์';
        foreach ($idxs as $i) {
            $drugs[$i]['prior_opd'] = false;
            $drugs[$i]['alert_level'] = '';
            $drugs[$i]['remaining_ignored'] = 1;
            $drugs[$i]['order_value_hidden'] = 1;
            $prev = trim((string)($drugs[$i]['remaining_text'] ?? ''));
            $drugs[$i]['remaining_text'] = $prev !== '' ? ($prev . ' (' . $note . ')') : $note;
            $ic = trim((string)($drugs[$i]['hme_icode'] ?? ''));
            if ($ic !== '') {
                $dropped[$ic] = true;
            }
        }
    }
    return [$drugs, $dropped];
}

/** @deprecated ใช้ mhm_drop_low_value_prior_orders ระดับใบสั่งยาเดิม แทนการตัดรายการ */
function mhm_apply_low_remaining_value(array $item, array $cfg) {
    return $item;
}

/** ไม่ดึงรายการที่ยาเหลือ ณ admit ติดลบ หรือคำนวณประวัติ/วิธีใช้ไม่ได้ */
function mhm_skip_unusable_remaining(array $item) {
    if (empty($item['prior_opd'])) {
        return false;
    }
    if (!array_key_exists('remaining_days', $item) || $item['remaining_days'] === null || $item['remaining_days'] === '') {
        return true;
    }
    return (int)$item['remaining_days'] < 0;
}

/** จำนวนวันของใบยา HME: จาก qty÷วิธีใช้ ถ้าไม่ได้ใช้จำนวนวันถึงวันนัด */
function mhm_hme_supply_days(array $item) {
    if (isset($item['hme_coverage_days']) && $item['hme_coverage_days'] !== null && $item['hme_coverage_days'] !== '') {
        return (int)$item['hme_coverage_days'];
    }
    $appt = $item['days_to_appointment'] ?? null;
    if ($appt !== null && $appt !== '' && (int)$appt > 0) {
        return (int)$appt;
    }
    return null;
}

/** ยาเดิมเหลือ ณ admit น้อยกว่าเกณฑ์ — ไม่นับว่าเคยได้ก่อน admit */
function mhm_apply_low_remaining_line(array $item, array $cfg) {
    if (empty($cfg['hide_low_remaining']) || empty($item['prior_opd'])) {
        return $item;
    }
    $limit = max(0, (int)($cfg['hide_low_remaining_days'] ?? 20));
    if (!isset($item['remaining_days']) || $item['remaining_days'] === null || $item['remaining_days'] === '') {
        return $item;
    }
    $n = (int)$item['remaining_days'];
    if ($n >= $limit) {
        return $item;
    }
    $item['prior_opd'] = false;
    $item['alert_level'] = '';
    $item['remaining_ignored'] = 1;
    $item['remaining_text'] = $n . ' วัน';
    $qty_txt = mhm_fmt_remaining_qty($item['remaining_qty'] ?? mhm_remaining_qty($item));
    if ($qty_txt !== '') {
        $item['remaining_qty_text'] = $qty_txt;
        $item['remaining_text'] .= ' · ' . $qty_txt;
    }
    $item['remaining_text'] .= ' (น้อยกว่าเกณฑ์ ไม่นับ)';
    $item['match_type'] = '';
    $item['match_label'] = '';
    return $item;
}

/** สั่ง HME น้อยกว่าเกณฑ์วัน — ตัดรายการ */
function mhm_skip_short_hme(array $item, array $cfg) {
    if (empty($cfg['hide_short_hme'])) {
        return false;
    }
    $limit = max(0, (int)($cfg['hide_short_hme_days'] ?? 14));
    $days = mhm_hme_supply_days($item);
    if ($days === null) {
        return false;
    }
    return $days < $limit;
}

/** ตัดเคสเมื่อยาเดิมที่คำนวณเหลือ ณ admit ได้ เหลือน้อยกว่าเกณฑ์ทั้งหมด */
function mhm_drugs_all_remaining_low(array $drugs, array $cfg) {
    if (empty($cfg['hide_low_remaining'])) {
        return false;
    }
    $limit = max(0, (int)($cfg['hide_low_remaining_days'] ?? 20));
    $remain_vals = [];
    foreach ($drugs as $d) {
        if (!isset($d['remaining_days']) || $d['remaining_days'] === null || $d['remaining_days'] === '') {
            continue;
        }
        if (!empty($d['remaining_ignored'])) {
            continue;
        }
        $n = (int)$d['remaining_days'];
        $remain_vals[] = $n;
    }
    if (!$remain_vals) {
        return false;
    }
    foreach ($remain_vals as $n) {
        if ($n >= $limit) {
            return false;
        }
    }
    return true;
}

function mhm_empty_scan_result(array $meta) {
    return ['hard_alerts' => [], 'soft_alerts' => [], 'patients' => [], 'meta' => $meta];
}
function mhm_scan($con, $hos, $start_date, $end_date, array $an_filter = [], array $hn_filter = []) {
    $cfg = mhm_get_config($con);
    $t0 = microtime(true);
    $meta = [
        'start_date' => $start_date,
        'end_date' => $end_date,
        'lookback_days' => (int)$cfg['lookback_days'],
        'match_mode' => $cfg['match_mode'],
        'hme_orders' => 0,
        'opd_orders' => 0,
        'prior_hme_orders' => 0,
        'patients' => 0,
        'duplicate_count' => 0,
        'error' => '',
        'elapsed_ms' => 0,
        'hidden_low_remaining' => 0,
        'hidden_short_hme' => 0,
        'hide_low_remaining_days' => (int)$cfg['hide_low_remaining_days'],
        'hide_short_hme_days' => (int)$cfg['hide_short_hme_days'],
    ];
    if (empty($cfg['monitor_active'])) {
        $meta['error'] = 'Monitor ถูกปิดไว้ที่แท็บตั้งค่า';
        return mhm_empty_scan_result($meta);
    }

    $hme_res = mhm_fetch_hme_orders($hos, $start_date, $end_date, $an_filter, $hn_filter);
    if (empty($hme_res['ok'])) {
        $meta['error'] = 'SQL HME: ' . ($hme_res['error'] ?? 'unknown');
        return mhm_empty_scan_result($meta);
    }
    $hme_rows = $hme_res['rows'];
    $meta['hme_orders'] = count($hme_rows);
    if (empty($hme_rows)) {
        $meta['elapsed_ms'] = (int)round((microtime(true) - $t0) * 1000);
        return mhm_empty_scan_result($meta);
    }

    $hn_set = [];
    $hn_admit = [];
    foreach ($hme_rows as $h) {
        $ad = trim((string)($h['admit_date'] ?? ''));
        foreach (mhm_hn_variants($h['hn'] ?? '') as $hn) {
            $hn_set[$hn] = true;
            if ($ad !== '' && $ad !== '0000-00-00') {
                if (!isset($hn_admit[$hn])) {
                    $hn_admit[$hn] = ['min' => $ad, 'max' => $ad];
                } else {
                    if ($ad < $hn_admit[$hn]['min']) {
                        $hn_admit[$hn]['min'] = $ad;
                    }
                    if ($ad > $hn_admit[$hn]['max']) {
                        $hn_admit[$hn]['max'] = $ad;
                    }
                }
            }
        }
    }

    $lookback = (int)$cfg['lookback_days'];
    $opd_all = [];
    $prior_hme_all = [];
    $hn_keys = array_keys($hn_set);
    $recent_cut = date('Y-m-d', strtotime($start_date . ' -14 days'));
    $recent = [];
    $old = [];
    foreach ($hn_keys as $hn) {
        $min_ad = $hn_admit[$hn]['min'] ?? $start_date;
        if ($min_ad >= $recent_cut) {
            $recent[] = $hn;
        } else {
            $old[] = $hn;
        }
    }
    $hn_chunks = array_merge(array_chunk($recent, 40), array_chunk($old, 8));
    foreach ($hn_chunks as $chunk) {
        $admits = [];
        foreach ($chunk as $hn) {
            if (!empty($hn_admit[$hn]['min'])) {
                $admits[] = $hn_admit[$hn]['min'];
            }
            if (!empty($hn_admit[$hn]['max'])) {
                $admits[] = $hn_admit[$hn]['max'];
            }
        }
        $min_admit = $admits ? min($admits) : $start_date;
        $max_admit = $admits ? max($admits) : $end_date;
        $min_opd = date('Y-m-d', strtotime($min_admit . ' -' . $lookback . ' days'));
        $opd_res = mhm_fetch_opd_orders($hos, $chunk, $min_opd, $max_admit);
        if (empty($opd_res['ok'])) {
            $meta['error'] = 'SQL OPD: ' . ($opd_res['error'] ?? 'unknown');
            return mhm_empty_scan_result($meta);
        }
        foreach ($opd_res['rows'] as $row) {
            $opd_all[] = $row;
        }
        $prior_res = mhm_fetch_hme_orders($hos, $min_opd, $max_admit, [], $chunk);
        if (empty($prior_res['ok'])) {
            $meta['error'] = 'SQL HME IPD ครั้งก่อน: ' . ($prior_res['error'] ?? 'unknown');
            return mhm_empty_scan_result($meta);
        }
        foreach ($prior_res['rows'] as $row) {
            $prior_hme_all[] = [
                'hn' => $row['hn'] ?? '',
                'an' => $row['an'] ?? '',
                'vn' => '',
                'icode' => $row['icode'] ?? '',
                'qty' => $row['qty'] ?? '',
                'opd_date' => substr(trim((string)($row['hme_date'] ?? '')), 0, 10),
                'method' => $row['method'] ?? '',
                'drug_name' => $row['drug_name'] ?? '',
                'tmt_name' => $row['tmt_name'] ?? '',
                'unitprice' => $row['unitprice'] ?? 0,
                'source' => 'ipd_hme',
                'prior_admit' => substr(trim((string)($row['admit_date'] ?? '')), 0, 10),
            ];
        }
    }
    $opd_by_hn = mhm_index_opd_by_hn($opd_all);
    $prior_hme_by_hn = mhm_index_opd_by_hn($prior_hme_all);
    $meta['opd_orders'] = count($opd_all);
    $meta['prior_hme_orders'] = count($prior_hme_all);
    $appt_by_hn = mhm_fetch_next_appointments($hos, array_keys($hn_set), date('Y-m-d'));
    $admit_mins = [];
    $admit_maxs = [];
    foreach ($hn_admit as $span) {
        if (!empty($span['min'])) {
            $admit_mins[] = $span['min'];
        }
        if (!empty($span['max'])) {
            $admit_maxs[] = $span['max'];
        }
    }
    $hist_min = date('Y-m-d', strtotime(($admit_mins ? min($admit_mins) : $start_date) . ' -' . $lookback . ' days'));
    $hist_max = $admit_maxs ? max($admit_maxs) : $end_date;
    $appt_hist = mhm_fetch_next_appointments($hos, array_keys($hn_set), $hist_min, $hist_min, $hist_max, 80);

    $exclude = array_flip($cfg['exclude_icodes']);
    $best = [];
    $by_hn = [];
    $hidden_short = 0;

    foreach ($hme_rows as $hme) {
        $icode = trim((string)($hme['icode'] ?? ''));
        if ($icode !== '' && isset($exclude[$icode])) {
            continue;
        }
        $hn = trim((string)($hme['hn'] ?? ''));
        $an = trim((string)($hme['an'] ?? ''));
        $admit = trim((string)($hme['admit_date'] ?? ''));
        if ($hn === '' || $an === '') {
            continue;
        }
        $hn_disp = ltrim($hn, '0') ?: $hn;
        $opd_list = [];
        $prior_hme_list = [];
        foreach (mhm_hn_variants($hn) as $hv) {
            if (!$opd_list && !empty($opd_by_hn[$hv])) {
                $opd_list = $opd_by_hn[$hv];
            }
            if (!$prior_hme_list && !empty($prior_hme_by_hn[$hv])) {
                $prior_hme_list = $prior_hme_by_hn[$hv];
            }
        }
        $opd_match = $opd_list ? mhm_find_best_opd_match($hme, $opd_list, $cfg) : null;
        $appt_for_prior = mhm_lookup_appointment($appt_hist, $hn);
        $hme_match = $prior_hme_list
            ? mhm_find_best_prior_hme($hme, $prior_hme_list, $appt_for_prior['appointments'] ?? [], $cfg)
            : null;
        $match = mhm_pick_better_match($opd_match, $hme_match);
        $item = mhm_format_drug_item($hme, $match, $cfg);
        if (mhm_skip_unusable_remaining($item)) {
            continue;
        }

        if (!isset($by_hn[$hn_disp])) {
            $appt = mhm_lookup_appointment($appt_by_hn, $hn);
            $by_hn[$hn_disp] = [
                'hn' => $hn_disp,
                'hn_full' => $hn,
                'ptname' => trim((string)($hme['ptname'] ?? '')),
                'appointments' => $appt['appointments'],
                'next_appointment' => $appt['next_appointment'],
                'next_appointment_fmt' => $appt['next_appointment_fmt'],
                'next_appointment_time' => $appt['next_appointment_time'],
                'next_appointment_clinic' => $appt['next_appointment_clinic'],
                'next_appointment_doctor' => $appt['next_appointment_doctor'] ?? '',
                'admissions' => [],
            ];
        } elseif ($by_hn[$hn_disp]['ptname'] === '' && trim((string)($hme['ptname'] ?? '')) !== '') {
            $by_hn[$hn_disp]['ptname'] = trim((string)($hme['ptname'] ?? ''));
        }
        $item = mhm_attach_appt_days(
            $item,
            $by_hn[$hn_disp]['next_appointment'] ?? '',
            $by_hn[$hn_disp]['appointments'] ?? []
        );
        $item = mhm_apply_low_remaining_line($item, $cfg);
        if (mhm_skip_short_hme($item, $cfg)) {
            $hidden_short++;
            continue;
        }
        if (!isset($by_hn[$hn_disp]['admissions'][$an])) {
            $ward = trim((string)($hme['ward_name'] ?? ''));
            $by_hn[$hn_disp]['admissions'][$an] = [
                'an' => $an,
                'admit_date' => $admit,
                'admit_date_fmt' => mhm_format_date($admit),
                'ward_display' => $ward !== '' ? $ward : '-',
                'drugs' => [],
            ];
        }
        $drug_key = $icode !== '' ? $icode : ($item['hme_drug_name'] . '|' . $item['hme_date']);
        $prev = $by_hn[$hn_disp]['admissions'][$an]['drugs'][$drug_key] ?? null;
        if (!$prev || ($item['hme_date'] > ($prev['hme_date'] ?? ''))
            || (($item['hme_date'] === ($prev['hme_date'] ?? '')) && $item['prior_opd'] && empty($prev['prior_opd']))) {
            $by_hn[$hn_disp]['admissions'][$an]['drugs'][$drug_key] = $item;
        }

        if ($match && !empty($item['prior_opd'])) {
            $alert = mhm_build_alert($hme, $match['opd'], $match['match_type'], $cfg);
            if ($alert) {
                $akey = $an . '|' . $icode;
                $score = (int)($alert['remaining_days'] ?? -1);
                if (!isset($best[$akey]) || $score > (int)($best[$akey]['remaining_days'] ?? -1)) {
                    $best[$akey] = $alert;
                }
            }
        }
    }

    $patients = [];
    $prior_drug_total = 0;
    $hme_drug_total = 0;
    $hidden_ans = [];
    $hidden_n = 0;
    foreach ($by_hn as $hn_row) {
        $admissions = [];
        $prior = 0;
        $prior_opd_n = 0;
        $prior_hme_n = 0;
        $hard_n = 0;
        $soft_n = 0;
        $drug_n = 0;
        $ignored_only = 0;
        foreach ($hn_row['admissions'] as $adm) {
            $drugs = array_values(array_filter($adm['drugs'], function ($d) {
                return !mhm_skip_unusable_remaining($d);
            }));
            if (empty($drugs)) {
                continue;
            }
            list($drugs, $dropped_ic) = mhm_drop_low_value_prior_orders($drugs, $cfg);
            if ($dropped_ic) {
                $an_drop = trim((string)($adm['an'] ?? ''));
                foreach (array_keys($dropped_ic) as $ic_drop) {
                    unset($best[$an_drop . '|' . $ic_drop]);
                }
            }
            if (mhm_drugs_all_remaining_low($drugs, $cfg)) {
                $hidden_n++;
                $an_hide = trim((string)($adm['an'] ?? ''));
                if ($an_hide !== '') {
                    $hidden_ans[$an_hide] = true;
                }
                continue;
            }
            usort($drugs, function ($a, $b) {
                if (!empty($a['prior_opd']) !== !empty($b['prior_opd'])) {
                    return !empty($b['prior_opd']) ? 1 : -1;
                }
                return strcmp((string)($a['hme_drug_name'] ?? ''), (string)($b['hme_drug_name'] ?? ''));
            });
            $adm['drugs'] = $drugs;
            $adm['prior_count'] = 0;
            $adm['hard_count'] = 0;
            $adm['soft_count'] = 0;
            $adm_ignored = 0;
            foreach ($drugs as $d) {
                $drug_n++;
                if (!empty($d['remaining_ignored'])) {
                    $adm_ignored++;
                }
                if (!empty($d['prior_opd'])) {
                    $adm['prior_count']++;
                    $prior++;
                    if (($d['prior_source'] ?? '') === 'ipd_hme') {
                        $prior_hme_n++;
                    } else {
                        $prior_opd_n++;
                    }
                }
                if (($d['alert_level'] ?? '') === 'hard') {
                    $adm['hard_count']++;
                    $hard_n++;
                } elseif (($d['alert_level'] ?? '') === 'soft') {
                    $adm['soft_count']++;
                    $soft_n++;
                }
            }
            if ($adm['prior_count'] < 1 && $adm_ignored > 0) {
                $ignored_only++;
                $drug_n -= count($drugs);
                $an_hide = trim((string)($adm['an'] ?? ''));
                if ($an_hide !== '') {
                    $hidden_ans[$an_hide] = true;
                }
                continue;
            }
            $admissions[] = $adm;
        }
        usort($admissions, function ($a, $b) {
            return strcmp((string)($b['admit_date'] ?? ''), (string)($a['admit_date'] ?? ''));
        });
        $hidden_n += $ignored_only;
        if (empty($admissions) || $drug_n < 1 || $prior < 1) {
            continue;
        }
        $hme_drug_total += $drug_n;
        $prior_drug_total += $prior;
        $latest_hme = '';
        foreach ($admissions as $adm) {
            foreach ($adm['drugs'] as $d) {
                $hd = substr(trim((string)($d['hme_date'] ?? '')), 0, 10);
                if ($hd !== '' && $hd > $latest_hme) {
                    $latest_hme = $hd;
                }
            }
        }
        $appointments = mhm_future_appointments($hn_row['appointments'] ?? [], $latest_hme);
        $next = mhm_next_from_appointments($appointments);
        $days_appt = $next['next_appointment'] !== ''
            ? mhm_days_hme_to_appointment($latest_hme, $next['next_appointment'])
            : null;
        $patients[] = [
            'hn' => $hn_row['hn'],
            'hn_full' => $hn_row['hn_full'],
            'ptname' => $hn_row['ptname'],
            'appointments' => $appointments,
            'next_appointment' => $next['next_appointment'],
            'next_appointment_fmt' => $next['next_appointment_fmt'],
            'next_appointment_time' => $next['next_appointment_time'],
            'next_appointment_clinic' => $next['next_appointment_clinic'],
            'next_appointment_doctor' => $next['next_appointment_doctor'],
            'hme_latest_date' => $latest_hme,
            'days_to_appointment' => $days_appt,
            'days_to_appointment_text' => mhm_days_hme_to_appointment_text($days_appt),
            'admissions' => $admissions,
            'drug_count' => $drug_n,
            'prior_count' => $prior,
            'prior_opd_count' => $prior_opd_n,
            'prior_hme_count' => $prior_hme_n,
            'hard_count' => $hard_n,
            'soft_count' => $soft_n,
        ];
    }
    usort($patients, function ($a, $b) {
        if ((int)$b['prior_count'] !== (int)$a['prior_count']) {
            return (int)$b['prior_count'] - (int)$a['prior_count'];
        }
        return strnatcmp((string)$a['hn'], (string)$b['hn']);
    });

    $hard = [];
    $soft = [];
    foreach ($best as $alert) {
        $an_a = trim((string)($alert['an'] ?? ''));
        if ($an_a !== '' && isset($hidden_ans[$an_a])) {
            continue;
        }
        if (($alert['alert_level'] ?? '') === 'hard') {
            $hard[] = $alert;
        } else {
            $soft[] = $alert;
        }
    }

    $meta['patients'] = count($patients);
    $meta['duplicate_count'] = count($hard) + count($soft);
    $meta['prior_drug_count'] = $prior_drug_total;
    $meta['hme_drug_unique'] = $hme_drug_total;
    $meta['hidden_low_remaining'] = $hidden_n;
    $meta['hidden_short_hme'] = $hidden_short;
    $meta['elapsed_ms'] = (int)round((microtime(true) - $t0) * 1000);
    return ['hard_alerts' => $hard, 'soft_alerts' => $soft, 'patients' => $patients, 'meta' => $meta];
}
