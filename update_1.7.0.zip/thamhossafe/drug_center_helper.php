<?php
/**
 * API Drug Center helper
 * @see https://docs.google.com/document/d/1oJZ700FIOCNr8QcdvhCGPWfuLAre2q2s797VOE1Vp68/
 */

require_once __DIR__ . '/provider_oauth_helper.php';

function drug_center_config_loaded() {
    return provider_oauth_config_loaded();
}

function drug_center_base_url() {
    provider_oauth_config_loaded();
    $env = provider_oauth_env();
    if ($env === 'prd') {
        return 'https://api-healthcare.manageai.co.th/mai/drug-datacenter';
    }
    return 'https://uat-api-healthcare.manageai.co.th/mai/drug-datacenter';
}

function drug_center_api_key() {
    $key = trim((string)provider_oauth_cfg('drug_center_api_key'));
    if ($key === '' || strpos($key, 'your-') === 0) {
        return '';
    }
    return $key;
}

function drug_center_is_configured() {
    return drug_center_api_key() !== '';
}

function drug_center_request($method, $path, array $opts = []) {
    $api_key = drug_center_api_key();
    if ($api_key === '') {
        return ['ok' => false, 'status' => false, 'code' => 0, 'message' => 'ยังไม่ได้ตั้งค่า DRUG_CENTER_API_KEY', 'data' => null];
    }

    $method = strtoupper($method);
    $url = rtrim(drug_center_base_url(), '/') . '/' . ltrim($path, '/');
    if (!empty($opts['query']) && is_array($opts['query'])) {
        $url .= (strpos($url, '?') === false ? '?' : '&') . http_build_query($opts['query']);
    }

    $headers = [
        'Content-Type' => 'application/json',
        'apiKey' => $api_key,
    ];
    if (!empty($opts['headers']) && is_array($opts['headers'])) {
        $headers = array_merge($headers, $opts['headers']);
    }

    $body = null;
    if (isset($opts['json'])) {
        $body = json_encode($opts['json'], JSON_UNESCAPED_UNICODE);
    }

    $res = provider_oauth_http_request($method, $url, [
        'headers' => $headers,
        'body' => $body,
        'timeout' => (int)($opts['timeout'] ?? 45),
    ]);

    if (!$res['ok']) {
        return ['ok' => false, 'status' => false, 'code' => 0, 'message' => $res['error'] ?: 'request failed', 'data' => null];
    }

    $json = json_decode($res['body'], true);
    if (!is_array($json)) {
        return [
            'ok' => false,
            'status' => false,
            'code' => $res['http_code'],
            'message' => 'Drugs Center ตอบกลับไม่ใช่ JSON',
            'data' => null,
            'raw' => $res['body'],
        ];
    }

    $code = (int)($json['code'] ?? $res['http_code']);
    $status = !empty($json['status']);
    $ok = $status && $code >= 200 && $code < 300;
    return [
        'ok' => $ok,
        'status' => $status,
        'code' => $code,
        'message' => (string)($json['message'] ?? ''),
        'data' => $json['data'] ?? null,
        'raw' => $json,
    ];
}

function drug_center_resolve_moph_token($explicit = null) {
    if ($explicit !== null && trim((string)$explicit) !== '') {
        return trim((string)$explicit);
    }
    return provider_oauth_session_moph_token();
}

function drug_center_resolve_hcode($explicit = null) {
    if ($explicit !== null && trim((string)$explicit) !== '') {
        return trim((string)$explicit);
    }
    return provider_oauth_session_hcode();
}

function drug_center_search_drugs($keyword = '', $page = 1, $row = 10) {
    return drug_center_request('GET', '/api/v1/drugs', [
        'query' => [
            'page' => max(1, (int)$page),
            'row' => max(1, min(100, (int)$row)),
            'keyword' => $keyword,
        ],
    ]);
}

function drug_center_check_contrast(array $codes, $cid, $opts = []) {
    $token = drug_center_resolve_moph_token($opts['moph_access_token_idp'] ?? null);
    $body = [
        'code' => array_values(array_filter(array_map('strval', $codes))),
        'cid' => (string)$cid,
        'history_mode' => (string)($opts['history_mode'] ?? ''),
    ];
    $hcode = drug_center_resolve_hcode($opts['hcode'] ?? null);
    if ($hcode !== '') {
        $body['hcode'] = $hcode;
    }
    if ($token !== '') {
        $body['moph_access_token_idp'] = $token;
    }
    return drug_center_request('POST', '/api/v1/drug/contrast', [
        'json' => $body,
        'query' => [
            'page' => max(1, (int)($opts['page'] ?? 1)),
            'row' => max(1, min(100, (int)($opts['row'] ?? 50))),
        ],
    ]);
}

function drug_center_check_allergy(array $codes, $cid, $opts = []) {
    $token = drug_center_resolve_moph_token($opts['moph_access_token_idp'] ?? null);
    if ($token === '') {
        return ['ok' => false, 'status' => false, 'code' => 400, 'message' => 'moph_access_token_idp not found', 'data' => null];
    }
    $body = [
        'code' => array_values(array_filter(array_map('strval', $codes))),
        'cid' => (string)$cid,
        'moph_access_token_idp' => $token,
        'history_mode' => (string)($opts['history_mode'] ?? ''),
    ];
    $hcode = drug_center_resolve_hcode($opts['hcode'] ?? null);
    if ($hcode !== '') {
        $body['hcode'] = $hcode;
    }
    return drug_center_request('POST', '/api/v1/drug/allergy', [
        'json' => $body,
        'query' => [
            'page' => max(1, (int)($opts['page'] ?? 1)),
            'row' => max(1, min(100, (int)($opts['row'] ?? 50))),
        ],
    ]);
}

function drug_center_safety_check(array $codes, $cid, $opts = []) {
    $token = drug_center_resolve_moph_token($opts['moph_access_token_idp'] ?? null);
    if ($token === '') {
        return ['ok' => false, 'status' => false, 'code' => 400, 'message' => 'moph_access_token_idp not found', 'data' => null];
    }
    $body = [
        'code' => array_values(array_filter(array_map('strval', $codes))),
        'cid' => (string)$cid,
        'moph_access_token_idp' => $token,
        'history_mode' => (string)($opts['history_mode'] ?? ''),
    ];
    $hcode = drug_center_resolve_hcode($opts['hcode'] ?? null);
    if ($hcode !== '') {
        $body['hcode'] = $hcode;
    }
    return drug_center_request('POST', '/api/v1/drug/safety-check', [
        'json' => $body,
        'query' => [
            'page' => max(1, (int)($opts['page'] ?? 1)),
            'row' => max(1, min(100, (int)($opts['row'] ?? 50))),
        ],
    ]);
}

/** 5. Med Reconcile — ประวัติรับยาจาก PHR */
function drug_center_med_reconcile($cid, $opts = []) {
    $token = drug_center_resolve_moph_token($opts['moph_access_token_idp'] ?? null);
    if ($token === '') {
        return ['ok' => false, 'status' => false, 'code' => 400, 'message' => 'moph_access_token_idp not found — กรุณาเข้าสู่ระบบด้วย Provider ID', 'data' => null];
    }
    $cid = preg_replace('/\D+/', '', (string)$cid);
    if ($cid === '') {
        return ['ok' => false, 'status' => false, 'code' => 400, 'message' => 'cid not found', 'data' => null];
    }
    $body = [
        'cid' => $cid,
        'moph_access_token_idp' => $token,
        'history_mode' => (string)($opts['history_mode'] ?? ''),
    ];
    $hcode = drug_center_resolve_hcode($opts['hcode'] ?? null);
    if ($hcode !== '') {
        $body['hcode'] = $hcode;
    }
    return drug_center_request('POST', '/api/v1/med/reconcile', [
        'json' => $body,
        'query' => [
            'page' => max(1, (int)($opts['page'] ?? 1)),
            'row' => max(1, min(200, (int)($opts['row'] ?? 100))),
        ],
    ]);
}

/** 6. Check Drug All — contrast + allergy + med_reconcile ในครั้งเดียว */
function drug_center_check_all(array $codes, $cid, $opts = []) {
    $token = drug_center_resolve_moph_token($opts['moph_access_token_idp'] ?? null);
    if ($token === '') {
        return ['ok' => false, 'status' => false, 'code' => 400, 'message' => 'moph_access_token_idp not found — กรุณาเข้าสู่ระบบด้วย Provider ID', 'data' => null];
    }
    $cid = preg_replace('/\D+/', '', (string)$cid);
    if ($cid === '') {
        return ['ok' => false, 'status' => false, 'code' => 400, 'message' => 'cid not found', 'data' => null];
    }
    $codes = array_values(array_filter(array_map('strval', $codes)));
    if (empty($codes)) {
        return ['ok' => false, 'status' => false, 'code' => 400, 'message' => 'code not found', 'data' => null];
    }
    $hcode = drug_center_resolve_hcode($opts['hcode'] ?? null);
    if ($hcode === '') {
        return ['ok' => false, 'status' => false, 'code' => 400, 'message' => 'hcode not found — ไม่พบรหัส รพ. จาก Provider profile หรือที่ระบุ', 'data' => null];
    }
    $body = [
        'code' => $codes,
        'cid' => $cid,
        'hcode' => $hcode,
        'moph_access_token_idp' => $token,
        'history_mode' => (string)($opts['history_mode'] ?? ''),
        'med_reconcile_history' => (string)($opts['med_reconcile_history'] ?? '6M'),
    ];
    return drug_center_request('POST', '/api/v1/drug/check/all', [
        'json' => $body,
        'timeout' => (int)($opts['timeout'] ?? 60),
    ]);
}

/** ดึงรายการยาล่าสุดจาก HOSxP ตาม HN แล้วแปลงเป็น TPU */
function drug_center_recent_tpu_by_hn($hos, $hn, $days = 7) {
    $hn = trim((string)$hn);
    if (!$hos || $hn === '') {
        return ['cid' => '', 'codes' => [], 'items' => [], 'hn' => ''];
    }
    $patient = drug_center_find_patient_by_hn($hos, $hn);
    $cid = $patient['cid'] ?? '';
    $hn_found = $patient['hn'] ?? drug_center_canonical_hn($hn);
    $in = drug_center_hn_sql_in($hos, $hn_found !== '' ? $hn_found : $hn);
    if ($in === '') {
        return ['cid' => $cid, 'codes' => [], 'items' => [], 'hn' => $hn_found];
    }
    $days = max(1, min(90, (int)$days));
    $sql = "SELECT o.icode, CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
            TRIM(d.tpu_code_list) AS tpu_code, MAX(o.vstdate) AS last_date
        FROM opitemrece o
        INNER JOIN drugitems d ON d.icode = o.icode AND d.istatus = 'Y'
        WHERE o.hn IN ($in) AND o.qty > 0
          AND o.vstdate >= DATE_SUB(CURDATE(), INTERVAL $days DAY)
        GROUP BY o.icode, d.name, d.tpu_code_list
        ORDER BY last_date DESC
        LIMIT 80";
    $q = @mysqli_query($hos, $sql);
    $items = [];
    $codes = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $tpu = trim((string)($r['tpu_code'] ?? ''));
            $first = '';
            if ($tpu !== '') {
                $parts = preg_split('/\s*,\s*/', $tpu);
                $first = trim((string)($parts[0] ?? ''));
            }
            if ($first !== '') {
                $codes[$first] = true;
            }
            $items[] = [
                'icode' => trim((string)($r['icode'] ?? '')),
                'name' => trim((string)($r['drug_name'] ?? '')),
                'tpu_code' => $first,
                'last_date' => trim((string)($r['last_date'] ?? '')),
            ];
        }
    }
    return ['cid' => $cid, 'codes' => array_keys($codes), 'items' => $items, 'hn' => $hn_found];
}

/** ค่า config สำหรับ Med Reconcile: hcode ที่ดึงจาก HOSxP ท้องถิ่น */
function drug_center_cfg_get($con, $name, $default = '') {
    $name = mysqli_real_escape_string($con, $name);
    $q = @mysqli_query($con, "SELECT config_value FROM sys_config WHERE config_name = '$name' LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return (string)($r['config_value'] ?? $default);
    }
    return $default;
}

/** รูปแบบ HN ที่อาจเก็บใน HOSxP (มี/ไม่มี 0 นำหน้า) — จำกัดเฉพาะที่จำเป็นเพื่อไม่ให้ query ช้า */
function drug_center_hn_variants($hn) {
    $hn = trim((string)$hn);
    if ($hn === '') {
        return [];
    }
    $variants = [$hn];
    $digits = preg_replace('/\D+/', '', $hn);
    if ($digits === '') {
        return array_values(array_unique($variants));
    }
    $trimmed = ltrim($digits, '0');
    if ($trimmed === '') {
        $trimmed = '0';
    }
    $variants[] = $trimmed;
    $variants[] = str_pad($trimmed, 9, '0', STR_PAD_LEFT);
    return array_values(array_unique($variants));
}

/** HN มาตรฐาน 9 หลัก (เติม 0 นำหน้า) สำหรับแสดงผล */
function drug_center_canonical_hn($hn) {
    $hn = trim((string)$hn);
    if ($hn === '') {
        return '';
    }
    $digits = preg_replace('/\D+/', '', $hn);
    if ($digits === '') {
        return $hn;
    }
    $trimmed = ltrim($digits, '0');
    if ($trimmed === '') {
        $trimmed = '0';
    }
    return str_pad($trimmed, 9, '0', STR_PAD_LEFT);
}

function drug_center_hn_sql_in($hos, $hn) {
    $parts = [];
    foreach (drug_center_hn_variants($hn) as $v) {
        $parts[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    return implode(',', $parts);
}

/**
 * หา patient จาก HN (รองรับไม่ใส่ 0 นำหน้า)
 * @return array{hn:string,cid:string,ptname:string}|null
 */
function drug_center_find_patient_by_hn($hos, $hn) {
    $hn = trim((string)$hn);
    if (!$hos || $hn === '') {
        return null;
    }
    $in = drug_center_hn_sql_in($hos, $hn);
    if ($in === '') {
        return null;
    }
    $sql = "SELECT hn, cid,
            CAST(CONVERT(CONCAT(IFNULL(pname,''), IFNULL(fname,''), ' ', IFNULL(lname,'')) USING utf8) AS CHAR) AS ptname
        FROM patient
        WHERE hn IN ($in)
        LIMIT 1";
    $q = @mysqli_query($hos, $sql);
    if (!$q || !($r = mysqli_fetch_assoc($q))) {
        return null;
    }
    $found_hn = trim((string)($r['hn'] ?? ''));
    return [
        'hn' => $found_hn !== '' ? $found_hn : drug_center_canonical_hn($hn),
        'cid' => preg_replace('/\D+/', '', (string)($r['cid'] ?? '')),
        'ptname' => trim((string)($r['ptname'] ?? '')),
    ];
}

/** มาตรฐานรหัสสถานพยาบาล (ตัดตัวอักษร / leading zero เช่น EA0010699 → 10699) */
function drug_center_normalize_hcode($code) {
    $digits = preg_replace('/\D+/', '', (string)$code);
    if ($digits === '') {
        return '';
    }
    $trimmed = ltrim($digits, '0');
    return $trimmed === '' ? '0' : $trimmed;
}

function drug_center_local_hcodes($con) {
    $raw = drug_center_cfg_get($con, 'dc_local_hcodes', '10699');
    $parts = preg_split('/[\s,;]+/', trim($raw));
    $codes = [];
    foreach ($parts as $p) {
        $p = drug_center_normalize_hcode($p);
        if ($p !== '') {
            // ใช้ prefix กัน PHP แปลง numeric string key เป็น int
            $codes['c' . $p] = $p;
        }
    }
    return array_values($codes);
}

function drug_center_local_hname($con) {
    $name = trim(drug_center_cfg_get($con, 'dc_local_hname', ''));
    return $name;
}

/**
 * แผนที่รหัสสถานพยาบาล → ชื่อ
 * รูปแบบใน sys_config `dc_hospital_name_map`:
 * 10699=โรงพยาบาลตัวอย่าง
 * 28849=รพ.สต.ตัวอย่าง
 * หรือ JSON {"10699":"..."}
 */
function drug_center_hospital_name_map($con) {
    $raw = trim(drug_center_cfg_get($con, 'dc_hospital_name_map', ''));
    $map = [];
    if ($raw === '') {
        return $map;
    }
    if ($raw[0] === '{') {
        $json = json_decode($raw, true);
        if (is_array($json)) {
            foreach ($json as $k => $v) {
                $code = drug_center_normalize_hcode($k);
                $name = trim((string)$v);
                if ($code !== '' && $name !== '') {
                    $map[$code] = $name;
                }
            }
            return $map;
        }
    }
    foreach (preg_split('/\r\n|\r|\n/', $raw) as $line) {
        $line = trim($line);
        if ($line === '' || strpos($line, '=') === false) {
            continue;
        }
        list($code, $name) = array_map('trim', explode('=', $line, 2));
        $code = drug_center_normalize_hcode($code);
        if ($code !== '' && $name !== '') {
            $map[$code] = $name;
        }
    }
    return $map;
}

/**
 * ดึงชื่อสถานพยาบาลจากตาราง hospcode ของ HOSxP
 * @return array<string,string> code => name
 */
function drug_center_lookup_hospcode_names($hos, array $codes) {
    static $cache = [];
    $out = [];
    $need = [];
    foreach ($codes as $c) {
        $code = drug_center_normalize_hcode($c);
        if ($code === '') {
            continue;
        }
        if (isset($cache[$code])) {
            if ($cache[$code] !== '') {
                $out[$code] = $cache[$code];
            }
            continue;
        }
        $need[$code] = true;
    }
    if (!$hos || empty($need)) {
        return $out;
    }
    $variants = [];
    foreach (array_keys($need) as $code) {
        $variants[$code] = true;
        $variants[str_pad($code, 5, '0', STR_PAD_LEFT)] = true;
    }
    $esc = [];
    foreach (array_keys($variants) as $v) {
        $esc[] = "'" . mysqli_real_escape_string($hos, $v) . "'";
    }
    $in = implode(',', $esc);
    $sql = "SELECT hospcode, hospcode_5_digit,
            CAST(CONVERT(name USING utf8) AS CHAR) AS name
        FROM hospcode
        WHERE hospcode IN ($in) OR hospcode_5_digit IN ($in)
        LIMIT 500";
    $q = @mysqli_query($hos, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $name = trim((string)($r['name'] ?? ''));
            if ($name === '') {
                continue;
            }
            foreach ([$r['hospcode'] ?? '', $r['hospcode_5_digit'] ?? ''] as $raw) {
                $n = drug_center_normalize_hcode($raw);
                if ($n !== '' && isset($need[$n])) {
                    $cache[$n] = $name;
                    $out[$n] = $name;
                }
            }
        }
    }
    foreach (array_keys($need) as $code) {
        if (!isset($cache[$code])) {
            $cache[$code] = '';
        }
    }
    return $out;
}

function drug_center_hospital_display_name($con, $code, array $extra_map = []) {
    $code = drug_center_normalize_hcode($code);
    if ($code === '') {
        return '';
    }
    $local_codes = drug_center_local_hcodes($con);
    $local_name = drug_center_local_hname($con);
    if (in_array($code, $local_codes, true) && $local_name !== '') {
        return $local_name;
    }
    if (isset($extra_map[$code]) && trim((string)$extra_map[$code]) !== '') {
        return trim((string)$extra_map[$code]);
    }
    $map = drug_center_hospital_name_map($con);
    if (isset($map[$code])) {
        return $map[$code];
    }
    if (in_array($code, $local_codes, true)) {
        return 'โรงพยาบาลนี้ (HOSxP)';
    }
    return '';
}

/**
 * แปลงวันที่/เวลาจาก Med Reconcile PHR
 * รองรับ d/m/Y (พ.ศ./ค.ศ.), Y-m-d, datetime — ตัดค่า placeholder เช่น 0001-01-01 (ที่เคยแสดงเป็น 01/01/544)
 *
 * @return array{ok:bool,iso:string,display:string,time:string,time_display:string,raw:string}
 */
function drug_center_parse_med_datetime($date_raw, $time_raw = '') {
    $date_raw = trim((string)$date_raw);
    $time_raw = trim((string)$time_raw);
    $empty = [
        'ok' => false,
        'iso' => '',
        'display' => 'ไม่ระบุวันที่',
        'time' => '',
        'time_display' => '',
        'raw' => $date_raw,
    ];
    if ($date_raw === '' || preg_match('/^0{2,4}-0{1,2}-0{1,2}/', $date_raw) || stripos($date_raw, '0001-01-01') !== false) {
        return $empty;
    }

    $y = 0;
    $mo = 0;
    $d = 0;
    $hh = '';
    $mm = '';
    $ss = '00';

    // ดึงเวลาจากฟิลด์ date ถ้ามี เช่น 2026-05-12T14:30:00 / 12/05/2569 14:30
    if (preg_match('/(?:T|\s+)(\d{1,2}):(\d{2})(?::(\d{2}))?/', $date_raw, $tm)) {
        $hh = sprintf('%02d', (int)$tm[1]);
        $mm = sprintf('%02d', (int)$tm[2]);
        $ss = isset($tm[3]) ? sprintf('%02d', (int)$tm[3]) : '00';
    }
    if ($time_raw !== '' && preg_match('/(\d{1,2}):(\d{2})(?::(\d{2}))?/', $time_raw, $tm2)) {
        $hh = sprintf('%02d', (int)$tm2[1]);
        $mm = sprintf('%02d', (int)$tm2[2]);
        $ss = isset($tm2[3]) ? sprintf('%02d', (int)$tm2[3]) : '00';
    }

    if (preg_match('/(\d{4})-(\d{1,2})-(\d{1,2})/', $date_raw, $m)) {
        $y = (int)$m[1];
        $mo = (int)$m[2];
        $d = (int)$m[3];
    } elseif (preg_match('/(\d{1,2})\/(\d{1,2})\/(\d{4})/', $date_raw, $m)) {
        $d = (int)$m[1];
        $mo = (int)$m[2];
        $y = (int)$m[3];
    } else {
        return $empty;
    }

    // ปี พ.ศ. ในฟิลด์ ISO/d-m-Y
    if ($y >= 2400) {
        $y -= 543;
    }
    // placeholder / ปีเพี้ยน (เช่น ค.ศ. 1 → แสดงเป็น พ.ศ. 544)
    $maxY = (int)date('Y') + 1;
    if ($y < 1990 || $y > $maxY || $mo < 1 || $mo > 12 || $d < 1 || $d > 31) {
        return $empty;
    }
    if (!checkdate($mo, $d, $y)) {
        return $empty;
    }

    $iso = sprintf('%04d-%02d-%02d', $y, $mo, $d);
    $be = $y + 543;
    $display = sprintf('%02d/%02d/%d', $d, $mo, $be);
    $time = ($hh !== '' && $mm !== '') ? ($hh . ':' . $mm . ':' . $ss) : '';
    $time_display = ($hh !== '' && $mm !== '') ? ($hh . ':' . $mm) : '';

    return [
        'ok' => true,
        'iso' => $iso,
        'display' => $display,
        'time' => $time,
        'time_display' => $time_display,
        'raw' => $date_raw,
    ];
}

/** แปลงวันที่ Med Reconcile (d/m/Y หรือ Y-m-d) เป็นคีย์เรียง YYYY-MM-DD */
function drug_center_med_date_sort_key($date) {
    $p = drug_center_parse_med_datetime($date);
    return $p['ok'] ? $p['iso'] : '';
}

/** เรียงตามวันที่ใหม่→เก่า (วันเดียวกัน: HOSxP ก่อน PHR) */
function drug_center_sort_med_reconcile_rows(array &$rows) {
    usort($rows, function ($a, $b) {
        $da = drug_center_med_date_sort_key(is_array($a) ? ($a['date'] ?? '') : '');
        $db = drug_center_med_date_sort_key(is_array($b) ? ($b['date'] ?? '') : '');
        if ($da !== $db) {
            return strcmp($db, $da); // ใหม่ก่อน
        }
        $sa = (is_array($a) && (($a['source'] ?? '') === 'hosxp')) ? 0 : 1;
        $sb = (is_array($b) && (($b['source'] ?? '') === 'hosxp')) ? 0 : 1;
        if ($sa !== $sb) {
            return $sa - $sb;
        }
        $na = strtolower(trim((string)(is_array($a) ? ($a['code_text'] ?? '') : '')));
        $nb = strtolower(trim((string)(is_array($b) ? ($b['code_text'] ?? '') : '')));
        return strcmp($na, $nb);
    });
}

/**
 * ดึงรหัส TPU ตัวแรกจาก tpu_code_list (รูปแบบเดียวกับ drug_refer / drugitems.tpu_code_list)
 */
function drug_center_extract_tpu_code($tpu_code_list) {
    $raw = trim((string)$tpu_code_list);
    if ($raw === '') {
        return '';
    }
    // คั่นด้วย comma / semicolon / ช่องว่าง
    $parts = preg_split('/\s*[,;]\s*|\s+/', $raw);
    foreach ($parts as $p) {
        $p = trim((string)$p);
        if ($p === '') {
            continue;
        }
        // คงรหัสตัวเลข (ตัดอักขระแปลก แต่ไม่ตัด leading zero ในรหัส TPU ถ้ามี)
        $digits = preg_replace('/\D+/', '', $p);
        if ($digits !== '') {
            return $digits;
        }
    }
    return '';
}

/** คีย์เทียบยา: ตัดซ้ำเฉพาะเมื่อ TPU ตรงกันในวันเดียวกัน */
function drug_center_med_dedupe_keys(array $row) {
    $keys = [];
    $tpu = drug_center_extract_tpu_code($row['tpu_code'] ?? $row['tpu_code_list'] ?? $row['code'] ?? '');
    $date_key = drug_center_med_date_sort_key($row['date'] ?? '');
    if ($tpu !== '' && $date_key !== '') {
        $keys[] = 'tpu:' . $tpu . '|d:' . $date_key;
    }
    return $keys;
}

function drug_center_history_mode_to_days($mode) {
    $mode = trim((string)$mode);
    if ($mode === '') {
        return 1;
    }
    if (preg_match('/^(\d+)\s*D$/i', $mode, $m)) {
        return max(1, (int)$m[1]);
    }
    if (preg_match('/^(\d+)\s*M$/i', $mode, $m)) {
        return max(1, (int)$m[1] * 30);
    }
    if (preg_match('/^(\d+)\s*Y$/i', $mode, $m)) {
        return max(1, (int)$m[1] * 365);
    }
    // เช่น 2Y8M11D — รวมแบบหยาบ
    $days = 0;
    if (preg_match_all('/(\d+)\s*([YMD])/i', $mode, $mm, PREG_SET_ORDER)) {
        foreach ($mm as $part) {
            $n = (int)$part[1];
            $u = strtoupper($part[2]);
            if ($u === 'Y') {
                $days += $n * 365;
            } elseif ($u === 'M') {
                $days += $n * 30;
            } else {
                $days += $n;
            }
        }
    }
    return max(1, $days ?: 30);
}

/** ดึงชื่อ รพ. จาก HOSxP (ถ้ามีตาราง hospital / opdconfig) */
function drug_center_fetch_hosxp_hospital_meta($hos) {
    if (!$hos) {
        return ['hcode' => '', 'hname' => ''];
    }
    $queries = [
        "SELECT TRIM(hospitalcode) AS hcode, CAST(CONVERT(hospitalname USING utf8) AS CHAR) AS hname FROM opdconfig LIMIT 1",
        "SELECT TRIM(hospitalcode) AS hcode, CAST(CONVERT(hospitalname USING utf8) AS CHAR) AS hname FROM hospital LIMIT 1",
    ];
    foreach ($queries as $sql) {
        $q = @mysqli_query($hos, $sql);
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            return [
                'hcode' => drug_center_normalize_hcode($r['hcode'] ?? ''),
                'hname' => trim((string)($r['hname'] ?? '')),
            ];
        }
    }
    return ['hcode' => '', 'hname' => ''];
}

/**
 * ดึงประวัติรับยาจาก HOSxP ให้อยู่รูปแบบเดียวกับ Med Reconcile API
 * ใช้ query แบบเดียวกับ Smart Drug (ไม่ join opi_dispense ที่ทำให้ช้า/หลุด)
 */
function drug_center_fetch_hosxp_med_rows($hos, $hn, $days, $organization_code, $organization_name) {
    $hn = trim((string)$hn);
    if (!$hos || $hn === '') {
        return [];
    }
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    if (function_exists('hosxp_extend_read_timeout')) {
        hosxp_extend_read_timeout($hos, 120);
    }
    $days = max(1, min(730, (int)$days));
    $hn_in = drug_center_hn_sql_in($hos, $hn);
    if ($hn_in === '') {
        $hn_esc = mysqli_real_escape_string($hos, $hn);
        $hn_in = "'" . $hn_esc . "'";
    }

    // ตาม drug_refer / Smart Drug — join TPU ตัวแรกจาก tpu_code_list
    $sql = "SELECT o.icode, o.qty, o.vstdate, o.an, o.vn,
            CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
            TRIM(d.tpu_code_list) AS tpu_code_list,
            CAST(CONVERT(
                COALESCE(
                    NULLIF(TRIM(CONCAT(IFNULL(tm.active_ingredient, ''), ' ', IFNULL(tm.strength, ''))), ''),
                    d.name
                ) USING utf8
            ) AS CHAR) AS drug_name_tmt,
            CAST(CONVERT(
                IF(o.sp_use <> '' AND o.sp_use IS NOT NULL,
                    CONCAT(IFNULL(sp.name1,''), ' ', IFNULL(sp.name2,''), ' ', IFNULL(sp.name3,'')),
                    CONCAT(IFNULL(du.name1,''), ' ', IFNULL(du.name2,''), ' ', IFNULL(du.name3,''))
                ) USING utf8
            ) AS CHAR) AS method
        FROM opitemrece o
        INNER JOIN drugitems d ON d.icode = o.icode
        LEFT JOIN tmt_tpu_code tm ON tm.tpu_code = SUBSTRING_INDEX(REPLACE(TRIM(d.tpu_code_list), ' ', ''), ',', 1)
        LEFT JOIN drugusage du ON du.drugusage = o.drugusage
        LEFT JOIN sp_use sp ON sp.sp_use = o.sp_use
        WHERE o.hn IN ($hn_in)
          AND o.qty > 0
          AND o.vstdate >= DATE_SUB(CURDATE(), INTERVAL $days DAY)
        ORDER BY o.vstdate DESC, o.vsttime DESC, o.item_no ASC
        LIMIT 500";
    $q = mysqli_query($hos, $sql);
    $rows = [];
    if (!$q) {
        // fallback แบบสั้นมาก ถ้า join TMT/วิธีใช้มีปัญหา
        $sql2 = "SELECT o.icode, o.qty, o.vstdate, o.an,
                CAST(CONVERT(d.name USING utf8) AS CHAR) AS drug_name,
                TRIM(d.tpu_code_list) AS tpu_code_list,
                '' AS drug_name_tmt,
                '' AS method
            FROM opitemrece o
            INNER JOIN drugitems d ON d.icode = o.icode
            WHERE o.hn IN ($hn_in)
              AND o.qty > 0
              AND o.vstdate >= DATE_SUB(CURDATE(), INTERVAL $days DAY)
            ORDER BY o.vstdate DESC, o.vsttime DESC, o.item_no ASC
            LIMIT 500";
        $q = mysqli_query($hos, $sql2);
        if (!$q) {
            return [];
        }
    }
    while ($r = mysqli_fetch_assoc($q)) {
        $tpu_list = trim((string)($r['tpu_code_list'] ?? ''));
        $tpu = drug_center_extract_tpu_code($tpu_list);
        $name = trim((string)($r['drug_name_tmt'] ?? ''));
        if ($name === '') {
            $name = trim((string)($r['drug_name'] ?? ''));
        }
        $vst = trim((string)($r['vstdate'] ?? ''));
        $date_fmt = $vst;
        if (preg_match('/^\d{4}-\d{2}-\d{2}/', $vst)) {
            $ts = strtotime($vst);
            if ($ts) {
                $date_fmt = date('d/m/Y', $ts);
            }
        }
        $method = trim(preg_replace('/\s+/u', ' ', (string)($r['method'] ?? '')));
        $is_ipd = trim((string)($r['an'] ?? '')) !== '';
        $rows[] = [
            'tpu_code' => $tpu,
            'tpu_code_list' => $tpu_list,
            'code_text' => $name,
            'qty' => is_numeric($r['qty'] ?? null) ? (0 + $r['qty']) : ($r['qty'] ?? ''),
            'date' => $date_fmt,
            'organization_code' => (string)$organization_code,
            'organization_name' => $organization_name,
            'patien_category' => $is_ipd ? 'Inpatient' : 'Outpatient',
            'instruction' => $method,
            'patient_instruction' => $method,
            'method' => $method,
            'usage_display' => $method !== '' ? $method : '-',
            'source' => 'hosxp',
            'icode' => trim((string)($r['icode'] ?? '')),
        ];
    }
    return $rows;
}

/**
 * เติมชื่อสถานพยาบาล + แทนที่รายการของ รพ.ตนเองด้วยข้อมูลจาก HOSxP
 * และตัดรายการ PHR ที่ซ้ำกับประวัติใน database รพ.
 */
function drug_center_enrich_med_reconcile_rows($con, $api_rows, array $opts = []) {
    if (!is_array($api_rows)) {
        $api_rows = [];
    }
    $local_codes = drug_center_local_hcodes($con);
    $local_name = drug_center_local_hname($con);
    $name_map = drug_center_hospital_name_map($con);
    $hn = trim((string)($opts['hn'] ?? ''));
    $cid = preg_replace('/\D+/', '', (string)($opts['cid'] ?? ''));
    $days = drug_center_history_mode_to_days($opts['history_mode'] ?? '1M');
    $hosxp_used = false;
    $hosxp_count = 0;
    $phr_dropped = 0;

    // รวบรวมรหัสสถานพยาบาลจาก PHR เพื่อ lookup ชื่อ
    $org_codes = [];
    foreach ($api_rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $c = drug_center_normalize_hcode($row['organization_code'] ?? '');
        if ($c !== '') {
            $org_codes[$c] = true;
        }
    }

    // auto-fill ชื่อ/รหัส รพ. จาก HOSxP ถ้ายังไม่ตั้ง
    $hos = null;
    if (function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
        $hos = hosxp_connect($con, 120);
    }
    if ($hos) {
        if (function_exists('hosxp_extend_read_timeout')) {
            hosxp_extend_read_timeout($hos, 120);
        }
        $meta = drug_center_fetch_hosxp_hospital_meta($hos);
        if ($local_name === '' && $meta['hname'] !== '') {
            $local_name = $meta['hname'];
        }
        if (empty($local_codes) && $meta['hcode'] !== '') {
            $local_codes = [$meta['hcode']];
        }
        // ถ้า config ว่าง ให้ default 10699 ตามที่ใช้งาน
        if (empty($local_codes)) {
            $local_codes = ['10699'];
        }
        if ($local_name === '') {
            $local_name = 'โรงพยาบาลนี้ (HOSxP)';
        }
        foreach ($local_codes as $lc) {
            $name_map[$lc] = $local_name;
            $org_codes[$lc] = true;
        }

        // หา HN จาก CID ถ้ายังไม่มี
        if ($hn === '' && $cid !== '') {
            $cid_esc = mysqli_real_escape_string($hos, $cid);
            $q = @mysqli_query($hos, "SELECT hn FROM patient WHERE REPLACE(cid,'-','') = '$cid_esc' LIMIT 1");
            if ($q && ($r = mysqli_fetch_assoc($q))) {
                $hn = trim((string)($r['hn'] ?? ''));
            }
        } elseif ($hn !== '') {
            $pt = drug_center_find_patient_by_hn($hos, $hn);
            if ($pt) {
                $hn = $pt['hn'];
                if ($cid === '' && !empty($pt['cid'])) {
                    $cid = $pt['cid'];
                }
            } else {
                $hn = drug_center_canonical_hn($hn);
            }
        }
    }

    $local_code_primary = $local_codes[0] ?? '10699';
    $hosxp_rows = [];
    // ต่อ HOSxP ใหม่ก่อนดึงยา (กัน connection หลุดจาก query ก่อนหน้า)
    if ($hn !== '' && function_exists('hosxp_connect')) {
        require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
        if ($hos) {
            @mysqli_close($hos);
            $hos = null;
        }
        $hos = hosxp_connect($con, 120);
        if ($hos && function_exists('hosxp_extend_read_timeout')) {
            hosxp_extend_read_timeout($hos, 120);
        }
        if ($hos) {
            $hosxp_rows = drug_center_fetch_hosxp_med_rows($hos, $hn, $days, $local_code_primary, $local_name);
            $hosxp_count = count($hosxp_rows);
            $hosxp_used = $hosxp_count > 0;
        }
    }

    // lookup ชื่อสถานพยาบาลอื่น (connection แยก ถ้า med query ใช้ไปแล้ว)
    if (!empty($org_codes)) {
        if (!$hos || !@mysqli_ping($hos)) {
            if ($hos) {
                @mysqli_close($hos);
            }
            $hos = function_exists('hosxp_connect') ? hosxp_connect($con, 60) : null;
        }
        if ($hos) {
            $looked = drug_center_lookup_hospcode_names($hos, array_keys($org_codes));
            foreach ($looked as $c => $n) {
                if (!isset($name_map[$c]) || trim((string)$name_map[$c]) === '') {
                    $name_map[$c] = $n;
                }
            }
        }
    }
    if ($hos) {
        mysqli_close($hos);
        $hos = null;
    }

    // คีย์ยาจาก HOSxP: ตัดซ้ำเฉพาะ TPU+วันเดียวกัน
    $hosxp_key_set = [];
    foreach ($hosxp_rows as $hr) {
        foreach (drug_center_med_dedupe_keys($hr) as $k) {
            $hosxp_key_set[$k] = true;
        }
    }

    $out = [];
    foreach ($api_rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $code = drug_center_normalize_hcode($row['organization_code'] ?? '');
        // ดึง TPU จาก PHR (code / tpu_code / tpu_code_list)
        $phr_tpu = drug_center_extract_tpu_code(
            $row['tpu_code'] ?? $row['tpu_code_list'] ?? $row['code'] ?? ''
        );
        if ($phr_tpu !== '') {
            $row['tpu_code'] = $phr_tpu;
        }

        // ตัด PHR เฉพาะเมื่อ TPU ซ้ำกับ HOSxP ในวันเดียวกัน
        // (วันเดียวกันแต่คนละ TPU → คงไว้ทั้งคู่)
        if ($hosxp_used) {
            $dup = false;
            foreach (drug_center_med_dedupe_keys($row) as $k) {
                if (isset($hosxp_key_set[$k])) {
                    $dup = true;
                    break;
                }
            }
            // ของ รพ.ตนเอง: ถ้าไม่มี TPU ให้ตัดออกเมื่อมี HOSxP แล้ว (กันรายการซ้ำที่เทียบ TPU ไม่ได้)
            if (!$dup && $code !== '' && in_array($code, $local_codes, true) && $phr_tpu === '') {
                $dup = true;
            }
            if ($dup) {
                $phr_dropped++;
                continue;
            }
        }
        $row['organization_code'] = $code;
        $disp = drug_center_hospital_display_name($con, $code, $name_map);
        if ($disp === '' && isset($name_map[$code])) {
            $disp = $name_map[$code];
        }
        if ($disp === '' && !empty($row['organization_name'])) {
            $api_name = trim((string)$row['organization_name']);
            // ไม่ใช้ชื่อที่เป็นแค่รหัสตัวเลขจาก API
            if ($api_name !== '' && !preg_match('/^(รหัส\s*)?\d+$/u', $api_name)) {
                $disp = $api_name;
            }
        }
        if ($disp === '' && $code !== '') {
            $disp = 'รหัส ' . $code;
        }
        $row['organization_name'] = $disp;
        if (empty($row['source'])) {
            $row['source'] = 'phr';
        }
        $usage = trim((string)($row['patient_instruction'] ?? $row['instruction'] ?? $row['method'] ?? ''));
        $row['method'] = $usage;
        $row['usage_display'] = $usage !== '' ? $usage : '-';
        $out[] = $row;
    }

    if ($hosxp_used) {
        $out = array_merge($hosxp_rows, $out);
    } else {
        // ไม่มีประวัติ HOSxP — ยังแสดงชื่อให้แถว local จาก API
        foreach ($out as &$row) {
            $code = drug_center_normalize_hcode($row['organization_code'] ?? '');
            if ($code !== '' && in_array($code, $local_codes, true)) {
                $row['organization_name'] = $local_name ?: drug_center_hospital_display_name($con, $code, $name_map);
            }
        }
        unset($row);
    }

    drug_center_sort_med_reconcile_rows($out);

    return [
        'rows' => $out,
        'hosxp_used' => $hosxp_used,
        'hosxp_count' => $hosxp_count,
        'phr_dropped' => $phr_dropped,
        'local_hcodes' => $local_codes,
        'local_hname' => $local_name,
        'hn' => $hn,
        'hospital_name_map' => $name_map,
    ];
}

/**
 * แปลง icode ของ HOSxP เป็น TPU code (tpu_code_list)
 */
function drug_center_map_icodes_to_tpu($hos, array $icodes) {
    $icodes = array_values(array_unique(array_filter(array_map(function ($c) {
        return trim((string)$c);
    }, $icodes))));
    if (!$hos || empty($icodes)) {
        return [];
    }
    $esc = [];
    foreach ($icodes as $c) {
        $esc[] = "'" . mysqli_real_escape_string($hos, $c) . "'";
    }
    $sql = "SELECT icode, TRIM(tpu_code_list) AS tpu_code
        FROM drugitems
        WHERE icode IN (" . implode(',', $esc) . ")
          AND tpu_code_list IS NOT NULL AND TRIM(tpu_code_list) <> ''";
    $q = mysqli_query($hos, $sql);
    $map = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $icode = trim((string)($r['icode'] ?? ''));
            $tpu = trim((string)($r['tpu_code'] ?? ''));
            // tpu_code_list อาจเป็นหลายรหัสคั่นด้วย comma
            if ($icode === '' || $tpu === '') {
                continue;
            }
            $parts = preg_split('/\s*,\s*/', $tpu);
            $first = trim((string)($parts[0] ?? ''));
            if ($first !== '') {
                $map[$icode] = $first;
            }
        }
    }
    return $map;
}

function drug_center_fetch_patient_cid($hos, $hn) {
    $pt = drug_center_find_patient_by_hn($hos, $hn);
    return $pt ? (string)($pt['cid'] ?? '') : '';
}

/**
 * แปลงผล Drugs Center เป็นรูปแบบ sp_result_* เพื่อรวมกับ Smart Pharma
 */
function drug_center_to_sp_alerts(array $api_result, $kind = 'safety') {
    if (empty($api_result['ok'])) {
        return null;
    }
    $rows = [];
    $data = $api_result['data'] ?? null;
    if (is_array($data)) {
        if (isset($data['data']) && is_array($data['data'])) {
            $rows = $data['data'];
        } elseif (array_keys($data) === range(0, count($data) - 1)) {
            $rows = $data;
        }
    }
    if (empty($rows)) {
        return ['status' => 'pass', 'level' => '', 'summary' => 'Drugs Center: ไม่พบความเสี่ยง', 'details' => [], 'items' => []];
    }

    $details = [];
    $items = [];
    $hard = false;
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $type = (int)($row['type_output'] ?? 0);
        $is_allergy = ($kind === 'allergy') || $type === 2 || !empty($row['allergy_substances']);
        if ($is_allergy) {
            $name = $row['input_tpu_name'] ?? $row['input_tp_name'] ?? 'ยา';
            $subs = $row['allergy_substances'] ?? [];
            $reaction = '';
            if (is_array($subs) && !empty($subs[0]['reaction'])) {
                $reaction = $subs[0]['reaction'];
            }
            $line = '[DC แพ้ยา] ' . $name . ($reaction !== '' ? (' — ' . $reaction) : '');
            $details[] = $line;
            $items[] = $row;
            $hard = true;
            continue;
        }
        $sev = strtolower(trim((string)($row['severity'] ?? '')));
        if (in_array($sev, ['contraindicated', 'major'], true)) {
            $hard = true;
        }
        $a = $row['input_tpu_name'] ?? $row['input_tpu_code'] ?? '';
        $b = $row['contrast_tpu_name'] ?? $row['contrast_tpu_code'] ?? '';
        $detail = $row['interaction_detail_th'] ?? $row['interaction_detail_en'] ?? '';
        $line = '[DC Interaction] ' . trim($a . ' × ' . $b);
        if ($detail !== '') {
            $line .= ' — ' . $detail;
        }
        if ($sev !== '') {
            $line .= ' (' . $sev . ')';
        }
        $details[] = $line;
        $items[] = $row;
    }

    if (empty($details)) {
        return ['status' => 'pass', 'level' => '', 'summary' => 'Drugs Center: ไม่พบความเสี่ยง', 'details' => [], 'items' => []];
    }

    return [
        'status' => 'alert',
        'level' => $hard ? 'hard' : 'soft',
        'summary' => implode('; ', array_slice($details, 0, 3)),
        'details' => $details,
        'items' => $items,
    ];
}

/**
 * รวมผล local + Drugs Center (alert ชนะ pass; hard ชนะ soft)
 */
function drug_center_merge_sp_result(array $local, array $remote = null) {
    if ($remote === null) {
        return $local;
    }
    if (($remote['status'] ?? '') !== 'alert') {
        // เติมหมายเหตุว่าเช็ค DC แล้วถ้า local เป็น pass/na
        if (($local['status'] ?? '') === 'pass' && ($remote['status'] ?? '') === 'pass') {
            $local['summary'] = trim(($local['summary'] ?? 'ผ่าน') . ' + Drugs Center');
        }
        return $local;
    }
    if (($local['status'] ?? '') !== 'alert') {
        return $remote;
    }
    $level = (($local['level'] ?? '') === 'hard' || ($remote['level'] ?? '') === 'hard') ? 'hard' : 'soft';
    $details = array_values(array_unique(array_merge($local['details'] ?? [], $remote['details'] ?? [])));
    $items = array_merge($local['items'] ?? [], $remote['items'] ?? []);
    return [
        'status' => 'alert',
        'level' => $level,
        'summary' => implode('; ', array_slice($details, 0, 3)),
        'details' => $details,
        'items' => $items,
    ];
}

/**
 * เรียก Drugs Center สำหรับผู้ป่วย 1 คน (ใช้ตอน screen รายคน)
 */
function drug_center_enrich_patient($hos, array $patient, array $icodes, $kind = 'safety') {
    static $cache = [];
    if (!drug_center_is_configured() || !provider_oauth_session_has_moph_token()) {
        return null;
    }
    $hn = trim((string)($patient['hn'] ?? ''));
    $cid = trim((string)($patient['cid'] ?? ''));
    if ($cid === '' && $hn !== '') {
        $cid = drug_center_fetch_patient_cid($hos, $hn);
    }
    if ($cid === '' || strlen($cid) < 13) {
        return null;
    }
    $tpu_map = drug_center_map_icodes_to_tpu($hos, $icodes);
    $codes = array_values(array_unique(array_filter($tpu_map)));
    if (empty($codes)) {
        return null;
    }

    $cache_key = $cid . '|' . $kind . '|' . md5(implode(',', $codes));
    if (isset($cache[$cache_key])) {
        return $cache[$cache_key];
    }

    if ($kind === 'allergy') {
        $api = drug_center_check_allergy($codes, $cid);
        $sp = drug_center_to_sp_alerts($api, 'allergy');
    } elseif ($kind === 'contrast') {
        $api = drug_center_check_contrast($codes, $cid);
        $sp = drug_center_to_sp_alerts($api, 'contrast');
    } else {
        $api = drug_center_safety_check($codes, $cid);
        $sp = drug_center_to_sp_alerts($api, 'safety');
    }
    $cache[$cache_key] = $sp;
    return $sp;
}

/**
 * แปลงแถว Med Reconcile (PHR/HOSxP enrich) → รูปแบบ history/visits ของ Smart Drug
 * @return array{history:array,visits:array}
 */
function drug_center_rows_to_smart_drug(array $rows) {
    $history = [];
    $visits_map = [];
    $n = 0;
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        // ข้าม source=hosxp ที่ enrich ใส่มาแล้ว (Smart Drug มีจาก local อยู่แล้ว)
        if (($row['source'] ?? '') === 'hosxp') {
            continue;
        }
        $date_raw = trim((string)(
            $row['date'] ?? $row['vstdate'] ?? $row['visit_date'] ?? $row['dispense_date'] ?? $row['service_date'] ?? ''
        ));
        $time_raw = trim((string)(
            $row['time'] ?? $row['vsttime'] ?? $row['visit_time'] ?? $row['dispense_time'] ?? $row['order_time'] ?? ''
        ));
        $dt = drug_center_parse_med_datetime($date_raw, $time_raw);
        // วันที่เพี้ยน/ว่าง: ยังแสดงยาได้ แต่ไม่ใช้ปีปลอม (เช่น 544) และเรียงท้ายสุด
        $iso = $dt['ok'] ? $dt['iso'] : '';
        $disp = $dt['display'];
        $time = $dt['time'];
        $time_disp = $dt['time_display'];
        $sort_date = $dt['ok'] ? $iso : '0000-00-00';

        $hcode = drug_center_normalize_hcode($row['organization_code'] ?? '');
        if ($hcode === '') {
            $hcode = 'dc';
        }
        $hname = trim((string)($row['organization_name'] ?? ''));
        if ($hname === '') {
            $hname = 'Drug Center · รหัส ' . $hcode;
        }
        $cat = strtolower((string)($row['patien_category'] ?? $row['patient_category'] ?? ''));
        $is_ipd = (strpos($cat, 'in') !== false);
        $visit_type = $is_ipd ? 'ipd' : 'opd';
        $vn = trim((string)($row['vn'] ?? $row['visit_no'] ?? $row['visit_number'] ?? $row['encounter_no'] ?? ''));
        $an = trim((string)($row['an'] ?? $row['admit_no'] ?? ''));
        if ($an === '' && $is_ipd) {
            $an = $iso !== '' ? ('DC-' . $iso) : '';
        }
        $visit_key = 'dc:' . $hcode . ':' . $visit_type . ':' . ($iso !== '' ? $iso : ('nodate-' . $hcode));
        $drug_name = trim((string)($row['code_text'] ?? $row['drug_name'] ?? $row['name'] ?? ''));
        if ($drug_name === '') {
            continue;
        }
        $method = trim((string)($row['patient_instruction'] ?? $row['instruction'] ?? $row['method'] ?? ''));
        $tpu = drug_center_extract_tpu_code($row['tpu_code'] ?? $row['tpu_code_list'] ?? $row['code'] ?? '');
        $icode = trim((string)($row['icode'] ?? ''));
        if ($icode === '' && $tpu !== '') {
            $icode = 'TPU:' . $tpu;
        }
        $n++;
        $hist = [
            'icode' => $icode !== '' ? $icode : ('DC' . $n),
            'drug_name' => $drug_name,
            'name' => $drug_name,
            'qty' => is_numeric($row['qty'] ?? null) ? (0 + $row['qty']) : ($row['qty'] ?? ''),
            'units' => trim((string)($row['units'] ?? '')),
            'method' => $method,
            'vn' => $vn,
            'an' => $an,
            'vstdate' => $iso,
            'vstdate_iso' => $iso,
            'vstdate_display' => $disp,
            'vsttime' => $time,
            'vsttime_display' => $time_disp,
            'order_date_iso' => $iso,
            'order_date_display' => $disp,
            'order_time_display' => $time_disp,
            'order_sort_key' => $sort_date . ' ' . ($time !== '' ? $time : '00:00:00'),
            'visit_key' => $visit_key,
            'visit_type' => $visit_type,
            'hospital_code' => 'dc:' . $hcode,
            'hospital_name' => $hname,
            'tpu_code' => $tpu,
            'is_hme' => false,
            'source_kind' => 'drug_center',
            'dc_source' => (string)($row['source'] ?? 'phr'),
            'date_unknown' => $dt['ok'] ? 0 : 1,
            'numeric_mg_value' => null,
        ];
        $history[] = $hist;
        if (!isset($visits_map[$visit_key])) {
            $visits_map[$visit_key] = [
                'visit_key' => $visit_key,
                'visit_type' => $visit_type,
                'vn' => $vn,
                'an' => $an,
                'vstdate_iso' => $iso,
                'vstdate_display' => $disp,
                'vsttime_display' => $time_disp,
                'drug_count' => 0,
                'ward_name' => '',
                'admit_date' => ($is_ipd && $iso !== '') ? $iso : '',
                'hospital_code' => 'dc:' . $hcode,
                'hospital_name' => $hname,
                'source_kind' => 'drug_center',
                'date_unknown' => $dt['ok'] ? 0 : 1,
            ];
        } else {
            if ($vn !== '' && trim((string)($visits_map[$visit_key]['vn'] ?? '')) === '') {
                $visits_map[$visit_key]['vn'] = $vn;
            }
            if ($time_disp !== '' && trim((string)($visits_map[$visit_key]['vsttime_display'] ?? '')) === '') {
                $visits_map[$visit_key]['vsttime_display'] = $time_disp;
            }
        }
        $visits_map[$visit_key]['drug_count']++;
    }
    return [
        'history' => $history,
        'visits' => array_values($visits_map),
    ];
}

/**
 * ดึงข้อความแพ้ยาจากผล Drugs Center allergy API
 * @return array{has_allergy:bool,text:string,agents:array}
 */
function drug_center_allergy_summary_from_api($api_result) {
    $agents = [];
    if (!is_array($api_result) || empty($api_result['ok'])) {
        return ['has_allergy' => false, 'text' => '', 'agents' => []];
    }
    $data = $api_result['data'] ?? null;
    $rows = [];
    if (is_array($data)) {
        if (isset($data['data']) && is_array($data['data'])) {
            $rows = $data['data'];
        } elseif (isset($data['allergy']) && is_array($data['allergy'])) {
            $rows = $data['allergy'];
        } else {
            $rows = $data;
        }
    }
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $name = trim((string)($row['drug_name'] ?? $row['name'] ?? $row['code_text'] ?? $row['substance'] ?? ''));
        $subs = $row['allergy_substances'] ?? [];
        if (is_array($subs) && $subs) {
            foreach ($subs as $s) {
                if (is_array($s)) {
                    $n = trim((string)($s['name'] ?? $s['substance'] ?? ''));
                } else {
                    $n = trim((string)$s);
                }
                if ($n !== '' && !in_array($n, $agents, true)) {
                    $agents[] = $n;
                }
            }
        }
        $reaction = trim((string)($row['reaction'] ?? $row['symptom'] ?? ''));
        if ($name !== '') {
            $label = $reaction !== '' ? ($name . ' (' . $reaction . ')') : $name;
            if (!in_array($label, $agents, true)) {
                $agents[] = $label;
            }
        }
    }
    $text = implode(', ', $agents);
    return [
        'has_allergy' => $text !== '',
        'text' => $text,
        'agents' => $agents,
    ];
}

/**
 * ชุดข้อมูล Drug Center สำหรับ Smart Drug: Med Reconcile + Allergy
 */
function drug_center_smart_drug_bundle($con, $hn, $cid = '', $history_mode = '6M') {
    require_once __DIR__ . '/hosxp_tmt_drug_helper.php';
    $oauth = provider_oauth_status_summary();
    if (empty($oauth['has_moph_token'])) {
        return [
            'ok' => false,
            'need_provider' => true,
            'message' => 'ยังไม่ได้เข้าสู่ระบบด้วย Provider ID หรือไม่มี moph token — ไม่สามารถเชื่อม Drug Center ได้',
            'history' => [],
            'visits' => [],
            'allergy' => ['has_allergy' => false, 'text' => '', 'agents' => []],
        ];
    }
    if (!drug_center_is_configured()) {
        return [
            'ok' => false,
            'need_provider' => false,
            'message' => 'ยังไม่ได้ตั้งค่า Drugs Center apiKey',
            'history' => [],
            'visits' => [],
            'allergy' => ['has_allergy' => false, 'text' => '', 'agents' => []],
        ];
    }

    $hn = trim((string)$hn);
    $cid = preg_replace('/\D+/', '', (string)$cid);
    $hos = hosxp_connect($con, 30);
    $codes = [];
    if ($hos) {
        if ($hn !== '') {
            $pt = drug_center_find_patient_by_hn($hos, $hn);
            if ($pt) {
                $hn = $pt['hn'];
                if ($cid === '' && !empty($pt['cid'])) {
                    $cid = $pt['cid'];
                }
            }
        }
        if ($cid === '' && $hn !== '') {
            $cid = drug_center_fetch_patient_cid($hos, $hn);
        }
        $recent = drug_center_recent_tpu_by_hn($hos, $hn !== '' ? $hn : ($cid ?: ''), 90);
        $codes = $recent['codes'] ?? [];
        if ($cid === '' && !empty($recent['cid'])) {
            $cid = $recent['cid'];
        }
        mysqli_close($hos);
    }
    if ($cid === '') {
        return [
            'ok' => false,
            'need_provider' => false,
            'message' => 'ไม่พบ CID สำหรับเรียก Drug Center',
            'history' => [],
            'visits' => [],
            'allergy' => ['has_allergy' => false, 'text' => '', 'agents' => []],
        ];
    }

    $opts = ['history_mode' => $history_mode ?: '6M', 'page' => 1, 'row' => 200];
    $res = drug_center_med_reconcile($cid, $opts);
    $api_rows = [];
    if (!empty($res['ok']) && is_array($res['data']) && isset($res['data']['data']) && is_array($res['data']['data'])) {
        $api_rows = $res['data']['data'];
    }
    $enriched = drug_center_enrich_med_reconcile_rows($con, $api_rows, [
        'hn' => $hn,
        'cid' => $cid,
        'history_mode' => $opts['history_mode'],
    ]);
    $mapped = drug_center_rows_to_smart_drug($enriched['rows'] ?? []);

    $allergy = ['has_allergy' => false, 'text' => '', 'agents' => []];
    if (!empty($codes)) {
        $al_api = drug_center_check_allergy(array_slice($codes, 0, 40), $cid, $opts);
        $allergy = drug_center_allergy_summary_from_api($al_api);
    }

    $ok = !empty($res['ok']) || !empty($mapped['history']);
    return [
        'ok' => $ok,
        'need_provider' => false,
        'message' => $ok
            ? ('Drug Center: ยา ' . count($mapped['history']) . ' รายการ · Visit ' . count($mapped['visits'])
                . (!empty($allergy['has_allergy']) ? ' · พบแพ้ยา' : ''))
            : ($res['message'] ?: 'ดึง Drug Center ไม่สำเร็จ'),
        'cid' => $cid,
        'hn' => $hn,
        'history' => $mapped['history'],
        'visits' => $mapped['visits'],
        'allergy' => $allergy,
        'hosxp_count' => $enriched['hosxp_count'] ?? 0,
        'phr_dropped' => $enriched['phr_dropped'] ?? 0,
    ];
}

function drug_center_status_banner_html() {
    $oauth = provider_oauth_status_summary();
    $dc_ok = drug_center_is_configured();
    $parts = [];
    $cls = 'alert-secondary';

    if (!$oauth['configured']) {
        $parts[] = 'ยังไม่ได้ตั้งค่า Health ID / Provider ID (`provider_oauth_config.php`)';
    } elseif (!$oauth['has_moph_token']) {
        $parts[] = 'ยังไม่มี moph token — เข้าสู่ระบบด้วย <strong>Provider ID</strong> เพื่อใช้ Drugs Center';
        $cls = 'alert-warning';
    } else {
        $parts[] = 'Provider ID พร้อมใช้ (env: ' . htmlspecialchars($oauth['env'], ENT_QUOTES, 'UTF-8') . ')';
        if ($oauth['hcode'] !== '') {
            $parts[] = 'hcode ' . htmlspecialchars($oauth['hcode'], ENT_QUOTES, 'UTF-8');
        }
        $cls = 'alert-success';
    }

    if (!$dc_ok) {
        $parts[] = 'ยังไม่ได้ตั้งค่า Drugs Center apiKey';
        if ($cls === 'alert-success') {
            $cls = 'alert-warning';
        }
    } else {
        $parts[] = 'Drugs Center apiKey พร้อม';
    }

    $text = implode(' · ', $parts);
    return '<div class="alert ' . $cls . ' py-2 px-3 small mb-3" id="drugCenterStatusBanner">'
        . '<i class="fas fa-cloud me-1"></i><strong>Drugs Center / Provider ID:</strong> ' . $text
        . ' <button type="button" class="btn btn-sm btn-outline-dark fw-bold ms-2" id="btnDcSearchTest">'
        . '<i class="fas fa-search me-1"></i>ทดสอบค้นหายา</button>'
        . '<div id="dcSearchTestResult" class="mt-2 d-none small"></div>'
        . '</div>';
}

function drug_center_status_banner_script() {
    return <<<'JS'
<script>
(function () {
    var btn = document.getElementById('btnDcSearchTest');
    var box = document.getElementById('dcSearchTestResult');
    if (!btn || !box) return;
    btn.addEventListener('click', function () {
        box.classList.remove('d-none');
        box.innerHTML = '<span class="text-muted">กำลังค้นหา paracetamol...</span>';
        fetch('fetch_drug_center_api.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'search', keyword: 'paracetamol', page: 1, row: 5})
        }).then(function (r) { return r.json(); }).then(function (j) {
            if (!j || j.status !== 'ok') {
                box.innerHTML = '<span class="text-danger">' + (j && j.message ? j.message : 'เรียก API ไม่สำเร็จ') + '</span>';
                return;
            }
            var rows = (j.data && j.data.data) ? j.data.data : [];
            if (!rows.length) {
                box.innerHTML = '<span class="text-success">เชื่อมต่อสำเร็จ แต่ไม่พบผลค้นหา</span>';
                return;
            }
            var html = '<span class="text-success">เชื่อมต่อสำเร็จ</span><ul class="mb-0 mt-1">';
            rows.slice(0, 5).forEach(function (row) {
                html += '<li>' + (row.tpu_code || '') + ' — ' + (row.tpu_name || row.gpu_name || '') + '</li>';
            });
            html += '</ul>';
            box.innerHTML = html;
        }).catch(function (e) {
            box.innerHTML = '<span class="text-danger">Error: ' + e + '</span>';
        });
    });
})();
</script>
JS;
}
