<?php
/**
 * Monitor Warfarin — เฝ้าระวังความเหมาะสมของการปรับขนาดยาตาม Guideline + INR
 */

require_once __DIR__ . '/warfarin_helper.php';
require_once __DIR__ . '/warfarin_guideline_helper.php';

function mwf_normalize_scope($scope) {
    $s = strtolower(trim((string)$scope));
    if ($s === 'opd' || $s === 'ipd') {
        return $s;
    }
    return 'all';
}

function mwf_scope_label($scope) {
    $scope = mwf_normalize_scope($scope);
    if ($scope === 'opd') {
        return 'OPD';
    }
    if ($scope === 'ipd') {
        return 'IPD';
    }
    return 'ทั้งหมด';
}

function mwf_ensure_config_columns($con) {
    $q = mysqli_query($con, "SHOW COLUMNS FROM monitor_warfarin_config LIKE 'monitor_scope'");
    if (!$q || mysqli_num_rows($q) === 0) {
        @mysqli_query($con, "ALTER TABLE monitor_warfarin_config
            ADD COLUMN monitor_scope VARCHAR(10) NOT NULL DEFAULT 'all'
            AFTER monitor_active");
    }
}

function mwf_ensure_tables($con) {
    $need = false;
    foreach (['monitor_warfarin_config', 'monitor_warfarin_alert_rules'] as $t) {
        $q = mysqli_query($con, "SHOW TABLES LIKE '" . mysqli_real_escape_string($con, $t) . "'");
        if (!$q || mysqli_num_rows($q) === 0) {
            $need = true;
            break;
        }
    }
    if (!$need) {
        mwf_ensure_config_columns($con);
        mwf_seed_defaults($con);
        return true;
    }
    $sql = @file_get_contents(__DIR__ . '/sql/monitor_warfarin.sql');
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt === '') {
            continue;
        }
        if (!mysqli_query($con, $stmt)) {
            // INSERT IGNORE may fail on re-run; continue
        }
    }
    mwf_ensure_config_columns($con);
    mwf_seed_defaults($con);
    return true;
}

function mwf_seed_defaults($con) {
    $q = mysqli_query($con, "SELECT id FROM monitor_warfarin_config WHERE id=1 LIMIT 1");
    if (!$q || mysqli_num_rows($q) === 0) {
        mysqli_query($con, "INSERT IGNORE INTO monitor_warfarin_config (id, default_protocol_id, inr_assess_max_days, monitor_active)
            VALUES (1, 'inr_2_3', 5, 1)");
    }
    $defaults = [
        ['mismatch', 'ไม่สอดคล้อง', 'hard', 'พบการปรับขนาด Warfarin ไม่สอดคล้องกับ Guideline ตาม INR', 1, 1],
        ['partial', 'ค่อนข้างเหมาะสม', 'soft', 'พบการปรับขนาด Warfarin ค่อนข้างเหมาะสม (ทิศทางถูกแต่ % นอกช่วง)', 0, 2],
        ['unknown', 'ประเมินไม่ได้', 'soft', 'พบการสั่ง Warfarin ที่ประเมินความเหมาะสมไม่ได้ (ไม่มี INR / ไม่มี guideline)', 0, 3],
    ];
    foreach ($defaults as $d) {
        $v = mysqli_real_escape_string($con, $d[0]);
        $chk = mysqli_query($con, "SELECT id FROM monitor_warfarin_alert_rules WHERE verdict='$v' LIMIT 1");
        if ($chk && mysqli_num_rows($chk) > 0) {
            continue;
        }
        $label = mysqli_real_escape_string($con, $d[1]);
        $lvl = mysqli_real_escape_string($con, $d[2]);
        $msg = mysqli_real_escape_string($con, $d[3]);
        $active = (int)$d[4];
        $sort = (int)$d[5];
        mysqli_query($con, "INSERT INTO monitor_warfarin_alert_rules
            (verdict, label_th, alert_level, alert_message, active, sort_order)
            VALUES ('$v', '$label', '$lvl', '$msg', $active, $sort)");
    }
}

function mwf_get_config($con) {
    mwf_ensure_tables($con);
    $row = [
        'default_protocol_id' => 'inr_2_3',
        'inr_assess_max_days' => 5,
        'monitor_active' => 1,
        'monitor_scope' => 'all',
    ];
    $q = mysqli_query($con, "SELECT * FROM monitor_warfarin_config WHERE id=1 LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $row['default_protocol_id'] = trim((string)($r['default_protocol_id'] ?? 'inr_2_3')) ?: 'inr_2_3';
        $row['inr_assess_max_days'] = max(0, min(30, (int)($r['inr_assess_max_days'] ?? 5)));
        $row['monitor_active'] = !empty($r['monitor_active']) ? 1 : 0;
        $row['monitor_scope'] = mwf_normalize_scope($r['monitor_scope'] ?? 'all');
    }
    return $row;
}

function mwf_save_config($con, array $data) {
    mwf_ensure_tables($con);
    $pid = mysqli_real_escape_string($con, trim((string)($data['default_protocol_id'] ?? 'inr_2_3')) ?: 'inr_2_3');
    $days = max(0, min(30, (int)($data['inr_assess_max_days'] ?? 5)));
    $active = !empty($data['monitor_active']) ? 1 : 0;
    $scope = mysqli_real_escape_string($con, mwf_normalize_scope($data['monitor_scope'] ?? 'all'));
    $sql = "INSERT INTO monitor_warfarin_config (id, default_protocol_id, inr_assess_max_days, monitor_active, monitor_scope)
        VALUES (1, '$pid', $days, $active, '$scope')
        ON DUPLICATE KEY UPDATE
            default_protocol_id=VALUES(default_protocol_id),
            inr_assess_max_days=VALUES(inr_assess_max_days),
            monitor_active=VALUES(monitor_active),
            monitor_scope=VALUES(monitor_scope)";
    return (bool)mysqli_query($con, $sql);
}

function mwf_load_alert_rules($con, $activeOnly = false) {
    mwf_ensure_tables($con);
    $sql = "SELECT * FROM monitor_warfarin_alert_rules ORDER BY sort_order ASC, id ASC";
    $q = mysqli_query($con, $sql);
    $out = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            if ($activeOnly && empty($r['active'])) {
                continue;
            }
            $out[] = $r;
        }
    }
    return $out;
}

function mwf_rules_by_verdict($con, $activeOnly = true) {
    $map = [];
    foreach (mwf_load_alert_rules($con, $activeOnly) as $r) {
        $v = trim((string)($r['verdict'] ?? ''));
        if ($v !== '') {
            $map[$v] = $r;
        }
    }
    return $map;
}

function mwf_alert_level($row) {
    return (($row['alert_level'] ?? '') === 'soft') ? 'soft' : 'hard';
}

function mwf_dashboard_bucket($verdict) {
    $v = trim((string)$verdict);
    if ($v === 'ok') {
        return 'ok';
    }
    if ($v === 'mismatch') {
        return 'mismatch';
    }
    return 'other';
}

function mwf_bucket_label($bucket) {
    if ($bucket === 'ok') {
        return 'เหมาะสม';
    }
    if ($bucket === 'mismatch') {
        return 'ไม่สอดคล้อง';
    }
    return 'อื่นๆ';
}

/**
 * แปลงรายการ HN จาก CSV / array (จำกัดจำนวนต่อคำขอ เพื่อไม่ให้เกิน timeout)
 * @param mixed $raw
 * @return string[]
 */
function mwf_parse_hn_list($raw, $max = 12) {
    $parts = is_array($raw) ? $raw : preg_split('/[\s,;]+/', (string)$raw, -1, PREG_SPLIT_NO_EMPTY);
    $hns = [];
    foreach ($parts as $hn) {
        $hn = preg_replace('/\s+/', '', (string)$hn);
        if ($hn === '' || !preg_match('/^[0-9A-Za-z\-]{1,20}$/', $hn)) {
            continue;
        }
        $hns[$hn] = $hn;
    }
    $hns = array_values($hns);
    $max = max(1, min(20, (int)$max));
    if (count($hns) > $max) {
        $hns = array_slice($hns, 0, $max);
    }
    return $hns;
}

/**
 * ราย HN ที่มีสั่ง Warfarin ในช่วงวันที่ (จาก opitemrece)
 * @param string $scope all|opd|ipd
 * @return string[]
 */
function mwf_fetch_warfarin_hns($hos, $startYmd, $endYmd, $limit = 300, $scope = 'all') {
    $startYmd = trim((string)$startYmd);
    $endYmd = trim((string)$endYmd);
    if ($startYmd === '' || $endYmd === '') {
        return [];
    }
    $scope = mwf_normalize_scope($scope);
    $limit = max(1, min(500, (int)$limit));
    $s = mysqli_real_escape_string($hos, $startYmd);
    $e = mysqli_real_escape_string($hos, $endYmd);

    $scopeSql = '';
    if ($scope === 'opd') {
        $scopeSql = " AND o.vn IS NOT NULL AND TRIM(o.vn) <> '' AND (o.an IS NULL OR TRIM(o.an) = '') ";
    } elseif ($scope === 'ipd') {
        $scopeSql = " AND o.an IS NOT NULL AND TRIM(o.an) <> '' ";
    }

    $icode_in = function_exists('wf_sql_warfarin_icode_in') ? wf_sql_warfarin_icode_in($hos, 'o') : '';
    if ($icode_in !== '') {
        $sql = "
            SELECT DISTINCT o.hn
            FROM opitemrece o
            WHERE $icode_in
              AND o.vstdate BETWEEN '$s' AND '$e'
              $scopeSql
            ORDER BY o.hn ASC
            LIMIT $limit
        ";
    } else {
        $joins = dr_sql_drug_joins();
        $name_clause = wf_sql_warfarin_name_clause('d', 'tm');
        $sql = "
            SELECT DISTINCT o.hn
            FROM opitemrece o
            $joins
            WHERE $name_clause
              AND o.vstdate BETWEEN '$s' AND '$e'
              $scopeSql
            ORDER BY o.hn ASC
            LIMIT $limit
        ";
    }
    $hns = [];
    $q = @mysqli_query($hos, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $hn = trim((string)($r['hn'] ?? ''));
            if ($hn !== '') {
                $hns[] = $hn;
            }
        }
    }
    return $hns;
}

/**
 * กรอง HN จากรายชื่อที่กำหนด ว่ามียา Warfarin ในวันนั้นหรือไม่
 * @param string $scope all|opd|ipd
 * @return string[]
 */
function mwf_filter_hns_with_warfarin($hos, array $hn_list, $ymd, $scope = 'all') {
    $ymd = trim((string)$ymd);
    if ($ymd === '' || empty($hn_list)) {
        return [];
    }
    $hn_in = [];
    foreach ($hn_list as $hn) {
        $hn = trim((string)$hn);
        if ($hn === '') {
            continue;
        }
        $trimmed = ltrim($hn, '0');
        if ($trimmed === '') {
            $trimmed = '0';
        }
        foreach ([$hn, $trimmed, str_pad($trimmed, 9, '0', STR_PAD_LEFT)] as $h) {
            $hn_in[] = "'" . mysqli_real_escape_string($hos, $h) . "'";
        }
    }
    $hn_in = array_values(array_unique($hn_in));
    if (empty($hn_in)) {
        return [];
    }

    $scope = mwf_normalize_scope($scope);
    $joins = dr_sql_drug_joins();
    $name_clause = wf_sql_warfarin_name_clause('d', 'tm');
    $d = mysqli_real_escape_string($hos, $ymd);
    $scopeSql = '';
    if ($scope === 'opd') {
        $scopeSql = " AND o.vn IS NOT NULL AND TRIM(o.vn) <> '' ";
    } elseif ($scope === 'ipd') {
        $scopeSql = " AND o.an IS NOT NULL AND TRIM(o.an) <> '' ";
    }

    $sql = "
        SELECT DISTINCT o.hn
        FROM opitemrece o
        $joins
        WHERE $name_clause
          AND o.hn IN (" . implode(',', $hn_in) . ")
          AND COALESCE(NULLIF(o.rxdate, '0000-00-00'), o.vstdate) = '$d'
          $scopeSql
    ";
    $hns = [];
    $q = @mysqli_query($hos, $sql);
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $hn = trim((string)($r['hn'] ?? ''));
            if ($hn !== '') {
                $hns[] = $hn;
            }
        }
    }
    return $hns;
}

/**
 * ประเมิน Warfarin ของ HN ในวันเดียว ตามกฎแจ้งเตือนที่เปิดไว้
 * @return array{has_row:bool,alerts:array}
 */
function mwf_evaluate_hn_date($con, $hos, $hn, $ymd, $protocolId, $inrMaxDays, array $rules, $scope = 'all') {
    $ymd = trim((string)$ymd);
    $hist = wf_build_therapy_history($con, $hos, $hn, $protocolId, null, 36, 40, $inrMaxDays);
    $alerts = [];
    $has_row = false;
    foreach ($hist['rows'] ?? [] as $r) {
        $date = trim((string)($r['date'] ?? ''));
        if ($date !== $ymd) {
            continue;
        }
        if (!mwf_source_matches_scope($r['source'] ?? '', $scope)) {
            continue;
        }
        $has_row = true;
        $verdict = trim((string)($r['assess_verdict'] ?? ''));
        $ruleVerdict = ($verdict === 'baseline') ? 'unknown' : $verdict;
        if (!isset($rules[$ruleVerdict])) {
            continue;
        }
        $rule = $rules[$ruleVerdict];
        $label = trim((string)($r['assess_label'] ?? ''));
        $detail = trim((string)($r['assess_detail'] ?? ''));
        $msg = trim((string)($rule['alert_message'] ?? ''));
        if ($msg === '') {
            $msg = trim($label . ($detail !== '' ? ' — ' . $detail : ''));
        }
        $alerts[] = [
            'alert_level' => mwf_alert_level($rule),
            'alert_message' => $msg,
            'assess_label' => $label,
            'assess_detail' => $detail,
            'assess_verdict' => $verdict,
            'mg_week' => $r['mg_week'] ?? null,
            'prev_mg_week' => $r['prev_mg_week'] ?? null,
            'pct_change' => $r['pct_change'] ?? null,
            'inr' => $r['inr'] ?? null,
            'inr_date_th' => $r['inr_date_th'] ?? null,
            'methods' => $r['methods'] ?? '',
            'source' => $r['source'] ?? '',
        ];
    }
    return ['has_row' => $has_row, 'alerts' => $alerts];
}

function mwf_patient_name($hos, $hn) {
    $hn_sql = function_exists('dr_hn_sql_in') ? dr_hn_sql_in($hos, $hn) : '';
    if ($hn_sql === '') {
        return '';
    }
    $sql = "SELECT CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) AS ptname
            FROM patient p WHERE p.hn IN ($hn_sql) LIMIT 1";
    $q = @mysqli_query($hos, $sql);
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        return trim((string)($r['ptname'] ?? ''));
    }
    return '';
}

/** แปลง source ของ episode เป็น OPD/IPD */
function mwf_type_patient_from_source($source) {
    $s = strtolower(trim((string)$source));
    if ($s === 'ipd') {
        return 'IPD';
    }
    if ($s === 'opd') {
        return 'OPD';
    }
    return 'OPD';
}

function mwf_source_matches_scope($source, $scope) {
    $scope = mwf_normalize_scope($scope);
    if ($scope === 'all') {
        return true;
    }
    $type = strtolower(mwf_type_patient_from_source($source));
    return $type === $scope;
}

/** เรียงวันที่+เวลาล่าสุดก่อน แล้วตาม HN */
function mwf_sort_latest_first(array &$rows) {
    usort($rows, function ($a, $b) {
        $c = strcmp((string)($b['date'] ?? ''), (string)($a['date'] ?? ''));
        if ($c !== 0) {
            return $c;
        }
        $c = strcmp((string)($b['time'] ?? ''), (string)($a['time'] ?? ''));
        if ($c !== 0) {
            return $c;
        }
        return strcmp((string)($a['hn'] ?? ''), (string)($b['hn'] ?? ''));
    });
}

/**
 * สแกนประวัติ Warfarin ในช่วงวันที่ → dashboard + alerts ตามกฎที่ตั้งไว้
 * @param string $protocolOverride
 * @param string $scopeOverride all|opd|ipd|'' (=ใช้ค่าจาก config)
 * @return array
 */
function mwf_scan($con, $hos, $startYmd, $endYmd, $protocolOverride = '', $scopeOverride = '', $hnList = null) {
    $config = mwf_get_config($con);
    if (empty($config['monitor_active'])) {
        return [
            'ok' => true,
            'summary' => ['ok' => 0, 'mismatch' => 0, 'other' => 0, 'total' => 0],
            'dashboard' => [],
            'hard_alerts' => [],
            'soft_alerts' => [],
            'meta' => [
                'message' => 'Monitor Warfarin ถูกปิดใช้งาน — ไปที่แท็บตั้งค่าเพื่อเปิด',
                'hn_count' => 0,
                'protocol_id' => $config['default_protocol_id'],
                'scope' => $config['monitor_scope'],
            ],
        ];
    }

    $defaultProtocol = $protocolOverride !== '' ? $protocolOverride : $config['default_protocol_id'];
    $scope = $scopeOverride !== '' ? mwf_normalize_scope($scopeOverride) : $config['monitor_scope'];
    $inrMaxDays = (int)$config['inr_assess_max_days'];
    $rules = mwf_rules_by_verdict($con, true);

    $hns = [];
    if (is_array($hnList) && !empty($hnList)) {
        $hns = mwf_parse_hn_list($hnList, 12);
    } else {
        $hns = mwf_fetch_warfarin_hns($hos, $startYmd, $endYmd, 400, $scope);
    }
    $summary = ['ok' => 0, 'mismatch' => 0, 'other' => 0, 'total' => 0];
    $dashboard = [];
    $hard = [];
    $soft = [];

    foreach ($hns as $hn) {
        if (function_exists('hosxp_ensure_connection')) {
            hosxp_ensure_connection($con, $hos, 90);
        }
        $pref = function_exists('wf_hn_pref_get') ? wf_hn_pref_get($con, $hn) : [];
        $protocolId = trim((string)($pref['protocol_id'] ?? '')) ?: $defaultProtocol;

        $inrPayload = null;
        if (function_exists('wf_fetch_inr')) {
            $inrPayload = wf_fetch_inr($con, $hos, $hn, 6, 16);
        }
        $hist = wf_build_therapy_history($con, $hos, $hn, $protocolId, $inrPayload, 6, 12, $inrMaxDays);
        $rows = $hist['rows'] ?? [];
        if (empty($rows)) {
            continue;
        }

        $ptname = '';
        foreach ($rows as $r) {
            $date = trim((string)($r['date'] ?? ''));
            if ($date === '' || $date < $startYmd || $date > $endYmd) {
                continue;
            }
            if (!mwf_source_matches_scope($r['source'] ?? '', $scope)) {
                continue;
            }

            $verdict = $r['assess_verdict'] ?? '';
            $label = $r['assess_label'] ?? '';
            $detail = $r['assess_detail'] ?? '';
            $badge = $r['assess_badge'] ?? 'secondary';
            $inrUsable = !empty($r['inr_usable']);
            $inrDays = isset($r['inr_days_diff']) ? (int)$r['inr_days_diff'] : null;

            $bucket = mwf_dashboard_bucket($verdict);
            $summary[$bucket]++;
            $summary['total']++;

            if ($ptname === '') {
                $ptname = mwf_patient_name($hos, $hn);
            }

            $typePatient = mwf_type_patient_from_source($r['source'] ?? '');
            $item = [
                'hn' => $hn,
                'ptname' => $ptname,
                'date' => $date,
                'date_th' => $r['date_th'] ?? wf_format_date_th($date),
                'time' => $r['time'] ?? '',
                'time_hm' => $r['time_hm'] ?? (function_exists('wf_format_time_hm') ? wf_format_time_hm($r['time'] ?? '') : ''),
                'mg_week' => $r['mg_week'],
                'prev_mg_week' => $r['prev_mg_week'],
                'pct_change' => $r['pct_change'],
                'inr' => $r['inr'] ?? null,
                'inr_date_th' => $r['inr_date_th'] ?? null,
                'inr_usable' => $inrUsable,
                'inr_stale' => !empty($r['inr_stale']),
                'inr_days_diff' => $inrDays,
                'methods' => $r['methods'] ?? '',
                'qty_label' => $r['qty_label'] ?? '',
                'source' => $r['source'] ?? '',
                'type_patient' => $typePatient,
                'protocol_id' => $protocolId,
                'assess_verdict' => $verdict,
                'assess_label' => $label,
                'assess_detail' => $detail,
                'assess_badge' => $badge,
                'bucket' => $bucket,
                'bucket_label' => mwf_bucket_label($bucket),
                'calculator_url' => 'warfarin_calculator.php?hn=' . rawurlencode($hn),
            ];
            $dashboard[] = $item;

            // แจ้งเตือนตามกฎที่เปิดไว้
            $ruleVerdict = $verdict;
            if ($ruleVerdict === 'baseline') {
                $ruleVerdict = 'unknown';
            }
            if (isset($rules[$ruleVerdict])) {
                $rule = $rules[$ruleVerdict];
                $alert = $item;
                $alert['alert_level'] = mwf_alert_level($rule);
                $alert['alert_message'] = trim((string)($rule['alert_message'] ?? '')) !== ''
                    ? $rule['alert_message']
                    : ($label . ' — ' . $detail);
                $alert['rule_id'] = (int)$rule['id'];
                $alert['rule_label'] = $rule['label_th'] ?? $label;
                if ($alert['alert_level'] === 'hard') {
                    $hard[] = $alert;
                } else {
                    $soft[] = $alert;
                }
            }
        }
    }

    mwf_sort_latest_first($dashboard);
    mwf_sort_latest_first($hard);
    mwf_sort_latest_first($soft);

    return [
        'ok' => true,
        'summary' => $summary,
        'dashboard' => $dashboard,
        'hard_alerts' => $hard,
        'soft_alerts' => $soft,
        'meta' => [
            'message' => null,
            'hn_count' => count($hns),
            'row_count' => count($dashboard),
            'protocol_id' => $defaultProtocol,
            'inr_assess_max_days' => $inrMaxDays,
            'scope' => $scope,
            'scope_label' => mwf_scope_label($scope),
            'start_date' => $startYmd,
            'end_date' => $endYmd,
        ],
    ];
}
