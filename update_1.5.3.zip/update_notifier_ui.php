<?php
/**
 * UI แจ้งเตือนอัปเดต — include จาก sidebar เมื่อล็อกอินแล้ว
 */
if (!isset($_SESSION['user_id'])) {
    return;
}
?>
<div class="modal fade" id="thamUpdateModal" tabindex="-1" aria-labelledby="thamUpdateModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-header text-white" style="background:#1f4d3b;">
        <h5 class="modal-title fw-bold" id="thamUpdateModalLabel">
          <i class="fas fa-cloud-download-alt me-2"></i>พบอัปเดตระบบใหม่
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p class="mb-2">
          เวอร์ชันปัจจุบัน:
          <strong id="thamUpdateLocalVer" class="text-warning">-</strong>
          → เวอร์ชันล่าสุด:
          <strong id="thamUpdateRemoteVer" class="text-danger">-</strong>
        </p>
        <div id="thamUpdateDetails" class="small text-muted mb-3"></div>
        <p class="small mb-0 text-secondary">ต้องการอัปเดตตอนนี้ หรือให้เตือนอีกครั้งภายหลัง?</p>
      </div>
      <div class="modal-footer flex-wrap gap-2 justify-content-between">
        <div class="d-flex flex-wrap gap-2">
          <button type="button" class="btn btn-outline-secondary btn-sm" id="thamUpdateSnooze7">
            เตือนในอีก 7 วัน
          </button>
          <button type="button" class="btn btn-outline-secondary btn-sm" id="thamUpdateSnooze30">
            เตือนในอีก 30 วัน
          </button>
        </div>
        <a href="upgrade.php" class="btn btn-success btn-sm fw-bold" id="thamUpdateNowBtn">
          <i class="fas fa-rocket me-1"></i>อัปเกรดทันที
        </a>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  if (window.__thamUpdateCheckBound) return;
  window.__thamUpdateCheckBound = true;

  function esc(s) {
    var d = document.createElement('div');
    d.textContent = s == null ? '' : String(s);
    return d.innerHTML;
  }

  function snooze(days) {
    return fetch('check_update_api.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'snooze', days: days })
    }).then(function (r) { return r.json(); });
  }

  function showModal(data) {
    var localEl = document.getElementById('thamUpdateLocalVer');
    var remoteEl = document.getElementById('thamUpdateRemoteVer');
    var detailsEl = document.getElementById('thamUpdateDetails');
    if (!localEl || !remoteEl) return;

    localEl.textContent = data.local_version || '-';
    remoteEl.textContent = data.remote_version || '-';
    detailsEl.innerHTML = data.update_details
      ? ('<strong>รายละเอียด:</strong> ' + esc(data.update_details))
      : '';

    var modalEl = document.getElementById('thamUpdateModal');
    if (!modalEl) return;

    if (window.bootstrap && bootstrap.Modal) {
      bootstrap.Modal.getOrCreateInstance(modalEl).show();
      return;
    }
    // fallback ถ้ายังไม่มี bootstrap
    modalEl.style.display = 'block';
    modalEl.classList.add('show');
  }

  function bindSnooze(btnId, days) {
    var btn = document.getElementById(btnId);
    if (!btn) return;
    btn.addEventListener('click', function () {
      btn.disabled = true;
      snooze(days).then(function (res) {
        if (res.status !== 'success') {
          alert(res.message || 'บันทึกไม่สำเร็จ');
          btn.disabled = false;
          return;
        }
        var modalEl = document.getElementById('thamUpdateModal');
        if (window.bootstrap && bootstrap.Modal && modalEl) {
          bootstrap.Modal.getOrCreateInstance(modalEl).hide();
        } else if (modalEl) {
          modalEl.style.display = 'none';
        }
      }).catch(function () {
        alert('เชื่อมต่อไม่สำเร็จ');
        btn.disabled = false;
      });
    });
  }

  function runCheck() {
    // เบราว์เซอร์บอกว่า offline — ไม่ยิง API เลย
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return;
    }

    var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = null;
    if (controller) {
      timer = setTimeout(function () { controller.abort(); }, 4000);
    }

    fetch('check_update_api.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'check' }),
      signal: controller ? controller.signal : undefined
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data.status !== 'success' || !data.show_prompt) return;
        showModal(data);
      })
      .catch(function () { /* offline / timeout — ไม่รบกวนการใช้งาน */ })
      .finally(function () {
        if (timer) clearTimeout(timer);
      });
  }

  bindSnooze('thamUpdateSnooze7', 7);
  bindSnooze('thamUpdateSnooze30', 30);

  // เช็คเฉพาะเมื่อออนไลน์ และเมื่อกลับมาออนไลน์ใหม่
  function scheduleCheck() {
    setTimeout(runCheck, 800);
  }

  if (document.readyState === 'complete') {
    scheduleCheck();
  } else {
    window.addEventListener('load', scheduleCheck);
  }
  window.addEventListener('online', function () {
    setTimeout(runCheck, 1000);
  });
})();
</script>
